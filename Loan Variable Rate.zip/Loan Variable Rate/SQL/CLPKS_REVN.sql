CREATE OR REPLACE PACKAGE BODY clpks_revn IS

  PKG_PRINCIPAL CLTBS_ACCOUNT_SCHEDULES.COMPONENT_NAME%TYPE;

  PKG_EVENT   VARCHAR2(4);
  G_DIARY_KEY VARCHAR2(50) := 'ABC';

  G_UDE_CALC_REQD BOOLEAN := FALSE;

  L_FUNCTION_ID SMTBS_MENU.FUNCTION_ID%TYPE := '**';
  TYPE TY_TB_RATE_ROWID IS TABLE OF ROWID INDEX BY PLS_INTEGER;

  TYPE REC_ACC_UDE_CHG_ARVN IS RECORD(
    P_ROWID        ROWID,
    P_ROWID_1      ROWID,
    ACCOUNT_NUMBER CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
    PROCESS_NO     CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
    VERSION_NO     CLTBS_ACCOUNT_MASTER.VERSION_NO%TYPE,
    SEQ_NO         CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
    UDE_ID         CLTBS_ACCOUNT_UDE_VALUES.UDE_ID%TYPE,
    RESOLVED_VALUE CLTBS_ACCOUNT_UDE_VALUES.RESOLVED_VALUE%TYPE,
    UDE_EFF_DT     CLTBS_ACCOUNT_UDE_VALUES.EFFECTIVE_DATE%TYPE,
    UDE_RATE_CODE  CLTBS_ACCOUNT_UDE_VALUES.RATE_CODE%TYPE,
    RATE_DT        CLTMS_EFFECTED_RATES.EFFECTIVE_DATE%TYPE,
    COMPONENT_NAME CLTBS_ACCOUNT_EVENTS_DIARY.COMPONENT_NAME%TYPE);

  TYPE REF_ACC_UDE_CHG_ARVN IS REF CURSOR RETURN REC_ACC_UDE_CHG_ARVN;
  TYPE TY_TB_ACC_UDE_DET IS TABLE OF REC_ACC_UDE_CHG_ARVN INDEX BY PLS_INTEGER;

  TYPE REC_ALL_REVN IS RECORD(
    ACCOUNT_NUMBER CLTBS_ACCOUNT_EVENTS_DIARY.ACCOUNT_NUMBER%TYPE,
    BRANCH_CODE    CLTBS_ACCOUNT_EVENTS_DIARY.BRANCH_CODE%TYPE,
    EXECUTION_DATE CLTBS_ACCOUNT_EVENTS_DIARY.EXECUTION_DATE%TYPE);

  TYPE REF_ALL_REVN IS REF CURSOR RETURN REC_ALL_REVN;
  TYPE TY_ACC_REVN IS TABLE OF REC_ALL_REVN INDEX BY PLS_INTEGER;

  TYPE REC_UDE_ACC_AFFECTED IS RECORD(
    ACC_ROW_ID     ROWID,
    ACC_NO         CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
    SEQ_NO         CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
    ACC_PROCESS_NO CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
    UDE_ROW_ID     ROWID,
    UDE_ID         CLTBS_ACCOUNT_UDE_VALUES.UDE_ID%TYPE,
    UDE_EFF_DT     CLTBS_ACCOUNT_UDE_VALUES.EFFECTIVE_DATE%TYPE,
    UDE_VAL        CLTBS_ACCOUNT_UDE_VALUES.UDE_VALUE%TYPE,
    RATE_CODE      CLTBS_ACCOUNT_UDE_VALUES.RATE_CODE%TYPE,
    RESOLVED_VALUE CLTBS_ACCOUNT_UDE_VALUES.RESOLVED_VALUE%TYPE,
    CODE_USAGE     CLTBS_ACCOUNT_UDE_VALUES.CODE_USAGE%TYPE,
    OLD_VAL        CLTMS_UDE_CASCADE_DETAIL.OLD_UDE_VALUE%TYPE,
    NEW_VAL        CLTMS_UDE_CASCADE_DETAIL.NEW_UDE_VALUE%TYPE);

  TYPE REF_UDE_ACC_AFFECTED IS REF CURSOR RETURN REC_UDE_ACC_AFFECTED;
  TYPE TY_UDE_ACC_AFFECTED IS TABLE OF REC_UDE_ACC_AFFECTED INDEX BY PLS_INTEGER;

  TYPE TY_TB_REVN_ACCOUNTS IS TABLE OF CLTBS_REVISION_ACCOUNTS%ROWTYPE INDEX BY PLS_INTEGER;

  FUNCTION FN_PROCESS_CHARGE(P_ACCOUNT_OBJ  IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                             P_ESN          IN CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
                             P_TB_CHARGES   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES,
                             P_TB_ENTRIES   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES,
                             P_TB_SCH_ROWID IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_ROWID,
                             P_TB_SCH_ROW   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES,
                             P_ERROR_CODE   IN OUT VARCHAR2,
                             P_ERROR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN,
                               P_BRANCH_CODE        IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               P_EVENT_CODE         IN CLTBS_ACCOUNT_EVENTS_DIARY.EVENT_CODE%TYPE,
                               L_TB_RT_ROW_ID       IN OUT TY_TB_RATE_ROWID,
                               P_FOR_AN_ACCOUNT     IN BOOLEAN,
                               P_ERRORCODE          IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_PROCESS_REVISION(P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               CUR_ALL_REV_ACC  REF_ALL_REVN_ACC,
                               CUR_ALL_REV_UDE  REF_ALL_REVN_UDE,
                               CUR_ALL_REVN     REF_ALL_REVN,
                               P_FOR_AN_ACCOUNT IN BOOLEAN

                              ,
                               P_PROC_DATE IN DATE

                              ,
                               P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_PROCESS_NO     IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE

                              ,
                               P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_PROCESS_UDCN(P_BRANCH_CODE        IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                           CUR_UDE_ACC_AFFECTED IN REF_UDE_ACC_AFFECTED,
                           P_UDE_EFF_DT         IN DATE,
                           P_REFERENCE          IN CLTMS_UDE_CASCADE_MASTER.REFERENCE%TYPE,
                           L_PROCESSED_ALL_ACCS OUT BOOLEAN,
                           P_FOR_AN_ACCOUNT     IN BOOLEAN,
                           P_ERRORCODE          IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                           P_ERRORPARAM         IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_PROCESS_REVN_MRG(P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               CUR_ALL_REV_ACC  REF_ALL_REVN_ACC,
                               CUR_ALL_REV_UDE  REF_ALL_REVN_UDE,
                               CUR_ALL_REVN     REF_ALL_REVN,
                               P_FOR_AN_ACCOUNT IN BOOLEAN,
                               P_PROC_DATE      IN DATE,
                               P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_PROCESS_NO     IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                               P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE DBG(A IN VARCHAR2) IS
  BEGIN

    IF DEBUG.PKG_DEBUG_ON <> 2 THEN

      DEBUG.PR_DEBUG('CL', 'clpks_revn->' || A);

    END IF;

  END;

  FUNCTION FN_GET_TDRATE(P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                         P_BRANCH_CODE    IN CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE,
                         P_RATE_CODE      IN CLTBS_ACCOUNT_TDUDE_RATE.RATE_CODE%TYPE,
                         P_EFF_DATE       IN CLTBS_ACCOUNT_TDUDE_RATE.EFFECTIVE_DATE%TYPE,
                         P_TD_RATE        OUT CLTBS_ACCOUNT_TDUDE_RATE.INT_RATE%TYPE,
                         P_ERROR_CODE     IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERROR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('TD rate picking for Account Number is ' || P_ACCOUNT_NUMBER);
    DBG('RATE CODE OF CONTRACT IS' || P_RATE_CODE);
    DBG('p_eff_date ' || P_EFF_DATE);
    BEGIN
      SELECT INT_RATE
        INTO P_TD_RATE
        FROM CLTBS_ACCOUNT_TDUDE_RATE
       WHERE BRANCH_CODE = P_BRANCH_CODE
         AND ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND PROCESSED IN ('N', 'F')
         AND RATE_CODE = P_RATE_CODE
         AND PROCESSING_DATE IS NULL
         AND EFFECTIVE_DATE = P_EFF_DATE;
    EXCEPTION
      WHEN OTHERS THEN
        P_TD_RATE    := 0;
        P_ERROR_CODE := 'CL-TD-12;';
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, '');
        DBG('Failed in When others' || SQLERRM);
        RETURN FALSE;
    END;
    RETURN TRUE;
  END;

  FUNCTION FN_UDE_CASCADE(P_ACC_NO      IN CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                          P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_VALUES.BRANCH_CODE%TYPE,
                          L_TB_UDCN_UDE IN OUT NOCOPY TY_TB_UDCN_UDE,

                          L_ACC_AFF_FLAG             OUT BOOLEAN,
                          P_CAS_MAS_EFF_DT           IN CLTBS_ACCOUNT_UDE_VALUES.EFFECTIVE_DATE%TYPE,
                          L_TB_UPD_UDCN_UDE_VAL      IN OUT NOCOPY TY_TB_UPD_UDCN_UDE_VAL,
                          L_TB_UPD_UDCN_UDE_RSLV_VAL IN OUT NOCOPY TY_TB_UPD_UDCN_UDE_RSLV_VAL,
                          L_TB_UPD_UDCN_ROW_ID       IN OUT NOCOPY TY_TB_UPD_UDCN_ROW_ID,
                          L_TB_INS_UDCN_UDE_VALS     IN OUT NOCOPY TY_TB_INS_UDCN_UDE_VALS,

                          L_TY_TB_EFF_DT IN OUT NOCOPY TY_TB_EFF_DT,

                          P_ERRORCODE IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_PROCESS_CHGS_ENTRIES(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_VALUES.BRANCH_CODE%TYPE,
                                   P_ACC_NO      IN CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                                   P_ESN         IN CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
                                   P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                   P_ERRORPARAM  IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_MARGIN_PKUP_PERIODIC(CONTRACT_REF_NO IN CFTM_MARGIN_COMPONENT.CONTRACT_REF_NO%TYPE,
                                   P_MARGIN_RATE   OUT CFTM_MARGIN_EFFDATE.MARGIN_RATE%TYPE)
    RETURN BOOLEAN IS
    L_REP_TYPE       CLTM_PRODUCT_COMPONENTS.COMP_REPORTING_TYPE%TYPE;
    L_REF_NO         VARCHAR2(35);
    L_CUST_ID        CLTB_ACCOUNT_MASTER.CUSTOMER_ID%TYPE;
    L_COMPONENT_NAME CLTM_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
    L_COUNT          NUMBER(2);

    CURSOR CR_MARGIN_COMPONENTS(L_CONTRACT_REF_NO LSTB_DRAWDOWN_SCHEDULE.DRAWDOWN_ACCOUNT_NUMBER%TYPE) IS

      SELECT A.COMPONENT_NAME
        FROM CLTM_PRODUCT_COMPONENTS A
       WHERE A.COMPONENT_TYPE = 'G'
         AND A.PRODUCT_CODE = SUBSTR(L_CONTRACT_REF_NO, 4, 4);
  BEGIN

    DBG('Start of fn_margin_pickup_periodic');

    FOR CR_CUR_REC IN CR_MARGIN_COMPONENTS(CONTRACT_REF_NO) LOOP
      DBG('BEFORE IDENTIFYING DD');

      BEGIN
        DBG('before identifying the comp rep typ');
        SELECT A.COMP_REPORTING_TYPE
          INTO L_REP_TYPE
          FROM CLTM_PRODUCT_COMPONENTS A
         WHERE A.COMPONENT_TYPE = 'G'
           AND A.PRODUCT_CODE = SUBSTR(CONTRACT_REF_NO, 4, 4)
           AND COMPONENT_NAME = CR_CUR_REC.COMPONENT_NAME;

        DBG('before identifying the comp rep type' || L_REP_TYPE);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In No data found for comp repttype');
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('failed in getting comp_reporting_type' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('before identifying the comp rep type' || L_REP_TYPE);
      BEGIN
        DBG('before identifying the customer');
        SELECT C.CUSTOMER_NO
          INTO L_CUST_ID
          FROM CLTB_ACCOUNT_MASTER A, STTM_CUSTOMER C
         WHERE A.ACCOUNT_NUMBER = CONTRACT_REF_NO
           AND A.MODULE_CODE = 'LS'
           AND A.LOAN_TYPE IN ('L', 'E')
           AND A.AUTH_STAT = 'A'
           AND A.ACCOUNT_STATUS IN ('Y', 'A')
           AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
           AND A.CUSTOMER_ID = C.CUSTOMER_NO;

        DBG('after identifying the customer' || L_CUST_ID);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In No data found for customer');
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('failed in getting customer_no' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('after identifying the customer' || L_CUST_ID);
      IF L_REP_TYPE = 'FC' THEN
        BEGIN
          DBG('before identifying the facility');
          SELECT A.FACILITY_REF_NO
            INTO L_REF_NO
            FROM LSTB_DRAWDOWN_SCHEDULE A
           WHERE A.DRAWDOWN_ACCOUNT_NUMBER = CONTRACT_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('In No data found for facility');
            RETURN FALSE;
          WHEN OTHERS THEN
            DBG('failed in getting facility_ref_no' || SQLERRM);
            RETURN FALSE;
        END;
        DBG('after identifying the facility' || L_REF_NO);
      ELSE
        IF L_REP_TYPE = 'TR' THEN
          DBG('before identifying the tranche');
          BEGIN
            SELECT A.TRANCHE_REF_NO
              INTO L_REF_NO
              FROM LSTB_DRAWDOWN_SCHEDULE A
             WHERE A.DRAWDOWN_ACCOUNT_NUMBER = CONTRACT_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('In No data found for tranche');
              RETURN FALSE;
            WHEN OTHERS THEN
              DBG('failed in getting tranche' || SQLERRM);
              RETURN FALSE;
          END;
          DBG('after identifying the tranch' || L_REF_NO);
        ELSIF L_REP_TYPE = 'DD' THEN
          DBG('before identifying the DD');
          BEGIN
            SELECT A.DRAWDOWN_ACCOUNT_NUMBER
              INTO L_REF_NO
              FROM LSTB_DRAWDOWN_SCHEDULE A
             WHERE A.DRAWDOWN_ACCOUNT_NUMBER = CONTRACT_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('In No data found for DD');
              RETURN FALSE;
            WHEN OTHERS THEN
              DBG('failed in getting DD' || SQLERRM);
              RETURN FALSE;
          END;
        ELSE
          RETURN FALSE;
        END IF;
      END IF;

      DBG('after identifying the DD' || L_REF_NO);
      BEGIN
        DBG('Component is ' || CR_CUR_REC.COMPONENT_NAME);
        DBG('CRN is ' || L_REF_NO);
        BEGIN
          DBG('inside margin rate pickup');
          SELECT A.MARGIN_RATE
            INTO P_MARGIN_RATE
            FROM CFTMS_MARGIN_EFFDATE A
           WHERE A.CONTRACT_REF_NO = L_REF_NO
             AND A.COMPONENT = CR_CUR_REC.COMPONENT_NAME
             AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
             AND A.CUSTOMER_NO = L_CUST_ID
             AND A.EFFECTIVE_DATE =
                 (SELECT MAX(EFFECTIVE_DATE)
                    FROM CFTMS_MARGIN_EFFDATE
                   WHERE CONTRACT_REF_NO = L_REF_NO
                     AND A.COMPONENT = CR_CUR_REC.COMPONENT_NAME
                     AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                     AND CUSTOMER_NO = L_CUST_ID
                     AND NVL(MARGIN_RECORD_STATUS, '@') <> 'A');
          DBG('after margin rate pickup' || P_MARGIN_RATE);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('inside no data found for margin rate');
            SELECT COUNT(*)
              INTO L_COUNT
              FROM CFTMS_MARGIN_EFFDATE A
             WHERE A.CONTRACT_REF_NO = 'ALL'
               AND A.COMPONENT = 'ALL'
               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND A.CUSTOMER_NO IN (L_CUST_ID, 'ALL')
               AND A.EFFECTIVE_DATE =
                   (SELECT MAX(EFFECTIVE_DATE)
                      FROM CFTMS_MARGIN_EFFDATE
                     WHERE CONTRACT_REF_NO = 'ALL'
                       AND COMPONENT = 'ALL'
                       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND CUSTOMER_NO IN (L_CUST_ID, 'ALL')
                       AND NVL(MARGIN_RECORD_STATUS, '@') <> 'A');
            IF L_COUNT = 2 THEN
              DBG('after margin rate pickup for customer');
              SELECT A.MARGIN_RATE
                INTO P_MARGIN_RATE
                FROM CFTMS_MARGIN_EFFDATE A
               WHERE A.CONTRACT_REF_NO = 'ALL'
                 AND A.COMPONENT = 'ALL'
                 AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND A.CUSTOMER_NO = L_CUST_ID
                 AND A.EFFECTIVE_DATE =
                     (SELECT MAX(EFFECTIVE_DATE)
                        FROM CFTMS_MARGIN_EFFDATE
                       WHERE CONTRACT_REF_NO = 'ALL'
                         AND A.COMPONENT = 'ALL'
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                         AND CUSTOMER_NO = L_CUST_ID
                         AND NVL(MARGIN_RECORD_STATUS, '@') <> 'A');
              DBG('after margin rate pickup  for customer' ||
                  P_MARGIN_RATE);
            ELSE
              DBG('after margin rate pickup for all');
              SELECT A.MARGIN_RATE
                INTO P_MARGIN_RATE
                FROM CFTMS_MARGIN_EFFDATE A
               WHERE A.CONTRACT_REF_NO = 'ALL'
                 AND A.COMPONENT = 'ALL'
                 AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND A.CUSTOMER_NO IN (L_CUST_ID, 'ALL')
                 AND A.EFFECTIVE_DATE =
                     (SELECT MAX(EFFECTIVE_DATE)
                        FROM CFTMS_MARGIN_EFFDATE
                       WHERE CONTRACT_REF_NO = 'ALL'
                         AND A.COMPONENT = 'ALL'
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                         AND CUSTOMER_NO IN (L_CUST_ID, 'ALL')
                         AND NVL(MARGIN_RECORD_STATUS, '@') <> 'A');
              DBG('after margin rate pickup for all' || P_MARGIN_RATE);
            END IF;
        END;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('failed in getting rate');
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('failed in getting rate' || SQLERRM);
          RETURN FALSE;
      END;
    END LOOP;
    DBG('RETURNING SUCESS FROM PERIODIC MARGIN PICKUP');
    RETURN TRUE;
  END FN_MARGIN_PKUP_PERIODIC;

  FUNCTION FN_MARGIN_PKUP_AUTO(P_CONTRACT_REF_NO IN CFTM_MARGIN_COMPONENT.CONTRACT_REF_NO%TYPE,
                               P_MARGIN_RATE     OUT CFTM_MARGIN_EFFDATE.MARGIN_RATE%TYPE)
    RETURN BOOLEAN IS
    L_REP_TYPE  CLTM_PRODUCT_COMPONENTS.COMP_REPORTING_TYPE%TYPE;
    L_COMP_NAME CLTM_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
    L_REF_NO    VARCHAR2(35);
    L_CUST_ID   CLTB_ACCOUNT_MASTER.CUSTOMER_ID%TYPE;
    L_COUNT     NUMBER(10);
    L_LOAN_TYPE CLTB_ACCOUNT_MASTER.LOAN_TYPE%TYPE;
    L_PR_TYO    CSTB_CONTRACT.PRODUCT_TYPE%TYPE;
    CURSOR CR_MARGIN_EFFCTIVE_DATE IS
      SELECT *
        FROM CFTM_MARGIN_EFFDATE A
       WHERE A.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND NVL(A.MARGIN_RECORD_STATUS, '@') <> 'A';
    CURSOR CR_MARGIN_DRAWDOWNS(L_TRANCHE_REF_NO LSTB_DRAWDOWN_SCHEDULE.TRANCHE_REF_NO%TYPE) IS
      SELECT A.ACCOUNT_NUMBER,
             B.DRAWDOWN_ACCOUNT_NUMBER,
             C.CONTRACT_REF_NO,
             C.CUSTOMER_NO,
             C.EFFECTIVE_DATE
        FROM CLTB_ACCOUNT_MASTER    A,
             LSTB_DRAWDOWN_SCHEDULE B,
             CFTM_MARGIN_EFFDATE    C
       WHERE A.ACCOUNT_NUMBER = L_TRANCHE_REF_NO
         AND B.TRANCHE_REF_NO = A.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND B.BRANCH_CODE = A.BRANCH_CODE
         AND C.CONTRACT_REF_NO = B.DRAWDOWN_ACCOUNT_NUMBER
         AND C.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND NVL(C.MARGIN_RECORD_STATUS, '@') <> 'A';
    CURSOR CR_MARGIN_DRAWDOWNS_FACILITY(L_TRANCHE_REF_NO LSTB_DRAWDOWN_SCHEDULE.TRANCHE_REF_NO%TYPE,
                                        L_DRAW_DOWN      LSTB_DRAWDOWN_SCHEDULE.DRAWDOWN_ACCOUNT_NUMBER%TYPE) IS
      SELECT A.ACCOUNT_NUMBER,
             B.DRAWDOWN_ACCOUNT_NUMBER,
             C.CONTRACT_REF_NO,
             C.CUSTOMER_NO,
             C.EFFECTIVE_DATE
        FROM CLTB_ACCOUNT_MASTER    A,
             LSTB_DRAWDOWN_SCHEDULE B,
             CFTM_MARGIN_EFFDATE    C
       WHERE A.ACCOUNT_NUMBER = L_TRANCHE_REF_NO
         AND B.TRANCHE_REF_NO = A.ACCOUNT_NUMBER
         AND B.DRAWDOWN_ACCOUNT_NUMBER = L_DRAW_DOWN
         AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND B.BRANCH_CODE = A.BRANCH_CODE
         AND C.CONTRACT_REF_NO = B.DRAWDOWN_ACCOUNT_NUMBER
         AND C.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND NVL(C.MARGIN_RECORD_STATUS, '@') <> 'A';
    CURSOR CR_MARGIN_TRANCHE(L_FACILITY_REF_NO LSTB_DRAWDOWN_SCHEDULE.FACILITY_REF_NO%TYPE) IS
      SELECT A.CONTRACT_REF_NO, B.TRANCHE_REF_NO, B.DRAWDOWN_ACCOUNT_NUMBER
        FROM CSTB_CONTRACT A, LSTB_DRAWDOWN_SCHEDULE B
       WHERE A.CONTRACT_REF_NO = L_FACILITY_REF_NO
         AND B.FACILITY_REF_NO = A.CONTRACT_REF_NO
         AND A.BRANCH = GLOBAL.CURRENT_BRANCH
         AND B.BRANCH_CODE = A.BRANCH;
    CURSOR CR_MARGIN_COMPONENTS(L_CONTRACT_REF_NO LSTB_DRAWDOWN_SCHEDULE.DRAWDOWN_ACCOUNT_NUMBER%TYPE) IS
      SELECT A.COMPONENT_NAME
        FROM CLTM_PRODUCT_COMPONENTS A
       WHERE A.COMPONENT_TYPE = 'G'
         AND A.PRODUCT_CODE = SUBSTR(L_CONTRACT_REF_NO, 4, 4);

  BEGIN
    DBG('INSIDE THE FUNCTION FOR AUTO MARGIN PICKUP');

    FOR C_CUR_COMP IN CR_MARGIN_COMPONENTS(P_CONTRACT_REF_NO) LOOP
      FOR C_CUR_REC IN CR_MARGIN_EFFCTIVE_DATE LOOP
        DBG('BEFORE SELECTING LOAN TYPE');
        IF C_CUR_REC.CONTRACT_REF_NO <> 'ALL' AND
           C_CUR_COMP.COMPONENT_NAME <> 'ALL' THEN
          BEGIN
            SELECT A.LOAN_TYPE
              INTO L_LOAN_TYPE
              FROM CLTB_ACCOUNT_MASTER A
             WHERE A.ACCOUNT_NUMBER = C_CUR_REC.CONTRACT_REF_NO;
            DBG('LOAN TYPE FROR CRN->' || C_CUR_REC.CONTRACT_REF_NO || '->' ||
                L_LOAN_TYPE);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                DBG('inside no data found for LOAN TYPE');
                SELECT A.PRODUCT_TYPE
                  INTO L_LOAN_TYPE
                  FROM CSTB_CONTRACT A
                 WHERE A.CONTRACT_REF_NO = C_CUR_REC.CONTRACT_REF_NO;
                DBG('PRODUCT TYPE IN NO DATA FOUND->' || L_LOAN_TYPE ||
                    '->AND THE FACILITY IS->' || C_CUR_REC.CONTRACT_REF_NO);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('inside no data found for PRODUCT');
                  RETURN FALSE;
                WHEN OTHERS THEN
                  DBG('INSIDE WHEN OTHERS FOR PRODUCT' || SQLERRM);
                  RETURN FALSE;
              END;
            WHEN OTHERS THEN
              DBG('INSIDE WHEN OTHERS FOR LOANS' || SQLERRM);
              RETURN FALSE;
          END;
          DBG('AFTER SELECTING LOAN TYPE->' || L_LOAN_TYPE);

          IF L_LOAN_TYPE IN ('L', 'E') THEN
            BEGIN
              DBG('MARGIN RATE FOR DRAW DOWNS');
              SELECT A.MARGIN_RATE
                INTO P_MARGIN_RATE
                FROM CFTMS_MARGIN_EFFDATE A
               WHERE A.CONTRACT_REF_NO = C_CUR_REC.CONTRACT_REF_NO
                 AND A.COMPONENT = C_CUR_COMP.COMPONENT_NAME
                 AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND A.CUSTOMER_NO = C_CUR_REC.CUSTOMER_NO
                 AND A.EFFECTIVE_DATE = C_CUR_REC.EFFECTIVE_DATE;
              DBG('MARGIN RATE IN DD IS->' || P_MARGIN_RATE);
              DBG(' DD IS->' || C_CUR_REC.CONTRACT_REF_NO);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                RETURN FALSE;
              WHEN OTHERS THEN
                DBG('INSIDE WHEN OTHERS FOR DRAWDOWNS' || SQLERRM);
                RETURN FALSE;
            END;
          ELSIF L_LOAN_TYPE = 'C' THEN
            FOR C_CUR_TRN IN CR_MARGIN_DRAWDOWNS(C_CUR_REC.CONTRACT_REF_NO) LOOP
              BEGIN
                DBG('INSIDE TRANCHE IDENTIFICATION');
                SELECT A.MARGIN_RATE
                  INTO P_MARGIN_RATE
                  FROM CFTMS_MARGIN_EFFDATE A
                 WHERE A.CONTRACT_REF_NO =
                       C_CUR_TRN.DRAWDOWN_ACCOUNT_NUMBER
                   AND A.COMPONENT = C_CUR_COMP.COMPONENT_NAME
                   AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND A.CUSTOMER_NO = C_CUR_TRN.CUSTOMER_NO
                   AND A.EFFECTIVE_DATE = C_CUR_TRN.EFFECTIVE_DATE;
                DBG('INSIDE TRANCHE IDENTIFICATION AND THE MARGIN RATE IS->' ||
                    P_MARGIN_RATE);
                DBG('INSIDE TRANCHE IDENTIFICATION AND THE DRAWDOWN IS->' ||
                    C_CUR_TRN.DRAWDOWN_ACCOUNT_NUMBER);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('INSIDE NO DATA FOUND FOR A TRANCHE');
                  RETURN FALSE;
                WHEN OTHERS THEN
                  DBG('INSIDE WHEN OTHERS FOR TRANCHE' || SQLERRM);
                  RETURN FALSE;
              END;
            END LOOP;
          ELSIF L_LOAN_TYPE = 'F' THEN
            FOR C_CUR_FACILITY IN CR_MARGIN_TRANCHE(C_CUR_REC.CONTRACT_REF_NO) LOOP
              FOR C_CUR_TRN IN CR_MARGIN_DRAWDOWNS_FACILITY(C_CUR_FACILITY.TRANCHE_REF_NO,
                                                            C_CUR_FACILITY.DRAWDOWN_ACCOUNT_NUMBER) LOOP
                DBG('INSIDE FACILTY IDENTIFICATION');
                BEGIN
                  SELECT A.MARGIN_RATE
                    INTO P_MARGIN_RATE
                    FROM CFTMS_MARGIN_EFFDATE A
                   WHERE A.CONTRACT_REF_NO =
                         C_CUR_TRN.DRAWDOWN_ACCOUNT_NUMBER
                     AND A.COMPONENT = C_CUR_COMP.COMPONENT_NAME
                     AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                     AND A.CUSTOMER_NO = C_CUR_TRN.CUSTOMER_NO
                     AND A.EFFECTIVE_DATE = C_CUR_TRN.EFFECTIVE_DATE;
                  DBG('INSIDE FACILTY IDENTIFICATION AND DRAWDOWN  IS->' ||
                      C_CUR_TRN.DRAWDOWN_ACCOUNT_NUMBER);
                  DBG('INSIDE FACILTY IDENTIFICATION AND THE MARGIN RATE IS->' ||
                      P_MARGIN_RATE);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    RETURN FALSE;
                  WHEN OTHERS THEN
                    DBG('INSIDE WHEN OTHERS FOR FACILITY' || SQLERRM);
                    RETURN FALSE;

                END;
              END LOOP;
            END LOOP;
          ELSE
            RETURN FALSE;
          END IF;
        ELSE
          DBG('INSIDE ALL');
          IF C_CUR_REC.CUSTOMER_NO <> 'ALL' THEN
            DBG('INSIDE ALL FOR CUSTOMER<>ALL');
            SELECT A.MARGIN_RATE
              INTO P_MARGIN_RATE
              FROM CFTMS_MARGIN_EFFDATE A
             WHERE A.CONTRACT_REF_NO = 'ALL'
               AND A.COMPONENT = 'ALL'
               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND A.CUSTOMER_NO = C_CUR_REC.CUSTOMER_NO
               AND A.EFFECTIVE_DATE = C_CUR_REC.EFFECTIVE_DATE;
            DBG('MARGIN_RATE FOR CUSTOMER<>ALL' || P_MARGIN_RATE);
          ELSE
            DBG('INSIDE ALL FOR CUSTOMER=ALL');
            SELECT A.MARGIN_RATE
              INTO P_MARGIN_RATE
              FROM CFTMS_MARGIN_EFFDATE A
             WHERE A.CONTRACT_REF_NO = 'ALL'
               AND A.COMPONENT = 'ALL'
               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND A.CUSTOMER_NO = 'ALL'
               AND A.EFFECTIVE_DATE = C_CUR_REC.EFFECTIVE_DATE;
            DBG('MARGIN RATE FOR CUSTOMER=ALL' || P_MARGIN_RATE);
          END IF;
        END IF;
      END LOOP;
    END LOOP;
    DBG('SUCESSFULLY RETURNING FROM AUTO MARGIN PICKUP');
    RETURN TRUE;
  END FN_MARGIN_PKUP_AUTO;

  FUNCTION FN_ARVN_MRG_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                              P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CUR_ACC_UDE_MRG_ARVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

    L_MARGIN_COUNT NUMBER;
    L_TDUDE_COUNT  NUMBER;

  BEGIN

    SELECT COUNT(1)
      INTO L_MARGIN_COUNT
      FROM CFTMS_MARGIN_EFFDATE
     WHERE BRANCH_CODE = P_BRANCH_CODE
       AND NVL(MARGIN_RECORD_STATUS, 'X') <> 'A';

    SELECT COUNT(1)
      INTO L_TDUDE_COUNT
      FROM CLTBS_ACCOUNT_TDUDE_RATE
     WHERE BRANCH_CODE = P_BRANCH_CODE
       AND PROCESSED IN ('N', 'F')
       AND PROCESSING_DATE IS NULL;

    IF (NVL(L_TDUDE_COUNT, 0) > 0) OR (NVL(L_MARGIN_COUNT, 0) > 0) THEN

      OPEN CUR_ACC_UDE_MRG_ARVN FOR
        SELECT RATES.ROWID            P_ROWID,
               ACC_MAS.ROWID          P_ROWID_1,
               ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
               ACC_MAS.PROCESS_NO     PROCESS_NO,
               ACC_MAS.VERSION_NO     VERSION_NO,
               ACC_MAS.LATEST_ESN     SEQ_NO,
               ACC_UDE.UDE_ID         UDE_ID,
               ACC_UDE.RESOLVED_VALUE RESOLVED_VALUE,
               ACC_UDE.EFFECTIVE_DATE UDE_EFF_DT,
               ACC_UDE.RATE_CODE      UDE_RATE_CODE,
               RATES.EFFECTIVE_DATE   RATE_DT,
               NULL                   COMPONENT_NAME
          FROM CLTBS_ACCOUNT_UDE_VALUES ACC_UDE,
               CLTBS_ACCOUNT_MASTER     ACC_MAS,
               CFTMS_MARGIN_EFFDATE     RATES
         WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
           AND RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
           AND ACC_UDE.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.CODE_USAGE = 'A'
           AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR
               ACC_MAS.ACCOUNT_STATUS = 'Y')
           AND ACC_MAS.AUTH_STAT = 'A'
           AND NVL(RATES.MARGIN_RECORD_STATUS, 'X') <> 'A'
           AND RATES.EFFECTIVE_DATE <= ACC_MAS.MATURITY_DATE
           AND ACC_MAS.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
           AND NOT EXISTS
         (SELECT 1
                  FROM CLTBS_PROCESSED_REVISIONS X
                 WHERE X.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = P_BRANCH_CODE)

        UNION
        SELECT TD_RATES.ROWID          P_ROWID,
               AC_MAS.ROWID            P_ROWID_1,
               AC_MAS.ACCOUNT_NUMBER   ACCOUNT_NUMBER,
               AC_MAS.PROCESS_NO       PROCESS_NO,
               AC_MAS.VERSION_NO       VERSION_NO,
               AC_MAS.LATEST_ESN       SEQ_NO,
               AC_UDE.UDE_ID           UDE_ID,
               AC_UDE.RESOLVED_VALUE   RESOLVED_VALUE,
               AC_UDE.EFFECTIVE_DATE   UDE_EFF_DT,
               AC_UDE.RATE_CODE        UDE_RATE_CODE,
               TD_RATES.EFFECTIVE_DATE RATE_DT,
               NULL                    COMPONENT_NAME
          FROM CLTBS_ACCOUNT_UDE_VALUES AC_UDE,
               CLTBS_ACCOUNT_MASTER     AC_MAS,
               CLTBS_ACCOUNT_TDUDE_RATE TD_RATES
         WHERE AC_MAS.BRANCH_CODE = P_BRANCH_CODE
           AND TD_RATES.BRANCH_CODE = AC_MAS.BRANCH_CODE
           AND AC_UDE.ACCOUNT_NUMBER = AC_MAS.ACCOUNT_NUMBER
           AND AC_UDE.BRANCH_CODE = AC_MAS.BRANCH_CODE
           AND AC_UDE.CODE_USAGE = 'A'
           AND (AC_MAS.ACCOUNT_STATUS = 'A' OR AC_MAS.ACCOUNT_STATUS = 'Y')
           AND AC_MAS.AUTH_STAT = 'A'
           AND AC_UDE.RATE_CODE = TD_RATES.RATE_CODE
           AND TD_RATES.ACCOUNT_NUMBER = AC_MAS.ACCOUNT_NUMBER
           AND TD_RATES.EFFECTIVE_DATE <= AC_MAS.MATURITY_DATE
           AND AC_MAS.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')

           AND TD_RATES.PROCESSED IN ('N', 'F')
           AND TD_RATES.PROCESSING_DATE IS NULL

           AND NOT EXISTS
         (SELECT 1
                  FROM CLTBS_PROCESSED_REVISIONS X
                 WHERE X.ACCOUNT_NUMBER = AC_UDE.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = P_BRANCH_CODE)

           AND AC_UDE.RATE_CODE IN
               (SELECT AC_TD.RATE_CODE
                  FROM CLTBS_ACCOUNT_UDE_VALUES AC_TD
                 WHERE AC_TD.ACCOUNT_NUMBER = AC_MAS.ACCOUNT_NUMBER
                   AND AC_TD.BRANCH_CODE = AC_MAS.BRANCH_CODE
                   AND AC_TD.UDE_ID = AC_UDE.UDE_ID
                   AND AC_TD.RATE_CODE IS NOT NULL
                   AND AC_TD.EFFECTIVE_DATE =
                       (SELECT MAX(EFFECTIVE_DATE)
                          FROM CLTBS_ACCOUNT_UDE_VALUES
                         WHERE ACCOUNT_NUMBER = AC_MAS.ACCOUNT_NUMBER
                           AND BRANCH_CODE = AC_MAS.BRANCH_CODE
                           AND UDE_ID = AC_UDE.UDE_ID
                           AND EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE))
           AND TD_RATES.EFFECTIVE_DATE =
               (SELECT MAX(EFFECTIVE_DATE)
                  FROM CLTBS_ACCOUNT_TDUDE_RATE TD
                 WHERE TD.ACCOUNT_NUMBER = AC_MAS.ACCOUNT_NUMBER
                   AND TD.BRANCH_CODE = AC_MAS.BRANCH_CODE
                   AND TD.RATE_CODE = AC_UDE.RATE_CODE
                   AND TD.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE)

         ORDER BY ACCOUNT_NUMBER, UDE_EFF_DT DESC, RATE_DT DESC;

      DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

      IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_MRG_ARVN,
                                 P_BRANCH_CODE,
                                 'ARVN',
                                 L_TB_RT_ROW_ID,
                                 FALSE,
                                 P_ERRORCODE,
                                 P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_pop_for_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      IF CUR_ACC_UDE_MRG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_MRG_ARVN;
      END IF;
    END IF;
    DEBUG.PR_DEBUG('CL', 'Before end of Function FN_ARVN_MRG_BRANCH');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;

      IF CUR_ACC_UDE_MRG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_MRG_ARVN;
      END IF;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_ARVN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_ARVN_MRG_BRANCH;

  FUNCTION FN_REVN_MRG_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                              P_PROC_DATE   DATE,
                              P_PROCESS_NO  CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                              P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;
    CUR_ACC_UDE_MRG_REVN REF_ACC_UDE_CHG_ARVN;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_REVN_MRG_BRANCH');

    OPEN CUR_ACC_UDE_MRG_REVN FOR
      SELECT ACC_MAS.ROWID          P_ROWID,
             DIARY.ROWID            P_ROWID_1,
             ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
             ACC_MAS.PROCESS_NO     PROCESS_NO,
             ACC_MAS.VERSION_NO     VERSION_NO,
             ACC_MAS.LATEST_ESN     SEQ_NO,
             ACC_UDE.UDE_ID         UDE_ID,
             ACC_UDE.RESOLVED_VALUE RESOLVED_VALUE,
             ACC_UDE.EFFECTIVE_DATE UDE_EFF_DT,
             ACC_UDE.RATE_CODE      UDE_RATE_CODE,
             RATES.EFFECTIVE_DATE   RATE_DT,
             DIARY.COMPONENT_NAME   COMPONENT_NAME
        FROM CLTBS_ACCOUNT_UDE_VALUES   ACC_UDE,
             CLTBS_ACCOUNT_MASTER       ACC_MAS,
             CLTMS_PRODUCT_COMPONENTS   COMP,
             CFTMS_MARGIN_EFFDATE       RATES,
             CLTBS_ACCOUNT_EVENTS_DIARY DIARY
       WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
         AND DIARY.BRANCH_CODE = ACC_MAS.BRANCH_CODE
         AND RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
         AND ACC_UDE.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
         AND ACC_MAS.ACCOUNT_NUMBER = DIARY.ACCOUNT_NUMBER
         AND ACC_UDE.BRANCH_CODE = ACC_MAS.BRANCH_CODE
         AND ACC_UDE.UDE_ID = COMP.RATE_TO_USE
         AND COMP.COMPONENT_TYPE = 'G'
         AND COMP.PRODUCT_CODE = ACC_MAS.PRODUCT_CODE
         AND DIARY.PROCESS_NO = P_PROCESS_NO
         AND DIARY.EVENT_CODE = 'REVN'
         AND DIARY.EXECUTION_DATE <= P_PROC_DATE
         AND ACC_UDE.CODE_USAGE = 'P'
         AND DIARY.EXECUTION_STATUS = 'U'
         AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR ACC_MAS.ACCOUNT_STATUS = 'Y')
         AND DIARY.CONTRACT_STATUS IN ('A', 'Y')
         AND ACC_MAS.MODULE_CODE =
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
         AND ACC_UDE.EFFECTIVE_DATE =
             (SELECT MAX(EFFECTIVE_DATE)
                FROM CLTBS_ACCOUNT_UDE_VALUES UDE_MAX
               WHERE UDE_MAX.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
                 AND UDE_MAX.BRANCH_CODE = ACC_UDE.BRANCH_CODE
                 AND UDE_MAX.UDE_ID = ACC_UDE.UDE_ID
                 AND UDE_MAX.EFFECTIVE_DATE <= P_PROC_DATE)
         AND ACC_MAS.AUTH_STAT = 'A'
         AND NVL(RATES.MARGIN_RECORD_STATUS, 'X') <> 'A'
         AND (ACC_MAS.ACCOUNT_NUMBER = RATES.CONTRACT_REF_NO OR
             (RATES.CONTRACT_REF_NO = 'ALL' AND
             RATES.CUSTOMER_NO = ACC_MAS.CUSTOMER_ID))
         AND (COMP.COMPONENT_NAME = RATES.COMPONENT OR
             (RATES.COMPONENT = 'ALL' AND
             RATES.CUSTOMER_NO = ACC_MAS.CUSTOMER_ID))
         AND RATES.EFFECTIVE_DATE <= ACC_MAS.MATURITY_DATE
         AND NOT EXISTS
       (SELECT 1
                FROM CLTBS_PROCESSED_REVISIONS X
               WHERE X.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
                 AND X.BRANCH_CODE = P_BRANCH_CODE)
         AND EXISTS (SELECT 1
                FROM CLTMS_PRODUCT_COMP_FRM_ELEMS FRM
               WHERE ACC_UDE.UDE_ID = FRM.ELEM_ID
                 AND ELEM_TYPE = 'U'
                 AND PRODUCT_CODE = ACC_MAS.PRODUCT_CODE
                 AND ROWNUM < 2)
       ORDER BY ACCOUNT_NUMBER, UDE_EFF_DT DESC, RATE_DT DESC;
    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_MRG_REVN,
                               P_BRANCH_CODE,
                               'REVN',
                               L_TB_RT_ROW_ID,
                               FALSE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    IF CUR_ACC_UDE_MRG_REVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_MRG_REVN;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      IF CUR_ACC_UDE_MRG_REVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_MRG_REVN;
      END IF;

      L_TB_RT_ROW_ID.DELETE;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_REVN_MRG_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_REVN_MRG_BRANCH;

  FUNCTION FN_PROCESS_REVN_MRG(P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               CUR_ALL_REV_ACC  REF_ALL_REVN_ACC,
                               CUR_ALL_REV_UDE  REF_ALL_REVN_UDE,
                               CUR_ALL_REVN     REF_ALL_REVN,
                               P_FOR_AN_ACCOUNT IN BOOLEAN,
                               P_PROC_DATE      IN DATE,
                               P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_PROCESS_NO     IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                               P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CUR_RATE_DET IS

      SELECT B.ROWID                RATE_ROW_ID,
             B.EFFECTIVE_DATE       RT_EFF_DT,
             B.MARGIN_RATE          RATE,
             B.MARGIN_RECORD_STATUS MRG_STAT
        FROM CFTMS_MARGIN_COMPONENT A, CFTMS_MARGIN_EFFDATE B
       WHERE B.BRANCH_CODE = P_BRANCH_CODE
         AND B.BRANCH_CODE = A.BRANCH_CODE
         AND B.CUSTOMER_NO = A.CUSTOMER_NO
         AND B.CONTRACT_REF_NO = A.CONTRACT_REF_NO

         AND A.COMPONENT = B.COMPONENT
         AND NVL(B.MARGIN_RECORD_STATUS, 'X') <> 'A'
         AND B.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND EXISTS
       (SELECT 1
                FROM CLTBS_REVISION_ACCOUNTS X
               WHERE BRANCH_CODE = P_BRANCH_CODE

                 AND PROCESSED = 'N'
                 AND ROWNUM < 2

                 AND X.PROCESS_NO = NVL(P_PROCESS_NO, X.PROCESS_NO))
       ORDER BY B.EFFECTIVE_DATE, B.MARGIN_RATE;

    TYPE TY_PROCESSED_AC_ROWID IS TABLE OF ROWID INDEX BY PLS_INTEGER;
    TYPE TY_TB_RATE_DET IS TABLE OF CUR_RATE_DET%ROWTYPE INDEX BY PLS_INTEGER;
    TYPE TY_ACC_UDE_VALS IS TABLE OF REC_ALL_REVN_UDE INDEX BY VARCHAR2(100);
    TYPE TY_ACC_REVN_VALS IS TABLE OF REC_ALL_REVN INDEX BY VARCHAR2(50);

    L_TB_ACC_REC      TY_TB_ACC_REC;
    L_TB_ACC_REC_TEMP TY_TB_ACC_REC;
    L_COMMIT_FREQ     NUMBER;
    L_INDEX           PLS_INTEGER;
    L_IDX             PLS_INTEGER;
    L_PREV_ACC_NO     CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE := '@#$';
    LACCOBJ           CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_CURRENCY        CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE;
    L_AMOUNT          VARCHAR2(50);
    LTENOR            PLS_INTEGER;
    L_TB_ACC_ROW_ID   TY_TB_ACC_ROW_ID;
    L_TB_AC_NO        DBMS_SQL.VARCHAR2S;
    L_TB_BK_VALUE     DBMS_SQL.DATE_TABLE;
    L_TB_PROCESSED_AC TY_PROCESSED_AC_ROWID;
    L_TB_ACC_UDE      TY_ACC_UDE;
    L_TAB_ACC_VALS    TY_ACC_UDE_VALS;
    L_AC_REC_REVN     TY_ACC_REVN;
    L_TAB_REVN_VALS   TY_ACC_REVN_VALS;
    L_RT_CODE_IDX     VARCHAR2(50);
    L_RT_DT_IDX       PLS_INTEGER;
    L_TB_RATE_VALS    TY_TB_RATE_VALS;
    L_TB_RATE_DET     TY_TB_RATE_DET;
    L_RT_AMT_IDX      VARCHAR2(50);
    L_RT_TEN_IDX      PLS_INTEGER;
    L_TB_UDE_VAL      TY_TB_INS_UDE_VALS;
    L_UDE_VALUE       CLTBS_ACCOUNT_UDE_VALUES.UDE_VALUE%TYPE;
    L_AMT             VARCHAR2(50);
    L_RESLVD_VAL_CHGD BOOLEAN := FALSE;
    L_RESOLVED_VALUE  NUMBER;
    L_TNR             PLS_INTEGER;
    L_RATE            NUMBER;
    LRET              NUMBER;
    L_CODE_USAGE      VARCHAR2(1);
    L_CNTR            PLS_INTEGER;
    L_NO_ERRORS       PLS_INTEGER;
    L_ERR_IDX         PLS_INTEGER;
    L_EFF_DT          DATE;
    L_NEXT_DT         DATE;
    L_EXIT            BOOLEAN;
    L_EXIT_IN         BOOLEAN;
    L_UDE_IDX         VARCHAR2(100);
    SKIP_CURRENT_SET EXCEPTION;
    L_BTAB             DBMS_SQL.VARCHAR2S;
    L_ATAB             DBMS_SQL.VARCHAR2S;
    L_REVN_IDX         VARCHAR2(50);
    L_EVENT_CODE       CLTBS_ACCOUNT_EVENTS_DIARY.EVENT_CODE%TYPE;
    L_ROWID            ROWID;
    L_EXISTS           PLS_INTEGER := 0;
    L_TEMP_IDX         PLS_INTEGER;
    L_TB_DEL_ACC       DBMS_SQL.VARCHAR2S;
    L_TB_DEL_UDEID     DBMS_SQL.VARCHAR2S;
    L_TB_DEL_EFFDT     DBMS_SQL.DATE_TABLE;
    L_DUE_DT_INDX      PLS_INTEGER;
    L_START_DT         DATE;
    L_CHAR_VAL         VARCHAR2(50);
    L_DEC_PART         VARCHAR2(50);
    L_AMOUNT_FORMATTED BOOLEAN;
    L_MARGIN_RATE      NUMBER;

    L_TB_PRODUCT_UDE CLTM_PRODUCT_UDE%ROWTYPE;

    L_INTERM_COUNT NUMBER := 0;
  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_PROCESS_REVN_MRG');
    L_COMMIT_FREQ := NVL(CLPKSS_BATCH.G_COMMIT_FREQ, 500);

    IF CUR_RATE_DET%ISOPEN THEN
      CLOSE CUR_RATE_DET;
    END IF;

    OPEN CUR_RATE_DET;

    LOOP
      FETCH CUR_RATE_DET BULK COLLECT
        INTO L_TB_RATE_DET;
      EXIT WHEN CUR_RATE_DET%NOTFOUND;
    END LOOP;

    DEBUG.PR_DEBUG('CL', 'Fetched cursor.. cur_rate_det');

    IF NVL(L_TB_RATE_DET.COUNT, 0) = 0 THEN
      DEBUG.PR_DEBUG('CL', 'Count is zero hence returning');
      RETURN TRUE;
    END IF;

    IF NVL(L_TB_RATE_DET.COUNT, 0) > 0 THEN
      FOR L_IDX IN L_TB_RATE_DET.FIRST .. L_TB_RATE_DET.LAST LOOP
        DEBUG.PR_DEBUG('CL', '--populating the rate code table...');

        L_RT_DT_IDX := CLPKS_UTIL.FN_HASH_DATE(L_TB_RATE_DET(L_IDX)
                                               .RT_EFF_DT);

        DEBUG.PR_DEBUG('CL',
                       '--populating the rate code table HERE...' ||
                       L_RT_DT_IDX);

        L_DEC_PART := NULL;

        IF INSTR(L_CHAR_VAL, '.') > 0 THEN
          L_DEC_PART := SUBSTR(L_CHAR_VAL,
                               INSTR(L_CHAR_VAL, '.') + 1,
                               LENGTH(L_CHAR_VAL));
          L_DEC_PART := RPAD(L_DEC_PART, 3, '0');
          L_CHAR_VAL := SUBSTR(L_CHAR_VAL, 1, INSTR(L_CHAR_VAL, '.') - 1);
          L_CHAR_VAL := L_CHAR_VAL || L_DEC_PART;
        ELSE
          L_CHAR_VAL := RPAD(L_CHAR_VAL, LENGTH(L_CHAR_VAL) + 3, '0');
        END IF;

        L_RT_AMT_IDX := LPAD(L_CHAR_VAL, 50, '0');

      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before cursor for maintained UDEs');

    LOOP
      FETCH CUR_ALL_REV_UDE BULK COLLECT
        INTO L_TB_ACC_UDE;
      EXIT WHEN CUR_ALL_REV_UDE%NOTFOUND;
    END LOOP;

    IF L_TB_ACC_UDE.COUNT > 0 THEN
      FOR L_IDX IN L_TB_ACC_UDE.FIRST .. L_TB_ACC_UDE.LAST LOOP

        L_UDE_IDX := L_TB_ACC_UDE(L_IDX)
                     .ACCOUNT_NUMBER || L_TB_ACC_UDE(L_IDX).UDE_ID ||
                      CLPKSS_UTIL.FN_HASH_DATE(L_TB_ACC_UDE(L_IDX)
                                               .EFFECTIVE_DATE);

        DEBUG.PR_DEBUG('CL', 'Ude idx here is ' || L_UDE_IDX);
        DEBUG.PR_DEBUG('CL',
                       'Ude Value is ' || L_TB_ACC_UDE(L_IDX).UDE_VALUE);
        DEBUG.PR_DEBUG('CL',
                       'Ude Value is ' || L_TB_ACC_UDE(L_IDX).CODE_USAGE);

        L_TAB_ACC_VALS(L_UDE_IDX).RATE_CODE := L_TB_ACC_UDE(L_IDX).RATE_CODE;
        L_TAB_ACC_VALS(L_UDE_IDX).ACCOUNT_NUMBER := L_TB_ACC_UDE(L_IDX)
                                                    .ACCOUNT_NUMBER;
        L_TAB_ACC_VALS(L_UDE_IDX).BRANCH_CODE := L_TB_ACC_UDE(L_IDX)
                                                 .BRANCH_CODE;
        L_TAB_ACC_VALS(L_UDE_IDX).EFFECTIVE_DATE := L_TB_ACC_UDE(L_IDX)
                                                    .EFFECTIVE_DATE;
        L_TAB_ACC_VALS(L_UDE_IDX).UDE_ID := L_TB_ACC_UDE(L_IDX).UDE_ID;
        L_TAB_ACC_VALS(L_UDE_IDX).UDE_VALUE := L_TB_ACC_UDE(L_IDX).UDE_VALUE;
        L_TAB_ACC_VALS(L_UDE_IDX).CODE_USAGE := L_TB_ACC_UDE(L_IDX)
                                                .CODE_USAGE;
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before cursor for periodic revision');

    LOOP
      FETCH CUR_ALL_REVN BULK COLLECT
        INTO L_AC_REC_REVN;
      EXIT WHEN CUR_ALL_REVN%NOTFOUND;
    END LOOP;

    IF L_AC_REC_REVN.COUNT > 0 THEN
      FOR L_IDX IN L_AC_REC_REVN.FIRST .. L_AC_REC_REVN.LAST LOOP

        L_REVN_IDX := L_AC_REC_REVN(L_IDX)
                      .ACCOUNT_NUMBER ||
                       CLPKSS_UTIL.FN_HASH_DATE(L_AC_REC_REVN(L_IDX)
                                                .EXECUTION_DATE);
        L_TAB_REVN_VALS(L_REVN_IDX).ACCOUNT_NUMBER := L_AC_REC_REVN(L_IDX)
                                                      .ACCOUNT_NUMBER;
        L_TAB_REVN_VALS(L_REVN_IDX).BRANCH_CODE := L_AC_REC_REVN(L_IDX)
                                                   .BRANCH_CODE;
        L_TAB_REVN_VALS(L_REVN_IDX).EXECUTION_DATE := L_AC_REC_REVN(L_IDX)
                                                      .EXECUTION_DATE;

      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before opening accounts cursor');

    L_TB_DEL_ACC.DELETE;
    L_TB_DEL_UDEID.DELETE;
    L_TB_DEL_EFFDT.DELETE;

    IF P_ACCOUNT_NUMBER IS NULL THEN

      SELECT ACCOUNT_NUMBER, UDE_ID, LEAST_EFFECTIVE_DATE
        BULK COLLECT
        INTO L_TB_DEL_ACC, L_TB_DEL_UDEID, L_TB_DEL_EFFDT
        FROM CLTBS_REVISION_ACCOUNTS
       WHERE BRANCH_CODE = P_BRANCH_CODE
         AND PROCESS_NO = P_PROCESS_NO
         AND NVL(PROCESSED, 'N') <> 'Y';

    ELSE

      SELECT ACCOUNT_NUMBER, UDE_ID, LEAST_EFFECTIVE_DATE
        BULK COLLECT
        INTO L_TB_DEL_ACC, L_TB_DEL_UDEID, L_TB_DEL_EFFDT
        FROM CLTBS_REVISION_ACCOUNTS
       WHERE BRANCH_CODE = P_BRANCH_CODE
         AND ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND NVL(PROCESSED, 'N') <> 'Y';
    END IF;

    DEBUG.PR_DEBUG('CL',
                   '!!!!!!!!!Count of records is :' || L_TB_DEL_ACC.COUNT);

    L_TB_DEL_ACC.DELETE;
    L_TB_DEL_UDEID.DELETE;
    L_TB_DEL_EFFDT.DELETE;

    LOOP

      L_TB_ACC_REC.DELETE;
      L_TB_PROCESSED_AC.DELETE;
      L_ATAB.DELETE;
      L_BTAB.DELETE;
      L_TB_UDE_VAL.DELETE;
      L_TB_BK_VALUE.DELETE;
      L_TB_AC_NO.DELETE;
      L_TB_ACC_ROW_ID.DELETE;

      FETCH CUR_ALL_REV_ACC BULK COLLECT
        INTO L_TB_ACC_REC LIMIT L_COMMIT_FREQ;

      IF L_TB_ACC_REC_TEMP.COUNT > 0 THEN
        DBG('Inserting Acc ::' || L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST)
            .ACCOUNT_NUMBER || ' in the beginning');
        L_INDEX := L_TB_ACC_REC.FIRST;
        L_TB_ACC_REC(L_INDEX - 1) := L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST);
      END IF;

      BEGIN
        IF NVL(L_TB_ACC_REC.COUNT, 0) > 0 THEN
          L_INDEX := L_TB_ACC_REC.LAST;

          LOOP
            L_TB_ACC_REC_TEMP.DELETE;

            FETCH CUR_ALL_REV_ACC BULK COLLECT
              INTO L_TB_ACC_REC_TEMP LIMIT 1;

            EXIT WHEN(NVL(L_TB_ACC_REC_TEMP.COUNT, 0) = 0 OR L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST)
                      .ACCOUNT_NUMBER <> L_TB_ACC_REC(L_INDEX)
                      .ACCOUNT_NUMBER);

            L_INDEX := L_INDEX + 1;

            L_TB_ACC_REC(L_INDEX) := L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST);
          END LOOP;
        END IF;

        DEBUG.PR_DEBUG('CL', 'after data fetch....');

        DEBUG.PR_DEBUG('CL',
                       '$$$$$$$$$$l_tb_acc_rec.COUNT ' ||
                       L_TB_ACC_REC.COUNT);

        DEBUG.PR_DEBUG('CL',
                       'Deleting records with maint rslv M - Such records also need to be modified');

        IF NVL(L_TB_ACC_REC.COUNT, 0) > 0 THEN
          FOR L_IDX IN L_TB_ACC_REC.FIRST .. L_TB_ACC_REC.LAST LOOP

            DEBUG.PR_DEBUG('CL',
                           'Processing for....' || L_TB_ACC_REC(L_IDX)
                           .ACCOUNT_NUMBER || '~~' || L_TB_ACC_REC(L_IDX)
                           .UDE_ID);

            L_CODE_USAGE := L_TB_ACC_REC(L_IDX).CODE_USAGE;

            DEBUG.PR_DEBUG('CL', 'Code usage here is ' || L_CODE_USAGE);

            IF L_CODE_USAGE = 'A' THEN
              L_EVENT_CODE := 'ARVN';
            ELSE
              L_EVENT_CODE := 'REVN';
            END IF;

            DEBUG.PR_DEBUG('CL', 'Code usage is ' || L_CODE_USAGE);

            IF L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER <> L_PREV_ACC_NO THEN
              DEBUG.PR_DEBUG('CL', 'Inside here...');

              DBG('...fn_clear_acc_object...');

              CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
              CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_MASTER') := 1;

              IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(LACCOBJ,
                                                       P_ERRORCODE,
                                                       P_ERRORPARAM) THEN
                DBG('Failed in call to clear obj ::' || P_ERRORCODE);

                RAISE SKIP_CURRENT_SET;
              END IF;

              DBG('...After fn_clear_acc_object...');

              IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                         .ACCOUNT_NUMBER,
                                                         P_BRANCH_CODE,
                                                         LACCOBJ,
                                                         P_ERRORCODE,
                                                         P_ERRORPARAM) THEN
                DBG('Failed in populating Account object for ARVN::' ||
                    P_ERRORCODE);

                RAISE SKIP_CURRENT_SET;
              END IF;

              CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
              L_CURRENCY         := LACCOBJ.ACCOUNT_DET.CURRENCY;
              L_AMOUNT           := LACCOBJ.ACCOUNT_DET.AMOUNT_FINANCED;
              L_AMOUNT_FORMATTED := FALSE;

              IF NOT
                  CLPKSS_SDE.FN_GET_TENOR(P_BRANCH_CODE,
                                          L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER,
                                          LTENOR,
                                          P_ERRORCODE) THEN
                DBG('Failed in getting tenor from clpks_sde');
                RAISE SKIP_CURRENT_SET;
              END IF;

              DEBUG.PR_DEBUG('CL',
                             'Amount currency and tenor are' || L_AMOUNT || '~~' ||
                             L_CURRENCY || '~~' || LTENOR);

              IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                       L_EVENT_CODE) THEN
                CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;

                IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                           .ACCOUNT_NUMBER,
                                                           P_BRANCH_CODE,
                                                           LACCOBJ,
                                                           P_ERRORCODE,
                                                           P_ERRORPARAM) THEN
                  DBG('Failed in populating Account object for ARVN::' ||
                      P_ERRORCODE);

                  RAISE SKIP_CURRENT_SET;
                END IF;

                LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                             L_EVENT_CODE,
                                                             'B',
                                                             LACCOBJ,
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM);

                DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                IF LRET = -1 THEN
                  RAISE SKIP_CURRENT_SET;
                END IF;
              END IF;

              DEBUG.PR_DEBUG('CL',
                             '$$$$$$$$$$$$$l_tb_acc_rec(l_idx).effective_date ' || L_TB_ACC_REC(L_IDX)
                             .EFFECTIVE_DATE);

            END IF;

            DEBUG.PR_DEBUG('CL',
                           'Now getting the rate for ' || L_RT_CODE_IDX ||
                           '~~~' || L_RT_DT_IDX);

            L_RT_CODE_IDX := L_TB_ACC_REC(L_IDX).RATE_CODE || L_CURRENCY;
            L_RATE        := 0;
            L_RT_DT_IDX   := CLPKS_UTIL.FN_HASH_DATE(L_TB_ACC_REC(L_IDX)
                                                     .EFFECTIVE_DATE);
            L_EFF_DT      := L_TB_ACC_REC(L_IDX).EFFECTIVE_DATE;

            IF L_CODE_USAGE = 'P' THEN
              L_REVN_IDX := L_TB_ACC_REC(L_IDX)
                            .ACCOUNT_NUMBER ||
                             CLPKSS_UTIL.FN_HASH_DATE(L_TB_ACC_REC(L_IDX)
                                                      .EFFECTIVE_DATE);
            END IF;

            L_EXIT := FALSE;

            DEBUG.PR_DEBUG('CL', 'After first rate index ' || L_RT_DT_IDX);

            WHILE NOT L_EXIT LOOP

              L_AMT  := NULL;
              L_RATE := 0;

              L_UDE_IDX := L_TB_ACC_REC(L_IDX)
                           .ACCOUNT_NUMBER || L_TB_ACC_REC(L_IDX)

                           .UDE_ID ||
                            CLPKSS_UTIL.FN_HASH_DATE(L_TB_ACC_UDE(L_IDX)
                                                     .EFFECTIVE_DATE);

              DEBUG.PR_DEBUG('CL', 'Ude idx is  ' || L_UDE_IDX);

              IF NOT L_TAB_ACC_VALS.EXISTS(L_UDE_IDX) THEN
                DEBUG.PR_DEBUG('CL', '#23758978 inside if');
                L_UDE_IDX := L_TAB_ACC_VALS.PRIOR(L_UDE_IDX);
                DEBUG.PR_DEBUG('CL', '#23758978 l_ude_idx  ' || L_UDE_IDX);
              END IF;

              L_UDE_VALUE  := L_TAB_ACC_VALS(L_UDE_IDX).UDE_VALUE;
              L_CODE_USAGE := L_TAB_ACC_VALS(L_UDE_IDX).CODE_USAGE;
              DEBUG.PR_DEBUG('CL', '#23758978 l_ude_value ' || L_UDE_VALUE);
              DEBUG.PR_DEBUG('CL',
                             '#23758978 l_code_usage  ' || L_CODE_USAGE);
              DBG('$$$$$$$$$$Outside ' || L_EFF_DT);

              L_RESLVD_VAL_CHGD := FALSE;

              IF NOT L_RESLVD_VAL_CHGD THEN

                BEGIN
                  SELECT /*+ index_desc ( t pk_cl_acnt_ude_vals) */
                   T.RESOLVED_VALUE
                    INTO L_RESOLVED_VALUE
                    FROM CLTBS_ACCOUNT_UDE_VALUES T
                   WHERE T.ACCOUNT_NUMBER =
                         LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER
                     AND T.BRANCH_CODE = LACCOBJ.ACCOUNT_DET.BRANCH_CODE
                     AND T.UDE_ID = L_TB_ACC_REC(L_IDX).UDE_ID
                     AND EFFECTIVE_DATE <= L_EFF_DT
                     AND ROWNUM < 2;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    L_RESOLVED_VALUE := 0;
                END;

                DBG('$$$$$$$$$$l_resolved_value ' || L_RESOLVED_VALUE);

                IF L_EFF_DT < LACCOBJ.ACCOUNT_DET.MATURITY_DATE THEN

                  L_RESLVD_VAL_CHGD := TRUE;

                END IF;

              END IF;

              DBG('Going to call fn_margin_pkup');
              DBG('Going to call fn_margin_pkup' ||
                  LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER);
              DBG('Going to call fn_margin_pkup' || L_TB_ACC_REC(L_IDX)
                  .BRANCH_CODE);
              DBG('Going to call fn_margin_pkup' || L_EFF_DT);
              DBG('Going to call fn_margin_pkup' || L_TB_ACC_REC(L_IDX)
                  .RATE_CODE);

              IF L_CODE_USAGE = 'P' THEN
                DBG('Inside her for margin pick up');
                IF NOT FN_MARGIN_PKUP_PERIODIC(LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER,
                                               L_MARGIN_RATE) THEN
                  DEBUG.PR_DEBUG('CL', 'Failed in margin rate pickup');
                END IF;
              ELSE
                IF NOT FN_MARGIN_PKUP_AUTO(LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER,
                                           L_MARGIN_RATE) THEN
                  DEBUG.PR_DEBUG('CL', 'Failed in margin rate pickup');
                END IF;
              END IF;

              L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;

              DEBUG.PR_DEBUG('CL', 'Here to populate for ' || L_EFF_DT);
              DEBUG.PR_DEBUG('CL', 'Margin Rate is ' || L_MARGIN_RATE);

              L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TB_ACC_REC(L_IDX)
                                                     .ACCOUNT_NUMBER;
              L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TB_ACC_REC(L_IDX)
                                                  .BRANCH_CODE;
              L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_EFF_DT;
              L_TB_UDE_VAL(L_CNTR).UDE_ID := L_TB_ACC_REC(L_IDX).UDE_ID;
              L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_UDE_VALUE;
              L_TB_UDE_VAL(L_CNTR).RATE_CODE := L_TB_ACC_REC(L_IDX)
                                                .RATE_CODE;
              L_TB_UDE_VAL(L_CNTR).CODE_USAGE := L_CODE_USAGE;
              L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'R';
              L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_MARGIN_RATE,
                                                         L_RESOLVED_VALUE);

              L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                              L_TB_ACC_REC(L_IDX)
                                                              .UDE_ID);

              IF (L_TB_PRODUCT_UDE.UDE_ID = L_TB_UDE_VAL(L_CNTR).UDE_ID) THEN
                IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
                   NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
                   NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) > 0 THEN
                  IF (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) <
                     NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
                     (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) >
                     NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
                    DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');
                    RAISE SKIP_CURRENT_SET;
                  END IF;
                END IF;
              END IF;

              DEBUG.PR_DEBUG('CL', 'OUT AFTER ASSIGNING');

              BEGIN
                SELECT COUNT(1)
                  INTO L_INTERM_COUNT
                  FROM CLTM_PRODUCT_COMP_FRM_ELEMS FRMELEM,
                       CLTM_PRODUCT_COMP_FRM       FRM
                 WHERE FRMELEM.PRODUCT_CODE = FRM.PRODUCT_CODE
                   AND FRMELEM.COMPONENT_NAME = FRM.COMPONENT_NAME
                   AND FRMELEM.FORMULA_NAME = FRM.FORMULA_NAME
                   AND FRMELEM.ELEM_ID = L_TB_ACC_REC(L_IDX).UDE_ID
                   AND FRMELEM.ELEM_TYPE = 'U'
                   AND FRMELEM.PRODUCT_CODE =
                       LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                   AND NOT (FRM.BOOK_FLAG = 'Y' OR
                        (NVL(FRM.DFLT_MORATORIUM_FRM, 'N') = 'Y' OR
                        NVL(MORA_LIQ_FRM, 0) = 'Y'));
              EXCEPTION
                WHEN OTHERS THEN
                  L_INTERM_COUNT := 0;
              END;
              IF L_INTERM_COUNT > 0 THEN
                DBG('Going to insert record for Z_INTRMDT_RATE');
                DBG('EFFECTIVE_DATE :- ' ||
                    CLPKS_UTIL.FN_HASH_DATE(L_EFF_DT));
                L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;
                L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TB_ACC_REC(L_IDX)
                                                       .ACCOUNT_NUMBER;
                L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TB_ACC_REC(L_IDX)
                                                    .BRANCH_CODE;
                L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_EFF_DT;
                L_TB_UDE_VAL(L_CNTR).UDE_ID := 'Z_INTRMDT_RATE';
                L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_UDE_VALUE;
                L_TB_UDE_VAL(L_CNTR).RATE_CODE := NULL;
                L_TB_UDE_VAL(L_CNTR).CODE_USAGE := NULL;
                L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'M';
                L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_MARGIN_RATE,
                                                           L_RESOLVED_VALUE);
              END IF;

              IF L_CODE_USAGE = 'A' THEN

                DEBUG.PR_DEBUG('CL', '$$$$$$$$$$l_next_dt ' || L_NEXT_DT);
                L_EXIT := TRUE;

              ELSE
                DEBUG.PR_DEBUG('CL', 'In Else');
                L_REVN_IDX := L_TAB_REVN_VALS.NEXT(L_REVN_IDX);

                DEBUG.PR_DEBUG('CL',
                               'In Else with l_revn_idx ' || L_REVN_IDX);

                IF L_REVN_IDX IS NOT NULL THEN

                  DEBUG.PR_DEBUG('CL',
                                 'In if with crn ' || L_TAB_REVN_VALS(L_REVN_IDX)
                                 .ACCOUNT_NUMBER);
                  IF L_TAB_REVN_VALS(L_REVN_IDX)
                   .ACCOUNT_NUMBER = L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER THEN
                    L_RT_DT_IDX := CLPKS_UTIL.FN_HASH_DATE(L_TAB_REVN_VALS(L_REVN_IDX)
                                                           .EXECUTION_DATE);
                    L_EFF_DT    := L_TAB_REVN_VALS(L_REVN_IDX)
                                   .EXECUTION_DATE;

                    L_NEXT_DT := L_TAB_REVN_VALS(L_REVN_IDX).EXECUTION_DATE;

                    DEBUG.PR_DEBUG('CL', 'l_rt_dt_idx' || L_RT_DT_IDX);
                    DEBUG.PR_DEBUG('CL', 'l_eff_dt ' || L_EFF_DT);
                    DEBUG.PR_DEBUG('CL', 'l_next_dt ' || L_NEXT_DT);

                  ELSE

                    L_EXIT := TRUE;

                  END IF;
                ELSE
                  L_EXIT := TRUE;
                END IF;
              END IF;

              IF L_RT_DT_IDX IS NULL THEN

                DEBUG.PR_DEBUG('CL',
                               'INSIDE SECOND LOOP l_rt_dt_idx' ||
                               L_RT_DT_IDX);

                L_EXIT_IN := FALSE;
                WHILE NOT L_EXIT_IN LOOP
                  L_CNTR    := L_TB_UDE_VAL.COUNT;
                  L_UDE_IDX := L_TB_UDE_VAL(L_CNTR)
                               .ACCOUNT_NUMBER || L_TB_UDE_VAL(L_CNTR)
                               .UDE_ID ||
                                CLPKSS_UTIL.FN_HASH_DATE(L_TB_UDE_VAL(L_CNTR)
                                                         .EFFECTIVE_DATE);
                  L_UDE_IDX := L_TAB_ACC_VALS.NEXT(L_UDE_IDX);
                  IF L_UDE_IDX IS NOT NULL AND L_TAB_ACC_VALS(L_UDE_IDX)
                    .ACCOUNT_NUMBER = L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER AND L_TAB_ACC_VALS(L_UDE_IDX)
                    .UDE_ID = L_TB_UDE_VAL(L_CNTR).UDE_ID AND
                     NVL(L_TAB_ACC_VALS(L_UDE_IDX).RATE_CODE, '@@@@') =
                     NVL(L_TB_UDE_VAL(L_CNTR).RATE_CODE, '####') THEN
                    L_CNTR := L_TB_UDE_VAL.COUNT + 1;
                    L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TAB_ACC_VALS(L_UDE_IDX)
                                                           .ACCOUNT_NUMBER;
                    L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                        .BRANCH_CODE;
                    L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                           .EFFECTIVE_DATE;
                    L_TB_UDE_VAL(L_CNTR).UDE_ID := L_TAB_ACC_VALS(L_UDE_IDX)
                                                   .UDE_ID;
                    L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                      .UDE_VALUE;
                    L_TB_UDE_VAL(L_CNTR).RATE_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                      .RATE_CODE;
                    L_TB_UDE_VAL(L_CNTR).CODE_USAGE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                       .CODE_USAGE;
                    L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := NULL;
                    L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE, 0) +
                                                           NVL(L_TAB_ACC_VALS(L_UDE_IDX)
                                                               .UDE_VALUE,
                                                               0);

                    L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                                    L_TB_ACC_REC(L_IDX)
                                                                    .UDE_ID);
                    IF (L_TB_PRODUCT_UDE.UDE_ID = L_TB_UDE_VAL(L_CNTR)
                       .UDE_ID) THEN
                      IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
                         NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
                         NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) > 0 THEN
                        IF (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) <
                           NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
                           (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) >
                           NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
                          DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');
                          RAISE SKIP_CURRENT_SET;
                        END IF;
                      END IF;
                    END IF;

                    BEGIN
                      SELECT COUNT(1)
                        INTO L_INTERM_COUNT
                        FROM CLTM_PRODUCT_COMP_FRM_ELEMS FRMELEM,
                             CLTM_PRODUCT_COMP_FRM       FRM
                       WHERE FRMELEM.PRODUCT_CODE = FRM.PRODUCT_CODE
                         AND FRMELEM.COMPONENT_NAME = FRM.COMPONENT_NAME
                         AND FRMELEM.FORMULA_NAME = FRM.FORMULA_NAME
                         AND FRMELEM.ELEM_ID = L_TAB_ACC_VALS(L_UDE_IDX)
                            .UDE_ID
                         AND FRMELEM.ELEM_TYPE = 'U'
                         AND FRMELEM.PRODUCT_CODE =
                             LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                         AND NOT (FRM.BOOK_FLAG = 'Y' OR
                              (NVL(FRM.DFLT_MORATORIUM_FRM, 'N') = 'Y' OR
                              NVL(MORA_LIQ_FRM, 0) = 'Y'));
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_INTERM_COUNT := 0;
                    END;
                    IF L_INTERM_COUNT > 0 THEN
                      DBG('2 Going to insert record for Z_INTRMDT_RATE');
                      DBG('EFFECTIVE_DATE :- ' ||
                          CLPKS_UTIL.FN_HASH_DATE(L_TAB_ACC_VALS(L_UDE_IDX)
                                                  .EFFECTIVE_DATE));
                      L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;
                      L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TAB_ACC_VALS(L_UDE_IDX)
                                                             .ACCOUNT_NUMBER;
                      L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                          .BRANCH_CODE;
                      L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                             .EFFECTIVE_DATE;
                      L_TB_UDE_VAL(L_CNTR).UDE_ID := 'Z_INTRMDT_RATE';
                      L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                        .UDE_VALUE;
                      L_TB_UDE_VAL(L_CNTR).RATE_CODE := NULL;
                      L_TB_UDE_VAL(L_CNTR).CODE_USAGE := NULL;
                      L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'M';
                      L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE, 0) +
                                                             NVL(L_TAB_ACC_VALS(L_UDE_IDX)
                                                                 .UDE_VALUE,
                                                                 0);
                    END IF;

                  ELSE
                    L_EXIT_IN := TRUE;
                  END IF;
                END LOOP;
                L_EXIT := TRUE;
              END IF;

              DEBUG.PR_DEBUG('CL', '$$$$$$$$$$$l_idx ' || L_IDX);

              L_TEMP_IDX := L_TB_ACC_REC.FIRST;

              UPDATE CFTMS_MARGIN_EFFDATE
                 SET MARGIN_RECORD_STATUS = 'A'
               WHERE CONTRACT_REF_NO = LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND EFFECTIVE_DATE =
                     (SELECT MIN(EFFECTIVE_DATE)
                        FROM CFTMS_MARGIN_EFFDATE
                       WHERE CONTRACT_REF_NO =
                             LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                         AND MARGIN_RECORD_STATUS <> 'A');

              COMMIT;
            END LOOP;

            DEBUG.PR_DEBUG('CL', 'Out of the rates loop');

            IF L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER <> L_PREV_ACC_NO THEN
              IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                       L_EVENT_CODE) THEN
                DBG('Calling clpks_pol_wrapper with product::' ||
                    LACCOBJ.ACCOUNT_DET.PRODUCT_CODE ||
                    ' ,event ARVN and execution_type A');

                IF LACCOBJ.G_TB_COMPONENTS.COUNT = 0 THEN
                  CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;

                  IF NOT
                      CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                          .ACCOUNT_NUMBER,
                                                          P_BRANCH_CODE,
                                                          LACCOBJ,
                                                          P_ERRORCODE,
                                                          P_ERRORPARAM) THEN
                    DBG('Failed in populating Account object for ARVN::' ||
                        P_ERRORCODE);

                    RAISE SKIP_CURRENT_SET;
                  END IF;

                END IF;

                LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                             L_EVENT_CODE,
                                                             'A',
                                                             LACCOBJ,
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM);

                DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                IF LRET = -1 THEN
                  RAISE SKIP_CURRENT_SET;
                END IF;
              END IF;
            END IF;

            L_TB_PROCESSED_AC(NVL(L_TB_PROCESSED_AC.COUNT, 0) + 1) := L_TB_ACC_REC(L_IDX)
                                                                      .P_ROWID;

            L_PREV_ACC_NO := L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER;

            IF L_IDX =
               L_TB_ACC_REC.LAST OR L_TB_ACC_REC(L_IDX + 1).ACCOUNT_NUMBER <>
               L_PREV_ACC_NO THEN
              IF L_RESLVD_VAL_CHGD THEN
                L_TB_ACC_ROW_ID(NVL(L_TB_ACC_ROW_ID.COUNT, 0) + 1) := LACCOBJ.G_RECORD_ROWID;
                L_TB_AC_NO(NVL(L_TB_AC_NO.COUNT, 0) + 1) := L_PREV_ACC_NO;
                L_TB_BK_VALUE(NVL(L_TB_BK_VALUE.COUNT, 0) + 1) := P_PROC_DATE;
                DEBUG.PR_DEBUG('CL',
                               '$$$$$$$$$$$$$UDE VALUES HAVE CHANGED FOR ' ||
                               LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER || '~' ||
                               P_PROC_DATE);
              ELSE
                DEBUG.PR_DEBUG('CL',
                               '$$$$$$$$$$$$$UDE VALUES HAVE NOT CHANGED FOR ' ||
                               LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER || '~' ||
                               P_PROC_DATE);
              END IF;
              L_RESLVD_VAL_CHGD := FALSE;
            END IF;

          END LOOP;

          DEBUG.PR_DEBUG('CL', 'Out of the accounts loop');

          DEBUG.PR_DEBUG('CL',
                         'l_tb_acc_row_id.count ' || L_TB_ACC_ROW_ID.COUNT);

          IF L_TB_ACC_ROW_ID.COUNT > 0 THEN
            BEGIN
              FORALL I IN L_TB_ACC_ROW_ID.FIRST .. L_TB_ACC_ROW_ID.LAST SAVE
                                                   EXCEPTIONS
                UPDATE CLTBS_ACCOUNT_MASTER
                   SET CALC_REQD          = 'Y',
                       RECALC_ACTION_CODE = 'E',
                       LATEST_ESN         = LATEST_ESN + 1
                 WHERE ROWID = L_TB_ACC_ROW_ID(I);

              DEBUG.PR_DEBUG('CL', 'Updated cltbs_account_ude_values');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_ACCOUNT_UDE_VALUES');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'ARVN',
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;
          END IF;

          CLPKSS_UTIL.PR_LOG_CALC_DATES(L_TB_AC_NO,
                                        L_TB_BK_VALUE,
                                        P_BRANCH_CODE

                                       ,
                                        'E'

                                       ,
                                        NULL);

          IF L_TB_UDE_VAL.COUNT > 0 THEN

            L_TB_DEL_ACC.DELETE;
            L_TB_DEL_EFFDT.DELETE;
            L_TB_DEL_UDEID.DELETE;

            FOR I IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP

              L_TB_DEL_ACC(I) := L_TB_UDE_VAL(I).ACCOUNT_NUMBER;
              L_TB_DEL_EFFDT(I) := L_TB_UDE_VAL(I).EFFECTIVE_DATE;
              L_TB_DEL_UDEID(I) := L_TB_UDE_VAL(I).UDE_ID;
            END LOOP;

            DEBUG.PR_DEBUG('CL',
                           'Enjoy.. now deleting the existing records :' ||
                           L_TB_DEL_ACC.COUNT);

            IF L_TB_DEL_ACC.COUNT <> 0 THEN
              FORALL I IN L_TB_DEL_ACC.FIRST .. L_TB_DEL_ACC.LAST
                DELETE CLTBS_ACCOUNT_UDE_VALUES
                 WHERE BRANCH_CODE = P_BRANCH_CODE
                   AND ACCOUNT_NUMBER = L_TB_DEL_ACC(I)
                   AND EFFECTIVE_DATE = L_TB_DEL_EFFDT(I)
                   AND UDE_ID = L_TB_DEL_UDEID(I);
            END IF;

            L_TB_DEL_ACC.DELETE;
            L_TB_DEL_EFFDT.DELETE;
            L_TB_DEL_UDEID.DELETE;

            DEBUG.PR_DEBUG('CL',
                           'Existing records deleted..now going to insert !');

            BEGIN
              FORALL I IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST SAVE
                                                EXCEPTIONS
                INSERT INTO CLTBS_ACCOUNT_UDE_VALUES
                VALUES L_TB_UDE_VAL
                  (I);

              DEBUG.PR_DEBUG('CL', 'Updated cltbs_account_ude_values');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_ACCOUNT_UDE_VALUES');
                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'ARVN',
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;

            FOR II IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP
              L_BTAB(II) := L_TB_UDE_VAL(II).BRANCH_CODE;
              L_ATAB(II) := L_TB_UDE_VAL(II).ACCOUNT_NUMBER;
            END LOOP;

            FORALL II IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST
              DELETE CLTBS_PROCESSED_REVISIONS
               WHERE ACCOUNT_NUMBER = L_ATAB(II)
                 AND BRANCH_CODE = L_BTAB(II);

            L_BTAB.DELETE;
            L_ATAB.DELETE;
          END IF;

          IF L_TB_PROCESSED_AC.COUNT > 0 THEN
            BEGIN

              FORALL I IN L_TB_PROCESSED_AC.FIRST .. L_TB_PROCESSED_AC.LAST SAVE
                                                     EXCEPTIONS
                DELETE CLTBS_REVISION_ACCOUNTS
                 WHERE ROWID = L_TB_PROCESSED_AC(I);

              DBG('Updated CLTBS_REVISION_ACCOUNTS');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_REVISION_ACCOUNTS');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'ARVN',
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;
          END IF;
        END IF;

        DEBUG.PR_DEBUG('CL', 'Before commit in fn_process_revision');
        IF NOT P_FOR_AN_ACCOUNT THEN
          COMMIT;
        END IF;

        L_TB_ACC_REC.DELETE;
        L_TB_ACC_ROW_ID.DELETE;
        L_TB_AC_NO.DELETE;
        L_TB_BK_VALUE.DELETE;
        L_TB_PROCESSED_AC.DELETE;

      EXCEPTION
        WHEN SKIP_CURRENT_SET THEN
          DEBUG.PR_DEBUG('CL', '%%%%%%%%%%%%Reached here');

          ROLLBACK;

          L_TB_ACC_REC.DELETE;
          L_TB_ACC_ROW_ID.DELETE;
          L_TB_AC_NO.DELETE;
          L_TB_BK_VALUE.DELETE;
          L_TB_PROCESSED_AC.DELETE;
          L_BTAB.DELETE;
          L_ATAB.DELETE;

          DEBUG.PR_DEBUG('CL',
                         'Bombed in processing rates with ' || SQLERRM);
      END;

      EXIT WHEN CUR_ALL_REV_ACC%NOTFOUND;
    END LOOP;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;

      L_TB_ACC_REC.DELETE;
      L_TB_ACC_ROW_ID.DELETE;
      L_TB_AC_NO.DELETE;
      L_TB_BK_VALUE.DELETE;
      L_TB_PROCESSED_AC.DELETE;
      L_BTAB.DELETE;
      L_ATAB.DELETE;
      L_AC_REC_REVN.DELETE;
      L_TAB_REVN_VALS.DELETE;
      L_TB_ACC_UDE.DELETE;
      L_TAB_ACC_VALS.DELETE;
      L_TB_RATE_VALS.DELETE;
      L_TB_UDE_VAL.DELETE;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_PROC_REVISION_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PROCESS_REVN_MRG;

  FUNCTION FN_POPULATE_DIARY(L_TB_INS_DIARY IN OUT TY_TB_INS_DIARY,
                             P_AC_NO        IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                             P_BRANCH_CODE  IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                             P_EVENT_CODE   IN CLTB_ACCOUNT_EVENTS_DIARY.EVENT_CODE%TYPE,
                             P_ESN          IN CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
                             P_PROCESS_NO   IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                             P_VERSION_NO   IN CLTBS_ACCOUNT_MASTER.VERSION_NO%TYPE

                            ,
                             P_EXEC_DATE IN DATE,
                             P_COMP_NAME IN CLTBS_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE

                            ,
                             P_ERRORCODE IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS

    L_DIARY_IDX PLS_INTEGER;
    L_KEY       VARCHAR2(50);
    L_USER_ID   CLTBS_ACCOUNT_EVENTS_DIARY.MAKER_ID%TYPE;
  BEGIN

    IF GLOBAL.BRANCH_STATUS <> 'N' THEN
      L_USER_ID := 'SYSTEM';
    ELSE
      L_USER_ID := GLOBAL.USER_ID;
    END IF;

    L_KEY := P_AC_NO || P_BRANCH_CODE ||
             CLPKS_UTIL.FN_HASH_DATE(P_EXEC_DATE) || P_COMP_NAME;
    IF L_KEY <> G_DIARY_KEY THEN

      IF (P_EVENT_CODE <> 'REVN') OR
         (PKG_EVENT = 'REVN' AND L_FUNCTION_ID = 'LSDFXRVN')

       THEN
        L_DIARY_IDX := L_TB_INS_DIARY.COUNT + 1;

        L_TB_INS_DIARY(L_DIARY_IDX).ACCOUNT_NUMBER := P_AC_NO;
        L_TB_INS_DIARY(L_DIARY_IDX).BRANCH_CODE := P_BRANCH_CODE;
        L_TB_INS_DIARY(L_DIARY_IDX).COMPONENT_NAME := 'LOAN_ACCOUNT';
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_CODE := P_EVENT_CODE;
        L_TB_INS_DIARY(L_DIARY_IDX).EXECUTION_DATE := GLOBAL.APPLICATION_DATE;
        L_TB_INS_DIARY(L_DIARY_IDX).EXECUTION_STATUS := 'P';

        L_TB_INS_DIARY(L_DIARY_IDX).MAKER_ID := L_USER_ID;

        L_TB_INS_DIARY(L_DIARY_IDX).CHECKER_ID := L_USER_ID;
        L_TB_INS_DIARY(L_DIARY_IDX).MAKER_DT_STAMP := CSFNS_TIMESTAMP;
        L_TB_INS_DIARY(L_DIARY_IDX).CHECKER_DT_STAMP := CSFNS_TIMESTAMP;
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_DATE := GLOBAL.APPLICATION_DATE;
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_SEQ_NO := P_ESN;
        L_TB_INS_DIARY(L_DIARY_IDX).CONTRACT_STATUS := 'A';
        L_TB_INS_DIARY(L_DIARY_IDX).AUTH_STATUS := 'A';
        L_TB_INS_DIARY(L_DIARY_IDX).PROCESS_NO := P_PROCESS_NO;
        L_TB_INS_DIARY(L_DIARY_IDX).VERSION_NO := P_VERSION_NO;

        CLPKSS_CONTEXT.G_FUNCTION_ID := NVL(CLPKSS_CONTEXT.G_FUNCTION_ID,
                                            'AUTOREVN');
        L_TB_INS_DIARY(L_DIARY_IDX).INTERFACE_ID := CLPKSS_CONTEXT.FN_GET_TXN_ID(P_AC_NO,
                                                                                 P_BRANCH_CODE);

      ELSE
        L_DIARY_IDX := L_TB_INS_DIARY.COUNT + 1;

        BEGIN
          SELECT /*+ INDEX_ASC (PK_REVN_SCH) */
           SCHEDULE_DUE_DATE
            INTO L_TB_INS_DIARY(L_DIARY_IDX).EXECUTION_DATE
            FROM CLTBS_REVN_SCHEDULES A
           WHERE ACCOUNT_NUMBER = P_AC_NO
             AND BRANCH_CODE = P_BRANCH_CODE
             AND COMPONENT_NAME = P_COMP_NAME
             AND SCHEDULE_DUE_DATE > P_EXEC_DATE
             AND ROWNUM < 2;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            RETURN TRUE;
        END;

        L_TB_INS_DIARY(L_DIARY_IDX).ACCOUNT_NUMBER := P_AC_NO;
        L_TB_INS_DIARY(L_DIARY_IDX).BRANCH_CODE := P_BRANCH_CODE;
        L_TB_INS_DIARY(L_DIARY_IDX).COMPONENT_NAME := P_COMP_NAME;
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_CODE := P_EVENT_CODE;
        L_TB_INS_DIARY(L_DIARY_IDX).EXECUTION_STATUS := 'U';
        L_TB_INS_DIARY(L_DIARY_IDX).MAKER_ID := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).CHECKER_ID := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).MAKER_DT_STAMP := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).CHECKER_DT_STAMP := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_DATE := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).EVENT_SEQ_NO := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).CONTRACT_STATUS := 'A';
        L_TB_INS_DIARY(L_DIARY_IDX).AUTH_STATUS := NULL;
        L_TB_INS_DIARY(L_DIARY_IDX).PROCESS_NO := P_PROCESS_NO;
        L_TB_INS_DIARY(L_DIARY_IDX).VERSION_NO := P_VERSION_NO;

        CLPKSS_CONTEXT.G_FUNCTION_ID := NVL(CLPKSS_CONTEXT.G_FUNCTION_ID,
                                            'AUTOREVN');
        L_TB_INS_DIARY(L_DIARY_IDX).INTERFACE_ID := CLPKSS_CONTEXT.FN_GET_TXN_ID(P_AC_NO,
                                                                                 P_BRANCH_CODE);

      END IF;

    END IF;
    G_DIARY_KEY := L_KEY;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_POPULATE_DIARY..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_POPULATE_DIARY;

  FUNCTION FN_INSERT_DIARY(L_TB_INS_DIARY IN TY_TB_INS_DIARY,
                           P_BRANCH_CODE  IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                           P_ERRORCODE    IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS

    L_NO_ERRORS       PLS_INTEGER;
    L_ERR_IDX         PLS_INTEGER;
    L_OTHER_EXCEPTION BOOLEAN := FALSE;

  BEGIN
    FORALL I IN L_TB_INS_DIARY.FIRST .. L_TB_INS_DIARY.LAST SAVE EXCEPTIONS
      INSERT INTO CLTBS_ACCOUNT_EVENTS_DIARY VALUES L_TB_INS_DIARY (I);

    IF NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('STREAM'), 'LATAM') IN
       ('LATAM', 'RUSSIA') THEN

      IF NOT CLPKSS_STREAM_CONTEXT.FN_INSERT_TXN_LOG

       THEN
        DBG('Failed in clpkss_context.fn_insert_txn_id');
        P_ERRORCODE := 'CL-REVN06;';

        RETURN FALSE;
      END IF;

    END IF;

    DEBUG.PR_DEBUG('CL', 'Inserted cltbs_account_ude_values');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

      DEBUG.PR_DEBUG('CL',
                     'Error Raised Here at Cltbs_account_events_diary');

      L_OTHER_EXCEPTION := FALSE;

      FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
        L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

        IF SQL%BULK_EXCEPTIONS(L_IDX).ERROR_CODE <> 1 THEN
          L_OTHER_EXCEPTION := TRUE;

          CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                       P_BRANCH_CODE,
                                       GLOBAL.APPLICATION_DATE,
                                       'ARVN',
                                       'ERROR :' || L_IDX ||
                                       '  POSITION = ' || L_ERR_IDX ||
                                       ' -- ERROR_CODE = ' ||
                                       SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                               .ERROR_CODE));

        END IF;

      END LOOP;

      IF L_OTHER_EXCEPTION THEN

        RETURN FALSE;

      ELSE
        RETURN TRUE;
      END IF;

  END FN_INSERT_DIARY;

  FUNCTION FN_TRFR_ARVN_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_TRFR_ARVN_BRANCH');

    OPEN CUR_ACC_UDE_CHG_ARVN FOR
      SELECT RATES.ROWID            P_ROWID,
             ACC_MAS.ROWID          P_ROWID_1,
             ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
             ACC_MAS.PROCESS_NO     PROCESS_NO,
             ACC_MAS.VERSION_NO     VERSION_NO,
             ACC_MAS.LATEST_ESN     SEQ_NO,
             RATES.UDE_ID           UDE_ID,
             NULL                   RESOLVED_VALUE,
             RATES.EFFECTIVE_DATE   UDE_EFF_DT,
             RATES.RATE_CODE        UDE_RATE_CODE,
             RATES.EFFECTIVE_DATE   RATE_DT,
             NULL                   COMPONENT_NAME
        FROM CLTBS_ACCOUNT_MASTER ACC_MAS, CLTBS_ACC_BRN_TRFR_REVN RATES
       WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
         AND RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
         AND RATES.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
         AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR ACC_MAS.ACCOUNT_STATUS = 'Y')
         AND ACC_MAS.AUTH_STAT = 'A'
         AND NOT EXISTS
       (SELECT 1
                FROM CLTBS_PROCESSED_REVISIONS X
               WHERE X.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                 AND X.BRANCH_CODE = P_BRANCH_CODE)
       ORDER BY ACCOUNT_NUMBER, UDE_EFF_DT DESC, RATE_DT DESC;
    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN,
                               P_BRANCH_CODE,
                               'ARVN',
                               L_TB_RT_ROW_ID,
                               TRUE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    DEBUG.PR_DEBUG('CL', 'Before updating...');

    IF NVL(L_TB_RT_ROW_ID.COUNT, 0) > 0 THEN
      FORALL I IN L_TB_RT_ROW_ID.FIRST .. L_TB_RT_ROW_ID.LAST SAVE
                                          EXCEPTIONS

        DELETE FROM CLTBS_ACC_BRN_TRFR_REVN
         WHERE ROWID = L_TB_RT_ROW_ID(I);

      L_TB_RT_ROW_ID.DELETE;

      DEBUG.PR_DEBUG('CL', 'UPDATED CLTBS_ACC_BRN_TRFR_REVN');
    END IF;

    IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_CHG_ARVN;
    END IF;

    DEBUG.PR_DEBUG('CL', 'Before end of Function fn_trfr_arvn_branch;');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;

      IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_ARVN;
      END IF;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in fn_trfr_arvn_branch;..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();
      RETURN FALSE;
  END FN_TRFR_ARVN_BRANCH;
  FUNCTION FN_TRFR_ARVN_ACCOUNT(P_ACCOUNT_NUMBER IN OUT NOCOPY CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                                P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                                P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of fn_trfr_arvn_account');

    OPEN CUR_ACC_UDE_CHG_ARVN FOR
      SELECT RATES.ROWID            P_ROWID,
             ACC_MAS.ROWID          P_ROWID_1,
             ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
             ACC_MAS.PROCESS_NO     PROCESS_NO,
             ACC_MAS.VERSION_NO     VERSION_NO,
             ACC_MAS.LATEST_ESN     SEQ_NO,
             RATES.UDE_ID           UDE_ID,
             NULL                   RESOLVED_VALUE,
             RATES.EFFECTIVE_DATE   UDE_EFF_DT,
             RATES.RATE_CODE        UDE_RATE_CODE,
             RATES.EFFECTIVE_DATE   RATE_DT,
             NULL                   COMPONENT_NAME
        FROM CLTBS_ACCOUNT_MASTER ACC_MAS, CLTBS_ACC_BRN_TRFR_REVN RATES
       WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
         AND RATES.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
         AND RATES.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
         AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR ACC_MAS.ACCOUNT_STATUS = 'Y')
         AND ACC_MAS.AUTH_STAT = 'A'
         AND NOT EXISTS (SELECT 1
                FROM CLTBS_PROCESSED_REVISIONS X
               WHERE X.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
                 AND X.BRANCH_CODE = P_BRANCH_CODE)
       ORDER BY ACCOUNT_NUMBER, UDE_EFF_DT DESC, RATE_DT DESC;

    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN,
                               P_BRANCH_CODE,
                               'ARVN',
                               L_TB_RT_ROW_ID,
                               TRUE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    L_TB_RT_ROW_ID.DELETE;

    IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_CHG_ARVN;
    END IF;

    DEBUG.PR_DEBUG('CL', 'Before end of Function fn_trfr_arvn_account');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;

      P_ERRORCODE := 'CL-REVN04;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');
      DEBUG.PR_DEBUG('CL', 'BOMBED in fn_trfr_arvn_account..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_TRFR_ARVN_ACCOUNT;

  FUNCTION FN_ARVN_FOR_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                              P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;
    L_ERRIDX             PLS_INTEGER;
    L_ARVN_DATE          DATE;
  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_ARVN_FOR_BRANCH');

    IF NOT CLPKS_BATCH.FN_GET_PROCESSING_TODATE(P_BRANCH_CODE,
                                                GLOBAL.BRANCH_STATUS,
                                                L_ARVN_DATE,
                                                P_ERRORCODE,
                                                P_ERRORPARAM) THEN
      RETURN FALSE;
    END IF;
    DEBUG.PR_DEBUG('CL', 'l_arvn_date ::' || L_ARVN_DATE);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling clpks_stream_revn.FN_PRE_ARVN_FOR_BRANCH ');
      IF NOT CLPKS_STREAM_REVN.FN_PRE_ARVN_FOR_BRANCH(P_BRANCH_CODE,
                                                      P_ERRORCODE,
                                                      P_ERRORPARAM) THEN

        DBG('clpks_stream_revn.FN_PRE_ARVN_FOR_BRANCH has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      OPEN CUR_ACC_UDE_CHG_ARVN FOR
        SELECT RATES.ROWID            P_ROWID,
               ACC_MAS.ROWID          P_ROWID_1,
               ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
               ACC_MAS.PROCESS_NO     PROCESS_NO,
               ACC_MAS.VERSION_NO     VERSION_NO,
               ACC_MAS.LATEST_ESN     SEQ_NO,
               ACC_UDE.UDE_ID         UDE_ID,
               ACC_UDE.RESOLVED_VALUE RESOLVED_VALUE,
               ACC_UDE.EFFECTIVE_DATE UDE_EFF_DT,
               ACC_UDE.RATE_CODE      UDE_RATE_CODE,
               RATES.EFFECTIVE_DATE   RATE_DT,
               NULL                   COMPONENT_NAME
          FROM CLTBS_ACCOUNT_UDE_VALUES ACC_UDE,
               CLTBS_ACCOUNT_MASTER     ACC_MAS,
               CLTMS_EFFECTED_RATES     RATES

         WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
           AND RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
           AND ACC_UDE.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.CODE_USAGE = 'A'
           AND ACC_UDE.RATE_CODE = RATES.RATE_CODE
           AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR
               ACC_MAS.ACCOUNT_STATUS = 'Y')
           AND ACC_MAS.AUTH_STAT = 'A'
           AND ACC_MAS.CURRENCY = RATES.CCY_CODE
           AND RATES.RATE_RECORD_STATUS = 'C'
           AND RATES.BORROW_LEND_IND = 'L'
           AND

               RATES.NEXT_EFFECTIVE_DATE >= ACC_UDE.EFFECTIVE_DATE
           AND ACC_MAS.AMOUNT_FINANCED <= RATES.AMOUNT_SLAB
           AND ACC_MAS.AMOUNT_FINANCED >= NVL(RATES.PREV_AMOUNT_SLAB, 0)
           AND ACC_MAS.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
           AND RATES.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')

           AND ((RATES.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE AND
               ACC_MAS.MATURITY_DATE > GLOBAL.APPLICATION_DATE) OR
               ACC_MAS.MATURITY_DATE <= GLOBAL.APPLICATION_DATE)

           AND RATES.EFFECTIVE_DATE <= L_ARVN_DATE
           AND NOT EXISTS
         (SELECT 1
                  FROM CLTBS_PROCESSED_REVISIONS X
                 WHERE X.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = P_BRANCH_CODE)

           AND (ACC_UDE.RATE_CODE, ACC_UDE.EFFECTIVE_DATE) IN
               (SELECT RATE_CODE, EFFECTIVE_DATE

                  FROM CLTBS_ACCOUNT_UDE_VALUES
                 WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                   AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                   AND UDE_ID = ACC_UDE.UDE_ID
                   AND RATE_CODE IS NOT NULL
                   AND CODE_USAGE = 'A'
                   AND EFFECTIVE_DATE >=
                       (SELECT MAX(EFFECTIVE_DATE)
                          FROM CLTBS_ACCOUNT_UDE_VALUES
                         WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                           AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                           AND UDE_ID = ACC_UDE.UDE_ID
                           AND EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE))

        UNION
        SELECT TD_RATES.ROWID          P_ROWID,
               ACC_MAS.ROWID           P_ROWID_1,
               ACC_MAS.ACCOUNT_NUMBER  ACCOUNT_NUMBER,
               ACC_MAS.PROCESS_NO      PROCESS_NO,
               ACC_MAS.VERSION_NO      VERSION_NO,
               ACC_MAS.LATEST_ESN      SEQ_NO,
               ACC_UDE.UDE_ID          UDE_ID,
               ACC_UDE.RESOLVED_VALUE  RESOLVED_VALUE,
               ACC_UDE.EFFECTIVE_DATE  UDE_EFF_DT,
               ACC_UDE.RATE_CODE       UDE_RATE_CODE,
               TD_RATES.EFFECTIVE_DATE RATE_DT,
               NULL                    COMPONENT_NAME
          FROM CLTBS_ACCOUNT_UDE_VALUES ACC_UDE,
               CLTBS_ACCOUNT_MASTER     ACC_MAS,
               CLTB_ACCOUNT_TDUDE_RATE  TD_RATES
         WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
           AND TD_RATES.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
           AND ACC_UDE.BRANCH_CODE = ACC_MAS.BRANCH_CODE
           AND ACC_UDE.CODE_USAGE = 'A'
           AND ACC_UDE.RATE_CODE = TD_RATES.RATE_CODE
           AND (ACC_MAS.ACCOUNT_STATUS = 'A' OR
               ACC_MAS.ACCOUNT_STATUS = 'Y')
           AND ACC_MAS.AUTH_STAT = 'A'
           AND ACC_MAS.CURRENCY = TD_RATES.CCY
           AND TD_RATES.EFFECTIVE_DATE <= ACC_MAS.MATURITY_DATE

           AND TD_RATES.PROCESSED IN ('N', 'F')
           AND TD_RATES.PROCESSING_DATE IS NULL
           AND TD_RATES.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER

           AND ACC_MAS.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
           AND NOT EXISTS
         (SELECT 1
                  FROM CLTBS_PROCESSED_REVISIONS X
                 WHERE X.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = P_BRANCH_CODE)
           AND ACC_UDE.RATE_CODE IN
               (SELECT RATE_CODE
                  FROM CLTBS_ACCOUNT_UDE_VALUES
                 WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                   AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                   AND UDE_ID = ACC_UDE.UDE_ID
                   AND RATE_CODE IS NOT NULL
                   AND EFFECTIVE_DATE =
                       (SELECT MAX(EFFECTIVE_DATE)
                          FROM CLTBS_ACCOUNT_UDE_VALUES
                         WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                           AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                           AND UDE_ID = ACC_UDE.UDE_ID
                           AND EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE))

           AND TD_RATES.EFFECTIVE_DATE =
               (SELECT MAX(EFFECTIVE_DATE)
                  FROM CLTBS_ACCOUNT_TDUDE_RATE TD
                 WHERE TD.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                   AND TD.BRANCH_CODE = ACC_MAS.BRANCH_CODE
                   AND TD.RATE_CODE = ACC_UDE.RATE_CODE
                   AND TD.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE)

         ORDER BY ACCOUNT_NUMBER

                 ,
                  UDE_EFF_DT DESC,
                  RATE_DT    DESC

        ;
      DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision apple');

      IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN,
                                 P_BRANCH_CODE,
                                 'ARVN',
                                 L_TB_RT_ROW_ID,
                                 FALSE,
                                 P_ERRORCODE,
                                 P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_pop_for_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

      DEBUG.PR_DEBUG('CL', 'Before updating...');

      IF NVL(L_TB_RT_ROW_ID.COUNT, 0) > 0 THEN
        BEGIN
          FORALL I IN L_TB_RT_ROW_ID.FIRST .. L_TB_RT_ROW_ID.LAST SAVE
                                              EXCEPTIONS

            DELETE FROM CLTMS_EFFECTED_RATES

             WHERE EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
               AND ROWID = L_TB_RT_ROW_ID(I);

        EXCEPTION
          WHEN OTHERS THEN
            FOR E IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
              L_ERRIDX := SQL%BULK_EXCEPTIONS(E).ERROR_INDEX;
              DBG('Failed while deleting records from cltms_effected_rates' ||
                  SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(E).ERROR_CODE),
                         1,
                         1500));

            END LOOP;
        END;

        L_TB_RT_ROW_ID.DELETE;

        DEBUG.PR_DEBUG('CL', 'UPDATED cltms_effected_rates');
      END IF;

      IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_ARVN;
      END IF;

      DEBUG.PR_DEBUG('CL', 'Before end of Function FN_ARVN_FOR_BRANCH');

    END IF;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling clpks_stream_revn.fn_post_arvn_for_branch ');
      IF NOT CLPKS_STREAM_REVN.FN_POST_ARVN_FOR_BRANCH(P_BRANCH_CODE,
                                                       P_ERRORCODE,
                                                       P_ERRORPARAM) THEN

        DBG('clpks_stream_revn.fn_post_arvn_for_branch has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;

      IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_ARVN;
      END IF;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_ARVN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_ARVN_FOR_BRANCH;

  FUNCTION FN_ARVN_FOR_ACCOUNT(P_ACCOUNT_NUMBER IN OUT NOCOPY CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                               P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_ARVN_FOR_ACCOUNT');

    OPEN CUR_ACC_UDE_CHG_ARVN FOR
      SELECT RATES.ROWID            P_ROWID,
             ACC_MAS.ROWID          P_ROWID_1,
             ACC_MAS.ACCOUNT_NUMBER ACCOUNT_NUMBER,
             ACC_MAS.PROCESS_NO     PROCESS_NO,
             ACC_MAS.VERSION_NO     VERSION_NO,
             ACC_MAS.LATEST_ESN     SEQ_NO,
             ACC_UDE.UDE_ID         UDE_ID,
             ACC_UDE.RESOLVED_VALUE RESOLVED_VALUE,
             ACC_UDE.EFFECTIVE_DATE UDE_EFF_DT,
             ACC_UDE.RATE_CODE      UDE_RATE_CODE,
             RATES.EFFECTIVE_DATE   RATE_DT,
             NULL                   COMPONENT_NAME
        FROM CLTBS_ACCOUNT_UDE_VALUES ACC_UDE,
             CLTBS_ACCOUNT_MASTER     ACC_MAS,
             CLTMS_EFFECTED_RATES     RATES
       WHERE ACC_MAS.BRANCH_CODE = P_BRANCH_CODE
         AND ACC_UDE.BRANCH_CODE = P_BRANCH_CODE
         AND RATES.BRANCH_CODE = P_BRANCH_CODE
         AND ACC_MAS.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND ACC_MAS.ACCOUNT_NUMBER = ACC_UDE.ACCOUNT_NUMBER
         AND RATES.RATE_CODE = ACC_UDE.RATE_CODE
         AND RATES.CCY_CODE = ACC_MAS.CURRENCY
         AND RATES.NEXT_EFFECTIVE_DATE >= ACC_UDE.EFFECTIVE_DATE
         AND RATES.RATE_RECORD_STATUS = 'C'
         AND RATES.BORROW_LEND_IND = 'L'
         AND ACC_MAS.AMOUNT_FINANCED <= RATES.AMOUNT_SLAB
         AND ACC_MAS.AMOUNT_FINANCED >= NVL(RATES.PREV_AMOUNT_SLAB, 0)
         AND ACC_MAS.ACCOUNT_STATUS IN ('A', 'Y')
         AND ACC_MAS.AUTH_STAT = 'A'
         AND ACC_UDE.CODE_USAGE = 'A'
         AND ACC_MAS.MODULE_CODE = RATES.MODULE_CODE
         AND RATES.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND NOT EXISTS
       (SELECT 1
                FROM CLTBS_PROCESSED_REVISIONS X
               WHERE X.ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                 AND X.BRANCH_CODE = ACC_MAS.BRANCH_CODE)

         AND ACC_UDE.RATE_CODE IN
             (SELECT RATE_CODE
                FROM CLTBS_ACCOUNT_UDE_VALUES
               WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                 AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                 AND UDE_ID = ACC_UDE.UDE_ID
                 AND RATE_CODE IS NOT NULL
                 AND CODE_USAGE = 'A'
                 AND EFFECTIVE_DATE >=
                     (SELECT MAX(EFFECTIVE_DATE)
                        FROM CLTBS_ACCOUNT_UDE_VALUES
                       WHERE ACCOUNT_NUMBER = ACC_MAS.ACCOUNT_NUMBER
                         AND BRANCH_CODE = ACC_MAS.BRANCH_CODE
                         AND UDE_ID = ACC_UDE.UDE_ID))

       ORDER BY ACCOUNT_NUMBER;

    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN,
                               P_BRANCH_CODE,
                               'ARVN',
                               L_TB_RT_ROW_ID,
                               TRUE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    L_TB_RT_ROW_ID.DELETE;

    IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_CHG_ARVN;
    END IF;

    DEBUG.PR_DEBUG('CL', 'Before end of Function FN_ARVN_FOR_ACCOUNT');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;

      P_ERRORCODE := 'CL-REVN04;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_ARVN_FOR_ACCOUNT..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_ARVN_FOR_ACCOUNT;

  FUNCTION FN_REVN_FOR_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                              P_PROC_DATE   DATE,
                              P_PROCESS_NO  IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                              P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_REVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_REVN_FOR_BRANCH');

    OPEN CUR_ACC_UDE_CHG_REVN FOR
      SELECT ACC.ROWID            P_ROWID,
             DIARY.ROWID          P_ROWID_1,
             ACC.ACCOUNT_NUMBER   ACCOUNT_NUMBER,
             ACC.PROCESS_NO       PROCESS_NO,
             ACC.VERSION_NO       VERSION_NO,
             ACC.LATEST_ESN       SEQ_NO,
             UDE.UDE_ID           UDE_ID,
             UDE.RESOLVED_VALUE   RESOLVED_VALUE,
             UDE.EFFECTIVE_DATE   UDE_EFF_DT,
             UDE.RATE_CODE        RATE_CODE,
             DIARY.EXECUTION_DATE EFFECTIVE_DATE,
             DIARY.COMPONENT_NAME COMPONENT_NAME
        FROM CLTBS_ACCOUNT_EVENTS_DIARY DIARY,
             CLTBS_ACCOUNT_MASTER       ACC,
             CLTBS_ACCOUNT_UDE_VALUES   UDE
       WHERE DIARY.BRANCH_CODE = P_BRANCH_CODE
         AND ACC.BRANCH_CODE = P_BRANCH_CODE
         AND ACC.BRANCH_CODE = DIARY.BRANCH_CODE
         AND ACC.ACCOUNT_NUMBER = DIARY.ACCOUNT_NUMBER
         AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
         AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
         AND UDE.BRANCH_CODE = DIARY.BRANCH_CODE
         AND UDE.ACCOUNT_NUMBER = DIARY.ACCOUNT_NUMBER
         AND ACC.PROCESS_NO = DIARY.PROCESS_NO
         AND DIARY.PROCESS_NO = P_PROCESS_NO
         AND DIARY.EVENT_CODE = 'REVN'
         AND DIARY.EXECUTION_DATE <= P_PROC_DATE
         AND DIARY.EXECUTION_STATUS = 'U'

         AND DIARY.CONTRACT_STATUS IN ('A', 'Y')
         AND UDE.EFFECTIVE_DATE =
             (SELECT MAX(EFFECTIVE_DATE)
                FROM CLTBS_ACCOUNT_UDE_VALUES UDE_MAX
               WHERE UDE_MAX.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
                 AND UDE_MAX.BRANCH_CODE = UDE.BRANCH_CODE
                 AND UDE_MAX.UDE_ID = UDE.UDE_ID
                 AND UDE_MAX.EFFECTIVE_DATE <= P_PROC_DATE)

         AND UDE.CODE_USAGE = 'P'
         AND UDE.RATE_CODE IS NOT NULL
         AND ACC.MODULE_CODE =
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
         AND EXISTS (SELECT 1
                FROM CLTMS_PRODUCT_COMP_FRM_ELEMS FRM
               WHERE UDE.UDE_ID = FRM.ELEM_ID
                 AND ELEM_TYPE = 'U'
                 AND PRODUCT_CODE = ACC.PRODUCT_CODE
                 AND COMPONENT_NAME = DIARY.COMPONENT_NAME
                 AND ROWNUM < 2)
       ORDER BY ACC.ACCOUNT_NUMBER;

    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_REVN,
                               P_BRANCH_CODE,
                               'REVN',
                               L_TB_RT_ROW_ID,
                               FALSE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    L_TB_RT_ROW_ID.DELETE;

    IF CUR_ACC_UDE_CHG_REVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_CHG_REVN;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      IF CUR_ACC_UDE_CHG_REVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_REVN;
      END IF;

      L_TB_RT_ROW_ID.DELETE;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_REVN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_REVN_FOR_BRANCH;

  FUNCTION FN_REVN_FOR_ACCOUNT(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,

                               P_ACC_NO     IN OUT NOCOPY CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_PROC_DATE  DATE,
                               P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM IN OUT VARCHAR2) RETURN BOOLEAN IS

    CUR_ACC_UDE_CHG_REVN REF_ACC_UDE_CHG_ARVN;
    L_TB_RT_ROW_ID       TY_TB_RATE_ROWID;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_REVN_FOR_ACCOUNT');

    OPEN CUR_ACC_UDE_CHG_REVN FOR
      SELECT ACC.ROWID            P_ROWID,
             DIARY.ROWID          P_ROWID_1,
             ACC.ACCOUNT_NUMBER   ACCOUNT_NUMBER,
             ACC.PROCESS_NO       PROCESS_NO,
             ACC.VERSION_NO       VERSION_NO,
             ACC.LATEST_ESN       SEQ_NO,
             UDE.UDE_ID           UDE_ID,
             UDE.RESOLVED_VALUE   RESOLVED_VALUE,
             UDE.EFFECTIVE_DATE   UDE_EFF_DT,
             UDE.RATE_CODE        RATE_CODE,
             DIARY.EXECUTION_DATE EFFECTIVE_DATE,
             DIARY.COMPONENT_NAME COMPONENT_NAME
        FROM CLTBS_ACCOUNT_EVENTS_DIARY DIARY,
             CLTBS_ACCOUNT_MASTER       ACC,
             CLTBS_ACCOUNT_UDE_VALUES   UDE
       WHERE ACC.BRANCH_CODE = P_BRANCH_CODE
         AND ACC.ACCOUNT_NUMBER = P_ACC_NO
         AND ACC.BRANCH_CODE = DIARY.BRANCH_CODE
         AND ACC.ACCOUNT_NUMBER = DIARY.ACCOUNT_NUMBER
         AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
         AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
         AND DIARY.EVENT_CODE = 'REVN'
         AND DIARY.EXECUTION_DATE <= P_PROC_DATE
         AND DIARY.EXECUTION_STATUS = 'U'

         AND DIARY.CONTRACT_STATUS IN ('A', 'Y')
         AND UDE.EFFECTIVE_DATE =
             (SELECT MAX(EFFECTIVE_DATE)
                FROM CLTBS_ACCOUNT_UDE_VALUES UDE_MAX
               WHERE UDE_MAX.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
                 AND UDE_MAX.BRANCH_CODE = UDE.BRANCH_CODE
                 AND UDE_MAX.UDE_ID = UDE.UDE_ID
                 AND UDE_MAX.EFFECTIVE_DATE <= P_PROC_DATE)

         AND UDE.CODE_USAGE = 'P'
         AND EXISTS
       (SELECT 1
                FROM CLTMS_PRODUCT_COMP_FRM_ELEMS FRM
               WHERE UDE.UDE_ID = FRM.ELEM_ID
                 AND ELEM_TYPE = 'U'
                 AND PRODUCT_CODE = ACC.PRODUCT_CODE
                 AND COMPONENT_NAME = DIARY.COMPONENT_NAME)
       ORDER BY ACC.ACCOUNT_NUMBER, UDE.UDE_ID;

    DEBUG.PR_DEBUG('CL', 'Before Calling fn_pop_for_revision');

    IF NOT FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_REVN,
                               P_BRANCH_CODE,
                               'REVN',
                               L_TB_RT_ROW_ID,
                               TRUE,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_pop_for_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'After Calling fn_pop_for_revision');

    IF CUR_ACC_UDE_CHG_REVN%ISOPEN THEN
      CLOSE CUR_ACC_UDE_CHG_REVN;
    END IF;

    L_TB_RT_ROW_ID.DELETE;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      L_TB_RT_ROW_ID.DELETE;
      P_ERRORCODE := 'CL-REVN10;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_REVN_FOR_ACCOUNT..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_REVN_FOR_ACCOUNT;

  FUNCTION FN_POP_FOR_REVISION(CUR_ACC_UDE_CHG_ARVN REF_ACC_UDE_CHG_ARVN,
                               P_BRANCH_CODE        IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               P_EVENT_CODE         IN CLTBS_ACCOUNT_EVENTS_DIARY.EVENT_CODE%TYPE

                              ,
                               L_TB_RT_ROW_ID IN OUT NOCOPY TY_TB_RATE_ROWID

                              ,
                               P_FOR_AN_ACCOUNT IN BOOLEAN,
                               P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    TYPE TY_TB_PROC_REVN IS TABLE OF CLTBS_PROCESSED_REVISIONS%ROWTYPE INDEX BY PLS_INTEGER;

    L_TB_DIARY_ROWID   TY_TB_RATE_ROWID;
    L_TB_UPD_DIARY_SEQ TY_TB_UPD_DIARY_SEQ;
    L_TB_UDE_DET       TY_TB_ACC_UDE_DET;
    L_TB_UDE_DET_TEMP  TY_TB_ACC_UDE_DET;
    L_TB_INS_DIARY     TY_TB_INS_DIARY;
    L_TB_PROC_REVN     TY_TB_PROC_REVN;

    L_INDEX            PLS_INTEGER;
    L_COMMIT_FREQ      NUMBER;
    L_NXT_ACC_NO       CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
    L_IDX              PLS_INTEGER;
    L_ROWID            ROWID;
    L_NO_ERRORS        PLS_INTEGER;
    L_ERR_IDX          PLS_INTEGER;
    L_TB_EVENT_ADVICES CLPKSS_ADVICES.TY_TB_EVENT_ADVICES;
    SKIP_CURRENT_SET EXCEPTION;
    L_TO_DATE           CLTB_REVN_SCHEDULES.SCHEDULE_DUE_DATE%TYPE;
    L_FROM_DATE         CLTB_REVN_SCHEDULES.SCHEDULE_DUE_DATE%TYPE;
    L_TB_L_INTERFACE_ID DBMS_SQL.VARCHAR2S;

    TYPE TY_REVN_ACC IS TABLE OF CLTBS_REVISION_ACCOUNTS%ROWTYPE INDEX BY VARCHAR2(100);
    L_TB_ACCOUNT TY_REVN_ACC;
    L_REVN_INDEX VARCHAR2(100);

    L_USER_ID          CLTBS_ACCOUNT_EVENTS_DIARY.MAKER_ID%TYPE;
    L_TB_REVN_ACCOUNTS TY_TB_REVN_ACCOUNTS;
    L_TB_REVN_ACC      DBMS_SQL.VARCHAR2S;
    L_TB_REVN_BRN      DBMS_SQL.VARCHAR2S;
    L_TB_REVN_UDE      DBMS_SQL.VARCHAR2S;
    L_TB_REVN_EFFDT    DBMS_SQL.DATE_TABLE;
    L_TB_REVN_CODE     DBMS_SQL.VARCHAR2S;
    L_TB_CHARGES       CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    L_TB_ENTRIES       CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES;
    L_TB_SCH_ROWID     CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;
    L_TB_SCH_ROW       CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;

    L_TB_INS_SCH       CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    L_TB_UPD_SCH_ROWID CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;
    L_TB_UPD_SCH_ROW   CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    L_TB_INS_ENTRIES   CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES;
    L_OTHER_EXCEPTION  BOOLEAN;

    L_ACCOUNT_OBJ CLPKSS_OBJECT.TY_REC_ACCOUNT;

    CURSOR CR_TO_DATE(P_ACC  VARCHAR2,
                      P_BRN  VARCHAR2,
                      P_COMP VARCHAR2,
                      P_DATE DATE) IS
      SELECT /*+ INDEX (a PK_REVN_SCH) */
       A.SCHEDULE_DUE_DATE
        FROM CLTBS_REVN_SCHEDULES A
       WHERE A.ACCOUNT_NUMBER = P_ACC
         AND A.BRANCH_CODE = P_BRN
         AND A.COMPONENT_NAME = P_COMP
         AND A.SCHEDULE_DUE_DATE > P_DATE
       ORDER BY A.SCHEDULE_DUE_DATE;

    PROCEDURE PR_CLEAR IS
    BEGIN

      IF GLOBAL.BRANCH_STATUS <> 'N' THEN
        L_USER_ID := 'SYSTEM';
      ELSE
        L_USER_ID := GLOBAL.USER_ID;
      END IF;

      L_TB_DIARY_ROWID.DELETE;
      L_TB_UPD_DIARY_SEQ.DELETE;
      L_TB_UDE_DET.DELETE;
      L_TB_UDE_DET_TEMP.DELETE;
      L_TB_INS_DIARY.DELETE;
      L_TB_PROC_REVN.DELETE;
      L_TB_EVENT_ADVICES.DELETE;

      L_TB_REVN_ACCOUNTS.DELETE;
      L_TB_REVN_ACC.DELETE;
      L_TB_REVN_BRN.DELETE;
      L_TB_REVN_UDE.DELETE;
      L_TB_REVN_EFFDT.DELETE;
      L_TB_REVN_CODE.DELETE;
      CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
      CLPKSS_CONTEXT.G_PROCESSING_EVENT := NULL;
      CLPKSS_CONTEXT.G_FROM_DATE        := NULL;
      CLPKSS_CONTEXT.G_TO_DATE          := NULL;
      CLPKSS_CONTEXT.G_TB_COMPONENTS.DELETE;

      L_TB_CHARGES.DELETE;
      L_TB_ENTRIES.DELETE;
      L_TB_SCH_ROWID.DELETE;
      L_TB_SCH_ROW.DELETE;

      L_TB_INS_SCH.DELETE;
      L_TB_UPD_SCH_ROWID.DELETE;
      L_TB_UPD_SCH_ROW.DELETE;
      L_TB_INS_ENTRIES.DELETE;

      L_TB_ACCOUNT.DELETE;

      L_TB_L_INTERFACE_ID.DELETE;

    END PR_CLEAR;

  BEGIN

    L_COMMIT_FREQ := NVL(CLPKSS_BATCH.G_COMMIT_FREQ, 500);

    PR_CLEAR;

    LOOP

      L_TB_DIARY_ROWID.DELETE;
      L_TB_UPD_DIARY_SEQ.DELETE;
      L_TB_UDE_DET.DELETE;
      L_TB_INS_DIARY.DELETE;
      L_TB_PROC_REVN.DELETE;
      L_TB_REVN_ACCOUNTS.DELETE;
      L_TB_REVN_ACC.DELETE;
      L_TB_REVN_BRN.DELETE;
      L_TB_REVN_UDE.DELETE;
      L_TB_REVN_EFFDT.DELETE;
      L_TB_REVN_CODE.DELETE;
      L_TB_EVENT_ADVICES.DELETE;
      L_TB_CHARGES.DELETE;
      L_TB_ENTRIES.DELETE;
      L_TB_SCH_ROWID.DELETE;
      L_TB_SCH_ROW.DELETE;
      L_TB_INS_SCH.DELETE;
      L_TB_UPD_SCH_ROWID.DELETE;
      L_TB_UPD_SCH_ROW.DELETE;
      L_TB_INS_ENTRIES.DELETE;

      L_TB_L_INTERFACE_ID.DELETE;

      L_TB_ACCOUNT.DELETE;

      FETCH CUR_ACC_UDE_CHG_ARVN BULK COLLECT
        INTO L_TB_UDE_DET LIMIT L_COMMIT_FREQ;

      IF L_TB_UDE_DET_TEMP.COUNT > 0 THEN
        DBG('Inserting Acc ::' || L_TB_UDE_DET_TEMP(L_TB_UDE_DET_TEMP.FIRST)
            .ACCOUNT_NUMBER || ' in the beginning');
        L_INDEX := L_TB_UDE_DET.FIRST;
        IF L_INDEX IS NOT NULL THEN
          L_TB_UDE_DET(L_INDEX - 1) := L_TB_UDE_DET_TEMP(L_TB_UDE_DET_TEMP.FIRST);
        ELSE
          L_TB_UDE_DET(1) := L_TB_UDE_DET_TEMP(L_TB_UDE_DET_TEMP.FIRST);
        END IF;
      END IF;

      BEGIN

        DEBUG.PR_DEBUG('CL',
                       'Processing now.. No of recs= ' ||
                       L_TB_UDE_DET.COUNT);

        IF NVL(L_TB_UDE_DET.COUNT, 0) > 0 THEN
          L_INDEX := L_TB_UDE_DET.LAST;

          DEBUG.PR_DEBUG('CL', 'l_index is ' || L_INDEX);

          LOOP
            L_TB_UDE_DET_TEMP.DELETE;

            FETCH CUR_ACC_UDE_CHG_ARVN BULK COLLECT
              INTO L_TB_UDE_DET_TEMP LIMIT 1;

            EXIT WHEN(NVL(L_TB_UDE_DET_TEMP.COUNT, 0) = 0 OR L_TB_UDE_DET_TEMP(L_TB_UDE_DET_TEMP.FIRST)
                      .ACCOUNT_NUMBER <> L_TB_UDE_DET(L_INDEX)
                      .ACCOUNT_NUMBER);

            L_INDEX := L_INDEX + 1;

            L_TB_UDE_DET(L_INDEX) := L_TB_UDE_DET_TEMP(L_TB_UDE_DET_TEMP.FIRST);
          END LOOP;
        END IF;

        DEBUG.PR_DEBUG('CL', 'The count now is = ' || L_TB_UDE_DET.COUNT);

        IF NVL(L_TB_UDE_DET.COUNT, 0) > 0 THEN
          DEBUG.PR_DEBUG('CL', 'Processing Now...');

          FOR L_IDX IN L_TB_UDE_DET.FIRST .. L_TB_UDE_DET.LAST LOOP

            L_REVN_INDEX := L_TB_UDE_DET(L_IDX)
                            .ACCOUNT_NUMBER || L_TB_UDE_DET(L_IDX).UDE_ID;
            IF NOT L_TB_ACCOUNT.EXISTS(L_REVN_INDEX) THEN

              L_TB_ACCOUNT(L_REVN_INDEX).ACCOUNT_NUMBER := L_TB_UDE_DET(L_IDX)
                                                           .ACCOUNT_NUMBER;
              L_TB_ACCOUNT(L_REVN_INDEX).BRANCH_CODE := P_BRANCH_CODE;
              L_TB_ACCOUNT(L_REVN_INDEX).LEAST_EFFECTIVE_DATE := GREATEST(L_TB_UDE_DET(L_IDX)
                                                                          .UDE_EFF_DT,
                                                                          L_TB_UDE_DET(L_IDX)
                                                                          .RATE_DT);
              L_TB_ACCOUNT(L_REVN_INDEX).UDE_ID := L_TB_UDE_DET(L_IDX)
                                                   .UDE_ID;
              L_TB_ACCOUNT(L_REVN_INDEX).RATE_CODE := L_TB_UDE_DET(L_IDX)
                                                      .UDE_RATE_CODE;
              L_TB_ACCOUNT(L_REVN_INDEX).PROCESSED := 'N';
              L_TB_ACCOUNT(L_REVN_INDEX).PROCESS_NO := L_TB_UDE_DET(L_IDX)
                                                       .PROCESS_NO;

            ELSE
              L_TB_ACCOUNT(L_REVN_INDEX).LEAST_EFFECTIVE_DATE := GREATEST(L_TB_UDE_DET(L_IDX)
                                                                          .UDE_EFF_DT,
                                                                          L_TB_UDE_DET(L_IDX)
                                                                          .RATE_DT);
              L_TB_ACCOUNT(L_REVN_INDEX).RATE_CODE := L_TB_UDE_DET(L_IDX)
                                                      .UDE_RATE_CODE;
            END IF;

            IF L_IDX + 1 <= L_TB_UDE_DET.LAST

             THEN
              L_NXT_ACC_NO := L_TB_UDE_DET(L_IDX + 1).ACCOUNT_NUMBER;
            END IF;

            IF P_EVENT_CODE = 'REVN' THEN
              L_TB_DIARY_ROWID(NVL(L_TB_DIARY_ROWID.COUNT, 0) + 1) := L_TB_UDE_DET(L_IDX)
                                                                      .P_ROWID_1;
              L_TB_UPD_DIARY_SEQ(NVL(L_TB_UPD_DIARY_SEQ.COUNT, 0) + 1) := L_TB_UDE_DET(L_IDX)
                                                                          .SEQ_NO + 1;
              L_TB_L_INTERFACE_ID(NVL(L_TB_L_INTERFACE_ID.COUNT, 0) + 1) := CLPKSS_CONTEXT.FN_GET_TXN_ID(L_TB_UDE_DET(L_IDX)
                                                                                                         .ACCOUNT_NUMBER,
                                                                                                         P_BRANCH_CODE);

              IF NOT FN_POPULATE_DIARY(L_TB_INS_DIARY,
                                       L_TB_UDE_DET  (L_IDX).ACCOUNT_NUMBER,
                                       P_BRANCH_CODE,
                                       P_EVENT_CODE,
                                       L_TB_UDE_DET  (L_IDX).SEQ_NO + 1,
                                       L_TB_UDE_DET  (L_IDX).PROCESS_NO,
                                       L_TB_UDE_DET  (L_IDX).VERSION_NO,
                                       L_TB_UDE_DET  (L_IDX).RATE_DT,
                                       L_TB_UDE_DET  (L_IDX).COMPONENT_NAME,
                                       P_ERRORCODE) THEN
                DEBUG.PR_DEBUG('CL', 'Failed in Diary population');
                RAISE SKIP_CURRENT_SET;
              END IF;

            END IF;

            IF (L_TB_UDE_DET(L_IDX).ACCOUNT_NUMBER <> L_NXT_ACC_NO

               OR L_IDX = L_TB_UDE_DET.LAST)

             THEN

              L_TB_EVENT_ADVICES.DELETE;
              L_TB_CHARGES.DELETE;
              L_TB_ENTRIES.DELETE;
              L_TB_SCH_ROWID.DELETE;
              L_TB_SCH_ROW.DELETE;

              IF P_EVENT_CODE = 'ARVN' THEN
                IF NOT FN_POPULATE_DIARY(L_TB_INS_DIARY,
                                         L_TB_UDE_DET  (L_IDX).ACCOUNT_NUMBER,
                                         P_BRANCH_CODE,
                                         P_EVENT_CODE,
                                         L_TB_UDE_DET  (L_IDX).SEQ_NO + 1,
                                         L_TB_UDE_DET  (L_IDX).PROCESS_NO,
                                         L_TB_UDE_DET  (L_IDX).VERSION_NO

                                        ,
                                         GLOBAL.APPLICATION_DATE,
                                         NULL

                                        ,
                                         P_ERRORCODE) THEN
                  DEBUG.PR_DEBUG('CL', 'Failed in Diary population');
                  RAISE SKIP_CURRENT_SET;
                END IF;
              ELSE

                CLPKSS_CONTEXT.G_FUNCTION_ID := NVL(CLPKSS_CONTEXT.G_FUNCTION_ID,
                                                    'REVN');

                CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
                CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_MASTER') := 1;
                CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_COMPONENTS') := 1;
                CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTBS_ACCOUNT_COMPONENTS') := 1;

                IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(L_ACCOUNT_OBJ,
                                                         P_ERRORCODE,
                                                         P_ERRORPARAM) THEN
                  DBG('clpkss_object.fn_clear_acc_object failed with :-( ' ||
                      P_ERRORCODE);
                  RAISE SKIP_CURRENT_SET;
                END IF;

                IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_UDE_DET(L_IDX)
                                                           .ACCOUNT_NUMBER,
                                                           P_BRANCH_CODE,
                                                           L_ACCOUNT_OBJ,
                                                           P_ERRORCODE,
                                                           P_ERRORPARAM) THEN
                  DBG('clpkss_object.fn_create_acct_object failed with :-( ' ||
                      P_ERRORCODE);
                  RAISE SKIP_CURRENT_SET;
                END IF;

                IF NOT
                    CLPKSS_ADVICES.FN_DEFAULT_EVENT_ADVICES(L_ACCOUNT_OBJ,
                                                            CLPKSS_NLS.REVN,
                                                            L_TB_UDE_DET(L_IDX)
                                                            .SEQ_NO + 1,
                                                            P_ERRORCODE,
                                                            P_ERRORPARAM) THEN

                  DEBUG.PR_DEBUG('CL',
                                 'Failed in processing of default advice: ' ||
                                 P_ERRORCODE);

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_UDE_DET(L_IDX)
                                              .ACCOUNT_NUMBER,
                                              P_BRANCH_CODE,
                                              GLOBAL.APPLICATION_DATE,
                                              P_EVENT_CODE,
                                              'Failed in processing of advices:' ||
                                              P_ERRORCODE || ' - ' ||
                                              P_ERRORPARAM);

                  RAISE SKIP_CURRENT_SET;

                END IF;

                IF L_ACCOUNT_OBJ.G_TB_EVENT_ADV.COUNT > 0 THEN

                  BEGIN
                    L_FROM_DATE := GLOBAL.APPLICATION_DATE;

                    OPEN CR_TO_DATE(L_TB_UDE_DET (L_IDX).ACCOUNT_NUMBER,
                                    P_BRANCH_CODE,
                                    L_TB_UDE_DET (L_IDX).COMPONENT_NAME,
                                    L_FROM_DATE);

                    L_TO_DATE := NULL;

                    FETCH CR_TO_DATE
                      INTO L_TO_DATE;
                    CLOSE CR_TO_DATE;

                    SELECT MIN(SCHEDULE_DUE_DATE)
                      INTO L_TO_DATE
                      FROM CLTBS_REVN_SCHEDULES
                     WHERE ACCOUNT_NUMBER = L_TB_UDE_DET(L_IDX)
                          .ACCOUNT_NUMBER
                       AND BRANCH_CODE = P_BRANCH_CODE
                       AND COMPONENT_NAME = L_TB_UDE_DET(L_IDX)
                          .COMPONENT_NAME
                       AND SCHEDULE_DUE_DATE > L_FROM_DATE;

                    DBG('at 9666 l_to_date->' || L_TO_DATE);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      L_TO_DATE := NULL;
                  END;
                  CLPKSS_ADVICES.PR_INITIATE_DATES(L_FROM_DATE, L_TO_DATE);
                END IF;

                IF NOT
                    CLPKSS_ADVICES.FN_PROCESS_EVENT_ADVICES(L_ACCOUNT_OBJ,
                                                            L_TB_UDE_DET(L_IDX)
                                                            .SEQ_NO + 1,
                                                            'A',
                                                            P_ERRORCODE,
                                                            P_ERRORPARAM)

                 THEN
                  DEBUG.PR_DEBUG('CL',
                                 'Failed in processing of default advice: ' ||
                                 P_ERRORCODE);

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_UDE_DET(L_IDX)
                                              .ACCOUNT_NUMBER,
                                              P_BRANCH_CODE,
                                              GLOBAL.APPLICATION_DATE,
                                              P_EVENT_CODE,
                                              'Failed in processing of advices:' ||
                                              P_ERRORCODE || ' - ' ||
                                              P_ERRORPARAM);
                END IF;
              END IF;

              DBG('Process Revision - Account Number ' || L_TB_UDE_DET(L_IDX)
                  .ACCOUNT_NUMBER);
              DBG('Process Revision - Branch Code' || P_BRANCH_CODE);

              IF L_TB_CHARGES.COUNT > 0 THEN
                FOR I IN L_TB_CHARGES.FIRST .. L_TB_CHARGES.LAST LOOP
                  L_TB_INS_SCH(L_TB_INS_SCH.COUNT + 1) := L_TB_CHARGES(I);
                END LOOP;
              END IF;

              IF L_TB_ENTRIES.COUNT > 0 THEN
                FOR I IN L_TB_ENTRIES.FIRST .. L_TB_ENTRIES.LAST LOOP
                  L_TB_INS_ENTRIES(L_TB_INS_ENTRIES.COUNT + 1) := L_TB_ENTRIES(I);
                END LOOP;
              END IF;

              IF L_TB_SCH_ROWID.COUNT > 0 THEN
                FOR I IN L_TB_SCH_ROWID.FIRST .. L_TB_SCH_ROWID.LAST LOOP
                  L_TB_UPD_SCH_ROWID(L_TB_UPD_SCH_ROWID.COUNT + 1) := L_TB_SCH_ROWID(I);
                END LOOP;
              END IF;

              IF L_TB_SCH_ROW.COUNT > 0 THEN
                FOR I IN L_TB_SCH_ROW.FIRST .. L_TB_SCH_ROW.LAST LOOP
                  L_TB_UPD_SCH_ROW(L_TB_UPD_SCH_ROW.COUNT + 1) := L_TB_SCH_ROW(I);
                END LOOP;
              END IF;

              IF L_ACCOUNT_OBJ.G_TB_EVENT_ADV.COUNT > 0 THEN
                FOR I IN L_ACCOUNT_OBJ.G_TB_EVENT_ADV.FIRST .. L_ACCOUNT_OBJ.G_TB_EVENT_ADV.LAST LOOP
                  L_TB_EVENT_ADVICES(L_TB_EVENT_ADVICES.COUNT + 1) := L_ACCOUNT_OBJ.G_TB_EVENT_ADV(I)
                                                                      .EVENTS_ADVICES_DET;
                END LOOP;
              END IF;

              L_TB_PROC_REVN(NVL(L_TB_PROC_REVN.COUNT, 0) + 1).ACCOUNT_NUMBER := L_TB_UDE_DET(L_IDX)
                                                                                 .ACCOUNT_NUMBER;
              L_TB_PROC_REVN(L_TB_PROC_REVN.COUNT).BRANCH_CODE := P_BRANCH_CODE;

              DBG(L_TB_PROC_REVN.COUNT);
            END IF;

            DEBUG.PR_DEBUG('CL', 'before rowid');

            L_ROWID := L_TB_UDE_DET(L_IDX).P_ROWID;

            DEBUG.PR_DEBUG('CL', 'before check..');

            L_TB_RT_ROW_ID(NVL(L_TB_RT_ROW_ID.COUNT, 0) + 1) := L_ROWID;

            DEBUG.PR_DEBUG('CL', 'after rowid');

          END LOOP;

          IF L_TB_ACCOUNT.COUNT > 0 THEN

            L_REVN_INDEX := L_TB_ACCOUNT.FIRST;
            WHILE L_REVN_INDEX IS NOT NULL LOOP

              L_TB_REVN_ACCOUNTS(L_TB_REVN_ACCOUNTS.COUNT + 1) := L_TB_ACCOUNT(L_REVN_INDEX);

              L_REVN_INDEX := L_TB_ACCOUNT.NEXT(L_REVN_INDEX);

            END LOOP;

          END IF;

          IF NVL(L_TB_INS_DIARY.COUNT, 0) > 0 THEN
            IF NOT
                FN_INSERT_DIARY(L_TB_INS_DIARY, P_BRANCH_CODE, P_ERRORCODE) THEN
              DEBUG.PR_DEBUG('CL', 'Failed in Diary insert');

              RAISE SKIP_CURRENT_SET;
            END IF;
          END IF;

          IF NVL(L_TB_DIARY_ROWID.COUNT, 0) > 0 THEN
            BEGIN
              FORALL I IN L_TB_DIARY_ROWID.FIRST .. L_TB_DIARY_ROWID.LAST SAVE
                                                    EXCEPTIONS
                UPDATE CLTBS_ACCOUNT_EVENTS_DIARY
                   SET MAKER_ID = L_USER_ID

                      ,
                       CHECKER_ID = L_USER_ID

                      ,
                       MAKER_DT_STAMP   = CSFNS_TIMESTAMP,
                       CHECKER_DT_STAMP = CSFNS_TIMESTAMP

                      ,
                       EVENT_SEQ_NO = L_TB_UPD_DIARY_SEQ(I)

                      ,
                       INTERFACE_ID = L_TB_L_INTERFACE_ID(I)

                      ,
                       EVENT_DATE       = GLOBAL.APPLICATION_DATE,
                       AUTH_STATUS      = 'A',
                       EXECUTION_STATUS = 'P'
                 WHERE ROWID = L_TB_DIARY_ROWID(I);

              DEBUG.PR_DEBUG('CL', 'updated cltbs_account_events_diaryy');

            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                L_OTHER_EXCEPTION := FALSE;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

                  IF SQL%BULK_EXCEPTIONS(L_IDX).ERROR_CODE <> 1 THEN
                    L_OTHER_EXCEPTION := TRUE;

                    CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                                 P_BRANCH_CODE,
                                                 GLOBAL.APPLICATION_DATE,
                                                 P_EVENT_CODE,
                                                 'ERROR :' || L_IDX ||
                                                 '  POSITION = ' ||
                                                 L_ERR_IDX ||
                                                 ' -- ERROR_CODE = ' ||
                                                 SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                         .ERROR_CODE));

                  END IF;

                END LOOP;

                IF L_OTHER_EXCEPTION THEN
                  ROLLBACK;
                  L_OTHER_EXCEPTION := FALSE;
                  RAISE SKIP_CURRENT_SET;
                END IF;

            END;

            IF NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('STREAM'), 'LATAM') IN
               ('LATAM', 'RUSSIA') THEN

              IF NOT CLPKSS_STREAM_CONTEXT.FN_INSERT_TXN_LOG

               THEN
                DBG('Failed in clpkss_context.fn_insert_txn_id');
                ROLLBACK;
                P_ERRORCODE  := 'CL-REVN06;';
                P_ERRORPARAM := 'TRANSACTION LOG raised exception';
                RETURN FALSE;
              END IF;

            END IF;

          END IF;

          IF NVL(L_TB_PROC_REVN.COUNT, 0) > 0 THEN
            BEGIN
              FORALL I IN L_TB_PROC_REVN.FIRST .. L_TB_PROC_REVN.LAST SAVE
                                                  EXCEPTIONS
                INSERT INTO CLTBS_PROCESSED_REVISIONS
                VALUES L_TB_PROC_REVN
                  (I);

              DEBUG.PR_DEBUG('CL', 'Updated cltbs_processed_revisions');
            EXCEPTION

              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_PROCESSED_REVISIONS');

                L_OTHER_EXCEPTION := FALSE;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  IF SQL%BULK_EXCEPTIONS(L_IDX).ERROR_CODE <> 1 THEN
                    L_OTHER_EXCEPTION := TRUE;

                    CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                                 P_BRANCH_CODE,
                                                 GLOBAL.APPLICATION_DATE,
                                                 P_EVENT_CODE,
                                                 'ERROR :' || L_IDX ||
                                                 '  POSITION = ' ||
                                                 L_ERR_IDX ||
                                                 ' -- ERROR_CODE = ' ||
                                                 SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                         .ERROR_CODE));

                  ELSE
                    NULL;
                  END IF;

                END LOOP;
                IF L_OTHER_EXCEPTION THEN
                  ROLLBACK;
                  RAISE SKIP_CURRENT_SET;
                END IF;
            END;
          END IF;

          IF L_TB_REVN_ACCOUNTS.COUNT > 0 THEN
            BEGIN

              FORALL I IN L_TB_REVN_ACCOUNTS.FIRST .. L_TB_REVN_ACCOUNTS.LAST SAVE
                                                      EXCEPTIONS
                INSERT INTO CLTBS_REVISION_ACCOUNTS
                VALUES L_TB_REVN_ACCOUNTS
                  (I);

              DBG('Inserted into cltbs_revision_accounts');

            EXCEPTION

              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DBG('Error Raised Here at CLTBS_REVISION_ACCOUNTS');

                L_OTHER_EXCEPTION := FALSE;
                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  IF SQL%BULK_EXCEPTIONS(L_IDX).ERROR_CODE <> 1 THEN
                    L_OTHER_EXCEPTION := TRUE;
                    CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                                 P_BRANCH_CODE,
                                                 GLOBAL.APPLICATION_DATE,
                                                 P_EVENT_CODE,
                                                 'ERROR :' || L_IDX ||
                                                 '  POSITION = ' ||
                                                 L_ERR_IDX ||
                                                 ' -- ERROR_CODE = ' ||
                                                 SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                         .ERROR_CODE));
                  ELSE

                    L_INDEX := L_TB_REVN_ACC.COUNT + 1;
                    L_TB_REVN_ACC(L_INDEX) := L_TB_REVN_ACCOUNTS(L_ERR_IDX)
                                              .ACCOUNT_NUMBER;
                    L_TB_REVN_BRN(L_INDEX) := L_TB_REVN_ACCOUNTS(L_ERR_IDX)
                                              .BRANCH_CODE;
                    L_TB_REVN_EFFDT(L_INDEX) := L_TB_REVN_ACCOUNTS(L_ERR_IDX)
                                                .LEAST_EFFECTIVE_DATE;
                    L_TB_REVN_UDE(L_INDEX) := L_TB_REVN_ACCOUNTS(L_ERR_IDX)
                                              .UDE_ID;
                    L_TB_REVN_CODE(L_INDEX) := L_TB_REVN_ACCOUNTS(L_ERR_IDX)
                                               .RATE_CODE;

                  END IF;

                END LOOP;

                IF L_OTHER_EXCEPTION THEN
                  ROLLBACK;
                  RAISE SKIP_CURRENT_SET;
                END IF;
            END;

          END IF;

          IF L_TB_REVN_ACC.COUNT > 0 THEN
            BEGIN

              FORALL I IN L_TB_REVN_ACC.FIRST .. L_TB_REVN_ACC.LAST SAVE
                                                 EXCEPTIONS
                UPDATE CLTBS_REVISION_ACCOUNTS

                   SET LEAST_EFFECTIVE_DATE = GREATEST(L_TB_REVN_EFFDT(I),
                                                       LEAST_EFFECTIVE_DATE),
                       RATE_CODE            = L_TB_REVN_CODE(I),
                       PROCESSED            = 'N'
                 WHERE ACCOUNT_NUMBER = L_TB_REVN_ACC(I)
                   AND BRANCH_CODE = L_TB_REVN_BRN(I)
                   AND UDE_ID = L_TB_REVN_UDE(I);

              DBG('Inserted into cltbs_revision_accounts');

            EXCEPTION

              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DBG('Error Raised Here at update of  cltbs_revision_accounts');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               P_EVENT_CODE,
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;

          END IF;

          IF L_TB_INS_SCH.COUNT > 0 THEN
            BEGIN

              FORALL I IN L_TB_INS_SCH.FIRST .. L_TB_INS_SCH.LAST SAVE
                                                EXCEPTIONS
                INSERT INTO CLTBS_ACCOUNT_SCHEDULES
                VALUES L_TB_INS_SCH
                  (I);

              DBG('Inserted into cltb_account_schedules');

            EXCEPTION

              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DBG('Error Raised Here at CLTB_ACCOUNT_SCHEDULES');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               P_EVENT_CODE,
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;

          END IF;

          IF L_TB_UPD_SCH_ROWID.COUNT > 0 THEN
            BEGIN

              FORALL I IN L_TB_UPD_SCH_ROWID.FIRST .. L_TB_UPD_SCH_ROWID.LAST SAVE
                                                      EXCEPTIONS
                UPDATE CLTBS_ACCOUNT_SCHEDULES
                   SET ROW = L_TB_UPD_SCH_ROW(I)
                 WHERE ROWID = L_TB_UPD_SCH_ROWID(I);

              DBG('Updated into cltb_account_schedules');

            EXCEPTION

              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DBG('Error Raised Here at UPDATE OF CLTBS_ACCOUNT_SCHEDULES');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               P_EVENT_CODE,
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;

          END IF;

          IF NOT CLPKSS_ACCOUNTING.FN_STORE_EVENT_ENTRIES(L_TB_INS_ENTRIES,
                                                          'B',
                                                          P_ERRORCODE,
                                                          P_ERRORPARAM) THEN
            DBG('Failed in store event entries ::' || P_ERRORCODE);
            ROLLBACK;
            RAISE SKIP_CURRENT_SET;
          END IF;

          CLPKSS_ADVICES.PR_INS_EVENTADV(L_TB_EVENT_ADVICES);

        END IF;

        IF NOT P_FOR_AN_ACCOUNT THEN
          DBG('Before commit in fn_pop_for_revision');
          COMMIT;
        END IF;

        L_TB_UDE_DET.DELETE;
        L_TB_INS_DIARY.DELETE;
        L_TB_PROC_REVN.DELETE;
        L_TB_UPD_DIARY_SEQ.DELETE;
        L_TB_DIARY_ROWID.DELETE;

      EXCEPTION
        WHEN SKIP_CURRENT_SET THEN
          DBG('Error is' || SQLERRM);

          ROLLBACK;

          L_TB_UDE_DET.DELETE;
          L_TB_INS_DIARY.DELETE;
          L_TB_PROC_REVN.DELETE;
          L_TB_UPD_DIARY_SEQ.DELETE;
          L_TB_DIARY_ROWID.DELETE;
      END;

      EXIT WHEN CUR_ACC_UDE_CHG_ARVN%NOTFOUND;
    END LOOP;

    IF NOT P_FOR_AN_ACCOUNT THEN
      DBG('Before commit in fn_pop_for_revision-2');
      COMMIT;
    END IF;

    PR_CLEAR;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;

      L_TB_RT_ROW_ID.DELETE;
      L_TB_UDE_DET.DELETE;
      L_TB_INS_DIARY.DELETE;
      L_TB_PROC_REVN.DELETE;
      L_TB_UPD_DIARY_SEQ.DELETE;
      L_TB_DIARY_ROWID.DELETE;

      IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_ARVN;
      END IF;

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      PR_CLEAR;
      IF CUR_ACC_UDE_CHG_ARVN%ISOPEN THEN
        CLOSE CUR_ACC_UDE_CHG_ARVN;
      END IF;

      DBG('BOMBED in FN_ARVN_FOR_BRANCH..');
      DBG('SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DBG('SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_POP_FOR_REVISION;

  FUNCTION FN_PROC_REVISION_FOR_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                                       P_PROCESS_NO  IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE

                                      ,
                                       P_PROC_DATE IN DATE

                                      ,
                                       P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                       P_ERRORPARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CUR_ALL_REVN_ACC REF_ALL_REVN_ACC;
    CUR_ALL_REVN_UDE REF_ALL_REVN_UDE;
    CUR_ALL_REVN     REF_ALL_REVN;
  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_PROC_REVISION_FOR_BRANCH');

    DEBUG.PR_DEBUG('CL', 'Deleting the previously resolved UDE records');

    OPEN CUR_ALL_REVN_ACC FOR

      SELECT DISTINCT A.ROWID P_ROWID,
                      A.ACCOUNT_NUMBER,
                      A.BRANCH_CODE

                     ,
                      GREATEST((SELECT MIN(C.EFFECTIVE_DATE)
                                 FROM CLTBS_ACCOUNT_UDE_VALUES C
                                WHERE C.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                                  AND C.BRANCH_CODE = A.BRANCH_CODE),
                               A.LEAST_EFFECTIVE_DATE) EFFECTIVE_DATE

                     ,
                      B.UDE_ID,
                      B.RATE_CODE

                     ,
                      NVL(B.CODE_USAGE, 'P')

        FROM CLTBS_REVISION_ACCOUNTS A, CLTBS_ACCOUNT_UDE_VALUES B
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND A.UDE_ID = B.UDE_ID

         AND NVL(A.RATE_CODE, '$$$') = NVL(B.RATE_CODE, '$$$')

         AND A.PROCESSED = 'N'

         AND A.PROCESS_NO = P_PROCESS_NO

         AND EXISTS
       (SELECT 1
                FROM CLTBS_ACCOUNT_APPS_MASTER E2
               WHERE E2.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                 AND E2.BRANCH_CODE = P_BRANCH_CODE
                 AND E2.MODULE_CODE =
                     NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL'))

       ORDER BY ACCOUNT_NUMBER, UDE_ID;

    OPEN CUR_ALL_REVN_UDE FOR
      SELECT A.ROWID P_ROWID,
             A.ACCOUNT_NUMBER,
             A.BRANCH_CODE,
             B.EFFECTIVE_DATE,
             B.UDE_ID,
             B.UDE_VALUE,
             B.RATE_CODE,
             B.CODE_USAGE,
             B.RATE_BASIS
        FROM CLTBS_ACCOUNT_UDE_VALUES B, CLTBS_REVISION_ACCOUNTS A
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.PROCESSED = 'N'

         AND A.PROCESS_NO = P_PROCESS_NO

         AND B.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
         AND B.BRANCH_CODE = A.BRANCH_CODE
         AND B.UDE_ID = A.UDE_ID
       ORDER BY ACCOUNT_NUMBER, UDE_ID;

    OPEN CUR_ALL_REVN FOR
      SELECT DISTINCT A.ACCOUNT_NUMBER, A.BRANCH_CODE, A.EXECUTION_DATE
        FROM CLTBS_ACCOUNT_EVENTS_DIARY A, CLTBS_REVISION_ACCOUNTS B
       WHERE A.BRANCH_CODE = P_BRANCH_CODE

         AND B.PROCESS_NO = P_PROCESS_NO

         AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND B.PROCESSED = 'N'
         AND A.EVENT_CODE = 'REVN'

         AND A.CONTRACT_STATUS IN ('A', 'Y')

         AND A.EXECUTION_DATE >= B.LEAST_EFFECTIVE_DATE

         AND A.EXECUTION_DATE <= P_PROC_DATE

       ORDER BY A.ACCOUNT_NUMBER, A.EXECUTION_DATE;

    IF NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL') = 'LS' THEN
      IF NOT FN_PROCESS_REVN_MRG(P_BRANCH_CODE,
                                 CUR_ALL_REVN_ACC,
                                 CUR_ALL_REVN_UDE,
                                 CUR_ALL_REVN,
                                 FALSE,
                                 P_PROC_DATE,
                                 NULL,
                                 P_PROCESS_NO,
                                 P_ERRORCODE,
                                 P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  FN_PROCESS_REVN_MRG' || P_ERRORCODE);
        RETURN FALSE;
      END IF;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_REVISION');

    IF NOT FN_PROCESS_REVISION(P_BRANCH_CODE,
                               CUR_ALL_REVN_ACC,
                               CUR_ALL_REVN_UDE,
                               CUR_ALL_REVN,
                               FALSE

                              ,
                               P_PROC_DATE

                              ,
                               NULL,
                               P_PROCESS_NO

                              ,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_process_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'End of FN_PROC_REVISION_FOR_BRANCH');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_PROC_REVISION_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PROC_REVISION_FOR_BRANCH;

  FUNCTION FN_PROC_REVISION_FOR_ACCOUNT(P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                                        P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE

                                       ,
                                        P_PROC_DATE IN DATE

                                       ,
                                        P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                        P_ERRORPARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CUR_ALL_REVN_ACC REF_ALL_REVN_ACC;
    CUR_ALL_REVN_UDE REF_ALL_REVN_UDE;
    CUR_ALL_REVN     REF_ALL_REVN;
  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_PROC_REVISION_FOR_ACCOUNT');

    DEBUG.PR_DEBUG('CL', 'Deleting the previously resolved UDE records');

    OPEN CUR_ALL_REVN_ACC FOR
      SELECT DISTINCT A.ROWID P_ROWID,
                      A.ACCOUNT_NUMBER,
                      A.BRANCH_CODE

                     ,
                      GREATEST((SELECT MIN(C.EFFECTIVE_DATE)
                                 FROM CLTBS_ACCOUNT_UDE_VALUES C
                                WHERE C.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                                  AND C.BRANCH_CODE = A.BRANCH_CODE),
                               A.LEAST_EFFECTIVE_DATE) EFFECTIVE_DATE

                     ,
                      B.UDE_ID,
                      B.RATE_CODE,
                      NVL(B.CODE_USAGE, 'P')
        FROM CLTBS_REVISION_ACCOUNTS A, CLTBS_ACCOUNT_UDE_VALUES B
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND A.UDE_ID = B.UDE_ID
         AND A.PROCESSED = 'N'
       ORDER BY ACCOUNT_NUMBER, UDE_ID;

    OPEN CUR_ALL_REVN_UDE FOR
      SELECT A.ROWID P_ROWID,
             A.ACCOUNT_NUMBER,
             A.BRANCH_CODE,
             B.EFFECTIVE_DATE,
             B.UDE_ID,
             B.UDE_VALUE,
             B.RATE_CODE,
             B.CODE_USAGE,
             B.RATE_BASIS
        FROM CLTBS_REVISION_ACCOUNTS A, CLTBS_ACCOUNT_UDE_VALUES B
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND A.UDE_ID = B.UDE_ID
         AND A.PROCESSED = 'N'
       ORDER BY ACCOUNT_NUMBER, UDE_ID;

    OPEN CUR_ALL_REVN FOR
      SELECT DISTINCT A.ACCOUNT_NUMBER, A.BRANCH_CODE, A.EXECUTION_DATE
        FROM CLTBS_ACCOUNT_EVENTS_DIARY A, CLTBS_REVISION_ACCOUNTS B
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND B.PROCESSED = 'N'
         AND A.EVENT_CODE = 'REVN'

         AND A.CONTRACT_STATUS IN ('A', 'Y')

         AND A.EXECUTION_DATE >= B.LEAST_EFFECTIVE_DATE

         AND A.EXECUTION_DATE <= P_PROC_DATE

       ORDER BY A.ACCOUNT_NUMBER, A.EXECUTION_DATE;

    DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_REVISION');

    IF NOT FN_PROCESS_REVISION(P_BRANCH_CODE,
                               CUR_ALL_REVN_ACC,
                               CUR_ALL_REVN_UDE,
                               CUR_ALL_REVN,
                               TRUE

                              ,
                               P_PROC_DATE

                              ,
                               P_ACCOUNT_NUMBER,
                               NULL

                              ,
                               P_ERRORCODE,
                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL', 'failed in  fn_process_revision' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    DEBUG.PR_DEBUG('CL', 'End of FN_PROC_REVISION_FOR_ACCOUNT');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_PROC_REVISION_FOR_ACCOUNT..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PROC_REVISION_FOR_ACCOUNT;

  FUNCTION FN_PROCESS_REVISION(P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               CUR_ALL_REV_ACC  REF_ALL_REVN_ACC,
                               CUR_ALL_REV_UDE  REF_ALL_REVN_UDE,
                               CUR_ALL_REVN     REF_ALL_REVN,
                               P_FOR_AN_ACCOUNT IN BOOLEAN

                              ,
                               P_PROC_DATE IN DATE

                              ,
                               P_ACCOUNT_NUMBER IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                               P_PROCESS_NO     IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE

                              ,
                               P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM IN OUT VARCHAR2) RETURN BOOLEAN IS

    CURSOR CUR_RATE_DET IS
      SELECT B.ROWID              RATE_ROW_ID,
             A.RATE_CODE          RATE_CODE,
             B.CCY_CODE           CCY,
             B.EFFECTIVE_DATE     RT_EFF_DT,
             B.PREV_AMOUNT_SLAB   PREV_AMT,
             B.AMOUNT_SLAB        AMT_SLAB,
             A.TENOR_FROM         TEN_FROM,
             A.TENOR_TO           TEN_TO,
             A.INT_RATE           RATE,
             B.RATE_RECORD_STATUS CHG_STAT
        FROM CFTM_FLOAT_RATE_DETAIL A

            ,
             CFTMS_FLOAT_RATE_MASTER B

       WHERE B.BRANCH_CODE = P_BRANCH_CODE
         AND B.BRANCH_CODE = A.BRANCH_CODE
         AND B.RATE_CODE = A.RATE_CODE
         AND B.CCY_CODE = A.CCY_CODE
         AND B.AMOUNT_SLAB = A.AMOUNT_SLAB
         AND B.EFFECTIVE_DATE = A.EFFECTIVE_DATE
         AND

             A.BRANCH_CODE = P_BRANCH_CODE
         AND A.BORROW_LEND_IND = 'L'
         AND B.EFFECTIVE_DATE <= P_PROC_DATE
         AND EXISTS
       (SELECT 1
                FROM CLTBS_REVISION_ACCOUNTS X
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND X.RATE_CODE = A.RATE_CODE
                 AND PROCESSED = 'N'

                 AND X.ACCOUNT_NUMBER =
                     NVL(P_ACCOUNT_NUMBER, X.ACCOUNT_NUMBER)
                 AND X.PROCESS_NO = NVL(P_PROCESS_NO, X.PROCESS_NO)
                 AND X.LEAST_EFFECTIVE_DATE <= P_PROC_DATE

              )

      UNION
      SELECT T.ROWID          RATE_ROW_ID,
             T.RATE_CODE      RATE_CODE,
             T.CCY            CCY,
             T.EFFECTIVE_DATE RT_EFF_DT,
             NULL             PREV_AMT,
             NULL             AMT_SLAB,
             NULL             TEN_FROM,
             NULL             TEN_TO,
             T.INT_RATE       RATE,
             NULL             CHG_STAT
        FROM CLTBS_ACCOUNT_TDUDE_RATE T
       WHERE T.BRANCH_CODE = P_BRANCH_CODE

         AND T.PROCESSED IN ('N', 'F')
         AND T.PROCESSING_DATE IS NULL
         AND T.EFFECTIVE_DATE IN
             (SELECT MAX(EFFECTIVE_DATE)
                FROM CLTBS_ACCOUNT_TDUDE_RATE
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND ACCOUNT_NUMBER = T.ACCOUNT_NUMBER
                 AND PROCESSED IN ('N', 'F')
                 AND PROCESSING_DATE IS NULL)

         AND EXISTS
       (SELECT 1
                FROM CLTBS_REVISION_ACCOUNTS X
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND X.RATE_CODE = T.RATE_CODE
                 AND X.PROCESSED = 'N'
                 AND X.ACCOUNT_NUMBER = T.ACCOUNT_NUMBER
                 AND X.ACCOUNT_NUMBER =
                     NVL(P_ACCOUNT_NUMBER, X.ACCOUNT_NUMBER)
                 AND X.PROCESS_NO = NVL(P_PROCESS_NO, X.PROCESS_NO)
                 AND ROWNUM < 2)
       ORDER BY RATE_CODE, CCY, RT_EFF_DT, AMT_SLAB, TEN_FROM;

    TYPE TY_PROCESSED_AC_ROWID IS TABLE OF ROWID INDEX BY PLS_INTEGER;

    TYPE TY_TB_RATE_DET IS TABLE OF CUR_RATE_DET%ROWTYPE INDEX BY PLS_INTEGER;
    L_AC_NO   CLTBS_ACCOUNT_APPS_MASTER.ACCOUNT_NUMBER%TYPE;
    L_ACC_CCY CLTBS_ACCOUNT_APPS_MASTER.CURRENCY%TYPE;
    L_ACC_DET CLTBS_ACCOUNT_APPS_MASTER%ROWTYPE;

    CURSOR CUR_RATE_DET_ACC(L_ACC_CCY VARCHAR2) IS
      SELECT B.ROWID              RATE_ROW_ID,
             A.RATE_CODE          RATE_CODE,
             B.CCY_CODE           CCY,
             B.EFFECTIVE_DATE     RT_EFF_DT,
             B.PREV_AMOUNT_SLAB   PREV_AMT,
             B.AMOUNT_SLAB        AMT_SLAB,
             A.TENOR_FROM         TEN_FROM,
             A.TENOR_TO           TEN_TO,
             A.INT_RATE           RATE,
             B.RATE_RECORD_STATUS CHG_STAT
        FROM CFTM_FLOAT_RATE_DETAIL A, CFTMS_FLOAT_RATE_MASTER B

       WHERE A.BRANCH_CODE = B.BRANCH_CODE
         AND A.RATE_CODE = B.RATE_CODE
         AND A.CCY_CODE = B.CCY_CODE
         AND A.CCY_CODE = L_ACC_CCY
         AND A.EFFECTIVE_DATE = B.EFFECTIVE_DATE
         AND B.EFFECTIVE_DATE <= P_PROC_DATE
         AND A.BORROW_LEND_IND = B.BORROW_LEND_IND
         AND A.AMOUNT_SLAB = B.AMOUNT_SLAB
         AND A.BRANCH_CODE = P_BRANCH_CODE
         AND B.BRANCH_CODE = P_BRANCH_CODE
         AND A.BORROW_LEND_IND = 'L'
         AND EXISTS
       (SELECT 1
                FROM CLTBS_REVISION_ACCOUNTS X
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND X.RATE_CODE = A.RATE_CODE
                 AND PROCESSED = 'N'
                 AND X.ACCOUNT_NUMBER =
                     NVL(P_ACCOUNT_NUMBER, X.ACCOUNT_NUMBER)
                 AND X.PROCESS_NO = NVL(P_PROCESS_NO, X.PROCESS_NO)
                 AND X.LEAST_EFFECTIVE_DATE <= P_PROC_DATE

              )

      UNION
      SELECT T.ROWID          RATE_ROW_ID,
             T.RATE_CODE      RATE_CODE,
             T.CCY            CCY,
             T.EFFECTIVE_DATE RT_EFF_DT,
             NULL             PREV_AMT,
             NULL             AMT_SLAB,
             NULL             TEN_FROM,
             NULL             TEN_TO,
             T.INT_RATE       RATE,
             NULL             CHG_STAT
        FROM CLTBS_ACCOUNT_TDUDE_RATE T
       WHERE T.BRANCH_CODE = P_BRANCH_CODE
         AND T.PROCESSED IN ('N', 'F')
         AND T.PROCESSING_DATE IS NULL
         AND T.EFFECTIVE_DATE IN
             (SELECT MAX(EFFECTIVE_DATE)
                FROM CLTBS_ACCOUNT_TDUDE_RATE
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
                 AND PROCESSED IN ('N', 'F')
                 AND PROCESSING_DATE IS NULL)
         AND T.CCY = L_ACC_CCY
         AND EXISTS
       (SELECT 1
                FROM CLTBS_REVISION_ACCOUNTS X
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND X.RATE_CODE = T.RATE_CODE
                 AND X.ACCOUNT_NUMBER = T.ACCOUNT_NUMBER
                 AND PROCESSED = 'N'
                 AND X.ACCOUNT_NUMBER =
                     NVL(P_ACCOUNT_NUMBER, X.ACCOUNT_NUMBER)
                 AND X.PROCESS_NO = NVL(P_PROCESS_NO, X.PROCESS_NO)
                 AND ROWNUM < 2)

       ORDER BY RATE_CODE, CCY, RT_EFF_DT, AMT_SLAB, TEN_FROM;

    TYPE TY_ACC_REVN_VALS IS TABLE OF REC_ALL_REVN INDEX BY VARCHAR2(50);

    L_CNT             NUMBER := 0;
    L_TB_ACC_REC      TY_TB_ACC_REC;
    L_TB_ACC_REC_TEMP TY_TB_ACC_REC;
    L_COMMIT_FREQ     NUMBER;
    L_INDEX           PLS_INTEGER;
    L_IDX             PLS_INTEGER;
    L_PREV_ACC_NO     CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE := '@#$';
    LACCOBJ           CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_CURRENCY        CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE;

    L_AMOUNT VARCHAR2(50);

    LTENOR                PLS_INTEGER;
    L_TB_ACC_ROW_ID       TY_TB_ACC_ROW_ID;
    L_TB_ACC_NOT_RSLV_RID TY_TB_ACC_ROW_ID;
    L_TB_AC_NO            DBMS_SQL.VARCHAR2S;
    L_TB_BK_VALUE         DBMS_SQL.DATE_TABLE;
    L_TB_ACT_CODE         DBMS_SQL.VARCHAR2S;

    L_TB_CALC_REQD DBMS_SQL.VARCHAR2S;
    L_INT_COUNT    NUMBER := 0;

    L_TB_PROCESSED_AC TY_PROCESSED_AC_ROWID;
    L_TB_ACC_UDE      TY_ACC_UDE;
    L_TAB_ACC_VALS    TY_ACC_UDE_VALS;

    L_AC_REC_REVN   TY_ACC_REVN;
    L_TAB_REVN_VALS TY_ACC_REVN_VALS;

    L_RT_CODE_IDX  VARCHAR2(50);
    L_RT_DT_IDX    PLS_INTEGER;
    L_TB_RATE_VALS TY_TB_RATE_VALS;
    L_TB_RATE_DET  TY_TB_RATE_DET;

    L_RT_AMT_IDX VARCHAR2(50);

    L_RT_TEN_IDX PLS_INTEGER;

    L_UDE_IDXS       VARCHAR2(100);
    L_COMPONENT_NAME CLTM_PRODUCT_COMP_FRM_ELEMS.COMPONENT_NAME%TYPE;

    L_ROW_ACC_COMPS CLTBS_ACCOUNT_COMPONENTS%ROWTYPE;
    L_ACCOUNT       CLTBS_ACCOUNT_MASTER%ROWTYPE;

    L_TB_UDE_VAL TY_TB_INS_UDE_VALS;

    L_TY_TB_EFF_DT TY_TB_ACC_EFF_DT;
    L_CNTR_D       PLS_INTEGER;

    L_UDE_VALUE CLTBS_ACCOUNT_UDE_VALUES.UDE_VALUE%TYPE;

    L_AMT VARCHAR2(50);

    L_RESLVD_VAL_CHGD BOOLEAN := FALSE;
    L_RESOLVED_VALUE  NUMBER;

    L_TNR        PLS_INTEGER;
    L_RATE       NUMBER;
    LRET         NUMBER;
    L_CODE_USAGE VARCHAR2(1);
    L_CNTR       PLS_INTEGER;
    L_NO_ERRORS  PLS_INTEGER;
    L_ERR_IDX    PLS_INTEGER;
    L_EFF_DT     DATE;
    L_NEXT_DT    DATE;
    L_EXIT       BOOLEAN;
    L_EXIT_IN    BOOLEAN;
    L_UDE_IDX    VARCHAR2(100);
    SKIP_CURRENT_SET EXCEPTION;
    L_BTAB       DBMS_SQL.VARCHAR2S;
    L_ATAB       DBMS_SQL.VARCHAR2S;
    L_REVN_IDX   VARCHAR2(50);
    L_EVENT_CODE CLTBS_ACCOUNT_EVENTS_DIARY.EVENT_CODE%TYPE;
    L_ROWID      ROWID;
    L_EXISTS     PLS_INTEGER := 0;

    L_TEMP_IDX PLS_INTEGER;

    L_COUNT NUMBER := 0;

    L_TB_DEL_ACC   DBMS_SQL.VARCHAR2S;
    L_TB_DEL_UDEID DBMS_SQL.VARCHAR2S;
    L_TB_DEL_EFFDT DBMS_SQL.DATE_TABLE;

    L_DUE_DT_INDX PLS_INTEGER;
    L_START_DT    DATE;

    L_CHAR_VAL VARCHAR2(50);
    L_DEC_PART VARCHAR2(50);

    L_AMOUNT_FORMATTED BOOLEAN;

    L_TB_PRODUCT_UDE CLTM_PRODUCT_UDE%ROWTYPE;

    COUNT1 NUMBER;

    L_TD_RATE      NUMBER;
    L_TD_EFF_DATE  DATE;
    L_BATCH_HAS_TD BOOLEAN := FALSE;
    L_ERRIDX       PLS_INTEGER;

    L_FINAL_RATE CLTBS_ACCOUNT_UDE_VALUES.RESOLVED_VALUE%TYPE;

    L_RATE_BASIS CLTBS_ACCOUNT_UDE_VALUES.RATE_BASIS%TYPE;
    L_FAIL       BOOLEAN := FALSE;
    L_ESN        NUMBER;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    L_INTERM_COUNT NUMBER := 0;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of FN_PROC_REVISION_FOR_BRANCH');
    G_TB_TEMP_ARVN_COMP.DELETE;
    L_COMMIT_FREQ := NVL(CLPKSS_BATCH.G_COMMIT_FREQ, 500);

    DEBUG.PR_DEBUG('CL', 'Deleted the Resolved records');

    IF CUR_RATE_DET%ISOPEN THEN
      CLOSE CUR_RATE_DET;
    END IF;

    DEBUG.PR_DEBUG('CL',
                   'bhanu for CTCB-15308 : l_tb_rate_det.COUNT = ' ||
                   L_TB_RATE_DET.COUNT);
    IF P_ACCOUNT_NUMBER IS NOT NULL THEN
      IF L_TB_RATE_DET.COUNT = 0 THEN
        IF CUR_RATE_DET_ACC%ISOPEN THEN
          CLOSE CUR_RATE_DET_ACC;
        END IF;
        L_AC_NO   := P_ACCOUNT_NUMBER;
        L_ACC_DET := CLPKSS_CACHE.FN_ACCOUNT_MASTER(L_AC_NO, P_BRANCH_CODE);
        DEBUG.PR_DEBUG('CL',
                       ' l_ac_no ' || L_AC_NO || ' l_acc_det.currency ' ||
                       L_ACC_DET.CURRENCY);
        OPEN CUR_RATE_DET_ACC(L_ACC_DET.CURRENCY);
        LOOP
          FETCH CUR_RATE_DET_ACC BULK COLLECT
            INTO L_TB_RATE_DET;
          EXIT WHEN CUR_RATE_DET_ACC%NOTFOUND;
        END LOOP;

      END IF;
    ELSE
      L_TB_RATE_DET.DELETE;

      OPEN CUR_RATE_DET;

      LOOP
        FETCH CUR_RATE_DET BULK COLLECT
          INTO L_TB_RATE_DET;
        EXIT WHEN CUR_RATE_DET%NOTFOUND;
      END LOOP;
    END IF;
    DEBUG.PR_DEBUG('CL', 'Fetched cursor.. cur_rate_det');

    IF NVL(L_TB_RATE_DET.COUNT, 0) > 0 THEN
      FOR L_IDX IN L_TB_RATE_DET.FIRST .. L_TB_RATE_DET.LAST LOOP
        DEBUG.PR_DEBUG('CL', '--populating the rate code table...');

        L_RT_CODE_IDX := L_TB_RATE_DET(L_IDX)
                         .RATE_CODE || L_TB_RATE_DET(L_IDX).CCY;

        DBG('Index for rate and ccy is ::' || L_RT_CODE_IDX);

        IF NOT L_TB_RATE_VALS.EXISTS(L_RT_CODE_IDX) THEN
          L_TB_RATE_VALS(L_RT_CODE_IDX).RATE_CODE := L_TB_RATE_DET(L_IDX)
                                                     .RATE_CODE;
          L_TB_RATE_VALS(L_RT_CODE_IDX).CCY := L_TB_RATE_DET(L_IDX).CCY;
        END IF;

        L_RT_DT_IDX := CLPKS_UTIL.FN_HASH_DATE(L_TB_RATE_DET(L_IDX)
                                               .RT_EFF_DT);

        DBG('Index for eff_dt is ::' || L_RT_DT_IDX);

        IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES.EXISTS(L_RT_DT_IDX) THEN
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).EFF_DATE := L_TB_RATE_DET(L_IDX)
                                                                          .RT_EFF_DT;
        END IF;

        L_CHAR_VAL := NVL(L_TB_RATE_DET(L_IDX).AMT_SLAB, 0);
        L_DEC_PART := NULL;
        IF INSTR(L_CHAR_VAL, '.') > 0 THEN
          L_DEC_PART := SUBSTR(L_CHAR_VAL,
                               INSTR(L_CHAR_VAL, '.') + 1,
                               LENGTH(L_CHAR_VAL));
          L_DEC_PART := RPAD(L_DEC_PART, 3, '0');
          L_CHAR_VAL := SUBSTR(L_CHAR_VAL, 1, INSTR(L_CHAR_VAL, '.') - 1);
          L_CHAR_VAL := L_CHAR_VAL || L_DEC_PART;
        ELSE
          L_CHAR_VAL := RPAD(L_CHAR_VAL, LENGTH(L_CHAR_VAL) + 3, '0');
        END IF;

        L_RT_AMT_IDX := LPAD(L_CHAR_VAL, 50, '0');

        DBG('Index for amt_slab is ::' || L_RT_AMT_IDX);

        IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
           .TB_AMT.EXISTS(L_RT_AMT_IDX) THEN
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX).PREV_AMT := L_TB_RATE_DET(L_IDX)
                                                                                               .PREV_AMT;
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX).AMT_SLAB := L_TB_RATE_DET(L_IDX)
                                                                                               .AMT_SLAB;
        END IF;

        L_RT_TEN_IDX := NVL(L_TB_RATE_DET(L_IDX).TEN_TO, 0);

        DBG('Index for tenor is ::' || L_RT_TEN_IDX);

        IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX)
           .TB_TENOR.EXISTS(L_RT_TEN_IDX) THEN
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX).TB_TENOR(L_RT_TEN_IDX).TEN_FROM := L_TB_RATE_DET(L_IDX)
                                                                                                                      .TEN_FROM;
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX).TB_TENOR(L_RT_TEN_IDX).TEN_TO := L_TB_RATE_DET(L_IDX)
                                                                                                                    .TEN_TO;
          L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_RT_AMT_IDX).TB_TENOR(L_RT_TEN_IDX).RATE := L_TB_RATE_DET(L_IDX).RATE;
        END IF;
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before cursor for maintained UDEs');

    LOOP
      FETCH CUR_ALL_REV_UDE BULK COLLECT
        INTO L_TB_ACC_UDE;
      EXIT WHEN CUR_ALL_REV_UDE%NOTFOUND;
    END LOOP;

    IF L_TB_ACC_UDE.COUNT > 0 THEN
      FOR L_IDX IN L_TB_ACC_UDE.FIRST .. L_TB_ACC_UDE.LAST LOOP

        L_UDE_IDX := L_TB_ACC_UDE(L_IDX)
                     .ACCOUNT_NUMBER || L_TB_ACC_UDE(L_IDX).UDE_ID ||
                      CLPKSS_UTIL.FN_HASH_DATE(L_TB_ACC_UDE(L_IDX)
                                               .EFFECTIVE_DATE);

        DEBUG.PR_DEBUG('CL', 'Ude idx here is ' || L_UDE_IDX);
        L_TAB_ACC_VALS(L_UDE_IDX).RATE_CODE := L_TB_ACC_UDE(L_IDX).RATE_CODE;
        L_TAB_ACC_VALS(L_UDE_IDX).ACCOUNT_NUMBER := L_TB_ACC_UDE(L_IDX)
                                                    .ACCOUNT_NUMBER;
        L_TAB_ACC_VALS(L_UDE_IDX).BRANCH_CODE := L_TB_ACC_UDE(L_IDX)
                                                 .BRANCH_CODE;
        L_TAB_ACC_VALS(L_UDE_IDX).EFFECTIVE_DATE := L_TB_ACC_UDE(L_IDX)
                                                    .EFFECTIVE_DATE;
        L_TAB_ACC_VALS(L_UDE_IDX).UDE_ID := L_TB_ACC_UDE(L_IDX).UDE_ID;
        L_TAB_ACC_VALS(L_UDE_IDX).UDE_VALUE := L_TB_ACC_UDE(L_IDX).UDE_VALUE;
        L_TAB_ACC_VALS(L_UDE_IDX).CODE_USAGE := L_TB_ACC_UDE(L_IDX)
                                                .CODE_USAGE;
        L_TAB_ACC_VALS(L_UDE_IDX).RATE_BASIS := L_TB_ACC_UDE(L_IDX)
                                                .RATE_BASIS;
      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before cursor for periodic revision');

    LOOP
      FETCH CUR_ALL_REVN BULK COLLECT
        INTO L_AC_REC_REVN;
      EXIT WHEN CUR_ALL_REVN%NOTFOUND;
    END LOOP;

    IF L_AC_REC_REVN.COUNT > 0 THEN
      FOR L_IDX IN L_AC_REC_REVN.FIRST .. L_AC_REC_REVN.LAST LOOP

        L_REVN_IDX := L_AC_REC_REVN(L_IDX)
                      .ACCOUNT_NUMBER ||
                       CLPKSS_UTIL.FN_HASH_DATE(L_AC_REC_REVN(L_IDX)
                                                .EXECUTION_DATE);

        L_TAB_REVN_VALS(L_REVN_IDX).ACCOUNT_NUMBER := L_AC_REC_REVN(L_IDX)
                                                      .ACCOUNT_NUMBER;
        L_TAB_REVN_VALS(L_REVN_IDX).BRANCH_CODE := L_AC_REC_REVN(L_IDX)
                                                   .BRANCH_CODE;
        L_TAB_REVN_VALS(L_REVN_IDX).EXECUTION_DATE := L_AC_REC_REVN(L_IDX)
                                                      .EXECUTION_DATE;

      END LOOP;
    END IF;

    DEBUG.PR_DEBUG('CL', 'before opening accounts cursor');

    L_TB_DEL_ACC.DELETE;
    L_TB_DEL_UDEID.DELETE;
    L_TB_DEL_EFFDT.DELETE;

    IF P_ACCOUNT_NUMBER IS NULL THEN

      SELECT ACCOUNT_NUMBER, UDE_ID, LEAST_EFFECTIVE_DATE
        BULK COLLECT
        INTO L_TB_DEL_ACC, L_TB_DEL_UDEID, L_TB_DEL_EFFDT
        FROM CLTBS_REVISION_ACCOUNTS
       WHERE BRANCH_CODE = P_BRANCH_CODE

         AND PROCESS_NO = P_PROCESS_NO

         AND NVL(PROCESSED, 'N') <> 'Y';

    ELSE

      SELECT ACCOUNT_NUMBER, UDE_ID, LEAST_EFFECTIVE_DATE
        BULK COLLECT
        INTO L_TB_DEL_ACC, L_TB_DEL_UDEID, L_TB_DEL_EFFDT
        FROM CLTBS_REVISION_ACCOUNTS
       WHERE BRANCH_CODE = P_BRANCH_CODE
         AND ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
         AND NVL(PROCESSED, 'N') <> 'Y';
    END IF;

    DEBUG.PR_DEBUG('CL',
                   '!!!!!!!!!Count of records is :' || L_TB_DEL_ACC.COUNT);

    L_TB_DEL_ACC.DELETE;
    L_TB_DEL_UDEID.DELETE;
    L_TB_DEL_EFFDT.DELETE;

    LOOP
      L_TB_ACC_REC.DELETE;

      L_TB_PROCESSED_AC.DELETE;
      L_ATAB.DELETE;
      L_BTAB.DELETE;
      L_TB_UDE_VAL.DELETE;
      L_TY_TB_EFF_DT.DELETE;
      L_TB_BK_VALUE.DELETE;
      L_TB_AC_NO.DELETE;
      L_TB_ACT_CODE.DELETE;
      L_TB_ACC_ROW_ID.DELETE;
      L_TB_ACC_NOT_RSLV_RID.DELETE;
      L_TB_CALC_REQD.DELETE;

      FETCH CUR_ALL_REV_ACC BULK COLLECT
        INTO L_TB_ACC_REC LIMIT L_COMMIT_FREQ;

      IF L_TB_ACC_REC_TEMP.COUNT > 0 THEN
        DBG('Inserting Acc ::' || L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST)
            .ACCOUNT_NUMBER || ' in the beginning');
        L_INDEX := L_TB_ACC_REC.FIRST;

        IF L_INDEX IS NOT NULL THEN
          L_TB_ACC_REC(L_INDEX - 1) := L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST);
        ELSE
          L_TB_ACC_REC(1) := L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST);
        END IF;

      END IF;

      BEGIN
        IF NVL(L_TB_ACC_REC.COUNT, 0) > 0 THEN
          L_INDEX := L_TB_ACC_REC.LAST;

          LOOP
            L_TB_ACC_REC_TEMP.DELETE;

            FETCH CUR_ALL_REV_ACC BULK COLLECT
              INTO L_TB_ACC_REC_TEMP LIMIT 1;

            EXIT WHEN(NVL(L_TB_ACC_REC_TEMP.COUNT, 0) = 0 OR L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST)
                      .ACCOUNT_NUMBER <> L_TB_ACC_REC(L_INDEX)
                      .ACCOUNT_NUMBER);

            L_INDEX := L_INDEX + 1;

            L_TB_ACC_REC(L_INDEX) := L_TB_ACC_REC_TEMP(L_TB_ACC_REC_TEMP.FIRST);
          END LOOP;
        END IF;

        DEBUG.PR_DEBUG('CL', 'after data fetch....');

        DEBUG.PR_DEBUG('CL',
                       '$$$$$$$$$$l_tb_acc_rec.COUNT ' ||
                       L_TB_ACC_REC.COUNT);

        DEBUG.PR_DEBUG('CL',
                       'Deleting records with maint rslv M - Such records also need to be modified');

        L_RESLVD_VAL_CHGD := FALSE;
        IF NVL(L_TB_ACC_REC.COUNT, 0) > 0 THEN
          FOR L_IDX IN L_TB_ACC_REC.FIRST .. L_TB_ACC_REC.LAST LOOP
            SAVEPOINT SP_REVN;
            DEBUG.PR_DEBUG('CL',
                           'Processing for....' || L_TB_ACC_REC(L_IDX)
                           .ACCOUNT_NUMBER || '~~' || L_TB_ACC_REC(L_IDX)
                           .UDE_ID);

            L_CODE_USAGE := L_TB_ACC_REC(L_IDX).CODE_USAGE;

            IF L_CODE_USAGE = 'A' THEN
              L_EVENT_CODE := 'ARVN';
            ELSE
              L_EVENT_CODE := 'REVN';
            END IF;

            DEBUG.PR_DEBUG('CL', 'Code usage is ' || L_CODE_USAGE);

            IF L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER <> L_PREV_ACC_NO THEN
              DEBUG.PR_DEBUG('CL', 'Inside here...');

              DBG('...fn_clear_acc_object...');

              CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
              CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_MASTER') := 1;

              CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_COMPONENTS') := 1;
              CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTBS_ACCOUNT_COMPONENTS') := 1;
              CLPKSS_CONTEXT.G_TB_BLOCK_NAME('CLTB_ACCOUNT_COMP_SCH') := 1;

              L_RESLVD_VAL_CHGD := FALSE;
              IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(LACCOBJ,
                                                       P_ERRORCODE,
                                                       P_ERRORPARAM) THEN
                DBG('Failed in call to clear obj ::' || P_ERRORCODE);

                CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                            .ACCOUNT_NUMBER,
                                            P_BRANCH_CODE,
                                            P_PROC_DATE,
                                            L_EVENT_CODE,
                                            'Failed in clearing acc obj:' ||
                                            P_ERRORCODE || ' - ' ||
                                            P_ERRORPARAM);

                L_FAIL := TRUE;
                ROLLBACK TO SP_REVN;

              END IF;

              DBG('...After fn_clear_acc_object...');

              IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                         .ACCOUNT_NUMBER,
                                                         P_BRANCH_CODE,
                                                         LACCOBJ,
                                                         P_ERRORCODE,
                                                         P_ERRORPARAM) THEN
                DBG('Failed in populating Account object for ARVN::' ||
                    P_ERRORCODE);

                CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                            .ACCOUNT_NUMBER,
                                            P_BRANCH_CODE,
                                            P_PROC_DATE,
                                            L_EVENT_CODE,
                                            'Failed in creating acc obj:' ||
                                            P_ERRORCODE || ' - ' ||
                                            P_ERRORPARAM);

                L_FAIL := TRUE;
                ROLLBACK TO SP_REVN;

              END IF;

              CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;
              L_CURRENCY := LACCOBJ.ACCOUNT_DET.CURRENCY;
              L_AMOUNT   := LACCOBJ.ACCOUNT_DET.AMOUNT_FINANCED;

              L_AMOUNT_FORMATTED := FALSE;

              IF NOT
                  CLPKSS_SDE.FN_GET_TENOR(P_BRANCH_CODE,
                                          L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER,
                                          LTENOR,
                                          P_ERRORCODE) THEN
                DBG('Failed in getting tenor from clpks_sde');

                CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                            .ACCOUNT_NUMBER,
                                            P_BRANCH_CODE,
                                            P_PROC_DATE,
                                            L_EVENT_CODE,
                                            'Failed calling clpkss_sde.fn_get_tenor:' ||
                                            P_ERRORCODE || ' - ' ||
                                            P_ERRORPARAM);

                L_FAIL := TRUE;
                ROLLBACK TO SP_REVN;

              END IF;

              DEBUG.PR_DEBUG('CL',
                             'Amount currency and tenor are' || L_AMOUNT || '~~' ||
                             L_CURRENCY || '~~' || LTENOR);

              IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                       L_EVENT_CODE) THEN

                CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;

                IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                           .ACCOUNT_NUMBER,
                                                           P_BRANCH_CODE,
                                                           LACCOBJ,
                                                           P_ERRORCODE,
                                                           P_ERRORPARAM) THEN
                  DBG('Failed in populating Account object for ARVN::' ||
                      P_ERRORCODE);

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                              .ACCOUNT_NUMBER,
                                              P_BRANCH_CODE,
                                              P_PROC_DATE,
                                              L_EVENT_CODE,
                                              'Failed in creating account obj:' ||
                                              P_ERRORCODE || ' - ' ||
                                              P_ERRORPARAM);

                  L_FAIL := TRUE;
                  ROLLBACK TO SP_REVN;

                END IF;

                LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                             L_EVENT_CODE,
                                                             'B',
                                                             LACCOBJ,
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM);

                DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                IF LRET = -1 THEN

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                              .ACCOUNT_NUMBER,
                                              P_BRANCH_CODE,
                                              P_PROC_DATE,
                                              L_EVENT_CODE,
                                              'Failed executing B policy :' ||
                                              P_ERRORCODE || ' - ' ||
                                              P_ERRORPARAM);

                  L_FAIL := TRUE;
                  ROLLBACK TO SP_REVN;

                END IF;
              END IF;

              DEBUG.PR_DEBUG('CL',
                             '$$$$$$$$$$$$$l_tb_acc_rec(l_idx).effective_date ' || L_TB_ACC_REC(L_IDX)
                             .EFFECTIVE_DATE);

            END IF;

            DEBUG.PR_DEBUG('CL',
                           'Now getting the rate for ' || L_RT_CODE_IDX ||
                           '~~~' || L_RT_DT_IDX);

            L_RT_CODE_IDX := L_TB_ACC_REC(L_IDX).RATE_CODE || L_CURRENCY;
            L_RATE        := 0;
            L_RT_DT_IDX   := CLPKS_UTIL.FN_HASH_DATE(L_TB_ACC_REC(L_IDX)
                                                     .EFFECTIVE_DATE);
            L_EFF_DT      := L_TB_ACC_REC(L_IDX).EFFECTIVE_DATE;

            IF L_CODE_USAGE = 'P' THEN
              L_REVN_IDX := L_TB_ACC_REC(L_IDX)
                            .ACCOUNT_NUMBER ||
                             CLPKSS_UTIL.FN_HASH_DATE(L_TB_ACC_REC(L_IDX)
                                                      .EFFECTIVE_DATE);
            END IF;

            L_EXIT := FALSE;

            IF L_TB_RATE_VALS.EXISTS(L_RT_CODE_IDX) THEN
              IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX)
                 .TB_RATES.EXISTS(L_RT_DT_IDX) THEN
                L_RT_DT_IDX := L_TB_RATE_VALS(L_RT_CODE_IDX)
                               .TB_RATES.PRIOR(L_RT_DT_IDX);
              END IF;
            ELSE
              L_EXIT := TRUE;
            END IF;

            DEBUG.PR_DEBUG('CL', 'After first rate index ' || L_RT_DT_IDX);

            WHILE NOT L_EXIT LOOP
              L_AMT  := NULL;
              L_TNR  := NULL;
              L_RATE := 0;

              L_FAIL := FALSE;

              IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX)
                 .TB_RATES.EXISTS(L_RT_DT_IDX) THEN
                DEBUG.PR_DEBUG('CL', 'Going to exit here');
                L_EXIT := TRUE;
              ELSE

                IF NOT L_AMOUNT_FORMATTED THEN
                  L_CHAR_VAL := NVL(L_AMOUNT, 0);
                  L_DEC_PART := NULL;
                  IF INSTR(L_CHAR_VAL, '.') > 0 THEN
                    L_DEC_PART := SUBSTR(L_CHAR_VAL,
                                         INSTR(L_CHAR_VAL, '.') + 1,
                                         LENGTH(L_CHAR_VAL));
                    L_DEC_PART := RPAD(L_DEC_PART, 3, '0');
                    L_CHAR_VAL := SUBSTR(L_CHAR_VAL,
                                         1,
                                         INSTR(L_CHAR_VAL, '.') - 1);
                    L_CHAR_VAL := L_CHAR_VAL || L_DEC_PART;
                  ELSE
                    IF LENGTH(L_CHAR_VAL) < 20 THEN
                      L_CHAR_VAL := RPAD(L_CHAR_VAL,
                                         LENGTH(L_CHAR_VAL) + 3,
                                         '0');
                    END IF;
                  END IF;

                  L_AMOUNT := LPAD(L_CHAR_VAL, 50, '0');

                  L_AMOUNT_FORMATTED := TRUE;
                END IF;

                IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
                   .TB_AMT.EXISTS(L_AMOUNT) THEN
                  DEBUG.PR_DEBUG('CL', 'checking for amount ' || L_AMOUNT);
                  L_AMT := L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
                           .TB_AMT.NEXT(L_AMOUNT);
                  DEBUG.PR_DEBUG('CL', 'Amount got is ' || L_AMT);
                ELSE
                  DEBUG.PR_DEBUG('CL', 'In else condition of amount');
                  L_AMT := L_AMOUNT;
                END IF;

                IF L_AMT IS NOT NULL THEN

                  IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_AMT)
                     .TB_TENOR.EXISTS(LTENOR) THEN
                    DEBUG.PR_DEBUG('CL', 'checking for  tenor ' || LTENOR);
                    L_TNR := L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_AMT)
                             .TB_TENOR.NEXT(LTENOR);
                    DEBUG.PR_DEBUG('CL', 'Tenor got is ' || L_TNR);
                  ELSE
                    DEBUG.PR_DEBUG('CL', 'In else condition of amount');
                    L_TNR := LTENOR;
                  END IF;

                  IF L_TNR IS NOT NULL THEN
                    L_RATE := L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX).TB_AMT(L_AMT).TB_TENOR(L_TNR).RATE;

                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CLUSTER,
                        CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_FN_CALL_ID := 1;
                      L_TB_CLUSTER_DATA('l_idx') := L_IDX;
                      L_TB_CLUSTER_DATA('l_rt_code_idx') := L_RT_CODE_IDX;
                      L_TB_CLUSTER_DATA('l_rt_dt_idx') := L_RT_DT_IDX;
                      L_TB_CLUSTER_DATA('l_amt') := L_AMT;
                      L_TB_CLUSTER_DATA('l_tnr') := L_TNR;
                      IF NOT
                          CLPKS_REVN_CLUSTER.FN_PROCESS_REVISION(LACCOBJ,
                                                                 L_TB_ACC_REC,
                                                                 L_RATE,
                                                                 L_EFF_DT,
                                                                 L_TB_ACC_UDE,
                                                                 L_TB_RATE_VALS,
                                                                 L_TAB_ACC_VALS,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA,
                                                                 P_ERRORCODE,
                                                                 P_ERRORPARAM) THEN
                        DBG('Failed in clpks_calc.Fn_Recalc_Components');
                        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                        RETURN FALSE;
                      END IF;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    END IF;
                    GLOBAL.PR_RESET_SKIP_KERNEL;

                    IF L_CODE_USAGE = 'A' THEN
                      L_EFF_DT := GREATEST(L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
                                           .EFF_DATE,
                                           L_TB_ACC_REC  (L_IDX)
                                           .EFFECTIVE_DATE);
                    END IF;
                  ELSE
                    DEBUG.PR_DEBUG('CL', 'No rates found..for tenor');
                  END IF;
                ELSE

                  DEBUG.PR_DEBUG('CL', 'No rates found..for amount');
                  DEBUG.PR_DEBUG('CL', 'For Td Rates it will come here');

                  L_EFF_DT := L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
                              .EFF_DATE;
                  DEBUG.PR_DEBUG('CL', 'l_eff_dt' || L_EFF_DT);
                  L_BATCH_HAS_TD := TRUE;
                  L_TD_RATE      := 0;
                  IF NOT FN_GET_TDRATE(L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER,
                                       L_TB_ACC_REC(L_IDX).BRANCH_CODE,
                                       L_TB_ACC_REC(L_IDX).RATE_CODE,
                                       L_EFF_DT,
                                       L_TD_RATE,
                                       P_ERRORCODE,
                                       P_ERRORPARAM) THEN

                    CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                                .ACCOUNT_NUMBER,
                                                P_BRANCH_CODE,
                                                P_PROC_DATE,
                                                L_EVENT_CODE,
                                                'Failed While Getting TD Rate :' ||
                                                P_ERRORCODE || ' - ' ||
                                                P_ERRORPARAM);
                    BEGIN
                      DEBUG.PR_DEBUG('CL',
                                     'Update to fail for acc' || L_TB_ACC_REC(L_IDX)
                                     .ACCOUNT_NUMBER || 'rate code' || L_TB_ACC_REC(L_IDX)
                                     .RATE_CODE);
                      UPDATE CLTBS_ACCOUNT_TDUDE_RATE
                         SET PROCESSED = 'F'
                       WHERE BRANCH_CODE = P_BRANCH_CODE
                         AND ACCOUNT_NUMBER = L_TB_ACC_REC(L_IDX)
                            .ACCOUNT_NUMBER
                         AND EFFECTIVE_DATE = L_EFF_DT
                         AND RATE_CODE = L_TB_ACC_REC(L_IDX).RATE_CODE;
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('Failed during Updation' || SQLERRM);
                    END;

                  END IF;

                  L_RATE := L_TD_RATE;

                END IF;

                DEBUG.PR_DEBUG('CL',
                               'After getting the rate' || L_RATE || '~~' ||
                               L_EFF_DT);

                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                  L_FN_CALL_ID := 1;
                  L_TB_CLUSTER_DATA('l_idx') := L_IDX;
                  IF NOT
                      CLPKS_REVN_CLUSTER.FN_PROCESS_REVISION(LACCOBJ,
                                                             L_TB_ACC_REC,
                                                             L_RATE,
                                                             L_EFF_DT,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA,
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM) THEN
                    DBG('Failed in clpks_calc.Fn_Recalc_Components');
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

                    L_FAIL := TRUE;
                    ROLLBACK TO SP_REVN;

                  END IF;
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                END IF;

                L_UDE_IDX := L_TB_ACC_REC(L_IDX)
                             .ACCOUNT_NUMBER || L_TB_ACC_REC(L_IDX).UDE_ID ||
                              CLPKSS_UTIL.FN_HASH_DATE(L_EFF_DT);

                DEBUG.PR_DEBUG('CL', 'Ude id is... ' || L_UDE_IDX);

                IF NOT L_TAB_ACC_VALS.EXISTS(L_UDE_IDX) THEN
                  L_UDE_IDX := L_TAB_ACC_VALS.PRIOR(L_UDE_IDX);
                END IF;

                L_UDE_VALUE  := L_TAB_ACC_VALS(L_UDE_IDX).UDE_VALUE;
                L_CODE_USAGE := L_TAB_ACC_VALS(L_UDE_IDX).CODE_USAGE;
                L_RATE_BASIS := L_TAB_ACC_VALS(L_UDE_IDX).RATE_BASIS;

                DBG('$$$$$$$$$$Outside ' || L_EFF_DT);

                IF NOT L_RESLVD_VAL_CHGD THEN

                  BEGIN
                    SELECT /*+ index_desc ( t pk_cl_acnt_ude_vals) */
                     T.RESOLVED_VALUE
                      INTO L_RESOLVED_VALUE
                      FROM CLTBS_ACCOUNT_UDE_VALUES T
                     WHERE T.ACCOUNT_NUMBER =
                           LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER
                       AND T.BRANCH_CODE = LACCOBJ.ACCOUNT_DET.BRANCH_CODE
                       AND T.UDE_ID = L_TB_ACC_REC(L_IDX).UDE_ID
                       AND EFFECTIVE_DATE <= L_EFF_DT
                       AND ROWNUM < 2;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      L_RESOLVED_VALUE := 0;
                  END;

                  DBG('$$$$$$$$$$l_resolved_value ' || L_RESOLVED_VALUE);

                  IF L_TD_RATE = 0 AND L_BATCH_HAS_TD THEN
                    L_RESLVD_VAL_CHGD := FALSE;

                  ELSIF NVL(L_RATE, 0) + NVL(L_UDE_VALUE, 0) <>
                        L_RESOLVED_VALUE AND
                        L_EFF_DT < LACCOBJ.ACCOUNT_DET.MATURITY_DATE THEN
                    L_RESLVD_VAL_CHGD := TRUE;

                    L_INT_COUNT := 0;
                    BEGIN
                      SELECT 1
                        INTO L_INT_COUNT
                        FROM CLTM_PRODUCT_COMPONENTS
                       WHERE PRODUCT_CODE =
                             LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                         AND COMPONENT_NAME IN
                             (SELECT COMPONENT_NAME
                                FROM CLTM_PRODUCT_COMP_FRM_ELEMS
                               WHERE PRODUCT_CODE =
                                     LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                                 AND ELEM_TYPE = 'U'
                                 AND ELEM_ID = L_TB_ACC_REC(L_IDX).UDE_ID)
                         AND COMPONENT_TYPE = 'I'
                         AND ROWNUM < 2;
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_INT_COUNT := 0;
                    END;

                    IF NVL(L_RATE, 0) + NVL(L_UDE_VALUE, 0) < 0 THEN

                      DBG('l_tb_acc_rec(l_idx).ude_id: ' || L_TB_ACC_REC(L_IDX)
                          .UDE_ID);
                      BEGIN
                        SELECT 1
                          INTO L_CNT
                          FROM CLTM_PRODUCT_COMPONENTS     PC,
                               CLTM_PRODUCT_COMP_FRM_ELEMS FE
                         WHERE PC.PRODUCT_CODE = FE.PRODUCT_CODE
                           AND PC.COMPONENT_NAME = FE.COMPONENT_NAME
                           AND PC.COMPONENT_TYPE = 'I'
                           AND PC.MAIN_COMPONENT = 'Y'
                           AND PC.NEGATIVE_INT_ALLOWED = 'Y'
                           AND FE.PRODUCT_CODE =
                               LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                           AND FE.COMPONENT_NAME = CLPKS_NLS.MAIN_INT
                           AND FE.ELEM_TYPE = 'U'
                           AND FE.ELEM_ID = L_TB_ACC_REC(L_IDX).UDE_ID
                           AND ROWNUM = 1;
                      EXCEPTION
                        WHEN OTHERS THEN
                          L_CNT := 0;
                          DBG('not a neg int comp');
                      END;
                      IF L_CNT > 0 THEN
                        L_RESLVD_VAL_CHGD := TRUE;
                        DBG('Negative ude_val allowed since this is a Interest Main component and has Negative Interest Allowed');
                      ELSE

                        L_RESLVD_VAL_CHGD := FALSE;
                        CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                                    .ACCOUNT_NUMBER,
                                                    P_BRANCH_CODE,
                                                    P_PROC_DATE,
                                                    L_EVENT_CODE,
                                                    'Resolve value is negetive, so assigned with old value');

                        L_FAIL := TRUE;
                        ROLLBACK TO SP_REVN;

                      END IF;
                    ELSE

                      DEBUG.PR_DEBUG('CL', 'resolved value not changed');
                      L_RESLVD_VAL_CHGD := TRUE;
                    END IF;

                    L_INT_COUNT := 0;
                    BEGIN
                      SELECT 1
                        INTO L_INT_COUNT
                        FROM CLTM_PRODUCT_COMPONENTS
                       WHERE PRODUCT_CODE =
                             LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                         AND COMPONENT_NAME IN
                             (SELECT COMPONENT_NAME
                                FROM CLTM_PRODUCT_COMP_FRM_ELEMS
                               WHERE PRODUCT_CODE =
                                     LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                                 AND ELEM_TYPE = 'U'
                                 AND ELEM_ID = L_TB_ACC_REC(L_IDX).UDE_ID)
                         AND COMPONENT_TYPE = 'I'
                         AND ROWNUM < 2;
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_INT_COUNT := 0;
                    END;

                  END IF;
                END IF;

                L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;

                DEBUG.PR_DEBUG('CL', 'Here to populate for ' || L_EFF_DT);

                L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TB_ACC_REC(L_IDX)
                                                       .ACCOUNT_NUMBER;
                L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TB_ACC_REC(L_IDX)
                                                    .BRANCH_CODE;
                L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_EFF_DT;
                L_TB_UDE_VAL(L_CNTR).UDE_ID := L_TB_ACC_REC(L_IDX).UDE_ID;
                L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_UDE_VALUE;
                L_TB_UDE_VAL(L_CNTR).RATE_CODE := L_TB_ACC_REC(L_IDX)
                                                  .RATE_CODE;
                L_TB_UDE_VAL(L_CNTR).CODE_USAGE := L_CODE_USAGE;
                L_TB_UDE_VAL(L_CNTR).RATE_BASIS := L_RATE_BASIS;
                L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'R';
                L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE, 0) +
                                                       NVL(L_UDE_VALUE, 0);

                L_CNTR_D := NVL(L_TY_TB_EFF_DT.COUNT, 0) + 1;
                L_TY_TB_EFF_DT(L_CNTR_D).ACCOUNT_NUMBER := L_TB_ACC_REC(L_IDX)
                                                           .ACCOUNT_NUMBER;
                L_TY_TB_EFF_DT(L_CNTR_D).BRANCH_CODE := L_TB_ACC_REC(L_IDX)
                                                        .BRANCH_CODE;
                L_TY_TB_EFF_DT(L_CNTR_D).EFFECTIVE_DATE := L_EFF_DT;

                L_TB_UDE_VAL(L_CNTR).MAINT_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                    .RESOLVED_VALUE;
                IF NOT CLPKSS_UDE.FN_GET_EXPONENTIAL_RATE(LACCOBJ,
                                                          L_TB_ACC_REC(L_IDX)
                                                          .RATE_CODE,
                                                          L_TB_UDE_VAL(L_CNTR)
                                                          .RESOLVED_VALUE,
                                                          L_FINAL_RATE,
                                                          L_TB_ACC_REC(L_IDX)
                                                          .UDE_ID,

                                                          L_EFF_DT,

                                                          'R',
                                                          P_ERRORCODE,
                                                          P_ERRORPARAM) THEN
                  DBG('Failed in gettimng the final Rate after LRR/ERR computation');
                  CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                               .ACCOUNT_NUMBER,
                                               P_BRANCH_CODE,
                                               P_PROC_DATE,
                                               L_EVENT_CODE,
                                               'Failed in deriving exponential rate for UDE - ' || L_TB_ACC_REC(L_IDX)
                                               .UDE_ID || ' : ' ||
                                                P_ERRORCODE || ' - ' ||
                                                P_ERRORPARAM);
                  L_FAIL := TRUE;
                  ROLLBACK TO SP_REVN;
                END IF;
                DEBUG.PR_DEBUG('CL', 'Final Rate is :' || L_FINAL_RATE);

                L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := L_FINAL_RATE;

                L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                                L_TB_ACC_REC(L_IDX)
                                                                .UDE_ID);
                IF (L_TB_PRODUCT_UDE.UDE_ID = L_TB_UDE_VAL(L_CNTR).UDE_ID) THEN
                  IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
                     NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
                     NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) > 0 THEN
                    IF (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) <
                       NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
                       (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) >
                       NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
                      DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');

                      L_FAIL := TRUE;
                      ROLLBACK TO SP_REVN;

                    END IF;
                  END IF;
                END IF;

                BEGIN
                  SELECT COUNT(1)
                    INTO L_INTERM_COUNT
                    FROM CLTM_PRODUCT_COMP_FRM_ELEMS FRMELEM,
                         CLTM_PRODUCT_COMP_FRM       FRM
                   WHERE FRMELEM.PRODUCT_CODE = FRM.PRODUCT_CODE
                     AND FRMELEM.COMPONENT_NAME = FRM.COMPONENT_NAME
                     AND FRMELEM.FORMULA_NAME = FRM.FORMULA_NAME
                     AND FRMELEM.ELEM_ID = L_TB_ACC_REC(L_IDX).UDE_ID
                     AND FRMELEM.ELEM_TYPE = 'U'
                     AND FRMELEM.PRODUCT_CODE =
                         LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                     AND NOT (FRM.BOOK_FLAG = 'Y' OR
                          (NVL(FRM.DFLT_MORATORIUM_FRM, 'N') = 'Y' OR
                          NVL(MORA_LIQ_FRM, 0) = 'Y'));
                EXCEPTION
                  WHEN OTHERS THEN
                    L_INTERM_COUNT := 0;
                END;
                IF L_INTERM_COUNT > 0 THEN
                  DBG('Going to insert record for Z_INTRMDT_RATE');
                  DBG('EFFECTIVE_DATE :- ' ||
                      CLPKS_UTIL.FN_HASH_DATE(L_EFF_DT));
                  L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;
                  L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TB_ACC_REC(L_IDX)
                                                         .ACCOUNT_NUMBER;
                  L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TB_ACC_REC(L_IDX)
                                                      .BRANCH_CODE;
                  L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_EFF_DT;
                  L_TB_UDE_VAL(L_CNTR).UDE_ID := 'Z_INTRMDT_RATE';

                  L_TB_UDE_VAL(L_CNTR).RATE_CODE := NULL;
                  L_TB_UDE_VAL(L_CNTR).CODE_USAGE := NULL;
                  L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'M';
                  L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE, 0) +
                                                         NVL(L_UDE_VALUE, 0);
                  L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                    .RESOLVED_VALUE;

                  L_TB_UDE_VAL(L_CNTR).MAINT_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                      .RESOLVED_VALUE;
                  L_TB_UDE_VAL(L_CNTR).RATE_BASIS := 'N';
                  DEBUG.PR_DEBUG('CL', 'Final Rate is ##:' || L_FINAL_RATE);
                  L_RESLVD_VAL_CHGD := TRUE;

                END IF;

                IF L_CODE_USAGE = 'A' THEN
                  DEBUG.PR_DEBUG('CL',
                                 '$$$$$$$$$$l_rt_code_idx ' ||
                                 L_RT_CODE_IDX);

                  L_RT_DT_IDX := L_TB_RATE_VALS(L_RT_CODE_IDX)
                                 .TB_RATES.NEXT(L_RT_DT_IDX);

                  DEBUG.PR_DEBUG('CL',
                                 '$$$$$$$$$$l_rt_dt_idx ' || L_RT_DT_IDX);

                  IF L_RT_DT_IDX IS NOT NULL THEN
                    L_NEXT_DT := L_TB_RATE_VALS(L_RT_CODE_IDX).TB_RATES(L_RT_DT_IDX)
                                 .EFF_DATE;
                  END IF;

                  DEBUG.PR_DEBUG('CL', '$$$$$$$$$$l_next_dt ' || L_NEXT_DT);

                ELSE
                  L_REVN_IDX := L_TAB_REVN_VALS.NEXT(L_REVN_IDX);

                  IF L_REVN_IDX IS NOT NULL THEN
                    IF L_TAB_REVN_VALS(L_REVN_IDX)
                     .ACCOUNT_NUMBER = L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER THEN
                      L_RT_DT_IDX := CLPKS_UTIL.FN_HASH_DATE(L_TAB_REVN_VALS(L_REVN_IDX)
                                                             .EXECUTION_DATE);
                      L_EFF_DT    := L_TAB_REVN_VALS(L_REVN_IDX)
                                     .EXECUTION_DATE;

                      L_NEXT_DT := L_TAB_REVN_VALS(L_REVN_IDX)
                                   .EXECUTION_DATE;

                      IF NOT L_TB_RATE_VALS(L_RT_CODE_IDX)
                         .TB_RATES.EXISTS(L_RT_DT_IDX) THEN
                        L_RT_DT_IDX := L_TB_RATE_VALS(L_RT_CODE_IDX)
                                       .TB_RATES.PRIOR(L_RT_DT_IDX);
                      END IF;
                    ELSE

                      L_EXIT := TRUE;
                    END IF;
                  ELSE
                    L_EXIT := TRUE;
                  END IF;
                END IF;

                IF L_RT_DT_IDX IS NOT NULL AND L_FAIL THEN
                  L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := NULL;
                  L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := NULL;
                  L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := NULL;
                END IF;

                IF L_RT_DT_IDX IS NULL THEN

                  L_EXIT_IN := FALSE;
                  WHILE NOT L_EXIT_IN LOOP
                    L_CNTR    := L_TB_UDE_VAL.COUNT;
                    L_UDE_IDX := L_TB_UDE_VAL(L_CNTR)
                                 .ACCOUNT_NUMBER || L_TB_UDE_VAL(L_CNTR)
                                 .UDE_ID ||
                                  CLPKSS_UTIL.FN_HASH_DATE(L_TB_UDE_VAL(L_CNTR)
                                                           .EFFECTIVE_DATE);
                    L_UDE_IDX := L_TAB_ACC_VALS.NEXT(L_UDE_IDX);

                    IF L_FAIL THEN
                      L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := NULL;
                      L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := NULL;
                      L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := NULL;
                    END IF;

                    IF L_UDE_IDX IS NOT NULL AND L_TAB_ACC_VALS(L_UDE_IDX)
                      .ACCOUNT_NUMBER = L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER AND L_TAB_ACC_VALS(L_UDE_IDX)
                      .UDE_ID = L_TB_UDE_VAL(L_CNTR).UDE_ID AND
                       NVL(L_TAB_ACC_VALS(L_UDE_IDX).RATE_CODE, '@@@@') =
                       NVL(L_TB_UDE_VAL(L_CNTR).RATE_CODE, '####') THEN
                      L_CNTR := L_TB_UDE_VAL.COUNT + 1;
                      L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TAB_ACC_VALS(L_UDE_IDX)
                                                             .ACCOUNT_NUMBER;
                      L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                          .BRANCH_CODE;
                      L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                             .EFFECTIVE_DATE;
                      L_TB_UDE_VAL(L_CNTR).UDE_ID := L_TAB_ACC_VALS(L_UDE_IDX)
                                                     .UDE_ID;
                      L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                        .UDE_VALUE;
                      L_TB_UDE_VAL(L_CNTR).RATE_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                        .RATE_CODE;
                      L_TB_UDE_VAL(L_CNTR).CODE_USAGE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                         .CODE_USAGE;
                      L_TB_UDE_VAL(L_CNTR).RATE_BASIS := L_TAB_ACC_VALS(L_UDE_IDX)
                                                         .RATE_BASIS;
                      L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := NULL;
                      L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE, 0) +
                                                             NVL(L_TAB_ACC_VALS(L_UDE_IDX)
                                                                 .UDE_VALUE,
                                                                 0);

                      L_TB_UDE_VAL(L_CNTR).MAINT_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                          .RESOLVED_VALUE;
                      IF NOT
                          CLPKSS_UDE.FN_GET_EXPONENTIAL_RATE(LACCOBJ,
                                                             L_TB_ACC_REC(L_IDX)
                                                             .RATE_CODE,
                                                             L_TB_UDE_VAL(L_CNTR)
                                                             .RESOLVED_VALUE,
                                                             L_FINAL_RATE,
                                                             L_TB_UDE_VAL(L_CNTR)
                                                             .UDE_ID,

                                                             L_TB_ACC_REC(L_IDX)
                                                             .EFFECTIVE_DATE,
                                                             'R',
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM) THEN
                        DBG('Failed in gettimng the final Rate after LRR/ERR computation');
                        CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                                     .ACCOUNT_NUMBER,
                                                     P_BRANCH_CODE,
                                                     P_PROC_DATE,
                                                     L_EVENT_CODE,
                                                     'Failed in deriving exponential rate for UDE - ' || L_TB_UDE_VAL(L_CNTR)
                                                     .UDE_ID || ' : ' ||
                                                      P_ERRORCODE || ' - ' ||
                                                      P_ERRORPARAM);
                        L_FAIL := TRUE;
                        ROLLBACK TO SP_REVN;
                      END IF;
                      DBG('Final Rate is :' || L_FINAL_RATE);

                      L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := L_FINAL_RATE;

                      L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                                      L_TB_ACC_REC(L_IDX)
                                                                      .UDE_ID);
                      IF (L_TB_PRODUCT_UDE.UDE_ID = L_TB_UDE_VAL(L_CNTR)
                         .UDE_ID) THEN
                        IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
                           NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
                           NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) > 0 THEN
                          IF (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) <
                             NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
                             (NVL(L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE, 0) >
                             NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
                            DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');

                            L_FAIL := TRUE;
                            ROLLBACK TO SP_REVN;

                          END IF;
                        END IF;
                      END IF;

                      BEGIN
                        SELECT COUNT(1)
                          INTO L_INTERM_COUNT
                          FROM CLTM_PRODUCT_COMP_FRM_ELEMS FRMELEM,
                               CLTM_PRODUCT_COMP_FRM       FRM
                         WHERE FRMELEM.PRODUCT_CODE = FRM.PRODUCT_CODE
                           AND FRMELEM.COMPONENT_NAME = FRM.COMPONENT_NAME
                           AND FRMELEM.FORMULA_NAME = FRM.FORMULA_NAME
                           AND FRMELEM.ELEM_ID = L_TAB_ACC_VALS(L_UDE_IDX)
                              .UDE_ID
                           AND FRMELEM.ELEM_TYPE = 'U'
                           AND FRMELEM.PRODUCT_CODE =
                               LACCOBJ.ACCOUNT_DET.PRODUCT_CODE
                           AND NOT (FRM.BOOK_FLAG = 'Y' OR
                                (NVL(FRM.DFLT_MORATORIUM_FRM, 'N') = 'Y' OR
                                NVL(MORA_LIQ_FRM, 0) = 'Y'));
                      EXCEPTION
                        WHEN OTHERS THEN
                          L_INTERM_COUNT := 0;
                      END;
                      IF L_INTERM_COUNT > 0 THEN
                        DBG('Going to insert record for Z_INTRMDT_RATE');
                        DBG('EFFECTIVE_DATE :- ' ||
                            CLPKS_UTIL.FN_HASH_DATE(L_TAB_ACC_VALS(L_UDE_IDX)
                                                    .EFFECTIVE_DATE));
                        L_CNTR := NVL(L_TB_UDE_VAL.COUNT, 0) + 1;
                        L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := L_TAB_ACC_VALS(L_UDE_IDX)
                                                               .ACCOUNT_NUMBER;
                        L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                            .BRANCH_CODE;
                        L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := L_TAB_ACC_VALS(L_UDE_IDX)
                                                               .EFFECTIVE_DATE;
                        L_TB_UDE_VAL(L_CNTR).UDE_ID := 'Z_INTRMDT_RATE';

                        L_TB_UDE_VAL(L_CNTR).RATE_CODE := NULL;
                        L_TB_UDE_VAL(L_CNTR).CODE_USAGE := NULL;
                        L_TB_UDE_VAL(L_CNTR).MAINT_RSLV_FLAG := 'M';
                        L_TB_UDE_VAL(L_CNTR).RESOLVED_VALUE := NVL(L_RATE,
                                                                   0) +
                                                               NVL(L_TAB_ACC_VALS(L_UDE_IDX)
                                                                   .UDE_VALUE,
                                                                   0);
                        L_TB_UDE_VAL(L_CNTR).UDE_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                          .RESOLVED_VALUE;

                        L_TB_UDE_VAL(L_CNTR).MAINT_VALUE := L_TB_UDE_VAL(L_CNTR)
                                                            .RESOLVED_VALUE;
                        L_TB_UDE_VAL(L_CNTR).RATE_BASIS := 'N';
                        DEBUG.PR_DEBUG('CL',
                                       'Final Rate is ##:' || L_FINAL_RATE);
                        L_RESLVD_VAL_CHGD := TRUE;

                      END IF;

                    ELSE
                      L_EXIT_IN := TRUE;
                    END IF;
                  END LOOP;

                  L_EXIT := TRUE;
                END IF;

                DEBUG.PR_DEBUG('CL', '$$$$$$$$$$$l_idx ' || L_IDX);

                L_TEMP_IDX := L_TB_ACC_REC.FIRST;

              END IF;
            END LOOP;

            DEBUG.PR_DEBUG('CL', 'Out of the rates loop');

            IF L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER <> L_PREV_ACC_NO THEN
              IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                       L_EVENT_CODE) THEN
                DBG('Calling clpks_pol_wrapper with product::' ||
                    LACCOBJ.ACCOUNT_DET.PRODUCT_CODE ||
                    ' ,event ARVN and execution_type A');

                IF LACCOBJ.G_TB_COMPONENTS.COUNT = 0 THEN
                  CLPKSS_CONTEXT.G_TB_BLOCK_NAME.DELETE;

                  IF NOT
                      CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_REC(L_IDX)
                                                          .ACCOUNT_NUMBER,
                                                          P_BRANCH_CODE,
                                                          LACCOBJ,
                                                          P_ERRORCODE,
                                                          P_ERRORPARAM) THEN
                    DBG('Failed in populating Account object for ARVN::' ||
                        P_ERRORCODE);

                    CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                                .ACCOUNT_NUMBER,
                                                P_BRANCH_CODE,
                                                P_PROC_DATE,
                                                L_EVENT_CODE,
                                                'Failed in creating acc object:' ||
                                                P_ERRORCODE || ' - ' ||
                                                P_ERRORPARAM);

                    L_FAIL := TRUE;
                    ROLLBACK TO SP_REVN;

                  END IF;

                END IF;

                LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LACCOBJ.ACCOUNT_DET.PRODUCT_CODE,
                                                             L_EVENT_CODE,
                                                             'A',
                                                             LACCOBJ,
                                                             P_ERRORCODE,
                                                             P_ERRORPARAM);

                DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                IF LRET = -1 THEN

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_TB_ACC_REC(L_IDX)
                                              .ACCOUNT_NUMBER,
                                              P_BRANCH_CODE,
                                              P_PROC_DATE,
                                              L_EVENT_CODE,
                                              'Failed executing A policy :' ||
                                              P_ERRORCODE || ' - ' ||
                                              P_ERRORPARAM);

                  L_FAIL := TRUE;
                  ROLLBACK TO SP_REVN;

                END IF;
              END IF;
            END IF;

            L_TB_PROCESSED_AC(NVL(L_TB_PROCESSED_AC.COUNT, 0) + 1) := L_TB_ACC_REC(L_IDX)
                                                                      .P_ROWID;

            L_PREV_ACC_NO := L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER;

            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID := 1;
              L_TB_CLUSTER_DATA('l_idx') := L_IDX;
              L_TB_CLUSTER_DATA('p_branch_code') := P_BRANCH_CODE;
              L_TB_CLUSTER_DATA('l_cntr') := L_CNTR;
              IF NOT CLPKS_REVN_CLUSTER.FN_PROCESS_REVISION(LACCOBJ,
                                                            L_TB_ACC_REC,
                                                            L_RATE,
                                                            L_EFF_DT,
                                                            L_TB_UDE_VAL,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERRORCODE,
                                                            P_ERRORPARAM) THEN
                DEBUG.PR_DEBUG('CL',
                               'Failed in clpks_revn_cluster.fn_process_revision');
                L_FAIL := TRUE;
                ROLLBACK TO SP_REVN;
              END IF;
            END IF;

            DBG('before l_tb_acc_rec.count >>>>>>::' || L_TB_ACC_REC.COUNT);
            IF L_IDX =
               L_TB_ACC_REC.LAST OR L_TB_ACC_REC(L_IDX + 1).ACCOUNT_NUMBER <>
               L_PREV_ACC_NO THEN
              DBG('after l_tb_acc_rec.count >>>>>>::' ||
                  L_TB_ACC_REC.COUNT);
              IF NOT L_FAIL THEN
                IF L_RESLVD_VAL_CHGD THEN
                  L_TB_ACC_ROW_ID(NVL(L_TB_ACC_ROW_ID.COUNT, 0) + 1) := LACCOBJ.G_RECORD_ROWID;

                  DBG('l_int_count' || L_INT_COUNT);
                  DBG('laccobj.account_det.MATURITY_DATE' ||
                      LACCOBJ.ACCOUNT_DET.MATURITY_DATE);
                  DBG('p_proc_date' || P_PROC_DATE);

                  IF P_PROC_DATE < LACCOBJ.ACCOUNT_DET.MATURITY_DATE THEN
                    DBG('Setting calc reqd = Y');
                    L_TB_CALC_REQD(NVL(L_TB_CALC_REQD.COUNT, 0) + 1) := 'Y';
                    L_TB_ACT_CODE(NVL(L_TB_ACT_CODE.COUNT, 0) + 1) := NVL(LACCOBJ.ACCOUNT_DET.RATE_CHG_ACTION,
                                                                          'E');
                    L_TB_AC_NO(NVL(L_TB_AC_NO.COUNT, 0) + 1) := L_PREV_ACC_NO;
                    L_TB_BK_VALUE(NVL(L_TB_BK_VALUE.COUNT, 0) + 1) := P_PROC_DATE;
                  ELSE
                    DBG('Setting calc reqd = N');
                    L_TB_CALC_REQD(NVL(L_TB_CALC_REQD.COUNT, 0) + 1) := 'N';
                    L_TB_ACT_CODE(NVL(L_TB_ACT_CODE.COUNT, 0) + 1) := LACCOBJ.ACCOUNT_DET.RATE_CHG_ACTION;
                  END IF;

                  IF NVL(CLPKSS_CACHE.FN_PRODUCT_COMPONENTS(CLPKSS_CACHE.FN_ACCOUNT_MASTER(L_TB_ACC_REC(L_IDX).ACCOUNT_NUMBER, L_TB_ACC_REC(L_IDX).BRANCH_CODE).PRODUCT_CODE, CLPKSS_NLS.MAIN_INT)
                         .FORMULA_TYPE,
                         '#') IN ('3', '4', '12') THEN
                    L_TB_ACT_CODE(L_TB_ACT_CODE.COUNT + 1) := 'A';
                  ELSE
                    L_TB_ACT_CODE(NVL(L_TB_ACT_CODE.COUNT, 0) + 1) := NVL(LACCOBJ.ACCOUNT_DET.RATE_CHG_ACTION,
                                                                          'E');
                  END IF;

                  L_RESLVD_VAL_CHGD := FALSE;

                  DEBUG.PR_DEBUG('CL',
                                 '$$$$$$$$$$$$$UDE VALUES HAVE CHANGED FOR ' ||
                                 LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER || '~' ||
                                 P_PROC_DATE);
                ELSE
                  DEBUG.PR_DEBUG('CL',
                                 '$$$$$$$$$$$$$UDE VALUES HAVE NOT CHANGED FOR ' ||
                                 LACCOBJ.ACCOUNT_DET.ACCOUNT_NUMBER || '~' ||
                                 P_PROC_DATE);
                  L_TB_ACC_NOT_RSLV_RID(NVL(L_TB_ACC_NOT_RSLV_RID.COUNT, 0) + 1) := LACCOBJ.G_RECORD_ROWID;
                END IF;

              ELSE
                DBG('LACCOBJ.ACCOUNT_DET.LATEST_ESN_NO' ||
                    LACCOBJ.ACCOUNT_DET.LATEST_ESN);
                L_ESN := LACCOBJ.ACCOUNT_DET.LATEST_ESN + 1;

                DELETE FROM CLTB_ACCOUNT_EVENTS_DIARY
                 WHERE BRANCH_CODE = L_TB_UDE_VAL(L_CNTR).BRANCH_CODE
                   AND ACCOUNT_NUMBER = L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER
                   AND EVENT_CODE IN ('ARVN', 'REVN')
                   AND EXECUTION_DATE = L_EFF_DT
                   AND EVENT_SEQ_NO = L_ESN;

                DELETE FROM CLTB_ACCOUNT_EVENTS_ADVICES X
                 WHERE BRANCH_CODE = L_TB_UDE_VAL(L_CNTR).BRANCH_CODE
                   AND ACCOUNT_NUMBER = L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER
                   AND EVENT_CODE IN ('ARVN', 'REVN')
                   AND X.EVENT_SEQ_NO = L_ESN;

                L_TB_UDE_VAL(L_CNTR).ACCOUNT_NUMBER := NULL;
                L_TB_UDE_VAL(L_CNTR).BRANCH_CODE := NULL;
                L_TB_UDE_VAL(L_CNTR).EFFECTIVE_DATE := NULL;
              END IF;
              L_FAIL := FALSE;

              L_RESLVD_VAL_CHGD := FALSE;
            END IF;

            L_INT_COUNT := 0;
          END LOOP;

          DEBUG.PR_DEBUG('CL', 'Out of the accounts loop');

          DEBUG.PR_DEBUG('CL',
                         'l_tb_acc_row_id.count ' || L_TB_ACC_ROW_ID.COUNT);

          IF L_TB_ACC_ROW_ID.COUNT > 0 THEN
            BEGIN
              FORALL I IN L_TB_ACC_ROW_ID.FIRST .. L_TB_ACC_ROW_ID.LAST SAVE
                                                   EXCEPTIONS
                UPDATE CLTBS_ACCOUNT_MASTER
                   SET CALC_REQD = L_TB_CALC_REQD(I),

                       RECALC_ACTION_CODE = L_TB_ACT_CODE(I),

                       LATEST_ESN = LATEST_ESN + 1
                 WHERE ROWID = L_TB_ACC_ROW_ID(I);

              DEBUG.PR_DEBUG('CL', 'Updated cltbs_account_ude_values');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_ACCOUNT_UDE_VALUES');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION(

                                               L_TB_ACC_ROW_ID(L_ERR_IDX),

                                               P_BRANCH_CODE,

                                               P_PROC_DATE,
                                               L_EVENT_CODE,

                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;
          END IF;

          IF L_TB_ACC_NOT_RSLV_RID.COUNT > 0 THEN
            BEGIN
              FORALL I IN L_TB_ACC_NOT_RSLV_RID.FIRST .. L_TB_ACC_NOT_RSLV_RID.LAST SAVE
                                                         EXCEPTIONS
                UPDATE CLTBS_ACCOUNT_MASTER
                   SET LATEST_ESN = LATEST_ESN + 1
                 WHERE ROWID = L_TB_ACC_NOT_RSLV_RID(I);

              DEBUG.PR_DEBUG('CL',
                             'Updated cltbs_account_ude_values for accounts not resolved');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_ACCOUNT_UDE_VALUES');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'ARVN',
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;
          END IF;

          BEGIN

            CLPKSS_UTIL.PR_LOG_CALC_DATES(L_TB_AC_NO,
                                          L_TB_BK_VALUE,
                                          P_BRANCH_CODE

                                         ,
                                          'E'

                                         ,
                                          NULL);

          EXCEPTION
            WHEN OTHERS THEN
              RAISE SKIP_CURRENT_SET;
          END;

          IF L_TB_UDE_VAL.COUNT > 0 THEN

            L_TB_DEL_ACC.DELETE;
            L_TB_DEL_EFFDT.DELETE;
            L_TB_DEL_UDEID.DELETE;

            COUNT1 := 0;

            FOR I IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP

              L_TB_DEL_ACC(I) := L_TB_UDE_VAL(I).ACCOUNT_NUMBER;
              L_TB_DEL_EFFDT(I) := L_TB_UDE_VAL(I).EFFECTIVE_DATE;
              L_TB_DEL_UDEID(I) := L_TB_UDE_VAL(I).UDE_ID;

              SELECT COUNT(1)
                INTO COUNT1
                FROM CLTB_ACCOUNT_UDE_EFF_DATES
               WHERE ACCOUNT_NUMBER = L_TB_UDE_VAL(I).ACCOUNT_NUMBER
                 AND BRANCH_CODE = P_BRANCH_CODE
                 AND EFFECTIVE_DATE = L_TB_UDE_VAL(I).EFFECTIVE_DATE;

              IF COUNT1 > 0 THEN
                L_TB_UDE_VAL(I).MAINT_RSLV_FLAG := 'M';
              END IF;

            END LOOP;
            DBG('l_tb_ude_val.count ::' || L_TB_UDE_VAL.COUNT);

            IF L_TB_UDE_VAL.COUNT > 0 THEN
              FOR I_IDX IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP
                IF L_TB_UDE_VAL(I_IDX).ACCOUNT_NUMBER IS NOT NULL AND L_TB_UDE_VAL(I_IDX)
                   .BRANCH_CODE IS NOT NULL THEN --sampath
                  BEGIN

                    L_ACCOUNT := CLPKSS_CACHE.FN_ACCOUNT_MASTER(L_TB_UDE_VAL(I_IDX)
                                                                .ACCOUNT_NUMBER,
                                                                L_TB_UDE_VAL(I_IDX)
                                                                .BRANCH_CODE);

                    SELECT COMPONENT_NAME
              
                      INTO L_COMPONENT_NAME
                      FROM CLTM_PRODUCT_COMP_FRM_ELEMS A

                     WHERE A.PRODUCT_CODE = L_ACCOUNT.PRODUCT_CODE

                       AND A.ELEM_TYPE = 'U'
                       AND ELEM_ID = L_TB_UDE_VAL(I_IDX).UDE_ID;
                  EXCEPTION
                    WHEN TOO_MANY_ROWS THEN
                      DBG('Too many rows came..');
                      SELECT COMPONENT_NAME
                        INTO L_COMPONENT_NAME
                        FROM CLTM_PRODUCT_COMP_FRM_ELEMS A

                       WHERE A.PRODUCT_CODE = L_ACCOUNT.PRODUCT_CODE

                         AND A.ELEM_TYPE = 'U'
                         AND ELEM_ID = L_TB_UDE_VAL(I_IDX).UDE_ID
                         AND ROWNUM = 1;
                    WHEN NO_DATA_FOUND THEN
                      DBG('There is no any component found..');
                  END;
                  DBG('L_COMPONENT_NAME ::' || L_COMPONENT_NAME);

                  L_ROW_ACC_COMPS := CLPKSS_CACHE.FN_ACCOUNT_COMPONENTS(L_ACCOUNT.ACCOUNT_NUMBER,
                                                                        L_ACCOUNT.BRANCH_CODE,
                                                                        L_COMPONENT_NAME);
                  IF NVL(L_ROW_ACC_COMPS.IRR_APPLICABLE, '$') = 'Y' AND
                     L_ROW_ACC_COMPS.ACCOUNT_NUMBER =
                     L_ACCOUNT.ACCOUNT_NUMBER THEN

                    DBG('l_row_acc_comps.account_number ::' ||
                        L_ROW_ACC_COMPS.ACCOUNT_NUMBER);
                    DBG('l_Account.account_number ::' ||
                        L_ACCOUNT.ACCOUNT_NUMBER);
                    DBG('IRR l_tb_ude_val(i_idx).account_number ::' || L_TB_UDE_VAL(I_IDX)
                        .ACCOUNT_NUMBER);
                    DBG('IRR l_tb_ude_val(i_idx).ude_id ::' || L_TB_UDE_VAL(I_IDX)
                        .UDE_ID);
                    L_UDE_IDXS := L_ACCOUNT.ACCOUNT_NUMBER ||
                                  L_ACCOUNT.BRANCH_CODE || 'ARVN';
                    G_TB_TEMP_ARVN_COMP(L_UDE_IDXS).ACCOUNT_NUMBER := L_ACCOUNT.ACCOUNT_NUMBER;
                    G_TB_TEMP_ARVN_COMP(L_UDE_IDXS).BRANCH_CODE := L_ACCOUNT.BRANCH_CODE;

                    G_TB_TEMP_ARVN_COMP(L_UDE_IDXS).EVENT_CODE := 'ARVN';

                  END IF;
                END IF; --sampath
              END LOOP;
            END IF;

            DEBUG.PR_DEBUG('CL',
                           'Enjoy.. now deleting the existing records :' ||
                           L_TB_DEL_ACC.COUNT);

            IF L_TB_DEL_ACC.COUNT <> 0 THEN
              BEGIN
                FORALL I IN L_TB_DEL_ACC.FIRST .. L_TB_DEL_ACC.LAST SAVE
                                                  EXCEPTIONS
                  DELETE CLTBS_ACCOUNT_UDE_VALUES
                   WHERE BRANCH_CODE = P_BRANCH_CODE
                     AND ACCOUNT_NUMBER = L_TB_DEL_ACC(I)
                     AND EFFECTIVE_DATE = L_TB_DEL_EFFDT(I)
                     AND UDE_ID = L_TB_DEL_UDEID(I);

              EXCEPTION
                WHEN OTHERS THEN
                  FOR ED IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
                    L_ERRIDX := SQL%BULK_EXCEPTIONS(ED).ERROR_INDEX;
                    DBG('Failed while UPDATING THE RECORDS IN CLTBS_ACCOUNT_TDUDE_RATE' ||
                        SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(ED).ERROR_CODE),
                               1,
                               1500));
                  END LOOP;
              END;

              IF L_BATCH_HAS_TD THEN
                BEGIN
                  L_BATCH_HAS_TD := FALSE;

                  FORALL I IN L_TB_DEL_ACC.FIRST .. L_TB_DEL_ACC.LAST SAVE
                                                    EXCEPTIONS
                    UPDATE CLTBS_ACCOUNT_TDUDE_RATE
                       SET PROCESSED       = DECODE(EFFECTIVE_DATE,
                                                    L_TB_DEL_EFFDT(I),
                                                    'Y',
                                                    'C'),
                           PROCESSING_DATE = P_PROC_DATE
                     WHERE BRANCH_CODE = P_BRANCH_CODE
                       AND ACCOUNT_NUMBER = L_TB_DEL_ACC(I)
                       AND PROCESSED <> 'Y'
                       AND EFFECTIVE_DATE <= P_PROC_DATE;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
                    DBG('Error Raised while updating CLTBS_ACCOUNT_TDUDE_RATE');
                    FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                      L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                      CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                                   P_BRANCH_CODE,
                                                   GLOBAL.APPLICATION_DATE,
                                                   L_EVENT_CODE,
                                                   'ERROR :' || L_IDX ||
                                                   '  POSITION = ' ||
                                                   L_ERR_IDX ||
                                                   ' -- ERROR_CODE = ' ||
                                                   SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                           .ERROR_CODE));
                    END LOOP;
                END;
              END IF;

            END IF;

            L_TB_DEL_ACC.DELETE;
            L_TB_DEL_EFFDT.DELETE;
            L_TB_DEL_UDEID.DELETE;

            DEBUG.PR_DEBUG('CL',
                           'Existing records deleted..now going to insert !');

            BEGIN

              FOR I IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP

                DBG('l_tb_ude_val(i).account_number --->' || L_TB_UDE_VAL(I)
                    .ACCOUNT_NUMBER);
                IF L_TB_UDE_VAL(I).ACCOUNT_NUMBER IS NOT NULL AND L_TB_UDE_VAL(I)
                   .BRANCH_CODE IS NOT NULL AND L_TB_UDE_VAL(I)
                   .EFFECTIVE_DATE IS NOT NULL THEN
                  DBG('l_tb_ude_val(i).account_number --->' || L_TB_UDE_VAL(I)
                      .ACCOUNT_NUMBER);

                  BEGIN
                    INSERT INTO CLTBS_ACCOUNT_UDE_VALUES
                    VALUES L_TB_UDE_VAL
                      (I);
                  EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                      NULL;
                  END;

                  UPDATE CLTB_REVN_SCHEDULES
                     SET APPLIED_FLAG = 'Y'
                   WHERE BRANCH_CODE = P_BRANCH_CODE
                     AND ACCOUNT_NUMBER = L_TB_UDE_VAL(I).ACCOUNT_NUMBER
                     AND SCHEDULE_DUE_DATE = L_TB_UDE_VAL(I).EFFECTIVE_DATE
                     AND APPLIED_FLAG IS NULL;

                END IF;
              END LOOP;

              DEBUG.PR_DEBUG('CL', 'Updated cltbs_account_ude_values');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_ACCOUNT_UDE_VALUES');
                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION(

                                               L_TB_UDE_VAL(L_ERR_IDX)
                                               .ACCOUNT_NUMBER,

                                               P_BRANCH_CODE,

                                               P_PROC_DATE,
                                               L_EVENT_CODE,

                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;

            FOR II IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST LOOP
              L_BTAB(II) := L_TB_UDE_VAL(II).BRANCH_CODE;
              L_ATAB(II) := L_TB_UDE_VAL(II).ACCOUNT_NUMBER;
            END LOOP;

            FORALL II IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST
              DELETE CLTBS_PROCESSED_REVISIONS
               WHERE ACCOUNT_NUMBER = L_ATAB(II)
                 AND BRANCH_CODE = L_BTAB(II);

          END IF;

          IF L_TY_TB_EFF_DT.COUNT > 0 THEN
            FOR I IN L_TY_TB_EFF_DT.FIRST .. L_TY_TB_EFF_DT.LAST LOOP
              BEGIN
                INSERT INTO CLTBS_ACCOUNT_UDE_EFF_DATES
                VALUES L_TY_TB_EFF_DT
                  (I);
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  NULL;
              END;
            END LOOP;
          END IF;

          IF L_TB_PROCESSED_AC.COUNT > 0 THEN
            BEGIN

              FORALL II IN L_TB_UDE_VAL.FIRST .. L_TB_UDE_VAL.LAST
                DELETE CLTBS_REVISION_ACCOUNTS
                 WHERE ACCOUNT_NUMBER = L_ATAB(II)
                   AND BRANCH_CODE = L_BTAB(II)
                   AND LEAST_EFFECTIVE_DATE <= P_PROC_DATE;

              L_BTAB.DELETE;
              L_ATAB.DELETE;

              DBG('Updated CLTBS_REVISION_ACCOUNTS');
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at CLTBS_REVISION_ACCOUNTS');

                ROLLBACK;

                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'ARVN',
                                               'ERROR :' || L_IDX ||
                                               '  POSITION = ' || L_ERR_IDX ||
                                               ' -- ERROR_CODE = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;

                RAISE SKIP_CURRENT_SET;
            END;
          END IF;
        END IF;

        DEBUG.PR_DEBUG('CL', 'Before commit in fn_process_revision');
        IF NOT P_FOR_AN_ACCOUNT THEN
          COMMIT;
        END IF;

        L_TB_ACC_REC.DELETE;
        L_TB_ACC_ROW_ID.DELETE;
        L_TB_AC_NO.DELETE;
        L_TB_BK_VALUE.DELETE;
        L_TB_PROCESSED_AC.DELETE;
        L_TB_ACC_NOT_RSLV_RID.DELETE;

      EXCEPTION
        WHEN SKIP_CURRENT_SET THEN
          DEBUG.PR_DEBUG('CL', '%%%%%%%%%%%%Reached here');

          ROLLBACK;

          L_TB_ACC_REC.DELETE;
          L_TB_ACC_ROW_ID.DELETE;
          L_TB_AC_NO.DELETE;
          L_TB_BK_VALUE.DELETE;
          L_TB_PROCESSED_AC.DELETE;
          L_BTAB.DELETE;
          L_ATAB.DELETE;
          L_TB_ACC_NOT_RSLV_RID.DELETE;
          DEBUG.PR_DEBUG('CL',
                         'Bombed in processing rates with ' || SQLERRM);
      END;

      EXIT WHEN CUR_ALL_REV_ACC%NOTFOUND;
    END LOOP;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_idx') := 0;
      IF NOT CLPKS_REVN_CLUSTER.FN_PROCESS_REVISION(LACCOBJ,
                                                    L_TB_ACC_REC,
                                                    L_RATE,
                                                    L_EFF_DT,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA,
                                                    P_ERRORCODE,
                                                    P_ERRORPARAM) THEN
        DBG('Failed in clpks_revn_cluster.fn_process_revision with ' ||
            P_ERRORCODE || ' : ' || P_ERRORPARAM);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      END IF;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;

      L_TB_ACC_REC.DELETE;
      L_TB_ACC_ROW_ID.DELETE;
      L_TB_AC_NO.DELETE;
      L_TB_BK_VALUE.DELETE;
      L_TB_PROCESSED_AC.DELETE;
      L_BTAB.DELETE;
      L_ATAB.DELETE;
      L_AC_REC_REVN.DELETE;
      L_TAB_REVN_VALS.DELETE;
      L_TB_ACC_UDE.DELETE;
      L_TAB_ACC_VALS.DELETE;
      L_TB_RATE_VALS.DELETE;
      L_TB_UDE_VAL.DELETE;
      L_TY_TB_EFF_DT.DELETE;
      L_TB_ACC_NOT_RSLV_RID.DELETE;
      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_PROC_REVISION_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PROCESS_REVISION;

  FUNCTION FN_UDCN_FOR_BRANCH(P_BRANCH_CODE IN CLTMS_UDE_CASCADE_MASTER.BRANCH_CODE%TYPE,
                              P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CURSOR CUR_UDE_CASCADE(P_BRANCH_CODE CLTMS_UDE_CASCADE_MASTER.BRANCH_CODE%TYPE) IS
      SELECT REFERENCE, PRODUCT_CODE, CCY_CODE, UDE_EFF_DT

        FROM CLTMS_UDE_CASCADE_MASTER PR

       WHERE NVL(CHANGE_CASCADED, 'N') = 'N'
         AND UDE_EFF_DT <= GLOBAL.APPLICATION_DATE
         AND BRANCH_CODE = P_BRANCH_CODE
         AND

             RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'

         AND EXISTS
       (SELECT 1
                FROM CLTM_PRODUCT MO
               WHERE PR.PRODUCT_CODE = MO.PRODUCT_CODE
                 AND MO.MODULE_CODE =
                     NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL'));

    CUR_UDE_ACC_AFFECTED REF_UDE_ACC_AFFECTED;
    L_PROCESSED_ALL_ACCS BOOLEAN;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of fn_udcn_for_branch');

    PKG_EVENT := 'UDCN';

    FOR EACH_REC IN CUR_UDE_CASCADE(P_BRANCH_CODE) LOOP
      OPEN CUR_UDE_ACC_AFFECTED FOR
        SELECT ACC.ROWID          ACC_ROW_ID,
               ACC.ACCOUNT_NUMBER ACC_NO,
               ACC.LATEST_ESN     SEQ_NO,
               ACC.PROCESS_NO     ACC_PROCESS_NO,
               UDE.ROWID          UDE_ROW_ID,
               UDE.UDE_ID         UDE_ID,
               UDE.EFFECTIVE_DATE UDE_EFF_DT,
               UDE.UDE_VALUE      UDE_VAL,
               UDE.RATE_CODE      RATE_CODE,
               UDE.RESOLVED_VALUE RESOLVED_VALUE,
               UDE.CODE_USAGE     CODE_USAGE,
               QRY.OLD_UDE_VALUE  OLD_VAL,
               QRY.NEW_UDE_VALUE  NEW_VAL
          FROM CLTBS_ACCOUNT_MASTER     ACC,
               CLTBS_ACCOUNT_UDE_VALUES UDE,
               CLTMS_UDE_CASCADE_DETAIL QRY
         WHERE ACC.BRANCH_CODE = P_BRANCH_CODE
           AND ACC.ACCOUNT_STATUS IN ('A', 'Y')
           AND ACC.AUTH_STAT = 'A'
           AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
           AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
           AND UDE.UDE_ID = QRY.UDE_ID
           AND ACC.PRODUCT_CODE = EACH_REC.PRODUCT_CODE
           AND ACC.CURRENCY = EACH_REC.CCY_CODE
           AND ACC.VALUE_DATE < EACH_REC.UDE_EFF_DT
           AND

               UDE.EFFECTIVE_DATE =
               (SELECT MAX(EFFECTIVE_DATE)
                  FROM CLTB_ACCOUNT_UDE_VALUES C
                 WHERE C.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
                   AND C.BRANCH_CODE = UDE.BRANCH_CODE
                   AND C.UDE_ID = UDE.UDE_ID
                   AND C.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE)
           AND

               QRY.REFERENCE = EACH_REC.REFERENCE
           AND UDE.UDE_VALUE = NVL(QRY.OLD_UDE_VALUE, UDE.UDE_VALUE)
           AND UDE.UDE_VALUE != QRY.NEW_UDE_VALUE
           AND ACC.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
           AND NOT EXISTS
         (SELECT 1
                  FROM CLTB_UDE_CASCADED_ACCS X
                 WHERE X.ACCOUNT_NUMBER = ACC.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = ACC.BRANCH_CODE
                   AND X.REFERENCE_NO = EACH_REC.REFERENCE)
         ORDER BY ACC.ACCOUNT_NUMBER;

      DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_UDCN');

      IF NOT FN_PROCESS_UDCN(P_BRANCH_CODE,
                             CUR_UDE_ACC_AFFECTED,
                             EACH_REC.UDE_EFF_DT,
                             EACH_REC.REFERENCE,
                             L_PROCESSED_ALL_ACCS,
                             FALSE,
                             P_ERRORCODE,
                             P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_process_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      IF L_PROCESSED_ALL_ACCS THEN
        UPDATE CLTMS_UDE_CASCADE_MASTER
           SET CHANGE_CASCADED = 'Y'
         WHERE REFERENCE = EACH_REC.REFERENCE;

        DELETE CLTB_UDE_CASCADED_ACCS
         WHERE BRANCH_CODE = P_BRANCH_CODE
           AND REFERENCE_NO = EACH_REC.REFERENCE;
      END IF;

      DEBUG.PR_DEBUG('CL', 'Before commit in fn_udcn_for_branch');
      COMMIT;

      DEBUG.PR_DEBUG('CL', 'Done with FN_PROCESS_UDCN');

    END LOOP;

    DEBUG.PR_DEBUG('CL', 'Processing successful for fn_udcn_for_branch');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDCN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_UDCN_FOR_BRANCH;

  FUNCTION FN_UDCN_FOR_ACCOUNT(P_ACCOUNT_NUMBER IN OUT NOCOPY CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                               P_BRANCH_CODE    IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                               P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                               P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CUR_UDE_CASCADE(P_BRANCH_CODE CLTMS_UDE_CASCADE_MASTER.BRANCH_CODE%TYPE) IS
      SELECT REFERENCE, PRODUCT_CODE, CCY_CODE, UDE_EFF_DT
        FROM CLTMS_UDE_CASCADE_MASTER

       WHERE NVL(CHANGE_CASCADED, 'N') = 'N'
         AND UDE_EFF_DT <= GLOBAL.APPLICATION_DATE
         AND BRANCH_CODE = P_BRANCH_CODE
         AND

             RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

    CUR_UDE_ACC_AFFECTED REF_UDE_ACC_AFFECTED;
    L_PROCESSED_ALL_ACCS BOOLEAN;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of fn_udcn_for_account');

    PKG_EVENT := 'UDCN';

    FOR EACH_REC IN CUR_UDE_CASCADE(P_BRANCH_CODE) LOOP
      OPEN CUR_UDE_ACC_AFFECTED FOR
        SELECT ACC.ROWID          ACC_ROW_ID,
               ACC.ACCOUNT_NUMBER ACC_NO,
               ACC.LATEST_ESN     SEQ_NO,
               ACC.PROCESS_NO     ACC_PROCESS_NO,
               UDE.ROWID          UDE_ROW_ID,
               UDE.UDE_ID         UDE_ID,
               UDE.EFFECTIVE_DATE UDE_EFF_DT,
               UDE.UDE_VALUE      UDE_VAL,
               UDE.RATE_CODE      RATE_CODE,
               UDE.RESOLVED_VALUE RESOLVED_VALUE,
               UDE.CODE_USAGE     CODE_USAGE,
               QRY.OLD_UDE_VALUE  OLD_VAL,
               QRY.NEW_UDE_VALUE  NEW_VAL
          FROM CLTBS_ACCOUNT_MASTER     ACC,
               CLTBS_ACCOUNT_UDE_VALUES UDE,
               CLTMS_UDE_CASCADE_DETAIL QRY
         WHERE ACC.BRANCH_CODE = P_BRANCH_CODE
           AND ACC.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
           AND ACC.ACCOUNT_STATUS IN ('A', 'Y')
           AND ACC.AUTH_STAT = 'A'
           AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
           AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
           AND UDE.UDE_ID = QRY.UDE_ID
           AND ACC.PRODUCT_CODE = EACH_REC.PRODUCT_CODE
           AND ACC.CURRENCY = EACH_REC.CCY_CODE
           AND ACC.VALUE_DATE < EACH_REC.UDE_EFF_DT
           AND ACC.MATURITY_DATE >= EACH_REC.UDE_EFF_DT
           AND UDE.EFFECTIVE_DATE <= EACH_REC.UDE_EFF_DT
           AND QRY.REFERENCE = EACH_REC.REFERENCE
           AND UDE.UDE_VALUE = NVL(QRY.OLD_UDE_VALUE, UDE.UDE_VALUE)
           AND UDE.UDE_VALUE != QRY.NEW_UDE_VALUE
           AND NOT EXISTS
         (SELECT 1
                  FROM CLTB_UDE_CASCADED_ACCS X
                 WHERE X.ACCOUNT_NUMBER = ACC.ACCOUNT_NUMBER
                   AND X.BRANCH_CODE = ACC.BRANCH_CODE
                   AND X.REFERENCE_NO = EACH_REC.REFERENCE)
         ORDER BY ACC.ACCOUNT_NUMBER;

      DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_UDCN');

      IF NOT FN_PROCESS_UDCN(P_BRANCH_CODE,
                             CUR_UDE_ACC_AFFECTED,
                             EACH_REC.UDE_EFF_DT,
                             EACH_REC.REFERENCE,
                             L_PROCESSED_ALL_ACCS,
                             TRUE,
                             P_ERRORCODE,
                             P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_process_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      DEBUG.PR_DEBUG('CL', 'Done with FN_PROCESS_UDCN');

    END LOOP;

    DEBUG.PR_DEBUG('CL', 'Processing successful for fn_udcn_for_account');

    RETURN TRUE;
  EXCEPTION

    WHEN OTHERS THEN
      P_ERRORCODE := 'CL-REVN08;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDCN_FOR_ACCOUNT..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_UDCN_FOR_ACCOUNT;

  FUNCTION FN_PERIODIC_REVN_FOR_BRANCH(P_BRANCH_CODE IN CLTMS_UDE_CASCADE_MASTER.BRANCH_CODE%TYPE,
                                       P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                       P_ERRORPARAM  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CUR_UDE_P_REVN(P_BRANCH_CODE CLTMS_ACCOUNT_UDE_REVN.BRANCH_CODE%TYPE) IS
      SELECT ACCOUNT_NUMBER, EFFECTIVE_DATE
        FROM CLTMS_ACCOUNT_UDE_REVN
       WHERE NVL(CHANGE_APPLIED, 'N') = 'N'
         AND EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND BRANCH_CODE = P_BRANCH_CODE;

    CUR_UDE_ACC_AFFECTED REF_UDE_ACC_AFFECTED;
    L_PROCESSED_ALL_ACCS BOOLEAN;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of fn_udcn_for_branch');

    PKG_EVENT := 'REVN';

    L_FUNCTION_ID := 'LSDFXRVN';
    FOR EACH_REC IN CUR_UDE_P_REVN(P_BRANCH_CODE) LOOP
      OPEN CUR_UDE_ACC_AFFECTED FOR
        SELECT ACC.ROWID          ACC_ROW_ID,
               ACC.ACCOUNT_NUMBER ACC_NO,
               ACC.LATEST_ESN     SEQ_NO,
               ACC.PROCESS_NO     ACC_PROCESS_NO,
               UDE.ROWID          UDE_ROW_ID,
               UDE.UDE_ID         UDE_ID,
               UDE.EFFECTIVE_DATE UDE_EFF_DT,
               UDE.UDE_VALUE      UDE_VAL,
               UDE.RATE_CODE      RATE_CODE,
               UDE.RESOLVED_VALUE RESOLVED_VALUE,
               UDE.CODE_USAGE     CODE_USAGE,
               QRY.OLD_UDE_VALUE  OLD_VAL,
               QRY.NEW_UDE_VALUE  NEW_VAL
          FROM CLTBS_ACCOUNT_MASTER       ACC,
               CLTBS_ACCOUNT_UDE_VALUES   UDE,
               CLTMS_ACCOUNT_UDE_REVN_DET QRY
         WHERE ACC.BRANCH_CODE = P_BRANCH_CODE
           AND ACC.ACCOUNT_STATUS IN ('A', 'Y')
           AND ACC.AUTH_STAT = 'A'
           AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
           AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
           AND UDE.UDE_ID = QRY.UDE_ID
           AND ACC.MATURITY_DATE >= EACH_REC.EFFECTIVE_DATE
           AND UDE.EFFECTIVE_DATE <= EACH_REC.EFFECTIVE_DATE
           AND QRY.ACCOUNT_NUMBER = EACH_REC.ACCOUNT_NUMBER
           AND UDE.UDE_VALUE = NVL(QRY.OLD_UDE_VALUE, UDE.UDE_VALUE)
           AND UDE.UDE_VALUE != QRY.NEW_UDE_VALUE
           AND ACC.MODULE_CODE =
               NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')

         ORDER BY ACC.ACCOUNT_NUMBER;

      DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_UDCN');

      IF NOT FN_PROCESS_UDCN(P_BRANCH_CODE,
                             CUR_UDE_ACC_AFFECTED,
                             EACH_REC.EFFECTIVE_DATE,
                             EACH_REC.ACCOUNT_NUMBER,
                             L_PROCESSED_ALL_ACCS,
                             FALSE,
                             P_ERRORCODE,
                             P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_process_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      IF L_PROCESSED_ALL_ACCS THEN
        UPDATE CLTMS_ACCOUNT_UDE_REVN
           SET CHANGE_APPLIED = 'Y'
         WHERE ACCOUNT_NUMBER = EACH_REC.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_BRANCH_CODE;
      END IF;

      DEBUG.PR_DEBUG('CL', 'Before commit in fn_udcn_for_branch');
      COMMIT;

      DEBUG.PR_DEBUG('CL', 'Done with FN_PROCESS_UDCN');

    END LOOP;

    PKG_EVENT := NULL;

    L_FUNCTION_ID := NULL;
    DEBUG.PR_DEBUG('CL', 'Processing successful for fn_udcn_for_branch');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDCN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PERIODIC_REVN_FOR_BRANCH;

  FUNCTION FN_PERIODIC_REVN_FOR_ACCOUNT(P_ACCOUNT_NUMBER CLTB_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                        P_BRANCH_CODE    IN CLTMS_UDE_CASCADE_MASTER.BRANCH_CODE%TYPE,
                                        P_ERRORCODE      IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                        P_ERRORPARAM     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    CURSOR CUR_UDE_P_REVN(P_BRANCH_CODE CLTMS_ACCOUNT_UDE_REVN.BRANCH_CODE%TYPE) IS
      SELECT ACCOUNT_NUMBER, EFFECTIVE_DATE
        FROM CLTMS_ACCOUNT_UDE_REVN
       WHERE NVL(CHANGE_APPLIED, 'N') = 'N'
         AND EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND BRANCH_CODE = P_BRANCH_CODE;

    CUR_UDE_ACC_AFFECTED REF_UDE_ACC_AFFECTED;
    L_PROCESSED_ALL_ACCS BOOLEAN;

  BEGIN

    DEBUG.PR_DEBUG('CL', 'Start of periodic_revn_for_account');

    PKG_EVENT := 'REVN';

    L_FUNCTION_ID := 'LSDFXRVN';
    FOR EACH_REC IN CUR_UDE_P_REVN(P_BRANCH_CODE) LOOP
      OPEN CUR_UDE_ACC_AFFECTED FOR
        SELECT ACC.ROWID          ACC_ROW_ID,
               ACC.ACCOUNT_NUMBER ACC_NO,
               ACC.LATEST_ESN     SEQ_NO,
               ACC.PROCESS_NO     ACC_PROCESS_NO,
               UDE.ROWID          UDE_ROW_ID,
               UDE.UDE_ID         UDE_ID,
               UDE.EFFECTIVE_DATE UDE_EFF_DT,
               UDE.UDE_VALUE      UDE_VAL,
               UDE.RATE_CODE      RATE_CODE,
               UDE.RESOLVED_VALUE RESOLVED_VALUE,
               UDE.CODE_USAGE     CODE_USAGE,
               QRY.OLD_UDE_VALUE  OLD_VAL,
               QRY.NEW_UDE_VALUE  NEW_VAL
          FROM CLTBS_ACCOUNT_MASTER       ACC,
               CLTBS_ACCOUNT_UDE_VALUES   UDE,
               CLTMS_ACCOUNT_UDE_REVN_DET QRY
         WHERE ACC.BRANCH_CODE = P_BRANCH_CODE
           AND ACC.ACCOUNT_STATUS IN ('A', 'Y')
           AND ACC.AUTH_STAT = 'A'
           AND ACC.ACCOUNT_NUMBER = P_ACCOUNT_NUMBER
           AND ACC.ACCOUNT_NUMBER = UDE.ACCOUNT_NUMBER
           AND ACC.BRANCH_CODE = UDE.BRANCH_CODE
           AND UDE.UDE_ID = QRY.UDE_ID
           AND ACC.MATURITY_DATE >= EACH_REC.EFFECTIVE_DATE
           AND UDE.EFFECTIVE_DATE <= EACH_REC.EFFECTIVE_DATE
           AND QRY.ACCOUNT_NUMBER = EACH_REC.ACCOUNT_NUMBER
           AND UDE.UDE_VALUE = NVL(QRY.OLD_UDE_VALUE, UDE.UDE_VALUE)
           AND UDE.UDE_VALUE != QRY.NEW_UDE_VALUE

         ORDER BY ACC.ACCOUNT_NUMBER;

      DEBUG.PR_DEBUG('CL', 'before FN_PROCESS_UDCN');

      IF NOT FN_PROCESS_UDCN(P_BRANCH_CODE,
                             CUR_UDE_ACC_AFFECTED,
                             EACH_REC.EFFECTIVE_DATE,
                             EACH_REC.ACCOUNT_NUMBER,
                             L_PROCESSED_ALL_ACCS,
                             FALSE,
                             P_ERRORCODE,
                             P_ERRORPARAM) THEN
        DEBUG.PR_DEBUG('CL',
                       'failed in  fn_process_revision' || P_ERRORCODE);
        RETURN FALSE;
      END IF;

      IF L_PROCESSED_ALL_ACCS THEN
        UPDATE CLTMS_ACCOUNT_UDE_REVN
           SET CHANGE_APPLIED = 'Y'
         WHERE ACCOUNT_NUMBER = EACH_REC.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_BRANCH_CODE;
      END IF;

      DEBUG.PR_DEBUG('CL', 'Before commit in fn_udcn_for_branch');
      COMMIT;

      DEBUG.PR_DEBUG('CL', 'Done with FN_PROCESS_UDCN');

    END LOOP;

    PKG_EVENT := NULL;

    L_FUNCTION_ID := NULL;
    DEBUG.PR_DEBUG('CL', 'Processing successful for fn_udcn_for_branch');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      P_ERRORCODE := 'CL-REVN06;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDCN_FOR_BRANCH..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      RETURN FALSE;

  END FN_PERIODIC_REVN_FOR_ACCOUNT;

  FUNCTION FN_PROCESS_UDCN(P_BRANCH_CODE        IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                           CUR_UDE_ACC_AFFECTED IN REF_UDE_ACC_AFFECTED,
                           P_UDE_EFF_DT         IN DATE,
                           P_REFERENCE          IN CLTMS_UDE_CASCADE_MASTER.REFERENCE%TYPE,
                           L_PROCESSED_ALL_ACCS OUT BOOLEAN,
                           P_FOR_AN_ACCOUNT     IN BOOLEAN,
                           P_ERRORCODE          IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                           P_ERRORPARAM         IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    TYPE TY_PROCESSED_ACCS IS TABLE OF CLTB_UDE_CASCADED_ACCS%ROWTYPE INDEX BY PLS_INTEGER;

    L_TB_ACC_AFF               TY_UDE_ACC_AFFECTED;
    L_REC_ACC_AFF              TY_UDE_ACC_AFFECTED;
    L_INDEX                    PLS_INTEGER;
    L_TB_UDCN_UDE              TY_TB_UDCN_UDE;
    L_UDE_ID_IDX               CLTBS_ACCOUNT_UDE_VALUES.UDE_ID%TYPE;
    L_UDE_DT_IDX               PLS_INTEGER;
    L_TB_UPD_UDCN_UDE_VAL      TY_TB_UPD_UDCN_UDE_VAL;
    L_TB_UPD_UDCN_ROW_ID       TY_TB_UPD_UDCN_ROW_ID;
    L_TB_UPD_UDCN_UDE_RSLV_VAL TY_TB_UPD_UDCN_UDE_RSLV_VAL;
    L_TB_INS_UDCN_UDE_VALS     TY_TB_INS_UDCN_UDE_VALS;
    L_TB_ACC_ROW_ID            TY_TB_ACC_ROW_ID;
    L_TB_BK_VALUE              DBMS_SQL.DATE_TABLE;
    L_TB_AC_NO                 DBMS_SQL.VARCHAR2S;
    L_ACC_AFF_FLAG             BOOLEAN;
    L_TB_ACC_MIN_DT            TY_TB_ACC_MIN_DT;
    L_CNT                      PLS_INTEGER;
    L_ACC_IDX                  CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE;
    L_NXT_ACC_NO               CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE := NULL;
    L_CURR_ACC_NO              CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE := NULL;
    L_ACC_ROW_ID               ROWID;
    L_TB_INS_DIARY             TY_TB_INS_DIARY;
    L_INS_DIARY_IDX            PLS_INTEGER;
    L_NO_ERRORS                PLS_INTEGER;
    L_ERR_IDX                  PLS_INTEGER;
    L_TB_CAS_MAS               TY_TB_CAS_MAS;
    L_CAS_MAS_IDX              PLS_INTEGER;
    L_ACC_ROW_ID_IDX           PLS_INTEGER;
    L_COMMIT_FREQ              PLS_INTEGER;
    L_TY_TB_EFF_DT             TY_TB_EFF_DT;
    L_TB_ACC_EFF_DT            TY_TB_ACC_EFF_DT;
    L_IDX                      VARCHAR2(100);
    LPROD                      CLTMS_PRODUCT.PRODUCT_CODE%TYPE;
    LEVENT                     CLTMS_PRODUCT_EVENT_POLCS.EVENT_CODE%TYPE;
    LRET                       NUMBER;
    LACMASTER                  CLTBS_ACCOUNT_MASTER%ROWTYPE;
    LACCOBJ                    CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_TB_PROCESSED_ACCS        TY_PROCESSED_ACCS;

    L_PROC_NO CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE;
    SKIP_CURRENT_SET EXCEPTION;
    L_AC_IDX NUMBER;
    NEXT_RECORD EXCEPTION;

  BEGIN

    L_COMMIT_FREQ        := NVL(CLPKSS_BATCH.G_COMMIT_FREQ, 500);
    L_PROCESSED_ALL_ACCS := TRUE;
    L_CAS_MAS_IDX        := 1;
    L_INS_DIARY_IDX      := 1;

    LEVENT := NVL(PKG_EVENT, 'UDCN');
    DEBUG.PR_DEBUG('CL', 'Before fetch from Cursor');

    LOOP
      L_TB_ACC_AFF.DELETE;

      FETCH CUR_UDE_ACC_AFFECTED BULK COLLECT
        INTO L_TB_ACC_AFF LIMIT L_COMMIT_FREQ;

      IF L_REC_ACC_AFF.COUNT > 0 THEN
        L_INDEX := L_TB_ACC_AFF.FIRST;

        IF L_INDEX IS NULL THEN
          L_INDEX := L_REC_ACC_AFF.FIRST;
          L_TB_ACC_AFF(L_INDEX) := L_REC_ACC_AFF(L_REC_ACC_AFF.FIRST);
        ELSE
          L_TB_ACC_AFF(L_INDEX - 1) := L_REC_ACC_AFF(L_REC_ACC_AFF.FIRST);
        END IF;

      END IF;

      DEBUG.PR_DEBUG('CL',
                     'after fetch from cursor..no. of rows fetced :' ||
                     CUR_UDE_ACC_AFFECTED%ROWCOUNT);
      DEBUG.PR_DEBUG('CL', 'l_tb_acc_aff.count  :' || L_TB_ACC_AFF.COUNT);

      BEGIN
        IF NVL(L_TB_ACC_AFF.COUNT, 0) > 0 THEN
          L_INDEX := L_TB_ACC_AFF.LAST;
          LOOP
            L_REC_ACC_AFF.DELETE;

            FETCH CUR_UDE_ACC_AFFECTED BULK COLLECT
              INTO L_REC_ACC_AFF LIMIT 1;

            EXIT WHEN(NVL(L_REC_ACC_AFF.COUNT, 0) = 0 OR L_REC_ACC_AFF(L_REC_ACC_AFF.FIRST)
                      .ACC_NO <> L_TB_ACC_AFF(L_INDEX).ACC_NO);

            L_INDEX := L_INDEX + 1;
            L_TB_ACC_AFF(L_INDEX) := L_REC_ACC_AFF(L_REC_ACC_AFF.FIRST);
          END LOOP;
        END IF;

        IF L_TB_ACC_AFF.COUNT > 0 THEN
          FOR L_IDX IN L_TB_ACC_AFF.FIRST .. L_TB_ACC_AFF.LAST LOOP

            BEGIN
              SAVEPOINT SP_UDCN;

              L_UDE_ID_IDX := L_TB_ACC_AFF(L_IDX).UDE_ID;
              L_UDE_DT_IDX := CLPKS_UTIL.FN_HASH_DATE(L_TB_ACC_AFF(L_IDX)
                                                      .UDE_EFF_DT);

              DEBUG.PR_DEBUG('CL', 'populating the udcn table..');

              L_TB_UDCN_UDE(L_UDE_ID_IDX).UDE_ID := L_UDE_ID_IDX;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).UDE_ROWID := L_TB_ACC_AFF(L_IDX)
                                                                                   .UDE_ROW_ID;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).UDE_EFF_DT := L_TB_ACC_AFF(L_IDX)
                                                                                    .UDE_EFF_DT;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).UDE_VALUE := L_TB_ACC_AFF(L_IDX)
                                                                                   .UDE_VAL;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).RATE_CODE := L_TB_ACC_AFF(L_IDX)
                                                                                   .RATE_CODE;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).RESOLVED_VALUE := L_TB_ACC_AFF(L_IDX)
                                                                                        .RESOLVED_VALUE;

              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).CODE_USAGE := L_TB_ACC_AFF(L_IDX)
                                                                                    .CODE_USAGE;

              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).OLD_VAL := L_TB_ACC_AFF(L_IDX)
                                                                                 .OLD_VAL;
              L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_UDE_DT_IDX).NEW_VAL := L_TB_ACC_AFF(L_IDX)
                                                                                 .NEW_VAL;
              L_CURR_ACC_NO := L_TB_ACC_AFF(L_IDX).ACC_NO;
              L_ACC_ROW_ID := L_TB_ACC_AFF(L_IDX).ACC_ROW_ID;
              L_PROC_NO := L_TB_ACC_AFF(L_IDX).ACC_PROCESS_NO;

              IF L_IDX + 1 <= L_TB_ACC_AFF.LAST

               THEN
                L_NXT_ACC_NO := L_TB_ACC_AFF(L_IDX + 1).ACC_NO;
              END IF;

              IF L_TB_ACC_AFF(L_IDX)
               .ACC_NO <> L_NXT_ACC_NO OR L_IDX = L_TB_ACC_AFF.LAST

               THEN

                DBG('Getting account master from cache');
                LACMASTER := CLPKSS_CACHE.FN_ACCOUNT_MASTER(L_TB_ACC_AFF(L_IDX)
                                                            .ACC_NO,
                                                            P_BRANCH_CODE);
                LPROD     := LACMASTER.PRODUCT_CODE;

                IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LPROD, LEVENT) THEN
                  DBG('##########fn_clear_acc_object#######');

                  IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(LACCOBJ,
                                                           P_ERRORCODE,
                                                           P_ERRORPARAM) THEN
                    DBG('Failed in call to clear obj ::' || P_ERRORCODE);

                    RAISE NEXT_RECORD;

                  END IF;

                  DBG('##########After fn_clear_acc_object#######');

                  IF NOT
                      CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_ACC_AFF(L_IDX)
                                                          .ACC_NO,
                                                          P_BRANCH_CODE,
                                                          LACCOBJ,
                                                          P_ERRORCODE,
                                                          P_ERRORPARAM) THEN
                    DBG('Failed in populating Account object for UDCN for account::' ||
                        P_ERRORCODE);

                    RAISE SKIP_CURRENT_SET;
                  END IF;

                  DBG('Calling clpks_pol_wrapper with product::' || LPROD ||
                      ' ,event UDCN and execution_type B');

                  LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LPROD,
                                                               LEVENT,
                                                               'B',
                                                               LACCOBJ,
                                                               P_ERRORCODE,
                                                               P_ERRORPARAM);

                  DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                  IF LRET = -1 THEN

                    RAISE NEXT_RECORD;

                  END IF;
                END IF;
                G_UDE_CALC_REQD := FALSE;
                IF NOT FN_UDE_CASCADE(L_TB_ACC_AFF(L_IDX).ACC_NO,
                                      P_BRANCH_CODE,
                                      L_TB_UDCN_UDE,
                                      L_ACC_AFF_FLAG,
                                      P_UDE_EFF_DT,
                                      L_TB_UPD_UDCN_UDE_VAL,
                                      L_TB_UPD_UDCN_UDE_RSLV_VAL,
                                      L_TB_UPD_UDCN_ROW_ID,
                                      L_TB_INS_UDCN_UDE_VALS,
                                      L_TY_TB_EFF_DT,
                                      P_ERRORCODE) THEN
                  P_ERRORPARAM := L_CURR_ACC_NO;
                  P_ERRORCODE  := 'CL-REVN05;';
                  OVPKSS.PR_APPENDTBL(P_ERRORCODE, P_ERRORPARAM);

                  DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDE_CASCADE..');
                  DEBUG.PR_DEBUG('CL',
                                 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
                  DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

                  CLPKS_UTIL.PR_LOG_EXCEPTION(L_CURR_ACC_NO,
                                              P_BRANCH_CODE,
                                              GLOBAL.APPLICATION_DATE

                                             ,
                                              LEVENT,
                                              P_ERRORCODE ||
                                              ' - UNABLE TO CASCADE UDE VAL CHANGE TO THE ACCOUNT ' ||
                                              P_ERRORPARAM);

                  RAISE NEXT_RECORD;

                ELSE
                  DEBUG.PR_DEBUG('CL', 'BACK FROM FN_UDE_CASCADE..');

                  IF L_ACC_AFF_FLAG THEN
                    L_ACC_ROW_ID_IDX := NVL(L_TB_AC_NO.COUNT, 0) + 1;

                    DEBUG.PR_DEBUG('CL',
                                   '$$$$$$$$$p_ude_eff_dt ' || P_UDE_EFF_DT);

                    IF NOT L_TB_ACC_MIN_DT.EXISTS(L_CURR_ACC_NO) THEN
                      L_TB_ACC_MIN_DT(L_CURR_ACC_NO).ACC_ROW_ID := L_TB_ACC_AFF(L_IDX)
                                                                   .ACC_ROW_ID;

                      IF G_UDE_CALC_REQD THEN
                        L_TB_ACC_MIN_DT(L_CURR_ACC_NO).CALC_REQD := 'Y';
                        L_TB_ACC_MIN_DT(L_CURR_ACC_NO).RECALC_ACTION_CODE := NVL(LACCOBJ.ACCOUNT_DET.RATE_CHG_ACTION,
                                                                                 'E');
                        L_TB_BK_VALUE(L_ACC_ROW_ID_IDX) := P_UDE_EFF_DT;
                        L_TB_AC_NO(L_ACC_ROW_ID_IDX) := L_TB_ACC_AFF(L_IDX)
                                                        .ACC_NO;
                      ELSE
                        L_TB_ACC_MIN_DT(L_CURR_ACC_NO).CALC_REQD := 'N';
                        L_TB_ACC_MIN_DT(L_CURR_ACC_NO).RECALC_ACTION_CODE := LACCOBJ.ACCOUNT_DET.RATE_CHG_ACTION;
                      END IF;

                      IF NOT FN_POPULATE_DIARY(L_TB_INS_DIARY,
                                               L_CURR_ACC_NO,
                                               P_BRANCH_CODE

                                              ,
                                               LEVENT,
                                               L_TB_ACC_AFF(L_IDX).SEQ_NO + 1,
                                               LACCOBJ.ACCOUNT_DET.PROCESS_NO,
                                               LACCOBJ.ACCOUNT_DET.VERSION_NO

                                              ,
                                               GLOBAL.APPLICATION_DATE,
                                               NULL

                                              ,
                                               P_ERRORCODE) THEN
                        DEBUG.PR_DEBUG('CL', 'Failed in Diary population');

                        RAISE NEXT_RECORD;

                      END IF;
                    END IF;
                  END IF;
                END IF;

                IF CLPKSS_CACHE.FN_EXISTS_PRODUCT_POLICY(LPROD, LEVENT) THEN
                  DBG('Calling clpks_pol_wrapper with product::' || LPROD ||
                      ' ,event UDCN and execution_type A');

                  LRET := CLPKSS_POL_WRAPPER.FN_EXECUTE_POLICY(LPROD,
                                                               LEVENT,
                                                               'A',
                                                               LACCOBJ,
                                                               P_ERRORCODE,
                                                               P_ERRORPARAM);

                  DBG('Returned value from clps_pol_wrapper is ::' || LRET);

                  IF LRET = -1 THEN

                    RAISE NEXT_RECORD;

                  END IF;
                END IF;

                L_AC_IDX := NVL(L_TB_PROCESSED_ACCS.LAST, 0) + 1;

                L_TB_PROCESSED_ACCS(L_AC_IDX).ACCOUNT_NUMBER := L_CURR_ACC_NO;
                L_TB_PROCESSED_ACCS(L_AC_IDX).BRANCH_CODE := P_BRANCH_CODE;
                L_TB_PROCESSED_ACCS(L_AC_IDX).REFERENCE_NO := P_REFERENCE;

                L_TB_UDCN_UDE.DELETE;
              END IF;

            EXCEPTION
              WHEN NEXT_RECORD THEN
                DBG('When Others Processing Failed :- ' ||
                    SUBSTR(SQLERRM, 1, 80));
                BEGIN
                  ROLLBACK TO SP_UDCN;
                EXCEPTION
                  WHEN OTHERS THEN
                    ROLLBACK;
                END;
              WHEN OTHERS THEN
                DBG('When Others Processing Failed :- ' ||
                    SUBSTR(SQLERRM, 1, 80));
                BEGIN
                  ROLLBACK TO SP_UDCN;
                EXCEPTION
                  WHEN OTHERS THEN
                    ROLLBACK;
                END;
            END;

          END LOOP;
        END IF;

        DEBUG.PR_DEBUG('CL', 'updating cltbs_account_ude_values');

        BEGIN
          IF NVL(L_TB_UPD_UDCN_ROW_ID.COUNT, 0) > 0 THEN
            FORALL I IN L_TB_UPD_UDCN_ROW_ID.FIRST .. L_TB_UPD_UDCN_ROW_ID.LAST SAVE
                                                      EXCEPTIONS
              UPDATE CLTBS_ACCOUNT_UDE_VALUES
                 SET RESOLVED_VALUE = L_TB_UPD_UDCN_UDE_RSLV_VAL(I),
                     UDE_VALUE      = L_TB_UPD_UDCN_UDE_VAL(I)
               WHERE ROWID = L_TB_UPD_UDCN_ROW_ID(I);

            DEBUG.PR_DEBUG('CL', 'updated cltbs_account_ude_values');

          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

            ROLLBACK;

            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE

                                          ,
                                           LEVENT,
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;

            RAISE SKIP_CURRENT_SET;
        END;

        DEBUG.PR_DEBUG('CL', 'Inserting  into cltbs_account_ude_values');
        DEBUG.PR_DEBUG('CL',
                       '.......No of rows to insert.....' ||
                       L_TB_INS_UDCN_UDE_VALS.COUNT);

        BEGIN
          IF NVL(L_TB_INS_UDCN_UDE_VALS.COUNT, 0) > 0 THEN

            FORALL I IN L_TB_INS_UDCN_UDE_VALS.FIRST .. L_TB_INS_UDCN_UDE_VALS.LAST
              DELETE CLTBS_ACCOUNT_UDE_VALUES
               WHERE BRANCH_CODE = P_BRANCH_CODE
                 AND ACCOUNT_NUMBER = L_TB_INS_UDCN_UDE_VALS(I)
                    .ACCOUNT_NUMBER
                 AND EFFECTIVE_DATE = L_TB_INS_UDCN_UDE_VALS(I)
                    .EFFECTIVE_DATE
                 AND UDE_ID = L_TB_INS_UDCN_UDE_VALS(I).UDE_ID;

            FORALL I IN L_TB_INS_UDCN_UDE_VALS.FIRST .. L_TB_INS_UDCN_UDE_VALS.LAST SAVE
                                                        EXCEPTIONS
              INSERT INTO CLTBS_ACCOUNT_UDE_VALUES
              VALUES L_TB_INS_UDCN_UDE_VALS
                (I);

            DEBUG.PR_DEBUG('CL', 'Inserted into cltbs_account_ude_values');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

            ROLLBACK;

            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE

                                          ,
                                           LEVENT,
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));

            END LOOP;

            RAISE SKIP_CURRENT_SET;
        END;

        DEBUG.PR_DEBUG('CL',
                       'Into change for inserting into ude-eff-dtaes table....');

        L_IDX := L_TY_TB_EFF_DT.FIRST;
        L_CNT := 1;

        WHILE L_IDX IS NOT NULL LOOP
          L_TB_ACC_EFF_DT(L_CNT).ACCOUNT_NUMBER := L_TY_TB_EFF_DT(L_IDX)
                                                   .ACCOUNT_NUMBER;
          L_TB_ACC_EFF_DT(L_CNT).BRANCH_CODE := L_TY_TB_EFF_DT(L_IDX)
                                                .BRANCH_CODE;
          L_TB_ACC_EFF_DT(L_CNT).EFFECTIVE_DATE := L_TY_TB_EFF_DT(L_IDX)
                                                   .EFFECTIVE_DATE;
          L_IDX := L_TY_TB_EFF_DT.NEXT(L_IDX);
          L_CNT := L_CNT + 1;
        END LOOP;

        DEBUG.PR_DEBUG('CL', 'Inserting  into cltbs_account_ude_eff_dates');
        DEBUG.PR_DEBUG('CL',
                       '.......No of rows to insert.....' ||
                       L_TB_ACC_EFF_DT.COUNT);

        BEGIN
          IF NVL(L_TB_ACC_EFF_DT.COUNT, 0) > 0 THEN
            FORALL I IN L_TB_ACC_EFF_DT.FIRST .. L_TB_ACC_EFF_DT.LAST SAVE
                                                 EXCEPTIONS
              INSERT INTO CLTBS_ACCOUNT_UDE_EFF_DATES
              VALUES L_TB_ACC_EFF_DT
                (I);

            DEBUG.PR_DEBUG('CL',
                           'inserted into cltbs_account_ude_eff_dates');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

            ROLLBACK;

            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE

                                          ,
                                           LEVENT,
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;

            RAISE SKIP_CURRENT_SET;
        END;

        IF NVL(L_TB_INS_DIARY.COUNT, 0) > 0 THEN
          IF NOT FN_INSERT_DIARY(L_TB_INS_DIARY, P_BRANCH_CODE, P_ERRORCODE) THEN
            DEBUG.PR_DEBUG('CL', 'Failed in Diary insert');

            RAISE SKIP_CURRENT_SET;
          END IF;
        END IF;

        L_ACC_IDX := L_TB_ACC_MIN_DT.FIRST;
        L_CNT     := 1;

        WHILE L_ACC_IDX IS NOT NULL LOOP
          L_TB_ACC_ROW_ID(L_CNT) := L_TB_ACC_MIN_DT(L_ACC_IDX).ACC_ROW_ID;

          L_CNT     := L_CNT + 1;
          L_ACC_IDX := L_TB_ACC_MIN_DT.NEXT(L_ACC_IDX);
        END LOOP;

        DEBUG.PR_DEBUG('CL',
                       'Updating affected account in cltbs_account_master..');

        BEGIN
          IF NVL(L_TB_ACC_ROW_ID.COUNT, 0) > 0 THEN
            FORALL I IN L_TB_ACC_ROW_ID.FIRST .. L_TB_ACC_ROW_ID.LAST SAVE
                                                 EXCEPTIONS
              UPDATE CLTBS_ACCOUNT_MASTER
                 SET CALC_REQD = 'Y'

                    ,
                     RECALC_ACTION_CODE = 'E'

                    ,
                     LATEST_ESN = LATEST_ESN + 1
               WHERE ROWID = L_TB_ACC_ROW_ID(I);

            DEBUG.PR_DEBUG('CL', 'UPDATED CLTBS_ACCOUNT_MASTER');

          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

            ROLLBACK;

            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE

                                          ,
                                           LEVENT,
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;

            RAISE SKIP_CURRENT_SET;
        END;

        BEGIN
          IF NVL(L_TB_PROCESSED_ACCS.COUNT, 0) > 0 THEN
            FORALL I IN L_TB_PROCESSED_ACCS.FIRST .. L_TB_PROCESSED_ACCS.LAST SAVE
                                                     EXCEPTIONS
              INSERT INTO CLTBS_UDE_CASCADED_ACCS
              VALUES L_TB_PROCESSED_ACCS
                (I);

            DEBUG.PR_DEBUG('CL', 'updated cltbs_ude_cascaded_accs');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

            ROLLBACK;

            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE

                                          ,
                                           LEVENT,
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;

            RAISE SKIP_CURRENT_SET;
        END;

        CLPKSS_UTIL.PR_LOG_CALC_DATES(L_TB_AC_NO,
                                      L_TB_BK_VALUE,
                                      P_BRANCH_CODE

                                     ,
                                      'E'

                                     ,
                                      NULL);

        IF NOT P_FOR_AN_ACCOUNT THEN
          DEBUG.PR_DEBUG('CL', 'Before Debug in fn_process_udcn');
          COMMIT;
        END IF;

        DEBUG.PR_DEBUG('CL', ' COMMIT...');

        L_TB_ACC_AFF.DELETE;
        L_TB_INS_UDCN_UDE_VALS.DELETE;
        L_TB_UPD_UDCN_ROW_ID.DELETE;
        L_TB_UPD_UDCN_UDE_RSLV_VAL.DELETE;
        L_TB_UPD_UDCN_UDE_VAL.DELETE;
        L_TB_ACC_ROW_ID.DELETE;
        L_TB_ACC_MIN_DT.DELETE;
        L_TB_BK_VALUE.DELETE;
        L_TB_AC_NO.DELETE;
        L_TB_UDCN_UDE.DELETE;
        L_TB_INS_DIARY.DELETE;
        L_TB_ACC_EFF_DT.DELETE;
        L_TY_TB_EFF_DT.DELETE;
        L_TB_PROCESSED_ACCS.DELETE;

      EXCEPTION
        WHEN SKIP_CURRENT_SET THEN
          ROLLBACK;

          L_PROCESSED_ALL_ACCS := FALSE;

          L_TB_ACC_AFF.DELETE;
          L_TB_INS_UDCN_UDE_VALS.DELETE;
          L_TB_UPD_UDCN_ROW_ID.DELETE;
          L_TB_UPD_UDCN_UDE_RSLV_VAL.DELETE;
          L_TB_UPD_UDCN_UDE_VAL.DELETE;
          L_TB_ACC_ROW_ID.DELETE;
          L_TB_ACC_MIN_DT.DELETE;
          L_TB_BK_VALUE.DELETE;
          L_TB_AC_NO.DELETE;
          L_TB_UDCN_UDE.DELETE;
          L_TB_INS_DIARY.DELETE;
          L_TB_ACC_EFF_DT.DELETE;
          L_TY_TB_EFF_DT.DELETE;
          L_TB_PROCESSED_ACCS.DELETE;
      END;

      EXIT WHEN CUR_UDE_ACC_AFFECTED%NOTFOUND;
    END LOOP;

    L_TB_CAS_MAS(L_CAS_MAS_IDX) := P_REFERENCE;
    L_CAS_MAS_IDX := L_CAS_MAS_IDX + 1;

    L_TB_ACC_AFF.DELETE;
    L_TB_INS_UDCN_UDE_VALS.DELETE;
    L_TB_UPD_UDCN_ROW_ID.DELETE;
    L_TB_UPD_UDCN_UDE_RSLV_VAL.DELETE;
    L_TB_UPD_UDCN_UDE_VAL.DELETE;
    L_TB_ACC_ROW_ID.DELETE;
    L_TB_ACC_MIN_DT.DELETE;
    L_TB_BK_VALUE.DELETE;
    L_TB_AC_NO.DELETE;
    L_TB_UDCN_UDE.DELETE;
    L_TB_INS_DIARY.DELETE;
    L_TB_ACC_EFF_DT.DELETE;
    L_TY_TB_EFF_DT.DELETE;
    L_TB_PROCESSED_ACCS.DELETE;

    DEBUG.PR_DEBUG('CL', 'Returning true to calling function...');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERRORCODE := 'CL-REVN08;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDCN_FOR_ACCOUNT..');

      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);

      CLPKS_LOGGER.PR_LOG_EXCEPTION();

      ROLLBACK;

      L_TB_ACC_AFF.DELETE;
      L_TB_INS_UDCN_UDE_VALS.DELETE;
      L_TB_UPD_UDCN_ROW_ID.DELETE;
      L_TB_UPD_UDCN_UDE_RSLV_VAL.DELETE;
      L_TB_UPD_UDCN_UDE_VAL.DELETE;
      L_TB_ACC_ROW_ID.DELETE;
      L_TB_ACC_MIN_DT.DELETE;
      L_TB_BK_VALUE.DELETE;
      L_TB_AC_NO.DELETE;
      L_TB_UDCN_UDE.DELETE;
      L_TB_INS_DIARY.DELETE;
      L_TB_ACC_EFF_DT.DELETE;
      L_TY_TB_EFF_DT.DELETE;
      L_TB_PROCESSED_ACCS.DELETE;

      RETURN FALSE;

  END FN_PROCESS_UDCN;

  FUNCTION FN_PROCESS_CHGS_ENTRIES(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_VALUES.BRANCH_CODE%TYPE,
                                   P_ACC_NO      IN CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                                   P_ESN         IN CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
                                   P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                   P_ERRORPARAM  IN OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN AS

    L_TAB_CHGS    CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    L_REC_ACCOUNT CLPKSS_OBJECT.TY_REC_ACCOUNT;

    LTABCHGS       CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    LTABENTRIES    CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES;
    LSCHROWIDTAB   CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;
    LSCHSETLAMTTAB DBMS_SQL.NUMBER_TABLE;

    LTABSCHUPD   CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    LTABCHGSHIST CLPKSS_ELEMENT_TYPES.TY_TB_ACC_SCH_HISTORY;

    LACCNOTAB        DBMS_SQL.VARCHAR2_TABLE;
    LBRNTAB          DBMS_SQL.VARCHAR2_TABLE;
    LCMPNMTAB        DBMS_SQL.VARCHAR2_TABLE;
    LFRMNMTAB        DBMS_SQL.VARCHAR2_TABLE;
    LSCHTPTAB        DBMS_SQL.VARCHAR2_TABLE;
    LSCTSTDTTAB      DBMS_SQL.DATE_TABLE;
    LSCTDUDTTAB      DBMS_SQL.DATE_TABLE;
    L_TB_AMT_SETTLED DBMS_SQL.NUMBER_TABLE;

  BEGIN

    IF NOT CLPKS_OBJECT.FN_CREATE_ACCT_OBJECT(P_ACC_NO,
                                              P_BRANCH_CODE,
                                              L_REC_ACCOUNT,
                                              P_ERRORCODE,
                                              P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL',
                     'Failed in creating account pbject:: ' || P_ERRORCODE);
      RETURN FALSE;
    END IF;

    IF NOT CLPKSS_CHARGES.FN_PROCESS_CHARGES(L_REC_ACCOUNT,
                                             'REVN',
                                             GLOBAL.APPLICATION_DATE,
                                             P_ESN,
                                             'S',
                                             L_TAB_CHGS,
                                             P_ERRORCODE,
                                             P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL',
                     ' Failed to process charges ::' || P_ERRORCODE || '~' ||
                     P_ERRORPARAM);
      RETURN FALSE;

    END IF;

    IF NOT CLPKSS_CHARGES.FN_CHG_EVENT_ENTRIES(L_REC_ACCOUNT,
                                               'REVN',
                                               GLOBAL.APPLICATION_DATE,
                                               NULL,
                                               NULL,
                                               LTABCHGS,
                                               LTABENTRIES,
                                               LSCHROWIDTAB,
                                               LTABSCHUPD,
                                               P_ERRORCODE,
                                               P_ERRORPARAM) THEN
      DEBUG.PR_DEBUG('CL',
                     'Error in the function clpks_charges.fn_chg_event_entries');
      RETURN FALSE;
    END IF;

    IF LTABENTRIES.COUNT > 0 THEN

      IF NOT CLPKSS_ACCOUNTING.FN_FRAME_EVENT_ENTRIES(L_REC_ACCOUNT,
                                                      'REVN',
                                                      NULL,
                                                      LTABENTRIES,
                                                      P_ERRORCODE,
                                                      P_ERRORPARAM) THEN
        DBG('Failed in frame event entries ::' || P_ERRORCODE);
        RETURN FALSE;
      END IF;
      IF NOT CLPKSS_ACCOUNTING.FN_STORE_EVENT_ENTRIES(LTABENTRIES,
                                                      'B',
                                                      P_ERRORCODE,
                                                      P_ERRORPARAM) THEN
        DBG('Failed in store event entries ::' || P_ERRORCODE);
        RETURN FALSE;
      END IF;
      DBG('Trhu with store event entries !!!');

    END IF;

    IF LTABCHGS.COUNT > 0 THEN
      FORALL ZZ IN LTABCHGS.FIRST .. LTABCHGS.LAST SAVE EXCEPTIONS
        INSERT INTO CLTBS_ACCOUNT_SCHEDULES VALUES LTABCHGS (ZZ);

    END IF;

    IF LSCHROWIDTAB.COUNT > 0 THEN

      FOR ZZ IN LTABSCHUPD.FIRST .. LTABSCHUPD.LAST LOOP
        LACCNOTAB(ZZ) := LTABSCHUPD(ZZ).ACCOUNT_NUMBER;
        LBRNTAB(ZZ) := LTABSCHUPD(ZZ).BRANCH_CODE;
        LCMPNMTAB(ZZ) := LTABSCHUPD(ZZ).COMPONENT_NAME;
        LFRMNMTAB(ZZ) := LTABSCHUPD(ZZ).FORMULA_NAME;
        LSCHTPTAB(ZZ) := LTABSCHUPD(ZZ).SCHEDULE_TYPE;
        LSCTSTDTTAB(ZZ) := LTABSCHUPD(ZZ).SCHEDULE_ST_DATE;
        LSCTDUDTTAB(ZZ) := LTABSCHUPD(ZZ).SCHEDULE_DUE_DATE;
        L_TB_AMT_SETTLED(ZZ) := LTABSCHUPD(ZZ).AMOUNT_SETTLED;

      END LOOP;

      FORALL ZZ IN LSCHROWIDTAB.FIRST .. LSCHROWIDTAB.LAST SAVE EXCEPTIONS
        UPDATE CLTBS_ACCOUNT_SCHEDULES

           SET AMOUNT_SETTLED = LSCHSETLAMTTAB(ZZ)

         WHERE ROWID = LSCHROWIDTAB(ZZ);

    END IF;

    DEBUG.PR_DEBUG('CL', 'Thru with REVN processing');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      ROLLBACK;

      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      P_ERRORCODE := 'CL-REVN10;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_RATE_REVISION..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);
      LTABENTRIES.DELETE;
      RETURN FALSE;
  END FN_PROCESS_CHGS_ENTRIES;

  FUNCTION FN_PROCESS_CHARGE(P_ACCOUNT_OBJ  IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                             P_ESN          IN CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE,
                             P_TB_CHARGES   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES,
                             P_TB_ENTRIES   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES,
                             P_TB_SCH_ROWID IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_ROWID,
                             P_TB_SCH_ROW   IN OUT NOCOPY CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES,
                             P_ERROR_CODE   IN OUT VARCHAR2,
                             P_ERROR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_TAB_CHGS     CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    LTABCHGS       CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;
    LTABENTRIES    CLPKSS_ELEMENT_TYPES.TY_TB_EVENT_ENTRIES;
    LSCHROWIDTAB   CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;
    LSCHSETLAMTTAB DBMS_SQL.NUMBER_TABLE;

    LTABSCHUPD CLPKSS_ELEMENT_TYPES.TY_TB_SCHEDULES;

    PROCEDURE PR_CLEAR IS
    BEGIN
      L_TAB_CHGS.DELETE;
      LTABCHGS.DELETE;
      LTABENTRIES.DELETE;
      LSCHROWIDTAB.DELETE;
      LSCHSETLAMTTAB.DELETE;
      LTABSCHUPD.DELETE;
    END PR_CLEAR;

  BEGIN

    DBG('Start of fn_process_charge, Account ::' ||
        P_ACCOUNT_OBJ.ACCOUNT_DET.ACCOUNT_NUMBER || ' Esn ::' || P_ESN);

    IF NOT CLPKSS_CHARGES.FN_PROCESS_CHARGES(P_ACCOUNT_OBJ,
                                             CLPKSS_NLS.REVN,
                                             GLOBAL.APPLICATION_DATE,
                                             P_ESN,
                                             'S',
                                             L_TAB_CHGS,
                                             P_ERROR_CODE,
                                             P_ERROR_PARAM) THEN
      DBG(' Failed to process charges ::' || P_ERROR_CODE || ':' ||
          P_ERROR_PARAM);
      PR_CLEAR;
      RETURN FALSE;
    END IF;

    IF NOT CLPKSS_CHARGES.FN_CHG_EVENT_ENTRIES(P_ACCOUNT_OBJ,
                                               CLPKSS_NLS.REVN,
                                               GLOBAL.APPLICATION_DATE,
                                               NULL,
                                               NULL,
                                               LTABCHGS,
                                               LTABENTRIES,
                                               LSCHROWIDTAB,
                                               LTABSCHUPD,
                                               P_ERROR_CODE,
                                               P_ERROR_PARAM) THEN
      DBG('Error in the function clpks_charges.fn_chg_event_entries');
      PR_CLEAR;
      RETURN FALSE;
    END IF;

    IF LTABENTRIES.COUNT > 0 THEN

      IF NOT CLPKSS_ACCOUNTING.FN_FRAME_EVENT_ENTRIES(P_ACCOUNT_OBJ,
                                                      CLPKSS_NLS.REVN,
                                                      NULL,
                                                      LTABENTRIES,
                                                      P_ERROR_CODE,
                                                      P_ERROR_PARAM) THEN
        DBG('Failed in frame event entries ::' || P_ERROR_CODE);
        PR_CLEAR;
        RETURN FALSE;
      END IF;

    END IF;

    P_TB_CHARGES   := LTABCHGS;
    P_TB_ENTRIES   := LTABENTRIES;
    P_TB_SCH_ROWID := LSCHROWIDTAB;
    P_TB_SCH_ROW   := LTABSCHUPD;

    DBG('Thru with REVN processing');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      ROLLBACK;
      P_ERROR_CODE := 'CL-REVN10;';
      OVPKSS.PR_APPENDTBL(P_ERROR_CODE, '');
      DBG('BOMBED in FN_RATE_REVISION..');
      DBG('SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DBG('SQLCODE: ' || SQLCODE);
      PR_CLEAR;
      RETURN FALSE;
  END FN_PROCESS_CHARGE;

  FUNCTION FN_UDE_CASCADE(P_ACC_NO      IN CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE,
                          P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_VALUES.BRANCH_CODE%TYPE,
                          L_TB_UDCN_UDE IN OUT NOCOPY TY_TB_UDCN_UDE,

                          L_ACC_AFF_FLAG             OUT BOOLEAN,
                          P_CAS_MAS_EFF_DT           IN CLTBS_ACCOUNT_UDE_VALUES.EFFECTIVE_DATE%TYPE,
                          L_TB_UPD_UDCN_UDE_VAL      IN OUT NOCOPY TY_TB_UPD_UDCN_UDE_VAL,
                          L_TB_UPD_UDCN_UDE_RSLV_VAL IN OUT NOCOPY TY_TB_UPD_UDCN_UDE_RSLV_VAL,
                          L_TB_UPD_UDCN_ROW_ID       IN OUT NOCOPY TY_TB_UPD_UDCN_ROW_ID,
                          L_TB_INS_UDCN_UDE_VALS     IN OUT NOCOPY TY_TB_INS_UDCN_UDE_VALS,

                          L_TY_TB_EFF_DT IN OUT NOCOPY TY_TB_EFF_DT,

                          P_ERRORCODE IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS

    L_CHANGE             NUMBER;
    L_UPD_CNT            PLS_INTEGER;
    L_INS_CNT            PLS_INTEGER;
    L_UDE_ID_IDX         CLTBS_ACCOUNT_UDE_VALUES.UDE_ID%TYPE;
    P_HSH_CAS_MAS_EFF_DT PLS_INTEGER;
    L_PREV_EFF_DT        PLS_INTEGER;

    L_REC_ACC_MAS    CLTB_ACCOUNT_MASTER%ROWTYPE;
    L_TB_PRODUCT_UDE CLTM_PRODUCT_UDE%ROWTYPE;
    L_PRODUCT_CD     CLTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_ACCOUNT_NUM    CLTBS_ACCOUNT_UDE_VALUES.ACCOUNT_NUMBER%TYPE;

    L_EFF_COUNT PLS_INTEGER := 0;
    L_INT_COUNT PLS_INTEGER;
  BEGIN
    DEBUG.PR_DEBUG('CL', 'P_CAS_MAS_EFF_DT..' || P_CAS_MAS_EFF_DT);

    L_ACCOUNT_NUM := P_ACC_NO;
    L_REC_ACC_MAS := CLPKSS_CACHE.FN_ACCOUNT_MASTER(L_ACCOUNT_NUM,
                                                    P_BRANCH_CODE);
    L_PRODUCT_CD  := L_REC_ACC_MAS.PRODUCT_CODE;

    P_HSH_CAS_MAS_EFF_DT := CLPKS_UTIL.FN_HASH_DATE(P_CAS_MAS_EFF_DT);
    L_UPD_CNT            := L_TB_UPD_UDCN_UDE_VAL.COUNT + 1;
    L_INS_CNT            := L_TB_INS_UDCN_UDE_VALS.COUNT + 1;
    L_UDE_ID_IDX         := L_TB_UDCN_UDE.FIRST;
    G_UDE_CALC_REQD      := FALSE;
    WHILE L_UDE_ID_IDX IS NOT NULL LOOP
      DEBUG.PR_DEBUG('CL', 'B4 UPDATE....');

      L_INT_COUNT := 0;
      BEGIN
        SELECT 1
          INTO L_INT_COUNT
          FROM CLTM_PRODUCT_COMPONENTS
         WHERE PRODUCT_CODE = L_PRODUCT_CD
           AND COMPONENT_NAME IN
               (SELECT COMPONENT_NAME
                  FROM CLTM_PRODUCT_COMP_FRM_ELEMS
                 WHERE PRODUCT_CODE = L_PRODUCT_CD
                   AND ELEM_TYPE = 'U'
                   AND ELEM_ID = L_UDE_ID_IDX)
           AND COMPONENT_TYPE = 'I'
           AND ROWNUM < 2;
      EXCEPTION
        WHEN OTHERS THEN
          L_INT_COUNT := 0;
      END;
      IF L_INT_COUNT > 0 AND
         P_CAS_MAS_EFF_DT <= L_REC_ACC_MAS.MATURITY_DATE THEN
        G_UDE_CALC_REQD := TRUE;
      END IF;

      IF L_TB_UDCN_UDE(L_UDE_ID_IDX)
       .G_TB_UDE_VALS.EXISTS(P_HSH_CAS_MAS_EFF_DT) THEN
        IF L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
         .OLD_VAL IS NULL OR L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
           .OLD_VAL = L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
           .UDE_VALUE

         THEN
          DEBUG.PR_DEBUG('CL', 'INTO UPDATE....');
          L_TB_UPD_UDCN_UDE_VAL(L_UPD_CNT) := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
                                              .NEW_VAL;

          L_CHANGE := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
                      .RESOLVED_VALUE - L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
                      .UDE_VALUE;

          L_TB_UPD_UDCN_UDE_RSLV_VAL(L_UPD_CNT) := NVL(L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
                                                       .NEW_VAL,
                                                       0) +
                                                   NVL(L_CHANGE, 0);

          L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(L_PRODUCT_CD,
                                                          L_UDE_ID_IDX);
          IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
             NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
             NVL(L_TB_UPD_UDCN_UDE_RSLV_VAL(L_UPD_CNT), 0) > 0 THEN
            IF (NVL(L_TB_UPD_UDCN_UDE_RSLV_VAL(L_UPD_CNT), 0) <
               NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
               (NVL(L_TB_UPD_UDCN_UDE_RSLV_VAL(L_UPD_CNT), 0) >
               NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
              DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');
              P_ERRORCODE := 'CL-UDE09;';
              OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');
              RETURN FALSE;
            END IF;
          END IF;

          L_TB_UPD_UDCN_ROW_ID(L_UPD_CNT) := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(P_HSH_CAS_MAS_EFF_DT)
                                             .UDE_ROWID;

          L_UPD_CNT      := L_UPD_CNT + 1;
          L_ACC_AFF_FLAG := TRUE;
          DEBUG.PR_DEBUG('CL', 'ONE RECORD UPDATED');
        END IF;
      ELSE

        L_PREV_EFF_DT := L_TB_UDCN_UDE(L_UDE_ID_IDX)
                         .G_TB_UDE_VALS.PRIOR(P_HSH_CAS_MAS_EFF_DT);

        IF L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS.EXISTS(L_PREV_EFF_DT) AND
            (L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
             .OLD_VAL IS NULL OR L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
             .OLD_VAL = L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
             .UDE_VALUE)

         THEN

          DEBUG.PR_DEBUG('CL', 'INTO INSERT....');

          DEBUG.PR_DEBUG('CL', '$$$$$$ABOUT TO CHECK FOR THE IDX..');

          BEGIN
            L_EFF_COUNT := 0;
            SELECT 1
              INTO L_EFF_COUNT
              FROM CLTB_ACCOUNT_UDE_EFF_DATES
             WHERE ACCOUNT_NUMBER = P_ACC_NO
               AND BRANCH_CODE = P_BRANCH_CODE
               AND EFFECTIVE_DATE = P_CAS_MAS_EFF_DT;
          EXCEPTION
            WHEN OTHERS THEN
              L_EFF_COUNT := 0;
          END;

          IF L_EFF_COUNT = 0 THEN

            IF NOT L_TY_TB_EFF_DT.EXISTS(P_ACC_NO || P_BRANCH_CODE ||
                                         P_HSH_CAS_MAS_EFF_DT) THEN
              DEBUG.PR_DEBUG('CL',
                             '$$$ONE RECORD TO BE INSERTED INTO CLTB_aCCOUNT_EFF_DATES');
              L_TY_TB_EFF_DT(P_ACC_NO || P_BRANCH_CODE || P_HSH_CAS_MAS_EFF_DT).ACCOUNT_NUMBER := P_ACC_NO;
              L_TY_TB_EFF_DT(P_ACC_NO || P_BRANCH_CODE || P_HSH_CAS_MAS_EFF_DT).BRANCH_CODE := P_BRANCH_CODE;
              L_TY_TB_EFF_DT(P_ACC_NO || P_BRANCH_CODE || P_HSH_CAS_MAS_EFF_DT).EFFECTIVE_DATE := P_CAS_MAS_EFF_DT;
            END IF;
          END IF;

          DEBUG.PR_DEBUG('CL',
                         '$$$$L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT).new_VAL ' || L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                         .NEW_VAL);

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).UDE_VALUE := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                                                         .NEW_VAL;

          DEBUG.PR_DEBUG('CL',
                         'l_tb_udcn_ude(l_ude_id_idx).g_tb_ude_vals(L_PREV_EFF_DT).resolved_value ' || L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                         .RESOLVED_VALUE);
          DEBUG.PR_DEBUG('CL',
                         'l_tb_udcn_ude(l_ude_id_idx).g_tb_ude_vals(L_PREV_EFF_DT).ude_value ' || L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                         .UDE_VALUE);

          L_CHANGE := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                      .RESOLVED_VALUE - L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                      .UDE_VALUE;

          DEBUG.PR_DEBUG('CL', '$$$$L_CHANGE ' || L_CHANGE);
          DEBUG.PR_DEBUG('CL',
                         'l_tb_udcn_ude(l_ude_id_idx).g_tb_ude_vals(L_PREV_EFF_DT).new_val ' || L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                         .NEW_VAL);

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RESOLVED_VALUE := NVL(L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                                                                  .NEW_VAL,
                                                                  0) +
                                                              NVL(L_CHANGE,
                                                                  0);

          L_TB_PRODUCT_UDE := CLPKSS_CACHE.FN_PRODUCT_UDE(L_PRODUCT_CD,
                                                          L_UDE_ID_IDX);
          IF (NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0) > 0 OR
             NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0) > 0) AND
             NVL(L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RESOLVED_VALUE, 0) > 0 THEN
            IF (NVL(L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RESOLVED_VALUE, 0) <
               NVL(L_TB_PRODUCT_UDE.MIN_UDE_VAL, 0)) OR
               (NVL(L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RESOLVED_VALUE, 0) >
               NVL(L_TB_PRODUCT_UDE.MAX_UDE_VAL, 0)) THEN
              DBG('The resolved UDE value must be within the min and max UDE value maintained for the Product');
              P_ERRORCODE := 'CL-UDE09;';
              OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');
              RETURN FALSE;
            END IF;
          END IF;

          DEBUG.PR_DEBUG('CL',
                         '$$$$L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RESOLVED_VALUE ' || L_TB_INS_UDCN_UDE_VALS(L_INS_CNT)
                         .RESOLVED_VALUE);

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).EFFECTIVE_DATE := P_CAS_MAS_EFF_DT;

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).RATE_CODE := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                                                         .RATE_CODE;

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).ACCOUNT_NUMBER := P_ACC_NO;
          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).BRANCH_CODE := P_BRANCH_CODE;
          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).UDE_ID := L_UDE_ID_IDX;

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).MAINT_RSLV_FLAG := 'M';

          L_TB_INS_UDCN_UDE_VALS(L_INS_CNT).CODE_USAGE := L_TB_UDCN_UDE(L_UDE_ID_IDX).G_TB_UDE_VALS(L_PREV_EFF_DT)
                                                          .CODE_USAGE;

          L_INS_CNT      := L_INS_CNT + 1;
          L_ACC_AFF_FLAG := TRUE;

          DEBUG.PR_DEBUG('CL',
                         'inserted record for effective date..' ||
                         P_CAS_MAS_EFF_DT);
          DEBUG.PR_DEBUG('CL', 'ONE RECORD INSERTED...');
        END IF;
      END IF;

      L_UDE_ID_IDX := L_TB_UDCN_UDE.NEXT(L_UDE_ID_IDX);
    END LOOP;

    DEBUG.PR_DEBUG('CL', 'RETURNING TRUE FROM FN_UDE_CASCADE');

    RETURN TRUE;
  EXCEPTION

    WHEN OTHERS THEN
      P_ERRORCODE := 'CL-REVN08;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'BOMBED in FN_UDE_CASCADE..');
      DEBUG.PR_DEBUG('CL', 'SQLERRM: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'SQLCODE: ' || SQLCODE);
      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      RETURN FALSE;
  END FN_UDE_CASCADE;

  FUNCTION FN_UDE_UPDATE(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                         P_PROC_DATE   IN DATE,
                         P_PROCESS_NO  IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                         P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                         P_ERRORPARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS

    CURSOR C_ACCOUNT(P_PRODUCT_CODE CLTBS_PROD_UDE_CASCADE.PRODUCT_CODE%TYPE,
                     P_UDE_ID       CLTBS_PROD_UDE_CASCADE.UDE_ID%TYPE) IS
      SELECT A.ACCOUNT_NUMBER
        FROM CLTB_ACCOUNT_MASTER A
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.ACCOUNT_STATUS IN ('A', 'Y')
         AND A.PROCESS_NO = NVL(P_PROCESS_NO, A.PROCESS_NO)
         AND A.PRODUCT_CODE = P_PRODUCT_CODE
         AND A.MODULE_CODE =
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
         AND NOT EXISTS (SELECT 1
                FROM CLTBS_ACCOUNT_UDE_VALUES C
               WHERE C.BRANCH_CODE = P_BRANCH_CODE
                 AND C.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                 AND C.UDE_ID = P_UDE_ID);

    TYPE TYP_PROD_UDE_CASCADE IS TABLE OF CLTBS_PROD_UDE_CASCADE%ROWTYPE INDEX BY PLS_INTEGER;

    TBL_PROD_UDE_CASCADE TYP_PROD_UDE_CASCADE;
    TBL_ACCOUNT_NUMBER   DBMS_SQL.VARCHAR2_TABLE;

    L_COMMIT_FREQ PLS_INTEGER;
    L_NO_ERRORS   PLS_INTEGER;
    L_LOOP        BOOLEAN := FALSE;
    L_ERR_IDX     PLS_INTEGER;

    L_REMAINING_ACCOUNTS PLS_INTEGER := 0;

  BEGIN

    L_COMMIT_FREQ := NVL(CLPKSS_BATCH.G_COMMIT_FREQ, 500);

    FOR EACH_REC IN (SELECT *
                       FROM CLTBS_PROD_UDE_CASCADE
                      WHERE BRANCH_CODE = P_BRANCH_CODE
                        AND PROCESSED = 'N'
                      ORDER BY PRODUCT_CODE, UDE_ID) LOOP
      TBL_PROD_UDE_CASCADE(TBL_PROD_UDE_CASCADE.COUNT + 1) := EACH_REC;
    END LOOP;

    IF TBL_PROD_UDE_CASCADE.COUNT > 0 THEN

      FOR J IN TBL_PROD_UDE_CASCADE.FIRST .. TBL_PROD_UDE_CASCADE.LAST LOOP

        FOR EACH_REC IN (SELECT DISTINCT UDE_RULE_CODE, CCY_CODE
                           FROM CLTMS_PRODUCT_UDE_RULES
                          WHERE PRODUCT_CODE = TBL_PROD_UDE_CASCADE(J)
                               .PRODUCT_CODE) LOOP

          BEGIN
            INSERT INTO CLTMS_PRODUCT_UDE_DATES
              (PRODUCT_CODE, UDE_RULE_CODE, UDE_EFF_DT, CCY_CODE)
            VALUES
              (TBL_PROD_UDE_CASCADE(J).PRODUCT_CODE,
               EACH_REC.UDE_RULE_CODE,
               P_PROC_DATE,
               EACH_REC.CCY_CODE);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              NULL;
          END;

          BEGIN
            INSERT INTO CLTMS_PRODUCT_UDE_VALUES
              (PRODUCT_CODE,
               UDE_RULE_CODE,
               UDE_EFF_DT,
               UDE_ID,
               UDE_VALUE,
               RATE_CODE,
               CODE_USAGE,
               CASCADE,
               CCY_CODE)
            VALUES
              (TBL_PROD_UDE_CASCADE  (J).PRODUCT_CODE,
               EACH_REC.UDE_RULE_CODE,
               P_PROC_DATE,
               TBL_PROD_UDE_CASCADE  (J).UDE_ID,
               0,
               NULL,
               'A',
               'Y',
               EACH_REC.CCY_CODE);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              NULL;
          END;

        END LOOP;

      END LOOP;

    END IF;

    DEBUG.PR_DEBUG('CL', 'Before Debug in fn_ude_update');
    COMMIT;

    IF TBL_PROD_UDE_CASCADE.COUNT > 0 THEN

      FOR I IN TBL_PROD_UDE_CASCADE.FIRST .. TBL_PROD_UDE_CASCADE.LAST LOOP

        L_LOOP := TRUE;

        WHILE L_LOOP LOOP

          TBL_ACCOUNT_NUMBER.DELETE;

          IF C_ACCOUNT%ISOPEN THEN
            CLOSE C_ACCOUNT;
          END IF;

          OPEN C_ACCOUNT(TBL_PROD_UDE_CASCADE(I).PRODUCT_CODE,
                         TBL_PROD_UDE_CASCADE(I).UDE_ID);
          FETCH C_ACCOUNT BULK COLLECT
            INTO TBL_ACCOUNT_NUMBER LIMIT L_COMMIT_FREQ;
          CLOSE C_ACCOUNT;

          IF TBL_ACCOUNT_NUMBER.COUNT > 0 THEN
            BEGIN
              FORALL J IN TBL_ACCOUNT_NUMBER.FIRST .. TBL_ACCOUNT_NUMBER.LAST
                INSERT INTO CLTBS_ACCOUNT_UDE_EFF_DATES
                  (ACCOUNT_NUMBER, BRANCH_CODE, EFFECTIVE_DATE)
                VALUES
                  (TBL_ACCOUNT_NUMBER(J), P_BRANCH_CODE, P_PROC_DATE);
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            BEGIN
              FORALL J IN TBL_ACCOUNT_NUMBER.FIRST .. TBL_ACCOUNT_NUMBER.LAST SAVE
                                                      EXCEPTIONS
                INSERT INTO CLTBS_ACCOUNT_UDE_VALUES
                  (ACCOUNT_NUMBER,
                   BRANCH_CODE,
                   EFFECTIVE_DATE,
                   UDE_ID,
                   UDE_VALUE,
                   RATE_CODE,
                   CODE_USAGE,
                   MAINT_RSLV_FLAG,
                   RESOLVED_VALUE)
                VALUES
                  (TBL_ACCOUNT_NUMBER(J),
                   P_BRANCH_CODE,
                   P_PROC_DATE,
                   TBL_PROD_UDE_CASCADE(I).UDE_ID,
                   0,
                   NULL,
                   'A',
                   'M',
                   0);
            EXCEPTION
              WHEN OTHERS THEN
                L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;

                DEBUG.PR_DEBUG('CL',
                               'Error Raised Here at Inserting Account UDE Values');
                FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
                  L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;

                  CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                               P_BRANCH_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               'UDEGC',
                                               'error :' || L_IDX ||
                                               '  position = ' || L_ERR_IDX ||
                                               ' -- error_code = ' ||
                                               SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                       .ERROR_CODE));
                END LOOP;
            END;

            DEBUG.PR_DEBUG('CL', 'Before Debug in fn_ude_update-2');
            COMMIT;
          ELSE
            L_LOOP := FALSE;
          END IF;

        END LOOP;

        L_REMAINING_ACCOUNTS := 0;

        BEGIN
          SELECT 1
            INTO L_REMAINING_ACCOUNTS
            FROM CLTBS_ACCOUNT_MASTER A
           WHERE A.BRANCH_CODE = P_BRANCH_CODE
             AND A.ACCOUNT_STATUS IN ('A', 'Y')
             AND A.PRODUCT_CODE = TBL_PROD_UDE_CASCADE(I).PRODUCT_CODE
             AND NOT EXISTS
           (SELECT 1
                    FROM CLTBS_ACCOUNT_UDE_VALUES C
                   WHERE C.BRANCH_CODE = P_BRANCH_CODE
                     AND C.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
                     AND C.UDE_ID = TBL_PROD_UDE_CASCADE(I).UDE_ID)
             AND ROWNUM < 2;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_REMAINING_ACCOUNTS := 0;
        END;

        IF L_REMAINING_ACCOUNTS = 0 THEN
          UPDATE CLTBS_PROD_UDE_CASCADE
             SET PROCESSED = 'Y'
           WHERE PRODUCT_CODE = TBL_PROD_UDE_CASCADE(I).PRODUCT_CODE
             AND UDE_ID = TBL_PROD_UDE_CASCADE(I).UDE_ID;
        END IF;

        DEBUG.PR_DEBUG('CL', 'Before Debug in fn_ude_update-3');
        COMMIT;

      END LOOP;

    END IF;

    TBL_PROD_UDE_CASCADE.DELETE;
    TBL_ACCOUNT_NUMBER.DELETE;

    DEBUG.PR_DEBUG('CL', 'Before Debug in fn_ude_update-4');
    COMMIT;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;

      TBL_PROD_UDE_CASCADE.DELETE;
      TBL_ACCOUNT_NUMBER.DELETE;

      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      P_ERRORCODE := 'CL-REVN11;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'bombed in fn_ude_update..');
      DEBUG.PR_DEBUG('CL', 'sqlerrm: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'sqlcode: ' || SQLCODE);

      DEBUG.PR_DEBUG('CL', 'Before Debug in fn_ude_update-5');

      COMMIT;
      RETURN FALSE;
  END FN_UDE_UPDATE;

  FUNCTION FN_UDE_UPDATE_FOR_ACCOUNT(P_BRANCH_CODE IN CLTBS_ACCOUNT_UDE_EFF_DATES.BRANCH_CODE%TYPE,
                                     P_ACC_NO      IN CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                     P_PROC_DATE   IN DATE,
                                     P_ERRORCODE   IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                     P_ERRORPARAM  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    TYPE TYP_PROD_UDE_CASCADE IS TABLE OF CLTBS_PROD_UDE_CASCADE%ROWTYPE INDEX BY PLS_INTEGER;

    TBL_PROD_UDE_CASCADE TYP_PROD_UDE_CASCADE;
    L_PRODUCT            CLTMS_PRODUCT.PRODUCT_CODE%TYPE;

  BEGIN

    DBG('$$$$p_acc_no ' || P_ACC_NO);

    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PRODUCT
        FROM CLTBS_ACCOUNT_MASTER
       WHERE ACCOUNT_NUMBER = P_ACC_NO
         AND BRANCH_CODE = P_BRANCH_CODE
         AND ACCOUNT_STATUS = 'A';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN

        RETURN TRUE;

    END;

    FOR EACH_REC IN (SELECT *
                       FROM CLTBS_PROD_UDE_CASCADE
                      WHERE PRODUCT_CODE = L_PRODUCT
                        AND BRANCH_CODE = P_BRANCH_CODE
                        AND PROCESSED = 'N'
                      ORDER BY UDE_ID) LOOP
      TBL_PROD_UDE_CASCADE(TBL_PROD_UDE_CASCADE.COUNT + 1) := EACH_REC;
    END LOOP;

    IF TBL_PROD_UDE_CASCADE.COUNT > 0 THEN

      FOR J IN TBL_PROD_UDE_CASCADE.FIRST .. TBL_PROD_UDE_CASCADE.LAST LOOP

        FOR EACH_REC IN (SELECT DISTINCT UDE_RULE_CODE, CCY_CODE
                           FROM CLTMS_PRODUCT_UDE_RULES
                          WHERE PRODUCT_CODE = TBL_PROD_UDE_CASCADE(J)
                               .PRODUCT_CODE) LOOP

          BEGIN
            INSERT INTO CLTMS_PRODUCT_UDE_DATES
              (PRODUCT_CODE, UDE_RULE_CODE, UDE_EFF_DT, CCY_CODE)
            VALUES
              (TBL_PROD_UDE_CASCADE(J).PRODUCT_CODE,
               EACH_REC.UDE_RULE_CODE,
               P_PROC_DATE,
               EACH_REC.CCY_CODE);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              NULL;
          END;

          BEGIN
            INSERT INTO CLTMS_PRODUCT_UDE_VALUES
              (PRODUCT_CODE,
               UDE_RULE_CODE,
               UDE_EFF_DT,
               UDE_ID,
               UDE_VALUE,
               RATE_CODE,
               CODE_USAGE,
               CASCADE,
               CCY_CODE)
            VALUES
              (TBL_PROD_UDE_CASCADE  (J).PRODUCT_CODE,
               EACH_REC.UDE_RULE_CODE,
               P_PROC_DATE,
               TBL_PROD_UDE_CASCADE  (J).UDE_ID,
               0,
               NULL,
               'A',
               'Y',
               EACH_REC.CCY_CODE);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              NULL;
          END;

        END LOOP;

      END LOOP;

    END IF;

    IF TBL_PROD_UDE_CASCADE.COUNT > 0 THEN

      FOR I IN TBL_PROD_UDE_CASCADE.FIRST .. TBL_PROD_UDE_CASCADE.LAST LOOP

        BEGIN
          INSERT INTO CLTBS_ACCOUNT_UDE_EFF_DATES
            (ACCOUNT_NUMBER, BRANCH_CODE, EFFECTIVE_DATE)
          VALUES
            (P_ACC_NO, P_BRANCH_CODE, P_PROC_DATE);
        EXCEPTION

          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CL', 'bombed in fn_ude_update..for account');
            DEBUG.PR_DEBUG('CL', 'sqlerrm: ' || SUBSTR(SQLERRM, 1, 250));
            DEBUG.PR_DEBUG('CL', 'sqlcode: ' || SQLCODE);
            P_ERRORCODE := 'CL-REVN11;';
            OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');
            RETURN FALSE;
        END;

        BEGIN
          INSERT INTO CLTBS_ACCOUNT_UDE_VALUES
            (ACCOUNT_NUMBER,
             BRANCH_CODE,
             EFFECTIVE_DATE,
             UDE_ID,
             UDE_VALUE,
             RATE_CODE,
             CODE_USAGE,
             MAINT_RSLV_FLAG,
             RESOLVED_VALUE)
          VALUES
            (P_ACC_NO,
             P_BRANCH_CODE,
             P_PROC_DATE,
             TBL_PROD_UDE_CASCADE(I).UDE_ID,
             0,
             NULL,
             'A',
             'M',
             0);
        EXCEPTION

          WHEN DUP_VAL_ON_INDEX THEN
            NULL;

          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('CL', 'bombed in fn_ude_update..for account');
            DEBUG.PR_DEBUG('CL', 'sqlerrm: ' || SUBSTR(SQLERRM, 1, 250));
            DEBUG.PR_DEBUG('CL', 'sqlcode: ' || SQLCODE);
            P_ERRORCODE := 'CL-REVN11;';
            OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');
            RETURN FALSE;

        END;
      END LOOP;
    END IF;

    TBL_PROD_UDE_CASCADE.DELETE;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      TBL_PROD_UDE_CASCADE.DELETE;
      CLPKSS_LOGGER.PR_LOG_EXCEPTION;
      P_ERRORCODE := 'CL-REVN11;';
      OVPKSS.PR_APPENDTBL(P_ERRORCODE, '');

      DEBUG.PR_DEBUG('CL', 'bombed in fn_ude_update..');
      DEBUG.PR_DEBUG('CL', 'sqlerrm: ' || SUBSTR(SQLERRM, 1, 250));
      DEBUG.PR_DEBUG('CL', 'sqlcode: ' || SQLCODE);
      RETURN FALSE;
  END FN_UDE_UPDATE_FOR_ACCOUNT;

  FUNCTION FN_ADHOC_HOL_TREATMENT_REQD(P_PROD CLTMS_PRODUCT.PRODUCT_CODE%TYPE)
    RETURN VARCHAR2 IS
    L_PROD CLTMS_PRODUCT%ROWTYPE;
  BEGIN
    DBG('$$$$$$Product ' || P_PROD);
    L_PROD := CLPKSS_CACHE.FN_PRODUCT(P_PROD);

    DBG('$$$$$$$$$$l_prod.adhoc_hol_treatment_reqd ' ||
        L_PROD.ADHOC_HOL_TREATMENT_REQD);

    RETURN L_PROD.ADHOC_HOL_TREATMENT_REQD;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('$$$$$$$error ' || SUBSTR(SQLERRM, 1, 200));
      RETURN 'N';
  END FN_ADHOC_HOL_TREATMENT_REQD;

  FUNCTION FN_ADHOC_HOL_REV(P_PROD CLTMS_PRODUCT.PRODUCT_CODE%TYPE)
    RETURN VARCHAR2 IS
    L_PROD CLTMS_PRODUCT%ROWTYPE;
  BEGIN
    DBG('$$$$$$Product fn_adhoc_hol_rev ' || P_PROD);
    L_PROD := CLPKSS_CACHE.FN_PRODUCT(P_PROD);
    DBG('$$$$$$$$$$l_prod.adhoc_hol_treatment_reqd_rev ' ||
        L_PROD.ADHOC_HOLIDAY_REV);
    IF L_PROD.IGNORE_HOLIDAYS_REV = 'Y' OR
       L_PROD.CASCADE_SCEDULES_REV = 'Y' THEN
      L_PROD.ADHOC_HOLIDAY_REV := 'N';
    END IF;

    DBG('$$$$$$$$$$l_prod.adhoc_hol_treatment_reqd_rev ' ||
        L_PROD.ADHOC_HOLIDAY_REV);
    RETURN L_PROD.ADHOC_HOLIDAY_REV;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('$$$$$$$error ' || SQLERRM);
      RETURN 'N';
  END FN_ADHOC_HOL_REV;

  FUNCTION FN_LS_ADHOC_HOL_TREATMENT_REQD(P_ACC_NO   CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE,
                                          P_BRN_CODE CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE)
    RETURN VARCHAR2 IS
    L_ADHOC_HOL_TREATMENT_REQD CLTMS_PRODUCT.ADHOC_HOL_TREATMENT_REQD%TYPE := 'Y';

    L_ACC_NO   CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
    L_PRD_CODE CLTM_PRODUCT.PRODUCT_CODE%TYPE;

    L_ACC_MASTER     CLTBS_ACCOUNT_MASTER%ROWTYPE;
    L_ACC_NO         CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
    L_COUNT          NUMBER;
    L_HOL_DFLT_BASIS CLTMS_PRODUCT.HOLIDAY_DEFAULT_BASIS%TYPE;
    L_ADHL_COUNT     NUMBER;
    L_PROD           CLTMS_PRODUCT.PRODUCT_CODE%TYPE;
  BEGIN
    DBG('coming inside fn_ls_adhoc_hol_treatment_reqd');
    IF L_ACC_MASTER.MODULE_CODE = 'LS' THEN
      SELECT HOLIDAY_DEFAULT_BASIS
        INTO L_HOL_DFLT_BASIS
        FROM CLTM_PRODUCT
       WHERE PRODUCT_CODE = L_ACC_MASTER.PRODUCT_CODE;
      L_ADHL_COUNT := 0;

      DBG('l_hol_dflt_basis' || L_HOL_DFLT_BASIS);

      IF L_HOL_DFLT_BASIS = 'P' THEN

        SELECT COUNT(1)
          INTO L_ADHL_COUNT
          FROM CLTM_PRODUCT
         WHERE PRODUCT_CODE = L_ACC_MASTER.PRODUCT_CODE
           AND ADHOC_HOL_TREATMENT_REQD = 'Y';

      ELSIF L_HOL_DFLT_BASIS = 'T' THEN

        SELECT PRODUCT_CODE
          INTO L_PROD
          FROM CLTBS_ACCOUNT_MASTER
         WHERE ACCOUNT_NUMBER =
               (SELECT TRANCHE_REF_NO
                  FROM LSTB_ACCOUNT_MASTER
                 WHERE ACCOUNT_NUMBER = P_ACC_NO)
           AND BRANCH_CODE = P_BRN_CODE;

        SELECT COUNT(1)
          INTO L_ADHL_COUNT
          FROM CLTM_PRODUCT
         WHERE PRODUCT_CODE = L_PROD
           AND ADHOC_HOL_TREATMENT_REQD = 'Y';
      END IF;

      IF L_COUNT > 0 THEN
        L_ADHOC_HOL_TREATMENT_REQD := 'Y';
      ELSE
        L_ADHOC_HOL_TREATMENT_REQD := 'N';
      END IF;

      IF L_HOL_DFLT_BASIS = 'F' THEN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM LSTBS_SYNDICATION_PREFERENCE
         WHERE CONTRACT_REF_NO =
               (SELECT FACILITY_REF_NO
                  FROM LSTB_ACCOUNT_MASTER
                 WHERE ACCOUNT_NUMBER = P_ACC_NO)
           AND VERSION_NO =
               (SELECT MAX(VERSION_NO)
                  FROM LSTBS_SYNDICATION_PREFERENCE
                 WHERE CONTRACT_REF_NO =
                       (SELECT FACILITY_REF_NO
                          FROM LSTB_ACCOUNT_MASTER
                         WHERE ACCOUNT_NUMBER = P_ACC_NO))
           AND SCH_CONSIDER_BRANCH_HOLIDAY = 'Y';
        IF L_COUNT > 0 THEN
          L_ADHOC_HOL_TREATMENT_REQD := 'Y';
        END IF;
      END IF;
    END IF;
    DBG('$$$$$$$$$$l_adhoc_hol_treatment_reqd ' ||
        L_ADHOC_HOL_TREATMENT_REQD);

    RETURN L_ADHOC_HOL_TREATMENT_REQD;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('$$$$$$$error ' || SUBSTR(SQLERRM, 1, 200));
      RETURN 'N';
  END FN_LS_ADHOC_HOL_TREATMENT_REQD;

  FUNCTION FN_ADCH_HOLIDAY_FOR_BRANCH(P_BRANCH_CODE IN CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE,
                                      P_PROC_DATE   IN DATE,
                                      P_PROCESS_NO  IN CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                                      P_ERR_CODE    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                      P_ERR_PARAM   IN OUT VARCHAR2,
                                      P_COMMIT      IN VARCHAR2)

   RETURN BOOLEAN IS
    L_REVN_IDX PLS_INTEGER;
    CURSOR CUR_SCH IS
      SELECT DISTINCT A.ACCOUNT_NUMBER,
                      A.BRANCH_CODE,
                      A.PROCESS_NO

                     ,
                      A.PRODUCT_CODE,
                      A.MATURITY_DATE,
                      A.VALUE_DATE

                     ,
                      B.SCHEDULE_DUE_DATE,
                      'P' SCHEDULE_TYPE
        FROM CLTBS_ACCOUNT_MASTER    A,
             CLTBS_ACCOUNT_SCHEDULES B,
             CLTBS_ACCOUNT_HOLIDAY   H
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.PROCESS_NO = NVL(P_PROCESS_NO, A.PROCESS_NO)
         AND A.ACCOUNT_STATUS = 'A'
         AND B.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
         AND B.BRANCH_CODE = P_BRANCH_CODE
         AND H.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
         AND H.BRANCH_CODE = A.BRANCH_CODE
         AND B.SCHEDULE_DUE_DATE > P_PROC_DATE
         AND

             ((NVL(B.AMOUNT_DUE, -1) <> NVL(B.AMOUNT_SETTLED, -2)) OR
             (B.AMOUNT_DUE = 0 AND B.AMOUNT_SETTLED = 0))
         AND A.MODULE_CODE =
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
         AND EXISTS
       (SELECT 1
                FROM CLTBS_AFFECTED_HOLIDAYS C

               WHERE (C.BRANCH_CODE = P_BRANCH_CODE OR
                     C.BRANCH_CODE = H.HOLIDAY_CCY_SCH)
                 AND C.HOLIDAY_DATE = B.SCHEDULE_DUE_DATE)
         AND

             ((FN_ADHOC_HOL_TREATMENT_REQD(A.PRODUCT_CODE) = 'Y' AND
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL') IN
             ('CL', 'MO')) OR
             (FN_LS_ADHOC_HOL_TREATMENT_REQD(A.ACCOUNT_NUMBER,
                                              A.BRANCH_CODE) = 'Y' AND
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL') = 'LS'))

      UNION
      SELECT A.ACCOUNT_NUMBER,
             A.BRANCH_CODE,
             A.PROCESS_NO,
             A.PRODUCT_CODE,
             A.MATURITY_DATE,
             A.VALUE_DATE,
             B.SCHEDULE_DUE_DATE,
             'R' SCHEDULE_TYPE
        FROM CLTBS_ACCOUNT_MASTER  A,
             CLTBS_REVN_SCHEDULES  B,
             CLTBS_ACCOUNT_HOLIDAY H
       WHERE A.BRANCH_CODE = P_BRANCH_CODE
         AND A.PROCESS_NO = NVL(P_PROCESS_NO, A.PROCESS_NO)
         AND A.ACCOUNT_STATUS = 'A'
         AND B.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
         AND B.BRANCH_CODE = P_BRANCH_CODE
         AND H.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
         AND H.BRANCH_CODE = A.BRANCH_CODE
         AND B.SCHEDULE_DUE_DATE > P_PROC_DATE
         AND A.MODULE_CODE =
             NVL(GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE, 'CL')
         AND EXISTS
       (SELECT 1
                FROM CLTBS_AFFECTED_HOLIDAYS C
               WHERE (C.BRANCH_CODE = P_BRANCH_CODE OR
                     C.BRANCH_CODE = H.HOLIDAY_CCY_REV)
                 AND C.HOLIDAY_DATE = B.SCHEDULE_DUE_DATE)

       ORDER BY 1, 8, 7;

    TYPE TB_SCH IS TABLE OF CUR_SCH%ROWTYPE;
    L_TB_SCH TB_SCH;

    L_NEXT_WDAY     DATE;
    L_ACCOUNT_OBJ   CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_TMP_ACC_OBJ   CLPKSS_OBJECT.TY_REC_ACCOUNT;
    L_TB_CALC_DATES CLPKSS_RECALC.TY_TB_CALC_DATES;

    PIND  CLPKSS_SCHEDULES.TY_TB_INDICATOR;
    PDATE DATE;

    TYPE TY_TB_ACCOUNT IS TABLE OF CLTBS_ACCOUNT_MASTER%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_ACCOUNT TY_TB_ACCOUNT;

    TYPE TY_TB_ACCOUNT_HIST IS TABLE OF CLTBS_ACCOUNT_HISTORY%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_ACCOUNT_HIST TY_TB_ACCOUNT_HIST;

    L_TB_ROWID_UPD CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;

    TYPE TY_TB_ACCOUNT_COMP_SCH IS TABLE OF CLTBS_ACCOUNT_COMP_SCH%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_ACCOUNT_COMP_SCH TY_TB_ACCOUNT_COMP_SCH;

    TYPE TY_TB_ACCOUNT_COMP_BALANCES IS TABLE OF CLTBS_ACCOUNT_COMP_BALANCES%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_COMP_BALANCE TY_TB_ACCOUNT_COMP_BALANCES;

    TYPE TY_TB_AMOUNT_DUE IS TABLE OF CLTBS_ACCOUNT_SCHEDULES%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_AMOUNT_DUE TY_TB_AMOUNT_DUE;

    TYPE TY_TB_EVENTS_DIARY IS TABLE OF CLTBS_ACCOUNT_EVENTS_DIARY%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_EVENTS_DIARY TY_TB_EVENTS_DIARY;

    TYPE TY_TB_ACCOUNT_COMP_SCH_HIST IS TABLE OF CLTBS_ACCOUNT_COMP_SCH_HISTORY%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_ACCOUNT_COMP_SCH_HIST TY_TB_ACCOUNT_COMP_SCH_HIST;

    TYPE TY_TB_ACCOUNT_COMP_BAL_HIST IS TABLE OF CLTBS_COMP_BALANCES_HISTORY%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_COMP_BALANCE_HIST TY_TB_ACCOUNT_COMP_BAL_HIST;

    TYPE TY_TB_AMOUNT_DUE_HIST IS TABLE OF CLTB_ACCOUNT_SCHEDULES_HISTORY%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_AMOUNT_DUE_HIST TY_TB_AMOUNT_DUE_HIST;

    TYPE TY_TB_REVN IS TABLE OF CLTB_REVN_SCHEDULES%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_REVN TY_TB_REVN;
    TYPE TY_TB_REVN_HIST IS TABLE OF CLTB_REVN_SCHEDULES_HIST%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_REVN_HIST             TY_TB_REVN_HIST;
    L_ACC_NUM                  CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE := NULL;
    L_CONSIDER_BRANCH_MOVEMENT CLTM_PRODUCT.CONSIDER_BRANCH_HOLIDAY_SCH%TYPE;

    L_IDX1 CLTB_ACCOUNT_COMPONENTS.COMPONENT_NAME%TYPE;
    L_IDX2 VARCHAR2(50);
    J      VARCHAR2(50);

    L_INDX_DEL PLS_INTEGER;
    L_IND      VARCHAR2(35);
    L_INDX     PLS_INTEGER := 0;
    L_COUNT    NUMBER;
    NEXT_TXN EXCEPTION;

    L_TB_AC                 DBMS_SQL.VARCHAR2_TABLE;
    L_TB_BRN                DBMS_SQL.VARCHAR2_TABLE;
    L_TB_VER                DBMS_SQL.VARCHAR2_TABLE;
    L_NEW_HSH_DT            PLS_INTEGER;
    L_OLD_SCHEDULE_DUE_DATE DATE := TO_DATE('01-01-1900', 'dd-mm-rrrr');

    L_REC_EVENTS_DIARY      CLTBS_ACCOUNT_EVENTS_DIARY%ROWTYPE;
    L_TB_EVENTS_DIARY_ROWID CLPKSS_ELEMENT_TYPES.TY_TB_ROWID;

    L_ADHL_COUNT INTEGER := 0;

    L_USER_ID CLTBS_ACCOUNT_EVENTS_DIARY.MAKER_ID%TYPE;

    L_REC_HOLIDAY        CLTBS_ACCOUNT_HOLIDAY%ROWTYPE;
    L_ISHOLIDAY          VARCHAR2(1);
    OLD_MONTH_YEAR       VARCHAR(4);
    NEW_MONTH_YEAR       VARCHAR(4);
    L_PAST_LIMIT         BOOLEAN;
    L_FORWARD_BACKWARD   VARCHAR2(1);
    L_DT_ATTEMPT1        DATE;
    L_DT_ATTEMPT2        DATE;
    L_IGNORE_HOLIDAY     CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS%TYPE;
    L_SCHEDULE_MOVEMENT  CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT%TYPE;
    L_MOVE_ACROSS_MONTH  CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH%TYPE;
    L_CASCADE_SCHEDULE   CLTBS_ACCOUNT_HOLIDAY.CASCADE_SCHEDULES%TYPE;
    L_HOLIDAY_CHECK      CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK%TYPE;
    L_HOLIDAY_CCY        CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_SCH%TYPE;
    L_BOOL_LCL           BOOLEAN := FALSE;
    L_NO_ERRORS          PLS_INTEGER;
    L_ERR_IDX            PLS_INTEGER;
    L_OLD_ACCOUNT_NUMBER CLTB_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE := NULL;
    L_SCH_TYPE           VARCHAR2(1);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    PROCEDURE PR_CLEAR IS
    BEGIN
      DBG('$$$$$$$$$$$$$$$$l_account_obj.g_tb_events_diary.count in clear ' ||
          L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.COUNT);
      L_TB_CALC_DATES.DELETE;

      L_REC_HOLIDAY := NULL;

      IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(L_ACCOUNT_OBJ,
                                               P_ERR_CODE,
                                               P_ERR_PARAM) THEN
        DBG('Failed in call to clear obj ::' || P_ERR_CODE);
      END IF;

      IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(L_TMP_ACC_OBJ,
                                               P_ERR_CODE,
                                               P_ERR_PARAM) THEN
        DBG('Failed in call to clear obj ::' || P_ERR_CODE);
      END IF;

    END PR_CLEAR;

    PROCEDURE PR_INSERT IS
    BEGIN

      DBG('$$$$$$$$GOING HERE ' || L_TB_ACCOUNT_COMP_SCH.COUNT);

      IF L_TB_ACCOUNT.COUNT > 0 THEN
        FORALL I IN L_TB_ACCOUNT.FIRST .. L_TB_ACCOUNT.LAST
          UPDATE CLTBS_ACCOUNT_MASTER
             SET ROW = L_TB_ACCOUNT(I)
           WHERE ROWID = L_TB_ROWID_UPD(I);
      END IF;

      IF L_TB_ACCOUNT_HIST.COUNT > 0 THEN
        FORALL I IN L_TB_AC.FIRST .. L_TB_AC.LAST
          DELETE FROM CLTBS_ACCOUNT_HISTORY
           WHERE ACCOUNT_NUMBER = L_TB_AC(I)
             AND BRANCH_CODE = L_TB_BRN(I)
             AND VERSION_NO = L_TB_VER(I);

        FORALL I IN L_TB_ACCOUNT_HIST.FIRST .. L_TB_ACCOUNT_HIST.LAST
          INSERT INTO CLTBS_ACCOUNT_HISTORY VALUES L_TB_ACCOUNT_HIST (I);
      END IF;

      IF L_TB_ACCOUNT_COMP_SCH.COUNT > 0 THEN

        FORALL I IN L_TB_ACCOUNT_COMP_SCH.FIRST .. L_TB_ACCOUNT_COMP_SCH.LAST
          DELETE FROM CLTBS_ACCOUNT_COMP_SCH
           WHERE ACCOUNT_NUMBER = L_TB_ACCOUNT_COMP_SCH(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_ACCOUNT_COMP_SCH(I).BRANCH_CODE
             AND COMPONENT_NAME = L_TB_ACCOUNT_COMP_SCH(I).COMPONENT_NAME;

        FORALL I IN L_TB_ACCOUNT_COMP_SCH.FIRST .. L_TB_ACCOUNT_COMP_SCH.LAST
          INSERT INTO CLTBS_ACCOUNT_COMP_SCH
          VALUES L_TB_ACCOUNT_COMP_SCH
            (I);
      END IF;

      IF L_TB_ACCOUNT_COMP_SCH_HIST.COUNT > 0 THEN

        FORALL I IN L_TB_ACCOUNT_COMP_SCH_HIST.FIRST .. L_TB_ACCOUNT_COMP_SCH_HIST.LAST
          DELETE FROM CLTBS_ACCOUNT_COMP_SCH_HISTORY
           WHERE ACCOUNT_NUMBER = L_TB_ACCOUNT_COMP_SCH_HIST(I)
                .ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_ACCOUNT_COMP_SCH_HIST(I).BRANCH_CODE
             AND VERSION_NO = L_TB_ACCOUNT_COMP_SCH_HIST(I).VERSION_NO;

        FORALL I IN L_TB_ACCOUNT_COMP_SCH_HIST.FIRST .. L_TB_ACCOUNT_COMP_SCH_HIST.LAST
          INSERT INTO CLTBS_ACCOUNT_COMP_SCH_HISTORY
          VALUES L_TB_ACCOUNT_COMP_SCH_HIST
            (I);
      END IF;

      IF L_TB_AMOUNT_DUE.COUNT > 0 THEN

        FORALL I IN L_TB_AMOUNT_DUE.FIRST .. L_TB_AMOUNT_DUE.LAST
          DELETE FROM CLTBS_ACCOUNT_SCHEDULES
           WHERE ACCOUNT_NUMBER = L_TB_AMOUNT_DUE(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_AMOUNT_DUE(I).BRANCH_CODE;

        FORALL I IN L_TB_AMOUNT_DUE.FIRST .. L_TB_AMOUNT_DUE.LAST
          INSERT INTO CLTBS_ACCOUNT_SCHEDULES VALUES L_TB_AMOUNT_DUE (I);
      END IF;

      IF L_TB_AMOUNT_DUE_HIST.COUNT > 0 THEN
        FOR I IN 1 .. L_TB_AMOUNT_DUE_HIST.COUNT LOOP
          DBG('ACCOUNT_NUMBER---i---->' || L_TB_AMOUNT_DUE_HIST(I)
              .ACCOUNT_NUMBER);
          DBG('BRANCH_CODE---i-->' || L_TB_AMOUNT_DUE_HIST(I).BRANCH_CODE);
          DBG('COMPONENT_NAME---i--->' || L_TB_AMOUNT_DUE_HIST(I)
              .COMPONENT_NAME);
          DBG('SCHEDULE_DUE_DATE---i--->' || L_TB_AMOUNT_DUE_HIST(I)
              .SCHEDULE_DUE_DATE);
          DBG('SCHEDULE_ST_DATE------i--->' || L_TB_AMOUNT_DUE_HIST(I)
              .SCHEDULE_ST_DATE);
          DBG('VERSION_NO----i----->' || L_TB_AMOUNT_DUE_HIST(I)
              .VERSION_NO);
          DBG('EVENT_SEQ_NO---i---->' || L_TB_AMOUNT_DUE_HIST(I)
              .EVENT_SEQ_NO);
        END LOOP;
        BEGIN
          FOR I IN 1 .. L_TB_AC.COUNT LOOP
            DBG('ACCOUNT_NUMBER---d---->' || L_TB_AC(I));
            DBG('BRANCH_CODE---d-->' || L_TB_BRN(I));
            DBG('COMPONENT_NAME---d--->' || L_TB_VER(I));
          END LOOP;

          FORALL I IN L_TB_AMOUNT_DUE_HIST.FIRST .. L_TB_AMOUNT_DUE_HIST.LAST
            DELETE FROM CLTB_ACCOUNT_SCHEDULES_HISTORY
             WHERE ACCOUNT_NUMBER = L_TB_AMOUNT_DUE_HIST(I).ACCOUNT_NUMBER
               AND BRANCH_CODE = L_TB_AMOUNT_DUE_HIST(I).BRANCH_CODE
               AND VERSION_NO = L_TB_AMOUNT_DUE_HIST(I).VERSION_NO;

          FORALL I IN L_TB_AMOUNT_DUE_HIST.FIRST .. L_TB_AMOUNT_DUE_HIST.LAST
            INSERT INTO CLTB_ACCOUNT_SCHEDULES_HISTORY
            VALUES L_TB_AMOUNT_DUE_HIST
              (I);

        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed on cltb_account_schedules_history insertion');
        END;

      END IF;

      IF L_TB_REVN.COUNT > 0 THEN

        FORALL I IN L_TB_REVN.FIRST .. L_TB_REVN.LAST
          DELETE FROM CLTB_REVN_SCHEDULES
           WHERE ACCOUNT_NUMBER = L_TB_REVN(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_REVN(I).BRANCH_CODE;

        BEGIN
          FORALL I IN L_TB_REVN.FIRST .. L_TB_REVN.LAST SAVE EXCEPTIONS
            INSERT INTO CLTB_REVN_SCHEDULES VALUES L_TB_REVN (I);

        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
            DEBUG.PR_DEBUG('CL',
                           'Error Raised Here at cltb_revn_schedules');
            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           'REVN',
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;
        END;
      END IF;

      IF L_TB_REVN_HIST.COUNT > 0 THEN

        FORALL I IN L_TB_REVN_HIST.FIRST .. L_TB_REVN_HIST.LAST
          DELETE FROM CLTB_REVN_SCHEDULES_HIST
           WHERE ACCOUNT_NUMBER = L_TB_REVN_HIST(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_REVN_HIST(I).BRANCH_CODE
             AND VERSION_NO = L_TB_REVN_HIST(I).VERSION_NO;

        BEGIN
          FORALL I IN L_TB_REVN_HIST.FIRST .. L_TB_REVN_HIST.LAST SAVE
                                              EXCEPTIONS
            INSERT INTO CLTB_REVN_SCHEDULES_HIST VALUES L_TB_REVN_HIST (I);
        EXCEPTION
          WHEN OTHERS THEN
            L_NO_ERRORS := SQL%BULK_EXCEPTIONS.COUNT;
            DEBUG.PR_DEBUG('CL',
                           'Error Raised Here at cltb_revn_schedules_hist');
            FOR L_IDX IN 1 .. L_NO_ERRORS LOOP
              L_ERR_IDX := SQL%BULK_EXCEPTIONS(L_IDX).ERROR_INDEX;
              CLPKSS_UTIL.PR_LOG_EXCEPTION('ALL',
                                           P_BRANCH_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           'ARVN',
                                           'ERROR :' || L_IDX ||
                                           '  POSITION = ' || L_ERR_IDX ||
                                           ' -- ERROR_CODE = ' ||
                                           SQLERRM(-SQL%BULK_EXCEPTIONS(L_IDX)
                                                   .ERROR_CODE));
            END LOOP;
        END;
      END IF;

      IF L_TB_COMP_BALANCE.COUNT > 0 THEN

        FORALL I IN L_TB_COMP_BALANCE.FIRST .. L_TB_COMP_BALANCE.LAST
          DELETE FROM CLTBS_ACCOUNT_COMP_BALANCES
           WHERE ACCOUNT_NUMBER = L_TB_COMP_BALANCE(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_COMP_BALANCE(I).BRANCH_CODE
             AND COMPONENT_NAME = L_TB_COMP_BALANCE(I).COMPONENT_NAME;

        FORALL I IN L_TB_COMP_BALANCE.FIRST .. L_TB_COMP_BALANCE.LAST
          INSERT INTO CLTBS_ACCOUNT_COMP_BALANCES
          VALUES L_TB_COMP_BALANCE
            (I);
      END IF;

      IF L_TB_COMP_BALANCE_HIST.COUNT > 0 THEN

        FORALL I IN L_TB_COMP_BALANCE_HIST.FIRST .. L_TB_COMP_BALANCE_HIST.LAST
          DELETE FROM CLTBS_COMP_BALANCES_HISTORY
           WHERE ACCOUNT_NUMBER = L_TB_COMP_BALANCE_HIST(I).ACCOUNT_NUMBER
             AND BRANCH_CODE = L_TB_COMP_BALANCE_HIST(I).BRANCH_CODE
             AND VERSION_NO = L_TB_COMP_BALANCE_HIST(I).VERSION_NO;

        FORALL I IN L_TB_COMP_BALANCE_HIST.FIRST .. L_TB_COMP_BALANCE_HIST.LAST
          INSERT INTO CLTBS_COMP_BALANCES_HISTORY
          VALUES L_TB_COMP_BALANCE_HIST
            (I);
      END IF;

      IF L_TB_EVENTS_DIARY_ROWID.COUNT > 0 THEN
        FORALL I IN L_TB_EVENTS_DIARY_ROWID.FIRST .. L_TB_EVENTS_DIARY_ROWID.LAST
          DELETE FROM CLTBS_ACCOUNT_EVENTS_DIARY
           WHERE ROWID = L_TB_EVENTS_DIARY_ROWID(I);
      END IF;

      IF L_TB_EVENTS_DIARY.COUNT > 0 THEN
        FORALL I IN L_TB_EVENTS_DIARY.FIRST .. L_TB_EVENTS_DIARY.LAST
          INSERT INTO CLTBS_ACCOUNT_EVENTS_DIARY
          VALUES L_TB_EVENTS_DIARY
            (I);
      END IF;

      IF P_COMMIT = 'Y' THEN
        COMMIT;
      END IF;

      L_TB_ACCOUNT.DELETE;
      L_TB_ACCOUNT_COMP_SCH.DELETE;
      L_TB_COMP_BALANCE.DELETE;
      L_TB_AMOUNT_DUE.DELETE;
      L_TB_REVN.DELETE;
      L_TB_EVENTS_DIARY.DELETE;
      L_TB_EVENTS_DIARY_ROWID.DELETE;

      L_TB_ACCOUNT_HIST.DELETE;
      L_TB_ACCOUNT_COMP_SCH_HIST.DELETE;
      L_TB_COMP_BALANCE_HIST.DELETE;
      L_TB_AMOUNT_DUE_HIST.DELETE;
      L_TB_ROWID_UPD.DELETE;
      L_TB_REVN_HIST.DELETE;

      L_TB_CALC_DATES.DELETE;
      L_ACCOUNT_OBJ := NULL;
      L_TMP_ACC_OBJ := NULL;
      L_TB_AC.DELETE;
      L_TB_BRN.DELETE;
      L_TB_VER.DELETE;

    END PR_INSERT;

  BEGIN
    DEBUG.PR_DEBUG('CL', 'begin of fn_adch_holiday_for_branch');

    L_TB_ACCOUNT.DELETE;
    L_TB_ACCOUNT_COMP_SCH.DELETE;
    L_TB_COMP_BALANCE.DELETE;
    L_TB_AMOUNT_DUE.DELETE;
    L_TB_REVN.DELETE;
    L_TB_EVENTS_DIARY.DELETE;
    L_TB_EVENTS_DIARY_ROWID.DELETE;

    L_TB_ACCOUNT_HIST.DELETE;
    L_TB_ACCOUNT_COMP_SCH_HIST.DELETE;
    L_TB_COMP_BALANCE_HIST.DELETE;
    L_TB_AMOUNT_DUE_HIST.DELETE;
    L_TB_REVN_HIST.DELETE;
    L_TB_ROWID_UPD.DELETE;

    L_TB_CALC_DATES.DELETE;
    L_ACCOUNT_OBJ := NULL;
    L_TMP_ACC_OBJ := NULL;
    L_TB_AC.DELETE;
    L_TB_BRN.DELETE;
    L_TB_VER.DELETE;

    DEBUG.PR_DEBUG('CL', 'after delete');

    BEGIN
      SELECT 1
        INTO L_ADHL_COUNT
        FROM CLTBS_AFFECTED_HOLIDAYS
       WHERE (BRANCH_CODE = P_BRANCH_CODE OR EXISTS
              (SELECT 1
                 FROM CLTBS_ACCOUNT_HOLIDAY B
                WHERE B.BRANCH_CODE = P_BRANCH_CODE
                  AND ((HOLIDAY_CCY_SCH = BRANCH_CODE AND
                      IGNORE_HOLIDAYS = 'N' AND HOLIDAY_CHECK IN ('C', 'B')) OR
                      (HOLIDAY_CCY_REV = BRANCH_CODE AND
                      IGNORE_HOLIDAYS_REV = 'N' AND
                      HOLIDAY_CHK_REV IN ('C', 'B')))
                  AND ROWNUM < 2) AND ROWNUM < 2);
    EXCEPTION
      WHEN TOO_MANY_ROWS THEN
        L_ADHL_COUNT := 1;

      WHEN NO_DATA_FOUND THEN
        L_ADHL_COUNT := 0;
      WHEN OTHERS THEN
        L_ADHL_COUNT := 0;

    END;

    IF L_ADHL_COUNT = 0 THEN
      RETURN TRUE;
    END IF;

    DBG('gwpkss_ls_accountservice.g_module_code->' ||
        GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE);
    DBG('p_proc_date->' || P_PROC_DATE);
    DBG('p_process_no->' || P_PROCESS_NO);
    DBG('p_branch_code->' || P_BRANCH_CODE);

    IF CUR_SCH%ISOPEN THEN
      CLOSE CUR_SCH;
    END IF;

    OPEN CUR_SCH;

    DBG('$$$$$$$$$after open');

    LOOP

      DBG('$$$$$$$$$$after delete of l_tb_sch');

      FETCH CUR_SCH BULK COLLECT
        INTO L_TB_SCH LIMIT CLPKSS_BATCH.G_COMMIT_FREQ;

      DBG('$$$$$$$l_tb_sch.count ' || L_TB_SCH.COUNT);

      IF L_TB_SCH.COUNT > 0 THEN

        FOR I IN L_TB_SCH.FIRST .. L_TB_SCH.LAST LOOP
          BEGIN

            IF CLPKSS_BATCH.G_TB_PROBLEM_ACCOUNT.EXISTS(L_TB_SCH(I)
                                                        .BRANCH_CODE || L_TB_SCH(I)
                                                        .ACCOUNT_NUMBER) THEN
              DBG('problematic contracts skipping the same ' || L_TB_SCH(I)
                  .ACCOUNT_NUMBER || '::' || L_TB_SCH(I).BRANCH_CODE);
              RAISE NEXT_TXN;
            END IF;

            L_REC_HOLIDAY := CLPKS_CACHE.FN_GET_HOLIDAY_PREF(L_TB_SCH(I)
                                                             .ACCOUNT_NUMBER,
                                                             L_TB_SCH(I)
                                                             .BRANCH_CODE);

            DBG('l_rec_holiday.account_number->' ||
                L_REC_HOLIDAY.ACCOUNT_NUMBER);
            DBG('gwpkss_ls_accountservice.g_module_code->' ||
                GWPKSS_LS_ACCOUNTSERVICE.G_MODULE_CODE);
            DBG('l_old_schedule_due_date->' || L_OLD_SCHEDULE_DUE_DATE);
            DBG('l_tb_sch(i).schedule_due_date->' || L_TB_SCH(I)
                .SCHEDULE_DUE_DATE);
            DBG('l_old_account_number->' || L_OLD_ACCOUNT_NUMBER);
            DBG('l_tb_sch(i).account_number->' || L_TB_SCH(I)
                .ACCOUNT_NUMBER);
            DBG('l_sch_type->' || L_SCH_TYPE);
            DBG('l_tb_sch(i).schedule_type->' || L_TB_SCH(I).SCHEDULE_TYPE);

            IF L_OLD_SCHEDULE_DUE_DATE <> L_TB_SCH(I).SCHEDULE_DUE_DATE

               OR NVL(L_OLD_ACCOUNT_NUMBER, '000') <> L_TB_SCH(I)
              .ACCOUNT_NUMBER OR
               NVL(L_SCH_TYPE, 'X') <> L_TB_SCH(I).SCHEDULE_TYPE THEN

              DBG('Old sch date is not equal to the new sch date');
              PR_INSERT;

              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID := 1;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                L_TB_CLUSTER_DATA('l_next_wday') := L_NEXT_WDAY;
                L_TB_CLUSTER_DATA('account_number') := L_TB_SCH(I)
                                                       .ACCOUNT_NUMBER;
                L_TB_CLUSTER_DATA('schedule_due_date') := L_TB_SCH(I)
                                                          .SCHEDULE_DUE_DATE;
                L_TB_CLUSTER_DATA('i') := I;
                IF NOT
                    CLPKS_REVN_CLUSTER.FN_ADCH_HOLIDAY_FOR_BRANCH(P_BRANCH_CODE,
                                                                  P_PROC_DATE,
                                                                  P_PROCESS_NO,
                                                                  P_COMMIT,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAM) THEN

                  RETURN FALSE;
                END IF;
                IF L_TB_CLUSTER_DATA('l_next_wday') IS NOT NULL THEN
                  L_NEXT_WDAY := L_TB_CLUSTER_DATA('l_next_wday');
                END IF;
              END IF;
              IF NOT GLOBAL.G_SKIP_KERNEL THEN

                DBG('l_tb_sch(i).schedule_type->' || L_TB_SCH(I)
                    .SCHEDULE_TYPE);
                DBG('l_rec_holiday.payment_sch->' ||
                    L_REC_HOLIDAY.PAYMENT_SCH);
                IF L_TB_SCH(I).SCHEDULE_TYPE = 'P' OR
                    NVL(L_REC_HOLIDAY.PAYMENT_SCH, 'N') = 'Y' THEN
                  DBG('coming here');
                  L_IGNORE_HOLIDAY    := NVL(L_REC_HOLIDAY.IGNORE_HOLIDAYS,
                                             'X');
                  L_SCHEDULE_MOVEMENT := NVL(L_REC_HOLIDAY.SCHEDULE_MOVEMENT,
                                             'X');
                  L_MOVE_ACROSS_MONTH := NVL(L_REC_HOLIDAY.MOVE_ACROSS_MONTH,
                                             'X');
                  L_CASCADE_SCHEDULE  := NVL(L_REC_HOLIDAY.CASCADE_SCHEDULES,
                                             'X');
                  L_HOLIDAY_CHECK     := NVL(L_REC_HOLIDAY.HOLIDAY_CHECK,
                                             'X');
                  L_HOLIDAY_CCY       := L_REC_HOLIDAY.HOLIDAY_CCY_SCH;
                  DBG('l_ignore_holiday->' || L_IGNORE_HOLIDAY);
                  DBG('l_schedule_movement->' || L_SCHEDULE_MOVEMENT);
                  DBG('l_move_across_month->' || L_MOVE_ACROSS_MONTH);
                  DBG('l_cascade_schedule->' || L_CASCADE_SCHEDULE);
                  DBG('l_holiday_check->' || L_HOLIDAY_CHECK);
                  DBG('l_holiday_ccy->' || L_HOLIDAY_CCY);

                  DBG('l_rec_holiday.holiday_ccy_rev' ||
                      L_REC_HOLIDAY.HOLIDAY_CCY_REV);
                  DBG('l_rec_holiday.holiday_chk_rev' ||
                      L_REC_HOLIDAY.HOLIDAY_CHK_REV);
                  DBG('l_rec_holiday.holiday_ccy_mat' ||
                      L_REC_HOLIDAY.HOLIDAY_CCY_SCH);
                  DBG('l_rec_holiday.holiday_check_mat' ||
                      L_REC_HOLIDAY.HOLIDAY_CHECK);

                  IF L_IGNORE_HOLIDAY = 'N' THEN
                    DBG('inside this');
                    IF (L_REC_HOLIDAY.HOLIDAY_CHECK = 'L' AND
                       L_REC_HOLIDAY.HOLIDAY_CCY_SCH IS NULL) THEN
                      DBG('checking for holidays');

                      L_NEXT_WDAY := CLPKS_SCHEDULES.FN_GET_BRANCHWORKINGDAY(P_BRANCH_CODE,
                                                                             L_TB_SCH           (I)
                                                                             .SCHEDULE_DUE_DATE,
                                                                             L_TB_SCH           (I)
                                                                             .PRODUCT_CODE,
                                                                             L_TB_SCH           (I)
                                                                             .MATURITY_DATE,
                                                                             L_TB_SCH           (I)
                                                                             .VALUE_DATE + 1,
                                                                             L_TB_SCH           (I)
                                                                             .MATURITY_DATE,
                                                                             L_SCHEDULE_MOVEMENT,
                                                                             L_MOVE_ACROSS_MONTH,
                                                                             P_ERR_CODE);
                      DBG('local holiday l_next_wday->' || L_NEXT_WDAY);

                    ELSIF (L_REC_HOLIDAY.HOLIDAY_CHECK = 'C' AND
                          L_REC_HOLIDAY.HOLIDAY_CCY_SCH IS NOT NULL) OR
                          (L_REC_HOLIDAY.HOLIDAY_CHECK = 'B' AND
                          L_REC_HOLIDAY.HOLIDAY_CCY_SCH IS NOT NULL) THEN
                      DBG('both ccy and both');
                      DBG('P_SOURCE_DATE' || L_TB_SCH(I).SCHEDULE_DUE_DATE);
                      IF L_REC_HOLIDAY.HOLIDAY_CHECK = 'B' THEN
                        L_CONSIDER_BRANCH_MOVEMENT := 'Y';
                      ELSE
                        L_CONSIDER_BRANCH_MOVEMENT := 'N';
                      END IF;

                      L_NEXT_WDAY := CLPKS_SCHEDULES.FN_GET_CCY_WORKINGDAY(L_TB_SCH           (I)
                                                                           .SCHEDULE_DUE_DATE,
                                                                           L_HOLIDAY_CCY,
                                                                           L_TB_SCH           (I)
                                                                           .VALUE_DATE + 1,
                                                                           L_TB_SCH           (I)
                                                                           .MATURITY_DATE,
                                                                           L_SCHEDULE_MOVEMENT,
                                                                           L_MOVE_ACROSS_MONTH,
                                                                           L_HOLIDAY_CHECK,
                                                                           P_ERR_CODE);
                      DBG('ccy/both holiday l_next_wday->' || L_NEXT_WDAY);

                      IF L_NEXT_WDAY IS NULL THEN
                        RAISE NEXT_TXN;
                      END IF;

                    END IF;
                  ELSE
                    IF L_TB_SCH(I).SCHEDULE_TYPE IN ('P', 'R') THEN
                      L_NEXT_WDAY := L_TB_SCH(I).SCHEDULE_DUE_DATE;
                    END IF;
                  END IF;
                  DBG('l_rec_holiday.payment_sch->' ||
                      L_REC_HOLIDAY.PAYMENT_SCH);
                  DBG('l_tb_sch(i).schedule_type->' || L_TB_SCH(I)
                      .SCHEDULE_TYPE);
                ELSIF NVL(L_REC_HOLIDAY.PAYMENT_SCH, 'N') = 'N' AND L_TB_SCH(I)
                     .SCHEDULE_TYPE = 'R' THEN
                  DBG('came here for revision schedules');
                  L_IGNORE_HOLIDAY    := NVL(L_REC_HOLIDAY.IGNORE_HOLIDAYS_REV,
                                             'X');
                  L_SCHEDULE_MOVEMENT := NVL(L_REC_HOLIDAY.SCHEDULE_MOVEMENT_REV,
                                             'X');
                  L_MOVE_ACROSS_MONTH := NVL(L_REC_HOLIDAY.MOVE_ACROSS_MONTH_REV,
                                             'X');
                  L_CASCADE_SCHEDULE  := NVL(L_REC_HOLIDAY.CASCADE_SCEDULES_REV,
                                             'X');
                  L_HOLIDAY_CHECK     := NVL(L_REC_HOLIDAY.HOLIDAY_CHK_REV,
                                             'X');
                  L_HOLIDAY_CCY       := L_REC_HOLIDAY.HOLIDAY_CCY_REV;
                  IF L_IGNORE_HOLIDAY = 'N' THEN
                    DBG('inside this');
                    IF (L_REC_HOLIDAY.HOLIDAY_CHK_REV = 'L' AND
                       L_REC_HOLIDAY.HOLIDAY_CCY_REV IS NULL) THEN
                      DBG('checking for holidays');

                      L_NEXT_WDAY := CLPKS_SCHEDULES.FN_GET_BRANCHWORKINGDAY(P_BRANCH_CODE,
                                                                             L_TB_SCH           (I)
                                                                             .SCHEDULE_DUE_DATE,
                                                                             L_TB_SCH           (I)
                                                                             .PRODUCT_CODE,
                                                                             L_TB_SCH           (I)
                                                                             .MATURITY_DATE,
                                                                             L_TB_SCH           (I)
                                                                             .VALUE_DATE + 1,
                                                                             L_TB_SCH           (I)
                                                                             .MATURITY_DATE,
                                                                             L_SCHEDULE_MOVEMENT,
                                                                             L_MOVE_ACROSS_MONTH,
                                                                             P_ERR_CODE);

                    ELSIF (L_REC_HOLIDAY.HOLIDAY_CHK_REV = 'C' AND
                          L_REC_HOLIDAY.HOLIDAY_CCY_REV IS NOT NULL) OR
                          (L_REC_HOLIDAY.HOLIDAY_CHK_REV = 'B' AND
                          L_REC_HOLIDAY.HOLIDAY_CCY_REV IS NOT NULL) THEN
                      DBG('here for both and currency condition for revision');

                      L_NEXT_WDAY := CLPKS_SCHEDULES.FN_GET_CCY_WORKINGDAY(L_TB_SCH           (I)
                                                                           .SCHEDULE_DUE_DATE,
                                                                           L_HOLIDAY_CCY,
                                                                           L_TB_SCH           (I)
                                                                           .VALUE_DATE + 1,
                                                                           L_TB_SCH           (I)
                                                                           .MATURITY_DATE,
                                                                           L_SCHEDULE_MOVEMENT,
                                                                           L_MOVE_ACROSS_MONTH,
                                                                           L_HOLIDAY_CHECK,
                                                                           P_ERR_CODE);

                      IF L_NEXT_WDAY IS NULL THEN
                        RAISE NEXT_TXN;
                      END IF;

                    END IF;
                  ELSE
                    IF L_TB_SCH(I).SCHEDULE_TYPE = 'R' THEN
                      L_NEXT_WDAY := L_TB_SCH(I).SCHEDULE_DUE_DATE;
                    END IF;
                  END IF;
                END IF;
                DBG('$$$$$$$$$$$$$l_next_wday ' || L_NEXT_WDAY);

              ELSE
                DBG('$$$$$$$$$$$$$l_next_wday ' || L_NEXT_WDAY);
                GLOBAL.PR_RESET_SKIP_KERNEL;
              END IF;

              L_NEW_HSH_DT := CLPKSS_UTIL.FN_HASH_DATE(L_NEXT_WDAY);

              L_OLD_SCHEDULE_DUE_DATE := L_TB_SCH(I).SCHEDULE_DUE_DATE;
              L_OLD_ACCOUNT_NUMBER    := L_TB_SCH(I).ACCOUNT_NUMBER;
              L_SCH_TYPE              := L_TB_SCH(I).SCHEDULE_TYPE;
            END IF;

            PR_CLEAR;

            IF NOT CLPKSS_OBJECT.FN_CLEAR_ACC_OBJECT(L_ACCOUNT_OBJ,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN
              DEBUG.PR_DEBUG('CL', 'failed in account object clear');
              PR_CLEAR;
              CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_SCH(I).ACCOUNT_NUMBER,
                                           L_TB_SCH(I).BRANCH_CODE,
                                           P_PROC_DATE,
                                           'ADHL',
                                           P_ERR_CODE || P_ERR_PARAM);

              RAISE NEXT_TXN;
            END IF;

            IF NOT CLPKSS_OBJECT.FN_CREATE_ACCT_OBJECT(L_TB_SCH     (I)
                                                       .ACCOUNT_NUMBER,
                                                       L_TB_SCH     (I)
                                                       .BRANCH_CODE,
                                                       L_ACCOUNT_OBJ,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN
              DEBUG.PR_DEBUG('CL', 'failed in account object creation');
              PR_CLEAR;
              CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_SCH(I).ACCOUNT_NUMBER,
                                           L_TB_SCH(I).BRANCH_CODE,
                                           P_PROC_DATE,
                                           'ADHL',
                                           P_ERR_CODE || P_ERR_PARAM);

              RAISE NEXT_TXN;
            END IF;

            DBG('$$$$$$$$$$$$$$$$l_account_obj.g_tb_events_diary.count after acc obj ' ||
                L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.COUNT);

            L_TMP_ACC_OBJ := L_ACCOUNT_OBJ;
            DBG('here1 l_tb_sch(i).schedule_type->' || L_TB_SCH(I)
                .SCHEDULE_TYPE);
            IF L_TB_SCH(I).SCHEDULE_TYPE = 'P' THEN

              DBG('$$$$$$$After account object');

              L_ACCOUNT_OBJ.ACCOUNT_DET.CALC_REQD          := 'Y';
              L_ACCOUNT_OBJ.ACCOUNT_DET.RECALC_ACTION_CODE := 'N';
              L_TMP_ACC_OBJ                                := L_ACCOUNT_OBJ;

              IF L_TMP_ACC_OBJ.ACCOUNT_DET.MATURITY_DATE = L_TB_SCH(I)
                .SCHEDULE_DUE_DATE THEN
                L_ACCOUNT_OBJ.ACCOUNT_DET.MATURITY_DATE := L_NEXT_WDAY;
              END IF;

              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_AMT_DUE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  IF NOT L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                     .G_TB_AMT_DUE.EXISTS(L_NEW_HSH_DT) AND
                     L_NEW_HSH_DT IS NOT NULL THEN
                    IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                     .G_AMOUNT_DUE.SCHEDULE_ST_DATE = L_TB_SCH(I)
                       .SCHEDULE_DUE_DATE THEN
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2).G_AMOUNT_DUE.SCHEDULE_ST_DATE := L_NEXT_WDAY;
                    END IF;

                    IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                     .G_AMOUNT_DUE.SCHEDULE_DUE_DATE = L_TB_SCH(I)
                       .SCHEDULE_DUE_DATE THEN
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE.DELETE(L_IDX2);
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_NEW_HSH_DT).G_AMOUNT_DUE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                                       .G_AMOUNT_DUE;
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_NEW_HSH_DT).G_AMOUNT_DUE.SCHEDULE_DUE_DATE := L_NEXT_WDAY;
                    END IF;

                    DBG('l_account_obj.g_tb_components.count::' ||
                        L_ACCOUNT_OBJ.G_TB_COMPONENTS.COUNT);
                    IF L_ACCOUNT_OBJ.G_TB_COMPONENTS.EXISTS(L_IDX1) THEN
                      DBG('l_account_obj.g_tb_components(l_idx1).g_tb_amt_due.count::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_AMT_DUE.COUNT);
                      IF L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                       .G_TB_AMT_DUE.EXISTS(L_IDX2) THEN
                        DBG('l_account_obj.g_tb_components(l_idx1) .g_tb_amt_due(l_idx2) .g_amount_due.schedule_st_date::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                            .G_AMOUNT_DUE.SCHEDULE_ST_DATE);
                        DBG('l_account_obj.g_tb_components(l_idx1) .g_tb_amt_due(l_idx2) .g_amount_due.schedule_due_date::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                            .G_AMOUNT_DUE.SCHEDULE_DUE_DATE);
                        IF L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                         .G_AMOUNT_DUE.SCHEDULE_ST_DATE > L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                           .G_AMOUNT_DUE.SCHEDULE_DUE_DATE THEN
                          DBG('abt to go to next record as Unable to reschedule the Schedule dates please check the local holiday maintainance');
                          PR_CLEAR;
                          CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_SCH                                                                            (I)
                                                       .ACCOUNT_NUMBER,
                                                       L_TB_SCH                                                                            (I)
                                                       .BRANCH_CODE,
                                                       P_PROC_DATE,
                                                       'ADHL',
                                                       'Unable to reschedule the Schedule dates please check the local holiday maintainance');

                          RAISE NEXT_TXN;
                        END IF;
                      END IF;
                    END IF;

                  ELSE
                    RAISE NEXT_TXN;
                  END IF;
                  L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_AMT_DUE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_COMP_SCH.FIRST;

                WHILE L_IDX2 IS NOT NULL LOOP
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.ACCOUNT_NUMBER);
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.BRANCH_CODE);
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.COMPONENT_NAME);
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.SCHEDULE_TYPE);
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.SCH_START_DATE);

                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.UNIT);
                  DBG('0000::' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                      .G_ACCOUNT_COMP_SCH.FIRST_DUE_DATE);
                  DBG('0000::' || L_TMP_ACC_OBJ.ACCOUNT_DET.MATURITY_DATE);

                  IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                   .G_ACCOUNT_COMP_SCH.SCH_START_DATE = L_TB_SCH(I)
                     .SCHEDULE_DUE_DATE AND L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.SCHEDULE_TYPE = 'P' THEN
                    L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2).G_ACCOUNT_COMP_SCH.SCH_START_DATE := L_NEXT_WDAY;
                  END IF;

                  IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                   .G_ACCOUNT_COMP_SCH.SCH_END_DATE = L_TB_SCH(I)
                     .SCHEDULE_DUE_DATE AND L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.SCHEDULE_TYPE = 'P' THEN
                    L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2).G_ACCOUNT_COMP_SCH.SCH_END_DATE := L_NEXT_WDAY;
                  END IF;

                  IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                   .G_ACCOUNT_COMP_SCH.SCH_END_DATE = L_TB_SCH(I)
                     .SCHEDULE_DUE_DATE AND L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.SCHEDULE_TYPE = 'P' AND L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.UNIT = 'B' AND L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.SCH_END_DATE = L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.FIRST_DUE_DATE AND
                      L_TMP_ACC_OBJ.ACCOUNT_DET.MATURITY_DATE = L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                     .G_ACCOUNT_COMP_SCH.FIRST_DUE_DATE THEN
                    L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2).G_ACCOUNT_COMP_SCH.FIRST_DUE_DATE := L_NEXT_WDAY;
                  END IF;

                  L_IDX2 := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_COMP_SCH.NEXT(L_IDX2);
                END LOOP;

                L_IDX1 := L_ACCOUNT_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_TMP_ACC_OBJ.G_ACCT_BALANCE.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1)
                          .G_TB_ACCT_BALANCE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  DBG('$$$$$$$$l_idx1-------' || L_IDX1);
                  DBG('$$$$$$$$l_idx2-------' || L_IDX2);

                  IF L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                   .G_ACCT_BAL.VAL_DATE = L_TB_SCH(I).SCHEDULE_DUE_DATE AND
                      L_NEW_HSH_DT IS NOT NULL THEN

                    L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE.DELETE(L_IDX2);
                    L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_NEW_HSH_DT).G_ACCT_BAL.VAL_DATE := L_NEXT_WDAY;
                    L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_NEW_HSH_DT).G_ACCT_BAL.ACCOUNT_NUMBER := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                                                      .G_ACCT_BAL.ACCOUNT_NUMBER;
                    L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_NEW_HSH_DT).G_ACCT_BAL.BRANCH_CODE := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                                                   .G_ACCT_BAL.BRANCH_CODE;
                    L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_NEW_HSH_DT).G_ACCT_BAL.COMPONENT_NAME := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                                                      .G_ACCT_BAL.COMPONENT_NAME;

                  END IF;
                  L_IDX2 := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1)
                            .G_TB_ACCT_BALANCE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_ACCT_BALANCE.NEXT(L_IDX1);
              END LOOP;

              DEBUG.PR_DEBUG('CL', 'splitting schedules');

              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT + 1).ACCOUNT_NUMBER := L_TB_SCH(I)
                                                                           .ACCOUNT_NUMBER;
              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT).BRANCH_CODE := L_TB_SCH(I)
                                                                    .BRANCH_CODE;
              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT).RECALC_ACTION_CODE := 'N';
              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT).RECALC_DATE := P_PROC_DATE;
              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT).PROCESS_NO := L_TB_SCH(I)
                                                                   .PROCESS_NO;
              L_TB_CALC_DATES(L_TB_CALC_DATES.COUNT).PRINCIPAL_CHG_AMT := 0;

              DBG('$$$$$$$After filling Calc Dates');

              DBG('--------------------------------BEFORE------------------------------------------');

              PRINT_COMPBALS_FULL(L_ACCOUNT_OBJ);

              IF NOT CLPKSS_RECALC.FN_RECALC_FOR_AN_ACCOUNT(L_ACCOUNT_OBJ,
                                                            L_TB_SCH(I)
                                                            .SCHEDULE_DUE_DATE,
                                                            L_TB_CALC_DATES,
                                                            'N',
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
                DEBUG.PR_DEBUG('CL',
                               'failed in clpkss_recalc.fn_recalc_for_an_account');
                PR_CLEAR;
                CLPKSS_UTIL.PR_LOG_EXCEPTION(L_TB_SCH(I).ACCOUNT_NUMBER,
                                             L_TB_SCH(I).BRANCH_CODE,
                                             P_PROC_DATE,
                                             'ADHL',
                                             P_ERR_CODE || P_ERR_PARAM);

                RAISE NEXT_TXN;
              END IF;

              DBG('--------------------------------AFTER------------------------------------------');

              PRINT_COMPBALS_FULL(L_ACCOUNT_OBJ);

              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_AMT_DUE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT + 1).ACCOUNT_NUMBER := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                         .G_AMOUNT_DUE.ACCOUNT_NUMBER;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).BRANCH_CODE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.BRANCH_CODE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).COMPONENT_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.COMPONENT_NAME;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).FORMULA_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.FORMULA_NAME;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_TYPE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                    .G_AMOUNT_DUE.SCHEDULE_TYPE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_ST_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                       .G_AMOUNT_DUE.SCHEDULE_ST_DATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_DUE_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                        .G_AMOUNT_DUE.SCHEDULE_DUE_DATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).GRACE_DAYS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.GRACE_DAYS;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).ORIG_AMOUNT_DUE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                      .G_AMOUNT_DUE.ORIG_AMOUNT_DUE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).AMOUNT_DUE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.AMOUNT_DUE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).ADJ_AMOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.ADJ_AMOUNT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).AMOUNT_SETTLED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.AMOUNT_SETTLED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).AMOUNT_OVERDUE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.AMOUNT_OVERDUE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).ACCRUED_AMOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.ACCRUED_AMOUNT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SETTLEMENT_CCY := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.SETTLEMENT_CCY;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LCY_EQUIVALENT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.LCY_EQUIVALENT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).DLY_AVG_AMT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.DLY_AVG_AMT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).EMI_AMOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.EMI_AMOUNT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_FLAG := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                    .G_AMOUNT_DUE.SCHEDULE_FLAG;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).WAIVER_FLAG := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.WAIVER_FLAG;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).VERSION_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).EVENT_SEQ_NO := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.EVENT_SEQ_NO;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_LINKAGE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                       .G_AMOUNT_DUE.SCHEDULE_LINKAGE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).CAPITALIZED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.CAPITALIZED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).PROCESS_NO := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.PROCESS_NO;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).AMOUNT_READJUSTED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                        .G_AMOUNT_DUE.AMOUNT_READJUSTED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).ADJ_SETTLED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.ADJ_SETTLED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCH_STATUS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.SCH_STATUS;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).ACCOUNT_GL := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                 .G_AMOUNT_DUE.ACCOUNT_GL;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).MORA_INT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                               .G_AMOUNT_DUE.MORA_INT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SCHEDULE_NO := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                  .G_AMOUNT_DUE.SCHEDULE_NO;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).WRITEOFF_AMT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.WRITEOFF_AMT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LAST_PMNT_VALUE_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                           .G_AMOUNT_DUE.LAST_PMNT_VALUE_DATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).RETRY_START_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                       .G_AMOUNT_DUE.RETRY_START_DATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).READJ_SETTLED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                    .G_AMOUNT_DUE.READJ_SETTLED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LAST_READJ_XRATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                       .G_AMOUNT_DUE.LAST_READJ_XRATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SUSP_AMT_DUE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.SUSP_AMT_DUE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SUSP_AMT_SETTLED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                       .G_AMOUNT_DUE.SUSP_AMT_SETTLED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SUSP_AMT_LCY := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.SUSP_AMT_LCY;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SUSP_READ_AMT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                    .G_AMOUNT_DUE.SUSP_READ_AMT;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).SUSP_READ_SETTLED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                        .G_AMOUNT_DUE.SUSP_READ_SETTLED;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LAST_SUSP_XRATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                      .G_AMOUNT_DUE.LAST_SUSP_XRATE;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).AMOUNT_WAIVED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                    .G_AMOUNT_DUE.AMOUNT_WAIVED;

                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LIST_DAYS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                .G_AMOUNT_DUE.LIST_DAYS;
                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).LIST_AVG_AMT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                   .G_AMOUNT_DUE.LIST_AVG_AMT;

                  L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT).IRR_APPLICABLE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                                     .G_AMOUNT_DUE.IRR_APPLICABLE;

                  DBG('ACCOUNT_NUMBER------->' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .ACCOUNT_NUMBER);
                  DBG('BRANCH_CODE----->' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .BRANCH_CODE);
                  DBG('COMPONENT_NAME------>' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .COMPONENT_NAME);
                  DBG('SCHEDULE_DUE_DATE------>' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .SCHEDULE_DUE_DATE);
                  DBG('SCHEDULE_ST_DATE--------->' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .SCHEDULE_ST_DATE);
                  DBG('VERSION_NO--------->' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .VERSION_NO);
                  DBG('EVENT_SEQ_NO------->' || L_TB_AMOUNT_DUE_HIST(L_TB_AMOUNT_DUE_HIST.COUNT)
                      .EVENT_SEQ_NO);
                  L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_AMT_DUE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_TMP_ACC_OBJ.G_ACCT_BALANCE.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1)
                          .G_TB_ACCT_BALANCE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT + 1).ACCOUNT_NUMBER := NVL(L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                                 .G_ACCT_BAL.ACCOUNT_NUMBER,
                                                                                                 L_TMP_ACC_OBJ.ACCOUNT_DET.ACCOUNT_NUMBER);
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT).BRANCH_CODE := NVL(L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                          .G_ACCT_BAL.BRANCH_CODE,
                                                                                          L_TMP_ACC_OBJ.ACCOUNT_DET.BRANCH_CODE);
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT).VERSION_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT).COMPONENT_NAME := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                         .G_ACCT_BAL.COMPONENT_NAME;
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT).VAL_DATE := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                   .G_ACCT_BAL.VAL_DATE;
                  L_TB_COMP_BALANCE_HIST(L_TB_COMP_BALANCE_HIST.COUNT).BALANCE := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                                  .G_ACCT_BAL.BALANCE;
                  L_IDX2 := L_TMP_ACC_OBJ.G_ACCT_BALANCE(L_IDX1)
                            .G_TB_ACCT_BALANCE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_ACCT_BALANCE.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_ACCOUNT_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_AMT_DUE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_AMOUNT_DUE(L_TB_AMOUNT_DUE.COUNT + 1) := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_AMT_DUE(L_IDX2)
                                                                .G_AMOUNT_DUE;
                  DBG('Coming here with ' || L_TB_AMOUNT_DUE.COUNT);
                  L_IDX2 := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_AMT_DUE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_ACCOUNT_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_ACCOUNT_OBJ.G_ACCT_BALANCE.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1)
                          .G_TB_ACCT_BALANCE.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_COMP_BALANCE(L_TB_COMP_BALANCE.COUNT + 1) := L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1).G_TB_ACCT_BALANCE(L_IDX2)
                                                                    .G_ACCT_BAL;
                  L_IDX2 := L_ACCOUNT_OBJ.G_ACCT_BALANCE(L_IDX1)
                            .G_TB_ACCT_BALANCE.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_ACCOUNT_OBJ.G_ACCT_BALANCE.NEXT(L_IDX1);
              END LOOP;

              DBG('here2 l_tb_sch(i).schedule_type->' || L_TB_SCH(I)
                  .SCHEDULE_TYPE);
            ELSIF L_TB_SCH(I).SCHEDULE_TYPE = 'R' THEN
              DBG('COMING HERE FOR REVISION POPULATION');
              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              DBG('l_idx1' || L_IDX1);
              WHILE L_IDX1 IS NOT NULL LOOP
                L_REVN_IDX := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                              .G_TB_REVN_SCHEDULES.FIRST;
                WHILE L_REVN_IDX IS NOT NULL LOOP
                  DBG('l_revn_idx' || L_REVN_IDX);
                  IF NOT L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                     .G_TB_REVN_SCHEDULES.EXISTS(L_NEW_HSH_DT) AND
                     L_NEW_HSH_DT IS NOT NULL THEN
                    DBG(' IF l_tmp_acc_obj.g_tb_components(l_idx1).g_Tb_Revn_Schedules(l_revn_idx).
                                    g_Revn_Schedules.schedule_st_date' || L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX) .
                        G_REVN_SCHEDULES.SCHEDULE_ST_DATE);
                    IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX) .
                      G_REVN_SCHEDULES.SCHEDULE_ST_DATE = L_TB_SCH(I)
                       .SCHEDULE_DUE_DATE THEN
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX).G_REVN_SCHEDULES.SCHEDULE_ST_DATE := L_NEXT_WDAY;
                    END IF;
                    IF L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX)
                     .G_REVN_SCHEDULES.SCHEDULE_DUE_DATE = L_TB_SCH(I)
                       .SCHEDULE_DUE_DATE THEN
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES.DELETE(L_REVN_IDX);
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_NEW_HSH_DT).G_REVN_SCHEDULES := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX)
                                                                                                                  .G_REVN_SCHEDULES;
                      L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_NEW_HSH_DT).G_REVN_SCHEDULES.SCHEDULE_DUE_DATE := L_NEXT_WDAY;
                      IF L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                       .G_TB_REVN_SCHEDULES.EXISTS(L_REVN_IDX) THEN
                        DBG('l_account_obj.g_tb_components(l_idx1) .g_Tb_Revn_Schedules(l_new_hsh_dt) .g_Revn_Schedules.schedule_due_date' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_NEW_HSH_DT)
                            .G_REVN_SCHEDULES.SCHEDULE_DUE_DATE);
                        DBG('l_account_obj.g_tb_components(l_idx1) .g_Tb_Revn_Schedules(l_revn_idx).g_Revn_Schedules.schedule_st_date' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_REVN_IDX)
                            .G_REVN_SCHEDULES.SCHEDULE_ST_DATE);
                      END IF;
                    END IF;
                  ELSE
                    RAISE NEXT_TXN;
                  END IF;
                  L_REVN_IDX := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                                .G_TB_REVN_SCHEDULES.NEXT(L_REVN_IDX);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_REVN_SCHEDULES.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT + 1).ACCOUNT_NUMBER := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                             .G_REVN_SCHEDULES.ACCOUNT_NUMBER;
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).BRANCH_CODE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                      .G_REVN_SCHEDULES.BRANCH_CODE;
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).COMPONENT_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                         .G_REVN_SCHEDULES.COMPONENT_NAME;

                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).SCHEDULE_ST_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                           .G_REVN_SCHEDULES.SCHEDULE_ST_DATE;
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).SCHEDULE_DUE_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                            .G_REVN_SCHEDULES.SCHEDULE_DUE_DATE;

                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).APPLIED_FLAG := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                       .G_REVN_SCHEDULES.APPLIED_FLAG;
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).SCHEDULE_LINKAGE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                                           .G_REVN_SCHEDULES.SCHEDULE_LINKAGE;
                  L_TB_REVN_HIST(L_TB_REVN_HIST.COUNT).VERSION_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;

                  L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_REVN_SCHEDULES.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_IDX1 := L_ACCOUNT_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_REVN_SCHEDULES.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_REVN(L_TB_REVN.COUNT + 1) := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_REVN_SCHEDULES(L_IDX2)
                                                    .G_REVN_SCHEDULES;
                  L_IDX2 := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_REVN_SCHEDULES.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_ACCOUNT_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

            END IF;

            IF L_ACC_NUM <> L_TB_SCH(I).ACCOUNT_NUMBER THEN
              L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.FIRST;
              WHILE L_IDX1 IS NOT NULL LOOP
                L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                          .G_TB_COMP_SCH.FIRST;
                WHILE L_IDX2 IS NOT NULL LOOP
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT + 1).ACCOUNT_NUMBER := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                     .G_ACCOUNT_COMP_SCH.ACCOUNT_NUMBER;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).BRANCH_CODE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                              .G_ACCOUNT_COMP_SCH.BRANCH_CODE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).COMPONENT_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                 .G_ACCOUNT_COMP_SCH.COMPONENT_NAME;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).SCHEDULE_TYPE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                .G_ACCOUNT_COMP_SCH.SCHEDULE_TYPE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).SCHEDULE_FLAG := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                .G_ACCOUNT_COMP_SCH.SCHEDULE_FLAG;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).FORMULA_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                               .G_ACCOUNT_COMP_SCH.FORMULA_NAME;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).SCH_START_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                 .G_ACCOUNT_COMP_SCH.SCH_START_DATE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).NO_OF_SCHEDULES := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                  .G_ACCOUNT_COMP_SCH.NO_OF_SCHEDULES;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).FREQUENCY := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                            .G_ACCOUNT_COMP_SCH.FREQUENCY;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).UNIT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                       .G_ACCOUNT_COMP_SCH.UNIT;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).SCH_END_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                               .G_ACCOUNT_COMP_SCH.SCH_END_DATE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).AMOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                         .G_ACCOUNT_COMP_SCH.AMOUNT;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).PAYMENT_MODE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                               .G_ACCOUNT_COMP_SCH.PAYMENT_MODE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).PMNT_PROD_AC := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                               .G_ACCOUNT_COMP_SCH.PMNT_PROD_AC;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).PAYMENT_DETAILS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                  .G_ACCOUNT_COMP_SCH.PAYMENT_DETAILS;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).BEN_ACCOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                              .G_ACCOUNT_COMP_SCH.BEN_ACCOUNT;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).BEN_BANK := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                           .G_ACCOUNT_COMP_SCH.BEN_BANK;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).BEN_NAME := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                           .G_ACCOUNT_COMP_SCH.BEN_NAME;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).VERSION_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).CAPITALIZED := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                              .G_ACCOUNT_COMP_SCH.CAPITALIZED;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).FIRST_DUE_DATE := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                 .G_ACCOUNT_COMP_SCH.FIRST_DUE_DATE;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).WAIVER_FLAG := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                              .G_ACCOUNT_COMP_SCH.WAIVER_FLAG;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).DUE_DATES_ON := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                               .G_ACCOUNT_COMP_SCH.DUE_DATES_ON;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).COMPOUND_DAYS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                .G_ACCOUNT_COMP_SCH.COMPOUND_DAYS;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).COMPOUND_MONTHS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                  .G_ACCOUNT_COMP_SCH.COMPOUND_MONTHS;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).COMPOUND_YEARS := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                                 .G_ACCOUNT_COMP_SCH.COMPOUND_YEARS;
                  L_TB_ACCOUNT_COMP_SCH_HIST(L_TB_ACCOUNT_COMP_SCH_HIST.COUNT).EMI_AMOUNT := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1).G_TB_COMP_SCH(L_IDX2)
                                                                                             .G_ACCOUNT_COMP_SCH.EMI_AMOUNT;

                  L_IDX2 := L_TMP_ACC_OBJ.G_TB_COMPONENTS(L_IDX1)
                            .G_TB_COMP_SCH.NEXT(L_IDX2);
                END LOOP;
                L_IDX1 := L_TMP_ACC_OBJ.G_TB_COMPONENTS.NEXT(L_IDX1);
              END LOOP;

              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT + 1).ACCOUNT_NUMBER := L_TMP_ACC_OBJ.ACCOUNT_DET.ACCOUNT_NUMBER;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).BRANCH_CODE := L_TMP_ACC_OBJ.ACCOUNT_DET.BRANCH_CODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).APPLICATION_NUM := L_TMP_ACC_OBJ.ACCOUNT_DET.APPLICATION_NUM;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CUSTOMER_ID := L_TMP_ACC_OBJ.ACCOUNT_DET.CUSTOMER_ID;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PRODUCT_CODE := L_TMP_ACC_OBJ.ACCOUNT_DET.PRODUCT_CODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PRODUCT_CATEGORY := L_TMP_ACC_OBJ.ACCOUNT_DET.PRODUCT_CATEGORY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).BOOK_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.BOOK_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).VALUE_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.VALUE_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).MATURITY_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.MATURITY_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AMOUNT_FINANCED := L_TMP_ACC_OBJ.ACCOUNT_DET.AMOUNT_FINANCED;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DOWNPAYMENT_AMOUNT := L_TMP_ACC_OBJ.ACCOUNT_DET.DOWNPAYMENT_AMOUNT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CURRENCY := L_TMP_ACC_OBJ.ACCOUNT_DET.CURRENCY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ORIGINAL_ST_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.ORIGINAL_ST_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PRIMARY_APPLICANT_ID := L_TMP_ACC_OBJ.ACCOUNT_DET.PRIMARY_APPLICANT_ID;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PRIMARY_APPLICANT_NAME := L_TMP_ACC_OBJ.ACCOUNT_DET.PRIMARY_APPLICANT_NAME;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).USER_DEFINED_STATUS := L_TMP_ACC_OBJ.ACCOUNT_DET.USER_DEFINED_STATUS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CALC_REQD := L_TMP_ACC_OBJ.ACCOUNT_DET.CALC_REQD;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).BACK_VAL_EFF_DT := L_TMP_ACC_OBJ.ACCOUNT_DET.BACK_VAL_EFF_DT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AUTO_MAN_ROLLOVER := L_TMP_ACC_OBJ.ACCOUNT_DET.AUTO_MAN_ROLLOVER;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).SCHEDULE_BASIS := L_TMP_ACC_OBJ.ACCOUNT_DET.SCHEDULE_BASIS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).UDE_ROLLOVER_BASIS := L_TMP_ACC_OBJ.ACCOUNT_DET.UDE_ROLLOVER_BASIS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ROLLOVER_TYPE := L_TMP_ACC_OBJ.ACCOUNT_DET.ROLLOVER_TYPE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).SPECIAL_AMOUNT := L_TMP_ACC_OBJ.ACCOUNT_DET.SPECIAL_AMOUNT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).RATE_CODE_PREF := L_TMP_ACC_OBJ.ACCOUNT_DET.RATE_CODE_PREF;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PASSBOOK_FACILITY := L_TMP_ACC_OBJ.ACCOUNT_DET.PASSBOOK_FACILITY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ATM_FACILITY := L_TMP_ACC_OBJ.ACCOUNT_DET.ATM_FACILITY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ALLOW_BACK_PERIOD_ENTRY := L_TMP_ACC_OBJ.ACCOUNT_DET.ALLOW_BACK_PERIOD_ENTRY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).INT_STMT := L_TMP_ACC_OBJ.ACCOUNT_DET.INT_STMT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).TRACK_RECEIVABLE_ALIQ := L_TMP_ACC_OBJ.ACCOUNT_DET.TRACK_RECEIVABLE_ALIQ;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).TRACK_RECEIVABLE_MLIQ := L_TMP_ACC_OBJ.ACCOUNT_DET.TRACK_RECEIVABLE_MLIQ;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LIQUIDATION_MODE := L_TMP_ACC_OBJ.ACCOUNT_DET.LIQUIDATION_MODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AMEND_PAST_PAID_SCHEDULE := L_TMP_ACC_OBJ.ACCOUNT_DET.AMEND_PAST_PAID_SCHEDULE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CHEQUE_BOOK_FACILITY := L_TMP_ACC_OBJ.ACCOUNT_DET.CHEQUE_BOOK_FACILITY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LIQ_BACK_VALUED_SCHEDULES := L_TMP_ACC_OBJ.ACCOUNT_DET.LIQ_BACK_VALUED_SCHEDULES;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LIQ_COMP_DATES_FLAG := L_TMP_ACC_OBJ.ACCOUNT_DET.LIQ_COMP_DATES_FLAG;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).RETRIES_AUTO_LIQ := L_TMP_ACC_OBJ.ACCOUNT_DET.RETRIES_AUTO_LIQ;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).RESIDUAL_AMOUNT := L_TMP_ACC_OBJ.ACCOUNT_DET.RESIDUAL_AMOUNT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ACCOUNT_STATUS := L_TMP_ACC_OBJ.ACCOUNT_DET.ACCOUNT_STATUS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AUTH_STAT := L_TMP_ACC_OBJ.ACCOUNT_DET.AUTH_STAT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).VERSION_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LATEST_ESN := L_TMP_ACC_OBJ.ACCOUNT_DET.LATEST_ESN;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).NEXT_ACCR_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.NEXT_ACCR_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).HAS_PROBLEMS := L_TMP_ACC_OBJ.ACCOUNT_DET.HAS_PROBLEMS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PROCESS_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.PROCESS_NO;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AMOUNT_DISBURSED := L_TMP_ACC_OBJ.ACCOUNT_DET.AMOUNT_DISBURSED;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).STOP_ACCRUALS := L_TMP_ACC_OBJ.ACCOUNT_DET.STOP_ACCRUALS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FUNDED_STATUS := L_TMP_ACC_OBJ.ACCOUNT_DET.FUNDED_STATUS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AMORTIZED := L_TMP_ACC_OBJ.ACCOUNT_DET.AMORTIZED;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).RECALC_ACTION_CODE := L_TMP_ACC_OBJ.ACCOUNT_DET.RECALC_ACTION_CODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).MAKER_ID := L_TMP_ACC_OBJ.ACCOUNT_DET.MAKER_ID;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).MAKER_DT_STAMP := L_TMP_ACC_OBJ.ACCOUNT_DET.MAKER_DT_STAMP;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CHECKER_ID := L_TMP_ACC_OBJ.ACCOUNT_DET.CHECKER_ID;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CHECKER_DT_STAMP := L_TMP_ACC_OBJ.ACCOUNT_DET.CHECKER_DT_STAMP;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ARVN_APPLIED := L_TMP_ACC_OBJ.ACCOUNT_DET.ARVN_APPLIED;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ALT_ACC_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.ALT_ACC_NO;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PARTIAL_LIQUIDATION := L_TMP_ACC_OBJ.ACCOUNT_DET.PARTIAL_LIQUIDATION;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ALIQ_REVERSED_PMT := L_TMP_ACC_OBJ.ACCOUNT_DET.ALIQ_REVERSED_PMT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).NO_OF_INSTALLMENTS := L_TMP_ACC_OBJ.ACCOUNT_DET.NO_OF_INSTALLMENTS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FREQUENCY := L_TMP_ACC_OBJ.ACCOUNT_DET.FREQUENCY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FREQUENCY_UNIT := L_TMP_ACC_OBJ.ACCOUNT_DET.FREQUENCY_UNIT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIRST_INS_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.FIRST_INS_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LINKED_REFERENCE := L_TMP_ACC_OBJ.ACCOUNT_DET.LINKED_REFERENCE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LINKAGE_TYPE := L_TMP_ACC_OBJ.ACCOUNT_DET.LINKAGE_TYPE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_1 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_1;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_2 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_2;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_3 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_3;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_4 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_4;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_5 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_5;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_6 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_6;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_7 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_7;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_8 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_8;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_9 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_9;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_10 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_10;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_11 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_11;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_12 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_12;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_13 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_13;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_14 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_14;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_15 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_15;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_16 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_16;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_17 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_17;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_18 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_18;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_19 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_19;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_CHAR_20 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_CHAR_20;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_1 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_1;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_2 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_2;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_3 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_3;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_4 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_4;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_5 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_5;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_6 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_6;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_7 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_7;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_8 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_8;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_9 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_9;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_10 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_10;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_11 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_11;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_12 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_12;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_13 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_13;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_14 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_14;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_15 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_15;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_16 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_16;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_17 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_17;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_18 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_18;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_19 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_19;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_NUMBER_20 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_NUMBER_20;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_1 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_1;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_2 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_2;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_3 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_3;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_4 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_4;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_5 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_5;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_6 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_6;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_7 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_7;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_8 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_8;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_9 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_9;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).FIELD_DATE_10 := L_TMP_ACC_OBJ.ACCOUNT_DET.FIELD_DATE_10;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ROLL_BY := L_TMP_ACC_OBJ.ACCOUNT_DET.ROLL_BY;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).MATURITY_TYPE := L_TMP_ACC_OBJ.ACCOUNT_DET.MATURITY_TYPE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).NET_PRINCIPAL := L_TMP_ACC_OBJ.ACCOUNT_DET.NET_PRINCIPAL;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DR_PAYMENT_MODE := L_TMP_ACC_OBJ.ACCOUNT_DET.DR_PAYMENT_MODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CR_PAYMENT_MODE := L_TMP_ACC_OBJ.ACCOUNT_DET.CR_PAYMENT_MODE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DR_PROD_AC := L_TMP_ACC_OBJ.ACCOUNT_DET.DR_PROD_AC;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CR_PROD_AC := L_TMP_ACC_OBJ.ACCOUNT_DET.CR_PROD_AC;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DR_ACC_BRN := L_TMP_ACC_OBJ.ACCOUNT_DET.DR_ACC_BRN;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CR_ACC_BRN := L_TMP_ACC_OBJ.ACCOUNT_DET.CR_ACC_BRN;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EXT_ACC_NO_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.EXT_ACC_NO_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EXT_ACC_NAME_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.EXT_ACC_NAME_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_BANK_CODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_BANK_CODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_BRN_CODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_BRN_CODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PC_CAT_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PC_CAT_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EXT_ACC_NO_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.EXT_ACC_NO_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EXT_ACC_NAME_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.EXT_ACC_NAME_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_BANK_CODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_BANK_CODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_BRN_CODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_BRN_CODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PC_CAT_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PC_CAT_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CARD_NO := L_TMP_ACC_OBJ.ACCOUNT_DET.CARD_NO;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).INSTRUMENT_NO_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.INSTRUMENT_NO_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ROUTING_NO_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.ROUTING_NO_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).END_POINT_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.END_POINT_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_PROD_CODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_PROD_CODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).SECTOR_CODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.SECTOR_CODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).INSTRUMENT_NO_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.INSTRUMENT_NO_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).ROUTING_NO_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.ROUTING_NO_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).END_POINT_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.END_POINT_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CLG_PROD_CODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.CLG_PROD_CODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).SECTOR_CODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.SECTOR_CODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).UPLOAD_SOURCE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.UPLOAD_SOURCE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).UPLOAD_SOURCE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.UPLOAD_SOURCE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EMI_AMOUNT := L_TMP_ACC_OBJ.ACCOUNT_DET.EMI_AMOUNT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).CUTOFF_TRANSACTION := L_TMP_ACC_OBJ.ACCOUNT_DET.CUTOFF_TRANSACTION;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DELINQUENCY_STATUS := L_TMP_ACC_OBJ.ACCOUNT_DET.DELINQUENCY_STATUS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).INDEX_XRATE := L_TMP_ACC_OBJ.ACCOUNT_DET.INDEX_XRATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).EXECUTION_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.EXECUTION_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).MIGRATION_DATE := L_TMP_ACC_OBJ.ACCOUNT_DET.MIGRATION_DATE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).USGT_STATUS := L_TMP_ACC_OBJ.ACCOUNT_DET.USGT_STATUS;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LAST_INTRADAY_ACCR_DT := L_TMP_ACC_OBJ.ACCOUNT_DET.LAST_INTRADAY_ACCR_DT;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_MODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_MODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_SERVICE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_SERVICE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_NUMBER_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_NUMBER_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ACC_NO_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ACC_NO_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_BANK_CODE_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_BANK_CODE_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_BRANCH_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_BRANCH_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS1_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS1_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS2_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS2_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS3_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS3_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS4_DR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS4_DR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_MODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_MODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_SERVICE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_SERVICE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).GIRO_NUMBER_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.GIRO_NUMBER_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ACC_NO_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ACC_NO_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_BANK_CODE_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_BANK_CODE_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_BRANCH_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_BRANCH_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS1_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS1_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS2_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS2_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS3_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS3_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).PAYER_ADDRESS4_CR := L_TMP_ACC_OBJ.ACCOUNT_DET.PAYER_ADDRESS4_CR;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).DUE_DATES_ON := L_TMP_ACC_OBJ.ACCOUNT_DET.DUE_DATES_ON;

              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).AMT_AVAILABLE := L_TMP_ACC_OBJ.ACCOUNT_DET.AMT_AVAILABLE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).COMMITMENT_TYPE := L_TMP_ACC_OBJ.ACCOUNT_DET.COMMITMENT_TYPE;
              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).LOAN_TYPE := L_TMP_ACC_OBJ.ACCOUNT_DET.LOAN_TYPE;

              L_TB_ACCOUNT_HIST(L_TB_ACCOUNT_HIST.COUNT).RATE_CHG_ACTION := L_TMP_ACC_OBJ.ACCOUNT_DET.RATE_CHG_ACTION;

              L_ACCOUNT_OBJ.ACCOUNT_DET.LATEST_ESN := L_ACCOUNT_OBJ.ACCOUNT_DET.LATEST_ESN + 1;
              L_ACCOUNT_OBJ.ACCOUNT_DET.VERSION_NO := L_ACCOUNT_OBJ.ACCOUNT_DET.VERSION_NO + 1;
              L_TB_ACCOUNT(L_TB_ACCOUNT.COUNT + 1) := L_ACCOUNT_OBJ.ACCOUNT_DET;
              L_TB_ROWID_UPD(L_TB_ROWID_UPD.COUNT + 1) := L_ACCOUNT_OBJ.G_RECORD_ROWID;

              DBG('$$$$$$$$$$$$$$$$l_account_obj.g_tb_events_diary.count ' ||
                  L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.COUNT);

              IF NVL(L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.COUNT, 0) > 0 THEN
                FOR IDX_ED IN L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.FIRST .. L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY.LAST LOOP
                  L_COUNT            := NVL(L_TB_EVENTS_DIARY.COUNT, 0) + 1;
                  L_REC_EVENTS_DIARY := L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY(IDX_ED)
                                        .G_EVENTS_DIARY;

                  L_TB_EVENTS_DIARY(L_COUNT).ACCOUNT_NUMBER := L_REC_EVENTS_DIARY.ACCOUNT_NUMBER;
                  L_TB_EVENTS_DIARY(L_COUNT).BRANCH_CODE := L_REC_EVENTS_DIARY.BRANCH_CODE;
                  L_TB_EVENTS_DIARY(L_COUNT).COMPONENT_NAME := L_REC_EVENTS_DIARY.COMPONENT_NAME;
                  L_TB_EVENTS_DIARY(L_COUNT).EVENT_CODE := L_REC_EVENTS_DIARY.EVENT_CODE;

                  DBG('$$$$$$$$$$$$$$$$$$$l_rec_events_diary.execution_date ' ||
                      L_REC_EVENTS_DIARY.EXECUTION_DATE);

                  IF L_REC_EVENTS_DIARY.EXECUTION_DATE = L_TB_SCH(I)
                    .SCHEDULE_DUE_DATE THEN
                    L_TB_EVENTS_DIARY(L_COUNT).EXECUTION_DATE := L_NEXT_WDAY;
                  ELSE
                    L_TB_EVENTS_DIARY(L_COUNT).EXECUTION_DATE := L_REC_EVENTS_DIARY.EXECUTION_DATE;
                  END IF;

                  L_TB_EVENTS_DIARY(L_COUNT).EXECUTION_STATUS := L_REC_EVENTS_DIARY.EXECUTION_STATUS;
                  L_TB_EVENTS_DIARY(L_COUNT).MAKER_ID := L_REC_EVENTS_DIARY.MAKER_ID;
                  L_TB_EVENTS_DIARY(L_COUNT).MAKER_DT_STAMP := L_REC_EVENTS_DIARY.MAKER_DT_STAMP;
                  L_TB_EVENTS_DIARY(L_COUNT).CHECKER_ID := L_REC_EVENTS_DIARY.CHECKER_ID;
                  L_TB_EVENTS_DIARY(L_COUNT).CHECKER_DT_STAMP := L_REC_EVENTS_DIARY.CHECKER_DT_STAMP;
                  L_TB_EVENTS_DIARY(L_COUNT).EVENT_SEQ_NO := L_REC_EVENTS_DIARY.EVENT_SEQ_NO;
                  L_TB_EVENTS_DIARY(L_COUNT).EVENT_DATE := L_REC_EVENTS_DIARY.EVENT_DATE;
                  L_TB_EVENTS_DIARY(L_COUNT).CONTRACT_STATUS := L_REC_EVENTS_DIARY.CONTRACT_STATUS;
                  L_TB_EVENTS_DIARY(L_COUNT).AUTH_STATUS := L_REC_EVENTS_DIARY.AUTH_STATUS;
                  L_TB_EVENTS_DIARY(L_COUNT).PROCESS_NO := L_REC_EVENTS_DIARY.PROCESS_NO;
                  L_TB_EVENTS_DIARY(L_COUNT).VERSION_NO := L_REC_EVENTS_DIARY.VERSION_NO;

                  L_TB_EVENTS_DIARY_ROWID(L_TB_EVENTS_DIARY_ROWID.COUNT + 1) := L_ACCOUNT_OBJ.G_TB_EVENTS_DIARY(IDX_ED)
                                                                                .G_RECORD_ROWID;

                END LOOP;
              END IF;

              L_COUNT := L_TB_EVENTS_DIARY.COUNT + 1;
              L_TB_EVENTS_DIARY(L_COUNT).ACCOUNT_NUMBER := L_ACCOUNT_OBJ.ACCOUNT_DET.ACCOUNT_NUMBER;
              L_TB_EVENTS_DIARY(L_COUNT).BRANCH_CODE := L_TB_SCH(I)
                                                        .BRANCH_CODE;
              L_TB_EVENTS_DIARY(L_COUNT).COMPONENT_NAME := PKG_MAIN_INT;
              L_TB_EVENTS_DIARY(L_COUNT).EVENT_CODE := 'ADHL';
              L_TB_EVENTS_DIARY(L_COUNT).EXECUTION_DATE := L_TB_SCH(I)
                                                           .SCHEDULE_DUE_DATE;
              L_TB_EVENTS_DIARY(L_COUNT).EXECUTION_STATUS := 'P';
              L_TB_EVENTS_DIARY(L_COUNT).MAKER_ID := GLOBAL.USER_ID;
              L_TB_EVENTS_DIARY(L_COUNT).MAKER_DT_STAMP := P_PROC_DATE;
              L_TB_EVENTS_DIARY(L_COUNT).CHECKER_ID := GLOBAL.USER_ID;
              L_TB_EVENTS_DIARY(L_COUNT).CHECKER_DT_STAMP := P_PROC_DATE;
              L_TB_EVENTS_DIARY(L_COUNT).EVENT_SEQ_NO := L_ACCOUNT_OBJ.ACCOUNT_DET.LATEST_ESN;
              L_TB_EVENTS_DIARY(L_COUNT).EVENT_DATE := P_PROC_DATE;
              L_TB_EVENTS_DIARY(L_COUNT).CONTRACT_STATUS := 'A';
              L_TB_EVENTS_DIARY(L_COUNT).AUTH_STATUS := 'A';
              L_TB_EVENTS_DIARY(L_COUNT).PROCESS_NO := L_ACCOUNT_OBJ.ACCOUNT_DET.PROCESS_NO;
              L_TB_EVENTS_DIARY(L_COUNT).VERSION_NO := L_ACCOUNT_OBJ.ACCOUNT_DET.VERSION_NO;
            END IF;
            L_TB_AC(L_TB_AC.COUNT + 1) := L_ACCOUNT_OBJ.ACCOUNT_DET.ACCOUNT_NUMBER;
            L_TB_BRN(L_TB_BRN.COUNT + 1) := L_ACCOUNT_OBJ.ACCOUNT_DET.BRANCH_CODE;

            L_TB_VER(L_TB_VER.COUNT + 1) := L_TMP_ACC_OBJ.ACCOUNT_DET.VERSION_NO;

            PR_CLEAR;

          EXCEPTION
            WHEN NEXT_TXN THEN
              PR_CLEAR;
              L_ACC_NUM := L_TB_SCH(I).ACCOUNT_NUMBER;
              NULL;
          END;
          L_ACC_NUM := L_TB_SCH(I).ACCOUNT_NUMBER;
        END LOOP;

        PR_INSERT;
        L_TB_SCH.DELETE;

      END IF;

      EXIT WHEN CUR_SCH%NOTFOUND;
    END LOOP;

    L_TB_ACCOUNT.DELETE;
    L_TB_ACCOUNT_COMP_SCH.DELETE;
    L_TB_COMP_BALANCE.DELETE;
    L_TB_AMOUNT_DUE.DELETE;
    L_TB_REVN.DELETE;
    L_TB_EVENTS_DIARY.DELETE;
    L_TB_EVENTS_DIARY_ROWID.DELETE;
    L_TB_SCH.DELETE;

    L_TB_ACCOUNT_HIST.DELETE;
    L_TB_ACCOUNT_COMP_SCH_HIST.DELETE;
    L_TB_COMP_BALANCE_HIST.DELETE;
    L_TB_AMOUNT_DUE_HIST.DELETE;
    L_TB_REVN_HIST.DELETE;
    L_TB_ROWID_UPD.DELETE;

    L_TB_CALC_DATES.DELETE;
    L_ACCOUNT_OBJ := NULL;
    L_TMP_ACC_OBJ := NULL;
    L_TB_AC.DELETE;
    L_TB_BRN.DELETE;
    L_TB_VER.DELETE;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('failed during holiday processing for ' ||
                                     P_BRANCH_CODE || '~' || P_PROC_DATE || '~' ||
                                     P_PROCESS_NO);
      DBG('fn_adch_holiday_for_branch:when others. return false. sqlerrm:' ||
          SQLERRM);

      IF CUR_SCH%ISOPEN THEN
        CLOSE CUR_SCH;
      END IF;

      L_TB_ACCOUNT.DELETE;
      L_TB_ACCOUNT_COMP_SCH.DELETE;
      L_TB_COMP_BALANCE.DELETE;
      L_TB_AMOUNT_DUE.DELETE;
      L_TB_REVN.DELETE;
      L_TB_EVENTS_DIARY.DELETE;
      L_TB_EVENTS_DIARY_ROWID.DELETE;

      L_TB_ACCOUNT_HIST.DELETE;
      L_TB_ACCOUNT_COMP_SCH_HIST.DELETE;
      L_TB_COMP_BALANCE_HIST.DELETE;
      L_TB_REVN_HIST.DELETE;
      L_TB_AMOUNT_DUE_HIST.DELETE;
      L_TB_ROWID_UPD.DELETE;

      L_TB_CALC_DATES.DELETE;
      L_ACCOUNT_OBJ := NULL;
      L_TMP_ACC_OBJ := NULL;
      L_TB_AC.DELETE;
      L_TB_BRN.DELETE;
      L_TB_VER.DELETE;

      P_ERR_CODE  := 'CL-ACCR01;';
      P_ERR_PARAM := SUBSTR(SQLERRM, 1, 50) || '~;';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      ROLLBACK;
      RETURN FALSE;
  END FN_ADCH_HOLIDAY_FOR_BRANCH;

BEGIN

  PKG_PRINCIPAL := CLPKSS_NLS.PRINCIPAL;
  PKG_MAIN_INT  := CLPKS_NLS.MAIN_INT;

END CLPKS_REVN;
