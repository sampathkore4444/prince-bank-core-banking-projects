CREATE OR REPLACE PACKAGE BODY clpks_cldaccnt_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : clpks_cldaccnt_custom.sql
  **
  ** Module     : Retail Lending
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'clpks_cldaccnt_Custom ==>' || p_Msg;
      Debug.Pr_Debug('CL', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_Type_Structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  --sampath starts
  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';
  
    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING MID RATE');
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;
  --sampath ends

  --sampath starts for loan variable interest rate

  FUNCTION FN_GET_TD_BASE_RATE(P_BRANCH IN VARCHAR2, P_CCY IN VARCHAR2)
    RETURN CFTM_FLOAT_RATE_DETAIL.INT_RATE%TYPE AS
  
    L_TD_BASE_RATE CFTM_FLOAT_RATE_DETAIL.INT_RATE%TYPE;
  BEGIN
  
    SELECT A.INT_RATE
      INTO L_TD_BASE_RATE
      FROM CFTMS_FLOAT_RATE_DETAIL A,
           CFTMS_FLOAT_RATE_MASTER B,
           CFTMS_RATE_CODE         C
     WHERE C.BRANCH_CODE = P_BRANCH
       AND C.RATE_CODE = 'TD_1_YR_RT'
       AND C.RECORD_STAT = 'O'
       AND C.ONCE_AUTH = 'Y'
       AND B.BRANCH_CODE = C.BRANCH_CODE
       AND B.RATE_CODE = C.RATE_CODE
       AND B.CCY_CODE = P_CCY
       AND B.BORROW_LEND_IND = 'L'
       AND A.BRANCH_CODE = C.BRANCH_CODE
       AND A.RATE_CODE = C.RATE_CODE
       AND A.CCY_CODE = B.CCY_CODE
       AND A.AMOUNT_SLAB = B.AMOUNT_SLAB
       AND A.EFFECTIVE_DATE = B.EFFECTIVE_DATE
       AND A.TENOR_FROM >= 0
       AND A.TENOR_TO <= 0
       AND A.BORROW_LEND_IND = B.BORROW_LEND_IND;
  
    RETURN L_TD_BASE_RATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_TD_BASE_RATE;
    
  END FN_GET_TD_BASE_RATE;

  FUNCTION FN_GET_LOAN_VAR_DEFAULT_RATE RETURN LMTM_TYPE_VALUES.VALUE%TYPE AS
    L_LOAN_VAR_DEF_RATE LMTM_TYPE_VALUES.VALUE%TYPE;
  BEGIN
  
    SELECT B.VALUE
      INTO L_LOAN_VAR_DEF_RATE
      FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
     WHERE A.TYPE = B.TYPE
       AND A.TYPE = 'LOAN_VAR_DEF';
  
    RETURN L_LOAN_VAR_DEF_RATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_LOAN_VAR_DEF_RATE;
  END FN_GET_LOAN_VAR_DEFAULT_RATE;

  --sampath ends for loan variable interest rate

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
    --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    L_SECTOR_COUNT                 NUMBER := 0;
    --main and sub sector changes ends
  
    --loan variable interest rate starts
    L_RATE_TYPE_COUNT                   NUMBER := 0;
    L_cltb_account_ratetype_custom_hist cltb_account_ratetype_custom_hist%ROWTYPE;
    L_cltb_account_ratetype_custom      cltb_account_ratetype_custom%ROWTYPE;
    L_RATE_TYPE_HIST_COUNT              NUMBER := 0;
    --loan variable interest rate ends
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory..=' || P_ACTION_CODE);
    DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT=' ||
        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT);
  
    IF Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN
      DBG('SAVE CLICKED');
    ELSE
      DBG('SAVE NOT CLICKED');
    END IF;
  
    --sampath starts for loan variable interest rate
    IF P_ACTION_CODE IN ('PRDDFLT', 'NEW') THEN
    
      DBG('Variable interest rate type=' ||
          p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
      
        RETURN FALSE;
      
      END IF;
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' AND
         p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE NOT IN
         ('HL01',
          'HL02',
          'LT01',
          'ST02',
          'CL01',
          'LT02',
          'CG01',
          'CG02',
          'CG03',
          'CG04',
          'FI01',
          'FI02',
          'SME1',
          'SME2',
          'TFL1',
          'TFL2') THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-018', '');
      
        RETURN FALSE;
      
      END IF;
    
    END IF;
    --sampath ends for loan variable interest rate
  
    --sampath starts
    IF P_ACTION_CODE = 'NEW' /*AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED*/
     THEN
    
      --sampath starts for loan variable interest rate
    
      --Rate Code validation 
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' THEN
      
        DBG('P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
            P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
      
        FOR G IN 1 .. P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
        
          --Rate Code and Code Usage Allowed only for Interest Rate UDE ID
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
           .UDE_ID <> 'INTEREST_RATE' THEN
          
            IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
             .RATE_CODE IS NOT NULL OR P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
               .CODE_USAGE IS NOT NULL THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-017', '');
            
              RETURN FALSE;
            
            END IF;
          
          END IF;
        
          --Rate Code and Code Usage are required for Interest Rate UDE ID
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
           .UDE_ID = 'INTEREST_RATE' THEN
          
            IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_CODE IS NULL THEN
            
              --P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RESOLVED_VALUE := NULL;
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');
            
              RETURN FALSE;
            
            END IF;
          
            IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).CODE_USAGE IS NULL OR P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
               .CODE_USAGE <> 'A' THEN
            
              --P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RESOLVED_VALUE := NULL;
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-014', '');
            
              RETURN FALSE;
            
            END IF;
          
            /*DBG('P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RESOLVED_VALUE=' || P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
                .RESOLVED_VALUE);
            
            IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
             .RESOLVED_VALUE IS NULL THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-015', '');
            
              RETURN FALSE;
            
            END IF;*/
          
          END IF;
        
        END LOOP;
      
      END IF;
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'F' THEN
      
        FOR G IN 1 .. P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
        
          --Rate Code and Code Usage should not be allowed for all UDE IDs
          --IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
          -- .UDE_ID = 'INTEREST_RATE' THEN
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_CODE IS NOT NULL THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-013', '');
          
            RETURN FALSE;
          
          END IF;
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).CODE_USAGE IS NOT NULL THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-016', '');
          
            RETURN FALSE;
          
          END IF;
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_BASIS <> 'N' THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-019', '');
          
            RETURN FALSE;
          
          END IF;
        
        --END IF;
        
        END LOOP;
      
      END IF;
    
      --sampath ends for loan variable interest rate
    
      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);
    
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                               0);
      END IF;
    
      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);
      
      END IF;
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 THEN
      
        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
          (loan_account_number,
           branch_code,
           exposure_type,
           sub_exposure_type,
           term_conditions,
           percentage_ltv,
           purchased_prop,
           purchased_prop_usd,
           rating_agency,
           rating_approach,
           risk_class,
           risk_weight,
           out_in_cambodia,
           remark)
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      END IF;
    
      --main and sub sector changes starts
      BEGIN
        SELECT COUNT(1)
          INTO L_SECTOR_COUNT
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_SECTOR_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      IF L_SECTOR_COUNT > 0 THEN
      
        INSERT INTO CLTB_LOAN_SECTOR_DTLS_CUSTOM
          (loan_account_number,
           branch_code,
           main_sector,
           sub_sector,
           of_which_sector)
          SELECT *
            FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
               sub_sector      = p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
               of_which_sector = p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector
        
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_SECTOR_DTLS_CUSTOM
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_sector)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      
        /*p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') - 1);
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.main_sector,' ') + 1);
        
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,1,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') - 1);
                 p_cldaccnt.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,instr(p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,' ') + 1);
        */
      
      END IF;
      --main and sub sector changes ends
    
      --loan variable interest rate starts
      BEGIN
        SELECT COUNT(1)
          INTO L_RATE_TYPE_COUNT
          FROM CLTB_ACCOUNT_RATETYPE_CUSTOM
         WHERE ACCOUNT_NUMBER =
               p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER
           AND BRANCH_CODE = p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          L_RATE_TYPE_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_RATETYPE_CUSTOM
          FROM CLTB_ACCOUNT_RATETYPE_CUSTOM
         WHERE ACCOUNT_NUMBER =
               p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER
           AND BRANCH_CODE = p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_RATETYPE_CUSTOM := NULL;
      END;
    
      IF L_RATE_TYPE_COUNT > 0 THEN
      
        INSERT INTO CLTB_ACCOUNT_RATETYPE_CUSTOM_HIST
          (loan_account_number, branch_code, effective_date, interest_rate_type)
          SELECT *
            FROM CLTB_ACCOUNT_RATETYPE_CUSTOM
           WHERE ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_ACCOUNT_RATETYPE_CUSTOM
                   WHERE ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_ACCOUNT_RATETYPE_CUSTOM
           SET effective_date     = p_cldaccnt.v_cltbs_account_master.value_date,
               interest_rate_type = p_cldaccnt.V_ACCOUNT_RATETYPE_CUSTOM.interest_rate_type
        
         WHERE ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_ACCOUNT_RATETYPE_CUSTOM
            (account_number,
             branch_code,
             effective_date,
             interest_rate_type)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.V_ACCOUNT_RATETYPE_CUSTOM.effective_date,
             p_cldaccnt.V_ACCOUNT_RATETYPE_CUSTOM.interest_rate_type);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      
      END IF;
      --loan variable interest rate ends
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;
    
      --main and sub sector changes starts
      DELETE FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --main and sub sector changes ends
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    DBG('Variable interest rate type=' ||
        p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    DBG('Variable interest rate type=' ||
        p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    DBG('Variable interest rate type=' ||
        p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    DBG('Variable interest rate type=' ||
        p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of clpks_cldaccnt_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Product_Default..');
  
    --sampath starts for loan variable interest rate
    /*IF P_ACTION_CODE = 'PRDDFLT' THEN
    
      DBG('Variable interest rate type=' ||
          p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
      
        RETURN FALSE;
      
      END IF;
      
      p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE;
      
      DBG('P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
          P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
      
      DBG('p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
          p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
          
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
        FOR G IN 1 .. P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(G)
           .UDE_ID = 'INTEREST_RATE' THEN
          
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).RATE_CODE := 'TD_1_YR_RT';
            p_Wrk_cldaccnt.V_CLTBS_ACCOUNT_UDE_VALUES(G).CODE_USAGE := 'A';
          
          END IF;
        
        END LOOP;
      
      END IF;
      
    END IF;*/
    --sampath ends for loan variable interest rate
  
    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Product_Default..');
  
    --sampath starts for loan variable interest rate
    IF P_ACTION_CODE IN ('PRDDFLT', 'SUBSYSPKP_NEW') THEN
    
      DBG('Variable interest rate type=' ||
          p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
    
      DBG('P_wrk_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT=' ||
          P_wrk_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT);
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
      
        RETURN FALSE;
      
      END IF;
    
      p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE;
    
      --While clicking on product default then the make the resolved value as Null
      IF p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' THEN
      
        DBG('P_wrk_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(5).RESOLVED_VALUE=' || P_wrk_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(5)
            .RESOLVED_VALUE);
      
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(5).RESOLVED_VALUE := NULL;
      
      END IF;
    
      --if variable then display maximum effective date
      /* IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' THEN
      
        SELECT p_cldaccnt.v_cltbs_account_master.account_number,
               p_cldaccnt.v_cltbs_account_master.branch_code,
               A.UDE_EFF_DT bulk collect
        
          INTO p_WRK_cldaccnt.v_account_ude_eff_dates
          FROM CLTMS_PRODUCT_UDE_DATES A
         WHERE PRODUCT_CODE =
               p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE
           AND UDE_RULE_CODE = 'DFLT'
           AND CCY_CODE = p_cldaccnt.v_cltbs_account_master.CURRENCY
           AND A.UDE_EFF_DT IN
               (SELECT MAX(UDE_EFF_DT)
                  FROM CLTMS_PRODUCT_UDE_DATES
                
                 WHERE PRODUCT_CODE =
                       p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE
                   AND UDE_RULE_CODE = 'DFLT'
                   AND CCY_CODE = p_cldaccnt.v_cltbs_account_master.CURRENCY);
      
      END IF;*/
    
      /*IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'F' THEN
      
        SELECT p_cldaccnt.v_cltbs_account_master.account_number,
               p_cldaccnt.v_cltbs_account_master.branch_code,
               GLOBAL.application_date bulk collect
        
          INTO p_WRK_cldaccnt.v_account_ude_eff_dates
          FROM CLTMS_PRODUCT_UDE_DATES A
         WHERE PRODUCT_CODE =
               p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE
           AND UDE_RULE_CODE = 'DFLT'
           AND CCY_CODE = p_cldaccnt.v_cltbs_account_master.CURRENCY
           AND A.UDE_EFF_DT IN
               (SELECT MIN(UDE_EFF_DT)
                  FROM CLTMS_PRODUCT_UDE_DATES
                
                 WHERE PRODUCT_CODE =
                       p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE
                   AND UDE_RULE_CODE = 'DFLT'
                   AND CCY_CODE = p_cldaccnt.v_cltbs_account_master.CURRENCY);
      
      END IF;*/
    
    END IF;
    --sampath ends for loan variable interest rate
  
    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Unlock..');
  
    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Unlock');
  
    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Subsys_Pickup..=' || p_Action_code);
  
    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Subsys_Pickup..=' || p_Action_code);
  
    --sampath starts for loan variable interest rate
    DBG('Variable interest rate type=' ||
        p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    DBG('Variable interest rate type=' ||
        p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
  
    IF p_Action_code IN ('NEW', 'MODIFY') THEN
    
      IF p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' THEN
        p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := p_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE;
      END IF;
    END IF;
    --sampath ends for loan variable interest rate
  
    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Enrich..');
  
    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Enrich..');
  
    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..=' || P_ACTION_CODE);
  
    --sampath starts for loan variable interest rate
    IF P_ACTION_CODE IN ('NEW') THEN
    
      DBG('p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE=' ||
          p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.ACCOUNT_NUMBER=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.ACCOUNT_NUMBER);
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.BRANCH_CODE=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.BRANCH_CODE);
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.VALUE_DATE=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.VALUE_DATE);
    
      IF p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE IS NOT NULL THEN
      
        BEGIN
          INSERT INTO cltb_account_ratetype_custom
            (account_number,
             branch_code,
             effective_date,
             interest_rate_type)
          VALUES
            (p_Wrk_cldaccnt.v_cltbs_account_master.ACCOUNT_NUMBER,
             p_Wrk_cldaccnt.v_cltbs_account_master.BRANCH_CODE,
             p_Wrk_cldaccnt.v_cltbs_account_master.VALUE_DATE, --can book date also
             p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN INSERTING INTO cltb_account_ratetype_custom');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
      ELSE
        --FOR OLD LOAN CONTRACTS  OR MANUALLY INSERT USING SCRIPT
      
        BEGIN
          INSERT INTO cltb_account_ratetype_custom
            (account_number,
             branch_code,
             effective_date,
             interest_rate_type)
          VALUES
            (p_Wrk_cldaccnt.v_cltbs_account_master.ACCOUNT_NUMBER,
             p_Wrk_cldaccnt.v_cltbs_account_master.BRANCH_CODE,
             p_Wrk_cldaccnt.v_cltbs_account_master.VALUE_DATE, --can book date also
             p_Wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN INSERTING INTO cltb_account_ratetype_custom');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
      END IF;
    
    END IF;
    --sampath ends for loan variable interest rate
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Process..');
  
    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
    --main and sub sector changes starts
    L_SECTOR_COUNT                 NUMBER := 0;
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
  
  BEGIN
  
    Dbg('In Fn_Post_Process..=' || p_Action_Code);
  
    --sampath starts
  
    IF P_ACTION_CODE = 'NEW' AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN
    
      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);
    
      --Sub Exposure Type Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
            
         AND SUB_EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Term & Conditions Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
            
         AND term_conditions =
             p_cldaccnt.v_loan_risk_score_custom.term_conditions;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');
      
        RETURN FALSE;
      
      END IF;
    
      --% LTV Validation pls check
    
      IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
         '11_Exposures to Real Estate' THEN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND percentage_ltv =
               p_cldaccnt.v_loan_risk_score_custom.percentage_ltv;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      --Purchased Property Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
         AND purchased_prop =
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Purchased Property(USD) Field Validation
      IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
         '11_Exposures to Real Estate' THEN
      
        IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
           p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');
        
          RETURN FALSE;
        
        END IF;
      
        --p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;
      
      ELSE
      
        IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      --Rating Agency Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
         AND rating_agency =
             p_cldaccnt.v_loan_risk_score_custom.rating_agency;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Rating Approach Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
         AND rating_approach =
             p_cldaccnt.v_loan_risk_score_custom.rating_approach;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Risk Class Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             p_cldaccnt.v_loan_risk_score_custom.exposure_type
         AND rating_approach =
             p_cldaccnt.v_loan_risk_score_custom.rating_approach
            
         AND risk_class = p_cldaccnt.v_loan_risk_score_custom.risk_class;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Risk Weight Validation
      IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
         '5_Exposures to Non-Deposit Taking Institutions' THEN
      
        IF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
           'Short term (Up to 3month)' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
             ('40%', '75%', '100%', '150%') THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        ELSIF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
              'Longer than 3 months' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
             ('20%', '50%', '100%', '150%') THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
      ELSE
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE ((EXPOSURE_TYPE NOT IN
               (select value
                    from lmtm_type_values
                   where type = 'RISK_SCORE') AND
               EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type) OR
               (EXPOSURE_TYPE IN
               (select value
                    from lmtm_type_values
                   where type = 'RISK_SCORE') AND
               TERM_CONDITIONS =
               p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS))
           AND RISK_WEIGHT =
               p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
    
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                                   0);
      END IF;
    
      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                                   0);
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 /*OR
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.exposure_type, '*')
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                                                                                                               AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.percentage_ltv, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.total_collat_pool, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.rating_agency, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.rating_approach, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.risk_class, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.risk_weight, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding, '*') AND
                                                                                                                                                                                                                                                                                                                                                               NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
                                                                                                                                                                                                                                                                                                                                                               NVL(p_cldaccnt.v_loan_risk_score_custom.remark, '*')*/
       THEN
      
        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
          (loan_account_number,
           branch_code,
           exposure_type,
           sub_exposure_type,
           term_conditions,
           percentage_ltv,
           purchased_prop,
           purchased_prop_usd,
           rating_agency,
           rating_approach,
           risk_class,
           risk_weight,
           out_in_cambodia,
           remark)
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      END IF;
    
      --main and sub sector changes starts
    
      --Sub Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector
            
         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.SUB_SECTOR;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
      
        RETURN FALSE;
      
      END IF;
    
      --of-which Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector
            
         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccnt.v_loan_sector_dtls_custom.SUB_SECTOR
         AND DECODE(OF_WHICH_SECTOR_CODE,
                    NULL,
                    OF_WHICH_SECTOR_DESC,
                    OF_WHICH_SECTOR_CODE || ' ' || OF_WHICH_SECTOR_DESC) =
             p_cldaccnt.v_loan_sector_dtls_custom.OF_WHICH_SECTOR;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');
      
        RETURN FALSE;
      
      END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_SECTOR_COUNT
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_SECTOR_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      IF L_SECTOR_COUNT > 0 THEN
      
        INSERT INTO CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
          (loan_account_number,
           branch_code,
           main_sector,
           sub_sector,
           of_which_sector)
          SELECT *
            FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
               sub_sector      = p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
               of_which_sector = p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector
        
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_SECTOR_DTLS_CUSTOM
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_Sector)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_sector_dtls_custom.main_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.sub_sector,
             p_cldaccnt.v_loan_sector_dtls_custom.of_which_sector);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
          
        END;
      END IF;
      --main and sub sector changes ends
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;
    
      --main and sub sector changes starts
      DELETE FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --main and sub sector changes ends
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
    --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
  
    --sampath starts for loan variable interest rate
    L_cltb_account_ratetype_custom cltb_account_ratetype_custom%ROWTYPE;
    --sampath ends for loan variable interest rate
  
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    --sampath starts
    IF P_ACTION_CODE IN ('EXECUTEQUERY' /*, 'MODIFY'*/) THEN
      --sampath changes for loan variable interest rate added MODIFY action code
    
      --sampath starts for loan variable interest rate
      BEGIN
        SELECT *
          INTO L_cltb_account_ratetype_custom
          FROM cltb_account_ratetype_custom a
         where a.account_number =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM cltb_account_ratetype_custom
                 WHERE account_number =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_cltb_account_ratetype_custom := NULL;
      END;
    
      p_wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := L_cltb_account_ratetype_custom.Interest_Rate_Type;
      --sampath ends for loan variable interest rate
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      --Get Colltaeral Pool Amount
    
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      --main and sub sector changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      --main and sub sector changes ends
    
      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        --p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;
    
      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      
        --main and sub sector changes starts
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.OF_WHICH_SECTOR;
      
        DBG('ORANGE100');
        -- DBG(P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);
        --DBG(P_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1); --L_TB_UDF(L_UDF_IDX).FIELD_DESC;
        --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1);
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := 'apple1';
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := 'apple2';
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);
        --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := 'apple1';
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') - 1);
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') + 1);
      
        --DBG('ORANGE100='||P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8);
        --DBG(P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR);
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).NAME_FIELD_CHAR := L_TB_UDF(L_UDF_IDX)
        --                                                             .FIELD_NAME;
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1); --FN_UDF_LOV_REQUIRED(L_TB_UDF(L_UDF_IDX).FIELD_NAME);
      
        --main and sub sector changes ends
      
      END IF;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
    --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
  
    --sampath starts for loan variable interest rate
    L_cltb_account_ratetype_custom cltb_account_ratetype_custom%ROWTYPE;
    --sampath ends for loan variable interest rate
  
  BEGIN
  
    dbg('In Fn_Post_Query=' || P_ACTION_CODE);
  
    --sampath starts
    IF P_ACTION_CODE IN ('NEW',
                         'SUBSYSPKP_NEW',
                         'EXECUTEQUERY',
                         'MODIFY',
                         'SUBSYSPKP_MODIFY') THEN
      --sampath changes for loan variable interest rate added MODIFY and SUBSYSPKP_MODIFY action code
    
      --sampath starts for loan variable interest rate
      BEGIN
        SELECT *
          INTO L_cltb_account_ratetype_custom
          FROM cltb_account_ratetype_custom a
         where a.account_number =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM cltb_account_ratetype_custom
                 WHERE account_number =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_cltb_account_ratetype_custom := NULL;
      END;
    
      IF P_ACTION_CODE NOT IN ('MODIFY','SUBSYSPKP_MODIFY') THEN
      
        p_wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := L_cltb_account_ratetype_custom.Interest_Rate_Type;
      
      ELSE
      
        p_wrk_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE := P_cldaccnt.v_account_ratetype_custom.INTEREST_RATE_TYPE;
      
      END IF;
    
      --sampath ends for loan variable interest rate
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID1=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    
      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        -- p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;
    
      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      --main and sub sector changes starts
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      --main and sub sector changes ends
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      
        --main and sub sector changes starts
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR;
        p_Wrk_cldaccnt.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.OF_WHICH_SECTOR;
      
        -- DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8)
        --    .LBL_FIELD_CHAR);
      
        --  P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector; --L_TB_UDF(L_UDF_IDX).FIELD_DESC;
      
        --  DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8)
        --    .LBL_FIELD_CHAR);
      
        --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).NAME_FIELD_CHAR := L_TB_UDF(L_UDF_IDX)
        --                                                             .FIELD_NAME;
      
        --  DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LOV_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4)
        --     .LOV_FIELD_CHAR);
      
        -- P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LBL_FIELD_CHAR := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR; --FN_UDF_LOV_REQUIRED(L_TB_UDF(L_UDF_IDX).FIELD_NAME);
      
        -- DBG('P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).LBL_FIELD_CHAR=' || P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4)
        --    .LBL_FIELD_CHAR);
      
        /*P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') - 1);
                 --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LBL_FIELD_CHAR := 'apple1';
                 --P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).LOV_FIELD_CHAR := 'apple2';
                 P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,' ') + 1);
                 --P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIELD_CHAR_8 := 'apple1';
        
                 P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,1,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') - 1);
                 P_WRK_CLDACCNT.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC:= SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,' ') + 1);
        */
      
        --main and sub sector changes ends
      
      END IF;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END clpks_cldaccnt_custom;
