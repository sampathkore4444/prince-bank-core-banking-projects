CREATE OR REPLACE PACKAGE BODY Clpks_Cldaccnt_Default AS

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    CLPKS_CLDACCNT_DEFAULT_CLUSTER.PR_SKIP_HANDLER(P_STAGE);
    CLPKS_CLDACCNT_DEFAULT_CUSTOM.PR_SKIP_HANDLER(P_STAGE);
  END PR_SKIP_HANDLER;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'Clpks_Cldaccnt_Default ==>' || P_MSG;
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      DEBUG.PR_DEBUG('CL', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_GET_PROCESS_NO(P_BRN_CODE    CLTBS_ACCOUNT_MASTER.BRANCH_CODE%TYPE,
                             P_CUSTOMER_ID IN CLTBS_ACCOUNT_MASTER.CUSTOMER_ID%TYPE,
                             P_PROCESS_NO  OUT CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE,
                             P_ERR_CODE    IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                             P_ERR_PARAM   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_SEQ_NAME     VARCHAR2(25);
    L_STR          VARCHAR2(200);
    L_SEQVAL       INTEGER;
    L_CURSOR       INTEGER;
    L_RETURN       INTEGER;
    L_REC_BRANCH   CLTMS_BRANCH_PARAMETERS%ROWTYPE;
    L_REC_CUSTOMER STTMS_CUSTOMER%ROWTYPE;
    L_PROCESS_NO   CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE;
    CURSOR CR_PROCESS_NO(P_LIAB_ID VARCHAR2, P_BRANCH VARCHAR2) IS
      SELECT PROCESS_NO
        FROM CLTBS_PROCESS_PARTITION
       WHERE BRANCH_CODE = P_BRANCH
         AND LIABILITY_NO = P_LIAB_ID;
  
  BEGIN
  
    DBG('In Fn_Get_Process_No..');
  
    L_REC_BRANCH := CLPKSS_CACHE.FN_BRANCH_PARAMETERS(P_BRN_CODE);
    IF NVL(L_REC_BRANCH.NUM_PARALLEL_JOBS, 1) = 1 THEN
      DBG('Branch Parameter, Num of Parallel jobs is 1, Hence returning 1');
      P_PROCESS_NO := 1;
      RETURN TRUE;
    ELSE
      IF CR_PROCESS_NO%ISOPEN THEN
        CLOSE CR_PROCESS_NO;
      END IF;
    
      IF NOT FCPKS_PARTITION_INFO.GETMIGRATION THEN
        DBG('Calling clpkss_cache.fn_customer, Customer id ::' ||
            P_CUSTOMER_ID);
        IF NOT CLPKSS_CACHE.FN_CUSTOMER(P_CUSTOMER_ID,
                                        L_REC_CUSTOMER,
                                        P_ERR_CODE) THEN
          DBG('clpkss_cache.fn_customer failed with ::' || P_ERR_CODE);
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Calling clpkss_conv_cache.fn_customer, Customer id ::' ||
            P_CUSTOMER_ID);
      END IF;
    
      OPEN CR_PROCESS_NO(L_REC_CUSTOMER.LIABILITY_NO, P_BRN_CODE);
      FETCH CR_PROCESS_NO
        INTO L_PROCESS_NO;
      IF CR_PROCESS_NO%NOTFOUND THEN
      
        L_SEQ_NAME := DBMS_ASSERT.SIMPLE_SQL_NAME('TRSQ_' || P_BRN_CODE ||
                                                  '_PROCESS');
      
        L_STR := 'SELECT ' || L_SEQ_NAME || '.nextval from dual';
      
        DBG('SEQ::' || L_SEQ_NAME || '::' || L_STR);
        L_CURSOR := DBMS_SQL.OPEN_CURSOR;
        DBG(1);
        DBMS_SQL.PARSE(L_CURSOR, L_STR, DBMS_SQL.V7);
        DBG(2);
        DBMS_SQL.DEFINE_COLUMN(L_CURSOR, 1, L_SEQVAL);
        DBG(3);
      
        L_RETURN := DBMS_SQL.EXECUTE_AND_FETCH(L_CURSOR);
        DBG(4);
        DBMS_SQL.COLUMN_VALUE(L_CURSOR, 1, L_SEQVAL);
        DBG(5);
        L_PROCESS_NO := L_SEQVAL;
        DBG('6::' || L_SEQVAL);
        DBMS_SQL.CLOSE_CURSOR(L_CURSOR);
        DBG(7);
        DBG('l_Rec_Customer.Liability_No' || L_REC_CUSTOMER.LIABILITY_NO);
        INSERT INTO CLTBS_PROCESS_PARTITION
          (BRANCH_CODE, LIABILITY_NO, PROCESS_NO)
        VALUES
          (P_BRN_CODE, L_REC_CUSTOMER.LIABILITY_NO, L_PROCESS_NO);
      END IF;
      CLOSE CR_PROCESS_NO;
      P_PROCESS_NO := L_PROCESS_NO;
    
    END IF;
    DBG('Returning From Fn_Get_Process_No with ' || P_PROCESS_NO);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Get_Process_No..::' || SQLERRM);
      IF SQLCODE = -2289 THEN
        DBG('Sequence not Available for Process Number generation');
        P_ERR_CODE  := 'CL-OBJ-136;';
        P_ERR_PARAM := ';';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        P_PROCESS_NO := 1;
        RETURN TRUE;
      ELSE
        P_ERR_CODE  := 'CL-OBJ-135;';
        P_ERR_PARAM := ';';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RETURN FALSE;
      END IF;
  END FN_GET_PROCESS_NO;

  FUNCTION FN_DEFAULT_HOLIDAY_PREF(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_REC_PRODUCT CLTMS_PRODUCT%ROWTYPE;
  
    L_IS_CCYHOLIDAY   CHAR(1) := 'W';
    L_BOOL_LCL        BOOLEAN := FALSE;
    L_ISHOLIDAY       CHAR(1);
    L_IS_HOL_CHK_BOTH CHAR(1);
  
  BEGIN
    DBG('In Fn_Default_Holiday_Pref -->');
  
    L_BOOL_LCL := CLPKSS_UTIL.FN_ISHOLIDAY(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                           L_ISHOLIDAY);
    DBG('l_isholiday : ' || L_ISHOLIDAY);
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK_MAT = 'B' THEN
      L_IS_HOL_CHK_BOTH := 'Y';
    ELSE
      L_IS_HOL_CHK_BOTH := 'N';
    END IF;
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK_MAT IN
       ('C', 'B') THEN
      IF NOT CEPKSS_DATE.FN_ISHOLIDAY_MCCY('CCY',
                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_MAT,
                                           L_IS_HOL_CHK_BOTH,
                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                           L_IS_CCYHOLIDAY) THEN
        DBG('clpks_schedules. ->Result ' || L_IS_CCYHOLIDAY);
        P_ERR_CODE := 'CL-SCH001;';
        RETURN NULL;
      END IF;
    END IF;
    IF NVL(L_ISHOLIDAY, 'X') = 'H' OR NVL(L_IS_CCYHOLIDAY, 'X') = 'H' THEN
      DBG('value date lies on a holiday');
      P_ERR_CODE   := 'CL-ACC-128;';
      P_ERR_PARAMS := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE || ';';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    L_REC_PRODUCT := CLPKS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    DBG('product' || L_REC_PRODUCT.IGNORE_HOLIDAYS);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS              := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS,
                                                                               L_REC_PRODUCT.IGNORE_HOLIDAYS);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH            := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH,
                                                                               L_REC_PRODUCT.MOVE_ACROSS_MONTH);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT            := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT,
                                                                               L_REC_PRODUCT.SCHEDULE_MOVEMENT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.CASCADE_SCHEDULES            := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.CASCADE_SCHEDULES,
                                                                               L_REC_PRODUCT.CASCADE_SCHEDULES);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK                := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK,
                                                                               L_REC_PRODUCT.HOLIDAY_CHECK);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK_MAT            := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK_MAT,
                                                                               L_REC_PRODUCT.HOLIDAY_CHECK_MAT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_SCH              := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_SCH,
                                                                               L_REC_PRODUCT.HOLIDAY_CCY_SCH);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS_MAT_VAL_DT   := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS_MAT_VAL_DT,
                                                                               L_REC_PRODUCT.IGNORE_HOLIDAYS_MAT_VAL_DT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH_MAT_VAL_DT := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH_MAT_VAL_DT,
                                                                               L_REC_PRODUCT.MOVE_ACROSS_MONTH_MAT_VAL_DT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT_MAT_VAL_DT := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT_MAT_VAL_DT,
                                                                               L_REC_PRODUCT.SCHEDULE_MOVEMENT_MAT_VAL_DT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_MAT              := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_MAT,
                                                                               L_REC_PRODUCT.HOLIDAY_CCY_MAT);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.PAYMENT_SCH                  := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.PAYMENT_SCH,
                                                                               L_REC_PRODUCT.PAYMENT_SCH);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHK_REV              := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHK_REV,
                                                                               L_REC_PRODUCT.HOLIDAY_CHK_REV);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS_REV          := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.IGNORE_HOLIDAYS_REV,
                                                                               L_REC_PRODUCT.IGNORE_HOLIDAYS_REV);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH_REV        := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.MOVE_ACROSS_MONTH_REV,
                                                                               L_REC_PRODUCT.MOVE_ACROSS_MONTH_REV);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.CASCADE_SCEDULES_REV         := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.CASCADE_SCEDULES_REV,
                                                                               L_REC_PRODUCT.CASCADE_SCEDULES_REV);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_REV              := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_REV,
                                                                               L_REC_PRODUCT.HOLIDAY_CCY_REV);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT_REV        := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.SCHEDULE_MOVEMENT_REV,
                                                                               L_REC_PRODUCT.SCHEDULE_MOVEMENT_REV);
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK = 'L' THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_SCH := NULL;
    END IF;
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHECK_MAT = 'L' THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_MAT := NULL;
    END IF;
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CHK_REV = 'L' THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.HOLIDAY_CCY_REV := NULL;
    END IF;
    DBG('Fn_Default_Holiday_Pref Account Number is' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.ACCOUNT_NUMBER || 'Bran' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.BRANCH_CODE);
  
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.BRANCH_CODE    := GLOBAL.CURRENT_BRANCH;
  
    DBG('Post Fn_Default_Holiday_Pref Account Number is' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.ACCOUNT_NUMBER || 'Bran' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY.BRANCH_CODE);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Default_Holiday_Pref..');
      L_REC_PRODUCT := NULL;
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('In When Others of Fn_Default_Holiday_Pref.');
      P_ERR_CODE   := 'CL-OBJ-169';
      P_ERR_PARAMS := ';';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_DEFAULT_HOLIDAY_PREF;

  FUNCTION FN_DEFAULT_RATE_PLAN_DETAILS(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                        P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_PERIOD_ST_DT         CLTB_RATE_PLAN_EFF_DATES.PERIOD_ST_DT%TYPE;
    L_PERIOD_END_DT        CLTB_RATE_PLAN_EFF_DATES.PERIOD_END_DT%TYPE;
    L_UDE_TENOR            CLTMS_PRODUCT.UDE_TENOR%TYPE;
    L_UDE_UNIT             CLTMS_PRODUCT.UDE_UNIT%TYPE;
    L_RP_WNDW_UNIT         CLTMS_PRODUCT.RP_WINDOW_UNIT%TYPE;
    L_RP_WNDW_TENOR        CLTMS_PRODUCT.RP_WINDOW_TENOR%TYPE;
    L_PROD_DETAILS         CLTMS_PRODUCT%ROWTYPE;
    L_RTPLAN_EFFDATES_IDX  PLS_INTEGER;
    L_RTPLAN_EFFDATES_CNTR PLS_INTEGER;
    FUNCTION FN_L_CALC_RTPLAN_EFFDATES(L_RT_TENOR IN CLTMS_PRODUCT.UDE_TENOR%TYPE,
                                       L_RT_UNIT  IN VARCHAR2,
                                       L_ST_DT    IN DATE) RETURN DATE IS
      L_RT_DT DATE;
    BEGIN
      DBG('Rate Unit :' || L_RT_UNIT || ', ' || L_RT_TENOR || ', ' ||
          L_ST_DT);
      IF UPPER(L_RT_UNIT) = 'Y' THEN
        L_RT_DT := ADD_MONTHS(L_ST_DT, 12 * L_RT_TENOR);
      ELSIF UPPER(L_RT_UNIT) = 'M' THEN
        L_RT_DT := ADD_MONTHS(L_ST_DT, L_RT_TENOR);
      ELSIF UPPER(L_RT_UNIT) = 'D' THEN
        L_RT_DT := L_ST_DT + L_RT_TENOR;
      ELSE
        DBG('Invalid Tenor Unit for Product Code : ' ||
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
        P_ERR_CODE   := 'CL-OBJ-036';
        P_ERR_PARAMS := ';';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      END IF;
      RETURN L_RT_DT;
    END FN_L_CALC_RTPLAN_EFFDATES;
  BEGIN
    DBG('In Fn_Default_Rate_Plan_Details..');
    L_PROD_DETAILS  := CLPKS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    L_UDE_TENOR     := L_PROD_DETAILS.UDE_TENOR;
    L_UDE_UNIT      := L_PROD_DETAILS.UDE_UNIT;
    L_RP_WNDW_UNIT  := L_PROD_DETAILS.RP_WINDOW_UNIT;
    L_RP_WNDW_TENOR := L_PROD_DETAILS.RP_WINDOW_TENOR;
  
    IF L_UDE_UNIT IS NULL THEN
      RETURN TRUE;
    END IF;
  
    DBG('Val Date = ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE);
    L_PERIOD_ST_DT := FN_L_CALC_RTPLAN_EFFDATES(L_UDE_TENOR,
                                                L_UDE_UNIT,
                                                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE);
    DBG('First Start Date is ' || L_PERIOD_ST_DT);
    WHILE L_PERIOD_ST_DT <=
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE LOOP
      L_PERIOD_END_DT := FN_L_CALC_RTPLAN_EFFDATES(L_RP_WNDW_TENOR,
                                                   L_RP_WNDW_UNIT,
                                                   L_PERIOD_ST_DT);
      IF L_PERIOD_END_DT >
         (P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE) THEN
        L_PERIOD_END_DT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE;
      END IF;
      L_RTPLAN_EFFDATES_IDX := CLPKSS_UTIL.FN_HASH_DATE(L_PERIOD_ST_DT);
      DBG('Start Date~End Date ' || L_PERIOD_ST_DT || '~' ||
          L_PERIOD_END_DT);
      L_RTPLAN_EFFDATES_CNTR := P_WRK_CLDACCNT.V_CLTBS_RATE_PLAN_EFF_DATES.COUNT + 1;
      P_WRK_CLDACCNT.V_CLTBS_RATE_PLAN_EFF_DATES(L_RTPLAN_EFFDATES_CNTR).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
      P_WRK_CLDACCNT.V_CLTBS_RATE_PLAN_EFF_DATES(L_RTPLAN_EFFDATES_CNTR).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      P_WRK_CLDACCNT.V_CLTBS_RATE_PLAN_EFF_DATES(L_RTPLAN_EFFDATES_CNTR).PERIOD_ST_DT := L_PERIOD_ST_DT;
      P_WRK_CLDACCNT.V_CLTBS_RATE_PLAN_EFF_DATES(L_RTPLAN_EFFDATES_CNTR).PERIOD_END_DT := L_PERIOD_END_DT;
    
      L_PERIOD_ST_DT := FN_L_CALC_RTPLAN_EFFDATES(L_UDE_TENOR,
                                                  L_UDE_UNIT,
                                                  L_PERIOD_ST_DT);
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Default_Rate_Plan_Details..');
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('In When Others of Fn_Default_Rate_Plan_Details.');
      P_ERR_CODE   := 'CL-OBJ-134';
      P_ERR_PARAMS := ';';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_DEFAULT_RATE_PLAN_DETAILS;

  FUNCTION FN_COPY_PAY_MODE_DTLS(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SETTL_REC      ISTMS_INSTR%ROWTYPE;
    L_TB_PROD        CLPKS_CACHE.TY_TB_COMPONENTS;
    L_COMPONENT_NAME CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
  
  BEGIN
    RETURN TRUE;
    DBG('In Fn_Copy_Pay_Mode_Dtls..');
    IF NOT ISPKSS.FN_GET_DFLT_STL_INS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                      SUBSTR(P_FUNCTION_ID, 1, 2),
                                      GLOBAL.CURRENT_BRANCH,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                      0,
                                      L_SETTL_REC) THEN
      DBG('Settlement pickup failed');
      RETURN TRUE;
    END IF;
    DBG('Pmnt By Pay = ' || L_SETTL_REC.PAYMENT_BY_PAY);
    IF NVL(L_SETTL_REC.PAYMENT_BY_PAY, '%') = 'M' THEN
      L_TB_PROD := CLPKSS_CACHE.FN_COMPONENTS_FOR_PROD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
      DBG('Cmp = ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT);
      IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT > 0 THEN
        FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.LAST LOOP
          FOR L_REC_RTH IN (SELECT ACCOUNT_HEAD, ACCOUNTING_ROLE
                              FROM CLTM_PRODUCT_RTH
                             WHERE PRODUCT_CODE =
                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE
                               AND ACCOUNTING_ROLE LIKE '%SETTL_BRIDGE') LOOP
            DBG('Role = ' || L_REC_RTH.ACCOUNTING_ROLE);
            IF L_REC_RTH.ACCOUNTING_ROLE = 'DR_SETTL_BRIDGE' THEN
              DBG(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                  .COMPONENT_NAME || ', ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                  .DR_PROD_AC || ', ' || L_REC_RTH.ACCOUNT_HEAD || ', ' ||
                   L_SETTL_REC.RECV_ACCOUNT);
              IF ((NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                       .DR_PROD_AC,
                       '*') = NVL(L_REC_RTH.ACCOUNT_HEAD, '*')) OR
                 (NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                       .DR_PROD_AC,
                       '*') = NVL(L_SETTL_REC.RECV_ACCOUNT, '*'))) THEN
                DBG('Changeing for comp..');
              
                IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                       'ACC') <> 'PDC' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.
                                                                            DR_ACC_BRN;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
                
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                  END IF;
                
                END IF;
              END IF;
            ELSIF L_REC_RTH.ACCOUNTING_ROLE = 'CR_SETTL_BRIDGE' THEN
              DBG(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                  .COMPONENT_NAME || ', ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                  .CR_PROD_AC || ', ' || L_REC_RTH.ACCOUNT_HEAD || ', ' ||
                   L_SETTL_REC.RECV_ACCOUNT);
              IF ((NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                       .CR_PROD_AC,
                       '*') = NVL(L_REC_RTH.ACCOUNT_HEAD, '*')) OR
                 (NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                       .CR_PROD_AC,
                       '*') = NVL(L_SETTL_REC.PAY_ACCOUNT, '*'))) THEN
                DBG('Changeing for comp..');
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
                END IF;
              
              END IF;
            END IF;
          END LOOP;
        END LOOP;
      END IF;
      DBG('Charge Component = ' ||
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.COUNT);
      IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.COUNT > 0 THEN
        FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.LAST LOOP
          FOR L_REC_RTH IN (SELECT ACCOUNT_HEAD, ACCOUNTING_ROLE
                              FROM CLTM_PRODUCT_RTH
                             WHERE PRODUCT_CODE =
                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE
                               AND ACCOUNTING_ROLE LIKE '%SETTL_BRIDGE') LOOP
            DBG('Role = ' || L_REC_RTH.ACCOUNTING_ROLE);
            IF L_REC_RTH.ACCOUNTING_ROLE = 'DR_SETTL_BRIDGE' THEN
              DBG(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                  .COMPONENT_NAME || ', ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                  .DR_PROD_AC || ', ' || L_REC_RTH.ACCOUNT_HEAD || ', ' ||
                   L_SETTL_REC.RECV_ACCOUNT);
              IF ((NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                       .DR_PROD_AC,
                       '*') = NVL(L_REC_RTH.ACCOUNT_HEAD, '*')) OR
                 (NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                       .DR_PROD_AC,
                       '*') = NVL(L_SETTL_REC.RECV_ACCOUNT, '*'))) THEN
                DBG('Changeing for comp..');
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.
                                                                          DR_ACC_BRN;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                END IF;
              
              END IF;
            ELSIF L_REC_RTH.ACCOUNTING_ROLE = 'CR_SETTL_BRIDGE' THEN
              DBG(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                  .COMPONENT_NAME || ', ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                  .CR_PROD_AC || ', ' || L_REC_RTH.ACCOUNT_HEAD || ', ' ||
                   L_SETTL_REC.RECV_ACCOUNT);
              IF ((NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                       .CR_PROD_AC,
                       '*') = NVL(L_REC_RTH.ACCOUNT_HEAD, '*')) OR
                 (NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                       .CR_PROD_AC,
                       '*') = NVL(L_SETTL_REC.PAY_ACCOUNT, '*'))) THEN
                DBG('Changeing for comp..');
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
                END IF;
              
              END IF;
            END IF;
          END LOOP;
        END LOOP;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Copy_Pay_Mode_Dtls..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Fn_Copy_Pay_mode_Dtls..');
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('In When Others of Fn_Copy_Pay_mode_Dtls.');
      P_ERR_CODE   := 'CL-OBJ-134';
      P_ERR_PARAMS := ';';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_COPY_PAY_MODE_DTLS;

  FUNCTION FN_DEFAULT_SETTLEMENT_DETAILS(P_SOURCE           IN VARCHAR2,
                                         P_SOURCE_OPERATION IN VARCHAR2,
                                         P_FUNCTION_ID      IN VARCHAR2,
                                         P_ACTION_CODE      IN VARCHAR2,
                                         P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                         P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                         P_ERR_CODE         IN OUT VARCHAR2,
                                         P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_SETTL_REC      ISTMS_INSTR%ROWTYPE;
    L_COMPONENT_NAME CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
  
    L_RECV            ISTBS_CONTRACTIS.RECEIVER%TYPE;
    L_CVR_REQD        CLTBS_ACCOUNT_SETTL_DETAILS.COVER_REQUIRED%TYPE;
    L_OUR_CORR        ISTBS_CONTRACTIS.OUR_CORRESPONDENT%TYPE;
    L_INSTR_ROW       ISTMS_INSTR%ROWTYPE;
    L_CONT_ROW        ISTBS_CONTRACTIS%ROWTYPE;
    L_CONT_SWIFT_ROW  ISTBS_CONTRACTIS_SWIFT%ROWTYPE;
    L_REC_BRANCH      STTMS_BRANCH%ROWTYPE;
    L_BR_SWIFT_ADDR   STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_CP_NAME         STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_CP_ADR1         STTMS_BRANCH.BRANCH_ADDR1%TYPE;
    L_CP_ADR2         STTMS_BRANCH.BRANCH_ADDR2%TYPE;
    L_CP_ADR3         STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_CP_ADR4         STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_CUST_DETAIL     STTMS_CUSTOMER%ROWTYPE;
    L_PROV_EXISTS     BOOLEAN;
    L_ORG_EXCHRATE    NUMBER;
    L_EXCHRATE_CR     NUMBER;
    L_ORG_EXCHRATE_CR NUMBER;
    L_TB_PROD         CLPKS_CACHE.TY_TB_COMPONENTS;
  
    L_DR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_DR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
    L_CR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_CR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
  
  BEGIN
    DBG('In Fn_Default_Settlement_Details..');
    DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.module_code : ' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE);
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE NOT IN
       ('CI', 'MF') THEN
      IF NOT FN_GET_DFLT_STL_INS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER) THEN
        DBG('Settlement pickup failed');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT ISPKSS.FN_GET_DFLT_STL_INS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                      NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SETTLEMENT_SEQ_NUM,
                                          0),
                                      L_SETTL_REC) THEN
      DBG('Settlement pickup failed');
      RETURN TRUE;
    END IF;
  
    IF L_SETTL_REC.PAYMENT_BY_PAY IS NOT NULL THEN
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE NOT IN
         ('CI', 'MF') THEN
        IF L_SETTL_REC.PAYMENT_BY_PAY <> 'M' THEN
          P_ERR_CODE   := 'CL-ACC-913;';
          P_ERR_PARAMS := L_SETTL_REC.PAYMENT_BY_PAY || '~' ||
                          L_SETTL_REC.PAY_ACCOUNT;
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      
      END IF;
    
      IF (L_SETTL_REC.PAYMENT_BY_PAY = 'M' AND
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE IN ('CI', 'MF')) OR
         (P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE NOT IN
         ('CI', 'MF')) THEN
      
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.EVENT_SEQ_NO := 3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.AMOUNT_TAG := CLPKSS_NLS.PRINCIPAL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS. VERSION_FLAG := 'N';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TAG_CCY := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_BRANCH := L_SETTL_REC.PAY_AC_BRANCH;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACCOUNT := L_SETTL_REC.PAY_ACCOUNT;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY := L_SETTL_REC.PAY_ACCOUNT_CCY;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CCY_RESTRICTION := 'N';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.VALUE_DATE := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAY_RECEIVE := 'P';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_BY := 'E';
      
        L_DR_ACC_ROLE := 'DR_SETTL_BRIDGE';
        L_CR_ACC_ROLE := 'CR_SETTL_BRIDGE';
        IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                           L_DR_ACC_ROLE,
                                           L_DR_ACC_HEAD) THEN
          L_DR_ACC_ROLE := NULL;
          L_DR_ACC_HEAD := NULL;
        END IF;
        IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                           L_CR_ACC_ROLE,
                                           L_CR_ACC_HEAD) THEN
          L_CR_ACC_ROLE := NULL;
          L_CR_ACC_HEAD := NULL;
        END IF;
      
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE IN
           ('CI', 'MF') THEN
          DBG('CI module settlement instruction check starts');
          L_TB_PROD := CLPKSS_CACHE.FN_COMPONENTS_FOR_PROD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
        
          IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT > 0 THEN
            FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.LAST LOOP
              IF L_TB_PROD.COUNT > 0 THEN
                FOR CMP_IDX IN 1 .. L_TB_PROD.COUNT LOOP
                  L_COMPONENT_NAME := L_TB_PROD(CMP_IDX).COMPONENT_NAME;
                  IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                   .COMPONENT_NAME = L_COMPONENT_NAME THEN
                  
                    IF L_DR_ACC_ROLE = 'DR_SETTL_BRIDGE' THEN
                    
                      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'MF' THEN
                        DBG('Debit account ' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC || '~' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                                      NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                          GLOBAL.CURRENT_BRANCH));
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC,
                                                                                      L_SETTL_REC.RECV_ACCOUNT);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                      
                      END IF;
                    
                      IF L_DR_ACC_HEAD = NVL(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC,
                                             L_DR_ACC_HEAD) THEN
                      
                        IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                               'ACC') <> 'PDC' THEN
                          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE <> 'MF' THEN
                            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                          GLOBAL.CURRENT_BRANCH);
                            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                          END IF;
                        
                          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                             L_SETTL_REC.RECV_ACCOUNT);
                          
                          END IF;
                        
                        END IF;
                        DBG('Settlement Currency ' ||
                            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY);
                        DBG('Account Currency ' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
                        IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <>
                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY THEN
                          DBG('Get rp exchange rate');
                        
                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                                  P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                                                  L_ORG_EXCHRATE,
                                                                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                                                                  .EXCHANGE_RATE_DR,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                          
                            DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                                P_ERR_CODE);
                            P_ERR_PARAMS := '~;';
                            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                            RETURN FALSE;
                          END IF;
                        END IF;
                        DBG('p_Wrk_Cldaccnt.v_Account_Components__Cmp(i).exchange_rate_dr :' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                            .EXCHANGE_RATE_DR);
                        DBG('l_Org_Exchrate:' || L_ORG_EXCHRATE);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).ORG_EXCH_RATE_DR := L_ORG_EXCHRATE;
                      END IF;
                    END IF;
                  
                    IF L_CR_ACC_ROLE = 'CR_SETTL_BRIDGE' THEN
                    
                      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'MF' THEN
                        DBG('Debit account111 ' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC || '~' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                                      NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                          GLOBAL.CURRENT_BRANCH));
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC,
                                                                                      L_SETTL_REC.PAY_ACCOUNT);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
                      
                      END IF;
                    
                      IF L_CR_ACC_HEAD = NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC,
                                             L_CR_ACC_HEAD) THEN
                      
                        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE <> 'MF' THEN
                          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                        GLOBAL.CURRENT_BRANCH);
                          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                        END IF;
                      
                        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                           L_SETTL_REC.PAY_ACCOUNT);
                        
                        END IF;
                      
                        DBG('Settlement Currency 111' ||
                            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY);
                        DBG('Account Currency11 ' ||
                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
                        IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <>
                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY THEN
                          DBG('Get rp exchange rate1');
                        
                          IF NOT
                              COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                                  P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                                                  L_ORG_EXCHRATE,
                                                                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                                                                  .EXCHANGE_RATE,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                          
                            DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                                P_ERR_CODE);
                            P_ERR_PARAMS := '~;';
                            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                            RETURN FALSE;
                          END IF;
                        END IF;
                        DBG('p_Wrk_Cldaccnt.v_Account_Components__Cmp(i).exchange_rate :' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                            .EXCHANGE_RATE);
                        DBG('l_Org_Exchrate:' || L_ORG_EXCHRATE);
                        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).ORG_EXCH_RATE := L_ORG_EXCHRATE;
                      
                      END IF;
                    END IF;
                  
                    EXIT;
                  END IF;
                END LOOP;
              
              END IF;
            END LOOP;
          END IF;
        
        ELSE
          DBG('For CL Module');
          DBG('p_Wrk_Cldaccnt.v_Account_Components__Cmp.COUNT :- ' ||
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT);
          IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT > 0 THEN
            FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.LAST LOOP
              DBG(' p_Wrk_Cldaccnt.v_Account_Components__Cmp(i).component_name :- ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                  .COMPONENT_NAME);
              DBG('l_Settl_Rec.Payment_By_Pay :- ' ||
                  L_SETTL_REC.PAYMENT_BY_PAY);
              DBG('l_Settl_Rec.Recv_Account :- ' ||
                  L_SETTL_REC.RECV_ACCOUNT);
              DBG('l_Settl_Rec.Pay_Account :- ' || L_SETTL_REC.PAY_ACCOUNT);
              IF L_SETTL_REC.PAYMENT_BY_PAY IS NOT NULL THEN
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID <>
                   L_SETTL_REC.COUNTERPARTY THEN
                  DBG('Coming here if counterparty is not same as customer id ');
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NOT NULL THEN
                    DBG('Debit account ' ||
                        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC,
                                                                                  L_SETTL_REC.RECV_ACCOUNT);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                         L_SETTL_REC.UI_RECV_ACCOUNT),
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                                  L_SETTL_REC.RECV_AC_BRANCH);
                  ELSE
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                  END IF;
                  DBG('Debit account defaulted in components tab');
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NOT NULL THEN
                    DBG('credit  account  ' ||
                        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC,
                                                                                  L_SETTL_REC.PAY_ACCOUNT);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                         L_SETTL_REC.UI_PAY_ACCOUNT),
                                                                                     L_SETTL_REC.PAY_ACCOUNT);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                                  L_SETTL_REC.PAY_AC_BRANCH);
                  ELSE
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                     L_SETTL_REC.PAY_ACCOUNT);
                  END IF;
                  DBG('credit  account defaulted in components tab');
                ELSE
                
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                   L_SETTL_REC.PAY_ACCOUNT);
                  DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.Dr_Payment_Mode :- ' ||
                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE);
                  IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                         'ACC') <> 'PDC' THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).SETTLEMENT_CCY := L_SETTL_REC.RECV_ACCOUNT_CCY;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                  END IF;
                END IF;
              ELSE
                IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                 .DR_PROD_AC IS NULL THEN
                  IF NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                         .DR_PAYMENT_MODE,
                         'ACC') <> 'PDC' THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
                  END IF;
                END IF;
                IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                 .CR_PROD_AC IS NULL THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
                END IF;
              END IF;
              IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <> P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                .COMPONENT_CCY THEN
                DBG('Get rp exchange rate1');
                IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP            (I)
                                                           .COMPONENT_CCY,
                                                           L_ORG_EXCHRATE,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP            (I)
                                                           .EXCHANGE_RATE,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
                  DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                      P_ERR_CODE);
                  P_ERR_PARAMS := '~;';
                  OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                  RETURN FALSE;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END IF;
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE NOT IN ('CI') THEN
          IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.COUNT > 0 THEN
            FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.LAST LOOP
              IF L_SETTL_REC.PAYMENT_BY_PAY IS NOT NULL THEN
              
                DBG('In Charges ');
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID <>
                   L_SETTL_REC.COUNTERPARTY THEN
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NOT NULL THEN
                    DBG('Debit account ' ||
                        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                                  L_SETTL_REC.RECV_AC_BRANCH);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC,
                                                                                  L_SETTL_REC.RECV_ACCOUNT);
                  
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_DR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                         L_SETTL_REC.UI_RECV_ACCOUNT),
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                  
                  ELSE
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                  END IF;
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NOT NULL THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                                  L_SETTL_REC.PAY_AC_BRANCH);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC,
                                                                                  L_SETTL_REC.PAY_ACCOUNT);
                  
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                         L_SETTL_REC.UI_PAY_ACCOUNT),
                                                                                     L_SETTL_REC.PAY_ACCOUNT);
                  
                  ELSE
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                     L_SETTL_REC.PAY_ACCOUNT);
                  END IF;
                ELSE
                
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).SETTLEMENT_CCY := L_SETTL_REC.RECV_ACCOUNT_CCY;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                   L_SETTL_REC.PAY_ACCOUNT);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                   L_SETTL_REC.RECV_ACCOUNT);
                END IF;
              ELSE
                IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                 .DR_PROD_AC IS NULL THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
                END IF;
                IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                 .CR_PROD_AC IS NULL THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
                END IF;
              END IF;
              IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <> P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
                .COMPONENT_CCY THEN
                DBG('Get rp exchange rate1');
                IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG            (I)
                                                           .COMPONENT_CCY,
                                                           L_ORG_EXCHRATE,
                                                           P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG            (I)
                                                           .EXCHANGE_RATE,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
                  DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                      P_ERR_CODE);
                  P_ERR_PARAMS := '~;';
                  OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                  RETURN FALSE;
                END IF;
              END IF;
            END LOOP;
          END IF;
        
        END IF;
      
        IF NOT CLPKS_CACHE.FN_CUSTOMER(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                       L_CUST_DETAIL,
                                       P_ERR_CODE) THEN
          DBG('Failed in clpks_cache.fn_customer');
        END IF;
        IF L_CUST_DETAIL.CUSTOMER_TYPE = 'B' THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE := 'B';
        ELSE
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE := 'C';
        END IF;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CHANGE_AC             := 'Y';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CHANGE_RATE           := 'Y';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PARTY_INFO_ALLOWED    := 'Y';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.COVER_REQUIRED        := 'N';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.NETTING_INDICATOR     := 'N';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.OUR_CORRESPONDENT     := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RECEIVER              := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST1        := L_SETTL_REC.INT_REIM_INST1;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST2        := L_SETTL_REC.INT_REIM_INST2;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST3        := L_SETTL_REC.INT_REIM_INST3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST4        := L_SETTL_REC.INT_REIM_INST4;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP1         := L_SETTL_REC.RCVR_CORRESP1;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP2         := L_SETTL_REC.RCVR_CORRESP2;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP3         := L_SETTL_REC.RCVR_CORRESP3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP4         := L_SETTL_REC.RCVR_CORRESP4;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY1         := L_SETTL_REC.INTERMEDIARY1;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY2         := L_SETTL_REC.INTERMEDIARY2;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY3         := L_SETTL_REC.INTERMEDIARY3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY4         := L_SETTL_REC.INTERMEDIARY4;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN1       := L_SETTL_REC.ACC_WITH_INSTN1;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN2       := L_SETTL_REC.ACC_WITH_INSTN2;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN3       := L_SETTL_REC.ACC_WITH_INSTN3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN4       := L_SETTL_REC.ACC_WITH_INSTN4;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS1      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS2      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS3      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS4      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO1    := L_SETTL_REC.SNDR_TO_RCVR_INFO1;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO2    := L_SETTL_REC.SNDR_TO_RCVR_INFO2;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO3    := L_SETTL_REC.SNDR_TO_RCVR_INFO3;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO4    := L_SETTL_REC.SNDR_TO_RCVR_INFO4;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO5    := L_SETTL_REC.SNDR_TO_RCVR_INFO5;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO6    := L_SETTL_REC.SNDR_TO_RCVR_INFO6;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.EX_RATE_FLAG          := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ERI_CCY               := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ERI_AMOUNT            := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RATE_CODE_PREFERRED   := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN5       := L_SETTL_REC.ACC_WITH_INSTN5;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION5    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY5         := L_SETTL_REC.INTERMEDIARY5;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST5        := L_SETTL_REC.INT_REIM_INST5;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER5    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION5 := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP5         := L_SETTL_REC.RCVR_CORRESP5;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY5      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SEND_MESG             := 'Y';
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.MIN_EVENT_SEQ_NO      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERPAY_GENERATED    := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CLEARING_NETWORK      := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.GENERATION_DATE       := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.IBAN_AC_NO            := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ISSUING_BANK          := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYABLE_BRANCH        := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PRINTED_STATIONARY_NO := NULL;
        DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.cr_prod_ac' ||
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC ||
            'l_Settl_Rec.Pay_Ac_Branch' || L_SETTL_REC.PAY_AC_BRANCH);
        DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.cr_acc_brn' ||
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN ||
            'l_Settl_Rec.Pay_Account' || L_SETTL_REC.PAY_ACCOUNT);
        IF NOT ISPKSS.FN_GET_IS_INFO(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                     3,
                                     CLPKS_NLS.PRINCIPAL,
                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                     'P',
                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE,
                                     L_SETTL_REC.PAY_ACCOUNT_CCY,
                                     L_SETTL_REC.PAY_ACCOUNT,
                                     L_SETTL_REC.PAY_AC_BRANCH,
                                     NULL,
                                     L_CVR_REQD,
                                     L_RECV,
                                     L_OUR_CORR,
                                     L_INSTR_ROW,
                                     L_CONT_ROW,
                                     L_CONT_SWIFT_ROW,
                                     P_ERR_CODE) THEN
          DBG('Istm instr fetch failed with ' || P_ERR_CODE);
          RETURN FALSE;
        END IF;
        L_REC_BRANCH := CLPKSS_CACHE.FN_STTM_BRANCH(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
        IF LENGTH(L_REC_BRANCH.SWIFT_ADDR) > 11 THEN
          L_BR_SWIFT_ADDR := SUBSTR(L_REC_BRANCH.SWIFT_ADDR, 1, 11);
        ELSIF LENGTH(L_REC_BRANCH.SWIFT_ADDR) < 11 THEN
          IF LENGTH(L_REC_BRANCH.SWIFT_ADDR) > 8 THEN
            L_BR_SWIFT_ADDR := SUBSTR(L_REC_BRANCH.SWIFT_ADDR, 1, 8);
          ELSE
            L_BR_SWIFT_ADDR := L_REC_BRANCH.SWIFT_ADDR;
          END IF;
        END IF;
        IF NOT ISPKSS.FN_GET_COUNTERPARTYDETAILS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                 L_CP_NAME,
                                                 L_CP_ADR1,
                                                 L_CP_ADR2,
                                                 L_CP_ADR3,
                                                 L_CP_ADR4,
                                                 P_ERR_CODE) THEN
          DBG('returning false while getting customer details ');
          RETURN FALSE;
        END IF;
        IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE = 'B' THEN
          IF L_BR_SWIFT_ADDR IS NOT NULL THEN
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION1 := L_BR_SWIFT_ADDR;
          ELSE
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION1 := L_REC_BRANCH.BRANCH_NAME;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION2 := L_REC_BRANCH.BRANCH_ADDR1;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION3 := L_REC_BRANCH.BRANCH_ADDR2;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION4 := L_REC_BRANCH.BRANCH_ADDR3;
          END IF;
          IF L_INSTR_ROW.BENEF_INSTITUTION1 IS NOT NULL THEN
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION1 := L_INSTR_ROW.BENEF_INSTITUTION1;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION2 := L_INSTR_ROW.BENEF_INSTITUTION2;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION3 := L_INSTR_ROW.BENEF_INSTITUTION3;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION4 := L_INSTR_ROW.BENEF_INSTITUTION4;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION5 := L_INSTR_ROW.BENEF_INSTITUTION5;
          ELSIF L_CP_NAME IS NOT NULL AND P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID !=
                L_REC_BRANCH.WALKIN_CUSTOMER THEN
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION1 := L_CP_NAME;
          END IF;
        
          IF L_INSTR_ROW.BENEF_INST1_FOR_COVER IS NOT NULL THEN
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST1_FOR_COVER := L_INSTR_ROW.BENEF_INST1_FOR_COVER;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST2_FOR_COVER := L_INSTR_ROW.BENEF_INST2_FOR_COVER;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST3_FOR_COVER := L_INSTR_ROW.BENEF_INST3_FOR_COVER;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST4_FOR_COVER := L_INSTR_ROW.BENEF_INST4_FOR_COVER;
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST5_FOR_COVER := L_INSTR_ROW.BENEF_INST5_FOR_COVER;
          END IF;
        ELSE
          IF L_BR_SWIFT_ADDR IS NOT NULL THEN
          
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1,
                                                                             L_REC_BRANCH.BRANCH_NAME);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2,
                                                                             L_BR_SWIFT_ADDR);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3,
                                                                             L_REC_BRANCH.BRANCH_ADDR2);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4,
                                                                             L_REC_BRANCH.BRANCH_ADDR3);
          
          ELSE
          
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1,
                                                                             L_REC_BRANCH.BRANCH_NAME);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2,
                                                                             L_REC_BRANCH.BRANCH_ADDR1);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3,
                                                                             L_REC_BRANCH.BRANCH_ADDR2);
            P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4 := NVL(P_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4,
                                                                             L_REC_BRANCH.BRANCH_ADDR3);
          
          END IF;
        END IF;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RECEIVER          := L_RECV;
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.OUR_CORRESPONDENT := L_OUR_CORR;
      
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NULL THEN
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN := L_SETTL_REC.RECV_AC_BRANCH;
        END IF;
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NULL THEN
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN := L_SETTL_REC.PAY_AC_BRANCH;
        END IF;
      
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                         L_SETTL_REC.UI_PAY_ACCOUNT),
                                                                     L_SETTL_REC.PAY_ACCOUNT);
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                         L_SETTL_REC.UI_RECV_ACCOUNT),
                                                                     L_SETTL_REC.RECV_ACCOUNT);
        END IF;
      
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                    L_SETTL_REC.PAY_AC_BRANCH),
                                                                GLOBAL.CURRENT_BRANCH);
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN := NVL(NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                    L_SETTL_REC.RECV_AC_BRANCH),
                                                                GLOBAL.CURRENT_BRANCH);
      
      END IF;
    
    ELSE
      L_TB_PROD.DELETE;
      L_TB_PROD := CLPKSS_CACHE.FN_COMPONENTS_FOR_PROD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE NOT IN
         ('CI', 'MF') THEN
        IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT > 0 THEN
          FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.LAST LOOP
            IF L_SETTL_REC.PAYMENT_BY_PAY IS NOT NULL THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
            
              IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                 L_SETTL_REC.PAY_ACCOUNT);
              END IF;
            
              IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                     'ACC') <> 'PDC' THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                   L_SETTL_REC.RECV_ACCOUNT);
                END IF;
              
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).SETTLEMENT_CCY := L_SETTL_REC.RECV_ACCOUNT_CCY;
              END IF;
            ELSE
              IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
               .DR_PROD_AC IS NULL THEN
                IF NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
                       .DR_PAYMENT_MODE,
                       'ACC') <> 'PDC' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
                
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                  END IF;
                
                END IF;
              END IF;
              IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
               .CR_PROD_AC IS NULL THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
                END IF;
              
              END IF;
            END IF;
            IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <> P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
              .COMPONENT_CCY THEN
              DBG('Get rp exchange rate1');
            
              IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP            (I)
                                                         .COMPONENT_CCY,
                                                         L_ORG_EXCHRATE,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP            (I)
                                                         .EXCHANGE_RATE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
              
                DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                    P_ERR_CODE);
                P_ERR_PARAMS := '~;';
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
          END LOOP;
        END IF;
        IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.COUNT > 0 THEN
          FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG.LAST LOOP
            IF L_SETTL_REC.PAYMENT_BY_PAY IS NOT NULL THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
            
              IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                 L_SETTL_REC.PAY_ACCOUNT);
              END IF;
            
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).SETTLEMENT_CCY := L_SETTL_REC.RECV_ACCOUNT_CCY;
            ELSE
              IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
               .DR_PROD_AC IS NULL THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
                END IF;
              
              END IF;
              IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
               .CR_PROD_AC IS NULL THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
              
                IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
                END IF;
              
              END IF;
            END IF;
            IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY <> P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(I)
              .COMPONENT_CCY THEN
              DBG('Get rp exchange rate1');
            
              IF NOT COPKSS_RP_PROCESSING.FN_GET_RP_RATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG            (I)
                                                         .COMPONENT_CCY,
                                                         L_ORG_EXCHRATE,
                                                         P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG            (I)
                                                         .EXCHANGE_RATE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
              
                DBG('Copkss_rp_processing.fn_get_rp_rate failed with :-( ' ||
                    P_ERR_CODE);
                P_ERR_PARAMS := '~;';
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
          END LOOP;
        END IF;
      END IF;
    END IF;
    DBG('Returning Success From Fn_Default_Settlement_Details');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of Fn_Default_Settlement_Details ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_SETTLEMENT_DETAILS;

  FUNCTION FN_DEFAULT_SETTLEMENT_SUBSIDY(P_SOURCE           IN VARCHAR2,
                                         P_SOURCE_OPERATION IN VARCHAR2,
                                         P_FUNCTION_ID      IN VARCHAR2,
                                         P_ACTION_CODE      IN VARCHAR2,
                                         P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                         P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                         P_ERR_CODE         IN OUT VARCHAR2,
                                         P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_SETTL_REC       ISTMS_INSTR%ROWTYPE;
    NO_OF_RECORDS     NUMBER := 0;
    LO_AC_CCY         VARCHAR2(4);
    LO_ERR_CODE       VARCHAR2(10);
    LO_XFER_TYPE_FLAG VARCHAR2(4);
    TYPE PARTY_TABLE IS TABLE OF NLS_TABLE.DESCRIPTION_COLUMN%TYPE INDEX BY BINARY_INTEGER;
    LO_PAY_DETAILS        PARTY_TABLE;
    LO_BY_ORDER_OF        PARTY_TABLE;
    LO_ULT_BEN            PARTY_TABLE;
    L_RECV                ISTBS_CONTRACTIS.RECEIVER%TYPE;
    L_OUR_CORR            ISTBS_CONTRACTIS.OUR_CORRESPONDENT%TYPE;
    LO_COVER_REQUIRED     ISTBS_CONTRACTIS.COVER_REQUIRED%TYPE;
    LO_ERI_CCY            ISTBS_CONTRACTIS.ERI_CCY%TYPE;
    LO_ERI_AMOUNT         ISTBS_CONTRACTIS.ERI_AMOUNT%TYPE;
    L_RATE_CODE_PREFERRED CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_TEMP_EUR_FLAG       CYTMS_CCY_DEFN.EUR_CONVERSION_REQD%TYPE;
    L_TEMP_EUR            CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_SETTLE_CCY          CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    LO_SR_TYPE            VARCHAR(1);
    LO_ISTM_REC_BIC       ISPKSS.ISDETAILS;
    L_PREVTAGCCY          ISTBS_CONTRACTIS.TAG_CCY%TYPE;
    L_INSTR_ROW           ISTMS_INSTR%ROWTYPE;
    L_CONT_ROW            ISTBS_CONTRACTIS%ROWTYPE;
    L_CONT_SWIFT_ROW      ISTBS_CONTRACTIS_SWIFT%ROWTYPE;
    L_CP_NAME             STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_CP_ADR1             STTMS_BRANCH.BRANCH_ADDR1%TYPE;
    L_CP_ADR2             STTMS_BRANCH.BRANCH_ADDR2%TYPE;
    L_CP_ADR3             STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_CP_ADR4             STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_BR_SWIFT_ADDR       STTMS_BRANCH.BRANCH_ADDR3%TYPE;
    L_ESN                 CLTBS_ACCOUNT_MASTER.LATEST_ESN%TYPE := 3;
    L_CUST_TYPE           STTMS_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_CVR_REQD            CLTBS_ACCOUNT_SETTL_DETAILS.COVER_REQUIRED%TYPE;
    L_COMPONENT_NAME      CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
    L_TB_PROD             CLPKS_CACHE.TY_TB_COMPONENTS;
    L_REC_BRANCH          STTMS_BRANCH%ROWTYPE;
  BEGIN
    DBG('In Fn_Default_Settlement_Subsidy..');
  
    IF NOT ISPKSS.FN_GET_DFLT_STL_INS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                      'CL',
                                      GLOBAL.CURRENT_BRANCH,
                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                      0,
                                      L_SETTL_REC) THEN
      DBG('Settlement pickup failed');
      RETURN TRUE;
    END IF;
    IF NVL(L_SETTL_REC.PAYMENT_BY_PAY, '%') = 'M' THEN
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.EVENT_SEQ_NO := 3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.AMOUNT_TAG := CLPKSS_NLS.PRINCIPAL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS. VERSION_FLAG := 'N';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TAG_CCY := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_BRANCH := L_SETTL_REC.PAY_AC_BRANCH;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACCOUNT := L_SETTL_REC.PAY_ACCOUNT;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_CCY := L_SETTL_REC.PAY_ACCOUNT_CCY;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CCY_RESTRICTION := 'N';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.VALUE_DATE := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAY_RECEIVE := 'P';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_BY := 'E';
    
      L_TB_PROD := CLPKSS_CACHE.FN_COMPONENTS_FOR_PROD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    
      IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.COUNT > 0 THEN
        FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.LAST LOOP
          IF L_TB_PROD.COUNT > 0 THEN
            FOR CMP_IDX IN 1 .. L_TB_PROD.COUNT LOOP
              L_COMPONENT_NAME := L_TB_PROD(CMP_IDX).COMPONENT_NAME;
              IF P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I)
               .COMPONENT_NAME = L_COMPONENT_NAME THEN
                IF L_TB_PROD(CMP_IDX)
                 .COMPONENT_TYPE = 'I' AND
                    L_COMPONENT_NAME != CLPKS_NLS.MAIN_INT AND
                    L_COMPONENT_NAME != CLPKS_NLS.PRINCIPAL THEN
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_ACC_BRN := NVL(L_SETTL_REC.RECV_AC_BRANCH,
                                                                                GLOBAL.CURRENT_BRANCH);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_ACC_BRN := NVL(L_SETTL_REC.PAY_AC_BRANCH,
                                                                                GLOBAL.CURRENT_BRANCH);
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).DR_PROD_AC := L_SETTL_REC.RECV_ACCOUNT;
                
                  IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_DR_PROD_AC := NVL(L_SETTL_REC.UI_RECV_ACCOUNT,
                                                                                     L_SETTL_REC.RECV_ACCOUNT);
                    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).UI_CR_PROD_AC := NVL(L_SETTL_REC.UI_PAY_ACCOUNT,
                                                                                     L_SETTL_REC.PAY_ACCOUNT);
                  END IF;
                
                  P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(I).CR_PROD_AC := L_SETTL_REC.PAY_ACCOUNT;
                END IF;
                EXIT;
              END IF;
            END LOOP;
          END IF;
        END LOOP;
      END IF;
    
      SELECT CUSTOMER_TYPE
        INTO L_CUST_TYPE
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO =
             P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
    
      IF L_CUST_TYPE = 'B' THEN
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE := 'B';
      ELSE
        P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE := 'C';
      END IF;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CHANGE_AC             := 'Y';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CHANGE_RATE           := 'Y';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PARTY_INFO_ALLOWED    := 'Y';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.COVER_REQUIRED        := 'N';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.NETTING_INDICATOR     := 'N';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.OUR_CORRESPONDENT     := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RECEIVER              := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST1        := L_SETTL_REC.INT_REIM_INST1;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST2        := L_SETTL_REC.INT_REIM_INST2;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST3        := L_SETTL_REC.INT_REIM_INST3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST4        := L_SETTL_REC.INT_REIM_INST4;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP1         := L_SETTL_REC.RCVR_CORRESP1;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP2         := L_SETTL_REC.RCVR_CORRESP2;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP3         := L_SETTL_REC.RCVR_CORRESP3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP4         := L_SETTL_REC.RCVR_CORRESP4;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY1         := L_SETTL_REC.INTERMEDIARY1;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY2         := L_SETTL_REC.INTERMEDIARY2;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY3         := L_SETTL_REC.INTERMEDIARY3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY4         := L_SETTL_REC.INTERMEDIARY4;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN1       := L_SETTL_REC.ACC_WITH_INSTN1;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN2       := L_SETTL_REC.ACC_WITH_INSTN2;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN3       := L_SETTL_REC.ACC_WITH_INSTN3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN4       := L_SETTL_REC.ACC_WITH_INSTN4;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS1      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS2      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS3      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYMENT_DETAILS4      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO1    := L_SETTL_REC.SNDR_TO_RCVR_INFO1;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO2    := L_SETTL_REC.SNDR_TO_RCVR_INFO2;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO3    := L_SETTL_REC.SNDR_TO_RCVR_INFO3;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO4    := L_SETTL_REC.SNDR_TO_RCVR_INFO4;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO5    := L_SETTL_REC.SNDR_TO_RCVR_INFO5;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SNDR_TO_RCVR_INFO6    := L_SETTL_REC.SNDR_TO_RCVR_INFO6;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.EX_RATE_FLAG          := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ERI_CCY               := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ERI_AMOUNT            := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RATE_CODE_PREFERRED   := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ACC_WITH_INSTN5       := L_SETTL_REC.ACC_WITH_INSTN5;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION5    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERMEDIARY5         := L_SETTL_REC.INTERMEDIARY5;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INT_REIM_INST5        := L_SETTL_REC.INT_REIM_INST5;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER5    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION5 := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RCVR_CORRESP5         := L_SETTL_REC.RCVR_CORRESP5;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY5      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.SEND_MESG             := 'Y';
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.MIN_EVENT_SEQ_NO      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.INTERPAY_GENERATED    := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.CLEARING_NETWORK      := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.GENERATION_DATE       := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.IBAN_AC_NO            := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ISSUING_BANK          := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PAYABLE_BRANCH        := NULL;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.PRINTED_STATIONARY_NO := NULL;
    
      IF NOT ISPKSS.FN_GET_IS_INFO(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                   3,
                                   'PRINCIPAL',
                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                   'P',
                                   GLOBAL.CURRENT_BRANCH,
                                   'CL',
                                   L_SETTL_REC.PAY_ACCOUNT_CCY,
                                   L_SETTL_REC.PAY_ACCOUNT,
                                   L_SETTL_REC.PAY_AC_BRANCH,
                                   NULL,
                                   L_CVR_REQD,
                                   L_RECV,
                                   L_OUR_CORR,
                                   L_INSTR_ROW,
                                   L_CONT_ROW,
                                   L_CONT_SWIFT_ROW,
                                   P_ERR_CODE) THEN
        DBG('Istm instr fetch failed with ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    
      L_REC_BRANCH := CLPKSS_CACHE.FN_STTM_BRANCH(GLOBAL.CURRENT_BRANCH);
      IF LENGTH(L_REC_BRANCH.SWIFT_ADDR) > 11 THEN
        L_BR_SWIFT_ADDR := SUBSTR(L_REC_BRANCH.SWIFT_ADDR, 1, 11);
      ELSIF LENGTH(L_REC_BRANCH.SWIFT_ADDR) < 11 THEN
        IF LENGTH(L_REC_BRANCH.SWIFT_ADDR) > 8 THEN
          L_BR_SWIFT_ADDR := SUBSTR(L_REC_BRANCH.SWIFT_ADDR, 1, 8);
        ELSE
          L_BR_SWIFT_ADDR := L_REC_BRANCH.SWIFT_ADDR;
        END IF;
      END IF;
    
      IF NOT ISPKSS.FN_GET_COUNTERPARTYDETAILS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                               L_CP_NAME,
                                               L_CP_ADR1,
                                               L_CP_ADR2,
                                               L_CP_ADR3,
                                               L_CP_ADR4,
                                               P_ERR_CODE) THEN
        DBG('returning false while getting customer details ');
        RETURN FALSE;
      END IF;
    
      IF P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.TRANSFER_TYPE = 'B' THEN
        IF L_BR_SWIFT_ADDR IS NOT NULL THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION1 := L_BR_SWIFT_ADDR;
        ELSE
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION1 := L_REC_BRANCH.BRANCH_NAME;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION2 := L_REC_BRANCH.BRANCH_ADDR1;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION3 := L_REC_BRANCH.BRANCH_ADDR2;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_INSTITUTION4 := L_REC_BRANCH.BRANCH_ADDR3;
        END IF;
      
        IF L_INSTR_ROW.BENEF_INSTITUTION1 IS NOT NULL THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION1 := L_INSTR_ROW.BENEF_INSTITUTION1;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION2 := L_INSTR_ROW.BENEF_INSTITUTION2;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION3 := L_INSTR_ROW.BENEF_INSTITUTION3;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION4 := L_INSTR_ROW.BENEF_INSTITUTION4;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION5 := L_INSTR_ROW.BENEF_INSTITUTION5;
        ELSIF L_CP_NAME IS NOT NULL AND P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID !=
              L_REC_BRANCH.WALKIN_CUSTOMER THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INSTITUTION1 := L_CP_NAME;
        END IF;
        IF L_INSTR_ROW.BENEF_INST1_FOR_COVER IS NOT NULL THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST1_FOR_COVER := L_INSTR_ROW.BENEF_INST1_FOR_COVER;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST2_FOR_COVER := L_INSTR_ROW.BENEF_INST2_FOR_COVER;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST3_FOR_COVER := L_INSTR_ROW.BENEF_INST3_FOR_COVER;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST4_FOR_COVER := L_INSTR_ROW.BENEF_INST4_FOR_COVER;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.BENEF_INST5_FOR_COVER := L_INSTR_ROW.BENEF_INST5_FOR_COVER;
        END IF;
      ELSE
        IF L_BR_SWIFT_ADDR IS NOT NULL THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1 := L_BR_SWIFT_ADDR;
        ELSE
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER1 := L_REC_BRANCH.BRANCH_NAME;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER2 := L_REC_BRANCH.BRANCH_ADDR1;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER3 := L_REC_BRANCH.BRANCH_ADDR2;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ORDERING_CUSTOMER4 := L_REC_BRANCH.BRANCH_ADDR3;
        END IF;
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID !=
           L_REC_BRANCH.WALKIN_CUSTOMER THEN
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY1 := L_CP_NAME;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY2 := L_CP_ADR1;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY3 := L_CP_ADR2;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY4 := L_CP_ADR3;
          P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.ULT_BENEFICIARY5 := L_CP_ADR4;
        END IF;
      END IF;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.RECEIVER          := L_RECV;
      P_WRK_CLDACCNT.V_ACCOUNT_SETTL_DETAILS.OUR_CORRESPONDENT := L_OUR_CORR;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When Others BOMB in Defaulting Settlement Details Fn_Default_SEttlement_Subsidy with SQL ERROR :' ||
          SUBSTR(SQLERRM, 1, 250));
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('When Others BOMB in Defaulting Settl Details Fn_Default_SEttlement_Subsidy');
      P_ERR_CODE   := 'CL-OBJ-134' || ';';
      P_ERR_PARAMS := ';';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_DEFAULT_SETTLEMENT_SUBSIDY;
  FUNCTION FN_DEFAULT_UDE(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                          P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR CR_UDE_DATE(P_PRD_CODE  CLTBS_ACCOUNT_MASTER.PRODUCT_CODE%TYPE,
                       P_RULE_CODE CLTMS_PRODUCT_UDE_RULES.UDE_RULE_CODE%TYPE,
                       P_VAL_DT    CLTBS_ACCOUNT_MASTER.VALUE_DATE%TYPE,
                       P_CCY       CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE) IS
      SELECT /*+ INDEX_DESC  (PK_CL_UDE_DT)*/
       UDE_EFF_DT
        FROM CLTMS_PRODUCT_UDE_DATES
       WHERE PRODUCT_CODE = P_PRD_CODE
         AND UDE_RULE_CODE = P_RULE_CODE
         AND UDE_EFF_DT <= P_VAL_DT
         AND CCY_CODE = P_CCY
         AND EXISTS (SELECT 1
                FROM CLTMS_PRODUCT_UDE_MASTER
               WHERE PRODUCT_CODE = P_PRD_CODE
                 AND CCY_CODE = P_CCY
                 AND RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y')
       ORDER BY UDE_EFF_DT DESC;
  
    CURSOR CR_UDE_VALS(P_PRD_CODE  CLTBS_ACCOUNT_MASTER.PRODUCT_CODE%TYPE,
                       P_RULE_CODE CLTMS_PRODUCT_UDE_RULES.UDE_RULE_CODE%TYPE,
                       P_MAT_DT    CLTBS_ACCOUNT_MASTER.MATURITY_DATE%TYPE,
                       P_EFF_DT    CLTMS_PRODUCT_UDE_VALUES.UDE_EFF_DT%TYPE,
                       P_CCY       CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE) IS
      SELECT UDE_RULE_CODE,
             UDE_EFF_DT,
             UDE_ID,
             UDE_VALUE,
             RATE_CODE,
             RATE_BASIS,
             CODE_USAGE
        FROM CLTMS_PRODUCT_UDE_VALUES A
       WHERE PRODUCT_CODE = P_PRD_CODE
         AND UDE_RULE_CODE = P_RULE_CODE
         AND UDE_EFF_DT < P_MAT_DT
         AND CCY_CODE = P_CCY
         AND UDE_EFF_DT >= P_EFF_DT
         AND EXISTS (SELECT 1
                FROM CLTM_PRODUCT_UDE B
               WHERE B.PRODUCT_CODE = P_PRD_CODE
                 AND B.UDE_ID = A.UDE_ID)
         AND EXISTS (SELECT 1
                FROM CLTMS_PRODUCT_UDE_MASTER
               WHERE PRODUCT_CODE = P_PRD_CODE
                 AND RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y')
       ORDER BY UDE_EFF_DT;
  
    CURSOR CR_PROD_UDE(P_PRD_CODE CLTBS_ACCOUNT_MASTER.PRODUCT_CODE%TYPE) IS
      SELECT * FROM CLTMS_PRODUCT_UDE WHERE PRODUCT_CODE = P_PRD_CODE;
    TYPE TY_TB_UDE IS TABLE OF CR_PROD_UDE%ROWTYPE INDEX BY PLS_INTEGER;
  
    L_UDE_VAL_COUNT    NUMBER;
    L_EXCH_RATE        ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_CCY_TO_BE_USED   CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE;
    L_EXISTS           BOOLEAN;
    L_REC_UDE_VAL      CR_UDE_VALS%ROWTYPE;
    L_UDE_RULE_CODE    CLTMS_PRODUCT_UDE_VALUES.UDE_RULE_CODE%TYPE;
    L_UDE_ID           CLTMS_PRODUCT_UDE_VALUES.UDE_ID%TYPE;
    L_UDE_COUNT        NUMBER(8);
    L_UDE_RULE_CODE    CLTMS_PRODUCT_UDE_RULES.UDE_RULE_CODE%TYPE;
    L_UDE_RULE         CLTMS_PRODUCT_UDE_RULES.UDE_RULE_CODE%TYPE;
    L_FLAG             BOOLEAN := FALSE;
    L_EFF_COUNT        NUMBER(8);
    L_EFF_DATES_FLAG   CLTBS_ACCOUNT_UDE_EFF_DATES%ROWTYPE;
    P_CAL_DT           CLTBS_ACCOUNT_MASTER.MATURITY_DATE%TYPE;
    L_MARTURITY_DT     CLTBS_ACCOUNT_MASTER.MATURITY_DATE%TYPE;
    L_PRIV_DT          CLTBS_ACCOUNT_UDE_EFF_DATES.EFFECTIVE_DATE%TYPE;
    L_PRD_CODE         CLTBS_ACCOUNT_MASTER.PRODUCT_CODE%TYPE;
    L_VAL_DATE         CLTBS_ACCOUNT_MASTER.VALUE_DATE%TYPE;
    L_UDE_DATE         CLTBS_ACCOUNT_UDE_EFF_DATES.EFFECTIVE_DATE%TYPE;
    L_CCY_CODE         CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE;
    L_TB_PRD_UDE_RULES CLPKSS_CACHE.TY_TB_PRD_UDE_RULES;
    L_TB_UDE           TY_TB_UDE;
    L_ACCOUNT_OBJ      CLPKS_OBJECT.TY_REC_ACCOUNT;
  
    L_QUOTE_BASIS CFTMS_RATE_CODE.QUOTE_BASIS%TYPE;
  
  BEGIN
    DBG('In Fn_Default_Ude..');
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.DELETE;
      DBG('Ude Values account cleared');
    END IF;
    IF P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT > 0 THEN
      P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.DELETE;
      DBG('Ude Values account cleared');
    END IF;
    L_PRD_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
    L_VAL_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
    L_CCY_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
  
    L_TB_UDE.DELETE;
    L_CCY_TO_BE_USED := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
  
    BEGIN
      OPEN CR_PROD_UDE(L_PRD_CODE);
      FETCH CR_PROD_UDE BULK COLLECT
        INTO L_TB_UDE;
      CLOSE CR_PROD_UDE;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE := 'CL-OBJ-010';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, '');
        RETURN FALSE;
    END;
    L_TB_PRD_UDE_RULES.DELETE;
    BEGIN
      L_TB_PRD_UDE_RULES := CLPKSS_CACHE.FN_PRODUCT_UDE_RULES(L_PRD_CODE,
                                                              L_CCY_TO_BE_USED);
    EXCEPTION
      WHEN OTHERS THEN
        L_FLAG := FALSE;
    END;
  
    L_UDE_RULE := L_TB_PRD_UDE_RULES.FIRST;
    IF L_UDE_RULE IS NOT NULL THEN
      IF NOT CLPKS_CLDACCNT_TYPE_CONV.FN_BUILD_ACC_OBJ(L_ACCOUNT_OBJ,
                                                       P_WRK_CLDACCNT,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS) THEN
        DBG('Failed in Clpks_Cldaccnt_Type_Conv.Fn_Build_Acc_Obj..');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;
  
    WHILE L_UDE_RULE IS NOT NULL LOOP
      IF C3PK#_UDE_SHELL.FN_EVALUATE_UDE_RULE(L_ACCOUNT_OBJ,
                                              L_UDE_RULE,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Welcome to UDE for default account creation');
      
        L_MARTURITY_DT := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE,
                              CLPKSS_UTIL.PKG_ETERNITY);
      
        OPEN CR_UDE_DATE(L_PRD_CODE,
                         L_UDE_RULE,
                         L_VAL_DATE,
                         L_CCY_TO_BE_USED);
        FETCH CR_UDE_DATE
          INTO L_UDE_DATE;
        IF CR_UDE_DATE%NOTFOUND THEN
          L_UDE_DATE := L_VAL_DATE;
        END IF;
        IF CR_UDE_DATE%ISOPEN THEN
          CLOSE CR_UDE_DATE;
        END IF;
        OPEN CR_UDE_VALS(L_PRD_CODE,
                         L_UDE_RULE,
                         L_MARTURITY_DT,
                         L_UDE_DATE,
                         L_CCY_TO_BE_USED);
        LOOP
          L_REC_UDE_VAL.UDE_RULE_CODE := NULL;
          FETCH CR_UDE_VALS
            INTO L_REC_UDE_VAL;
          IF L_REC_UDE_VAL.UDE_RULE_CODE IS NULL THEN
            IF CR_UDE_VALS%ISOPEN THEN
              CLOSE CR_UDE_VALS;
            END IF;
            EXIT;
          END IF;
        
          IF L_REC_UDE_VAL.UDE_EFF_DT < L_VAL_DATE THEN
            L_UDE_DATE := L_VAL_DATE;
          ELSE
            L_UDE_DATE := L_REC_UDE_VAL.UDE_EFF_DT;
          END IF;
          IF (L_PRIV_DT <> L_UDE_DATE) OR L_PRIV_DT IS NULL THEN
            L_PRIV_DT := L_UDE_DATE;
            L_EXISTS  := FALSE;
            IF P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT > 0 THEN
              FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.LAST LOOP
                IF L_PRIV_DT = P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(I)
                  .EFFECTIVE_DATE THEN
                  L_EXISTS := TRUE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF NOT L_EXISTS THEN
              L_EFF_COUNT := P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT + 1;
              P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
              P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
              P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).EFFECTIVE_DATE := L_PRIV_DT;
            END IF;
          END IF;
        
          IF L_REC_UDE_VAL.RATE_CODE IS NOT NULL THEN
            L_QUOTE_BASIS := CLPKS_CACHE.FN_GET_QUOTE_BASIS(L_REC_UDE_VAL.RATE_CODE,
                                                            L_ACCOUNT_OBJ.ACCOUNT_DET.BRANCH_CODE);
          
          END IF;
        
          L_UDE_ID := L_REC_UDE_VAL.UDE_ID;
          L_UDE_COUNT := CLPKS_UTIL.FN_HASH_DATE(L_UDE_DATE);
          L_UDE_VAL_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT + 1;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).EFFECTIVE_DATE := L_UDE_DATE;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_ID := L_REC_UDE_VAL.UDE_ID;
        
          IF P_CLDACCNT.v_account_ratetype_custom.INTEREST_RATE_TYPE = 'V' AND
             L_REC_UDE_VAL.UDE_ID = 'INTEREST_RATE' AND
             p_cldaccnt.v_cltbs_account_master.PRODUCT_CODE IN
             ('HL01',
              'HL02',
              'LT01',
              'ST02',
              'CL01',
              'LT02',
              'CG01',
              'CG02',
              'CG03',
              'CG04',
              'FI01',
              'FI02',
              'SME1',
              'SME2',
              'TFL1',
              'TFL2',
              'LV01', --Additional product codes for Variable Rate Phase 2
              'LV02') THEN
            --Additional product codes for Variable Rate Phase 2
            --sampath
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_VALUE := CLPKS_CLDACCNT_CUSTOM.FN_GET_LOAN_VAR_DEFAULT_RATE;
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_CODE := 'TD_1_YR_RT';
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).CODE_USAGE := 'A';
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'A';
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RESOLVED_VALUE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
                                                                                         .UDE_VALUE +
                                                                                          CLPKS_CLDACCNT_CUSTOM.FN_GET_TD_BASE_RATE(P_WRK_CLDACCNT.v_cltbs_account_master.BRANCH_CODE,
                                                                                                                                    P_WRK_CLDACCNT.v_cltbs_account_master.CURRENCY);
          
          ELSE
            --sampath
          
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_VALUE := L_REC_UDE_VAL.UDE_VALUE;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_CODE := L_REC_UDE_VAL.RATE_CODE;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).CODE_USAGE := L_REC_UDE_VAL.CODE_USAGE;
          
          END IF; --sampath
        
          IF L_REC_UDE_VAL.RATE_CODE IS NOT NULL THEN
            L_QUOTE_BASIS := CLPKS_CACHE.FN_GET_QUOTE_BASIS(L_REC_UDE_VAL.RATE_CODE,
                                                            L_ACCOUNT_OBJ.ACCOUNT_DET.BRANCH_CODE);
            IF L_QUOTE_BASIS IS NULL OR
               L_QUOTE_BASIS = CLPKS_CLDPRMNT_KERNEL.G_PER_ANNUM THEN
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'A';
            ELSE
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'Q';
            END IF;
          ELSE
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := L_REC_UDE_VAL.RATE_BASIS;
          END IF;
        
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Ude_Id' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .UDE_ID);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Effective_Date ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .EFFECTIVE_DATE);
        
          DBG('l_Quote_Basis' || L_QUOTE_BASIS);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Code ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_CODE);
          DBG('1st loop rate basis- p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Basis= ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_BASIS);
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).MAINT_RSLV_FLAG := 'M';
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RESOLVED_VALUE := NULL;
          L_FLAG := TRUE;
        END LOOP;
        IF CR_UDE_VALS%ISOPEN THEN
          CLOSE CR_UDE_VALS;
        END IF;
      END IF;
      L_UDE_RULE := L_TB_PRD_UDE_RULES.NEXT(L_UDE_RULE);
    END LOOP;
    IF NOT L_FLAG THEN
      L_EXISTS := FALSE;
      IF P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT > 0 THEN
        FOR I IN P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.FIRST .. P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.LAST LOOP
          IF L_VAL_DATE = P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(I)
            .EFFECTIVE_DATE THEN
            L_EXISTS := TRUE;
            EXIT;
          END IF;
        END LOOP;
      END IF;
      IF NOT L_EXISTS THEN
        L_EFF_COUNT := NVL(P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT, 0) + 1;
        P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
        P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
        P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).EFFECTIVE_DATE := L_VAL_DATE;
      END IF;
      L_UDE_COUNT := CLPKS_UTIL.FN_HASH_DATE(L_VAL_DATE);
      IF L_TB_UDE.COUNT > 0 THEN
        FOR I IN L_TB_UDE.FIRST .. L_TB_UDE.LAST LOOP
        
          L_UDE_ID := L_TB_UDE(I).UDE_ID;
          L_UDE_VAL_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT + 1;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).EFFECTIVE_DATE := L_VAL_DATE;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_ID := L_TB_UDE(I)
                                                                               .UDE_ID;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_VALUE := 0;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_CODE := NULL;
        
          IF L_REC_UDE_VAL.RATE_CODE IS NOT NULL THEN
            L_QUOTE_BASIS := CLPKS_CACHE.FN_GET_QUOTE_BASIS(L_REC_UDE_VAL.RATE_CODE,
                                                            L_ACCOUNT_OBJ.ACCOUNT_DET.BRANCH_CODE);
            IF L_QUOTE_BASIS IS NULL OR
               L_QUOTE_BASIS = CLPKS_CLDPRMNT_KERNEL.G_PER_ANNUM THEN
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'A';
            ELSE
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'Q';
            END IF;
          ELSE
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := L_TB_UDE(I)
                                                                                     .RATE_BASIS;
          END IF;
        
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Ude_Id ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .UDE_ID);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Effective_Date ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .EFFECTIVE_DATE);
        
          DBG('l_Quote_Basis' || L_QUOTE_BASIS);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Code ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_CODE);
          DBG('2nd loop rate basis- p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Basis= ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_BASIS);
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).MAINT_RSLV_FLAG := 'M';
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RESOLVED_VALUE := 0;
        END LOOP;
      END IF;
    END IF;
  
    IF L_TB_UDE.COUNT > 0 THEN
      L_UDE_COUNT := CLPKS_UTIL.FN_HASH_DATE(L_VAL_DATE);
      FOR I IN L_TB_UDE.FIRST .. L_TB_UDE.LAST LOOP
        L_EXISTS := FALSE;
        FOR J IN 1 .. P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(J)
           .UDE_ID = L_TB_UDE(I).UDE_ID THEN
            L_EXISTS := TRUE;
            EXIT;
          END IF;
        END LOOP;
      
        IF NOT L_EXISTS THEN
          L_UDE_ID := L_TB_UDE(I).UDE_ID;
          L_UDE_VAL_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT + 1;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).EFFECTIVE_DATE := L_VAL_DATE;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_ID := L_TB_UDE(I)
                                                                               .UDE_ID;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_VALUE := 0;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_CODE := NULL;
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := L_TB_UDE(I)
                                                                                   .RATE_BASIS;
        
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Ude_Id ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .UDE_ID);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Effective_Date ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .EFFECTIVE_DATE);
        
          DBG('l_Quote_Basis' || L_QUOTE_BASIS);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Code ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_CODE);
          DBG('3rd loop rate basis- p_Wrk_Cldaccnt.v_Cltbs_Account_Ude_Values(l_Ude_Val_Count).Rate_Basis= ' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT)
              .RATE_BASIS);
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).MAINT_RSLV_FLAG := 'M';
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RESOLVED_VALUE := 0;
        
        END IF;
      END LOOP;
    
      IF P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT > 0 THEN
        L_EXISTS := FALSE;
        FOR I IN 1 .. P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT LOOP
          DBG('Effective Date :- ' || P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(I)
              .EFFECTIVE_DATE);
          DBG('Value Date :- ' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE);
          IF P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(I)
           .EFFECTIVE_DATE =
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE THEN
            L_EXISTS := TRUE;
            EXIT;
          END IF;
        END LOOP;
        IF NOT L_EXISTS THEN
          L_EFF_COUNT := NVL(P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES.COUNT,
                             0) + 1;
          P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
          P_WRK_CLDACCNT.V_ACCOUNT_UDE_EFF_DATES(L_EFF_COUNT).EFFECTIVE_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
        END IF;
      END IF;
    
      IF L_TB_UDE.COUNT > 0 AND
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
        FOR I IN L_TB_UDE.FIRST .. L_TB_UDE.LAST LOOP
          L_EXISTS := FALSE;
          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT > 0 THEN
            FOR J IN 1 .. P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT LOOP
              IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(J)
               .UDE_ID = L_TB_UDE(I).UDE_ID AND P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(J)
                 .EFFECTIVE_DATE =
                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE THEN
                L_EXISTS := TRUE;
              END IF;
            END LOOP;
          END IF;
        
          IF NOT L_EXISTS THEN
            L_UDE_VAL_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES.COUNT + 1;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).EFFECTIVE_DATE := L_VAL_DATE;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_ID := L_TB_UDE(I)
                                                                                 .UDE_ID;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).UDE_VALUE := 0;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_CODE := NULL;
            IF L_REC_UDE_VAL.RATE_CODE IS NOT NULL THEN
              L_QUOTE_BASIS := CLPKS_CACHE.FN_GET_QUOTE_BASIS(L_REC_UDE_VAL.RATE_CODE,
                                                              L_ACCOUNT_OBJ.ACCOUNT_DET.BRANCH_CODE);
              IF L_QUOTE_BASIS IS NULL OR
                 L_QUOTE_BASIS = CLPKS_CLDPRMNT_KERNEL.G_PER_ANNUM THEN
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'A';
              ELSE
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := 'Q';
              END IF;
            ELSE
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RATE_BASIS := L_TB_UDE(I)
                                                                                       .RATE_BASIS;
            END IF;
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).MAINT_RSLV_FLAG := 'M';
            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_UDE_VALUES(L_UDE_VAL_COUNT).RESOLVED_VALUE := 0;
          END IF;
        END LOOP;
      END IF;
    
    END IF;
    DBG('Returning Success From  Fn_Default_Ude..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Ude..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_UDE;

  FUNCTION FN_DEFAULT_ROLL_COMPONENTS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                      P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    CURSOR CUR_ROLL_COMP IS
      SELECT COMPONENT_NAME
        FROM CLTMS_PRODUCT_ROLL_COMP
       WHERE PRODUCT_CODE =
             P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
  
    L_ROLL_COMP_IDX PLS_INTEGER := 0;
  BEGIN
    DBG('In Fn_Default_Roll_Components..');
    FOR REC_ROLL_COMP IN CUR_ROLL_COMP LOOP
      L_ROLL_COMP_IDX := L_ROLL_COMP_IDX + 1;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_ROLL_COMP(L_ROLL_COMP_IDX).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_ROLL_COMP(L_ROLL_COMP_IDX).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_ROLL_COMP(L_ROLL_COMP_IDX).COMPONENT_NAME := REC_ROLL_COMP.COMPONENT_NAME;
    END LOOP;
    DBG('Returning Success From  Fn_Default_Roll_Components..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Roll_Components..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_ROLL_COMPONENTS;

  FUNCTION FN_DEFAULT_COMPONENTS(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_COMPONENT_NAME       CLTMS_PRODUCT_COMPONENTS.COMPONENT_NAME%TYPE;
    L_COMPONENT_NUMBER     NUMBER := 0;
    L_CHG_COMPONENT_NUMBER NUMBER := 0;
    L_TB_PROD              CLPKS_CACHE.TY_TB_COMPONENTS;
    L_COMPONENT_INDEX      PLS_INTEGER;
    L_ACCOUNT_REC          STTBS_ACCOUNT%ROWTYPE;
  
    L_PROV_EXISTS    BOOLEAN := FALSE;
    L_SETTL_REC      ISTMS_INSTR%ROWTYPE;
    L_ROW_PROD_COMPS CLTMS_PRODUCT_COMPONENTS%ROWTYPE;
  
    L_DR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_DR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
    L_CR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_CR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
  
  BEGIN
    DBG('In Fn_Default_Components..');
    P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP.DELETE;
    L_TB_PROD := CLPKS_CACHE.FN_COMPONENTS_FOR_PROD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
  
    L_DR_ACC_ROLE := 'DR_SETTL_BRIDGE';
    L_CR_ACC_ROLE := 'CR_SETTL_BRIDGE';
    IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                       L_DR_ACC_ROLE,
                                       L_DR_ACC_HEAD) THEN
      L_DR_ACC_ROLE := NULL;
      L_DR_ACC_HEAD := NULL;
    END IF;
    IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                       L_CR_ACC_ROLE,
                                       L_CR_ACC_HEAD) THEN
      L_CR_ACC_ROLE := NULL;
      L_CR_ACC_HEAD := NULL;
    END IF;
  
    FOR L_COMPONENT_INDEX IN 1 .. L_TB_PROD.COUNT LOOP
      L_COMPONENT_NAME := L_TB_PROD(L_COMPONENT_INDEX).COMPONENT_NAME;
      IF L_TB_PROD(L_COMPONENT_INDEX).COMPONENT_TYPE IN ('I', 'L', 'P') THEN
        DBG('Component NAme :' || L_COMPONENT_NAME);
        L_COMPONENT_NUMBER := L_COMPONENT_NUMBER + 1;
        DBG('Component NAme :' || L_COMPONENT_NAME || '/' ||
            L_COMPONENT_NUMBER);
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).IRR_APPLICABLE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                       .IRR_APPLICABLE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).ACCOUNT_NUMBER := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).COMPONENT_NAME := L_COMPONENT_NAME;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SETTLEMENT_CCY := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).COMPONENT_TYPE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                       .COMPONENT_TYPE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).MAIN_COMPONENT := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                       .MAIN_COMPONENT;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SPL_INTEREST := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                     .SPL_INTEREST;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CAPITALIZED := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                    .CAPITALIZED;
      
        IF NVL(L_TB_PROD(L_COMPONENT_INDEX).BOOK_UNEARNED_PROFIT, 'N') = 'Y' THEN
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BOOK_UNEARNED_INTEREST := L_TB_PROD(L_COMPONENT_INDEX)
                                                                          .BOOK_UNEARNED_PROFIT;
        END IF;
      
        IF ((NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                 'ACC') = 'ACC' AND
           NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE,
                 'ACC') = 'ACC') OR L_PROV_EXISTS) THEN
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_PAYMENT_MODE := 'ACC';
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_PAYMENT_MODE := 'ACC';
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SETTLEMENT_SEQ_NUM := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SETTLEMENT_SEQ_NUM;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                                         GLOBAL.CURRENT_BRANCH);
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                                         GLOBAL.CURRENT_BRANCH);
        
        ELSE
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_BANK_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BANK_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_BANK_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BANK_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_BRN_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BRN_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_BRN_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BRN_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_PROD_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_PROD_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CLG_PROD_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_PROD_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_PAYMENT_MODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_PAYMENT_MODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
        
          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
          END IF;
        
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).END_POINT_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_POINT_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).EXT_ACC_NAME_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NAME_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).EXT_ACC_NAME_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NAME_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).EXT_ACC_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).EXT_ACC_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).INSTRUMENT_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.INSTRUMENT_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).INSTRUMENT_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.INSTRUMENT_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PC_CAT_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PC_CAT_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PC_CAT_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PC_CAT_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).ROUTING_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ROUTING_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).ROUTING_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ROUTING_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SECTOR_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SECTOR_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SECTOR_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SECTOR_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UPLOAD_SOURCE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UPLOAD_SOURCE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UPLOAD_SOURCE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UPLOAD_SOURCE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CARD_NO := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CARD_NO;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).END_POINT_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_POINT_DR;
        
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PAYMENT_DETAILS_1 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_1;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PAYMENT_DETAILS_2 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_2;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PAYMENT_DETAILS_3 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_3;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PAYMENT_DETAILS_4 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_4;
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_1' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_1);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_2' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_2);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_3' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_3);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_4' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_4);
        
        END IF;
      
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).PENAL_BASIS_COMP := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                         .PENAL_BASIS_COMP;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).COMPONENT_CCY := NVL(L_TB_PROD(L_COMPONENT_INDEX)
                                                                                          .COMPONENT_CCY,
                                                                                          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).VERIFY_FUNDS := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                     .VERIFY_FUNDS;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).IRR_APPLICABLE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                       .IRR_APPLICABLE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).LIQUIDATION_MODE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                         .LIQUIDATION_MODE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).EXPONENTIAL_FLAG := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                         .EXPONENTIAL_FLAG;
      
        IF L_DR_ACC_ROLE = 'DR_SETTL_BRIDGE' THEN
        
          IF (P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
             .DR_PAYMENT_MODE = 'ACC' AND
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NULL) THEN
          
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_PROD_AC := L_DR_ACC_HEAD;
          
          ELSE
          
            IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                   'ACC') <> 'PDC' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
            
              IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
              END IF;
            
            END IF;
          END IF;
        
        END IF;
      
        IF L_CR_ACC_ROLE = 'CR_SETTL_BRIDGE' THEN
        
          IF (P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
             .CR_PAYMENT_MODE = 'ACC' AND
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NULL) THEN
          
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_PROD_AC := L_CR_ACC_HEAD;
          
          ELSE
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
          
            IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
            END IF;
          
          END IF;
        END IF;
      
        IF CLPKSS_CONTEXT.G_FUNCTION_ID <> 'CLDOR001' AND
           CLPKSS_CONTEXT.G_FUNCTION_ID <> 'CLDOR050' THEN
          IF NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
                 .DR_PAYMENT_MODE,
                 '###') = 'ACC' AND
             NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
                 .CR_PAYMENT_MODE,
                 '###') = 'ACC' THEN
            IF NOT CVPKSS_UTILS.GET_STTB_ACC(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
                                             .DR_ACC_BRN,
                                             P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER)
                                             .DR_PROD_AC,
                                             L_ACCOUNT_REC) THEN
              P_ERR_CODE   := 'CL-OBJ-011;';
              P_ERR_PARAMS := '~;';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
          
            IF L_ACCOUNT_REC.AC_OR_GL = 'A' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SETTLEMENT_CCY := NVL(L_ACCOUNT_REC.AC_GL_CCY,
                                                                                                 P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
            END IF;
          END IF;
        ELSE
          IF GWPKSS_CL_ACCOUNT_TS_TO_TY.G_ACC_CCY IS NOT NULL THEN
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_COMPONENT_NUMBER).SETTLEMENT_CCY := GWPKSS_CL_ACCOUNT_TS_TO_TY.G_ACC_CCY;
          END IF;
        END IF;
      
      ELSE
        DBG('Charge NAme 12:' || L_COMPONENT_NAME);
        L_CHG_COMPONENT_NUMBER := L_CHG_COMPONENT_NUMBER + 1;
        DBG('Charge NAme 12:' || L_COMPONENT_NAME || '/' ||
            L_CHG_COMPONENT_NUMBER);
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).ACCOUNT_NUMBER := NULL;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).COMPONENT_NAME := L_COMPONENT_NAME;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SETTLEMENT_CCY := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).COMPONENT_TYPE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                           .COMPONENT_TYPE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).MAIN_COMPONENT := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                           .MAIN_COMPONENT;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SPL_INTEREST := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                         .SPL_INTEREST;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CAPITALIZED := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                        .CAPITALIZED;
      
        DBG('p_Source' || P_SOURCE);
        IF NVL(P_SOURCE, 'X') <> 'FLEXCUBE' THEN
        
          IF NVL(CLPKSS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE)
                 .IOF_PAYMENT_METHOD,
                 'N') = 'C' THEN
          
            DBG('Its IOF Compounding');
            IF NVL(L_TB_PROD(L_COMPONENT_INDEX).COMPONENT_TYPE, 'X') = 'H' THEN
              IF (NVL(L_TB_PROD(L_COMPONENT_INDEX).COMP_REPORTING_TYPE,
                      '$$') = 'IF') THEN
                DBG('Its IOF Component');
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_CHG_COMPONENT_NUMBER).FUND_DURING_INIT := 'Y';
                P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CMP(L_CHG_COMPONENT_NUMBER).WAIVE := 'N';
              END IF;
            END IF;
          END IF;
        END IF;
      
        IF ((NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE,
                 'ACC') = 'ACC' AND
           NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE,
                 'ACC') = 'ACC') OR L_PROV_EXISTS) THEN
          DBG('Charge NAme inside:' || L_COMPONENT_NAME);
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_PAYMENT_MODE := 'ACC';
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_PAYMENT_MODE := 'ACC';
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN,
                                                                                             GLOBAL.CURRENT_BRANCH);
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_ACC_BRN := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN,
                                                                                             GLOBAL.CURRENT_BRANCH);
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SETTLEMENT_SEQ_NUM := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SETTLEMENT_SEQ_NUM;
        
        ELSE
          DBG('p_wrk_cldaccnt.v_cltbs_account_master.cr_prod_ac :' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
          DBG('p_wrk_cldaccnt.v_cltbs_account_master.ext_acc_no_cr :' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NO_CR);
        
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_BANK_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BANK_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_BANK_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BANK_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_BRN_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BRN_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_BRN_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_BRN_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_PROD_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_PROD_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CLG_PROD_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CLG_PROD_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_ACC_BRN := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_PAYMENT_MODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_PAYMENT_MODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
        
          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
          END IF;
        
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).END_POINT_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_POINT_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).EXT_ACC_NAME_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NAME_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).EXT_ACC_NAME_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NAME_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).EXT_ACC_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).EXT_ACC_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXT_ACC_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).INSTRUMENT_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.INSTRUMENT_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).INSTRUMENT_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.INSTRUMENT_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).PC_CAT_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PC_CAT_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).PC_CAT_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PC_CAT_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).ROUTING_NO_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ROUTING_NO_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).ROUTING_NO_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ROUTING_NO_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SECTOR_CODE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SECTOR_CODE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SECTOR_CODE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SECTOR_CODE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UPLOAD_SOURCE_CR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UPLOAD_SOURCE_CR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UPLOAD_SOURCE_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UPLOAD_SOURCE_DR;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CARD_NO := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CARD_NO;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).END_POINT_DR := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_POINT_DR;
        
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_COMPONENT_NUMBER).PAYMENT_DETAILS_1 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_1;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_COMPONENT_NUMBER).PAYMENT_DETAILS_2 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_2;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_COMPONENT_NUMBER).PAYMENT_DETAILS_3 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_3;
          P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_COMPONENT_NUMBER).PAYMENT_DETAILS_4 := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_4;
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_1' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_1);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_2' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_2);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_3' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_3);
          DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.payment_details_4' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_4);
        
        END IF;
      
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).PENAL_BASIS_COMP := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                             .PENAL_BASIS_COMP;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).COMPONENT_CCY := NVL(L_TB_PROD(L_COMPONENT_INDEX)
                                                                                              .COMPONENT_CCY,
                                                                                              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).VERIFY_FUNDS := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                         .VERIFY_FUNDS;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).IRR_APPLICABLE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                           .IRR_APPLICABLE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).LIQUIDATION_MODE := L_TB_PROD(L_COMPONENT_INDEX)
                                                                                             .LIQUIDATION_MODE;
        P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DEFERRED_CHARGE := NVL(L_TB_PROD(L_COMPONENT_INDEX)
                                                                                                .DEFERRED_CHARGE,
                                                                                                'N');
      
        IF L_DR_ACC_ROLE = 'DR_SETTL_BRIDGE' THEN
        
          DBG('p_wrk_cldaccnt.v_account_components__chg(l_chg_component_number).dr_payment_mode :' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
              .DR_PAYMENT_MODE);
          DBG('p_wrk_cldaccnt.v_cltbs_account_master.dr_prod_ac :' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
        
          IF (P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
             .DR_PAYMENT_MODE = 'ACC' AND
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NULL) THEN
          
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_PROD_AC := L_DR_ACC_HEAD;
          
          ELSE
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC;
          
            IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                                                    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
            END IF;
          
          END IF;
        
        END IF;
      
        IF L_CR_ACC_ROLE = 'CR_SETTL_BRIDGE' THEN
        
          DBG('p_wrk_cldaccnt.v_cltbs_account_master.cr_prod_ac :' ||
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
          DBG('p_wrk_cldaccnt.v_account_components__chg(l_chg_component_number).cr_payment_mode :' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
              .CR_PAYMENT_MODE);
          IF (P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
             .CR_PAYMENT_MODE = 'ACC' AND
              P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NULL) THEN
          
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_PROD_AC := L_CR_ACC_HEAD;
          
          ELSE
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC;
          
            IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CL' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                                                    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
            END IF;
          
          END IF;
        END IF;
      
        DBG('p_wrk_cldaccnt.v_account_components__chg(l_chg_component_number).dr_prod_ac :- ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
            .DR_PROD_AC);
        DBG('p_wrk_cldaccnt.v_account_components__chg(l_chg_component_number).cr_prod_ac :- ' || P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
            .CR_PROD_AC);
      
        IF CLPKSS_CONTEXT.G_FUNCTION_ID <> 'CLDOR001' AND
           CLPKSS_CONTEXT.G_FUNCTION_ID <> 'CLDOR050' THEN
          IF NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
                 .DR_PAYMENT_MODE,
                 '###') = 'ACC' AND
             NVL(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
                 .CR_PAYMENT_MODE,
                 '###') = 'ACC' THEN
            IF NOT CVPKSS_UTILS.GET_STTB_ACC(P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
                                             .DR_ACC_BRN,
                                             P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER)
                                             .DR_PROD_AC,
                                             L_ACCOUNT_REC) THEN
              P_ERR_CODE   := 'CL-OBJ-011;';
              P_ERR_PARAMS := '~;';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
          
            IF L_ACCOUNT_REC.AC_OR_GL = 'A' THEN
              P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SETTLEMENT_CCY := NVL(L_ACCOUNT_REC.AC_GL_CCY,
                                                                                                     P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY);
            END IF;
          END IF;
        ELSE
          IF GWPKSS_CL_ACCOUNT_TS_TO_TY.G_ACC_CCY IS NOT NULL THEN
            P_WRK_CLDACCNT.V_ACCOUNT_COMPONENTS__CHG(L_CHG_COMPONENT_NUMBER).SETTLEMENT_CCY := GWPKSS_CL_ACCOUNT_TS_TO_TY.G_ACC_CCY;
          END IF;
        END IF;
      
      END IF;
    
    END LOOP;
  
    DBG('Returning Success From  Fn_Default_Components..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Components..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_COMPONENTS;

  FUNCTION FN_DEFAULT_EVENT_ADVICES(P_SOURCE           IN VARCHAR2,
                                    P_SOURCE_OPERATION IN VARCHAR2,
                                    P_FUNCTION_ID      IN VARCHAR2,
                                    P_ACTION_CODE      IN VARCHAR2,
                                    P_EVENT_CODE       IN VARCHAR2,
                                    P_EVENT_SEQ_NO     IN NUMBER,
                                    P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                    P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    TYPE TY_REC_ADV_REC IS RECORD(
      MSG_TYPE CLTBS_ACCOUNT_EVENTS_ADVICES.MSG_TYPE%TYPE);
    TYPE TY_TB_ADV IS TABLE OF TY_REC_ADV_REC INDEX BY VARCHAR2(20);
    L_REC_ADV          TY_TB_ADV;
    L_TB_EVENT_ADV     CLPKSS_ELEMENT_TYPES.TB_EVENT_ADV;
    L_EVENT_CODE       CLTB_ACCOUNT_EVENTS_ADVICES.EVENT_CODE%TYPE;
    L_IDX_EVNTADV      PLS_INTEGER;
    L_CUSTOMER_REC     STTMS_CUSTOMER%ROWTYPE;
    L_EVENT_COUNT      NUMBER := 0;
    L_FORMAT_LANG      MSTMS_ADV_FORMAT.LANGUAGE%TYPE;
    L_AMOUNT_FINANCED  CLTB_ACCOUNT_MASTER.AMOUNT_FINANCED%TYPE;
    L_BRANCH_PARAMETER CLTMS_BRANCH_PARAMETERS%ROWTYPE;
  
  BEGIN
    DBG('In Fn_Default_Event_Advices..');
  
    IF NVL(CLPKSS_CONTEXT.G_FUNCTION_ID, 'XYZABCD') NOT IN
       ('CLDACCDT',
        'CLDSIMDT',
        'CLDINADT',
        'MODACCDT',
        'MFDACCDT',
        'MODSIMDT',
        'MODINADT',
        'LEDACCDT') THEN
      P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES.DELETE;
    END IF;
  
    IF NOT (NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER, '~!@#') =
        P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER AND
        NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE, '~!@#') =
        P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE) THEN
      IF NOT (P_SOURCE <> 'FLEXCUBE' AND
          P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE = 'CI') THEN
        IF NVL(L_BRANCH_PARAMETER.ACCT_AUTO_GEN, 'Y') = 'N' THEN
          P_WRK_CLDACCNT := P_CLDACCNT;
        END IF;
      
      ELSE
        L_AMOUNT_FINANCED := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED;
        IF NVL(L_BRANCH_PARAMETER.ACCT_AUTO_GEN, 'Y') = 'N' THEN
          P_WRK_CLDACCNT := P_CLDACCNT;
        END IF;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED := L_AMOUNT_FINANCED;
      END IF;
    
    END IF;
  
    L_EVENT_CODE := P_EVENT_CODE;
  
    DBG('Calling C3pk#_Prd_Shell.Fn_Get_Event_Adv');
    IF NOT C3PK#_PRD_SHELL.FN_GET_EVENT_ADV(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                            L_EVENT_CODE,
                                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                            P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                            L_TB_EVENT_ADV,
                                            P_ERR_CODE) THEN
      DBG('Failed C3pk#_Prd_Shell.Fn_Get_Event_Adv..');
      RETURN FALSE;
    END IF;
  
    L_IDX_EVNTADV := L_TB_EVENT_ADV.FIRST;
  
    WHILE L_IDX_EVNTADV IS NOT NULL LOOP
    
      L_EVENT_COUNT := P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES.COUNT + 1;
      L_FORMAT_LANG := NVL(CLPKS_CACHE.FN_ADVICE_FORMAT(L_TB_EVENT_ADV(L_IDX_EVNTADV).FORMAT)
                           .LANGUAGE,
                           GLOBAL.LANG);
    
      IF NVL(GWPKSS_CL_ACCOUNT_TS_TO_TY.G_ISCUST, 'N') = 'N' THEN
        IF NOT CLPKS_CACHE.FN_CUSTOMER(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                       L_CUSTOMER_REC,
                                       P_ERR_CODE) THEN
          DBG('Failed in function Clpks_cache.fn_customer' || P_ERR_CODE);
          RETURN FALSE;
        END IF;
      ELSE
        L_CUSTOMER_REC.LANGUAGE := GLOBAL.LANG;
      END IF;
      IF L_CUSTOMER_REC.LANGUAGE = L_FORMAT_LANG THEN
        IF NOT L_REC_ADV.EXISTS(P_EVENT_CODE || '~' || L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                .MSG_TYPE) THEN
          L_REC_ADV(P_EVENT_CODE || '~' || L_TB_EVENT_ADV(L_IDX_EVNTADV).MSG_TYPE).MSG_TYPE := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                                               .MSG_TYPE;
        
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).EVENT_CODE := P_EVENT_CODE;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).EVENT_SEQ_NO := P_EVENT_SEQ_NO;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).MSG_TYPE := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                             .MSG_TYPE;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).FORMAT := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                           .FORMAT;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).SUPPRESS := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                             .SUPPRESS;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).PRIORITY := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                             .PRIORITY;
          P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES(L_EVENT_COUNT).GENERATION_TIME := L_TB_EVENT_ADV(L_IDX_EVNTADV)
                                                                                    .GENERATION_TIME;
        END IF;
      END IF;
    
      L_IDX_EVNTADV := L_TB_EVENT_ADV.NEXT(L_IDX_EVNTADV);
    END LOOP;
    DBG('Returning Success From Fn_Default_Event_Advices');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccnt_defaults.Fn_Default_Event_Advices ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_EVENT_ADVICES;

  FUNCTION FN_DEFAULT_PROMOTIONS(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    CURSOR CR_PRMO IS
      SELECT DISTINCT CUSTOMER_NO, BEN_PLAN_ID
        FROM COTM_SCHEME_DETAIL A, COTB_CUST_SCHEME_DETAILS B
       WHERE B.CUSTOMER_NO = P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
         AND A.MODULE IN ('CL', 'MO', 'CI')
         AND A.SCHEME_ID = B.SCHEME_ID
         AND B.ONCE_AUTH = 'Y'
         AND B.RECORD_STAT = 'O'
         AND B.LINKAGE_STAT IN ('A', 'W', 'X')
         AND B.BEN_START_DT <=
             P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
         AND B.BEN_END_DT >=
             P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
      
      ;
  
    L_PRIORITY       NUMBER;
    L_PROMOTION_CNTR NUMBER := 0;
  
    L_CONV_AMT  NUMBER;
    L_EXCH_RATE NUMBER;
  
  BEGIN
    DBG('In Fn_Default_Promotions..');
  
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS.DELETE;
  
    IF GLOBAL.LCY <> P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY THEN
    
      IF NOT CYPKSS.FN_AMT1_TO_AMT2(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY,
                                    GLOBAL.LCY,
                                    'STANDARD',
                                    'M',
                                    NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED,
                                        0),
                                    'Y',
                                    L_CONV_AMT,
                                    L_EXCH_RATE,
                                    P_ERR_CODE) THEN
        DBG('Failed in  clpkss_util.fn_amt1_to_amt2 With : ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
    ELSE
      L_CONV_AMT := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED,
                        0);
    END IF;
  
    L_PRIORITY := 1;
  
    FOR PROMO IN CR_PRMO LOOP
      DBG('l_Promotion_Cntr..' || L_PROMOTION_CNTR);
    
      IF NOT CLPKS_UTIL.FN_ISPROMOTION_ALLOWED(PROMO.BEN_PLAN_ID,
                                               P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                               L_CONV_AMT,
                                               P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
      
        DBG('Failed in Fn_Default_Promotions..p_Err_Code~' || P_ERR_CODE ||
            '..p_Err_Params~' || P_ERR_PARAMS);
        IF P_ERR_CODE IS NOT NULL THEN
          RETURN FALSE;
        END IF;
      ELSE
      
        L_PROMOTION_CNTR := L_PROMOTION_CNTR + 1;
      
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).PROMOTION_TYPE := 'P';
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).PROMOTION_ID := PROMO.BEN_PLAN_ID;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).BENEFICIARY_CIF := PROMO.CUSTOMER_NO;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS(L_PROMOTION_CNTR).PRIORITY := L_PRIORITY;
      
        L_PRIORITY := L_PRIORITY + 1;
      
      END IF;
    
    END LOOP;
  
    DBG('Returning success from fn_promotions');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_promotions ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_PROMOTIONS;

  FUNCTION FN_DEFAULT_HOL_PERIODS(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_ACC_HOL_PERDS_IDX NUMBER := 0;
  BEGIN
    DBG('In Fn_Default_Settle_Accounts..');
    FOR L_ACC_HOL_PERDS IN (SELECT HOLIDAY_PERIODS
                              FROM CLTMS_PRODUCT_HOL_PERDS
                             WHERE PRODUCT_CODE =
                                   P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE) LOOP
    
      L_ACC_HOL_PERDS_IDX := L_ACC_HOL_PERDS_IDX + 1;
    
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS(L_ACC_HOL_PERDS_IDX).ACCOUNT_NUMBER := NULL;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS(L_ACC_HOL_PERDS_IDX).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS(L_ACC_HOL_PERDS_IDX).HOLIDAY_PERIODS := L_ACC_HOL_PERDS.HOLIDAY_PERIODS;
    END LOOP;
    DBG('Returning Success From  Fn_Default_Hol_Periods..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Hol_Periods..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_HOL_PERIODS;
  FUNCTION FN_DEFAULT_PARTIES(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CUST_NAME             CLTBS_ACCOUNT_PARTIES.CUSTOMER_NAME%TYPE;
    L_CUSTROW               STTMS_CUSTOMER%ROWTYPE;
    L_FOUND                 BOOLEAN := FALSE;
    L_COUNTER               NUMBER := 0;
    L_CLTBS_ACCOUNT_PARTIES CLPKS_CLDACCNT_MAIN.TY_TB_V_CLTBS_ACCOUNT_PARTIES;
  
  BEGIN
    DBG('In Fn_Default_Parties..');
    IF CLPKSS_CACHE.FN_CUSTOMER(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                                L_CUSTROW,
                                P_ERR_CODE) THEN
      L_CUST_NAME := L_CUSTROW.CUSTOMER_NAME1;
    END IF;
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES.COUNT = 0 THEN
      L_COUNTER := 1;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).CUSTOMER_ID := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).RESPONSIBILITY := 'BRW';
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).LIABILITY := 100;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).LIABILITY_AMT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).EFFECTIVE_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(L_COUNTER).CUSTOMER_NAME := L_CUST_NAME;
    ELSE
    
      L_CLTBS_ACCOUNT_PARTIES.DELETE;
      L_COUNTER := 0;
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES.COUNT LOOP
          L_COUNTER := L_CLTBS_ACCOUNT_PARTIES.COUNT + 1;
          IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
           .RESPONSIBILITY = 'BRW' THEN
            IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
             .CUSTOMER_ID <>
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID OR
                P_ACTION_CODE = 'PRDDFLT' THEN
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).CUSTOMER_ID := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).RESPONSIBILITY := 'BRW';
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).LIABILITY := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                                                                  .LIABILITY,
                                                                  100);
              DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Parties(i).liability_amt' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                  .LIABILITY_AMT);
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).LIABILITY_AMT := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                                                                      .LIABILITY_AMT,
                                                                      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED);
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).EFFECTIVE_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).CUSTOMER_NAME := L_CUST_NAME;
            ELSE
              L_CLTBS_ACCOUNT_PARTIES(L_COUNTER) := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I);
            END IF;
          ELSE
            L_CLTBS_ACCOUNT_PARTIES(L_COUNTER) := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I);
            L_CLTBS_ACCOUNT_PARTIES(L_COUNTER).EFFECTIVE_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
          END IF;
        END LOOP;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES := L_CLTBS_ACCOUNT_PARTIES;
      END IF;
    
    END IF;
    DBG('Returning Success From Fn_Default_Parties');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccnt_vals.Fn_Default_Parties ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_PARTIES;

  FUNCTION FN_DEFAULT_LINKAGE(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_COUNT VARCHAR2(50);
    C_COUNT VARCHAR2(50);
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    DBG('p_Cldaccnt.v_cltbs_account_parties.COUNT11111' ||
        P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES.COUNT);
  
    L_COUNT := P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES.COUNT;
    DBG('l_Count--->' || L_COUNT);
  
    IF L_COUNT > 0 THEN
      DELETE FROM CLTB_ACCOUNT_CUST_LINKAGES
       WHERE ACCOUNT_NUMBER =
             P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER
         AND BRANCH_CODE = P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
    
      FOR I IN 1 .. L_COUNT LOOP
        DBG(P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I).CUSTOMER_ID);
        DBG(P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I).ACCOUNT_NUMBER);
      
        BEGIN
        
          SELECT COUNT(*)
            INTO C_COUNT
            FROM CLTB_ACCOUNT_CUST_LINKAGES
           WHERE ACCOUNT_NUMBER = P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                .ACCOUNT_NUMBER
             AND CUSTOMER_ID = P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                .CUSTOMER_ID
             AND BRANCH_CODE = P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I)
                .BRANCH_CODE;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Alt acc' || SQLERRM);
        END;
      
        IF C_COUNT = 0 THEN
        
          BEGIN
          
            INSERT INTO CLTB_ACCOUNT_CUST_LINKAGES
              (ACCOUNT_NUMBER, BRANCH_CODE, CUSTOMER_ID)
            VALUES
              (P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I).ACCOUNT_NUMBER,
               P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I).BRANCH_CODE,
               P_CLDACCNT.V_CLTBS_ACCOUNT_PARTIES(I).CUSTOMER_ID);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('No Alt acc' || SQLERRM);
          END;
        
        END IF;
      END LOOP;
    END IF;
  
    COMMIT;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_DEFAULT_LINKAGE;

  FUNCTION FN_DEFAULT_CHECK_LIST(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_EVENT_CODE       IN VARCHAR2,
                                 P_EVENT_SEQ_NO     IN NUMBER,
                                 P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    CURSOR CUR_LIST_DETAILS(P_PRODUCT_CODE CLTMS_PRODUCT.PRODUCT_CODE%TYPE,
                            P_MODULE_CODE  CLTMS_PRODUCT.MODULE_CODE%TYPE) IS
      SELECT A.*
        FROM CLTMS_CHECK_LIST_DETAIL A, CLTMS_CHECK_LIST_MASTER B
       WHERE A.EVENT_CODE = B.EVENT_CODE
         AND RECORD_STAT = 'O'
         AND NVL(ONCE_AUTH, 'N') = 'Y'
         AND B.EVENT_CODE = P_EVENT_CODE
         AND B.PRODUCT_CODE = A.PRODUCT_CODE
         AND B.PRODUCT_CODE = P_PRODUCT_CODE
         AND A.MODULE_CODE = B.MODULE_CODE
         AND A.MODULE_CODE = P_MODULE_CODE;
  
    TYPE TY_TB_LIST_DETAILS IS TABLE OF CLTMS_CHECK_LIST_DETAIL%ROWTYPE INDEX BY PLS_INTEGER;
    L_CHECK_LIST_DETAILS TY_TB_LIST_DETAILS;
    L_TB_CHECK_LIST      CLPKS_UTIL.TY_TB_LIST_DESC;
    L_IDX                PLS_INTEGER := 0;
    L_CHK_IDX            PLS_INTEGER := 0;
  
  BEGIN
    DBG('In Fn_Default_Check_List..');
  
    OPEN CUR_LIST_DETAILS(CLPKSS_UTIL.G_PROD,
                          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE);
    FETCH CUR_LIST_DETAILS BULK COLLECT
      INTO L_CHECK_LIST_DETAILS;
    CLOSE CUR_LIST_DETAILS;
  
    IF L_CHECK_LIST_DETAILS.COUNT = 0 THEN
      OPEN CUR_LIST_DETAILS('ALL', 'AL');
      FETCH CUR_LIST_DETAILS BULK COLLECT
        INTO L_CHECK_LIST_DETAILS;
      CLOSE CUR_LIST_DETAILS;
    END IF;
  
    IF L_CHECK_LIST_DETAILS.COUNT > 0 THEN
      L_IDX := L_IDX + 1;
      FOR EACH_DETAIL IN L_CHECK_LIST_DETAILS.FIRST .. L_CHECK_LIST_DETAILS.LAST LOOP
        L_TB_CHECK_LIST(L_IDX) := L_CHECK_LIST_DETAILS(EACH_DETAIL)
                                  .CHECKLIST_ITEM;
        L_IDX := L_IDX + 1;
      END LOOP;
    
      DBG('Count :' || L_TB_CHECK_LIST.COUNT);
      IF L_TB_CHECK_LIST.COUNT > 0 THEN
        FOR EACH_DESC IN L_TB_CHECK_LIST.FIRST .. L_TB_CHECK_LIST.LAST LOOP
          L_CHK_IDX := L_CHK_IDX + 1;
          P_WRK_CLDACCNT.V_CLTBS_EVENT_CHECK_LIST(L_CHK_IDX).ACCOUNT_NUMBER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER;
          P_WRK_CLDACCNT.V_CLTBS_EVENT_CHECK_LIST(L_CHK_IDX).BRANCH_CODE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE;
          P_WRK_CLDACCNT.V_CLTBS_EVENT_CHECK_LIST(L_CHK_IDX).DESCRIPTION := L_TB_CHECK_LIST(EACH_DESC);
          P_WRK_CLDACCNT.V_CLTBS_EVENT_CHECK_LIST(L_CHK_IDX).ESN := 1;
          P_WRK_CLDACCNT.V_CLTBS_EVENT_CHECK_LIST(L_CHK_IDX).CHECKED := 'N';
        
        END LOOP;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      CLPKSS_LOGGER.PR_LOG_EXCEPTION('Failed Fn_Default_Check_List..');
      DBG('In When Others Of  Fn_Default_Check_List..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'CL-UTIL01';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_CHECK_LIST;

  FUNCTION FN_DEFAULT_MATURITY_DATE(P_SOURCE              IN VARCHAR2,
                                    P_SOURCE_OPERATION    IN VARCHAR2,
                                    P_FUNCTION_ID         IN VARCHAR2,
                                    P_ACTION_CODE         IN VARCHAR2,
                                    P_CLDACCNT            IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                    P_WRK_CLDACCNT        IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                    P_MATURITY_DATE       IN OUT DATE,
                                    P_CALCULATED_MATURITY IN OUT BOOLEAN,
                                    P_ERR_CODE            IN OUT VARCHAR2,
                                    P_ERR_PARAMS          IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_MATURITY_DATE      DATE;
    L_PRODUCT_PREFERENCE CLTMS_PRODUCT%ROWTYPE;
    L_ACCOUNT_OBJ        CLPKSS_OBJECT.TY_REC_ACCOUNT;
  
    L_ENT              CLTB_ACCOUNT_MASTER.CUSTOMER_ID%TYPE;
    L_NO_OF_SCHEDULES  MFTM_MEETING_SCH_MASTER.NUMBER_OF_SCHEDULES%TYPE;
    L_START_DT         DATE;
    L_UNIT             MFTM_MEETING_SCH_MASTER.UNIT%TYPE;
    L_FREQUENCY        MFTM_MEETING_SCH_MASTER.FREQUENCY%TYPE;
    L_DFLT_FRM_MEETING CLTM_PRODUCT.DEFAULT_FROM_METSCH%TYPE;
    L_MEET_CODE        MFTM_MEETING_SCH_MASTER.MEETING_CODE%TYPE;
    L_FLAG             BOOLEAN := TRUE;
    L_COUNT            NUMBER := 0;
    L_COUNT_4          NUMBER := 0;
    L_REC_PROD         CLTM_PRODUCT%ROWTYPE;
    CURSOR CR_MEETING(P_MEETING_CODE VARCHAR2) IS
      SELECT B.ACTUAL_MEETING_DATE
        FROM MFTM_MEETING_SCH_MASTER A, MFTM_MEETING_SCH_DETAIL B
       WHERE A.MEETING_CODE = B.MEETING_CODE
         AND A.MEETING_CODE = P_MEETING_CODE;
  
    TYPE TY_MEETING_DT IS TABLE OF CR_MEETING%ROWTYPE INDEX BY BINARY_INTEGER;
    L_MEETING_DT TY_MEETING_DT;
  
  BEGIN
    DBG('In Fn_Default_Maturity_Date..');
  
    IF NOT CLPKSS_CLDACCNT_TYPE_CONV.FN_BUILD_ACC_OBJ(L_ACCOUNT_OBJ,
                                                      P_WRK_CLDACCNT,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
    END IF;
  
    IF NVL(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE, 'CL') = 'MF' THEN
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NULL THEN
        P_WRK_CLDACCNT := P_CLDACCNT;
      END IF;
    
      IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE IS NOT NULL THEN
        P_MATURITY_DATE       := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE;
        P_CALCULATED_MATURITY := FALSE;
        RETURN TRUE;
      END IF;
    
      BEGIN
        SELECT DEFAULT_FROM_METSCH
          INTO L_DFLT_FRM_MEETING
          FROM CLTM_PRODUCT
         WHERE PRODUCT_CODE =
               P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('INSIDE NO_DATA_FOUND OF DEFAULT_FROM_METSCH');
      END;
      DBG(' nik333333333' || L_DFLT_FRM_MEETING);
      IF L_DFLT_FRM_MEETING = 'Y' THEN
        DBG('NIK TESTING1111');
        DBG(' p_cldaccnt.v_cltbs_account_master.customer_idNN' ||
            P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID);
        BEGIN
          SELECT CENTER_CODE
            INTO L_ENT
            FROM MFTM_CENTER_DEFINITION
           WHERE CENTER_CIF_ID =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
             AND RECORD_STAT = 'O';
          DBG('CENTER_CODE' || L_ENT);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT A.CENTER_CODE
                INTO L_ENT
                FROM MFTM_CENTER_CURRENT_MEMBER A, MFTM_GROUP_DEFINITION B
               WHERE A.GROUP_CODE = B.GROUP_CODE
                 AND B.GROUP_CIF_ID =
                     P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                 AND B.RECORD_STAT = 'O';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                BEGIN
                  SELECT A.CENTER_CODE
                    INTO L_ENT
                    FROM MFTM_CENTER_CURRENT_MEMBER A,
                         MFTM_GROUP_MEMBER          B,
                         MFTM_CENTER_DEFINITION     C,
                         MFTM_GROUP_DEFINITION      D
                   WHERE A.GROUP_CODE = B.GROUP_CODE
                     AND A.CENTER_CODE = C.CENTER_CODE
                     AND A.GROUP_CODE = D.GROUP_CODE
                     AND B.CUSTOMER_NO =
                         P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                     AND C.RECORD_STAT = 'O'
                     AND D.RECORD_STAT = 'O';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    BEGIN
                      SELECT GROUP_CODE
                        INTO L_ENT
                        FROM MFTM_GROUP_DEFINITION
                       WHERE GROUP_CIF_ID =
                             P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                         AND RECORD_STAT = 'O';
                    
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        BEGIN
                          SELECT A.GROUP_CODE
                            INTO L_ENT
                            FROM MFTM_GROUP_MEMBER     A,
                                 MFTM_GROUP_DEFINITION B
                           WHERE A.GROUP_CODE = B.GROUP_CODE
                             AND B.RECORD_STAT = 'O'
                             AND A.CUSTOMER_NO =
                                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
                          DBG('GROUP_CODE' || L_ENT);
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            DBG('NO GROUP_CODE FOUND FOR THIS CUSTOMER NO xx');
                          
                            BEGIN
                              SELECT CUSTOMER_NO
                                INTO L_ENT
                                FROM STTM_CUSTOMER
                               WHERE CUSTOMER_NO =
                                     P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                                 AND RECORD_STAT = 'O';
                            EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                                DBG('Meeting Schedule Not defined For This Customer.');
                              
                            END;
                          
                        END;
                    END;
                END;
            END;
        END;
      
        DBG('NIK TESTING22222');
      
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_4
            FROM MFTM_MEETING_SCH_MASTER K
           WHERE K.START_DATE =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
             AND K.LAST_MEETING_DATE =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE
             AND K.MEETING_ENTITY = L_ENT;
        END;
        DBG('l_count_4>' || L_COUNT_4);
        IF L_COUNT_4 > 0 THEN
          BEGIN
            SELECT NUMBER_OF_SCHEDULES,
                   START_DATE,
                   UNIT,
                   FREQUENCY,
                   MEETING_CODE
              INTO L_NO_OF_SCHEDULES,
                   L_START_DT,
                   L_UNIT,
                   L_FREQUENCY,
                   L_MEET_CODE
              FROM MFTM_MEETING_SCH_MASTER K
             WHERE K.START_DATE =
                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
               AND K.LAST_MEETING_DATE =
                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE
               AND K.MEETING_ENTITY = L_ENT;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Meeting Schedule Not defined For This Customer.');
          END;
        
          DBG('OPENING CURSOR');
          L_MEETING_DT.DELETE;
          OPEN CR_MEETING(L_MEET_CODE);
          FETCH CR_MEETING BULK COLLECT
            INTO L_MEETING_DT;
          CLOSE CR_MEETING;
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE > L_MEETING_DT(L_MEETING_DT.LAST)
            .ACTUAL_MEETING_DATE THEN
            DBG('Meeting Schedule Not Maintained For This Period For This Customer...');
          ELSE
            FOR I IN L_MEETING_DT.FIRST .. L_MEETING_DT.LAST LOOP
              IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE < L_MEETING_DT(I)
                .ACTUAL_MEETING_DATE AND L_FLAG THEN
                BEGIN
                  SELECT COUNT(*)
                    INTO L_COUNT
                    FROM MFTM_MEETING_SCH_DETAIL
                   WHERE MEETING_CODE = L_MEET_CODE
                     AND ACTUAL_MEETING_DATE >= L_MEETING_DT(I)
                        .ACTUAL_MEETING_DATE;
                END;
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS := L_COUNT;
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT     := L_UNIT;
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY          := L_FREQUENCY;
                P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE     := L_MEETING_DT(I)
                                                                            .ACTUAL_MEETING_DATE;
              
                IF L_UNIT IN ('M', 'H', 'Q', 'Y') THEN
                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON := TO_NUMBER(TO_CHAR(L_MEETING_DT(I)
                                                                                          .ACTUAL_MEETING_DATE,
                                                                                          'DD'));
                END IF;
              
                L_FLAG := FALSE;
              END IF;
            END LOOP;
          END IF;
        ELSE
          DBG('Inside ELSE1');
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY          := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT;
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE;
        END IF;
      ELSE
        DBG('Inside ELSE');
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY          := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE;
      END IF;
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NULL THEN
        P_WRK_CLDACCNT := P_CLDACCNT;
      END IF;
    
      IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE IS NOT NULL THEN
        P_MATURITY_DATE       := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE;
        P_CALCULATED_MATURITY := FALSE;
        RETURN TRUE;
      END IF;
    END IF;
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS IS NOT NULL AND
       P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY IS NOT NULL AND
       P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT IS NOT NULL AND
       P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE IS NOT NULL THEN
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT = 'B' AND
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS > 1 THEN
        P_ERR_CODE   := 'CL-ACC-080';
        P_ERR_PARAMS := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS = 1 AND
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT <> 'B' THEN
        P_ERR_CODE   := 'CL-ACC-046';
        P_ERR_PARAMS := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON < 1 OR
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON > 31 THEN
        DBG('failed in validating 1 <= due_dates_on  <= 31');
        P_ERR_CODE   := 'CL-ACC-078;';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
      DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.due_dates_on :' ||
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON);
      DBG('after converting to days :' ||
          TO_CHAR(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                  'DD'));
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON IS NOT NULL THEN
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON <
           TO_CHAR(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                   'DD') OR P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON >
           TO_CHAR(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                                    'DD') THEN
          DBG('Due Date On Days $1 and Installment Start Date Days $1 are not sync.');
          P_ERR_CODE   := 'CL-COL-092;';
          P_ERR_PARAMS := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON || '~' ||
                          TO_CHAR(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                                  'DD');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    
      DBG('Calling Clpks_Cldaccnt_Utils_1.Fn_First_sche_Date_val');
      IF NOT CLPKS_CLDACCNT_UTILS_1.FN_FIRST_SCHE_DATE_VAL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT,
                                                           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
        DBG('Fn_First_sche_Date_val failed  ' || P_ERR_CODE);
        IF P_ERR_CODE IS NULL THEN
          P_ERR_CODE   := 'CL-SCH036';
          P_ERR_PARAMS := NULL;
        END IF;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
      L_COUNT := 0;
      IF CLPKS_CACHE.FN_PRODUCT_COMPONENTS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE, CLPKS_NLS.MAIN_INT)
       .FORMULA_TYPE = CLPKS_CLDPRMNT_KERNEL.G_DISCOUNTED_SCH THEN
        L_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS + 1;
      ELSE
        L_COUNT := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS;
      END IF;
    
      DBG('Calling clpks_schedules.fn_get_maturity_date ');
      IF NOT CLPKS_SCHEDULES.FN_GET_MATURITY_DATE(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOLIDAY,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_TYPE,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                                  
                                                  L_COUNT,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE,
                                                  P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DUE_DATES_ON,
                                                  P_MATURITY_DATE,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DBG('Failed in LPKS_SCHEDULES.FN_GET_MATURITY_DATE with Err ' ||
            P_ERR_CODE);
        IF P_ERR_CODE IS NULL THEN
          P_ERR_CODE   := 'CL-SCH036';
          P_ERR_PARAMS := NULL;
        END IF;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    
      DBG('Computed Maturity Date' ||
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE);
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE IS NOT NULL THEN
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE <>
           P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE THEN
          DBG('MAturity Date is Redefaulred..');
        END IF;
      END IF;
      P_CALCULATED_MATURITY := TRUE;
    ELSE
    
      L_PRODUCT_PREFERENCE := CLPKS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
      IF L_PRODUCT_PREFERENCE.TENOR_UNIT = 'D' THEN
        P_MATURITY_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE +
                           L_PRODUCT_PREFERENCE.STD_TENOR;
      ELSIF L_PRODUCT_PREFERENCE.TENOR_UNIT = 'M' THEN
        P_MATURITY_DATE := ADD_MONTHS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                      L_PRODUCT_PREFERENCE.STD_TENOR);
      ELSIF L_PRODUCT_PREFERENCE.TENOR_UNIT = 'Y' THEN
        P_MATURITY_DATE := ADD_MONTHS(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                      L_PRODUCT_PREFERENCE.STD_TENOR * 12);
      END IF;
      P_CALCULATED_MATURITY := FALSE;
    END IF;
  
    L_REC_PROD := CLPKS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    IF L_REC_PROD.PRODUCT_END_DATE IS NOT NULL THEN
      DBG('End date of Product ' || L_REC_PROD.PRODUCT_END_DATE);
      IF P_MATURITY_DATE IS NOT NULL AND
         L_REC_PROD.PRODUCT_END_DATE < P_MATURITY_DATE THEN
        DBG(' Maturity date ' || P_MATURITY_DATE);
        DBG('Loan Product Expired Date $1 is Less than Loan Maturity date $2.');
        P_ERR_CODE   := 'CL-PRD-0012;';
        P_ERR_PARAMS := L_REC_PROD.PRODUCT_END_DATE || '~' ||
                        P_MATURITY_DATE || '~;';
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Default_Maturity_Date');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Default_Maturity_Date ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_MATURITY_DATE;

  FUNCTION FN_DEFAULT_ACC_MASTER(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_PROD_CAT  CLTMS_PRODUCT.PRODUCT_CATEGORY%TYPE;
    L_CUST_NAME STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_CON_NO CONSTANT VARCHAR2(1) := 'N';
    L_MARTURITY_DT          CLTBS_ACCOUNT_MASTER.MATURITY_DATE%TYPE;
    L_PROD_PREFS            CLTMS_PRODUCT%ROWTYPE;
    P_CAL_DT                CLTBS_ACCOUNT_MASTER.MATURITY_DATE%TYPE;
    L_ROWID                 ROWID;
    L_TEMP                  VARCHAR2(32);
    L_PROCESS_NO            CLTBS_ACCOUNT_MASTER.PROCESS_NO%TYPE;
    L_SEQ                   VARCHAR2(255);
    L_USER_REF              CLTBS_ACCOUNT_MASTER.USER_REF_NO%TYPE;
    L_BR_AUTO_USERREF       CLTMS_BRANCH_PARAMETERS.AUTO_GEN_USER_REF%TYPE;
    L_REC_BRANCH_PARAMETERS CLTMS_BRANCH_PARAMETERS%ROWTYPE;
    L_ACC_MASTER            CLTBS_ACCOUNT_MASTER%ROWTYPE;
    L_CALCULATED_MATURITY   BOOLEAN := FALSE;
    L_BRANCH_PARAMETERS     CLTMS_BRANCH_PARAMETERS%ROWTYPE;
    L_FOR_SIMULATION        BOOLEAN := FALSE;
    L_COUNT                 NUMBER := 0;
    L_REC_BANK_PARAMETERS   CLTMS_BANK_PARAMETERS%ROWTYPE;
    L_HOLDAY_IDX1           NUMBER;
  
    L_DR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_DR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
    L_CR_ACC_HEAD CLTM_PRODUCT_RTH.ACCOUNT_HEAD%TYPE;
    L_CR_ACC_ROLE CLTM_PRODUCT_RTH.ACCOUNTING_ROLE%TYPE;
  
  BEGIN
    DBG('In Fn_Default_Acc_Master..');
    L_PROD_PREFS                                      := CLPKS_CACHE.FN_PRODUCT(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
  
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.APPLICATION_NUM := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.APPLICATION_NUM;
  
    IF P_ACTION_CODE = 'PRDDFLT' THEN
      CIPKS_CIDACCNT_DEFAULT.G_FRSTDEF := TRUE;
    END IF;
  
    CLPKSS_UTIL.G_PROD := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
  
    L_ACC_MASTER := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER;
  
    L_ACC_MASTER.CUSTOMER_ID      := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
    L_ACC_MASTER.PRODUCT_CODE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
    L_ACC_MASTER.PRODUCT_CATEGORY := L_PROD_PREFS.PRODUCT_CATEGORY;
    L_ACC_MASTER.MODULE_CODE      := L_PROD_PREFS.MODULE_CODE;
    L_ACC_MASTER.BOOK_DATE        := GLOBAL.APPLICATION_DATE;
    L_ACC_MASTER.VALUE_DATE       := NVL(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE,
                                         GLOBAL.APPLICATION_DATE);
  
    L_BRANCH_PARAMETERS   := CLPKS_CACHE.FN_BRANCH_PARAMETERS(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
    L_REC_BANK_PARAMETERS := CLPKS_CACHE.FN_CLTM_BANK_PARAMS();
    DBG('account_number ->' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
    DBG('l_Rec_Bank_parameters.account_mask_reqd' ||
        L_REC_BANK_PARAMETERS.ACCOUNT_MASK_REQD);
    DBG('l_Rec_Bank_parameters.account_mask' ||
        L_REC_BANK_PARAMETERS.ACCOUNT_MASK);
    IF NVL(L_BRANCH_PARAMETERS.ACCT_AUTO_GEN, 'N') = 'N'
      
       AND NOT (L_REC_BANK_PARAMETERS.ACCOUNT_MASK_REQD = 'Y' AND
                L_REC_BANK_PARAMETERS.ACCOUNT_MASK IS NOT NULL) AND
       P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NULL
    
     THEN
      DBG('Account Number Is null..');
      P_ERR_CODE   := 'CL-ACN-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    ELSE
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NULL THEN
        IF NOT CLPKS_OBJECT.FN_CREATE_ACCT_NO(L_ACC_MASTER.BRANCH_CODE,
                                              L_ACC_MASTER.CUSTOMER_ID,
                                              L_ACC_MASTER.PRODUCT_CODE,
                                              L_ACC_MASTER.VALUE_DATE,
                                              L_ACC_MASTER.CURRENCY,
                                              FALSE,
                                              L_FOR_SIMULATION,
                                              L_ACC_MASTER.ACCOUNT_NUMBER,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
          DBG('Failed in Clpks_Object.Fn_Create_Acct_No..');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Auto Generation is Y adn Account Nunmber is received .. Need toValidate the account number..??');
      END IF;
    END IF;
  
    IF L_ACC_MASTER.ALT_ACC_NO IS NULL THEN
      L_ACC_MASTER.ALT_ACC_NO := L_ACC_MASTER.ACCOUNT_NUMBER;
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' THEN
      DBG('HOLIDAY PERIOD COUNT' ||
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS.COUNT);
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS.COUNT > 0 THEN
        FOR K IN 1 .. P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS.COUNT LOOP
          DBG('INSIDE LOOP TO ADD ADHOC HOLIDAY' || P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS(K)
              .HOLIDAY_PERIODS);
          L_HOLDAY_IDX1 := CLPKS_OBJECT.G_ACCOUNT.G_HOL_PERDS.COUNT + 1;
          CLPKS_OBJECT.G_ACCOUNT.G_HOL_PERDS(L_HOLDAY_IDX1).G_ACC_HOL_PERDS.ACCOUNT_NUMBER := NULL;
          CLPKS_OBJECT.G_ACCOUNT.G_HOL_PERDS(L_HOLDAY_IDX1).G_ACC_HOL_PERDS.BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
          CLPKS_OBJECT.G_ACCOUNT.G_HOL_PERDS(L_HOLDAY_IDX1).G_ACC_HOL_PERDS.HOLIDAY_PERIODS := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_HOL_PERDS(K)
                                                                                               .HOLIDAY_PERIODS;
          CLPKS_OBJECT.G_ACCOUNT.G_HOL_PERDS(L_HOLDAY_IDX1).G_ACTION := 'I';
        END LOOP;
      END IF;
    
      IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE, 'CL') = 'CI' THEN
        IF NVL(L_ACC_MASTER.PROP_HANDOVER, 'N') = 'Y' AND
           L_ACC_MASTER.HANDOVER_DATE IS NULL AND
           L_ACC_MASTER.PRODUCT_CATEGORY IN
           ('FORWARDIJARA', 'MUSHARAKAUNCONSTR') AND
           L_ACC_MASTER.END_CONSTRUCT_DT IS NOT NULL THEN
          L_ACC_MASTER.HANDOVER_DATE := L_ACC_MASTER.END_CONSTRUCT_DT;
        END IF;
        IF L_ACC_MASTER.WINDOW_PERIOD_UNIT IS NULL AND
           L_ACC_MASTER.WINDOW_PERIOD_FREQ IS NULL AND
           L_ACC_MASTER.PRODUCT_CATEGORY = 'ISTISNA' THEN
          L_ACC_MASTER.WINDOW_PERIOD_UNIT := L_PROD_PREFS.WINDOW_PERIOD_UNIT;
          L_ACC_MASTER.WINDOW_PERIOD_FREQ := L_PROD_PREFS.WINDOW_PERIOD_FREQ;
        END IF;
        IF L_ACC_MASTER.SUPP_GRACE_PERIOD IS NULL THEN
          L_ACC_MASTER.SUPP_GRACE_PERIOD   := L_PROD_PREFS.SUPP_GRACE_PERIOD;
          L_ACC_MASTER.SUPP_FREQUENCY_UNIT := L_PROD_PREFS.SUPP_FREQUENCY_UNIT;
        END IF;
        IF L_ACC_MASTER.CUST_GRACE_PERIOD IS NULL THEN
          L_ACC_MASTER.CUST_GRACE_PERIOD   := L_PROD_PREFS.CUST_GRACE_PERIOD;
          L_ACC_MASTER.CUST_FREQUENCY_UNIT := L_PROD_PREFS.CUST_FREQUENCY_UNIT;
        END IF;
      END IF;
    
    END IF;
  
    IF NOT FN_DEFAULT_MATURITY_DATE(P_SOURCE,
                                    P_SOURCE_OPERATION,
                                    P_FUNCTION_ID,
                                    P_ACTION_CODE,
                                    P_CLDACCNT,
                                    P_WRK_CLDACCNT,
                                    L_MARTURITY_DT,
                                    L_CALCULATED_MATURITY,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Maturity_Date..');
      RETURN FALSE;
    END IF;
  
    IF NVL(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MODULE_CODE, 'CL') = 'MF' THEN
      L_ACC_MASTER.MATURITY_DATE := L_MARTURITY_DT;
    END IF;
  
    IF L_ACC_MASTER.MATURITY_DATE IS NULL THEN
      L_ACC_MASTER.MATURITY_DATE := L_MARTURITY_DT;
    ELSE
      IF L_CALCULATED_MATURITY THEN
        IF L_MARTURITY_DT <> L_ACC_MASTER.MATURITY_DATE THEN
          DBG('Maturity Date is Re-Defaulted..Can only be a Web Service Request');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CL-MTCL-RDF', NULL);
          L_ACC_MASTER.NO_OF_INSTALLMENTS := NULL;
          L_ACC_MASTER.FREQUENCY          := NULL;
          L_ACC_MASTER.FREQUENCY_UNIT     := 'B';
          L_ACC_MASTER.FIRST_INS_DATE     := NULL;
          L_ACC_MASTER.DUE_DATES_ON       := NULL;
        
        END IF;
      END IF;
    END IF;
    IF NOT (P_SOURCE <> 'FLEXCUBE' AND L_ACC_MASTER.MODULE_CODE = 'CI') THEN
      L_ACC_MASTER.AMOUNT_FINANCED := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED;
    
    ELSE
      L_ACC_MASTER.AMOUNT_FINANCED := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED;
    END IF;
  
    DBG('p_Cldaccnt.v_cstbs_ui_columns__main.char_field3 :- ' ||
        P_CLDACCNT.V_CSTBS_UI_COLUMNS__MAIN.CHAR_FIELD3);
    IF CLPKS_CLDACCNT_UTILS.FROMENRICH = 0 OR
       L_ACC_MASTER.NET_PRINCIPAL IS NULL OR
       (CLPKS_CLDACCNT_UTILS.FROMENRICH = 1 AND
       NVL(P_CLDACCNT.V_CSTBS_UI_COLUMNS__MAIN.CHAR_FIELD3, '#') = 'N') THEN
    
      L_ACC_MASTER.NET_PRINCIPAL := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_FINANCED;
      DBG('l_Acc_Master.Net_Principal:- ' || L_ACC_MASTER.NET_PRINCIPAL);
    
    END IF;
    CLPKS_CLDACCNT_UTILS.FROMENRICH := 0;
  
    L_ACC_MASTER.DOWNPAYMENT_AMOUNT := NULL;
    L_ACC_MASTER.CURRENCY           := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CURRENCY;
    IF P_FUNCTION_ID NOT IN ('CLDMNROL') THEN
      L_ACC_MASTER.ORIGINAL_ST_DATE := NULL;
    END IF;
    L_ACC_MASTER.PRIMARY_APPLICANT_ID := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
  
    DBG('p_Cldaccnt.v_Cltbs_Account_Master.Customer_Id :' ||
        P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID);
    DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.Customer_Id :' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID);
    SELECT CUSTOMER_NAME1
      INTO L_ACC_MASTER.PRIMARY_APPLICANT_NAME
      FROM STTM_CUSTOMER
     WHERE CUSTOMER_NO = P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
       AND ONCE_AUTH = 'Y';
  
    IF P_FUNCTION_ID NOT IN ('CLDMNROL') THEN
      L_ACC_MASTER.USER_DEFINED_STATUS := 'NORM';
    ELSE
      L_ACC_MASTER.USER_DEFINED_STATUS := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.USER_DEFINED_STATUS;
    END IF;
  
    L_ACC_MASTER.CALC_REQD       := L_CON_NO;
    L_ACC_MASTER.BACK_VAL_EFF_DT := NULL;
  
    IF CIPKS_CIDACCNT_DEFAULT.G_FRSTDEF THEN
      L_ACC_MASTER.AUTO_MAN_ROLLOVER        := NVL(L_PROD_PREFS.AUTO_MAN_ROLLOVER,
                                                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AUTO_MAN_ROLLOVER);
      L_ACC_MASTER.SCHEDULE_BASIS           := L_PROD_PREFS.SCHEDULE_BASIS;
      L_ACC_MASTER.UDE_ROLLOVER_BASIS       := L_PROD_PREFS.UDE_ROLLOVER_BASIS;
      L_ACC_MASTER.ROLLOVER_TYPE            := L_PROD_PREFS.ROLLOVER_WITH_INTEREST;
      L_ACC_MASTER.RATE_CODE_PREF           := L_PROD_PREFS.RATE_CODE_PREF;
      L_ACC_MASTER.PASSBOOK_FACILITY        := L_PROD_PREFS.PASSBOOK_FACILITY;
      L_ACC_MASTER.ATM_FACILITY             := L_PROD_PREFS.ATM_FACILITY;
      L_ACC_MASTER.PACKING_CREDIT           := L_PROD_PREFS.PACKING_CREDIT;
      L_ACC_MASTER.ALLOW_BACK_PERIOD_ENTRY  := 'Y';
      L_ACC_MASTER.INT_STMT                 := 'Y';
      L_ACC_MASTER.TRACK_RECEIVABLE_ALIQ    := L_PROD_PREFS.TRACK_RECEIVABLE_ALIQ;
      L_ACC_MASTER.TRACK_RECEIVABLE_MLIQ    := L_PROD_PREFS.TRACK_RECEIVABLE_MLIQ;
      L_ACC_MASTER.LIQUIDATION_MODE         := L_PROD_PREFS.LIQUIDATION_MODE;
      L_ACC_MASTER.AMEND_PAST_PAID_SCHEDULE := L_PROD_PREFS.AMEND_PAST_PAID_SCHEDULE;
      L_ACC_MASTER.CHEQUE_BOOK_FACILITY     := L_PROD_PREFS.CHEQUE_BOOK_FACILITY;
      L_ACC_MASTER.LIQ_COMP_DATES_FLAG      := L_PROD_PREFS.LIQ_COMP_DATES_FLAG;
      L_ACC_MASTER.RATE_CHG_ACTION          := L_PROD_PREFS.RATE_CHG_ACTION;
      L_ACC_MASTER.PROVISIONING_MODE        := L_PROD_PREFS.PROVISIONING_MODE;
      DBG('l_Acc_Master.Account_Status  ' || L_ACC_MASTER.ACCOUNT_STATUS ||
          'p_Function_Id ' || P_FUNCTION_ID);
      IF NVL(P_FUNCTION_ID, '###') IN ('MODEMINT', 'CLDEMINT') THEN
        L_ACC_MASTER.ACCOUNT_STATUS := 'E';
      
      ELSIF NVL(P_FUNCTION_ID, '###') = 'CLDINANT' THEN
        L_ACC_MASTER.ACCOUNT_STATUS  := 'I';
        CLPKS_FUNDING.G_FUND_ACC_IND := 'F';
        L_ACC_MASTER.FUNDED_STATUS   := 950;
        DBG('Account is inactive');
      
      ELSE
        L_ACC_MASTER.ACCOUNT_STATUS := 'A';
      END IF;
      L_ACC_MASTER.AUTH_STAT                 := 'U';
      L_ACC_MASTER.LIQ_BACK_VALUED_SCHEDULES := L_PROD_PREFS.LIQ_BACK_VAL_SCH_FLAG;
      L_ACC_MASTER.VERSION_NO                := 1;
      L_ACC_MASTER.LATEST_ESN                := 1;
      L_ACC_MASTER.PARTIAL_LIQUIDATION       := L_PROD_PREFS.PARTIAL_LIQUIDATION;
      L_ACC_MASTER.ALIQ_REVERSED_PMT         := L_PROD_PREFS.ALIQ_REVERSED_PMT;
      L_ACC_MASTER.RETRIES_AUTO_LIQ          := L_PROD_PREFS.RETRIES_AUTO_LIQ;
      L_ACC_MASTER.RETRIES_ADVICE_DAYS       := L_PROD_PREFS.RETRIES_FOR_ADVICE;
      L_ACC_MASTER.LOAN_STLMNT_NOTICEFLG     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.LOAN_STLMNT_NOTICEFLG;
      L_ACC_MASTER.NOTICE_DATE               := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NOTICE_DATE;
      L_ACC_MASTER.EXPECTED_CLOSURE_DATE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXPECTED_CLOSURE_DATE;
      L_ACC_MASTER.ROLL_BY                   := NVL(L_ACC_MASTER.ROLL_BY,
                                                    L_PROD_PREFS.ROLL_BY);
      L_ACC_MASTER.LOAN_TYPE                 := NVL(L_ACC_MASTER.LOAN_TYPE,
                                                    NVL(L_PROD_PREFS.PRODUCT_TYPE,
                                                        'L'));
      L_ACC_MASTER.COMMITMENT_TYPE           := 'N';
      L_ACC_MASTER.ROLLOVER_ALLOWED          := NVL(L_ACC_MASTER.ROLLOVER_ALLOWED,
                                                    NVL(L_PROD_PREFS.ROLLOVER_ALLOWED,
                                                        'N'));
      L_REC_BRANCH_PARAMETERS                := CLPKS_CACHE.FN_BRANCH_PARAMETERS(GLOBAL.CURRENT_BRANCH);
      L_BR_AUTO_USERREF                      := L_REC_BRANCH_PARAMETERS.AUTO_GEN_USER_REF;
      L_ACC_MASTER.LOAN_TO_VALUE             := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.LOAN_TO_VALUE;
      L_ACC_MASTER.LEASE_TYPE                := NVL(L_ACC_MASTER.LEASE_TYPE,
                                                    L_PROD_PREFS.LEASE_TYPE);
      L_ACC_MASTER.LEASE_PAYMENT_MODE        := NVL(L_ACC_MASTER.LEASE_PAYMENT_MODE,
                                                    L_PROD_PREFS.LEASE_PAYMENT_MODE);
      L_ACC_MASTER.EMI_FREQ                  := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EMI_FREQ;
      L_ACC_MASTER.MIN_EMI                   := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MIN_EMI;
      L_ACC_MASTER.MAX_EMI                   := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MAX_EMI;
      L_ACC_MASTER.EMI_FREQ_UNIT             := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EMI_FREQ_UNIT;
      L_ACC_MASTER.END_DATE                  := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_DATE;
      L_ACC_MASTER.LOAN_AGAINST_SAL          := L_PROD_PREFS.LOAN_AGAINST_SAL;
      L_ACC_MASTER.AMOUNT_BLOCK_FLAG         := L_PROD_PREFS.AMOUNT_BLOCK_FLAG;
    ELSE
    
      L_ACC_MASTER.AUTO_MAN_ROLLOVER        := NVL(L_ACC_MASTER.AUTO_MAN_ROLLOVER,
                                                   NVL(L_PROD_PREFS.AUTO_MAN_ROLLOVER,
                                                       P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AUTO_MAN_ROLLOVER));
      L_ACC_MASTER.SCHEDULE_BASIS           := NVL(L_ACC_MASTER.SCHEDULE_BASIS,
                                                   L_PROD_PREFS.SCHEDULE_BASIS);
      L_ACC_MASTER.UDE_ROLLOVER_BASIS       := NVL(L_ACC_MASTER.UDE_ROLLOVER_BASIS,
                                                   L_PROD_PREFS.UDE_ROLLOVER_BASIS);
      L_ACC_MASTER.ROLLOVER_TYPE            := NVL(L_ACC_MASTER.ROLLOVER_TYPE,
                                                   L_PROD_PREFS.ROLLOVER_WITH_INTEREST);
      L_ACC_MASTER.RATE_CODE_PREF           := NVL(L_ACC_MASTER.RATE_CODE_PREF,
                                                   L_PROD_PREFS.RATE_CODE_PREF);
      L_ACC_MASTER.PASSBOOK_FACILITY        := NVL(L_ACC_MASTER.PASSBOOK_FACILITY,
                                                   L_PROD_PREFS.PASSBOOK_FACILITY);
      L_ACC_MASTER.ATM_FACILITY             := NVL(L_ACC_MASTER.ATM_FACILITY,
                                                   L_PROD_PREFS.ATM_FACILITY);
      L_ACC_MASTER.PACKING_CREDIT           := NVL(L_ACC_MASTER.PACKING_CREDIT,
                                                   L_PROD_PREFS.PACKING_CREDIT);
      L_ACC_MASTER.ALLOW_BACK_PERIOD_ENTRY  := 'Y';
      L_ACC_MASTER.INT_STMT                 := 'Y';
      L_ACC_MASTER.TRACK_RECEIVABLE_ALIQ    := NVL(L_ACC_MASTER.TRACK_RECEIVABLE_ALIQ,
                                                   L_PROD_PREFS.TRACK_RECEIVABLE_ALIQ);
      L_ACC_MASTER.TRACK_RECEIVABLE_MLIQ    := NVL(L_ACC_MASTER.TRACK_RECEIVABLE_MLIQ,
                                                   L_PROD_PREFS.TRACK_RECEIVABLE_MLIQ);
      L_ACC_MASTER.LIQUIDATION_MODE         := NVL(L_ACC_MASTER.LIQUIDATION_MODE,
                                                   L_PROD_PREFS.LIQUIDATION_MODE);
      L_ACC_MASTER.AMEND_PAST_PAID_SCHEDULE := NVL(L_ACC_MASTER.AMEND_PAST_PAID_SCHEDULE,
                                                   L_PROD_PREFS.AMEND_PAST_PAID_SCHEDULE);
      L_ACC_MASTER.CHEQUE_BOOK_FACILITY     := NVL(L_ACC_MASTER.CHEQUE_BOOK_FACILITY,
                                                   L_PROD_PREFS.CHEQUE_BOOK_FACILITY);
      L_ACC_MASTER.LIQ_COMP_DATES_FLAG      := NVL(L_ACC_MASTER.LIQ_COMP_DATES_FLAG,
                                                   L_PROD_PREFS.LIQ_COMP_DATES_FLAG);
    
      L_ACC_MASTER.RATE_CHG_ACTION := NVL(L_ACC_MASTER.RATE_CHG_ACTION,
                                          L_PROD_PREFS.RATE_CHG_ACTION);
    
      DBG('l_Acc_Master.Account_Status  ' || L_ACC_MASTER.ACCOUNT_STATUS ||
          'p_Function_Id ' || P_FUNCTION_ID);
      IF NVL(P_FUNCTION_ID, '###') IN ('MODEMINT', 'CLDEMINT') THEN
        L_ACC_MASTER.ACCOUNT_STATUS := 'E';
      ELSE
        L_ACC_MASTER.ACCOUNT_STATUS := 'A';
      END IF;
    
      L_ACC_MASTER.AUTH_STAT := 'U';
    
      L_ACC_MASTER.LIQ_BACK_VALUED_SCHEDULES := NVL(P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.LIQ_BACK_VALUED_SCHEDULES,
                                                    L_PROD_PREFS.LIQ_BACK_VAL_SCH_FLAG);
    
      IF NVL(P_FUNCTION_ID, '###') <> 'CLDMNROL' THEN
      
        L_ACC_MASTER.VERSION_NO := 1;
        L_ACC_MASTER.LATEST_ESN := 1;
      END IF;
      L_ACC_MASTER.PARTIAL_LIQUIDATION   := NVL(L_ACC_MASTER.PARTIAL_LIQUIDATION,
                                                L_PROD_PREFS.PARTIAL_LIQUIDATION);
      L_ACC_MASTER.ALIQ_REVERSED_PMT     := NVL(L_ACC_MASTER.ALIQ_REVERSED_PMT,
                                                L_PROD_PREFS.ALIQ_REVERSED_PMT);
      L_ACC_MASTER.RETRIES_AUTO_LIQ      := NVL(L_ACC_MASTER.RETRIES_AUTO_LIQ,
                                                L_PROD_PREFS.RETRIES_AUTO_LIQ);
      L_ACC_MASTER.RETRIES_ADVICE_DAYS   := NVL(L_ACC_MASTER.RETRIES_ADVICE_DAYS,
                                                L_PROD_PREFS.RETRIES_FOR_ADVICE);
      L_ACC_MASTER.LOAN_STLMNT_NOTICEFLG := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.LOAN_STLMNT_NOTICEFLG;
      L_ACC_MASTER.NOTICE_DATE           := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NOTICE_DATE;
      L_ACC_MASTER.EXPECTED_CLOSURE_DATE := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EXPECTED_CLOSURE_DATE;
      L_ACC_MASTER.ROLL_BY               := NVL(L_ACC_MASTER.ROLL_BY,
                                                L_PROD_PREFS.ROLL_BY);
      L_ACC_MASTER.LOAN_TYPE             := NVL(L_ACC_MASTER.LOAN_TYPE,
                                                NVL(L_PROD_PREFS.PRODUCT_TYPE,
                                                    'L'));
      L_ACC_MASTER.COMMITMENT_TYPE       := 'N';
      L_ACC_MASTER.ROLLOVER_ALLOWED      := NVL(L_ACC_MASTER.ROLLOVER_ALLOWED,
                                                NVL(L_PROD_PREFS.ROLLOVER_ALLOWED,
                                                    'N'));
      L_REC_BRANCH_PARAMETERS            := CLPKS_CACHE.FN_BRANCH_PARAMETERS(GLOBAL.CURRENT_BRANCH);
      L_BR_AUTO_USERREF                  := L_REC_BRANCH_PARAMETERS.AUTO_GEN_USER_REF;
      L_ACC_MASTER.LOAN_TO_VALUE         := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.LOAN_TO_VALUE;
      L_ACC_MASTER.LEASE_TYPE            := NVL(L_ACC_MASTER.LEASE_TYPE,
                                                L_PROD_PREFS.LEASE_TYPE);
      L_ACC_MASTER.LEASE_PAYMENT_MODE    := NVL(L_ACC_MASTER.LEASE_PAYMENT_MODE,
                                                L_PROD_PREFS.LEASE_PAYMENT_MODE);
    
      L_ACC_MASTER.EMI_FREQ      := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EMI_FREQ;
      L_ACC_MASTER.MIN_EMI       := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MIN_EMI;
      L_ACC_MASTER.MAX_EMI       := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MAX_EMI;
      L_ACC_MASTER.EMI_FREQ_UNIT := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.EMI_FREQ_UNIT;
      L_ACC_MASTER.END_DATE      := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.END_DATE;
    
      L_ACC_MASTER.LOAN_AGAINST_SAL := NVL(L_ACC_MASTER.LOAN_AGAINST_SAL,
                                           L_PROD_PREFS.LOAN_AGAINST_SAL);
    
      L_ACC_MASTER.AMOUNT_BLOCK_FLAG := NVL(L_ACC_MASTER.AMOUNT_BLOCK_FLAG,
                                            L_PROD_PREFS.AMOUNT_BLOCK_FLAG);
    
    END IF;
  
    SELECT COUNT(*)
      INTO L_COUNT
      FROM CLTMS_PRODUCT_STMT
     WHERE PRODUCT_CODE =
           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE
       AND MESSAGE_TYPE = CLPKSS_NLS.CL_LOAN_STMT;
    DBG('Loan Settlement details is maintained @ product if count is not ZERO, see l_count value is ' ||
        L_COUNT);
    IF L_ACC_MASTER.LOAN_STMT_REQD IS NULL THEN
    
      IF L_COUNT > 0 THEN
        L_ACC_MASTER.LOAN_STMT_REQD := 'Y';
      ELSE
        L_ACC_MASTER.LOAN_STMT_REQD := 'N';
      END IF;
    END IF;
  
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER := L_ACC_MASTER;
  
    IF L_BR_AUTO_USERREF = 'Y' THEN
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.USER_REF_NO IS NULL THEN
        IF NOT TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                           'ZSWF',
                                           GLOBAL.APPLICATION_DATE,
                                           L_SEQ,
                                           L_USER_REF,
                                           P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.USER_REF_NO := L_USER_REF;
      END IF;
    END IF;
  
    IF L_BR_AUTO_USERREF = 'N' THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.USER_REF_NO := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.USER_REF_NO,
                                                               P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
    END IF;
  
    DBG('open line loan IN product defualt account master is= ' ||
        L_PROD_PREFS.OPEN_LINE_LOAN);
    DBG('revp;ving type in product defualt account master is= ' ||
        L_PROD_PREFS.REVOLVING_TYPE);
    DBG('action code in  product defualt account master is= ' ||
        L_PROD_PREFS.OPEN_LINE_LOAN);
  
    IF NVL(L_PROD_PREFS.OPEN_LINE_LOAN, 'N') = 'Y' AND
       NVL(L_PROD_PREFS.REVOLVING_TYPE, 'N') = 'Y' AND
       P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_PRDDFLT THEN
      DBG('for setting the default value for min_amt_due_calc_method');
    
      BEGIN
        SELECT RULE_NAME
          INTO P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MIN_AMT_DUE_RULE
          FROM CLTM_MIN_AMT_DUE_RULE
         WHERE PRODUCT_CODE = L_PROD_PREFS.PRODUCT_CODE
           AND DEFAULT_RULE = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('failed in getting default formula for mad calculation .......');
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MIN_AMT_DUE_RULE := NULL;
      END;
      DBG('minimum amt due cal method = ' ||
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MIN_AMT_DUE_RULE);
      L_ACC_MASTER.OPEN_LINE_LOAN := NVL(L_PROD_PREFS.OPEN_LINE_LOAN, 'n');
      L_ACC_MASTER.REVOLVING_TYPE := NVL(L_PROD_PREFS.REVOLVING_TYPE, 'n');
      L_ACC_MASTER.CREDITDAYS     := NVL(L_PROD_PREFS.CREDITDAYS, 0);
    
    END IF;
  
    IF FN_GET_PROCESS_NO(GLOBAL.CURRENT_BRANCH,
                         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID,
                         L_PROCESS_NO,
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PROCESS_NO := L_PROCESS_NO;
      IF NOT FCPKS_PARTITION_INFO.GETFROMHOMER THEN
        FCPKS_PARTITION_INFO.G_THIS_PART := L_PROCESS_NO;
      END IF;
    END IF;
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMOUNT_DISBURSED := 0;
    IF CLPKSS_FUNDING.G_FUND_ACC_IND = 'A' THEN
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FUNDED_STATUS := 1000;
    ELSE
      P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FUNDED_STATUS := 700;
    END IF;
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.AMORTIZED := NULL;
  
    DBG('Defaulting the Settlement Accounts..');
  
    L_DR_ACC_ROLE := 'DR_SETTL_BRIDGE';
    L_CR_ACC_ROLE := 'CR_SETTL_BRIDGE';
    IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                       L_DR_ACC_ROLE,
                                       L_DR_ACC_HEAD) THEN
      L_DR_ACC_ROLE := NULL;
      L_DR_ACC_HEAD := NULL;
    END IF;
    IF NOT CLPKS_CACHE.FN_GET_ACC_HEAD(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                       L_CR_ACC_ROLE,
                                       L_CR_ACC_HEAD) THEN
      L_CR_ACC_ROLE := NULL;
      L_CR_ACC_HEAD := NULL;
    END IF;
  
    IF L_DR_ACC_ROLE = 'DR_SETTL_BRIDGE' THEN
    
      IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE, 'ACC') =
         'ACC' THEN
      
        IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
               P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC) IS NULL THEN
        
          DBG('Sent in dr details are null.. so assigning default vals');
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PAYMENT_MODE := 'ACC';
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC := L_DR_ACC_HEAD;
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_ACC_BRN := GLOBAL.CURRENT_BRANCH;
        
        END IF;
      
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC IS NOT NULL THEN
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC;
        END IF;
      
      END IF;
    
    END IF;
  
    IF L_CR_ACC_ROLE = 'CR_SETTL_BRIDGE' THEN
    
      IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE, 'ACC') =
         'ACC' THEN
      
        IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
               P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC) IS NULL THEN
        
          DBG('Sent in cr details are null.. so assigning default vals');
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE := 'ACC';
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC := L_DR_ACC_HEAD;
        
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_ACC_BRN := GLOBAL.CURRENT_BRANCH;
        
        END IF;
      
        IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC IS NOT NULL THEN
          P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC;
        END IF;
      
      END IF;
    
    END IF;
  
    IF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC IS NOT NULL THEN
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_CR_PROD_AC,
                                                                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PROD_AC);
      END IF;
      IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC IS NOT NULL THEN
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC := NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.UI_DR_PROD_AC,
                                                                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.DR_PROD_AC);
      END IF;
    END IF;
  
    IF NVL(P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CR_PAYMENT_MODE, 'ACC') <>
       'EAC' THEN
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_1 IS NOT NULL OR
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_2 IS NOT NULL OR
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_3 IS NOT NULL OR
         P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PAYMENT_DETAILS_4 IS NOT NULL THEN
        P_ERR_CODE   := 'CL-MDSBR99;';
        P_ERR_PARAMS := '';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
        DBG('payment details applicable only for external account settlement ');
      
      END IF;
    
    END IF;
  
    DBG('Returning Success From  Fn_Default_Acc_Master..');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling clpks_cldaccnt_default_cluster.Fn_Post_Default_Acc_Master');
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_POST_DEFAULT_ACC_MASTER(P_SOURCE,
                                                                    P_SOURCE_OPERATION,
                                                                    P_FUNCTION_ID,
                                                                    P_ACTION_CODE,
                                                                    P_CLDACCNT,
                                                                    P_WRK_CLDACCNT,
                                                                    P_ERR_CODE,
                                                                    P_ERR_PARAMS) THEN
        DBG('Failed in clpks_cldaccnt_default_cluster.Fn_Post_Default_Acc_Master....');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Acc_Master..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DEFAULT_ACC_MASTER;

  FUNCTION FN_GET_DFLT_STL_INS(P_ACCOUNT_REC CLTBS_ACCOUNT_MASTER%ROWTYPE)
    RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    CUR_LEVEL    INTEGER := 1;
    IS_REC_FOUND BOOLEAN := FALSE;
    L_CPARTY     ISTMS_INSTR.COUNTERPARTY%TYPE;
    L_STL_CCY    CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_MOD        SMTBS_MODULES.MODULE_ID%TYPE;
    L_BRN        STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_PROD_CD    CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    TYPE TY_TB_MAINT_INSTR IS TABLE OF ISTMS_INSTR%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_MAINTROW TY_TB_MAINT_INSTR;
    FUNCTION FN_FETCH_INS(P_CP      VARCHAR2,
                          P_SCCY    VARCHAR2,
                          P_MDL     VARCHAR2,
                          P_BRN     VARCHAR2,
                          P_PROD_CD VARCHAR2) RETURN BOOLEAN IS
    
    BEGIN
      DBG('Trying level ' || TO_CHAR(CUR_LEVEL));
      DBG('Counterparty ' || P_CP);
      DBG('Currency ' || P_SCCY);
      DBG('Module ' || P_MDL);
      DBG('Branch ' || P_BRN);
      DBG('Product' || P_PROD_CD);
      SELECT *
        BULK COLLECT
        INTO L_TB_MAINTROW
        FROM ISTMS_INSTR
       WHERE COUNTERPARTY = P_CP
         AND CURRENCY = P_SCCY
         AND MODULE = P_MDL
         AND BRANCH = P_BRN
         AND PRODUCT_CODE = P_PROD_CD
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      IF L_TB_MAINTROW.COUNT > 0 THEN
        RETURN TRUE;
      ELSE
        RETURN FALSE;
      END IF;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
    END FN_FETCH_INS;
  
  BEGIN
    DBG(' just before the loop in dflt_setl_ins');
    DELETE FROM CLTB_ACCOUNT_SETTL_SEQ
     WHERE ACCOUNT_NUMBER = P_ACCOUNT_REC.ACCOUNT_NUMBER
       AND BRANCH_CODE = P_ACCOUNT_REC.BRANCH_CODE;
    WHILE (CUR_LEVEL <= 24) AND (NOT IS_REC_FOUND) LOOP
    
      DBG(' cur_level is....1 :' || CUR_LEVEL);
      IF CUR_LEVEL > 12 THEN
        L_CPARTY := 'ALL';
      ELSE
        L_CPARTY := P_ACCOUNT_REC.CUSTOMER_ID;
      END IF;
    
      IF MOD(CUR_LEVEL, 12) BETWEEN 1 AND 6 THEN
        L_STL_CCY := P_ACCOUNT_REC.CURRENCY;
      ELSE
        L_STL_CCY := 'ALL';
      END IF;
    
      IF MOD(CUR_LEVEL, 6) BETWEEN 1 AND 4 THEN
        L_MOD := P_ACCOUNT_REC.MODULE_CODE;
      ELSE
        L_MOD := 'AL';
      END IF;
    
      IF MOD(CUR_LEVEL, 6) IN (1, 2) THEN
        L_PROD_CD := P_ACCOUNT_REC.PRODUCT_CODE;
      ELSE
        L_PROD_CD := 'ALL';
      END IF;
    
      IF MOD(CUR_LEVEL, 2) = 0 THEN
        L_BRN := 'ALL';
      ELSE
        L_BRN := P_ACCOUNT_REC.BRANCH_CODE;
      END IF;
    
      DEBUG.PR_DEBUG('IS',
                     ' party is 2 : ' || L_CPARTY || ' :settle ccy2 :' ||
                     L_STL_CCY);
      DEBUG.PR_DEBUG('IS', ' module 2 :' || L_MOD || ' branch2 :' || L_BRN);
      DEBUG.PR_DEBUG('IS',
                     CUR_LEVEL || '  ' || L_CPARTY || ' ' || L_STL_CCY || ' ' ||
                     L_MOD || ' ' || L_PROD_CD || ' ' || L_BRN);
    
      IS_REC_FOUND := FN_FETCH_INS(L_CPARTY,
                                   L_STL_CCY,
                                   L_MOD,
                                   L_BRN,
                                   L_PROD_CD);
      CUR_LEVEL    := CUR_LEVEL + 1;
    END LOOP;
    IF L_TB_MAINTROW.COUNT > 0 THEN
      FORALL I IN L_TB_MAINTROW.FIRST .. L_TB_MAINTROW.LAST
        INSERT INTO CLTB_ACCOUNT_SETTL_SEQ
        VALUES
          (P_ACCOUNT_REC.ACCOUNT_NUMBER,
           P_ACCOUNT_REC.BRANCH_CODE,
           L_TB_MAINTROW               (I).SETTLEMENT_SEQ_NO,
           L_TB_MAINTROW               (I).PAY_ACCOUNT,
           L_TB_MAINTROW               (I).RECV_ACCOUNT,
           L_TB_MAINTROW               (I).PAY_AC_BRANCH,
           L_TB_MAINTROW               (I).RECV_AC_BRANCH,
           L_TB_MAINTROW               (I).PAY_ACCOUNT_CCY,
           L_TB_MAINTROW               (I).RECV_ACCOUNT_CCY,
           P_ACCOUNT_REC.MODULE_CODE,
           P_ACCOUNT_REC.CURRENCY,
           L_TB_MAINTROW               (I).COUNTERPARTY,
           L_TB_MAINTROW               (I).PAYMENT_BY_PAY,
           L_TB_MAINTROW               (I).PAYMENT_BY_REC
           
          ,
           L_TB_MAINTROW(I).UI_PAY_ACCOUNT,
           L_TB_MAINTROW(I).UI_RECV_ACCOUNT
           
           );
    
    END IF;
  
    COMMIT;
    L_TB_MAINTROW.DELETE;
    RETURN TRUE;
  END FN_GET_DFLT_STL_INS;

  FUNCTION FN_DEFAULT_ACCOUNT(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_WRK_CLDACCNT     IN OUT CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_ACCOUNT_OBJ       CLPKS_OBJECT.TY_REC_ACCOUNT;
    L_VALUE_DATE        DATE;
    L_MATURITY_DATE     DATE;
    L_EVENT_CODE        VARCHAR2(100) := 'BOOK';
    L_EVENT_SEQ_NO      NUMBER := 1;
    L_DUE_IDX           NUMBER;
    L_CHG               VARCHAR2(100);
    L_DISBURSEMENT_MODE CLTMS_PRODUCT.DISBURSEMENT_MODE%TYPE;
  
    L_ENT              CLTB_ACCOUNT_MASTER.CUSTOMER_ID%TYPE;
    L_NO_OF_SCHEDULES  MFTM_MEETING_SCH_MASTER.NUMBER_OF_SCHEDULES%TYPE;
    L_START_DT         DATE;
    L_UNIT             MFTM_MEETING_SCH_MASTER.UNIT%TYPE;
    L_FREQUENCY        MFTM_MEETING_SCH_MASTER.FREQUENCY%TYPE;
    L_DFLT_FRM_MEETING CLTM_PRODUCT.DEFAULT_FROM_METSCH%TYPE;
    L_MEET_CODE        MFTM_MEETING_SCH_MASTER.MEETING_CODE%TYPE;
    L_FLAG             BOOLEAN := TRUE;
    L_COUNT            NUMBER := 0;
    L_COUNT_4          NUMBER := 0;
    L_TD_REC_ACC       STTMS_CUST_ACCOUNT%ROWTYPE;
    CURSOR CR_MEETING(P_MEETING_CODE VARCHAR2) IS
      SELECT B.ACTUAL_MEETING_DATE
        FROM MFTM_MEETING_SCH_MASTER A, MFTM_MEETING_SCH_DETAIL B
       WHERE A.MEETING_CODE = B.MEETING_CODE
         AND A.MEETING_CODE = P_MEETING_CODE;
  
    TYPE TY_MEETING_DT IS TABLE OF CR_MEETING%ROWTYPE INDEX BY BINARY_INTEGER;
    L_MEETING_DT TY_MEETING_DT;
  
    L_TB_CLUSTER_DATA       GLOBAL. TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL. TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('In Fn_Default_Account..');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Clpks_cldaccnt_default_cluster');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_PRE_DEFAULT_ACCOUNT(L_ACCOUNT_OBJ,
                                                                P_SOURCE,
                                                                P_SOURCE_OPERATION,
                                                                P_FUNCTION_ID,
                                                                P_ACTION_CODE,
                                                                P_CLDACCNT,
                                                                P_WRK_CLDACCNT,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAMS) THEN
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    IF NVL(P_CLDACCNT. V_CLTBS_ACCOUNT_MASTER.MODULE_CODE, 'CL') = 'MF' THEN
      IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NULL THEN
        P_WRK_CLDACCNT := P_CLDACCNT;
      END IF;
    END IF;
  
    IF NOT FN_DEFAULT_ACC_MASTER(P_SOURCE,
                                 P_SOURCE_OPERATION,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_CLDACCNT,
                                 P_WRK_CLDACCNT,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Account..');
      RETURN FALSE;
    END IF;
  
    CLPKSS_CONTEXT.G_ACCOUNT_OBJ.ACCOUNT_DET := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER;
  
    IF NOT FN_DEFAULT_CHECK_LIST(P_SOURCE,
                                 P_SOURCE_OPERATION,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 L_EVENT_CODE,
                                 L_EVENT_SEQ_NO,
                                 P_CLDACCNT,
                                 P_WRK_CLDACCNT,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Check_List..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_PARTIES(P_SOURCE,
                              P_SOURCE_OPERATION,
                              P_FUNCTION_ID,
                              P_ACTION_CODE,
                              P_CLDACCNT,
                              P_WRK_CLDACCNT,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Parties..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_HOL_PERIODS(P_SOURCE,
                                  P_SOURCE_OPERATION,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_CLDACCNT,
                                  P_WRK_CLDACCNT,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Hol_Periods..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_PROMOTIONS(P_SOURCE,
                                 P_SOURCE_OPERATION,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_CLDACCNT,
                                 P_WRK_CLDACCNT,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Promotions..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_ROLL_COMPONENTS(P_SOURCE,
                                      P_SOURCE_OPERATION,
                                      P_FUNCTION_ID,
                                      P_ACTION_CODE,
                                      P_CLDACCNT,
                                      P_WRK_CLDACCNT,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Roll_Components..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_COMPONENTS(P_SOURCE,
                                 P_SOURCE_OPERATION,
                                 P_FUNCTION_ID,
                                 P_ACTION_CODE,
                                 P_CLDACCNT,
                                 P_WRK_CLDACCNT,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Components..');
      RETURN FALSE;
    END IF;
  
    P_WRK_CLDACCNT.V_ACCOUNT_EVENTS_ADVICES.DELETE;
  
    IF NOT FN_DEFAULT_EVENT_ADVICES(P_SOURCE,
                                    P_SOURCE_OPERATION,
                                    P_FUNCTION_ID,
                                    P_ACTION_CODE,
                                    'BOOK',
                                    1,
                                    P_CLDACCNT,
                                    P_WRK_CLDACCNT,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Event_Advices..');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_DEFAULT_EVENT_ADVICES(P_SOURCE,
                                    P_SOURCE_OPERATION,
                                    P_FUNCTION_ID,
                                    P_ACTION_CODE,
                                    'INIT',
                                    2,
                                    P_CLDACCNT,
                                    P_WRK_CLDACCNT,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Event_Advices..');
      RETURN FALSE;
    END IF;
  
    DBG('p_Wrk_Cldaccnt.v_Cltbs_Account_Master.Product_Code' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    SELECT NVL(DISBURSEMENT_MODE, 'A')
      INTO L_DISBURSEMENT_MODE
      FROM CLTMS_PRODUCT
     WHERE PRODUCT_CODE =
           P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
    DBG('l_disbursement_mode' || L_DISBURSEMENT_MODE);
    IF L_DISBURSEMENT_MODE = 'A' THEN
      IF NOT FN_DEFAULT_EVENT_ADVICES(P_SOURCE,
                                      P_SOURCE_OPERATION,
                                      P_FUNCTION_ID,
                                      P_ACTION_CODE,
                                      'DSBR',
                                      3,
                                      P_CLDACCNT,
                                      P_WRK_CLDACCNT,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Default_Event_Advices..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_DEFAULT_UDE(P_SOURCE,
                          P_SOURCE_OPERATION,
                          P_FUNCTION_ID,
                          P_ACTION_CODE,
                          P_CLDACCNT,
                          P_WRK_CLDACCNT,
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Components..');
      RETURN FALSE;
    END IF;
  
    DBG('Calling Fn_Default_Settlement_Details..');
    IF P_ACTION_CODE <> CLPKS_CLDACCNT_DEFAULT.G_HOLDFLT THEN
      IF NOT FN_DEFAULT_SETTLEMENT_DETAILS(P_SOURCE,
                                           P_SOURCE_OPERATION,
                                           P_FUNCTION_ID,
                                           P_ACTION_CODE,
                                           P_CLDACCNT,
                                           P_WRK_CLDACCNT,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Default_Settlement_Details..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.SUBSIDY_CUSTOMER_ID IS NOT NULL THEN
      DBG('Calling Fn_Default_Settlement_Subsidy..');
      IF NOT FN_DEFAULT_SETTLEMENT_SUBSIDY(P_SOURCE,
                                           P_SOURCE_OPERATION,
                                           P_FUNCTION_ID,
                                           P_ACTION_CODE,
                                           P_CLDACCNT,
                                           P_WRK_CLDACCNT,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Default_Settlement_Subsidy..');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Calling Fn_Default_Rate_Plan_Details..');
    IF NOT FN_DEFAULT_RATE_PLAN_DETAILS(P_SOURCE,
                                        P_SOURCE_OPERATION,
                                        P_FUNCTION_ID,
                                        P_ACTION_CODE,
                                        P_CLDACCNT,
                                        P_WRK_CLDACCNT,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Default_Rate_Plan_Details..');
      RETURN FALSE;
    END IF;
  
    DBG('Calling Fn_Default_Holiday_Pref.. for action code' ||
        P_ACTION_CODE);
    IF P_ACTION_CODE <> CLPKS_CLDACCNT_DEFAULT.G_HOLDFLT THEN
      IF NOT FN_DEFAULT_HOLIDAY_PREF(P_SOURCE,
                                     P_SOURCE_OPERATION,
                                     P_FUNCTION_ID,
                                     P_ACTION_CODE,
                                     P_CLDACCNT,
                                     P_WRK_CLDACCNT,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Default_Components..');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('the First Pay by Date in in parameter ' ||
        P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_PAY_BY_DATE);
    P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_PAY_BY_DATE := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_PAY_BY_DATE;
  
    DBG('Converting into Account Object..');
    IF NOT CLPKS_CLDACCNT_TYPE_CONV.FN_BUILD_ACC_OBJ(L_ACCOUNT_OBJ,
                                                     P_WRK_CLDACCNT,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
      DBG('Failed in Clpks_Cldaccnt_Type_Conv.Fn_Build_Acc_Obj..');
      RETURN FALSE;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_DEFAULT_ACCOUNT(L_ACCOUNT_OBJ,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
        DBG('Failed in clpks_cldaccnt_default_cluster.Fn_default_account');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        RETURN FALSE;
      END IF;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    END IF;
  
    IF NOT CLPKS_OBJECT.FN_DEFAULT_SCH_CALC(L_ACCOUNT_OBJ,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
      DBG('Failed in Clpks_Object.Fn_Default_Sch_Calc..');
      RETURN FALSE;
    END IF;
  
    DBG('calling default linkages...');
    IF NOT CLPKSS_CLDACCNT_DEFAULT.FN_DEFAULT_TD_LINKAGES(L_ACCOUNT_OBJ,
                                                          L_TD_REC_ACC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
      DBG('Failed in fn_default_td_linkage details of fn_enrich');
      RETURN FALSE;
    END IF;
  
    IF NVL(P_CLDACCNT. V_CLTBS_ACCOUNT_MASTER.MODULE_CODE, 'CL') = 'MF' THEN
      BEGIN
        SELECT DEFAULT_FROM_METSCH
          INTO L_DFLT_FRM_MEETING
          FROM CLTM_PRODUCT
         WHERE PRODUCT_CODE =
               P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('INSIDE NO_DATA_FOUND OF DEFAULT_FROM_METSCH');
      END;
      DBG(' nik333333333' || L_DFLT_FRM_MEETING);
      IF L_DFLT_FRM_MEETING = 'Y' THEN
        DBG('NIK TESTING1111');
        DBG(' p_cldaccnt.v_cltbs_account_master.customer_idNN' ||
            P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID);
        BEGIN
          SELECT CENTER_CODE
            INTO L_ENT
            FROM MFTM_CENTER_DEFINITION
           WHERE CENTER_CIF_ID =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
             AND RECORD_STAT = 'O';
          DBG('CENTER_CODE' || L_ENT);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT A.CENTER_CODE
                INTO L_ENT
                FROM MFTM_CENTER_CURRENT_MEMBER A, MFTM_GROUP_DEFINITION B
               WHERE A.GROUP_CODE = B.GROUP_CODE
                 AND B.GROUP_CIF_ID =
                     P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                 AND B.RECORD_STAT = 'O';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
              
                BEGIN
                  SELECT A.CENTER_CODE
                    INTO L_ENT
                    FROM MFTM_CENTER_CURRENT_MEMBER A,
                         MFTM_GROUP_MEMBER          B,
                         MFTM_CENTER_DEFINITION     C,
                         MFTM_GROUP_DEFINITION      D
                   WHERE A.GROUP_CODE = B.GROUP_CODE
                     AND A.CENTER_CODE = C.CENTER_CODE
                     AND A.GROUP_CODE = D.GROUP_CODE
                     AND B.CUSTOMER_NO =
                         P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                     AND C.RECORD_STAT = 'O'
                     AND D.RECORD_STAT = 'O';
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    BEGIN
                    
                      SELECT GROUP_CODE
                        INTO L_ENT
                        FROM MFTM_GROUP_DEFINITION
                       WHERE GROUP_CIF_ID =
                             P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                         AND RECORD_STAT = 'O';
                    
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        BEGIN
                          SELECT A.GROUP_CODE
                            INTO L_ENT
                            FROM MFTM_GROUP_MEMBER     A,
                                 MFTM_GROUP_DEFINITION B
                           WHERE A.GROUP_CODE = B.GROUP_CODE
                             AND B.RECORD_STAT = 'O'
                             AND A.CUSTOMER_NO =
                                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID;
                          DBG('GROUP_CODE' || L_ENT);
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            DBG('NO GROUP_CODE FOUND FOR THIS CUSTOMER NO xx');
                            BEGIN
                              SELECT CUSTOMER_NO
                                INTO L_ENT
                                FROM STTM_CUSTOMER
                               WHERE CUSTOMER_NO =
                                     P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID
                                 AND RECORD_STAT = 'O';
                            EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                                DBG('Meeting Schedule Not defined For This Customer.');
                            END;
                          
                        END;
                    END;
                END;
            END;
        END;
      
        DBG('NIK TESTING22222');
        DBG('l_customer_id' || L_ENT);
        DBG('p_cldaccnt.v_cltbs_account_master.customer_id' ||
            P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.CUSTOMER_ID);
        DBG(' p_cldaccnt.v_cltbs_account_master.value_date' ||
            P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE);
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_4
            FROM MFTM_MEETING_SCH_MASTER K
           WHERE K.START_DATE =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
             AND K.LAST_MEETING_DATE =
                 P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE
             AND K.MEETING_ENTITY = L_ENT;
        END;
        DBG('l_count_4>' || L_COUNT_4);
        IF L_COUNT_4 > 0 THEN
          BEGIN
            SELECT NUMBER_OF_SCHEDULES,
                   START_DATE,
                   UNIT,
                   FREQUENCY,
                   MEETING_CODE
              INTO L_NO_OF_SCHEDULES,
                   L_START_DT,
                   L_UNIT,
                   L_FREQUENCY,
                   L_MEET_CODE
              FROM MFTM_MEETING_SCH_MASTER K
             WHERE K.START_DATE =
                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE
               AND K.LAST_MEETING_DATE =
                   P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE
               AND K.MEETING_ENTITY = L_ENT;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG('Meeting Schedulenot maintained as per the criteria where startdate=value date and last meeting date=maturity date.');
            
          END;
          DBG('OPENING CURSOR2');
          L_MEETING_DT.DELETE;
          OPEN CR_MEETING(L_MEET_CODE);
          FETCH CR_MEETING BULK COLLECT
            INTO L_MEETING_DT;
          CLOSE CR_MEETING;
          DBG('l_meeting_dt' || L_MEETING_DT(L_MEETING_DT.LAST)
              .ACTUAL_MEETING_DATE);
        
          IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE > L_MEETING_DT(L_MEETING_DT.LAST)
            .ACTUAL_MEETING_DATE THEN
            DBG('If Unit is Daily or Weekly, Due Date On should be Null...');
          ELSE
            FOR I IN L_MEETING_DT.FIRST .. L_MEETING_DT.LAST LOOP
              IF P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE < L_MEETING_DT(I)
                .ACTUAL_MEETING_DATE AND L_FLAG THEN
                BEGIN
                  SELECT COUNT(*)
                    INTO L_COUNT
                    FROM MFTM_MEETING_SCH_DETAIL
                   WHERE MEETING_CODE = L_MEET_CODE
                     AND ACTUAL_MEETING_DATE >= L_MEETING_DT(I)
                        .ACTUAL_MEETING_DATE;
                END;
                L_ACCOUNT_OBJ.ACCOUNT_DET.NO_OF_INSTALLMENTS := L_COUNT;
                L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY_UNIT     := L_UNIT;
                L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY          := L_FREQUENCY;
                L_ACCOUNT_OBJ.ACCOUNT_DET.FIRST_INS_DATE     := L_MEETING_DT(I)
                                                                .ACTUAL_MEETING_DATE;
              
                IF L_UNIT IN ('M', 'H', 'Q', 'Y') THEN
                  L_ACCOUNT_OBJ.ACCOUNT_DET.DUE_DATES_ON := TO_NUMBER(TO_CHAR(L_MEETING_DT(I)
                                                                              .ACTUAL_MEETING_DATE,
                                                                              'DD'));
                END IF;
              
                L_FLAG := FALSE;
              END IF;
            END LOOP;
          END IF;
        END IF;
      ELSE
        DBG('Inside ELSE1');
        L_ACCOUNT_OBJ.ACCOUNT_DET.NO_OF_INSTALLMENTS := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS;
        L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY          := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY;
        L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY_UNIT     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT;
        L_ACCOUNT_OBJ.ACCOUNT_DET.FIRST_INS_DATE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE;
      END IF;
    ELSE
      DBG('Inside ELSE');
      L_ACCOUNT_OBJ.ACCOUNT_DET.NO_OF_INSTALLMENTS := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.NO_OF_INSTALLMENTS;
      L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY          := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY;
      L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY_UNIT     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FREQUENCY_UNIT;
      L_ACCOUNT_OBJ.ACCOUNT_DET.FIRST_INS_DATE     := P_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.FIRST_INS_DATE;
    
      DBG('No_Of_Installments 1::' ||
          L_ACCOUNT_OBJ.ACCOUNT_DET.NO_OF_INSTALLMENTS);
      DBG('Frequency' || L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY);
      DBG('Frequency_Unit' || L_ACCOUNT_OBJ.ACCOUNT_DET.FREQUENCY_UNIT);
      DBG('First_Ins_Date' || L_ACCOUNT_OBJ.ACCOUNT_DET.FIRST_INS_DATE);
    END IF;
  
    L_VALUE_DATE    := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.VALUE_DATE;
    L_MATURITY_DATE := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER.MATURITY_DATE;
    IF NOT CLPKS_OBJECT.FN_DEFAULT_CHARGES(L_ACCOUNT_OBJ,
                                           L_VALUE_DATE,
                                           L_MATURITY_DATE,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
      DBG('Clpks_Object.Fn_Default_Charges');
      RETURN FALSE;
    END IF;
  
    L_CHG := L_ACCOUNT_OBJ.G_TB_COMPONENTS.FIRST;
    DBG('Firstdummy :' || L_CHG);
    WHILE L_CHG IS NOT NULL LOOP
      DBG('COMP :' || L_CHG || '/' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG)
          .COMP_DET.COMPONENT_TYPE);
      IF L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG)
       .COMP_DET.COMPONENT_TYPE IN ('H', 'O') THEN
        DBG('DUE COUNT :' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG)
            .G_TB_AMT_DUE.COUNT);
        IF L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG).G_TB_AMT_DUE.COUNT > 0 THEN
          L_DUE_IDX := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG)
                       .G_TB_AMT_DUE.FIRST;
          WHILE L_DUE_IDX IS NOT NULL LOOP
            DBG('RINTING :' || L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG).G_TB_AMT_DUE(L_DUE_IDX)
                .G_AMOUNT_DUE.AMOUNT_DUE);
          
            L_DUE_IDX := L_ACCOUNT_OBJ.G_TB_COMPONENTS(L_CHG)
                         .G_TB_AMT_DUE.NEXT(L_DUE_IDX);
          END LOOP;
        END IF;
      END IF;
      L_CHG := L_ACCOUNT_OBJ.G_TB_COMPONENTS.NEXT(L_CHG);
    END LOOP;
  
    IF P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_PROMOTIONS.COUNT > 0 THEN
      IF NOT CLPKS_PROMOTIONS.FN_APPLY_PROMOTIONS(L_ACCOUNT_OBJ,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DBG('Failed in Clpks_Promotions.Fn_Apply_Promotions.. ');
        RETURN FALSE;
      END IF;
    END IF;
  
    CLPKSS_CONTEXT.G_ACCOUNT_OBJ.ACCOUNT_DET := P_WRK_CLDACCNT.V_CLTBS_ACCOUNT_MASTER;
  
    IF NOT C3PK#_PRD_SHELL.FN_DERIVE_UDF(L_ACCOUNT_OBJ.ACCOUNT_DET.PRODUCT_CODE,
                                         L_ACCOUNT_OBJ.ACCOUNT_DET,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
      DBG('Failed in C3pk#_Prd_Shell.Fn_Derive_Udf..');
      RETURN FALSE;
    END IF;
  
    DBG('IOF Changes @@@@@@' ||
        P_WRK_CLDACCNT.V_CSTBS_UI_COLUMNS__MAIN.CHAR_FIELD3);
    DBG('IOF Changes  g_calc_gp :- ' ||
        P_CLDACCNT.V_CSTBS_UI_COLUMNS__MAIN.CHAR_FIELD3);
    IF NVL(P_CLDACCNT.V_CSTBS_UI_COLUMNS__MAIN.CHAR_FIELD3, 'N') = 'Y' THEN
      DBG('Requires Gross Principal Calculation..');
      DBG('Calling clpkss_account.fn_calculate_gross_principal, Amount Financed ::' ||
          L_ACCOUNT_OBJ.ACCOUNT_DET.AMOUNT_FINANCED);
      IF NOT CLPKSS_ACCOUNT.FN_CALCULATE_GROSS_PRINCIPAL(L_ACCOUNT_OBJ,
                                                         CLPKSS_NLS.INIT,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
        DBG('clpkss_account.fn_calculate_gross_principal failed with :-( ' ||
            P_ERR_CODE || ':' || P_ERR_PARAMS);
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('After clpkss_account.fn_calculate_gross_principal, Amount Financed ::' ||
          L_ACCOUNT_OBJ.ACCOUNT_DET.AMOUNT_FINANCED);
    END IF;
  
    DBG('Converting Back To Type...');
  
    IF NOT CLPKS_CLDACCNT_UTILS_1.FN_APPLY_UDF_VALUES(P_SOURCE,
                                                      P_SOURCE_OPERATION,
                                                      P_FUNCTION_ID,
                                                      P_ACTION_CODE,
                                                      P_CLDACCNT,
                                                      L_ACCOUNT_OBJ,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
      DBG('Failed in Clpks_Cldaccnt_Utils_1.Fn_Apply_Udf_Values..');
      RETURN FALSE;
    END IF;
  
    IF NOT CLPKS_CLDACCNT_TYPE_CONV.FN_BUILD_TYPE(P_WRK_CLDACCNT,
                                                  L_ACCOUNT_OBJ,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
      DBG('Failed in Clpks_Cldaccnt_Type_Conv.Fn_Build_Acc_Obj..');
      RETURN FALSE;
    END IF;
  
    IF NOT CLPKS_CLDACCNT_UTILS_1.FN_DERIVE_UDF_DISPLAY(P_WRK_CLDACCNT,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
      DBG('Failed in call to clpkss_utils_2.fn_derive_udf_display');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Clpks_cldaccnt_default_cluster');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_POST_DEFAULT_ACCOUNT(L_ACCOUNT_OBJ,
                                                                 P_SOURCE,
                                                                 P_SOURCE_OPERATION,
                                                                 P_FUNCTION_ID,
                                                                 P_ACTION_CODE,
                                                                 P_CLDACCNT,
                                                                 P_WRK_CLDACCNT,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAMS) THEN
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    DBG('Returning Success From  Fn_Default_Account..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_Default_Account..');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END;

  FUNCTION FN_DEFAULT_TD_LINKAGES(P_REC_ACC    IN OUT NOCOPY CLPKSS_OBJECT.TY_REC_ACCOUNT,
                                  P_TD_ACC     IN STTMS_CUST_ACCOUNT%ROWTYPE,
                                  P_ERRORCODE  IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                  P_ERRORPARAM IN OUT ERTBS_MSGS.MESSAGE%TYPE)
  
   RETURN BOOLEAN IS
    L_LNK_IDX     NUMBER;
    L_LNK_SEQ_NO  NUMBER := 0;
    L_NEXT_SEQ_NO NUMBER := 0;
  BEGIN
    DBG(' Inside function Fn_default_td_linkages ....');
  
    IF NOT CLPKS_CLDACCNT_DEFAULT.FN_SKIP_CUSTOM THEN
    
      DBG('Calling  clpks_cldaccnt_default_custom.Fn_Pre_Validate_Cust_Acno_Modify');
    
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CUSTOM.FN_PRE_DEFAULT_TD_LINKAGES(P_REC_ACC,
                                                                   P_TD_ACC,
                                                                   P_ERRORCODE,
                                                                   P_ERRORPARAM) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF NOT CLPKS_CLDACCNT_DEFAULT.FN_SKIP_CLUSTER THEN
      DBG('Calling  clpks_cldaccnt_default_cluster.Fn_Pre_Validate_Cust_Acno_Modify');
    
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_PRE_DEFAULT_TD_LINKAGES(P_REC_ACC,
                                                                    P_TD_ACC,
                                                                    P_ERRORCODE,
                                                                    P_ERRORPARAM) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF NOT CLPKS_CLDACCNT_DEFAULT.FN_SKIP_KERNEL THEN
    
      DBG('Linkages count-->' || P_REC_ACC.G_ACC_LINKAGES.COUNT);
      IF P_REC_ACC.G_ACC_LINKAGES.COUNT > 0 THEN
        FOR IDX IN P_REC_ACC.G_ACC_LINKAGES.FIRST .. P_REC_ACC.G_ACC_LINKAGES.LAST LOOP
          IF P_REC_ACC.G_ACC_LINKAGES(IDX)
           .ACC_LINKAGES_ROW.LINKAGE_TYPE = 'D' THEN
            L_LNK_SEQ_NO := P_REC_ACC.G_ACC_LINKAGES(IDX)
                            .ACC_LINKAGES_ROW.LINKAGE_SEQ_NO;
            IF NVL(P_REC_ACC.G_ACC_LINKAGES(IDX).G_ACTION, '*') = 'I' AND P_REC_ACC.G_ACC_LINKAGES(IDX)
              .ACC_LINKAGES_ROW.AMT_BLOCK_NO IS NULL AND P_REC_ACC.G_ACC_LINKAGES(IDX)
              .ACC_LINKAGES_ROW.LINKED_REF_NO = P_TD_ACC.CUST_AC_NO THEN
              P_REC_ACC.G_ACC_LINKAGES(IDX).ACC_LINKAGES_ROW.LINKAGE_AMOUNT := P_REC_ACC.ACCOUNT_DET.AMOUNT_FINANCED;
              RETURN TRUE;
            ELSIF NVL(P_REC_ACC.G_ACC_LINKAGES(IDX).G_ACTION, '*') = 'I' AND P_REC_ACC.G_ACC_LINKAGES(IDX)
                 .ACC_LINKAGES_ROW.AMT_BLOCK_NO IS NULL AND
                  (P_REC_ACC.G_ACC_LINKAGES(IDX)
                   .ACC_LINKAGES_ROW.LINKED_REF_NO <> P_TD_ACC.CUST_AC_NO OR
                    P_TD_ACC.CUST_AC_NO IS NULL) THEN
              P_REC_ACC.G_ACC_LINKAGES.DELETE(IDX);
            END IF;
          
          ELSE
            L_NEXT_SEQ_NO := P_REC_ACC.G_ACC_LINKAGES.COUNT + 1;
          
          END IF;
        END LOOP;
      END IF;
    
      IF L_NEXT_SEQ_NO > 0 AND L_LNK_SEQ_NO = 0 THEN
        L_LNK_SEQ_NO := L_NEXT_SEQ_NO;
      ELSIF L_LNK_SEQ_NO = 0 THEN
        L_LNK_SEQ_NO := 1;
      END IF;
    
      DBG('TD account number-->' || P_TD_ACC.CUST_AC_NO);
      IF P_TD_ACC.CUST_AC_NO IS NOT NULL THEN
        L_LNK_IDX := P_REC_ACC.G_ACC_LINKAGES.COUNT + 1;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.ACCOUNT_NUMBER := P_REC_ACC.ACCOUNT_DET.ACCOUNT_NUMBER;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.BRANCH_CODE := P_REC_ACC.ACCOUNT_DET.BRANCH_CODE;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKED_REF_NO := P_TD_ACC.CUST_AC_NO;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKAGE_TYPE := 'D';
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKED_PERCENT := 100;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.CUSTOMER_ID := P_REC_ACC.ACCOUNT_DET.CUSTOMER_ID;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKAGE_BRANCH := P_TD_ACC.BRANCH_CODE;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKED_CCY := P_TD_ACC.CCY;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKAGE_AMOUNT := P_REC_ACC.ACCOUNT_DET.AMOUNT_FINANCED;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.AMT_BLOCK_NO := NULL;
      
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.LINKAGE_SEQ_NO := L_LNK_SEQ_NO;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.CONVERTED_PAID_AMOUNT := 0;
      
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).ACC_LINKAGES_ROW.CONVERTED_LINKED_AMT := P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX)
                                                                                     .ACC_LINKAGES_ROW.LINKAGE_AMOUNT;
        P_REC_ACC.G_ACC_LINKAGES(L_LNK_IDX).G_ACTION := 'I';
      
      END IF;
    
    END IF;
    CLPKS_CLDACCNT_DEFAULT.PR_SET_ACTIVATE_KERNEL;
    IF NOT CLPKS_CLDACCNT_DEFAULT.FN_SKIP_CLUSTER THEN
    
      DBG('Calling  clpks_cldaccnt_default_cluster.Fn_post_default_td_linkages');
    
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CLUSTER.FN_POST_DEFAULT_TD_LINKAGES(P_REC_ACC,
                                                                     P_TD_ACC,
                                                                     P_ERRORCODE,
                                                                     P_ERRORPARAM) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF NOT CLPKS_CLDACCNT_DEFAULT.FN_SKIP_CUSTOM THEN
    
      DBG('Calling  clpks_cldaccnt_default_custom.Fn_post_default_td_linkages');
    
      IF NOT
          CLPKS_CLDACCNT_DEFAULT_CUSTOM.FN_POST_DEFAULT_TD_LINKAGES(P_REC_ACC,
                                                                    P_TD_ACC,
                                                                    P_ERRORCODE,
                                                                    P_ERRORPARAM) THEN
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('Returning Success From Fn_default_td_linkages');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others Of Fn_default_td_linkages ....');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERRORCODE  := 'ST-OTHR-001';
      P_ERRORPARAM := NULL;
      RETURN FALSE;
  END FN_DEFAULT_TD_LINKAGES;

END CLPKS_CLDACCNT_DEFAULT;
