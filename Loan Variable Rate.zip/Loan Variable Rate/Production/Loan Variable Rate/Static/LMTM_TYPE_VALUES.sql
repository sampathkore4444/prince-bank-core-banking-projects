insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('LOAN_VAR_DEF', '3.5', null);

COMMIT;