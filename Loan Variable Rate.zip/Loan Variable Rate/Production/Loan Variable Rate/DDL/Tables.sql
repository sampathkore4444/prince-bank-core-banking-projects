-- Create table
create table CLTB_ACCOUNT_RATETYPE_CUSTOM
(
  account_number     VARCHAR2(35) not null,
  branch_code        VARCHAR2(35) not null,
  effective_date     DATE not null,
  interest_rate_type CHAR(1) not null
)
/
alter table CLTB_ACCOUNT_RATETYPE_CUSTOM
  add primary key (ACCOUNT_NUMBER, BRANCH_CODE, EFFECTIVE_DATE, INTEREST_RATE_TYPE)
/
-- Create table
create table CLTB_ACCOUNT_RATETYPE_CUSTOM_HIST
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  effective_date      DATE,
  interest_rate_type  VARCHAR2(255),
  unique_seq_no       VARCHAR2(25)
)
/
