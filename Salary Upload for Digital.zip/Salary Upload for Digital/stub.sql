declare
p_payload_data clob;
p_upload_status char(1);
p_error_code varchar2(100);
p_error_msg varchar2(100);
begin
  -- Call the procedure
  global.pr_init('001','SAMPATH2');
  
  p_payload_data := '<XML>
  <BATCH_NO></BATCH_NO>
  <UPLOAD_DETAILS>
    <TXN_DETAILS>
      <PRODUCT_CODE>PRD1</PRODUCT_CODE>
      <EMPLOYER>
        <NAME>PEPSI CO LIMITED</NAME>
        <COMPANY_ID>12345</COMPANY_ID>
        <DEBIT_ACC>000012330</DEBIT_ACC>
        <DEBIT_CCY>USD</DEBIT_CCY>
        <DEBIT_AMT>1000</DEBIT_AMT>
      </EMPLOYER>
      <EMPLOYEES>
        <EMPLOYEE>
          <EMP_ID>0001</EMP_ID>
          <CREDIT_ACC>000003930</CREDIT_ACC>
          <CREDIT_CCY>KHR</CREDIT_CCY>
          <CREDIT_AMT>50000</CREDIT_AMT>
        </EMPLOYEE>
        <EMPLOYEE>
          <EMP_ID>0002</EMP_ID>
          <CREDIT_ACC>000002756</CREDIT_ACC>
          <CREDIT_CCY>USD</CREDIT_CCY>
          <CREDIT_AMT>20</CREDIT_AMT>
        </EMPLOYEE>
      </EMPLOYEES>
    </TXN_DETAILS>
    <CHARGE_DETAILS>
      <FEE_PRODUCT_CODE>CHD1</FEE_PRODUCT_CODE>
      <TOTOL_FEE_AMT>10</TOTOL_FEE_AMT>
      <FEE_CCY>USD</FEE_CCY>
    </CHARGE_DETAILS>
  </UPLOAD_DETAILS>
</XML>';

  ifpks_salary_utils_dig.pr_post_salary_batch_upload('B123',
                                                     'B123000000000000',
                                                     1,
                                                     'PEPSI',
                                                     'PEPSICOMP1',
                                                     '000012330',
                                                     'USD',
                                                     '1000',
                                                     p_payload_data,
                                                     '2',
                                                     p_upload_status,
                                                     p_error_code,
                                                     p_error_msg);
exception
  when others then
    dbms_output.put_line('error code='||sqlcode);
    dbms_output.put_line('error message='||sqlerrm);
    debug.pr_debug('AC','error code='||sqlcode);
     debug.pr_debug('AC','error message='||sqlerrm);
end;
