prompt Importing table ictm_sde...
set feedback off
set define off
insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ACCOUNT_LIMIT', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SUB-LIMIT AT ACCOUNT LEVEL', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ACCOUNT_TOD', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'TOD AT ACCOUNT LEVEL', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('AC_DORMANCY_DAYS', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Charge on account dormancy days', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('AC_DORMANT', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Account Dormant', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('APPLY_ZAKAT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Apply Zakat Charge', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('AVG_MON_BAL_PREV', 'O', 'V', 'N', 'P', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'Monthly average bal prev month', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BASIS', 'B', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SUDHA8', to_date('03-07-2000 15:09:56', 'dd-mm-yyyy hh24:mi:ss'), 'SUDHA8', to_date('03-07-2000 15:09:57', 'dd-mm-yyyy hh24:mi:ss'), 'SUB-LIMIT AT ACCOUNT LEVEL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BASIS1', 'B', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SUDHA8', to_date('03-07-2000 15:13:41', 'dd-mm-yyyy hh24:mi:ss'), 'SUDHA8', to_date('03-07-2000 15:13:41', 'dd-mm-yyyy hh24:mi:ss'), 'basis1', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BD_CR_CONTR_AMT', 'Z', 'B', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Booking Date CR Contribution Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BD_DR_CONTR_AMT', 'Z', 'B', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Booking Date DR Contribution Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BD_NET_CONTR_AMT', 'Z', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Booking Date Net Contribution Amt', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('BD_NET_POOL_BAL', 'N', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Booking Date Net Pool Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CHECK_TAX_CYCLE', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'TAX CYCLE CHECK REQUIRED', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CREDIT_BALANCE', 'B', 'V', 'C', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'RISHI3', to_date('03-10-2005', 'dd-mm-yyyy'), 'RISHI4', to_date('03-10-2005', 'dd-mm-yyyy'), 'monthly average val dated credit ba', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CR_COT_SEMI', 'T', 'B', 'C', 'S', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'TURNOVER ON CR TXNS-SEMI ANNUAL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CURRENT_BAL', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'CURRENT BALANCE AT END OF LIQUIDATI', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CURR_VD_BAL', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Current VD Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CUSTOMER_CREDIT_RATING', 'O', 'B', 'C', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:00', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:00', 'dd-mm-yyyy hh24:mi:ss'), 'Customer Credit Rating', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CUST_CR_RATING', 'O', 'B', 'C', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:00', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:00', 'dd-mm-yyyy hh24:mi:ss'), 'IL Compensated Contrib BD Cr Bal', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CUST_FATCA_CLASSFN', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA Customer Classification', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS', 'P', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAYS PERIOD', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FRMLAST_LIQ', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Last Liquidation Date for Penalty', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_0', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis Actual / 364', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_1', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 30-Euro / 360', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_2', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 30-US /360', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_3', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis Actual / 360', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_4', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 30-Euro / 365', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_5', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 30(US) / 365', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_6', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis Actual / 365', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_7', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 30-Euro / Actual', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_8', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty with interest basis 3(US) / Actual', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_FROM_START_9', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty withi interest basis Actual / Actual', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DEPOSIT_AMOUNT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DEPOSIT BALANCE', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DEP_AMT_INIT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'INITIAL DEPOSIT BALANCE', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DIRTFLG', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DIRT EXEMPT FLAG', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_BALANCE', 'B', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'VENKY1', to_date('10-03-2005', 'dd-mm-yyyy'), 'VENKY2', to_date('10-03-2005', 'dd-mm-yyyy'), 'for reg dd purposes', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_COT_QTLY', 'B', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'ABHIAU000', to_date('10-03-2005', 'dd-mm-yyyy'), 'ABHI000', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAILY TURNOVER', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_CR_BAL_M', 'B', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAILY CR BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_DR_BAL_M', 'B', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAILY DEBIT BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_NET_BAL_M', 'B', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAILY NET BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_NET_COT', 'T', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAILY NET TURNOVER', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DLY_NET_VD_BAL', 'B', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'ARUL2', to_date('10-03-2005', 'dd-mm-yyyy'), 'ARUL1', to_date('10-03-2005', 'dd-mm-yyyy'), 'Daily Net VD Balance', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DR_AVG_QTLY', 'B', 'B', 'D', 'Q', 'A', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'QUARTERLY DEBIT AVERAGE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DR_BAL_MAX_SEMI', 'B', 'V', 'D', 'S', 'X', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'MAX DEBIT BALANCE-SEMI ANNUAL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DR_CNT_QTLY', 'I', 'B', 'D', 'Q', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'SUM OF QUARTERLY DEBIT COUNT', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DR_COT_QTLY', 'T', 'V', 'D', 'Q', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'TURNOVER ON DR TXNS IN A QUATER', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DR_COT_SEMI', 'T', 'B', 'D', 'S', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'DR TURNOVER - SEMI ANNUAL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EEE', 'B', 'B', 'N', 'D', 'N', null, 'O', 'U', 'N', 1, 'ROHIT1', to_date('03-07-2000 20:14:08', 'dd-mm-yyyy hh24:mi:ss'), null, null, 'eeeeee', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EFF_LIMIT_AMOUNT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Effective Limit Amount For Line Accounts', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EFF_LINE_AMOUNT', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'CREDIT LIMIT INCLUSIVE OF LIMIT AMOUNT AND COLLATERAL CONTRIBUTION', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EFF_RATE', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Effective Rate for Penalty', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FATCA_CUST_TYPE', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA Customer Type', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FATCA_EXT_CUST', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA External Customer', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FATCA_GRANDFATHERED', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA Grandfathered', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FATCA_RECALCITRANT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA Recalcitrant', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FATCA_US_SOURCED', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA US Sourced', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('FULL_REDEM', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Full Redemtion Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_POST_LM_AL_BL', 'G', 'A', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Available Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_POST_LM_BD_BL', 'G', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Booking Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_POST_LM_VD_BL', 'G', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Value Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_PRE_LM_AL_BAL', 'H', 'A', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Available Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_PRE_LM_BD_BAL', 'H', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Booking Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('HD_PRE_LM_VD_BAL', 'H', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Value Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('IFCY', 'B', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'VINEETAU', to_date('03-07-2000 14:20:08', 'dd-mm-yyyy hh24:mi:ss'), 'VINEETAU', to_date('03-07-2000 14:20:22', 'dd-mm-yyyy hh24:mi:ss'), 'Daily Net VD Balance', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('IGA_DOMICILE', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'FATCA IGN Domicile', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_CP_CR_CONT', 'O', 'B', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Compensated Contrib BD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_CP_DR_CONT', 'O', 'B', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Compensated Contrib BD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_NCP_CR_CONT', 'O', 'B', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL NONCompensated Contrib BD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_NCP_DR_CONT', 'O', 'B', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL NONCompensated Contrib BD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_STL_CR_BAL', 'O', 'B', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Standalone BD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_STL_DR_BAL', 'O', 'B', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Standalone BD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_ULT_CR_BAL', 'O', 'B', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Ult Par/Pool Header BD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILBD_ULT_DR_BAL', 'O', 'B', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Ult Par/Pool Header BD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_CP_CR_CONT', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Compensated Contrib VD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_CP_DR_CON', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Compensated Contrib VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_CP_DR_CONT', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Compensated Contrib VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_CR_CONT', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Contrib VD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_DR_CONT', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Contrib VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_NCP_CR_CONT', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL NONCompensated Contrib VD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_NCP_DR_CONT', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL NONCompensated Contrib VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_STL_CR_BAL', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Standalone VD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_STL_DR_BAL', 'O', 'O', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Standalone VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_ULT_CR_BAL', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Ult Par/Pool Header VD Cr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ILVD_ULT_DR_BAL', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Ult Par/Pool Header VD Dr Bal', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('IL_CR_EFF_RATE', 'O', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Effective Cr rate', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('IL_DR_EFF_RATE', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('01-01-1998', 'dd-mm-yyyy'), 'IL Effective Dr rate', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('INTEREST_AMOUNT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'INTEREST AMOUNT', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('IS_CONSOL_CHGACC', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'OD APPLICABLE', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('LIMIT_AMOUNT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Limit Amount For Line Accounts', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('LINE_AMOUNT', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'CREDIT LIMIT INCLUSIVE OF UNCOLLECT', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('LIQ_PERIOD_DAYS', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'No of days in Liquidation Period', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MATURED_AMOUNT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Matured Amount For Line Accounts', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MIN1', 'B', 'V', 'C', 'M', 'A', 10, 'O', 'A', 'Y', 1, 'VINEETAU', to_date('03-07-2000 13:56:54', 'dd-mm-yyyy hh24:mi:ss'), 'VINEETAU', to_date('03-07-2000 13:57:14', 'dd-mm-yyyy hh24:mi:ss'), 'min1', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MIN9', 'B', 'V', 'C', 'M', 'A', 10, 'O', 'A', 'Y', 1, 'PAV1', to_date('03-07-2000 17:43:05', 'dd-mm-yyyy hh24:mi:ss'), 'PAV1', to_date('03-07-2000 17:43:13', 'dd-mm-yyyy hh24:mi:ss'), 'min1', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MIN_BAL_REQD', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'MIN BALANCE REQUIRED FOR A/C CLASS', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MIN_MON_BAL', 'B', 'V', 'C', 'M', 'M', 1, 'O', 'A', 'Y', 1, 'KRI2', to_date('10-03-2005', 'dd-mm-yyyy'), 'KRIT', to_date('10-03-2005', 'dd-mm-yyyy'), 'Minimum Monthly Credit Bal', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MONTH', 'P', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAYS IN THE MONTH', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVE_BALQ', 'B', 'V', 'C', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'BM4', to_date('03-07-2000 11:16:50', 'dd-mm-yyyy hh24:mi:ss'), 'BM4', to_date('03-07-2000 11:16:50', 'dd-mm-yyyy hh24:mi:ss'), 'monthaly average balence', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BAL', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'VENKY1', to_date('03-10-2005', 'dd-mm-yyyy'), 'VENKY2', to_date('03-10-2005', 'dd-mm-yyyy'), 'for reg dd purposes', 31, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BALQ', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'VENK000', to_date('03-10-2005', 'dd-mm-yyyy'), 'VENKAU000', to_date('03-10-2005', 'dd-mm-yyyy'), 'AVERAGE MONTHLY BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BALQ1', 'B', 'V', 'C', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'BM4', to_date('03-07-2000 15:41:15', 'dd-mm-yyyy hh24:mi:ss'), 'BM4', to_date('03-07-2000 15:41:16', 'dd-mm-yyyy hh24:mi:ss'), 'average monthly balance', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BAL_CONS', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'MON AVG BALANCE CONSOLIDATED', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BAL_M', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'GIRISH', to_date('03-10-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('03-10-2005', 'dd-mm-yyyy'), 'AVERAGE MONTHLY BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BAL_M1', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'GIRISH', to_date('03-10-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('03-10-2005', 'dd-mm-yyyy'), 'AVERAGE MONTHLY BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_BAL_M2', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'CHET000', to_date('10-03-2005', 'dd-mm-yyyy'), 'ARULAU001', to_date('10-03-2005', 'dd-mm-yyyy'), 'AVERAGE MONTHLY BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_AVG_ICBAL', 'A', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'KARTHIK', to_date('28-12-1999 12:47:20', 'dd-mm-yyyy hh24:mi:ss'), 'ARVIND', to_date('28-12-1999 12:48:18', 'dd-mm-yyyy hh24:mi:ss'), 'Average Monthly Balance', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_CNT', 'I', 'V', 'C', 'M', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'Montly Cr Txns count', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_MIN_BALM1', 'B', 'V', 'C', 'M', 'M', 1, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'MINIMUM CR BALANCE', 0, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_MIN_BALM2', 'B', 'V', 'C', 'M', 'M', 10, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'MINIMUM CR BALANCE-INDIAN WAY', 0, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_MIN_BALM3', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'KARTHIK', to_date('28-12-1999 12:33:47', 'dd-mm-yyyy hh24:mi:ss'), 'ARVIND', to_date('28-12-1999 12:35:01', 'dd-mm-yyyy hh24:mi:ss'), 'min cr balance-back dated', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_MIN_BALZ', 'B', 'V', 'C', 'M', 'M', 10, 'O', 'A', 'Y', 3, 'VENK000', to_date('10-03-2005', 'dd-mm-yyyy'), 'VENKAU000', to_date('10-03-2005', 'dd-mm-yyyy'), 'MON MIN CR BAL BET 10 & 30', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_CR_MIN_BAL_M', 'B', 'V', 'C', 'M', 'M', 1, 'O', 'A', 'Y', 1, 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'MINIMUM MONTHLY CR BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_DR_BAL', 'B', 'V', 'D', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'SRIK003', to_date('03-10-2005', 'dd-mm-yyyy'), 'MAX002', to_date('03-10-2005', 'dd-mm-yyyy'), 'MONTHLY DR BAL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_DR_CNT', 'I', 'V', 'D', 'M', 'S', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'Monthly Dr Txns Count', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_DR_MAX', 'B', 'V', 'D', 'M', 'X', 1, 'O', 'A', 'Y', 1, 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'SHIV01', to_date('10-03-2005', 'dd-mm-yyyy'), 'MONTHLY MAXIMUM DR BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_MIN_BAL', 'B', 'V', 'N', 'M', 'A', 10, 'O', 'A', 'Y', 1, 'SUNDAR', to_date('03-07-2000 14:55:29', 'dd-mm-yyyy hh24:mi:ss'), 'SUNDAR', to_date('03-07-2000 14:55:30', 'dd-mm-yyyy hh24:mi:ss'), 'Monthly Minimum bal', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MON_MIN_VD_BAL', 'B', 'V', 'C', 'M', 'A', 10, 'O', 'A', 'Y', 1, 'BM4', to_date('03-07-2000 17:20:56', 'dd-mm-yyyy hh24:mi:ss'), 'BM4', to_date('03-07-2000 17:20:56', 'dd-mm-yyyy hh24:mi:ss'), 'MINIMUM CR BALANCE-INDIAN WAY', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('MPN_AVG_BAL_M40', 'B', 'V', 'N', 'M', 'A', 1, 'O', 'A', 'Y', 1, 'SRIK000', to_date('10-03-2005', 'dd-mm-yyyy'), 'SRIKAU000', to_date('10-03-2005', 'dd-mm-yyyy'), 'AVERAGE MONTHLY BALANCE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OD_APPLICABLE', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('03-10-2005', 'dd-mm-yyyy'), 'OD APPLICABLE', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OD_BAL_TOD_LIMIT', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Available Balance For Overdraft Accounts', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OD_INTEREST_CALC', 'O', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SQA11', to_date('30-11-2007', 'dd-mm-yyyy'), 'SQA11', to_date('30-11-2007', 'dd-mm-yyyy'), 'overdraft interest', null, 'Y', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OD_INT_CALC_BD', 'O', 'B', 'D', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SQA11', to_date('30-11-2007', 'dd-mm-yyyy'), 'SQA11', to_date('30-11-2007', 'dd-mm-yyyy'), 'Overdraft interest Book Date', null, 'Y', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OD_MOV_TOD_LIMIT', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Movement Balance For Overdraft Accounts', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OLD_TAX_AMT', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'PREVIOUS TAX LIQUIDATED', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('OPENING_BAL', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'OPENING BALANCE AT END OF LIQUIDATI', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PENALTY_APPLY', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Penalty Flag', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PENALTY_BASIS', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Penalty Basis Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PENALTY_INT_RATE', 'B', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'DIVYA1', to_date('03-07-2000 14:50:29', 'dd-mm-yyyy hh24:mi:ss'), 'DIVYA1', to_date('03-07-2000 14:50:29', 'dd-mm-yyyy hh24:mi:ss'), 'penalty interest rate', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('POST_LM_AVL_BAL', 'S', 'A', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Available Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('POST_LM_BD_BAL', 'S', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Booking Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('POST_LM_VD_BAL', 'S', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Post LM Value Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_CLS', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Penalty Basis Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_CLS_ACCR', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Penalty Basis for Current Period', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_CLS_FACT', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DEPOSIT BALANCE', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_CLS_LIQ', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Penalty Basis for liquidated Period', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_LM_AVL_BAL', 'R', 'A', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Available Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_LM_BD_BAL', 'R', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Booking Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRE_LM_VD_BAL', 'R', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Pre LM Value Date Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('QTLY_NET_COT_AVG', 'T', 'V', 'N', 'Q', 'A', null, 'O', 'A', 'Y', 1, 'GIRISH', to_date('10-03-2005', 'dd-mm-yyyy'), 'GIRISHAU', to_date('10-03-2005', 'dd-mm-yyyy'), 'QUARTERLY NET TURNOVER AVERAGE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('RD_INSTALL_DUE', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'RD Installment Due', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('RD_OVERDUE_DAYS', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'RD Overdue Days', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('REDEM_AMT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'Redemption Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('REF_ACCEPT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'REFERRAL ACCEPT FLAG', null, 'Y', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('REF_REJECT', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'REFERRAL REJECT FLAG', null, 'Y', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('REPORTING_AMOUNT', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'CREDIT LINE REPORTING AMOUNT', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ROHIT', 'B', 'V', 'D', 'D', 'N', null, 'O', 'U', 'N', 1, 'ROHIT1', to_date('03-07-2000 20:02:23', 'dd-mm-yyyy hh24:mi:ss'), null, null, 'rohit sinha', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('SB_MONTHLY_BAL', 'B', 'V', 'C', 'M', 'M', 10, 'O', 'A', 'Y', 1, 'DESIKAN', to_date('10-03-2005', 'dd-mm-yyyy'), 'DESI', to_date('10-03-2005', 'dd-mm-yyyy'), 'SAVINGS A/C MINI BAL - FOR INT CAL', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('SD_INCOME', 'O', 'B', 'N', 'P', 'A', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('19-11-1998', 'dd-mm-yyyy'), 'SYSTEM', to_date('19-11-1998', 'dd-mm-yyyy'), 'SD income', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TAX_CYCLE_CLOSED', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'TAX CYCLE CLOSURE', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TAX_EXEMP_SDE', 'U', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SUR2', to_date('10-03-2005', 'dd-mm-yyyy'), 'SUR1', to_date('10-03-2005', 'dd-mm-yyyy'), 'exempt tax', null, 'Y', 'TE', null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TDS_AMOUNT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'TDS AMOUNT', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TENOR', 'O', 'B', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DEPOSIT TENOR', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TEST', 'B', 'V', 'D', 'D', 'N', null, 'O', 'U', 'N', 1, 'ROHIT1', to_date('03-07-2000 20:13:43', 'dd-mm-yyyy hh24:mi:ss'), null, null, 'rah', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TOT_INT_AMOUNT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'TOTAL INT AMOUNT', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('UTILIZATION', 'O', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Utilization For Line Accounts', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_CR_CONTR_AMT', 'Z', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Value Date CR Contribution Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_DLY_CR_BAL_M', 'B', 'V', 'C', 'D', 'N', null, 'O', 'A', 'Y', 1, 'OFSSCAMAK1', to_date('27-11-2007 17:53:01', 'dd-mm-yyyy hh24:mi:ss'), 'OFSSCAAUTH1', to_date('27-11-2007 19:37:31', 'dd-mm-yyyy hh24:mi:ss'), 'Value dated daily credit bal', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_DLY_DR_BAL_M', 'B', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'OFSSCAMAK1', to_date('27-11-2007 17:53:46', 'dd-mm-yyyy hh24:mi:ss'), 'OFSSCAAUTH1', to_date('27-11-2007 19:37:53', 'dd-mm-yyyy hh24:mi:ss'), 'Value dated daily debit bal', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_DR_CONTR_AMT', 'Z', 'V', 'D', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Value Date DR Contribution Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_NET_CONTR_AMT', 'Z', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Value Date Net Contribution Amount', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VD_NET_POOL_BAL', 'N', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Value Date Net Pool Balance', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('VIR_ACCT_COUNT', 'O', 'B', 'N', 'C', 'C', null, 'O', 'A', 'Y', 1, 'FLEXCUBE', to_date('01-04-2011', 'dd-mm-yyyy'), 'FLEXCUBE', to_date('01-04-2011', 'dd-mm-yyyy'), 'Virtual Account SDE', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('WAIVE_FULL_INT', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'waive interest', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('WAIVE_INTEREST', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'waive interest', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('WAIVE_PROFIT', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'waive profit', null, 'Y', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('YEAR', 'P', 'V', 'N', 'D', 'N', null, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'DAYS IN THE YEAR', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('DAYS_TILL_REDEEM', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('16-12-2016', 'dd-mm-yyyy'), 'SYSTEM', to_date('16-12-2016', 'dd-mm-yyyy'), 'Days From Interest Start Date for Penalty', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TRACK_DAYS', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SAMPATH1', to_date('16-12-2016', 'dd-mm-yyyy'), 'SAMPATH2', to_date('16-12-2016', 'dd-mm-yyyy'), 'TRACK DAYS TO CALCULATE PENALTY CORRECTLY', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TD_UPFRONT_AUTOROLLOVER_FLAG', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'FLAG TO CHECK AUTOROLLOVER FOR TAXN CALCULATION FOR TD UPFRONT ', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TD_UPFRONT_BOOK_FLAG', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'FLAG TO CHECK BOOKING FOR TAXN CALCULATION FOR TD UPFRONT ', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('TD_UPFRONT_PREMAT_FLAG', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'FLAG TO CHECK PRE MATURE FOR TAXN CALCULATION FOR TD UPFRONT ', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('COUNT_DAYS_OF_MONTH', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SAMPATH1', to_date('16-12-2016', 'dd-mm-yyyy'), 'SAMPATH2', to_date('16-12-2016', 'dd-mm-yyyy'), 'TRACK DAYS TO CALCULATE PENALTY CORRECTLY', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EACCOUNT_INT_RATE', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SAMPATH1', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'FLAG TO CHECK AUTOROLLOVER FOR TAXN CALCULATION FOR TD UPFRONT ', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EACCOUNT_KHQR_INT_RATE', 'O', 'V', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SAMPATH1', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('01-01-1998 10:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'FLAG TO CHECK KHQR INTEREST RATE', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CLEVER_SAVINGS_INT_DAYS', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('12-09-2023', 'dd-mm-yyyy'), 'SYSTEM', to_date('16-12-2016', 'dd-mm-yyyy'), 'TRACK DAYS TO CALCULATE PENALTY CORRECTLY', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('CLEVER_SAVINGS_TOPUP_AMT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('12-09-2023', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Top Up of all amounts done for the month', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRO_SAVINGS_TOPUP_AMT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('18-01-2024', 'dd-mm-yyyy'), 'SYSTEM', to_date('18-01-2024', 'dd-mm-yyyy'), 'Top Up of all amounts done for the month', null, 'N', null, 'N');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('ACC_NET_TOD', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'TOD AT ACCOUNT NETTING STRUCTURE LEVEL', null, 'N', null, null);

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('EFF_NET_LMT_AMT', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'CREDIT LIMIT AT ACCOUNT NETTING STRUCTURE LEVEL INCLUSIVE OF LIMIT AMOUNT AND COLLATERAL CONTRIBUTION', null, 'N', null, 'Y');

insert into ictm_sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('NET_LINE_AMT', 'O', 'B', 'N', 'D', 'N', 0, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'SYSTEM', to_date('19-04-2018', 'dd-mm-yyyy'), 'CREDIT LIMIT AT ACCOUNT NETTING STRUCTURE LEVEL', null, 'N', null, 'Y');

prompt Done.
