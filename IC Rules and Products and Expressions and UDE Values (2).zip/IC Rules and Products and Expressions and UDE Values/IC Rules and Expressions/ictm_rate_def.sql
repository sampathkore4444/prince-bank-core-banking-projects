prompt Importing table ictm_rate_def...
set feedback off
set define off
insert into ictm_rate_def (RATE_CODE, CCY_CODE, RECORD_STAT, ONCE_AUTH, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, BRANCH_CODE)
values ('TD_1_YR_RT', 'USD', 'O', 'Y', 'A', 3, 'SSOKPHENG', to_date('12-05-2024 23:51:25', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('12-05-2024 23:51:50', 'dd-mm-yyyy hh24:mi:ss'), 'ALL');

insert into ictm_rate_def (RATE_CODE, CCY_CODE, RECORD_STAT, ONCE_AUTH, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, BRANCH_CODE)
values ('TD_1_YR_RT', 'KHR', 'O', 'Y', 'A', 3, 'SSOKPHENG', to_date('12-05-2024 23:51:42', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('12-05-2024 23:51:59', 'dd-mm-yyyy hh24:mi:ss'), 'ALL');

prompt Done.
