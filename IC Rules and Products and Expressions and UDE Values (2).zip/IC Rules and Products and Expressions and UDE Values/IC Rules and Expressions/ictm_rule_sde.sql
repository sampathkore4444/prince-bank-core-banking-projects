prompt Importing table ictm_rule_sde...
set feedback off
set define off
insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CACM', 'MIN_MON_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBI', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBI', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBI', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBP', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBP', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIBP', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICN', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICN', 'DLY_NET_COT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICN', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICN', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICP', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICP', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CICP', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIDS', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIDS', 'DAYS_FROM_START');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIDS', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIDS', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIEB', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIEB', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIEB', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIES', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIES', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIES', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIET', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIET', 'DAYS_FROM_START');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIET', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIET', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISE', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISE', 'DLY_NET_COT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISE', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISE', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'DLY_NET_COT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'MON_DR_CNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'VD_DLY_CR_BAL_M');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CISP', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVN', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVN', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVN', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVS', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVS', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CIVS', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB1', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB1', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB1', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB1', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB3', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB3', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB3', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLB3', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE2', 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE2', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE2', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE2', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE2', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE3', 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE3', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE3', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE3', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLE3', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLR1', 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLR1', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLR1', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('CLR1', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCDN', 'AC_DORMANT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCDN', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCMN', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCUN', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCUN', 'EFF_LINE_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCUN', 'VD_DLY_DR_BAL_M');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DCUN', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVN', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVN', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVN', 'EFF_LINE_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVN', 'VD_DLY_DR_BAL_M');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVN', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVR', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVR', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVR', 'EFF_LINE_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVR', 'VD_DLY_DR_BAL_M');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('DIVR', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA01', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA01', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA01', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'COUNT_DAYS_OF_MONTH');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'EACCOUNT_INT_RATE');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'EACCOUNT_KHQR_INT_RATE');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'MONTH');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'MON_AVG_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'MON_AVG_BAL_M');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('EA02', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('MA01', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('MA01', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('MA01', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PR01', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PR01', 'DLY_NET_VD_BAL');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PR01', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS01', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS01', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS01', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS01', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS03', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS03', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS03', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS03', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS05', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS05', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS05', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS05', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS07', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS07', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS07', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS07', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS09', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS09', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS09', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS09', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS11', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS11', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS11', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS11', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS13', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS13', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS13', 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('PS13', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'DAYS_TILL_REDEEM');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'PENALTY_APPLY');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'PENALTY_BASIS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'TENOR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDFI', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'DAYS_FROM_START');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'DAYS_TILL_REDEEM');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'PENALTY_APPLY');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'PENALTY_BASIS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'TD_UPFRONT_AUTOROLLOVER_FLAG');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'TD_UPFRONT_BOOK_FLAG');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'TD_UPFRONT_PREMAT_FLAG');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'TENOR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'TRACK_DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDIS', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'DAYS_FROM_START');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'DAYS_TILL_REDEEM');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'PENALTY_APPLY');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'PENALTY_BASIS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'TENOR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'TRACK_DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTB', 'YEAR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'DAYS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'DAYS_FROM_START');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'DEPOSIT_AMOUNT');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'PENALTY_APPLY');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'PENALTY_BASIS');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'TENOR');

insert into ictm_rule_sde (RULE_ID, SDE_ID)
values ('TDTD', 'YEAR');

prompt Done.
