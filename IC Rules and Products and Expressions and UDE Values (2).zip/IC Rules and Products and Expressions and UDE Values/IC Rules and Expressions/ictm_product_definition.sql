prompt Importing table ictm_product_definition...
set feedback off
set define off
insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDIM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDOM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDMN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLNC', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TSCM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDCN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLCM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLRM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TSCC', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLCC', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLRC', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TLNM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDDD', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDDN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIVN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CINN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIVS', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CISN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DIVN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIDS', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CISP', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DCUN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DCMN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DCDN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CACM', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CA07', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIEO', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CISB', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIBS', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIBB', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TCSM', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TCLN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PR01', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CLB4', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CA04', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CA06', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIKN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DINR', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DIIR', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDSR', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDSN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDLN', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TCSR', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TCLR', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS02', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS04', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS09', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS11', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS12', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CLB1', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CLB2', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CLB3', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIER', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CISR', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIED', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIBN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIBR', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CIBP', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('EA01', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('SY01', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('RY02', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS01', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS03', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS07', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS10', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS13', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS14', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('CA05', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDBO', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDFO', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('DINN', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('TDLR', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('EA02', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PR02', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('SY02', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('GY01', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('GY02', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('RY01', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('MA01', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('MA02', 'I', 'Y', 'N', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS05', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS06', 'I', 'Y', 'Y', 'I', 'N', 'N');

insert into ictm_product_definition (PRODUCT_CODE, PRODUCT_TYPE, OK, DEP, BOOK_ACC_TYPE, TAX, BILLING_LIQD)
values ('PS08', 'I', 'Y', 'Y', 'I', 'N', 'N');

prompt Done.
