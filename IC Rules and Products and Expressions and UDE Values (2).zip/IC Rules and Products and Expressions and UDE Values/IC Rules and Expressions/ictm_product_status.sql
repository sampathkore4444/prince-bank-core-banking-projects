prompt Importing table ictm_product_status...
set feedback off
set define off
insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIVN', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIVN', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIVN', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIVN', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCUN', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCUN', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCUN', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCUN', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCMN', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCMN', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCMN', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCMN', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCDN', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCDN', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCDN', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DCDN', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('CACM', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('CACM', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('CACM', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('CACM', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINR', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINR', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINR', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINR', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIIR', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIIR', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIIR', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DIIR', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINN', 'DOUB', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINN', 'LOSS', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINN', 'SPME', '111', 'N', 'N', 'N', null, null, null, 'N');

insert into ictm_product_status (PRODUCT_CODE, STATUS, TRN_CODE, STOP_IC, REVERSE_ACCRUAL, CAP_REVR_INC, CAP_REVR_INC_DAYS, UNIT, TENOR_OPTION, PRIN_MOV_BADGL)
values ('DINN', 'SUBS', '111', 'N', 'N', 'N', null, null, null, 'N');

prompt Done.
