prompt Importing table ictm_rule_ude...
set feedback off
set define off
insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_4', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_5', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'INTEREST_RATE_6', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'SLAB_5', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIDS', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISP', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISP', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISP', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISP', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISP', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVN', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVN', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'INTEREST_RATE_4', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'INTEREST_RATE_5', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIVS', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DCDN', 'DORM_CHG_AMT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DCMN', 'CHG_AMT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DCMN', 'MIN_BAL', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DCUN', 'UNUTIL_CHG_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'DR_INT_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'DR_INT_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'DR_INT_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'INT_RATE_12M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'INT_RATE_1M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'INT_RATE_3M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'INT_RATE_6M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'INT_RATE_A1Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'PENALTY_PERCENT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SAVINGS_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_1M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_3M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_6M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_5', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'PENALTY_PERCENT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SAVINGS_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'SLAB_5', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTD', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICN', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICN', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICN', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICN', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CACM', 'CHG_AMT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CACM', 'MIN_BAL', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBP', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVR', 'DR_INT_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_1M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_1Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_2Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_3M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_3Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_4Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_5Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_6M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'INT_RATE_9M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'PENALTY_PERCENT', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SAVINGS_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_5', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_6', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_7', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_8', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'SLAB_9', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDIS', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA01', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA01', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB1', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB1', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB1', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB3', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB3', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLB3', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBI', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBI', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBI', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBI', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIBI', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'INTEREST_RATE_2Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'SLAB_1', 'N', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TOPUP_EXTRA_RAT2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE2', 'TOPUP_EXTRA_RAT3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS01', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS01', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS01', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS05', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS05', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS05', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS09', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS09', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS09', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS11', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS11', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS11', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'INTEREST_RATE_4', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'INTEREST_RATE_5', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CICP', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIES', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIES', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIES', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIES', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVR', 'DR_INT_RATE_PEN', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('DIVN', 'DR_INT_RATE_PEN', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_1Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_2Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_1', 'N', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_2', 'N', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'SLAB_3', 'N', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLE3', 'TOPUP_EXTRA_RAT3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'INTEREST_RATE_3Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CLR1', 'TOPUP_EXTRA_RAT3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS03', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS03', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS03', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS07', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS07', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS07', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS13', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS13', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PS13', 'TOPUP_EXTRA_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_1Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_2Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_3Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_4Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_5Y', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'INT_RATE_9M', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_6', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_7', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_8', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDTB', 'SLAB_9', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIEB', 'INTEREST_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIEB', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_4', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_5', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'INTEREST_RATE_6', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'SLAB_4', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'SLAB_5', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CIET', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISE', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISE', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISE', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('CISE', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('TDFI', 'INT_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'EACC_MON_AVG_BAL', 'N', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'INT_EACC_KHQR', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'INT_EACC_MAVG', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'INT_EACC_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('EA02', 'INT_EACC_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'INTEREST_RATE_2', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'SLAB_1', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'TAX_RATE', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'INTEREST_RATE_3', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'INTEREST_RATE_4', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'SLAB_2', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('PR01', 'SLAB_3', 'A', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('MA01', 'INTEREST_RATE_1', 'R', 'N');

insert into ictm_rule_ude (RULE_ID, UDE_ID, UDE_TYPE, GET_LATEST)
values ('MA01', 'TAX_RATE', 'R', 'N');

prompt Done.
