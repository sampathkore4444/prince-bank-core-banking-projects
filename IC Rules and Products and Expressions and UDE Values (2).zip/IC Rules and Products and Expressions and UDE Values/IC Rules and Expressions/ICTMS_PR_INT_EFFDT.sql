prompt Importing table p1fchprfm.ICTMS_PR_INT_EFFDT...
set feedback off
set define off
insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:45', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:06', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:39', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:59', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:56', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:32', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:05', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:52', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:28', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:18', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:48', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:24', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:24', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:45', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:20', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:33', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:42', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:16', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:41', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:37', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:11', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:46', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:34', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:06', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:11:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:11:52', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:29', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:15:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:15:56', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:04', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:24', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:15:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:15:47', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:06:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:06:23', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:06:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:06:31', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('19-03-2018 20:07:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:07:42', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('19-03-2018 20:07:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:07:34', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:52', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:02', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'ST10', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'KVANNROATH', 'PROFINCH02', to_date('27-07-2018 09:37:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:08:13', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'ST10', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:06:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:06:07', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'SA02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:05:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:05:34', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'SA02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:05:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:05:41', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:36', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIVN', 'BI01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:52:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:52:30', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIVN', 'BI01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:51:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:51:10', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVS', 'SA03', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:59:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:59:15', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVS', 'SA03', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:58:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:58:16', 'dd-mm-yyyy hh24:mi:ss'), 11, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVS', 'BI02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:56:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:56:48', 'dd-mm-yyyy hh24:mi:ss'), 14, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVS', 'BI02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 09:55:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 09:55:07', 'dd-mm-yyyy hh24:mi:ss'), 12, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISN', 'SA04', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:02:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:02:45', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISN', 'SA04', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:01:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:01:21', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIDS', 'SA05', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:04:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:04:11', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIDS', 'SA05', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:05:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:05:07', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISP', 'SA07', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:06:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:06:36', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISP', 'SA07', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:06:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:06:20', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:12:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:12:23', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:10:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:10:20', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:16:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:16:44', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:21:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:21:09', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:25:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:25:00', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:28:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:28:26', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:32:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:32:46', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDDD', 'TD13', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:24:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:24:43', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:35:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:35:45', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:38:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:38:35', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDDN', 'TD16', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:18:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:18:07', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:40:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:40:42', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:43:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:43:50', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:46:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:46:14', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:48:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:48:32', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:15:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:15:08', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:18:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:18:31', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:23:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:23:28', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:26:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:26:59', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:31:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:31:19', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDDD', 'TD13', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:17:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:17:57', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:34:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:34:31', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:37:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:37:17', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDDN', 'TD16', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:18:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:18:14', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:39:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:39:58', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:41:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:41:59', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:45:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:45:19', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 10:47:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 10:47:38', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:20', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:16', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:15:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:15:38', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:26', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:21', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:15:41', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:32', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:15', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:48', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC08', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:10:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:10:39', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'FC09', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:10', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CINN', 'FC09', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:45', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:06', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:15', 'dd-mm-yyyy hh24:mi:ss'), 11, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:19', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:24', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:28', 'dd-mm-yyyy hh24:mi:ss'), 10, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:47', 'dd-mm-yyyy hh24:mi:ss'), 10, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:53', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:07:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:07:59', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:05', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:11', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:17', 'dd-mm-yyyy hh24:mi:ss'), 10, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:22', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:31', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:36', 'dd-mm-yyyy hh24:mi:ss'), 10, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:40', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:45', 'dd-mm-yyyy hh24:mi:ss'), 10, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:49', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:54', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:08:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:08:59', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:04', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:09', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:14', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:23', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:29', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:35', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:40', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:46', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:54', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:09:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:09:58', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:03', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:53', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:01', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:05', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:09', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:13', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:19', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:23', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:27', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:31', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:35', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:41', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:13:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:13:48', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:01', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:06', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:11', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:17', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:25', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:29', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:33', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:39', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:44', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:48', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:14:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:14:53', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:31', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:05', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:13', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:21', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:26', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:46', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:50', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:54', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:59', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:06', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:09', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:13', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:20', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:26', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:29', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:32', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:35', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:40', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:46', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:18:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:18:00', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:27', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:20:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:20:22', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:35', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:39', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:46', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:49', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:53', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:56', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:59', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:20:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:20:08', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:20:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:20:12', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:20:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:20:15', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:20:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:20:19', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:31', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:27', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:37', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:45', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:51', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:30', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:54', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:59', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:03', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:06', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:10', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:14', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:20', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:24', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:27', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:30', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:18', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'CAD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:15', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'CHF', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:10', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'CNH', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:05', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'CNY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:02', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'GBP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:59', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'HKD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:16:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:16:56', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'JPY', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:22', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'MYR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:53', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'NZD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:49', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'PHP', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:44', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'SGD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:40', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'THB', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:33', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'TWD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:30', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC09', 'VND', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:17:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:17:26', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC08', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:12:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:12:18', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC03', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:07', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'FC04', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:11', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:16', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:22', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:27', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:32', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA03', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'KVANNROATH', 'KPISETH', to_date('27-07-2018 13:44:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 14:04:55', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA03', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'KVANNROATH', 'KPISETH', to_date('27-07-2018 13:44:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 14:04:45', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA04', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:10:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:10:57', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA04', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:01', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA05', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:07', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA05', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:12', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA06', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:24', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA06', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:29', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA07', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:33', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA07', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:39', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'ST10', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:46', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'ST10', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:50', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:11:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:11:55', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:12', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:18', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:23', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:35', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:41', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:15:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:15:55', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:00', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:03', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:08', 'dd-mm-yyyy hh24:mi:ss'), 8, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA03', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:16', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA03', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:20', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA05', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:25', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA05', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:29', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:14:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:14:02', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC09', 'EUR', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:19:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:19:42', 'dd-mm-yyyy hh24:mi:ss'), 9, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:34', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:39', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI02', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:44', 'dd-mm-yyyy hh24:mi:ss'), 7, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI02', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:51', 'dd-mm-yyyy hh24:mi:ss'), 6, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC08', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'PROFINCH03', 'PROFINCH03', to_date('19-03-2018 20:13:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-03-2018 20:13:42', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'AUD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:16:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:16:56', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BI01', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:17:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:17:04', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BI01', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:17:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:17:00', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA04', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:48', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA04', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:12:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:12:40', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'KVANNROATH', 'KPISETH', to_date('27-07-2018 13:50:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 14:04:37', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'KVANNROATH', 'KPISETH', to_date('27-07-2018 13:50:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 14:04:02', 'dd-mm-yyyy hh24:mi:ss'), 4, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA06', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:06:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:06:35', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIVN', 'SA06', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'PROFINCH02', 'PROFINCH02', to_date('27-07-2018 13:06:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-07-2018 13:06:18', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TDST', 'KHR', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'KPISETH', to_date('10-09-2018 18:46:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-09-2018 18:47:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TDST', 'USD', to_date('01-01-2001', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'KPISETH', to_date('10-09-2018 18:46:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-09-2018 18:48:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'USD', to_date('01-05-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('07-05-2019 18:09:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('07-05-2019 18:12:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'USD', to_date('01-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:11:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:06:45', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA04', 'CA04', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:40:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 14:58:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA04', 'CA04', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:41:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 14:59:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:01:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:08:45', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:00:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:08:35', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA06', 'CA06', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:49:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 15:01:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA06', 'CA06', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:51:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 15:04:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:52:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 15:04:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 14:53:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 15:05:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA04', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 17:40:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 17:44:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA04', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 17:41:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 17:44:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA06', 'KHR', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 17:42:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 17:45:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA06', 'USD', to_date('08-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'CMAKARA', to_date('08-08-2019 17:43:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-08-2019 17:45:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 16:54:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 17:58:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:02:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:06:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:02:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:07:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:02:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:09:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:02:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:20:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:14', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:13:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:14:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:48', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:15:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:04:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TDST', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:16:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:04:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:24:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 17:57:52', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:25:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 17:58:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:26:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:27:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:28:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:29:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:02:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:30:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:02:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:31:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:33:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:34:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:35:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:03:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:37:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:04:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TDST', 'USD', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:38:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:04:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA07', 'CA07', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 16:57:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 17:07:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'THB', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:25:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:00:43', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'TWD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:25:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:01:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'VND', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:27:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:01:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'AUD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:29:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:51:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CAD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:29:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:51:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CNH', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:30:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:52:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'EUR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:32:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:52:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'VND', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:39:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:53:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI01', 'KHR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:42:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:49:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'ST11', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:39:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:46:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'ST11', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:39:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:48:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'ST11', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:41:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:45:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'ST11', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:42:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:45:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'SA09', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:43:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:55:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'SA09', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:44:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:55:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA09', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:45:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:54:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA09', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:45:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:54:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIKN', 'SA08', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:49:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:58:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIKN', 'SA08', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:51:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:59:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA08', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:52:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:56:46', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA08', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:53:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 19:55:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISR', 'SA10', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:54:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 20:05:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISR', 'SA10', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:55:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 20:05:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:00:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:12:01', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:00:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:11:53', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA10', 'KHR', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:58:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 20:04:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'SA10', 'USD', to_date('02-12-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('02-12-2019 19:59:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-12-2019 20:04:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:07:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:13:37', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:07:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:13:27', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:08:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:15:04', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 18:59:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:06:46', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 14:59:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:16:15', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 14:59:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:16:03', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:08:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:17:40', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:08:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:17:17', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'AUD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:43:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:48:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'CAD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:44:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:49:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'CNY', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:44:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:49:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'EUR', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:45:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:51:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'GBP', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:45:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:51:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'HKD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:46:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:51:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'JPY', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:46:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:51:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'MYR', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:47:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:52:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'NZD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:48:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:52:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'SGD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:48:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:52:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'THB', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:49:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:52:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'TWD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:36:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:53:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC03', 'VND', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 16:38:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 16:53:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:08:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:15:16', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 19:01:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:06:53', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'KHR', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 19:03:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:07:13', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'USD', to_date('13-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 19:03:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:07:24', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'AUD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:06:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:15:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'CAD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:07:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:15:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'CNY', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:08:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:15:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'EUR', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:08:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:15:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'GBP', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:09:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:16:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'HKD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:09:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:16:43', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'JPY', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:10:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:17:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'MYR', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:11:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:17:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'NZD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:11:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:18:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'SGD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:12:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:19:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'THB', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:13:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:19:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'KHR', to_date('01-05-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('07-05-2019 18:07:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('07-05-2019 18:11:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA07', 'KHR', to_date('01-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:11:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:07:20', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 16:57:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 17:58:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:03:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'KHR', to_date('19-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('19-08-2019 17:04:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-08-2019 18:01:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA05', 'CA05', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 16:56:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 17:06:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA05', 'CA05', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 16:57:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 17:06:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CA07', 'CA07', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 16:58:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 17:07:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:02:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:18:40', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA05', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:01:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:05:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:02:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:18:48', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA05', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:02:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:06:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:02:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:06:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA07', 'KHR', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:02:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:06:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:03:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:07:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA07', 'USD', to_date('20-08-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CLAYHOUT', 'YRAROTH', to_date('20-08-2019 18:03:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-08-2019 18:07:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'USD', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:01:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:09:05', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'KHR', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:01:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:08:52', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'USD', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:02:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:19:00', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'KHR', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-07-2020 15:02:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-07-2020 15:19:11', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'USD', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:39:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:03', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'KHR', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:40:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:10', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'USD', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:39:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:16', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'KHR', to_date('16-08-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:39:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:22', 'dd-mm-yyyy hh24:mi:ss'), 5, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:09:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:13:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:19:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:26:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:33:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:36:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:41:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:52', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:45:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:19:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:48:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:53:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:56:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 18:59:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:07:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:12:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:50', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:14:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:20:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:18:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:21:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:21:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:21:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:23:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:21:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:33:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:21:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:36:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:22:05', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:41:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:22:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:10:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:22:22', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:48:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:22:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('13-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 19:51:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:22:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:25:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:27:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:29:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:30:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:31:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:00', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:31:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:33:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:33:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:05', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:34:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:35:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:36:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('16-09-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:36:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:54:46', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:43:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:46', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:43:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:55:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:44:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:45:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:46:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:46:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:47:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:48:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:49:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:50:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:56:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:51:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:57:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('01-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CMAKARA', to_date('13-09-2019 20:52:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2019 20:57:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA03', 'KHR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:05:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:02:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA03', 'USD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:05:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:03:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA04', 'KHR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:08:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:04:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'SA04', 'USD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:08:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:05:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'AUD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:19:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:02:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CAD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:19:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:03:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CHF', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:20:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:04:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CNH', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:20:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:05:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'CNY', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:21:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:05:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'EUR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:21:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:06:48', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'GBP', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:22:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:07:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'HKD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:22:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:07:43', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'JPY', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'CHOUNGLINY', to_date('25-10-2019 18:23:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:08:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'MYR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:23:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:10:00', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'NZD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:24:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:09:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'PHP', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:24:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:08:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC03', 'SGD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:25:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 19:08:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CHF', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:29:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:53:43', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'CNY', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:30:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:54:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'GBP', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:32:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:55:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'HKD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:33:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:55:35', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'JPY', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:33:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:56:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'MYR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:34:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:56:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'NZD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:35:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:57:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'PHP', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:35:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:57:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'SGD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:35:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:58:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'THB', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:36:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:59:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'FC04', 'TWD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:36:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:59:35', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI01', 'USD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:43:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:49:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI02', 'KHR', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:43:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:45:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'BI02', 'USD', to_date('25-10-2019', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'YRAROTH', 'SROURN', to_date('25-10-2019 18:46:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-10-2019 18:47:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:44:17', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:44:48', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:44:35', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:06:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:06:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:48:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:09:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:48:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:09:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:51:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:09:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:53:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:10:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:59:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:11:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:01:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:13:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:01:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:12:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BO01', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:55:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BO01', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:55:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BO02', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:56:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BO02', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:57:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINR', 'BO01', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:58:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINR', 'BO01', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:58:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:52', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINN', 'BO02', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:59:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:08:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINN', 'BO02', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:59:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:09:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:48:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:12:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD34', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 17:04:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:34:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSN', 'TD43', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:49:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:50:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCSM', 'TD51', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:14:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:14:32', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCSM', 'TD51', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:54:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:54:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS04', 'PS04', 'USD', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:21:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:24:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB2', 'CLB2', 'KHR', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:29:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:34:08', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB3', 'CLB3', 'KHR', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:30:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:34:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB3', 'CLB3', 'USD', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:31:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:34:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB4', 'CLB4', 'KHR', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:32:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:34:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'TWD', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:14:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:19:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'FC04', 'VND', to_date('13-08-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:14:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:19:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'SA02', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:17:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:20:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'SA02', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:17:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:21:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'HKD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:39:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'JPY', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:39:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:59', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'MYR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:40:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'NZD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:40:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'SGD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:41:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'THB', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:41:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'TWD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:41:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'VND', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:42:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:47:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIED', 'SA05', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:45:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:51:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIED', 'SA05', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:46:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:50:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISB', 'SA07', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:47:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:52:48', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CISB', 'SA07', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:48:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:52:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'SA03', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:49:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:55:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'SA03', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:50:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:55:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:50:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:57:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:51:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:57:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'SA04', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:55:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 18:02:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'SA04', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:54:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 18:01:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBB', 'BI02', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:58:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 18:00:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBB', 'BI02', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:59:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 18:00:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 17:26:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 18:41:45', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:53:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA08', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:55:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:06:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA09', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:55:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:04:52', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI03', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:06:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:04:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BI03', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:06:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:05:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BP01', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:08:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:05:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BP02', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:08:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:05:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BP02', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:09:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:05:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:10:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:03:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:15:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:32:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:17:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:35:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:22:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:52:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:25:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:16:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:27:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:18:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:46:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:01:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:48:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:41:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:29:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:03:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:30:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 15:59:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:32:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:09:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:32:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:12:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:34:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:18:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:36:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:20:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 09:54:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:05:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:46:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:12:19', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:46:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:12:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:58:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:06:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:59:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:06:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD27', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:26:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:12:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 16:59:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:02:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:01:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:03:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:14:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:06:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:15:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:06:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:20:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:14:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:21:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:14:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD27', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:26:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:17:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD28', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:27:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:18:43', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD28', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:28:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:19:00', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD30', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:33:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:26:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD30', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:33:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:26:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'CA06', 'USD', to_date('25-11-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-11-2022 23:52:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-11-2022 23:58:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY02', 'SY02', 'KHR', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:49:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 00:59:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY01', 'GY01', 'USD', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:58:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:02:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY01', 'RY01', 'KHR', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:01:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:08:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY01', 'RY01', 'USD', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:02:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:07:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY02', 'RY02', 'KHR', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:03:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:10:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'MA01', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:50:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:53:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'KHR', to_date('02-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('02-01-2024 17:25:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-01-2024 17:32:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'KHR', to_date('02-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('02-01-2024 17:28:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-01-2024 17:32:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB1', 'CLB1', 'KHR', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:27:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:33:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB1', 'CLB1', 'USD', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:28:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:32:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB2', 'CLB2', 'USD', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:30:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:33:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CLB4', 'CLB4', 'USD', to_date('03-06-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('03-06-2024 22:32:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-06-2024 22:34:48', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:08:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:11:39', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBR', 'BP01', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:32:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:06:05', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBR', 'BP01', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:33:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:06:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBP', 'BP02', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:34:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:06:35', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBP', 'BP02', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:34:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:06:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:36', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:32:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:07:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:38:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:07:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:43:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:09:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:44:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:08:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'KHR', to_date('16-10-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-10-2020 17:27:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-10-2020 17:37:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA08', 'KHR', to_date('16-10-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-10-2020 17:29:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-10-2020 17:37:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 17:59:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:30:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 18:01:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:31:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 18:01:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:31:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLN', 'TD44', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:16:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:28:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLN', 'TD48', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:07:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:08:19', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLN', 'TD44', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:27:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:28:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PR01', 'PR01', 'KHR', to_date('30-06-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('30-06-2023 22:42:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2023 22:50:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY02', 'SY02', 'USD', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:47:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 00:58:33', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY01', 'SY01', 'USD', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:48:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 00:53:50', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY01', 'GY01', 'KHR', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:54:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:04:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY02', 'GY02', 'KHR', to_date('13-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:00:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:06:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('GY02', 'GY02', 'USD', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:00:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:05:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'USD', to_date('02-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('02-01-2024 17:27:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-01-2024 17:31:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS02', 'PS02', 'USD', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:11:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:22:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS03', 'PS03', 'KHR', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:14:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:23:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS06', 'PS06', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:50:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:35:46', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS08', 'PS08', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:51:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:44:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'PR02', 'KHR', to_date('18-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CMAKARA', to_date('17-03-2020 18:04:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-03-2020 18:07:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'PR01', 'USD', to_date('18-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CMAKARA', to_date('17-03-2020 18:05:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-03-2020 18:07:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'PR02', 'USD', to_date('18-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CMAKARA', to_date('17-03-2020 18:05:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-03-2020 18:07:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BP01', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('15-04-2020 16:07:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-04-2020 17:07:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:08:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:11:47', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:47:19', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:44:56', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:06', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:29', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:54:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:10:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:59:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:12:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:02:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:13:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:03:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:13:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'BO02', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:56:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:09:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BO01', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:56:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:09:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BO02', 'KHR', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:57:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:09:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'BO01', 'USD', to_date('03-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('02-09-2020 16:57:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-09-2020 17:09:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'KHR', to_date('16-10-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-10-2020 17:28:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-10-2020 17:37:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:55:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:11:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:55:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:12:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('30-06-2021 18:18:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2021 18:22:33', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:57:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:06:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD28', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:39:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:18:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD30', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:45:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:24:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD31', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:50:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:27:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD33', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:56:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:33:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSN', 'TD43', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:34:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:44:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('EA02', 'EA02', 'USD', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 03:43:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 03:57:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('EA02', 'EA02', 'KHR', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 03:44:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 03:57:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'EA02', 'USD', to_date('01-03-2024', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 04:02:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 04:03:49', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'EA02', 'KHR', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 03:49:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 03:59:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PR01', 'PR01', 'USD', to_date('30-06-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('30-06-2023 22:45:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2023 22:51:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PR02', 'PR02', 'KHR', to_date('30-06-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('30-06-2023 22:47:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2023 22:52:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PR02', 'PR02', 'USD', to_date('30-06-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('30-06-2023 22:48:09', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2023 22:52:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('SY01', 'SY01', 'KHR', to_date('14-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 00:45:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 00:55:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'MA01', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:38:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:40:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'MA01', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:47:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:52:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'PR01', 'KHR', to_date('18-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CMAKARA', to_date('17-03-2020 18:04:03', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-03-2020 18:07:41', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:09:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:11:55', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:09:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:12:02', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:11:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:05:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:20:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:49:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:55:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:25:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD11', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:57:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:28:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:26:43', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 15:45:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD01', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:28:13', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 15:48:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'KHR', to_date('22-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:10:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:12:11', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:07:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:06:53', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'USD', to_date('22-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:10:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:12:20', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:30:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:48:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:31:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:52:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:32:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:49:46', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:05:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:09:46', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD15', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:05:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:10:28', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:05:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:13:27', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:14:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:07:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:31:48', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:07:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:41:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:08:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:50:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:10:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:56:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:11:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:56:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:10:51', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA09', 'KHR', to_date('16-10-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-10-2020 17:30:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-10-2020 17:37:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'PR01', 'KHR', to_date('05-11-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('04-11-2020 17:01:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('04-11-2020 17:11:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'ST10', 'USD', to_date('01-04-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-04-2021 07:35:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-04-2021 07:37:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'ST11', 'USD', to_date('01-04-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-04-2021 07:35:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-04-2021 07:37:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'ST11', 'KHR', to_date('01-04-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-04-2021 07:36:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-04-2021 07:37:27', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'EA01', 'KHR', to_date('09-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('09-06-2021 15:28:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('09-06-2021 15:34:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'EA01', 'USD', to_date('09-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('09-06-2021 15:28:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('09-06-2021 15:34:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIVN', 'BI01', 'KHR', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:24:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:35:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD27', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:31:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:10:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRM', 'TD31', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:49:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:27:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNC', 'TD34', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:59:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:35:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSR', 'TD41', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:12:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:26:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSR', 'TD41', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:19:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:29:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSR', 'TD45', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:23:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:33:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSN', 'TD47', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:42:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:00:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSN', 'TD47', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:04:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:05:01', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLR', 'TD42', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:52:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:06:44', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:28:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:46:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'USD', to_date('01-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:38:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'KHR', to_date('01-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:38:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD12', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:32:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:49:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('01-05-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('29-04-2020 17:33:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-04-2020 17:53:24', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:05:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:08:02', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-11-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 11:05:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:12:41', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:17', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:56', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIVN', 'BI01', 'USD', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:25:34', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:36:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'PR01', 'USD', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:27:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:37:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'PR01', 'KHR', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:28:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:37:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINR', 'BO01', 'KHR', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:30:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:39:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINR', 'BO01', 'USD', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:30:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:40:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINN', 'BO02', 'USD', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:32:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:41:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 17:56:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:30:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'USD', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 18:03:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:31:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCC', 'TD24', 'KHR', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 18:05:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:31:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:11:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:04:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:12:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:04:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD03', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:13:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:05:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD04', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:17:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:12:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:23:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:15:01', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:24:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:15:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDIM', 'TD27', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:25:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:17:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD29', 'KHR', to_date('12-11-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:29:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:20:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD29', 'KHR', to_date('01-02-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-11-2021 17:31:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-11-2021 18:20:40', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCSR', 'TD49', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:09:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:09:36', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'CA06', 'KHR', to_date('25-11-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-11-2022 23:53:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-11-2022 23:58:29', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'CA07', 'KHR', to_date('25-11-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-11-2022 23:54:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-11-2022 23:58:55', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCMN', 'CA07', 'USD', to_date('25-11-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-11-2022 23:55:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-11-2022 23:58:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'USD', to_date('02-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('02-01-2024 17:29:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('02-01-2024 17:32:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS05', 'PS05', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:48:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:34:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS05', 'PS05', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:48:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:34:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS06', 'PS06', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:49:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:36:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS07', 'PS07', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:50:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:40:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'NZD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:24:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'SGD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:25:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'THB', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:25:44', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'TWD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:26:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'VND', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:26:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:52', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'ST10', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:32:17', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:41:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'ST10', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:32:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:42:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'SA01', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:33:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:44:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'SA06', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:34:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:45:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'SA06', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:35:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:45:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'AUD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:36:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:20', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'CAD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:37:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'CNY', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:38:08', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'EUR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:38:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'FC03', 'GBP', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:38:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:46:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'KHR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:56:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:59:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:57:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:58:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'KHR', to_date('01-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:39:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:45', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA08', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:35:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'USD', to_date('01-03-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('27-02-2020 18:39:27', 'dd-mm-yyyy hh24:mi:ss'), to_date('27-02-2020 18:41:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:47:26', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA08', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:43:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:06:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA09', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:44:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA09', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:44:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:06:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:47:35', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:42', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:47:44', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'PR01', 'USD', to_date('05-11-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('04-11-2020 17:02:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('04-11-2020 17:12:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'PR01', 'KHR', to_date('05-11-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('04-11-2020 17:09:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('04-11-2020 17:12:11', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'PR01', 'USD', to_date('05-11-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('04-11-2020 17:09:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('04-11-2020 17:12:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:44:54', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:58:35', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCC', 'TD22', 'USD', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 17:57:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:30:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'ST10', 'KHR', to_date('01-04-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-04-2021 07:34:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-04-2021 07:38:08', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TSCM', 'TD21', 'USD', to_date('16-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('15-07-2021 17:55:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('15-07-2021 18:30:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLR', 'TD42', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:00:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:06:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLR', 'TD46', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:04:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:04:44', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLR', 'TD46', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:03:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:04:53', 'dd-mm-yyyy hh24:mi:ss'), 3, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDLN', 'TD48', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:08:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:08:25', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCSR', 'TD49', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:35:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:39:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCLR', 'TD50', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:41:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:47:32', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCLR', 'TD50', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 04:11:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 04:11:54', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCLN', 'TD52', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:56:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:59:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TCLN', 'TD52', 'USD', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 03:58:55', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 03:59:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'EA02', 'USD', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 04:03:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 04:03:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('EA01', 'EA01', 'KHR', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 04:18:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 04:20:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('EA01', 'EA01', 'USD', to_date('01-04-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('25-03-2023 04:19:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('25-03-2023 04:20:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('RY02', 'RY02', 'USD', to_date('13-09-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('13-09-2023 01:04:38', 'dd-mm-yyyy hh24:mi:ss'), to_date('13-09-2023 01:11:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('MA01', 'MA01', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:23:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:29:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('MA02', 'MA02', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:25:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:30:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'MA01', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:37:26', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:40:37', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'MA02', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:38:53', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:40:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'MA02', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:39:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:40:47', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCUN', 'MA01', 'USD', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:48:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:52:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DIIR', 'MA01', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:49:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:53:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS01', 'PS01', 'KHR', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:04:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:20:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS01', 'PS01', 'USD', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:05:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:20:48', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS02', 'PS02', 'KHR', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:10:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:22:13', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS03', 'PS03', 'USD', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:15:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:23:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS04', 'PS04', 'KHR', to_date('19-01-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('19-01-2024 23:20:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('19-01-2024 23:24:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'AUD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:20:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:34:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'CAD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:21:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:34:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'CNY', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:21:49', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:35:04', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'EUR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:22:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:35:18', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'GBP', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:22:37', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:36:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'HKD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:22:57', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:36:15', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'JPY', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:23:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIER', 'FC04', 'MYR', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:24:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:39:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIEO', 'SA01', 'USD', to_date('01-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('01-01-2020 17:34:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-01-2020 17:44:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBS', 'CA06', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:36:31', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:33', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:37:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:17', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA09', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:38:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'KHR', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:09:11', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:12:30', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DCDN', 'CA08', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:43:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:06:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA06', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 17:26:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 18:41:51', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 19:03:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:07:41', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA07', 'KHR', to_date('29-01-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'SROURN', to_date('05-02-2020 19:03:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-02-2020 19:07:53', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CIBN', 'CA07', 'USD', to_date('29-01-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'YRAROTH', to_date('28-01-2020 18:54:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-01-2020 19:05:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'USD', to_date('16-04-2020', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('01-08-2020 16:09:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('01-08-2020 16:12:42', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:45', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA03', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:22:51', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:52', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD14', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:52:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 16:44:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'KHR', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 14:59:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:10:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLCM', 'TD23', 'USD', to_date('20-04-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'CHOUNGLINY', to_date('17-04-2020 15:00:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-04-2020 17:12:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:45:59', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:23:10', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:46:06', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:39', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:29', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:32', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDBO', 'TD25', 'KHR', to_date('20-07-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('17-07-2020 17:07:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-07-2020 17:09:57', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDBO', 'TD25', 'USD', to_date('20-07-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('17-07-2020 17:07:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-07-2020 17:10:05', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDFO', 'TD26', 'KHR', to_date('20-07-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('17-07-2020 17:08:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-07-2020 17:10:14', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDFO', 'TD26', 'USD', to_date('20-07-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('17-07-2020 17:08:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('17-07-2020 17:10:28', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI01', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:26', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'USD', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:43:47', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'KHR', to_date('01-01-2021', 'dd-mm-yyyy'), 'C', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:21:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:44:10', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD02', 'KHR', to_date('01-09-2020', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('31-08-2020 10:16:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('31-08-2020 16:07:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA04', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:49:23', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:13:00', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('30-06-2021 18:16:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2021 18:22:40', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA07', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('30-06-2021 18:16:41', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2021 18:22:46', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA04', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:54:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:11:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'CA05', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:56:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:12:02', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'SA10', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('30-06-2021 18:17:24', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-06-2021 18:22:53', 'dd-mm-yyyy hh24:mi:ss'), 2, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI02', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 13:59:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:06:54', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:00:22', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:09:16', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BI03', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:00:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:09:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:01:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:10:49', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP01', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:01:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:09:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'KHR', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:02:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:11:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('CACM', 'BP02', 'USD', to_date('01-01-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('28-12-2020 14:03:58', 'dd-mm-yyyy hh24:mi:ss'), to_date('28-12-2020 14:11:31', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('DINN', 'BO02', 'KHR', to_date('16-06-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('16-06-2021 23:32:01', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-06-2021 23:41:09', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDOM', 'TD28', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:38:00', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:15:21', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD29', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:41:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:20:34', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDMN', 'TD29', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:42:35', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:19:42', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDCN', 'TD30', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:47:47', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:22:06', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD32', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:52:40', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:32:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLRC', 'TD32', 'KHR', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:53:59', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:29:10', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TLNM', 'TD33', 'USD', to_date('01-07-2021', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'HLEANG', 'FLEXADMIN', to_date('29-06-2021 16:55:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('29-06-2021 17:33:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('TDSR', 'TD45', 'KHR', to_date('20-06-2022', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('20-06-2022 02:27:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('20-06-2022 02:33:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('MA01', 'MA01', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:24:02', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:29:30', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('MA02', 'MA02', 'KHR', to_date('10-10-2023', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('10-10-2023 16:25:06', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-10-2023 16:30:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS07', 'PS07', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 17:51:07', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:38:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS08', 'PS08', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:07:21', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:42:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS09', 'PS09', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:08:33', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:46:26', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS09', 'PS09', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:08:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:45:58', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS10', 'PS10', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:09:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:47:07', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS10', 'PS10', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:09:39', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:46:53', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS11', 'PS11', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:10:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:48:12', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS11', 'PS11', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:14:16', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:47:56', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS12', 'PS12', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:14:45', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:49:03', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS12', 'PS12', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:15:15', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:48:38', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS13', 'PS13', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:17:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:50:25', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS13', 'PS13', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:18:36', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:49:23', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS14', 'PS14', 'KHR', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:19:12', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:52:36', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

insert into p1fchprfm.ICTMS_PR_INT_EFFDT (PRODUCT_CODE, ACLASS, CCY_CODE, UDE_EFF_DT, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, MOD_NO, BRANCH_CODE)
values ('PS14', 'PS14', 'USD', to_date('09-04-2024', 'dd-mm-yyyy'), 'O', 'A', 'Y', 'CSOTTHORN', 'FLEXADMIN', to_date('08-04-2024 18:19:28', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-04-2024 18:51:39', 'dd-mm-yyyy hh24:mi:ss'), 1, 'ALL');

prompt Done.
