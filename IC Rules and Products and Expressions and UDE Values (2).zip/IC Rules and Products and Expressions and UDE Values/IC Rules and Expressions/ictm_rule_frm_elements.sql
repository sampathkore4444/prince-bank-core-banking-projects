prompt Importing table ictm_rule_frm_elements...
set feedback off
set define off
insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CACM', 1, 'CHG_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CACM', 1, 'MIN_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CACM', 1, 'MIN_MON_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBI', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIBP', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 1, 'DLY_NET_COT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICN', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'INTEREST_RATE_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'INTEREST_RATE_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CICP', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'DAYS_FROM_START');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'INTEREST_RATE_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 1, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 2, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIDS', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIEB', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIES', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'DAYS_FROM_START');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'INTEREST_RATE_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 1, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIET', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 1, 'DLY_NET_COT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISE', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'DLY_NET_COT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'MON_DR_CNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 1, 'VD_DLY_CR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 2, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CISP', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 2, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 2, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVA', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 1, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVN', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'INTEREST_RATE_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'INTEREST_RATE_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CIVS', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 2, 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB1', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 2, 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLB3', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'INTEREST_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'INTEREST_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'TOPUP_EXTRA_RAT2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'TOPUP_EXTRA_RAT3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE2', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'INTEREST_RATE_1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'INTEREST_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'INTEREST_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'CLEVER_SAVINGS_INT_DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'TOPUP_EXTRA_RAT1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'TOPUP_EXTRA_RAT2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'TOPUP_EXTRA_RAT3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLE3', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 1, 'INTEREST_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 2, 'CLEVER_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 2, 'TOPUP_EXTRA_RAT3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('CLR1', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCDN', 1, 'AC_DORMANT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCDN', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCDN', 1, 'DORM_CHG_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCMN', 1, 'CHG_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCMN', 1, 'MIN_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCMN', 1, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCUN', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCUN', 1, 'EFF_LINE_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCUN', 1, 'UNUTIL_CHG_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCUN', 1, 'VD_DLY_DR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DCUN', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'DR_INT_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'DR_INT_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'DR_INT_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 1, 'VD_DLY_DR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 2, 'VD_DLY_DR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 3, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 3, 'DR_INT_RATE_PEN');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 3, 'EFF_LINE_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 4, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 4, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 4, 'EFF_LINE_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 4, 'FORMULA3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVN', 4, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 1, 'DR_INT_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 1, 'VD_DLY_DR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 2, 'VD_DLY_DR_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 3, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 3, 'DR_INT_RATE_PEN');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 3, 'EFF_LINE_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 4, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 4, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 4, 'EFF_LINE_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 4, 'FORMULA3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('DIVR', 4, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 2, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA01', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'COUNT_DAYS_OF_MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'EACCOUNT_INT_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'INT_EACC_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'INT_EACC_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'MON_AVG_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'COUNT_DAYS_OF_MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'EACCOUNT_KHQR_INT_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'INT_EACC_KHQR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'MON_AVG_BAL_M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 3, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'COUNT_DAYS_OF_MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'EACC_MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'INT_EACC_MAVG');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'MONTH');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'MON_AVG_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 4, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 5, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 5, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 5, 'FORMULA3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 5, 'FORMULA4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('EA02', 5, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('MA01', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'DLY_NET_VD_BAL');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'INTEREST_RATE_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'INTEREST_RATE_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'INTEREST_RATE_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'INTEREST_RATE_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 2, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PR01', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS01', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS03', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS05', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS07', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS09', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS11', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 1, 'INTEREST_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 2, 'PRO_SAVINGS_TOPUP_AMT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 2, 'TOPUP_EXTRA_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 4, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('PS13', 4, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 1, 'INT_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 2, 'DAYS_TILL_REDEEM');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 2, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 2, 'INT_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 2, 'PENALTY_APPLY');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDFI', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_4Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_5Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'INT_RATE_9M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_7');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_8');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'SLAB_9');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_4Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'INT_RATE_9M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'PENALTY_APPLY');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SAVINGS_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_7');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_8');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'SLAB_9');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'TD_UPFRONT_AUTOROLLOVER_FLAG');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'TD_UPFRONT_BOOK_FLAG');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDIS', 3, 'TD_UPFRONT_PREMAT_FLAG');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_4Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_5Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'INT_RATE_9M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_7');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_8');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'SLAB_9');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_2Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_3Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_4Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_5Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'INT_RATE_9M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'PENALTY_APPLY');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'PENALTY_PERCENT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SAVINGS_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_6');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_7');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_8');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'SLAB_9');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'TRACK_DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 3, 'FORMULA2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTB', 3, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'DAYS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'DEPOSIT_AMOUNT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'INT_RATE_12M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'INT_RATE_A1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 1, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'DAYS_FROM_START');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'INT_RATE_12M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'INT_RATE_1M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'INT_RATE_3M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'INT_RATE_6M');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'INT_RATE_A1Y');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'PENALTY_APPLY');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'PENALTY_BASIS');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'PENALTY_PERCENT');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SAVINGS_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SLAB_1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SLAB_2');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SLAB_3');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SLAB_4');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'SLAB_5');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'TAX_RATE');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'TENOR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 2, 'YEAR');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 3, 'FORMULA1');

insert into ictm_rule_frm_elements (RULE_ID, FRM_NO, ELEMENT_ID)
values ('TDTD', 3, 'TAX_RATE');

prompt Done.
