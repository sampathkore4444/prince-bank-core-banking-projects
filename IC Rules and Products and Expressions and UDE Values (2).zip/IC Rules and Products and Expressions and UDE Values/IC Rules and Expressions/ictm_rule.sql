prompt Importing table ictm_rule...
set feedback off
set define off
insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIDS', 'CREDIT INTEREST - TENOR SLAB', null, 'O', 'A', 'Y', 12, 'CLAYHOUT', to_date('20-03-2019 20:02:53', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:04:28', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CISP', 'CREDIT INTEREST - SPECIAL', null, 'O', 'A', 'Y', 6, 'CLAYHOUT', to_date('20-03-2019 20:03:02', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:04:38', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIVN', 'CREDIT INTEREST - MONTHLY AVG BAL', null, 'O', 'A', 'Y', 6, 'CLAYHOUT', to_date('20-03-2019 20:03:08', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:04:48', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIVS', 'CREDIT INTEREST - MONTHLY AVG BAL - AMOUNT SLAB', null, 'O', 'A', 'Y', 9, 'CLAYHOUT', to_date('20-03-2019 20:03:16', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:04:56', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('DCDN', 'CHARGE FOR DORMANCY', null, 'O', 'A', 'Y', 6, 'CSOTTHORN', to_date('11-04-2023 22:45:01', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('11-04-2023 22:51:35', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'N', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('DCMN', 'CHARGE FOR MINIMUM AVG BAL', null, 'O', 'A', 'Y', 7, 'CLAYHOUT', to_date('20-03-2019 20:03:38', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:05:15', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'N', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('DCUN', 'CHARGE FOR UN-UTILIZED LINE', null, 'O', 'A', 'Y', 13, 'HLEANG', to_date('01-03-2021 19:50:22', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('01-03-2021 19:54:55', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('DIVN', 'DEBIT INTEREST - DAILY DEBIT BAL', null, 'O', 'A', 'Y', 8, 'HLEANG', to_date('16-06-2021 22:07:16', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('16-06-2021 22:13:44', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('TDTB', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 13, 'HLEANG', to_date('09-02-2021 23:08:46', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('09-02-2021 23:15:12', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('TDTD', 'DISCOUNTED INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 6, 'CLAYHOUT', to_date('20-03-2019 20:04:11', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('20-03-2019 20:06:09', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CICN', 'CREDIT INTEREST CURRENT ACCOUNT', null, 'O', 'A', 'Y', 1, 'CLAYHOUT', to_date('08-08-2019 10:23:35', 'dd-mm-yyyy hh24:mi:ss'), 'CMAKARA', to_date('08-08-2019 11:28:45', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CACM', 'CHARGE FOR MINIMUM BAL', null, 'O', 'A', 'Y', 2, 'YRAROTH', to_date('13-09-2019 16:26:49', 'dd-mm-yyyy hh24:mi:ss'), 'CMAKARA', to_date('13-09-2019 16:28:02', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'N', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIBP', 'CREDIT INTEREST EOD BALANCE AMOUNT SLAB BP', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('15-04-2020 14:58:34', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('15-04-2020 15:39:02', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('DIVR', 'DEBIT INTEREST - DAILY DEBIT BAL - NO SLAB', null, 'O', 'A', 'Y', 2, 'HLEANG', to_date('16-06-2021 22:01:29', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('16-06-2021 22:16:33', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('TDIS', 'CREDIT INTEREST - TDUPFRONT - TENOR SLAB', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('20-06-2022 00:09:21', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('20-06-2022 00:26:37', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('EA01', 'CREDIT INTEREST EOD BALANCE SPECIAL', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('25-03-2023 04:10:06', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('25-03-2023 04:11:07', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLB1', 'CREDIT INTEREST - TD 1YEAR', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('03-06-2024 21:39:27', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('03-06-2024 22:06:45', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLB3', 'CREDIT INTEREST - TD 2YEARS', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('03-06-2024 21:40:45', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('03-06-2024 22:06:58', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIBI', 'CREDIT INTEREST EOD BALANCE AMOUNT SLAB BBI', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('02-12-2019 13:23:56', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('02-12-2019 17:44:01', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLE2', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('13-09-2023 22:56:48', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('13-09-2023 23:10:40', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS01', 'CREDIT INTEREST - PRO SAVINGS IND 60K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('19-01-2024 22:32:01', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('19-01-2024 22:38:31', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS05', 'CREDIT INTEREST - PRO SAVINGS 100K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('08-04-2024 16:40:44', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('08-04-2024 16:56:36', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS09', 'CREDIT INTEREST - PRO SAVINGS 600K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('08-04-2024 16:42:04', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('08-04-2024 17:02:39', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS11', 'CREDIT INTEREST - PRO SAVINGS 720K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('08-04-2024 16:42:51', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('08-04-2024 17:04:57', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CICP', 'CREDIT INTEREST PRIORITY CHECK ACCOUNT', null, 'O', 'A', 'Y', 1, 'CLAYHOUT', to_date('08-08-2019 10:31:52', 'dd-mm-yyyy hh24:mi:ss'), 'CMAKARA', to_date('08-08-2019 11:29:14', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIES', 'CREDIT INTEREST EOD BALANCE AMOUNT SLAB', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('02-12-2019 11:54:15', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('02-12-2019 17:46:15', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLE3', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('13-09-2023 22:50:29', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('13-09-2023 23:14:11', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CLR1', 'CREDIT INTEREST - TD - TENOR SLAB', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('13-09-2023 22:59:57', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('13-09-2023 23:06:10', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS03', 'CREDIT INTEREST - PRO SAVINGS IND 200K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('19-01-2024 22:34:22', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('19-01-2024 22:39:51', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS07', 'CREDIT INTEREST - PRO SAVINGS 300K PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('08-04-2024 16:41:25', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('08-04-2024 17:00:33', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PS13', 'CREDIT INTEREST - PRO SAVINGS 1.32M PLAN', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('08-04-2024 16:43:17', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('08-04-2024 17:06:41', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIEB', 'CREDIT INTEREST EOD BALANCE', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('02-12-2019 11:29:05', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('02-12-2019 17:44:32', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CIET', 'CREDIT INTEREST EOD BALANCE TENOR SLAB', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('02-12-2019 11:39:01', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('02-12-2019 17:57:01', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('CISE', 'CREDIT INTEREST EOD BALANCE SPECIAL', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('02-12-2019 11:47:07', 'dd-mm-yyyy hh24:mi:ss'), 'YRAROTH', to_date('02-12-2019 17:57:16', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('TDFI', 'CREDIT INTEREST - TD - TENOR NON SLAB', null, 'O', 'A', 'Y', 1, 'HLEANG', to_date('17-07-2020 16:28:19', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('17-07-2020 16:33:47', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('EA02', 'E-Account daily Accrual but with bonus rate on month end', null, 'O', 'A', 'Y', 2, 'CSOTTHORN', to_date('25-03-2023 03:55:26', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('25-03-2023 03:55:56', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('PR01', 'CREDIT INTEREST EOD BALANCE AMOUNT SLAB', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('30-06-2023 22:17:02', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('30-06-2023 22:20:10', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

insert into ictm_rule (RULE_ID, RULE_DESC, RULE_CATG, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, INT_ACC_OPEN, INT_ACC_CLOSE, HAS_ACCR, PRIMARY_ELEMENT, IL_RULE, IL_TYPE, MODULEID)
values ('MA01', 'CREDIT INTEREST EOD BALANCE', null, 'O', 'A', 'Y', 1, 'CSOTTHORN', to_date('10-10-2023 15:42:58', 'dd-mm-yyyy hh24:mi:ss'), 'FLEXADMIN', to_date('10-10-2023 15:49:42', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'Y', 'Y', null, 'N', null, 'IC');

prompt Done.
