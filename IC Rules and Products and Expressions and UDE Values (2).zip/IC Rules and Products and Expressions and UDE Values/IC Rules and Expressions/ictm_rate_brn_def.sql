prompt Importing table ictm_rate_brn_def...
set feedback off
set define off
insert into ictm_rate_brn_def (RATE_CODE, BRANCH_ALLOWED, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, AUTH_STAT, RECORD_STAT, ONCE_AUTH)
values ('TD_1_YR_RT', 'D', 'SYSTEM', to_date('01-10-2023 09:23:22', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('01-10-2023 09:23:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'A', 'O', 'Y');

prompt Done.
