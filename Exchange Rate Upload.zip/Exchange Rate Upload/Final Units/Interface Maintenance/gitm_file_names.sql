prompt Importing table gitm_file_names...
set feedback off
set define off
insert into gitm_file_names (INTERFACE_CODE, FILE_NAME)
values ('IXRATEJU', 'XR.csv');

prompt Done.
