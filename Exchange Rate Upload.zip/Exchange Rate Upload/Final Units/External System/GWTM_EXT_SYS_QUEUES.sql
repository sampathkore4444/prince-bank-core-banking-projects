prompt Importing table GWTM_EXT_SYS_QUEUES...
set feedback off
set define off
insert into GWTM_EXT_SYS_QUEUES (EXT_SYSTEM, IN_QUEUE, RESP_QUEUE)
values ('EXTSYS', 'MDB_QUEUE', 'MDB_QUEUE_RESPONSE');

prompt Done.
