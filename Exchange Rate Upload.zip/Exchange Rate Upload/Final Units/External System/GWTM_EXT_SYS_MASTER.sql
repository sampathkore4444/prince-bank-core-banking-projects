prompt Importing table GWTM_EXT_SYS_MASTER...
set feedback off
set define off
insert into GWTM_EXT_SYS_MASTER (EXT_SYSTEM, DESCRIPTION, DEFAULT_RESP_QUEUE, DEAD_LETTER_QUEUE, RESP_MSG_ID_REG_REQD, CORREL_PATTERN, MSG_XCHANGE_PATTERN, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, XSD_VALIDATION_REQD)
values ('EXTSYS', 'EXTSYS', null, null, 'N', 'M2C', 'FSFS', 'SYSTEM', 'SYSTEM', to_date('30-11-2007 16:17:20', 'dd-mm-yyyy hh24:mi:ss'), to_date('30-11-2007 16:18:19', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 2, 'N');

prompt Done.
