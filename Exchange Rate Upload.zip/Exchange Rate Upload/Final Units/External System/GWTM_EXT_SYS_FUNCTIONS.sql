prompt Importing table GWTM_EXT_SYS_FUNCTIONS...
set feedback off
set define off
insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('EXTSYS', 'CYGRATEE', 'AUTHORIZE', 'SAMPATH2', 'SAMPATH1', to_date('06-08-2022 10:04:30', 'dd-mm-yyyy hh24:mi:ss'), to_date('06-08-2022 10:05:00', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

insert into GWTM_EXT_SYS_FUNCTIONS (EXT_SYSTEM, FUNCTION_ID, ACTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, ONCE_AUTH, AUTH_STAT, RECORD_STAT, MOD_NO, BULK_SMS_CHK_REQ)
values ('EXTSYS', 'CYGRATEE', 'UNLOCK', 'SAMPATH2', 'SAMPATH1', to_date('06-08-2022 10:24:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('06-08-2022 10:25:06', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'A', 'O', 1, 'N');

prompt Done.
