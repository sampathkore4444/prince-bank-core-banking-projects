
CREATE DIRECTORY "IXRATEJU_I" AS '/u01/fcubs/interfaces/gi/incoming/xr/wip';
CREATE DIRECTORY "XRUPLD_I/error" AS '/u01/fcubs/interfaces/gi/incoming/xr/error';
CREATE DIRECTORY "XRUPLD_I/file_processed" AS '/u01/fcubs/interfaces/gi/incoming/xr/file_processed';
CREATE DIRECTORY "XRUPLD_I/processed" AS '/u01/fcubs/interfaces/gi/incoming/xr/processed';
CREATE DIRECTORY "XRUPLD_I/wip" AS '/u01/fcubs/interfaces/gi/incoming/xr/wip';
CREATE DIRECTORY "XRUPLD_I/ready" AS '/u01/fcubs/interfaces/gi/incoming/xr/ready';
CREATE DIRECTORY "XRUPLD_I" AS '/u01/fcubs/interfaces/gi/incoming/xr/wip';


GRANT READ,WRITE ON DIRECTORY IXRATEJU_I TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I/error" TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I/file_processed" TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I/processed" TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I/wip" TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I/ready" TO P1FCHPRFM;
GRANT READ,WRITE ON DIRECTORY "XRUPLD_I" TO P1FCHPRFM;