CREATE OR REPLACE PACKAGE BODY GIPKS_IXCGRATE_UBS_txt IS

  function fn_process_file(p_interface_code IN VARCHAR2,
                           p_file_name      IN VARCHAR2,
                           p_Phy_file_name  IN VARCHAR2,
                           p_ProcessRefNo   IN VARCHAR2,
                           p_err_code       IN OUT VARCHAR2,
                           p_err_params     IN OUT VARCHAR2,
                           p_status         IN OUT VARCHAR2) return BOOLEAN IS
  
    p_format_dtls     GITM_INTERFACE_DEFINITION%ROWTYPE;
    p_file_dtls       gitm_file_names%ROWTYPE;
    p_comp_dtls       gipks_gi_service.ty_tb_f_gitm_component_linkage;
    p_field_dtls      gipks_gi_service.ty_tb_f_omponent_field_linkage;
    l_upload_master   gipks_gi_service.ty_upload_master;
    l_upload_child    gipks_gi_service.ty_upload_detail;
    upload_mstr_index number := 0;
    upload_chld_index number := 0;
    istart            number;
    iend              number;
    l_prev_start      number;
    l_rec_count       number;
    indx              number := 0;
    txnRef            GITU_UPLOAD_MASTER.record_reference%type;
    l_row             varchar2(4000);
    hdrlineNo         number;
    tlrlineNo         number;
    e_Failure_Exception Exception;
    L_REC_ARRAY             GIPKS_GI_SERVICE.ty_rec_array;
    I                       NUMBER;
    p_fld_name              varchar2(1000);
    p_fld_value             varchar2(32767);
    p_GITE_IXCGRATEUBS_txt1 ty_GITE_IXCGRATEUBS_txt1;
    p_GITE_IXCGRATEUBS_txt2 ty_GITE_IXCGRATEUBS_txt2;
    p_GITE_IXCGRATEUBS_txt3 ty_GITE_IXCGRATEUBS_txt3;
    p_GITE_IXCGRATEUBS_txt4 ty_GITE_IXCGRATEUBS_txt4;
  
    CURSOR CUR_IXCGRATEUBS_txt1 IS
      SELECT LINE_NO,
             rtrim(HEADER, ' ') HEADER,
             rtrim(SYSCDORGN, ' ') SYSCDORGN,
             rtrim(DESSYSCD, ' ') DESSYSCD,
             rtrim(APPDATE, ' ') APPDATE
        FROM GITE_IXCGRATEUBS_txt1
       WHERE HEADER = 'HDR';
  
    CURSOR CUR_IXCGRATEUBS_txt2 IS
      SELECT LINE_NO,
             rtrim(CYTMMASTER, ' ') CYTMMASTER,
             rtrim(BRNCODE, ' ') BRNCODE,
             rtrim(CCY1, ' ') CCY1,
             rtrim(CCY2, ' ') CCY2
        FROM GITE_IXCGRATEUBS_txt2
       WHERE CYTMMASTER = 'BHR';
  
    CURSOR CUR_IXCGRATEUBS_txt3(startLineNo IN VARCHAR2,
                                endLineNo   IN VARCHAR2) IS
      SELECT LINE_NO,
             rtrim(CYTMRATES, ' ') CYTMRATES,
             rtrim(RATETYPE, ' ') RATETYPE,
             TO_NUMBER(rtrim(MIDRATE, ' ')) MIDRATE,
             TO_NUMBER(rtrim(BUYSPREAD, ' ')) BUYSPREAD,
             TO_NUMBER(rtrim(SALESPREAD, ' ')) SALESPREAD,
             TO_NUMBER(rtrim(BUYRATE, ' ')) BUYRATE,
             TO_NUMBER(rtrim(SALERATE, ' ')) SALERATE,
             rtrim(RATEDATE, ' ') RATEDATE,
             TO_NUMBER(rtrim(RATESERIAL, ' ')) RATESERIAL
        FROM GITE_IXCGRATEUBS_txt3
       WHERE CYTMRATES = 'BBR'
         AND LINE_NO > startLineNo
         AND LINE_NO < endLineNo;
  
    CURSOR CUR_IXCGRATEUBS_txt4 IS
      SELECT LINE_NO,
             rtrim(TRAILER, ' ') TRAILER,
             TO_NUMBER(rtrim(NOOFREC, ' ')) NOOFREC
        FROM GITE_IXCGRATEUBS_txt4
       WHERE TRAILER = 'TLR';
  
  BEGIN
  
    SAVEPOINT UPLOADINSERT;
    debug.pr_debug('GI', 'Opening Trailer Cursor');
    OPEN CUR_IXCGRATEUBS_txt4;
    FETCH CUR_IXCGRATEUBS_txt4 BULK COLLECT
      INTO P_GITE_IXCGRATEUBS_txt4;
  
    IF P_GITE_IXCGRATEUBS_txt4.COUNT <> 0 THEN
      FOR EACH_BHD_REC IN P_GITE_IXCGRATEUBS_txt4.FIRST .. P_GITE_IXCGRATEUBS_txt4.LAST LOOP
      
        NULL;
      END LOOP;
    END IF;
    CLOSE CUR_IXCGRATEUBS_txt4;
    debug.pr_debug('GI', 'TRAILER CURSOR CLOSED');
    debug.pr_debug('GI', 'Opening Header Cursor');
    OPEN CUR_IXCGRATEUBS_txt1;
    FETCH CUR_IXCGRATEUBS_txt1 BULK COLLECT
      INTO P_GITE_IXCGRATEUBS_txt1;
  
    IF P_GITE_IXCGRATEUBS_txt1.COUNT <> 0 THEN
      FOR EACH_BHD_REC IN P_GITE_IXCGRATEUBS_txt1.FIRST .. P_GITE_IXCGRATEUBS_txt1.LAST LOOP
      
        debug.pr_debug('GI', 'Uploading Master batch Header Component');
        OPEN CUR_IXCGRATEUBS_txt2;
        FETCH CUR_IXCGRATEUBS_txt2 BULK COLLECT
          INTO P_GITE_IXCGRATEUBS_txt2;
      
        IF P_GITE_IXCGRATEUBS_txt2.COUNT <> 0 THEN
          FOR EACH_BHD_REC2 IN P_GITE_IXCGRATEUBS_txt2.FIRST .. P_GITE_IXCGRATEUBS_txt2.LAST LOOP
            upload_mstr_index := upload_mstr_index + 1;
            SELECT RECORD_REFERENCE.NEXTVAL INTO txnRef FROM DUAL;
            l_upload_master(upload_mstr_index).record_reference := txnRef;
            l_upload_master(upload_mstr_index).fld1 := P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2)
                                                       .CYTMMASTER;
            l_upload_master(upload_mstr_index).fld2 := P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2)
                                                       .BRNCODE;
            l_upload_master(upload_mstr_index).fld3 := GIPKS_GI_SERVICE.FN_TRANSLATE('EXCH',
                                                                                     'I',
                                                                                     P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2).CCY1,
                                                                                     'S');
            l_upload_master(upload_mstr_index).fld4 := GIPKS_GI_SERVICE.FN_TRANSLATE('EXCH',
                                                                                     'I',
                                                                                     P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2).CCY2,
                                                                                     'S');
            l_upload_master(upload_mstr_index).INTERFACE_CODE := 'IXCGRATE';
            l_upload_master(upload_mstr_index).FILE_NAME := 'UBS_txt';
            l_upload_master(upload_mstr_index).PHY_FILE_NAME := p_Phy_file_name;
            l_upload_master(upload_mstr_index).PROCESS_REF_NO := p_ProcessRefNo;
            l_upload_master(upload_mstr_index).EXTERNAL_SYSTEM := 'EXTSYS';
            l_upload_master(upload_mstr_index).FUNCTION_ID := 'CYDRATES';
            l_upload_master(upload_mstr_index).PROCESS_NO := 1;
            l_upload_master(upload_mstr_index).STATUS := 'U';
            l_upload_master(upload_mstr_index).ACTION := 'N';
            l_upload_master(upload_mstr_index).TARGET_TABLE := 'CYTMS_RATES_MASTER';
            istart := P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2).LINE_NO;
            IF EACH_BHD_REC2 <> P_GITE_IXCGRATEUBS_txt2.LAST THEN
              iend := P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2 + 1).LINE_NO;
            else
              SELECT MAX(LINE_NO) INTO iend FROM GITE_IXCGRATEUBS_txt4;
            end if;
            debug.pr_debug('GI', 'Uploading Batch Body Component');
            OPEN CUR_IXCGRATEUBS_txt3(istart, iend);
            FETCH CUR_IXCGRATEUBS_txt3 BULK COLLECT
              INTO p_GITE_IXCGRATEUBS_txt3;
          
            IF p_GITE_IXCGRATEUBS_txt3.COUNT <> 0 THEN
              FOR EACH_BBD_REC IN p_GITE_IXCGRATEUBS_txt3.FIRST .. p_GITE_IXCGRATEUBS_txt3.LAST LOOP
                upload_chld_index := upload_chld_index + 1;
                l_upload_child(upload_chld_index).record_reference := txnRef;
                l_upload_child(upload_chld_index).fld1 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .CYTMRATES;
                l_upload_child(upload_chld_index).fld2 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .RATETYPE;
                l_upload_child(upload_chld_index).fld3 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .MIDRATE;
                l_upload_child(upload_chld_index).fld4 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .BUYSPREAD;
                l_upload_child(upload_chld_index).fld5 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .SALESPREAD;
                l_upload_child(upload_chld_index).fld6 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .BUYRATE;
                l_upload_child(upload_chld_index).fld7 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .SALERATE;
                l_upload_child(upload_chld_index).fld8 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .RATEDATE;
                l_upload_child(upload_chld_index).fld9 := p_GITE_IXCGRATEUBS_txt3(EACH_BBD_REC)
                                                          .RATESERIAL;
                l_upload_child(upload_chld_index).fld10 := P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2)
                                                           .BRNCODE;
                l_upload_child(upload_chld_index).fld11 := GIPKS_GI_SERVICE.FN_TRANSLATE('EXCH',
                                                                                         'I',
                                                                                         P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2).CCY1,
                                                                                         'S');
                l_upload_child(upload_chld_index).fld12 := GIPKS_GI_SERVICE.FN_TRANSLATE('EXCH',
                                                                                         'I',
                                                                                         P_GITE_IXCGRATEUBS_txt2(EACH_BHD_REC2).CCY2,
                                                                                         'S');
                l_upload_child(upload_chld_index).INTERFACE_CODE := 'IXCGRATE';
                l_upload_child(upload_chld_index).FILE_NAME := 'UBS_txt';
                l_upload_child(upload_chld_index).PHY_FILE_NAME := p_Phy_file_name;
                l_upload_child(upload_chld_index).PROCESS_REF_NO := p_ProcessRefNo;
                l_upload_child(upload_chld_index).EXTERNAL_SYSTEM := 'EXTSYS';
                l_upload_child(upload_chld_index).FUNCTION_ID := 'CYDRATES';
                l_upload_child(upload_chld_index).PROCESS_NO := 1;
                l_upload_child(upload_chld_index).TARGET_TABLE := 'CYTMS_RATES';
              END LOOP;
            END IF;
            CLOSE CUR_IXCGRATEUBS_txt3;
            debug.pr_debug('GI',
                           'Uploading Batch Body Component completed ');
          END LOOP;
        END IF;
        CLOSE CUR_IXCGRATEUBS_txt2;
        debug.pr_debug('GI', 'Uploading Master Header Component Completed');
      END LOOP;
    END IF;
    CLOSE CUR_IXCGRATEUBS_txt1;
    debug.pr_debug('GI', 'HEADER CURSOR CLOSED');
    IF l_upload_master.COUNT > 0 THEN
      debug.pr_debug('GI', 'Inserting Master Details to Upload Master');
      FOR k IN l_upload_master.FIRST .. l_upload_master.last LOOP
        INSERT INTO GITU_UPLOAD_MASTER VALUES l_upload_master (k);
      END LOOP;
    END IF;
    IF l_upload_child.COUNT > 0 THEN
      debug.pr_debug('GI', 'Inserting Child Details to Upload Child');
      FOR I IN l_upload_child.FIRST .. l_upload_child.last LOOP
        INSERT INTO GITU_UPLOAD_DETAIL VALUES l_upload_child (I);
      END LOOP;
    END IF;
    debug.pr_debug('GI', 'Going to Commit the Insert Statements');
    p_status := 'S';
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      IF CUR_IXCGRATEUBS_txt2%ISOPEN THEN
        CLOSE CUR_IXCGRATEUBS_txt2;
      END IF;
      IF CUR_IXCGRATEUBS_txt3%ISOPEN THEN
        CLOSE CUR_IXCGRATEUBS_txt3;
      END IF;
    WHEN OTHERS THEN
      debug.pr_debug('GI', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
      RAISE e_Failure_Exception;
      debug.pr_debug('GI', 'Failed in File Process' || SQLERRM);
      ROLLBACK TO UPLOADINSERT;
      p_status := 'E';
      RETURN FALSE;
  END fn_process_file;
  function fn_upload(p_interface_code IN VARCHAR2,
                     p_file_name      IN VARCHAR2,
                     p_Phy_file_name  IN VARCHAR2,
                     p_ProcessRefNo   IN VARCHAR2,
                     p_process_no     IN NUMBER,
                     p_err_code       IN OUT VARCHAR2,
                     p_error_params   IN OUT VARCHAR2,
                     p_status         IN OUT VARCHAR2) return BOOLEAN IS
  
    l_precision     number := 1000000000000;
    txnRef          varchar2(20);
    child_index     number := 0;
    l_multi_trip_id varchar2(32);
    l_status        varchar2(1);
    e_Failure_Exception Exception;
    l_error_code         varchar2(255);
    l_error_params       varchar2(255);
    L_ERROR_REFERENCES   VARCHAR2(32727) := NULL;
    IS_DATA_VALID        BOOLEAN := TRUE;
    ERRORS               VARCHAR2(32727) := NULL;
    l_gitm_upload_master GITU_UPLOAD_MASTER%rowtype;
    l_gitm_upload_detail GITU_UPLOAD_DETAIL%rowtype;
    L_COUNT              NUMBER;
    p_cydrates           cypks_fcj_cydrates.ty_cydrates;
    p_null_cydrates      cypks_fcj_cydrates.ty_cydrates; --GIB Temp
  
    CURSOR CR_ERR_REF IS
      SELECT RECORD_REFERENCE
        FROM GITU_UPLOAD_MASTER U
       WHERE U.INTERFACE_CODE = p_interface_code
         and U.FILE_NAME = p_file_name
         and U.TARGET_TABLE = 'CYTMS_RATES_MASTER'
         and U.PROCESS_NO = p_process_no
         and STATUS <> 'P';
  
    CURSOR CR_RATES_MASTER IS
      SELECT U.RECORD_REFERENCE,
             TRIM(U.FLD2) BRNCODE,
             TRIM(U.FLD3) CCY1,
             TRIM(U.FLD4) CCY2
        FROM GITU_UPLOAD_MASTER U
       WHERE U.INTERFACE_CODE = p_interface_code
         and U.FILE_NAME = p_file_name
         and U.TARGET_TABLE = 'CYTMS_RATES_MASTER'
         and U.PROCESS_NO = p_process_no
         and STATUS <> 'P';
  
    CURSOR CR_RATES(refno IN NUMBER) IS
      SELECT TRIM(U.FLD2) RATETYPE,
             TRIM(TO_NUMBER(U.FLD3)) MIDRATE,
             TRIM(TO_NUMBER(U.FLD4)) BUYSPREAD,
             TRIM(TO_NUMBER(U.FLD5)) SALESPREAD,
             TRIM(TO_NUMBER(U.FLD6)) BUYRATE,
             TRIM(TO_NUMBER(U.FLD7)) SALERATE,
             TRIM(TO_DATE(U.FLD8, 'YYYYMMDD')) RATEDATE,
             TRIM(TO_NUMBER(U.FLD9)) RATESERIAL,
             TRIM(U.FLD10) BRANCHCODE,
             TRIM(U.FLD11) CCY1,
             TRIM(U.FLD12) CCY2
        FROM GITU_UPLOAD_DETAIL U
       WHERE U.RECORD_REFERENCE = refno
         and U.TARGET_TABLE = 'CYTMS_RATES';
  
  BEGIN
  
    p_status := 'S';
    SELECT COUNT(*)
      INTO L_COUNT
      FROM GITU_UPLOAD_MASTER U
     WHERE U.INTERFACE_CODE = p_interface_code
       and U.FILE_NAME = p_file_name
       and U.TARGET_TABLE = 'CYTMS_RATES_MASTER'
       AND U.PROCESS_NO = p_process_no
       and STATUS <> 'P';
    IF L_COUNT = 0 THEN
      debug.pr_debug('GI', 'NO DATA TO PROCESS ');
      p_err_code     := 'GI-PRS-043';
      p_status       := 'E';
      p_error_params := null;
      RETURN FALSE;
    END IF;
    FOR EACH_REC IN CR_ERR_REF LOOP
      BEGIN
        SELECT U.RECORD_REFERENCE, U.FLD2 BRNCODE, U.FLD3 CCY1, U.FLD4 CCY2
          INTO l_gitm_upload_master.record_reference,
               L_GITM_UPLOAD_MASTER.FLD2,
               L_GITM_UPLOAD_MASTER.FLD3,
               L_GITM_UPLOAD_MASTER.FLD4
          FROM GITU_UPLOAD_MASTER U
         WHERE RECORD_REFERENCE = EACH_REC.RECORD_REFERENCE;
      
        SELECT U.FLD2 RATETYPE,
               TO_NUMBER(U.FLD3) MIDRATE,
               TO_NUMBER(U.FLD4) BUYSPREAD,
               TO_NUMBER(U.FLD5) SALESPREAD,
               TO_NUMBER(U.FLD6) BUYRATE,
               TO_NUMBER(U.FLD7) SALERATE,
               TO_DATE(U.FLD8, 'YYYYMMDD') RATEDATE,
               TO_NUMBER(U.FLD9) RATESERIAL,
               U.FLD10 BRANCHCODE,
               U.FLD11 CCY1,
               U.FLD12 CCY2
          INTO L_GITM_UPLOAD_DETAIL.FLD2,
               L_GITM_UPLOAD_DETAIL.FLD3,
               L_GITM_UPLOAD_DETAIL.FLD4,
               L_GITM_UPLOAD_DETAIL.FLD5,
               L_GITM_UPLOAD_DETAIL.FLD6,
               L_GITM_UPLOAD_DETAIL.FLD7,
               L_GITM_UPLOAD_DETAIL.FLD8,
               L_GITM_UPLOAD_DETAIL.FLD9,
               L_GITM_UPLOAD_DETAIL.FLD10,
               L_GITM_UPLOAD_DETAIL.FLD11,
               L_GITM_UPLOAD_DETAIL.FLD12
          FROM GITU_UPLOAD_DETAIL U
         WHERE RECORD_REFERENCE = EACH_REC.RECORD_REFERENCE
           AND ROWNUM = 1
           AND TARGET_TABLE = 'CYTMS_RATES';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
          ERRORS             := ERRORS || '~' || SQLERRM;
          L_ERROR_REFERENCES := L_ERROR_REFERENCES || '~' ||
                                EACH_REC.RECORD_REFERENCE;
          IS_DATA_VALID      := FALSE;
          debug.pr_debug('GI',
                         DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
      END;
    END LOOP;
    IF NOT IS_DATA_VALID THEN
      debug.pr_debug('GI',
                     'Records with  invalid data --> ' ||
                     L_ERROR_REFERENCES);
      debug.pr_debug('GI', 'Error code of invalid data --> ' || ERRORS);
      RETURN FALSE;
    END IF;
    FOR MASTER_REC IN CR_RATES_MASTER LOOP
      txnRef                                          := MASTER_REC.RECORD_REFERENCE;
      p_cydrates                                      := p_null_cydrates; --GIB Temp
      p_cydrates.rates_cytms_rates_master.BRANCH_CODE := MASTER_REC.BRNCODE;
      p_cydrates.rates_cytms_rates_master.CCY1        := MASTER_REC.CCY1;
      p_cydrates.rates_cytms_rates_master.CCY2        := MASTER_REC.CCY2;
    
      SELECT NVL(UPLOAD_MAKER, 'SYSTEM'), NVL(UPLOAD_CHECKER, 'SYSTEM')
        INTO p_cydrates.rates_cytms_rates_master.MAKER_ID,
             p_cydrates.rates_cytms_rates_master.CHECKER_ID
        FROM GITM_PARAMETER;
    
      FOR CHILD_REC IN CR_RATES(MASTER_REC.RECORD_REFERENCE) LOOP
        child_index := child_index + 1;
        p_cydrates.rates_cytms_rates(child_index).RATE_TYPE := CHILD_REC.RATETYPE;
        p_cydrates.rates_cytms_rates(child_index).MID_RATE := CHILD_REC.MIDRATE;
        p_cydrates.rates_cytms_rates(child_index).BUY_SPREAD := CHILD_REC.BUYSPREAD;
        p_cydrates.rates_cytms_rates(child_index).SALE_SPREAD := CHILD_REC.SALESPREAD;
        p_cydrates.rates_cytms_rates(child_index).BUY_RATE := CHILD_REC.BUYRATE;
        p_cydrates.rates_cytms_rates(child_index).SALE_RATE := CHILD_REC.SALERATE;
        p_cydrates.rates_cytms_rates(child_index).RATE_DATE := CHILD_REC.RATEDATE;
        p_cydrates.rates_cytms_rates(child_index).RATE_SERIAL := CHILD_REC.RATESERIAL;
        p_cydrates.rates_cytms_rates(child_index).BRANCH_CODE := CHILD_REC.BRANCHCODE;
        p_cydrates.rates_cytms_rates(child_index).CCY1 := CHILD_REC.CCY1;
        p_cydrates.rates_cytms_rates(child_index).CCY2 := CHILD_REC.CCY2;
      END LOOP;
      child_index := 0;
      BEGIN
        SAVEPOINT UPLOADPROCESS;
        IF NOT cypks_fcj_cydrates.Fn_Main('EXTSYS',
                                          'CYDRATES_AMEND',
                                          'MODIFY',
                                          l_multi_trip_id,
                                          p_cydrates,
                                          l_status,
                                          l_error_code,
                                          l_error_params) THEN
          RAISE e_Failure_Exception;
        END IF;
        UPDATE GITU_UPLOAD_MASTER
           SET STATUS      = 'P',
               ERROR       = l_error_code,
               ERROR_PARAM = l_error_params
         WHERE RECORD_REFERENCE = txnRef
           AND TARGET_TABLE = 'CYTMS_RATES_MASTER';
      EXCEPTION
        WHEN e_Failure_Exception THEN
          debug.pr_debug('GI',
                         DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
          p_status := 'E';
          ROLLBACK TO UPLOADPROCESS;
          UPDATE GITU_UPLOAD_MASTER
             SET STATUS      = 'E',
                 ERROR       = l_error_code,
                 ERROR_PARAM = l_error_params
           WHERE RECORD_REFERENCE = txnRef
             AND TARGET_TABLE = 'CYTMS_RATES_MASTER';
          p_err_code     := l_error_code;
          p_error_params := l_error_params;
        WHEN OTHERS THEN
          p_status := 'E';
          debug.pr_debug('GI',
                         DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
          ROLLBACK TO UPLOADPROCESS;
          UPDATE GITU_UPLOAD_MASTER
             SET STATUS      = 'E',
                 ERROR       = l_error_code,
                 ERROR_PARAM = l_error_params
           WHERE RECORD_REFERENCE = txnRef
             AND TARGET_TABLE = 'CYTMS_RATES_MASTER';
          p_err_code     := l_error_code;
          p_error_params := l_error_params;
      END;
      COMMIT;
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      p_status       := 'E';
      p_err_code     := 'GI-PRS-046';
      p_error_params := NULL;
      debug.pr_debug('GI', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM);
      RETURN FALSE;
  end fn_upload;

END GIPKS_IXCGRATE_UBS_txt;
/
