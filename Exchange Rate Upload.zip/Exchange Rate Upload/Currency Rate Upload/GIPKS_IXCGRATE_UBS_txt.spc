CREATE OR REPLACE PACKAGE GIPKS_IXCGRATE_UBS_txt IS


---- Author  : SYSTEM 
-- Created :  10-MAY-14
-- Purpose :  Dynamically Generated package to handle Incoming File - UBS_txt



 TYPE  ty_GITE_IXCGRATEUBS_txt1 IS TABLE OF GITE_IXCGRATEUBS_txt1%ROWTYPE INDEX BY BINARY_INTEGER; 
 TYPE  ty_GITE_IXCGRATEUBS_txt2 IS TABLE OF GITE_IXCGRATEUBS_txt2%ROWTYPE INDEX BY BINARY_INTEGER; 
 TYPE  ty_GITE_IXCGRATEUBS_txt3 IS TABLE OF GITE_IXCGRATEUBS_txt3%ROWTYPE INDEX BY BINARY_INTEGER; 
 TYPE  ty_GITE_IXCGRATEUBS_txt4 IS TABLE OF GITE_IXCGRATEUBS_txt4%ROWTYPE INDEX BY BINARY_INTEGER; 

 function fn_process_file(p_interface_code IN VARCHAR2,
                        p_file_name      IN VARCHAR2,
                        p_Phy_file_name     IN VARCHAR2,
                        p_ProcessRefNo      IN VARCHAR2,
                        p_err_code     IN OUT VARCHAR2,
                        p_err_params   IN OUT VARCHAR2,
                        p_status       IN OUT VARCHAR2)
  return BOOLEAN;

 function fn_upload(p_interface_code IN VARCHAR2,
                    p_file_name      IN VARCHAR2,
                    p_Phy_file_name     IN VARCHAR2,
                    p_ProcessRefNo      IN VARCHAR2,
                    p_process_no     IN NUMBER,
                    p_err_code     IN OUT VARCHAR2,
                    p_error_params IN OUT VARCHAR2,
                    p_status       IN OUT VARCHAR2)
 return BOOLEAN;
end GIPKS_IXCGRATE_UBS_txt;
/