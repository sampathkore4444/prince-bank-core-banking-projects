CREATE OR REPLACE PACKAGE BODY GIPKS_INTERFACE_TRIGGER IS

  G_INTERFACE_TYPE GITM_FORMAT_DEFINITION.INTERFACE_TYPE%TYPE;

  FUNCTION FN_SET_FILE_LOG(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                           P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                           P_BRN_CODE     IN VARCHAR2,
                           P_FILE_NAME    IN VARCHAR2,
                           P_PROCESS_DATE IN DATE,
                           P_SERIAL       IN OUT NUMBER,
                           P_FILE_STATUS  IN VARCHAR2,
                           P_ERR_CODE     IN OUT VARCHAR2,
                           P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_MOVE_FILE(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                        SRC_LOC  IN OUT VARCHAR2,
                        DEST_LOC IN OUT VARCHAR2,

                        SRC_FILE_NAME  IN VARCHAR2,
                        DEST_FILE_NAME IN VARCHAR2,
                        P_ERR_CODE     IN OUT VARCHAR2,
                        P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_MOVE_FILE_OUT(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                            SRC_LOC  IN OUT VARCHAR2,
                            DEST_LOC IN OUT VARCHAR2,

                            SRC_FILE_NAME  IN VARCHAR2,
                            DEST_FILE_NAME IN VARCHAR2,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_COPY_FILE(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                        SRC_LOC  IN OUT VARCHAR2,
                        DEST_LOC IN OUT VARCHAR2,

                        SRC_FILE_NAME  IN VARCHAR2,
                        DEST_FILE_NAME IN VARCHAR2,
                        P_ERR_CODE     IN OUT VARCHAR2,
                        P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;
  FUNCTION FN_GENERATE_CRC(P_DIRECTORY   IN VARCHAR2,
                           FILE_NAME     IN VARCHAR2,
                           CRC_VALUE     IN OUT VARCHAR2,
                           CRC_ALOGIRTHM IN VARCHAR2,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE(P_SOURCE      IN VARCHAR2,
                       P_ACTION_CODE IN VARCHAR2,
                       P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_CRC(P_SOURCE      IN VARCHAR2,
                           P_ACTION_CODE IN VARCHAR2,
                           P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                           P_PHYFNAME    IN VARCHAR2,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_UPDATE_LOG(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                         P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                         P_BRN_CODE     IN VARCHAR2,
                         P_FILE_NAME    IN VARCHAR2,
                         P_PROCESS_DATE IN DATE,
                         P_STATUS       IN VARCHAR2,
                         P_FILE_STATUS  IN VARCHAR2,
                         P_SERIAL       IN OUT NUMBER,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_UPDATE_FILENAME_OUTGOING(P_FILE_NAME  IN VARCHAR2,
                                       P_SERIAL     IN NUMBER,
                                       P_ERR_CODE   IN OUT VARCHAR2,
                                       P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_OUTGOING(P_SOURCE         IN VARCHAR2,
                                P_ACTION_CODE    IN VARCHAR2,
                                P_GIDIFPRS       IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FILE_LOG       IN GITB_FILE_LOG%ROWTYPE,
                                P_FORMAT_DETAILS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_INCOMING(P_SOURCE      IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_INCOMING_CRC(P_SOURCE      IN VARCHAR2,
                                    P_ACTION_CODE IN VARCHAR2,
                                    P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                    P_PHYFNAME    IN VARCHAR2,
                                    P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                    P_ERR_CODE    IN OUT VARCHAR2,
                                    P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_RETRY(P_SOURCE      IN VARCHAR2,
                             P_ACTION_CODE IN VARCHAR2,
                             P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                             P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                             P_ERR_CODE    IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_RETRY_ERROR(P_SOURCE      IN VARCHAR2,
                                   P_ACTION_CODE IN VARCHAR2,
                                   P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                   P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_IS_FILE_EXISTS(

                             FILE_PATH IN OUT VARCHAR2,

                             FILE_NAME    IN VARCHAR2,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_PROCESS_IN_FILE(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_ACTION_CODE IN VARCHAR2,
                              P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                              P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                              P_STATUS      IN OUT VARCHAR2,
                              P_ERR_CODE    IN OUT VARCHAR2,
                              P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_PROCESS_IN_UPLOAD(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_EXECUTIONS(P_SOURCE      IN VARCHAR2,
                                  P_ACTION_CODE IN VARCHAR2,
                                  P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                  P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                  P_ERR_CODE    IN OUT VARCHAR2,
                                  P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_UPDATE_PROCESS(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_ACTION_CODE IN VARCHAR2,
                             P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                             P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                             P_PROCESS_CNT IN NUMBER,
                             P_ERR_CODE    IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_GET_PROCESS_COUNT(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_PROCESS_CNT IN OUT NUMBER,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_PARALLEL_JOBS(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_LOG_SERIAL  IN NUMBER,
                            P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                            P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                            P_STATUS      IN OUT VARCHAR2,
                            P_ERR_CODE    IN OUT VARCHAR2,
                            P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_APPLY_MASK(P_FILE_NAME       IN OUT VARCHAR2,
                         P_MASK            IN OUT GITM_FORMAT_DEFINITION.PROCESSED_FILE_MASK%TYPE,
                         P_INTERFACE_CODE  IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE,
                         P_EXTERNAL_SYSTEM IN GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE,
                         P_BRANCH_CODE     IN GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE,
                         P_ERROR           IN OUT VARCHAR2,
                         P_ERR_PARAM       IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_WRITE_DATA_LOG(P_INTERFACE_CODE IN VARCHAR2,

                             FILE_PATH IN OUT VARCHAR2,

                             FILE_NAME IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_SET_FILE_LOG_FILEMASTER(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                      P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                      P_BRN_CODE     IN VARCHAR2,
                                      P_FILE_NAME    IN VARCHAR2,
                                      P_PROCESS_DATE IN DATE,
                                      P_SERIAL       IN NUMBER,
                                      P_FILE_STATUS  IN VARCHAR2,
                                      P_ERR_CODE     IN OUT VARCHAR2,
                                      P_ERR_PARAMS   IN OUT VARCHAR2,
                                      P_PHYFILE_NAME IN VARCHAR2)
    RETURN BOOLEAN;
  FUNCTION FN_WRITELOGTOFILE(P_INTERFACE_CODE IN VARCHAR2,
                             P_FILE_NAME      IN VARCHAR2,
                             P_PHY_FILE_NAME  IN VARCHAR2,
                             P_SERIAL         IN VARCHAR2,
                             P_LOG_OUTPUT     IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION ISVALIDFILEFORPROCESS(P_PHYFNAME  IN VARCHAR2,
                                 P_FILE_NAME IN VARCHAR2,
                                 P_FILE_MASK IN GITM_INTERFACE_DEFINITION.INCOMING_FILE_MASK%TYPE)
    RETURN BOOLEAN;

  PROCEDURE PR_RUN_PARALLEL_JOB(D_SQL          VARCHAR2,
                                L_JOB_NO       NUMBER,
                                I              NUMBER,
                                FILE_NAME      VARCHAR2,
                                INTERFACE_CODE VARCHAR2,
                                P_SERIAL       NUMBER,
                                P_ERR_CODE     VARCHAR2,
                                P_ERR_PARAMS   VARCHAR2);

  FUNCTION FN_UPDATE_INTERFACE_DEFINITION(P_BRANCH_CODE    IN GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE,
                                          P_INTERFACE_CODE IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE)
    RETURN BOOLEAN;

  FUNCTION FN_CREATE_DIRECTORY(P_SQL VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CREATE_DIRECTORY(P_SQL VARCHAR2) RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DEBUG.PR_DEBUG('GI', 'inside fn_create_directory');
    EXECUTE IMMEDIATE P_SQL;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('GI', 'failed in fn_create_directory - ' || SQLERRM);
      RETURN FALSE;
  END FN_CREATE_DIRECTORY;

  FUNCTION FN_UPDATE_ERR_FILE_LOG(P_SERIAL     IN NUMBER,
                                  P_ERR_CODE   IN VARCHAR2,
                                  P_ERR_PARAMS IN VARCHAR2) RETURN BOOLEAN;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := CURRENT_TIMESTAMP || '<<>>>' || 'Gipks_Interface_Trigger ==>' ||
             P_MSG;
    DEBUG.PR_DEBUG('GI', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_SOURCE     VARCHAR2,
                         P_ERR_CODE   VARCHAR2,
                         P_ERR_PARAMS VARCHAR2) IS
    L_FUNCTION_ID SMTB_MENU.FUNCTION_ID%TYPE := 'GIDIFPRS';
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 L_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  FUNCTION FN_WRITE_DATA_LOG(P_INTERFACE_CODE IN VARCHAR2,

                             FILE_PATH IN OUT VARCHAR2,

                             FILE_NAME IN VARCHAR2) RETURN BOOLEAN IS

    FID        UTL_FILE.FILE_TYPE;
    L_DIR_NAME ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;

    LINE         VARCHAR2(32767);
    L_TIME_STAMP DATE := FN_HOSTDATETIME;
    SERIAL       NUMBER := 1;
    PK           VARCHAR2(50);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    P_ERR_CODE              VARCHAR2(20);
    P_ERR_PARAMS            VARCHAR2(255);
    L_DEST_LOC              VARCHAR2(500);

  BEGIN

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_GET_DIRECTORY_NAME('',
                                                               FILE_PATH,
                                                               L_DEST_LOC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGERCLUSTER.FN_WRITE_DATA_LOG');
        RETURN FALSE;
      END IF;
    END IF;

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      FID := UTL_FILE.FOPEN(FILE_PATH, FILE_NAME, 'R');

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(FILE_PATH,
                                                   L_DIR_NAME,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      FID := UTL_FILE.FOPEN(L_DIR_NAME, FILE_NAME, 'R');
    END IF;

    SAVEPOINT INSERT_DATA_LOG;
    BEGIN
      DBMS_OUTPUT.PUT_LINE(FILE_NAME);
      LOOP
        UTL_FILE.GET_LINE(FID, LINE);

        PK := TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYDDDHHMMSS') || 'GBDL' ||
              LPAD(SEQ_GITB_DATA_LOG.NEXTVAL, 28, 0);

        INSERT INTO GITB_DATA_LOG
          (FILE_NAME,
           LINE,
           TIME_STAMP,
           SERIAL,
           INTERFACE_CODE,
           PK_SERIAL_NO)
        VALUES
          (FILE_NAME, LINE, L_TIME_STAMP, SERIAL, P_INTERFACE_CODE, PK);
        SERIAL := SERIAL + 1;
        DBMS_OUTPUT.PUT_LINE(LINE);

      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        UTL_FILE.FCLOSE(FID);
    END;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Writin Data Log Failed  ' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      ROLLBACK TO INSERT_DATA_LOG;
      RETURN FALSE;
  END FN_WRITE_DATA_LOG;

  FUNCTION FN_VALIDATE(P_SOURCE      IN VARCHAR2,
                       P_ACTION_CODE IN VARCHAR2,
                       P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                       P_ERR_CODE    IN OUT VARCHAR2,
                       P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN

   IS
    L_COUNT       NUMBER;
    P_FORMAT_DTLS GITM_INTERFACE_DEFINITION%ROWTYPE;
    P_FILE_LOG    GITB_FILE_LOG%ROWTYPE;
  BEGIN

    DBG('In fn_validate');
    DBG('2. Validating Interface Definition Details..');
    BEGIN
      SELECT *
        INTO P_FORMAT_DTLS
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND EXTERNAL_SYSTEM =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

      IF G_ALL_DIR_FILE_PATH IS NOT NULL THEN
        P_FORMAT_DTLS.FILE_PATH := G_ALL_DIR_FILE_PATH;
      END IF;

      P_FORMAT_DTLS.CRC_FILE_PATH          := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) || 'crc';
      P_FORMAT_DTLS.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) ||
                                              'confirmation';
      DBG('cRC fILE PATH...' || P_FORMAT_DTLS.CRC_FILE_PATH);
      DBG('Confirmation FILE PATH...' ||
          P_FORMAT_DTLS.CONFIRMATION_FILE_PATH);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed In Validation Interface details...');
        P_ERR_CODE   := 'GI-PRS-002';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG('Interface Definition Details Record is Not Authorized');
        RETURN FALSE;
    END;

    DBG('Validation For Incoming/Outgoing Process Starts....');
    DBG('Interface Code ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('External System ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM);
    DBG('Interface TYpe ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE);

    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'O' THEN
      DBG('Interface type is Outgoing');
      BEGIN
        SELECT *
          INTO P_FILE_LOG
          FROM GITB_FILE_LOG
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
           AND START_DATE_STAMP =
               (SELECT MAX(START_DATE_STAMP)
                  FROM GITB_FILE_LOG
                 WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                   AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                   AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE)
           AND PK_SERIAL_NO =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PK_SERIAL_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in Selecting Details From File Log.....');
      END;

      IF P_FILE_LOG.STATUS IS NOT NULL THEN
        IF NOT FN_VALIDATE_OUTGOING(P_SOURCE,
                                    P_ACTION_CODE,
                                    P_GIDIFPRS,
                                    P_FILE_LOG,
                                    P_FORMAT_DTLS,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
          DBG('Failed in Validation of Outgoing process..');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'I' THEN
      DBG('Interface type is Incoming');

      IF NOT FN_VALIDATE_INCOMING(P_SOURCE,
                                  P_ACTION_CODE,
                                  P_GIDIFPRS,
                                  P_FORMAT_DTLS,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Failed in Validation of Incoming process..' || SQLERRM);
        DBG('Error>>>>>>>>>>>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

    END IF;
    DBG('Returning Success from fn_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE;

  FUNCTION FN_VALIDATE_CRC(P_SOURCE      IN VARCHAR2,
                           P_ACTION_CODE IN VARCHAR2,
                           P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                           P_PHYFNAME    IN VARCHAR2,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN

   IS
    L_COUNT       NUMBER;
    P_FORMAT_DTLS GITM_INTERFACE_DEFINITION%ROWTYPE;
    P_FILE_LOG    GITB_FILE_LOG%ROWTYPE;

  BEGIN

    DBG('In fn_validate_crc');

    DBG('2. Validating Interface Definition Details..');
    BEGIN
      SELECT *
        INTO P_FORMAT_DTLS
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND EXTERNAL_SYSTEM =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

      IF G_ALL_DIR_FILE_PATH IS NOT NULL THEN
        P_FORMAT_DTLS.FILE_PATH := G_ALL_DIR_FILE_PATH;
      END IF;

      P_FORMAT_DTLS.CRC_FILE_PATH          := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) || 'crc';
      P_FORMAT_DTLS.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) ||
                                              'confirmation';
      DBG('cRC fILE PATH...' || P_FORMAT_DTLS.CRC_FILE_PATH);
      DBG('Confirmation FILE PATH...' ||
          P_FORMAT_DTLS.CONFIRMATION_FILE_PATH);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed In Validation Interface details...');
        P_ERR_CODE   := 'GI-PRS-002';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;

        DBG('Interface Definition Details Record is Not Authorized');
        RETURN FALSE;
    END;

    DBG('Validation For Incoming/Outgoing Process Starts....');
    DBG('Interface Code ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('External System ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM);
    DBG('Interface TYpe ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE);

    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'I' AND
       (P_FORMAT_DTLS.CRC_REQUIRED = 'Y' OR
       P_FORMAT_DTLS.CONFIRM_FILE_REQD = 'Y') THEN
      DBG('Interface type is Incoming');

      IF NOT FN_VALIDATE_INCOMING_CRC(P_SOURCE,
                                      P_ACTION_CODE,
                                      P_GIDIFPRS,
                                      P_PHYFNAME,
                                      P_FORMAT_DTLS,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DBG('Failed in Validation of Incoming process..' || SQLERRM);
        DBG('Error>>>>>>>>>>>' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;
      END IF;

    END IF;
    DBG('Returning Success from fn_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_validate_crc ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_CRC;

  FUNCTION FN_TRIGGER_PROCESS(P_SOURCE       IN VARCHAR2,
                              P_ACTION_CODE  IN VARCHAR2,
                              P_WRK_GIDIFPRS IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                              P_ERR_CODE     IN OUT VARCHAR2,
                              P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    E_FAILURE_EXCEPTION EXCEPTION;
    L_FORMAT GITM_FORMAT_DEFINITION%ROWTYPE;
  BEGIN
    DBG('In fn_trigger_process');

    DBG('Validation Starts From here....');
    DBG('p_wrk_gidifprs.ifprs_gitm_interface_trigger.process_code = ' ||
        P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);

    G_ALL_DIR_FILE_PATH := NULL;
    BEGIN
      SELECT *
        INTO L_FORMAT
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE =
             P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

      G_ALL_DIR_FILE_PATH := NULL;

      DBG('l_format.interface_code :: ' || L_FORMAT.INTERFACE_CODE);
      DBG('26188512 :: p_Wrk_Gidifprs.Ifprs_Gitm_Interface_Trigger.Interface_Type :: ' ||
          P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE);
      G_INTERFACE_TYPE := P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE;
      DBG('p_wrk_gidifprs.ifprs_gitm_interface_trigger.interface_code :: ' ||
          P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
      GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE := P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;

      BEGIN

        SELECT DIRECTORY_PATH
          INTO G_ALL_DIR_FILE_PATH
          FROM ALL_DIRECTORIES
         WHERE DIRECTORY_NAME = L_FORMAT.FILE_PATH;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('File path maintained is not present in ');
          G_ALL_DIR_FILE_PATH := NULL;
      END;

      DBG('g_all_dir_file_path...' || G_ALL_DIR_FILE_PATH);
      IF L_FORMAT.INTERFACE_TYPE = 'I' THEN
        G_ALL_DIR_FILE_PATH := SUBSTR(G_ALL_DIR_FILE_PATH,
                                      0,
                                      INSTR(G_ALL_DIR_FILE_PATH,
                                            GLOBAL.SLASH,
                                            -1) - 1);
      END IF;
      L_FORMAT.FILE_PATH := G_ALL_DIR_FILE_PATH;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('File path maintained is not present in ');
        G_ALL_DIR_FILE_PATH := NULL;
    END;

    IF P_ACTION_CODE = 'DEFAULT' OR P_ACTION_CODE = 'NEW' THEN
      IF NOT FN_VALIDATE(P_SOURCE,
                         P_ACTION_CODE,
                         P_WRK_GIDIFPRS,
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
        DBG('Failed in Triggering Process validations...');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Validation Ends Successfully....');

    IF P_ACTION_CODE = 'CUSTOM' OR P_ACTION_CODE = 'NEW' THEN
      DBG('Calling Incoming or Outgoing Process...');
      IF P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'O' THEN
        DBG('Calling Outgoing Process....');
        IF NOT FN_PROCESS_OUTGOING(P_SOURCE,
                                   P_ACTION_CODE,
                                   P_WRK_GIDIFPRS,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
          DBG('Failed in fn_process_outgoing');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

      IF P_WRK_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'I' THEN
        DBG('Calling Incoming process....');
        IF NOT FN_PROCESS_INCOMING(P_SOURCE,
                                   P_ACTION_CODE,
                                   P_WRK_GIDIFPRS,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
          DBG('Failed in fn_process_incoming');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
      DBG('Processed Successfully.....');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('From E_Failure_Exception of fn_trigger_process');
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_trigger_process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_TRIGGER_PROCESS;

  FUNCTION FN_PROCESS_INCOMING(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_ACTION_CODE IN VARCHAR2,
                               P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    P_FORMAT_DTLS      GITM_FORMAT_DEFINITION%ROWTYPE;
    P_BRANCH_CODE      GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE;
    P_EXT_SYSTEM       GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE;
    P_INTERFACE_CODE   GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE;
    P_FILE_NAME        GITM_FILE_NAMES.FILE_NAME%TYPE;
    SRC_LOC            VARCHAR2(200);
    SRC_FILE_NAME      VARCHAR2(200);
    DEST_LOC           VARCHAR2(200);
    DEST_FILE_NAME     VARCHAR2(200);
    L_OPERATING_SYSTEM VARCHAR2(20);
    L_DIR_SEP          VARCHAR2(1);
    F_PROG             VARCHAR2(32767);
    F_SQL              VARCHAR2(32767);
    D_PROG             VARCHAR2(32767);
    D_SQL              VARCHAR2(32767);
    L_MODULE           VARCHAR2(2) := 'GI';
    E_FAILURE_EXCEPTION EXCEPTION;
    P_STATUS VARCHAR2(1);

    FP_STATUS         BOOLEAN := FALSE;
    L_IN_FILE_PATH    VARCHAR2(1000);
    L_IN_CRC_PATH     VARCHAR2(1000);
    L_IN_CONF_PATH    VARCHAR2(1000);
    L_IN_DIR          VARCHAR2(100);
    L_TYPE_STRING     VARCHAR2(2);
    L_ROUTING_TYPE    VARCHAR2(2);
    P_OUT_FORMAT_DTLS GITM_FORMAT_DEFINITION%ROWTYPE;
    P_OUT_GIDIFPRS    GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS;

    STATUS                  VARCHAR2(20);
    L_PROCESS_CODE          VARCHAR2(20);
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  BEGIN

    DBG('In fn_process_incoming');
    BEGIN
      SELECT *
        INTO P_FORMAT_DTLS
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND EXTERNAL_SYSTEM =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

      IF G_ALL_DIR_FILE_PATH IS NOT NULL THEN
        P_FORMAT_DTLS.FILE_PATH := G_ALL_DIR_FILE_PATH;
      END IF;

      P_FORMAT_DTLS.CRC_FILE_PATH          := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) || 'crc';
      P_FORMAT_DTLS.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) ||
                                              'confirmation';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed In Fetching Interface details...');
        P_ERR_CODE   := 'GI-PRS-002';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;

    END;
    G_CUSTOM_LOGGING := P_FORMAT_DTLS.CUSTOM_LOGGING;
    L_IN_FILE_PATH   := P_FORMAT_DTLS.FILE_PATH;
    L_IN_CRC_PATH    := P_FORMAT_DTLS.CRC_FILE_PATH;
    L_IN_CONF_PATH   := P_FORMAT_DTLS.CONFIRMATION_FILE_PATH;

    DBG('Action Code' || P_ACTION_CODE);

    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE = 'I' THEN

      DBG('calling custom code to get incoming file in ready folder');
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DEBUG.PR_DEBUG('GI',
                       'Calling Gipks_Interface_Triggercluster.Fn_Process_Incoming');
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_INCOMING(P_SOURCE,
                                                               P_ACTION_CODE,
                                                               P_GIDIFPRS,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('IS',
                         'Failed in Gipks_Interface_Triggercluster.Fn_Process_Incoming***please check');
          RETURN FALSE;
        END IF;
      END IF;

      DBG('Started Processing for Incoming Files');
      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'RT' THEN
        DBG('pROCESSING FOR RT');
        DBG('TAKING THE PROCESS CODE FROM GITB FILE LOG');
        BEGIN
          SELECT STATUS, PROCESS_CODE
            INTO STATUS, L_PROCESS_CODE
            FROM GITB_FILE_LOG
           WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
             AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
             AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
             AND FILE_NAME =
                 P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
             AND START_DATE_STAMP =
                 (SELECT MAX(START_DATE_STAMP)
                    FROM GITB_FILE_LOG
                   WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                     AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                     AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                     AND FILE_NAME =
                         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('File $1 of Interface $2 was not processed today to Initiate Retry Process');
            P_ERR_CODE   := 'GI-PRS-025';
            P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                            P_FORMAT_DTLS.INTERFACE_CODE;
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
        END;
        DBG('CURRENT STATUS IS = ' || STATUS);
        DBG('CURRENT PROCESS CODE  IS = ' || L_PROCESS_CODE);
        DBG('CHANGING PROCESS CODE TO CURRENT PROCESS CODE ');
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := L_PROCESS_CODE;

        IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'FP' THEN
          DBG('Calling Process for FP Processs...FOR RETRY ');
          IF NOT FN_PROCESS_IN_FILE(P_SOURCE,
                                    P_ACTION_CODE,
                                    P_GIDIFPRS,
                                    P_FORMAT_DTLS,
                                    P_STATUS,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
            DBG('Failed in FP Process...');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END IF;

        IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP' THEN
          DBG('Calling Process for DP Process....FOR RETRY ');
          IF NOT FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                      P_ACTION_CODE,
                                      P_GIDIFPRS,
                                      P_FORMAT_DTLS,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
            DBG('Failed in DP Process...');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END IF;
        DBG('pROCESSING FOR RT END HERE ');
      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'FP' THEN
        DBG('Calling Process for FP Processs...');
        IF NOT FN_PROCESS_IN_FILE(P_SOURCE,
                                  P_ACTION_CODE,
                                  P_GIDIFPRS,
                                  P_FORMAT_DTLS,
                                  P_STATUS,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
          DBG('Failed in FP Process...');
          RETURN FALSE;
        END IF;

      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP' THEN
        DBG('Calling Process for DP Process....');
        IF NOT FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                    P_ACTION_CODE,
                                    P_GIDIFPRS,
                                    P_FORMAT_DTLS,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
          DBG('Failed in DP Process...');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'AL' THEN
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := 'FP';

        DBG('Calling Process for AL Process....');
        IF NOT FN_PROCESS_IN_FILE(P_SOURCE,
                                  P_ACTION_CODE,
                                  P_GIDIFPRS,
                                  P_FORMAT_DTLS,
                                  P_STATUS,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
          DBG('Failed in FP Process...');
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := 'AL';
          RETURN FALSE;

        END IF;

        DBG('p_status in AL process after fn_process_in_file = ' ||
            P_STATUS);

        DBG('Before calling Gipks_Interface_Triggercluster:' ||
            GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '<>' ||
            GIPKS_INTERFACE_TRIGGER.G_SERIAL || '<>' ||
            GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          DEBUG.PR_DEBUG('GI',
                         'Calling Gipks_Interface_Triggercluster.Fn_Process_Incoming');
          L_FN_CALL_ID      := 3;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_INCOMING(P_SOURCE,
                                                                 P_ACTION_CODE,
                                                                 P_GIDIFPRS,
                                                                 P_ERR_CODE,
                                                                 P_ERR_PARAMS,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
            DEBUG.PR_DEBUG('IS',
                           'Failed in Gipks_Interface_Triggercluster.Fn_Process_Incoming***please check');
            RETURN FALSE;
          END IF;
        END IF;
        DBG('Done with Gipks_Interface_Triggercluster');

        IF P_STATUS <> 'E' THEN

          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := 'DP';
          IF NOT FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                      P_ACTION_CODE,
                                      P_GIDIFPRS,
                                      P_FORMAT_DTLS,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
            DBG('Failed in DP Process...');
            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := 'AL';
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

        ELSE

          DBG('Failed in FP Process cannot proceed with D Process...');
        END IF;
      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'RE' THEN
        DBG('Calling Process for RE Process....');
        IF NOT FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                    P_ACTION_CODE,
                                    P_GIDIFPRS,
                                    P_FORMAT_DTLS,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
          DBG('Failed in DP Process...');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

      DBG('Before calling Gipks_Interface_Triggercluster:' ||
          GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '<>' ||
          GIPKS_INTERFACE_TRIGGER.G_SERIAL || '<>' ||
          GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DEBUG.PR_DEBUG('GI',
                       'Calling Gipks_Interface_Triggercluster.Fn_Process_Incoming');
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_INCOMING(P_SOURCE,
                                                               P_ACTION_CODE,
                                                               P_GIDIFPRS,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
          DEBUG.PR_DEBUG('IS',
                         'Failed in Gipks_Interface_Triggercluster.Fn_Process_Incoming***please check');
          RETURN FALSE;
        END IF;
      END IF;
      DBG('Done with Gipks_Interface_Triggercluster');

      DBG('Calling Generation of Exception File for Incoming Intereface..' ||
          P_FORMAT_DTLS.INTERFACE_CODE);
      IF P_FORMAT_DTLS.OUTGOING_INTERFACE IS NOT NULL AND
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP' THEN
        DBG('Calling Generation of Exception File for Incoming Intereface..' ||
            P_FORMAT_DTLS.INTERFACE_CODE);
        BEGIN
          SELECT *
            INTO P_OUT_FORMAT_DTLS
            FROM GITM_FORMAT_DEFINITION
           WHERE INTERFACE_CODE = P_FORMAT_DTLS.OUTGOING_INTERFACE;
          P_FORMAT_DTLS.CRC_FILE_PATH          := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                         0,
                                                         INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                               GLOBAL.SLASH,
                                                               -1)) ||
                                                  'crc';
          P_FORMAT_DTLS.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                         0,
                                                         INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                               GLOBAL.SLASH,
                                                               -1)) ||
                                                  'confirmation';
        END;
        P_OUT_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE  := P_OUT_FORMAT_DTLS.INTERFACE_CODE;
        P_OUT_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE     := P_OUT_FORMAT_DTLS.BRANCH_CODE;
        P_OUT_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM := P_OUT_FORMAT_DTLS.EXTERNAL_SYSTEM;
        P_OUT_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE  := 'O';
        P_OUT_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.STATUS          := 'W';
        DBG('-------------------------------------BEGIN OF EXCEPTION FILE GENERATION CALL------------------------------------------------------------------------------------');
        IF NOT FN_PROCESS_OUTGOING(P_SOURCE,
                                   P_ACTION_CODE,
                                   P_OUT_GIDIFPRS,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
          DBG('Failed in fn_process_outgoing');
          P_ERR_CODE   := 'GI-PRS-039';
          P_ERR_PARAMS := P_FORMAT_DTLS.OUTGOING_INTERFACE;
          DBG('Failed in Generating Exception File for interface $1');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RAISE E_FAILURE_EXCEPTION;

          RETURN FALSE;
        END IF;
        DBG('-------------------------------------END OF EXCEPTION FILE GENERATION CALL------------------------------------------------------------------------------------');

      END IF;
      DBG('Finished Generation of Exception File for Incoming Intereface successfully' ||
          P_FORMAT_DTLS.INTERFACE_CODE);

    END IF;

    DBG('Returning Success from fn_process_incoming');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DEBUG.PR_DEBUG('GI',
                     'From E_Failure_Exception of GIPKS_INTERFACE_TRIGGER.fn_process_incoming');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'ST-MSRV-001';
        P_ERR_PARAMS := NULL;
      END IF;

      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_process_incoming ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      RETURN FALSE;
  END FN_PROCESS_INCOMING;

  FUNCTION FN_PROCESS_OUTGOING(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                               P_ACTION_CODE IN VARCHAR2,
                               P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    P_FILE_LOG       GITB_FILE_LOG%ROWTYPE;
    P_FORMAT_DTLS    GITM_FORMAT_DEFINITION%ROWTYPE;
    P_BRANCH_CODE    GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE;
    P_EXT_SYSTEM     GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE;
    P_INTERFACE_CODE GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE;
    P_FILE_NAME      GITM_FILE_NAMES.FILE_NAME%TYPE;
    PKG_NAME         VARCHAR2(1000);
    PKG_ERR_CODE     VARCHAR2(255);
    PKG_ERR_PARAMS   VARCHAR2(255);

    SRC_LOC            VARCHAR2(200);
    SRC_FILE_NAME      VARCHAR2(200);
    DEST_LOC           VARCHAR2(200);
    DEST_FILE_NAME     VARCHAR2(200);
    L_OPERATING_SYSTEM VARCHAR2(20);
    L_DIR_SEP          VARCHAR2(1);
    L_PROG             VARCHAR2(32767);
    L_SQL              VARCHAR2(32767);
    L_MODULE           VARCHAR2(2) := 'GI';
    E_FAILURE_EXCEPTION EXCEPTION;
    P_STATUS VARCHAR2(1);

    CONF_FILE_DIR    VARCHAR2(1000);
    CONF_FILE_GRANTS VARCHAR2(1000);
    DIR_NAME         VARCHAR2(100);
    CONF_FILE_NAME   VARCHAR2(100);
    CONF_MSG         CLOB;
    CONF_MODE        VARCHAR2(1);
    CONF_TYPE        VARCHAR2(10);
    CONF_GROUP       VARCHAR2(10);

    CRC_FILE_DIR            VARCHAR2(1000);
    CRC_FILE_GRANTS         VARCHAR2(1000);
    L_CRC_INDEX             NUMBER;
    L_CRC_GRN_INDEX         NUMBER;
    CRC_DIR_NAME            VARCHAR2(100);
    CRC_FILE_NAME           VARCHAR2(100);
    CRC_MSG                 CLOB;
    CRC_MODE                VARCHAR2(1);
    CRC_TYPE                VARCHAR2(10);
    CRC_GROUP               VARCHAR2(10);
    CRC_VALUE               VARCHAR2(100);
    L_OUT_FILE_PATH         VARCHAR2(1000);
    L_OUT_DIRECTORY         VARCHAR2(1000);
    L_OUT_CRC_PATH          VARCHAR2(1000);
    L_OUT_CONF_PATH         VARCHAR2(1000);
    L_CONF_FILE_TYPE        UTL_FILE.FILE_TYPE;
    P_SERIAL                NUMBER;
    C_SQL                   VARCHAR2(32767);
    CRC_SQL                 VARCHAR2(32767);
    L_CURSOR                NUMBER;
    L_RETURN                NUMBER;
    L_FILE_NAME             VARCHAR2(100);
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_DIR_NAME              ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;
  BEGIN

    DBG('In fn_process_outgoing');
    BEGIN
      SELECT *
        INTO P_FORMAT_DTLS
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND EXTERNAL_SYSTEM =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';

      IF G_ALL_DIR_FILE_PATH IS NOT NULL THEN
        P_FORMAT_DTLS.FILE_PATH := G_ALL_DIR_FILE_PATH;
      END IF;

      P_FORMAT_DTLS.CRC_FILE_PATH          := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) || 'crc';
      P_FORMAT_DTLS.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                                     0,
                                                     INSTR(P_FORMAT_DTLS.FILE_PATH,
                                                           GLOBAL.SLASH,
                                                           -1)) ||
                                              'confirmation';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed In Fetching Interface details...');
        P_ERR_CODE   := 'GI-PRS-002';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

    END;
    DBG('Insert into File Log');

    P_SERIAL := GISQ_FILE_LOG.NEXTVAL;

    IF NOT FN_SET_FILE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           P_FORMAT_DTLS.BRANCH_CODE,
                           L_FILE_NAME,
                           GLOBAL.APPLICATION_DATE,
                           P_SERIAL,
                           'U',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Failed in Inserting into File Log');
      RETURN FALSE;
    END IF;
    DBG('Serial Number generated....' || P_SERIAL);
    GIPKS_INTERFACE_TRIGGER.G_SERIAL := P_SERIAL;
    DBG('Action Code' || P_ACTION_CODE);
    G_BRANCH_CODE := P_FORMAT_DTLS.BRANCH_CODE;
    DBG('Interface Type ....' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE);

    DBG('Started Processing of Outgoing Files');
    BEGIN
      IF NOT FN_UPDATE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           G_BRANCH_CODE,
                           G_FILE_NAME,
                           GLOBAL.APPLICATION_DATE,
                           'U',
                           'W',
                           P_SERIAL,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('Failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
         G_CUSTOM_LOGGING = 'Y' THEN
        DBG('Before the call to cluster package');
        IF NOT GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                            'W',
                                                            P_SERIAL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

          DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
          RETURN FALSE;
        END IF;
        DBG('after the call to cluster package');
      END IF;

      GIPKS_INTERFACE_TRIGGER.G_SERIAL := P_SERIAL;
      P_INTERFACE_CODE                 := P_FORMAT_DTLS.INTERFACE_CODE;
      G_INTERFACE_CODE                 := P_FORMAT_DTLS.INTERFACE_CODE;
      G_BRANCH_CODE                    := P_FORMAT_DTLS.BRANCH_CODE;
      G_EXTERNAL_SYSTEM                := P_FORMAT_DTLS.EXTERNAL_SYSTEM;
      G_SOURCE                         := P_SOURCE;
      L_PROG                           := L_MODULE || 'PKS_' ||
                                          P_INTERFACE_CODE || '.FN_HANDOFF';
      DBG('Package Name ' || L_PROG);

      L_SQL := 'DECLARE ' || CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_err_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_code;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_err_params     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_params;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_brn_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_branch_code;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_intf_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_interface_code;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_ext_system      varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_external_system;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_file_name      varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_file_name;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_source      varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_source;  ' ||
               CHR(10);
      L_SQL := L_SQL || ' ' ||
               'l_status          varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_status;  ' ||
               CHR(10);
      L_SQL := L_SQL || 'BEGIN' || CHR(10);
      L_SQL := L_SQL || 'IF NOT ' || L_PROG ||
               '(l_brn_code, l_intf_code, l_ext_system, l_source, l_file_name, l_err_code, l_err_params, l_status)  THEN ' ||

               CHR(10);
      L_SQL := L_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := FALSE;' ||
               CHR(10);
      L_SQL := L_SQL || 'END IF;' || CHR(10);
      L_SQL := L_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status:=l_status;' ||
               CHR(10);
      L_SQL := L_SQL || 'GIPKS_INTERFACE_TRIGGER.g_file_name:=l_file_name;' ||
               CHR(10);
      L_SQL := L_SQL || 'END;' || CHR(10);

      DBG('DYNAMIC SQL...');
      DBG(L_SQL);
      BEGIN
        EXECUTE IMMEDIATE L_SQL;

        IF NOT
            FN_UPDATE_INTERFACE_DEFINITION(P_FORMAT_DTLS.BRANCH_CODE,
                                           P_FORMAT_DTLS.INTERFACE_CODE) THEN
          DBG('FAILED IN UPDATING interface definition table');

        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('GI', SQLERRM);
          IF NOT FN_UPDATE_LOG(P_SOURCE,
                               P_GIDIFPRS,
                               G_BRANCH_CODE,
                               G_FILE_NAME,
                               GLOBAL.APPLICATION_DATE,
                               'W',
                               'E',
                               P_SERIAL,
                               G_ERR_CODE,
                               G_ERR_PARAMS) THEN
            DBG('failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
          RAISE E_FAILURE_EXCEPTION;
          RETURN FALSE;

          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
             G_CUSTOM_LOGGING = 'Y' THEN
            DBG('Before the call to cluster package');
            IF NOT
                GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                             'E',
                                                             P_SERIAL,
                                                             G_ERR_CODE,
                                                             G_ERR_PARAMS) THEN

              DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
              RETURN FALSE;
            END IF;
            DBG('after the call to cluster package');
          END IF;

      END;

    END;
    DBG('Status of Outgoing Package Call....' || G_STATUS);
    DBG('Error Codes...' || G_ERR_CODE);
    DBG('Error params...' || G_ERR_PARAMS);
    P_STATUS     := G_STATUS;
    P_ERR_CODE   := G_ERR_CODE;
    P_ERR_PARAMS := G_ERR_PARAMS;
    IF NOT G_RETURN OR P_STATUS = 'E' THEN
      DBG('Function Id package ' || L_PROG || ' has returned False..');
      IF P_STATUS = 'E' THEN
        DBG('Failed in generation of outgoing file for interface code' ||
            P_INTERFACE_CODE || ' FILE :' || G_FILE_NAME);
        IF NOT FN_UPDATE_LOG(P_SOURCE,
                             P_GIDIFPRS,
                             G_BRANCH_CODE,
                             G_FILE_NAME,
                             GLOBAL.APPLICATION_DATE,
                             'W',
                             'E',
                             P_SERIAL,
                             G_ERR_CODE,
                             G_ERR_PARAMS) THEN
          DBG('failed in Updating the Log');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
           G_CUSTOM_LOGGING = 'Y' THEN
          DBG('Before the call to cluster package');
          IF NOT
              GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                           'E',
                                                           P_SERIAL,
                                                           G_ERR_CODE,
                                                           G_ERR_PARAMS) THEN

            DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
            RETURN FALSE;
          END IF;
          DBG('after the call to cluster package');
        END IF;

        IF NOT FN_UPDATE_FILENAME_OUTGOING(G_FILE_NAME,
                                           P_SERIAL,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
          DBG('Failed in GIPKS_INTERFACE_TRIGGER.fn_update_filename_outgoing');
        END IF;

      END IF;
      RETURN FALSE;

    END IF;
    IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'S' THEN
      DBG('Successfull in Outgoing Process');
      DBG('Moving the file from WIP Folder to Ready -->' || G_FILE_NAME);

      L_OUT_FILE_PATH := P_FORMAT_DTLS.FILE_PATH;
      L_OUT_CRC_PATH  := P_FORMAT_DTLS.CRC_FILE_PATH;
      L_OUT_CONF_PATH := P_FORMAT_DTLS.CONFIRMATION_FILE_PATH;


   IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        SRC_LOC  := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';
        DEST_LOC := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath
        SRC_LOC  := 'XRUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';
        DEST_LOC := 'XRUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';
      END IF; --sampath


      SRC_FILE_NAME  := G_FILE_NAME;
      DEST_FILE_NAME := G_FILE_NAME;

      IF NOT FN_UPDATE_FILENAME_OUTGOING(G_FILE_NAME,
                                         P_SERIAL,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGER.fn_update_filename_outgoing');
      END IF;

      IF NOT FN_MOVE_FILE_OUT(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('FAILED IN MOVING FILE FROM WIP TO READY FOLDER');
      END IF;
      IF NVL(P_FORMAT_DTLS.DATA_LOG_REQD, 'N') = 'Y' THEN


  IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
          --sampath
          SRC_LOC  := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';
          DEST_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

        ELSE
          --sampath
          SRC_LOC  := 'XRUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';
          DEST_LOC := 'XRUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';
        END IF; --sampath
        BEGIN
          IF NOT FN_WRITE_DATA_LOG(P_FORMAT_DTLS.INTERFACE_CODE,
                                   SRC_LOC,
                                   SRC_FILE_NAME) THEN
            DBG('FAILED IN INSERTING INTO DATA LOG....');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Exception raised in calling the function fn_write_data_log' ||
                SQLERRM);
            DBG('failed at : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
        SRC_FILE_NAME  := G_FILE_NAME;
        DEST_FILE_NAME := G_FILE_NAME || '.LOG';
        IF NOT FN_COPY_FILE(P_SOURCE,
                            SRC_LOC,
                            DEST_LOC,
                            SRC_FILE_NAME,
                            DEST_FILE_NAME,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
          DBG('FAILED IN copying FILE FROM READY to wip FOLDER');
        END IF;
      END IF;
      DBG('Updating file log status');
      IF NOT FN_UPDATE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           G_BRANCH_CODE,
                           G_FILE_NAME,
                           GLOBAL.APPLICATION_DATE,
                           'W',
                           'P',
                           P_SERIAL,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
         G_CUSTOM_LOGGING = 'Y' THEN
        DBG('Before the call to cluster package');
        IF NOT GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                            'P',
                                                            P_SERIAL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

          DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
          RETURN FALSE;
        END IF;
        DBG('after the call to cluster package');
      END IF;

    ELSE
      DBG('Failed in generation of outgoing file for interface code' ||
          P_INTERFACE_CODE || '---' || G_FILE_NAME);
      IF NOT FN_UPDATE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           G_BRANCH_CODE,
                           G_FILE_NAME,
                           GLOBAL.APPLICATION_DATE,
                           'W',
                           'E',
                           P_SERIAL,
                           G_ERR_CODE,
                           G_ERR_PARAMS) THEN
        DBG('Failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
         G_CUSTOM_LOGGING = 'Y' THEN
        DBG('Before the call to cluster package');
        IF NOT GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                            'E',
                                                            P_SERIAL,
                                                            G_ERR_CODE,
                                                            G_ERR_PARAMS) THEN

          DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
          RETURN FALSE;
        END IF;
        DBG('after the call to cluster package');
      END IF;

    END IF;

    IF P_STATUS = 'S' AND P_FORMAT_DTLS.CONFIRM_FILE_REQD = 'Y' THEN
      DBG('going to generate Confirmation File');


   IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        DIR_NAME := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

      ELSE
        --sampath

        DIR_NAME := 'XRUPLD_I/wip'; --L_OUT_CONF_PATH || GLOBAL.SLASH || 'wip';

      END IF; --sampath


      CONF_FILE_NAME := SRC_FILE_NAME || '.CNF';
      CONF_MODE      := 'w';
      DBG('Directory Name...' || DIR_NAME);

      IF GLOBAL.IS12CR2 <> 'Y' THEN
        L_CONF_FILE_TYPE := UTL_FILE.FOPEN(DIR_NAME,
                                           CONF_FILE_NAME,
                                           'w',
                                           10);

      ELSE
        IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(DIR_NAME,
                                                     L_DIR_NAME,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;
        L_CONF_FILE_TYPE := UTL_FILE.FOPEN(L_DIR_NAME,
                                           CONF_FILE_NAME,
                                           'w',
                                           10);
      END IF;

      UTL_FILE.FCLOSE(L_CONF_FILE_TYPE);
      SRC_LOC := DIR_NAME;

      DEST_LOC := L_OUT_CONF_PATH || GLOBAL.SLASH || 'ready';

      IF NOT FN_MOVE_FILE_OUT(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              CONF_FILE_NAME,
                              CONF_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('FAILED IN MOVING CONFIRMATION FILE FROM WIP TO READY FOLDER');
      END IF;

    END IF;

    IF P_STATUS = 'S' AND P_FORMAT_DTLS.CRC_REQUIRED = 'Y' THEN
      DBG('Going to calcuate CRC For Generated File');

      DBG('Going to Generate CRC File for Generated CRC for FileName');

      DIR_NAME      := L_OUT_CRC_PATH || GLOBAL.SLASH || 'wip';
      CRC_FILE_NAME := SRC_FILE_NAME || '.CRC';

      IF P_FORMAT_DTLS.CRC_ALGORITHM NOT IN ('CRC32', 'ADLER32') THEN
        DIR_NAME := DIR_NAME || GLOBAL.SLASH ||
                    P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
        BEGIN
          SELECT DEFAULT_CRC
            INTO CRC_SQL
            FROM GITM_CRC_CHECKSUM
           WHERE CRC_NAME = P_FORMAT_DTLS.CRC_ALGORITHM;

          C_SQL := ' DECLARE ' || CHR(10);
          C_SQL := C_SQL || 'ABS_FILE_PATH VARCHAR2(2000):=' || '' ||
                   DIR_NAME || '' || '; ' || CHR(10);
          C_SQL := C_SQL || 'CRC_VALUE VARCHAR2(30); ' || CHR(10);
          C_SQL := C_SQL || ' BEGIN ' || CHR(10);
          C_SQL := C_SQL || CRC_SQL || CHR(10);
          C_SQL := C_SQL || ' CRC_VALUE:= L_CRC_VALUE; ' || CHR(10);
          C_SQL := C_SQL ||
                   'gipks_interface_trigger.g_crc_value:= CRC_VALUE;' ||
                   CHR(10);
          C_SQL := C_SQL || 'END;' || CHR(10);

          L_CURSOR := DBMS_SQL.OPEN_CURSOR;
          DBMS_SQL.PARSE(L_CURSOR, C_SQL, DBMS_SQL.NATIVE);
          L_RETURN := DBMS_SQL.EXECUTE(L_CURSOR);
          DBMS_SQL.CLOSE_CURSOR(L_CURSOR);
          CRC_VALUE := GIPKS_INTERFACE_TRIGGER.G_CRC_VALUE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in generating CRC Value...');
            P_ERR_CODE   := 'GI-PRS-021';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END;

      ELSE


        IF NOT FN_GENERATE_CRC(CASE g_interface_code WHEN 'DEUPLOAD' THEN
                               'DEUPLD_I/ready' WHEN 'SVUPLOAD' THEN
                               'DEUPLD_I/ready' WHEN 'IXRATEJU' THEN
                               'XRUPLD_I/ready' ELSE NULL END, -- || GLOBAL.SLASH || 'ready',
                               SRC_FILE_NAME,
                               CRC_VALUE,
                               P_FORMAT_DTLS.CRC_ALGORITHM,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
          P_ERR_CODE   := 'GI-PRS-021';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
      DBG('CRC Value ...' || CRC_VALUE);
      IF GLOBAL.IS12CR2 <> 'Y' THEN
        L_CONF_FILE_TYPE := UTL_FILE.FOPEN(DIR_NAME,
                                           CRC_FILE_NAME,
                                           'w',
                                           1000);

      ELSE
        IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(DIR_NAME,
                                                     L_DIR_NAME,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
          DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;
        L_CONF_FILE_TYPE := UTL_FILE.FOPEN(L_DIR_NAME,
                                           CRC_FILE_NAME,
                                           'w',
                                           10);
      END IF;

      UTL_FILE.PUT(L_CONF_FILE_TYPE, CRC_VALUE);
      UTL_FILE.FCLOSE(L_CONF_FILE_TYPE);
      SRC_LOC := DIR_NAME;

      DEST_LOC       := L_OUT_CRC_PATH || GLOBAL.SLASH || 'ready';
      SRC_FILE_NAME  := CRC_FILE_NAME;
      DEST_FILE_NAME := CRC_FILE_NAME;

      IF NOT FN_MOVE_FILE_OUT(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('FAILED IN MOVING CRC FILE FROM WIP TO READY FOLDER');
      END IF;
    END IF;

    DBG('calling custom code to move outgoing file and log in ready folder');
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_outgoing');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_OUTGOING(P_SOURCE,
                                                             P_ACTION_CODE,
                                                             P_GIDIFPRS,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_outgoing***please check');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning Success from fn_process_outgoing');
    RETURN TRUE;
  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DEBUG.PR_DEBUG('GI',
                     'From E_Failure_Exception of GIPKS_INTERFACE_TRIGGER.fn_process_outgoing');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE   := 'ST-MSRV-001';
        P_ERR_PARAMS := NULL;
      END IF;
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_process_outgoing ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PROCESS_OUTGOING;

  FUNCTION FN_UPDATE_FILENAME_OUTGOING(P_FILE_NAME  IN VARCHAR2,
                                       P_SERIAL     IN NUMBER,
                                       P_ERR_CODE   IN OUT VARCHAR2,
                                       P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG(' inside GIPKS_INTERFACE_TRIGGER.fn_update_filename_outgoing');

    DBG('File Name = ' || P_FILE_NAME);

    DBG('p_serial  = ' || P_SERIAL);

    UPDATE GITB_FILE_LOG
       SET FILE_NAME = P_FILE_NAME, PHY_FILE_NAME = P_FILE_NAME
     WHERE PROCESS_REF_NO = P_SERIAL;
    COMMIT;
    RETURN TRUE;
    DBG('Returning from GIPKS_INTERFACE_TRIGGER.fn_update_filename_outgoing');
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBG('In when others of GIPKS_INTERFACE_TRIGGER.fn_update_filename_outgoing...');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;

  END FN_UPDATE_FILENAME_OUTGOING;

  FUNCTION FN_SET_FILE_LOG(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                           P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                           P_BRN_CODE     IN VARCHAR2,
                           P_FILE_NAME    IN VARCHAR2,
                           P_PROCESS_DATE IN DATE,
                           P_SERIAL       IN OUT NUMBER,
                           P_FILE_STATUS  IN VARCHAR2,
                           P_ERR_CODE     IN OUT VARCHAR2,
                           P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    PRAGMA AUTONOMOUS_TRANSACTION;

    L_FILE_LOG GITB_FILE_LOG%ROWTYPE;
    L_COUNT    NUMBER;
    E_INSERT_EXCEPTION EXCEPTION;
    L_SERIAL_NO NUMBER;

    PK VARCHAR2(50);

  BEGIN

    DBG('File Status>>> ' || P_FILE_STATUS);
    DBG('File Name>>>> ' || P_FILE_NAME);
    DBG('iNSERTED 1..');
    DBG('p_brn_code' || P_BRN_CODE);
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.external_system' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM);
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.interface_code' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('p_file_name' || P_FILE_NAME);
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.process_code' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);

    DBG('Global.User_id' || GLOBAL.USER_ID);
    SAVEPOINT INS_LOG;
    DBG('iNSERTED 111..');

    BEGIN

      PK := TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYDDDHHMMSS') || 'GBFL' ||
            LPAD(SEQ_GITB_FILE_LOG.NEXTVAL, 28, 0);

      INSERT INTO GITB_FILE_LOG
        (BRANCH_CODE,
         EXTERNAL_SYSTEM,
         INTERFACE_CODE,
         STATUS,
         FILE_NAME,
         USER_ID,
         PROCESS_CODE,
         PROCESS_REF_NO,
         START_DATE_STAMP,
         END_DATE_STAMP,
         UPLOAD_DATE,
         RECORDS_PROCESSED,
         RECORDS_ERRORED,
         ERROR_CODE,
         ERROR_PARAMS,
         PK_SERIAL_NO)
      VALUES
        (P_BRN_CODE,
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
         'U',
         P_FILE_NAME,
         GLOBAL.USER_ID,
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
         P_SERIAL,
         FN_HOSTDATETIME,

         NULL,
         GLOBAL.APPLICATION_DATE,
         '',
         '',
         NULL,
         NULL,
         PK);

      DBG('iNSERTED 2..');
    EXCEPTION
      WHEN OTHERS THEN
        RAISE E_INSERT_EXCEPTION;
    END;
    DBG('iNSERTED 3..');
    COMMIT;
    DBG('iNSERTED 4..');
    RETURN TRUE;
  EXCEPTION
    WHEN E_INSERT_EXCEPTION THEN
      DBG('iNSERTED 5..');
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_set_file_log ..' ||
                     SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO INS_LOG;
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('iNSERTED 6..');
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_set_file_log ..' ||
                     SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO INS_LOG;
      RETURN FALSE;

  END FN_SET_FILE_LOG;

  FUNCTION FN_SET_FILE_LOG_FILEMASTER(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                      P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                      P_BRN_CODE     IN VARCHAR2,
                                      P_FILE_NAME    IN VARCHAR2,
                                      P_PROCESS_DATE IN DATE,
                                      P_SERIAL       IN NUMBER,
                                      P_FILE_STATUS  IN VARCHAR2,
                                      P_ERR_CODE     IN OUT VARCHAR2,
                                      P_ERR_PARAMS   IN OUT VARCHAR2,
                                      P_PHYFILE_NAME IN VARCHAR2)
    RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;

    L_FILE_LOG GITB_FILE_LOG%ROWTYPE;
    L_COUNT    NUMBER;
    E_INSERT_EXCEPTION EXCEPTION;
    L_SERIAL_NO       NUMBER;
    L_FP_FILE_EXIST   NUMBER;
    L_DP_STAT         NUMBER;
    L_FP_MASTER_EXIST NUMBER;

    PK VARCHAR2(50);

  BEGIN
    DBG('Entered into fn_set_file_log_FILEMASTER');
    SAVEPOINT INS_LOG;
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.interface_code : ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('p_file_name : ' || P_FILE_NAME);
    DBG('p_phyfile_name : ' || P_PHYFILE_NAME);
    DBG('p_serial : ' || P_SERIAL);
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.PROCESS_CODE : ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);
    SELECT COUNT(1)
      INTO L_FP_MASTER_EXIST
      FROM GITB_FILE_MASTER
     WHERE INTERFACE_CODE =
           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
       AND FILE_NAME = P_FILE_NAME
       AND PHY_FILE_NAME = P_PHYFILE_NAME
       AND PROCESS_CODE =
           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE
       AND PROCESS_REF_NO = P_SERIAL;
    DBG('l_fp_master_exist : ' || L_FP_MASTER_EXIST);
    IF L_FP_MASTER_EXIST = 0 THEN
      DBG('file Master inserted');

      PK := TO_CHAR(GLOBAL.APPLICATION_DATE, 'YYDDDHHMMSS') || 'GBFM' ||
            LPAD(SEQ_GITB_FILE_MASTER.NEXTVAL, 28, 0);

      INSERT INTO GITB_FILE_MASTER
        (PROCESS_REF_NO,
         INTERFACE_CODE,
         FILE_NAME,
         PHY_FILE_NAME,
         PROCESS_CODE,
         UPLOAD_STATUS,
         PROCESS_DATE,
         PK_SERIAL_NO)
      VALUES
        (P_SERIAL,
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
         P_FILE_NAME,
         P_PHYFILE_NAME,
         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
         'U',
         GLOBAL.APPLICATION_DATE,
         PK);

    END IF;
    DBG('Commited...');
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN E_INSERT_EXCEPTION THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_set_file_log_FILEMASTER ..' ||
                     SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO INS_LOG;
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('iNSERTED 6..');
      DEBUG.PR_DEBUG('**',
                     'In when others of GIPKS_INTERFACE_TRIGGER.fn_set_file_log_FILEMASTER ..' ||
                     SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO INS_LOG;
      RETURN FALSE;
  END FN_SET_FILE_LOG_FILEMASTER;

  FUNCTION FN_UPDATE_LOG_FILEMASTER(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                    P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                    P_BRN_CODE     IN VARCHAR2,
                                    P_FILE_NAME    IN VARCHAR2,
                                    P_PROCESS_DATE IN DATE,
                                    P_STATUS       IN VARCHAR2,
                                    P_FILE_STATUS  IN VARCHAR2,
                                    P_SERIAL       IN NUMBER,
                                    P_ERR_CODE     IN OUT VARCHAR2,
                                    P_ERR_PARAMS   IN OUT VARCHAR2,
                                    P_PHYFILENAME  IN VARCHAR2)
    RETURN BOOLEAN IS

    L_FILE_LOG          GITB_FILE_LOG%ROWTYPE;
    L_COUNT             NUMBER;
    L_SERIAL            NUMBER;
    L_RECORDS_PROCESSED NUMBER := 0;
    L_RECORDS_ERRORED   NUMBER := 0;
    L_DP_COUNT          NUMBER;
  BEGIN
    DBG(' inside GIPKS_INTERFACE_TRIGGER.fn_update_log_FILEMASTER');
    DBG('Status = ' || P_STATUS);
    DBG('File Status = ' || P_FILE_STATUS);
    DBG('File Name = ' || P_FILE_NAME);
    DBG('branch_code =  ' || P_BRN_CODE);
    DBG('interface_code = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('external_system = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM);
    DBG('process code  = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);
    DBG('p_serial  = ' || P_SERIAL);
    IF (P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'FP') THEN
      DBG('FP Updating status to : ' || P_FILE_STATUS);
      UPDATE GITB_FILE_MASTER
         SET UPLOAD_STATUS = P_FILE_STATUS,
             ERROR_CODE    = P_ERR_CODE,
             ERROR_PARAMS  = REPLACE(P_ERR_PARAMS, '~', '^')
       WHERE PROCESS_REF_NO = P_SERIAL
         AND PHY_FILE_NAME = P_PHYFILENAME
         AND PROCESS_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE;
      DBG('Number of rows updated : ' || SQL%ROWCOUNT);
    END IF;
    IF (P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP') THEN
      DBG('DP Updating status to : ' || P_FILE_STATUS);
      UPDATE GITB_FILE_MASTER
         SET UPLOAD_STATUS = P_FILE_STATUS,
             ERROR_CODE    = P_ERR_CODE,
             ERROR_PARAMS  = REPLACE(P_ERR_PARAMS, '~', '^')
       WHERE PROCESS_REF_NO = P_SERIAL
         AND PHY_FILE_NAME = P_PHYFILENAME
         AND PROCESS_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE;
      DBG('Number of rows updated : ' || SQL%ROWCOUNT);
    END IF;
    RETURN TRUE;
    DBG('Returning from GIPKS_INTERFACE_TRIGGER.fn_update_log_FILEMASTER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of GIPKS_INTERFACE_TRIGGER.fn_update_log_FILEMASTER...');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO FILE_LOG;
      RETURN FALSE;
  END FN_UPDATE_LOG_FILEMASTER;

  FUNCTION FN_COPY_FILE(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                        SRC_LOC  IN OUT VARCHAR2,
                        DEST_LOC IN OUT VARCHAR2,

                        SRC_FILE_NAME  IN VARCHAR2,
                        DEST_FILE_NAME IN VARCHAR2,
                        P_ERR_CODE     IN OUT VARCHAR2,
                        P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    BUFFER_SIZE NUMBER(20) := 32767;
    FILE_TYPE   UTL_FILE.FILE_TYPE;

    L_SRC_PATH  VARCHAR2(300);
    L_DEST_PATH VARCHAR2(300);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('24681320 inf fn_copy_file ');
    DBG('src_loc  ' || SRC_LOC);
    DBG('dest_loc    ' || DEST_LOC);
    DBG('src_file_name    ' || SRC_FILE_NAME);
    DBG('dest_file_name   ' || DEST_FILE_NAME);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_GET_DIRECTORY_NAME(P_SOURCE,
                                                               SRC_LOC,
                                                               DEST_LOC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGERCLUSTER.Fn_Get_Directory_Name');
        RETURN FALSE;
      END IF;
    END IF;

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      FILE_TYPE := UTL_FILE.FOPEN(SRC_LOC, SRC_FILE_NAME, 'r', BUFFER_SIZE);
      DBG('Started Copying File....');
      UTL_FILE.FCOPY(SRC_LOC,
                     SRC_FILE_NAME,
                     DEST_LOC,
                     DEST_FILE_NAME,
                     1,
                     NULL);

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(SRC_LOC,
                                                   L_SRC_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(DEST_LOC,
                                                   L_DEST_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      FILE_TYPE := UTL_FILE.FOPEN(L_SRC_PATH,
                                  SRC_FILE_NAME,
                                  'r',
                                  BUFFER_SIZE);
      DBG('Started Copying File....');
      UTL_FILE.FCOPY(L_SRC_PATH,
                     SRC_FILE_NAME,
                     L_DEST_PATH,
                     DEST_FILE_NAME,
                     1,
                     NULL);
    END IF;

    UTL_FILE.FCLOSE(FILE_TYPE);
    DBG('SuccessFully Completed Copying File');
    RETURN TRUE;
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN

      DBG('24681320 In UTL_FILE.invalid_path');
      BEGIN
        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_SRC_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = SRC_LOC;
          DBG('24681320 l_src_path -->' || L_SRC_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_SRC_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                          G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_dest_path -->' || L_SRC_PATH);

        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_DEST_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = DEST_LOC;
          DBG('24681320 l_dest_path -->' || L_DEST_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_DEST_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                           G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_dest_path -->' || L_DEST_PATH);

        UTL_FILE.FCOPY(L_SRC_PATH,
                       SRC_FILE_NAME,
                       L_DEST_PATH,
                       DEST_FILE_NAME,
                       1,
                       NULL);
        DBG('24681320 SuccessFully Completed Copying File');
        RETURN TRUE;
      EXCEPTION
        WHEN UTL_FILE.INVALID_PATH THEN

          DBG('Failed in COpying File');
          DBG('Invalid path...');
          P_ERR_CODE   := UTL_FILE.INVALID_PATH_ERRCODE;
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
      END;
    WHEN UTL_FILE.INVALID_FILEHANDLE THEN
      DBG('Invalid File Handle...');
      P_ERR_CODE   := UTL_FILE.INVALID_FILEHANDLE_ERRCODE;
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_MAXLINESIZE THEN
      DBG('Bad Line Number....');
      P_ERR_CODE   := UTL_FILE.INVALID_MAXLINESIZE_ERRCODE;
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_OPERATION THEN
      P_ERR_CODE   := UTL_FILE.INVALID_OPERATION_ERRCODE;
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Failed in Copying File....' || SQLERRM);
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('Failed in Copying File....' || SQLERRM);
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;

  END FN_COPY_FILE;

  FUNCTION FN_MOVE_FILE(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                        SRC_LOC  IN OUT VARCHAR2,
                        DEST_LOC IN OUT VARCHAR2,

                        SRC_FILE_NAME  IN VARCHAR2,
                        DEST_FILE_NAME IN VARCHAR2,
                        P_ERR_CODE     IN OUT VARCHAR2,
                        P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_SRC_PATH  VARCHAR2(300);
    L_DEST_PATH VARCHAR2(300);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Started Moving File....');
    DBG('inside fn_move_file ....');
    DBG('src_loc ---------------> ' || SRC_LOC);
    DBG('dest_loc ---------------> ' || DEST_LOC);
    DBG('src_file_name ---------------> ' || SRC_FILE_NAME);
    DBG('dest_file_name ---------------> ' || DEST_FILE_NAME);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_GET_DIRECTORY_NAME(P_SOURCE,
                                                               SRC_LOC,
                                                               DEST_LOC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGERCLUSTER.Fn_Move_File');
        RETURN FALSE;
      END IF;
    END IF;

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      UTL_FILE.FRENAME(SRC_LOC,
                       SRC_FILE_NAME,
                       DEST_LOC,
                       DEST_FILE_NAME,
                       FALSE);

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(SRC_LOC,
                                                   L_SRC_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(DEST_LOC,
                                                   L_DEST_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      UTL_FILE.FRENAME(L_SRC_PATH,
                       SRC_FILE_NAME,
                       L_DEST_PATH,
                       DEST_FILE_NAME,
                       FALSE);
    END IF;

    DBG('SuccessFully Completed Moving File');
    RETURN TRUE;
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN

      DBG('24681320 In UTL_FILE.invalid_path');
      BEGIN
        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_SRC_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = SRC_LOC;
          DBG('24681320 l_src_path -->' || L_SRC_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_SRC_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                          G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_src_path -->' || L_SRC_PATH);

        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_DEST_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = DEST_LOC;
          DBG('24681320 l_dest_path -->' || L_DEST_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_DEST_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                           G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_dest_path -->' || L_DEST_PATH);

        UTL_FILE.FRENAME(L_SRC_PATH,
                         SRC_FILE_NAME,
                         L_DEST_PATH,
                         DEST_FILE_NAME,
                         FALSE);
        DBG('24681320 SuccessFully Completed Moving File');
        RETURN TRUE;
      EXCEPTION
        WHEN UTL_FILE.INVALID_PATH THEN

          DBG('Failed in Moving File');
          DBG('Invalid path...');
          DBG('UTL_FILE.invalid_path_errcode');
          P_ERR_CODE   := 'GI-PRS-018';
          P_ERR_PARAMS := NULL;
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    WHEN UTL_FILE.RENAME_FAILED THEN
      DBG('Rename Failed...');
      DBG(UTL_FILE.RENAME_FAILED_ERRCODE);
      P_ERR_CODE   := 'GI-PRS-081';
      P_ERR_PARAMS := SRC_LOC || '~' || DEST_LOC;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN UTL_FILE.ACCESS_DENIED THEN
      DBG('Access Denied....');
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_FILENAME THEN
      DBG('Invalid File Name....');
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('Failed in Moving File....');
      P_ERR_CODE   := 'GI-PRS-082';
      P_ERR_PARAMS := SRC_FILE_NAME;
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_MOVE_FILE;

  FUNCTION FN_MOVE_FILE_OUT(P_SOURCE IN COTMS_SOURCE.SOURCE_CODE%TYPE,

                            SRC_LOC  IN OUT VARCHAR2,
                            DEST_LOC IN OUT VARCHAR2,

                            SRC_FILE_NAME  IN VARCHAR2,
                            DEST_FILE_NAME IN VARCHAR2,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_SRC_PATH  VARCHAR2(300);
    L_DEST_PATH VARCHAR2(300);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Started Moving File....');
    DBG('inside fn_move_file_out...');
    DBG('src_loc ---------------> ' || SRC_LOC);
    DBG('dest_loc ---------------> ' || DEST_LOC);
    DBG('src_file_name ---------------> ' || SRC_FILE_NAME);
    DBG('dest_file_name ---------------> ' || DEST_FILE_NAME);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_GET_DIRECTORY_NAME(P_SOURCE,
                                                               SRC_LOC,
                                                               DEST_LOC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGERCLUSTER.Fn_Move_File_Out');
        RETURN FALSE;
      END IF;
    END IF;

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      UTL_FILE.FRENAME(SRC_LOC,
                       SRC_FILE_NAME,
                       DEST_LOC,
                       DEST_FILE_NAME,
                       FALSE);

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(SRC_LOC,
                                                   L_SRC_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(DEST_LOC,
                                                   L_DEST_PATH,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      UTL_FILE.FRENAME(L_SRC_PATH,
                       SRC_FILE_NAME,
                       L_DEST_PATH,
                       DEST_FILE_NAME,
                       FALSE);
    END IF;

    DBG('SuccessFully Completed Moving File');
    RETURN TRUE;
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN

      DBG('24681320 In UTL_FILE.invalid_path');
      BEGIN
        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_SRC_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = SRC_LOC;
          DBG('24681320 l_src_path -->' || L_SRC_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_SRC_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                          G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_dest_path -->' || L_SRC_PATH);

        BEGIN
          SELECT DIRECTORY_NAME
            INTO L_DEST_PATH
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH = DEST_LOC;
          DBG('24681320 l_dest_path -->' || L_DEST_PATH);

        EXCEPTION
          WHEN TOO_MANY_ROWS THEN
            DBG('26188512 g_interface_type :: ' || G_INTERFACE_TYPE);
            DBG('26188512 Gipks_Interface_Trigger.g_Interface_Code :: ' ||
                GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
            L_DEST_PATH := GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE || '_' ||
                           G_INTERFACE_TYPE;
        END;
        DBG('26188512 l_dest_path -->' || L_DEST_PATH);

        UTL_FILE.FRENAME(L_SRC_PATH,
                         SRC_FILE_NAME,
                         L_DEST_PATH,
                         DEST_FILE_NAME,
                         FALSE);
        DBG('24681320 SuccessFully Completed Moving File');
        RETURN TRUE;
      EXCEPTION
        WHEN UTL_FILE.INVALID_PATH THEN

          DBG('Failed in Moving File');
          DBG('Invalid path...');
          DBG('UTL_FILE.invalid_path_errcode');
          P_ERR_CODE   := 'GI-PRS-018';
          P_ERR_PARAMS := NULL;
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    WHEN UTL_FILE.RENAME_FAILED THEN
      DBG('Rename Failed...');
      DBG(UTL_FILE.RENAME_FAILED_ERRCODE);
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN UTL_FILE.ACCESS_DENIED THEN
      DBG('Access Denied....');
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_FILENAME THEN
      DBG('Invalid File Name....');
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('Failed in Moving File....');
      P_ERR_CODE   := 'GI-PRS-018';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_MOVE_FILE_OUT;

  FUNCTION FN_GENERATE_CRC(P_DIRECTORY   IN VARCHAR2,
                           FILE_NAME     IN VARCHAR2,
                           CRC_VALUE     IN OUT VARCHAR2,
                           CRC_ALOGIRTHM IN VARCHAR2,
                           P_ERR_CODE    IN OUT VARCHAR2,
                           P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    PATH               VARCHAR2(1000);
    L_OPERATING_SYSTEM VARCHAR2(12);
    L_DIR_SEP          VARCHAR2(1);

  BEGIN
    BEGIN
      DBG('Check for Operating System');
      SELECT PARAM_VAL
        INTO L_OPERATING_SYSTEM
        FROM CSTBS_PARAM
       WHERE PARAM_NAME = 'OPERATING_SYSTEM';
    EXCEPTION
      WHEN OTHERS THEN
        L_OPERATING_SYSTEM := 'UNIX';

    END;
    IF L_OPERATING_SYSTEM = 'UNIX' THEN
      L_DIR_SEP := '/';
    ELSE
      L_DIR_SEP := '\';
    END IF;
    DBG('crc ALGORITHM....' || CRC_ALOGIRTHM);
    IF CRC_ALOGIRTHM = 'CRC32' THEN
      PATH := P_DIRECTORY || L_DIR_SEP || FILE_NAME;
      DBG('Path ....' || PATH);
      BEGIN
        CRC_VALUE := GIPKS_CRC_UTILITY.CREATECHECKSUM(PATH);
      EXCEPTION
        WHEN OTHERS THEN
          CRC_VALUE := 'COULD NOT GENERATE CRC FOR THE FILE ' || FILE_NAME;
          DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    ELSIF CRC_ALOGIRTHM = 'ADLER32' THEN
      PATH := P_DIRECTORY || L_DIR_SEP || FILE_NAME;
      DBG('Path ....' || PATH);
      BEGIN
        CRC_VALUE := GIPKS_CRC_UTILITY.CREATEADLERCHECKSUM(PATH);
      EXCEPTION
        WHEN OTHERS THEN
          CRC_VALUE := 'COULD NOT GENERATE CRC FOR THE FILE ' || FILE_NAME;
          DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    ELSE
      CRC_VALUE := 'CRC32 ALG IS ONLY HANDLED ' || FILE_NAME;
    END IF;

    RETURN TRUE;
  END FN_GENERATE_CRC;

  FUNCTION FN_UPDATE_LOG(P_SOURCE       IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                         P_GIDIFPRS     IN GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                         P_BRN_CODE     IN VARCHAR2,
                         P_FILE_NAME    IN VARCHAR2,
                         P_PROCESS_DATE IN DATE,
                         P_STATUS       IN VARCHAR2,
                         P_FILE_STATUS  IN VARCHAR2,
                         P_SERIAL       IN OUT NUMBER,
                         P_ERR_CODE     IN OUT VARCHAR2,
                         P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_FILE_LOG          GITB_FILE_LOG%ROWTYPE;
    L_COUNT             NUMBER;
    L_SERIAL            NUMBER;
    L_RECORDS_PROCESSED NUMBER := 0;
    L_RECORDS_ERRORED   NUMBER := 0;
    L_NEXT_WORKING_DATE DATE;
    L_TRIGGER_TYPE      GITM_INTERFACE_DEFINITION.TRIGGER_TYPE%TYPE;
    L_WHEN_TO_RUN       GITM_INTERFACE_DEFINITION.WHEN_TO_RUN%TYPE;
    L_EOD_STAGE         STTMS_CORE_BRANCH_STATUS.END_OF_INPUT%TYPE;
    L_TODAY             DATE;
  BEGIN
    DBG(' inside GIPKS_INTERFACE_TRIGGER.fn_update_log');
    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP' THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_RECORDS_ERRORED
          FROM GITM_UPLOAD_MASTER
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND STATUS = 'E'
           AND PROCESS_REF_NO = P_SERIAL;
        DBG('Got l_records_errored~' || L_RECORDS_ERRORED);
      EXCEPTION
        WHEN OTHERS THEN
          L_RECORDS_ERRORED := 0;
          DBG('Failed In getting l_records_errored ~' || SQLERRM);
      END;
      BEGIN
        SELECT COUNT(1)
          INTO L_RECORDS_PROCESSED
          FROM GITM_UPLOAD_MASTER
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
           AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
           AND STATUS = 'P'
           AND PROCESS_REF_NO = P_SERIAL;
        DBG('Got l_records_processed~' || L_RECORDS_ERRORED);
      EXCEPTION
        WHEN OTHERS THEN
          L_RECORDS_PROCESSED := 0;
          DBG('Failed In getting l_records_processed ~' || SQLERRM);
      END;
    ELSE
      IF P_FILE_STATUS = 'E' THEN
        BEGIN
          SELECT COUNT(1)
            INTO L_RECORDS_ERRORED
            FROM GITB_FILE_LOG
           WHERE PROCESS_REF_NO = P_SERIAL
             AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_');
          DBG('Got l_records_errored~' || L_RECORDS_ERRORED);
        EXCEPTION
          WHEN OTHERS THEN
            L_RECORDS_ERRORED := 0;
            DBG('Failed In getting l_records_errored ~' || SQLERRM);
        END;
      ELSIF P_FILE_STATUS = 'P' THEN
        BEGIN

          SELECT COUNT(1)
            INTO L_RECORDS_PROCESSED
            FROM GITM_UPLOAD_MASTER
           WHERE INTERFACE_CODE =
                 P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
             AND FILE_NAME = REPLACE(P_FILE_NAME, '.', '_')
             AND PROCESS_REF_NO = P_SERIAL;

          DBG('Got l_records_processed~' || L_RECORDS_PROCESSED);
        EXCEPTION
          WHEN OTHERS THEN
            L_RECORDS_PROCESSED := 0;
            DBG('Failed In getting l_records_processed ~' || SQLERRM);
        END;
      END IF;
    END IF;

    DBG('Status = ' || P_STATUS);
    DBG('File Status = ' || P_FILE_STATUS);
    DBG('File Name = ' || P_FILE_NAME);
    DBG('branch_code =  ' || P_BRN_CODE);
    DBG('interface_code = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
    DBG('external_system = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM);
    DBG('process code  = ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);
    DBG('p_serial  = ' || P_SERIAL);

    SAVEPOINT FILE_LOG;
    IF P_FILE_STATUS IN ('E', 'P') THEN
      UPDATE GITB_FILE_LOG
         SET STATUS            = P_FILE_STATUS,
             END_DATE_STAMP    = FN_HOSTDATETIME,
             RECORDS_PROCESSED = L_RECORDS_PROCESSED,
             RECORDS_ERRORED   = L_RECORDS_ERRORED,
             ERROR_CODE        = P_ERR_CODE,
             ERROR_PARAMS      = REPLACE(P_ERR_PARAMS, '~', '^')
       WHERE PROCESS_REF_NO = P_SERIAL
         AND PROCESS_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE;

      IF P_FILE_STATUS = 'P' THEN
        SELECT NEXT_WORKING_DAY, TODAY
          INTO L_NEXT_WORKING_DATE, L_TODAY
          FROM STTMS_DATES
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;

        BEGIN
          SELECT END_OF_INPUT
            INTO L_EOD_STAGE
            FROM STTMS_CORE_BRANCH_STATUS
           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
          DBG('l_Eod_Stage -' || L_EOD_STAGE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG(SQLERRM);
            DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;

        BEGIN
          SELECT TRIGGER_TYPE, WHEN_TO_RUN
            INTO L_TRIGGER_TYPE, L_WHEN_TO_RUN
            FROM GITM_INTERFACE_DEFINITION
           WHERE INTERFACE_CODE =
                 P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG(SQLERRM);
            DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
      END IF;

      IF L_TRIGGER_TYPE = 'S' AND L_WHEN_TO_RUN = 'N' THEN
        UPDATE GITM_INTERFACE_DEFINITION
           SET LAST_RUN_DATE = GLOBAL.APPLICATION_DATE,
               NEXT_RUN_DATE = L_NEXT_WORKING_DATE
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;

      ELSIF L_TRIGGER_TYPE = 'S' AND L_WHEN_TO_RUN != 'N' THEN
        UPDATE GITM_INTERFACE_DEFINITION
           SET LAST_RUN_DATE = GLOBAL.APPLICATION_DATE,
               NEXT_RUN_DATE = CASE
                                 WHEN L_EOD_STAGE IN ('T', 'F', 'E') THEN
                                  L_NEXT_WORKING_DATE
                                 WHEN L_EOD_STAGE IN ('B', 'N') THEN
                                  L_TODAY
                                 ELSE
                                  NULL
                               END
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;

      ELSE
        UPDATE GITM_INTERFACE_DEFINITION
           SET LAST_RUN_DATE = GLOBAL.APPLICATION_DATE
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
      END IF;
      COMMIT;
    ELSE
      UPDATE GITB_FILE_LOG
         SET STATUS = P_FILE_STATUS
       WHERE PROCESS_REF_NO = P_SERIAL
         AND PROCESS_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE;
      COMMIT;
    END IF;
    RETURN TRUE;
    DBG('Returning from GIPKS_INTERFACE_TRIGGER.fn_update_log');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of GIPKS_INTERFACE_TRIGGER.fn_update_log...');
      DBG(SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'GI-PRS-016';
      P_ERR_PARAMS := NULL;
      ROLLBACK TO FILE_LOG;
      RETURN FALSE;

  END FN_UPDATE_LOG;

  FUNCTION FN_TRIGGER_INTERFACE(P_BRANCH_CODE    IN VARCHAR2,
                                P_INTERFACE_CODE IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE,
                                P_FILE_NAME      IN GITM_FILE_NAMES.FILE_NAME%TYPE,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_GIDIFPRS GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS;
    P_FORMAT   GITM_FORMAT_DEFINITION%ROWTYPE;

    L_FN_WIP_FILES    VARCHAR2(50);
    L_FILE_PATH       VARCHAR2(1000);
    L_FILE_LIST       VARCHAR2(32767);
    L_FILE_NAME       VARCHAR2(50);
    L_FILE_NAME_TXT   VARCHAR2(50);
    J                 INTEGER;
    K                 INTEGER := 0;
    P_FILE_NAMES      GIPKS_GI_SERVICE.TY_TB_F_FILE_NAMES;
    ACTUAL_FILE_NAMES GIPKS_GI_SERVICE.TY_TB_F_FILE_NAMES;
    CURSOR CUR_FILE_NAMES(C_INTF_CODE IN GITM_INTERFACE_DEFINITION.INTERFACE_CODE%TYPE) IS
      SELECT * FROM GITM_FILE_NAMES WHERE INTERFACE_CODE = C_INTF_CODE;

  BEGIN

    BEGIN
      SELECT *
        INTO P_FORMAT
        FROM GITM_FORMAT_DEFINITION
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND BRANCH_CODE = P_BRANCH_CODE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';

      BEGIN
        G_ALL_DIR_FILE_PATH := NULL;
        SELECT DIRECTORY_PATH
          INTO G_ALL_DIR_FILE_PATH
          FROM ALL_DIRECTORIES
         WHERE DIRECTORY_NAME = P_FORMAT.FILE_PATH;
        DBG('g_all_dir_file_path...' || G_ALL_DIR_FILE_PATH);
        IF P_FORMAT.INTERFACE_TYPE = 'I' THEN
          G_ALL_DIR_FILE_PATH := SUBSTR(G_ALL_DIR_FILE_PATH,
                                        0,
                                        INSTR(G_ALL_DIR_FILE_PATH,
                                              GLOBAL.SLASH,
                                              -1) - 1);
        END IF;
        P_FORMAT.FILE_PATH := G_ALL_DIR_FILE_PATH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('File path maintained is not present in ');
          G_ALL_DIR_FILE_PATH := NULL;
      END;

      P_FORMAT.CRC_FILE_PATH          := SUBSTR(P_FORMAT.FILE_PATH,
                                                0,
                                                INSTR(P_FORMAT.FILE_PATH,
                                                      GLOBAL.SLASH,
                                                      -1)) || 'crc';
      P_FORMAT.CONFIRMATION_FILE_PATH := SUBSTR(P_FORMAT.FILE_PATH,
                                                0,
                                                INSTR(P_FORMAT.FILE_PATH,
                                                      GLOBAL.SLASH,
                                                      -1)) ||
                                         'confirmation';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in Querying Interface Definition Details...');
        P_ERR_CODE   := 'GI-PRS-002';
        P_ERR_PARAMS := P_INTERFACE_CODE;
        PR_LOG_ERROR('FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
    END;

    IF P_FILE_NAME = 'SCHEDULED_TRIGGER' THEN
      IF P_FORMAT.INTERFACE_TYPE = 'I' THEN
        OPEN CUR_FILE_NAMES(P_INTERFACE_CODE);
        FETCH CUR_FILE_NAMES BULK COLLECT
          INTO P_FILE_NAMES;
        FOR J IN P_FILE_NAMES.FIRST .. P_FILE_NAMES.LAST LOOP
          DBG('j :' || J);


   IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            L_FILE_PATH := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

          ELSE
            --sampath
            L_FILE_PATH := 'XRUPLD_I/ready'; --P_FORMAT.FILE_PATH || GLOBAL.SLASH || 'ready';
          END IF; --sampath


          L_FILE_NAME_TXT := P_FILE_NAMES(J).FILE_NAME;
          L_FILE_NAME     := SUBSTR(L_FILE_NAME_TXT,
                                    1,
                                    INSTR(L_FILE_NAME_TXT, '.') - 1);
          L_FN_WIP_FILES  := FN_WIP_FILES(L_FILE_PATH, L_FILE_NAME);
          IF L_FN_WIP_FILES IS NOT NULL OR L_FN_WIP_FILES = '' THEN
            L_FILE_LIST := L_FILE_LIST || L_FN_WIP_FILES || '~';
            DBG('l_file_list --> :' || L_FILE_LIST);
            K := K + 1;
            ACTUAL_FILE_NAMES(K).FILE_NAME := P_FILE_NAMES(J).FILE_NAME;

          END IF;

        END LOOP;
        CLOSE CUR_FILE_NAMES;
        DBG('l_file_list --> : ' || L_FILE_LIST);
        IF L_FILE_LIST IS NULL OR L_FILE_LIST = '' THEN
          P_ERR_CODE   := 'GI-PRS-005';
          P_ERR_PARAMS := P_FILE_NAME || '~' || L_FILE_PATH;
          DBG('Errors     :' || P_ERR_CODE);
          DBG('Parameters :' || P_ERR_PARAMS);

          DBG('Failed to trigger the interface as files are not present in the folder : ' ||
              L_FILE_PATH);
          RETURN TRUE;

        END IF;

      END IF;
    END IF;

    IF P_FILE_NAME = 'SCHEDULED_TRIGGER' THEN
      FOR J IN ACTUAL_FILE_NAMES.FIRST .. ACTUAL_FILE_NAMES.LAST LOOP
        DBG('PROCESSING THE FILE ||' || ACTUAL_FILE_NAMES(J).FILE_NAME);
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE  := P_INTERFACE_CODE;
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME       := ACTUAL_FILE_NAMES(J)
                                                                   .FILE_NAME;
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE    := 'AL';
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE     := P_FORMAT.BRANCH_CODE;
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM := P_FORMAT.EXTERNAL_SYSTEM;
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE  := P_FORMAT.INTERFACE_TYPE;
        L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.STATUS          := 'U';

        IF NOT FN_TRIGGER_PROCESS('FLEXCUBE',
                                  'NEW',
                                  L_GIDIFPRS,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
          PR_LOG_ERROR('FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN TRUE;
        END IF;
      END LOOP;
      RETURN TRUE;

    ELSE
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE  := P_FORMAT.INTERFACE_CODE;
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME       := P_FILE_NAME;
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE    := 'AL';
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE     := P_FORMAT.BRANCH_CODE;
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM := P_FORMAT.EXTERNAL_SYSTEM;
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_TYPE  := P_FORMAT.INTERFACE_TYPE;
      L_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.STATUS          := 'U';

      IF NOT FN_TRIGGER_PROCESS('FLEXCUBE',
                                'NEW',
                                L_GIDIFPRS,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        PR_LOG_ERROR('FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN TRUE;
      END IF;
      RETURN TRUE;
    END IF;
  END FN_TRIGGER_INTERFACE;

  FUNCTION FN_VALIDATE_OUTGOING(P_SOURCE         IN VARCHAR2,
                                P_ACTION_CODE    IN VARCHAR2,
                                P_GIDIFPRS       IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FILE_LOG       IN GITB_FILE_LOG%ROWTYPE,
                                P_FORMAT_DETAILS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAMS     IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    FILE_LOG    BOOLEAN;
    L_BRANCH    STTM_CORE_BRANCH.BRANCH_CODE%TYPE;
    L_FILE_NAME VARCHAR2(100);
    L_FILE_PATH VARCHAR2(1000);
    P_SERIAL    NUMBER;
  BEGIN

    IF P_FILE_LOG.STATUS = 'W' THEN
      P_ERR_CODE   := 'GI-PRS-003';
      P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Failed as Outgoing Process for Interface is already in WIP Stage');
      FILE_LOG := FALSE;
      RETURN FALSE;

    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_validate_outgoing ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_VALIDATE_OUTGOING;

  FUNCTION FN_VALIDATE_INCOMING(P_SOURCE      IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_COUNT            NUMBER;
    DIR_NAME           ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;
    DIR_PATH           ALL_DIRECTORIES.DIRECTORY_PATH%TYPE;
    FILE_TYPE          UTL_FILE.FILE_TYPE;
    FILE_EXISTS        BOOLEAN := TRUE;
    LEN                NUMBER;
    BLK_SIZE           BINARY_INTEGER;
    LINE_TEXT          VARCHAR2(1000);
    CRC_VALUE          VARCHAR2(100);
    FNID_COUNT         NUMBER;
    L_OPERATING_SYSTEM VARCHAR2(20);
    L_DIR_SEP          VARCHAR2(1);
    FILE_LOG           BOOLEAN := TRUE;
    FILE_LOG_STATUS    VARCHAR2(2);
    L_FILE_NAME        VARCHAR2(100);
    L_DIR_SQL          VARCHAR2(2000);
    BUFFER_SIZE        NUMBER(20) := 32767;
    IN_CRC_FILE_PATH   VARCHAR2(1000);
    IN_CRC_FILE_NAME   VARCHAR2(1000);
    IN_CONF_FILE_PATH  VARCHAR2(1000);
    IN_CONF_FILE_NAME  VARCHAR2(1000);
    L_BRANCH           STTM_CORE_BRANCH.BRANCH_CODE%TYPE;
    P_FILE_LOG         GITB_FILE_LOG%ROWTYPE;
    L_OUT_COUNT        NUMBER;
    L_ERR_COUNT        NUMBER;
    L_SQL              VARCHAR2(2000);
    CRC_SQL            VARCHAR2(32767);
    C_SQL              VARCHAR2(32767);
    L_CURSOR           NUMBER;
    L_RETURN           NUMBER;
    L_WIP              VARCHAR2(100);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('inside fn_validate_incoming');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_validate_incoming');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_VALIDATE_INCOMING(P_SOURCE,
                                                              P_ACTION_CODE,
                                                              P_GIDIFPRS,
                                                              P_FORMAT_DTLS,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_validate_incoming***please check');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      BEGIN
        SELECT *
          INTO P_FILE_LOG
          FROM GITB_FILE_LOG
         WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
           AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
           AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
           AND FILE_NAME =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
           AND START_DATE_STAMP =
               (SELECT MAX(START_DATE_STAMP)
                  FROM GITB_FILE_LOG
                 WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                   AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                   AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                   AND FILE_NAME =
                       P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No Records Exists for File Log...');
        WHEN OTHERS THEN
          DBG('WHEN OTHERS No Records Exists for File Log...');
      END;
      DBG('1. Validationg whether file is mapped to specified interface code');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM GITM_FILE_NAMES
       WHERE INTERFACE_CODE =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
      IF L_COUNT = 0 THEN
        P_ERR_CODE   := 'GI-PRS-004';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
        DBG('File Name is not mapped to interface code');
        RETURN FALSE;
      END IF;
      DBG('1. Validation Successfull for File Mapped to Interface Code..');

      DBG('8. Validation for Single Or Multiple Executions Per Day Starts.....');
      IF NOT FN_VALIDATE_EXECUTIONS(P_SOURCE,
                                    P_ACTION_CODE,
                                    P_GIDIFPRS,
                                    P_FORMAT_DTLS,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Failed in fn_validate_executions...');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('8. Validation for Single Or Multiple Executions Per Day Ends  Successfullly.....');
      DBG('2. Validating whether file exists in the file path...' ||
          P_FORMAT_DTLS.FILE_PATH);
      L_DIR_SEP := GLOBAL.SLASH;
      DBG('p_format_dtls.Interface_Code >>' ||
          P_FORMAT_DTLS.INTERFACE_CODE);
      DBG('p_format_dtls.file_path >>' || P_FORMAT_DTLS.FILE_PATH);
      IF P_FORMAT_DTLS.FILE_PATH IS NOT NULL THEN
        BEGIN
          SELECT DIRECTORY_NAME
            INTO DIR_NAME
            FROM ALL_DIRECTORIES
           WHERE DIRECTORY_PATH =

                 P_FORMAT_DTLS.FILE_PATH || L_DIR_SEP || 'wip'
             AND (DIRECTORY_NAME = 'IN_WIP' OR
                 DIRECTORY_NAME LIKE (P_FORMAT_DTLS.INTERFACE_CODE || '%'));
          DIR_PATH := P_FORMAT_DTLS.FILE_PATH;
          DBG('Dir_name >>' || DIR_NAME);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Directory Does Not Exists');
            BEGIN
              DIR_NAME := P_FORMAT_DTLS.INTERFACE_CODE || '_' ||
                          P_FORMAT_DTLS.INTERFACE_TYPE;

              L_WIP := P_FORMAT_DTLS.FILE_PATH || L_DIR_SEP || 'wip';
              DBG('26188512 :: l_Wip :: ' || L_WIP);
              L_DIR_SQL := 'CREATE OR REPLACE DIRECTORY ' || DIR_NAME ||
                           ' AS ' || '''' || L_WIP || '''';

              IF NOT FN_CREATE_DIRECTORY(L_DIR_SQL) THEN
                P_ERR_CODE   := 'GI-PRS-006';
                P_ERR_PARAMS := 'INCOM_' || P_FORMAT_DTLS.INTERFACE_CODE;
                PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
                DBG('Failed to create Directory... INCOM_' ||
                    P_FORMAT_DTLS.INTERFACE_CODE || 'Exception is  ' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;

            EXCEPTION
              WHEN OTHERS THEN
                P_ERR_CODE   := 'GI-PRS-006';
                P_ERR_PARAMS := 'INCOM_' || P_FORMAT_DTLS.INTERFACE_CODE;
                PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
                DBG('Failed to create Directory... INCOM_' ||
                    P_FORMAT_DTLS.INTERFACE_CODE || 'Exception is  ' ||
                    SQLERRM);
                RETURN FALSE;
            END;
          WHEN TOO_MANY_ROWS THEN
            P_ERR_CODE   := 'GI-PRS-057';
             P_ERR_PARAMS := ' directory name ! Multiple directories found for the path ' ||
                            'XRUPLD_I/wip'; --P_FORMAT_DTLS.FILE_PATH || GLOBAL.SLASH ||
            --'wip';
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
        END;

      END IF;
      DBG('2.1 . File Exists...');

      DBG('3. Validation begins to check in File Log whether the File Already Processed Today or not');
      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'FP' THEN
        IF P_FILE_LOG.STATUS = 'P' AND P_FILE_LOG.PROCESS_CODE = 'FP' AND
           TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 1 THEN
          DBG('Record already processed');
          P_ERR_CODE   := 'GI-PRS-007';
          P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        IF P_FILE_LOG.STATUS = 'E' AND P_FILE_LOG.PROCESS_CODE = 'FP' THEN
          FILE_LOG        := TRUE;
          FILE_LOG_STATUS := 'U';
        END IF;
        IF P_FILE_LOG.STATUS = 'P' AND P_FILE_LOG.PROCESS_CODE = 'DP' AND
           TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 1 THEN
          DBG('Already Processed File till Master...');
          P_ERR_CODE   := 'GI-PRS-008';
          P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'DP' THEN

        IF P_FILE_LOG.STATUS = 'P' AND P_FILE_LOG.PROCESS_CODE = 'DP' AND
           TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 1 THEN
          DBG('Record already processed');
          P_ERR_CODE   := 'GI-PRS-008';
          P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        IF P_FILE_LOG.STATUS = 'E' AND P_FILE_LOG.PROCESS_CODE = 'DP' THEN
          FILE_LOG        := TRUE;
          FILE_LOG_STATUS := 'U';
        END IF;
        IF P_FILE_LOG.STATUS = 'P' AND P_FILE_LOG.PROCESS_CODE = 'FP' AND
           TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 1 THEN
          FILE_LOG := TRUE;
        END IF;
        IF P_FILE_LOG.STATUS = 'E' AND P_FILE_LOG.PROCESS_CODE = 'FP' THEN
          DBG('Cannot Proceed as Failed in FP Process');
          P_ERR_CODE   := 'GI-PRS-009';
          P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

      END IF;

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'RT' THEN
        DBG('Validation for Retry');
        IF NOT FN_VALIDATE_RETRY(P_SOURCE,
                                 P_ACTION_CODE,
                                 P_GIDIFPRS,
                                 P_FORMAT_DTLS,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
          DBG('Failed in Validation of Retry Process..');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'RE' THEN
        DBG('Validation for Retry Error....');
        IF NOT FN_VALIDATE_RETRY_ERROR(P_SOURCE,
                                       P_ACTION_CODE,
                                       P_GIDIFPRS,
                                       P_FORMAT_DTLS,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
          DBG('Failed in Validation of Retry Process..');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
      DBG('3.  Validation for File already Processed Ends...');
      DBG('4. Validation Begins for Confirmation File Required and CRC Required');

      DBG('6. Validation for Interface Mapped to Function Id or Not...');
      IF P_FORMAT_DTLS.INTERFACE_TYPE = 'I' AND
         P_FORMAT_DTLS.FUNCTION_ID IS NOT NULL THEN
        DBG('Checking for Function Id Exists or Not...');
        SELECT COUNT(*)
          INTO FNID_COUNT
          FROM SMTB_MENU
         WHERE FUNCTION_ID = P_FORMAT_DTLS.FUNCTION_ID
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
        IF FNID_COUNT = 0 THEN
          DBG('Invalid Function Id Mapped to Interface Code');
          P_ERR_CODE   := 'GI-PRS-011';
          P_ERR_PARAMS := P_FORMAT_DTLS.FUNCTION_ID || '~' ||
                          P_FORMAT_DTLS.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

      END IF;
      DBG('6. Validation for Interface Mapped to Function Id is Successfull...');
      DBG('7. Any Outgoing Interface  attached exists or not...');
      IF P_FORMAT_DTLS.OUTGOING_INTERFACE IS NOT NULL THEN
        BEGIN
          SELECT COUNT(*)
            INTO L_OUT_COUNT
            FROM GITM_FORMAT_DEFINITION
           WHERE INTERFACE_CODE = P_FORMAT_DTLS.OUTGOING_INTERFACE
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
          IF L_OUT_COUNT = 0 THEN
            P_ERR_CODE   := 'GI-PRS-036';
            P_ERR_PARAMS := P_FORMAT_DTLS.OUTGOING_INTERFACE;
            DBG('No Record Found for attache outgoing interface $1');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          IF L_OUT_COUNT = 1 THEN
            BEGIN
              L_SQL := ' SELECT COUNT(*) FROM USER_ERRORS WHERE NAME = ''GIPKS_' ||
                       DBMS_ASSERT.SIMPLE_SQL_NAME(P_FORMAT_DTLS.OUTGOING_INTERFACE) || '''';
              EXECUTE IMMEDIATE L_SQL
                INTO L_ERR_COUNT;
              IF L_ERR_COUNT >= 1 THEN
                DBG('Failed in Executing SQL Command...' || L_SQL);
                P_ERR_CODE   := 'GI-PRS-037';
                P_ERR_PARAMS := 'GIPKS_' ||
                                P_FORMAT_DTLS.OUTGOING_INTERFACE || '~' ||
                                P_FORMAT_DTLS.OUTGOING_INTERFACE;
                DBG('Package $1 is invalid for Interface $2');
                PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Executing SQL Command...' || L_SQL ||
                    SQLERRM);
                P_ERR_CODE := 'GI-PRS-038';
                DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                P_ERR_PARAMS := SQLERRM;
                DBG('Outgoing Interface $1 attached does not exists...');
                PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
                RETURN FALSE;
            END;

          END IF;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_CODE   := 'GI-PRS-036';
            P_ERR_PARAMS := P_FORMAT_DTLS.OUTGOING_INTERFACE;
            DBG('Outgoing Interface $1 attached does not exists...');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
        END;

      END IF;
    END IF;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_validate_incoming2');
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_VALIDATE_INCOMING(P_SOURCE,
                                                              P_ACTION_CODE,
                                                              P_GIDIFPRS,
                                                              P_FORMAT_DTLS,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_validate_incoming***please check');
        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_validate_incoming ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_INCOMING;

  FUNCTION FN_VALIDATE_INCOMING_CRC(P_SOURCE      IN VARCHAR2,
                                    P_ACTION_CODE IN VARCHAR2,
                                    P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                    P_PHYFNAME    IN VARCHAR2,
                                    P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                    P_ERR_CODE    IN OUT VARCHAR2,
                                    P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    P_BRANCH_USER  VARCHAR2(50);
    L_FILE_LIST    VARCHAR2(32767);
    L_PROCESS_PATH VARCHAR2(1000);
    L_FILE_COUNT   NUMBER := 1;
    L_PHYFNAME     VARCHAR2(50);
    L_TMP_PHYFNAME VARCHAR2(50);
    L_POS_BRANCH   NUMBER;
    L_PHYFCOUNT    NUMBER := 0;
    TYPE TY_FILE_NAME IS TABLE OF VARCHAR2(50) INDEX BY PLS_INTEGER;
    L_PHYALLFILENAME   TY_FILE_NAME;
    IDX                PLS_INTEGER;
    L_PHYSICALFILENAME VARCHAR2(50);
    L_FILE_NAME        VARCHAR2(50);
    IN_CRC_FILE_PATH   VARCHAR2(1000);
    IN_CRC_FILE_NAME   VARCHAR2(1000);
    IN_CONF_FILE_PATH  VARCHAR2(1000);
    IN_CONF_FILE_NAME  VARCHAR2(1000);
    FILE_TYPE          UTL_FILE.FILE_TYPE;
    LINE_TEXT          VARCHAR2(1000);
    CRC_VALUE          VARCHAR2(100);
    CRC_SQL            VARCHAR2(32767);
    C_SQL              VARCHAR2(32767);
    L_CURSOR           NUMBER;
    L_COUNT            NUMBER;
    FNID_COUNT         NUMBER;
    L_RETURN           NUMBER;
    L_DIR_NAME         ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;

  BEGIN
    DBG('inside fn_validate_incoming_crc');

    IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE IN ('FP', 'AL') THEN
      IF P_FORMAT_DTLS.CRC_REQUIRED = 'Y' THEN
        DBG('Calculation CRC Value for Filename');
        IN_CRC_FILE_PATH := SUBSTR(P_FORMAT_DTLS.FILE_PATH,
                                   0,
                                   INSTR(P_FORMAT_DTLS.FILE_PATH,
                                         GLOBAL.SLASH,
                                         -1)) || 'crc' || GLOBAL.SLASH ||
                            'ready';
        IN_CRC_FILE_NAME := SUBSTR(P_PHYFNAME,
                                   1,
                                   INSTR(P_PHYFNAME, '.') - 1) || '.CRC';
        BEGIN

          IF GLOBAL.IS12CR2 <> 'Y' THEN
            FILE_TYPE := UTL_FILE.FOPEN(IN_CRC_FILE_PATH,
                                        IN_CRC_FILE_NAME,
                                        'r',
                                        NULL);

          ELSE
            IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(IN_CRC_FILE_PATH,
                                                         L_DIR_NAME,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
              DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
              RETURN FALSE;
            END IF;
            FILE_TYPE := UTL_FILE.FOPEN(L_DIR_NAME,
                                        IN_CRC_FILE_NAME,
                                        'r',
                                        NULL);
          END IF;

          UTL_FILE.GET_LINE(FILE_TYPE, LINE_TEXT, 32767);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in reading CRC file : ' || IN_CRC_FILE_PATH || '/' ||
                IN_CRC_FILE_NAME);
            DBG('CRC File Does Not Exists ');
            P_ERR_CODE   := 'GI-CRC-006';
            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
        END;

        IF P_FORMAT_DTLS.CRC_ALGORITHM NOT IN ('CRC32', 'ADLER32') THEN
          BEGIN
            SELECT DEFAULT_CRC
              INTO CRC_SQL
              FROM GITM_CRC_CHECKSUM
             WHERE CRC_NAME = P_FORMAT_DTLS.CRC_ALGORITHM;
            IN_CRC_FILE_PATH := IN_CRC_FILE_PATH || GLOBAL.SLASH ||
                                P_PHYFNAME;
            C_SQL            := ' DECLARE ' || CHR(10);
            C_SQL            := C_SQL || 'ABS_FILE_PATH VARCHAR2(2000):=' || '' ||
                                IN_CRC_FILE_PATH || '' || '; ' || CHR(10);
            C_SQL            := C_SQL || 'CRC_VALUE VARCHAR2(30); ' ||
                                CHR(10);
            C_SQL            := C_SQL || ' BEGIN ' || CHR(10);
            C_SQL            := C_SQL || CRC_SQL || CHR(10);
            C_SQL            := C_SQL || ' CRC_VALUE:= L_CRC_VALUE ; ' ||
                                CHR(10);
            C_SQL            := C_SQL ||
                                'gipks_interface_trigger.g_crc_value:= CRC_VALUE;' ||
                                CHR(10);
            C_SQL            := C_SQL || 'END;' || CHR(10);

            L_CURSOR := DBMS_SQL.OPEN_CURSOR;
            DBMS_SQL.PARSE(L_CURSOR, C_SQL, DBMS_SQL.NATIVE);
            L_RETURN := DBMS_SQL.EXECUTE(L_CURSOR);
            DBMS_SQL.CLOSE_CURSOR(L_CURSOR);
            CRC_VALUE := GIPKS_INTERFACE_TRIGGER.G_CRC_VALUE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in generating CRC Value...');
              P_ERR_CODE   := 'GI-PRS-021';
              P_ERR_PARAMS := NULL;

          END;

        ELSE
          DBG('in_crc_file_path - ' || IN_CRC_FILE_PATH);
          DBG('in_crc_file_name - ' || IN_CRC_FILE_NAME);
          DBG('crc_value - ' || CRC_VALUE);
          DBG('p_format_dtls.crc_algorithm - ' ||
              P_FORMAT_DTLS.CRC_ALGORITHM);

    IF NOT FN_GENERATE_CRC(CASE g_interface_code WHEN 'DEUPLOAD' THEN
                                 'DEUPLD_I/ready' WHEN 'SVUPLOAD' THEN
                                 'DEUPLD_I/ready' WHEN 'IXRATEJU' THEN
                                 'XRUPLD_I/ready' ELSE NULL END,

                                 -- 'XRUPLD_I/ready', --P_FORMAT_DTLS.FILE_PATH || GLOBAL.SLASH ||
                                 --'ready',
                                 P_PHYFNAME,
                                 CRC_VALUE,
                                 NVL(P_FORMAT_DTLS.CRC_ALGORITHM, 'CRC32'),
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
            DBG('Failed in generating CRC Value...');
            P_ERR_CODE   := 'GI-PRS-021';
            P_ERR_PARAMS := NULL;

            RETURN FALSE;
          END IF;
        END IF;
        UTL_FILE.FCLOSE(FILE_TYPE);
        L_COUNT := INSTR(LINE_TEXT, CRC_VALUE, 1);
        DBG('Actual CRC value : ' || CRC_VALUE);
        IF TRIM(LINE_TEXT) <> CRC_VALUE THEN
          DBG('File is Corrupted ');
          P_ERR_CODE   := 'GI-CRC-005';
          P_ERR_PARAMS := NULL;

          RETURN FALSE;
        END IF;
      END IF;
      DBG('4. CRC Validation was successfull and returns true...');
      DBG('5. Validating Confiramtion File ...');
      IF P_FORMAT_DTLS.CONFIRM_FILE_REQD = 'Y' THEN

        IN_CONF_FILE_PATH := P_FORMAT_DTLS.CONFIRMATION_FILE_PATH ||
                             GLOBAL.SLASH || 'ready';
        IN_CONF_FILE_NAME := SUBSTR(P_PHYFNAME,
                                    1,
                                    INSTR(P_PHYFNAME, '.') - 1) || '.CNF';
        BEGIN

          IF GLOBAL.IS12CR2 <> 'Y' THEN
            FILE_TYPE := UTL_FILE.FOPEN(IN_CONF_FILE_PATH,
                                        IN_CONF_FILE_NAME,
                                        'r',
                                        NULL);

          ELSE
            IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(IN_CONF_FILE_PATH,
                                                         L_DIR_NAME,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
              DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
              RETURN FALSE;
            END IF;
            FILE_TYPE := UTL_FILE.FOPEN(L_DIR_NAME,
                                        IN_CONF_FILE_NAME,
                                        'r',
                                        NULL);
          END IF;
          UTL_FILE.FCLOSE(FILE_TYPE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('CONFIRMATION FILE DOES NOT EXISTS... ');
            P_ERR_CODE   := 'GI-CNF-001';
            P_ERR_PARAMS := NULL;

            RETURN FALSE;
        END;

      END IF;
      DBG('5. Validation for Confiramtion file Successfull....');
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of gipks_interface_trigger.fn_validate_incoming_crc ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_INCOMING_CRC;

  FUNCTION FN_VALIDATE_RETRY(P_SOURCE      IN VARCHAR2,
                             P_ACTION_CODE IN VARCHAR2,
                             P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                             P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                             P_ERR_CODE    IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_STATUS       VARCHAR2(2);
    P_FILE_LOG     GITB_FILE_LOG%ROWTYPE;
    L_COUNT        NUMBER;
    L_PROCESS_CODE VARCHAR2(100);
    L_SERIAL_NO    NUMBER;
  BEGIN
    BEGIN
      SELECT STATUS, PROCESS_CODE
        INTO L_STATUS, L_PROCESS_CODE
        FROM GITB_FILE_LOG
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
         AND START_DATE_STAMP =
             (SELECT MAX(START_DATE_STAMP)
                FROM GITB_FILE_LOG
               WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                 AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                 AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                 AND FILE_NAME =
                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME)
         AND PK_SERIAL_NO =
             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PK_SERIAL_NO;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('File $1 of Interface $2 was not processed today to Initiate Retry Process');
        P_ERR_CODE   := 'GI-PRS-025';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                        P_FORMAT_DTLS.INTERFACE_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
    END;
    IF L_STATUS = 'P' THEN
      DBG('Record already Processed  for Interface $1');
      PR_LOG_ERROR(P_SOURCE, 'GI-PRS-024', P_FORMAT_DTLS.INTERFACE_CODE);
      RETURN FALSE;
    ELSIF L_STATUS = 'W' OR L_STATUS = 'U' THEN
      DBG('Other Process already in Progress for Interface $1...');
      PR_LOG_ERROR(P_SOURCE, 'GI-PRS-028', NULL);
      RETURN FALSE;
    ELSIF L_STATUS = 'E' THEN
      SAVEPOINT RETRY;

      UPDATE GITB_FILE_LOG
         SET STATUS = 'R'
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
         AND STATUS = 'E'
         AND START_DATE_STAMP =
             (SELECT MAX(START_DATE_STAMP)
                FROM GITB_FILE_LOG
               WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                 AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                 AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                 AND FILE_NAME =
                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);

      UPDATE GITM_UPLOAD_MASTER
         SET STATUS = 'U', ERROR = NULL, ERROR_PARAM = NULL
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                 '.',
                                 '_');

      DBG('Current process Code is...' || L_PROCESS_CODE);
      P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE := L_PROCESS_CODE;

    END IF;

    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO RETRY;
      DEBUG.PR_DEBUG('GI', 'In when others of fn_validate_retry....');
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_RETRY;

  FUNCTION FN_VALIDATE_RETRY_ERROR(P_SOURCE      IN VARCHAR2,
                                   P_ACTION_CODE IN VARCHAR2,
                                   P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                   P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_SERIAL_NO NUMBER;
    L_COUNT     NUMBER;
  BEGIN
    BEGIN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM GITB_FILE_LOG
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
         AND PROCESS_CODE = 'DP'
         AND START_DATE_STAMP =
             (SELECT MAX(START_DATE_STAMP)
                FROM GITB_FILE_LOG
               WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                 AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                 AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                 AND FILE_NAME =
                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
                 AND PROCESS_CODE = 'DP')
         AND STATUS = 'E';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('File $1 is not in Error Stage to Process Retry for Interface Code $2');
        P_ERR_CODE   := 'GI-PRS-025';
        P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                        P_FORMAT_DTLS.INTERFACE_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
    END;
    SAVEPOINT RETRY_ERROR;
    IF L_COUNT = 1 THEN

      UPDATE GITB_FILE_LOG
         SET STATUS = 'R'
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
         AND STATUS = 'E'
         AND PROCESS_CODE = 'DP'
         AND START_DATE_STAMP =
             (SELECT MAX(START_DATE_STAMP)
                FROM GITB_FILE_LOG
               WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                 AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                 AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                 AND FILE_NAME =
                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
                 AND PROCESS_CODE = 'DP');

      UPDATE GITM_UPLOAD_MASTER
         SET STATUS = 'U', ERROR = NULL, ERROR_PARAM = NULL
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                 '.',
                                 '_');

    ELSIF L_COUNT = 0 THEN
      DBG('No Records Found...');
      DBG('File $1 is not in Error Stage to Process Retry for Interface Code $2');
      P_ERR_CODE   := 'GI-PRS-029';
      P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                      P_FORMAT_DTLS.INTERFACE_CODE;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    ELSE
      DBG('Duplicate Records Exists.in Log..');
      P_ERR_CODE   := 'GI-PRS-026';
      P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                      P_FORMAT_DTLS.INTERFACE_CODE;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    DBG('Validated Successfully and defaulted successfully for Retry Error Process Code...');
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO RETRY_ERROR;
      DEBUG.PR_DEBUG('GI', 'In when others of fn_validate_retry_error....');
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_RETRY_ERROR;

  FUNCTION FN_IS_FILE_EXISTS(

                             FILE_PATH IN OUT VARCHAR2,

                             FILE_NAME    IN VARCHAR2,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    BUFFER_SIZE NUMBER := 32767;
    FILE_TYPE   UTL_FILE.FILE_TYPE;
    FILE_EXISTS BOOLEAN := TRUE;
    LEN         NUMBER;
    BLK_SIZE    BINARY_INTEGER;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_DEST_LOC              VARCHAR2(500) := '';

    L_DIR_NAME ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;

  BEGIN
    DBG('In fn_is_file_exists....');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 5;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_GET_DIRECTORY_NAME('',
                                                               FILE_PATH,
                                                               L_DEST_LOC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAMS) THEN
        DBG('Failed in GIPKS_INTERFACE_TRIGGERCLUSTER.Fn_Is_File_Exists');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('FILE_PATH FILE_PATH='||FILE_PATH);
    DBG('FILE_NAME FILE_NAME='||FILE_NAME);
    DBG('LEN LEN='||LEN);
    DBG('BLK_SIZE BLK_SIZE='||BLK_SIZE);

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      UTL_FILE.FGETATTR(FILE_PATH, FILE_NAME, FILE_EXISTS, LEN, BLK_SIZE);

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(FILE_PATH,
                                                   L_DIR_NAME,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      UTL_FILE.FGETATTR(L_DIR_NAME, FILE_NAME, FILE_EXISTS, LEN, BLK_SIZE);
    END IF;

    IF FILE_EXISTS THEN
      IF GLOBAL.IS12CR2 <> 'Y' THEN
        FILE_TYPE := UTL_FILE.FOPEN(FILE_PATH, FILE_NAME, 'r', BUFFER_SIZE);
      ELSE
        FILE_TYPE := UTL_FILE.FOPEN(L_DIR_NAME, FILE_NAME, 'r', BUFFER_SIZE);
      END IF;
      UTL_FILE.FCLOSE(FILE_TYPE);
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.INVALID_PATH_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_MODE THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.INVALID_MODE_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_OPERATION THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.INVALID_OPERATION_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN UTL_FILE.INVALID_FILENAME THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.INVALID_FILENAME_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN UTL_FILE.FILE_OPEN THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.INVALID_FILEHANDLE_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN UTL_FILE.ACCESS_DENIED THEN
      UTL_FILE.FCLOSE(FILE_TYPE);
      P_ERR_CODE   := UTL_FILE.ACCESS_DENIED_ERRCODE;
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    WHEN OTHERS THEN
      P_ERR_CODE   := 'GI-PRS-005';
      P_ERR_PARAMS := FILE_NAME;
      UTL_FILE.FCLOSE(FILE_TYPE);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_IS_FILE_EXISTS;

  FUNCTION FN_PROCESS_IN_FILE(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_ACTION_CODE    IN VARCHAR2,
                              P_GIDIFPRS       IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                              P_FORMAT_DTLS    IN GITM_FORMAT_DEFINITION%ROWTYPE,
                              P_STATUS         IN OUT VARCHAR2,
                              P_ERR_CODE       IN OUT VARCHAR2,
                              P_ERR_PARAMS     IN OUT VARCHAR2,
                              L_PHYFNAME       IN VARCHAR2,
                              L_FP_FAILED_ONCE IN OUT NUMBER) RETURN BOOLEAN IS

    E_RETURN_EXCEPTION EXCEPTION;
    P_BRANCH_CODE    GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE;
    P_EXT_SYSTEM     GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE;
    P_INTERFACE_CODE GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE;
    P_FILE_NAME      GITM_FILE_NAMES.FILE_NAME%TYPE;
    SRC_LOC          VARCHAR2(200);
    SRC_FILE_NAME    VARCHAR2(200);
    DEST_LOC         VARCHAR2(200);
    DEST_FILE_NAME   VARCHAR2(200);
    L_IN_FILE_PATH   VARCHAR2(1000);
    L_IN_CRC_PATH    VARCHAR2(1000);
    L_IN_CONF_PATH   VARCHAR2(1000);
    L_IN_DIR         VARCHAR2(100);
    F_PROG           VARCHAR2(32767);
    F_SQL            VARCHAR2(32767);
    L_MODULE         VARCHAR2(2) := 'GI';
    E_FAILURE_EXCEPTION EXCEPTION;

    FP_STATUS     BOOLEAN := FALSE;
    P_PROCESS_CNT NUMBER;
    P_SERIAL      NUMBER;

    L_FILE_LIST  VARCHAR2(32767);
    L_FILE_COUNT NUMBER := 1;
    L_PHYFCOUNT  NUMBER := 0;

    L_PHYSICALFILENAME GITB_FILE_LOG.PHY_FILE_NAME%TYPE;
    TYPE TY_FILE_NAME IS TABLE OF GITB_FILE_LOG.PHY_FILE_NAME%TYPE INDEX BY PLS_INTEGER;

    L_PHYALLFILENAME TY_FILE_NAME;
    L_SEPARATOR      VARCHAR2(5);
    IDX              PLS_INTEGER;
    L_PROCESS_PATH   VARCHAR2(1000);
    L_FILE_NAME      VARCHAR2(50);
    L_ERR_CODE       VARCHAR2(100);
    L_ERR_PARAM      VARCHAR2(100);

    L_FILE_ALREADY_PROCESSED NUMBER;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Entered into fn_process_in_file');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_in_file1');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_IN_FILE(P_SOURCE,
                                                            P_ACTION_CODE,
                                                            P_GIDIFPRS,
                                                            P_FORMAT_DTLS,
                                                            P_STATUS,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS,
                                                            L_PHYFNAME,
                                                            L_FP_FAILED_ONCE) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_in_file***please check');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      L_IN_FILE_PATH := P_FORMAT_DTLS.FILE_PATH;
      DBG('#1# l_in_file_path : ' || L_IN_FILE_PATH);


   IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        L_PROCESS_PATH := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath
        L_PROCESS_PATH := 'XRUPLD_I/ready'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'ready';

      END IF; --sampath

      DBG('File search Path is : ' || L_PROCESS_PATH);
      L_PHYSICALFILENAME := L_PHYFNAME;
      DBG('Processing starts for the physical file name : ' ||
          L_PHYSICALFILENAME);
      P_SERIAL := GIPKS_INTERFACE_TRIGGER.G_SERIAL;

      IF NOT FN_SET_FILE_LOG_FILEMASTER(P_SOURCE,
                                        P_GIDIFPRS,
                                        P_FORMAT_DTLS.BRANCH_CODE,
                                        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                        GLOBAL.APPLICATION_DATE,
                                        P_SERIAL,
                                        'U',
                                        P_ERR_CODE,
                                        P_ERR_PARAMS,
                                        L_PHYSICALFILENAME) THEN
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG('Failed in Inserting into File Log');
        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;
      DBG('p_format_dtls.dup_file_check_reqd 435345 : ' ||
          P_FORMAT_DTLS.DUP_FILE_CHECK_REQD);
      DBG('p_gidifprs.ifprs_gitm_interface_trigger.file_name : ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
      DBG('p_gidifprs.ifprs_gitm_interface_trigger.interface_code : ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
      DBG('Physical FIle Name : ' || L_PHYFNAME);
      DBG('p_gidifprs.ifprs_gitm_interface_trigger.process_code : ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);
      DBG('Process Date : ' || GLOBAL.APPLICATION_DATE);

      IF NVL(P_FORMAT_DTLS.DUP_FILE_CHECK_REQD, 'N') = 'Y' THEN
        SELECT COUNT(*)
          INTO L_FILE_ALREADY_PROCESSED
          FROM GITB_FILE_MASTER
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
           AND FILE_NAME =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
           AND PHY_FILE_NAME = L_PHYFNAME
           AND PROCESS_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE

           AND UPLOAD_STATUS IN ('P', 'W')
           AND PROCESS_DATE = GLOBAL.APPLICATION_DATE;

        DBG('l_file_already_processed value : ' ||
            L_FILE_ALREADY_PROCESSED);

        IF L_FILE_ALREADY_PROCESSED > 0 THEN
          DBG('Duplication of file occurs');
          P_ERR_CODE   := 'GI-INF-62';
          P_ERR_PARAMS := 'Duplication of File Occurs';
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
          BEGIN

            UPDATE GITB_FILE_MASTER
               SET UPLOAD_STATUS = 'E',
                   ERROR_CODE    = 'GI-INF-62',
                   ERROR_PARAMS  = 'Duplication of File Occurs : ' ||
                                   L_PHYFNAME || '. So Process Cancelled.'
             WHERE PROCESS_REF_NO = P_SERIAL;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Exception in updating the error log');
          END;
          RETURN FALSE;
        END IF;
      END IF;

      DBG('Copying File From Ready  to WIP Folder');


   IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        SRC_LOC := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

      ELSE
        --sampath
        SRC_LOC := 'XRUPLD_I/ready'; --P_FORMAT_DTLS.FILE_PATH || GLOBAL.SLASH || 'ready';

      END IF; --sampath


      SRC_FILE_NAME  := L_PHYSICALFILENAME;

 IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        DEST_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

      ELSE
        --sampath
        DEST_LOC := 'XRUPLD_I/wip'; --P_FORMAT_DTLS.FILE_PATH || GLOBAL.SLASH || 'wip';

      END IF; --sampath


      DEST_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

      IF FN_IS_FILE_EXISTS(DEST_LOC,
                           DEST_FILE_NAME,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('File type already available in the folder WIP ');
        P_ERR_CODE   := 'GI-INF-61';
        P_ERR_PARAMS := 'wip';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

        RETURN FALSE;
      END IF;

      IF NOT FN_MOVE_FILE(P_SOURCE,
                          SRC_LOC,
                          DEST_LOC,
                          SRC_FILE_NAME,
                          DEST_FILE_NAME,
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
        DBG('Failed in Copying file from Ready to WIP Folder');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;
      DBG('Successfully copied file from Ready to WIP Folder');
      DBG('Going to Update Log to work in progress stage...');
      P_INTERFACE_CODE  := P_FORMAT_DTLS.INTERFACE_CODE;
      G_INTERFACE_CODE  := P_FORMAT_DTLS.INTERFACE_CODE;
      G_FILE_NAME       := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
      G_PHY_FILE_NAME   := L_PHYSICALFILENAME;
      G_BRANCH_CODE     := P_FORMAT_DTLS.BRANCH_CODE;
      G_EXTERNAL_SYSTEM := P_FORMAT_DTLS.EXTERNAL_SYSTEM;

      IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                      P_GIDIFPRS,
                                      G_BRANCH_CODE,
                                      G_FILE_NAME,
                                      CURRENT_TIMESTAMP,
                                      'U',
                                      'W',
                                      P_SERIAL,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS,
                                      L_PHYSICALFILENAME) THEN
        DBG('Failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RAISE E_RETURN_EXCEPTION;
        RETURN FALSE;
      END IF;

      GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME := L_PHYSICALFILENAME;
      GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO  := GIPKS_INTERFACE_TRIGGER.G_SERIAL;
      GIPKS_INTERFACE_TRIGGER.G_STATUS        := 'U';

      DBG('p_gidifprs.ifprs_gitm_interface_trigger.process_code' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);
      DBG('File Name is ....' || G_FILE_NAME);
      DBG('File Name is ....' || GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
      F_PROG := L_MODULE || 'PKS_' ||
                DBMS_ASSERT.SIMPLE_SQL_NAME(P_INTERFACE_CODE) || '_' ||
                REPLACE(G_FILE_NAME, '.', '_') || '.fn_process_file';
      DBG('Package Name ' || F_PROG);

      DBG('#25461173 GIPKS_INTERFACE_TRIGGER.g_interface_code ' ||
          GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
      DBG('#25461173 GIPKS_INTERFACE_TRIGGER.g_file_name ' ||
          GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
      DBG('#25461173 GIPKS_INTERFACE_TRIGGER.g_phy_file_name ' ||
          GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME);
      DBG('#25461173 GIPKS_INTERFACE_TRIGGER.g_ProcessRefNo ' ||
          GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO);
      DBG('#25461173 GIPKS_INTERFACE_TRIGGER.g_status ' ||
          GIPKS_INTERFACE_TRIGGER.G_STATUS);

      F_SQL := 'DECLARE ' || CHR(10);
      F_SQL := F_SQL || ' ' ||
               'l_err_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_code;  ' ||
               CHR(10);
      F_SQL := F_SQL || ' ' ||
               'l_err_params     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_params;  ' ||
               CHR(10);
      F_SQL := F_SQL || ' ' ||
               'l_intf_code     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_interface_code;  ' ||
               CHR(10);
      F_SQL := F_SQL || ' ' ||
               'l_file_name     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_file_name;  ' ||
               CHR(10);

      F_SQL := F_SQL || ' ' ||
               'l_phy_file_name     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_phy_file_name;  ' ||
               CHR(10);
      F_SQL := F_SQL || ' ' ||
               'l_ProcessRefNo     varchar2(50):=  GIPKS_INTERFACE_TRIGGER.g_ProcessRefNo;  ' ||
               CHR(10);

      F_SQL := F_SQL || ' ' ||
               'l_status     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_status;  ' ||
               CHR(10);
      F_SQL := F_SQL || 'BEGIN' || CHR(10);

      F_SQL := F_SQL || 'IF NOT ' || F_PROG ||
               '(l_intf_code, l_file_name, l_phy_file_name, l_ProcessRefNo, l_err_code, l_err_params,l_status)  THEN ' ||
               CHR(10);

      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := FALSE;' ||
               CHR(10);
      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status := l_status;' ||
               CHR(10);
      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_err_code := l_err_code;' ||
               CHR(10);
      F_SQL := F_SQL ||
               'GIPKS_INTERFACE_TRIGGER.g_err_params := l_err_params;' ||
               CHR(10);
      F_SQL := F_SQL || 'ELSE ' || CHR(10);
      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := TRUE;' ||
               CHR(10);
      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status := l_status;' ||
               CHR(10);
      F_SQL := F_SQL || 'GIPKS_INTERFACE_TRIGGER.g_err_code := l_err_code;' ||
               CHR(10);
      F_SQL := F_SQL ||
               'GIPKS_INTERFACE_TRIGGER.g_err_params := l_err_params;' ||
               CHR(10);
      F_SQL := F_SQL || 'END IF;' || CHR(10);
      F_SQL := F_SQL || 'END;' || CHR(10);
      DBG('DYNAMIC SQL...');
      DBG(F_SQL);
      BEGIN
        EXECUTE IMMEDIATE F_SQL;
        P_ERR_CODE   := GIPKS_INTERFACE_TRIGGER.G_ERR_CODE;
        P_ERR_PARAMS := GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_CODE   := GIPKS_INTERFACE_TRIGGER.G_ERR_CODE;
          P_ERR_PARAMS := GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS;
          DEBUG.PR_DEBUG('GI', SQLERRM);
          GIPKS_INTERFACE_TRIGGER.G_ERR_CODE := 'GI-PRS-045';
          GIPKS_INTERFACE_TRIGGER.G_STATUS   := 'E';
          L_FP_FAILED_ONCE                   := L_FP_FAILED_ONCE + 1;
          PR_LOG_ERROR(P_SOURCE, G_ERR_CODE, G_ERR_PARAMS);

          IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                          P_GIDIFPRS,
                                          G_BRANCH_CODE,
                                          G_FILE_NAME,
                                          CURRENT_TIMESTAMP,
                                          'W',
                                          'E',
                                          P_SERIAL,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS,
                                          L_PHYSICALFILENAME) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;



    IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

          ELSE
            --sampath
            SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
          END IF;

          SRC_FILE_NAME  := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;


     IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

          ELSE
            --sampath
            DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
          END IF; --sampath

          DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

          IF FN_IS_FILE_EXISTS(DEST_LOC,
                               DEST_FILE_NAME,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
            DBG('File name already available in the folder ERROR ');
            P_ERR_CODE   := 'GI-INF-61';
            P_ERR_PARAMS := 'error';

            RETURN FALSE;
          END IF;

          IF NOT FN_MOVE_FILE(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
            DBG('Failed in Copying fie from wip to ERROR Folder');
            RETURN FALSE;
          END IF;
          RETURN FALSE;
      END;
      DBG('GIPKS_INTERFACE_TRIGGER.g_status = ' ||
          GIPKS_INTERFACE_TRIGGER.G_STATUS);
      IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'S' THEN
        P_ERR_CODE   := 'GI-PRS-044';
        P_ERR_PARAMS := 'FP Success';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        GIPKS_INTERFACE_TRIGGER.G_ERR_CODE := 'GI-PRS-044';
        L_ERR_CODE                         := P_ERR_CODE;
        L_ERR_PARAM                        := P_ERR_PARAMS;

        IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                        P_GIDIFPRS,
                                        G_BRANCH_CODE,
                                        G_FILE_NAME,
                                        CURRENT_TIMESTAMP,
                                        'W',
                                        'P',
                                        P_SERIAL,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS,
                                        L_PHYSICALFILENAME) THEN
          DBG('Failed in Updating the Log');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RAISE E_RETURN_EXCEPTION;
          RETURN FALSE;
        END IF;
        DBG('Checking for Parallel Process is Required or not...');
        IF P_FORMAT_DTLS.PARALLEL_PROCESS_REQD = 'Y' THEN
          IF FN_GET_PROCESS_COUNT(P_SOURCE,
                                  P_ACTION_CODE,
                                  P_GIDIFPRS,
                                  P_FORMAT_DTLS,
                                  P_PROCESS_CNT,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
            DBG('Number of parallel processes...' || P_PROCESS_CNT);
            IF NOT FN_UPDATE_PROCESS(P_SOURCE,
                                     P_ACTION_CODE,
                                     P_GIDIFPRS,
                                     P_FORMAT_DTLS,
                                     P_PROCESS_CNT,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
              DBG('Failed in fn_update_process for upload master...');
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
              RAISE E_RETURN_EXCEPTION;
            END IF;


     IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

            ELSE
              --sampath
              SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';

            END IF; --sampath

            SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

            IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              DEST_LOC := 'DEUPLD_I/file_processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

            ELSE
              --sampath
              DEST_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH ||
              --'file_processed';
            END IF;


            DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

            IF FN_IS_FILE_EXISTS(DEST_LOC,
                                 DEST_FILE_NAME,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
              DBG('File name already available in the folder file_processed');
              P_ERR_CODE   := 'GI-INF-61';
              P_ERR_PARAMS := 'file_processed';
              RAISE E_RETURN_EXCEPTION;
              RETURN FALSE;
            ELSE
              P_ERR_CODE   := L_ERR_CODE;
              P_ERR_PARAMS := L_ERR_PARAM;
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            END IF;

            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in Copying fie from wip to FILE_PROCESSED Folder');
              RAISE E_RETURN_EXCEPTION;
              RETURN FALSE;
            END IF;
          END IF;

        ELSE


    IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

          ELSE
            --sampath
            SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';

          END IF; --sampath

          SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

          IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            DEST_LOC := 'DEUPLD_I/file_processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

          ELSE
            --sampath
            DEST_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH ||
            --'file_processed';
          END IF;


          DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

          IF FN_IS_FILE_EXISTS(DEST_LOC,
                               DEST_FILE_NAME,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
            DBG('File name already available in the folder file_processed');
            P_ERR_CODE   := 'GI-INF-61';
            P_ERR_PARAMS := 'file_processed';

            RAISE E_RETURN_EXCEPTION;

            RETURN FALSE;

          ELSE
            P_ERR_CODE   := L_ERR_CODE;
            P_ERR_PARAMS := L_ERR_PARAM;
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

          END IF;

          IF NOT FN_MOVE_FILE(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
            DBG('Failed in Copying fie from wip to FILE_PROCESSED Folder');

            RAISE E_RETURN_EXCEPTION;
            RETURN FALSE;
          END IF;
        END IF;

        P_STATUS := GIPKS_INTERFACE_TRIGGER.G_STATUS;
        RETURN TRUE;
      END IF;
      P_STATUS := G_STATUS;
      DBG('p_status' || P_STATUS);
      IF NOT GIPKS_INTERFACE_TRIGGER.G_RETURN AND
         GIPKS_INTERFACE_TRIGGER.G_STATUS = 'E' THEN
        DBG('Function Id package ' || F_PROG || ' has returned False..');
        IF P_STATUS = 'E' THEN
          DBG('Failed in generation of FP Process for interface code' ||
              P_INTERFACE_CODE);
          L_FP_FAILED_ONCE                   := L_FP_FAILED_ONCE + 1;
          FP_STATUS                          := FALSE;
          GIPKS_INTERFACE_TRIGGER.G_ERR_CODE := 'GI-PRS-045';
          IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                          P_GIDIFPRS,
                                          G_BRANCH_CODE,
                                          G_FILE_NAME,
                                          CURRENT_TIMESTAMP,
                                          'W',
                                          'E',
                                          P_SERIAL,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS,
                                          L_PHYSICALFILENAME) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          RAISE E_RETURN_EXCEPTION;
        END IF;
      END IF;
    END IF;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_in_file2');
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_IN_FILE(P_SOURCE,
                                                            P_ACTION_CODE,
                                                            P_GIDIFPRS,
                                                            P_FORMAT_DTLS,
                                                            P_STATUS,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS,
                                                            L_PHYFNAME,
                                                            L_FP_FAILED_ONCE) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_in_file***please check');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Exit from fn_process_in_file_1 with TRUE');
    RETURN TRUE;
  EXCEPTION
    WHEN E_RETURN_EXCEPTION THEN

      DEBUG.PR_DEBUG('GI',
                     'From E_Return_Exception of GIPKS_INTERFACE_TRIGGER.fn_process_IN_FILE');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_ERR_CODE  := P_ERR_CODE;
      L_ERR_PARAM := P_ERR_PARAMS;
      DBG('p_err_code1 :' || P_ERR_CODE);



    IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

      ELSE
        --sampath
        SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
      END IF; --sampah

      SRC_FILE_NAME  := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
   --sampath
        DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath
        DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
      END IF;


      DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

      IF FN_IS_FILE_EXISTS(DEST_LOC,
                           DEST_FILE_NAME,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('File name already available in the folder ERROR ');
        P_ERR_CODE   := 'GI-INF-61';
        P_ERR_PARAMS := 'error';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;

      ELSE
        P_ERR_CODE   := L_ERR_CODE;
        P_ERR_PARAMS := L_ERR_PARAM;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

      END IF;
      DBG('p_err_code2 :' || P_ERR_CODE);
      IF NOT FN_MOVE_FILE(P_SOURCE,
                          SRC_LOC,
                          DEST_LOC,
                          SRC_FILE_NAME,
                          DEST_FILE_NAME,
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
        DBG('Failed in Copying fie from wip to ERROR Folder');
        RETURN FALSE;
      END IF;
      DBG('p_err_code3 :' || P_ERR_CODE);
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('GI',
                     'In when others of fn_process_in_file...' || SQLERRM);
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_PROCESS_IN_FILE;

  FUNCTION FN_PROCESS_IN_FILE(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                              P_ACTION_CODE IN VARCHAR2,
                              P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                              P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                              P_STATUS      IN OUT VARCHAR2,
                              P_ERR_CODE    IN OUT VARCHAR2,
                              P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    P_BRANCH_CODE    GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE;
    P_EXT_SYSTEM     GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE;
    P_INTERFACE_CODE GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE;
    P_FILE_NAME      GITM_FILE_NAMES.FILE_NAME%TYPE;
    SRC_LOC          VARCHAR2(200);
    SRC_FILE_NAME    VARCHAR2(200);
    DEST_LOC         VARCHAR2(200);
    DEST_FILE_NAME   VARCHAR2(200);
    L_IN_FILE_PATH   VARCHAR2(1000);
    L_IN_CRC_PATH    VARCHAR2(1000);
    L_IN_CONF_PATH   VARCHAR2(1000);
    L_IN_DIR         VARCHAR2(100);
    F_PROG           VARCHAR2(32767);
    F_SQL            VARCHAR2(32767);
    L_MODULE         VARCHAR2(2) := 'GI';
    E_FAILURE_EXCEPTION EXCEPTION;
    G_RETURN      BOOLEAN := TRUE;
    FP_STATUS     BOOLEAN := FALSE;
    P_PROCESS_CNT NUMBER;
    P_SERIAL      NUMBER;

    L_FILE_LIST        VARCHAR2(32767);
    L_FILE_COUNT       NUMBER := 1;
    L_PHYFCOUNT        NUMBER := 0;
    L_PHYSICALFILENAME VARCHAR2(50);
    TYPE TY_FILE_NAME IS TABLE OF VARCHAR2(50) INDEX BY PLS_INTEGER;
    L_PHYALLFILENAME TY_FILE_NAME;
    L_PHYFNAME       VARCHAR2(50);
    L_SEPARATOR      VARCHAR2(5);
    IDX              PLS_INTEGER;
    L_PROCESS_PATH   VARCHAR2(1000);
    L_FILE_NAME      VARCHAR2(50);
    L_FP_FAILED_ONCE NUMBER := 0;
    L_IF_PROCESSED   NUMBER := 0;
    L_PROCESS_FREQ   GITM_INTERFACE_DEFINITION.FREQUENCY%TYPE;
    P_BRANCH_USER    VARCHAR2(50);
    L_POS_BRANCH     NUMBER;
    L_TMP_PHYFNAME   VARCHAR2(50);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Entered into fn_process_in_file');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_in_file1');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_IN_FILE(P_SOURCE,
                                                            P_ACTION_CODE,
                                                            P_GIDIFPRS,
                                                            P_FORMAT_DTLS,
                                                            P_STATUS,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_in_file***please check');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      BEGIN
        SELECT NVL(FREQUENCY, 0)
          INTO L_PROCESS_FREQ
          FROM GITM_INTERFACE_DEFINITION
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          L_PROCESS_FREQ := 0;
          DBG('Exception in selecting frequency');
      END;
      DBG('Current process date : ' || GLOBAL.APPLICATION_DATE);
      DBG('l_process_freq value : ' || L_PROCESS_FREQ);
      IF L_PROCESS_FREQ = 1 THEN
        SELECT COUNT(DISTINCT PROCESS_REF_NO)
          INTO L_IF_PROCESSED
          FROM GITB_FILE_MASTER
         WHERE INTERFACE_CODE =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE
           AND PROCESS_CODE = 'FP'
           AND UPLOAD_STATUS = 'P'
           AND PROCESS_DATE = GLOBAL.APPLICATION_DATE;
        DBG('l_if_processed value : ' || L_IF_PROCESSED);
        IF L_IF_PROCESSED > 0 THEN
          DBG('Interface Already Processed for Single Frequency Interface');
          RETURN FALSE;
        END IF;
      END IF;

      L_IN_FILE_PATH := P_FORMAT_DTLS.FILE_PATH;
      DBG('#1# l_in_file_path : ' || L_IN_FILE_PATH);
      P_SERIAL := GISQ_FILE_LOG.NEXTVAL;

      IF NOT FN_SET_FILE_LOG(P_SOURCE,
                             P_GIDIFPRS,
                             P_FORMAT_DTLS.BRANCH_CODE,
                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                             GLOBAL.APPLICATION_DATE,
                             P_SERIAL,
                             'U',
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG('Failed in Inserting into File Log');
        RETURN FALSE;
      END IF;
      GIPKS_INTERFACE_TRIGGER.G_SERIAL := P_SERIAL;


IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        L_PROCESS_PATH := 'DEUPLD_I/ready'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath
        L_PROCESS_PATH := 'XRUPLD_I/ready'; --L_IN_FILE_PATH || GLOBAL.SLASH ||
        --'ready';
      END IF; --sampath


      DBG('File search Path is : ' || L_PROCESS_PATH);
      DBG('File Type name : ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
      L_FILE_NAME := SUBSTR(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                            1,
                            INSTR(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                  '.') - 1);
      DBG('l_file_name --> : ' || L_FILE_NAME);

      P_BRANCH_USER := GLOBAL.CURRENT_BRANCH || '_' || GLOBAL.USER_ID || '_';

      DBG('file mask1 --> ' || P_FORMAT_DTLS.INCOMING_FILE_MASK);
      DBG('phy_file_name-->:' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PHY_FILE_NAME);























      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PHY_FILE_NAME IS NOT NULL THEN

        IF P_FORMAT_DTLS.INCOMING_FILE_MASK <> 'ALL' THEN

          L_FILE_LIST := P_BRANCH_USER ||
                         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PHY_FILE_NAME;

        ELSE
          DBG('BEFORE L_FILE_LIST during upload');
          L_FILE_LIST := FN_WIP_FILES(L_PROCESS_PATH, '*');
        END IF;

      ELSE
        BEGIN

          IF P_FORMAT_DTLS.INCOMING_FILE_MASK <> 'ALL' THEN

            L_FILE_LIST := FN_WIP_FILES(L_PROCESS_PATH, L_FILE_NAME);

          ELSE
            DBG('BEFORE L_FILE_LIST');
            L_FILE_LIST := FN_WIP_FILES(L_PROCESS_PATH, '*');
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('GI', 'Invalid File path2...' || SQLERRM);
            P_ERR_CODE   := 'GI-PRS-083';
            P_ERR_PARAMS := L_PROCESS_PATH;

            DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN FALSE;
        END;

      END IF;

      DBG('l_file_list --> : ' || L_FILE_LIST);

      IF NOT FN_UPDATE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           G_BRANCH_CODE,
                           G_FILE_NAME,
                           CURRENT_TIMESTAMP,
                           'U',
                           'W',
                           P_SERIAL,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('Failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
         G_CUSTOM_LOGGING = 'Y' THEN
        DBG('Before the call to cluster package');
        IF NOT GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                            'W',
                                                            P_SERIAL,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN

          DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
          RETURN FALSE;
        END IF;
        DBG('after the call to cluster package');
      END IF;

      LOOP
        L_PHYFNAME := CSPKES_MISC.FN_GETPARAM(L_FILE_LIST,
                                              L_FILE_COUNT,
                                              ',');
        EXIT WHEN L_PHYFNAME = 'EOPL';
        DBG('Physical file name getting is : ' || L_PHYFNAME);

        L_TMP_PHYFNAME := L_PHYFNAME;
        L_FILE_COUNT   := L_FILE_COUNT + 1;

        IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PHY_FILE_NAME IS NOT NULL THEN
          L_POS_BRANCH := LENGTH(P_BRANCH_USER) + 1;

          L_PHYFNAME := SUBSTR(L_TMP_PHYFNAME, L_POS_BRANCH);

        END IF;

        DBG('l_PhyFname : ' || L_PHYFNAME);
        IF (ISVALIDFILEFORPROCESS(L_PHYFNAME,
                                  P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                  P_FORMAT_DTLS.INCOMING_FILE_MASK) = TRUE) THEN

          DBG('CHECKING FOR CRC AND CONFIRMATION : ' || L_PHYFNAME);
          IF NOT FN_VALIDATE_CRC(P_SOURCE,
                                 P_ACTION_CODE,
                                 P_GIDIFPRS,
                                 L_PHYFNAME,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
            DBG('Failed in Triggering Process validations...');

            DBG('This file cannot be processed : ' || L_PHYFNAME);
          ELSE

            DBG('This file need to be processed : ' || L_PHYFNAME);
            L_PHYFCOUNT := L_PHYFCOUNT + 1;

            IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PHY_FILE_NAME IS NOT NULL THEN
              L_PHYFNAME := P_BRANCH_USER || L_PHYFNAME;
            END IF;

            L_PHYALLFILENAME(L_PHYFCOUNT) := L_PHYFNAME;
          END IF;
        END IF;
      END LOOP;
      DBG('Total number of files to be processed : ' ||
          L_PHYALLFILENAME.COUNT);
      IF L_PHYALLFILENAME.COUNT > 0 THEN
        DBG('*******Starting the File Processing******************');
        IDX := L_PHYALLFILENAME.FIRST;
        WHILE IDX IS NOT NULL LOOP
          L_PHYSICALFILENAME := L_PHYALLFILENAME(IDX);
          DBG('Processing starts for the physical file name : ' ||
              L_PHYSICALFILENAME);
          IF (FN_PROCESS_IN_FILE(P_SOURCE,
                                 P_ACTION_CODE,
                                 P_GIDIFPRS,
                                 P_FORMAT_DTLS,
                                 P_STATUS,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS,
                                 L_PHYSICALFILENAME,
                                 L_FP_FAILED_ONCE)) THEN
            DBG('*******Successfuly processed for  : ' ||
                L_PHYSICALFILENAME);
          ELSE
            DBG('******File Processing Failed for  : ' ||
                L_PHYSICALFILENAME);
            DBG('Error Code : ' || P_ERR_CODE);

            IF P_ERR_CODE = 'GI-INF-61' AND P_ERR_PARAMS = 'wip' THEN
              DBG('Returning false from fn_process_in_file function');

              IF NOT
                  FN_UPDATE_ERR_FILE_LOG(P_SERIAL, P_ERR_CODE, P_ERR_PARAMS) THEN
                DBG('FAILED IN UPDATING interface definition table');

              END IF;

              RETURN FALSE;
            END IF;
          END IF;
          DBG('Fetching next Physical file name...');

          DBG('GIPKS_INTERFACE_TRIGGER.g_status : ' ||
              GIPKS_INTERFACE_TRIGGER.G_STATUS);
          DBG('p_format_dtls.on_override : ' || P_FORMAT_DTLS.ON_OVERRIDE);
          IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'E' THEN
            IF P_FORMAT_DTLS.ON_OVERRIDE = 'R' THEN

              DBG('On override is Reject. so processing of next physical file names are ignored');
              EXIT;
            END IF;
          END IF;
          IDX := L_PHYALLFILENAME.NEXT(IDX);
        END LOOP;
        IF (L_FP_FAILED_ONCE != 0) THEN
          IF NOT FN_UPDATE_LOG(P_SOURCE,
                               P_GIDIFPRS,
                               G_BRANCH_CODE,
                               G_FILE_NAME,
                               CURRENT_TIMESTAMP,
                               'S',
                               'E',
                               P_SERIAL,
                               P_ERR_CODE,
                               P_ERR_PARAMS

                               ) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
             G_CUSTOM_LOGGING = 'Y' THEN
            DBG('Before the call to cluster package');
            IF NOT
                GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                             'E',
                                                             P_SERIAL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN

              DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
              RETURN FALSE;
            END IF;
            DBG('after the call to cluster package');
          END IF;

        ELSE
          IF NOT FN_UPDATE_LOG(P_SOURCE,
                               P_GIDIFPRS,
                               G_BRANCH_CODE,
                               G_FILE_NAME,
                               CURRENT_TIMESTAMP,
                               'S',
                               'P',
                               P_SERIAL,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
             G_CUSTOM_LOGGING = 'Y' THEN
            DBG('Before the call to cluster package');
            IF NOT
                GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                             P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                             'P',
                                                             P_SERIAL,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN

              DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
              RETURN FALSE;
            END IF;
            DBG('after the call to cluster package');
          END IF;

        END IF;

      ELSE

        IF P_ERR_CODE IS NOT NULL THEN
          IF P_FORMAT_DTLS.CRC_REQUIRED <> 'Y' THEN

            P_ERR_CODE   := 'GI-PRS-005';
            P_ERR_PARAMS := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '~' ||
                            P_FORMAT_DTLS.FILE_PATH;
            DBG('Errors     :' || P_ERR_CODE);
            DBG('Parameters :' || P_ERR_PARAMS);

          ELSE
            P_ERR_CODE   := 'GI-PRS-067';
            P_ERR_PARAMS := NULL;
            DBG('Errors     :' || P_ERR_CODE);
          END IF;
        END IF;

        RETURN FALSE;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('GI',
                     'In when others of fn_process_in_file...' || SQLERRM);
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_PROCESS_IN_FILE;

  FUNCTION FN_PROCESS_IN_UPLOAD(P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_ACTION_CODE    IN VARCHAR2,
                                P_GIDIFPRS       IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS    IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_PHYFILENAME    IN VARCHAR2,
                                P_SERIAL         IN NUMBER,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAMS     IN OUT VARCHAR2,
                                L_FP_FAILED_ONCE IN OUT NUMBER)
    RETURN BOOLEAN IS

    D_PROG   VARCHAR2(32767);
    D_SQL    VARCHAR2(32767);
    L_MODULE VARCHAR2(2) := 'GI';
    E_FAILURE_EXCEPTION EXCEPTION;
    E_RETURN_EXCEPTION  EXCEPTION;
    P_STATUS VARCHAR2(1);

    FP_STATUS         BOOLEAN := FALSE;
    L_IN_FILE_PATH    VARCHAR2(1000);
    L_IN_CRC_PATH     VARCHAR2(1000);
    L_IN_CONF_PATH    VARCHAR2(1000);
    L_IN_DIR          VARCHAR2(100);
    L_ROUTING_TYPE    VARCHAR2(2);
    P_BRANCH_CODE     GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE;
    P_EXT_SYSTEM      GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE;
    P_INTERFACE_CODE  GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE;
    P_FILE_NAME       GITM_FILE_NAMES.FILE_NAME%TYPE;
    SRC_LOC           VARCHAR2(200);
    SRC_FILE_NAME     VARCHAR2(200);
    DEST_LOC          VARCHAR2(200);
    DEST_FILE_NAME    VARCHAR2(200);
    L_TYPE_STRING     VARCHAR2(2);
    P_LOG_SERIAL      NUMBER;
    PARALLEL_STATUS   VARCHAR2(1);
    L_FILE_MASK       VARCHAR2(2000);
    PROCESS_COUNT     NUMBER := 0;
    IN_CRC_FILE_NAME  VARCHAR2(1000);
    IN_CONF_FILE_NAME VARCHAR2(1000);
    L_ERR_CODE        VARCHAR2(100);
    L_ERR_PARAM       VARCHAR2(100);
    L_SUCC_PROCESSED  NUMBER;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Insert into File Log11');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_in_upload1');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                                              P_ACTION_CODE,
                                                              P_GIDIFPRS,
                                                              P_FORMAT_DTLS,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS,
                                                              L_FP_FAILED_ONCE) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_in_upload***please check');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF NOT FN_SET_FILE_LOG_FILEMASTER(P_SOURCE,
                                        P_GIDIFPRS,
                                        P_FORMAT_DTLS.BRANCH_CODE,
                                        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                        GLOBAL.APPLICATION_DATE,
                                        P_SERIAL,
                                        'U',
                                        P_ERR_CODE,
                                        P_ERR_PARAMS,
                                        P_PHYFILENAME) THEN
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG('Failed in Inserting into File Log');
        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;

      IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                      P_GIDIFPRS,
                                      G_BRANCH_CODE,
                                      G_FILE_NAME,
                                      CURRENT_TIMESTAMP,
                                      'U',
                                      'W',
                                      P_SERIAL,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS,
                                      P_PHYFILENAME) THEN
        DBG('Failed in Updating the Log');
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;
      BEGIN
        SELECT TYPE_STRING, ROUTING_TYPE
          INTO L_TYPE_STRING, L_ROUTING_TYPE
          FROM SMTB_MENU
         WHERE TRIM(FUNCTION_ID) = TRIM(P_FORMAT_DTLS.FUNCTION_ID);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Function Id Does Not Exists...');
          L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
          RETURN FALSE;
      END;
      DBG('GIPKS_INTERFACE_TRIGGER.g_phy_file_name 1: ' ||
          GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME);
      GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME := P_PHYFILENAME;
      GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO  := P_SERIAL;
      DBG('GIPKS_INTERFACE_TRIGGER.g_phy_file_name 2: ' ||
          GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME);
      GIPKS_INTERFACE_TRIGGER.G_SERIAL := P_LOG_SERIAL;
      DBG('gipks_interface_trigger.g_serial...' ||
          GIPKS_INTERFACE_TRIGGER.G_SERIAL);
      P_INTERFACE_CODE := P_FORMAT_DTLS.INTERFACE_CODE;
      G_INTERFACE_CODE := P_INTERFACE_CODE;
      G_FILE_NAME      := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
      L_IN_FILE_PATH   := P_FORMAT_DTLS.FILE_PATH;
      DBG('#2# l_in_file_path : ' || L_IN_FILE_PATH);
      DBG('p_gidifprs.ifprs_gitm_interface_trigger.process_code..2 = ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE);



      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE IN ('RE') THEN
          SRC_LOC := 'DEUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
        ELSE
          SRC_LOC := 'DEUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'file_processed';
        END IF;
      ELSE
        --sampath
        IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE IN ('RE') THEN
          SRC_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
        ELSE
          SRC_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'file_processed';
        END IF;
      END IF; --sampath

      SRC_FILE_NAME := P_SERIAL || '_' || P_PHYFILENAME;

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        DEST_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath

        DEST_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
      END IF; --sampath

      DBG('p_gidifprs.ifprs_gitm_interface_trigger.file_name ' ||
          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);

      DEST_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

      IF FN_IS_FILE_EXISTS(DEST_LOC,
                           DEST_FILE_NAME,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('File name already available in the folder WIP ');
        P_ERR_CODE   := 'GI-INF-61';
        P_ERR_PARAMS := 'wip';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;

      IF NOT FN_MOVE_FILE(P_SOURCE,
                          SRC_LOC,
                          DEST_LOC,
                          SRC_FILE_NAME,
                          DEST_FILE_NAME,
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
        DBG('Failed in moving fie from FILE_PROCESSED TO WIP Folder');
        L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
        RETURN FALSE;
      END IF;

      DBG('INTERFACE CODE...' || GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
      DBG('File Name...' || GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
      IF L_TYPE_STRING <> 'O' THEN
        D_PROG := L_MODULE || 'PKS_' || P_INTERFACE_CODE || '_' ||
                  REPLACE(G_FILE_NAME, '.', '_') || '.fn_upload';
      ELSE
        D_PROG := 'GIPKS_#' || P_FORMAT_DTLS.FUNCTION_ID || '.fn_upload';
      END IF;
      DBG('D_PROG   ' || D_PROG);
      DBG('Package Name ' || D_PROG);
      DBG('GIPKS_INTERFACE_TRIGGER.g_ProcessRefNo = ' ||
          GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO);

      SELECT MAX(PROCESS_NO)
        INTO PROCESS_COUNT
        FROM GITM_UPLOAD_MASTER
       WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                 '.',
                                 '_')
         AND STATUS <> 'P'
         AND PROCESS_REF_NO = GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO;
      IF PROCESS_COUNT IS NULL THEN
        PROCESS_COUNT := 0;
      END IF;
      IF PROCESS_COUNT > 0 THEN

        GIPKS_INTERFACE_TRIGGER.G_PROCESS_NO := PROCESS_COUNT;
        DBG('GIPKS_INTERFACE_TRIGGER.g_process_no = ' ||
            GIPKS_INTERFACE_TRIGGER.G_PROCESS_NO);
        D_SQL := 'DECLARE ' || CHR(10);
        D_SQL := D_SQL || ' ' ||
                 'l_err_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_code;  ' ||
                 CHR(10);
        D_SQL := D_SQL || ' ' ||
                 'l_err_params     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_params;  ' ||
                 CHR(10);
        D_SQL := D_SQL || ' ' ||
                 'l_intf_code     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_interface_code;  ' ||
                 CHR(10);
        D_SQL := D_SQL || ' ' ||
                 'l_file_name     varchar2(255):=  REPLACE(GIPKS_INTERFACE_TRIGGER.g_file_name,''.'',''_'');  ' ||
                 CHR(10);

        D_SQL := D_SQL || ' ' ||
                 'l_phy_file_name     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_phy_file_name;  ' ||
                 CHR(10);
        D_SQL := D_SQL || ' ' ||
                 'l_ProcessRefNo     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_ProcessRefNo;  ' ||
                 CHR(10);

        D_SQL := D_SQL || ' ' ||
                 'l_process_no     Number :=  GIPKS_INTERFACE_TRIGGER.g_process_no;  ' ||
                 CHR(10);

        D_SQL := D_SQL || ' ' ||
                 'l_status     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_status;  ' ||
                 CHR(10);
        D_SQL := D_SQL || 'BEGIN' || CHR(10);

        D_SQL := D_SQL || 'IF NOT ' || D_PROG ||
                 '(l_intf_code, l_file_name, l_phy_file_name, l_ProcessRefNo, l_process_no,  l_err_code, l_err_params, l_status)  THEN ' ||
                 CHR(10);

        D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := FALSE;' ||
                 CHR(10);
        D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status := l_status;' ||
                 CHR(10);
        D_SQL := D_SQL ||
                 'GIPKS_INTERFACE_TRIGGER.g_err_code := l_err_code;' ||
                 CHR(10);
        D_SQL := D_SQL ||
                 'GIPKS_INTERFACE_TRIGGER.g_err_params := l_err_params;' ||
                 CHR(10);
        D_SQL := D_SQL || 'ELSE' || CHR(10);
        D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := TRUE;' ||
                 CHR(10);
        D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status := l_status;' ||
                 CHR(10);
        D_SQL := D_SQL ||
                 'GIPKS_INTERFACE_TRIGGER.g_err_code := l_err_code;' ||
                 CHR(10);
        D_SQL := D_SQL ||
                 'GIPKS_INTERFACE_TRIGGER.g_err_params := l_err_params;' ||
                 CHR(10);
        D_SQL := D_SQL || 'END IF;' || CHR(10);
        D_SQL := D_SQL || 'END;' || CHR(10);
        DBG('DYNAMIC SQL...');
        DBG(D_SQL);

        BEGIN
          DBG('just before exe sweta');
          EXECUTE IMMEDIATE D_SQL;
          DBG(' just after exe sweta');

          IF NOT
              FN_UPDATE_INTERFACE_DEFINITION(P_FORMAT_DTLS.BRANCH_CODE,
                                             P_FORMAT_DTLS.INTERFACE_CODE) THEN
            DBG('FAILED IN UPDATING interface definition table');

          END IF;

          DBG(' just after after updating interface definition sweta');
          P_ERR_CODE   := GIPKS_INTERFACE_TRIGGER.G_ERR_CODE;
          P_ERR_PARAMS := GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS;
        EXCEPTION
          WHEN OTHERS THEN

            DEBUG.PR_DEBUG('GI',
                           'DP PROCESS FAILED ##############################');
            DEBUG.PR_DEBUG('GI', SQLERRM);
            L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
            DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            L_ERR_CODE  := P_ERR_CODE;
            L_ERR_PARAM := P_ERR_PARAMS;
            DBG('p_err_code1 :' || P_ERR_CODE);

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

            ELSE
              --sampath
              SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
            END IF; --sampath

            SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

            IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

            ELSE
              --sampath
              DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
            END IF; --sampath

            DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

            IF FN_IS_FILE_EXISTS(DEST_LOC,
                                 DEST_FILE_NAME,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
              DBG('File name already available in the folder ERROR ');
              P_ERR_CODE   := 'GI-INF-61';
              P_ERR_PARAMS := 'error';
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;

            ELSE
              P_ERR_CODE   := L_ERR_CODE;
              P_ERR_PARAMS := L_ERR_PARAM;
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            END IF;
            DBG('p_err_code2 :' || P_ERR_CODE);
            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in Copying fie from wip to ERROR Folder');

              RETURN FALSE;
            END IF;
            DBG('p_err_code3 :' || P_ERR_CODE);
            RETURN FALSE;
        END;

        IF NOT
            FN_UPDATE_INTERFACE_DEFINITION(P_FORMAT_DTLS.BRANCH_CODE,
                                           P_FORMAT_DTLS.INTERFACE_CODE) THEN
          DBG('FAILED IN UPDATING interface definition table');

        END IF;

        DBG('JUST AFTER CALLING DP  PROCESS *****   ');

        SELECT COUNT(*)
          INTO L_SUCC_PROCESSED
          FROM GITU_UPLOAD_MASTER
         WHERE INTERFACE_CODE = GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE
           AND PHY_FILE_NAME = GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME
           AND PROCESS_REF_NO = GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO
           AND STATUS = 'P';
        DBG('Number of Successfully processed records : ' ||
            L_SUCC_PROCESSED);
        IF L_SUCC_PROCESSED <> 0 THEN
          DBG('Atleast one record has been successfully Processed');
          GIPKS_INTERFACE_TRIGGER.G_STATUS := 'P';
        ELSE
          DBG('Not a single record having status as Processed');
          GIPKS_INTERFACE_TRIGGER.G_STATUS := 'E';
        END IF;

        DBG('GIPKS_INTERFACE_TRIGGER.g_status =  ' ||
            GIPKS_INTERFACE_TRIGGER.G_STATUS);
        DBG('ERROR CODE ...' || GIPKS_INTERFACE_TRIGGER.G_ERR_CODE);
        DBG('ERROR pARAM ...' || GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS);
        DBG('ERROR CODE_p ...' || P_ERR_CODE);
        DBG('ERROR pARAM_p ...' || P_ERR_PARAMS);

        IF NOT GIPKS_INTERFACE_TRIGGER.G_STATUS = 'E' THEN
          DBG('Going to update log 1 **** ');
          IF TRIM(P_ERR_CODE) IS NULL THEN

            P_ERR_CODE   := 'MS-AUT06';
            P_ERR_PARAMS := 'Uploaded Successfully';
          END IF;
          IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                          P_GIDIFPRS,
                                          G_BRANCH_CODE,
                                          G_FILE_NAME,
                                          FN_HOSTDATETIME,
                                          'W',
                                          'P',
                                          P_SERIAL,
                                          P_ERR_CODE,
                                          P_ERR_PARAMS,
                                          P_PHYFILENAME) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RAISE E_RETURN_EXCEPTION;
            RETURN FALSE;
          END IF;
          DBG('updating  log success ***** ');

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

          ELSE
            --sampath
            SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
          END IF; --sampath

          SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

          IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            DEST_LOC := 'DEUPLD_I/processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

          ELSE
            --sampath
            DEST_LOC := 'XRUPLD_I/processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'processed';
          END IF; --sampath

          DBG('p_gidifprs.ifprs_gitm_interface_trigger.file_name ' ||
              P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
          IF P_FORMAT_DTLS.PROCESSED_FILE_MASK IS NOT NULL THEN
            DBG('Applying mask ***** ');
            L_FILE_MASK := P_FORMAT_DTLS.PROCESSED_FILE_MASK;
            IF NOT FN_APPLY_MASK(DEST_FILE_NAME,
                                 L_FILE_MASK,
                                 P_FORMAT_DTLS.INTERFACE_CODE,
                                 P_FORMAT_DTLS.EXTERNAL_SYSTEM,
                                 P_FORMAT_DTLS.BRANCH_CODE,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
              RAISE E_RETURN_EXCEPTION;
              RETURN FALSE;
            END IF;
            DBG('Applying mask success ***** ');
          ELSE

            DEST_FILE_NAME := SUBSTR(P_PHYFILENAME,
                                     1,
                                     INSTR(P_PHYFILENAME, '.', -1) - 1) || '_' ||

                              TO_CHAR(FN_HOSTDATETIME, 'YYYYMMDDHH24MISS') ||

                              SUBSTR(P_PHYFILENAME,
                                     INSTR(P_PHYFILENAME, '.', -1));

          END IF;
          IF NOT FN_MOVE_FILE(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
            DBG('Failed in moving fie from wip to processed Folder');
            RAISE E_RETURN_EXCEPTION;
            RETURN FALSE;
          END IF;

          IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'S' AND
             P_FORMAT_DTLS.CRC_REQUIRED = 'Y' THEN

            L_IN_CRC_PATH := P_FORMAT_DTLS.CRC_FILE_PATH;
            SRC_LOC       := L_IN_CRC_PATH || GLOBAL.SLASH || 'ready';

            IN_CRC_FILE_NAME := SUBSTR(P_PHYFILENAME,
                                       1,
                                       INSTR(P_PHYFILENAME, '.') - 1) ||
                                '.CRC';
            SRC_FILE_NAME    := IN_CRC_FILE_NAME;
            DEST_LOC         := L_IN_CRC_PATH || GLOBAL.SLASH ||
                                'processed';

            DEST_FILE_NAME := SUBSTR(P_PHYFILENAME,
                                     1,
                                     INSTR(P_PHYFILENAME, '.', -1) - 1) || '_' ||

                              TO_CHAR(FN_HOSTDATETIME, 'YYYYMMDDHH24MISS') ||

                              '.CRC';
            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in Copying CRC file from ready to processed Folder');
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            END IF;
          END IF;

          IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'P' AND
             P_FORMAT_DTLS.CONFIRM_FILE_REQD = 'Y' THEN

            L_IN_CONF_PATH := P_FORMAT_DTLS.CONFIRMATION_FILE_PATH;
            SRC_LOC        := L_IN_CONF_PATH || GLOBAL.SLASH || 'ready';

            IN_CONF_FILE_NAME := SUBSTR(P_PHYFILENAME,
                                        1,
                                        INSTR(P_PHYFILENAME, '.') - 1) ||
                                 '.CNF';
            SRC_FILE_NAME     := IN_CONF_FILE_NAME;
            DEST_LOC          := L_IN_CONF_PATH || GLOBAL.SLASH ||
                                 'processed';

            DEST_FILE_NAME := SUBSTR(P_PHYFILENAME,
                                     1,
                                     INSTR(P_PHYFILENAME, '.', -1) - 1) || '_' ||

                              TO_CHAR(FN_HOSTDATETIME, 'YYYYMMDDHH24MISS') ||

                              '.CNF';
            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in Copying confirmation file from ready to processed Folder');
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            END IF;

          END IF;
        ELSE

          DBG('Inside else part of IF NOT GIPKS_INTERFACE_TRIGGER.g_status = E Then');
          DBG('Failed in running of DP Process for interface code ' ||
              P_INTERFACE_CODE);
          DBG('Updtaing Log 2 ** ');
          L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
          IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                          P_GIDIFPRS,
                                          G_BRANCH_CODE,
                                          G_FILE_NAME,
                                          FN_HOSTDATETIME,
                                          'W',
                                          'E',
                                          P_SERIAL,
                                          GIPKS_INTERFACE_TRIGGER.G_ERR_CODE,
                                          GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS,
                                          P_PHYFILENAME) THEN
            DBG('Failed in Updating the Log');
            PR_LOG_ERROR(P_SOURCE,
                         GIPKS_INTERFACE_TRIGGER.G_ERR_CODE,
                         GIPKS_INTERFACE_TRIGGER.G_ERR_PARAMS);
            RETURN FALSE;
          END IF;

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

          ELSE
            --sampath
            SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
          END IF; --sampath

          SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

          IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
            --sampath
            DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

          ELSE
            --sampath
            DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
          END IF; --sampath

          DEST_FILE_NAME := P_SERIAL || '_' || P_PHYFILENAME;

          DBG('ERROR CODES ASSIGNED TO L_ERRRCODE');
          L_ERR_CODE  := SUBSTR(P_ERR_CODE, 1, 100);
          L_ERR_PARAM := SUBSTR(P_ERR_PARAMS, 1, 100);

          IF FN_IS_FILE_EXISTS(DEST_LOC,
                               DEST_FILE_NAME,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
            DBG('File name already available in the folder Error ');
            P_ERR_CODE   := 'GI-INF-61';
            P_ERR_PARAMS := 'error';
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            BEGIN
              UPDATE GITB_FILE_LOG
                 SET ERROR_CODE   = 'GI-INF-61',
                     ERROR_PARAMS = 'error folder already has file name : ' ||
                                    DEST_FILE_NAME
               WHERE PROCESS_REF_NO = P_SERIAL;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Exception in updating the error log');
            END;
            RETURN FALSE;

          ELSE
            P_ERR_CODE   := L_ERR_CODE;
            P_ERR_PARAMS := L_ERR_PARAM;

          END IF;
          IF NOT FN_MOVE_FILE(P_SOURCE,
                              SRC_LOC,
                              DEST_LOC,
                              SRC_FILE_NAME,
                              DEST_FILE_NAME,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
            DBG('Failed in Copying fie from wip to Error Folder');
            PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          END IF;

        END IF;
        P_STATUS := G_STATUS;
        DBG('p_status just before If Not g_Return And p_status = E -->> ' ||
            P_STATUS);

      END IF;

      IF PROCESS_COUNT = 0 THEN
        DBG('NO DATA TO DO DP PROCESS ');
        P_ERR_CODE   := 'GI-PRS-043';
        P_ERR_PARAMS := 'No Data to Process';
        IF NOT FN_UPDATE_LOG_FILEMASTER(P_SOURCE,
                                        P_GIDIFPRS,
                                        G_BRANCH_CODE,
                                        G_FILE_NAME,
                                        FN_HOSTDATETIME,
                                        'W',
                                        'E',
                                        P_SERIAL,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS,
                                        P_PHYFILENAME) THEN
          DBG('Failed in Updating the Log');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        RAISE E_RETURN_EXCEPTION;
      END IF;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DEBUG.PR_DEBUG('GI',
                     'Calling Gipks_Interface_Triggercluster.fn_process_in_upload2');
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          GIPKS_INTERFACE_TRIGGERCLUSTER.FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                                              P_ACTION_CODE,
                                                              P_GIDIFPRS,
                                                              P_FORMAT_DTLS,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS,
                                                              L_FP_FAILED_ONCE) THEN
        DEBUG.PR_DEBUG('IS',
                       'Failed in Gipks_Interface_Triggercluster.fn_process_in_upload***please check');
        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION

    WHEN E_RETURN_EXCEPTION THEN

      DEBUG.PR_DEBUG('GI',
                     'From E_Return_Exception of GIPKS_INTERFACE_TRIGGER.fn_process_IN_FILE');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_ERR_CODE  := P_ERR_CODE;
      L_ERR_PARAM := P_ERR_PARAMS;
      DBG('p_err_code1 :' || P_ERR_CODE);

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        SRC_LOC := 'DEUPLD_I/wip'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

      ELSE
        --sampath
        SRC_LOC := 'XRUPLD_I/wip'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'wip';
      END IF; --sampath

      SRC_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;

      IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
        --sampath
        DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

      ELSE
        --sampath
        DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
      END IF; --sampath

      DEST_FILE_NAME := P_SERIAL || '_' || G_PHY_FILE_NAME;

      IF FN_IS_FILE_EXISTS(DEST_LOC,
                           DEST_FILE_NAME,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
        DBG('File name already available in the folder ERROR ');
        P_ERR_CODE   := 'GI-INF-61';
        P_ERR_PARAMS := 'error';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;

      ELSE
        P_ERR_CODE   := L_ERR_CODE;
        P_ERR_PARAMS := L_ERR_PARAM;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

      END IF;
      DBG('p_err_code2 :' || P_ERR_CODE);
      IF NOT FN_MOVE_FILE(P_SOURCE,
                          SRC_LOC,
                          DEST_LOC,
                          SRC_FILE_NAME,
                          DEST_FILE_NAME,
                          P_ERR_CODE,
                          P_ERR_PARAMS) THEN
        DBG('Failed in Copying fie from wip to ERROR Folder');

        RETURN FALSE;
      END IF;
      DBG('p_err_code3 :' || P_ERR_CODE);
      RETURN FALSE;

    WHEN OTHERS THEN
      L_FP_FAILED_ONCE := L_FP_FAILED_ONCE + 1;
      DEBUG.PR_DEBUG('GI',
                     'In when others of fn_process_in_upload...' || SQLERRM);
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_PROCESS_IN_UPLOAD;

  FUNCTION FN_PROCESS_IN_UPLOAD(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_IN_FILE_PATH VARCHAR2(2000);
    L_PROCESS_PATH VARCHAR2(2000);
    L_FILE_NAME    VARCHAR2(255);
    L_FILE_LIST    VARCHAR2(2000);
    L_PHYFNAME     VARCHAR2(2000);
    L_FILE_COUNT   NUMBER := 1;

    P_STATUS       VARCHAR2(3) := 'U';
    SRC_LOC        VARCHAR2(200);
    SRC_FILE_NAME  VARCHAR2(200);
    DEST_LOC       VARCHAR2(200);
    DEST_FILE_NAME VARCHAR2(200);
    L_FILE_MASK    VARCHAR2(2000);

    CURSOR CR_FILENAMES(P_FN VARCHAR2, P_PRF VARCHAR2, P_IF VARCHAR2) IS
      SELECT *
        FROM GITB_FILE_MASTER
       WHERE FILE_NAME = P_FN
         AND PROCESS_REF_NO = P_PRF
         AND INTERFACE_CODE = P_IF
         AND UPLOAD_STATUS = 'P'
         AND PROCESS_CODE = 'FP';

    CURSOR CR_FILEMASTER(P_FN VARCHAR2, P_PRF VARCHAR2, P_IF VARCHAR2) IS
      SELECT *
        FROM GITB_FILE_MASTER
       WHERE FILE_NAME = P_FN
         AND PROCESS_REF_NO = P_PRF
         AND INTERFACE_CODE = P_IF
         AND UPLOAD_STATUS = 'P'
         AND PROCESS_CODE = 'FP';
    TYPE TY_FILE_MASTER IS TABLE OF GITB_FILE_MASTER%ROWTYPE INDEX BY BINARY_INTEGER;
    LIST_FILEMASTER    TY_FILE_MASTER;
    LIST_PHYFILES      TY_FILE_MASTER;
    L_PHYSICALFILENAME VARCHAR2(50);
    TYPE TY_FILE_NAME IS TABLE OF VARCHAR2(50) INDEX BY PLS_INTEGER;
    L_PHYALLFILENAME TY_FILE_NAME;
    L_SEPARATOR      VARCHAR2(5);
    IDX              PLS_INTEGER;
    L_PHYFCOUNT      NUMBER := 0;
    P_SERIAL_FP      NUMBER := 0;
    L_FP_FAILED_ONCE NUMBER := 0;
    P_SERIAL         NUMBER := 0;
  BEGIN
    DBG('Entered into fn_process_in_upload');
    L_IN_FILE_PATH := P_FORMAT_DTLS.FILE_PATH;
    DBG('#1# l_in_file_path : ' || L_IN_FILE_PATH);

    BEGIN

      SELECT PROCESS_REF_NO
        INTO P_SERIAL_FP
        FROM GITB_FILE_LOG
       WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
         AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
         AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
         AND

             PROCESS_CODE IN ('FP', 'AL')
         AND STATUS = 'P'
         AND START_DATE_STAMP =
             (SELECT MAX(START_DATE_STAMP)
                FROM GITB_FILE_LOG
               WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                 AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                 AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                 AND FILE_NAME =
                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
                 AND PROCESS_CODE IN ('FP', 'AL')

              );

      DBG('p_serial_fp' || P_SERIAL_FP);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed In retrieving process_ref_no');

        DBG('Cannot proceed with DP due to failure in FP');
        DEBUG.PR_DEBUG('GI',
                       'In when others of fn_process_in_upload...' ||
                       SQLERRM);
        P_ERR_CODE   := 'GI-PRS-076';
        P_ERR_PARAMS := 'Cannot proceed with DP due to failure in FP';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;
      WHEN OTHERS THEN
        DBG('WHEN OTHERS No Records Exists for File Log...');

        DBG('Cannot proceed with DP due to failure in FP');
        DEBUG.PR_DEBUG('GI',
                       'In when others of fn_process_in_upload...' ||
                       SQLERRM);
        P_ERR_CODE   := 'GI-PRS-076';
        P_ERR_PARAMS := 'Cannot proceed with DP due to failure in FP';
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

        RETURN FALSE;
    END;

    DBG('FP - Record reference>>' || P_SERIAL_FP);

    IF NOT FN_SET_FILE_LOG(P_SOURCE,
                           P_GIDIFPRS,
                           P_FORMAT_DTLS.BRANCH_CODE,
                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                           GLOBAL.APPLICATION_DATE,

                           P_SERIAL_FP,

                           'U',
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Failed in Inserting into File Log');
      RETURN FALSE;
    END IF;

    IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
      --sampath
      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE IN ('RE') THEN
        L_PROCESS_PATH := 'DEUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
      ELSE
        L_PROCESS_PATH := 'DEUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'file_processed';
      END IF;
    ELSE
      --sampath
      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE IN ('RE') THEN
        L_PROCESS_PATH := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
      ELSE
        L_PROCESS_PATH := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'file_processed';
      END IF;

    END IF; --sampath


    DBG('File search Path is : ' || L_PROCESS_PATH);
    DBG('File Type name : ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
    L_FILE_NAME := SUBSTR(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                          1,
                          INSTR(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                '.') - 1);

    IF NOT FN_UPDATE_LOG(P_SOURCE,
                         P_GIDIFPRS,
                         G_BRANCH_CODE,
                         G_FILE_NAME,
                         CURRENT_TIMESTAMP,
                         'U',
                         'W',

                         P_SERIAL_FP,

                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
      DBG('Failed in Updating the Log');
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
       G_CUSTOM_LOGGING = 'Y' THEN
      DBG('Before the call to cluster package');
      IF NOT GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                          'W',
                                                          P_SERIAL_FP,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN

        DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
        RETURN FALSE;
      END IF;
      DBG('after the call to cluster package');
    END IF;

    DBG('p_gidifprs.ifprs_gitm_interface_trigger.file_name : ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME);
    DBG('p_serial_fp : ' || P_SERIAL_FP);
    DBG('p_gidifprs.ifprs_gitm_interface_trigger.interface_code : ' ||
        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);

    IF (P_FORMAT_DTLS.PARALLEL_PROCESS_REQD = 'Y') THEN

      IF NOT FN_PARALLEL_JOBS(P_SOURCE,
                              P_SERIAL_FP,
                              P_GIDIFPRS,
                              P_FORMAT_DTLS,
                              P_STATUS,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('Failed in parallel jobs.....');

        OPEN CR_FILENAMES(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                          P_SERIAL_FP,
                          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
        FETCH CR_FILENAMES BULK COLLECT
          INTO LIST_PHYFILES;
        CLOSE CR_FILENAMES;
        DBG('Identified File Count>>' || LIST_PHYFILES.COUNT);
        IF (LIST_PHYFILES.COUNT > 0) THEN
          FOR I_REC IN LIST_PHYFILES.FIRST .. LIST_PHYFILES.LAST LOOP
            L_PHYFNAME := LIST_PHYFILES(I_REC).PHY_FILE_NAME;
            DBG('****************************');
            DBG('Physical file name to be moved : ' || L_PHYFNAME);

        IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              SRC_LOC := 'DEUPLD_I/file_processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

            ELSE
              --sampath
              SRC_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH ||
              --'file_processed';

            END IF; --sampath

            IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              DEST_LOC := 'DEUPLD_I/error'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

            ELSE
              --sampath

              DEST_LOC := 'XRUPLD_I/error'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'error';
            END IF; --sampath

            SRC_FILE_NAME := P_SERIAL_FP || '_' || L_PHYFNAME;
            DBG('####src_file_name.....' || SRC_FILE_NAME);
            DBG('####GIPKS_INTERFACE_TRIGGER.g_phy_file_name.....' ||
                GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME);
            DEST_FILE_NAME := P_SERIAL_FP || '_' || L_PHYFNAME;
            DBG('####dest_file_name.....' || DEST_FILE_NAME);
            IF FN_IS_FILE_EXISTS(DEST_LOC,
                                 DEST_FILE_NAME,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
              DBG('File name already available in the folder ERROR ');
              P_ERR_CODE   := 'GI-INF-61';
              P_ERR_PARAMS := 'ERROR';
              PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;

            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in moving fie from FILE_PROCESSED TO ERROR Folder');
              RETURN FALSE;
            END IF;
          END LOOP;
        END IF;
      ELSE

        OPEN CR_FILENAMES(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                          P_SERIAL_FP,
                          P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
        FETCH CR_FILENAMES BULK COLLECT
          INTO LIST_PHYFILES;
        CLOSE CR_FILENAMES;
        DBG('Identified File Count>>' || LIST_PHYFILES.COUNT);
        IF (LIST_PHYFILES.COUNT > 0) THEN
          FOR I_REC IN LIST_PHYFILES.FIRST .. LIST_PHYFILES.LAST LOOP
            L_PHYFNAME := LIST_PHYFILES(I_REC).PHY_FILE_NAME;
            DBG('****************************');
            DBG('Physical file name to be moved : ' || L_PHYFNAME);

    IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              SRC_LOC := 'DEUPLD_I/file_processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'wip';

            ELSE
              --sampath
              SRC_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH ||
              --'file_processed';
            END IF; --sampath

            IF g_interface_code IN ('DEUPLOAD', 'SVUPLOAD') THEN
              --sampath
              DEST_LOC := 'DEUPLD_I/file_processed'; --L_OUT_FILE_PATH || GLOBAL.SLASH || 'ready';

            ELSE
              --sampath
              DEST_LOC := 'XRUPLD_I/file_processed'; --L_IN_FILE_PATH || GLOBAL.SLASH || 'processed';
            END IF; --sampath

            SRC_FILE_NAME := P_SERIAL_FP || '_' || L_PHYFNAME;
            DBG('####src_file_name.....' || SRC_FILE_NAME);
            DEST_FILE_NAME := P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME;
            DBG('####dest_file_name.....' || DEST_FILE_NAME);

            IF P_FORMAT_DTLS.PROCESSED_FILE_MASK IS NOT NULL THEN
              DBG('Applying mask ***** ');
              L_FILE_MASK := P_FORMAT_DTLS.PROCESSED_FILE_MASK;
              IF NOT FN_APPLY_MASK(DEST_FILE_NAME,
                                   L_FILE_MASK,
                                   P_FORMAT_DTLS.INTERFACE_CODE,
                                   P_FORMAT_DTLS.EXTERNAL_SYSTEM,
                                   P_FORMAT_DTLS.BRANCH_CODE,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
                PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
              DBG('Applying mask success ***** ');
            ELSE
              DEST_FILE_NAME := SUBSTR(L_PHYFNAME,
                                       1,
                                       INSTR(L_PHYFNAME, '.', -1) - 1) || '_' ||
                                TO_CHAR(FN_HOSTDATETIME, 'YYYYMMDDHHMISS') ||
                                SUBSTR(L_PHYFNAME,
                                       INSTR(L_PHYFNAME, '.', -1));

            END IF;
            DBG('***dest_file_name after applying file mask.....***');
            DBG('####dest_file_name.....' || DEST_FILE_NAME);

            IF NOT FN_MOVE_FILE(P_SOURCE,
                                SRC_LOC,
                                DEST_LOC,
                                SRC_FILE_NAME,
                                DEST_FILE_NAME,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
              DBG('Failed in moving fie from FILE_PROCESSED TO PROCESSED Folder');
              RETURN FALSE;
            END IF;
          END LOOP;
        END IF;
      END IF;
    ELSE

      OPEN CR_FILEMASTER(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                         P_SERIAL_FP,
                         P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE);
      FETCH CR_FILEMASTER BULK COLLECT
        INTO LIST_FILEMASTER;
      CLOSE CR_FILEMASTER;
      DBG('Identified File Count>>' || LIST_FILEMASTER.COUNT);
      IF (LIST_FILEMASTER.COUNT > 0) THEN
        FOR I_REC IN LIST_FILEMASTER.FIRST .. LIST_FILEMASTER.LAST LOOP
          L_PHYFNAME := LIST_FILEMASTER(I_REC).PHY_FILE_NAME;
          DBG('****************************');
          DBG('Physical file name under Process : ' || L_PHYFNAME);
          IF NOT FN_PROCESS_IN_UPLOAD(P_SOURCE,
                                      P_ACTION_CODE,
                                      P_GIDIFPRS,
                                      P_FORMAT_DTLS,
                                      L_PHYFNAME,
                                      P_SERIAL_FP,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS,
                                      L_FP_FAILED_ONCE) THEN
            DBG('Processing failed for physical file name : ' ||
                L_PHYFNAME);
          END IF;
          DBG('****************************');

          DBG('For Writting Log into files');
          DBG('p_format_dtls.LOG_OUTPUT : ' || P_FORMAT_DTLS.LOG_OUTPUT);
          IF P_FORMAT_DTLS.LOG_OUTPUT IS NOT NULL THEN
            IF NOT FN_WRITELOGTOFILE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                     P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                     L_PHYFNAME,
                                     P_SERIAL_FP,
                                     P_FORMAT_DTLS.LOG_OUTPUT) THEN
              DBG('Failed in writting success log 1');
            END IF;
          END IF;

          DBG('GIPKS_INTERFACE_TRIGGER.g_status : ' ||
              GIPKS_INTERFACE_TRIGGER.G_STATUS);
          DBG('p_format_dtls.on_override : ' || P_FORMAT_DTLS.ON_OVERRIDE);
          IF GIPKS_INTERFACE_TRIGGER.G_STATUS = 'E' THEN
            IF P_FORMAT_DTLS.ON_OVERRIDE = 'R' THEN

              DBG('On override is Reject. so processing of next physical file names are ignored');
              EXIT;
            END IF;
          END IF;
        END LOOP;
      ELSE
        DBG('list_filemaster.count is zero');
      END IF;
      DBG('l_FP_failed_once>>' || L_FP_FAILED_ONCE);
      IF (L_FP_FAILED_ONCE != 0) THEN
        IF NOT FN_UPDATE_LOG(P_SOURCE,
                             P_GIDIFPRS,
                             G_BRANCH_CODE,
                             G_FILE_NAME,
                             CURRENT_TIMESTAMP,
                             'S',
                             'E',

                             P_SERIAL_FP,

                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
          DBG('Failed in Updating the Log');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
           G_CUSTOM_LOGGING = 'Y' THEN
          DBG('Before the call to cluster package');
          IF NOT
              GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                           'E',
                                                           P_SERIAL_FP,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN

            DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
            RETURN FALSE;
          END IF;
          DBG('after the call to cluster package');
        END IF;

      ELSE
        IF NOT FN_UPDATE_LOG(P_SOURCE,
                             P_GIDIFPRS,
                             G_BRANCH_CODE,
                             G_FILE_NAME,
                             CURRENT_TIMESTAMP,
                             'S',
                             'P',

                             P_SERIAL_FP,

                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
          DBG('Failed in Updating the Log');
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM AND
           G_CUSTOM_LOGGING = 'Y' THEN
          DBG('Before the call to cluster package');
          IF NOT
              GIPKS_INTERFACE_TRIGGERCLUSTER.FN_UPDATE_LOG(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.EXTERNAL_SYSTEM,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.BRANCH_CODE,
                                                           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE,
                                                           'P',
                                                           P_SERIAL_FP,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN

            DBG('failed in Gipks_Interface_TriggerCluster.Fn_Update_Log');
            RETURN FALSE;
          END IF;
          DBG('after the call to cluster package');
        END IF;

      END IF;
    END IF;
    DBG('Exit from fn_process_in_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('GI',
                     'In when others of fn_process_in_upload.....' ||
                     SQLERRM);
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := 'Failed to Process the Request';
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_PROCESS_IN_UPLOAD;

  FUNCTION FN_VALIDATE_EXECUTIONS(P_SOURCE      IN VARCHAR2,
                                  P_ACTION_CODE IN VARCHAR2,
                                  P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                  P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                  P_ERR_CODE    IN OUT VARCHAR2,
                                  P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN

    SELECT COUNT(*)
      INTO L_COUNT
      FROM GITB_FILE_LOG
     WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
       AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
       AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
       AND FILE_NAME = P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
       AND PROCESS_CODE =
           P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE
       AND STATUS = 'P';

    IF TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 1 OR
       TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) = 0 THEN
      DBG('Frequency is Single...');

      IF L_COUNT > 0 THEN
        DBG('Interface $1 already processed today. Only Once in a day it can be triggered...');
        P_ERR_CODE   := 'GI-PRS-031';
        P_ERR_PARAMS := P_FORMAT_DTLS.INTERFACE_CODE || ' For ' ||
                        P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE;
        PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    ELSIF TO_NUMBER(P_FORMAT_DTLS.FREQUENCY) > 1 THEN
      DBG('Frequency is Multiple...');

      IF P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE = 'FP' THEN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM GITB_FILE_LOG
         WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
           AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
           AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
           AND FILE_NAME =
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
           AND PROCESS_CODE = 'DP'
           AND STATUS <> 'P'
           AND START_DATE_STAMP =
               (SELECT MAX(START_DATE_STAMP)
                  FROM GITB_FILE_LOG
                 WHERE BRANCH_CODE = P_FORMAT_DTLS.BRANCH_CODE
                   AND EXTERNAL_SYSTEM = P_FORMAT_DTLS.EXTERNAL_SYSTEM
                   AND INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
                   AND FILE_NAME =
                       P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME
                   AND PROCESS_CODE = 'DP')
           AND TO_CHAR(START_DATE_STAMP, 'DD-MON-YY') =
               TO_CHAR(FN_HOSTDATETIME, 'DD-MON-YY')
           AND PROCESS_REF_NO = GIPKS_INTERFACE_TRIGGER.G_SERIAL;

        IF L_COUNT > 0 THEN
          DBG('Cannot Trigger File Process for $1 Again Until Data Process for Initiated Previous File Process is Completed');
          P_ERR_CODE   := 'GI-PRS-030';
          P_ERR_PARAMS := P_FORMAT_DTLS.INTERFACE_CODE;
          PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

    ELSE
      DBG('Invalid Frequency $1 for Interface $2');
      P_ERR_CODE   := 'GI-PRS-032';
      P_ERR_PARAMS := P_FORMAT_DTLS.FREQUENCY || '~' ||
                      P_FORMAT_DTLS.INTERFACE_CODE;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('GI',
                     'In when others of fn_validate_executions' || SQLERRM);
      P_ERR_CODE   := 'GI-PRS-027';
      P_ERR_PARAMS := NULL;
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_EXECUTIONS;

  FUNCTION FN_GET_PROCESS_COUNT(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                P_ACTION_CODE IN VARCHAR2,
                                P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                                P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                                P_PROCESS_CNT IN OUT NUMBER,
                                P_ERR_CODE    IN OUT VARCHAR2,
                                P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_COUNT            NUMBER;
    P_COMP_DETAILS     GITM_COMPONENT_LINKAGE%ROWTYPE;
    L_SQL              VARCHAR2(1000);
    L_START_FIELD_NAME VARCHAR2(100);
    L_START_DEF_PARAM  VARCHAR2(100);
    L_FILE_NAME        GITM_FILE_NAMES.FILE_NAME%TYPE;
    L_RECORDS          NUMBER;
    MAX_PROCESS_COUNT  NUMBER;

    TYPE REC_COUNT_CUR IS REF CURSOR;
    REC_COUNT REC_COUNT_CUR;

  BEGIN
    DBG('In fn_get_process_count...');
    IF P_FORMAT_DTLS.PARALLEL_PROCESS_REQD = 'Y' THEN
      IF P_FORMAT_DTLS.PARALLEL_PROCESS = 'P' THEN
        DBG('No. of Parallel Process are...' ||
            P_FORMAT_DTLS.NO_OF_PARALLEL_PROCESS);
        P_PROCESS_CNT := P_FORMAT_DTLS.NO_OF_PARALLEL_PROCESS;
      ELSIF P_FORMAT_DTLS.PARALLEL_PROCESS = 'R' THEN
        DBG('Building Cursor for the Master Component...');
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM GITM_COMPONENT_LINKAGE
           WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
             AND COMPONENT_TYPE = 'HDR';
          DBG('L_count...' || L_COUNT);
          SELECT *
            INTO P_COMP_DETAILS
            FROM GITM_COMPONENT_LINKAGE
           WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
             AND SERIAL_NO = L_COUNT + 1;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT *
              INTO P_COMP_DETAILS
              FROM GITM_COMPONENT_LINKAGE
             WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
               AND SERIAL_NO = 1;
        END;
        SELECT FIELD_NAME, DEFAULT_PARAMETER
          INTO L_START_FIELD_NAME, L_START_DEF_PARAM
          FROM GITM_COMPONENT_FIELD_LINKAGE
         WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
           AND COMPONENT_NAME = P_COMP_DETAILS.COMPONENT_NAME
           AND FIELD_TYPE = 'S';

        L_FILE_NAME := REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                               '.',
                               '_');
        L_SQL       := ' SELECT COUNT(*) ' || ' FROM  GITE_' ||
                       P_FORMAT_DTLS.INTERFACE_CODE || L_FILE_NAME ||
                       P_COMP_DETAILS.SERIAL_NO || ' WHERE  ' ||
                       L_START_FIELD_NAME || '=' || '''' ||
                       L_START_DEF_PARAM || '''';
        DBG('l_sql...' || L_SQL);
        OPEN REC_COUNT FOR L_SQL;
        FETCH REC_COUNT
          INTO GIPKS_INTERFACE_TRIGGER.G_REC_COUNT;
        CLOSE REC_COUNT;
        DBG('Record Count....' || GIPKS_INTERFACE_TRIGGER.G_REC_COUNT);
        IF GIPKS_INTERFACE_TRIGGER.G_REC_COUNT = 0 THEN
          DBG('No records found for the Component in file...');
          RETURN FALSE;
        ELSE

          L_RECORDS := ROUND(GIPKS_INTERFACE_TRIGGER.G_REC_COUNT /
                             P_FORMAT_DTLS.NO_OF_RECORDS);
          DBG('gipks_interface_trigger.g_rec_count/p_format_dtls.no_of_records' ||
              GIPKS_INTERFACE_TRIGGER.G_REC_COUNT /
              P_FORMAT_DTLS.NO_OF_RECORDS);
          DBG('l_records....' || L_RECORDS);
          IF L_RECORDS = 0 THEN
            L_RECORDS := 1;
          END IF;
          P_PROCESS_CNT := L_RECORDS;
        END IF;

      END IF;

    END IF;

    BEGIN
      SELECT PARAM_VAL
        INTO MAX_PROCESS_COUNT
        FROM CSTB_PARAM
       WHERE PARAM_NAME = 'GI_MAX_PARALLEL_THREADS';
      IF P_PROCESS_CNT > MAX_PROCESS_COUNT THEN
        P_PROCESS_CNT := MAX_PROCESS_COUNT;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Updating p_process_count to 3...');
        P_PROCESS_CNT := 3;
        DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;

    RETURN TRUE;
  END FN_GET_PROCESS_COUNT;

  FUNCTION FN_UPDATE_PROCESS(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                             P_ACTION_CODE IN VARCHAR2,
                             P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                             P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                             P_PROCESS_CNT IN NUMBER,
                             P_ERR_CODE    IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_PROCESS_NO     NUMBER := 1;
    L_MOD_VALUE      NUMBER;
    L_PROCESS_REF_NO NUMBER := GIPKS_INTERFACE_TRIGGER.G_PROCESSREFNO;

    CURSOR CUR_UPLOAD_MASTER(C_INTERFACE_CODE IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE,
                             C_FILE_NAME      IN GITM_FILE_NAMES.FILE_NAME%TYPE,
                             C_BRANCH_CODE    IN GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE,
                             C_EXT_SYSTEM     IN GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE) IS
      SELECT ROWID
        FROM GITM_UPLOAD_MASTER
       WHERE INTERFACE_CODE = C_INTERFACE_CODE
         AND FILE_NAME = C_FILE_NAME
         AND EXTERNAL_SYSTEM = C_EXT_SYSTEM
         AND PHY_FILE_NAME = GIPKS_INTERFACE_TRIGGER.G_PHY_FILE_NAME
         AND STATUS <> 'P'
         AND PROCESS_REF_NO = L_PROCESS_REF_NO
         AND NVL(TARGET_TABLE, '~#~') <> '~#~';
    L_FILE_NAME VARCHAR2(1000);
    PRAGMA AUTONOMOUS_TRANSACTION;

    L_INDEX NUMBER := 0;
    TYPE L_REC IS RECORD(
      RWID       ROWID,
      PROCESS_NO GITM_UPLOAD_MASTER.PROCESS_NO%TYPE);
    TYPE REC_TYP IS TABLE OF L_REC INDEX BY BINARY_INTEGER;
    REC_TYP_TBL REC_TYP;

  BEGIN
    DBG('In fn_update_process.....');

    DBG('P_FORMAT_DTLS.INTERFACE_CODE ' || P_FORMAT_DTLS.INTERFACE_CODE);
    DBG('L_FILE_NAME ' || L_FILE_NAME);
    DBG('P_FORMAT_DTLS.BRANCH_CODE ' || P_FORMAT_DTLS.BRANCH_CODE);
    DBG('P_FORMAT_DTLS.EXTERNAL_SYSTEM ' || P_FORMAT_DTLS.EXTERNAL_SYSTEM);

    L_FILE_NAME := REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                           '.',
                           '_');
    SAVEPOINT UPDATE_PROCESS;

    FOR UPLD_REC IN CUR_UPLOAD_MASTER(P_FORMAT_DTLS.INTERFACE_CODE,
                                      L_FILE_NAME,
                                      P_FORMAT_DTLS.BRANCH_CODE,
                                      P_FORMAT_DTLS.EXTERNAL_SYSTEM) LOOP

      IF L_PROCESS_NO > NVL(P_PROCESS_CNT, 0) THEN
        L_PROCESS_NO := 1;
      END IF;

      L_INDEX := L_INDEX + 1;
      REC_TYP_TBL(L_INDEX).RWID := UPLD_REC.ROWID;
      REC_TYP_TBL(L_INDEX).PROCESS_NO := L_PROCESS_NO;
      L_PROCESS_NO := L_PROCESS_NO + 1;

    END LOOP;

    DBG(' TOTAL NUMBER OF RECORDS ' || REC_TYP_TBL.COUNT);
    FORALL EACH_REC IN 1 .. REC_TYP_TBL.COUNT
      UPDATE GITM_UPLOAD_MASTER GITM
         SET GITM.PROCESS_NO = REC_TYP_TBL(EACH_REC).PROCESS_NO
       WHERE GITM.ROWID = REC_TYP_TBL(EACH_REC).RWID;

    COMMIT;
    DBG('successfully returing fn_update_process.....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR...' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      ROLLBACK TO UPDATE_PROCESS;
      RETURN FALSE;
  END FN_UPDATE_PROCESS;

  FUNCTION FN_PARALLEL_JOBS(P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_LOG_SERIAL  IN NUMBER,
                            P_GIDIFPRS    IN OUT GIPKS_FCJ_GIDIFPRS.TY_GIDIFPRS,
                            P_FORMAT_DTLS IN GITM_FORMAT_DEFINITION%ROWTYPE,
                            P_STATUS      IN OUT VARCHAR2,
                            P_ERR_CODE    IN OUT VARCHAR2,
                            P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    PROCESS_COUNT  NUMBER;
    L_TYPE_STRING  VARCHAR2(2);
    L_ROUTING_TYPE VARCHAR2(2);
    D_PROG         VARCHAR2(32767);
    D_SQL          VARCHAR2(32767);
    L_JOB_NO       NUMBER;
    L_SEC          PLS_INTEGER := 1.00;
    L_STATUS       BOOLEAN := TRUE;
    P_USER         SMTB_USER.USER_ID%TYPE;
    P_BRANCH       STTM_CORE_BRANCH.BRANCH_CODE%TYPE;

    CURSOR CUR_JOB_PROCESS(P_LOG_SERIAL IN NUMBER, FILE_NAME IN VARCHAR2) IS
      SELECT *
        FROM GITB_JOBS
       WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = FILE_NAME
         AND TASK_STATUS IN ('W', 'E');

    REC_JOB_PROCESS CUR_JOB_PROCESS%ROWTYPE;
    L_WIP           BOOLEAN;
  BEGIN
    DBG('In fn_parallel_jobs...');
    BEGIN
      SELECT MAX(PROCESS_NO)
        INTO PROCESS_COUNT
        FROM GITM_UPLOAD_MASTER
       WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                 '.',
                                 '_')
         AND STATUS = 'U'
         AND PROCESS_REF_NO = P_LOG_SERIAL;
      DBG('PRocess COunt...' || PROCESS_COUNT);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data FOUNd...');
        RETURN FALSE;
    END;
    BEGIN
      SELECT TYPE_STRING, ROUTING_TYPE
        INTO L_TYPE_STRING, L_ROUTING_TYPE
        FROM SMTB_MENU
       WHERE TRIM(FUNCTION_ID) = TRIM(P_FORMAT_DTLS.FUNCTION_ID);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Function Id Does Not Exists...');
        RETURN FALSE;
    END;
    BEGIN
      DELETE FROM GITB_JOBS
       WHERE INTERFACE_CODE = P_FORMAT_DTLS.INTERFACE_CODE
         AND FILE_NAME = REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                                 '.',
                                 '_');
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('failed to delete the records...');
        RETURN FALSE;
    END;
    FOR I IN 1 .. PROCESS_COUNT LOOP
      DBG('INTERFACE CODE...' || GIPKS_INTERFACE_TRIGGER.G_INTERFACE_CODE);
      GIPKS_INTERFACE_TRIGGER.G_PROCESS_NO := I;
      P_USER                               := 'SYSTEM';
      P_BRANCH                             := GLOBAL.CURRENT_BRANCH;

      DBG('Process Number Assigned is...' ||
          GIPKS_INTERFACE_TRIGGER.G_PROCESS_NO);
      DBG('File Name...' || GIPKS_INTERFACE_TRIGGER.G_FILE_NAME);
      IF L_TYPE_STRING <> 'O' THEN
        D_PROG := 'GIPKS_' || P_FORMAT_DTLS.INTERFACE_CODE || '_' ||
                  REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                          '.',
                          '_') || '.fn_upload';

      ELSE
        D_PROG := 'GIPKS_#' || P_FORMAT_DTLS.FUNCTION_ID || '.fn_upload';
      END IF;
      DBG('D_PROG   ' || D_PROG);
      DBG('Package Name ' || D_PROG);
      D_SQL := 'DECLARE ' || CHR(10);
      D_SQL := D_SQL || ' ' ||
               'l_err_code       varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_code;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' ||
               'l_err_params     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_err_params;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' || 'l_user       varchar2(100):=  ' || '''' ||
               P_USER || '''' || ';' || CHR(10);
      D_SQL := D_SQL || ' ' || 'l_source       varchar2(100):=  ' || '''' ||
               CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') || '''' || ';' ||
               CHR(10);
      D_SQL := D_SQL || ' ' || 'l_branch       varchar2(3):=  ' || '''' ||
               P_BRANCH || '''' || ';' || CHR(10);

      D_SQL := D_SQL || ' ' ||
               'l_intf_code     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_interface_code;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' ||
               'l_file_name     varchar2(255):=  REPLACE(GIPKS_INTERFACE_TRIGGER.g_file_name,''.'',''_'');  ' ||
               CHR(10);

      D_SQL := D_SQL || ' ' ||
               'l_process_no     Number :=  GIPKS_INTERFACE_TRIGGER.g_process_no;  ' ||
               CHR(10);

      D_SQL := D_SQL || ' ' ||
               'l_status     varchar2(255):=  GIPKS_INTERFACE_TRIGGER.g_status;  ' ||
               CHR(10);

      D_SQL := D_SQL || ' ' || 'l_records_errored     number :=  0;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' || 'l_records_processed     number :=  0;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' || 'l_records_errored_prev     number :=  0;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' ||
               'l_records_processed_prev     number :=  0;  ' || CHR(10);
      D_SQL := D_SQL || ' ' || 'p_err_params    varchar2(32000) ;  ' ||
               CHR(10);
      D_SQL := D_SQL || ' ' || 'p_err_code    varchar2(1000);  ' || CHR(10);

      D_SQL := D_SQL || 'BEGIN' || CHR(10);
      D_SQL := D_SQL || 'global.pr_init(l_branch,l_user);' || CHR(10);
      D_SQL := D_SQL || 'cspks_req_global.g_header(''SOURCE''):=l_source;' ||
               CHR(10);

      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'GIPKS_INTERFACE_TRIGGER.g_process_no.....' || '''' ||
               ' || ' || 'GIPKS_INTERFACE_TRIGGER.g_process_no' || ');' ||
               CHR(10);
      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'GIPKS_INTERFACE_TRIGGER.g_err_code.....' || '''' || ' || ' ||
               'GIPKS_INTERFACE_TRIGGER.g_err_code' || ');' || CHR(10);
      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'GIPKS_INTERFACE_TRIGGER.g_err_params.....' || '''' ||
               ' || ' || 'GIPKS_INTERFACE_TRIGGER.g_err_params' || ');' ||
               CHR(10);
      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'l_err_code.....' || '''' || ' || ' || 'l_err_code' || ');' ||
               CHR(10);
      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'l_err_params.....' || '''' || ' || ' || 'l_err_params' || ');' ||
               CHR(10);

      D_SQL := D_SQL || 'IF NOT ' || D_PROG || '(' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || ' , ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || ' , ' ||

               '''' || REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                               '.',
                               '_') || '''' || ' , ' || P_LOG_SERIAL ||
               ' , ' ||

               I || ' , ' || ' l_err_code, l_err_params, l_status)  THEN ' ||
               CHR(10);
      D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_return := FALSE;' ||
               CHR(10);
      D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_status := l_status;' ||
               CHR(10);
      D_SQL := D_SQL || 'GIPKS_INTERFACE_TRIGGER.g_err_code := l_err_code;' ||
               CHR(10);
      D_SQL := D_SQL ||
               'GIPKS_INTERFACE_TRIGGER.g_err_params := l_err_params;' ||
               CHR(10);
      D_SQL := D_SQL || '   UPDATE gitb_JOBS SET TASK_STATUS=' || '''' || 'E' || '''' ||
               ', end_time=fn_hostdatetime' || CHR(10);
      D_SQL := D_SQL || '            WHERE INTERFACE_CODE=' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || CHR(10);
      D_SQL := D_SQL || '           and file_name= ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || CHR(10);
      D_SQL := D_SQL || '           and process_no=' || I || ';' || CHR(10);
      D_SQL := D_SQL || '  ELSE                             ' || CHR(10);
      D_SQL := D_SQL || '   UPDATE gitb_JOBS SET TASK_STATUS=' || '''' || 'P' || '''' ||
               ', end_time=fn_hostdatetime' || CHR(10);
      D_SQL := D_SQL || '            WHERE INTERFACE_CODE=' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || CHR(10);
      D_SQL := D_SQL || '           and file_name= ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || CHR(10);
      D_SQL := D_SQL || '           and process_no=' || I || ';' || CHR(10);
      D_SQL := D_SQL || 'END IF;' || CHR(10);

      D_SQL := D_SQL ||
               'SELECT COUNT(1) into l_records_errored From GITM_UPLOAD_MASTER Where ' ||
               CHR(10) || 'INTERFACE_CODE = ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE || '''' ||
               CHR(10) || 'And FILE_NAME = ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || CHR(10) || ' And Status = ' || '''' || 'E' || '''' ||
               CHR(10) || 'And PROCESS_REF_NO =' || P_LOG_SERIAL || ';' ||
               CHR(10);

      D_SQL := D_SQL ||
               'SELECT COUNT(1) into l_records_processed From GITM_UPLOAD_MASTER ' ||
               CHR(10) || 'Where INTERFACE_CODE = ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.INTERFACE_CODE || '''' ||
               CHR(10) || 'And FILE_NAME = ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || CHR(10) || ' And Status = ' || '''' || 'P' || '''' ||
               CHR(10) || 'And PROCESS_REF_NO =' || P_LOG_SERIAL || ';' ||
               CHR(10);

      D_SQL := D_SQL || 'IF l_records_processed != 0 THEN' || CHR(10);
      D_SQL := D_SQL || 'IF trim(l_err_code) Is Null THEN' || CHR(10);
      D_SQL := D_SQL || 'p_err_code := ' || '''' || 'MS-AUT06' || '''' || ';' ||
               CHR(10);
      D_SQL := D_SQL || 'p_err_params := ' || '''' ||
               'Uploaded Successfully' || '''' || ';' || CHR(10);
      D_SQL := D_SQL || 'ELSE ' || CHR(10);
      D_SQL := D_SQL || 'p_err_code:=l_err_code;' || CHR(10);
      D_SQL := D_SQL || 'p_err_params:= l_err_params;' || CHR(10);
      D_SQL := D_SQL || 'END IF;' || CHR(10);
      D_SQL := D_SQL || 'debug.pr_debug' || '(' || '''' || 'GI' || '''' || ',' || '''' ||
               'p_err_code.....' || '''' || ' || ' || 'p_err_code' || ');' ||
               CHR(10);

      D_SQL := D_SQL || '   UPDATE gitb_FILE_LOG SET STATUS=' || '''' || 'P' || '''' ||
               ', end_date_stamp=fn_hostdatetime, ' || CHR(10) ||
               'records_errored=l_records_errored , records_processed=l_records_processed ,' ||
               CHR(10);
      D_SQL := D_SQL ||
               'error_code=p_err_code , error_params= p_err_params' ||
               CHR(10);
      D_SQL := D_SQL || '          WHERE INTERFACE_CODE=' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || CHR(10);
      D_SQL := D_SQL || '           and file_name= ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '''' ||
               CHR(10);
      D_SQL := D_SQL || '           AND PROCESS_CODE = ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE || '''' ||
               CHR(10) || '           and process_ref_no=' || P_LOG_SERIAL || ';' ||
               CHR(10);

      D_SQL := D_SQL || 'ELSE ' || CHR(10);
      D_SQL := D_SQL || '   UPDATE gitb_FILE_LOG SET STATUS=' || '''' || 'E' || '''' ||
               ', end_date_stamp=fn_hostdatetime, ' || CHR(10) ||
               'records_errored=l_records_errored,records_processed=l_records_processed ,' ||
               CHR(10);
      D_SQL := D_SQL ||
               'error_code=p_err_code , error_params= p_err_params' ||
               CHR(10);
      D_SQL := D_SQL || '          WHERE INTERFACE_CODE=' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || CHR(10);
      D_SQL := D_SQL || '           and file_name= ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME || '''' ||
               CHR(10);
      D_SQL := D_SQL || '           AND PROCESS_CODE = ' || '''' ||
               P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.PROCESS_CODE || '''' ||
               CHR(10) || '           and process_ref_no=' || P_LOG_SERIAL || ';' ||
               CHR(10);

      D_SQL := D_SQL || 'END IF; ' || CHR(10);

      D_SQL := D_SQL || 'COMMIT; ' || CHR(10);
      D_SQL := D_SQL || 'EXCEPTION    ' || CHR(10);
      D_SQL := D_SQL || 'WHEN OTHERS THEN ' || CHR(10);
      D_SQL := D_SQL || '              UPDATE gitb_JOBS SET TASK_STATUS=' || '''' || 'E' || '''' ||
               ', end_time=fn_hostdatetime' || CHR(10);
      D_SQL := D_SQL || '            WHERE INTERFACE_CODE=' || '''' ||
               P_FORMAT_DTLS.INTERFACE_CODE || '''' || CHR(10);
      D_SQL := D_SQL || '           and file_name= ' || '''' ||
               REPLACE(P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                       '.',
                       '_') || '''' || CHR(10);
      D_SQL := D_SQL || '                    and process_no=' || I || ';' ||
               CHR(10);
      D_SQL := D_SQL || 'COMMIT; ' || CHR(10);
      D_SQL := D_SQL || 'END;' || CHR(10);

      DBG('DYNAMIC SQL...');
      DBG(D_SQL);

      BEGIN

        L_JOB_NO := TO_CHAR(GLOBAL.APPLICATION_DATE, 'DDMMYYYY') ||
                    TO_CHAR(FN_HOSTDATETIME, 'HH24MISS') + I;
        DBG('l_job_no = ' || L_JOB_NO);

        DEBUG.PR_DEBUG('GI', 'l_job_no ' || L_JOB_NO);

        DEBUG.PR_DEBUG('GI',
                       '## Just before calling pr_run_parallel_jobs for job no...' ||
                       L_JOB_NO);
        PR_RUN_PARALLEL_JOB(D_SQL,
                            L_JOB_NO,
                            I,
                            P_GIDIFPRS.IFPRS_GITM_INTERFACE_TRIGGER.FILE_NAME,
                            P_FORMAT_DTLS.INTERFACE_CODE,
                            P_LOG_SERIAL,
                            P_ERR_CODE,
                            P_ERR_PARAMS);
        DEBUG.PR_DEBUG('GI', '####Ran the job...');
        DEBUG.PR_DEBUG('GI',
                       '## Just after calling pr_run_parallel_jobs for job no...' ||
                       L_JOB_NO);

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in Inserting into gitm_jobs');
          DEBUG.PR_DEBUG('GI', SQLERRM);
          DBG('eRROR..' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_LOG_ERROR(P_SOURCE, G_ERR_CODE, G_ERR_PARAMS);
      END;

    END LOOP;
    DBG('Waiting for Some time....');
    DBMS_LOCK.SLEEP(L_SEC);

    P_STATUS := 'S';
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in UPloading Jobs...');
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_PARALLEL_JOBS;

  FUNCTION FN_APPLY_MASK(P_FILE_NAME       IN OUT VARCHAR2,
                         P_MASK            IN OUT GITM_FORMAT_DEFINITION.PROCESSED_FILE_MASK%TYPE,
                         P_INTERFACE_CODE  IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE,
                         P_EXTERNAL_SYSTEM IN GITM_FORMAT_DEFINITION.EXTERNAL_SYSTEM%TYPE,
                         P_BRANCH_CODE     IN GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE,
                         P_ERROR           IN OUT VARCHAR2,
                         P_ERR_PARAM       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_FILE_MASK GITM_FORMAT_DEFINITION.PROCESSED_FILE_MASK%TYPE;
    L_FILE_NAME VARCHAR2(100);
    TYPE TY_FILE_MASK_ARRAY IS TABLE OF VARCHAR2(10) INDEX BY BINARY_INTEGER;
    L_FILE_MASK_ARRAY TY_FILE_MASK_ARRAY;
    L_IND             NUMBER := 0;
    L_POS             NUMBER := 1;

    L_APP_DATE VARCHAR2(500);
    L_DAY      NUMBER;
    L_MON      NUMBER;
    L_YEAR     NUMBER;
    E_FAILURE_EXCEPTION EXCEPTION;
    L_INTERFACE_TYPE GITM_FORMAT_DEFINITION.INTERFACE_TYPE%TYPE;

  BEGIN
    DBG('INSIDE FN_GET_FILE_NAME');
    L_FILE_MASK := P_MASK;
    L_APP_DATE  := TO_CHAR(GLOBAL.APPLICATION_DATE +
                           (FN_HOSTDATETIME - TRUNC(FN_HOSTDATETIME)),
                           'DD/MM/YYYY HH24:mm:ss');
    DBG('Application Date ' || L_APP_DATE);
    DBG('global.Application Date ' || GLOBAL.APPLICATION_DATE);

    DBG('File Mask ' || L_FILE_MASK);
    IF L_FILE_MASK IS NOT NULL THEN
      WHILE L_POS <= LENGTH(TRIM(L_FILE_MASK)) LOOP
        DBG('INSERTING CHARACTER BY CHARACTER TO ARRAY');
        L_IND := L_IND + 1;
        L_FILE_MASK_ARRAY(L_IND) := SUBSTR(L_FILE_MASK, L_POS, 1);
        L_POS := L_POS + 1;
      END LOOP;
    END IF;

    IF L_FILE_MASK_ARRAY.COUNT > 0 THEN
      FOR L_INDEX IN L_FILE_MASK_ARRAY.FIRST .. L_FILE_MASK_ARRAY.LAST LOOP
        DBG('Character No ' || L_INDEX || ' ' ||
            L_FILE_MASK_ARRAY(L_INDEX));
        IF L_INDEX < L_FILE_MASK_ARRAY.COUNT THEN
          IF L_FILE_MASK_ARRAY(L_INDEX) = '/' THEN
            L_FILE_NAME := L_FILE_NAME || L_FILE_MASK_ARRAY(L_INDEX + 1);
          ELSIF L_FILE_MASK_ARRAY(L_INDEX) = '$' THEN
            IF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'B' THEN
              L_FILE_NAME := L_FILE_NAME || GLOBAL.CURRENT_BRANCH;
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'U' THEN
              L_FILE_NAME := L_FILE_NAME || GLOBAL.USER_ID;
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'D' THEN
              L_FILE_NAME := L_FILE_NAME ||
                             SUBSTR(GLOBAL.APPLICATION_DATE, 1, 2);
              DBG('Date ' || SUBSTR(GLOBAL.APPLICATION_DATE, 1, 2));
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'M' THEN

              L_FILE_NAME := L_FILE_NAME || TO_CHAR(TO_DATE(GLOBAL.APPLICATION_DATE,
                                                            'DD-MON-YYYY'),
                                                    'MM');
              DBG('Month ' ||
                  TO_CHAR(TO_DATE(GLOBAL.APPLICATION_DATE, 'DD-MON-YYYY'),
                          'MM'));

            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'Y' THEN
              L_YEAR      := EXTRACT(YEAR FROM GLOBAL.APPLICATION_DATE);
              L_FILE_NAME := L_FILE_NAME || TO_CHAR(L_YEAR);
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'h' THEN
              L_FILE_NAME := L_FILE_NAME || SUBSTR(L_APP_DATE, 12, 2);
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 'm' THEN
              L_FILE_NAME := L_FILE_NAME || SUBSTR(L_APP_DATE, 15, 2);
            ELSIF L_FILE_MASK_ARRAY(L_INDEX + 1) = 's' THEN
              L_FILE_NAME := L_FILE_NAME || SUBSTR(L_APP_DATE, 18, 2);
            END IF;
          END IF;
        END IF;
      END LOOP;
    END IF;

    DBG('l_file_name ' || L_FILE_NAME);
    P_FILE_NAME := L_FILE_NAME;

    DBG('RETURNING FROM FN_GET_FILE_NAME');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('!!! FN_GET_FILE_NAME - ' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_APPLY_MASK;

  FUNCTION FN_WRITE_FILE(P_DIRECTORY IN OUT VARCHAR2,
                         P_FILENAME  IN OUT VARCHAR2,
                         P_MSG       IN CLOB,
                         P_ERROR     IN OUT VARCHAR2,
                         P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS

    FILE_HANDLE UTL_FILE.FILE_TYPE;
    TYPE TEMP_ARRAY IS TABLE OF VARCHAR2(32767) INDEX BY BINARY_INTEGER;
    V_ARRAY        TEMP_ARRAY;
    LENGTH_OF_FILE NUMBER(20);
    NO_OF_INDEXES  NUMBER(20);
    REMAINDER      NUMBER(20);
    BUFFER_SIZE    NUMBER(20) := 32767;
    STR            NUMBER(20) := 1;
    EN             NUMBER(20) := 0;
    DIR_NAME       ALL_DIRECTORIES.DIRECTORY_NAME%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('GI', 'Start of function fn_write_file....');
    DEBUG.PR_DEBUG('GI', 'buffer_size :: ' || BUFFER_SIZE);
    DEBUG.PR_DEBUG('GI', 'p_directory :: ' || P_DIRECTORY);
    DEBUG.PR_DEBUG('GI', 'p_filename :: ' || P_FILENAME);

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      FILE_HANDLE := UTL_FILE.FOPEN(P_DIRECTORY,
                                    P_FILENAME,
                                    'w',
                                    BUFFER_SIZE);

    ELSE
      IF NOT GLOBAL_FRC_CORE.FN_GET_DIRECTORY_NAME(P_DIRECTORY,
                                                   DIR_NAME,
                                                   P_ERROR,
                                                   P_ERR_PARAM) THEN
        DEBUG.PR_DEBUG('GI', 'Failed while getting Directory Name ');
        RETURN FALSE;
      END IF;
      FILE_HANDLE := UTL_FILE.FOPEN(DIR_NAME, P_FILENAME, 'w', BUFFER_SIZE);
    END IF;

    UTL_FILE.FCLOSE(FILE_HANDLE);
    LENGTH_OF_FILE := DBMS_LOB.GETLENGTH(P_MSG);
    NO_OF_INDEXES  := FLOOR(LENGTH_OF_FILE / BUFFER_SIZE);
    REMAINDER      := LENGTH_OF_FILE - (BUFFER_SIZE * NO_OF_INDEXES);
    DEBUG.PR_DEBUG('GI', 'length of file : ' || LENGTH_OF_FILE);
    DEBUG.PR_DEBUG('GI', 'no_of_indexes : ' || NO_OF_INDEXES);
    DEBUG.PR_DEBUG('GI', 'remainder : ' || REMAINDER);
    IF NO_OF_INDEXES > 0 THEN
      FOR IND IN 1 .. NO_OF_INDEXES LOOP
        DEBUG.PR_DEBUG('GI', 'Start : ' || STR || ' End :' || EN);
        V_ARRAY(IND) := DBMS_LOB.SUBSTR(P_MSG, BUFFER_SIZE, STR);
        STR := STR + BUFFER_SIZE;
      END LOOP;
    END IF;
    IF REMAINDER > 0 THEN
      DEBUG.PR_DEBUG('GI',
                     'last Start : ' || STR || ' last End :' ||
                     LENGTH_OF_FILE);
      V_ARRAY(V_ARRAY.COUNT + 1) := DBMS_LOB.SUBSTR(P_MSG, REMAINDER, STR);
    END IF;
    DEBUG.PR_DEBUG('GI', 'Array length : ' || V_ARRAY.COUNT);
    FOR IND IN V_ARRAY.FIRST .. V_ARRAY.LAST LOOP
      DEBUG.PR_DEBUG('GI', 'Array length : ' || V_ARRAY.COUNT);
    END LOOP;

    IF GLOBAL.IS12CR2 <> 'Y' THEN
      FILE_HANDLE := UTL_FILE.FOPEN(P_DIRECTORY,
                                    P_FILENAME,
                                    'a',
                                    BUFFER_SIZE);

    ELSE
      FILE_HANDLE := UTL_FILE.FOPEN(DIR_NAME, P_FILENAME, 'a', BUFFER_SIZE);
    END IF;

    FOR IND IN V_ARRAY.FIRST .. V_ARRAY.LAST LOOP
      UTL_FILE.PUT(FILE_HANDLE, V_ARRAY(IND));
      UTL_FILE.FFLUSH(FILE_HANDLE);
    END LOOP;
    UTL_FILE.FCLOSE(FILE_HANDLE);
    DEBUG.PR_DEBUG('GI', 'End of function fn_write_file....');
    RETURN TRUE;
  EXCEPTION
    WHEN UTL_FILE.INVALID_PATH THEN

      DBG('25965329 In UTL_FILE.invalid_path');
      BEGIN
        SELECT DIRECTORY_NAME
          INTO DIR_NAME
          FROM ALL_DIRECTORIES
         WHERE DIRECTORY_PATH = P_DIRECTORY;
        DBG('25965329 dir_name -->' || DIR_NAME);
        FILE_HANDLE := UTL_FILE.FOPEN(DIR_NAME,
                                      P_FILENAME,
                                      'w',
                                      BUFFER_SIZE);
        UTL_FILE.FCLOSE(FILE_HANDLE);
        LENGTH_OF_FILE := DBMS_LOB.GETLENGTH(P_MSG);
        NO_OF_INDEXES  := FLOOR(LENGTH_OF_FILE / BUFFER_SIZE);
        REMAINDER      := LENGTH_OF_FILE - (BUFFER_SIZE * NO_OF_INDEXES);
        DEBUG.PR_DEBUG('GI', 'length of file : ' || LENGTH_OF_FILE);
        DEBUG.PR_DEBUG('GI', 'no_of_indexes : ' || NO_OF_INDEXES);
        DEBUG.PR_DEBUG('GI', 'remainder : ' || REMAINDER);
        IF NO_OF_INDEXES > 0 THEN
          FOR IND IN 1 .. NO_OF_INDEXES LOOP
            DEBUG.PR_DEBUG('GI', 'Start : ' || STR || ' End :' || EN);
            V_ARRAY(IND) := DBMS_LOB.SUBSTR(P_MSG, BUFFER_SIZE, STR);
            STR := STR + BUFFER_SIZE;
          END LOOP;
        END IF;
        IF REMAINDER > 0 THEN
          DEBUG.PR_DEBUG('GI',
                         'last Start : ' || STR || ' last End :' ||
                         LENGTH_OF_FILE);
          V_ARRAY(V_ARRAY.COUNT + 1) := DBMS_LOB.SUBSTR(P_MSG,
                                                        REMAINDER,
                                                        STR);
        END IF;
        DEBUG.PR_DEBUG('GI', 'Array length : ' || V_ARRAY.COUNT);
        FOR IND IN V_ARRAY.FIRST .. V_ARRAY.LAST LOOP
          DEBUG.PR_DEBUG('GI', 'Array length : ' || V_ARRAY.COUNT);
        END LOOP;
        FILE_HANDLE := UTL_FILE.FOPEN(DIR_NAME,
                                      P_FILENAME,
                                      'a',
                                      BUFFER_SIZE);
        FOR IND IN V_ARRAY.FIRST .. V_ARRAY.LAST LOOP
          UTL_FILE.PUT(FILE_HANDLE, V_ARRAY(IND));
          UTL_FILE.FFLUSH(FILE_HANDLE);
        END LOOP;
        UTL_FILE.FCLOSE(FILE_HANDLE);
        DBG('25965329 Successfully completed writing file');
        RETURN TRUE;
      EXCEPTION
        WHEN UTL_FILE.INVALID_PATH THEN

          DBG('!!! utl_file raised INVALID_PATH exception - ' ||
              P_DIRECTORY);
          DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
    WHEN UTL_FILE.INVALID_FILEHANDLE THEN
      DBG('!!! utl_file raised INVALID_FILEHANDLE exception');
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    WHEN UTL_FILE.WRITE_ERROR THEN
      DBG('!!! utl_file raised WRITE_ERROR exception' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      IF UTL_FILE.IS_OPEN(FILE_HANDLE) THEN
        UTL_FILE.FCLOSE(FILE_HANDLE);
      END IF;
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('!!! Exception in fn_write_file - ' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      IF UTL_FILE.IS_OPEN(FILE_HANDLE) THEN
        UTL_FILE.FCLOSE(FILE_HANDLE);
      END IF;
      RETURN FALSE;
  END FN_WRITE_FILE;

  FUNCTION FN_WRITELOGTOFILE(P_INTERFACE_CODE IN VARCHAR2,
                             P_FILE_NAME      IN VARCHAR2,
                             P_PHY_FILE_NAME  IN VARCHAR2,
                             P_SERIAL         IN VARCHAR2,
                             P_LOG_OUTPUT     IN VARCHAR2) RETURN BOOLEAN

   AS
    CURSOR CUR_COMP_LINK_FIELDS(SZINTERFACENAME VARCHAR2) IS
      SELECT COLUMN_NAME, FIELD_LENGTH, SERIAL_NO, DATA_TYPE
        FROM GITM_COMP_FLD_LINKAGE
       WHERE INTERFACE_CODE = P_INTERFACE_CODE
         AND PKEY = 'Y'
       ORDER BY SERIAL_NO;
    TYPE TYP_UPLOAD_MASTER IS REF CURSOR;
    CR_UPLOAD_MASTER TYP_UPLOAD_MASTER;
    TYPE TY_COMP_LINK_FIELDS IS TABLE OF CUR_COMP_LINK_FIELDS%ROWTYPE INDEX BY BINARY_INTEGER;
    L_TB_COMP_LINK_FIELDS TY_COMP_LINK_FIELDS;
    L_FLDLIST             VARCHAR2(4000);
    L_COUNT               NUMBER := 0;
    L_FILE_MSG            CLOB;
    L_FILE_NAME           VARCHAR(100);
    L_SQL_QUERY           VARCHAR2(2048);
    L_NUM_REC             NUMBER := 0;
    LV_SFD                CLOB;
    L_TXT_ALIGN           GITM_INTERFACE_DEFINITION.TEXT_JUSTIFICATION%TYPE;
    L_NUM_ALIGN           GITM_INTERFACE_DEFINITION.NUMBER_JUSTIFICATION%TYPE;
    L_DT_ALIGN            GITM_INTERFACE_DEFINITION.DATE_JUSTIFICATION%TYPE;
    L_TXT_PAD             GITM_INTERFACE_DEFINITION.TEXT_PADDING_CHARACTER%TYPE;
    L_NUM_PAD             GITM_INTERFACE_DEFINITION.NUMBER_PADDING_CHARACTER%TYPE;
    L_DT_PAD              GITM_INTERFACE_DEFINITION.DATE_PADDING_CHARACTER%TYPE;
    L_PAD_POSITION        VARCHAR2(5);
    P_ERROR               GITU_UPLOAD_MASTER.ERROR%TYPE;
    P_ERROR_PARAM         GITU_UPLOAD_MASTER.ERROR_PARAM%TYPE;
    L_INIT_DIR            VARCHAR2(100);
    L_ORIG_DIR            VARCHAR2(100);
    L_FILE_TYPE           VARCHAR2(50);
    L_REC_STATUS          VARCHAR2(1);
    L_LOOP_CNT            NUMBER;
  BEGIN
    DEBUG.PR_DEBUG('GI', 'start of function fn_WriteLogToFile....');

    DEBUG.PR_DEBUG('GI', 'p_interface_code : ' || P_INTERFACE_CODE);
    DEBUG.PR_DEBUG('GI', 'p_file_name : ' || P_FILE_NAME);
    DEBUG.PR_DEBUG('GI', 'p_phy_file_name : ' || P_PHY_FILE_NAME);
    DEBUG.PR_DEBUG('GI', 'p_serial : ' || P_SERIAL);
    DEBUG.PR_DEBUG('GI', 'p_log_output : ' || P_LOG_OUTPUT);
    L_FILE_TYPE := REPLACE(P_FILE_NAME, '.', '_');

    IF CUR_COMP_LINK_FIELDS%ISOPEN THEN
      CLOSE CUR_COMP_LINK_FIELDS;
    END IF;
    DEBUG.PR_DEBUG('GI', 'Opening Cursor cur_comp_link_fields');
    OPEN CUR_COMP_LINK_FIELDS(P_INTERFACE_CODE);
    FETCH CUR_COMP_LINK_FIELDS BULK COLLECT
      INTO L_TB_COMP_LINK_FIELDS;
    DEBUG.PR_DEBUG('GI',
                   'Number of rows fetched by cur_comp_link_fields is : ' ||
                   L_TB_COMP_LINK_FIELDS.COUNT);
    BEGIN
      SELECT FILE_PATH,
             TEXT_JUSTIFICATION,
             NUMBER_JUSTIFICATION,
             DATE_JUSTIFICATION,
             TEXT_PADDING_CHARACTER,
             NUMBER_PADDING_CHARACTER,
             DATE_PADDING_CHARACTER
        INTO L_ORIG_DIR,
             L_TXT_ALIGN,
             L_NUM_ALIGN,
             L_DT_ALIGN,
             L_TXT_PAD,
             L_NUM_PAD,
             L_DT_PAD
        FROM GITM_INTERFACE_DEFINITION
       WHERE INTERFACE_CODE = P_INTERFACE_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('GI',
                       'Error in fetching interface definition details');
        RETURN FALSE;
    END;
    IF SUBSTR(L_ORIG_DIR, LENGTH(L_ORIG_DIR), 1) = GLOBAL.SLASH THEN
      L_ORIG_DIR := SUBSTR(L_ORIG_DIR, LENGTH(L_ORIG_DIR) - 1);
    END IF;
    DEBUG.PR_DEBUG('GI', 'l_orig_dir : ' || L_ORIG_DIR);
    DEBUG.PR_DEBUG('GI', 'before for loop');
    IF (L_TB_COMP_LINK_FIELDS.COUNT <= 0) THEN
      DEBUG.PR_DEBUG('GI', 'No Primary key found exit success');
      RETURN TRUE;
    END IF;
    DBG('25515264 l_txt_align : ' || L_TXT_ALIGN);
    DBG('25515264 l_dt_align : ' || L_DT_ALIGN);
    DBG('25515264 l_num_align : ' || L_NUM_ALIGN);
    FOR IDX IN L_TB_COMP_LINK_FIELDS.FIRST .. L_TB_COMP_LINK_FIELDS.LAST LOOP
      L_COUNT := L_COUNT + 1;
      IF L_TB_COMP_LINK_FIELDS(IDX).DATA_TYPE IN ('VARCHAR2') THEN
        IF L_TXT_ALIGN = 'L' THEN
          L_PAD_POSITION := 'RPAD(';
        ELSIF L_TXT_ALIGN = 'R' THEN
          L_PAD_POSITION := 'LPAD(';

        ELSE
          L_PAD_POSITION := '(';

        END IF;
        DBG('25515264 l_pad_position : ' || L_PAD_POSITION);

        IF L_TXT_ALIGN IS NULL THEN

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || Q'[)||]';
        ELSE

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || ',' || L_TB_COMP_LINK_FIELDS(IDX)
                      .FIELD_LENGTH || ',' || '''' || L_TXT_PAD ||
                       Q'[')||]';
        END IF;
      ELSIF L_TB_COMP_LINK_FIELDS(IDX).DATA_TYPE IN ('DATE') THEN
        IF L_DT_ALIGN = 'L' THEN
          L_PAD_POSITION := 'RPAD(';
        ELSIF L_DT_ALIGN = 'R' THEN
          L_PAD_POSITION := 'LPAD(';

        ELSE
          L_PAD_POSITION := '(';

        END IF;
        DBG('25515264 l_pad_position : ' || L_PAD_POSITION);

        IF L_DT_ALIGN IS NULL THEN

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || Q'[)||]';
        ELSE

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || ',' || L_TB_COMP_LINK_FIELDS(IDX)
                      .FIELD_LENGTH || ',' || '''' || L_DT_PAD || Q'[')||]';
        END IF;
      ELSIF L_TB_COMP_LINK_FIELDS(IDX).DATA_TYPE IN ('NUMBER') THEN
        IF L_NUM_ALIGN = 'L' THEN
          L_PAD_POSITION := 'RPAD(';
        ELSIF L_NUM_ALIGN = 'R' THEN
          L_PAD_POSITION := 'LPAD(';

        ELSE
          L_PAD_POSITION := '(';

        END IF;
        DBG('25515264 l_pad_position : ' || L_PAD_POSITION);

        IF L_NUM_ALIGN IS NULL THEN

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || Q'[)||]';
        ELSE

          L_FLDLIST := L_FLDLIST || L_PAD_POSITION || 'FLD' || L_TB_COMP_LINK_FIELDS(IDX)
                      .SERIAL_NO || ',' || L_TB_COMP_LINK_FIELDS(IDX)
                      .FIELD_LENGTH || ',' || '''' || L_NUM_PAD ||
                       Q'[')||]';
        END IF;
      END IF;
      DEBUG.PR_DEBUG('GI',
                     'l_count : ' || L_COUNT || ' l_fldList : ' ||
                     L_FLDLIST);
    END LOOP;
    DEBUG.PR_DEBUG('GI', 'l_count final : ' || L_COUNT);
    DEBUG.PR_DEBUG('GI', ' l_fldList final : ' || L_FLDLIST);
    L_FLDLIST := SUBSTR(L_FLDLIST, 1, LENGTH(L_FLDLIST) - 2);
    DEBUG.PR_DEBUG('GI', ' l_fldList final : ' || L_FLDLIST);
    DEBUG.PR_DEBUG('GI', 'Building Dynamic Query starts');
    IF P_LOG_OUTPUT = 'SUC' THEN
      DEBUG.PR_DEBUG('GI',
                     'Need to write only Processed records. so loop count 1 and status P');
      L_REC_STATUS := 'P';
      L_LOOP_CNT   := 1;
    ELSIF P_LOG_OUTPUT = 'ERR' THEN
      DEBUG.PR_DEBUG('GI',
                     'Need to write only Error records. so loop count 1 and status E');
      L_REC_STATUS := 'E';
      L_LOOP_CNT   := 1;
    ELSIF P_LOG_OUTPUT = 'BTH' THEN
      DEBUG.PR_DEBUG('GI',
                     'Need to write Processed as well as Error records. so loop count 2 and status P to process Success first');
      L_REC_STATUS := 'P';
      L_LOOP_CNT   := 2;
    END IF;
    FOR I IN 1 .. L_LOOP_CNT LOOP
      L_FILE_MSG    := NULL;
      LV_SFD        := NULL;
      P_ERROR       := NULL;
      P_ERROR_PARAM := NULL;
      L_SQL_QUERY   := 'SELECT ' || L_FLDLIST;

      L_SQL_QUERY := L_SQL_QUERY ||
                     ' col1 , ERROR,ERROR_PARAM FROM Gitu_Upload_Master WHERE STATUS = ''' ||
                     L_REC_STATUS || ''' AND FILE_NAME = ''' || L_FILE_TYPE ||
                     ''' AND PHY_FILE_NAME = ''' || P_PHY_FILE_NAME ||
                     ''' AND PROCESS_REF_NO = ''' || P_SERIAL || '''';
      DEBUG.PR_DEBUG('GI', 'l_sql_query --> : ' || L_SQL_QUERY);
      DEBUG.PR_DEBUG('GI', 'Building Dynamic Query Ends');
      OPEN CR_UPLOAD_MASTER FOR L_SQL_QUERY;
      LOOP
        FETCH CR_UPLOAD_MASTER
          INTO LV_SFD, P_ERROR, P_ERROR_PARAM;
        DEBUG.PR_DEBUG('GI', 'LV_SFD --> : ' || LV_SFD);
        DEBUG.PR_DEBUG('GI', 'p_error --> : ' || P_ERROR);
        DEBUG.PR_DEBUG('GI', 'p_error_param --> : ' || P_ERROR_PARAM);
        EXIT WHEN CR_UPLOAD_MASTER%NOTFOUND;
        L_NUM_REC  := L_NUM_REC + 1;
        L_FILE_MSG := L_FILE_MSG || LV_SFD;
        L_FILE_MSG := L_FILE_MSG || P_ERROR || P_ERROR_PARAM || CHR(10);
        DEBUG.PR_DEBUG('GI',
                       'Record Number : ' || L_NUM_REC ||
                       ' Error Message : ' || L_FILE_MSG);
      END LOOP;
      DEBUG.PR_DEBUG('GI',
                     'l_ErrorMsg_rec Final to be write --> : ' ||
                     L_FILE_MSG);
      IF L_FILE_MSG IS NOT NULL THEN
        L_INIT_DIR := L_ORIG_DIR;
        DEBUG.PR_DEBUG('GI', 'l_init_dir : ' || L_INIT_DIR);
        IF L_REC_STATUS = 'E' THEN
          L_FILE_NAME := P_INTERFACE_CODE || '_' ||
                         REPLACE(P_PHY_FILE_NAME, '.', '_') || '_ERR_' ||
                         P_SERIAL || '.dat';
          L_INIT_DIR  := L_INIT_DIR || '/log_failure';
        ELSIF L_REC_STATUS = 'P' THEN
          L_FILE_NAME := P_INTERFACE_CODE || '_' ||
                         REPLACE(P_PHY_FILE_NAME, '.', '_') || '_SUC_' ||
                         P_SERIAL || '.dat';
          L_INIT_DIR  := L_INIT_DIR || '/log_success';
        END IF;
        DEBUG.PR_DEBUG('GI', 'l_file_name @@@@ : ' || L_FILE_NAME);
        DEBUG.PR_DEBUG('GI', 'l_init_dir @@@@ : ' || L_INIT_DIR);
        IF NOT FN_WRITE_FILE(L_INIT_DIR,
                             L_FILE_NAME,
                             L_FILE_MSG,
                             P_ERROR,
                             P_ERROR_PARAM) THEN
          DEBUG.PR_DEBUG('GI',
                         'Error in writting file : ' || L_FILE_NAME ||
                         ' Error is : ' || SQLERRM);
        END IF;
      END IF;
      IF P_LOG_OUTPUT = 'BTH' THEN
        DEBUG.PR_DEBUG('GI',
                       'Log output is Both. Success is already processed. So next status is E - Error');
        L_REC_STATUS := 'E';
      END IF;
    END LOOP;
    DEBUG.PR_DEBUG('GI', 'End of function fn_WriteLogToFile ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('!!! Exception in fn_WriteLogToFile - ' || SQLERRM);
      RETURN FALSE;
  END FN_WRITELOGTOFILE;

  FUNCTION ISVALIDFILEFORPROCESS(P_PHYFNAME  IN VARCHAR2,
                                 P_FILE_NAME IN VARCHAR2,
                                 P_FILE_MASK IN GITM_INTERFACE_DEFINITION.INCOMING_FILE_MASK%TYPE)
    RETURN BOOLEAN

   AS
    L_FILE_NAME    VARCHAR2(50);
    L_REM_FIL_NAME VARCHAR2(50);
    L_FILE_TYPE    VARCHAR2(50);
    L_PHY_NAME     VARCHAR2(50);
    FUNCTION IS_NUMBER(N VARCHAR2) RETURN BOOLEAN IS
      L_NUM VARCHAR2(1);
      L_POS NUMBER := 1;
    BEGIN
      DBG('Checking ' || N || ' is a numberic or not');
      L_NUM := SUBSTR(N, L_POS, 1);
      WHILE (L_NUM IS NOT NULL) LOOP
        IF ASCII(L_NUM) < 48 OR ASCII(L_NUM) > 57 THEN
          DBG(N || ' is Not a Numeric');
          RETURN FALSE;
        END IF;
        L_POS := L_POS + 1;
        L_NUM := SUBSTR(N, L_POS, 1);
      END LOOP;
      DBG(N || ' is NUMBERIC');
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Others Exception : ' || SQLERRM);
        RETURN FALSE;
    END IS_NUMBER;
  BEGIN
    DBG('Start of function IsValidFileForProcess...');
    DBG('p_PhyFname --> : ' || P_PHYFNAME);
    DBG('p_file_name --> : ' || P_FILE_NAME);
    DBG('p_file_mask --> : ' || P_FILE_MASK);

    IF P_FILE_MASK = 'ALL' THEN
      IF P_PHYFNAME IS NOT NULL THEN
        DBG('Returning success from is valid file for process as mask is ALL');
        RETURN TRUE;
      ELSE
        DBG('NO FILES PRESENT IN THE FOLDER');
        RETURN FALSE;
      END IF;
    END IF;

   IF P_FILE_MASK = 'EFN' THEN
    IF P_PHYFNAME = P_FILE_NAME THEN
		DBG('file type and physical file name are same. So Return True.');
        RETURN TRUE;
      ELSE
        DBG('file type and physical file name are NOT same. So Return False.');
        RETURN FALSE;
      END IF;
    END IF;
    L_FILE_TYPE := SUBSTR(P_FILE_NAME, 1, INSTR(P_FILE_NAME, '.') - 1);
    L_FILE_NAME := SUBSTR(P_PHYFNAME, 1, LENGTH(L_FILE_TYPE));
    DBG('l_fil_name --> : ' || L_FILE_NAME);
    IF L_FILE_NAME <> L_FILE_TYPE OR L_FILE_NAME IS NULL THEN
      DBG('Physical file name not matched with the filter file type');
      RETURN FALSE;
    ELSE
      DBG('Physical file name is matched with the filter file type');
      IF P_FILE_MASK = 'SWF' THEN

        DBG('p_file_mask is ALL, So starting with file type is True');
        RETURN TRUE;
      ELSE
        L_PHY_NAME     := SUBSTR(P_PHYFNAME, 1, INSTR(P_PHYFNAME, '.') - 1);
        L_REM_FIL_NAME := SUBSTR(L_PHY_NAME, LENGTH(L_FILE_TYPE) + 2);
        DBG('l_rem_fil_name --> : ' || L_REM_FIL_NAME);
        IF P_FILE_MASK = 'YMD' THEN

          DBG('length(l_rem_fil_name) --> : ' || LENGTH(L_REM_FIL_NAME));
          IF LENGTH(L_REM_FIL_NAME) = 14 THEN
            IF IS_NUMBER(L_REM_FIL_NAME) THEN
              DBG('All digits are number, So return True');
              RETURN TRUE;
            ELSE
              DBG('Not number, So return False');
              RETURN FALSE;
            END IF;
          ELSE
            DBG('Length of remaining file name part not matched with required length, RETURN False');
            RETURN FALSE;
          END IF;
        ELSIF P_FILE_MASK = 'NNN' THEN
          IF LENGTH(L_REM_FIL_NAME) = 3 THEN
            IF IS_NUMBER(L_REM_FIL_NAME) THEN
              DBG('All digits are number, So return True');

              RETURN TRUE;
            ELSE
              DBG('Not number, So return False');
              RETURN FALSE;
            END IF;
          ELSE
            DBG('Length of remaining file name part not matched with required length, RETURN False');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('End of function IsValidFileForProcess...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in function IsValidFileForProcess...' || SQLERRM);
      RETURN FALSE;
  END ISVALIDFILEFORPROCESS;

  PROCEDURE PR_RUN_PARALLEL_JOB(D_SQL          VARCHAR2,
                                L_JOB_NO       NUMBER,
                                I              NUMBER,
                                FILE_NAME      VARCHAR2,
                                INTERFACE_CODE VARCHAR2,
                                P_SERIAL       NUMBER,
                                P_ERR_CODE     VARCHAR2,
                                P_ERR_PARAMS   VARCHAR2) IS

    P_USER         VARCHAR2(100);
    P_BRANCH       VARCHAR2(100);
    L_PROGRAM_NAME VARCHAR2(100);
    L_JOB_NAME     VARCHAR2(100);

  BEGIN

    P_USER   := GLOBAL.USER_ID;
    P_BRANCH := GLOBAL.CURRENT_BRANCH;

    DEBUG.PR_DEBUG('GI', '##In pr_run_parallel_jobs12');
    DEBUG.PR_DEBUG('GI', '##p_user' || P_USER);
    DEBUG.PR_DEBUG('GI', '##p_branch' || P_BRANCH);

    L_PROGRAM_NAME := 'GIProg' || L_JOB_NO;
    L_JOB_NAME     := 'GIP' || L_JOB_NO;

    DBMS_SCHEDULER.CREATE_JOB(JOB_NAME        => 'GIP' || L_JOB_NO,
                              JOB_TYPE        => 'PLSQL_BLOCK',
                              JOB_ACTION      => D_SQL,
                              START_DATE      => SYSTIMESTAMP,
                              REPEAT_INTERVAL => NULL,
                              ENABLED         => TRUE,
                              COMMENTS        => 'GI parallel Jobs');

    DEBUG.PR_DEBUG('GI', '## Job created with number...' || L_JOB_NO);
    INSERT INTO GITB_JOBS
      (FILE_LOG_SERIAL,
       INTERFACE_CODE,
       FILE_NAME,
       PROCESS_NO,
       TASK,
       TASK_STATUS,

       RUN_DATE,
       START_TIME,
       END_TIME,
       JOB_ID)
    VALUES
      (P_SERIAL,
       INTERFACE_CODE,
       REPLACE(FILE_NAME, '.', '_'),

       I,
       D_SQL,
       'W',

       GLOBAL.APPLICATION_DATE,
       FN_HOSTDATETIME,
       NULL,
       L_JOB_NO);

    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in RUNNING THE JOB');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      DBG('eRROR..' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_RUN_PARALLEL_JOB;

  FUNCTION FN_UPDATE_INTERFACE_DEFINITION(P_BRANCH_CODE    IN GITM_FORMAT_DEFINITION.BRANCH_CODE%TYPE,
                                          P_INTERFACE_CODE IN GITM_FORMAT_DEFINITION.INTERFACE_CODE%TYPE)
    RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('inside Fn_Update_Interface_Definition');
    UPDATE GITM_INTERFACE_DEFINITION
       SET LAST_RUN_DATE = GLOBAL.APPLICATION_DATE
     WHERE INTERFACE_CODE = P_INTERFACE_CODE
       AND BRANCH_CODE = P_BRANCH_CODE;
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBG('Failed in RUNNING THE JOB');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      DBG('eRROR..' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END FN_UPDATE_INTERFACE_DEFINITION;

  FUNCTION FN_UPDATE_ERR_FILE_LOG(P_SERIAL     IN NUMBER,
                                  P_ERR_CODE   IN VARCHAR2,
                                  P_ERR_PARAMS IN VARCHAR2) RETURN BOOLEAN IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('inside Fn_Update_File_log');

    UPDATE GITB_FILE_LOG
       SET ERROR_CODE   = P_ERR_CODE,
           ERROR_PARAMS = P_ERR_PARAMS,
           STATUS       = 'E'
     WHERE PROCESS_REF_NO = P_SERIAL;
    COMMIT;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DBG('Failed in Fn_Update_File_log');
      DEBUG.PR_DEBUG('GI', SQLERRM);
      DBG('ERROR..' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END FN_UPDATE_ERR_FILE_LOG;
END GIPKS_INTERFACE_TRIGGER;
