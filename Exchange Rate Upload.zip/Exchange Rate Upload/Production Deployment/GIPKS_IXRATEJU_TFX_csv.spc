CREATE OR REPLACE PACKAGE GIPKS_IXRATEJU_TFX_csv IS

  ---- Author  : SYSTEM 
  -- Created :  10-FEB-23
  -- Purpose :  Dynamically Generated package to handle Incoming File - TFX_csv

  TYPE ty_GITE_IXRATEJUTFX_csv1 IS TABLE OF GITE_IXRATEJUTFX_csv1%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE ty_GITE_IXRATEJUTFX_csv2 IS TABLE OF GITE_IXRATEJUTFX_csv2%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE ty_GITE_IXRATEJUTFX_csv3 IS TABLE OF GITE_IXRATEJUTFX_csv3%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE ty_GITE_IXRATEJUTFX_csv4 IS TABLE OF GITE_IXRATEJUTFX_csv4%ROWTYPE INDEX BY BINARY_INTEGER;

  function fn_process_file(p_interface_code IN VARCHAR2,
                           p_file_name      IN VARCHAR2,
                           p_Phy_file_name  IN VARCHAR2,
                           p_ProcessRefNo   IN VARCHAR2,
                           p_err_code       IN OUT VARCHAR2,
                           p_err_params     IN OUT VARCHAR2,
                           p_status         IN OUT VARCHAR2) return BOOLEAN;

  function fn_upload(p_interface_code IN VARCHAR2,
                     p_file_name      IN VARCHAR2,
                     p_Phy_file_name  IN VARCHAR2,
                     p_ProcessRefNo   IN VARCHAR2,
                     p_process_no     IN NUMBER,
                     p_err_code       IN OUT VARCHAR2,
                     p_error_params   IN OUT VARCHAR2,
                     p_status         IN OUT VARCHAR2) return BOOLEAN;
end GIPKS_IXRATEJU_TFX_csv;
