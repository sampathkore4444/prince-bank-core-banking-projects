insert into gitm_file_names (INTERFACE_CODE, FILE_NAME)
values ('IXRATEJU', 'TFX.csv');

COMMIT;
