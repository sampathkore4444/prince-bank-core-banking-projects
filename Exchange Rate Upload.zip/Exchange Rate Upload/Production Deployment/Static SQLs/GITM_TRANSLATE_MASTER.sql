insert into GITM_TRANSLATE_MASTER (TNAME, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO)
values ('EXCH', 'O', 'A', 'Y', 'SAMPATH2', to_date('27-01-2023', 'dd-mm-yyyy'), 'SAMPATH2', to_date('27-01-2023', 'dd-mm-yyyy'), 1);

COMMIT;
