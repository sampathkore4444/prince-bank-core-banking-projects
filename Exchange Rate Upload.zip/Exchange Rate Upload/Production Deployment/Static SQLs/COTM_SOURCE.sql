insert into COTM_SOURCE (SOURCE_CODE, SOURCE_DESC, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, BASE_DATA_FROM_FC, SYS_AUTH_REQ)
values ('EXTSYS', 'External System', 'O', 'A', 'Y', 1, 'SAMPATH2', to_date('06-08-2022 10:06:00', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH1', to_date('06-08-2022 10:06:16', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'N');

COMMIT;
