--Create a Program
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM (
program_name      => 'PROG_PROCESS_SWIFT_IN_PAYMENTS',
program_action    => 'IFPKS_SWIFT_INCOMING_UTILS.PR_INIT_MSG',
program_type      => 'STORED_PROCEDURE');
END;
/
--SELECT * FROM dba_scheduler_programs WHERE owner = 'P1OBPRFM';
--Create a scheduler
BEGIN
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCH_EVERY5MIN_SWIFT_IN_PAYMENTS',
 start_date    => TRUNC(SYSDATE, 'HH'),
 repeat_interval  => 'FREQ=DAILY;BYHOUR=7,8,9,10,11,12,13,14,15,16,17,18,19,20,21;BYMINUTE=0,5,10,15,20,25,30,35,40,45,50,55',
 comments     => 'For Every 5 Minutes between 8 AM to 10:55 PM');
END;
/
--SELECT * FROM dba_scheduler_schedules WHERE owner = 'P1OBPRFM';
--Create a job
BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_PROCESS_SWIFT_IN_PAYMENTS',
  program_name   => 'PROG_PROCESS_SWIFT_IN_PAYMENTS',
  schedule_name   => 'SCH_EVERY5MIN_SWIFT_IN_PAYMENTS',
  enabled            =>  true);
END;
/
--SELECT * FROM dba_scheduler_jobs WHERE owner = 'P1OBPRFM'