CREATE OR REPLACE PACKAGE IFPKS_SWIFT_INCOMING_UTILS AS

  G_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
  G_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
  G_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;

  PROCEDURE PR_INIT_MSG;

  PROCEDURE PR_SWIFT_TXN_INC_HANDOFF(P_REQ_MSG   IN CLOB, --P_REQ_MSG   IN XMLTYPE, --Fix for & ampersand Issue Changes
                                     P_FILE_NAME IN VARCHAR2);

  g_cstb_params CSTB_PARAM_CUSTOM%ROWTYPE;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME VARCHAR2);

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2);

  PROCEDURE PR_INSERT_SWIFT_TRACKER(P_tag_1     IN VARCHAR2,
                                    P_tag_2     IN VARCHAR2,
                                    P_tag_3     IN VARCHAR2,
                                    P_tag_4_20  IN VARCHAR2,
                                    P_tag_4_23b IN VARCHAR2,
                                    P_tag_4_32a IN VARCHAR2,
                                    P_tag_4_50k IN VARCHAR2,
                                    P_tag_4_52a IN VARCHAR2,
                                    P_tag_4_53a IN VARCHAR2,
                                    P_tag_4_54a IN VARCHAR2,
                                    P_tag_4_59  IN VARCHAR2,
                                    P_tag_4_70  IN VARCHAR2,
                                    P_tag_4_71a IN VARCHAR2,
                                    P_tag_5     IN VARCHAR2,
                                    P_file_name IN VARCHAR2,
                                    P_time_in   IN VARCHAR2,
                                    P_swift_msg IN CLOB,
                                    P_file_date IN DATE,
                                    P_status    IN CHAR DEFAULT 'U');

  PROCEDURE PR_SWIFT_UPLOAD(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2);

  PROCEDURE PR_PROCESS_SWIFT_TXN(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2);

  PROCEDURE PR_PROCESS_SWIFT_INC_TXN;

END IFPKS_SWIFT_INCOMING_UTILS;
