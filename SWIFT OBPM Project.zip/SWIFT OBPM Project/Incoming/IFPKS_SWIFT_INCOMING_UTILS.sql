CREATE OR REPLACE PACKAGE BODY IFPKS_SWIFT_INCOMING_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_SWIFT_INCOMING_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  FUNCTION FN_GET_PAYMENT_REQ_FORMAT RETURN CLOB IS
  
    L_XML CLOB;
  
  BEGIN
  
    L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETRANSACTION_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>DIGIBANK</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:MSGID></fcub:MSGID>
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>DIGIUSER1</fcub:USERID>
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>' || GLOBAL.current_branch ||
             '</fcub:BRANCH>
            <fcub:MODULEID></fcub:MODULEID>
            <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
            <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Transaction-Details>
               <fcub:XREF></fcub:XREF>
               <fcub:FCCREF></fcub:FCCREF>
               <fcub:PRD>SITT</fcub:PRD>
               <fcub:ESN></fcub:ESN>
               <fcub:EVNTCD></fcub:EVNTCD>
               <fcub:BRN>BRN</fcub:BRN>
               <fcub:MODULE></fcub:MODULE>
               <fcub:TXNBRN>BRN</fcub:TXNBRN>
               <fcub:TXNACC>$L_CUST_CRAC_NO</fcub:TXNACC>
               <fcub:TXNCCY>$L_CUST_CRAC_CCY</fcub:TXNCCY>
               <fcub:TXNAMT>$L_TXN_AMT</fcub:TXNAMT>
               <fcub:TXNTRN></fcub:TXNTRN>
               <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
               <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
               <fcub:OFFSETBRN>991</fcub:OFFSETBRN>
               <fcub:OFFSETACC>$L_SETTLEMENT_ACC</fcub:OFFSETACC>
               <fcub:OFFSETCCY>$L_SETTLEMENT_CCY</fcub:OFFSETCCY>
               <fcub:OFFSETAMT>$L_OFFSET_AMT</fcub:OFFSETAMT>
               <fcub:OFFSETTRN></fcub:OFFSETTRN>
               <fcub:XRATE>$L_EXCH_RATE</fcub:XRATE>
               <fcub:SDBREFNO></fcub:SDBREFNO>


            </fcub:Transaction-Details>
         </fcub:FCUBS_BODY>
      </fcub:CREATETRANSACTION_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
  
    RETURN L_XML;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PAYMENT_REQ_FORMAT');
      DBG('ERROR CODE IN FN_GET_PAYMENT_REQ_FORMAT=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_PAYMENT_REQ_FORMAT=' || SQLERRM);
    
  END FN_GET_PAYMENT_REQ_FORMAT;

  FUNCTION FN_GET_RELATED_REF_NO
    RETURN IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE AS
  
    l_serial_no      VARCHAR2(16);
    L_RELATED_REF_NO IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE;
    p_Err_Code       VARCHAR2(16);
  
  BEGIN
  
    IF NOT trpks_core.fn_get_product_refno(GLOBAL.current_branch,
                                           'OBPM',
                                           GLOBAL.application_date,
                                           l_serial_no,
                                           L_RELATED_REF_NO,
                                           p_err_code) THEN
      dbg('Failed in generation Transaction Ref No');
      RETURN L_RELATED_REF_NO;
    ELSE
      dbg('L_RELATED_REF_NO=' || L_RELATED_REF_NO);
    
      RETURN L_RELATED_REF_NO;
    
    END IF;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_GET_RELATED_REF_NO');
      DBG('ERROR CODE IN FN_GET_RELATED_REF_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_RELATED_REF_NO=' || SQLERRM);
    
      RETURN L_RELATED_REF_NO;
    
  END FN_GET_RELATED_REF_NO;

  /*FUNCTION FN_GET_PAYER_BANK_NAME(P_PAYER_BIC_CODE IN VARCHAR2)
      RETURN IFTB_CROSS_BORDER_MASTER.PAYER_BANK_NAME%TYPE AS
    
      L_PAYER_BANK_NAME IFTB_CROSS_BORDER_MASTER.PAYER_BANK_NAME%TYPE;
    
    BEGIN
    
      SELECT A.BANK_NAME
        INTO L_PAYER_BANK_NAME
        FROM IFTB_SWIFT_PARTICIPANTS A
       WHERE A.EXTERNAL_CODE = P_PAYER_BIC_CODE;
    
      RETURN L_PAYER_BANK_NAME;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN FN_GET_PAYER_BANK_NAME');
        DBG('ERROR CODE IN FN_GET_PAYER_BANK_NAME=' || SQLCODE);
        DBG('ERROR MESSAGE IN FN_GET_PAYER_BANK_NAME=' || SQLERRM);
        L_PAYER_BANK_NAME := NULL;
        RETURN L_PAYER_BANK_NAME;
    END FN_GET_PAYER_BANK_NAME;
  */

  PROCEDURE PR_GET_ONLINE_EXCHANGE_RATES(P_CCY1      IN VARCHAR2,
                                         P_CCY2      IN VARCHAR2,
                                         P_MID_RATE  OUT VARCHAR2,
                                         P_BUY_RATE  OUT VARCHAR2,
                                         P_SELL_RATE OUT VARCHAR2) AS
  
    L_XML               VARCHAR2(32767);
    L_RESPONSE          VARCHAR2(32767) := '';
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
    L_EXCH_RATE IFTB_CROSS_BORDER_MASTER.EXCH_RATE%TYPE;
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
  
  BEGIN
  
    L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSCcyService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:QUERYCYDRATEE_IOFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>DIGIBANK</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:USERID>DIGIUSER1</fcub:USERID>
            <fcub:BRANCH>001</fcub:BRANCH>
            <fcub:SERVICE>FCUBSCcyService</fcub:SERVICE>
            <fcub:OPERATION>QueryCYDRATEE</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Ccy-Rate-Master-IO>
               <fcub:CCY1>USD</fcub:CCY1>
               <fcub:CCY2>KHR</fcub:CCY2>
            </fcub:Ccy-Rate-Master-IO>
         </fcub:FCUBS_BODY>
      </fcub:QUERYCYDRATEE_IOFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
  
    L_RESPONSE := process_http('http://10.80.80.109:8001/' ||
                               'FCUBSCcyService/FCUBSCcyService',
                               L_XML,
                               'text/xml;charset=utf-8');
  
    DBG('L_RESPONSE OF EXCHANGE RATES=' || L_RESPONSE);
  
    PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
  
    DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
  
    --Check if returned error or success
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                    .GETSTRINGVAL;
  
    IF L_STATUS_MSG <> 'SUCCESS' THEN
    
      L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                      .GETSTRINGVAL;
    
      Pr_Log_Error('IFDCBDFT', 'FLEXCUBE', 'IF-NCS001', L_ERROR_DESC); --pls put the error code
    
    ELSE
    
      --Get list of rates
    
      BEGIN
        WITH t(xml) AS
         (SELECT xmltype(L_FORMATTED_RES_MSG) FROM DUAL)
        SELECT x.*
          BULK COLLECT
          INTO L_EXCHANGE_RATES_LIST
          FROM t,
               xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                      "nq1"),
                        '/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details'
                        passing t.xml columns RATE_TYPE varchar2(50) PATH
                        'RATETYPE',
                        MID_RATE varchar2(50) PATH 'MIDRATE',
                        BUY_RATE VARCHAR2(50) PATH 'BUYRATE',
                        SALE_RATE VARCHAR2(50) PATH 'SALERATE') x;
      
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF',
                         'ERROR CODE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLCODE);
          DEBUG.PR_DEBUG('IF',
                         'ERROR MESSAGE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLERRM);
      END;
      Debug.Pr_Debug('IF', 'COUNT=' || L_EXCHANGE_RATES_LIST.COUNT);
    
      DBG('L_EXCHANGE_RATES_LIST.RATE_TYPE=' || L_EXCHANGE_RATES_LIST(1)
          .RATE_TYPE);
      DBG('L_EXCHANGE_RATES_LIST.BUY_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .BUY_RATE);
      DBG('L_EXCHANGE_RATES_LIST.MID_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .MID_RATE);
      DBG('L_EXCHANGE_RATES_LIST.SALE_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .SALE_RATE);
    
      IF L_EXCHANGE_RATES_LIST.COUNT > 0 THEN
      
        BEGIN
          FOR K IN 1 .. L_EXCHANGE_RATES_LIST.COUNT LOOP
            Debug.Pr_Debug('IF',
                           'RATE_TYPE=' || L_EXCHANGE_RATES_LIST(K)
                           .RATE_TYPE || ' ' || 'MID RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .MID_RATE || ' ' || 'BUY RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .BUY_RATE || ' ' || 'SALE RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .SALE_RATE);
          
            IF L_EXCHANGE_RATES_LIST(K).RATE_TYPE = 'COMM' THEN
            
              L_MID_RATE  := L_EXCHANGE_RATES_LIST(K).MID_RATE;
              L_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
              G_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
              L_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
              G_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
            
            END IF;
          
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
      END IF;
    
      DBG('L_MID_RATE=' || L_MID_RATE);
    
      DBG('L_BUY_RATE=' || L_BUY_RATE);
    
      DBG('L_SALE_RATE=' || L_SALE_RATE);
    
      P_MID_RATE  := L_MID_RATE;
      P_BUY_RATE  := L_BUY_RATE;
      P_SELL_RATE := L_SALE_RATE;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GET_ONLINE_EXCHANGE_RATES');
      DBG('ERROR CODE IN PR_GET_ONLINE_EXCHANGE_RATES=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GET_ONLINE_EXCHANGE_RATES=' || SQLCODE);
  END PR_GET_ONLINE_EXCHANGE_RATES;

  PROCEDURE PR_INSERT_SWIFT_TXN_MASTER(P_branch_code         IN IFTB_CROSS_BORDER_MASTER.BRANCH_CODE%TYPE,
                                       P_msg_flow            IN IFTB_CROSS_BORDER_MASTER.MSG_FLOW%TYPE,
                                       P_trn_ref_no          IN IFTB_CROSS_BORDER_MASTER.TRN_REF_NO%TYPE,
                                       P_related_ref_no      IN IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE,
                                       P_transfer_date       IN IFTB_CROSS_BORDER_MASTER.TRANSFER_DATE%TYPE,
                                       P_txn_ccy             IN IFTB_CROSS_BORDER_MASTER.TXN_CCY%TYPE,
                                       P_txn_amt             IN IFTB_CROSS_BORDER_MASTER.TXN_AMT%TYPE,
                                       P_tot_chg_amt         IN IFTB_CROSS_BORDER_MASTER.TOT_CHG_AMT%TYPE,
                                       P_net_txn_amt         IN IFTB_CROSS_BORDER_MASTER.NET_TXN_AMT%TYPE,
                                       P_exch_rate           IN IFTB_CROSS_BORDER_MASTER.EXCH_RATE%TYPE,
                                       P_rem_acc             IN IFTB_CROSS_BORDER_MASTER.REM_ACC%TYPE,
                                       P_REM_ACC_BRN         IN IFTB_CROSS_BORDER_MASTER.REM_ACC_BRANCH%TYPE,
                                       P_rem_name            IN IFTB_CROSS_BORDER_MASTER.REM_NAME%TYPE,
                                       P_dr_acc_ccy          IN IFTB_CROSS_BORDER_MASTER.DR_ACC_CCY%TYPE,
                                       P_dr_amount           IN IFTB_CROSS_BORDER_MASTER.DR_AMOUNT%TYPE,
                                       P_ben_acc             IN IFTB_CROSS_BORDER_MASTER.BEN_ACC%TYPE,
                                       P_ben_bic             IN IFTB_CROSS_BORDER_MASTER.BEN_BIC%TYPE,
                                       P_ben_name            IN IFTB_CROSS_BORDER_MASTER.BEN_NAME%TYPE,
                                       P_ben_add1            IN IFTB_CROSS_BORDER_MASTER.BEN_ADD1%TYPE,
                                       P_ben_add2            IN IFTB_CROSS_BORDER_MASTER.BEN_ADD2%TYPE,
                                       P_ben_add3            IN IFTB_CROSS_BORDER_MASTER.BEN_ADD3%TYPE,
                                       P_ben_add4            IN IFTB_CROSS_BORDER_MASTER.BEN_ADD4%TYPE,
                                       P_bank_name           IN IFTB_CROSS_BORDER_MASTER.BANK_NAME%TYPE,
                                       P_maker_id            IN IFTB_CROSS_BORDER_MASTER.MAKER_ID%TYPE,
                                       P_maker_dt_stamp      IN IFTB_CROSS_BORDER_MASTER.MAKER_DT_STAMP%TYPE,
                                       P_checker_id          IN IFTB_CROSS_BORDER_MASTER.CHECKER_ID%TYPE,
                                       P_checker_dt_stamp    IN IFTB_CROSS_BORDER_MASTER.CHECKER_DT_STAMP%TYPE,
                                       P_auth_stat           IN IFTB_CROSS_BORDER_MASTER.AUTH_STAT%TYPE,
                                       P_record_stat         IN IFTB_CROSS_BORDER_MASTER.RECORD_STAT%TYPE,
                                       P_once_auth           IN IFTB_CROSS_BORDER_MASTER.ONCE_AUTH%TYPE,
                                       P_mod_no              IN IFTB_CROSS_BORDER_MASTER.MOD_NO%TYPE,
                                       P_purpose_of_trf      IN IFTB_CROSS_BORDER_MASTER.PURPOSE_OF_TRF%TYPE,
                                       p_requestors_branch   IN IFTB_CROSS_BORDER_MASTER.REQUESTOR_BRANCH%type,
                                       P_WAIVE_FLAG          IN IFTB_CROSS_BORDER_MASTER.WAIVE_CHG1%type,
                                       P_INC_TXN_STATUS      IN IFTB_CROSS_BORDER_MASTER.INC_TXN_STATUS%TYPE,
                                       P_INC_TXN_FAIL_REASON IN IFTB_CROSS_BORDER_MASTER.INC_TXN_FAIL_REASON%TYPE,
                                       P_PAYER_BIC_CODE      IN IFTB_CROSS_BORDER_MASTER.OTHER_BANK_BEN_BIC%TYPE,
                                       P_PAYER_BANK_NAME     IN IFTB_CROSS_BORDER_MASTER.INTERMEDIATORY_BANK_NAME%TYPE,
                                       P_BATCH_NO            IN IFTB_CROSS_BORDER_MASTER.BATCH_NO%TYPE) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_SWIFT_TXN_MASTER');
  
    INSERT INTO IFTB_CROSS_BORDER_MASTER
    VALUES
      (P_branch_code,
       P_msg_flow,
       P_trn_ref_no,
       P_related_ref_no,
       P_transfer_date,
       P_txn_ccy,
       P_txn_amt,
       P_tot_chg_amt,
       P_net_txn_amt,
       P_exch_rate,
       P_rem_acc,
       P_rem_name,
       P_dr_acc_ccy,
       P_dr_amount,
       P_ben_acc,
       P_ben_bic,
       P_ben_name,
       P_ben_add1,
       P_ben_add2,
       P_ben_add3,
       P_ben_add4,
       P_bank_name,
       P_maker_id,
       P_maker_dt_stamp,
       P_checker_id,
       P_checker_dt_stamp,
       P_auth_stat,
       P_record_stat,
       P_once_auth,
       P_mod_no,
       P_purpose_of_trf,
       p_requestors_branch,
       NULL,
       P_INC_TXN_STATUS,
       P_INC_TXN_FAIL_REASON,
       P_REM_ACC_BRN,
       'C',
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL,
       NULL);
  
    COMMIT;
  
    DBG('END OF PR_INSERT_SWIFT_TXN_MASTER');
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN PR_INSERT_SWIFT_TXN_MASTER');
      DBG('ERROR CODE IN PR_INSERT_SWIFT_TXN_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_SWIFT_TXN_MASTER=' || SQLCODE);
    
  END PR_INSERT_SWIFT_TXN_MASTER;

  PROCEDURE PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(P_TAG_1             IN VARCHAR2,
                                               P_TAG_4_20          IN VARCHAR2,
                                               P_REF_NO            IN VARCHAR2,
                                               P_INVOKE_START_DATE IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG');
  
    INSERT INTO IFTB_SWIFT_UNIQUE_TXN_NO_LOG
      (TAG_1, TAG_4_20, TRN_REF_NO, INVOKE_DATE_START)
    VALUES
      (P_TAG_1, P_TAG_4_20, P_REF_NO, P_INVOKE_START_DATE);
  
    COMMIT;
    DBG('END OF PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG');
      DBG('ERROR CODE IN PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG=' ||
          SQLERRM);
    
  END PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG;

  PROCEDURE PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(P_TAG_1           IN VARCHAR2,
                                               P_TAG_4_20        IN VARCHAR2,
                                               P_REF_NO          IN VARCHAR2,
                                               P_STATUS          IN CHAR,
                                               P_ERR_CODE        IN VARCHAR2,
                                               P_ERR_PARAM       IN VARCHAR2,
                                               P_INVOKE_DATE_END IN DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG');
  
    UPDATE IFTB_SWIFT_UNIQUE_TXN_NO_LOG
       SET STATUS          = P_STATUS,
           TRN_REF_NO      = P_REF_NO,
           ERROR_CODE      = P_ERR_CODE,
           ERROR_PARAM     = P_ERR_PARAM,
           INVOKE_DATE_END = P_INVOKE_DATE_END
     WHERE TAG_1 = P_TAG_1
       AND TAG_4_20 = P_TAG_4_20;
    -- AND TRN_REF_NO = P_REF_NO;
    COMMIT;
    DBG('END OF PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG');
      DBG('ERROR CODE IN PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG=' ||
          SQLERRM);
  END PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG;

  PROCEDURE PR_UPDATE_SWIFT_TRACKER(P_TAG_1    IN VARCHAR2,
                                    P_TAG_4_20 IN VARCHAR2,
                                    P_STATUS   IN CHAR) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_SWIFT_TRACKER');
  
    UPDATE IFTB_SWIFT_MT103_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE TAG_1 = P_TAG_1
       AND TAG_4_20 = P_TAG_4_20;
  
    UPDATE IFTB_SWIFT_MT103_INCOMING_TRACK
       SET STATUS = P_STATUS
     WHERE TAG_1 = P_TAG_1
       AND TAG_4_20 = P_TAG_4_20;
    COMMIT;
    DBG('END OF PR_UPDATE_SWIFT_TRACKER');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_SWIFT_TRACKER');
      DBG('ERROR CODE IN PR_UPDATE_SWIFT_TRACKER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_SWIFT_TRACKER=' || SQLERRM);
  END PR_UPDATE_SWIFT_TRACKER;

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO g_cstb_params
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'SWIFT_PAYMENT_DTLS';
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_cstb_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  /*
    
    DECLARE
  
    L_SWIFT_MSG CLOB := '{1:F01AAAABEBBAXXX1234567890}
  {2:I103ABCDEFFXXXN}
  {3:{108:MT103 0001}}
  {4:
  :20:1234567890123456
  :23B:CRED
  :32A:210515USD9876,54
  :50K:/12345678901234567890
  JOHN DOE
  123 MAIN STREET
  ANYTOWN USA
  :52A:BANKUS33
  :53A:BANKGB2L
  :54A:BANKDEFF
  :59:/12345678901234567890
  JANE DOE
  123 MAIN STREET
  ANYTOWN USA
  :70:TRANSFER
  :71A:OUR
  -}
  {5:{MAC:00000000}{CHK:000000000000}}}';
  
    L_TAG_1_POSITION   VARCHAR2(100);
    L_TAG_1            VARCHAR2(100);
    L_TAG_2_POSITION   VARCHAR2(100);
    L_TAG_2_MSG_TYPE   VARCHAR2(100);
    L_TAG_2_SENDER_BIC VARCHAR2(100);
    L_STARTPOSN        VARCHAR2(100);
    L_ENDPOSN          VARCHAR2(100);
    L_REFERENCE_NO     VARCHAR2(100);
    L_REFERENCE_NO1     VARCHAR2(100);
    L_REFERENCE_NO2     VARCHAR2(100);
    L_REFERENCE_NO3     VARCHAR2(100);
  
  BEGIN
    DBMS_OUTPUT.PUT_LINE(L_SWIFT_MSG);
  
    --Get Tag1 position --{1:F01AAAABEBBAXXX1234567890}
    L_TAG_1_POSITION := INSTR(L_SWIFT_MSG, '{1:');
    L_TAG_1          := SUBSTR(L_SWIFT_MSG,
                               L_TAG_1_POSITION + 3,
                               INSTR(L_SWIFT_MSG, '}') - 4);
  
    DBMS_OUTPUT.put_line('L_TAG_1=' || L_TAG_1);
  
    --Get Tag2 position --{2:I103ABCDEFFXXXN}
    L_TAG_2_POSITION := INSTR(L_SWIFT_MSG, '{2:');
    L_TAG_2_MSG_TYPE := SUBSTR(L_SWIFT_MSG, L_TAG_2_POSITION + 4, 3);
    DBMS_OUTPUT.put_line('L_TAG_2_MSG_TYPE=' || L_TAG_2_MSG_TYPE);
  
    L_TAG_2_SENDER_BIC := SUBSTR(L_SWIFT_MSG, L_TAG_2_POSITION + 7, 11);
    DBMS_OUTPUT.put_line('L_TAG_2_SENDER_BIC=' || L_TAG_2_SENDER_BIC);
  
    --Get Tag4 position --{4:
    --L_TAG_4_POSITION := INSTR(L_SWIFT_MSG, '{4:');
    --L_TAG_4_MSG_TYPE := SUBSTR(L_SWIFT_MSG, L_TAG_4_POSITION + 4, 3);
    --DBMS_OUTPUT.put_line('L_TAG_4_MSG_TYPE=' || L_TAG_4_MSG_TYPE);
  
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '20:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 3);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 3,
                             (L_ENDPOSN - L_STARTPOSN - 4));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO=' || L_REFERENCE_NO);
    
    --23B
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '23B:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO1 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO1=' || L_REFERENCE_NO1);
    
    --:32A:210515USD9876,54
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '32A:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO2 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO2=' || L_REFERENCE_NO2);
    
    --:50K:
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '50K:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO3 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO3=' || L_REFERENCE_NO3);
    
    --:52A:BANKUS33
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '52A:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO3 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO3=' || L_REFERENCE_NO3);
    
    --:53A:BANKGB2L
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '52A:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO3 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO3=' || L_REFERENCE_NO3);
    
    --:54A:BANKDEFF
     L_STARTPOSN    := INSTR(L_SWIFT_MSG, '54A:');
    DBMS_OUTPUT.put_line('L_STARTPOSN=' || L_STARTPOSN);
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    DBMS_OUTPUT.put_line('L_ENDPOSN=' || L_ENDPOSN);
    L_REFERENCE_NO3 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
  
    DBMS_OUTPUT.put_line('L_REFERENCE_NO3=' || L_REFERENCE_NO3);
    
    --59
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '59:');
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 3);
    L_REFERENCE_NO := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 3,
                             (L_ENDPOSN - L_STARTPOSN - 4));
    DBMS_OUTPUT.put_line('L_REFERENCE_NO=' || L_REFERENCE_NO);
    
    --70
    L_STARTPOSN    := INSTR(L_SWIFT_MSG, '70:');
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 3);
    L_REFERENCE_NO := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 3,
                             (L_ENDPOSN - L_STARTPOSN - 4));
    DBMS_OUTPUT.put_line('L_REFERENCE_NO=' || L_REFERENCE_NO);
    
    --71A
     L_STARTPOSN    := INSTR(L_SWIFT_MSG, '71A:');
    L_ENDPOSN      := INSTR(L_SWIFT_MSG, ':', L_STARTPOSN + 4);
    L_REFERENCE_NO3 := SUBSTR(L_SWIFT_MSG,
                             L_STARTPOSN + 4,
                             (L_ENDPOSN - L_STARTPOSN - 5));
     DBMS_OUTPUT.put_line('L_REFERENCE_NO3=' || L_REFERENCE_NO3);
  
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('EXCEPTION');
  END;
  
  
  
  
    */

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_PROCESS_SWIFT_INC_TXN IS
  
    L_COSMETIC_RES_MSG  CLOB;
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
    L_SETTLEMENT_ACC    STTM_CORE_ACCOUNT.CUST_ACCOUNT_NO%TYPE;
    L_CUST_ACC_BRN      STTM_CORE_ACCOUNT.SOURCE_SYSTEM_ACC_BRN%TYPE;
    L_XML               VARCHAR2(32767);
    L_CUST_CRAC_CCY     STTM_CORE_ACCOUNT.CUST_AC_CCY%TYPE;
    L_RESPONSE          VARCHAR2(32767) := '';
    L_STATUS_MSG        VARCHAR2(105);
    L_ERROR_CODE        VARCHAR2(255);
    L_ERROR_DESC        VARCHAR2(255);
    L_TRN_REF_NO        IFTB_CROSS_BORDER_MASTER.TRN_REF_NO%TYPE;
    L_AMOUNT_CREDITED   PMTB_ACCOUNTING_DETAIL.AMOUNT%TYPE;
    L_TXN_AMOUNT        PMTB_ACCOUNTING_DETAIL.AMOUNT%TYPE;
    L_TXN_CCY           CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_EXCH_RATE         NUMBER(24, 12);
  
    L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
  
    L_BENEF_NAME          IFTB_CROSS_BORDER_MASTER.BEN_NAME%TYPE;
    L_SETTLEMENT_ACC_NAME IFTB_CROSS_BORDER_MASTER.REM_NAME%TYPE;
    L_BENEF_ADDR_1        IFTB_CROSS_BORDER_MASTER.BEN_ADD1%TYPE;
    L_BENEF_ADDR_2        IFTB_CROSS_BORDER_MASTER.BEN_ADD2%TYPE;
    L_BENEF_ADDR_3        IFTB_CROSS_BORDER_MASTER.BEN_ADD3%TYPE;
    L_BENEF_ADDR_4        IFTB_CROSS_BORDER_MASTER.BEN_ADD4%TYPE;
    L_RELATED_REF_NO      IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE;
  
    L_STTM_CORE_ACCOUNT STTM_CORE_ACCOUNT%ROWTYPE;
    L_COUNT             NUMBER := 0;
    L_NAME_MATCH_FLAG   BOOLEAN := FALSE;
    L_BEN_ACCOUNT       STTM_CORE_ACCOUNT.CUST_ACCOUNT_NO%TYPE;
  
    CURSOR C1 IS
      SELECT *
        FROM IFTB_SWIFT_MT103_INCOMING_TRACK A
       WHERE A.STATUS IN ('U')
         AND A.TAG_1 NOT IN
             (SELECT B.TAG_1 FROM IFTB_SWIFT_UNIQUE_TXN_NO_LOG B);
  
  BEGIN
  
    GLOBAL.PR_INIT('993', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_SWIFT_INC_TXN');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        --GLOBAL.pr_init('000', 'SYSTEM');
      
        SAVEPOINT A;
      
        L_TXN_CCY := SUBSTR(G.TAG_4_32A, 7, 3);
      
        DBG('L_TXN_CCY=' || L_TXN_CCY);
      
        IF L_TXN_CCY = 'USD' THEN
        
          BEGIN
          
            SELECT A.PARAM_VAL
              INTO L_SETTLEMENT_ACC
              FROM CSTB_PARAM_CUSTOM A
             WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_USD';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_SETTLEMENT_ACC := '000207985';
          END;
        
          L_SETTLEMENT_ACC_NAME := 'Kasikorn USD-099 9222528';
        
        ELSIF L_TXN_CCY = 'EUR' THEN
        
          BEGIN
          
            SELECT A.PARAM_VAL
              INTO L_SETTLEMENT_ACC
              FROM CSTB_PARAM_CUSTOM A
             WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_EUR';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_SETTLEMENT_ACC := '000208738';
          END;
        
          L_SETTLEMENT_ACC_NAME := 'Kasikorn EUR-099 9222536';
        
        ELSIF L_TXN_CCY = 'THB' THEN
        
          BEGIN
          
            SELECT A.PARAM_VAL
              INTO L_SETTLEMENT_ACC
              FROM CSTB_PARAM_CUSTOM A
             WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_THB';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_SETTLEMENT_ACC := '000208740';
          END;
        
          L_SETTLEMENT_ACC_NAME := 'Kasikorn THB-069 8708867';
        
        END IF;
      
        L_XML := FN_GET_PAYMENT_REQ_FORMAT;
      
        L_BEN_ACCOUNT := SUBSTR(G.TAG_4_59, 2, 9);
      
        DBG('L_BEN_ACCOUNT=' || L_BEN_ACCOUNT);
      
        --Get Account details
        BEGIN
          SELECT *
            INTO L_STTM_CORE_ACCOUNT
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = L_BEN_ACCOUNT; --G.TAG_4_50K;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_STTM_CORE_ACCOUNT := NULL;
            DBG('FAILED IN GETTING ACCOUNT DETAILS');
        END;
      
        --Get Count of Beneficiary Account
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = L_BEN_ACCOUNT; --G.TAG_4_50K;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        --Get the beneficiary name
        SELECT SUBSTR(G.TAG_4_50K,
                      --INSTR(G.TAG_4_50K, CHR(10), 1, 1) + 1,
                      --INSTR(G.TAG_4_50K, CHR(10), 1, 2) -
                      --INSTR(G.TAG_4_50K, CHR(10), 1, 1) - 1)
                      
                      INSTR(G.TAG_4_59, CHR(10), 1, 1) + 1,
                      INSTR(G.TAG_4_59, CHR(10), 1, 2) -
                      INSTR(G.TAG_4_59, CHR(10), 1, 1) - 1)
          into L_BENEF_NAME
          FROM dual;
      
        IF UPPER(TRIM(REGEXP_REPLACE(L_STTM_CORE_ACCOUNT.CUST_AC_NAME,
                                     '\s{2,}',
                                     ' '))) <>
           UPPER(TRIM(REGEXP_REPLACE(L_BENEF_NAME, '\s{2,}', ' '))) THEN
        
          L_NAME_MATCH_FLAG := FALSE;
        
        ELSE
        
          L_NAME_MATCH_FLAG := TRUE;
        
        END IF;
      
        IF NOT L_NAME_MATCH_FLAG THEN
        
          DBG('APPLE');
        
          L_ERROR_CODE := 'FT-MTUP100';
        
          L_ERROR_DESC := 'Beneficiary Account Name Mismatch';
        
          PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                             G.TAG_4_20,
                                             NULL,
                                             SYSDATE);
        
          PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
        
          PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                             G.TAG_4_20,
                                             NULL,
                                             'E',
                                             L_ERROR_CODE,
                                             L_ERROR_DESC,
                                             SYSDATE);
        
          L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
        
          PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                     'I',
                                     NULL,
                                     L_RELATED_REF_NO,
                                     GLOBAL.application_date,
                                     L_CUST_CRAC_CCY,
                                     L_AMOUNT_CREDITED,
                                     
                                     0,
                                     L_AMOUNT_CREDITED,
                                     L_EXCH_RATE,
                                     L_SETTLEMENT_ACC,
                                     '991',
                                     L_SETTLEMENT_ACC_NAME,
                                     
                                     L_TXN_CCY,
                                     L_TXN_AMOUNT,
                                     L_BEN_ACCOUNT,
                                     'PINCKHPPXXXX',
                                     L_BENEF_NAME,
                                     L_BENEF_ADDR_1,
                                     L_BENEF_ADDR_2,
                                     L_BENEF_ADDR_3,
                                     L_BENEF_ADDR_4,
                                     'PRINCE BANK PLC',
                                     'SYSTEM',
                                     GLOBAL.application_date,
                                     NULL,
                                     NULL,
                                     'U',
                                     'O',
                                     'N',
                                     1,
                                     NULL,
                                     L_CUST_ACC_BRN,
                                     'N',
                                     'FAILED',
                                     L_ERROR_DESC,
                                     NULL,
                                     NULL,
                                     NULL);
        
          ROLLBACK TO A;
          CONTINUE;
        
        ELSIF L_COUNT = 0 OR L_STTM_CORE_ACCOUNT.RECORD_STAT = 'C' OR
              L_STTM_CORE_ACCOUNT.AC_STAT_FROZEN = 'Y' OR
              L_STTM_CORE_ACCOUNT.AC_STAT_NO_CR = 'Y' OR
              L_STTM_CORE_ACCOUNT.AUTH_STAT = 'U' OR
              L_STTM_CORE_ACCOUNT.AC_STAT_DORMANT = 'Y' THEN
        
          DBG('SOME PROBLEM WITH BENEFICIARY ACCOUNT. HENCE REJECT');
        
          IF L_COUNT = 0 THEN
          
            L_ERROR_CODE := 'FT-MTUP100';
          
            L_ERROR_DESC := 'Beneficiary Account Not Found';
          
            PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               SYSDATE);
          
            PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
          
            PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               'E',
                                               L_ERROR_CODE,
                                               L_ERROR_DESC,
                                               SYSDATE);
          
            L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
            PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                       'I',
                                       NULL,
                                       L_RELATED_REF_NO,
                                       GLOBAL.application_date,
                                       L_CUST_CRAC_CCY,
                                       L_AMOUNT_CREDITED,
                                       
                                       0,
                                       L_AMOUNT_CREDITED,
                                       L_EXCH_RATE,
                                       L_SETTLEMENT_ACC,
                                       '991',
                                       L_SETTLEMENT_ACC_NAME,
                                       
                                       L_TXN_CCY,
                                       L_TXN_AMOUNT,
                                       L_BEN_ACCOUNT,
                                       'PINCKHPPXXXX',
                                       L_BENEF_NAME,
                                       L_BENEF_ADDR_1,
                                       L_BENEF_ADDR_2,
                                       L_BENEF_ADDR_3,
                                       L_BENEF_ADDR_4,
                                       'PRINCE BANK PLC',
                                       'SYSTEM',
                                       GLOBAL.application_date,
                                       NULL,
                                       NULL,
                                       'U',
                                       'O',
                                       'N',
                                       1,
                                       NULL,
                                       L_CUST_ACC_BRN,
                                       'N',
                                       'FAILED',
                                       L_ERROR_DESC,
                                       NULL,
                                       NULL,
                                       NULL);
          
            ROLLBACK TO A;
            CONTINUE;
          
          ELSIF L_STTM_CORE_ACCOUNT.RECORD_STAT = 'C' THEN
          
            L_ERROR_CODE := 'AC-VAC12';
          
            L_ERROR_DESC := 'Beneficiary Account Status Closed';
          
            PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
          
            PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               SYSDATE);
          
            PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               'E',
                                               L_ERROR_CODE,
                                               L_ERROR_DESC,
                                               SYSDATE);
          
            L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
            PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                       'I',
                                       NULL,
                                       L_RELATED_REF_NO,
                                       GLOBAL.application_date,
                                       L_CUST_CRAC_CCY,
                                       L_AMOUNT_CREDITED,
                                       
                                       0,
                                       L_AMOUNT_CREDITED,
                                       L_EXCH_RATE,
                                       L_SETTLEMENT_ACC,
                                       '991',
                                       L_SETTLEMENT_ACC_NAME,
                                       
                                       L_TXN_CCY,
                                       L_TXN_AMOUNT,
                                       L_BEN_ACCOUNT,
                                       'PINCKHPPXXXX',
                                       L_BENEF_NAME,
                                       L_BENEF_ADDR_1,
                                       L_BENEF_ADDR_2,
                                       L_BENEF_ADDR_3,
                                       L_BENEF_ADDR_4,
                                       'PRINCE BANK PLC',
                                       'SYSTEM',
                                       GLOBAL.application_date,
                                       NULL,
                                       NULL,
                                       'U',
                                       'O',
                                       'N',
                                       1,
                                       NULL,
                                       L_CUST_ACC_BRN,
                                       'N',
                                       'FAILED',
                                       L_ERROR_DESC,
                                       NULL,
                                       NULL,
                                       NULL);
          
            ROLLBACK TO A;
            CONTINUE;
          
          ELSIF L_STTM_CORE_ACCOUNT.AC_STAT_FROZEN = 'Y' THEN
          
            L_ERROR_CODE := 'AC-VAC04';
          
            L_ERROR_DESC := 'Beneficiary Account Status Frozen';
          
            PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
          
            PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               SYSDATE);
          
            PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               'E',
                                               L_ERROR_CODE,
                                               L_ERROR_DESC,
                                               SYSDATE);
          
            L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
            PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                       'I',
                                       NULL,
                                       L_RELATED_REF_NO,
                                       GLOBAL.application_date,
                                       L_CUST_CRAC_CCY,
                                       L_AMOUNT_CREDITED,
                                       
                                       0,
                                       L_AMOUNT_CREDITED,
                                       L_EXCH_RATE,
                                       L_SETTLEMENT_ACC,
                                       '991',
                                       L_SETTLEMENT_ACC_NAME,
                                       
                                       L_TXN_CCY,
                                       L_TXN_AMOUNT,
                                       L_BEN_ACCOUNT,
                                       'PINCKHPPXXXX',
                                       L_BENEF_NAME,
                                       L_BENEF_ADDR_1,
                                       L_BENEF_ADDR_2,
                                       L_BENEF_ADDR_3,
                                       L_BENEF_ADDR_4,
                                       'PRINCE BANK PLC',
                                       'SYSTEM',
                                       GLOBAL.application_date,
                                       NULL,
                                       NULL,
                                       'U',
                                       'O',
                                       'N',
                                       1,
                                       NULL,
                                       L_CUST_ACC_BRN,
                                       'N',
                                       'FAILED',
                                       L_ERROR_DESC,
                                       NULL,
                                       NULL,
                                       NULL);
          
            ROLLBACK TO A;
            CONTINUE;
          
          ELSIF L_STTM_CORE_ACCOUNT.AC_STAT_NO_CR = 'Y' THEN
          
            L_ERROR_CODE := 'AC-VAC03';
          
            L_ERROR_DESC := 'Beneficiary Account Status No Credit';
          
            PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
          
            PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               SYSDATE);
          
            PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               'E',
                                               L_ERROR_CODE,
                                               L_ERROR_DESC,
                                               SYSDATE);
          
            L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
            PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                       'I',
                                       NULL,
                                       L_RELATED_REF_NO,
                                       GLOBAL.application_date,
                                       L_CUST_CRAC_CCY,
                                       L_AMOUNT_CREDITED,
                                       
                                       0,
                                       L_AMOUNT_CREDITED,
                                       L_EXCH_RATE,
                                       L_SETTLEMENT_ACC,
                                       '991',
                                       L_SETTLEMENT_ACC_NAME,
                                       
                                       L_TXN_CCY,
                                       L_TXN_AMOUNT,
                                       L_BEN_ACCOUNT,
                                       'PINCKHPPXXXX',
                                       L_BENEF_NAME,
                                       L_BENEF_ADDR_1,
                                       L_BENEF_ADDR_2,
                                       L_BENEF_ADDR_3,
                                       L_BENEF_ADDR_4,
                                       'PRINCE BANK PLC',
                                       'SYSTEM',
                                       GLOBAL.application_date,
                                       NULL,
                                       NULL,
                                       'U',
                                       'O',
                                       'N',
                                       1,
                                       NULL,
                                       L_CUST_ACC_BRN,
                                       'N',
                                       'FAILED',
                                       L_ERROR_DESC,
                                       NULL,
                                       NULL,
                                       NULL);
          
            ROLLBACK TO A;
            CONTINUE;
          
          ELSIF L_STTM_CORE_ACCOUNT.AUTH_STAT = 'U' THEN
          
            L_ERROR_CODE := 'EG-VALS-078';
          
            L_ERROR_DESC := 'Beneficiary Account is in Un-Authorized State';
          
            PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
          
            PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               SYSDATE);
          
            PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                               G.TAG_4_20,
                                               NULL,
                                               'E',
                                               L_ERROR_CODE,
                                               L_ERROR_DESC,
                                               SYSDATE);
          
            L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
          
            PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                       'I',
                                       NULL,
                                       L_RELATED_REF_NO,
                                       GLOBAL.application_date,
                                       L_CUST_CRAC_CCY,
                                       L_AMOUNT_CREDITED,
                                       
                                       0,
                                       L_AMOUNT_CREDITED,
                                       L_EXCH_RATE,
                                       L_SETTLEMENT_ACC,
                                       '991',
                                       L_SETTLEMENT_ACC_NAME,
                                       
                                       L_TXN_CCY,
                                       L_TXN_AMOUNT,
                                       L_BEN_ACCOUNT,
                                       'PINCKHPPXXXX',
                                       L_BENEF_NAME,
                                       L_BENEF_ADDR_1,
                                       L_BENEF_ADDR_2,
                                       L_BENEF_ADDR_3,
                                       L_BENEF_ADDR_4,
                                       'PRINCE BANK PLC',
                                       'SYSTEM',
                                       GLOBAL.application_date,
                                       NULL,
                                       NULL,
                                       'U',
                                       'O',
                                       'N',
                                       1,
                                       NULL,
                                       L_CUST_ACC_BRN,
                                       'N',
                                       'FAILED',
                                       L_ERROR_DESC,
                                       NULL,
                                       NULL,
                                       NULL);
          
            ROLLBACK TO A;
            CONTINUE;
          
          END IF;
        
        END IF;
      
        BEGIN
        
          SELECT A.SOURCE_SYSTEM_ACC_BRN
            INTO L_CUST_ACC_BRN
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = SUBSTR(G.TAG_4_59, 2, 9); --G.TAG_4_50K;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACC_BRN := NULL;
        END;
      
        DBG('L_CUST_ACC_BRN=' || L_CUST_ACC_BRN);
      
        L_XML := REPLACE(L_XML, '$L_CUST_CRAC_NO', L_BEN_ACCOUNT);
      
        BEGIN
        
          SELECT A.CUST_AC_CCY
            INTO L_CUST_CRAC_CCY
            FROM STTM_CORE_ACCOUNT A
           WHERE A.CUST_ACCOUNT_NO = L_BEN_ACCOUNT; --G.TAG_4_50K;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_CRAC_CCY := NULL;
        END;
      
        DBG('L_CUST_CRAC_CCY=' || L_CUST_CRAC_CCY);
      
        L_XML := REPLACE(L_XML, '$L_CUST_CRAC_CCY', L_CUST_CRAC_CCY);
      
        L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);
      
        --Get Transaction Amount
        SELECT REPLACE(SUBSTR(G.TAG_4_32A, 10), ',', '.')
          INTO L_TXN_AMOUNT
          FROM DUAL;
      
        DBG('L_TXN_AMOUNT=' || L_TXN_AMOUNT);
      
        L_XML := REPLACE(L_XML, '$L_OFFSET_AMT', L_TXN_AMOUNT);
      
        --Get Transaction Currency
        SELECT SUBSTR(G.TAG_4_32A, 7, 3) INTO L_TXN_CCY FROM DUAL;
      
        DBG('L_TXN_CCY=' || L_TXN_CCY);
      
        L_XML := REPLACE(L_XML, '$L_SETTLEMENT_CCY', L_TXN_CCY);
      
        IF L_CUST_CRAC_CCY = 'KHR' AND L_TXN_CCY = 'USD' THEN
        
          PR_GET_ONLINE_EXCHANGE_RATES(L_TXN_CCY,
                                       L_CUST_CRAC_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_EXCH_RATE := ROUND(1 * L_SALE_RATE, 2);
        
        ELSIF L_CUST_CRAC_CCY = 'KHR' AND L_TXN_CCY = 'EUR' THEN
        
          PR_GET_ONLINE_EXCHANGE_RATES('USD',
                                       L_TXN_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_EXCH_RATE := ROUND(L_SALE_RATE, 2);
        
        ELSIF L_CUST_CRAC_CCY = 'KHR' AND L_TXN_CCY = 'THB' THEN
        
          PR_GET_ONLINE_EXCHANGE_RATES('USD',
                                       L_TXN_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_EXCH_RATE := ROUND(L_SALE_RATE, 2);
        
        ELSIF L_CUST_CRAC_CCY = 'USD' AND L_TXN_CCY = 'EUR' THEN
        
          PR_GET_ONLINE_EXCHANGE_RATES(L_CUST_CRAC_CCY,
                                       L_TXN_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_EXCH_RATE := L_SALE_RATE;
        
        ELSIF L_CUST_CRAC_CCY = 'USD' AND L_TXN_CCY = 'THB' THEN
        
          PR_GET_ONLINE_EXCHANGE_RATES(L_CUST_CRAC_CCY,
                                       L_TXN_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_EXCH_RATE := L_SALE_RATE;
        
        ELSIF L_CUST_CRAC_CCY = 'USD' AND L_TXN_CCY = 'USD' THEN
        
          L_EXCH_RATE := 1;
        
        END IF;
      
        DBG('Derived Exchange Rate=' || L_EXCH_RATE);
      
        /*IF L_CUST_CRAC_CCY <> L_TXN_CCY THEN
        
          --Get Exchange rate
        
          PR_GET_ONLINE_EXCHANGE_RATES(L_TXN_CCY,
                                       L_CUST_CRAC_CCY,
                                       L_MID_RATE,
                                       L_BUY_RATE,
                                       L_SALE_RATE);
        
          L_XML := REPLACE(L_XML, '$L_EXCH_RATE', L_EXCH_RATE);
        
        ELSE
          L_EXCH_RATE := 1;
          L_XML       := REPLACE(L_XML, '$L_EXCH_RATE', L_EXCH_RATE);
        
        END IF;*/
      
        DBG('Final Request xml=' || L_XML);
      
        PR_INSERT_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                           G.TAG_4_20,
                                           NULL,
                                           SYSDATE);
      
        L_RESPONSE := process_http('http://10.80.80.109:8001/' ||
                                   'FCUBSRTService/FCUBSRTService',
                                   L_XML,
                                   'text/xml;charset=utf-8');
      
        DBG('L_RESPONSE=' || L_RESPONSE);
      
        --Get Cosmetic XML
        PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
      
        DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
      
        P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
      
        --Check if returned error or success
        L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                        .GETSTRINGVAL;
      
        IF L_STATUS_MSG <> 'SUCCESS' THEN
        
          L_ERROR_CODE := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/ECODE/text()')
                          .GETSTRINGVAL;
        
          L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                          .GETSTRINGVAL;
        
          PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'E');
        
          PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                             G.TAG_4_20,
                                             NULL,
                                             'E',
                                             L_ERROR_CODE,
                                             L_ERROR_DESC,
                                             SYSDATE);
        
          L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
        
          PR_INSERT_SWIFT_TXN_MASTER(NULL,
                                     'I',
                                     NULL, --L_TRN_REF_NO,
                                     L_RELATED_REF_NO,
                                     GLOBAL.application_date,
                                     L_CUST_CRAC_CCY,
                                     L_AMOUNT_CREDITED,
                                     
                                     0,
                                     L_AMOUNT_CREDITED,
                                     L_EXCH_RATE,
                                     L_SETTLEMENT_ACC,
                                     '991',
                                     L_SETTLEMENT_ACC_NAME,
                                     
                                     L_TXN_CCY,
                                     L_TXN_AMOUNT,
                                     L_BEN_ACCOUNT,
                                     'PINCKHPPXXXX',
                                     L_BENEF_NAME,
                                     L_BENEF_ADDR_1,
                                     L_BENEF_ADDR_2,
                                     L_BENEF_ADDR_3,
                                     L_BENEF_ADDR_4,
                                     'PRINCE BANK PLC',
                                     'SYSTEM',
                                     GLOBAL.application_date,
                                     NULL, --'SYSTEM',
                                     NULL, --GLOBAL.application_date,
                                     'U',
                                     'O',
                                     'N',
                                     1,
                                     NULL,
                                     L_CUST_ACC_BRN,
                                     'N',
                                     'FAILED',
                                     L_ERROR_DESC,
                                     NULL,
                                     NULL,
                                     NULL);
        
          ROLLBACK TO A;
          CONTINUE;
        
        ELSE
        
          DBG('AFTER ALL ELSE CONDITION');
        
          L_TRN_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                          .GETSTRINGVAL;
        
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        
          L_RELATED_REF_NO := FN_GET_RELATED_REF_NO;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<TXNAMT>') > 0 THEN
          
            L_AMOUNT_CREDITED := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/TXNAMT/text()')
                                 .GETSTRINGVAL;
          
            DBG('L_AMOUNT_CREDITED=' || L_AMOUNT_CREDITED);
          
          END IF;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<BENFNAME>') > 0 THEN
          
            L_BENEF_NAME := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFNAME/text()')
                            .GETSTRINGVAL;
          
            DBG('L_BENEF_NAME=' || L_BENEF_NAME);
          
          END IF;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<BENFADDR1>') > 0 THEN
          
            L_BENEF_ADDR_1 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR1/text()')
                              .GETSTRINGVAL;
          
            DBG('L_BENEF_ADDR_1=' || L_BENEF_ADDR_1);
          
          END IF;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<BENFADDR2>') > 0 THEN
          
            L_BENEF_ADDR_2 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR2/text()')
                              .GETSTRINGVAL;
          
            DBG('L_BENEF_ADDR_2=' || L_BENEF_ADDR_2);
          
          END IF;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<BENFADDR3>') > 0 THEN
          
            L_BENEF_ADDR_3 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR3/text()')
                              .GETSTRINGVAL;
          
            DBG('L_BENEF_ADDR_3=' || L_BENEF_ADDR_3);
          
          END IF;
        
          IF INSTR(L_FORMATTED_RES_MSG, '<BENFADDR4>') > 0 THEN
          
            L_BENEF_ADDR_4 := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/BENFADDR4/text()')
                              .GETSTRINGVAL;
          
            DBG('L_BENEF_ADDR_4=' || L_BENEF_ADDR_4);
          
          END IF;
        
          PR_UPDATE_UNIQUE_TXN_NO_INVOKE_LOG(G.TAG_1,
                                             G.TAG_4_20,
                                             L_TRN_REF_NO,
                                             'P',
                                             NULL,
                                             NULL,
                                             GLOBAL.application_date);
        
          PR_INSERT_SWIFT_TXN_MASTER(SUBSTR(L_TRN_REF_NO, 1, 3),
                                     'I',
                                     L_TRN_REF_NO,
                                     L_RELATED_REF_NO,
                                     GLOBAL.application_date,
                                     L_CUST_CRAC_CCY,
                                     L_AMOUNT_CREDITED,
                                     
                                     0,
                                     L_AMOUNT_CREDITED,
                                     L_EXCH_RATE,
                                     L_SETTLEMENT_ACC,
                                     '991',
                                     L_SETTLEMENT_ACC_NAME,
                                     L_TXN_CCY,
                                     L_TXN_AMOUNT,
                                     L_BEN_ACCOUNT,
                                     'PINCKHPPXXXX',
                                     L_BENEF_NAME,
                                     L_BENEF_ADDR_1,
                                     L_BENEF_ADDR_2,
                                     L_BENEF_ADDR_3,
                                     L_BENEF_ADDR_4,
                                     'PRINCE BANK PLC',
                                     'SYSTEM',
                                     GLOBAL.application_date,
                                     'SYSTEM',
                                     GLOBAL.application_date,
                                     'A',
                                     'O',
                                     'Y',
                                     1,
                                     NULL, --G.PAYEE_REF,
                                     L_CUST_ACC_BRN,
                                     'N',
                                     'SUCCESS',
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL);
        
          PR_UPDATE_SWIFT_TRACKER(G.TAG_1, G.TAG_4_20, 'P');
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PROCESSING CURRENT INCOMING SWIFT TXN=' ||
              G.TAG_1);
          DBG('FAILED IN PROCESSING CURRENT INCOMING SWIFT TXN=' ||
              G.TAG_4_20);
        
          ROLLBACK TO A;
          CONTINUE;
      END;
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_SWIFT_INC_TXN');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE IN PR_PROCESS_SWIFT_INC_TXN=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_SWIFT_INC_TXN=' || SQLERRM);
  END PR_PROCESS_SWIFT_INC_TXN;

  PROCEDURE PR_SWIFT_TXN_INC_HANDOFF(P_REQ_MSG   IN CLOB, --P_REQ_MSG   IN XMLTYPE,  --Fix for & ampersand Issue
                                     P_FILE_NAME IN VARCHAR2) IS
  
    L_RESPONSE              VARCHAR2(32767);
    L_SNIPPET               XMLTYPE;
    L_IX                    BINARY_INTEGER;
    L_TEXT                  CLOB;
    L_START                 NUMBER := 1;
    L_END                   NUMBER := 0;
    L_UNIQUE_TXN_NO_PAYMENT CLOB;
  
    E_UPDATE_ERROR EXCEPTION;
    P_ERR_CODE   VARCHAR2(1000);
    P_ERR_PARAMS VARCHAR2(1000);
    L_SWIFT_MSG  CLOB;
  
    --103
    L_TAG_1_POSITION   VARCHAR2(100);
    L_TAG_1            VARCHAR2(100);
    L_TAG_2_POSITION   VARCHAR2(100);
    L_TAG_2_MSG_TYPE   VARCHAR2(100);
    L_TAG_2_SENDER_BIC VARCHAR2(100);
  
    L_TAG_20_START_POSITION  VARCHAR2(100);
    L_TAG_20_END_POSITION    VARCHAR2(100);
    L_TAG_4_20_REFERENCE     VARCHAR2(100);
    L_TAG_23B_START_POSITION VARCHAR2(100);
    L_TAG_23B_END_POSITION   VARCHAR2(100);
  
    L_TAG_4_23B_REFERENCE    VARCHAR2(100);
    L_TAG_32A_START_POSITION VARCHAR2(100);
  
    L_TAG_32A_END_POSITION VARCHAR2(100);
  
    L_TAG_4_32A_VALUE VARCHAR2(100);
  
    L_TAG_50K_START_POSITION VARCHAR2(100);
  
    L_TAG_50K_END_POSITION VARCHAR2(100);
  
    L_TAG_4_50K_VALUE VARCHAR2(100);
  
    L_TAG_52A_START_POSITION VARCHAR2(100);
  
    L_TAG_52A_END_POSITION VARCHAR2(100);
  
    L_TAG_4_52A_VALUE VARCHAR2(100);
  
    L_TAG_53A_START_POSITION VARCHAR2(100);
    L_TAG_53A_END_POSITION   VARCHAR2(100);
  
    L_TAG_4_53A_VALUE VARCHAR2(100);
  
    L_TAG_54A_START_POSITION VARCHAR2(100);
    L_TAG_54A_END_POSITION   VARCHAR2(100);
  
    L_TAG_4_54A_VALUE VARCHAR2(100);
  
    L_TAG_4_59_START_POSITION VARCHAR2(100);
    L_TAG_4_59_END_POSITION   VARCHAR2(100);
  
    L_TAG_4_59_VALUE VARCHAR2(100);
  
    L_TAG_4_70_START_POSITION VARCHAR2(100);
    L_TAG_4_70_END_POSITION   VARCHAR2(100);
    L_TAG_4_70_VALUE          VARCHAR2(100);
  
    L_TAG_4_71A_START_POSITION VARCHAR2(100);
    L_TAG_4_71A_END_POSITION   VARCHAR2(100);
    L_TAG_4_71A_VALUE          VARCHAR2(100);
  
  BEGIN
  
    DBG('START OF PR_SWIFT_TXN_INC_HANDOFF');
  
    L_SWIFT_MSG := P_REQ_MSG; --.getClobVal(); --fix added
  
    --DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);
  
    --Get Tag1 position --{1:F01AAAABEBBAXXX1234567890}
    L_TAG_1_POSITION := INSTR(L_SWIFT_MSG, '{1:');
    L_TAG_1          := SUBSTR(L_SWIFT_MSG,
                               L_TAG_1_POSITION + 3,
                               INSTR(L_SWIFT_MSG, '}') - 4);
  
    DBMS_OUTPUT.put_line('L_TAG_1=' || L_TAG_1);
  
    --Get Tag2 position --{2:I103ABCDEFFXXXN}
    L_TAG_2_POSITION := INSTR(L_SWIFT_MSG, '{2:');
    L_TAG_2_MSG_TYPE := SUBSTR(L_SWIFT_MSG, L_TAG_2_POSITION + 4, 3);
    DBMS_OUTPUT.put_line('L_TAG_2_MSG_TYPE=' || L_TAG_2_MSG_TYPE);
  
    L_TAG_2_SENDER_BIC := SUBSTR(L_SWIFT_MSG, L_TAG_2_POSITION + 7, 11);
    DBMS_OUTPUT.put_line('L_TAG_2_SENDER_BIC=' || L_TAG_2_SENDER_BIC);
  
    --Get Tag4 position --{4:
    --L_TAG_4_POSITION := INSTR(L_SWIFT_MSG, '{4:');
    --L_TAG_4_MSG_TYPE := SUBSTR(L_SWIFT_MSG, L_TAG_4_POSITION + 4, 3);
    --DBMS_OUTPUT.put_line('L_TAG_4_MSG_TYPE=' || L_TAG_4_MSG_TYPE);
  
    L_TAG_20_START_POSITION := INSTR(L_SWIFT_MSG, '20:');
    DBMS_OUTPUT.put_line('L_TAG_20_START_POSITION=' ||
                         L_TAG_20_START_POSITION);
    L_TAG_20_END_POSITION := INSTR(L_SWIFT_MSG,
                                   ':',
                                   L_TAG_20_START_POSITION + 3);
    DBMS_OUTPUT.put_line('L_TAG_20_END_POSITION=' || L_TAG_20_END_POSITION);
    L_TAG_4_20_REFERENCE := SUBSTR(L_SWIFT_MSG,
                                   L_TAG_20_START_POSITION + 3,
                                   (L_TAG_20_END_POSITION -
                                   L_TAG_20_START_POSITION - 4));
  
    DBMS_OUTPUT.put_line('L_TAG_4_20_REFERENCE=' || L_TAG_4_20_REFERENCE);
  
    --23B
    L_TAG_23B_START_POSITION := INSTR(L_SWIFT_MSG, '23B:');
    DBMS_OUTPUT.put_line('L_TAG_23B_START_POSITION=' ||
                         L_TAG_23B_START_POSITION);
    L_TAG_23B_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_23B_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_23B_END_POSITION=' ||
                         L_TAG_23B_END_POSITION);
    L_TAG_4_23B_REFERENCE := SUBSTR(L_SWIFT_MSG,
                                    L_TAG_23B_START_POSITION + 4,
                                    (L_TAG_23B_END_POSITION -
                                    L_TAG_23B_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_23B_REFERENCE=' || L_TAG_4_23B_REFERENCE);
  
    --:32A:210515USD9876,54
    L_TAG_32A_START_POSITION := INSTR(L_SWIFT_MSG, '32A:');
    DBMS_OUTPUT.put_line('L_TAG_32A_START_POSITION=' ||
                         L_TAG_32A_START_POSITION);
    L_TAG_32A_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_32A_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_32A_END_POSITION=' ||
                         L_TAG_32A_END_POSITION);
    L_TAG_4_32A_VALUE := SUBSTR(L_SWIFT_MSG,
                                L_TAG_32A_START_POSITION + 4,
                                (L_TAG_32A_END_POSITION -
                                L_TAG_32A_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_32A_VALUE=' || L_TAG_4_32A_VALUE);
  
    --:50K:
    L_TAG_50K_START_POSITION := INSTR(L_SWIFT_MSG, '50K:');
    DBMS_OUTPUT.put_line('L_TAG_50K_START_POSITION=' ||
                         L_TAG_50K_START_POSITION);
    L_TAG_50K_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_50K_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_50K_END_POSITION=' ||
                         L_TAG_50K_END_POSITION);
    L_TAG_4_50K_VALUE := SUBSTR(L_SWIFT_MSG,
                                L_TAG_50K_START_POSITION + 4,
                                (L_TAG_50K_END_POSITION -
                                L_TAG_50K_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_50K_VALUE=' || L_TAG_4_50K_VALUE);
  
    --:52A:BANKUS33
    L_TAG_52A_START_POSITION := INSTR(L_SWIFT_MSG, '52A:');
    DBMS_OUTPUT.put_line('L_TAG_52A_START_POSITION=' ||
                         L_TAG_52A_START_POSITION);
    L_TAG_52A_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_52A_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_52A_END_POSITION=' ||
                         L_TAG_52A_END_POSITION);
    L_TAG_4_52A_VALUE := SUBSTR(L_SWIFT_MSG,
                                L_TAG_52A_START_POSITION + 4,
                                (L_TAG_52A_END_POSITION -
                                L_TAG_52A_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_52A_VALUE=' || L_TAG_4_52A_VALUE);
  
    --:53A:BANKGB2L
    L_TAG_53A_START_POSITION := INSTR(L_SWIFT_MSG, '53A:');
    DBMS_OUTPUT.put_line('L_TAG_53A_START_POSITION=' ||
                         L_TAG_53A_START_POSITION);
    L_TAG_53A_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_53A_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_53A_END_POSITION=' ||
                         L_TAG_53A_END_POSITION);
    L_TAG_4_53A_VALUE := SUBSTR(L_SWIFT_MSG,
                                L_TAG_53A_START_POSITION + 4,
                                (L_TAG_53A_END_POSITION -
                                L_TAG_53A_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_53A_VALUE=' || L_TAG_4_53A_VALUE);
  
    --:54A:BANKDEFF
    L_TAG_54A_START_POSITION := INSTR(L_SWIFT_MSG, '54A:');
    DBMS_OUTPUT.put_line('L_TAG_54A_START_POSITION=' ||
                         L_TAG_54A_START_POSITION);
    L_TAG_54A_END_POSITION := INSTR(L_SWIFT_MSG,
                                    ':',
                                    L_TAG_54A_START_POSITION + 4);
    DBMS_OUTPUT.put_line('L_TAG_54A_END_POSITION=' ||
                         L_TAG_54A_END_POSITION);
    L_TAG_4_54A_VALUE := SUBSTR(L_SWIFT_MSG,
                                L_TAG_54A_START_POSITION + 4,
                                (L_TAG_54A_END_POSITION -
                                L_TAG_54A_START_POSITION - 5));
  
    DBMS_OUTPUT.put_line('L_TAG_4_54A_VALUE=' || L_TAG_4_54A_VALUE);
  
    --59
    L_TAG_4_59_START_POSITION := INSTR(L_SWIFT_MSG, '59:');
    L_TAG_4_59_END_POSITION   := INSTR(L_SWIFT_MSG,
                                       ':',
                                       L_TAG_4_59_START_POSITION + 3);
    L_TAG_4_59_VALUE          := SUBSTR(L_SWIFT_MSG,
                                        L_TAG_4_59_START_POSITION + 3,
                                        (L_TAG_4_59_END_POSITION -
                                        L_TAG_4_59_START_POSITION - 4));
    DBMS_OUTPUT.put_line('L_TAG_4_59_VALUE=' || L_TAG_4_59_VALUE);
  
    --70
    L_TAG_4_70_START_POSITION := INSTR(L_SWIFT_MSG, '70:');
    L_TAG_4_70_END_POSITION   := INSTR(L_SWIFT_MSG,
                                       ':',
                                       L_TAG_4_70_START_POSITION + 3);
    L_TAG_4_70_VALUE          := SUBSTR(L_SWIFT_MSG,
                                        L_TAG_4_70_START_POSITION + 3,
                                        (L_TAG_4_70_END_POSITION -
                                        L_TAG_4_70_START_POSITION - 4));
    DBMS_OUTPUT.put_line('L_TAG_4_70_VALUE=' || L_TAG_4_70_VALUE);
  
    --71A
    L_TAG_4_71A_START_POSITION := INSTR(L_SWIFT_MSG, '71A:');
    L_TAG_4_71A_END_POSITION   := INSTR(L_SWIFT_MSG,
                                        ':',
                                        L_TAG_4_71A_START_POSITION + 4);
    L_TAG_4_71A_VALUE          := SUBSTR(L_SWIFT_MSG,
                                         L_TAG_4_71A_START_POSITION + 4,
                                         (L_TAG_4_71A_END_POSITION -
                                         L_TAG_4_71A_START_POSITION - 5));
    DBMS_OUTPUT.put_line('L_TAG_4_71A_VALUE=' || L_TAG_4_71A_VALUE);
  
    PR_INSERT_SWIFT_TRACKER(L_TAG_1,
                            L_TAG_2_SENDER_BIC,
                            NULL,
                            L_TAG_4_20_REFERENCE,
                            L_TAG_23B_END_POSITION,
                            L_TAG_4_32A_VALUE,
                            L_TAG_4_50K_VALUE,
                            L_TAG_4_52A_VALUE,
                            L_TAG_4_53A_VALUE,
                            L_TAG_4_54A_VALUE,
                            L_TAG_4_59_VALUE,
                            L_TAG_4_70_VALUE,
                            L_TAG_4_71A_VALUE,
                            NULL,
                            P_FILE_NAME,
                            SYSDATE,
                            L_SWIFT_MSG,
                            SYSDATE,
                            'U');
  
    DBG('DONE WITH HANDOFF');
  
    IF P_FILE_NAME IS NOT NULL THEN
      BEGIN
        UTL_FILE.FRENAME('SWIFT_PAY_INCOMING_WIP',
                         P_FILE_NAME,
                         'SWIFT_PAY_INCOMING_COMP',
                         P_FILE_NAME,
                         TRUE);
        DBG('moved to Incoming completed directory');
        DBG('File name: ' || P_FILE_NAME);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN PR_SWIFT_TXN_INC_HANDOFF=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_SWIFT_TXN_INC_HANDOFF=' || SQLERRM);
  END PR_SWIFT_TXN_INC_HANDOFF;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(1000);
  BEGIN
    global.pr_init('000', 'SYSTEM');
  
    DBG('entered  ');
    DBMS_OUTPUT.PUT_LINE('entered  ');
  
    g_cstb_params := FN_GET_PARAMS;
  
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    DBMS_OUTPUT.PUT_LINE('Income path :' || g_cstb_params.PARAM_VAL);
  
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;
  
    DBG('FPATH  - ' || FPATH);
    DBMS_OUTPUT.PUT_LINE('FPATH=' || FPATH);
  
    FILE_NAME := FN_READ_NCS_FILE('/u01/fcubs/interfaces/SWIFT_Payments/Incoming/ready');
  
    DBG('FILE_NAME  - ' || FILE_NAME);
    DBMS_OUTPUT.PUT_LINE('FILE_NAME=' || FILE_NAME);
  
    PR_MOVE_FILE(FILE_NAME);
  
    DBG('Success  ');
    DBMS_OUTPUT.PUT_LINE('Success');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  
    L_CLOB CLOB;
    F      UTL_FILE.FILE_TYPE;
    V_LINE VARCHAR2(1000);
  BEGIN
  
    --GLOBAL.PR_INIT('002', 'SYSTEM');
  
    DBG('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
    DBMS_OUTPUT.PUT_LINE('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
  
    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('SWIFT_PAY_INCOMING_READY',
                       P_FILE_NAME,
                       'SWIFT_PAY_INCOMING_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBMS_OUTPUT.PUT_LINE('moved to wip');
      DBG('File name: ' || P_FILE_NAME);
      DBMS_OUTPUT.PUT_LINE('File name:');
    
      F := UTL_FILE.FOPEN('SWIFT_PAY_INCOMING_WIP', P_FILE_NAME, 'R');
    
      IF UTL_FILE.IS_OPEN(F) THEN
        LOOP
          BEGIN
            UTL_FILE.GET_LINE(F, V_LINE, 1000);
            IF V_LINE IS NULL THEN
              EXIT;
            END IF;
          
            L_CLOB := L_CLOB || V_LINE;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              EXIT;
            WHEN OTHERS THEN
              NULL;
          END;
        END LOOP;
      END IF;
    
      UTL_FILE.FCLOSE(F);
    
      DEBUG.PR_dEBUG('AC', 'L_CLOB=' || L_CLOB);
    
      --Handle Handoff
      PR_SWIFT_TXN_INC_HANDOFF(L_CLOB, P_FILE_NAME);
    
      --Handle Process
      PR_PROCESS_SWIFT_INC_TXN;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN WOT OF PR_MOVE_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN WOT OF PR_MOVE_FILE=' || SQLERRM);
    
  END PR_MOVE_FILE;

  PROCEDURE PR_INSERT_SWIFT_TRACKER(P_tag_1     IN VARCHAR2,
                                    P_tag_2     IN VARCHAR2,
                                    P_tag_3     IN VARCHAR2,
                                    P_tag_4_20  IN VARCHAR2,
                                    P_tag_4_23b IN VARCHAR2,
                                    P_tag_4_32a IN VARCHAR2,
                                    P_tag_4_50k IN VARCHAR2,
                                    P_tag_4_52a IN VARCHAR2,
                                    P_tag_4_53a IN VARCHAR2,
                                    P_tag_4_54a IN VARCHAR2,
                                    P_tag_4_59  IN VARCHAR2,
                                    P_tag_4_70  IN VARCHAR2,
                                    P_tag_4_71a IN VARCHAR2,
                                    P_tag_5     IN VARCHAR2,
                                    P_file_name IN VARCHAR2,
                                    P_time_in   IN VARCHAR2,
                                    P_swift_msg IN CLOB,
                                    P_file_date IN DATE,
                                    P_status    IN CHAR DEFAULT 'U') IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
  
    L_COUNT NUMBER;
  
  BEGIN
  
    --Check if above reference no already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_SWIFT_MT103_INCOMING_TRACK
       WHERE TAG_1 = P_TAG_1
         AND TAG_4_20 = P_TAG_4_20;
      -- AND STATUS = 'P';
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_SWIFT_MT103_INCOMING_TRACK
        (tag_1,
         tag_2,
         tag_3,
         tag_4_20,
         tag_4_23b,
         tag_4_32a,
         tag_4_50k,
         tag_4_52a,
         tag_4_53a,
         tag_4_54a,
         tag_4_59,
         tag_4_70,
         tag_4_71a,
         tag_5,
         file_name,
         time_in,
         swift_msg,
         file_date,
         status)
      VALUES
        (P_tag_1,
         P_tag_2,
         P_tag_3,
         P_tag_4_20,
         P_tag_4_23b,
         P_tag_4_32a,
         P_tag_4_50k,
         P_tag_4_52a,
         P_tag_4_53a,
         P_tag_4_54a,
         P_tag_4_59,
         P_tag_4_70,
         P_tag_4_71a,
         P_tag_5,
         P_file_name,
         P_time_in,
         P_swift_msg,
         P_file_date,
         P_status);
    
      --Temp table
      INSERT INTO IFTB_SWIFT_MT103_INC_TRACK
        (tag_1,
         tag_2,
         tag_3,
         tag_4_20,
         tag_4_23b,
         tag_4_32a,
         tag_4_50k,
         tag_4_52a,
         tag_4_53a,
         tag_4_54a,
         tag_4_59,
         tag_4_70,
         tag_4_71a,
         tag_5,
         file_name,
         time_in,
         swift_msg,
         file_date,
         status)
      VALUES
        (P_tag_1,
         P_tag_2,
         P_tag_3,
         P_tag_4_20,
         P_tag_4_23b,
         P_tag_4_32a,
         P_tag_4_50k,
         P_tag_4_52a,
         P_tag_4_53a,
         P_tag_4_54a,
         P_tag_4_59,
         P_tag_4_70,
         P_tag_4_71a,
         P_tag_5,
         P_file_name,
         P_time_in,
         P_swift_msg,
         P_file_date,
         P_status);
    END IF;
  
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_SWIFT_TRACKER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_SWIFT_TRACKER=' || SQLERRM);
    
  END PR_INSERT_SWIFT_TRACKER;

  PROCEDURE PR_SWIFT_UPLOAD(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('993', 'SYSTEM');
  
    DBG('Inside PR_SWIFT_UPLOAD');
  
    PR_INIT_MSG;
  
    DBG('Successful return from PR_SWIFT_UPLOAD');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_SWIFT_UPLOAD' || SQLERRM);
  END PR_SWIFT_UPLOAD;

  PROCEDURE PR_PROCESS_SWIFT_TXN(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('000', 'SYSTEM');
  
    PR_PROCESS_SWIFT_INC_TXN;
  
    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_SWIFT_TXN');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_SWIFT_TXN');
      DBG('ERROR CODE IN PR_PROCESS_SWIFT_TXN=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_SWIFT_TXN=' || SQLERRM);
  END PR_PROCESS_SWIFT_TXN;

END IFPKS_SWIFT_INCOMING_UTILS;
