CREATE OR REPLACE PACKAGE BODY ifpks_ifdcbdft_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdcbdft_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  --fn_swift_decompose
  --lcpks_swift_mt700
  --bcpks_swiftfmt for swift header and footer
  --mspks_msc

  /*
    
    --Field1
  PM_SENDER_HEAD := '{1:F01';
  
  IF LENGTH(PM_SENDER_ADD) = 8
  
         THEN
  
          PM_SENDER_HEAD := PM_SENDER_HEAD || PM_SENDER_ADD || 'A' || 'XXX' ||
                            '1111111111';
  
        ELSE
  
          PM_SENDER_HEAD := PM_SENDER_HEAD || SUBSTR(PM_SENDER_ADD, 1, 8) || 'A' ||
                            SUBSTR(PM_SENDER_ADD, 9, 3) || '1111111111';
  
        END IF;
                
  PM_SENDER_HEAD := PM_SENDER_HEAD || '}';
  PM_SENDER_HEAD := PM_SENDER_HEAD || {4:{177:2001031102}{451:0}}; --here 2001031102 is YYMMDDHHMM
  
  --Field2
  PM_RECVR_HEAD := '{2:O' || PM_MSG_TYPE;
  IF LENGTH(PM_RECVR_ADD) = 8 THEN
        PM_RECVR_HEAD := PM_RECVR_HEAD || PM_RECVR_ADD || 'XXXX';
      ELSE
        PM_RECVR_HEAD := PM_RECVR_HEAD || SUBSTR(PM_RECVR_ADD, 1, 8) || 'X' ||
                         SUBSTR(PM_RECVR_ADD, 9);
      END IF;
  PM_RECVR_HEAD := PM_RECVR_HEAD || 'N';
  PM_RECVR_HEAD := PM_RECVR_HEAD || '}';
  
  
  --Field3
  PM_TAG108 := '{3:{108:' || PM_DCN || '}';
  PM_TAG108 := PM_TAG108 || '{121:' || L_UETR || '}' || '}';
  
  --Field4
  work on this based on tags
  
  
  --Field5
  {5:{MAC:00000000}{CHK:FF3C83CBCE93}}{S:{SAC:}{COP:P}} --here FF3C83CBCE93 seems like some unique number
  
  
  
  
  https://labs.withsecure.com/publications/forging-swift-mt-payment-messages
  
  https://stackoverflow.com/questions/34810441/swift-ack-message-parsing
  
  --For Incoming pls check below
  --ftpks_swift_upload_job (main)
  --ftpks_upload (main)
  --Ftpks_Ftdtronl_Validate
  --ftpks_fcj_ftdconon_vals
  --Ftpks_Contract
  --ftpks_upldsrv  
    
    */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifdcbdft_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;

  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;

  FUNCTION FN_GET_CUST_ADDR(P_ACC_NO IN STTM_CORE_ACCOUNT.CUST_ACCOUNT_NO%TYPE)
    RETURN VARCHAR2 AS
  
    L_ADDRESS VARCHAR2(300);
  
  BEGIN
  
    BEGIN
      SELECT A.ADDRESS1 || ',' || A.ADDRESS2 || ',' || A.ADDRESS3 || ',' ||
             A.ADDRESS4
        INTO L_ADDRESS
        FROM STTM_CORE_ACCOUNT A
       WHERE A.CUST_ACCOUNT_NO = P_ACC_NO;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_ADDRESS := NULL;
    END;
  
    RETURN L_ADDRESS;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_ADDRESS;
    
  END FN_GET_CUST_ADDR;

  FUNCTION FN_GET_PARAM_VAL(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END FN_GET_PARAM_VAL;

  FUNCTION FN_RETURN_LOG_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_AML_SWIFT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_LOG_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_LOG_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_LOG_SEQ_NO=' || SQLERRM);
  END FN_RETURN_LOG_SEQ_NO;

  PROCEDURE PR_INSERT_SWIFT_WS_LOG(P_SEQ_NO     IN VARCHAR2,
                                   P_TRN_REF_NO IN VARCHAR2,
                                   P_DATE       IN TIMESTAMP,
                                   P_REQ_TYPE   IN VARCHAR2,
                                   
                                   P_REQ_MSG   IN CLOB,
                                   P_ADDL_INFO IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('START OF PR_INSERT_SWIFT_WS_LOG');
    DBG('BEFORE INSERTING INTO PR_INSERT_SWIFT_WS_LOG');
    INSERT INTO STTB_CORAL_SWIFT_WS_LOG
      (SEQ_NO, RELATED_REF_NO, INVOKE_DATE, REQ_TYPE, REQ_MSG, ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_TRN_REF_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       
       P_ADDL_INFO);
  
    COMMIT;
    DBG('END OF PR_INSERT_SWIFT_WS_LOG');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_SWIFT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_SWIFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_SWIFT_WS_LOG=' || SQLERRM);
    
  END PR_INSERT_SWIFT_WS_LOG;

  /*PROCEDURE PR_UPDATE_SWIFT_WS_LOG(P_TRN_REF_NO IN VARCHAR2,
                                   P_SEQ_NO     IN VARCHAR2,
                                   P_STATUS     IN CHAR,
                                   P_RES_MSG    IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_SWIFT_WS_LOG');
  
    UPDATE STTB_CORAL_SWIFT_WS_LOG
       SET MATCH_STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE RELATED_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF PR_UPDATE_SWIFT_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_SWIFT_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_SWIFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_SWIFT_WS_LOG=' || SQLERRM);
  END PR_UPDATE_SWIFT_WS_LOG;*/

  PROCEDURE PR_UPDATE_SWIFT_WS_LOG(P_TRN_REF_NO      IN VARCHAR2,
                                   P_SEQ_NO          IN VARCHAR2,
                                   P_MATCHSTATUS     IN VARCHAR2,
                                   P_WHITELISTSTATUS IN VARCHAR2,
                                   P_APPROVAL_STATUS IN VARCHAR2,
                                   P_TOKEN_KEY       IN VARCHAR2,
                                   P_SCAN_ID         IN VARCHAR2,
                                   P_RES_MSG         IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF OVERLOADED PR_UPDATE_SWIFT_WS_LOG');
  
    UPDATE STTB_CORAL_SWIFT_WS_LOG
       SET MATCH_STATUS     = P_MATCHSTATUS,
           WHITELIST_STATUS = P_WHITELISTSTATUS,
           APPROVAL_STATUS  = P_APPROVAL_STATUS,
           RES_MSG          = P_RES_MSG,
           TOKEN_KEY        = P_TOKEN_KEY,
           SCAN_ID          = P_SCAN_ID
     WHERE RELATED_REF_NO = P_TRN_REF_NO
       AND SEQ_NO = P_SEQ_NO;
  
    COMMIT;
  
    DBG('END OF OVERLOADED PR_UPDATE_SWIFT_WS_LOG');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN OVERLOADED PR_UPDATE_SWIFT_WS_LOG');
      DBG('ERROR CODE IN OVERLOADED PR_UPDATE_SWIFT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN OVERLOADED PR_UPDATE_SWIFT_WS_LOG=' || SQLERRM);
  END PR_UPDATE_SWIFT_WS_LOG;

  FUNCTION FN_RETURN_AML_TOKEN RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_AML_TOKEN');
  
    L_FORMATTED_MSG := '{
	"AuthID": "$L_AUTH_ID",
	"AuthPW": "$L_AUTH_PWD"
}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_AML_TOKEN');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_AML_TOKEN');
      DBG('ERROR CODE IN FN_RETURN_AML_TOKEN=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_AML_TOKEN=' || SQLERRM);
    
  END FN_RETURN_AML_TOKEN;

  FUNCTION FN_RETURN_FMT_AML_TOKEN RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
    L_AUTH_ID  VARCHAR2(100);
    L_AUTH_PWD VARCHAR2(100);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_FMT_AML_TOKEN');
  
    L_FORMATTED_MSG := FN_RETURN_AML_TOKEN;
  
    L_AUTH_ID := FN_GET_PARAM_VAL('PGW_AML_PAY_AUTH_ID');
  
    L_AUTH_PWD := FN_GET_PARAM_VAL('PGW_AML_PAY_AUTH_PWD');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AUTH_ID', L_AUTH_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_AUTH_PWD', L_AUTH_PWD);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_FMT_AML_TOKEN');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_AML_TOKEN');
      DBG('ERROR CODE IN FN_RETURN_FMT_AML_TOKEN=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_AML_TOKEN=' || SQLERRM);
    
  END FN_RETURN_FMT_AML_TOKEN;

  FUNCTION FN_RETURN_TXN_REALTIME_SCREEN RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_TXN_REALTIME_SCREEN');
  
    L_FORMATTED_MSG := '{
      "OfficerId": "$L_USER_ID",
      "Location": "$L_BRANCH_CODE",
      "Source": "SWIFT",
      "ServiceType": "3",
      "RedFlagType": "Y",
      "FileId": "pacs.008",
      "MsgId": "$L_MSG_ID",
      "CreDtTm": "$L_CREATED_DATE_TIME",
      "NbOfTxs": "1",
      "TtlAmt": "$L_TXN_AMT",
      "TtlAmtCcy": "$L_TXN_CCY",
      "SttlmInf_Date": "$L_TXN_DATE",
      "PayInfo_Direction": "CRDT",
      "PayInfo_Ccy": "$L_PAY_INFO_CCY",
      "PayInfo_Amt": "$L_PAY_INFO_AMT",
      "PayInfo_Date": "$L_TXN_DATE",
      "SenderAccountNo": "$L_SENDER_ACC_NO",
      "SenderName": "$L_SENDER_ACC_NAME",
      "SenderIDNo": "$L_SENDER_ID_NO",
      "Sender_BICFI": "$L_SENDER_BICFI",
      "SenderStreetName": "$L_SENDER_STREET_NAME",
      "SenderPostCode": "$L_SENDER_POST_CODE",
      "SenderTownName": "$L_SENDER_TOWN_NAME",
      "SenderCountry": "$L_SENDER_COUNTRY",
      "BeneAccountNo": "$L_BEN_ACC_NO",
      "BeneName": "$L_BEN_NAME",
      "BeneIDNo": "$L_BEN_ID_NO",
      "Bene_BICFI": "$L_BEN_BICFI",
      "BeneStreetName": "$L_BEN_STREET_NAME",
      "BenePostCode": "$L_BEN_POST_CODE",
      "BeneTownName": "$L_BEN_TOWN_NAME",
      "BeneCountry": "$L_BEN_COUNTRY",
      "Purpose_CodeOrProp": "$L_PURPOSE_OF_TRF",
      "InstructingAgent_BICFI": "$L_INSTRUCTING_AGENT_BICFI",
      "InstructingAgentName": "$L_INSTRUCTING_AGENT_NAME",
      "InstructingAgentCountry": "$L_INSTRUCTING_AGENT_COUNTRY",
      "InstructedAgent_BICFI": "$L_INSTRUCTED_AGENT_BICFI",
      "InstructedAgentName": "$L_INSTRUCTED_AGENT_NAME",
      "InstructedAgentCountry":"$L_INSTRUCTED_AGENT_COUNTRY",
      "IntermediaryAgent_BICFI": "$L_INTERMEDIARY_AGENT_BICFI",
      "IntermediaryAgentName": "$L_INTERMEDIARY_AGENT_NAME",
      "IntermediaryAgentCountry": "$L_INTERMEDIARY_AGENT_COUNTRY",
      "IntermediaryAgent_BICFI_02": "$L_INTERMEDIARY_AGENT2_BICFI_02",
      "IntermediaryAgentName_02": "$L_INTERMEDIARY_AGENT2_NAME_02",
      "IntermediaryAgentCountry_02": "$L_INTERMEDIARY_AGENT2_COUNTRY_02",
      "IntermediaryAgent_BICFI_03":  "$L_INTERMEDIARY_AGENT3_BICFI_03",
      "IntermediaryAgentName_03": "$L_INTERMEDIARY_AGENT3_NAME_03",
      "IntermediaryAgentCountry_03": "$L_INTERMEDIARY_AGENT3_COUNTRY_03",
      "CounterParty1":"",
      "CounterParty2":"",
      "CounterParty3":"",
      "CounterParty4":"",
      "PaymentChannel":"OTC"
      }';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_TXN_REALTIME_SCREEN');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_TXN_REALTIME_SCREEN');
      DBG('ERROR CODE IN FN_RETURN_TXN_REALTIME_SCREEN=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_TXN_REALTIME_SCREEN=' || SQLERRM);
    
  END FN_RETURN_TXN_REALTIME_SCREEN;

  FUNCTION FN_RETURN_FMT_TXN_REALTIME_SCREEN(ifdcbdft IN ifpks_ifdcbdft_Main.Ty_ifdcbdft)
    RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
    L_MSG_ID             IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE;
    L_CREATED_DATE_TIME  VARCHAR2(105);
    L_TXN_AMT            IFTB_CROSS_BORDER_MASTER.TXN_AMT%TYPE;
    L_TXN_CCY            IFTB_CROSS_BORDER_MASTER.TXN_CCY%TYPE;
    L_TXN_DATE           IFTB_CROSS_BORDER_MASTER.TRANSFER_DATE%TYPE;
    L_PAY_INFO_CCY       IFTB_CROSS_BORDER_MASTER.TXN_CCY%TYPE;
    L_PAY_INFO_AMT       IFTB_CROSS_BORDER_MASTER.TXN_AMT%TYPE;
    L_SENDER_ACC_NO      IFTB_CROSS_BORDER_MASTER.REM_ACC%TYPE;
    L_SENDER_ACC_NAME    IFTB_CROSS_BORDER_MASTER.REM_NAME%TYPE;
    L_SENDER_ID_NO       VARCHAR2(100);
    L_SENDER_BICFI       VARCHAR2(15);
    L_SENDER_STREET_NAME VARCHAR2(105);
    L_SENDER_POST_CODE   VARCHAR2(105);
    L_SENDER_TOWN_NAME   VARCHAR2(105);
    L_SENDER_COUNTRY     VARCHAR2(2);
    L_BEN_ACC_NO         IFTB_CROSS_BORDER_MASTER.BEN_ACC%TYPE;
    L_BEN_NAME           IFTB_CROSS_BORDER_MASTER.BEN_NAME%TYPE;
    L_BEN_ID_NO          VARCHAR2(100);
    L_BEN_BICFI          IFTB_CROSS_BORDER_MASTER.BEN_BIC%TYPE;
    L_BEN_STREET_NAME    IFTB_CROSS_BORDER_MASTER.BEN_ADD1%TYPE;
    L_BEN_POST_CODE      IFTB_CROSS_BORDER_MASTER.BEN_ADD2%TYPE;
    L_BEN_TOWN_NAME      IFTB_CROSS_BORDER_MASTER.BEN_ADD3%TYPE;
    L_BEN_COUNTRY        IFTB_CROSS_BORDER_MASTER.BEN_ADD4%TYPE;
    L_PURPOSE_OF_TRF     IFTB_CROSS_BORDER_MASTER.PURPOSE_OF_TRF%TYPE;
  
    L_INSTRUCTING_AGENT_BICFI   VARCHAR2(15);
    L_INSTRUCTING_AGENT_NAME    VARCHAR2(105);
    L_INSTRUCTING_AGENT_COUNTRY VARCHAR2(2);
  
    L_INSTRUCTED_AGENT_BICFI   VARCHAR2(15);
    L_INSTRUCTED_AGENT_NAME    VARCHAR2(105);
    L_INSTRUCTED_AGENT_COUNTRY VARCHAR2(2);
  
    L_INTERMEDIARY_AGENT_BICFI   VARCHAR2(15);
    L_INTERMEDIARY_AGENT_NAME    VARCHAR2(105);
    L_INTERMEDIARY_AGENT_COUNTRY VARCHAR2(2);
  
    L_INTERMEDIARY_AGENT_BICFI_02   VARCHAR2(15);
    L_INTERMEDIARY_AGENT_NAME_02    VARCHAR2(105);
    L_INTERMEDIARY_AGENT_COUNTRY_02 VARCHAR2(2);
  
    L_INTERMEDIARY_AGENT_BICFI_03   VARCHAR2(15);
    L_INTERMEDIARY_AGENT_NAME_03    VARCHAR2(105);
    L_INTERMEDIARY_AGENT_COUNTRY_03 VARCHAR2(2);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_FMT_TXN_REALTIME_SCREEN');
  
    L_FORMATTED_MSG := FN_RETURN_TXN_REALTIME_SCREEN;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_USER_ID',
                               GLOBAL.user_id);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BRANCH_CODE',
                               GLOBAL.current_branch);
  
    L_MSG_ID := ifdcbdft.v_iftbs_cross_border_master.related_ref_no;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_MSG_ID', L_MSG_ID);
  
    L_CREATED_DATE_TIME := to_char(SYSDATE, 'YYYY-MM-DD') || 'T' ||
                           to_char(SYSDATE, 'hh24:MM:SS');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CREATED_DATE_TIME',
                               L_CREATED_DATE_TIME);
  
    L_TXN_AMT := ifdcbdft.v_iftbs_cross_border_master.TXN_AMT;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_AMT', L_TXN_AMT);
  
    L_TXN_CCY := ifdcbdft.v_iftbs_cross_border_master.TXN_CCY;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_CCY', L_TXN_CCY);
  
    L_TXN_DATE := ifdcbdft.v_iftbs_cross_border_master.TRANSFER_DATE;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_TXN_DATE', L_TXN_DATE);
  
    L_PAY_INFO_CCY := ifdcbdft.v_iftbs_cross_border_master.TXN_CCY;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAY_INFO_CCY',
                               L_PAY_INFO_CCY);
  
    L_PAY_INFO_AMT := ifdcbdft.v_iftbs_cross_border_master.TXN_AMT;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PAY_INFO_AMT',
                               L_PAY_INFO_AMT);
  
    L_CREATED_DATE_TIME := ifdcbdft.v_iftbs_cross_border_master.MAKER_DT_STAMP;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_CREATED_DATE_TIME',
                               L_CREATED_DATE_TIME);
  
    L_SENDER_ACC_NO := ifdcbdft.v_iftbs_cross_border_master.rem_acc;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_ACC_NO',
                               L_SENDER_ACC_NO);
  
    L_SENDER_ACC_NAME := ifdcbdft.v_iftbs_cross_border_master.rem_name;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_ACC_NAME',
                               L_SENDER_ACC_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SENDER_ID_NO', '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_BICFI',
                               'PINCKHPPXXXX');
  
    L_SENDER_STREET_NAME := NULL;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_STREET_NAME',
                               L_SENDER_STREET_NAME);
  
    L_SENDER_POST_CODE := NULL;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_POST_CODE',
                               L_SENDER_POST_CODE);
  
    L_SENDER_TOWN_NAME := NULL;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_TOWN_NAME',
                               L_SENDER_TOWN_NAME);
  
    L_SENDER_COUNTRY := 'KH';
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SENDER_COUNTRY',
                               L_SENDER_COUNTRY);
  
    L_BEN_ACC_NO := ifdcbdft.v_iftbs_cross_border_master.ben_acc;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_ACC_NO',
                               L_BEN_ACC_NO);
  
    L_BEN_NAME := ifdcbdft.v_iftbs_cross_border_master.ben_name;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_NAME', L_BEN_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_ID_NO', '');
  
    L_BEN_BICFI := ifdcbdft.v_iftbs_cross_border_master.ben_bic;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_BEN_BICFI', L_BEN_BICFI);
  
    L_BEN_STREET_NAME := ifdcbdft.v_iftbs_cross_border_master.BEN_ADD1;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_STREET_NAME',
                               L_BEN_STREET_NAME);
  
    L_BEN_POST_CODE := ifdcbdft.v_iftbs_cross_border_master.BEN_ADD2;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_POST_CODE',
                               L_BEN_POST_CODE);
  
    L_BEN_TOWN_NAME := ifdcbdft.v_iftbs_cross_border_master.BEN_ADD3;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_TOWN_NAME',
                               L_BEN_TOWN_NAME);
  
    L_BEN_COUNTRY := ifdcbdft.v_iftbs_cross_border_master.BEN_ADD4;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BEN_COUNTRY',
                               L_BEN_COUNTRY);
  
    L_PURPOSE_OF_TRF := ifdcbdft.v_iftbs_cross_border_master.PURPOSE_OF_TRF;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PURPOSE_OF_TRF',
                               L_PURPOSE_OF_TRF);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTING_AGENT_BICFI',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTING_AGENT_NAME',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTING_AGENT_COUNTRY',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTED_AGENT_BICFI',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTED_AGENT_NAME',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INSTRUCTED_AGENT_COUNTRY',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT_BICFI',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT_NAME',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT_COUNTRY',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT2_BICFI_02',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT2_NAME_02',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT2_COUNTRY_02',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT3_BICFI_03',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT3_NAME_03',
                               '');
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_INTERMEDIARY_AGENT3_COUNTRY_03',
                               '');
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_FMT_TXN_REALTIME_SCREEN');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_TXN_REALTIME_SCREEN');
      DBG('ERROR CODE IN FN_RETURN_FMT_TXN_REALTIME_SCREEN=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_TXN_REALTIME_SCREEN=' || SQLERRM);
    
  END FN_RETURN_FMT_TXN_REALTIME_SCREEN;

  FUNCTION FN_RETURN_AML_TXN_STATUS RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
  
    DBG('SATRT OF FN_RETURN_AML_TXN_STATUS');
  
    L_FORMATTED_MSG := '{  
  "OfficerId": "$L_USER_ID",
  "Location": "$L_BRANCH_CODE",
  "Source": "SWIFT",
  "TxnScreeningNo": "$L_TXN_SCAN_ID",
  "ApprovalStatus": ""
 }';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_AML_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_AML_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_AML_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_AML_TXN_STATUS=' || SQLERRM);
    
  END FN_RETURN_AML_TXN_STATUS;

  FUNCTION FN_RETURN_FMT_AML_TXN_STATUS(ifdcbdft IN ifpks_ifdcbdft_Main.Ty_ifdcbdft)
    RETURN CLOB IS
  
    L_USER_ID     SMTB_USER.USER_ID%TYPE;
    L_BRANCH_CODE STTM_CORE_BRANCH.BRANCH_CODE%TYPE;
    L_TXN_SCAN_ID IFTB_CROSS_BORDER_MASTER.TXN_SCAN_ID%TYPE;
  
    L_FORMATTED_MSG CLOB;
  BEGIN
    DBG('SATRT OF FN_RETURN_FMT_AML_TXN_STATUS');
  
    L_FORMATTED_MSG := FN_RETURN_AML_TXN_STATUS;
  
    DBG('BEFORE REPLACEMENT OF AML PAY TXN STATUS JSON=' ||
        L_FORMATTED_MSG);
  
    L_USER_ID := GLOBAL.user_id;
  
    DBG('L_USER_ID=' || L_USER_ID);
  
    L_BRANCH_CODE := GLOBAL.current_branch;
  
    DBG('L_BRANCH_CODE=' || L_BRANCH_CODE);
  
    L_TXN_SCAN_ID := ifdcbdft.v_iftbs_cross_border_master.txn_scan_id;
  
    DBG('L_TXN_SCAN_ID=' || L_TXN_SCAN_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_USER_ID', L_USER_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BRANCH_CODE',
                               L_BRANCH_CODE);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_TXN_SCAN_ID',
                               L_TXN_SCAN_ID);
  
    DBG('AFTER REPLACEMENT OF AML PAY TXN STATUS JSON=' || L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_RETURN_FMT_AML_TXN_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_FMT_AML_TXN_STATUS');
      DBG('ERROR CODE IN FN_RETURN_FMT_AML_TXN_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_FMT_AML_TXN_STATUS=' || SQLERRM);
  END FN_RETURN_FMT_AML_TXN_STATUS;

  FUNCTION FN_AML_WEBSERVICE_CALL(p_ws_call_type in varchar2,
                                  p_out_msg      VARCHAR2,
                                  p_access_token VARCHAR2,
                                  p_in_resp      IN OUT CLOB) RETURN BOOLEAN IS
  
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_url           varchar2(255);
    buffer          varchar2(32767);
    buffer1         clob;
  
    l_resp_ok  BOOLEAN;
    l_resp_num NUMBER;
  
  BEGIN
    dbg('START OF FN_AML_WEBSERVICE_CALL');
  
    --utl_http.set_transfer_timeout(get_param_val('PGW_OUT_RFT_TIMEOUT'));
  
    IF p_ws_call_type = 'T' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_AML_PAY_GET_TOKEN_URL');
    ELSIF p_ws_call_type = 'A' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_AML_PAY_TXN_SCREEN_URL');
    ELSIF p_ws_call_type = 'C' THEN
      L_URL := FN_GET_PARAM_VAL('PGW_AML_PAY_GET_TXN_STATUS_URL');
    END IF;
  
    DBG('l_url-->' || L_URL);
  
    --req := utl_http.begin_request(url);
    l_http_request := utl_http.begin_request(l_url, 'POST', ' HTTP/1.1');
  
    IF p_ws_call_type = 'A' THEN
    
      utl_http.set_header(l_http_request,
                          'content-type',
                          'application/json');
    
      utl_http.set_header(l_http_request,
                          'Content-Length',
                          length(p_out_msg));
    
      UTL_HTTP.SET_HEADER(l_http_request,
                          'Authorization',
                          'Bearer ' || p_access_token);
    
    ELSE
    
      utl_http.set_authentication(l_http_request,
                                  FN_GET_PARAM_VAL('PGW_AML_PAY_AUTH_ID'),
                                  FN_GET_PARAM_VAL('PGW_AML_PAY_AUTH_PWD'),
                                  'Basic');
      utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
      utl_http.set_header(l_http_request,
                          'content-type',
                          'application/json');
    
      utl_http.set_header(l_http_request,
                          'Content-Length',
                          length(p_out_msg));
    
    END IF;
  
    --UTL_HTTP.SET_BODY_CHARSET('UTF-8');
  
    utl_http.set_transfer_timeout(300);
  
    utl_http.write_text(l_http_request, p_out_msg);
  
    UTL_HTTP.WRITE_RAW(l_http_request, UTL_RAW.CAST_TO_RAW(p_out_msg));
  
    l_http_response := utl_http.get_response(l_http_request);
  
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      -- process the response from the HTTP call
      begin
        loop
          utl_http.read_line(l_http_response, buffer);
          --dbms_output.put_line(buffer);
          buffer1 := buffer1 || buffer;
        end loop;
        utl_http.end_response(l_http_response);
      exception
        when utl_http.end_of_body then
          utl_http.end_response(l_http_response);
        when others then
          dbg('ERROR CODE=' || SQLCODE);
          dbg('ERROR MESSAGE=' || SQLERRM);
      end;
    
      p_in_resp := buffer1;
    
      debug.pr_debug('IF', 'buffer1=' || buffer1); --dbms_output.put_line(buffer1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(buffer1); --buffer2 may be check
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      dbg('error line number=' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_AML_WEBSERVICE_CALL;

  FUNCTION fn_generate_uetr RETURN VARCHAR2 AS
  
    L_UETR     RAW(16);
    L_DIGIT17  VARCHAR2(2);
    L_GEN_UETR VARCHAR(36);
    L_STR      VARCHAR2(255) DEFAULT NULL;
    L_HEX      VARCHAR2(16) DEFAULT '0123456789ABCDEF';
  BEGIN
    SELECT ROUND(DBMS_RANDOM.VALUE(8, 11)) INTO L_DIGIT17 FROM DUAL;
    DEBUG.PR_DEBUG('MS', 'Random value generated-> ' || L_DIGIT17);
  
    L_STR := SUBSTR(L_HEX, MOD(L_DIGIT17, 16) + 1, 1) || L_STR;
    DEBUG.PR_DEBUG('MS', 'Conversion of 17th digit -> ' || L_STR);
    L_DIGIT17 := L_STR || '0';
  
    L_UETR := SYS.DBMS_CRYPTO.RANDOMBYTES(16);
    L_UETR := (UTL_RAW.OVERLAY(UTL_RAW.BIT_OR(UTL_RAW.BIT_AND(UTL_RAW.SUBSTR(L_UETR,
                                                                             7,
                                                                             1),
                                                              '0F'),
                                              '40'),
                               L_UETR,
                               7));
    SELECT LOWER((UTL_RAW.OVERLAY(UTL_RAW.BIT_OR(UTL_RAW.BIT_AND(UTL_RAW.SUBSTR(L_UETR,
                                                                                9,
                                                                                1),
                                                                 '0F'),
                                                 L_DIGIT17),
                                  L_UETR,
                                  9)))
      INTO L_GEN_UETR
      FROM DUAL;
    RETURN(SUBSTR(L_GEN_UETR, 1, 8) || '-' || SUBSTR(L_GEN_UETR, 9, 4) || '-' ||
           SUBSTR(L_GEN_UETR, 13, 4) || '-' || SUBSTR(L_GEN_UETR, 17, 4) || '-' ||
           SUBSTR(L_GEN_UETR, 21, 12));
  END FN_GENERATE_UETR;

  FUNCTION FN_CALCULATE_CHECKSUM(P_HDRBDY_SWIFT_MSG IN VARCHAR2)
    RETURN VARCHAR2 AS
  
    L_CHECKSUM RAW(256);
  
    L_KEY     VARCHAR2(25) := '123456789'; --Pls check Secret key  
    L_KEY_RAW RAW(256);
  
    L_SWIFT_MSG     VARCHAR2(1000);
    L_SWIFT_MSG_RAW RAW(32767);
  
  BEGIN
  
    L_SWIFT_MSG := P_HDRBDY_SWIFT_MSG;
  
    -- Remove unnecessary characters from message
    L_SWIFT_MSG := REPLACE(REPLACE(L_SWIFT_MSG, CHR(10), ''), CHR(13), '');
  
    -- Convert key from VARCHAR2 to RAW
    L_KEY_RAW := utl_i18n.string_to_raw(L_KEY, 'AL32UTF8');
  
    -- Convert message from VARCHAR2 to RAW
    L_SWIFT_MSG_RAW := utl_i18n.string_to_raw(L_SWIFT_MSG, 'AL32UTF8');
  
    -- Calculate checksum using HMAC-SHA256
    L_CHECKSUM := dbms_crypto.mac(src => L_SWIFT_MSG_RAW,
                                  key => L_KEY_RAW,
                                  typ => dbms_crypto.hmac_sh256);
  
    --Encode checksum as a hexadecimal string
    L_CHECKSUM := RAWTOHEX(L_CHECKSUM);
  
    RETURN L_CHECKSUM;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN CALCULATING THE CHECKSUM');
      DBG('ERROR CODE IN CALCULATING THE CHECKSUM=' || SQLCODE);
      DBG('ERROR MESSAGE IN CALCULATING THE CHECKSUM=' || SQLERRM);
      RETURN L_CHECKSUM;
    
  END FN_CALCULATE_CHECKSUM;

  FUNCTION FN_GEN_SWIFT_HEADER(P_IFDCBDFT IN IFPKS_IFDCBDFT_MAIN.TY_IFDCBDFT,
                               P_MSG_TYPE IN VARCHAR2,
                               P_DCN      IN VARCHAR2,
                               P_BEN_BIC  IN VARCHAR2) RETURN VARCHAR2 AS
    --103
  
    L_SWIFT_HEADER VARCHAR2(3000);
    L_UETR         VARCHAR2(100);
    L_SWIFT_CODE   VARCHAR2(8);
  
  BEGIN
  
    DBG('START OF FN_GEN_SWIFT_HEADER');
  
    L_SWIFT_CODE := 'PINCKHPP';
  
    IF P_MSG_TYPE = 'C' THEN
    
      L_SWIFT_HEADER := FN_GEN_COVER_PAYMENT_HEADER(L_SWIFT_CODE || 'A' ||
                                                    'XXX',
                                                    FN_GENERATE_SESSION_NUMBER ||
                                                    FN_GENERATE_SEQUENCE_NUMBER,
                                                    TO_CHAR(SYSDATE,
                                                            'YYMMDDHHMM'),
                                                    'O');
    
      --Field1
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{1:F01';
    
      IF LENGTH(L_SWIFT_CODE) = 8
      
       THEN
      
        L_SWIFT_HEADER := L_SWIFT_HEADER || L_SWIFT_CODE || 'A' || 'XXX' ||
                          FN_GENERATE_SESSION_NUMBER ||
                          FN_GENERATE_SEQUENCE_NUMBER;
      
      ELSE
      
        L_SWIFT_HEADER := L_SWIFT_HEADER || SUBSTR(L_SWIFT_CODE, 1, 8) || 'A' ||
                          SUBSTR(L_SWIFT_CODE, 9, 3) ||
                          FN_GENERATE_SESSION_NUMBER ||
                          FN_GENERATE_SEQUENCE_NUMBER;
      
      END IF;
    
      L_SWIFT_HEADER := L_SWIFT_HEADER || '}';
    
      DBG('L_SWIFT_HEADER - 1=' || L_SWIFT_HEADER);
    
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{4:{177:' ||
                        TO_CHAR(SYSDATE, 'YYMMDDHHMM') || '}{451:0}}'; --here 2001031102 is YYMMDDHHMM
    
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{1:F01' || L_SWIFT_CODE || 'A' ||
                        'XXX' || TO_CHAR(SYSDATE, 'YYMMDDHHMM') || '}'; --here 2001031102 is YYMMDDHHMM
    
      --Field2
      DBG('P_BEN_BIC=' || P_BEN_BIC);
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{2:I' || P_MSG_TYPE;
    
      IF LENGTH(P_BEN_BIC) = 8 THEN
        L_SWIFT_HEADER := L_SWIFT_HEADER || RPAD(P_BEN_BIC, 12, 'X'); -- || 'XXXX';
      ELSE
        L_SWIFT_HEADER := L_SWIFT_HEADER || SUBSTR(P_BEN_BIC, 1, 8) || 'X' ||
                          SUBSTR(P_BEN_BIC, 9);
      END IF;
    
      L_SWIFT_HEADER := L_SWIFT_HEADER ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.RELATED_REF_NO || 'N';
      L_SWIFT_HEADER := L_SWIFT_HEADER || '}';
    
      --Field3
    
      L_UETR := FN_GENERATE_UETR;
    
      --L_SWIFT_HEADER := L_SWIFT_HEADER || '{3:{108:' || P_DCN || '}';
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{3:{121:' || L_UETR || '}' || '}';
      --L_SWIFT_HEADER := L_SWIFT_HEADER || '{121:' || L_UETR || '}' || '}';
    
    ELSE
      --MT202
    
      --Field1
      L_SWIFT_HEADER := '{1:F21';
    
      IF LENGTH(L_SWIFT_CODE) = 8
      
       THEN
      
        L_SWIFT_HEADER := L_SWIFT_HEADER || L_SWIFT_CODE || 'A' || 'XXX' ||
                          '1111111111';
      
      ELSE
      
        L_SWIFT_HEADER := L_SWIFT_HEADER || SUBSTR(L_SWIFT_CODE, 1, 8) || 'A' ||
                          SUBSTR(L_SWIFT_CODE, 9, 3) || '1111111111';
      
      END IF;
    
      L_SWIFT_HEADER := L_SWIFT_HEADER || '}';
    
      DBG('L_SWIFT_HEADER - 1=' || L_SWIFT_HEADER);
    
      L_SWIFT_HEADER := L_SWIFT_HEADER || '{2:O' || P_MSG_TYPE ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.RELATED_REF_NO;
      L_SWIFT_HEADER := L_SWIFT_HEADER || NULL; --52A
      L_SWIFT_HEADER := L_SWIFT_HEADER || to_char(sysdate, 'YYMMDDHHMM'); --
      L_SWIFT_HEADER := L_SWIFT_HEADER || CHR(10); --
    
    END IF;
  
    RETURN L_SWIFT_HEADER;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GEN_SWIFT_HEADER');
      DBG('ERROR CODE IN FN_GEN_SWIFT_HEADER=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GEN_SWIFT_HEADER=' || SQLERRM);
      RETURN L_SWIFT_HEADER;
  END FN_GEN_SWIFT_HEADER;

  FUNCTION FN_GEN_SWIFT_BODY(P_IFDCBDFT IN IFPKS_IFDCBDFT_MAIN.TY_IFDCBDFT)
    RETURN VARCHAR2 AS
  
    L_SWIFT_BODY               VARCHAR2(32767);
    L_SENDERS_CHG_DTLS         VARCHAR2(3);
    L_SENDERS_CHG_1            IFTB_CROSS_BORDER_MASTER.CHG_AMT1%TYPE;
    L_SENDERS_CHG_2            IFTB_CROSS_BORDER_MASTER.CHG_AMT2%TYPE;
    L_SENDERS_CHG_3            IFTB_CROSS_BORDER_MASTER.CHG_AMT3%TYPE;
    L_INTERBANK_SETTLED_AMOUNT VARCHAR2(15);
  
    L_BEN_CUST_DTLS VARCHAR2(2500);
    L_INT_BIC_DLS   VARCHAR2(2500);
    L_BEN_BIC_DTLS  VARCHAR2(2500);
  
  BEGIN
  
    DBG('START OF FN_GEN_SWIFT_BODY');
  
    IF p_ifdcbdft.v_iftbs_cross_border_master.TRANSFER_TYPE = 'C' THEN
    
      /*
          L_MESSAGE=-------------------------Instance Type and Transmission-------------------------
      Notification (Transmission) of Original sent to SWIFT (ACK)
      Network Delivery Status    :Network Ack 
      ---------------------------------Message Header---------------------------------
      FIN 103 Single Customer Credit Transfer
      Sender Swift address      : PINCKHPPXXX
      Receiver Swift address    : 
      ----------------------------------User Header-----------------------------------
      ----------------------------------Message Text----------------------------------
       :20: Sender's Reference
              OR23068246
      :23B: Bank Operation Code
              CRED
      :32A: Value Date/Currency/Interbank Settled Amount
              230224USD6918,91
      :33B: Currency/Instructed Amount
              USD7000,00
      :50F: Ordering Customer
              CCPT/SG/7209051714
              1/MR NIGEL TANG WAN BAO NABIL
              2/69 COMMONWEALTH DRIVE
              3/SG/HEX 02-239
              8/SINGAPORE 140069
      :52A: Ordering Institution
              UOVBSGSG
       :59: Beneficiary Customer
              /000112328
              NIGEL TANG WAN BAO NABIL
              PHUM 5, VEAL VONG COMMUNE
              PRAMPIR MEAKKAKRA DISTRICT,
              PHNOM PENH
       :70: Remittance Information
              TRANSFER TO OWN ACCOUNT-LIVING
              EXPENSES WHILST WORKING IN
              CAMBODIA
      :71A: Details of Charges
              BEN
      :71F: Sender's Charges
              USD22,59
      :71F: Sender's Charges
              USD38,50
      :71F: Sender's Charges
              USD20,
       :72: Sender to Receiver Information
              /ACC/PRINCE BANK PLC. NO. 175ABCD,
              //MAO TSE TOUNG BLVD., KHAN CHAMKAR
              //MON, PHNOM PENH
              /BOOK/8477728054FS
              
      ---------------------------------Message Trailer--------------------------------
      {MAC:00000000}
      {CHK:FF3C83CBCE93}
      }
      {S:{SAC:}
      {COP:P}
      
      
      
          */
    
      --Field4 Work on this based on tags
      L_SWIFT_BODY := '{4:';
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':20:' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.TRN_REF_NO;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':23B:' || 'CRED';
    
      L_INTERBANK_SETTLED_AMOUNT := P_IFDCBDFT.v_iftbs_cross_border_master.TXN_AMT;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':32A:' || TO_CHAR(SYSDATE, 'DDMMYY') ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.TXN_CCY ||
                      L_INTERBANK_SETTLED_AMOUNT;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      --L_SWIFT_BODY := L_SWIFT_BODY || ':33B:' ||
      --                P_IFDCBDFT.v_iftbs_cross_border_master.TXN_CCY ||
      --                L_INTERBANK_SETTLED_AMOUNT;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':50K:' || '/' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.rem_acc;
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.rem_name;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY ||
                      FN_GET_CUST_ADDR(P_IFDCBDFT.v_iftbs_cross_border_master.rem_acc);
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':52A:' || 'PINCKHPPXXX';
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':57A:' || 'PINCKHPPXXX';
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':59:' || '/' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ACC;
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.BEN_NAME;
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_BEN_CUST_DTLS := L_BEN_CUST_DTLS ||
                         P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD1 || ',';
    
      L_BEN_CUST_DTLS := L_BEN_CUST_DTLS ||
                         P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD2 || ',';
    
      L_BEN_CUST_DTLS := L_BEN_CUST_DTLS ||
                         P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD3;
    
      L_SWIFT_BODY := L_SWIFT_BODY || L_BEN_CUST_DTLS;
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':70:' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.PURPOSE_OF_TRF;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      IF P_IFDCBDFT.v_iftbs_cross_border_master.charge_type = 'BEN' THEN
      
        L_SENDERS_CHG_DTLS := 'BEN';
      
      ELSIF P_IFDCBDFT.v_iftbs_cross_border_master.charge_type = 'SHA' THEN
      
        L_SENDERS_CHG_DTLS := 'SHA';
      
      ELSE
      
        L_SENDERS_CHG_DTLS := 'OUR';
      
      END IF;
    
      L_SWIFT_BODY := L_SWIFT_BODY || ':71A:' || L_SENDERS_CHG_DTLS;
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
    
      IF NVL(P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT1, 0) > 0 THEN
      
        L_SENDERS_CHG_1 := P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT1_IN_USD;
      
        L_SWIFT_BODY := L_SWIFT_BODY || ':71F:' || 'USD' || L_SENDERS_CHG_1;
        L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      
      END IF;
    
      IF NVL(P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT2, 0) > 0 THEN
      
        L_SENDERS_CHG_2 := P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT2_IN_USD;
      
        L_SWIFT_BODY := L_SWIFT_BODY || ':71F:' || 'USD' || L_SENDERS_CHG_2;
        L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      
      END IF;
    
      IF NVL(P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT3, 0) > 0 THEN
      
        L_SENDERS_CHG_3 := P_IFDCBDFT.v_iftbs_cross_border_master.CHG_AMT3_IN_USD;
      
        L_SWIFT_BODY := L_SWIFT_BODY || ':71F:' || 'USD' || L_SENDERS_CHG_3;
        L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      
      END IF;
    
      L_SWIFT_BODY := L_SWIFT_BODY ||
                      ':72:/ACC/PRINCE BANK PLC. NO. 175ABCD,' || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || '//MAO TSE TOUNG BLVD., KHAN CHAMKAR' ||
                      chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || '//MON, PHNOM PENH' || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || '/BOOK/8477728054FS' || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || '-}';
    
    ELSE
      --MT202
    
      --Field4 Work on this based on tags
      L_SWIFT_BODY := '{4:';
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':20:' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.TRN_REF_NO;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':21:' ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.RELATED_REF_NO;
    
      L_INTERBANK_SETTLED_AMOUNT := P_IFDCBDFT.v_iftbs_cross_border_master.TXN_AMT;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':32A:' || TO_CHAR(SYSDATE, 'DDMMYY') ||
                      P_IFDCBDFT.v_iftbs_cross_border_master.TXN_CCY ||
                      L_INTERBANK_SETTLED_AMOUNT;
    
      --Always Prince Bank
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':52A:' || 'PINCKHPP'; --Ordering Institution (Sender) bank name and address
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || 'PRINCE BANK PLC.';
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || 'PHNOM PENH  KH';
    
      --L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      --L_SWIFT_BODY := L_SWIFT_BODY || ':56A:' || NULL; --Intermediary Institution (Receiver) bank name and address
    
      L_INT_BIC_DLS := P_IFDCBDFT.v_iftbs_cross_border_master.INTERMEDIARY_BIC ||
                       chr(10);
      L_INT_BIC_DLS := L_INT_BIC_DLS ||
                       P_IFDCBDFT.v_iftbs_cross_border_master.INTERMEDIATORY_BANK_NAME ||
                       chr(10);
      L_INT_BIC_DLS := L_INT_BIC_DLS ||
                       P_IFDCBDFT.v_iftbs_cross_border_master.INTERMEDIATORY_ADDR1 ||
                       chr(10);
    
      L_INT_BIC_DLS := L_INT_BIC_DLS ||
                       P_IFDCBDFT.v_iftbs_cross_border_master.INTERMEDIATORY_ADDR2 ||
                       chr(10);
    
      L_INT_BIC_DLS := L_INT_BIC_DLS ||
                       P_IFDCBDFT.v_iftbs_cross_border_master.INTERMEDIATORY_ADDR3;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':57A:' || L_INT_BIC_DLS; --beneficiary bank (receiver bank) of the payment
    
      L_BEN_BIC_DTLS := '/' ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ACC ||
                        chr(10);
    
      L_BEN_BIC_DTLS := L_BEN_CUST_DTLS || CASE
                          WHEN P_IFDCBDFT.v_iftbs_cross_border_master.BEN_BIC =
                               'OTHER' THEN
                           P_IFDCBDFT.v_iftbs_cross_border_master.OTHER_BANK_BEN_BIC ||
                           chr(10)
                        
                          ELSE
                           P_IFDCBDFT.v_iftbs_cross_border_master.BEN_BIC ||
                           chr(10)
                        END;
    
      L_BEN_BIC_DTLS := L_BEN_CUST_DTLS ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.BANK_NAME ||
                        chr(10);
    
      L_BEN_BIC_DTLS := L_BEN_CUST_DTLS ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD1 ||
                        chr(10);
    
      L_BEN_BIC_DTLS := L_BEN_CUST_DTLS ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD2 ||
                        chr(10);
    
      L_BEN_BIC_DTLS := L_BEN_CUST_DTLS ||
                        P_IFDCBDFT.v_iftbs_cross_border_master.BEN_ADD3;
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':58A:' || L_BEN_BIC_DTLS; --Beneficiary - This tag identifies the ultimate beneficiary whose account is credited with the funds transferred.
    
      L_SWIFT_BODY := L_SWIFT_BODY || chr(10);
      L_SWIFT_BODY := L_SWIFT_BODY || ':72:' || chr(10);
    
      L_SWIFT_BODY := L_SWIFT_BODY || '-}';
    
    END IF;
  
    RETURN L_SWIFT_BODY;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GEN_SWIFT_BODY');
      DBG('ERROR CODE IN FN_GEN_SWIFT_BODY=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GEN_SWIFT_BODY=' || SQLERRM);
      RETURN L_SWIFT_BODY;
  END FN_GEN_SWIFT_BODY;

  FUNCTION FN_GEN_SWIFT_FOOTER(P_IFDCBDFT     IN IFPKS_IFDCBDFT_MAIN.TY_IFDCBDFT,
                               P_HDR_BODY_MSG IN VARCHAR2) RETURN VARCHAR2 AS
  
    L_SWIFT_FOOTER VARCHAR2(3000);
    L_CHECKSUM     VARCHAR2(1000);
  
  BEGIN
  
    DBG('START OF FN_GEN_SWIFT_FOOTER');
  
    IF p_ifdcbdft.v_iftbs_cross_border_master.TRANSFER_TYPE = 'C' THEN
      --Field5
      --L_SWIFT_FOOTER := '{5:{MAC:00000000}{CHK:FF3C83CBCE93}}{S:{SAC:}{COP:P}}'; --here FF3C83CBCE93 seems like some unique number
      L_SWIFT_FOOTER := '{5:{MAC:00000000}' || '{CHK:' ||
                        FN_CALCULATE_CHECKSUM(P_HDR_BODY_MSG) ||
                        '}}{S:{SAC:}{COP:P}}';
    
    ELSE
    
      --L_SWIFT_FOOTER := CHR(10);
      L_SWIFT_FOOTER := '{S:{CHK:' || FN_CALCULATE_CHECKSUM(P_HDR_BODY_MSG) || '}}';
    
    END IF;
  
    RETURN L_SWIFT_FOOTER;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GEN_SWIFT_FOOTER');
      DBG('ERROR CODE IN FN_GEN_SWIFT_FOOTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GEN_SWIFT_FOOTER=' || SQLERRM);
      RETURN L_SWIFT_FOOTER;
  END FN_GEN_SWIFT_FOOTER;

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSCcyService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSRTService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  PROCEDURE PR_GET_RATES(P_CCY1      IN VARCHAR2, --Remitter Account Currency
                         P_CCY2      IN VARCHAR2, --Transaction Currency
                         P_MID_RATE  OUT VARCHAR2,
                         P_BUY_RATE  OUT VARCHAR2,
                         P_SELL_RATE OUT VARCHAR2) AS
  
    L_XML_REQUEST VARCHAR2(32767) := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSCcyService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:QUERYCYDRATEE_IOFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>OBPAY</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:USERID>OBPAYUSER</fcub:USERID>
            <fcub:BRANCH>000</fcub:BRANCH>
            <fcub:SERVICE>FCUBSCcyService</fcub:SERVICE>
            <fcub:OPERATION>QueryCYDRATEE</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Ccy-Rate-Master-IO>
               <fcub:CCY1>$L_CCY1</fcub:CCY1>
               <fcub:CCY2>$L_CCY2</fcub:CCY2>
            </fcub:Ccy-Rate-Master-IO>
         </fcub:FCUBS_BODY>
      </fcub:QUERYCYDRATEE_IOFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
  
    L_RESPONSE          VARCHAR2(32767) := '';
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
    L_STATUS_MSG        VARCHAR2(105);
    L_ERROR_DESC        VARCHAR2(255);
  
    TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
  
    L_MID_RATE  CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE  CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE CYTM_RATES.SALE_RATE%TYPE;
  
  BEGIN
  
    DBG('INSIDE PR_GET_RATES');
  
    L_XML_REQUEST := REPLACE(L_XML_REQUEST, '$L_CCY1', P_CCY1);
    L_XML_REQUEST := REPLACE(L_XML_REQUEST, '$L_CCY2', P_CCY2);
  
    DBG('L_XML_REQUEST=' || L_XML_REQUEST);
  
    L_RESPONSE := process_http('http://10.80.80.109:8001/' ||
                               'FCUBSCcyService/FCUBSCcyService',
                               L_XML_REQUEST,
                               'text/xml;charset=utf-8');
  
    DBG('L_RESPONSE OF EXCHANGE RATES=' || L_RESPONSE);
  
    PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
  
    DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
  
    --Check if returned error or success
    L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                    .GETSTRINGVAL;
  
    IF L_STATUS_MSG <> 'SUCCESS' THEN
    
      L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                      .GETSTRINGVAL;
    
      Pr_Log_Error('IFDCBDFT', 'FLEXCUBE', 'IF-NCS001', L_ERROR_DESC); --pls put the error code
    
      --RETURN FALSE;
    
    ELSE
    
      --Get list of rates      
    
      BEGIN
        WITH t(xml) AS
         (SELECT xmltype(L_FORMATTED_RES_MSG) FROM DUAL)
        SELECT x.*
          BULK COLLECT
          INTO L_EXCHANGE_RATES_LIST
          FROM t,
               xmltable(xmlnamespaces('urn:org:abcd:message:TRequest:v2.1.0' AS
                                      "nq1"),
                        '/QUERYCYDRATEE_IOFS_RES/FCUBS_BODY/Ccy-Rate-Master-Full/Ccy-Rate-Details'
                        passing t.xml columns RATE_TYPE varchar2(50) PATH
                        'RATETYPE',
                        MID_RATE varchar2(50) PATH 'MIDRATE',
                        BUY_RATE VARCHAR2(50) PATH 'BUYRATE',
                        SALE_RATE VARCHAR2(50) PATH 'SALERATE') x;
      
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IF',
                         'ERROR CODE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLCODE);
          DEBUG.PR_DEBUG('IF',
                         'ERROR MESSAGE OF WITH CLAUSE OF EXCHANGE RATES LIST=' ||
                         SQLERRM);
      END;
      Debug.Pr_Debug('IF', 'COUNT=' || L_EXCHANGE_RATES_LIST.COUNT);
    
      DBG('L_EXCHANGE_RATES_LIST.RATE_TYPE=' || L_EXCHANGE_RATES_LIST(1)
          .RATE_TYPE);
      DBG('L_EXCHANGE_RATES_LIST.BUY_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .BUY_RATE);
      DBG('L_EXCHANGE_RATES_LIST.MID_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .MID_RATE);
      DBG('L_EXCHANGE_RATES_LIST.SALE_RATE=' || L_EXCHANGE_RATES_LIST(1)
          .SALE_RATE);
    
      IF L_EXCHANGE_RATES_LIST.COUNT > 0 THEN
      
        BEGIN
          FOR K IN 1 .. L_EXCHANGE_RATES_LIST.COUNT LOOP
            Debug.Pr_Debug('IF',
                           'RATE_TYPE=' || L_EXCHANGE_RATES_LIST(K)
                           .RATE_TYPE || ' ' || 'MID RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .MID_RATE || ' ' || 'BUY RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .BUY_RATE || ' ' || 'SALE RATE=' || L_EXCHANGE_RATES_LIST(K)
                           .SALE_RATE);
          
            IF L_EXCHANGE_RATES_LIST(K).RATE_TYPE = 'COMM' THEN
            
              L_MID_RATE  := L_EXCHANGE_RATES_LIST(K).MID_RATE;
              L_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
              G_BUY_RATE  := L_EXCHANGE_RATES_LIST(K).BUY_RATE;
              L_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
              G_SALE_RATE := L_EXCHANGE_RATES_LIST(K).SALE_RATE;
            
            END IF;
          
          END LOOP;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE ASSINGING THE PARSED FIELD TO MULTI RECORD BLOCK');
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
        END;
      
      END IF;
    
      DBG('L_MID_RATE=' || L_MID_RATE);
    
      DBG('L_BUY_RATE=' || L_BUY_RATE);
    
      DBG('L_SALE_RATE=' || L_SALE_RATE);
    
      P_MID_RATE  := L_MID_RATE;
      P_BUY_RATE  := L_BUY_RATE;
      P_SELL_RATE := L_SALE_RATE;
    
    END IF;
  
    DBG('RETURNING FROM PR_GET_RATES');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GET_RATES');
      DBG('ERROR CODE IN PR_GET_RATES=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GET_RATES=' || SQLERRM);
  END PR_GET_RATES;

  FUNCTION FN_GET_ACCOUNT_DTLS(P_CUSTAC_NO IN VARCHAR2)
    RETURN STTM_CORE_ACCOUNT%ROWTYPE AS
  
    L_STTM_CORE_ACCOUNT STTM_CORE_ACCOUNT%ROWTYPE;
  
  BEGIN
    BEGIN
      SELECT *
        INTO L_STTM_CORE_ACCOUNT
        FROM STTM_CORE_ACCOUNT A
       WHERE A.CUST_ACCOUNT_NO = P_CUSTAC_NO;
    
      RETURN L_STTM_CORE_ACCOUNT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('ERROR CODE IN FN_GET_ACCOUNT_DTLS=' || SQLCODE);
        DBG('ERROR MESSAGE IN FN_GET_ACCOUNT_DTLS=' || SQLERRM);
        L_STTM_CORE_ACCOUNT := NULL;
        RETURN L_STTM_CORE_ACCOUNT;
    END;
  
    RETURN L_STTM_CORE_ACCOUNT;
  
  END FN_GET_ACCOUNT_DTLS;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_RETURN_SEQ_NO RETURN VARCHAR2 IS
    L_SEQ NUMBER;
    L_REF VARCHAR2(100);
  BEGIN
  
    SELECT TRSQ_SWIFT_SEQID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 12, '0');
  
    RETURN L_REF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_RETURN_SEQ_NO');
      DBG('ERROR CODE IN FN_RETURN_SEQ_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_SEQ_NO=' || SQLERRM);
  END FN_RETURN_SEQ_NO;

  PROCEDURE PR_GEN_SWIFT_MSG_FILE_GEN(P_IN_DIR_NAME  IN VARCHAR2,
                                      P_IN_FILE_NAME IN VARCHAR2,
                                      P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_SWIFT_MSG_FILE_GEN');
      DBG('ERROR CODE IN PR_WRITE_SDR_TXN_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_SWIFT_MSG_FILE_GEN=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_GEN_SWIFT_MSG_FILE_GEN=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_GEN_SWIFT_MSG_FILE_GEN;

  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifdcbdft         IN OUT ifpks_ifdcbdft_Main.ty_ifdcbdft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifdcbdft_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifdcbdft         IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    l_serial_no      VARCHAR2(16);
    L_RELATED_REF_NO IFTB_CROSS_BORDER_MASTER.RELATED_REF_NO%TYPE;
  
    L_XML            VARCHAR2(32767);
    L_RESPONSE       VARCHAR2(32767) := '';
    L_SETTLEMENT_ACC IFTB_CROSS_BORDER_MASTER.REM_ACC%TYPE;
    L_CUST_DRAC_CCY  STTM_CORE_ACCOUNT.CUST_AC_CCY%TYPE;
    L_BRN            STTM_CORE_ACCOUNT.SOURCE_SYSTEM_ACC_BRN%TYPE;
  
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_MID_RATE   CYTM_RATES.MID_RATE%TYPE;
    L_BUY_RATE   CYTM_RATES.BUY_RATE%TYPE;
    L_SALE_RATE  CYTM_RATES.SALE_RATE%TYPE;
    L_EXCH_RATE  IFTB_CROSS_BORDER_MASTER.EXCH_RATE%TYPE;
    L_EXCH_RATE1 IFTB_CROSS_BORDER_MASTER.EXCH_RATE%TYPE;
    L_EXCH_RATE2 IFTB_CROSS_BORDER_MASTER.EXCH_RATE%TYPE;
  
    l_txn_amt IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
  
    L_COMM_FEE_P    IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_COMM_MIN_FEE  IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_CABLE_FEE     IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_COMM_FEE      IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_COMM_CALC_FEE IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_OTHER_FEE     IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    l_chg_amt1      IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    l_chg_amt2      IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    l_chg_amt3      IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
  
    l_chg_amt1_in_usd IFTB_CROSS_BORDER_MASTER.Chg_Amt1_In_Usd%TYPE;
    l_chg_amt2_in_usd IFTB_CROSS_BORDER_MASTER.Chg_Amt2_In_Usd%TYPE;
    l_chg_amt3_in_usd IFTB_CROSS_BORDER_MASTER.Chg_Amt3_In_Usd%TYPE;
  
    l_final_chg_amt      IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    l_chg_amt_in_acc_ccy IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
    L_EQUIVALENT_USD_AMT IFTB_CROSS_BORDER_MASTER.txn_amt%TYPE;
  
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    TYPE TYPE_EXCHANGE_RATES_LIST IS TABLE OF CYTB_RATES_CUSTOM%ROWTYPE;
    L_EXCHANGE_RATES_LIST TYPE_EXCHANGE_RATES_LIST;
  
    L_TRN_REF_NO IFTB_CROSS_BORDER_MASTER.TRN_REF_NO%TYPE;
    L_XREF       VARCHAR2(15);
  
    L_STTM_CORE_ACCOUNT STTM_CORE_ACCOUNT%ROWTYPE;
  
    L_SWIFT_HDR_MSG VARCHAR2(2500);
    L_SWIFT_BDY_MSG VARCHAR2(2500);
    L_SWIFT_FTR_MSG VARCHAR2(2500);
  
    L_COUNT NUMBER := 0;
  
    l_rate       NUMBER;
    l_charge_amt NUMBER := 0;
  
    L_FORMATTED_MSG           CLOB;
    L_GEN_SEQ_NO              VARCHAR2(100);
    L_IN_RESP                 CLOB;
    L_RESP_IN_XML             CLOB;
    L_RESPONSE_CODE           VARCHAR2(105);
    L_RESPONSE_MSG            VARCHAR2(105);
    L_TXN_SCAN_ID             STTB_CORAL_SWIFT_WS_LOG.SCAN_ID%TYPE;
    L_AML_TOKEN_KEY           STTB_CORAL_SWIFT_WS_LOG.TOKEN_KEY%TYPE;
    L_MATCH_STATUS            STTB_CORAL_SWIFT_WS_LOG.MATCH_STATUS%TYPE;
    L_WHITELIST_STATUS        STTB_CORAL_SWIFT_WS_LOG.WHITELIST_STATUS%TYPE;
    L_APPROVAL_STATUS         STTB_CORAL_SWIFT_WS_LOG.APPROVAL_STATUS%TYPE;
    L_STTB_CORAL_SWIFT_WS_LOG STTB_CORAL_SWIFT_WS_LOG%ROWTYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory=');
  
    IF P_ACTION_CODE = 'NEW' THEN
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'KHR' THEN
      
        L_EQUIVALENT_USD_AMT := p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT /
                                p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE;
      
        IF L_EQUIVALENT_USD_AMT < 0.01 THEN
        
          OVPKSS.PR_APPENDTBL('DE-PRI-SC01',
                              p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY);
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      L_STTM_CORE_ACCOUNT := FN_GET_ACCOUNT_DTLS(p_ifdcbdft.v_iftbs_cross_border_master.REM_ACC);
    
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_FROZEN, 'N') = 'Y' THEN
      
        Pr_Log_Error(p_Function_id,
                     p_Source,
                     'CS-UPD-016',
                     p_ifdcbdft.v_iftbs_cross_border_master.REM_ACC);
      
        RETURN FALSE;
      
      END IF;
    
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_DORMANT, 'N') = 'Y' THEN
      
        Pr_Log_Error(p_Function_id,
                     p_Source,
                     'CS-UPD-017',
                     p_ifdcbdft.v_iftbs_cross_border_master.REM_ACC);
      
        RETURN FALSE;
      END IF;
    
      IF NVL(L_STTM_CORE_ACCOUNT.AC_STAT_NO_DR, 'N') = 'Y' THEN
      
        Pr_Log_Error(p_Function_id,
                     p_Source,
                     'CS-TRFR-51',
                     p_ifdcbdft.v_iftbs_cross_border_master.REM_ACC);
      
        RETURN FALSE;
      END IF;
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.BEN_BIC = 'OTHER' THEN
      
        IF p_ifdcbdft.v_iftbs_cross_border_master.OTHER_BANK_BEN_BIC IS NULL THEN
        
          Pr_Log_Error(p_Function_id, p_Source, 'IF-SWIFT-02', NULL);
        
          RETURN FALSE;
        
        END IF;
      
        IF p_ifdcbdft.v_iftbs_cross_border_master.BANK_NAME IS NULL THEN
        
          Pr_Log_Error(p_Function_id, p_Source, 'IF-SWIFT-03', NULL);
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.BEN_BIC <> 'OTHER' THEN
      
        IF p_ifdcbdft.v_iftbs_cross_border_master.OTHER_BANK_BEN_BIC IS NOT NULL THEN
        
          Pr_Log_Error(p_Function_id, p_Source, 'IF-SWIFT-04', NULL);
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN ('PICKUP', 'NEW') THEN
    
      p_ifdcbdft.v_iftbs_cross_border_master.trn_ref_no    := NULL;
      p_ifdcbdft.v_iftbs_cross_border_master.transfer_date := GLOBAL.application_date;
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.related_ref_no IS NULL THEN
        IF NOT trpks_core.fn_get_product_refno(GLOBAL.current_branch,
                                               'OBPM',
                                               GLOBAL.application_date,
                                               l_serial_no,
                                               L_RELATED_REF_NO,
                                               p_err_code) THEN
          dbg('Failed in generation Transaction Ref No');
          RETURN FALSE;
        ELSE
          dbg('L_RELATED_REF_NO=' || L_RELATED_REF_NO);
          p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO := L_RELATED_REF_NO;
        
        END IF;
      END IF;
    
      DBG('p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY=' ||
          p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY);
    
      BEGIN
      
        SELECT A.CUST_AC_CCY
          INTO L_CUST_DRAC_CCY
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO =
               p_ifdcbdft.v_iftbs_cross_border_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_DRAC_CCY := NULL;
      END;
    
      DBG('L_CUST_DRAC_CCY=' || L_CUST_DRAC_CCY);
    
      DBG('p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY=' ||
          p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY);
    
      DBG('p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT=' ||
          p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT);
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'KHR' AND
         p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' THEN
      
        PR_GET_RATES(p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        L_EXCH_RATE := ROUND(1 * L_SALE_RATE, 2);
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'KHR' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'EUR' THEN
      
        PR_GET_RATES('USD',
                     p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        L_EXCH_RATE1 := L_BUY_RATE;
      
        L_EXCH_RATE := ROUND(L_SALE_RATE, 2); --recent change
      
        /*PR_GET_RATES('USD',
                     p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
        
        L_EXCH_RATE2 := L_SALE_RATE;
        
        L_EXCH_RATE := ROUND(1 / L_EXCH_RATE1 * L_EXCH_RATE2, 2);*/
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'KHR' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'THB' THEN
      
        PR_GET_RATES('USD',
                     p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        L_EXCH_RATE1 := L_BUY_RATE;
      
        L_EXCH_RATE := ROUND(L_SALE_RATE, 2); --recent change
      
        /*PR_GET_RATES('USD',
                     p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
        
        L_EXCH_RATE2 := L_SALE_RATE;
        
        L_EXCH_RATE := ROUND(1 / L_EXCH_RATE1 * L_EXCH_RATE2, 2);*/
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'USD' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'EUR' THEN
      
        PR_GET_RATES(p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        --L_EXCH_RATE := ROUND(1 / L_BUY_RATE, 2);
      
        L_EXCH_RATE := L_SALE_RATE; --recent change
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'USD' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'THB' THEN
      
        PR_GET_RATES(p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        --L_EXCH_RATE := ROUND(1 / L_BUY_RATE, 2);
      
        L_EXCH_RATE := L_SALE_RATE; --recent change
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'USD' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'KHR' THEN
      
        PR_GET_RATES(p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                     p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                     L_MID_RATE,
                     L_BUY_RATE,
                     L_SALE_RATE);
      
        L_EXCH_RATE := ROUND(1 / L_BUY_RATE, 2);
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY = 'USD' AND
            p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' THEN
      
        L_EXCH_RATE := 1;
      
      END IF;
    
      DBG('Derived Exchange Rate=' || L_EXCH_RATE);
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE IS NULL THEN
      
        p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE := L_EXCH_RATE;
      
      END IF;
    
      --check if charge type is null
      IF p_ifdcbdft.v_iftbs_cross_border_master.CHARGE_TYPE IS NULL THEN
      
        P_ERR_CODE := 'IF-SWIFT-01';
      
        Pr_Log_Error(p_Function_id, P_SOURCE, p_Err_Code, p_Err_Params);
      
        RETURN FALSE;
      
      END IF;
    
      --Charge Calculation Stats
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT > 0 THEN
      
        --Get Percentage
        L_COMM_FEE_P := FN_GET_PARAM_VAL('SWIFT_COMM_FEE_PERCENTAGE');
      
        DBG('L_COMM_FEE_P=' || L_COMM_FEE_P);
      
        --Get Min Fee
        L_COMM_MIN_FEE := FN_GET_PARAM_VAL('SWIFT_MIN_FEE_USD');
      
        --Get Telex Fee
        L_CABLE_FEE := FN_GET_PARAM_VAL('SWIFT_TELEX_FEE_USD');
      
        DBG('L_COMM_MIN_FEE=' || L_COMM_MIN_FEE);
      
        IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY <>
           L_CUST_DRAC_CCY THEN
        
          IF L_CUST_DRAC_CCY = 'USD' THEN
            --here transaction currency is EUR/CNY/THB and account currency is USD
          
            DBG('INSIDE ACCOUNT CURRENCY - USD');
          
            --Charge1
            IF p_ifdcbdft.v_iftbs_cross_border_master.waive_chg1 = 'Y' THEN
            
              l_chg_amt1 := 0;
            
            ELSE
            
              L_COMM_FEE := (L_COMM_FEE_P *
                            p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
            
              --convert settlement currency commisson fee to casa currency
              l_rate       := NULL;
              l_charge_amt := NULL;
            
              IF NOT cypkss.fn_amt1_to_amt2(p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                                            L_CUST_DRAC_CCY,
                                            L_COMM_FEE,
                                            L_EXCH_RATE,
                                            'Y',
                                            l_chg_amt1,
                                            p_Err_Params) THEN
                debug.pr_debug('**', 'In When Others of EX RATE.');
                debug.pr_debug('**', SQLERRM);
                p_err_code   := 'ST-OTHR-001';
                p_err_params := NULL;
                RETURN FALSE;
              END IF;
            
              dbg('converted charge1-->' || l_chg_amt1);
            
              L_COMM_FEE := l_chg_amt1;
            
              IF L_COMM_FEE > L_COMM_MIN_FEE THEN
              
                l_chg_amt1 := L_COMM_FEE;
              
              ELSE
              
                l_chg_amt1 := L_COMM_MIN_FEE;
              
              END IF;
            END IF;
          
            DBG('l_chg_amt1 IN USD=' || l_chg_amt1);
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt1, l_chg_amt1) THEN
              RETURN FALSE;
            END IF;
          
            --recent changes starts
            l_chg_amt1_in_usd                                      := l_chg_amt1;
            p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT1_IN_USD := l_chg_amt1_in_usd;
            --recent changes ends
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR 1=' ||
                           l_chg_amt1);
          
            p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1 := NVL(l_chg_amt1,
                                                                   0);
          
            p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE := 1; --charge exchange rate
          
            --Charge2
            IF p_ifdcbdft.v_iftbs_cross_border_master.waive_chg2 = 'Y' THEN
            
              l_chg_amt2 := 0;
            
            ELSE
            
              L_COMM_FEE := (L_COMM_FEE_P *
                            p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
            
              /*IF L_COMM_FEE > L_COMM_MIN_FEE THEN
              
                l_chg_amt2 := L_COMM_FEE;
              
              ELSE
              
                l_chg_amt2 := L_COMM_MIN_FEE;
              
              END IF;*/
            
              l_chg_amt2 := L_CABLE_FEE;
            
            END IF;
          
            DBG('l_chg_amt2 IN USD=' || l_chg_amt2);
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt2, l_chg_amt2) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR 2=' ||
                           l_chg_amt2);
          
            --recent changes starts
            l_chg_amt2_in_usd                                      := l_chg_amt2;
            p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT2_IN_USD := l_chg_amt2_in_usd;
            --recent changes ends
          
            p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2 := NVL(l_chg_amt2,
                                                                   0);
          
            --Charge3
            IF P_IFDCBDFT.v_iftbs_cross_border_master.charge_type NOT IN
               ('SHA', 'BEN') THEN
              IF p_ifdcbdft.v_iftbs_cross_border_master.waive_chg3 = 'Y' THEN
              
                l_chg_amt3 := 0;
              
              ELSE
              
                /*L_COMM_FEE := (L_COMM_FEE_P *
                              p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
                
                IF L_COMM_FEE > L_COMM_MIN_FEE THEN
                
                  l_chg_amt3 := L_COMM_FEE;
                
                ELSE
                
                  l_chg_amt3 := L_COMM_MIN_FEE;
                
                END IF;*/
              
                l_chg_amt3 := FN_GET_PARAM_VAL('SWIFT_OTHER_FEE_USD');
              
              END IF;
            
              DBG('l_chg_amt3 IN USD=' || l_chg_amt3);
            
              IF NOT
                  cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt3, l_chg_amt3) THEN
                RETURN FALSE;
              END IF;
            
              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT AFTER ROUNDING FOR 3=' ||
                             l_chg_amt3);
            
              --recent changes starts
              l_chg_amt3_in_usd                                      := l_chg_amt3;
              p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT3_IN_USD := l_chg_amt3_in_usd;
              --recent changes ends
            
              p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3 := NVL(l_chg_amt3,
                                                                     0);
            
            END IF;
          
            p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT := NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1,
                                                                      0) +
                                                                  NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2,
                                                                      0) +
                                                                  NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3,
                                                                      0);
          
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
          
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
            DBG('L_EXCH_RATE=' || L_EXCH_RATE);
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT);
          
            PR_GET_RATES('USD',
                         p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                         L_MID_RATE,
                         L_BUY_RATE,
                         L_SALE_RATE);
          
            DBG('L_SALE_RATE=' || L_SALE_RATE);
            DBG('ROUNDED L_SALE_RATE=' || ROUND(L_SALE_RATE, 2));
          
            IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'EUR' AND
               L_CUST_DRAC_CCY = 'USD' THEN
            
              p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT /
                                                                 --ROUND(
                                                                  L_SALE_RATE;
              --2);
            
            ELSE
            
              p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT /
                                                                 --ROUND(
                                                                  L_SALE_RATE;
              --2);
            
              --p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := L_EXCH_RATE * --p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE *
              --   p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT;
            
            END IF;
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY,
                                   p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                   p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR 1=' ||
                           p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
          
            p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := NVL(p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                                                    0);
          
            p_ifdcbdft.v_iftbs_cross_border_master.NET_TXN_AMT := nvl(p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                                                      0) +
                                                                  nvl(p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT,
                                                                      0);
          
          ELSE
            --here transaction currency is USD/EUR/THB/CNY and account currency is KHR
          
            PR_GET_RATES(global.lcy,
                         p_ifdcbdft.v_iftbs_cross_border_master.DR_ACC_CCY,
                         L_MID_RATE,
                         L_BUY_RATE,
                         L_SALE_RATE);
          
            L_EXCH_RATE := ROUND(1 * L_SALE_RATE, 2);
          
            DBG('L_EXCH_RATE L_EXCH_RATE=' || L_EXCH_RATE);
          
            DBG('INSIDE ACCOUNT CURRENCY - KHR');
          
            IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG1 = 'Y' THEN
            
              l_chg_amt1 := 0;
            
            ELSE
            
              L_COMM_FEE := (L_COMM_FEE_P *
                            p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
            
              DBG('p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE=' ||
                  p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
            
              IF NOT cypkss.fn_amt1_to_amt2(p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                                            GLOBAL.lcy,
                                            L_COMM_FEE,
                                            p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE,
                                            'Y',
                                            L_COMM_CALC_FEE,
                                            p_Err_Params) THEN
                debug.pr_debug('**', 'In When Others of EX RATE.');
                debug.pr_debug('**', SQLERRM);
                p_err_code   := 'ST-OTHR-001';
                p_err_params := NULL;
                RETURN FALSE;
              END IF;
            
              DBG('L_COMM_CALC_FEE=' || L_COMM_CALC_FEE);
              DBG('L_COMM_MIN_FEE=' || L_COMM_MIN_FEE);
            
              IF L_COMM_CALC_FEE /*L_COMM_FEE*/
                 > L_COMM_MIN_FEE THEN
              
                l_chg_amt1 := L_COMM_CALC_FEE; --L_COMM_FEE;
              
              ELSE
              
                l_chg_amt1 := L_COMM_MIN_FEE;
              
              END IF;
            
              --recent changes starts
              l_chg_amt1_in_usd                                      := l_chg_amt1;
              p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT1_IN_USD := l_chg_amt1_in_usd;
              --recent changes ends
            
              --Get Equivalent charge from account currency
              l_chg_amt_in_acc_ccy := L_EXCH_RATE * --(p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE) *
                                      l_chg_amt1;
            
              l_chg_amt1 := l_chg_amt_in_acc_ccy;
            
              DBG('BEFORE ASSIGN=' || L_EXCH_RATE);
            
              p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE := L_EXCH_RATE; --charge exchange rate
            
              DBG('p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE=' ||
                  p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE);
            
            END IF;
          
            DBG('l_chg_amt1 IN KHR=' || l_chg_amt1);
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt1, l_chg_amt1) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE1=' ||
                           l_chg_amt1);
          
            p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1 := NVL(l_chg_amt1,
                                                                   0);
          
            IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG2 = 'Y' THEN
            
              l_chg_amt2 := 0;
            
            ELSE
            
              L_COMM_FEE := (L_COMM_FEE_P *
                            p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
            
              /*IF L_COMM_FEE > L_COMM_MIN_FEE THEN
              
                l_chg_amt2 := L_COMM_FEE;
              
              ELSE
              
                l_chg_amt2 := L_COMM_MIN_FEE;
              
              END IF;*/
            
              l_chg_amt2 := L_CABLE_FEE;
            
              --recent changes starts
              l_chg_amt2_in_usd                                      := l_chg_amt2;
              p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT2_IN_USD := l_chg_amt2_in_usd;
              --recent changes ends
            
              --Get Equivalent charge from account currency
              l_chg_amt_in_acc_ccy := L_EXCH_RATE * --(p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE) *
                                      l_chg_amt2;
            
              l_chg_amt2 := l_chg_amt_in_acc_ccy;
            
              --p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE := L_EXCH_RATE; --charge exchange rate
            
            END IF;
          
            DBG('l_chg_amt2 IN KHR=' || l_chg_amt2);
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt2, l_chg_amt2) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE2=' ||
                           l_chg_amt2);
          
            p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2 := NVL(l_chg_amt2,
                                                                   0);
          
            IF P_IFDCBDFT.v_iftbs_cross_border_master.charge_type NOT IN
               ('SHA', 'BEN') THEN
            
              IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG3 = 'Y' THEN
              
                l_chg_amt3 := 0;
              
              ELSE
              
                --L_COMM_FEE := (L_COMM_FEE_P *
                --           p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
              
                l_chg_amt3 := FN_GET_PARAM_VAL('SWIFT_OTHER_FEE_USD');
              
                dbg('l_chg_amt3=' || l_chg_amt3);
              
                IF NOT cypkss.fn_amt1_to_amt2( --p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                                              GLOBAL.lcy,
                                              L_CUST_DRAC_CCY,
                                              
                                              l_chg_amt3, --L_COMM_FEE,
                                              --p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE,
                                              p_ifdcbdft.v_iftbs_cross_border_master.CHG_EXCH_RATE,
                                              'Y',
                                              L_OTHER_FEE,
                                              p_Err_Params) THEN
                  debug.pr_debug('**', 'In When Others of EX RATE.');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
                END IF;
              
                /*IF L_COMM_CALC_FEE \*L_COMM_FEE*\
                   > L_COMM_MIN_FEE THEN
                
                  l_chg_amt3 := L_COMM_CALC_FEE; -- L_COMM_FEE;
                
                ELSE
                
                  l_chg_amt3 := L_COMM_MIN_FEE;
                
                END IF;*/
              
                --recent changes starts
                l_chg_amt3_in_usd                                      := l_chg_amt3;
                p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT3_IN_USD := l_chg_amt3_in_usd;
                --recent changes ends
              
                l_chg_amt_in_acc_ccy := L_OTHER_FEE;
              
                --Get Equivalent charge from account currency
                --l_chg_amt_in_acc_ccy := L_EXCH_RATE * --(p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE) *
                --                      l_chg_amt3;
              
                l_chg_amt3 := l_chg_amt_in_acc_ccy;
              
              END IF;
            
              DBG('l_chg_amt3 IN KHR=' || l_chg_amt3);
            
              IF NOT
                  cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt3, l_chg_amt3) THEN
                RETURN FALSE;
              END IF;
            
              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE3=' ||
                             l_chg_amt3);
            
              p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3 := NVL(l_chg_amt3,
                                                                     0);
            
            END IF;
          
            p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT := NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1,
                                                                      0) +
                                                                  NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2,
                                                                      0) +
                                                                  NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3,
                                                                      0);
          
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
          
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
            DBG('L_EXCH_RATE=' || L_EXCH_RATE);
            DBG('p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT=' ||
                p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT);
          
            IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY <> 'USD' THEN
            
              PR_GET_RATES('USD',
                           p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                           L_MID_RATE,
                           L_BUY_RATE,
                           L_SALE_RATE);
            
              DBG('L_SALE_RATE=' || L_SALE_RATE);
              DBG('ROUNDED L_SALE_RATE=' || ROUND(L_SALE_RATE, 2));
            
              p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := L_EXCH_RATE * --p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE *
                                                                  p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT /
                                                                  ROUND(L_SALE_RATE,
                                                                        2);
            
            ELSE
            
              PR_GET_RATES(p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY,
                           L_CUST_DRAC_CCY,
                           L_MID_RATE,
                           L_BUY_RATE,
                           L_SALE_RATE);
            
              DBG('L_SALE_RATE=' || L_SALE_RATE);
              DBG('ROUNDED L_SALE_RATE=' || ROUND(L_SALE_RATE, 2));
            
              p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT *
                                                                  ROUND(L_SALE_RATE,
                                                                        2);
            
            END IF;
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY,
                                   p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                   p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR 1=' ||
                           p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
          
            p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := NVL(p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                                                    0);
          
            p_ifdcbdft.v_iftbs_cross_border_master.NET_TXN_AMT := nvl(p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                                                      0) +
                                                                  nvl(p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT,
                                                                      0);
          
          END IF;
        
        ELSE
          --TXN USD AND CASA USD
          DBG('INSIDE ELSE CONDITION');
        
          --charge1
          IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG1 = 'Y' THEN
          
            l_chg_amt1 := 0;
          
          ELSE
          
            --IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' AND
            --   L_CUST_DRAC_CCY = 'USD' THEN
          
            --L_COMM_FEE := (L_COMM_FEE_P * l_txn_amt) / 100;
          
            --ELSE
          
            DBG('INSIDE ELSE');
          
            DBG('l_txn_amt=' || l_txn_amt);
          
            L_COMM_FEE := (L_COMM_FEE_P *
                          p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT) / 100;
          
            DBG('L_COMM_FEE=' || L_COMM_FEE);
          
            L_COMM_MIN_FEE := L_COMM_MIN_FEE *
                              p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE; --G_SALE_RATE;
          
            DBG('L_COMM_MIN_FEE=' || L_COMM_MIN_FEE);
          
            --END IF;
          
            IF L_COMM_FEE > L_COMM_MIN_FEE THEN
            
              l_chg_amt1 := L_COMM_FEE;
            
            ELSE
            
              l_chg_amt1 := L_COMM_MIN_FEE;
            
            END IF;
          
          END IF;
        
          DBG('l_chg_amt IN USD=' || l_chg_amt1);
        
          --recent changes starts
          l_chg_amt1_in_usd                                      := l_chg_amt1;
          p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT1_IN_USD := l_chg_amt1_in_usd;
          --recent changes ends
        
          IF NOT cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt1, l_chg_amt1) THEN
            RETURN FALSE;
          END IF;
        
          DEBUG.PR_DEBUG('AC',
                         'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE1=' ||
                         l_chg_amt1);
        
          p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1 := NVL(l_chg_amt1,
                                                                 0);
        
          --charge 2
          IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG2 = 'Y' THEN
          
            l_chg_amt2 := 0;
          
          ELSE
          
            --IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' AND
            --   L_CUST_DRAC_CCY = 'USD' THEN
          
            l_chg_amt2 := FN_GET_PARAM_VAL('SWIFT_TELEX_FEE_USD');
          
            --ELSE
          
            --  DBG('INSIDE ELSE');
          
            --  l_chg_amt2 := l_chg_amt2 * G_SALE_RATE;
          
            DBG('l_chg_amt2=' || l_chg_amt2);
          
            --END IF;
          
          END IF;
        
          DBG('l_chg_amt2 IN USD=' || l_chg_amt2);
        
          --recent changes starts
          l_chg_amt2_in_usd                                      := l_chg_amt2;
          p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT2_IN_USD := l_chg_amt2_in_usd;
          --recent changes ends
        
          IF NOT cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt2, l_chg_amt2) THEN
            RETURN FALSE;
          END IF;
        
          DEBUG.PR_DEBUG('AC',
                         'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE2 1=' ||
                         l_chg_amt2);
        
          p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2 := NVL(l_chg_amt2,
                                                                 0);
        
          --charge3
          IF p_ifdcbdft.v_iftbs_cross_border_master.charge_type NOT IN
             ('BEN', 'SHA') THEN
            IF p_ifdcbdft.v_iftbs_cross_border_master.WAIVE_CHG3 = 'Y' THEN
            
              l_chg_amt3 := 0;
            
            ELSE
            
              --IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' AND
              --   L_CUST_DRAC_CCY = 'USD' THEN
            
              l_chg_amt3 := FN_GET_PARAM_VAL('SWIFT_OTHER_FEE_USD');
            
              --ELSE
            
              --  DBG('INSIDE ELSE');
            
              -- l_chg_amt3 := l_chg_amt3 * G_SALE_RATE;
            
              DBG('l_chg_amt3=' || l_chg_amt3);
            
              --END IF;
            
            END IF;
          
            DBG('l_chg_amt3 IN USD=' || l_chg_amt3);
          
            --recent changes starts
            l_chg_amt3_in_usd                                      := l_chg_amt3;
            p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT3_IN_USD := l_chg_amt3_in_usd;
            --recent changes ends
          
            IF NOT
                cypks.fn_amt_round(L_CUST_DRAC_CCY, l_chg_amt3, l_chg_amt3) THEN
              RETURN FALSE;
            END IF;
          
            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR CHARGE3=' ||
                           l_chg_amt3);
          
            p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3 := NVL(l_chg_amt3,
                                                                   0);
          END IF;
        
          p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT := NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt1,
                                                                    0) +
                                                                NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt2,
                                                                    0) +
                                                                NVL(p_ifdcbdft.v_iftbs_cross_border_master.chg_amt3,
                                                                    0);
        
          DBG('p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT=' ||
              p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
        
          DBG('p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE=' ||
              p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
          DBG('L_EXCH_RATE=' || L_EXCH_RATE);
          DBG('p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT=' ||
              p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT);
        
          p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT := L_EXCH_RATE * --p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE *
                                                              p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT;
        
          p_ifdcbdft.v_iftbs_cross_border_master.NET_TXN_AMT := nvl(p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT,
                                                                    0) +
                                                                nvl(p_ifdcbdft.v_iftbs_cross_border_master.TOT_CHG_AMT,
                                                                    0);
        
        END IF;
      
      END IF;
      --Charge Calculation Ends
    
      --p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE := L_EXCH_RATE;
    
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
      
        L_FORMATTED_MSG := FN_RETURN_FMT_AML_TOKEN;
      
        DBG('FORMATTED AML TOKEN REQUEST=' || L_FORMATTED_MSG);
      
        --Log the request
        L_GEN_SEQ_NO := FN_RETURN_LOG_SEQ_NO;
      
        PR_INSERT_SWIFT_WS_LOG(L_GEN_SEQ_NO,
                               p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                               SYSTIMESTAMP,
                               'T',
                               L_FORMATTED_MSG,
                               'Get AML Token');
      
        IF NOT FN_AML_WEBSERVICE_CALL('T', L_FORMATTED_MSG, NULL, L_IN_RESP) THEN
        
          DBG('FAILED IN CALLING THE GET AML TOKEN API');
        
          P_ERR_CODE := 'IF-AMLPG-09';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        
          RETURN FALSE;
        
        ELSE
        
          DBG('RESPONSE OF GETTOEN=' || L_IN_RESP);
        
          --Get JSON in XML
          L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
          DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
        
          L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
          DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
        
          L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
          DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
        
          DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
              L_RESP_IN_XML);
        
          P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
        
          L_AML_TOKEN_KEY := P_DOCUMENT_XML.EXTRACT('/root/access_token/text()')
                             .GETSTRINGVAL;
        
          DBG('L_AML_TOKEN_KEY =' || L_AML_TOKEN_KEY);
        
          IF L_AML_TOKEN_KEY IS NOT NULL THEN
          
            DBG('SUCCESS IN GETTING THE TOKEN');
          
            --Update webservice call
            PR_UPDATE_SWIFT_WS_LOG(p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                                   L_GEN_SEQ_NO,
                                   NULL,
                                   NULL,
                                   NULL,
                                   L_AML_TOKEN_KEY,
                                   NULL,
                                   L_IN_RESP);
          
            L_FORMATTED_MSG := FN_RETURN_FMT_TXN_REALTIME_SCREEN(p_ifdcbdft);
          
            DBG('FORMATTED AML TXN STATUS REQUEST=' || L_FORMATTED_MSG);
          
            --Log the request
            L_GEN_SEQ_NO := FN_RETURN_LOG_SEQ_NO;
          
            PR_INSERT_SWIFT_WS_LOG(L_GEN_SEQ_NO,
                                   p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                                   SYSTIMESTAMP,
                                   'A',
                                   L_FORMATTED_MSG,
                                   'AML Txn Screen');
          
            --call screening
            IF NOT FN_AML_WEBSERVICE_CALL('A',
                                          L_FORMATTED_MSG,
                                          L_AML_TOKEN_KEY,
                                          L_IN_RESP) THEN
            
              DBG('FAILED IN CALLING THE AML TXN SCREENING API');
            
              P_ERR_CODE := 'IF-AMLPG-10';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            
              RETURN FALSE;
            
            ELSE
            
              DBG('RESPONSE OF AML TXN SCREENING API=' || L_IN_RESP);
            
              --Get JSON in XML
              L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
              DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
            
              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
              DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' ||
                  L_RESP_IN_XML);
            
              L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
              DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' ||
                  L_RESP_IN_XML);
            
              DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
                  L_RESP_IN_XML);
            
              P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
            
              L_MATCH_STATUS := P_DOCUMENT_XML.EXTRACT('/root/MatchStatus/text()')
                                .GETSTRINGVAL;
            
              L_WHITELIST_STATUS := P_DOCUMENT_XML.EXTRACT('/root/WhitelistStatus/text()')
                                    .GETSTRINGVAL;
            
              L_TXN_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/TxnScreeningNo/text()')
                               .GETSTRINGVAL;
            
              DBG('L_TXN_SCAN_ID =' || L_TXN_SCAN_ID);
            
              IF L_TXN_SCAN_ID IS NOT NULL THEN
              
                DBG('SUCCESS IN CALLING AML TXN SCREENING');
              
                p_ifdcbdft.v_iftbs_cross_border_master.txn_scan_id := L_TXN_SCAN_ID;
              
                --Update webservice call
                PR_UPDATE_SWIFT_WS_LOG(p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                                       L_GEN_SEQ_NO,
                                       L_MATCH_STATUS,
                                       L_WHITELIST_STATUS,
                                       NULL,
                                       L_AML_TOKEN_KEY,
                                       L_TXN_SCAN_ID,
                                       L_IN_RESP);
              
              ELSE
              
                DBG('FAILED IN CALLING AML TXN SCREENING');
              
                P_ERR_CODE := 'IF-AMLPG-10';
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          ELSE
          
            DBG('FAILED IN GETTING THE TOKEN');
          
            P_ERR_CODE := 'IF-AMLPG-09';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;
  
    IF p_Action_Code = 'AUTH' THEN
    
      --Get AML Status
      BEGIN
        SELECT *
          INTO L_STTB_CORAL_SWIFT_WS_LOG
          FROM STTB_CORAL_SWIFT_WS_LOG A
         WHERE RELATED_REF_NO =
               P_IFDCBDFT.v_iftbs_cross_border_master.RELATED_REF_NO
           AND SCAN_ID IN (SELECT MAX(SCAN_ID)
                             FROM STTB_CORAL_SWIFT_WS_LOG
                            WHERE RELATED_REF_NO =
                                  P_IFDCBDFT.v_iftbs_cross_border_master.RELATED_REF_NO
                              AND REQ_TYPE = 'A');
      
      EXCEPTION
        WHEN OTHERS THEN
          L_STTB_CORAL_SWIFT_WS_LOG := NULL;
      END;
    
      DBG('L_STTB_CORAL_SWIFT_WS_LOG.MATCH_STATUS=' ||
          L_STTB_CORAL_SWIFT_WS_LOG.MATCH_STATUS);
      DBG('L_STTB_CORAL_SWIFT_WS_LOG.WHITELIST_STATUS=' ||
          L_STTB_CORAL_SWIFT_WS_LOG.WHITELIST_STATUS);
    
      IF L_STTB_CORAL_SWIFT_WS_LOG.SCAN_ID IS NOT NULL AND
         (L_STTB_CORAL_SWIFT_WS_LOG.MATCH_STATUS = 'T' OR
         L_STTB_CORAL_SWIFT_WS_LOG.WHITELIST_STATUS = 'T') THEN
      
        L_FORMATTED_MSG := FN_RETURN_FMT_AML_TXN_STATUS(P_IFDCBDFT);
      
        DBG('FORMATTED AML STATUS REQUEST=' || L_FORMATTED_MSG);
      
        --Log the request
        L_GEN_SEQ_NO := FN_RETURN_LOG_SEQ_NO;
      
        PR_INSERT_SWIFT_WS_LOG(L_GEN_SEQ_NO,
                               p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                               SYSTIMESTAMP,
                               'C',
                               L_FORMATTED_MSG,
                               'Get AML Txn Status');
      
        IF NOT FN_AML_WEBSERVICE_CALL('C', L_FORMATTED_MSG, NULL, L_IN_RESP) THEN
        
          DBG('FAILED IN CALLING THE GET AML TXN STATUS API');
        
          P_ERR_CODE := 'IF-AMLPG-08';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        
          RETURN FALSE;
        
        ELSE
        
          DBG('RESPONSE OF GET STATUS=' || L_IN_RESP);
        
          --Get JSON in XML
          L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(L_IN_RESP);
          DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
        
          L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
          DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
        
          L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;;', '>');
          DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
        
          DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' ||
              L_RESP_IN_XML);
        
          P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
        
          L_APPROVAL_STATUS := P_DOCUMENT_XML.EXTRACT('/root/ApprovalStatus/text()')
                               .GETSTRINGVAL;
        
          DBG('L_APPROVAL_STATUS =' || L_APPROVAL_STATUS);
        
          IF L_APPROVAL_STATUS IS NOT NULL THEN
          
            PR_UPDATE_SWIFT_WS_LOG(p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO,
                                   L_GEN_SEQ_NO,
                                   NULL,
                                   NULL,
                                   L_APPROVAL_STATUS,
                                   NULL,
                                   NULL,
                                   L_IN_RESP);
          
            IF L_APPROVAL_STATUS IN ('R', 'REJECTED') THEN
              P_ERR_CODE   := 'IF-AMLPG-06';
              P_ERR_PARAMS := L_STTB_CORAL_SWIFT_WS_LOG.SCAN_ID;
              Pr_Log_Error('IFDCBDFT',
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
          
            /*IF L_APPROVAL_STATUS IN ('P', 'PENDING') THEN
              P_ERR_CODE := 'IF-AMLPG-07';
              P_ERR_PARAMS := L_STTB_CORAL_SWIFT_WS_LOG.SCAN_ID;
              Pr_Log_Error('IFDCBDFT', 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;*/
          
          ELSE
          
            DBG('FAILED IN GET STATUS API CALL');
          
            P_ERR_CODE := 'IF-AMLPG-08';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
      END IF;
    
      --call ws
      L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSRTService">
   <soapenv:Header/>
   <soapenv:Body>
      <fcub:CREATETRANSACTION_FSFS_REQ>
         <fcub:FCUBS_HEADER>
            <fcub:SOURCE>OBPAY</fcub:SOURCE>
            <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>
            <fcub:MSGID></fcub:MSGID>
            <fcub:CORRELID></fcub:CORRELID>
            <fcub:USERID>OBPAYUSER</fcub:USERID>
            <fcub:ENTITY></fcub:ENTITY>
            <fcub:BRANCH>' || GLOBAL.current_branch ||
               '</fcub:BRANCH>
            <fcub:MODULEID></fcub:MODULEID>
            <fcub:SERVICE>FCUBSRTService</fcub:SERVICE>
            <fcub:OPERATION>CreateTransaction</fcub:OPERATION>
         </fcub:FCUBS_HEADER>
         <fcub:FCUBS_BODY>
            <fcub:Transaction-Details>
               <fcub:XREF>$L_XREF</fcub:XREF>
               <fcub:FCCREF></fcub:FCCREF>
               <fcub:PRD>SOTT</fcub:PRD>
               <fcub:ESN></fcub:ESN>
               <fcub:EVNTCD></fcub:EVNTCD>
               <fcub:BRN>BRN</fcub:BRN>
               <fcub:MODULE></fcub:MODULE>
               <fcub:TXNBRN>991</fcub:TXNBRN>
               <fcub:TXNACC>$L_SETTLEMENT_ACC</fcub:TXNACC>
               <fcub:TXNCCY>$L_SETTLEMENT_CCY</fcub:TXNCCY>
               <fcub:TXNAMT>$L_TXN_AMT</fcub:TXNAMT>
               <fcub:TXNTRN></fcub:TXNTRN>
               <fcub:CREDITCARDNO></fcub:CREDITCARDNO>
               <fcub:CC_HOLDER_NAME></fcub:CC_HOLDER_NAME>
               <fcub:OFFSETBRN>$L_BRN</fcub:OFFSETBRN>
               <fcub:OFFSETACC>$L_CUST_DRAC_NO</fcub:OFFSETACC>
               <fcub:OFFSETCCY>$L_CUST_DRAC_CCY</fcub:OFFSETCCY>
               <fcub:OFFSETAMT>$L_DEBIT_AMT</fcub:OFFSETAMT>
               <fcub:XRATE>$L_EXCH_RATE</fcub:XRATE>
               <fcub:SDBREFNO></fcub:SDBREFNO>
               <fcub:Charge-Details>
                  <fcub:CHGCOMP>COMMISSION FEE</fcub:CHGCOMP>
                  <fcub:WAIVER></fcub:WAIVER>
                  <fcub:CHGAMT>$L_CHG_AMT1</fcub:CHGAMT>
                  <fcub:CHGCCY>USD</fcub:CHGCCY>
               </fcub:Charge-Details>
               <fcub:Charge-Details>
                  <fcub:CHGCOMP>TELEX FEE</fcub:CHGCOMP>
                  <fcub:WAIVER></fcub:WAIVER>
                  <fcub:CHGAMT>$L_CHG_AMT2</fcub:CHGAMT>
                  <fcub:CHGCCY>USD</fcub:CHGCCY>
               </fcub:Charge-Details>
               <fcub:Charge-Details>
                  <fcub:CHGCOMP>OTHER COMMISSION FEE</fcub:CHGCOMP>
                  <fcub:WAIVER></fcub:WAIVER>
                  <fcub:CHGAMT>$L_CHG_AMT3</fcub:CHGAMT>
                  <fcub:CHGCCY>USD</fcub:CHGCCY>
               </fcub:Charge-Details>
               
               <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_BEN_BANK_NAME</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_BEN_BANK_NAME</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
              
               <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_BEN_BANK_BIC</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_BEN_BANK_BIC</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
               
                <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_BEN_NAME</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_BEN_NAME</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
                <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_BEN_ACC</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_BEN_ACC</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
               <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_BEN_ADDRESS</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_BEN_ADDRESS</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
               <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>SOTT_TRANSFER_TYPE</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_TRANSFER_TYPE</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
               
               <fcub:Udf-Details>
                  <fcub:FUNCTIONID>SOTT</fcub:FUNCTIONID>
                  <fcub:FIELD_NAME>REQUESTORS_BRANCH_SWIFT</fcub:FIELD_NAME>
                  <fcub:FIELD_VALUE>$L_REQUESTOR_BRANCH</fcub:FIELD_VALUE>
               </fcub:Udf-Details>
         
               <fcub:NARRATIVE>$L_NARRATIVE</fcub:NARRATIVE>
               
            </fcub:Transaction-Details>
         </fcub:FCUBS_BODY>
      </fcub:CREATETRANSACTION_FSFS_REQ>
   </soapenv:Body>
</soapenv:Envelope>';
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.txn_ccy = 'USD' THEN
      
        BEGIN
        
          SELECT A.PARAM_VAL
            INTO L_SETTLEMENT_ACC
            FROM CSTB_PARAM_CUSTOM A
           WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_USD';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_SETTLEMENT_ACC := '000021058';
        END;
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.txn_ccy = 'EUR' THEN
      
        BEGIN
        
          SELECT A.PARAM_VAL
            INTO L_SETTLEMENT_ACC
            FROM CSTB_PARAM_CUSTOM A
           WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_EUR';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_SETTLEMENT_ACC := '000168588';
        END;
      
      ELSIF p_ifdcbdft.v_iftbs_cross_border_master.txn_ccy = 'THB' THEN
      
        BEGIN
        
          SELECT A.PARAM_VAL
            INTO L_SETTLEMENT_ACC
            FROM CSTB_PARAM_CUSTOM A
           WHERE A.PARAM_NAME = 'SWIFT_TXN_ACC_THB';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_SETTLEMENT_ACC := '000168577';
        END;
      
      END IF;
    
      --L_XML := REPLACE(L_XML, '$L_BRANCH_CODE', L_CUST_ACCOUNT.BRANCH_CODE);
    
      L_XREF := FN_RETURN_SEQ_NO;
    
      L_XML := REPLACE(L_XML, '$L_XREF', L_XREF);
    
      L_XML := REPLACE(L_XML,
                       '$L_CUST_DRAC_NO',
                       p_ifdcbdft.v_iftbs_cross_border_master.rem_acc);
    
      BEGIN
      
        SELECT A.CUST_AC_CCY
          INTO L_CUST_DRAC_CCY
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO =
               p_ifdcbdft.v_iftbs_cross_border_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_DRAC_CCY := NULL;
      END;
    
      DBG('L_CUST_DRAC_CCY=' || L_CUST_DRAC_CCY);
    
      L_XML := REPLACE(L_XML, '$L_CUST_DRAC_CCY', L_CUST_DRAC_CCY);
    
      BEGIN
      
        SELECT A.SOURCE_SYSTEM_ACC_BRN
          INTO L_BRN
          FROM STTM_CORE_ACCOUNT A
         WHERE A.CUST_ACCOUNT_NO =
               p_ifdcbdft.v_iftbs_cross_border_master.rem_acc;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_BRN := NULL;
      END;
    
      DBG('L_BRN=' || L_BRN);
    
      L_XML := REPLACE(L_XML, '$L_BRN', L_BRN);
    
      L_XML := REPLACE(L_XML,
                       '$L_TXN_AMT',
                       p_ifdcbdft.v_iftbs_cross_border_master.TXN_AMT);
    
      L_XML := REPLACE(L_XML, '$L_SETTLEMENT_ACC', L_SETTLEMENT_ACC);
    
      L_XML := REPLACE(L_XML,
                       '$L_DEBIT_AMT',
                       p_ifdcbdft.v_iftbs_cross_border_master.DR_AMOUNT);
    
      IF p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY = 'USD' THEN
      
        L_XML := REPLACE(L_XML,
                         '$L_EXCH_RATE',
                         p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
      ELSE
      
        L_XML := REPLACE(L_XML, '$L_EXCH_RATE', NULL);
      
      END IF;
    
      L_XML := REPLACE(L_XML,
                       '$L_SETTLEMENT_CCY',
                       p_ifdcbdft.v_iftbs_cross_border_master.TXN_CCY);
    
      L_XML := REPLACE(L_XML,
                       '$L_CHG_AMT1',
                       p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT1_IN_USD);
      --p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT1);
    
      L_XML := REPLACE(L_XML,
                       '$L_CHG_AMT2',
                       p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT2_IN_USD);
      --p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT2);
    
      L_XML := REPLACE(L_XML,
                       '$L_CHG_AMT3',
                       NVL(p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT3_IN_USD,
                           0));
      --NVL(p_ifdcbdft.v_iftbs_cross_border_master.CHG_AMT3,
      --0));
    
      --L_XML := REPLACE(L_XML, '$L_CHG_CCY', L_CUST_DRAC_CCY);
    
      L_XML := REPLACE(L_XML,
                       '$L_REQUESTORS_BRANCH',
                       p_ifdcbdft.v_iftbs_cross_border_master.REQUESTOR_BRANCH);
      L_XML := REPLACE(L_XML,
                       '$L_EXCHANGE_RATE',
                       p_ifdcbdft.v_iftbs_cross_border_master.EXCH_RATE);
    
      L_XML := REPLACE(L_XML,
                       '$L_BEN_BANK_NAME',
                       p_ifdcbdft.v_iftbs_cross_border_master.BANK_NAME);
    
      L_XML := REPLACE(L_XML,
                       '$L_BEN_BANK_BIC',
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_BIC);
    
      L_XML := REPLACE(L_XML,
                       '$L_BEN_ACC',
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_ACC);
    
      L_XML := REPLACE(L_XML,
                       '$L_BEN_NAME',
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_NAME);
    
      L_XML := REPLACE(L_XML,
                       '$L_BEN_ADDRESS',
                       'apple' ||
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_ADD1 ||
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_ADD2 ||
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_ADD3 ||
                       p_ifdcbdft.v_iftbs_cross_border_master.BEN_ADD4);
    
      L_XML := REPLACE(L_XML,
                       '$L_TRANSFER_TYPE',
                       p_ifdcbdft.v_iftbs_cross_border_master.TRANSFER_TYPE);
    
      L_XML := REPLACE(L_XML,
                       '$L_REQUESTOR_BRANCH',
                       p_ifdcbdft.v_iftbs_cross_border_master.requestor_branch);
    
      L_XML := REPLACE(L_XML,
                       '$L_NARRATIVE',
                       p_ifdcbdft.v_iftbs_cross_border_master.PURPOSE_OF_TRF);
    
      DBG('Final Request xml=' || L_XML);
    
      L_RESPONSE := process_http('http://10.80.80.109:8001/' || --Need to change when move to production
                                 'FCUBSRTService/FCUBSRTService',
                                 L_XML,
                                 'text/xml;charset=utf-8');
    
      DBG('L_RESPONSE=' || L_RESPONSE);
    
      --Get Cosmetic XML
      PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
    
      DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
    
      P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
    
      --Check if returned error or success
      L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                      .GETSTRINGVAL;
    
      IF L_STATUS_MSG <> 'SUCCESS' THEN
      
        DBG('INSIDE FAILED');
      
        p_Err_Code := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/ECODE/text()')
                      .GETSTRINGVAL;
      
        p_Err_Params := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                        .GETSTRINGVAL;
      
        DBG('p_Err_Code=' || p_Err_Code);
        DBG('p_Err_Params=' || p_Err_Params);
      
        Pr_Log_Error(p_Function_id, p_Source, 'IF-SWIFT-05', p_Err_Params);
      
        RETURN FALSE;
      
      ELSE
      
        L_TRN_REF_NO := P_DOCUMENT_XML.EXTRACT('/CREATETRANSACTION_FSFS_RES/FCUBS_BODY/Transaction-Details/FCCREF/text()')
                        .GETSTRINGVAL;
      
        DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
      
        p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO := L_XREF; --L_TRN_REF_NO;
      
        DBG('p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO=' ||
            p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO);
      
        --File Name
        L_FILE_NAME := p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO ||
                       REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'), ':');
      
        L_SWIFT_HDR_MSG := FN_GEN_SWIFT_HEADER(p_ifdcbdft,
                                               CASE
                                                p_ifdcbdft.v_iftbs_cross_border_master.TRANSFER_TYPE
                                                 WHEN 'C' THEN
                                                  '103'
                                                 WHEN 'B' THEN
                                                  '202'
                                               END,
                                               p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO,
                                               p_ifdcbdft.v_iftbs_cross_border_master.ben_bic);
      
        /*IF L_SWIFT_HDR_MSG IS NULL THEN
          
        --Throw an error
          
        END IF;*/
      
        DBG('L_SWIFT_HDR_MSG=' || L_SWIFT_HDR_MSG);
      
        L_SWIFT_BDY_MSG := FN_GEN_SWIFT_BODY(P_IFDCBDFT);
      
        /*IF L_SWIFT_BDY_MSG IS NULL THEN
          
        --Throw an error
          
        END IF;*/
      
        L_SWIFT_FTR_MSG := FN_GEN_SWIFT_FOOTER(P_IFDCBDFT,
                                               L_SWIFT_HDR_MSG ||
                                               L_SWIFT_BDY_MSG);
      
        /*IF L_SWIFT_FTR_MSG IS NULL THEN
          
        --Throw an error
          
        END IF;*/
      
        L_RESP_CLOB := L_RESP_CLOB || L_SWIFT_HDR_MSG || L_SWIFT_BDY_MSG; -- ||
        --chr(10) || L_SWIFT_FTR_MSG;
      
        --check if file is already generated
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM IFTB_CROSS_BORDER_MESSAGES A
           WHERE A.RELATED_REF_NO =
                 p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        DBG('L_COUNT=' || L_COUNT);
      
        IF L_COUNT = 0 THEN
        
          --Messaging handoff table
          BEGIN
            INSERT INTO IFTB_CROSS_BORDER_MESSAGES
              (RELATED_REF_NO, MSG_TYPE, MSG_STATUS, MESSAGE)
            VALUES
              (P_IFDCBDFT.V_IFTBS_CROSS_BORDER_MASTER.RELATED_REF_NO,
               CASE P_IFDCBDFT.V_IFTBS_CROSS_BORDER_MASTER.TRANSFER_TYPE WHEN 'C' THEN
               'MT103' WHEN 'B' THEN 'MT202' END,
               'G',
               L_RESP_CLOB);
          
            DBG('SQL%ROWCOUNT=' || SQL%ROWCOUNT);
          
            IF SQL%ROWCOUNT = 1 THEN
            
              --Write to output file
              DBG('START OF WRITING CLOB TO AN XML FILE');
            
              PR_GEN_SWIFT_MSG_FILE_GEN('NCS_SDR_OUT_FILE_GEN', --'SWIFT_MSG_OUT_FILE_GEN',
                                        L_FILE_NAME || '.fin',
                                        L_RESP_CLOB);
            
              --Write to Archive Path
              DBG('START OF WRITING CLOB TO AN XML FILE FOR ARCHIVE PATH');
            
              PR_GEN_SWIFT_MSG_FILE_GEN('NCS_SDR_OUT_FILE_GEN_AR', --'SWIFT_MSG_OUT_FILE_GEN_AR',
                                        L_FILE_NAME || '.fin',
                                        L_RESP_CLOB);
            
              DBG('END OF WRITING CLOB TO AN XML FILE');
            
            END IF;
          
          EXCEPTION
            WHEN OTHERS THEN
            
              DBG('FAILED IN INSERTING INTO MESSAGING HANDOFF TABLE');
              utl_file.fremove('NCS_SDR_OUT_FILE_GEN',
                               L_FILE_NAME || '.fin');
              utl_file.fremove('NCS_SDR_OUT_FILE_GEN_AR',
                               L_FILE_NAME || '.fin');
              RETURN FALSE;
            
          END;
        END IF;
      
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'EXECUTEQUERY' /*CSPKS_REQ_GLOBAL.P_COPY*/
     THEN
    
      DBG('INSIDE COPY');
    
      p_ifdcbdft.v_cross_border_messages(1) := NULL;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdcbdft         IN ifpks_ifdcbdft_Main.ty_ifdcbdft,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifdcbdft         IN ifpks_ifdcbdft_Main.ty_ifdcbdft,
                                       p_Prev_ifdcbdft    IN OUT ifpks_ifdcbdft_Main.ty_ifdcbdft,
                                       p_Wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.ty_ifdcbdft,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifdcbdft         IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                                        p_Prev_ifdcbdft    IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                                        p_Wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifdcbdft         IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                            p_Prev_ifdcbdft    IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                            p_Wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifdcbdft         IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                             p_prev_ifdcbdft    IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                             p_wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    IF P_ACTION_CODE = 'AUTH' THEN
      DBG('p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO=' ||
          p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO);
    
      UPDATE IFTB_CROSS_BORDER_MASTER A
         SET A.TRN_REF_NO = p_ifdcbdft.v_iftbs_cross_border_master.TRN_REF_NO
       WHERE A.RELATED_REF_NO =
             p_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO;
    END IF;
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifdcbdft         IN ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                        p_Wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.Ty_ifdcbdft,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
    DBG('p_Wrk_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO=' ||
        p_Wrk_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO);
  
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.p_Query THEN
    
      DBG('INSIDE QUERY');
    
      SELECT *
        BULK COLLECT
        INTO p_Wrk_ifdcbdft.v_cross_border_messages
        FROM IFTB_CROSS_BORDER_MESSAGES A
       WHERE A.RELATED_REF_NO =
             p_Wrk_ifdcbdft.v_iftbs_cross_border_master.RELATED_REF_NO;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifdcbdft_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifdcbdft         IN ifpks_ifdcbdft_Main.ty_ifdcbdft,
                         p_wrk_ifdcbdft     IN OUT ifpks_ifdcbdft_Main.ty_ifdcbdft,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifdcbdft_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifdcbdft_custom;
