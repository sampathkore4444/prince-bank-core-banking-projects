var g_PickupClicked = 0;
var n =0;

function fnPickupReqd(){
	debugs("In fnPickupReqd", "A");
	g_PickupClicked = 0;
	n=0;
	return true;
}

function fnPickup() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	fnDisableElement(document.getElementById("BLK_CBD_MASTER__TXN_CCY"));
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	
	return true;
}

function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");

	if (document.getElementById("BLK_CBD_MASTER__NET_TXN_AMT").value == "" || g_PickupClicked != 1) {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}

/* 
//trigger on transfer_type field but not required now
function fnTransferType(){
	
	debugs("In fnTransferType", "A");
	
	var transfer_type1 = document.getElementsByName("TRANSFER_TYPE")[0];
	var transfer_type2 = document.getElementsByName("TRANSFER_TYPE")[1];

	if(transfer_type1.checked){
		console.log("Inside Customer Type");
		document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").value = null;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").nextSibling.style.visibility="hidden";
		document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_BANK_NAME").value = null;
		document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR1").value = null;
		document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR2").value = null;
		document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR3").value = null;
		
		fnDisableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC"));
		fnDisableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_BANK_NAME"));
		fnDisableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR1"));
		fnDisableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR2"));
		fnDisableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR3"));


		//document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").disabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").nextSibling.style.visibility="hidden";
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_BANK_NAME").disabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR1").disabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR2").disabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR3").disabled = true
	}
	if(transfer_type2.checked){
		console.log("Inside Bank Type");
		fnEnableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC"));
		fnEnableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_BANK_NAME"));
		fnEnableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR1"));
		fnEnableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR2"));
		fnEnableElement(document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR3"));
			
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").enabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIARY_BIC").nextSibling.style.visibility="hidden";
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_BANK_NAME").enabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR1").enabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR2").enabled = true;
		//document.getElementById("BLK_CBD_MASTER__INTERMEDIATORY_ADDR3").enabled = true;
	}

	return true;

}
*/