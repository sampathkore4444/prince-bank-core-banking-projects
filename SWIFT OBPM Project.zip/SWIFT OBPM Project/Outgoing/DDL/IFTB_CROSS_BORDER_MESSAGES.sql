-- Create table
create table IFTB_CROSS_BORDER_MESSAGES
(
  related_ref_no VARCHAR2(20),
  msg_type       VARCHAR2(10),
  msg_status     VARCHAR2(25),
  message        CLOB
)
/
alter table IFTB_CROSS_BORDER_MESSAGES add primary key (RELATED_REF_NO, MSG_TYPE)
/