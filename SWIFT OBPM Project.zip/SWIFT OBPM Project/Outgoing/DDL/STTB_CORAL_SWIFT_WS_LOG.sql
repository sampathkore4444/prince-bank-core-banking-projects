-- Create table
create table STTB_CORAL_SWIFT_WS_LOG
(
  seq_no           VARCHAR2(100),
  related_ref_no   VARCHAR2(20),
  invoke_date      TIMESTAMP(6),
  req_type         VARCHAR2(20),
  req_msg          CLOB,
  res_msg          CLOB,
  match_status     VARCHAR2(3),
  addl_info        VARCHAR2(255),
  token_key        VARCHAR2(2000),
  scan_id          VARCHAR2(105),
  whitelist_status VARCHAR2(3),
  approval_status  VARCHAR2(3)
)
/
alter table STTB_CORAL_SWIFT_WS_LOG add primary key (SEQ_NO)
/