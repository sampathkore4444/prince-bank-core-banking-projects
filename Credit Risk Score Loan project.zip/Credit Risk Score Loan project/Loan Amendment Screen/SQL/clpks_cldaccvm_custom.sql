CREATE OR REPLACE PACKAGE BODY clpks_cldaccvm_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'clpks_cldaccvm_Custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('CL', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;
  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Build_Type_Structure..');
  
    DBG('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Build_Type_Structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  --sampath starts
  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';
  
    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING MID RATE');
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;
  --sampath ends

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                  P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CLTB_LOAN_RISK_SCORE_CUSTOM.LCY_OUTSTANDING%TYPE;
    --sampath ends
  BEGIN
  
    DBG('In Fn_Pre_Check_Mandatory..=' || P_ACTION_CODE);
  
    --sampath starts
    IF P_ACTION_CODE = 'MODIFY' THEN
    
      DBG('P_CLDACCVM.v_loan_risk_score_custom.exposure_type=' ||
          P_CLDACCVM.v_loan_risk_score_custom.exposure_type);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type=' ||
          P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.term_conditions=' ||
          P_CLDACCVM.v_loan_risk_score_custom.term_conditions);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv=' ||
          P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.purchased_prop=' ||
          P_CLDACCVM.v_loan_risk_score_custom.purchased_prop);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.rating_agency=' ||
          P_CLDACCVM.v_loan_risk_score_custom.rating_agency);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.rating_approach=' ||
          P_CLDACCVM.v_loan_risk_score_custom.rating_approach);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.risk_class=' ||
          P_CLDACCVM.v_loan_risk_score_custom.risk_class);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.risk_weight=' ||
          P_CLDACCVM.v_loan_risk_score_custom.risk_weight);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia=' ||
          P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.remark=' ||
          P_CLDACCVM.v_loan_risk_score_custom.remark);
    
      IF P_CLDACCVM.v_cltbs_account_master.currency = 'USD' THEN
      
        L_LCY_OUTSTANDING := P_CLDACCVM.v_cltbs_account_master.AMOUNT_FINANCED *
                             FN_GET_MID_RATE;
      
        P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding := L_LCY_OUTSTANDING;
      END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 OR
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.exposure_type, '*')
        
         AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.purchased_prop, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.rating_agency, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.rating_approach, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.risk_class, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.risk_weight, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.remark, '*') THEN
      
        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 P_CLDACCVM.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         P_CLDACCVM.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         P_CLDACCVM.v_cltbs_account_master.branch_code);
      
        /*  DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM
        WHERE LOAN_ACCOUNT_NUMBER =
              P_CLDACCVM.v_cltbs_account_master.account_number
          AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;*/
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type     = P_CLDACCVM.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type = P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions   = P_CLDACCVM.v_loan_risk_score_custom.term_conditions,
               percentage_ltv    = P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop    = P_CLDACCVM.v_loan_risk_score_custom.purchased_prop,
               
               rating_agency   = P_CLDACCVM.v_loan_risk_score_custom.rating_agency,
               rating_approach = P_CLDACCVM.v_loan_risk_score_custom.rating_approach,
               risk_class      = P_CLDACCVM.v_loan_risk_score_custom.risk_class,
               risk_weight     = P_CLDACCVM.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia,
               lcy_outstanding = P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding,
               remark          = P_CLDACCVM.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             LCY_OUTSTANDING,
             REMARK)
          values
            (P_CLDACCVM.v_cltbs_account_master.account_number,
             P_CLDACCVM.v_cltbs_account_master.branch_code,
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type,
             P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type,
             P_CLDACCVM.v_loan_risk_score_custom.term_conditions,
             P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv,
             P_CLDACCVM.v_loan_risk_score_custom.purchased_prop,
             --P_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd ,
             --P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool ,
             P_CLDACCVM.v_loan_risk_score_custom.rating_agency,
             P_CLDACCVM.v_loan_risk_score_custom.rating_approach,
             P_CLDACCVM.v_loan_risk_score_custom.risk_class,
             P_CLDACCVM.v_loan_risk_score_custom.risk_weight,
             P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia,
             P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding,
             P_CLDACCVM.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
        END;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             P_CLDACCVM.v_cltbs_account_master.account_number
         and a.branch_code = P_CLDACCVM.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     P_CLDACCVM.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     P_CLDACCVM.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;
    
    END IF;
  
    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
          L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
    
      P_CLDACCVM.v_loan_risk_score_custom.exposure_type     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
      P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
      P_CLDACCVM.v_loan_risk_score_custom.term_conditions   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
      P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
      P_CLDACCVM.v_loan_risk_score_custom.purchased_prop    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
      P_CLDACCVM.v_loan_risk_score_custom.rating_agency     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
      P_CLDACCVM.v_loan_risk_score_custom.rating_approach   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
      P_CLDACCVM.v_loan_risk_score_custom.risk_class        := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
      P_CLDACCVM.v_loan_risk_score_custom.risk_weight       := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
      P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
      P_CLDACCVM.v_loan_risk_score_custom.remark            := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
    
    END IF;*/
  
    --sampath ends
  
    DBG('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    DBG('In Fn_Post_Check_Mandatory..');
  
    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Pre_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_RESOLVE_REF_NUMBERS;
  FUNCTION FN_POST_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Post_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of clpks_cldaccvm_Main.Fn_Post_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_RESOLVE_REF_NUMBERS;
  FUNCTION FN_PRE_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Product_Default..');
  
    DBG('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PRODUCT_DEFAULT;

  FUNCTION FN_POST_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Product_Default..');
  
    DBG('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PRODUCT_DEFAULT;

  FUNCTION FN_PRE_UNLOCK(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN OUT VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Unlock..');
  
    DBG('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UNLOCK;

  FUNCTION FN_POST_UNLOCK(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN OUT VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Unlock');
  
    DBG('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UNLOCK;

  FUNCTION FN_PRE_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SUBSYS_PICKUP;

  FUNCTION FN_POST_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SUBSYS_PICKUP;

  FUNCTION FN_PRE_ENRICH(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Enrich..');
  
    DBG('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_ENRICH;

  FUNCTION FN_POST_ENRICH(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Enrich..');
  
    DBG('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_ENRICH;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Upload_Db..=' || P_ACTION_CODE);
  
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Upload_Db..');
  
    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_PROCESS(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CHILD_FUNCTION   IN VARCHAR2,
                          P_MULTI_TRIP_ID    IN VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Process..');
  
    DBG('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PROCESS;

  FUNCTION FN_POST_PROCESS(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_MULTI_TRIP_ID    IN VARCHAR2,
                           P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Process..');
  
    DBG('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PROCESS;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                        P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    --sampath ends
  BEGIN
  
    DBG('In Fn_Pre_Query.. P_ACTION_CODE=' || P_ACTION_CODE);
  
    --sampath starts
    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
      BEGIN
        SELECT *
          INTO            P_WRK_CLDACCVM.v_cltb_restructure_custom
          FROM CLTB_RESTRUCTURE_CUSTOM
         WHERE ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN FN_PRE_QUERY');
          DBG('ERROR CODE IN FN_PRE_QUERY=' || SQLCODE);
          DBG('ERROR MESSAGE IN FN_PRE_QUERY=' || SQLERRM);
      END;
    
      BEGIN
        SELECT *
          BULK COLLECT
          INTO P_WRK_CLDACCVM.v_restructure_link_custom
          FROM CLTB_RESTRUCTURE_LINK_CUSTOM
         WHERE ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN FN_PRE_QUERY');
          DBG('ERROR CODE IN FN_PRE_QUERY=' || SQLCODE);
          DBG('ERROR MESSAGE IN FN_PRE_QUERY=' || SQLERRM);
      END;
    END IF;*/
  
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.exposure_type     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.term_conditions   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.percentage_ltv    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.purchased_prop    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_agency     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_approach   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_class        := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_weight       := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;    
        P_WRK_CLDACCVM.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      END IF;
    
    END IF;
  
    --sampath ends
    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Query');
  
    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

END CLPKS_CLDACCVM_CUSTOM;
