CREATE OR REPLACE FUNCTION FN_GET_PRINCIPAL_OUTSTAND_LCY(P_ACCOUNT_NO   IN CLTB_ACCOUNT_APPS_MASTER.ACCOUNT_NUMBER%TYPE,
                                                         P_BRANCH_CODE  IN CLTB_ACCOUNT_APPS_MASTER.BRANCH_CODE%TYPE,
                                                         P_PRODUCT_CODE IN CLTB_ACCOUNT_APPS_MASTER.PRODUCT_CODE%TYPE,
                                                         P_CCY          IN CLTB_ACCOUNT_APPS_MASTER.CURRENCY%TYPE)
  RETURN NUMBER AS
  L_PRIN_OUTSTANDING_LCY NUMBER := 0;

  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';
  
    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN GETTING MID RATE');
      DEBUG.PR_DEBUG('AC', 'ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DEBUG.PR_DEBUG('AC', 'ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;

BEGIN

  IF P_ACCOUNT_NO IS NOT NULL AND P_BRANCH_CODE IS NOT NULL THEN
  
    IF NOT
        CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(P_ACCOUNT_NO,
                                                 P_BRANCH_CODE,
                                                 P_PRODUCT_CODE,
                                                 L_PRIN_OUTSTANDING_LCY) THEN
      L_PRIN_OUTSTANDING_LCY := 0;
    
    END IF;
  
    DEBUG.PR_DEBUG('AC',
                   'L_PRIN_OUTSTANDING_LCY-- ' || L_PRIN_OUTSTANDING_LCY);
  
    IF P_CCY = 'KHR' THEN
    
      L_PRIN_OUTSTANDING_LCY := L_PRIN_OUTSTANDING_LCY * FN_GET_MID_RATE;
    
      DEBUG.PR_DEBUG('AC',
                     'L_PRIN_OUTSTANDING_LCY=' || L_PRIN_OUTSTANDING_LCY);
    
      IF NOT cypks.fn_amt_round('KHR',
                                L_PRIN_OUTSTANDING_LCY,
                                L_PRIN_OUTSTANDING_LCY) THEN
      
        RETURN L_PRIN_OUTSTANDING_LCY;
      
      ELSE
      
        DEBUG.PR_DEBUG('AC',
                       'AFTER FORMAT L_LCY_OUTSTANDING=' ||
                       L_PRIN_OUTSTANDING_LCY);
      
      END IF;
    
      RETURN L_PRIN_OUTSTANDING_LCY;
    
    ELSE
    
      RETURN L_PRIN_OUTSTANDING_LCY;
    
    END IF;
  
  END IF;

  RETURN L_PRIN_OUTSTANDING_LCY;

EXCEPTION
  WHEN OTHERS THEN
    L_PRIN_OUTSTANDING_LCY := 0;
    RETURN L_PRIN_OUTSTANDING_LCY;
END FN_GET_PRINCIPAL_OUTSTAND_LCY;
