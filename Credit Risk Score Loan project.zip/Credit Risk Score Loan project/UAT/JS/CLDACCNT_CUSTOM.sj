function fnPopulatePurchaseProp(){

console.log("Inside fnPopulatePurchaseProp");

console.log("Exposure Type Value="+document.getElementById("BLK_RISK_SCORE__EXPOSURE_TYPE").value);

if (document.getElementById("BLK_RISK_SCORE__EXPOSURE_TYPE").value == "11_Exposures to Real Estate"){

console.log("Inside if condition");

document.getElementById("BLK_RISK_SCORE__PURCHASED_PROP_USDI").value = 0;

fnDisableElement(document.getElementById("BLK_RISK_SCORE__PURCHASED_PROP_USDI"));

}

}