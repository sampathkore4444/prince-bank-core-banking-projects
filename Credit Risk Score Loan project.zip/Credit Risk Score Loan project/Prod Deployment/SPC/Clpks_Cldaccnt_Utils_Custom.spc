CREATE OR REPLACE PACKAGE Clpks_Cldaccnt_Utils_Custom IS
/*-----------------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2011 - 2014  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
Oracle Financial Services Software Limited.
**
*************************************************************************************************
**   Change Log
**
**   Modified By          : Santosh Sinha
**   Modified On          : 24-Sep-2014
**   Modified Reason      : Extensible changes introduced to handle the below mentioned requirement.
							EHD Ref No :- CDBBRB_12.0.3_02_SEP_2014_01_0000
							When a loan application is made, the borrower provides information on the specific sums required for each segment of the project.
							A unique budget and/or sector code is used to identify each segment. Sum total of amount allocated against each budget line should
							equal amount financed.

							To handle this requirement extensible call is introduced from functions Fn_Save_Account,Fn_Copy_Account,Fn_Delete_Account,Fn_Modify_Account,
							Fn_Hold_Account,Fn_Reverse_Account,Fn_Query
**   Search String        : FCUBS12.0.3->EXTN->CDBBRB;SFR#19619361

Modified By        : Saisudha Rathinavelu
Modified On        : 30-Aug-2017
Modified Reason    : Retro for hook change bug id 26634064.
Search String      : 12.4_RETRO_Bug#26658860

**  Modified By       : Suresh Babu B
**  Modified On       : 20-Sep-2017
**  Modified Reason   : To set clpks_context.g_from_interface for TBOK. Added code to query data from CLTC table.
**  Search String     : [FCUBS12.4_INTERNAL_26789213]
**-------------------------------------------------------------------------------------------------------*/

G_SAVE_CLICKED BOOLEAN := FALSE; --SAMPATH

	--FCUBS12.0.3->EXTN->CDBBRB;SFR#19619361 Start
	FUNCTION fn_pre_save_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_save_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_pre_copy_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_copy_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_pre_delete_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_delete_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_pre_modify_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_modify_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_pre_hold_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data 	    IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_hold_account(p_source         		IN VARCHAR2,
								p_source_operation 		IN VARCHAR2,
								p_function_id      		IN VARCHAR2,
								p_action_code      		IN VARCHAR2,
								p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
								p_fn_call_id       		IN OUT NUMBER,
								p_tb_custom_data		IN OUT NOCOPY global.ty_tb_custom_data,
								p_err_code   			IN OUT VARCHAR2,
								p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_pre_reverse_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION fn_post_reverse_account(p_source         		IN VARCHAR2,
									p_source_operation 		IN VARCHAR2,
									p_function_id      		IN VARCHAR2,
									p_action_code      		IN VARCHAR2,
									p_cldaccnt         		IN OUT NOCOPY clpks_cldaccnt_main.ty_cldaccnt,
									p_fn_call_id       		IN OUT NUMBER,
									p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data,
									p_err_code   			IN OUT VARCHAR2,
									p_err_params			IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION Fn_Pre_Query(p_Source           	IN VARCHAR2
					   ,p_Source_Operation 		IN VARCHAR2
					   ,p_Function_Id      		IN VARCHAR2
					   ,p_Action_Code      		IN VARCHAR2
					   ,p_Cldaccnt         		IN Clpkss_Cldaccnt_Main.Ty_Cldaccnt
					   ,p_Wrk_Cldaccnt     		IN OUT Clpkss_Cldaccnt_Main.Ty_Cldaccnt
					   ,p_fn_call_id       		IN OUT NUMBER
					   ,p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data
					   ,p_Err_Code         		IN OUT VARCHAR2
					   ,p_Err_Params       		IN OUT VARCHAR2) RETURN BOOLEAN;
	FUNCTION Fn_Post_Query(p_Source           	IN VARCHAR2
						   ,p_Source_Operation 		IN VARCHAR2
						   ,p_Function_Id      		IN VARCHAR2
						   ,p_Action_Code      		IN VARCHAR2
						   ,p_Cldaccnt         		IN Clpkss_Cldaccnt_Main.Ty_Cldaccnt
						   ,p_Wrk_Cldaccnt     		IN OUT Clpkss_Cldaccnt_Main.Ty_Cldaccnt
						   ,p_fn_call_id       		IN OUT NUMBER
						   ,p_tb_custom_data 		IN OUT NOCOPY global.ty_tb_custom_data
						   ,p_Err_Code         		IN OUT VARCHAR2
						   ,p_Err_Params       		IN OUT VARCHAR2) RETURN BOOLEAN;
	--FCUBS12.0.3->EXTN->CDBBRB;SFR#19619361 End
--12.4_RETRO_Bug#26658860 Changes starts here
FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2
                              ,p_Source_Operation IN VARCHAR2
                              ,p_Function_Id      IN VARCHAR2
                              ,p_Action_Code      IN VARCHAR2
                              ,p_Child_Function   IN VARCHAR2
                              ,p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL'
                              ,p_Cldaccnt         IN Clpks_Cldaccnt_Main.Ty_Cldaccnt
							  ,p_fn_call_id       IN OUT NUMBER
						      ,p_tb_custom_data   IN OUT NOCOPY global.ty_tb_custom_data
                              ,p_Err_Code         IN OUT VARCHAR2
                              ,p_Err_Params       IN OUT VARCHAR2)
	RETURN BOOLEAN;
--12.4_RETRO_Bug#26658860 Changes ends here
	--[FCUBS12.4_INTERNAL_26789213] starts
	FUNCTION Fn_Query_tanked(p_Source           IN VARCHAR2
						   ,p_Source_Operation IN VARCHAR2
						   ,p_Function_Id      IN VARCHAR2
						   ,p_Action_Code      IN VARCHAR2
						   ,p_With_Lock        IN VARCHAR2 DEFAULT 'N'
						   ,p_Qrydata_Reqd     IN VARCHAR2 DEFAULT 'Y'
						   ,p_Cldaccnt         IN Clpkss_Cldaccnt_Main.Ty_Cldaccnt
						   ,p_Wrk_Cldaccnt     IN OUT Clpkss_Cldaccnt_Main.Ty_Cldaccnt
						   ,p_fn_call_id       IN OUT NUMBER
						   ,p_tb_custom_data   IN OUT NOCOPY global.ty_tb_custom_data
						   ,p_Err_Code         IN OUT VARCHAR2
						   ,p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN;
	--[FCUBS12.4_INTERNAL_26789213] ends

END Clpks_Cldaccnt_Utils_Custom;
