insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '4_Green Project Finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '4_Green Project Finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '130%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '1_Residential Exposure', 'Meet criteria', 'LTV <=50%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '1_Residential Exposure', 'Meet criteria', 'LTV <=60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '40%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Meet criteria', 'LTV <=60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Not meet criteria', '50%< LTV <= 60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '60%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '50%< LTV <= 60%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '70%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '60%< LTV <= 80%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '90%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', 'LTV >80%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '80%< LTV <= 90%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '120%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '90%< LTV <= 100%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '130%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '1_Personal Loan', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '1_Personal Loan', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '2_Leases', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '2_Leases', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '3_Credit card', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '75%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'Unrated', 'SCRA', 'Grade A', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'Unrated', 'SCRA', 'Grade B', '40%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Grade C', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('4_Exposures to Deposit-Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'ECRA', '1', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade A', '40%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade B', '75%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade C', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade D', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '2_National Bank of Cambodia', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '80%< LTV <= 90%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '140%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', 'LTV >100%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to SMEs', '1_Registered SME at MOC', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to SMEs', '1_Registered SME at MOC', 'Meet criteria 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to SMEs', '2_Non-registered SME', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to SMEs', '2_Non-registered SME', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '1_Limited Companies', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '1_Limited Companies', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '2_Partnerships', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '2_Partnerships', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '3_Proprietorships', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '3_Proprietorships', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '4_Association', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '4_Association', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '5_Trusts', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '5_Trusts', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '75%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '6_Funds', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '6_Funds', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '7_Other entities with similar characteristics', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('7_Exposures to Corporates', '7_Other entities with similar characteristics', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '3_Credit card', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '4_All above', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('9_Exposures to Individuals', '4_All above', 'Not meet criteria 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '1_Project finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '130%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '1_Project finance', '2_During the operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '130%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '2_Object finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '2_Object finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '130%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '2_Object finance', '2_During the operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '80%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '3_Commodities finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('10_Exposures to Specialized Lending', '3_Commodities finance', '1_Pre-Operational Phase', null, 'N/A', 'N/A', 'N/A', 'N/A', '130%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '75%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '1_Securities Exchange Company', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '75%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('6_Exposures to Other Financial Institutions', '2_Insurance Company', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '1_Royal Government of Cambodia', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '2_Asian Development Bank (ADB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '3_Sovereigns (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('2_Exposures to Public Sector Entities (PSEs)', 'N/A', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('1_Exposures to Sovereigns and Other Central Bank', '4_Other Central Bank (Oversea)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '1_World Bank Group', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '3_Asian Infrastructure Investment Bank (AIIB)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '4_European Bank for Reconstruction and Development (EBRD)', 'N/A', null, 'N/A', 'N/A', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Standard &Poor''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Moody''s', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '2', '30%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '3', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '4', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', '5', '150%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Fitch Rating', 'ECRA', 'Unrated', '50%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '3', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '4', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '5', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'Unrated', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', 'N/A', '0%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '1', '20%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('3_Exposures to Multilateral Development Banks (MDBs)', '5_others MDB ', 'N/A', null, 'N/A', 'Unrated', 'ECRA', '2', '30%', 'Oversea');

COMMIT;
