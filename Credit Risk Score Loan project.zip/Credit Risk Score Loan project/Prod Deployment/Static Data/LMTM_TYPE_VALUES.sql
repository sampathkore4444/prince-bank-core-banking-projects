insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('RISK_SCORE', 'Loan Credit Risk', 'SAMPATH2', 'SAMPATH2', to_date('01-10-2022', 'dd-mm-yyyy'), to_date('01-10-2022', 'dd-mm-yyyy'), 'O', 'A', '1', 'Y');

COMMIT;
