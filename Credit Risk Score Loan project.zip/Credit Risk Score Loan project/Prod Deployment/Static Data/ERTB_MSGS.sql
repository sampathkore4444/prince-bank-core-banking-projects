insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-001', 'ENG', 'Risk Class Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-002', 'ENG', 'Risk Weight Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-003', 'ENG', 'Sub Exposure Type Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-004', 'ENG', 'Term/Condition Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-005', 'ENG', '% LTV Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-006', 'ENG', 'Purchased Property Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-007', 'ENG', 'Rating Agency Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-008', 'ENG', 'Rating Approach Selection is Wrong. Pls select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-009', 'ENG', 'Purchased Property(USD) Field Can Not Be Null or Zero if Exposure Type - 11_Exposures to Real Estate', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ERTB_MSGS (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-010', 'ENG', 'Purchased Property(USD) Field Must be Zero if Exposure Type is not 11_Exposures to Real Estate', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
