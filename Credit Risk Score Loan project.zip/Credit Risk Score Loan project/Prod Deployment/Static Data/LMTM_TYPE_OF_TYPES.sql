insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('RISK_SCORE', '5_Exposures to Non-Deposit Taking Institutions', null);

COMMIT;
