-- Create table
create table CLTB_LOAN_RISK_SCORE_CUSTOM
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  exposure_type       VARCHAR2(105),
  sub_exposure_type   VARCHAR2(105),
  term_conditions     VARCHAR2(105),
  percentage_ltv      VARCHAR2(105),
  purchased_prop      VARCHAR2(105),
  purchased_prop_usd  NUMBER(24,3),
  rating_agency       VARCHAR2(105),
  rating_approach     VARCHAR2(105),
  risk_class          VARCHAR2(105),
  risk_weight         VARCHAR2(105),
  out_in_cambodia     VARCHAR2(105),
  remark              VARCHAR2(255)
)
/
alter table CLTB_LOAN_RISK_SCORE_CUSTOM add primary key (LOAN_ACCOUNT_NUMBER, BRANCH_CODE)
/
-- Create table
create table STTB_LOAN_RISK_SCORE_CUSTOM
(
  exposure_type     VARCHAR2(255),
  sub_exposure_type VARCHAR2(255),
  term_conditions   VARCHAR2(255),
  percentage_ltv    VARCHAR2(255),
  purchased_prop    VARCHAR2(255),
  rating_agency     VARCHAR2(255),
  rating_approach   VARCHAR2(255),
  risk_class        VARCHAR2(255),
  risk_weight       VARCHAR2(255),
  out_in_cambodia   VARCHAR2(255)
)
/
-- Create table
create table CLTB_LOAN_RISK_SCORE_HIST
(
  loan_account_number VARCHAR2(35),
  branch_code         VARCHAR2(3),
  exposure_type       VARCHAR2(255),
  sub_exposure_type   VARCHAR2(255),
  term_conditions     VARCHAR2(255),
  percentage_ltv      VARCHAR2(255),
  purchased_prop      VARCHAR2(255),
  purchased_prop_usd  NUMBER(24,3),
  rating_agency       VARCHAR2(255),
  rating_approach     VARCHAR2(255),
  risk_class          VARCHAR2(255),
  risk_weight         VARCHAR2(255),
  out_in_cambodia     VARCHAR2(255),
  remark              VARCHAR2(255)
)
/