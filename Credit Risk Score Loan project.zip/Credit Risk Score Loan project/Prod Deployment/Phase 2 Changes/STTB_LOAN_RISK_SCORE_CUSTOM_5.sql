DELETE FROM STTB_LOAN_RISK_SCORE_CUSTOM WHERE EXPOSURE_TYPE = '5_Exposures to Non-Deposit Taking Institutions';

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade A', '20%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade B', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade C', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Short term (Up to 3month)', null, 'N/A', 'N/A', 'SCRA', 'Grade D', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '40%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '75%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '100%', 'Oversea');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('5_Exposures to Non-Deposit Taking Institutions', 'N/A', 'Longer than 3 months', null, 'N/A', 'N/A', 'SCRA', 'Unrated', '150%', 'Oversea');

COMMIT;
