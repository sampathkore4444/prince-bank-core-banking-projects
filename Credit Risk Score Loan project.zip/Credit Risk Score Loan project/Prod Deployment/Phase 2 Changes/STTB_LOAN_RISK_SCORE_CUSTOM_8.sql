DELETE FROM STTB_LOAN_RISK_SCORE_CUSTOM WHERE EXPOSURE_TYPE = '8_Exposures to Micro Small and Medium Enterprise(MSMEs)';

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to Micro Small and Medium Enterprise(MSMEs)', '1_Registered SME at MOC', 'Registered 85%', null, 'N/A', 'N/A', 'N/A', 'N/A', '85%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('8_Exposures to Micro Small and Medium Enterprise(MSMEs)', '2_Non-Registered SME', 'Non-Register 100%', null, 'N/A', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

COMMIT;
