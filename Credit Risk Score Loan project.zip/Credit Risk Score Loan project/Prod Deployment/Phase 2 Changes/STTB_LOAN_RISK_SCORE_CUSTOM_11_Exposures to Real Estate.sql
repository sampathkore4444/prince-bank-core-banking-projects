DELETE FROM STTB_LOAN_RISK_SCORE_CUSTOM WHERE EXPOSURE_TYPE = '11_Exposures to Real Estate';

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '1_Residential Exposure', 'Meet criteria', 'LTV <=50%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '30%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '1_Residential Exposure', 'Meet criteria', 'LTV <=60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '40%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Meet criteria', 'LTV <=60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '50%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Not meet criteria', '50%< LTV <= 60%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '60%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '50%< LTV <= 60%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '70%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '60%< LTV <= 80%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '90%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', 'LTV >80%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '100%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '80%< LTV <= 90%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '120%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '90%< LTV <= 100%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '130%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', '80%< LTV <= 90%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '140%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '3_Land Acquisition, Development & Construction (ADC)', 'Not meet criteria', 'LTV >100%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '150%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Meet criteria', 'LTV >80%', 'Pledged with Bank', 'N/A', 'N/A', 'N/A', '110%', 'Cambodia');

insert into STTB_LOAN_RISK_SCORE_CUSTOM (EXPOSURE_TYPE, SUB_EXPOSURE_TYPE, TERM_CONDITIONS, PERCENTAGE_LTV, PURCHASED_PROP, RATING_AGENCY, RATING_APPROACH, RISK_CLASS, RISK_WEIGHT, OUT_IN_CAMBODIA)
values ('11_Exposures to Real Estate', '2_Commercial Exposure', 'Meet criteria', '60%< LTV <= 80%', 'Not Pledge with Bank', 'N/A', 'N/A', 'N/A', '110%', 'Cambodia');

COMMIT;
