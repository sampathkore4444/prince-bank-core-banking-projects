CREATE OR REPLACE PACKAGE BODY clpks_cldaccnt_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : clpks_cldaccnt_custom.sql
  **
  ** Module     : Retail Lending
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2022 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'clpks_cldaccnt_Custom ==>' || p_Msg;
      Debug.Pr_Debug('CL', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_Type_Structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  --sampath starts
  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';
  
    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING MID RATE');
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;
  --sampath ends

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_cldaccnt         IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory..=' || P_ACTION_CODE);
    DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.SUBSYSTEMSTAT);
  
    IF Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN
      DBG('SAVE CLICKED');
    ELSE
       DBG('SAVE NOT CLICKED');
    END IF;
    --sampath starts
    IF P_ACTION_CODE = 'NEW' /*AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED*/ THEN
    
      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);
    
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                               0);
      END IF;
    
      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);
      
      END IF;
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 /*OR
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.exposure_type, '*')
                                                                                                                  
                                                                                                                           AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.percentage_ltv, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.total_collat_pool, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_agency, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_approach, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_class, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_weight, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.remark, '*')*/
       THEN
      
        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
     /*   --Sub Exposure Type Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
              
           AND SUB_EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Term & Conditions Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
              
           AND term_conditions =
               p_cldaccnt.v_loan_risk_score_custom.term_conditions;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');
        
          RETURN FALSE;
        
        END IF;
      
        --% LTV Validation pls check
      
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type
             AND percentage_ltv =
                 p_cldaccnt.v_loan_risk_score_custom.percentage_ltv;
        
          IF L_COUNT = 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
        --Purchased Property Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND purchased_prop =
               p_cldaccnt.v_loan_risk_score_custom.purchased_prop;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Purchased Property(USD) Field Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
             p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');
          
            RETURN FALSE;
          
          END IF;
        
          --p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;
        
        ELSE
        
          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
        --Rating Agency Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_agency =
               p_cldaccnt.v_loan_risk_score_custom.rating_agency;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Rating Approach Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Risk Class Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach
              
           AND risk_class = p_cldaccnt.v_loan_risk_score_custom.risk_class;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Risk Weight Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '5_Exposures to Non-Deposit Taking Institutions' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
             'Short term (Up to 3month)' THEN
          
            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('40%', '75%', '100%', '150%') THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
            
              RETURN FALSE;
            
            END IF;
          
          ELSIF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
                'Longer than 3 months' THEN
          
            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('20%', '50%', '100%', '150%') THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
            
              RETURN FALSE;
            
            END IF;
          
          END IF;
        
        ELSE
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE ((EXPOSURE_TYPE NOT IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type) OR
                 (EXPOSURE_TYPE IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 TERM_CONDITIONS =
                 p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS))
             AND RISK_WEIGHT =
                 p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT;
        
          IF L_COUNT = 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;*/
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
             
        END;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_cldaccnt         IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of clpks_cldaccnt_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Product_Default..');
  
    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Product_Default..');
  
    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Unlock..');
  
    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Unlock');
  
    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Enrich..');
  
    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Enrich..');
  
    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Process..');
  
    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Prev_cldaccnt    IN clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
   --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
    
  BEGIN
  
    Dbg('In Fn_Post_Process..='||p_Action_Code);
    
    --sampath starts
    
    IF P_ACTION_CODE = 'NEW' AND Clpks_Cldaccnt_Utils_Custom.G_SAVE_CLICKED THEN
    
      DBG('p_cldaccnt.v_loan_risk_score_custom.exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type=' ||
          p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type);
      DBG('p_cldaccnt.v_loan_risk_score_custom.term_conditions=' ||
          p_cldaccnt.v_loan_risk_score_custom.term_conditions);
      DBG('p_cldaccnt.v_loan_risk_score_custom.percentage_ltv=' ||
          p_cldaccnt.v_loan_risk_score_custom.percentage_ltv);
      DBG('p_cldaccnt.v_loan_risk_score_custom.purchased_prop=' ||
          p_cldaccnt.v_loan_risk_score_custom.purchased_prop);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_agency=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_agency);
      DBG('p_cldaccnt.v_loan_risk_score_custom.rating_approach=' ||
          p_cldaccnt.v_loan_risk_score_custom.rating_approach);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_class=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_class);
      DBG('p_cldaccnt.v_loan_risk_score_custom.risk_weight=' ||
          p_cldaccnt.v_loan_risk_score_custom.risk_weight);
      DBG('p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia=' ||
          p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia);
      DBG('p_cldaccnt.v_loan_risk_score_custom.remark=' ||
          p_cldaccnt.v_loan_risk_score_custom.remark);
          
          --Sub Exposure Type Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
              
           AND SUB_EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Term & Conditions Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
              
           AND term_conditions =
               p_cldaccnt.v_loan_risk_score_custom.term_conditions;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');
        
          RETURN FALSE;
        
        END IF;
      
        --% LTV Validation pls check
      
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type
             AND percentage_ltv =
                 p_cldaccnt.v_loan_risk_score_custom.percentage_ltv;
        
          IF L_COUNT = 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
        --Purchased Property Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND purchased_prop =
               p_cldaccnt.v_loan_risk_score_custom.purchased_prop;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Purchased Property(USD) Field Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '11_Exposures to Real Estate' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
             p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');
          
            RETURN FALSE;
          
          END IF;
        
          --p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;
        
        ELSE
        
          IF p_cldaccnt.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
        --Rating Agency Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_agency =
               p_cldaccnt.v_loan_risk_score_custom.rating_agency;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Rating Approach Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Risk Class Validation
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               p_cldaccnt.v_loan_risk_score_custom.exposure_type
           AND rating_approach =
               p_cldaccnt.v_loan_risk_score_custom.rating_approach
              
           AND risk_class = p_cldaccnt.v_loan_risk_score_custom.risk_class;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');
        
          RETURN FALSE;
        
        END IF;
      
        --Risk Weight Validation
        IF p_cldaccnt.v_loan_risk_score_custom.exposure_type =
           '5_Exposures to Non-Deposit Taking Institutions' THEN
        
          IF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
             'Short term (Up to 3month)' THEN
          
            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('40%', '75%', '100%', '150%') THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
            
              RETURN FALSE;
            
            END IF;
          
          ELSIF p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS =
                'Longer than 3 months' THEN
          
            IF p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
               ('20%', '50%', '100%', '150%') THEN
            
              PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
            
              RETURN FALSE;
            
            END IF;
          
          END IF;
        
        ELSE
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTB_LOAN_RISK_SCORE_CUSTOM
           WHERE ((EXPOSURE_TYPE NOT IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 EXPOSURE_TYPE =
                 p_cldaccnt.v_loan_risk_score_custom.exposure_type) OR
                 (EXPOSURE_TYPE IN
                 (select value
                      from lmtm_type_values
                     where type = 'RISK_SCORE') AND
                 TERM_CONDITIONS =
                 p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS))
             AND RISK_WEIGHT =
                 p_cldaccnt.v_loan_risk_score_custom.RISK_WEIGHT;
        
          IF L_COUNT = 0 THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
        
      
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE='||p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
      
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                               0);
      END IF;
    
      IF p_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING,0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);
      
      END IF;
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCNT.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 /*OR
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.exposure_type, '*')
                                                                                                                  
                                                                                                                           AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.percentage_ltv, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.total_collat_pool, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_agency, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.rating_approach, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_class, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.risk_weight, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding, '*') AND
                                                                                                                           NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
                                                                                                                           NVL(p_cldaccnt.v_loan_risk_score_custom.remark, '*')*/
       THEN
      
        INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
          SELECT *
            FROM CLTB_LOAN_RISK_SCORE_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccnt.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccnt.v_cltbs_account_master.branch_code
             AND ROWID =
                 (SELECT MAX(ROWID)
                    FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccnt.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccnt.v_cltbs_account_master.branch_code);
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = p_cldaccnt.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = p_cldaccnt.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24,
               rating_agency   = p_cldaccnt.v_loan_risk_score_custom.rating_agency,
               rating_approach = p_cldaccnt.v_loan_risk_score_custom.rating_approach,
               risk_class      = p_cldaccnt.v_loan_risk_score_custom.risk_class,
               risk_weight     = p_cldaccnt.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25,
               remark = p_cldaccnt.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccnt.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --lcy_outstanding,
             REMARK)
          values
            (p_cldaccnt.v_cltbs_account_master.account_number,
             p_cldaccnt.v_cltbs_account_master.branch_code,
             p_cldaccnt.v_loan_risk_score_custom.exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.sub_exposure_type,
             p_cldaccnt.v_loan_risk_score_custom.term_conditions,
             p_cldaccnt.v_loan_risk_score_custom.percentage_ltv,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop,
             p_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd,
             --p_cldaccnt.v_loan_risk_score_custom.total_collat_pool,
             p_cldaccnt.v_loan_risk_score_custom.rating_agency,
             p_cldaccnt.v_loan_risk_score_custom.rating_approach,
             p_cldaccnt.v_loan_risk_score_custom.risk_class,
             p_cldaccnt.v_loan_risk_score_custom.risk_weight,
             p_cldaccnt.v_loan_risk_score_custom.out_in_cambodia,
             --p_cldaccnt.v_loan_risk_score_custom.lcy_outstanding,
             p_cldaccnt.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
            
        END;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             p_cldaccnt.v_cltbs_account_master.account_number
         and a.branch_code = p_cldaccnt.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     p_cldaccnt.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     p_cldaccnt.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;
    
    END IF;
  
    --sampath ends
    
   
  
    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    --sampath starts
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      --Get Colltaeral Pool Amount
    
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        --p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;
    
      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      END IF;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_cldaccnt         IN clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Wrk_cldaccnt     IN OUT clpks_cldaccnt_Main.Ty_cldaccnt,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    --sampath ends
  
  BEGIN
  
    dbg('In Fn_Post_Query=' || P_ACTION_CODE);
  
    --sampath starts
    IF P_ACTION_CODE IN ('NEW', 'SUBSYSPKP_NEW', 'EXECUTEQUERY') THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               p_cldaccnt.v_cltbs_account_master.account_number
           and a.branch_code =
               p_cldaccnt.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       p_cldaccnt.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       p_cldaccnt.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      DBG('p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID1=' ||
          p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID);
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 p_Wrk_cldaccnt.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      p_Wrk_cldaccnt.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE);
      DBG('p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE=' ||
          p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE);
    
      --LCY Outstanding
      IF p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        p_cldaccnt.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        -- p_Wrk_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23 := NVL(L_OUTSTANDING, 0);
      END IF;
    
      IF p_Wrk_cldaccnt.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := NVL(L_OUTSTANDING, 0) / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('p_cldaccnt.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(p_cldaccnt.V_UI_COLUMNS__TOTAL_PRIN.NUM_FIELD23, 0));
        p_Wrk_cldaccnt.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        p_Wrk_cldaccnt.v_loan_risk_score_custom.exposure_type      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.sub_exposure_type  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.term_conditions    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.percentage_ltv     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --p_Wrk_cldaccnt.v_loan_risk_score_custom.lcy_outstanding    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        p_Wrk_cldaccnt.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      END IF;
    
    END IF;
  
    --sampath ends
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of clpks_cldaccnt_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END clpks_cldaccnt_custom;
