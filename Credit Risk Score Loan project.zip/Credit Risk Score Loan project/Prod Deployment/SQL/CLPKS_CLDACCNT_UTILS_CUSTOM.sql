CREATE OR REPLACE PACKAGE BODY Clpks_Cldaccnt_Utils_Custom IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'Clpkss_Cldaccnt_Utils_Cluster ==>' || P_MSG;
      DEBUG.PR_DEBUG('CL', L_MSG);
    END IF;
  END DBG;
  FUNCTION FN_PRE_SAVE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                               P_SOURCE_OPERATION IN VARCHAR2,
                               P_FUNCTION_ID      IN VARCHAR2,
                               P_ACTION_CODE      IN VARCHAR2,
                               P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                               P_FN_CALL_ID       IN OUT NUMBER,
                               P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    
  DBG('Inside Clpks_Cldaccnt_Utils_Custom.fn_pre_save_account');
  
    G_SAVE_CLICKED := TRUE;
    
    
    
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_save_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SAVE_ACCOUNT;
  FUNCTION FN_POST_SAVE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                P_FN_CALL_ID       IN OUT NUMBER,
                                P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Custom.fn_post_save_account');
    
    --G_SAVE_CLICKED := TRUE;
    
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_save_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SAVE_ACCOUNT;
  FUNCTION FN_PRE_COPY_ACCOUNT(P_SOURCE           IN VARCHAR2,
                               P_SOURCE_OPERATION IN VARCHAR2,
                               P_FUNCTION_ID      IN VARCHAR2,
                               P_ACTION_CODE      IN VARCHAR2,
                               P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                               P_FN_CALL_ID       IN OUT NUMBER,
                               P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_pre_copy_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_copy_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_COPY_ACCOUNT;
  FUNCTION FN_POST_COPY_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                P_FN_CALL_ID       IN OUT NUMBER,
                                P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_post_copy_account');

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_copy_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_COPY_ACCOUNT;
  FUNCTION FN_PRE_DELETE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_FN_CALL_ID       IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_pre_delete_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_delete_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DELETE_ACCOUNT;
  FUNCTION FN_POST_DELETE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_FN_CALL_ID       IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_post_delete_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_delete_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DELETE_ACCOUNT;
  FUNCTION FN_PRE_MODIFY_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                 P_FN_CALL_ID       IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_pre_modify_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_modify_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_MODIFY_ACCOUNT;
  FUNCTION FN_POST_MODIFY_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_FN_CALL_ID       IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_post_modify_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_modify_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_MODIFY_ACCOUNT;
  FUNCTION FN_PRE_HOLD_ACCOUNT(P_SOURCE           IN VARCHAR2,
                               P_SOURCE_OPERATION IN VARCHAR2,
                               P_FUNCTION_ID      IN VARCHAR2,
                               P_ACTION_CODE      IN VARCHAR2,
                               P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                               P_FN_CALL_ID       IN OUT NUMBER,
                               P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_pre_hold_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_hold_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_HOLD_ACCOUNT;
  FUNCTION FN_POST_HOLD_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                P_FN_CALL_ID       IN OUT NUMBER,
                                P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_post_hold_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_hold_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_HOLD_ACCOUNT;
  FUNCTION FN_PRE_REVERSE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                  P_FN_CALL_ID       IN OUT NUMBER,
                                  P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_pre_reverse_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_pre_reverse_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_REVERSE_ACCOUNT;
  FUNCTION FN_POST_REVERSE_ACCOUNT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CLDACCNT         IN OUT NOCOPY CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_FN_CALL_ID       IN OUT NUMBER,
                                   P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.fn_post_reverse_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in fn_post_reverse_account ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_REVERSE_ACCOUNT;
  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CLDACCNT         IN CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                        P_WRK_CLDACCNT     IN OUT CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                        P_FN_CALL_ID       IN OUT NUMBER,
                        P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.Fn_Pre_Query');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Pre_Query ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;
  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CLDACCNT         IN CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                         P_WRK_CLDACCNT     IN OUT CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                         P_FN_CALL_ID       IN OUT NUMBER,
                         P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Cluster.Fn_Post_Query');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Post_Query ' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

  FUNCTION FN_QUERY_TANKED(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                           P_QRYDATA_REQD     IN VARCHAR2 DEFAULT 'Y',
                           P_CLDACCNT         IN CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                           P_WRK_CLDACCNT     IN OUT CLPKSS_CLDACCNT_MAIN.TY_CLDACCNT,
                           P_FN_CALL_ID       IN OUT NUMBER,
                           P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Custom.Fn_Query_tanked');
    DBG('Returning Successfully from Clpks_Cldaccnt_Utils_Custom.Fn_Query_tanked');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('No custom details found in Fn_Query_tanked');
      RETURN FALSE;
  END FN_QUERY_TANKED;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_CLDACCNT         IN CLPKS_CLDACCNT_MAIN.TY_CLDACCNT,
                                   P_FN_CALL_ID       IN OUT NUMBER,
                                   P_TB_CUSTOM_DATA   IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Clpks_Cldaccnt_Utils_Custom.Fn_Post_Check_Mandatory');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others in Fn_Post_Check_Mandatory ' || SQLERRM);
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

END CLPKS_CLDACCNT_UTILS_CUSTOM;
