prompt Importing table ICTM_EXPR...
set feedback off
set define off
insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 1, 1, 'VD_DLY_DR_BAL_M >0 ', 'DR_INT_RATE');

insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 1, 2, 'VD_DLY_DR_BAL_M <= 0', '0');

insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 2, 1, '1=1', '(VD_DLY_DR_BAL_M*DAYS*FORMULA1)/(YEAR*100)');

insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 3, 1, 'EXCEED_LIMIT<=0', '0');

insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 3, 2, 'EXCEED_LIMIT>0', '24');

insert into ICTM_EXPR (RULE_ID, FRM_NO, EXPR_LINE, COND, RESULT)
values ('DIVR', 4, 1, '1=1', '(EXCEED_LIMIT*DAYS*FORMULA3)/(YEAR*100)');

prompt Done.
