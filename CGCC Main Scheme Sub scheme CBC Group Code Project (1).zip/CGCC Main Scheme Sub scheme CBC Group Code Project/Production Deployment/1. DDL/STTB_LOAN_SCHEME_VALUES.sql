-- Create table
create table STTB_LOAN_SCHEME_VALUES
(
  main_scheme VARCHAR2(105),
  sub_scheme  VARCHAR2(105),
  cbc_code    VARCHAR2(105)
)
/
alter table STTB_LOAN_SCHEME_VALUES add primary key (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
/