prompt Importing table ertb_msgs...
set feedback off
set define off
insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-040', 'ENG', 'Sub Scheme Selection is Wrong. Please select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('CL-PRIN-041', 'ENG', 'CBC Code Selection is Wrong. Please select again from the drop down!!', 'E', 'N', 'CLDACCNT', 1, 'N', 'E', null, 'N', null, null, null, null);

prompt Done.
