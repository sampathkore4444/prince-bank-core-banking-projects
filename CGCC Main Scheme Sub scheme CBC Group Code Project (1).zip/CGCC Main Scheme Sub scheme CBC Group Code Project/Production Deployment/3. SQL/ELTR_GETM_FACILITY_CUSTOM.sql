CREATE OR REPLACE TRIGGER ELTR_GETM_FACILITY_CUSTOM
  FOR INSERT OR UPDATE ON GETM_FACILITY
  COMPOUND TRIGGER

  BEFORE EACH ROW IS
  
    L_SEQ_NO varchar2(3);
    L_COUNT  NUMBER;
    L_TYPE   VARCHAR2(8);
  
  BEGIN
  
  IF :NEW.UDF_VALUE_1 IS NOT NULL THEN
  
    BEGIN
      L_TYPE := CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID');
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
	    L_TYPE := 'NULL';
        --L_TYPE := 'GEDFACLT';
      WHEN OTHERS THEN
        L_TYPE := NULL;
    END;
  
    IF L_TYPE IN ('GEDFACLT') THEN
    
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SCHEME_VALUES A
       WHERE A.MAIN_SCHEME = :NEW.UDF_VALUE_1
            
         AND A.SUB_SCHEME = :NEW.UDF_VALUE_2;
    
      IF L_COUNT = 0 THEN
      
        OVPKSS.PR_APPENDTBL('CL-PRIN-040', 'Invalid combination' || '~');
      
        RAISE_APPLICATION_ERROR(-20001, 'Invalid combination');
      
      END IF;
    
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SCHEME_VALUES A
       WHERE A.SUB_SCHEME = :NEW.UDF_VALUE_2
            
         AND A.CBC_CODE = :NEW.UDF_VALUE_3;
    
      IF L_COUNT = 0 THEN
      
        OVPKSS.PR_APPENDTBL('CL-PRIN-041', 'Invalid combination' || '~');
      
        RAISE_APPLICATION_ERROR(-20001, 'Invalid combination');
      
      END IF;
    
    END IF;
	
	END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN ELTR_GETM_FACILITY_CUSTOM');
    
      RAISE_APPLICATION_ERROR(-20001, 'Invalid combination');
    
  END BEFORE EACH ROW;

END ELTR_GETM_FACILITY_CUSTOM;
