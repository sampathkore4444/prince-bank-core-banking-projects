prompt Importing table STTB_LOAN_SCHEME_VALUES...
set feedback off
set define off
insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('General CGCC Schemes', 'CGCC-BRGS', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('General CGCC Schemes', 'CGCC-CFGS', 'SM1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('General CGCC Schemes', 'CGCC-WEGS', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('Non-Scheme', 'None', 'S0');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('Portfolio Guarantee 
Schemes', 'CGCC-PGS1-WE', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('Portfolio Guarantee 
Schemes', 'CGCC-PGS2-
MSME', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('Portfolio Guarantee 
Schemes', 'CGCC-PGS4-
RICE SECTOR', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('Portfolio Guarantee 
Schemes', 'CGCC-PGS5-
SGEF', 'S1');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('SME Scheme', 'SME1', 'S2');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('SME Scheme', 'SME2-SCFS', 'S2');

insert into STTB_LOAN_SCHEME_VALUES (MAIN_SCHEME, SUB_SCHEME, CBC_CODE)
values ('SME Scheme', 'SME3-TRCS', 'S2');

prompt Done.
