CREATE OR REPLACE PACKAGE BODY uvpks_udf_upload_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('ST', 'uvpks_udf_upload_custom ==>' || P_MSG);
  END DBG;
  
  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_PICKUP_CONT_UDF(P_CONT_REF        IN VARCHAR2,
                              P_MODULE          IN VARCHAR2,
                              P_PROD            IN VARCHAR2,
                              L_ERROR_CODE      IN OUT VARCHAR2,
                              L_ERROR_PARAMETER IN OUT VARCHAR2,
                              P_FN_CALL_ID      NUMBER,
                              P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside uvpks_udf_upload_custom.Fn_Pickup_Cont_Udf');
  
    DBG('Returning Success From uvpks_udf_upload_custom.Fn_Pickup_Cont_Udf');
    RETURN TRUE;
  END FN_PICKUP_CONT_UDF;

  FUNCTION FN_CONTRACT_UDF_UPLOAD_TYPE(P_SOURCE_CODE     IN VARCHAR2,
                                       P_EXTERNAL_REF_NO IN VARCHAR2,
                                       P_CONTRACT_REF_NO IN VARCHAR2,
                                       P_VERSION_NO      IN NUMBER DEFAULT 1,
                                       P_PRODUCT         IN CSTMS_PRODUCT.PRODUCT_CODE%TYPE,
                                       P_ACTION          IN VARCHAR2,
                                       P_TBL_UPL_UDF     IN UVPKS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                       P_ERROR_CODE      IN OUT VARCHAR2,
                                       P_ERROR_PARAMETER IN OUT VARCHAR2,
                                       P_FN_CALL_ID      NUMBER,
                                       P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    
    --sampath starts SCHEME
    L_MAIN_SCHEME Udtbs_Cont_Udf_Upload_Detail.Field_Val%type;
    L_SUB_SCHEME Udtbs_Cont_Udf_Upload_Detail.Field_Val%type;
    L_CBC_CODE Udtbs_Cont_Udf_Upload_Detail.Field_Val%type;
    L_COUNT NUMBER:=0;
    --sampath ends SCHEME
    
  BEGIN
    DBG('Inside uvpks_udf_upload_custom.Fn_Contract_Udf_Upload_Type=' ||
        P_ACTION);
  
    --sampath starts SCHEME
  
    IF P_ACTION IN ('NEW', 'MODIFY') AND
       P_PRODUCT IN ('GUBB',
                     'GUPG',
                     'GUPP',
                     'GURG',
                     'GUAP',
                     'STLC',
                     'ILSR',
                     'ILUR',
                     'SHGU') THEN
    
      DBG('UDF COUNT=' || P_TBL_UPL_UDF.COUNT);
    
      IF P_TBL_UPL_UDF.COUNT > 0 THEN
      
        FOR G IN P_TBL_UPL_UDF.FIRST .. P_TBL_UPL_UDF.LAST LOOP
        
          IF P_TBL_UPL_UDF(G).FIELD_NAME = 'MAIN_SCHEME_TRAD' THEN
          
            L_MAIN_SCHEME := P_TBL_UPL_UDF(G).FIELD_VAL;
          
          END IF;
        
          IF P_TBL_UPL_UDF(G).FIELD_NAME = 'SUB_SCHEME_TRAD' THEN
          
            L_SUB_SCHEME := P_TBL_UPL_UDF(G).FIELD_VAL;
          
          END IF;
        
          IF P_TBL_UPL_UDF(G).FIELD_NAME = 'GROUP_CBC_TRAD' THEN
          
            L_CBC_CODE := P_TBL_UPL_UDF(G).FIELD_VAL;
          
          END IF;
        
        END LOOP;
      
      END IF;
    
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SCHEME_VALUES A
       WHERE A.MAIN_SCHEME = L_MAIN_SCHEME
            
         AND A.SUB_SCHEME = L_SUB_SCHEME;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-040', '');
      
        RETURN FALSE;
      
      END IF;
    
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SCHEME_VALUES A
       WHERE A.SUB_SCHEME = L_SUB_SCHEME
            
         AND A.CBC_CODE = L_CBC_CODE;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-041', '');
      
        RETURN FALSE;
      
      END IF;
    
    END IF;
  
    --sampath ends SCHEME
  
    DBG('Returning Success From uvpks_udf_upload_custom.Fn_Contract_Udf_Upload_Type');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of Fn_Contract_Udf_Upload_Type' || SQLERRM);
      RETURN FALSE;
  END FN_CONTRACT_UDF_UPLOAD_TYPE;

  FUNCTION FN_PRE_QUERY_FUNC_UDFDETAILS(P_FUNCTION_ID  IN VARCHAR2,
                                        P_RECKEY       IN VARCHAR2,
                                        P_NOT_IN_LIST  IN VARCHAR2,
                                        P_UDF_REC      IN OUT CSTMS_FUNCTION_USERDEF_FIELDS%ROWTYPE,
                                        P_UDF_DET      IN OUT UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                        P_ERROR_CODE   IN OUT VARCHAR2,
                                        P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_Query_Func_Udfdetails');
  
    DBG('Returning Success From Fn_Pre_Query_Func_Udfdetails');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of Fn_Pre_Query_Func_Udfdetails' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_QUERY_FUNC_UDFDETAILS;

  FUNCTION FN_POST_QUERY_FUNC_UDFDETAILS(P_FUNCTION_ID  IN VARCHAR2,
                                         P_RECKEY       IN VARCHAR2,
                                         P_NOT_IN_LIST  IN VARCHAR2,
                                         P_UDF_REC      IN OUT CSTMS_FUNCTION_USERDEF_FIELDS%ROWTYPE,
                                         P_UDF_DET      IN OUT UVPKS_UDF_UPLOAD.TY_UPL_FUNC_UDF,
                                         P_ERROR_CODE   IN OUT VARCHAR2,
                                         P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_Query_Func_Udfdetails');
  
    DBG('Returning Success From Fn_Post_Query_Func_Udfdetails');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of Fn_Post_Query_Func_Udfdetails' || SQLERRM);
      RETURN FALSE;
  END FN_POST_QUERY_FUNC_UDFDETAILS;

  FUNCTION FN_PRE_QUERY_CONT_UDFDETAILS(P_FUNCTION_ID  IN VARCHAR2,
                                        P_KEY          IN VARCHAR2,
                                        P_NOT_IN_LIST  IN VARCHAR2,
                                        P_UDF_REC      IN OUT CSTMS_CONTRACT_USERDEF_FIELDS%ROWTYPE,
                                        P_UDF_DET      IN OUT UVPKS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                        P_ERROR_CODE   IN OUT VARCHAR2,
                                        P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_Query_Cont_Udfdetails');
  
    DBG('Returning Success From Fn_Pre_Query_Cont_Udfdetails');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of Fn_Pre_Query_Cont_Udfdetails' || SQLERRM);
      RETURN FALSE;
  END FN_PRE_QUERY_CONT_UDFDETAILS;

  FUNCTION FN_POST_QUERY_CONT_UDFDETAILS(P_FUNCTION_ID  IN VARCHAR2,
                                         P_KEY          IN VARCHAR2,
                                         P_NOT_IN_LIST  IN VARCHAR2,
                                         P_UDF_REC      IN OUT CSTMS_CONTRACT_USERDEF_FIELDS%ROWTYPE,
                                         P_UDF_DET      IN OUT UVPKS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                         P_ERROR_CODE   IN OUT VARCHAR2,
                                         P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Post_Query_Cont_Udfdetails');
  
    DBG('Returning Success From Fn_Post_Query_Cont_Udfdetails');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of Fn_Post_Query_Cont_Udfdetails' || SQLERRM);
      RETURN FALSE;
  END FN_POST_QUERY_CONT_UDFDETAILS;

END UVPKS_UDF_UPLOAD_CUSTOM;
