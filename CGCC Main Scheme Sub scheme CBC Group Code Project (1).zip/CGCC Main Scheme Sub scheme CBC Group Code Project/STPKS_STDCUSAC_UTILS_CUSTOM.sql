CREATE OR REPLACE PACKAGE BODY STPKS_STDCUSAC_UTILS_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_09_30052018
   **    Changes By        : Aniket
   **    Changes on        : 30-May-2018
   **    Description       : Multi-Currency account numbers to be generated starting with specific digit.Changes specific to prince.
  
   **    Changes By        : kore sampath kumar
   **    Changes on        : 08-March-2020
   **    Description       : Duplicate Account Found Issue
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcusac_utils_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('AE', L_MSG);
  END DBG;

  --Special Premium Account Changes Commented Starts
  /*--Duplicate Account Found Issue starts
  G_CUSTOM_AC_NO VARCHAR2(20) := '';
  
  
  
  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  
  FUNCTION FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID       IN VARCHAR2,
                                   P_STDCUSAC          IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   L_MULTI_CCY_ACCOUNT IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    SELECT DISTINCT (MULTI_CCY_AC_NO)
      INTO L_MULTI_CCY_ACCOUNT
      FROM STTM_MULTI_CCY_ACCNT_MASTER
     WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
       AND ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
  
    DBG('fn_multi_currency_check' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
  
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      L_MULTI_CCY_ACCOUNT := NULL;
      RETURN FALSE;
  END FN_MULTI_CURRENCY_CHECK;
  
  --Duplicate Account Found Issue ends
  --Special Premium Account Changes Commented Ends
  */

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_UPDATE_ACCNO(P_FUNCTION_ID    IN VARCHAR2,
                           P_ACC            IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_BRN            IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_Update_Accno');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_Update_Accno');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_Update_Accno' ||
          SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_ACCNO;

  FUNCTION FN_ACC_AUTOGEN(P_FUNCTION_ID    IN VARCHAR2,
                          P_AC_NO_LENGTH   IN NUMBER,
                          P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                          P_FN_CALL_ID     IN OUT NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
    /*
    --Special Premium Account Changes Commented Starts
    --Duplicate Account Found Issue starts
    L_AC_NO       VARCHAR2(20) := '';
    IGNORE        BOOLEAN;
    L_IGNORE      VARCHAR2(10);
    AL_RETURN     VARCHAR2(10);
    L_COUNT       NUMBER;
    L_BANK_CODE   PCTMS_BANK_PARAM.BANK_CODE%TYPE;
    L_START_AC_NO STTMS_ACC_PARAM.START_AC_NO%TYPE;
    L_END_AC_NO   STTMS_ACC_PARAM.END_AC_NO%TYPE;
    L_LENGTH      NUMBER;
    L_AC_TYPE     STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    
    L_MASK      STTM_ACC_PARAM.CUSTOMER_ACC_MASK%TYPE;
    L_AC_NO_G   STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ERR_CODE  VARCHAR2(100);
    L_ERR_PARAM VARCHAR2(100);
    
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    
    L_MULTI_CCY_ACC_PARAM_REC STTM_MULTICCY_ACC_PARAM%ROWTYPE;
    L_MULTI_CUST_MASK         STTM_MULTICCY_ACC_PARAM.MULTI_CCY_ACC_MASK%TYPE;
    L_MULTI_CURRENCY_FLAG     VARCHAR(1);
    L_MULTI_CCY_ACCOUNT       VARCHAR(20);
    L_MULTI_CCY_AC_NO_LENGTH  NUMBER;
    
    L_MULTI_CURRENCY VARCHAR2(20);
    
    FUNCTION FN_GET_NONSPL_NO(P_BRN    IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              P_ACC_NO IN OUT NUMBER) RETURN BOOLEAN IS
      L_START_RANGE STTM_CUST_RANGE_DETAIL.START_RANGE%TYPE;
      L_END_RANGE   STTM_CUST_RANGE_DETAIL.END_RANGE%TYPE;
    BEGIN
      DBG('Inside Function stpks_stdcusac_utils_0.fn_get_nonspl_no');
      BEGIN
        SELECT RD.START_RANGE, RD.END_RANGE
          INTO L_START_RANGE, L_END_RANGE
          FROM STTM_CUST_RANGE_MASTER RM, STTM_CUST_RANGE_DETAIL RD
         WHERE RM.RECORD_STAT = 'O'
           AND RM.ONCE_AUTH = 'Y'
           AND RM.BRANCH_CODE = P_BRN
           AND RM.RANGE_TYPE = 'A'
           AND RM.BRANCH_CODE = RD.BRANCH_CODE
           AND RM.RANGE_TYPE = RD.RANGE_TYPE
           AND TO_NUMBER(P_ACC_NO) BETWEEN TO_NUMBER(RD.START_RANGE) AND
               TO_NUMBER(RD.END_RANGE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Not a spl account number');
        WHEN OTHERS THEN
          DBG('In WOT of Select From sttm_cust_range_detail SQLERRM: ' ||
              SQLERRM);
      END;
      DBG('l_start_range: ' || L_START_RANGE);
      DBG('l_end_range: ' || L_END_RANGE);
      IF L_START_RANGE IS NOT NULL AND L_END_RANGE IS NOT NULL THEN
        DBG('p_acc_no is spl a Account number');
        P_ACC_NO := TO_NUMBER(L_END_RANGE) + 1;
    
        IF NOT FN_GET_NONSPL_NO(P_BRN, P_ACC_NO) THEN
          DBG('failed while calling fn_get_nonspl_no again' || SQLERRM);
        END IF;
      END IF;
      DBG('Returning TRUE from Function stpks_stdcusac_utils_0.fn_get_nonspl_no');
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT of Function stpks_stdcusac_utils_0.fn_get_nonspl_no. SQLERRM: ' ||
            SQLERRM);
    END FN_GET_NONSPL_NO;
    
    FUNCTION FN_UPD_ACC(P_FUNCTION_ID IN VARCHAR2,
                        P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
      RETURN BOOLEAN IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      L_UPDATED     BOOLEAN := FALSE;
      L_RETRY       NUMBER;
      L_WAIT_TIME   NUMBER;
      L_MAXTRY      NUMBER;
      L_COUNT2      NUMBER := 0;
      L_START_AC_NO STTMS_ACC_PARAM.START_AC_NO%TYPE;
      L_END_AC_NO   STTMS_ACC_PARAM.END_AC_NO%TYPE;
    
      L_AC_NO STTMS_ACC_PARAM.CUST_AC_NO%TYPE;
    
      L_BRN STTMS_ACC_PARAM.BRANCH_CODE%TYPE;
      L_CNT NUMBER := 0;
    
    BEGIN
      DBG('Inside fn_upd_acc');
    
      L_UPDATED := FALSE;
      L_RETRY   := 0;
    
      BEGIN
        SELECT PARAM_VAL
          INTO L_WAIT_TIME
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'CUST_ACCGEN_WAIT_TIME';
      EXCEPTION
        WHEN OTHERS THEN
          L_WAIT_TIME := 0.1;
      END;
    
      BEGIN
        SELECT PARAM_VAL
          INTO L_MAXTRY
          FROM CSTB_PARAM
         WHERE PARAM_NAME = 'MAX_ACCGEN_RETRY';
      EXCEPTION
        WHEN OTHERS THEN
          L_MAXTRY := 50;
      END;
    
      WHILE (L_UPDATED = FALSE) LOOP
    
        SELECT COUNT(1)
          INTO L_CNT
          FROM STTMS_ACC_PARAM
         WHERE BRANCH_CODE = P_BRN;
        IF L_CNT > 0 THEN
          L_BRN := P_BRN;
        ELSE
          L_BRN := '***';
        END IF;
    
        BEGIN
          SELECT START_AC_NO, END_AC_NO, NVL(CUST_AC_NO, START_AC_NO)
            INTO L_START_AC_NO, L_END_AC_NO, L_AC_NO
            FROM STTMS_ACC_PARAM
    
           WHERE BRANCH_CODE = L_BRN;
    
          --FOR UPDATE NOWAIT;
    
          IF NOT FN_GET_NONSPL_NO(L_BRN, L_AC_NO) THEN
            DBG('Error while getting non spl no' || SQLERRM);
          END IF;
    
          DBG('L_AC_NO=' || L_AC_NO);
    
          L_AC_NO := LPAD(L_AC_NO, P_AC_NO_LENGTH, '0'); --Duplicate Account Found Issue
    
          SELECT COUNT(*)
            INTO L_COUNT2
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_AC_NO;
    
          --AND BRANCH_CODE = L_BRN;
    
          IF L_COUNT2 = 0 THEN
    
            UPDATE STTMS_ACC_PARAM
               SET CUST_AC_NO = TO_NUMBER(L_AC_NO)
    
             WHERE BRANCH_CODE = L_BRN;
    
            COMMIT;
    
            SELECT COUNT(*)
              INTO L_COUNT2
              FROM STTBS_RECORD_MASTER
    
             WHERE KEY_ID =
                   '~STTM_CUST_ACCOUNT~' || L_BRN || '~' || L_AC_NO || '~';
          END IF;
    
          DBG('L_COUNT2 in customer account table=' || L_COUNT2);
    
          IF L_COUNT2 <> 0 THEN
            DBG('Account already exists so getting again');
    
            --PR_UPDATE_ACC_PARAM(L_AC_NO, L_BRN); --sampath added
    
            UPDATE STTMS_ACC_PARAM
               SET CUST_AC_NO = TO_NUMBER(L_AC_NO) + 1
             WHERE BRANCH_CODE = L_BRN;
    
            --G_CUSTOM_AC_NO := TO_NUMBER(L_AC_NO) + 1;
            G_CUSTOM_AC_NO := LPAD(TO_NUMBER(L_AC_NO) + 1,
                                   P_AC_NO_LENGTH,
                                   '0'); --save the number
    
            --L_AC_NO := LPAD( TO_NUMBER(L_AC_NO) + 1, P_AC_NO_LENGTH, '0'); --save the number
    
            COMMIT;
    
            IF NOT FN_UPD_ACC(P_FUNCTION_ID, L_BRN) THEN
              DBG('Error while calling fn_upd_acc');
            END IF;
          END IF;
    
          --L_AC_NO := LPAD(L_AC_NO, P_AC_NO_LENGTH, '0'); --sampath commented
          DBG('SYSTIMESTAMP=' || SYSTIMESTAMP);
          DBG('l_start_ac_no=' || L_START_AC_NO);
          DBG('l_end_ac_no=' || L_END_AC_NO);
          DBG('l_ac_no=' || L_AC_NO);
    
          --G_CUSTOM_AC_NO := L_AC_NO; --assign else unused will go as null
    
          DBG('G_CUSTOM_AC_NO=' || G_CUSTOM_AC_NO);
          IF TO_NUMBER(NVL(G_CUSTOM_AC_NO, L_AC_NO)) >
             TO_NUMBER(L_END_AC_NO) THEN
            DBG('maximum no of accounts reached for this branch');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-REC02', NULL);
            RETURN FALSE;
          END IF;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := G_CUSTOM_AC_NO;
    
          DBG('l_ac_no :: ' || L_AC_NO);
          DBG('G_CUSTOM_AC_NO=' || G_CUSTOM_AC_NO);
          DBG('p_stdcusac.v_sttms_cust_account.alt_ac_no :: ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO IS NULL THEN
    
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO := G_CUSTOM_AC_NO;
    
          END IF;
          DBG('p_stdcusac.v_sttms_cust_account.alt_ac_no :: ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO);
    
          DBG('Account No generated succesfully:' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
          DBG('calling fn_update_accno');
    
          DBG('L_AC_NO L_AC_NO L_AC_NO=' || L_AC_NO);
    
          DBG('account no is updated in sttms_acc_param APPLE');
          L_UPDATED := TRUE;
          EXIT;
    
        EXCEPTION
          WHEN OTHERS THEN
            IF SQLCODE = -54 THEN
              DBG('No. of attempts .... :' || TO_CHAR(L_RETRY));
              DBG('ERROR LINE NUMBER=' ||
                  DBMS_UTILITY.format_error_backtrace);
              DBMS_LOCK.SLEEP(L_WAIT_TIME);
              L_RETRY := L_RETRY + 1;
              IF L_RETRY = L_MAXTRY THEN
                EXIT;
              END IF;
            ELSE
              DBG('Failed IN WHEN generating account no : ' || SQLERRM);
              DBG('ERROR LINE NUMBER2=' ||
                  DBMS_UTILITY.format_error_backtrace);
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-ACC004', NULL);
              RETURN FALSE;
            END IF;
        END;
      END LOOP;
    
      BEGIN
        SELECT CUST_AC_NO
          INTO L_AC_NO
          FROM STTMS_ACC_PARAM
    
         WHERE BRANCH_CODE = L_BRN;
      EXCEPTION
        WHEN OTHERS THEN
          L_AC_NO := NULL;
      END;
    
      DBG('L_AC_NO L_AC_NO=' || L_AC_NO);
    
      G_CUSTOM_AC_NO := LPAD(TO_NUMBER(L_AC_NO), P_AC_NO_LENGTH, '0');
    
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := G_CUSTOM_AC_NO;
    
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO := G_CUSTOM_AC_NO;
    
      IF NOT L_UPDATED THEN
        DBG('Failed IN WHEN generating account no : ' || SQLERRM);
    
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-ACC004', NULL);
        ROLLBACK;
        RETURN FALSE;
      END IF;
      DBG('fn_upd_acc returning true');
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed IN WHEN generating account no : ' || SQLERRM);
        ROLLBACK;
        RETURN FALSE;
    END FN_UPD_ACC;
    --Duplicate Account Found Issue ends
    --Special Premium Account Changes Commented Ends
    */
  
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_Acc_Autogen');
  
    /*
    --Special Premium Account Changes Commented Starts
    --Duplicate Account Found Issue starts
    IF P_FN_CALL_ID = 1 THEN
    
      DBG('Branch: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      STPKS_ACCGEN.G_ACC_BRANCH := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                       GLOBAL.CURRENT_BRANCH);
    
      BEGIN
        BEGIN
          SELECT CUSTOMER_ACC_MASK
            INTO L_MASK
            FROM STTMS_ACC_PARAM
           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT CUSTOMER_ACC_MASK
              INTO L_MASK
              FROM STTMS_ACC_PARAM
             WHERE BRANCH_CODE = '***';
        END;
        L_AC_NO_G := L_MASK;
        DBG('Account mask~' || L_MASK);
    
        \*IF NOT STPKS_ACCGEN.FN_GETUNUSEDCUSTACNO(P_FUNCTION_ID,
                                                 NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                     GLOBAL.CURRENT_BRANCH),
                                                 L_AC_NO_G) THEN
          DBG('returned from stpks_accgen.fn_getunusedcustacno..' ||
              SQLERRM);
          DBG('going to get the ac no in normal way..........');
        ELSE
          DBG('got the cust ac no =' || L_AC_NO_G);
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := L_AC_NO_G;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO  := L_AC_NO_G;
          DBG('Going to call stpks_accgen.fn_update_unusedcustacno.. ');
    
          RETURN TRUE;
        END IF;*\
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    
      DBG('SYSTIMESTAMP=' || SYSTIMESTAMP);
      DBG('not using earlier fn_update_accno anymore..new autonomous function fn_upd_acc introduced ');
    
      IF NOT FN_UPD_ACC(P_FUNCTION_ID,
                        NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                            GLOBAL.CURRENT_BRANCH)) THEN
        DBG('Failed IN WHEN generating account no : ' || SQLERRM);
        RETURN FALSE;
      END IF;
    
      --Duplicate Account Found Issue starts selecting customer account no from the table
      BEGIN
        SELECT CUST_AC_NO
          INTO L_AC_NO
          FROM STTMS_ACC_PARAM
    
         WHERE BRANCH_CODE = NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                 GLOBAL.CURRENT_BRANCH);
      EXCEPTION
        WHEN OTHERS THEN
          L_AC_NO := NULL;
      END;
    
      DBG('FINAL ACC NO=' || L_AC_NO);
    
      G_CUSTOM_AC_NO := LPAD(TO_NUMBER(L_AC_NO), P_AC_NO_LENGTH, '0');
    
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := G_CUSTOM_AC_NO;
    
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO := G_CUSTOM_AC_NO;
    
      --Duplicate Account Found Issue ends
    
      DBG('Account No generated succesfully outside:' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    
      DBG('account no is updated in sttms_acc_param');
      DBG('going to update stpks_accgen.fn_update_unusedcustacno...');
    
      \* IF NOT STPKS_ACCGEN.FN_UPDATE_UNUSEDCUSTACNO(L_MASK,
                                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                   'INIT',
                                                   L_ERR_CODE,
                                                   L_ERR_PARAM) THEN
        DBG('failed in fn_update_unusedcustacno ' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;*\
    
      stpks_stdcusac_utils_0.G_MULTI_CURRENCY := STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                                                                P_STDCUSAC,
                                                                                                L_MULTI_CURRENCY);
    
      IF stpks_stdcusac_utils_0.G_MULTI_CURRENCY <> TRUE THEN
        BEGIN
          SELECT *
            INTO L_MULTI_CCY_ACC_PARAM_REC
            FROM STTMS_MULTICCY_ACC_PARAM
           WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            SELECT *
              INTO L_MULTI_CCY_ACC_PARAM_REC
              FROM STTMS_MULTICCY_ACC_PARAM
             WHERE BRANCH_CODE = '***';
    
        END;
        BEGIN
          SELECT MULTI_CURRENCY
            INTO L_MULTI_CURRENCY_FLAG
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    
        END;
    
        DBG('l_multi_currency_flag' || L_MULTI_CURRENCY_FLAG);
    
        IF FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                   P_STDCUSAC,
                                   L_MULTI_CURRENCY) THEN
          DBG('l_multi_currency' || L_MULTI_CURRENCY);
          RETURN TRUE;
        END IF;
        DBG('p_stdcusac.v_sttms_cust_account.multi_ccy_ac_no' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
        DBG('l_multi_ccy_account' || L_MULTI_CCY_ACCOUNT);
        IF NVL(L_MULTI_CURRENCY_FLAG, 'N') = 'Y' THEN
    
          IF L_MULTI_CCY_ACCOUNT IS NULL THEN
    
            DBG('Auto generation is turned ON multi');
            DBG('Before calling the stpks_accgen.fn_getunusedcustacno for getting the unused ac no multi...');
            L_MULTI_CUST_MASK := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO;
            IF NOT STPKS_MCY_ACCGEN.FN_MCY_ACCGEN(P_FUNCTION_ID, P_STDCUSAC) THEN
              DBG('Returning from stpks_accgen.fn_getunusedcustacno~' ||
                  SQLERRM);
            END IF;
            BEGIN
              SELECT LENGTH(MULTI_CCY_ACC_MASK)
                INTO L_MULTI_CCY_AC_NO_LENGTH
                FROM STTM_MULTICCY_ACC_PARAM
               WHERE BRANCH_CODE =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Error while getting sttm_multiccy_acc_param' ||
                    SQLERRM);
            END;
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO := LPAD(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO,
                                                                    L_MULTI_CCY_AC_NO_LENGTH,
                                                                    '0');
            DBG('p_stdcusac.v_sttms_cust_account.multi_ccy_ac_no after accgen' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    
          END IF;
        END IF;
    
      END IF;
    
      --Skip the kernel
      GLOBAL.PR_SET_SKIP_KERNEL;
    END IF;
    --Duplicate Account Found Issue ends
    --Special Premium Account Changes Commented Ends
    */
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_Acc_Autogen');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_Acc_Autogen' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ACC_AUTOGEN;

  FUNCTION FN_OTHER_DEFAULTS(P_FUNCTION_ID    IN VARCHAR2,
                             P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_SOURCE         IN VARCHAR2,
                             P_SKIP_CUST      IN BOOLEAN DEFAULT FALSE,
                             P_FN_CALL_ID     IN OUT NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_Other_Defaults');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_Other_Defaults');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_Other_Defaults' ||
          SQLERRM);
      RETURN FALSE;
  END FN_OTHER_DEFAULTS;

  FUNCTION FN_AUTH_CUSTACC(P_FUNCTION_ID IN VARCHAR2,
                           P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_ACTION_CODE IN VARCHAR2,
                           P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST', 'Start of fn_auth_custacc');
  
    DEBUG.PR_DEBUG('ST', 'Returning true from  fn_auth_custacc');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'Start of fn_auth_custacc');
      RETURN FALSE;
  END FN_AUTH_CUSTACC;

  FUNCTION FN_CUSTADVICE_ENTIRES(P_FUNCTION_ID    IN VARCHAR2,
                                 P_STDCUSAC       IN OUT STTMS_CUST_ACCOUNT%ROWTYPE,
                                 P_FN_CALL_ID     IN OUT NUMBER,
                                 P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST', 'Start of Fn_Custadvice_Entires');
  
    DEBUG.PR_DEBUG('ST', 'Returning true from  Fn_Custadvice_Entires');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'Start of Fn_Custadvice_Entires');
      RETURN FALSE;
  END FN_CUSTADVICE_ENTIRES;

  FUNCTION FN_CUSTACC_ENTIRES(P_FUNCTION_ID    IN VARCHAR2,
                              P_STDCUSAC       IN OUT STTMS_CUST_ACCOUNT%ROWTYPE,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST', 'Start of Fn_Custacc_Entires');
  
    DEBUG.PR_DEBUG('ST', 'Returning true from  Fn_Custacc_Entires');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'Start of Fn_Custacc_Entires');
      RETURN FALSE;
  END FN_CUSTACC_ENTIRES;

  FUNCTION FN_VALIDATE_CUST_ACC(P_FUNCTION_ID    IN VARCHAR2,
                                P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACC_PARAM_REC  IN STTMS_ACC_PARAM%ROWTYPE,
                                P_MASK_BRANCH    OUT STTMS_ACC_PARAM.BRANCH_CODE%TYPE,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_validate_Cust_Acc');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_validate_Cust_Acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_validate_Cust_Acc' ||
          SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_CUST_ACC;

  FUNCTION FN_DEFAULT_CUSTACC(P_FUNCTION_ID    IN VARCHAR2,
                              P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                              P_SOURCE         IN VARCHAR2,
                              P_USER_ID        IN SMTBS_USER.USER_ID%TYPE,
                              P_FN_CALL_ID     IN OUT NUMBER,
                              P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_default_custacc');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_default_custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_default_custacc' ||
          SQLERRM);
      RETURN FALSE;
  END FN_DEFAULT_CUSTACC;

  FUNCTION FN_CHQBOOK_UPLD(P_WRK_STDCUSAC     IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_FN_CALL_ID       IN OUT NUMBER,
                           P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.fn_chqbook_upld');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_chqbook_upld');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_chqbook_upld' ||
          SQLERRM);
      RETURN FALSE;
  END FN_CHQBOOK_UPLD;

  FUNCTION FN_MODIFY_ACC(P_FUNCTION_ID    IN VARCHAR2,
                         P_PREV_STDCUSAC  IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_ACTION_CODE    IN VARCHAR2,
                         P_SOURCE         IN VARCHAR2,
                         P_FN_CALL_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAMS     IN OUT VARCHAR2) RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.Fn_Modify_Acc');
  
    DBG('End  of stpks_stdcusac_utils_custom..Fn_Modify_Acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.Fn_Modify_Acc' ||
          SQLERRM);
      RETURN FALSE;
  END FN_MODIFY_ACC;

  FUNCTION FN_ALLOW_CLOSE(P_FUNCTION_ID    IN VARCHAR2,
                          P_AC_NO          IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                          P_BRN            IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                          P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.Fn_Allow_Close');
  
    DBG('End  of stpks_stdcusac_utils_custom..Fn_Allow_Close');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.Fn_Allow_Close' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ALLOW_CLOSE;

  FUNCTION FN_ACCGEN(P_FUNCTION_ID    IN VARCHAR2,
                     P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                     P_FN_CALL_ID     IN NUMBER,
                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    L_MASK STTMS_MULTICCY_ACC_PARAM.MULTI_CCY_ACC_MASK%TYPE; --PRF_CUSTOM_09_30052018 changes
  BEGIN
    DBG('Start  of stpks_stdcusac_utils_custom.Fn_Accgen');
  
    --PRF_CUSTOM_09_30052018 changes starts
    DBG('ANIKET IN TO REPLACE ACCOUNT ' || P_FN_CALL_ID);
    IF P_FN_CALL_ID = '1' THEN
      DBG('ACC IS :' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('MCY IS :' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
      IF SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO, 1, 1) = '#' THEN
        SELECT MULTI_CCY_ACC_MASK
          INTO L_MASK
          FROM STTM_MULTICCY_ACC_PARAM
         WHERE BRANCH_CODE = '***';
      
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO := SUBSTR(L_MASK,
                                                                  1,
                                                                  1) ||
                                                           SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO,
                                                                  2);
      END IF;
    END IF;
    --PRF_CUSTOM_09_30052018 changes ends
  
    DBG('End  of stpks_stdcusac_utils_custom..Fn_Accgen');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.Fn_Accgen' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ACCGEN;

  FUNCTION FN_VALIDATE_IBAN(P_FUNCTION_ID    IN VARCHAR2,
                            P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_ACTION_CODE    IN VARCHAR2,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside fn_validate_IBAN - Custom');
    DBG('Set Skip Kernel to True to Skip IBAN account Gen');
  
    DBG('fn_validate_IBAN returning true - Cluster');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_IBAN Custom with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_VALIDATE_IBAN;

  FUNCTION FN_COPY_INIT(P_FUNCTION_ID    IN VARCHAR2,
                        P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                        P_FN_CALL_ID     NUMBER,
                        P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Copy_Init ');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'WOT exception of Fn_Copy_Init' || SQLERRM);
      RETURN FALSE;
  END FN_COPY_INIT;

  FUNCTION FN_VALIDATE_IBAN_ACC(P_FUNCTION_ID    IN VARCHAR2,
                                P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACTION_CODE    IN VARCHAR2,
                                P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_validate_iban_acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST',
                     'WOT exception of fn_validate_iban_acc' || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_IBAN_ACC;

  FUNCTION FN_AUTHORIZE_CUSTACC(P_FUNCTION_ID    IN VARCHAR2,
                                P_REC_CUSTACC    IN OUT STTMS_CUST_ACCOUNT%ROWTYPE,
                                P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Authorize_Custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST',
                     'WOT exception of Fn_Authorize_Custacc' || SQLERRM);
      RETURN FALSE;
  END FN_AUTHORIZE_CUSTACC;

  FUNCTION FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID    IN VARCHAR2,
                                   P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   P_ACTION_CODE    IN VARCHAR2,
                                   P_SOURCE         IN VARCHAR2,
                                   P_FN_CALL_ID     NUMBER,
                                   P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_deposit_def_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST',
                     'WOT exception of fn_deposit_def_validate' || SQLERRM);
      RETURN FALSE;
  END FN_DEPOSIT_DEF_VALIDATE;

  FUNCTION FN_VALIDATE_CLOSURE_DET(P_FUNCTION_ID     IN VARCHAR2,
                                   P_CLOSE_REQD      IN VARCHAR2,
                                   P_STCACLOS        IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                   P_SOURCE          IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_INSTR_DETAILS   OUT VARCHAR2,
                                   P_OFFSET_DETAILS  OUT VARCHAR2,
                                   P_FN_CALL_ID      IN OUT NUMBER,
                                   P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside stpks_stdcusac_utils_custom.Fn_Validate_Closure_Det');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOE of stpks_stdcusac_utils_custom.Fn_Validate_Closure_Det : ' ||
          SQLCODE || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_CLOSURE_DET;

  FUNCTION FN_POPULATE_IC_DETAILS(P_FUNCTION_ID    IN VARCHAR2,
                                  P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_populate_ic_details');
    DBG('End  of stpks_stdcusac_utils_custom.fn_populate_ic_details');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_populate_ic_details' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POPULATE_IC_DETAILS;

  FUNCTION FN_UPLOAD(P_FUNCTION_ID    IN VARCHAR2,
                     P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                     P_ACTION_CODE    IN VARCHAR2,
                     P_SOURCE         IN VARCHAR2,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_ERR_PARAMS     IN OUT VARCHAR2,
                     P_FN_CALL_ID     NUMBER,
                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
    --sampath starts SCHEME
    L_MAIN_SCHEME Udtbs_Cont_Udf_Upload_Detail.Field_Name%type;
    L_SUB_SCHEME  Udtbs_Cont_Udf_Upload_Detail.Field_Name%type;
    L_CBC_CODE    Udtbs_Cont_Udf_Upload_Detail.Field_Name%type;
    L_COUNT       NUMBER := 0;
    --sampath ends SCHEME
  
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_upload');
  
    --sampath starts SCHEME
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.p_New, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('BO01', 'BO02', 'MA01', 'MA02', 'PR01', 'PR02') THEN
    
      IF p_stdcusac.Udf_Details.COUNT > 0 THEN
      
        FOR G IN p_stdcusac.Udf_Details.FIRST .. p_stdcusac.Udf_Details.LAST LOOP
        
          IF p_stdcusac.Udf_Details(G).FIELD_NAME = 'MAIN_SCHEME_CASA' THEN
          
            L_MAIN_SCHEME := p_stdcusac.Udf_Details(G).FIELD_VAL;
          
          END IF;
        
          IF p_stdcusac.Udf_Details(G).FIELD_NAME = 'SUB_SCHEME_CASA' THEN
          
            L_SUB_SCHEME := p_stdcusac.Udf_Details(G).FIELD_VAL;
          
          END IF;
        
          IF p_stdcusac.Udf_Details(G).FIELD_NAME = 'GROUP_CBC_CASA' THEN
          
            L_CBC_CODE := p_stdcusac.Udf_Details(G).FIELD_VAL;
          
          END IF;
        
        END LOOP;
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_SCHEME_VALUES A
         WHERE A.MAIN_SCHEME = L_MAIN_SCHEME
              
           AND A.SUB_SCHEME = L_SUB_SCHEME;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-040', '');
        
          RETURN FALSE;
        
        END IF;
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_SCHEME_VALUES A
         WHERE A.SUB_SCHEME = L_SUB_SCHEME
              
           AND A.CBC_CODE = L_CBC_CODE;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-041', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
    END IF;
    --sampath ends SCHEME
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_upload' ||
          SQLERRM);
      RETURN FALSE;
  END FN_UPLOAD;

  FUNCTION FN_VALIDATE_JOINT_ACCOUNT(P_FUNCTION_ID    IN VARCHAR2,
                                     P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_ACTION_CODE    IN VARCHAR2,
                                     P_FN_CALL_ID     NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_validate_joint_account');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_validate_joint_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_validate_joint_account' ||
          SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_JOINT_ACCOUNT;

  FUNCTION FN_VALIDATE_CUSTOMER(P_FUNCTION_ID    IN VARCHAR2,
                                P_CUST           STTMS_CUST_ACCOUNT.CUST_NO%TYPE,
                                P_ACCCLS         STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                                P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_validate_customer');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_validate_customer');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_validate_customer' ||
          SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_CUSTOMER;

  FUNCTION FN_ACCCLS_PICKUP(P_FUNCTION_ID    IN VARCHAR2,
                            P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_SOURCE         IN VARCHAR2,
                            P_SKIP_CUST      IN BOOLEAN DEFAULT FALSE,
                            P_FN_CALL_ID     NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_acccls_pickup');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_acccls_pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_acccls_pickup' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ACCCLS_PICKUP;

  FUNCTION FN_VALIDATE_ITEMS(P_SOURCE         IN VARCHAR2,
                             P_FUNCTION_ID    IN VARCHAR2,
                             P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ACTION_CODE    IN VARCHAR2,
                             P_ERR_CODE       IN OUT VARCHAR2,
                             P_ERR_PARAMS     IN OUT VARCHAR2,
                             P_FN_CALL_ID     NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_validate_items');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_validate_items');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_validate_items' ||
          SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_ITEMS;

  FUNCTION FN_PICKUP_MIS(P_FUNCTION_ID    IN VARCHAR2,
                         P_MICACCTM       IN OUT MIPKS_MICACCTM_MAIN.TY_MICACCTM,
                         P_PKP_FLAG       IN BOOLEAN DEFAULT FALSE,
                         P_DEL_FLAG       IN BOOLEAN DEFAULT FALSE,
                         P_FN_CALL_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST', 'Start of fn_pickup_mis');
    DEBUG.PR_DEBUG('ST', 'Returning true from  fn_pickup_mis');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'Failed in fn_pickup_mis' || SQLCODE || SQLERRM);
      RETURN FALSE;
  END FN_PICKUP_MIS;

  FUNCTION FN_PICKUP_IC(P_FUNCTION_ID    IN VARCHAR2,
                        P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                        P_FN_CALL_ID     NUMBER,
                        P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('In stpks_stdcusac_utils_custom.fn_pickup_ic ..');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of stpks_stdcusac_utils_cluster.fn_pickup_ic ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_PICKUP_IC;

  FUNCTION FN_CLOSE_CUSTACC(P_FUNCTION_ID    IN VARCHAR2,
                            P_STCACLOS       IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                            P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                            P_FN_CALL_ID     NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Close_Custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'WOT exception of Fn_Close_Custacc' || SQLERRM);
      RETURN FALSE;
  END FN_CLOSE_CUSTACC;

  FUNCTION FN_PAYINOUT_VALIDATE(P_FUNCTION_ID    IN VARCHAR2,
                                P_ACTION_CODE    IN VARCHAR2,
                                P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ERR_FLAG       IN OUT NUMBER,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_payinout_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of fn_payinout_validate' || SQLERRM);
      RETURN FALSE;
  END FN_PAYINOUT_VALIDATE;

  FUNCTION FN_PAYINOUT_DEFAULT(P_FUNCTION_ID    IN VARCHAR2,
                               P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ACTION_CODE    IN VARCHAR2,
                               P_SOURCE         IN VARCHAR2,
                               P_ERR_FLAG       IN OUT NUMBER,
                               P_FN_CALL_ID     IN OUT NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_payinout_default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT exception of fn_payinout_default' || SQLERRM);
      RETURN FALSE;
  END FN_PAYINOUT_DEFAULT;

  FUNCTION FN_POPULATE_AMTDT(P_FUNCTION_ID    IN VARCHAR2,
                             P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_FN_CALL_ID     IN OUT NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_populate_amtdt');
  
    DBG('End  of stpks_stdcusac_utils_custom.fn_populate_amtdt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_populate_amtdt' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POPULATE_AMTDT;

  PROCEDURE PR_CALC_MATURITY(P_BRN            IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                             P_ACC            IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                             P_PRODUCT_CODE   IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                             P_TOTAL_AMOUNT   IN OUT NUMBER,
                             P_FUNCTION_ID    IN VARCHAR2 DEFAULT 'STDCUSAC',
                             P_FLAG           IN VARCHAR2 DEFAULT 'N',
                             P_WRK_STDCUSAC   IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC DEFAULT NULL,
                             P_FN_CALL_ID     NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) AS
  BEGIN
    DBG('Inside stpks_util_custom.pr_calc_maturity ...');
  
    DBG('Returning Successfully from stpks_util_custom.pr_calc_maturity..');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of stpks_stdcusac_util_custom.pr_calc_maturity ..');
      DBG(SQLERRM);
      RAISE;
  END PR_CALC_MATURITY;

  FUNCTION FN_VALIDATE_NOTICE_PREFERENCE(P_FUNCTION_ID    IN VARCHAR2,
                                         P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                         P_FN_CALL_ID     NUMBER,
                                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_validate_notice_preference');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST',
                     'WOT exception of fn_validate_notice_preference' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_NOTICE_PREFERENCE;

  FUNCTION FN_GET_CUM_AMT(P_ACC_REC        IN STTM_CUST_ACCOUNT%ROWTYPE,
                          P_INSERT         VARCHAR2 DEFAULT 'N',
                          P_FN_CALL_ID     NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN NUMBER IS
    L_AMT NUMBER := 0;
  BEGIN
    DBG('Entering stpks_stdcusac_utils_custom.fn_get_cum_amt');
    RETURN L_AMT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_get_cum_amt with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_AMT := 0;
      RETURN L_AMT;
  END FN_GET_CUM_AMT;

  FUNCTION FN_VALIDATE_JOINT_HOLDERS(P_FUNCTION_ID    IN VARCHAR2,
                                     P_STDCUSAC       IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_FN_CALL_ID     IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DEBUG.PR_DEBUG('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_validate_joint_holders');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST',
                     'WOT exception of fn_validate_joint_holders' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_JOINT_HOLDERS;

  FUNCTION FN_PRE_VALIDATE_ACCCLS(P_FUNCTION_ID  IN VARCHAR2,
                                  P_ACCCLS       IN STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                                  P_CCY          IN STTMS_CUST_ACCOUNT.CCY%TYPE,
                                  P_CUST         IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE,
                                  P_BRN          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                  P_SKIP_CUST    IN BOOLEAN DEFAULT FALSE,
                                  P_AC_OPEN_DATE IN STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Inside fn_pre_validate_acccls');
  
    DBG('Returning sucess fn_pre_validate_acccls');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdcusac_utils_custom.fn_pre_validate_acccls..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_VALIDATE_ACCCLS;

  FUNCTION FN_POST_VALIDATE_ACCCLS(P_FUNCTION_ID  IN VARCHAR2,
                                   P_ACCCLS       IN STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                                   P_CCY          IN STTMS_CUST_ACCOUNT.CCY%TYPE,
                                   P_CUST         IN STTMS_CUST_ACCOUNT.CUST_NO%TYPE,
                                   P_BRN          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                   P_SKIP_CUST    IN BOOLEAN DEFAULT FALSE,
                                   P_AC_OPEN_DATE IN STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Inside fn_post_validate_acccls');
    DBG('Returning sucess fn_post_validate_acccls');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdcusac_utils_custom.fn_post_validate_acccls..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_POST_VALIDATE_ACCCLS;

  FUNCTION FN_POPDT(P_FUNCTION_ID    IN VARCHAR2,
                    P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                    P_FN_CALL_ID     NUMBER,
                    P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('In stpks_stdcusac_utils_custom.fn_popdt ..');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of stpks_stdcusac_utils_cluster.fn_popdt ..');
      DBG(SQLERRM);
      RETURN FALSE;
  END FN_POPDT;

  FUNCTION FN_PRE_CLOSE_CUSTACC_BRN(P_FUNCTION_ID    IN VARCHAR2,
                                    P_CLOSE_REQD     CHAR,
                                    P_STCACLOS       IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                    P_OFFSET_DETAILS VARCHAR2,
                                    P_INSTR_DETAILS  VARCHAR2,
                                    P_FN_CALL_ID     IN OUT NUMBER,
                                    P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.FN_PRE_CLOSE_CUSTACC_BRN');
  
    DBG('End of stpks_stdcusac_utils_custom.FN_PRE_CLOSE_CUSTACC_BRN');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.FN_PRE_CLOSE_CUSTACC_BRN' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_CLOSE_CUSTACC_BRN;

  FUNCTION FN_POST_CLOSE_CUSTACC_BRN(P_FUNCTION_ID    IN VARCHAR2,
                                     P_CLOSE_REQD     CHAR,
                                     P_STCACLOS       IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                     P_OFFSET_DETAILS VARCHAR2,
                                     P_INSTR_DETAILS  VARCHAR2,
                                     P_FN_CALL_ID     IN OUT NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
    L_TB_CUSTOM_DATA       GLOBAL.TY_TB_CUSTOM_DATA;
    L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.FN_POST_CLOSE_CUSTACC_BRN');
  
    DBG('End of stpks_stdcusac_utils_custom.FN_POST_CLOSE_CUSTACC_BRN');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.FN_POST_CLOSE_CUSTACC_BRN' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POST_CLOSE_CUSTACC_BRN;

  FUNCTION FN_PICKUP_TD(P_FUNCTION_ID    IN VARCHAR2,
                        P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                        P_FN_CALL_ID     IN OUT NUMBER,
                        P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of stpks_stdcusac_utils_custom.fn_pickup_td');
  
    DBG('End of stpks_stdcusac_utils_custom.fn_pickup_td');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_stdcusac_utils_custom.fn_pickup_td' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PICKUP_TD;

  FUNCTION FN_PRE_UPDATELIMITUTIL(P_ACC      IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                  P_BRN      IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                  P_FLAG     IN CHAR,
                                  P_ERRCODE  IN OUT VARCHAR2,
                                  P_ERRPARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside Fn_Pre_updatelimitutil');
  
    DBG('Returning sucess Fn_Pre_updatelimitutil');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdcusac_utils_custom.Fn_Pre_updatelimitutil..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      RETURN FALSE;
  END FN_PRE_UPDATELIMITUTIL;

END STPKS_STDCUSAC_UTILS_CUSTOM;
