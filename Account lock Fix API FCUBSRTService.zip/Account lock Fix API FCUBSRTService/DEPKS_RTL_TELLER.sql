CREATE OR REPLACE PACKAGE BODY depks_rtl_teller IS

  PKG_LCY                VARCHAR2(3);
  PKG_APPLICATION_DATE   DATE;
  PKG_REF_NO             VARCHAR2(16);
  PKG_BRANCH_COND_RECORD DETMS_BRANCH_COND%ROWTYPE;
  PKG_TXN_CUST           STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
  PKG_OFS_CUST           STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
  PKG_TXN_GL_TYPE        STTBS_ACCOUNT.GL_ACLASS_TYPE%TYPE;
  PKG_OFS_GL_TYPE        STTBS_ACCOUNT.GL_ACLASS_TYPE%TYPE;
  PKG_STTB_ACCOUNT       STTBS_ACCOUNT%ROWTYPE;
  PKG_BRN                STTMS_BRANCH.BRANCH_CODE%TYPE;
  PKG_CHG_ROW            IFTMS_ARC_MAINT%ROWTYPE;
  PKG_SHORT_NAME         STTMS_CUSTOMER.SHORT_NAME%TYPE;
  TYPE TB_RTLTELLER IS TABLE OF CSTBS_ARC_SETTLE%ROWTYPE INDEX BY BINARY_INTEGER;
  REC_ARCSETTLE           TB_RTLTELLER;
  G_ROW                   NUMBER := 1;
  G_TRACK_CHARGE_ENTRIES  VARCHAR2(1) := NULL;
  G_TRACK_ACCOUNT_ENTRIES VARCHAR2(1) := NULL;
  G_ARC_PICKP_REQD        BOOLEAN := TRUE;
  PKG_MAIN_ENTRIES_BUILT  BOOLEAN := FALSE;
  P_PARAM                 VARCHAR2(200);
  G_TXNAMT_FLAG           BOOLEAN := FALSE;
  G_OFSAMT_FLAG           BOOLEAN := FALSE;
  P_TRACK_CHG_ENTRY_NSF   VARCHAR2(1) := NULL;
  PKG_RED_AMT             NUMBER(22, 3) := 0;
  PKG_IS_TRACK_REQURD     CHAR := 'Y';

  TEMP_RTL_TELLER_REC DETBS_RTL_TELLER%ROWTYPE;

  PKG_TXN_EXCH_RATE DETB_RTL_TELLER.EXCH_RATE%TYPE := NULL;

  PKG_OFS_ACC  STTB_ACCOUNT%ROWTYPE;
  PKG_TXN_ACC  STTB_ACCOUNT%ROWTYPE;
  P_DB_LEG_CCY VARCHAR2(3);
  P_CR_LEG_CCY VARCHAR2(3);

  TYPE TY_RECEIVABLE_AMOUNT IS RECORD(
    TXN_TRACKED           VARCHAR2(1),
    TXN_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    TXN_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    TXN_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    TXN_AC_OR_GL          STTBS_ACCOUNT.AC_OR_GL%TYPE,
    TXN_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE,
    
    CHG1_TRACKED           VARCHAR2(1),
    CHG1_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    CHG1_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    CHG1_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    CHG1_TXN_OR_OFS        VARCHAR2(3),
    CHG1_COD_CHG_AMT       IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE,
    CHG1_AC_OR_GL          VARCHAR2(1),
    CHG1_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE,
    
    CHG2_TRACKED           VARCHAR2(1),
    CHG2_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    CHG2_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    CHG2_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    CHG2_TXN_OR_OFS        VARCHAR2(3),
    CHG2_COD_CHG_AMT       IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE,
    CHG2_AC_OR_GL          VARCHAR2(1),
    CHG2_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE,
    
    CHG3_TRACKED           VARCHAR2(1),
    CHG3_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    CHG3_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    CHG3_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    CHG3_TXN_OR_OFS        VARCHAR2(3),
    CHG3_COD_CHG_AMT       IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE,
    CHG3_AC_OR_GL          VARCHAR2(1),
    CHG3_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE,
    
    CHG4_TRACKED           VARCHAR2(1),
    CHG4_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    CHG4_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    CHG4_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    CHG4_TXN_OR_OFS        VARCHAR2(3),
    CHG4_COD_CHG_AMT       IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE,
    CHG4_AC_OR_GL          VARCHAR2(1),
    CHG4_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE,
    
    CHG5_TRACKED           VARCHAR2(1),
    CHG5_AC_NO             ACTB_DAILY_LOG.AC_NO%TYPE,
    CHG5_AC_BRANCH         ACTB_DAILY_LOG.AC_BRANCH%TYPE,
    CHG5_ACCY_AMT_TRACKED  ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
    CHG5_TXN_OR_OFS        VARCHAR2(3),
    CHG5_COD_CHG_AMT       IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE,
    CHG5_AC_OR_GL          VARCHAR2(1),
    CHG5_ACC_TRACK_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE);

  PKG_RECIVABLE_AMT_DET TY_RECEIVABLE_AMOUNT;

  PKG_NSF_TRACKED VARCHAR2(1) := 'N';

  PKG_INS_SETTLE_BLK_DONE VARCHAR2(1) := 'N';

  FUNCTION FN_INS_TXN_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF, I IN NUMBER)
    RETURN BOOLEAN;

  FUNCTION FN_INS_CHG_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF,
                            P_SEQ      IN NUMBER) RETURN BOOLEAN;

  FUNCTION FN_INS_SETTLE_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF, I IN NUMBER)
    RETURN BOOLEAN;

  PKG_TXN_BAL_DONE VARCHAR2(1) := 'N';
  PKG_OFS_BAL_DONE VARCHAR2(1) := 'N';

  PKG_LBAL_TXN STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
  PKG_LBAL_OFS STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;

  PKG_CLS_ACTAMT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'In Pr_Skip_Handler OF depks_rtl_teller ..');
  
    DEPKS_RTL_TELLER_CLUSTER.PR_SKIP_HANDLER(P_STAGE);
    DEPKS_RTL_TELLER_CUSTOM.PR_SKIP_HANDLER(P_STAGE);
  
  END PR_SKIP_HANDLER;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  
  END FN_SKIP_CLUSTER;

  PROCEDURE PR_GEN_REF_NO(P_ERR_CODE IN OUT VARCHAR2);
  PROCEDURE PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                    P_RET      IN OUT NUMBER);
  PROCEDURE PR_BUILD_CHG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                 P_CHG_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                 I          IN NUMBER,
                                 P_ERR_CODE IN OUT VARCHAR2,
                                 P_RET      IN OUT NUMBER);
  PROCEDURE PR_BUILD_CLOSE_AC_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                      P_RET      IN OUT NUMBER);
  PROCEDURE PR_BUILD_CLOSE_CHG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                       P_CHG_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                       I          IN NUMBER,
                                       P_ERR_CODE IN OUT VARCHAR2,
                                       P_RET      IN OUT NUMBER);

  PROCEDURE PR_BUILD_XRATE_P_AND_L_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                           P_ARC_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                           P_NEG_AMT  IN NUMBER,
                                           P_ERR_CODE IN OUT VARCHAR2,
                                           P_RET      IN OUT NUMBER);

  FUNCTION FN_VALIDATE_TXN_LIMIT(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF);
  FUNCTION FN_VALIDATE(P_ERR_CODE  IN OUT VARCHAR2,
                       P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN;
  PROCEDURE PR_CHECK_NOT_NULLS(P_RET      OUT NUMBER,
                               P_ERR_CODE IN OUT VARCHAR2,
                               P_PARAM    IN OUT VARCHAR2);
  PROCEDURE PR_CROSS_VALIDATIONS(P_RET      OUT NUMBER,
                                 P_ERR_CODE IN OUT VARCHAR2);
  PROCEDURE PR_INSTR_NO_VALS(P_RET       OUT NUMBER,
                             P_ERR_CODE  IN OUT VARCHAR2,
                             P_ERR_PARAM IN OUT VARCHAR2);
  PROCEDURE PR_CHK_BRN(P_BRN      IN VARCHAR2,
                       P_RET      OUT NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2);
  PROCEDURE PR_CHK_ACC(P_ACCOUNT  IN VARCHAR2,
                       P_BRANCH   IN VARCHAR2,
                       P_CUSTOMER OUT VARCHAR2,
                       P_GL_TYPE  OUT VARCHAR2,
                       P_CURRENCY IN OUT VARCHAR2,
                       P_RET      OUT NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2,
                       P_PARAM    IN OUT VARCHAR2);
  FUNCTION FN_IS_GL(P_BRN IN VARCHAR2,
                    P_ACC IN VARCHAR2,
                    P_CCY OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_CHECK_CUST_LIMIT(L_TBL_RESTR             IN OUT NOCOPY STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR,
                               TXN_ACC                 IN DETBS_RTL_TELLER.TXN_ACC%TYPE,
                               ACC_BRANCH              IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                               P_ERR_CODE              IN OUT VARCHAR2,
                               P_ERR_PARAM             IN OUT VARCHAR2,
                               TOTAL_CHARGE            IN NUMBER,
                               P_LEG_INDICATOR         IN VARCHAR2,
                               P_LINK_DELINK_INDICATOR IN VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE PR_MSGGEN(P_REF VARCHAR2, P_ERROR_CODE OUT VARCHAR2);
  PROCEDURE PR_UPDATE_REC;
  PROCEDURE PR_UPDATE_FAILURE(P_EXT_REF_NO IN VARCHAR2,
                              P_ERR_CODE   IN VARCHAR2);
  PROCEDURE PR_UPDATE_SUCCESS(P_EXT_REF_NO IN VARCHAR2);
  PROCEDURE PR_TRACK_ACCOUNT(TRN_REF_NO              IN VARCHAR2,
                             G_TRACK_CHARGE_ENTRIES  IN VARCHAR2,
                             G_TRACK_ACCOUNT_ENTRIES IN VARCHAR2);

  PROCEDURE PR_RESOLVE_CHG_WHOM(P_CHG_ROW     IN IFTMS_ARC_MAINT%ROWTYPE,
                                P_THEIR_CHGS  IN VARCHAR2,
                                P_CHG_ACC_CCY OUT VARCHAR2,
                                P_CHG_ACC     OUT VARCHAR2,
                                P_CHG_ACC_BRN OUT VARCHAR2);

  PROCEDURE PR_FETCH_CHG_DETAILS(P_RTL_TELLER  IN DETBS_RTL_TELLER%ROWTYPE,
                                 P_SNDRCHG1    OUT NUMBER,
                                 P_SNDRCHGCCY1 OUT VARCHAR2,
                                 P_SNDRCHG2    OUT NUMBER,
                                 P_SNDRCHGCCY2 OUT VARCHAR2,
                                 P_SNDRCHG3    OUT NUMBER,
                                 P_SNDRCHGCCY3 OUT VARCHAR2,
                                 P_SNDRCHG4    OUT NUMBER,
                                 P_SNDRCHGCCY4 OUT VARCHAR2,
                                 P_SNDRCHG5    OUT NUMBER,
                                 P_SNDRCHGCCY5 OUT VARCHAR2,
                                 P_RVRCHG1     OUT NUMBER,
                                 P_RVRCHGCCY1  OUT VARCHAR2
                                 
                                 );

  PROCEDURE PR_UPDATE_ENRICH(P_EXT_REF_NO IN VARCHAR2);

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
  
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'Depks_rtl_teller ==>' || P_DBG;
    
      DEBUG.PR_DEBUG('DE', L_MSG);
    
    END IF;
  
  END DBG;

  PROCEDURE PR_VALIDATE_DECEASED(PKG_TXN_CUST  IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                                 P_ACC         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                 P_ERROR_CODE  IN OUT VARCHAR2,
                                 P_ERROR_PARAM IN OUT VARCHAR2);

  FUNCTION FN_BULK_UPLOAD(P_BRN IN VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE  VARCHAR2(1000);
    L_ERR_PARAM VARCHAR2(1000);
    EACH_XREF   DETBS_RTL_TELLER.XREF%TYPE;
    CURSOR CR_RTL_RECORD(P_BRANCH VARCHAR2) IS
      SELECT XREF
        FROM DETBS_RTL_TELLER
       WHERE BRANCH_CODE = P_BRANCH
         AND (RECORD_STAT = 'U' OR RECORD_STAT = 'R');
  BEGIN
    OPEN CR_RTL_RECORD(P_BRN);
    LOOP
      FETCH CR_RTL_RECORD
        INTO EACH_XREF;
      EXIT WHEN CR_RTL_RECORD%NOTFOUND;
      IF NOT FN_UPLOAD(EACH_XREF, L_ERR_CODE, L_ERR_PARAM) THEN
        PR_UPDATE_FAILURE(EACH_XREF, L_ERR_CODE);
      ELSE
        PR_UPDATE_SUCCESS(EACH_XREF);
      END IF;
      L_ERR_CODE  := NULL;
      L_ERR_PARAM := NULL;
    END LOOP;
    CLOSE CR_RTL_RECORD;
    RETURN TRUE;
  END FN_BULK_UPLOAD;

  PROCEDURE PR_UPDATE_TRACKED_BALANCES(P_CONTRACT_REF_NO IN CSTB_CONTRACT.CONTRACT_REF_NO%TYPE) IS
  
    CURSOR CR_UPDATE_BALANCES IS
      SELECT *
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO
         AND AMOUNT_DUE != AMOUNT_PAID;
    L_AMOUNT_TO_BE_RELEASED NUMBER(22, 3) := 0;
  
  BEGIN
  
    FOR REC IN CR_UPDATE_BALANCES LOOP
    
      L_AMOUNT_TO_BE_RELEASED := REC.AMOUNT_AVAILABLE;
    
      DBG('account is :::: ' || REC.ACCOUNT_NO);
    
      DBG('L_AMOUNT_TO_BE_RELEASED is :::: ' || L_AMOUNT_TO_BE_RELEASED);
    
      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(REC.ACCOUNT_NO,
                                                     REC.ACCOUNT_BR,
                                                     'D',
                                                     L_AMOUNT_TO_BE_RELEASED);
      DEBUG.PR_DEBUG('LD', 'after updating recievable');
    
    END LOOP;
  
    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
      (SELECT *
         FROM CSTB_AUTO_SETTLE_BLOCK
        WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO);
  
    DBG('umber of rows iserted IN TEMP are :::: ' || SQL%ROWCOUNT);
    DELETE CSTB_AUTO_SETTLE_BLOCK
     WHERE CONTRACT_REF_NO = P_CONTRACT_REF_NO;
  
  END;

  PROCEDURE PR_VALIDATE_DECEASED(PKG_TXN_CUST  IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                                 P_ACC         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                 P_ERROR_CODE  IN OUT VARCHAR2,
                                 P_ERROR_PARAM IN OUT VARCHAR2)
  
   IS
    L_CUST_FROZEN             STTMS_CUSTOMER.FROZEN%TYPE;
    L_CUST_DECEASED           STTMS_CUSTOMER.DECEASED%TYPE;
    L_CUSTWHEREABOUTS_UNKNOWN STTMS_CUSTOMER.WHEREABOUTS_UNKNOWN%TYPE;
  
    L_JOINT_IND      STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR%TYPE;
    L_JOINT_CUSTOMER STTMS_AC_LINKED_ENTITIES.JOINT_HOLDER_CODE%TYPE;
    L_OPMODE         STTMS_CUST_ACCOUNT.MODE_OF_OPERATION%TYPE;
  
    L_JOINT_CUST_DECEASED STTMS_CUSTOMER.DECEASED%TYPE;
    L_JOINT_CUST          STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_AC_STAT_FROZEN      STTB_ACCOUNT.AC_STAT_FROZEN%TYPE;
    CURSOR JOINT_CUST IS
      SELECT JOINT_HOLDER_CODE
        FROM STTMS_AC_LINKED_ENTITIES
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    L_JOINT_CUST_REC JOINT_CUST%ROWTYPE;
    L_IS_ALIVE       CHAR := 'N';
    L_IS_DECEASED    CHAR := 'N';
  
  BEGIN
    DBG('Going inside Pr_validate_deceased with customer_no  ' ||
        PKG_TXN_CUST || '~p_acc: ' || P_ACC || '~p_brn: ' || P_BRN);
    BEGIN
      SELECT FROZEN, DECEASED, WHEREABOUTS_UNKNOWN, SHORT_NAME
        INTO L_CUST_FROZEN,
             L_CUST_DECEASED,
             L_CUSTWHEREABOUTS_UNKNOWN,
             PKG_SHORT_NAME
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = PKG_TXN_CUST;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('no customer record found');
      WHEN OTHERS THEN
        DBG('Error in selecting customer number');
      
    END;
    DBG('customer status   ' || L_CUST_FROZEN || '--' || L_CUST_DECEASED || '--' ||
        L_CUSTWHEREABOUTS_UNKNOWN);
    IF NVL(L_CUST_FROZEN, '**') = 'Y' THEN
    
      P_ERROR_CODE  := 'ST-CIF157';
      P_ERROR_PARAM := PKG_TXN_CUST;
      OVPKS.PR_APPENDTBL(P_ERROR_CODE, P_ERROR_PARAM);
    
    END IF;
  
    BEGIN
      SELECT JOINT_AC_INDICATOR, MODE_OF_OPERATION
        INTO L_JOINT_IND, L_OPMODE
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('no record found ');
    END;
    DBG('joint account idicator is' || L_JOINT_IND);
    DBG('modeof operation is' || L_OPMODE);
  
    IF L_JOINT_IND = 'S' THEN
      DBG('Joint Indicator is Single');
      IF NVL(L_CUST_DECEASED, '**') = 'Y' THEN
        DBG('The customer is deceased.......');
        OVPKS.PR_APPENDTBL('ST-CIF163', '');
      END IF;
    ELSIF L_JOINT_IND = 'J' THEN
      DBG('Joint indicator is joint');
    
      FOR L_JOINT_CUST_REC IN JOINT_CUST LOOP
        DBG('Joint customer is>>' || L_JOINT_CUST_REC.JOINT_HOLDER_CODE);
      
        SELECT DECEASED
          INTO L_JOINT_CUST_DECEASED
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = L_JOINT_CUST_REC.JOINT_HOLDER_CODE;
        DBG('Joint customer status is >>' || L_JOINT_CUST_DECEASED);
      
        IF L_JOINT_CUST_DECEASED = 'Y' THEN
          L_IS_DECEASED := 'Y';
          DBG('l_is_deceased is >>' || L_IS_DECEASED);
        END IF;
      
        IF L_JOINT_CUST_DECEASED = 'N' THEN
          L_IS_ALIVE := 'Y';
          DBG('l_is_alive is >>' || L_IS_ALIVE);
        END IF;
      
      END LOOP;
      IF L_IS_ALIVE = 'N' AND NVL(L_CUST_DECEASED, '*.*') = 'Y' AND
         NVL(L_OPMODE, '**') IN ('E', 'F', 'J') THEN
        DBG('Opmode is Anyone or survivor/Former or survivor and ALL customers are deceased');
        OVPKS.PR_APPENDTBL('ST-CIF164', '');
      
      ELSIF (L_IS_DECEASED = 'Y' OR NVL(L_CUST_DECEASED, '*.*') = 'Y') AND
            NVL(L_OPMODE, '**') = 'J' THEN
        DBG('Opmode is jointly and either one customer is deceased');
        OVPKS.PR_APPENDTBL('ST-CIF164', '');
      
      END IF;
    
    END IF;
  
    IF NVL(L_CUSTWHEREABOUTS_UNKNOWN, '**') = 'Y' THEN
      P_ERROR_CODE  := 'ST-CIF159';
      P_ERROR_PARAM := PKG_TXN_CUST;
      OVPKS.PR_APPENDTBL(P_ERROR_CODE, P_ERROR_PARAM);
    END IF;
    DBG('Returning successfully from pr_validate_deceased..');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IN WOT bec of - ' || SQLERRM);
    
  END PR_VALIDATE_DECEASED;

  FUNCTION FN_VALIDATE_TXN_LIMIT(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_CUSTOMER_NO VARCHAR2(9);
  BEGIN
    DBG('Inside fn_validate_txn_limit before calling smpks_fcj_txnlimitchk');
    DBG('Rel customer ==>' || PKG_RTL_TELLER_REC.REL_CUSTOMER);
    L_CUSTOMER_NO := PKG_RTL_TELLER_REC.REL_CUSTOMER;
    IF PKG_RTL_TELLER_REC.REL_CUSTOMER IS NULL THEN
      DBG('Rel cust is null');
      DBG('Acc no =>' || PKG_RTL_TELLER_REC.TXN_ACC || '~ Branch =>' ||
          PKG_RTL_TELLER_REC.BRANCH_CODE);
      BEGIN
        SELECT CUST_NO
          INTO L_CUSTOMER_NO
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = PKG_RTL_TELLER_REC.TXN_ACC
           AND BRANCH_CODE = PKG_RTL_TELLER_REC.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In No_data_found ' || SQLERRM);
          RETURN TRUE;
      END;
    END IF;
    DBG('Rel cust is ' || L_CUSTOMER_NO);
    IF NOT
        SMPKSS_FCJ_TXNLIMITCHK.FN_VALIDATE_PRODUCT_TXN_LIMIT(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                                             'RT',
                                                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                                             PKG_RTL_TELLER_REC.TRN_REF_NO,
                                                             PKG_RTL_TELLER_REC.ESN,
                                                             L_CUSTOMER_NO,
                                                             PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
      DBG('Failed in validating Product tarnsaction limits');
      IF P_ERR_CODE IS NULL THEN
        P_ERR_CODE  := 'CS-PLMT-003';
        P_ERR_PARAM := NULL;
      END IF;
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END;

  FUNCTION FN_USER_ALLOWED_ACC(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT         NUMBER;
    L_ACCOUNT_CLASS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_BRN           STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_ALLOWED_CLS_FLAG      CHAR := 'N';
    L_ALLOWED_AC_CLS_EXISTS CHAR := 'Y';
  
    CURSOR DISALLOWED_ACCCLASS_LIST(USERID SMTB_USER.USER_ID%TYPE) IS
      SELECT C.ACCOUNT_CLASS
        FROM SMTBS_ROLE_ACCCLASS C, SMTB_ROLE_MASTER D
       WHERE C.ROLE_ID = D.ROLE_ID
         AND C.ROLE_ID IN
             (SELECT ROLE_ID
                FROM SMVWS_CONSOLIDATED_USERROLE
               WHERE SMVWS_CONSOLIDATED_USERROLE.USER_ID = USERID)
         AND D.ACCCLASS_ALLOWED = 'D';
  
    CURSOR ALLOWED_ACCCLASS_LIST(USERID SMTB_USER.USER_ID%TYPE) IS
      SELECT C.ACCOUNT_CLASS
        FROM SMTBS_ROLE_ACCCLASS C, SMTB_ROLE_MASTER D
       WHERE C.ROLE_ID = D.ROLE_ID
         AND C.ROLE_ID IN
             (SELECT ROLE_ID
                FROM SMVWS_CONSOLIDATED_USERROLE
               WHERE SMVWS_CONSOLIDATED_USERROLE.USER_ID = USERID)
         AND D.ACCCLASS_ALLOWED = 'A';
  
    PROCEDURE PR_VALIDATE_ACCOUNT_CLASS(L_ACCOUNT_CLASS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                                        L_BRN           STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                        L_AC_OR_GL      STTB_ACCOUNT.AC_OR_GL%TYPE) AS
    
    BEGIN
      IF L_AC_OR_GL = 'A' THEN
      
        DBG('Inside procedure pr_validate_account_class');
        DBG('The account class is:' || L_ACCOUNT_CLASS ||
            ' with branch as:' || L_BRN);
        DBG('Checking for Branch restrictions');
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STVWS_ACLASS_BRANCHES
         WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS
           AND BRANCH_CODE = L_BRN;
        IF L_COUNT = 0 THEN
          DBG('Account class not allowed for the current branch');
          P_ERR_CODE  := 'ST-CUS03';
          P_ERR_PARAM := '~';
        END IF;
      
        DBG('Checking for User restrictions for the user: ' ||
            GLOBAL.USER_ID);
        SELECT COUNT(*)
          INTO L_COUNT
          FROM SMVW_USER_ACCCLASS
         WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS
           AND USER_ID = GLOBAL.USER_ID;
        IF L_COUNT = 0 THEN
          DBG('Account class not allowed for the current user');
          IF P_ERR_CODE IS NOT NULL THEN
            P_ERR_CODE  := P_ERR_CODE || ';' || 'ST-ACC-155';
            P_ERR_PARAM := P_ERR_PARAM || ';' || '~';
          ELSE
            P_ERR_CODE  := 'ST-ACC-155';
            P_ERR_PARAM := '~';
          END IF;
        END IF;
      
        DBG('Account class validation in Role level');
        FOR I IN DISALLOWED_ACCCLASS_LIST(GLOBAL.USER_ID) LOOP
          DBG('Account class restricted: ' || I.ACCOUNT_CLASS);
          IF (I.ACCOUNT_CLASS = L_ACCOUNT_CLASS) THEN
            DBG('Account class is restricted for the user ' ||
                GLOBAL.USER_ID);
            IF P_ERR_CODE IS NOT NULL THEN
              P_ERR_CODE  := P_ERR_CODE || ';' || 'ST-ACC-155';
              P_ERR_PARAM := P_ERR_PARAM || ';' || '~';
            ELSE
              P_ERR_CODE  := 'ST-ACC-155';
              P_ERR_PARAM := '~';
            END IF;
          END IF;
        END LOOP;
      
        DBG('Account class validation in Role level for allowed list starts');
        L_ALLOWED_AC_CLS_EXISTS := 'N';
        L_ALLOWED_CLS_FLAG      := 'N';
        FOR I IN ALLOWED_ACCCLASS_LIST(GLOBAL.USER_ID) LOOP
          L_ALLOWED_AC_CLS_EXISTS := 'Y';
          DBG('Account class ALLOWED from cursor: ' || I.ACCOUNT_CLASS ||
              ' Actual account class of account ' || L_ACCOUNT_CLASS);
          IF (I.ACCOUNT_CLASS = L_ACCOUNT_CLASS) THEN
            DBG('Account class is allowed for the user ' || GLOBAL.USER_ID);
            L_ALLOWED_CLS_FLAG := 'Y';
          END IF;
          DBG('l_allowed_cls_flag  ' || L_ALLOWED_CLS_FLAG);
        END LOOP;
        DBG('l_allowed_cls_flag finally  ' || L_ALLOWED_CLS_FLAG ||
            ' l_allowed_ac_cls_exists  ' || L_ALLOWED_AC_CLS_EXISTS);
        IF L_ALLOWED_CLS_FLAG <> 'Y' AND L_ALLOWED_AC_CLS_EXISTS = 'Y' THEN
          IF P_ERR_CODE IS NOT NULL THEN
            P_ERR_CODE  := P_ERR_CODE || ';' || 'ST-ACC-155';
            P_ERR_PARAM := P_ERR_PARAM || ';' || '~';
          ELSE
            P_ERR_CODE  := 'ST-ACC-155';
            P_ERR_PARAM := '~';
          END IF;
        END IF;
        DBG('Account class validation in Role level for allowed list ends');
      
      END IF;
      DBG('depks_rtl_teller pr_validate_account_class returning true');
    END PR_VALIDATE_ACCOUNT_CLASS;
  
    PROCEDURE PR_VALIDATE_GL(L_AC_OR_GL_NO STTB_ACCOUNT.AC_GL_NO%TYPE) AS
      L_GL_COUNT NUMBER := 0;
    BEGIN
      DBG('Start of pr_validate_gl');
      DBG('USER ID = ' || GLOBAL.USER_ID);
      DBG('Account = ' || L_AC_OR_GL_NO);
    
      SELECT COUNT(*)
        INTO L_GL_COUNT
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = L_AC_OR_GL_NO
         AND AC_OR_GL = 'G'
         AND AUTH_STAT = 'A';
    
      DBG('l_Gl_Count = ' || L_GL_COUNT);
      IF L_GL_COUNT > 0 THEN
        DBG('Pkg_Func = ' || GWPKS_UTIL.PKG_FUNC);
        DBG('Calling Glrestrict.Fn_Checkgl');
        IF GLRESTRICT.FN_CHECKGL(GLOBAL.USER_ID, L_AC_OR_GL_NO) = 'Y' THEN
          DBG('GL is Allowed');
        ELSE
          DBG('GL is Disallowed');
          IF P_ERR_CODE IS NOT NULL THEN
            P_ERR_CODE  := P_ERR_CODE || ';' || 'DE-TUD-103';
            P_ERR_PARAM := P_ERR_PARAM || ';' || L_AC_OR_GL_NO || '~';
          ELSE
            P_ERR_CODE  := 'DE-TUD-103';
            P_ERR_PARAM := L_AC_OR_GL_NO || '~';
          END IF;
        END IF;
      END IF;
      DBG('End of pr_validate_gl returning true');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Faile in pr_validate_gl. ' || SQLERRM || ', ' ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END PR_VALIDATE_GL;
  
    PROCEDURE PR_VAL_CUST_GRP_RESTR(L_CUSTOMER_NO STTB_ACCOUNT.CUST_NO%TYPE) AS
      L_RSTR_COUNT NUMBER := 1;
    BEGIN
      DBG('Start of pr_val_cust_grp_restr');
      DBG('USER ID = ' || GLOBAL.USER_ID);
      DBG('Account = ' || L_CUSTOMER_NO);
    
      SELECT COUNT(*)
        INTO L_RSTR_COUNT
        FROM STTMS_CUSTOMER A
       WHERE A.CUSTOMER_NO = L_CUSTOMER_NO
         AND ((A.GROUP_CODE IS NOT NULL AND EXISTS
              (SELECT 1
                  FROM STVWS_USER_GROUP B
                 WHERE B.USER_ID = GLOBAL.USER_ID
                   AND B.GROUP_CODE = A.GROUP_CODE)) OR
             A.GROUP_CODE IS NULL);
    
      DBG('l_rstr_Count = ' || L_RSTR_COUNT);
      IF L_RSTR_COUNT = 0 THEN
        DBG('User is restricted to query the details of this customer');
        IF P_ERR_CODE IS NOT NULL THEN
          P_ERR_CODE  := P_ERR_CODE || ';' || 'ST-ACCS-02';
          P_ERR_PARAM := P_ERR_PARAM || ';' || L_CUSTOMER_NO || '~';
        ELSE
          P_ERR_CODE  := 'ST-ACCS-02';
          P_ERR_PARAM := L_CUSTOMER_NO || '~';
        END IF;
      END IF;
      DBG('End of pr_val_cust_grp_restr returning true');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Faile in pr_val_cust_grp_restr. ' || SQLERRM || ', ' ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END PR_VAL_CUST_GRP_RESTR;
  
  BEGIN
    DBG('Inside Fn_User_Allowed_Acc');
  
    DBG('Checking whether Product is allowed for user or not');
    IF NOT
        CSPKS_PRODUCT_CHECKS.FN_USER_PROD_ACCESS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
      DBG('Returned False');
      P_ERR_CODE  := 'DE-TUD-111';
      P_ERR_PARAM := PKG_RTL_TELLER_REC.PRODUCT_CODE || '~';
      RETURN FALSE;
    END IF;
  
    DBG('The transaction branch is:' || PKG_RTL_TELLER_REC.TXN_BRANCH ||
        ' with transaction account as:' || PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('The offset branch is:' || PKG_RTL_TELLER_REC.OFS_BRANCH ||
        ' with offset account as:' || PKG_RTL_TELLER_REC.OFS_ACC);
  
    DBG('The transaction Account is GL OR CASA = ' || PKG_TXN_ACC.AC_OR_GL);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('Calling depks_rtl_teller_cluster.Fn_User_Allowed_Acc.. ');
      IF NOT
          DEPKS_RTL_TELLER_CLUSTER.FN_USER_ALLOWED_ACC(PKG_RTL_TELLER_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('FAILED IN depks_rtl_teller_cluster.Fn_User_Allowed_Acc...');
      END IF;
      DBG(' failed in depks_rtl_teller_cluster.Fn_User_Allowed_Acc');
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      PR_VALIDATE_ACCOUNT_CLASS(PKG_TXN_ACC.AC_CLASS,
                                PKG_TXN_ACC.BRANCH_CODE,
                                PKG_TXN_ACC.AC_OR_GL);
    
      PR_VALIDATE_ACCOUNT_CLASS(PKG_OFS_ACC.AC_CLASS,
                                PKG_OFS_ACC.BRANCH_CODE,
                                PKG_OFS_ACC.AC_OR_GL);
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('Calling depks_rtl_teller_cluster.Fn_User_Allowed_Acc.. ');
      IF NOT
          DEPKS_RTL_TELLER_CLUSTER.FN_USER_ALLOWED_ACC(PKG_RTL_TELLER_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('FAILED IN depks_rtl_teller_cluster.Fn_User_Allowed_Acc...');
      END IF;
      DBG(' failed in depks_rtl_teller_cluster.Fn_User_Allowed_Acc');
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      PR_VALIDATE_GL(PKG_TXN_ACC.AC_GL_NO);
      DBG('The offset Account is GL OR CASA = ' || PKG_OFS_ACC.AC_OR_GL);
      PR_VALIDATE_GL(PKG_OFS_ACC.AC_GL_NO);
    
      DBG('The offset Account is GL OR CASA@@ = ' || PKG_TXN_ACC.AC_OR_GL);
      IF PKG_TXN_ACC.AC_OR_GL = 'A' THEN
        PR_VAL_CUST_GRP_RESTR(PKG_TXN_ACC.CUST_NO);
      END IF;
      IF PKG_OFS_ACC.AC_OR_GL = 'A' THEN
        PR_VAL_CUST_GRP_RESTR(PKG_OFS_ACC.CUST_NO);
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF P_ERR_CODE IS NOT NULL THEN
      DBG('The error thrown for offset account is:' || P_ERR_CODE ||
          ' with error param as:' || P_ERR_PARAM);
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_User_Allowed_Acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      IF P_ERR_CODE IS NOT NULL THEN
        P_ERR_CODE  := P_ERR_CODE || ';' || 'ST-ACC-100';
        P_ERR_PARAM := P_ERR_PARAM || ';' ||
                       'User against Account Validation~';
      ELSE
        P_ERR_CODE  := 'ST-ACC-100';
        P_ERR_PARAM := 'User against Account Validation~';
      END IF;
      RETURN FALSE;
  END FN_USER_ALLOWED_ACC;

  FUNCTION FN_PROD_ALLOWED_ACC(PKG_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                               P_ERR_CODE         IN OUT VARCHAR2,
                               P_ERR_PARAM        IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT_PROD NUMBER := 0;
  
    L_TXN_COUNT NUMBER := 0;
    L_OFS_COUNT NUMBER := 0;
  
  BEGIN
    DBG('Inside cgpks_upload_utils.fn_prod_allowed_for_rem_acc....');
  
    IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                    PKG_RTL_TELLER_REC.TXN_ACC,
                                    PKG_TXN_ACC) THEN
      P_ERR_CODE := 'DE-TUD-055';
      RETURN FALSE;
    END IF;
    DBG('pkg_Txn_Acc.Ac_Or_Gl = ' || PKG_TXN_ACC.AC_OR_GL);
    DBG('Pkg_Arc_Row.Dr_Ac' || PKG_ARC_ROW.DR_ACC);
    IF PKG_TXN_ACC.AC_OR_GL = 'A' THEN
      IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
        DBG('Debit transaction for TXN');
        SELECT COUNT(*)
          INTO L_TXN_COUNT
          FROM CSVWS_ALLOWED_PRODUCTS
         WHERE CUSTAC = PKG_RTL_TELLER_REC.TXN_ACC
           AND BRANCH_CODE = PKG_RTL_TELLER_REC.TXN_BRANCH
           AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
           AND DEBIT_TXN = 'Y';
      ELSE
        SELECT COUNT(*)
          INTO L_TXN_COUNT
          FROM CSVWS_ALLOWED_PRODUCTS
         WHERE CUSTAC = PKG_RTL_TELLER_REC.TXN_ACC
           AND BRANCH_CODE = PKG_RTL_TELLER_REC.TXN_BRANCH
           AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
           AND CREDIT_TXN = 'Y';
      END IF;
      IF L_TXN_COUNT = 0 THEN
        DBG('TXN Leg :: transaction is not allowed for this customer and product');
        OVPKSS.PR_APPENDTBL('AC-PROD2',
                            PKG_RTL_TELLER_REC.PRODUCT_CODE || '~' ||
                            PKG_RTL_TELLER_REC.TXN_ACC || '~;');
      END IF;
    END IF;
  
    DBG('pkg_arc_row.cod_main_offset_flag in function Fn_Prod_Allowed_Acc before calling Cvpks_Utils :: ' ||
        PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG);
    IF NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'Y' THEN
      DBG('Calling Cvpks_Utils.Get_Sttb_Acc');
      IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                      PKG_RTL_TELLER_REC.OFS_ACC,
                                      PKG_OFS_ACC) THEN
        P_ERR_CODE := 'DE-TUD-055';
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('pkg_Ofs_Acc.Ac_Or_Gl = ' || PKG_OFS_ACC.AC_OR_GL);
    IF PKG_OFS_ACC.AC_OR_GL = 'A' THEN
      IF PKG_ARC_ROW.DR_ACC = 'OFS' THEN
        DBG('Debit transaction of OFS');
        SELECT COUNT(*)
          INTO L_OFS_COUNT
          FROM CSVWS_ALLOWED_PRODUCTS
         WHERE CUSTAC = PKG_RTL_TELLER_REC.OFS_ACC
           AND BRANCH_CODE = PKG_RTL_TELLER_REC.OFS_BRANCH
           AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
           AND DEBIT_TXN = 'Y';
      ELSE
        SELECT COUNT(*)
          INTO L_OFS_COUNT
          FROM CSVWS_ALLOWED_PRODUCTS
         WHERE CUSTAC = PKG_RTL_TELLER_REC.OFS_ACC
           AND BRANCH_CODE = PKG_RTL_TELLER_REC.OFS_BRANCH
           AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
           AND CREDIT_TXN = 'Y';
      END IF;
      IF L_OFS_COUNT = 0 THEN
        DBG('OFS Leg :: Transaction is not allowed for this customer and product');
        OVPKSS.PR_APPENDTBL('AC-PROD2',
                            PKG_RTL_TELLER_REC.PRODUCT_CODE || '~' ||
                            
                            PKG_RTL_TELLER_REC.OFS_ACC || '~;');
      
      END IF;
    END IF;
    DBG('Out of Fn_Prod_Allowed_Acc');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of fn_prod_allowed_acc..');
      DBG(SQLERRM);
      OVPKSS.PR_APPENDTBL('GW-RTL-002', '');
      RETURN FALSE;
  END FN_PROD_ALLOWED_ACC;

  FUNCTION FN_UPLOAD(P_REC_RTL_TELLER IN DETBS_RTL_TELLER%ROWTYPE,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN
  
   IS
  
    L_FUNDID      AMTM_FUND_MASTER.FUND_ID%TYPE;
    L_FUND_REF_NO AMTM_FUND_MASTER.FUND_REFERENCE_NO%TYPE;
    L_FUND_BRANCH STTM_BRANCH.FUND_BRANCH%TYPE;
  
    P_RET NUMBER := 0;
    
     --sampath starts
    L_BLOCK_ID VARCHAR2(100);
    --sampath ends
    
  BEGIN
    DBG('Issued Savepoint');
    SAVEPOINT SP_TELLER;
  
    IF NVL(P_REC_RTL_TELLER.MODULE, 's^') IN ('CL', 'MO') THEN
      PKG_RTL_TELLER_REC := P_REC_RTL_TELLER;
    
      PR_SET_GLOBAL(P_ERR_CODE);
    
    ELSE
    
      IF DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        DBG('fn_upload of 3 parameters.... Calling pr_initialize for Online Closure charges with 3 parameters');
        DBG('Xref.... p_rec_rtl_teller.xref :: ' || P_REC_RTL_TELLER.XREF);
        DBG('Trn_ref_no.... p_rec_rtl_teller.trn_ref_no :: ' ||
            P_REC_RTL_TELLER.TRN_REF_NO);
        PR_INITIALIZE(P_REC_RTL_TELLER.XREF,
                      P_REC_RTL_TELLER.TRN_REF_NO,
                      P_ERR_CODE);
      ELSE
        DBG('In fn_upload... Calling pr_initialize with 2 Parameters');
        DBG('Xref is ---->' || P_REC_RTL_TELLER.XREF);
      
        IF NVL(GWPKS_UTIL.PKG_FUNC, '*') <> '1317' THEN
          PR_INITIALIZE(P_REC_RTL_TELLER.XREF, P_ERR_CODE);
        
        ELSE
          DBG('>>skipped pr_initialize again for 1317');
        END IF;
      
      END IF;
    
    END IF;
  
    DBG('Initialized');
  
    IF P_ERR_CODE IS NOT NULL AND
       DEPKSS_RETAILTELLERUPLOAD.FN_IS_AN_ERROR_RAISED(P_RET) THEN
      DBG('Error found..');
    
      ROLLBACK TO SP_TELLER;
    
      PR_UPDATE_FAILURE(P_REC_RTL_TELLER.XREF, P_ERR_CODE);
    
      RETURN FALSE;
    END IF;
    PR_SUPERSCRIBE_ARC;
    DBG('Superscribed ARC');
    IF PKG_RTL_TELLER_REC.TRN_REF_NO IS NULL THEN
      PR_GEN_REF_NO(P_ERR_CODE);
    END IF;
  
    DBG('Gen ref no as ....' || PKG_RTL_TELLER_REC.TRN_REF_NO);
  
    IF P_ERR_CODE IS NOT NULL AND
       DEPKSS_RETAILTELLERUPLOAD.FN_IS_AN_ERROR_RAISED(P_RET) THEN
      DBG('Error found..');
    
      ROLLBACK TO SP_TELLER;
    
      PR_UPDATE_FAILURE(P_REC_RTL_TELLER.XREF, P_ERR_CODE);
    
      RETURN FALSE;
    END IF;
    DBG('checking error code............' || P_ERR_CODE);
    DBG('After this is a site specific change for hebros debit_cards.');
  
    DBG('To call fn save.');
  
    IF NVL(GWPKS_UTIL.PKG_FUNC, '*') NOT IN
       ('1056',
        '1410',
        '1411',
        '5555',
        '6560',
        '7010',
        '7011',
        '7030',
        '7031',
        '7789',
        '7790',
        '7795',
        '8323',
        '8324',
        '9007',
        '9008',
        '9020',
        'BCDI',
        'BCFT',
        'BCRP',
        'BCRV',
        'CQIN',
        'DDDI',
        'DDRP',
        'DDRV',
        'EODM',
        'IPTDMM',
        'SCTT',
        'TDTP') THEN
      IF NOT
          MIPKSS_REFERRAL.FN_GET_CON_DEFAULT(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                             PKG_RTL_TELLER_REC.TRN_REF_NO,
                                             PKG_RTL_TELLER_REC.REL_CUSTOMER,
                                             PKG_RTL_TELLER_REC.TXN_CCY) THEN
        P_ERR_CODE := 'MI-DEF02';
        ROLLBACK TO SP_TELLER;
      
        PR_UPDATE_FAILURE(P_REC_RTL_TELLER.XREF, P_ERR_CODE);
      
        RETURN FALSE;
      END IF;
    END IF;
  
    IF GWPKS_UTIL.PKG_ACTTYPE = 'SCAUTOAUTH' THEN
      PKG_RTL_TELLER_REC.AUTH_STAT := 'A';
    END IF;
  
    DBG('WILL SAVE AS UNAUTH,ENRICH etc...kya karen...');
  
    DBG('Source code is ==>' || PKG_RTL_TELLER_REC.SCODE);
  
    IF PKG_RTL_TELLER_REC.SCODE NOT IN ('FLEXCUBE', 'FLEXBRANCH') THEN
    
      DBG('Source is FlexSwitch');
      IF NOT
          FN_VALIDATE_TXN_LIMIT(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('Failed inside fn_validate_txn_limit');
      
        DBG('Error code-->' || P_ERR_CODE);
        DBG('Error param-->' || P_ERR_PARAM);
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      
      END IF;
    END IF;
  
    DBG('CHG1234 Currency here --> ' || PKG_ARC_ROW.COD_CHG_CCY);
  
    IF NOT FN_SAVE(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM) THEN
    
      DBG('Got back false from fn_save ' || P_ERR_CODE);
      ROLLBACK TO SP_TELLER;
      PR_UPDATE_FAILURE(PKG_RTL_TELLER_REC.XREF, P_ERR_CODE);
      
      --sampath starts
         IF SUBSTR(Depks_rtl_teller.pkg_rtl_teller_rec.xref,4,4) = 'KHQE' THEN
           
         IF NOT CASAPKS.FN_CREATE_AMOUNT_BLOCK(Depks_rtl_teller.pkg_rtl_teller_rec.trn_dt,--L_BRANCH_DATE,
                                            Depks_rtl_teller.pkg_rtl_teller_rec.ofs_branch,--L_ACC_BRANCH,
                                            Depks_rtl_teller.pkg_rtl_teller_rec.ofs_acc,--L_ACCOUNT,
                                            Depks_rtl_teller.pkg_rtl_teller_rec.ofs_amount,--L_AMOUNT,
                                            Depks_rtl_teller.pkg_rtl_teller_rec.trn_dt,--L_EFFECTIVE_DATE,
                                            NULL,--L_EXPIRY_DATE,
                                            'ACCOUNT BALANCE UPDATE ERROR',
                                            L_BLOCK_ID,
                                            Depks_rtl_teller.pkg_rtl_teller_rec.xref,
                                            NULL,
                                            'F',--L_BLOCK_TYPE,
                                            P_ERR_CODE,
                                            P_ERR_PARAM,
                                            'KHQE_CODE') THEN
        DBG('casapks.fn_create_amount_block' || SQLCODE);
        RETURN FALSE;
      
      END IF;
     -- L_CADAMBLK.V_CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO := L_BLOCK_ID;
         
     RETURN TRUE;
         
         END IF;
         --sampath ends
      RETURN FALSE;
    END IF;
  
    DBG('Back from acctg ' || P_ERR_CODE);
  
    IF GWPKS_UTIL.G_FROM_BEAN OR PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' THEN
    
      DBG('Calling pr_update_success for branch transactions');
      PR_UPDATE_SUCCESS(P_REC_RTL_TELLER.XREF);
    END IF;
  
    DBG('The route Code is ' || PKG_RTL_TELLER_REC.ROUTE_CODE ||
        ' , auth_stat' || PKG_RTL_TELLER_REC.AUTH_STAT);
    IF PKG_RTL_TELLER_REC.AUTH_STAT = 'A' THEN
    
      IF PKG_RTL_TELLER_REC.ROUTE_CODE IS NOT NULL THEN
        BEGIN
          DBG('Calling pr_msgins ');
        
          PR_MSGINS(P_REC_RTL_TELLER.XREF, P_ERR_CODE);
        
          DBG('After msgins ' || P_ERR_CODE);
        
          IF P_ERR_CODE IS NOT NULL THEN
            RETURN FALSE;
          END IF;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Exception pr_msgins for ' || SQLERRM);
          
            RETURN FALSE;
        END;
      END IF;
      PR_GENERATE_ICDODCADVICE(PKG_RTL_TELLER_REC.TRN_REF_NO);
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error is ' || SQLERRM);
      RETURN FALSE;
  END FN_UPLOAD;

  FUNCTION FN_GET_G_MODULE RETURN VARCHAR2 IS
  BEGIN
    RETURN NVL(G_MODULE, '**');
  END;

  FUNCTION FN_UPLOAD(P_EXT_REF_NO IN VARCHAR2,
                     P_ERR_CODE   IN OUT VARCHAR2,
                     P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ARC_ROW IFTMS_ARC_MAINT%ROWTYPE;
  BEGIN
    IF NOT FN_UPLOAD(P_EXT_REF_NO, TRUE, L_ARC_ROW, P_ERR_CODE, P_ERR_PARAM) THEN
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error is ' || SQLERRM);
      RETURN FALSE;
  END FN_UPLOAD;

  FUNCTION FN_UPLOAD(P_EXT_REF_NO     IN VARCHAR2,
                     P_ARC_PICKUP_REQ IN BOOLEAN,
                     P_ARC_ROW        IN IFTMS_ARC_MAINT%ROWTYPE,
                     P_ERR_CODE       IN OUT VARCHAR2,
                     P_ERR_PARAM      IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_REC_RTL_TELLER DETBS_RTL_TELLER%ROWTYPE;
  
  BEGIN
  
    DBG('Entered into Depks_Rtl_Teller.fn_upload with ref no as parameter, ref: ' ||
        P_EXT_REF_NO);
  
    G_ARC_PICKP_REQD := P_ARC_PICKUP_REQ;
  
    IF NOT P_ARC_PICKUP_REQ THEN
      DBG('Setting arc row here');
      PKG_ARC_ROW := P_ARC_ROW;
    END IF;
  
    IF DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
      DBG('fn_upload of 5 parameters.... Calling pr_initialize for Online Closure charges with 3 parameters');
      DBG('p_ext_ref_no is :: ' || P_EXT_REF_NO);
      DBG('Trn_ref_no is.. pkg_rtl_teller_rec.trn_ref_no :: ' ||
          PKG_RTL_TELLER_REC.TRN_REF_NO);
      PR_INITIALIZE(PKG_RTL_TELLER_REC.TRN_REF_NO,
                    P_EXT_REF_NO,
                    P_ERR_CODE);
    ELSE
      DBG('Calling pr_initialize in fn_upload... 3 Parameters');
      DBG('p_ext_ref_no is ---->' || P_EXT_REF_NO);
    
      PR_INITIALIZE(P_EXT_REF_NO, P_ERR_CODE);
    END IF;
    DBG('Calling fn_upload with teller record type parameter');
  
    IF NOT FN_UPLOAD(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM)
    
     THEN
      DBG('Depks_Rtl_Teller.fn_upload->error after calling ');
    
      RETURN FALSE;
    END IF;
  
    DBG('Successfully completed Depks_Rtl_Teller.fn_upload with ref no as parameter');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In fn_upload with ref no, W-O-T Error is ' || SQLERRM);
      RETURN FALSE;
    
  END FN_UPLOAD;

  PROCEDURE PR_INITIALIZE(P_EXT_REF_NO IN VARCHAR2,
                          P_ERR_CODE   IN OUT VARCHAR2) IS
    L_TRN_REF_NO DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
  BEGIN
    PR_INITIALIZE(P_EXT_REF_NO, L_TRN_REF_NO, P_ERR_CODE);
  END PR_INITIALIZE;

  PROCEDURE PR_INITIALIZE(P_EXT_REF_NO IN VARCHAR2,
                          P_TRN_REF_NO IN VARCHAR2,
                          P_ERR_CODE   IN OUT VARCHAR2) IS
    L_ERR_PARAM VARCHAR2(1000);
    L_LCY_REC   CVPKS_UTILS.REC_BRNLCY;
  
  BEGIN
  
    DBG('In init, p_ext_ref_no: ' || P_EXT_REF_NO);
    DBG('pkg_rtl_teller_rec.xref: ' || PKG_RTL_TELLER_REC.XREF);
    DBG('The value of : p_trn_Ref_no :: ' || P_TRN_REF_NO);
  
    IF P_TRN_REF_NO IS NOT NULL AND
       (STPKSS_ACCOUNT_CLOSE.G_CLOSE_MODE = 'MULTIMODE' OR
       DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y')
    
     THEN
      PKG_BRN := GLOBAL.CURRENT_BRANCH;
      BEGIN
        SELECT *
          INTO PKG_RTL_TELLER_REC
          FROM DETBS_RTL_TELLER
         WHERE TRN_REF_NO = P_TRN_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('From rtl_teller_rec ' || P_EXT_REF_NO || SQLERRM);
          P_ERR_CODE := 'DE-TUD-002';
          RETURN;
      END;
      DBG('The value of : p_trn_Ref_no :: ' || P_TRN_REF_NO);
      DBG('Calling pr_set_global now ...');
    
      PR_SET_GLOBAL(P_ERR_CODE);
    
      DBG('End of pr_initialize ...');
    
    ELSIF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
          NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' THEN
      PKG_BRN := GLOBAL.CURRENT_BRANCH;
      DBG('for two step The value of : p_trn_Ref_no :: ' ||
          G_SECOND_STEPREF_NO);
      BEGIN
        SELECT *
          INTO PKG_RTL_TELLER_REC
          FROM DETBS_RTL_TELLER
         WHERE TRN_REF_NO = G_SECOND_STEPREF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('for two step  :: From rtl_teller_rec ' ||
              G_SECOND_STEPREF_NO || SQLERRM);
          P_ERR_CODE := 'DE-TUD-002';
          RETURN;
      END;
    
      DBG('for two step Calling pr_set_global now ...');
    
      PR_SET_GLOBAL(P_ERR_CODE);
    
      DBG('End of pr_initialize for two step  ...');
    
    ELSIF NVL(PKG_RTL_TELLER_REC.XREF, 'SA$^%#H!') != P_EXT_REF_NO OR
          NVL(PKG_RTL_TELLER_REC.TRN_REF_NO, 'XXX') !=
          NVL(DEPKS_RTL_TELLER.G_TRN_REF_NO, 'XXX') THEN
    
      PKG_BRN := GLOBAL.CURRENT_BRANCH;
    
      BEGIN
        SELECT *
          INTO PKG_RTL_TELLER_REC
          FROM DETBS_RTL_TELLER
         WHERE XREF = P_EXT_REF_NO
           AND NVL(TRN_REF_NO, 'XXX') =
               NVL(DEPKS_RTL_TELLER.G_TRN_REF_NO, NVL(TRN_REF_NO, 'XXX'));
      EXCEPTION
        WHEN OTHERS THEN
          DBG('From rtl_teller_rec ' || P_EXT_REF_NO || SQLERRM);
          P_ERR_CODE := 'DE-TUD-002';
          RETURN;
      END;
      DBG('The value of : pkg_rtl_teller_rec.xref' ||
          PKG_RTL_TELLER_REC.XREF);
      DBG('Calling pr_set_global now ...');
    
      PR_SET_GLOBAL(P_ERR_CODE);
    
      DBG('End of pr_initialize ...');
    
    END IF;
  
  END PR_INITIALIZE;

  FUNCTION FN_GET_AC_ROW(P_BRN          IN VARCHAR2,
                         P_PROD         IN VARCHAR2,
                         P_REL_CUSTOMER IN VARCHAR2,
                         P_COD_CCY      IN VARCHAR2,
                         P_IB_FLAG      IN VARCHAR2 DEFAULT 'N',
                         P_ARC_MAINT    OUT IFTMS_ARC_MAINT%ROWTYPE,
                         P_ERR_CODE     OUT VARCHAR2,
                         P_ERR_PARAM    OUT VARCHAR2,
                         P_TXN_AC_NO    IN VARCHAR2,
                         P_AC_BRN       IN VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_get_ac_row');
    P_ERR_CODE := NULL;
    CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                              P_PROD,
                              'P',
                              P_REL_CUSTOMER,
                              P_COD_CCY,
                              P_IB_FLAG,
                              P_ARC_MAINT,
                              P_ERR_CODE,
                              P_ERR_PARAM,
                              P_TXN_AC_NO,
                              P_AC_BRN);
    IF P_ERR_CODE IS NOT NULL THEN
      P_ERR_CODE := NULL;
      CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                                P_PROD,
                                'P',
                                '*.*',
                                P_COD_CCY,
                                P_IB_FLAG,
                                P_ARC_MAINT,
                                P_ERR_CODE,
                                P_ERR_PARAM,
                                P_TXN_AC_NO,
                                P_AC_BRN);
      IF P_ERR_CODE IS NOT NULL THEN
        IF P_IB_FLAG = 'Y' THEN
          P_ERR_CODE := NULL;
          CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                                    P_PROD,
                                    'P',
                                    '*.*',
                                    P_COD_CCY,
                                    'N',
                                    P_ARC_MAINT,
                                    P_ERR_CODE,
                                    P_ERR_PARAM,
                                    P_TXN_AC_NO,
                                    P_AC_BRN);
        END IF;
      END IF;
    END IF;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      DBG('In exception while executing fn_get_ac_row....thus returning false.');
      RETURN FALSE;
  END FN_GET_AC_ROW;

  FUNCTION FN_GET_AC_ROW(P_BRN          IN VARCHAR2,
                         P_PROD         IN VARCHAR2,
                         P_REL_CUSTOMER IN VARCHAR2,
                         P_COD_CCY      IN VARCHAR2,
                         P_IB_FLAG      IN VARCHAR2 DEFAULT 'N',
                         P_ARC_MAINT    OUT IFTMS_ARC_MAINT%ROWTYPE,
                         P_ERR_CODE     OUT VARCHAR2,
                         P_ERR_PARAM    OUT VARCHAR2,
                         P_TXN_AC_NO    IN VARCHAR2,
                         P_AC_BRN       IN VARCHAR2,
                         
                         P_TBL_RESTR IN STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR)
  
   RETURN BOOLEAN IS
  
    L_IB_FLAG VARCHAR2(1);
  BEGIN
    DBG('Inside fn_get_ac_row');
    P_ERR_CODE := NULL;
    CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                              P_PROD,
                              'P',
                              P_REL_CUSTOMER,
                              P_COD_CCY,
                              P_IB_FLAG,
                              P_ARC_MAINT,
                              P_ERR_CODE,
                              P_ERR_PARAM,
                              P_TXN_AC_NO,
                              P_AC_BRN);
    IF P_ERR_CODE IS NOT NULL THEN
      P_ERR_CODE := NULL;
      CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                                P_PROD,
                                'P',
                                '*.*',
                                P_COD_CCY,
                                P_IB_FLAG,
                                P_ARC_MAINT,
                                P_ERR_CODE,
                                P_ERR_PARAM,
                                P_TXN_AC_NO,
                                P_AC_BRN);
      IF P_ERR_CODE IS NOT NULL THEN
        IF P_IB_FLAG = 'Y' THEN
          P_ERR_CODE := NULL;
          CSPKSS_ARC.PR_GET_ARC_ROW(P_BRN,
                                    P_PROD,
                                    'P',
                                    '*.*',
                                    P_COD_CCY,
                                    'N',
                                    P_ARC_MAINT,
                                    P_ERR_CODE,
                                    P_ERR_PARAM,
                                    P_TXN_AC_NO,
                                    P_AC_BRN);
        END IF;
      END IF;
    END IF;
  
    DBG('before second iteration of charge pick up');
    IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_BRN,
                                       P_PROD,
                                       'P',
                                       P_BRN,
                                       P_COD_CCY,
                                       P_REL_CUSTOMER,
                                       P_COD_CCY,
                                       PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                       PKG_PROD.RATE_TYPE_PREFERRED,
                                       PKG_PROD.RATE_CODE_PREFERRED,
                                       NULL,
                                       P_REL_CUSTOMER,
                                       
                                       P_IB_FLAG,
                                       
                                       P_ARC_MAINT,
                                       P_ERR_CODE,
                                       P_ERR_PARAM,
                                       P_TXN_AC_NO,
                                       P_AC_BRN,
                                       
                                       P_TBL_RESTR) THEN
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      DBG('In exception while executing fn_get_ac_row....thus returning false.');
      RETURN FALSE;
  END FN_GET_AC_ROW;

  PROCEDURE PR_SET_GLOBAL(P_ERR_CODE IN OUT VARCHAR2) IS
    L_LCY_REC   CVPKS_UTILS.REC_BRNLCY;
    L_ERR_PARAM VARCHAR2(1000);
    L_GET_ARC   BOOLEAN := FALSE;
    L_IB_FLAG   VARCHAR2(1);
    L_TXN_AC_NO DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN   DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Inside the pr_set_global ...');
  
    PR_SKIP_HANDLER('Pre_What_To_Do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.pr_set_global_Pre..');
      DEPKS_RTL_TELLER_CUSTOM.PR_SET_GLOBAL_PRE(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed in depks_rtl_teller_custom.pr_set_global_Pre..');
        RETURN;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('depks_rtl_teller_cluster.pr_set_global_Pre..');
      DEPKS_RTL_TELLER_CLUSTER.PR_SET_GLOBAL_PRE(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed in depks_rtl_teller_cluster.pr_set_global_Pre..');
        RETURN;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      IF PKG_LCY IS NULL THEN
        CVPKS_UTILS.GET_BRANCH_LCY(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                   L_LCY_REC);
        PKG_LCY := L_LCY_REC.BRN_LCY;
      END IF;
    
      IF NVL(PKG_PROD.PRODUCT_CODE, '$%&@') <>
         PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
        IF NOT
            CSPKS_UTILS.FN_GETPRODUCT_DETAILS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
          DBG('From cstm_prod ' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
              SQLERRM);
          P_ERR_CODE := 'DE-TUD-003';
          RETURN;
        END IF;
        PKG_PROD := CSPKS_UTILS.PKG_PRODUCT;
      END IF;
    
      DBG('Going to fetch the RT pref for - ' ||
          PKG_RTL_TELLER_REC.PRODUCT_CODE);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                                            P_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        DBG('Error occured while fetching the RT pref...');
        RETURN;
      ELSE
        DBG('Value is available in FRC..');
        PKG_RTL_TELLER_REC.TRACK_RECEIVABLE := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.TRACK_RECEIVABLE,
                                                   'N');
      END IF;
      DBG('Pkg_Rtl_Teller_Rec.Track_Receivable - ' ||
          PKG_RTL_TELLER_REC.TRACK_RECEIVABLE);
    
      IF DEPKS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        DBG('-----------Calling fn_get_ac_row for closeout account route-----------');
        DBG('pkg_rtl_teller_rec.branch_code ===> ' ||
            PKG_RTL_TELLER_REC.BRANCH_CODE);
        DBG('pkg_rtl_teller_rec.product_code ===> ' ||
            PKG_RTL_TELLER_REC.PRODUCT_CODE);
        DBG('pkg_rtl_teller_rec.rel_customer ===> ' ||
            PKG_RTL_TELLER_REC.REL_CUSTOMER);
        DBG('pkg_rtl_teller_rec.txn_ccy ===> ' ||
            PKG_RTL_TELLER_REC.TXN_CCY);
        DBG('l_ib_flag ===> ' || L_IB_FLAG);
        DBG('---Now setting Account Number and Branch Code for ARC Pick up---');
        IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
          DBG('Account Number NOT NULL and the value is ===> ' ||
              PKG_RTL_TELLER_REC.TXN_ACC);
          L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
        ELSE
          L_TXN_AC_NO := NULL;
        END IF;
        IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
          DBG('Branch is NOT NULL and the value is ===> ' ||
              PKG_RTL_TELLER_REC.TXN_BRANCH);
          L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        END IF;
        DBG('Account Number ===> ' || L_TXN_AC_NO);
        DBG('Branch ===> ' || L_TXN_BRN);
        IF NOT FN_GET_AC_ROW(PKG_RTL_TELLER_REC.BRANCH_CODE,
                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                             PKG_RTL_TELLER_REC.REL_CUSTOMER,
                             PKG_RTL_TELLER_REC.TXN_CCY,
                             L_IB_FLAG,
                             PKG_ARC_ROW,
                             P_ERR_CODE,
                             L_ERR_PARAM,
                             L_TXN_AC_NO,
                             L_TXN_BRN) THEN
          RETURN;
        END IF;
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed while fetching arc details....');
          RETURN;
        END IF;
      END IF;
    
      IF PKG_ARC_ROW.COD_BRANCH IS NULL THEN
        L_GET_ARC := TRUE;
      ELSE
        IF PKG_ARC_ROW.COD_BRANCH <> PKG_RTL_TELLER_REC.BRANCH_CODE THEN
          L_GET_ARC := TRUE;
        END IF;
      END IF;
      IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '!@#$') <>
         PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
        L_GET_ARC        := TRUE;
        G_ARC_PICKP_REQD := TRUE;
      END IF;
      IF NVL(PKG_ARC_ROW.COD_TRANS_TYPE, '!@#$') <>
         PKG_RTL_TELLER_REC.REL_CUSTOMER THEN
        L_GET_ARC := TRUE;
      END IF;
      IF NVL(PKG_ARC_ROW.COD_CCY, '!@#') <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        L_GET_ARC := TRUE;
      END IF;
      IF L_GET_ARC AND G_ARC_PICKP_REQD THEN
      
        DBG('checking the values 1 branch code---' ||
            PKG_RTL_TELLER_REC.BRANCH_CODE || '---values for curr brn' ||
            PKG_RTL_TELLER_REC.TXN_BRANCH);
        IF PKG_RTL_TELLER_REC.BRANCH_CODE <> PKG_RTL_TELLER_REC.TXN_BRANCH THEN
          L_IB_FLAG := 'Y';
        ELSE
          L_IB_FLAG := 'N';
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          DBG('depks_rtl_teller_cluster.pr_set_global..');
          L_FN_CALL_ID := 1;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('l_ib_flag') := L_IB_FLAG;
          DEPKS_RTL_TELLER_CLUSTER.PR_SET_GLOBAL(P_ERR_CODE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
          IF P_ERR_CODE IS NOT NULL THEN
            DBG('Failed in depks_rtl_teller_cluster.pr_set_global..');
            RETURN;
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('l_ib_flag') THEN
            L_IB_FLAG := L_TB_CLUSTER_DATA('l_ib_flag');
          END IF;
        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;
      
        DBG('Setting Account Number and Branch Code for ARC Pick up');
        IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
          DBG('Account Number NOT NULL ' || PKG_RTL_TELLER_REC.TXN_ACC);
          L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
        ELSE
          L_TXN_AC_NO := NULL;
        END IF;
        IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
          DBG('Branch is NOT NULL ' || PKG_RTL_TELLER_REC.TXN_BRANCH);
          L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        END IF;
        DBG('Account Number ' || L_TXN_AC_NO);
        DBG('Branch ' || L_TXN_BRN);
        DBG('Calling function --->fn_get_ac_row');
        IF NOT FN_GET_AC_ROW(PKG_RTL_TELLER_REC.BRANCH_CODE,
                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                             PKG_RTL_TELLER_REC.REL_CUSTOMER,
                             PKG_RTL_TELLER_REC.TXN_CCY,
                             L_IB_FLAG,
                             PKG_ARC_ROW,
                             P_ERR_CODE,
                             L_ERR_PARAM,
                             L_TXN_AC_NO,
                             L_TXN_BRN) THEN
          RETURN;
        END IF;
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed while fetching arc details....');
          RETURN;
        END IF;
      
      END IF;
      IF NVL(PKG_BRANCH_COND_RECORD.BRANCH_CODE, '!@#$') <>
         PKG_RTL_TELLER_REC.BRANCH_CODE THEN
        BEGIN
          SELECT *
            INTO PKG_BRANCH_COND_RECORD
            FROM DETMS_BRANCH_COND
           WHERE BRANCH_CODE = PKG_RTL_TELLER_REC.BRANCH_CODE
             AND AUTH_STAT = 'A'
             AND RECORD_STAT = 'O';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Branch Cond ' || PKG_RTL_TELLER_REC.BRANCH_CODE ||
                SQLERRM);
            P_ERR_CODE := 'DE-TUD-457';
            RETURN;
        END;
      END IF;
    
    END IF;
    PR_SKIP_HANDLER('Post_what_to_do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('Calling depks_rtl_teller_cluster.pr_set_global_Post..');
      DEPKS_RTL_TELLER_CLUSTER.PR_SET_GLOBAL_POST(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed in depks_rtl_teller_cluster.pr_set_global_Post..');
        RETURN;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.pr_set_global_Post..');
      DEPKS_RTL_TELLER_CUSTOM.PR_SET_GLOBAL_POST(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed in depks_rtl_teller_custom.pr_set_global_Post..');
        RETURN;
      END IF;
    END IF;
  
    DBG('Back from init');
    DBG('End of pr_set_global ...');
  END PR_SET_GLOBAL;

  FUNCTION FN_ONLINE(P_BRN      IN VARCHAR2,
                     P_PRD      IN VARCHAR2,
                     P_CUST     IN VARCHAR2,
                     P_CCY      IN VARCHAR2,
                     P_ERR_CODE IN OUT VARCHAR2,
                     P_PROD_ROW OUT CSTMS_PRODUCT%ROWTYPE,
                     P_ARC_ROW  OUT IFTMS_ARC_MAINT%ROWTYPE) RETURN BOOLEAN IS
    L_ERR_PARAM VARCHAR2(1000);
    L_LCY_REC   CVPKS_UTILS.REC_BRNLCY;
  BEGIN
    IF NOT FN_ONLINE(P_BRN,
                     P_PRD,
                     P_CUST,
                     P_CCY,
                     P_ERR_CODE,
                     P_PROD_ROW,
                     P_ARC_ROW) THEN
      RETURN FALSE;
    ELSE
      RETURN TRUE;
    END IF;
  END FN_ONLINE;

  FUNCTION FN_ONLINE(P_BRN      IN VARCHAR2,
                     P_PRD      IN VARCHAR2,
                     P_CUST     IN VARCHAR2,
                     P_CCY      IN VARCHAR2,
                     P_AMT      IN NUMBER,
                     P_ERR_CODE IN OUT VARCHAR2,
                     P_PROD_ROW OUT CSTMS_PRODUCT%ROWTYPE,
                     P_ARC_ROW  OUT IFTMS_ARC_MAINT%ROWTYPE,
                     P_AC_NO    IN VARCHAR2,
                     P_AC_BRN   IN VARCHAR2) RETURN BOOLEAN IS
    L_ERR_PARAM VARCHAR2(1000);
    L_LCY_REC   CVPKS_UTILS.REC_BRNLCY;
    L_IB_FLAG   VARCHAR2(1);
    L_TXN_AC_NO DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN   DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    PR_SKIP_HANDLER('Pre_What_To_Do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_online_Pre..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_ONLINE_PRE(P_BRN,
                                                   P_PRD,
                                                   P_CUST,
                                                   P_CCY,
                                                   P_AMT,
                                                   P_ERR_CODE,
                                                   P_PROD_ROW,
                                                   P_ARC_ROW,
                                                   P_AC_NO,
                                                   P_AC_BRN) THEN
        DBG('Failed in depks_rtl_teller_custom.fn_online_Pre..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('depks_rtl_teller_cluster.fn_online_Pre..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE_PRE(P_BRN,
                                                    P_PRD,
                                                    P_CUST,
                                                    P_CCY,
                                                    P_AMT,
                                                    P_ERR_CODE,
                                                    P_PROD_ROW,
                                                    P_ARC_ROW,
                                                    P_AC_NO,
                                                    P_AC_BRN) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_online_Pre..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      IF PKG_LCY IS NULL THEN
        CVPKS_UTILS.GET_BRANCH_LCY(P_BRN, L_LCY_REC);
        PKG_LCY := L_LCY_REC.BRN_LCY;
      END IF;
      IF NVL(PKG_PROD.PRODUCT_CODE, '!@#$') <>
         PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
        IF NOT
            CSPKS_UTILS.FN_GETPRODUCT_DETAILS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
          DBG('From cstm_prod ' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
              SQLERRM);
          P_ERR_CODE := 'DE-TUD-003';
          RETURN FALSE;
        END IF;
        PKG_PROD := CSPKS_UTILS.PKG_PRODUCT;
      END IF;
    
      DBG('checking the values 321 branch code---' ||
          PKG_RTL_TELLER_REC.BRANCH_CODE || '---values for curr brn' ||
          PKG_RTL_TELLER_REC.TXN_BRANCH);
      DBG('1');
      IF PKG_RTL_TELLER_REC.BRANCH_CODE <> PKG_RTL_TELLER_REC.TXN_BRANCH THEN
        DBG('assiging the val Y');
        L_IB_FLAG := 'Y';
      ELSE
        DBG('assigning the value no');
        L_IB_FLAG := 'N';
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('depks_rtl_teller_cluster.fn_online..');
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_ib_flag') := L_IB_FLAG;
        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE(P_BRN,
                                                  P_PRD,
                                                  P_CUST,
                                                  P_CCY,
                                                  P_AMT,
                                                  P_ERR_CODE,
                                                  P_PROD_ROW,
                                                  P_ARC_ROW,
                                                  P_AC_NO,
                                                  P_AC_BRN,
                                                  L_FN_CALL_ID,
                                                  L_TB_CLUSTER_DATA) THEN
          DBG('Failed in depks_rtl_teller_cluster.fn_online..');
          RETURN FALSE;
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_ib_flag') THEN
          L_IB_FLAG := L_TB_CLUSTER_DATA('l_ib_flag');
        END IF;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      DBG('Calling function --->fn_get_ac_row');
      DBG('The product codes are :' || P_PRD || ' 2:' ||
          PKG_RTL_TELLER_REC.PRODUCT_CODE || ' 3:' ||
          PKG_PROD.PRODUCT_CODE);
      G_RTL_TELLER_REC.PRODUCT_CODE := P_PRD;
    
      DBG('Setting Account Number and Branch Code for ARC Pick up');
      IF P_AC_NO IS NOT NULL THEN
        DBG('Account Number NOT NULL ' || P_AC_NO);
        L_TXN_AC_NO := P_AC_NO;
      ELSE
        L_TXN_AC_NO := NULL;
      END IF;
      IF P_AC_BRN IS NOT NULL THEN
        DBG('Branch is NOT NULL ' || P_AC_BRN);
        L_TXN_BRN := P_AC_BRN;
      END IF;
      DBG('Account Number ' || L_TXN_AC_NO);
      DBG('Branch ' || L_TXN_BRN);
      DBG('Calling function --->fn_get_ac_row');
      IF NOT FN_GET_AC_ROW(P_BRN,
                           P_PRD,
                           P_CUST,
                           P_CCY,
                           L_IB_FLAG,
                           PKG_ARC_ROW,
                           P_ERR_CODE,
                           L_ERR_PARAM,
                           L_TXN_AC_NO,
                           L_TXN_BRN) THEN
        RETURN FALSE;
      END IF;
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed while fetching arc details....');
        RETURN FALSE;
      END IF;
    
      IF NVL(PKG_BRANCH_COND_RECORD.BRANCH_CODE, '!@#') <> P_BRN THEN
        SELECT *
          INTO PKG_BRANCH_COND_RECORD
          FROM DETMS_BRANCH_COND
         WHERE BRANCH_CODE = P_BRN
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      END IF;
      IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_BRN,
                                         P_PRD,
                                         'P',
                                         P_BRN,
                                         P_CCY,
                                         P_CUST,
                                         P_CCY,
                                         P_AMT,
                                         PKG_PROD.RATE_TYPE_PREFERRED,
                                         PKG_PROD.RATE_CODE_PREFERRED,
                                         NULL,
                                         P_CUST,
                                         L_IB_FLAG,
                                         PKG_ARC_ROW,
                                         P_ERR_CODE,
                                         L_ERR_PARAM,
                                         L_TXN_AC_NO,
                                         L_TXN_BRN) THEN
        RETURN FALSE;
      END IF;
      P_PROD_ROW := PKG_PROD;
      P_ARC_ROW  := PKG_ARC_ROW;
    
    END IF;
    PR_SKIP_HANDLER('Post_what_to_do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('Calling depks_rtl_teller_cluster.fn_online_Post..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE_POST(P_BRN,
                                                     P_PRD,
                                                     P_CUST,
                                                     P_CCY,
                                                     P_AMT,
                                                     P_ERR_CODE,
                                                     P_PROD_ROW,
                                                     P_ARC_ROW,
                                                     P_AC_NO,
                                                     P_AC_BRN) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_online_Post..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_online_Post..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_ONLINE_POST(P_BRN,
                                                    P_PRD,
                                                    P_CUST,
                                                    P_CCY,
                                                    P_AMT,
                                                    P_ERR_CODE,
                                                    P_PROD_ROW,
                                                    P_ARC_ROW,
                                                    P_AC_NO,
                                                    P_AC_BRN) THEN
        DBG('Failed in depks_rtl_teller_custom.fn_online_Post..');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  END FN_ONLINE;

  FUNCTION FN_ONLINE(P_BRN      IN VARCHAR2,
                     P_PRD      IN VARCHAR2,
                     P_CUST     IN VARCHAR2,
                     P_CCY      IN VARCHAR2,
                     P_AMT      IN NUMBER,
                     P_PERIOD   IN NUMBER,
                     P_ERR_CODE IN OUT VARCHAR2,
                     P_PROD_ROW OUT CSTMS_PRODUCT%ROWTYPE,
                     P_ARC_ROW  OUT IFTMS_ARC_MAINT%ROWTYPE) RETURN BOOLEAN IS
    L_ERR_PARAM VARCHAR2(1000);
    L_LCY_REC   CVPKS_UTILS.REC_BRNLCY;
    L_IB_FLAG   VARCHAR2(1);
    L_TXN_AC_NO DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN   DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    PR_SKIP_HANDLER('Pre_What_To_Do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_online_Pre..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_ONLINE_PRE(P_BRN,
                                                   P_PRD,
                                                   P_CUST,
                                                   P_CCY,
                                                   P_AMT,
                                                   P_PERIOD,
                                                   P_ERR_CODE,
                                                   P_PROD_ROW,
                                                   P_ARC_ROW) THEN
        DBG('Failed in depks_rtl_teller_custom.fn_online_Pre..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('depks_rtl_teller_cluster.fn_online_Pre..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE_PRE(P_BRN,
                                                    P_PRD,
                                                    P_CUST,
                                                    P_CCY,
                                                    P_AMT,
                                                    P_PERIOD,
                                                    P_ERR_CODE,
                                                    P_PROD_ROW,
                                                    P_ARC_ROW) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_online_Pre..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      IF PKG_LCY IS NULL THEN
        CVPKS_UTILS.GET_BRANCH_LCY(P_BRN, L_LCY_REC);
        PKG_LCY := L_LCY_REC.BRN_LCY;
      END IF;
      IF NVL(PKG_PROD.PRODUCT_CODE, '!@#$') <>
         PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
        IF NOT
            CSPKS_UTILS.FN_GETPRODUCT_DETAILS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
          DBG('From cstm_prod ' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
              SQLERRM);
          P_ERR_CODE := 'DE-TUD-003';
          RETURN FALSE;
        END IF;
        PKG_PROD := CSPKS_UTILS.PKG_PRODUCT;
      END IF;
    
      DBG('checking the values 5 branch code---' ||
          PKG_RTL_TELLER_REC.BRANCH_CODE || '---values for curr brn' ||
          PKG_RTL_TELLER_REC.TXN_BRANCH);
      IF PKG_RTL_TELLER_REC.BRANCH_CODE <> PKG_RTL_TELLER_REC.TXN_BRANCH THEN
        L_IB_FLAG := 'Y';
      ELSE
        L_IB_FLAG := 'N';
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('depks_rtl_teller_cluster.fn_online..');
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_ib_flag') := L_IB_FLAG;
        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE(P_BRN,
                                                  P_PRD,
                                                  P_CUST,
                                                  P_CCY,
                                                  P_AMT,
                                                  P_PERIOD,
                                                  P_ERR_CODE,
                                                  P_PROD_ROW,
                                                  P_ARC_ROW,
                                                  L_FN_CALL_ID,
                                                  L_TB_CLUSTER_DATA) THEN
          DBG('Failed in depks_rtl_teller_cluster.fn_online..');
          RETURN FALSE;
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_ib_flag') THEN
          L_IB_FLAG := L_TB_CLUSTER_DATA('l_ib_flag');
        END IF;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      DBG('Setting Account Number and Branch Code for ARC Pick up');
      DBG('Setting Account Number to  NULL ');
      L_TXN_AC_NO := NULL;
      IF P_BRN IS NOT NULL THEN
        DBG('Branch is NOT NULL ' || P_BRN);
        L_TXN_BRN := P_BRN;
      END IF;
      DBG('Account Number ' || L_TXN_AC_NO);
      DBG('Branch ' || L_TXN_BRN);
      DBG('Calling function --->fn_get_ac_row');
      IF NOT FN_GET_AC_ROW(P_BRN,
                           P_PRD,
                           P_CUST,
                           P_CCY,
                           L_IB_FLAG,
                           PKG_ARC_ROW,
                           P_ERR_CODE,
                           L_ERR_PARAM,
                           L_TXN_AC_NO,
                           L_TXN_BRN) THEN
        RETURN FALSE;
      END IF;
      IF P_ERR_CODE IS NOT NULL THEN
        DBG('Failed while fetching arc details....');
        RETURN FALSE;
      END IF;
    
      IF NVL(PKG_BRANCH_COND_RECORD.BRANCH_CODE, '!@#') <> P_BRN THEN
        SELECT *
          INTO PKG_BRANCH_COND_RECORD
          FROM DETMS_BRANCH_COND
         WHERE BRANCH_CODE = P_BRN
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      END IF;
      IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(P_BRN,
                                         P_PRD,
                                         'P',
                                         P_BRN,
                                         P_CCY,
                                         P_CUST,
                                         P_CCY,
                                         P_AMT,
                                         PKG_PROD.RATE_CODE_PREFERRED,
                                         PKG_PROD.RATE_TYPE_PREFERRED,
                                         P_PERIOD,
                                         P_CUST,
                                         L_IB_FLAG,
                                         PKG_ARC_ROW,
                                         P_ERR_CODE,
                                         L_ERR_PARAM,
                                         L_TXN_AC_NO,
                                         L_TXN_BRN) THEN
        RETURN FALSE;
      END IF;
      P_PROD_ROW := PKG_PROD;
      P_ARC_ROW  := PKG_ARC_ROW;
    
    END IF;
    PR_SKIP_HANDLER('Post_what_to_do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('Calling depks_rtl_teller_cluster.fn_online_Post..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_ONLINE_POST(P_BRN,
                                                     P_PRD,
                                                     P_CUST,
                                                     P_CCY,
                                                     P_AMT,
                                                     P_PERIOD,
                                                     P_ERR_CODE,
                                                     P_PROD_ROW,
                                                     P_ARC_ROW) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_online_Post..');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_online_Post..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_ONLINE_POST(P_BRN,
                                                    P_PRD,
                                                    P_CUST,
                                                    P_CCY,
                                                    P_AMT,
                                                    P_PERIOD,
                                                    P_ERR_CODE,
                                                    P_PROD_ROW,
                                                    P_ARC_ROW) THEN
        DBG('Failed in depks_rtl_teller_custom.fn_online_Post..');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  END FN_ONLINE;

  PROCEDURE PR_GEN_REF_NO(P_ERR_CODE IN OUT VARCHAR2) IS
    L_SERIAL_NO VARCHAR2(16);
  BEGIN
    IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                       PKG_RTL_TELLER_REC.TRN_DT,
                                       L_SERIAL_NO,
                                       PKG_REF_NO,
                                       P_ERR_CODE) THEN
      RETURN;
    ELSE
      PKG_RTL_TELLER_REC.TRN_REF_NO := PKG_REF_NO;
    END IF;
  END PR_GEN_REF_NO;

  PROCEDURE PR_MESSAGING IS
  BEGIN
  
    IF PKG_ARC_ROW.COD_MAIN_LEG = 'T' THEN
      IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
        PR_INS_MSG_HANDOFF('DR ADVICE');
      ELSE
        PR_INS_MSG_HANDOFF('CR ADVICE');
      END IF;
    ELSIF PKG_ARC_ROW.COD_MAIN_LEG = 'O' THEN
      IF PKG_ARC_ROW.DR_ACC = 'OFS' THEN
        PR_INS_MSG_HANDOFF('DR ADVICE');
      ELSE
        PR_INS_MSG_HANDOFF('CR ADVICE');
      END IF;
    END IF;
  
  END PR_MESSAGING;

  PROCEDURE PR_INS_MSG_HANDOFF(P_DRCR VARCHAR2) IS
    CURSOR CUR_ACC(P_AC_NO VARCHAR2, P_BRANCH VARCHAR2) IS
      SELECT AC_OR_GL, CUST_NO
        FROM STTB_ACCOUNT
       WHERE NVL(BRANCH_CODE, P_BRANCH) = P_BRANCH
         AND AC_GL_NO = P_AC_NO;
    L_CUST_NO   STTB_ACCOUNT.CUST_NO%TYPE;
    L_AC_OR_GL  STTB_ACCOUNT.AC_OR_GL%TYPE;
    L_CUST_NAME STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE := NULL;
    L_ADDRESS1  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS2  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS3  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_ADDRESS4  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE := NULL;
    L_CCY       VARCHAR2(3);
    L_AMOUNT    NUMBER;
    L_MEDIA     STTMS_CUSTOMER.DEFAULT_MEDIA%TYPE := NULL;
    L_ACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    CURSOR CUR_CUST(CUSTNO VARCHAR2) IS
      SELECT CUSTOMER_NAME1,
             ADDRESS_LINE1,
             ADDRESS_LINE2,
             ADDRESS_LINE3,
             ADDRESS_LINE4,
             DEFAULT_MEDIA
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = CUSTNO;
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
    DBG('Txn acc is ' || PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('Ofs acc is ' || PKG_RTL_TELLER_REC.OFS_ACC);
    IF PKG_RTL_TELLER_REC.DR_ACC = 'TXN' AND P_DRCR = 'DR ADVICE' THEN
      DBG('equal to TXN and DR ADVICE');
      OPEN CUR_ACC(PKG_RTL_TELLER_REC.TXN_ACC,
                   PKG_RTL_TELLER_REC.TXN_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      DBG('customer number fetched');
      L_ACC    := PKG_RTL_TELLER_REC.TXN_ACC;
      L_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      L_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      DBG('values initialized for TXN');
    ELSIF PKG_RTL_TELLER_REC.DR_ACC = 'OFS' AND P_DRCR = 'DR ADVICE' THEN
      DBG('equal to OFS and DR ADVICE');
      OPEN CUR_ACC(PKG_RTL_TELLER_REC.OFS_ACC,
                   PKG_RTL_TELLER_REC.OFS_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      L_ACC    := PKG_RTL_TELLER_REC.OFS_ACC;
      L_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
      L_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
      DBG('values initialized for OFS');
    ELSIF PKG_RTL_TELLER_REC.DR_ACC = 'TXN' AND P_DRCR = 'CR ADVICE' THEN
      DBG('equal to TXN nd CR ADVICE');
      OPEN CUR_ACC(PKG_RTL_TELLER_REC.OFS_ACC,
                   PKG_RTL_TELLER_REC.OFS_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      DBG('customer number fetched');
      L_ACC    := PKG_RTL_TELLER_REC.OFS_ACC;
      L_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
      L_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
      DBG('values initialized for OFS');
    ELSIF PKG_RTL_TELLER_REC.DR_ACC = 'OFS' AND P_DRCR = 'CR ADVICE' THEN
      DBG('equal to OFS and CR ADVICE');
      OPEN CUR_ACC(PKG_RTL_TELLER_REC.TXN_ACC,
                   PKG_RTL_TELLER_REC.TXN_BRANCH);
      FETCH CUR_ACC
        INTO L_AC_OR_GL, L_CUST_NO;
      CLOSE CUR_ACC;
      L_ACC    := PKG_RTL_TELLER_REC.TXN_ACC;
      L_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      L_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      DBG('values initialized for TXN');
    END IF;
    DBG('AC or GL is ' || L_AC_OR_GL);
    IF L_AC_OR_GL = 'A' THEN
      DBG('before insert ' || L_ACC);
      FOR I IN CUR_CUST(L_CUST_NO) LOOP
        L_MEDIA    := I.DEFAULT_MEDIA;
        L_ADDRESS1 := I.ADDRESS_LINE1;
      
        IF L_MEDIA NOT IN ('SWIFT') THEN
          L_ADDRESS2  := I.ADDRESS_LINE2;
          L_ADDRESS3  := I.ADDRESS_LINE3;
          L_ADDRESS4  := I.ADDRESS_LINE4;
          L_CUST_NAME := I.CUSTOMER_NAME1;
        END IF;
      
      END LOOP;
      DBG('default media = ' || L_MEDIA);
      INSERT INTO MSTBS_MSG_HANDOFF
        (BRANCH,
         REFERENCE_NO,
         ESN,
         MSG_TYPE,
         RECEIVER,
         NAME,
         SERIAL_NO,
         CCY,
         PRODUCT,
         AMOUNT,
         MEDIA,
         PRIORITY,
         MODULE,
         ADDRESS1,
         ADDRESS2,
         ADDRESS3,
         ADDRESS4,
         FORMAT,
         DIRECTIVE_STATUS,
         PROCESSED_FLAG,
         SUPPRESS_FLAG,
         HOLD_STATUS,
         CUST_AC_NO)
      VALUES
        (PKG_RTL_TELLER_REC.BRANCH_CODE,
         PKG_RTL_TELLER_REC.TRN_REF_NO,
         1,
         P_DRCR,
         L_CUST_NO,
         L_CUST_NAME,
         1,
         L_CCY,
         PKG_RTL_TELLER_REC.PRODUCT_CODE,
         L_AMOUNT,
         L_MEDIA,
         1,
         'RT',
         L_ADDRESS1,
         L_ADDRESS2,
         L_ADDRESS3,
         L_ADDRESS4,
         NULL,
         'N',
         'N',
         'N',
         'N',
         L_ACC);
      DBG('after insert');
    ELSIF L_AC_OR_GL = 'G' THEN
      DBG('pr_ins_msg_handoff-> before select of default media GL ' ||
          L_ACC);
    
      DBG('Calling Fn_Get_Gl_Master_Rec_Wrp for account..' || L_ACC);
      IF NOT CSPKSS_FUNCTION_CACHE.FN_GET_GL_MASTER_REC_WRP(L_ACC,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('In no data found exception..');
          L_MEDIA := 'MAIL';
          DBG('pr_ins_msg_handoff-> Default media not found for GL assigning it to MAIL ');
        ELSE
          DBG('In WOT exception from Fn_Get_Gl_Master_Rec_Wrp..');
          RETURN;
        END IF;
      ELSE
        DBG('Record available in FRC function..');
        L_MEDIA := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.MEDIA,
                       'MAIL');
      END IF;
      DBG('Sucess Fn_Get_Gl_Master_Rec_Wrp..' || L_MEDIA);
    
      BEGIN
        DBG(' b4 insert and default media for GL= ' || L_MEDIA);
        DBG('name- ' || GWPKS_UTIL.G_BENEF_NAME);
        DBG('add1- ' || GWPKS_UTIL.G_BENEF_ADD1);
        DBG('add2- ' || GWPKS_UTIL.G_BENEF_ADD2);
        DBG('add3- ' || GWPKS_UTIL.G_BENEF_ADD3);
        INSERT INTO MSTBS_MSG_HANDOFF
          (BRANCH,
           REFERENCE_NO,
           ESN,
           MSG_TYPE,
           RECEIVER,
           NAME,
           SERIAL_NO,
           CCY,
           PRODUCT,
           AMOUNT,
           MEDIA,
           PRIORITY,
           MODULE,
           ADDRESS1,
           ADDRESS2,
           ADDRESS3,
           ADDRESS4,
           FORMAT,
           DIRECTIVE_STATUS,
           PROCESSED_FLAG,
           SUPPRESS_FLAG,
           HOLD_STATUS,
           CUST_AC_NO)
        VALUES
          (PKG_RTL_TELLER_REC.BRANCH_CODE,
           PKG_RTL_TELLER_REC.TRN_REF_NO,
           1,
           P_DRCR,
           'WALKIN',
           GWPKS_UTIL.G_BENEF_NAME,
           1,
           L_CCY,
           PKG_RTL_TELLER_REC.PRODUCT_CODE,
           L_AMOUNT,
           L_MEDIA,
           1,
           'RT',
           GWPKS_UTIL.G_BENEF_ADD1,
           GWPKS_UTIL.G_BENEF_ADD2,
           GWPKS_UTIL.G_BENEF_ADD3,
           NULL,
           NULL,
           'N',
           'N',
           'N',
           'N',
           L_ACC);
        DBG('pr_ins_msg_handoff-> After insert for GL account');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('pr_ins_msg_handoff-> Failed in WO while insert into mstbs_msg_handoff with ' ||
              SQLERRM);
      END;
    END IF;
  END PR_INS_MSG_HANDOFF;

  PROCEDURE PR_GENERATE_ADVICE(P_MSG_CUR MSPKSS.MODULE_PROC_CURTYPE) IS
    CURSOR CUR_RTL(REFNO VARCHAR2) IS
      SELECT * FROM DETBS_RTL_TELLER WHERE TRN_REF_NO = REFNO;
  
    CURSOR CUR_CASHTFR(REFNO VARCHAR2) IS
      SELECT * FROM RTTB_INTRA_BANK_MASTER WHERE XREF = REFNO;
    RTTB_MASTER_ROW RTTB_INTRA_BANK_MASTER%ROWTYPE;
  
    P_MSG_ROW      MSTBS_DLY_MSG_OUT%ROWTYPE;
    RTL_TELLER_ROW DETBS_RTL_TELLER%ROWTYPE;
    L_PRODDESC     CSTM_PRODUCT.PRODUCT_DESCRIPTION%TYPE;
    L_ACCOUNT      VARCHAR2(20);
    L_CCY          VARCHAR2(3);
    L_AMOUNT       NUMBER;
    L_ACCBAL       NUMBER;
    L_AVL_BAL      BOOLEAN;
    L_DT_FMT       VARCHAR2(20);
  
    L_SET_AMT  VARCHAR2(30);
    L_CHG_AMT1 VARCHAR2(30);
    L_CHG_AMT2 VARCHAR2(30);
    L_CHG_AMT3 VARCHAR2(30);
    L_CHG_AMT4 VARCHAR2(30);
    L_CHG_AMT5 VARCHAR2(30);
    L_ACC_BAL  VARCHAR2(30);
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
    L_FROM_BRANCH  STTM_BRANCH.BRANCH_NAME%TYPE;
    L_TO_BRANCH    STTM_BRANCH.BRANCH_NAME%TYPE;
    L_REQUEST_STAT VARCHAR2(10) := 'N';
    L_REQUEST_FOR  VARCHAR2(20);
  
  BEGIN
    FETCH P_MSG_CUR
      INTO P_MSG_ROW;
    OPEN CUR_RTL(P_MSG_ROW.REFERENCE_NO);
    FETCH CUR_RTL
      INTO RTL_TELLER_ROW;
    CLOSE CUR_RTL;
  
    DBG('Fetching values to rttb_master_row.....');
    OPEN CUR_CASHTFR(P_MSG_ROW.REFERENCE_NO);
    FETCH CUR_CASHTFR
      INTO RTTB_MASTER_ROW;
  
    IF CUR_CASHTFR%ROWCOUNT > 0 THEN
      DBG('Selecting a branch name for from branch....');
      SELECT BRANCH_NAME
        INTO L_FROM_BRANCH
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = RTTB_MASTER_ROW.FROM_BRANCH;
    
      DBG('Selecting a branch name for to branch....');
      SELECT BRANCH_NAME
        INTO L_TO_BRANCH
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = RTTB_MASTER_ROW.TO_BRANCH;
    
      DBG('Inserting REFERENCENO....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'REFERENCENO',
                     RTTB_MASTER_ROW.REFERENCE_NO);
    
      DBG('Inserting FROMBRANCH....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'FROMBRANCH',
                     RTTB_MASTER_ROW.FROM_BRANCH);
    
      DBG('Inserting from branch name....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'FROMBRANCHNAME', L_FROM_BRANCH);
      DBG('Inserting TOBRANCH....');
    
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'TOBRANCH',
                     RTTB_MASTER_ROW.TO_BRANCH);
    
      DBG('Inserting from branch name....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'TOBRANCHNAME', L_TO_BRANCH);
    
      DBG('Inserting transaction currency...');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'TXNCCY', RTTB_MASTER_ROW.TXN_CCY);
    
      DBG('Inserting transaction amount....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'TXNAMT', RTTB_MASTER_ROW.AMOUNT);
    
      IF NVL(RTTB_MASTER_ROW.REQUEST_STAT, 'N') = 'A' THEN
        L_REQUEST_STAT := 'Accepted';
      ELSIF NVL(RTTB_MASTER_ROW.REQUEST_STAT, 'N') = 'R' THEN
        L_REQUEST_STAT := 'Rejected';
      END IF;
    
      DBG('Inserting Request Status....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'REQUESTSTAT', L_REQUEST_STAT);
      DBG('Inserting Remarks....');
    
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'REMARKS', RTTB_MASTER_ROW.REMARKS);
    
      DBG('Inserting requested date....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'REQUESTDATE',
                     RTTB_MASTER_ROW.REQUEST_DATE);
    
      DBG('Inserting Delivery date....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'DELIVERYDATE',
                     RTTB_MASTER_ROW.DELIVERY_DATE);
      DBG('Inserting Description....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'DESCRIPTION',
                     RTTB_MASTER_ROW.DESCRIPTION);
    
      IF NVL(RTTB_MASTER_ROW.ADV_REQ_FLAG, 'N') = 'D' THEN
        L_REQUEST_FOR := 'Cash Delivery';
      ELSIF NVL(RTTB_MASTER_ROW.ADV_REQ_FLAG, 'N') = 'P' THEN
        L_REQUEST_FOR := 'Cash Pickup';
      END IF;
    
      DBG('Inserting advance request flag....');
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'ADVREQFLAG', L_REQUEST_FOR);
    END IF;
    CLOSE CUR_CASHTFR;
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'CONTRACTREFNO',
                   RTL_TELLER_ROW.TRN_REF_NO);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'USERREFNO', RTL_TELLER_ROW.XREF);
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'PRODUCT',
                   RTL_TELLER_ROW.PRODUCT_CODE);
  
    DBG('Calling Fn_Get_Product_Rec_Wrp for...' ||
        RTL_TELLER_ROW.PRODUCT_CODE);
    IF CSPKSS_FUNCTION_CACHE.FN_GET_PRODUCT_REC_WRP(RTL_TELLER_ROW.PRODUCT_CODE,
                                                    L_ERR_CODE,
                                                    L_ERR_PARAM) THEN
      L_PRODDESC := CSPKSS_FUNCTION_CACHE.G_TBL_CSTM_PROD_REC.PRODUCT_DESCRIPTION;
      DBG('Product desc...' || L_PRODDESC);
    ELSE
      DBG('Error in getting the product details...' || L_ERR_CODE);
      L_PRODDESC  := NULL;
      L_ERR_CODE  := NULL;
      L_ERR_PARAM := NULL;
    END IF;
    DBG('Product details retrived...');
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'PRODDESC', L_PRODDESC);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTOMER', P_MSG_ROW.RECEIVER);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTOMER-NAME', P_MSG_ROW.NAME);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR1', P_MSG_ROW.ADDRESS1);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR2', P_MSG_ROW.ADDRESS2);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR3', P_MSG_ROW.ADDRESS3);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CUSTADDR4', P_MSG_ROW.ADDRESS4);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'BRN-DATE', GLOBAL.APPLICATION_DATE);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN,
                   1,
                   'INSTRNO',
                   RTL_TELLER_ROW.DR_INSTRUMENT_CODE);
  
    IF P_MSG_ROW.CUST_AC_NO IS NULL THEN
      IF P_MSG_ROW.MSG_TYPE = 'DR ADVICE' AND RTL_TELLER_ROW.DR_ACC = 'TXN' THEN
        L_ACCOUNT := RTL_TELLER_ROW.TXN_ACC;
      ELSIF P_MSG_ROW.MSG_TYPE = 'CR ADVICE' AND
            RTL_TELLER_ROW.DR_ACC = 'TXN' THEN
        L_ACCOUNT := RTL_TELLER_ROW.OFS_ACC;
      ELSIF P_MSG_ROW.MSG_TYPE = 'DR ADVICE' AND
            RTL_TELLER_ROW.DR_ACC = 'OFS' THEN
        L_ACCOUNT := RTL_TELLER_ROW.OFS_ACC;
      ELSIF P_MSG_ROW.MSG_TYPE = 'CR ADVICE' AND
            RTL_TELLER_ROW.DR_ACC = 'OFS' THEN
        L_ACCOUNT := RTL_TELLER_ROW.TXN_ACC;
      
      ELSIF P_MSG_ROW.MSG_TYPE = 'REQ_TRANSFER' AND
            RTL_TELLER_ROW.DR_ACC = 'TXN' THEN
        L_ACCOUNT := RTL_TELLER_ROW.TXN_ACC;
      
      END IF;
    ELSE
      L_ACCOUNT := P_MSG_ROW.CUST_AC_NO;
    END IF;
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'ACCOUNT', L_ACCOUNT);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CCY', P_MSG_ROW.CCY);
  
    IF P_MSG_ROW.MSG_TYPE = 'DR ADVICE' AND PKG_GENERATE_MT101 <> 'Y' THEN
    
      DBG('Pr_Generate_Advice-> inside Pr_Generate_Advice>>p_Msg_Row.Amount>>' ||
          P_MSG_ROW.AMOUNT);
      DBG('Pr_Generate_Advice-> inside Pr_Generate_Advice>>p_Msg_Row.Ccy>>' ||
          P_MSG_ROW.CCY);
      L_SET_AMT := TRIM(CSFNS_FORMAT_AMT(P_MSG_ROW.CCY, P_MSG_ROW.AMOUNT));
      DBG('Pr_Generate_Advice-> inside Pr_Generate_Advice>>SETTLEMENT-AMT>>' ||
          L_SET_AMT);
    
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'SETTLEMENT-AMT', L_SET_AMT);
    
      L_DT_FMT := GLOBAL.GET_NLS_DT_FORMAT;
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'TRNDT',
                     TO_CHAR(RTL_TELLER_ROW.TRN_DT, L_DT_FMT));
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'VALUE-DATE',
                     TO_CHAR(RTL_TELLER_ROW.VALUE_DT, L_DT_FMT));
    ELSE
    
      L_SET_AMT := TRIM(CSFNS_FORMAT_AMT(P_MSG_ROW.CCY, P_MSG_ROW.AMOUNT));
    
      PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'AMOUNT', L_SET_AMT);
    
      L_DT_FMT := GLOBAL.GET_NLS_DT_FORMAT;
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'TRNDT',
                     TO_CHAR(RTL_TELLER_ROW.TRN_DT, L_DT_FMT));
      PR_INSERT_ROWS(P_MSG_ROW.DCN,
                     1,
                     'VALDT',
                     TO_CHAR(RTL_TELLER_ROW.VALUE_DT, L_DT_FMT));
    END IF;
  
    L_CHG_AMT1 := TRIM(CSFNS_FORMAT_AMT(RTL_TELLER_ROW.CHG_CCY,
                                        RTL_TELLER_ROW.CHG_AMT));
    L_CHG_AMT2 := TRIM(CSFNS_FORMAT_AMT(RTL_TELLER_ROW.CHG_CCY_1,
                                        RTL_TELLER_ROW.CHG_AMT_1));
    L_CHG_AMT3 := TRIM(CSFNS_FORMAT_AMT(RTL_TELLER_ROW.CHG_CCY_2,
                                        RTL_TELLER_ROW.CHG_AMT_2));
    L_CHG_AMT4 := TRIM(CSFNS_FORMAT_AMT(RTL_TELLER_ROW.CHG_CCY_3,
                                        RTL_TELLER_ROW.CHG_AMT_3));
    L_CHG_AMT5 := TRIM(CSFNS_FORMAT_AMT(RTL_TELLER_ROW.CHG_CCY_4,
                                        RTL_TELLER_ROW.CHG_AMT_4));
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGAMT1', L_CHG_AMT1);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGCCY1', RTL_TELLER_ROW.CHG_CCY);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGAMT2', L_CHG_AMT2);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGCCY2', RTL_TELLER_ROW.CHG_CCY_1);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGAMT3', L_CHG_AMT3);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGCCY3', RTL_TELLER_ROW.CHG_CCY_2);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGAMT4', L_CHG_AMT4);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGCCY4', RTL_TELLER_ROW.CHG_CCY_3);
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGAMT5', L_CHG_AMT5);
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'CHGCCY5', RTL_TELLER_ROW.CHG_CCY_4);
  
    IF L_REQUEST_STAT = 'N' THEN
      L_AVL_BAL := ACPKS_MISC.FN_GETAVLBAL(GLOBAL.CURRENT_BRANCH,
                                           L_ACCOUNT,
                                           L_ACCBAL);
    END IF;
  
    L_ACC_BAL := TRIM(CSFNS_FORMAT_AMT(P_MSG_ROW.CCY, L_ACCBAL));
  
    PR_INSERT_ROWS(P_MSG_ROW.DCN, 1, 'ACCBAL', L_ACC_BAL);
  
  END PR_GENERATE_ADVICE;

  PROCEDURE PR_GENERATE_ADVICE(P_DCN VARCHAR2) IS
    CURSOR CUR_MSG IS
      SELECT MESSAGE FROM MSTBS_DLY_MSG_OUT WHERE DCN = P_DCN;
  
    L_MESSAGE     MSTB_DLY_MSG_OUT.MESSAGE%TYPE;
    L_DATA        VARCHAR2(32767);
    L_KEY         VARCHAR2(60);
    P_DLY_MSG_CUR MSTBS_MSG_HANDOFF%ROWTYPE;
    P_BAD_DCN     VARCHAR2(1000);
  BEGIN
    DBG('Inside pr_generate_advice. before opening cursor');
    SELECT * INTO P_DLY_MSG_CUR FROM MSTBS_DLY_MSG_OUT WHERE DCN = P_DCN;
    IF P_DLY_MSG_CUR.MSG_TYPE IN ('DR ADVICE', 'CR ADVICE') THEN
      DBG('Inside pr_generate_advice. before calling overloaded pr_generate_advice');
      IF NOT MSPKSS.FN_GEN_MSG_OUT(P_DLY_MSG_CUR, P_BAD_DCN) THEN
        DBG('Failed in mspks');
      END IF;
      DBG('Inside pr_generate_advice. after return from overloaded pr_generate_advice');
      OPEN CUR_MSG;
      FETCH CUR_MSG
        INTO L_MESSAGE;
      CLOSE CUR_MSG;
    
      DBG('Inside pr_generate_advice. After last line of procedure');
    END IF;
  END PR_GENERATE_ADVICE;

  PROCEDURE PR_INSERT_ROWS(P_DCN       VARCHAR2,
                           P_LOOP_NO   NUMBER,
                           P_FIELD_TAG VARCHAR2,
                           P_VALUE     VARCHAR2) IS
  BEGIN
    INSERT INTO MSTB_ADV_INPUT
      (DCN, LOOP_NO, FIELD_TAG, VALUE, JUSTIFY)
    VALUES
      (P_DCN, P_LOOP_NO, P_FIELD_TAG, P_VALUE, 'L');
  END PR_INSERT_ROWS;

  FUNCTION FN_TRNFBYPC(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                       P_PCPAYOUTDETS_REC    IN OUT NOCOPY DETBS_PCTRN%ROWTYPE,
                       P_ERR_CODE            IN OUT VARCHAR2,
                       P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_KEY     VARCHAR2(4000);
    P_TOT_AMT NUMBER;
  BEGIN
    DBG('Inside FN_TRNFBYPC ...');
    DBG('p_pcpayoutdets_rec.pc_network_id' ||
        P_PCPAYOUTDETS_REC.PC_NETWORK_ID);
    DBG('p_detb_rtl_teller_rec.XREF!!!!!!!' || P_DETB_RTL_TELLER_REC.XREF);
    DBG('p_pcpayoutdets_rec.comm_mode' || P_PCPAYOUTDETS_REC.COMM_MODE);
  
    P_TOT_AMT := (P_DETB_RTL_TELLER_REC.TXN_AMOUNT -
                 NVL(P_DETB_RTL_TELLER_REC.CHG_AMT, 0));
  
    L_KEY := 'CLEARING_BRN~TXN_CCY~CUST_BANK~CATEGORY~SOURCE~STATION~THEIR_REF_NO~BRANCH_OF_INPUT~CUST_BRANCH~';
    L_KEY := L_KEY ||
             'CUST_AC~CPTY_BANK~CPTY_AC~CPTY_AC_PREFIX~CPTY_NAME~AMOUNT~SOURCE_REF~';
    L_KEY := L_KEY ||
             'INTERFACE_REF~INIT_DT~ACTIVATION_DT~CUST_AC_LCF~DISP_FILE_NAME~CONSOL~AGREEMENT_ID~';
    L_KEY := L_KEY ||
             'CUST_ENTRY_DT~CUST_ENTRY_VAL_DT~CPTY_ENTRY_DT~CPTY_ENTRY_VAL_DT~';
    L_KEY := L_KEY ||
             'UDF1~UDF2~UDF3~UDF4~UDF5~UDF6~UDF7~UDF8~UDF9~UDF10~UDF11~UDF12~UDF13~UDF14~UDF15~';
    L_KEY := L_KEY ||
             'UDF16~UDF17~UDF18~UDF19~UDF20~UDF21~UDF22~UDF23~UDF24~UDF25~UDF26~UDF27~UDF28~UDF29~UDF30~';
  
    L_KEY := L_KEY ||
             'CUST_NAME~CUST_ADDRESS_1~CUST_ADDRESS_2~CUST_ADDRESS_3~COMMUNICATION_MODE~MOBILENO_EMAILID~NETWORK~';
  
    L_KEY := L_KEY ||
             'CPTY_ADDRESS_1~CPTY_ADDRESS_2~CPTY_ADDRESS_3~SNDR_RECV_7495_1~SNDR_RECV_7495_2~SNDR_RECV_7495_3~CUST_ACC_TYPE';
  
    DBG('l_key is  ' || L_KEY);
  
    IF NOT ICPKS_BOD.FN_PAYMENT_TXN_1405(P_DETB_RTL_TELLER_REC,
                                         
                                         P_DETB_RTL_TELLER_REC.TRN_DT,
                                         P_TOT_AMT,
                                         L_KEY,
                                         P_PCPAYOUTDETS_REC,
                                         P_ERR_CODE,
                                         P_ERR_PARAM) THEN
    
      DBG('Failed while  PC txn in fn_payment_txn');
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of FN_TRNFBYPC ..');
      DBG(SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_TRNFBYPC;

  FUNCTION FN_TRNSBYFT(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                       P_ARC_ROW             IN IFTMS_ARC_MAINT%ROWTYPE,
                       P_FTTXNDETS_REC       IN OUT CSTB_UI_COLUMNS%ROWTYPE,
                       P_ERR_CODE            IN OUT VARCHAR2,
                       P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_FTDTRONL      FTPKS_FTDTRONL_MAIN.TY_FTDTRONL;
    L_CUSTOMER_NAME STTMS_CUSTOMER%ROWTYPE;
  BEGIN
    DBG('Inside fn_trnsbyft ...');
    DBG('Ftpks_Ftdtronl_Upload.g_Multi_Trip_Id~~' ||
        FTPKS_FTDTRONL_UPLOAD.G_MULTI_TRIP_ID);
    DBG('The xref is ...' || P_DETB_RTL_TELLER_REC.XREF);
    DBG('p_fttxndets_rec.char_field1~~' || P_FTTXNDETS_REC.CHAR_FIELD1 || '~~' ||
        'p_fttxndets_rec.char_field3~~' || P_FTTXNDETS_REC.CHAR_FIELD3 || '~~' ||
        'p_fttxndets_rec.char_field4~~' || P_FTTXNDETS_REC.CHAR_FIELD4 || '~~' ||
        'p_fttxndets_rec.char_field5~~' || P_FTTXNDETS_REC.CHAR_FIELD5 || '~~' ||
        'p_fttxndets_rec.char_field6~~' || P_FTTXNDETS_REC.CHAR_FIELD6 || '~~' ||
        'p_fttxndets_rec.char_field7~~' || P_FTTXNDETS_REC.CHAR_FIELD7 || '~~' ||
        'p_fttxndets_rec.char_field8~~' || P_FTTXNDETS_REC.CHAR_FIELD8 || '~~' ||
        'p_fttxndets_rec.char_field9~~' || P_FTTXNDETS_REC.CHAR_FIELD9 || '~~' ||
        'p_fttxndets_rec.char_field10~~' || P_FTTXNDETS_REC.CHAR_FIELD10 || '~~' ||
        'p_fttxndets_rec.char_field11~~' || P_FTTXNDETS_REC.CHAR_FIELD11 || '~~' ||
        'p_fttxndets_rec.char_field12~~' || P_FTTXNDETS_REC.CHAR_FIELD12 || '~~' ||
        'p_fttxndets_rec.char_field13~~' || P_FTTXNDETS_REC.CHAR_FIELD13 || '~~' ||
        'p_fttxndets_rec.char_field14~~' || P_FTTXNDETS_REC.CHAR_FIELD14 || '~~' ||
        'p_fttxndets_rec.char_field15~~' || P_FTTXNDETS_REC.CHAR_FIELD15 || '~~' ||
        'p_fttxndets_rec.char_field16~~' || P_FTTXNDETS_REC.CHAR_FIELD16 || '~~' ||
        'p_fttxndets_rec.char_field17~~' || P_FTTXNDETS_REC.CHAR_FIELD17 || '~~' ||
        'p_fttxndets_rec.char_field18~~' || P_FTTXNDETS_REC.CHAR_FIELD18 || '~~' ||
        'p_fttxndets_rec.char_field19~~' || P_FTTXNDETS_REC.CHAR_FIELD19);
  
    PR_SKIP_HANDLER('Pre_What_To_Do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_trnsbyft_Pre..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_TRNSBYFT_PRE(P_DETB_RTL_TELLER_REC,
                                                     P_ARC_ROW,
                                                     P_FTTXNDETS_REC,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_custom.fn_trnsbyft_Pre');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('depks_rtl_teller_cluster.fn_trnsbyft_Pre..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_TRNSBYFT_PRE(P_DETB_RTL_TELLER_REC,
                                                      P_ARC_ROW,
                                                      P_FTTXNDETS_REC,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_cluster.fn_trnsbyft_Pre');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.PRODUCT_CODE     := P_FTTXNDETS_REC.CHAR_FIELD1;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DR_CCY           := P_DETB_RTL_TELLER_REC.TXN_CCY;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INST6   := P_FTTXNDETS_REC.CHAR_FIELD3;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DMY_RECEIVER     := P_FTTXNDETS_REC.CHAR_FIELD4;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INSTN   := P_FTTXNDETS_REC.CHAR_FIELD5;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INSTN2  := P_FTTXNDETS_REC.CHAR_FIELD6;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INSTN3  := P_FTTXNDETS_REC.CHAR_FIELD7;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INSTN4  := P_FTTXNDETS_REC.CHAR_FIELD8;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ACC_WITH_INSTN5  := P_FTTXNDETS_REC.CHAR_FIELD9;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.PAYMENT_DETAILS1 := P_FTTXNDETS_REC.CHAR_FIELD10;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.PAYMENT_DETAILS2 := P_FTTXNDETS_REC.CHAR_FIELD11;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.PAYMENT_DETAILS3 := P_FTTXNDETS_REC.CHAR_FIELD12;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.PAYMENT_DETAILS4 := P_FTTXNDETS_REC.CHAR_FIELD13;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY6 := P_FTTXNDETS_REC.CHAR_FIELD14;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY1 := P_FTTXNDETS_REC.CHAR_FIELD15;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY2 := P_FTTXNDETS_REC.CHAR_FIELD16;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY3 := P_FTTXNDETS_REC.CHAR_FIELD17;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY4 := P_FTTXNDETS_REC.CHAR_FIELD18;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.ULT_BENEFICIARY5 := P_FTTXNDETS_REC.CHAR_FIELD19;
    
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DR_AMOUNT         := P_DETB_RTL_TELLER_REC.TXN_AMOUNT;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DR_VALUE_DATE     := P_DETB_RTL_TELLER_REC.TRN_DT;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.CR_VALUE_DATE     := P_DETB_RTL_TELLER_REC.TRN_DT;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DR_ACCOUNT        := P_ARC_ROW.COD_TXN_ACCOUNT;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.UI_DR_ACCOUNT     := P_ARC_ROW.COD_TXN_ACCOUNT;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.DR_ACCOUNT_BRANCH := P_DETB_RTL_TELLER_REC.OFS_BRANCH;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF1      := '/' ||
                                                              NVL(GWPKS_CREATERETAILTLR.G_SHORT_NAME,
                                                                  PKG_SHORT_NAME);
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF2      := P_DETB_RTL_TELLER_REC.BENEF_ADDR1;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF3      := P_DETB_RTL_TELLER_REC.BENEF_ADDR2;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF4      := P_DETB_RTL_TELLER_REC.BENEF_ADDR3;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF5      := P_DETB_RTL_TELLER_REC.BENEF_ADDR4;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.BY_ORDER_OF6      := P_DETB_RTL_TELLER_REC.COUNTRY;
      L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.SOURCE_REF_NO     := P_DETB_RTL_TELLER_REC.XREF;
      G_MODULE                                             := 'RT';
      DBG('23264040..Module set as...' || G_MODULE);
    
      DBG('callingh Ftpks_Ftdtronl_Upload.Fn_create_1406_ftcd...');
    
      IF NOT FTPKS_FTDTRONL_UPLOAD.FN_CREATE_FT_TXN(L_FTDTRONL,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
      
        DBG('Failed while FT txn in Fn_create_1406_ftcd');
      END IF;
    
      DBG('l_Ftdtronl.v_fttbs_contract_master.contract_ref_no' ||
          L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.CONTRACT_REF_NO);
      UPDATE DETB_RTL_TELLER
         SET SDB_REF_NO = L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.CONTRACT_REF_NO
       WHERE TRN_REF_NO = P_DETB_RTL_TELLER_REC.TRN_REF_NO;
    
      BEGIN
        UPDATE CSTBS_CONTRACT_EVENT_LOG
           SET CHECKER_ID = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID)
         WHERE CONTRACT_REF_NO =
               L_FTDTRONL.V_FTTBS_CONTRACT_MASTER.CONTRACT_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while updating checker ID in Fn_create_1406_ftcd');
      END;
    
    END IF;
    PR_SKIP_HANDLER('Post_what_to_do');
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('Calling depks_rtl_teller_cluster.fn_trnsbyft_Post..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_TRNSBYFT_POST(P_DETB_RTL_TELLER_REC,
                                                       P_ARC_ROW,
                                                       P_FTTXNDETS_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_cluster.fn_trnsbyft_Post');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_trnsbyft_Post..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_TRNSBYFT_POST(P_DETB_RTL_TELLER_REC,
                                                      P_ARC_ROW,
                                                      P_FTTXNDETS_REC,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_cluster.fn_trnsbyft_Post');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_trnsbyft ..');
      DBG(SQLERRM);
      P_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_TRNSBYFT;

  FUNCTION FN_GET_CASHAMT(P_ACC_HAND      IN ACPKS.TBL_ACHOFF,
                          P_TXNLEGCASHAMT OUT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                          P_OFSLEGCASHAMT OUT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                          P_ERR_CODE      OUT VARCHAR2,
                          P_ERR_PARAM     OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_TXN_LEG_CASH  CSTM_BRN_STAT_FUNC_DEFN.TXN_LEG_CASH%TYPE;
    L_OFS_LEG_CASH  CSTM_BRN_STAT_FUNC_DEFN.OFS_LEG_CASH%TYPE;
    L_CASHDRCR_IND  ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_CASHGLHANDOFF ACTB_DAILY_LOG.AC_NO%TYPE;
  
    L_OFSLEGCASHAMT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_TXNLEGCASHAMT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  
    L_CASHDRCR_MUL NUMBER;
  
    L_OFSLEGCASHAMT_TEMP ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_TXNLEGCASHAMT_TEMP ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  
    L_TXNLEGCASHSET BOOLEAN := FALSE;
    L_OFSLEGCASHSET BOOLEAN := FALSE;
  
    L_CASHCCYHANDOFF ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_CASHBRNHANDOFF ACTB_DAILY_LOG.AC_BRANCH%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG('Inside Fn_get_cashAmt ..');
  
    DBG(' gwpks_util.pkg_func ' || GWPKS_UTIL.PKG_FUNC);
    IF GWPKS_UTIL.PKG_FUNC = 'TDMM' OR GWPKS_UTIL.PKG_FUNC = '1317' OR
       GWPKS_UTIL.PKG_FUNC = '1350' OR GWPKS_UTIL.PKG_FUNC = 'IPTDMM' OR
       GWPKS_UTIL.PKG_FUNC = 'IPTDTP' OR GWPKS_UTIL.PKG_FUNC = 'TDTP' OR
       GWPKS_UTIL.PKG_FUNC = '8324' OR GWPKS_UTIL.PKG_FUNC = '8318' OR
       GWPKS_UTIL.PKG_FUNC = 'BCRV' OR GWPKS_UTIL.PKG_FUNC = 'DDRV' THEN
      DBG(' Set both out parameters to null ');
      P_TXNLEGCASHAMT := NULL;
      P_OFSLEGCASHAMT := NULL;
    ELSE
      DBG('Inside Fn_get_cashAmt .. In the else part');
    
      DBG(' gwpks_util.pkg_func ' || GWPKS_UTIL.PKG_FUNC);
      BEGIN
        SELECT NVL(TXN_LEG_CASH, 'N'), NVL(OFS_LEG_CASH, 'N')
          INTO L_TXN_LEG_CASH, L_OFS_LEG_CASH
          FROM CSTM_BRN_STAT_FUNC_DEFN
         WHERE FUNCTIONID = GWPKS_UTIL.PKG_FUNC;
      EXCEPTION
      
        WHEN OTHERS THEN
          DBG('Invalid func id......');
        
          RETURN TRUE;
      END;
      DBG(' l_txn_leg_cash ' || L_TXN_LEG_CASH);
      DBG(' l_ofs_leg_cash ' || L_OFS_LEG_CASH);
    
      IF L_TXN_LEG_CASH IN ('I', 'O') THEN
        DBG('Will find out Cash GL is in which Leg ');
        IF L_TXN_LEG_CASH = 'I' THEN
          L_CASHDRCR_IND := 'D';
        ELSE
          L_CASHDRCR_IND := 'C';
        END IF;
        DBG(' l_cashdrcr_ind ' || L_CASHDRCR_IND);
      
        DBG('Will find cash GL Value');
        FOR I IN 1 .. 2 LOOP
        
          IF L_CASHDRCR_IND = P_ACC_HAND(I).DRCR_IND THEN
          
            L_CASHGLHANDOFF := P_ACC_HAND(I).AC_NO;
          
            L_CASHCCYHANDOFF := P_ACC_HAND(I).AC_CCY;
            L_CASHBRNHANDOFF := P_ACC_HAND(I).AC_BRANCH;
          
            DBG(' l_cashGlHandoff ' || L_CASHGLHANDOFF);
            DBG('The handoff currency is:' || L_CASHCCYHANDOFF ||
                ' with handoff branch as :' || L_CASHBRNHANDOFF);
            L_TXNLEGCASHAMT := NVL(P_ACC_HAND(I).FCY_AMOUNT,
                                   P_ACC_HAND(I).LCY_AMOUNT);
          
            IF P_ACC_HAND(I).DRCR_IND = 'D' THEN
              DBG('multiply with -1 as header is debit');
              L_TXNLEGCASHAMT := L_TXNLEGCASHAMT * -1;
            END IF;
          
            DBG('l_txnlegcashAmt for ' || I || ' time is :::: ' ||
                L_TXNLEGCASHAMT);
          END IF;
        END LOOP;
        DBG(' Now before itrrating handoff and finding total amount for the GL ');
        DBG('p_acc_hand.count ::::: ' || P_ACC_HAND.COUNT);
      
        IF P_ACC_HAND.COUNT > 2 THEN
        
          FOR J IN 3 .. P_ACC_HAND.COUNT LOOP
          
            DBG('Inside Loop..');
            DBG('p_acc_hand(' || J ||
                ').amount_tag in fn_getCashamt for txn leg::::: ' || P_ACC_HAND(J)
                .AMOUNT_TAG);
            IF P_ACC_HAND(J).AMOUNT_TAG LIKE 'CHG_AMT%' THEN
            
              DBG('The txn handoff account number is:' || P_ACC_HAND(J)
                  .AC_NO || ' cashGl is:' || L_CASHGLHANDOFF);
              DBG('The txn handoff account currency is:' || P_ACC_HAND(J)
                  .AC_CCY || ' cash currency is:' || L_CASHCCYHANDOFF);
              DBG('The txn handoff account branch is:' || P_ACC_HAND(J)
                  .AC_BRANCH || ' cash branch is:' || L_CASHBRNHANDOFF);
            
              IF P_ACC_HAND(J).AC_NO = L_CASHGLHANDOFF AND P_ACC_HAND(J)
                 .AC_BRANCH = L_CASHBRNHANDOFF AND P_ACC_HAND(J)
                 .AC_CCY = L_CASHCCYHANDOFF THEN
              
                IF P_ACC_HAND(J).DRCR_IND = 'D' THEN
                  L_CASHDRCR_MUL := -1;
                ELSE
                  L_CASHDRCR_MUL := 1;
                END IF;
                DBG(' Adding Txn leg amnt.' || J);
                L_TXNLEGCASHAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                            P_ACC_HAND(J).LCY_AMOUNT);
                L_TXNLEGCASHAMT      := L_TXNLEGCASHAMT + (L_TXNLEGCASHAMT_TEMP *
                                        L_CASHDRCR_MUL);
              
                IF NOT L_TXNLEGCASHSET THEN
                  L_TXNLEGCASHSET := TRUE;
                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;
      
        DBG(' p_txnlegcashAmt ' || P_TXNLEGCASHAMT);
      END IF;
    
      IF NOT L_TXNLEGCASHSET THEN
        DBG(' txn leg was not set .. so set out parameter to null ' ||
            P_TXNLEGCASHAMT);
      
        P_TXNLEGCASHAMT := L_TXNLEGCASHAMT;
      END IF;
      P_TXNLEGCASHAMT := ABS(L_TXNLEGCASHAMT);
      DBG(' p_txnlegcashAmt before manipulating offset entries is:' ||
          P_TXNLEGCASHAMT);
    
      IF L_OFS_LEG_CASH IN ('I', 'O') THEN
        DBG(' inSide for Offset leg..');
        DBG('Will find out Cash GL is in which Leg  ');
        IF L_OFS_LEG_CASH = 'I' THEN
          L_CASHDRCR_IND := 'D';
        ELSE
          L_CASHDRCR_IND := 'C';
        END IF;
        DBG(' l_cashdrcr_ind ' || L_CASHDRCR_IND);
      
        DBG('Will find cash GL Value');
        FOR I IN 1 .. 2 LOOP
        
          IF L_CASHDRCR_IND = P_ACC_HAND(I).DRCR_IND THEN
          
            L_CASHGLHANDOFF := P_ACC_HAND(I).AC_NO;
          
            L_CASHCCYHANDOFF := P_ACC_HAND(I).AC_CCY;
            L_CASHBRNHANDOFF := P_ACC_HAND(I).AC_BRANCH;
          
            DBG(' l_cashGlHandoff ' || L_CASHGLHANDOFF);
            L_OFSLEGCASHAMT := NVL(P_ACC_HAND(I).FCY_AMOUNT,
                                   P_ACC_HAND(I).LCY_AMOUNT);
            DBG('l_ofslegcashAmt for ' || I || ' time is :::: ' ||
                L_OFSLEGCASHAMT);
          
            IF P_ACC_HAND(I).DRCR_IND = 'D' THEN
              DBG('multiply with -1 as header is debit');
              L_OFSLEGCASHAMT := L_OFSLEGCASHAMT * -1;
            END IF;
          
          END IF;
        END LOOP;
        DBG(' Now before itrrating handoff and finding total amount for the GL ');
      
        IF P_ACC_HAND.COUNT > 2 THEN
        
          FOR J IN 3 .. P_ACC_HAND.COUNT LOOP
          
            DBG('Inside Loop..');
            DBG('p_acc_hand(' || J ||
                ').amount_tag in fn_getCashamt for ofs leg::::: ' || P_ACC_HAND(J)
                .AMOUNT_TAG);
            IF P_ACC_HAND(J).AMOUNT_TAG LIKE 'CHG_AMT%' THEN
            
              DBG('The offset handoff account number is:' || P_ACC_HAND(J)
                  .AC_NO || ' cashGl is:' || L_CASHGLHANDOFF);
              DBG('The ofs handoff account currency is:' || P_ACC_HAND(J)
                  .AC_CCY || ' cash currency is:' || L_CASHCCYHANDOFF);
              DBG('The ofs handoff account branch is:' || P_ACC_HAND(J)
                  .AC_BRANCH || ' cash branch is:' || L_CASHBRNHANDOFF);
            
              IF P_ACC_HAND(J).AC_NO = L_CASHGLHANDOFF AND P_ACC_HAND(J)
                 .AC_BRANCH = L_CASHBRNHANDOFF AND P_ACC_HAND(J)
                 .AC_CCY = L_CASHCCYHANDOFF THEN
              
                DBG('Inside Loop....INSIDE THE IF CONITION..... ' || P_ACC_HAND(J)
                    .DRCR_IND);
                IF P_ACC_HAND(J).DRCR_IND = 'D' THEN
                  DBG('Inside Loop...SETTING THE  MULTIPLIER TO -1');
                  L_CASHDRCR_MUL := -1;
                ELSE
                  L_CASHDRCR_MUL := 1;
                END IF;
              
                DBG(' Adding ofs leg amnt.' || J);
              
                L_OFSLEGCASHAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                            P_ACC_HAND(J).LCY_AMOUNT);
                L_OFSLEGCASHAMT      := L_OFSLEGCASHAMT + (L_OFSLEGCASHAMT_TEMP *
                                        L_CASHDRCR_MUL);
                IF NOT L_OFSLEGCASHSET THEN
                  L_OFSLEGCASHSET := TRUE;
                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;
      
        IF NOT L_OFSLEGCASHSET THEN
          DBG(' txn leg was not set .. so set out parameter to null ' ||
              P_OFSLEGCASHAMT);
        
          P_OFSLEGCASHAMT := L_OFSLEGCASHAMT;
        
        END IF;
      
        DBG(' pkg_ofslegcashAmt ' || P_OFSLEGCASHAMT);
      
      END IF;
      P_OFSLEGCASHAMT := ABS(L_OFSLEGCASHAMT);
      DBG('Offset leg cash amount after offset manipulation is:' ||
          P_OFSLEGCASHAMT);
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_GET_CASHAMT(P_ACC_HAND,
                                                     P_TXNLEGCASHAMT,
                                                     P_OFSLEGCASHAMT,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM) THEN
      
        DBG('error ' || P_ERR_PARAM);
      
        RETURN FALSE;
      
      END IF;
    END IF;
  
    DBG('P_TXNLEGCASHAMT is:' || P_TXNLEGCASHAMT);
    DBG('P_OFSLEGCASHAMT is:' || P_OFSLEGCASHAMT);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In Exception Fn_get_cashAmt ' || SQLERRM);
      RETURN FALSE;
  END FN_GET_CASHAMT;

  FUNCTION FN_GET_ACTAMT(P_ACC_HAND  IN ACPKS.TBL_ACHOFF,
                         P_ERR_CODE  OUT VARCHAR2,
                         P_ERR_PARAM OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_CASHDRCR_IND         ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_CASHDRCR_MUL         NUMBER;
    L_FINALACC             ACTB_DAILY_LOG.AC_NO%TYPE;
    IS_ACCGL1              VARCHAR2(1);
    IS_ACCGL2              VARCHAR2(1);
    L_MAINLEGACC1          ACTB_DAILY_LOG.AC_NO%TYPE;
    L_MAINLEGACC2          ACTB_DAILY_LOG.AC_NO%TYPE;
    L_MAINLEGACC1_DRCR_IND ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_MAINLEGACC2_DRCR_IND ACTB_DAILY_LOG.DRCR_IND%TYPE;
    L_ACTAMT               ACTB_DAILY_LOG.LCY_AMOUNT%TYPE := 0;
    L_ACTAMT_TEMP          ACTB_DAILY_LOG.LCY_AMOUNT%TYPE := 0;
    L_MAINLEGCCY1          ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_MAINLEGCCY2          ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_MAINLEGBRN1          ACTB_DAILY_LOG.AC_BRANCH%TYPE;
    L_MAINLEGBRN2          ACTB_DAILY_LOG.AC_BRANCH%TYPE;
    L_FINALCCY             ACTB_DAILY_LOG.AC_CCY%TYPE;
    L_FINALBRN             ACTB_DAILY_LOG.AC_BRANCH%TYPE;
  BEGIN
  
    DBG('Inside fn_get_actAmt ..');
  
    DBG(' gwpks_util.pkg_func ' || GWPKS_UTIL.PKG_FUNC);
    DBG(' Before getting the value of Account/GL in main Leg ');
    FOR I IN 1 .. 2 LOOP
    
      DBG('I am inside loop i ' || I);
      IF I = 1 THEN
        L_MAINLEGACC1          := P_ACC_HAND(I).AC_NO;
        L_MAINLEGACC1_DRCR_IND := P_ACC_HAND(I).DRCR_IND;
        L_MAINLEGCCY1          := P_ACC_HAND(I).AC_CCY;
        L_MAINLEGBRN1          := P_ACC_HAND(I).AC_BRANCH;
      ELSE
      
        L_MAINLEGACC2          := P_ACC_HAND(I).AC_NO;
        L_MAINLEGACC2_DRCR_IND := P_ACC_HAND(I).DRCR_IND;
        L_MAINLEGCCY2          := P_ACC_HAND(I).AC_CCY;
        L_MAINLEGBRN2          := P_ACC_HAND(I).AC_BRANCH;
      END IF;
    
    END LOOP;
    DBG('After loop ');
    DBG('l_MainLegAcc1 ' || L_MAINLEGACC1);
    DBG('l_MainLegAcc1_drcr_ind ' || L_MAINLEGACC1_DRCR_IND);
    DBG('l_mainlegCcy1 ' || L_MAINLEGCCY1);
    DBG('l_mainlegBrn1 ' || L_MAINLEGBRN1);
  
    DBG('l_MainLegAcc2 ' || L_MAINLEGACC2);
    DBG('l_MainLegAcc2_drcr_ind ' || L_MAINLEGACC2_DRCR_IND);
    DBG('l_mainlegCcy2 ' || L_MAINLEGCCY2);
    DBG('l_mainlegBrn2 ' || L_MAINLEGBRN2);
  
    BEGIN
    
      SELECT AC_OR_GL
        INTO IS_ACCGL1
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = L_MAINLEGACC1
         AND BRANCH_CODE = L_MAINLEGBRN1;
    
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        DBG('NO DATA FOUND HENCE SETTTING l_MainLegAcc1 TYPE AS GL');
        IS_ACCGL1 := 'G';
      
      WHEN OTHERS THEN
        DBG('Failed While getting Acc/GL for ' || L_MAINLEGACC1);
        RETURN FALSE;
    END;
    DBG('Is_AccGL1 ' || IS_ACCGL1);
    BEGIN
    
      SELECT AC_OR_GL
        INTO IS_ACCGL2
        FROM STTB_ACCOUNT
       WHERE AC_GL_NO = L_MAINLEGACC2
         AND BRANCH_CODE = L_MAINLEGBRN2;
    
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        DBG('NO DATA FOUND HENCE SETTTING l_MainLegAcc2 TYPE AS GL');
        IS_ACCGL2 := 'G';
      
      WHEN OTHERS THEN
        DBG('Failed While getting Acc/GL for ' || L_MAINLEGACC2);
        RETURN FALSE;
    END;
    DBG('Is_AccGL2 ' || IS_ACCGL2);
  
    IF (IS_ACCGL1 = 'A' AND IS_ACCGL2 = 'A') OR
       (IS_ACCGL1 = 'G' AND IS_ACCGL2 = 'G') THEN
      IF L_MAINLEGACC1_DRCR_IND = 'D' THEN
        L_FINALACC := L_MAINLEGACC1;
        L_FINALCCY := L_MAINLEGCCY1;
        L_FINALBRN := L_MAINLEGBRN1;
      ELSE
        L_FINALACC := L_MAINLEGACC2;
        L_FINALCCY := L_MAINLEGCCY2;
        L_FINALBRN := L_MAINLEGBRN2;
      END IF;
      DBG(' l_FinalAcc  ' || L_FINALACC);
    
    END IF;
  
    IF IS_ACCGL1 <> IS_ACCGL2 THEN
    
      IF IS_ACCGL1 = 'A' THEN
        L_FINALACC := L_MAINLEGACC1;
        L_FINALCCY := L_MAINLEGCCY1;
        L_FINALBRN := L_MAINLEGBRN1;
      ELSE
        L_FINALACC := L_MAINLEGACC2;
        L_FINALCCY := L_MAINLEGCCY2;
        L_FINALBRN := L_MAINLEGBRN2;
      END IF;
    
    END IF;
  
    DBG('For Special CASE function:' || GWPKS_UTIL.PKG_FUNC);
    IF GWPKS_UTIL.PKG_FUNC IN ('8004', 'CRCP', '1460') OR
       NVL(GWPKS_CREATERETAILTLR.G_PARENT_FUNCTIONID, '*.*') IN
       ('8004', 'CRCP', '1460') THEN
      L_FINALACC := L_MAINLEGACC2;
      L_FINALCCY := L_MAINLEGCCY2;
      L_FINALBRN := L_MAINLEGBRN2;
    END IF;
    DBG(' l_FinalBrn  ' || L_FINALBRN);
    DBG(' l_FinalCcy  ' || L_FINALCCY);
    DBG(' l_FinalAcc  ' || L_FINALACC);
    DBG(' Now before itrrating handoff and finding total amount for the Account ');
    FOR J IN 1 .. P_ACC_HAND.COUNT LOOP
      DBG('Inside Loop..' || J);
      DBG('p_acc_hand(' || J || ').amount_tag in fn_get_actAmt::::: ' || P_ACC_HAND(J)
          .AMOUNT_TAG);
      IF P_ACC_HAND(J).AMOUNT_TAG NOT IN ('REVL_AMT') THEN
        DBG('The account number in account amount computation is:' || P_ACC_HAND(J)
            .AC_NO);
        DBG('The debit credit indicator is:' || P_ACC_HAND(J).DRCR_IND);
        DBG('The acpks account currency is:' || P_ACC_HAND(J).AC_CCY ||
            ' and account branch is:' || P_ACC_HAND(J).AC_BRANCH);
      
        IF L_MAINLEGACC1 = L_MAINLEGACC2 THEN
          IF P_ACC_HAND(J)
           .AC_BRANCH = L_FINALBRN AND P_ACC_HAND(J).AC_NO = L_FINALACC AND P_ACC_HAND(J)
             .AC_CCY = L_FINALCCY THEN
            IF P_ACC_HAND(J).DRCR_IND = 'C' THEN
              L_CASHDRCR_MUL := 1;
            ELSE
              L_CASHDRCR_MUL := -1;
            END IF;
            DBG('The fcy amount is:' || P_ACC_HAND(J).FCY_AMOUNT ||
                ' with lcy amount as:' || P_ACC_HAND(J).LCY_AMOUNT);
            L_ACTAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                 P_ACC_HAND(J).LCY_AMOUNT);
            L_ACTAMT      := L_ACTAMT + (L_ACTAMT_TEMP * L_CASHDRCR_MUL);
          
          END IF;
        ELSE
          IF P_ACC_HAND(J).AC_NO = L_FINALACC THEN
            IF P_ACC_HAND(J).DRCR_IND = 'C' THEN
              L_CASHDRCR_MUL := 1;
            ELSE
              L_CASHDRCR_MUL := -1;
            END IF;
            DBG('The fcy amount is:' || P_ACC_HAND(J).FCY_AMOUNT ||
                ' with lcy amount as:' || P_ACC_HAND(J).LCY_AMOUNT);
            L_ACTAMT_TEMP := NVL(P_ACC_HAND(J).FCY_AMOUNT,
                                 P_ACC_HAND(J).LCY_AMOUNT);
            L_ACTAMT      := L_ACTAMT + (L_ACTAMT_TEMP * L_CASHDRCR_MUL);
          
          END IF;
        END IF;
      END IF;
    END LOOP;
    PKG_TXNACTAMT := ABS(L_ACTAMT);
    DBG(' pkg_TxnactAmt ' || PKG_TXNACTAMT);
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CLUSTER THEN
      DBG('Calling depks_rtl_teller_cluster.fn_post_get_actAmt..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_POST_GET_ACTAMT(P_ACC_HAND,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_cluster.fn_post_get_actAmt');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_CUSTOM THEN
      DBG('Calling depks_rtl_teller_custom.fn_post_get_actAmt..');
      IF NOT DEPKS_RTL_TELLER_CUSTOM.FN_POST_GET_ACTAMT(P_ACC_HAND,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
        DBG('Failed in call to depks_rtl_teller_cluster.fn_post_get_actAmt');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG(' Before returning Successfully from fn_get_actAmt ');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In Exception fn_get_actAmt ' || SQLERRM);
      RETURN FALSE;
  END FN_GET_ACTAMT;

  FUNCTION FN_SAVE(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                   P_ERR_CODE            IN OUT VARCHAR2,
                   P_ERR_PARAM           IN OUT VARCHAR2) RETURN BOOLEAN IS
    P_ACC_HAND             ACPKS.TBL_ACHOFF;
    I                      NUMBER := 1;
    L_RET                  NUMBER := 0;
    L_AUTH_STAT            VARCHAR2(1) := 'U';
    TOT_CHGS               PLS_INTEGER := 5;
    L_STAT                 VARCHAR2(4);
    L_ACC                  VARCHAR2(20);
    L_BRN                  VARCHAR2(3);
    L_CCY                  VARCHAR2(3);
    L_ACENTRIES_RETURNED_2 BOOLEAN := FALSE;
  
    L_ACC_TYPE_1  VARCHAR2(20);
    L_ACC_TYPE_2  VARCHAR2(20);
    L_TOTAL_RES   NUMBER;
    L_ALL_RES     NUMBER;
    L_SUM         NUMBER;
    LEG_IND       VARCHAR2(10);
    L_CUS_ERRCODE VARCHAR2(100);
    L_ERR_PARAM   VARCHAR2(100);
    L_TXN_ACC     DETBS_RTL_TELLER.TXN_ACC%TYPE;
  
    V_TBL_RESTR          STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    V_TBL_RESTR_BOTH_ACC STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_COUNT_REST         NUMBER := 0;
    L_TOTAL_REST_COD     NUMBER := 0;
    L_ENTITY_NAME        STTM_BRN_ENT_MNT.ENTITY_NAME%TYPE;
    L_UNIT_NAME          STTM_BRN_ENT_MNT.UNIT_NAME%TYPE;
    L_ENTITY_TYPE        STTM_BRN_ENT_MNT.ENTITY_TYPE%TYPE;
    L_ENTITY_PARAM       STTM_BRN_ENT_MNT_PARAMS.PARAMETER%TYPE;
    L_NO_OF_PARAM        NUMBER;
    L_COUNT              NUMBER;
    X                    NUMBER;
  
    L_PROCEED NUMBER := 0;
    L_REL_CUS DETBS_RTL_TELLER.REL_CUSTOMER%TYPE;
  
    COUNT_LOOP NUMBER;
    L_HANDOFF  NUMBER;
  
    L_CHARGES_RETURNED_2 BOOLEAN := FALSE;
    L_BRN_AVAILABLE      VARCHAR2(1);
    L_PROCESS_ACCOUTING  BOOLEAN := TRUE;
  
    L_RETAIL_LENDING_PRODUCT DETMS_RT_PREFERENCES.RETAIL_LENDING_PRODUCT%TYPE;
  
    L_PCPAYOUTDETS_REC DETB_PCTRN%ROWTYPE;
    L_PC_TXN           DETMS_RT_PREFERENCES.PC_TXN%TYPE;
    L_NEG_AMT          NUMBER;
    L_SAVEFLAG         BOOLEAN := TRUE;
    TOT_AMOUNT_DUE     CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_NSF_CCY          STTM_CUST_ACCOUNT.CCY%TYPE;
    L_TRACK_ACCOUNT    BOOLEAN := TRUE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_TEMP_MAX  NUMBER := 0;
    L_RSC_INDEX NUMBER := 0;
    L_IB_FLAG   VARCHAR2(1);
    L_TXN_AC_NO DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN   DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
    L_FT_TXN    DETMS_RT_PREFERENCES.PC_TXN%TYPE;
  
    L_TOT_CHARGES        NUMBER := 1;
    L_AMT_1              NUMBER;
    L_AMT_2              NUMBER;
    L_AMT_3              NUMBER;
    L_AMT_4              NUMBER;
    L_AMT_5              NUMBER;
    L_EXECUTE1           BOOLEAN := FALSE;
    L_EXECUTE2           BOOLEAN := FALSE;
    L_EXECUTE3           BOOLEAN := FALSE;
    L_EXECUTE4           BOOLEAN := FALSE;
    L_EXECUTE5           BOOLEAN := FALSE;
    L_ARC_ROW_BEFORE_ENT IFTMS_ARC_MAINT%ROWTYPE;
  
    L_TD_REDEMPTION_CALL  BOOLEAN := FALSE;
    L_MULTIINSTR_EXCHRATE CSTM_PRODUCT.RATE_CODE_PREFERRED%TYPE;
  
    L_CLTB_ACCOUNT_DP_REC CLPKSS_OBJECT.TY_REC_DOWNPAYMENT;
    L_VAL_RESULT          BOOLEAN := TRUE;
    L_SUM_DP              CLTBS_ACCOUNT_DOWNPAYMENT.DP_AMOUNT%TYPE := 0;
    L_OS_DP_RECV          CLTBS_ACCOUNT_DOWNPAYMENT.DP_AMOUNT%TYPE := 0;
    L_ACCOUNT_REC         CLTBS_ACCOUNT_MASTER%ROWTYPE;
    L_SERIAL_DOWNPAYMENT  VARCHAR2(100);
    L_REF_NO_DOWNPAYMENT  CLTBS_ACCOUNT_DOWNPAYMENT.PROCESS_REF_NO%TYPE;
    L_COUNT_DOWNPAY       NUMBER := 0;
    L_CUSTID              VARCHAR2(30);
    L_CCY_HAMISHJIDDAYAH  VARCHAR2(30);
    L_HANDOFF_AMT         NUMBER := 0;
  
    L_TXN_AMT NUMBER := 0;
    L_CHG_AMT NUMBER := 0;
    CURSOR ENTITY_CODE(P_ENTITY_NAME VARCHAR2) IS
      SELECT ENTITY_NAME, UNIT_NAME, ENTITY_TYPE
        FROM STTM_BRN_ENT_MNT
       WHERE ENTITY_NAME = P_ENTITY_NAME;
  
    CURSOR ENTITY_CODE_DETAILS(P_ENTITY_NAME VARCHAR2) IS
      SELECT A.ENTITY_NAME, A.UNIT_NAME, A.ENTITY_TYPE, B.PARAMETER
        FROM STTM_BRN_ENT_MNT A, STTM_BRN_ENT_MNT_PARAMS B
       WHERE A.ENTITY_NAME = B.ENTITY_NAME
         AND A.ENTITY_NAME = P_ENTITY_NAME;
  
    TYPE TBL_ENTITY_CODE IS TABLE OF ENTITY_CODE%ROWTYPE INDEX BY PLS_INTEGER;
    L_CHG_ENTITY_CODE TBL_ENTITY_CODE;
  
    TYPE TBL_ENTITY_CODE_DETAILS IS TABLE OF ENTITY_CODE_DETAILS%ROWTYPE INDEX BY PLS_INTEGER;
    L_CHG_ENTITY_CODE_DETAILS TBL_ENTITY_CODE_DETAILS;
  
    L_TXNLEGCASHAMT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_OFSLEGCASHAMT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  
    L_AMT1               NUMBER;
    L_ACC_CHG_EXCH_RATE1 NUMBER;
    L_TCY1               NUMBER;
    L_TCY2               NUMBER;
    L_TCY3               NUMBER;
    L_TCY4               NUMBER;
    L_TCY5               NUMBER;
  
    L_CURRENT_DP_AMOUNT NUMBER := 0;
    L_CNT               NUMBER := 1;
    L_ACC_TAB           ACPKSS.TBL_ACHOFF;
    L_VIR_COUNT         NUMBER;
    L_VIR_ACC1          STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_VIR_ACC2          STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  BEGIN
    DBG('In fn_save.................SHIKHS HERE');
    PKG_RTL_TELLER_REC   := P_DETB_RTL_TELLER_REC;
    PKG_LCY              := GLOBAL.LCY;
    PKG_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
  
    IF PKG_ARC_ROW.COD_BRANCH IS NULL THEN
      PR_SET_GLOBAL(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NVL(DEPKS_RETAILTELLERUPLOAD.G_DENOM_VARIANCE, 'N') = 'Y' THEN
    
      IF GWPKS_UTIL.PKG_FUNC IN ('8203', '8004') OR
         NVL(GWPKS_CREATERETAILTLR.G_PARENT_FUNCTIONID, '*.*') IN
         ('8203', '8004') THEN
        IF DEPKS_RETAILTELLERUPLOAD.G_EXCH_RATE_NOT_NULL = 'Y' THEN
          DBG('Came here when g_exch_rate_Not_Null and for 8203 or 8004......');
          DBG('pkg_rtl_teller_rec.ofs_amount :::: ' ||
              PKG_RTL_TELLER_REC.OFS_AMOUNT);
          PKG_RTL_TELLER_REC.ORG_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        ELSE
          DBG('In 8203 or 8004 ofs_amt is  ' ||
              PKG_RTL_TELLER_REC.OFS_AMOUNT);
          DBG('In 8203 or 8004 exch_rate is  ' ||
              PKG_RTL_TELLER_REC.EXCH_RATE);
          PKG_RTL_TELLER_REC.OFS_AMOUNT := DEPKS_RETAILTELLERUPLOAD.G_ORG_AMOUNT;
          PKG_RTL_TELLER_REC.EXCH_RATE  := DEPKS_RETAILTELLERUPLOAD.G_ORG_EXCH_RATE;
          DBG('In 8203 or 8004 ofs_amt is  ' ||
              PKG_RTL_TELLER_REC.OFS_AMOUNT);
          DBG('In 8203 or 8004 exch_rate is  ' ||
              PKG_RTL_TELLER_REC.EXCH_RATE);
        END IF;
      ELSIF GWPKS_UTIL.PKG_FUNC IN ('8206', '8207') THEN
        IF DEPKS_RETAILTELLERUPLOAD.G_EXCH_RATE_NOT_NULL = 'Y' THEN
          DBG('Came here when g_exch_rate_Not_Null and for 8206 or 8207......');
          DBG('pkg_rtl_teller_rec.txn_amount :::: ' ||
              PKG_RTL_TELLER_REC.TXN_AMOUNT);
          PKG_RTL_TELLER_REC.ORG_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        ELSE
          DBG('In 8206 or 8207 txn_amount is  ' ||
              PKG_RTL_TELLER_REC.TXN_AMOUNT);
          DBG('In 8206 or 8207 exch_rate is  ' ||
              PKG_RTL_TELLER_REC.EXCH_RATE);
          PKG_RTL_TELLER_REC.TXN_AMOUNT := NVL(DEPKS_RETAILTELLERUPLOAD.G_ORG_AMOUNT,
                                               PKG_RTL_TELLER_REC.TXN_AMOUNT);
          PKG_RTL_TELLER_REC.EXCH_RATE  := DEPKS_RETAILTELLERUPLOAD.G_ORG_EXCH_RATE;
          DBG('In 8206 or 8207 txn_amount is  ' ||
              PKG_RTL_TELLER_REC.TXN_AMOUNT);
          DBG('In 8206 or 8207 exch_rate is  ' ||
              PKG_RTL_TELLER_REC.EXCH_RATE);
        END IF;
      END IF;
    
    END IF;
  
    IF NVL(PKG_PROD.PRODUCT_CODE, '!@#$') <>
       PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
      IF NOT
          CSPKS_UTILS.FN_GETPRODUCT_DETAILS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
        DBG('From cstm_prod ' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
            SQLERRM);
        P_ERR_CODE := 'DE-TUD-003';
        RETURN FALSE;
      END IF;
      PKG_PROD := CSPKS_UTILS.PKG_PRODUCT;
    END IF;
    IF PKG_PROD.PRODUCT_TYPE = 'IL' THEN
      BEGIN
      
        SELECT INSTR_STAT, AC_NO, AC_BRANCH, AC_CCY
          INTO L_STAT, L_ACC, L_BRN, L_CCY
          FROM ISTM_INSTR_TXN
         WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Could b issue. Any case, shl trap later.');
        WHEN OTHERS THEN
          DBG('Some other err ' || SQLERRM);
          P_ERR_CODE  := 'IF-DAT013';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.XREF || '~';
          RETURN FALSE;
      END;
      IF PKG_RTL_TELLER_REC.PRODUCT_CODE <> 'BCLT' THEN
        IF L_STAT = 'LOST' THEN
          DBG('Instrument Reported to have been Lost.');
          P_ERR_CODE  := 'AC-RECLOST';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE || '~';
          RETURN FALSE;
        END IF;
      END IF;
    
    END IF;
    IF NOT FN_VALIDATE(P_ERR_CODE, P_ERR_PARAM) THEN
      RETURN FALSE;
    END IF;
    DBG('coming out of fn_validate');
  
    DBG('cspkss_charge.g_Sc_Skip_Accntng got here is ->' ||
        CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG);
  
    IF NVL(CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG, 'N') = 'Y' THEN
      PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG := 'N';
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 3;
      DBG('Calling depks_rtl_teller_cluster.fn_derive_neg_rate....');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                              PKG_ARC_ROW,
                                              PKG_LCY,
                                              G_TXNAMT_FLAG,
                                              G_OFSAMT_FLAG,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
        DBG('Failed in depks_rtl_teller_custom.fn_derive_neg_rate with :::: ' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
      DBG('NEGOTIATE RATE VALUE ::::: ' ||
          PKG_RTL_TELLER_REC.NEGOTIATED_RATE);
    END IF;
  
    IF NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1001' AND
       NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' THEN
      DBG('setting the instr code as the gl will be misc gl ->');
      PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE := PKG_RTL_TELLER_REC.XREF;
      PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE := PKG_RTL_TELLER_REC.XREF;
    
      IF NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' THEN
        DBG('its a two step cash withdrawal with txn_branch as ' ||
            PKG_RTL_TELLER_REC.TXN_BRANCH);
        PKG_RTL_TELLER_REC.TXN_BRANCH := GLOBAL.CURRENT_BRANCH;
        DBG(' txn branch is reset to current branch ' ||
            PKG_RTL_TELLER_REC.TXN_BRANCH);
      END IF;
    
    END IF;
  
    IF GWPKS_ENRICHDDCONTRACTSERVICES.G_BLOCK_TYPE AND
       GWPKS_ENRICHDDCONTRACTSERVICES.G_CHG_BY_CASH = 'N' AND
       NVL(DEPKS_RTL_TELLER.G_CHARGE_MODE, 'N') NOT IN ('A') THEN
    
      DBG('-------------Came here for parent block accounts and charge amount assignment---------------------');
      DBG('pkg_chg_row.cod_txn_account ::::' ||
          PKG_ARC_ROW.COD_TXN_ACCOUNT);
      DBG('pkg_chg_row.cod_offset_acc :::: ' || PKG_ARC_ROW.COD_OFFSET_ACC);
      DBG('Assigning the values for getting the customer account as the debit account....');
      DBG('gwpks_createddcontract.g_total_amt :::: ' ||
          GWPKS_CREATEDDCONTRACT.G_TOTAL_AMT);
      DBG('gwpks_enrichddcontractservices.g_tot_tt_chg :::: ' ||
          GWPKS_ENRICHDDCONTRACTSERVICES.G_TOT_TT_CHG);
      DBG('Before the computation for MultiInst parent block');
    
      DBG('Trn ref no is:' || PKG_RTL_TELLER_REC.TRN_REF_NO ||
          ' with TXn amount is:' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
          ' with txn ccy:' || PKG_RTL_TELLER_REC.TXN_CCY);
      DBG('Ofs amount is:' || PKG_RTL_TELLER_REC.OFS_AMOUNT ||
          ' with ofs ccy:' || PKG_RTL_TELLER_REC.OFS_CCY || ' with lcy:' ||
          PKG_LCY);
      DBG('The product used is:' || PKG_ARC_ROW.COD_PROD_ACC_CLS ||
          ' with arc debit acc as:' || PKG_ARC_ROW.DR_ACC ||
          ' with Prod rate code:' || PKG_PROD.RATE_CODE_PREFERRED ||
          ' with prod rate type:' || PKG_PROD.RATE_TYPE_PREFERRED ||
          ' with pkg prod as:' || PKG_PROD.PRODUCT_CODE);
      IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
        L_MULTIINSTR_EXCHRATE := 'S';
      ELSE
        L_MULTIINSTR_EXCHRATE := 'B';
      END IF;
      IF PKG_PROD.RATE_CODE_PREFERRED = 'M' THEN
        L_MULTIINSTR_EXCHRATE := 'M';
      END IF;
    
      PKG_RTL_TELLER_REC.OFS_AMOUNT := GWPKS_CREATEDDCONTRACT.G_TOTAL_AMT +
                                       GWPKS_ENRICHDDCONTRACTSERVICES.G_TOT_TT_CHG;
    
      DBG('Offset amount is:' || PKG_RTL_TELLER_REC.OFS_AMOUNT ||
          ' with charge mode as:' || G_CHARGE_MODE);
      IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                      PKG_RTL_TELLER_REC.OFS_CCY,
                                      PKG_RTL_TELLER_REC.TXN_CCY,
                                      NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                          'STANDARD'),
                                      NVL(L_MULTIINSTR_EXCHRATE, 'M'),
                                      PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                      'Y',
                                      PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                      PKG_RTL_TELLER_REC.EXCH_RATE,
                                      P_ERR_CODE) THEN
          DBG('Failure in converting instr amt to ac ccy amt ' ||
              P_ERR_CODE);
        END IF;
      ELSE
        PKG_RTL_TELLER_REC.TXN_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
      END IF;
      GWPKS_ENRICHDDCONTRACTSERVICES.G_GL_AMT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      DBG('After computation txn amount:' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
          ' offset amount:' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
      UPDATE ISTM_INSTR_TOTTTTXN
         SET ACY_AMOUNT = PKG_RTL_TELLER_REC.TXN_AMOUNT,
             OFS_AMOUNT = PKG_RTL_TELLER_REC.OFS_AMOUNT,
             AUTH_STAT  = 'A'
       WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
    
      PKG_RTL_TELLER_REC.CHG_AMT := GWPKS_ENRICHDDCONTRACTSERVICES.G_TOT_TT_CHG;
    ELSIF GWPKS_ENRICHDDCONTRACTSERVICES.G_MULTI_CHILD THEN
      DBG('gwpks_enrichddcontractservices.g_parent_ofs_acc :::: ' ||
          GWPKS_ENRICHDDCONTRACTSERVICES.G_PARENT_OFS_ACC);
      PKG_RTL_TELLER_REC.TXN_ACC := GWPKS_ENRICHDDCONTRACTSERVICES.G_PARENT_OFS_ACC;
      IF PKG_RTL_TELLER_REC.PRODUCT_CODE NOT IN ('BCMA', 'BCMC', 'BCMG') THEN
        DBG('Product Code is not BCMA,BCMC OR BCMG');
        PKG_ARC_ROW.COD_TXN_ACCOUNT := GWPKS_ENRICHDDCONTRACTSERVICES.G_PARENT_OFS_ACC;
      END IF;
    ELSIF GWPKS_ENRICHDDCONTRACTSERVICES.G_BLOCK_TYPE AND
          GWPKS_ENRICHDDCONTRACTSERVICES.G_CHG_BY_CASH = 'Y' THEN
      DBG('----In depks_rtl_teller when g_chg_by_cash is Y---------');
      PKG_ARC_ROW.COD_CHG_AMT := GWPKS_ENRICHDDCONTRACTSERVICES.G_TOT_TT_CHG;
      DBG('pkg_arc_row.cod_chg_amt >>>>>> ' || PKG_ARC_ROW.COD_CHG_AMT);
      PKG_ARC_ROW.COD_CHG_GL := PKG_ARC_ROW.COD_OFFSET_ACC;
      DBG('pkg_arc_row.cod_chg_gl >>>>>> ' || PKG_ARC_ROW.COD_CHG_GL);
      PKG_ARC_ROW.CHG_DR_LEG := PKG_ARC_ROW.COD_TXN_ACCOUNT;
      DBG('pkg_arc_row.chg_dr_leg >>>>>> ' || PKG_ARC_ROW.CHG_DR_LEG);
    
    ELSIF GWPKS_ENRICHDDCONTRACTSERVICES.G_BLOCK_TYPE AND
          DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
      DBG('----In depks_rtl_teller when g_charge_mode is A---------');
      PKG_ARC_ROW.COD_CHG_AMT := GWPKS_ENRICHDDCONTRACTSERVICES.G_TOT_TT_CHG;
      DBG('pkg_arc_row.cod_chg_amt >>>>>> ' || PKG_ARC_ROW.COD_CHG_AMT);
      PKG_ARC_ROW.COD_CHG_GL := PKG_ARC_ROW.COD_OFFSET_ACC;
      DBG('pkg_arc_row.cod_chg_gl >>>>>> ' || PKG_ARC_ROW.COD_CHG_GL);
      PKG_ARC_ROW.CHG_DR_LEG := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
      DBG('pkg_arc_row.chg_dr_leg >>>>>> ' || PKG_ARC_ROW.CHG_DR_LEG);
    
    END IF;
  
    IF NOT CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      DBG('cspkss_charge.g_function_id function id got here is ->' ||
          CSPKSS_CHARGE.G_FUNCTION_ID);
      IF PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG = 'Y' THEN
        DBG('going to call acc_entries');
        PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND, L_RET);
        PKG_MAIN_ENTRIES_BUILT := TRUE;
      END IF;
    END IF;
  
    IF L_RET = -1 THEN
      DBG('Ac entries returned false...' || L_RET);
      RETURN FALSE;
    ELSIF L_RET = 2 THEN
      DBG('Ac entries need to be tracked...');
      L_ACENTRIES_RETURNED_2 := TRUE;
    END IF;
  
    IF ISPKSS_INSTRUMENTS.PKG_CHQ_PURCHASE AND P_ACC_HAND(1).EVENT = 'LIQD' THEN
      DBG('CALLING SWAP ACCOUNT...');
      ACPKSS.PR_SWAP_DRCR_IND_AMT(P_ACC_HAND);
    
      P_ACC_HAND(1).DONT_SHOWIN_STMT := 'Y';
    END IF;
  
    DBG('PKG_ARC_ROW.COD_CHG_TYPE=' || PKG_ARC_ROW.COD_CHG_TYPE);
    DBG('PKG_ARC_ROW.CHARGE_CODE=' || PKG_ARC_ROW.CHARGE_CODE);
  
    IF (PKG_ARC_ROW.COD_CHG_TYPE IS NULL AND
       PKG_ARC_ROW.CHARGE_CODE IS NULL) THEN
      TOT_CHGS := 0;
    ELSIF (PKG_ARC_ROW.COD_CHG_TYPE1 IS NULL AND
          PKG_ARC_ROW.CHARGE_CODE1 IS NULL) THEN
      TOT_CHGS := 1;
    ELSIF (PKG_ARC_ROW.COD_CHG_TYPE2 IS NULL AND
          PKG_ARC_ROW.CHARGE_CODE2 IS NULL) THEN
      TOT_CHGS := 2;
    ELSIF (PKG_ARC_ROW.COD_CHG_TYPE3 IS NULL AND
          PKG_ARC_ROW.CHARGE_CODE3 IS NULL) THEN
      TOT_CHGS := 3;
    ELSIF (PKG_ARC_ROW.COD_CHG_TYPE4 IS NULL AND
          PKG_ARC_ROW.CHARGE_CODE4 IS NULL) THEN
      TOT_CHGS := 4;
    END IF;
  
    PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := 0;
  
    --sampath starts
    IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'ABRU' THEN
      PKG_RTL_TELLER_REC.CHG_GL := '000000036';
    END IF;
    --sampath ends
  
    DBG('chg gl 1->' || PKG_RTL_TELLER_REC.CHG_GL);
    DBG('chg gl 2->' || PKG_RTL_TELLER_REC.CHG_GL_1);
    DBG('chg gl 3->' || PKG_RTL_TELLER_REC.CHG_GL_2);
    DBG('chg gl 4->' || PKG_RTL_TELLER_REC.CHG_GL_3);
    DBG('chg gl 5->' || PKG_RTL_TELLER_REC.CHG_GL_4);
  
    IF NVL(CSPKSS_CHARGE.G_SERIVE_CHARGE, 'N') = 'Y' THEN
      TOT_CHGS := CSPKSS_CHARGE.G_CHARGE_COUNT;
    END IF;
    DBG('tot_chgs got here is ->' || TOT_CHGS);
  
    IF TOT_CHGS > 0 THEN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 3;
        DBG('Going to call depks_rtl_teller_cluster.fn_save ');
        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                                P_ERR_CODE,
                                                P_ERR_PARAM,
                                                L_FN_CALL_ID,
                                                L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save3');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('In depks_rtl_teller the waiver 0 is:' ||
          PKG_RTL_TELLER_REC.WAIVER);
      IF NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'Y' THEN
        PKG_ARC_ROW.COD_CHG_AMT := 0;
      END IF;
      IF NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
        PKG_ARC_ROW.COD_CHG_AMT1 := 0;
      END IF;
      IF NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'Y' THEN
        PKG_ARC_ROW.COD_CHG_AMT2 := 0;
      END IF;
      IF NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'Y' THEN
        PKG_ARC_ROW.COD_CHG_AMT3 := 0;
      END IF;
      IF NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'Y' THEN
        PKG_ARC_ROW.COD_CHG_AMT4 := 0;
      END IF;
      DBG('The Instrument contract number is:' ||
          PKG_RTL_TELLER_REC.TRN_REF_NO);
      DBG('IN depks_rtl_teller The charge amount 0 in ARC PICKUP is:' ||
          PKG_ARC_ROW.COD_CHG_AMT);
      DBG('IN depks_rtl_teller The charge amount 1 in ARC PICKUP is:' ||
          PKG_ARC_ROW.COD_CHG_AMT1);
      DBG('IN depks_rtl_teller The charge amount 2 in ARC PICKUP is:' ||
          PKG_ARC_ROW.COD_CHG_AMT2);
      DBG('IN depks_rtl_teller The charge amount 3 in ARC PICKUP is:' ||
          PKG_ARC_ROW.COD_CHG_AMT3);
      DBG('IN depks_rtl_teller The charge amount 4 in ARC PICKUP is:' ||
          PKG_ARC_ROW.COD_CHG_AMT4);
      DBG('The Retail Teller charge amount 0 is:' ||
          PKG_RTL_TELLER_REC.CHG_AMT);
      DBG('The Retail Teller charge amount 1 is:' ||
          PKG_RTL_TELLER_REC.CHG_AMT_1);
      DBG('The Retail Teller charge amount 2 is:' ||
          PKG_RTL_TELLER_REC.CHG_AMT_2);
      DBG('The Retail Teller charge amount 3 is:' ||
          PKG_RTL_TELLER_REC.CHG_AMT_3);
      DBG('The Retail Teller charge amount 4 is:' ||
          PKG_RTL_TELLER_REC.CHG_AMT_4);
    
      DBG('tot_chg is > 0');
      FOR I IN 1 .. TOT_CHGS LOOP
        IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
          PR_BUILD_CLOSE_CHG_ENTRIES(P_ACC_HAND,
                                     PKG_ARC_ROW,
                                     I,
                                     P_ERR_CODE,
                                     L_RET);
        ELSE
          DBG('Check12 chg ccy->' || PKG_ARC_ROW.COD_CHG_CCY);
          PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                               PKG_ARC_ROW,
                               I,
                               P_ERR_CODE,
                               L_RET);
        END IF;
        IF L_RET = -1 THEN
          RETURN FALSE;
        ELSIF L_RET = 2 THEN
          L_CHARGES_RETURNED_2 := TRUE;
        END IF;
      END LOOP;
    
    ELSE
      IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'N' AND
         G_CLOSURE_CHARGE = 'Y' THEN
        DBG('---------Calling pr_build_close_chg_entries in fn_save---------');
        PR_BUILD_CLOSE_CHG_ENTRIES(P_ACC_HAND,
                                   PKG_ARC_ROW,
                                   I,
                                   P_ERR_CODE,
                                   L_RET);
      END IF;
    
    END IF;
  
    IF STPKSS_ACCOUNT_CLOSE.G_CLS_ONLINE_CHG_ROUTE = 'Y' THEN
      DBG('Here in fn_save to set gwpks_util.pkg_temp_chg_dets to NULL');
      DBG('gwpks_util.pkg_temp_chg_dets before setting to null :: ' ||
          GWPKS_UTIL.PKG_TEMP_CHG_DETS);
      GWPKS_UTIL.PKG_TEMP_CHG_DETS := NULL;
    END IF;
  
    DBG('stpks_account_close.g_last_payout :::::::: ' ||
        STPKS_ACCOUNT_CLOSE.G_LAST_PAYOUT);
    IF STPKS_ACCOUNT_CLOSE.G_LAST_PAYOUT = 'N' AND G_CLOSURE_CHARGE = 'Y' THEN
      DBG('gwpks_util.pkg_temp_chg_dets BEFORE setting :::: ' ||
          GWPKS_UTIL.PKG_TEMP_CHG_DETS);
      GWPKS_UTIL.PKG_TEMP_CHG_DETS := NULL;
      DBG('gwpks_util.pkg_temp_chg_dets AFTER setting :::: ' ||
          GWPKS_UTIL.PKG_TEMP_CHG_DETS);
    END IF;
  
    IF L_ACENTRIES_RETURNED_2 OR L_CHARGES_RETURNED_2 THEN
      L_RET := 2;
    END IF;
    IF L_RET = 2 THEN
      PR_TRACK_ACCOUNT(PKG_RTL_TELLER_REC.TRN_REF_NO,
                       G_TRACK_CHARGE_ENTRIES,
                       G_TRACK_ACCOUNT_ENTRIES);
      DBG('TRacked ..going to return true to the form');
      PKG_RTL_TELLER_REC.RECORD_STAT := 'N';
    
      IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 101;
        DBG('b4 calling depks_rtl_teller_cluster.fn_save');
      
        IF NOT DEPKSS_RTL_TELLER_CLUSTER.FN_SAVE(P_DETB_RTL_TELLER_REC,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM) THEN
          DBG('depks_rtl_teller_cluster...fn_save is failed');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        PR_UPDATE_REC;
        DBG('Deleting only in case of Non -NSF Tracking ');
        P_ACC_HAND.DELETE;
        P_ERR_CODE  := 'DE-TRACK01';
        P_ERR_PARAM := '~';
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RETURN TRUE;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
    IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      DBG('b4 call to close ac entries...');
      PR_BUILD_CLOSE_AC_ENTRIES(P_ACC_HAND, L_RET);
    END IF;
  
    DBG('Pkg_Rtl_Teller_Rec.NEGOTIATED_RATE ' ||
        PKG_RTL_TELLER_REC.NEGOTIATED_RATE);
    DBG('Pkg_Rtl_Teller_Rec.exch_rate ' || PKG_RTL_TELLER_REC.EXCH_RATE);
    DBG('Pkg_Rtl_Teller_Rec.ofs_ccy ' || PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('Pkg_Rtl_Teller_Rec.txn_ccy ' || PKG_RTL_TELLER_REC.TXN_CCY);
    DBG('Pkg_Rtl_Teller_Rec.ofs_amount ' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
  
    IF PKG_RTL_TELLER_REC.NEGOTIATED_RATE IS NOT NULL AND
       PKG_RTL_TELLER_REC.EXCH_RATE <> 1 AND
       PKG_ARC_ROW.PROFIT_REVAL_GL IS NOT NULL AND
       PKG_ARC_ROW.LOSS_REVAL_GL IS NOT NULL THEN
    
      IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.OFS_CCY,
                                   PKG_RTL_TELLER_REC.TXN_CCY,
                                   PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                   PKG_RTL_TELLER_REC.NEGOTIATED_RATE,
                                   'N',
                                   L_NEG_AMT,
                                   P_ERR_CODE) THEN
        RETURN FALSE;
      END IF;
    
      PR_BUILD_XRATE_P_AND_L_ENTRIES(P_ACC_HAND,
                                     PKG_ARC_ROW,
                                     L_NEG_AMT,
                                     P_ERR_CODE,
                                     L_RET);
      IF L_RET = -1 THEN
        DBG('profit loss entry failed');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID := 6;
      DBG('Going to call depks_rtl_teller_cluster.fn_save call id is 6 ');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                              P_ACC_HAND,
                                              PKG_ARC_ROW,
                                              P_ERR_CODE,
                                              P_ERR_PARAM,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA) THEN
        DBG('Failed inside depks_rtl_teller_cluster.Fn_Save3');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('skipped code');
    ELSE
      DBG('if custom is not call');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DBG('pr_print_acctng_table is cmd');
  
    BEGIN
      DBG('pr_print_acctng_table is cmd in begin.....');
      PR_PRINT_ACCTNG_TABLE(P_ACC_HAND);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In OTHERS with line tracking  ::::: ' ||
            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;
  
    IF GWPKS_UTIL.G_FROM_BEAN THEN
      L_AUTH_STAT := 'B';
    
    ELSE
    
      IF NVL(GWPKS_UTIL.PKG_ACTTYPE, 'SAVEAUTOAUTH') IN ('SAVEAUTOAUTH') AND
         (GWPKS_UTIL.G_FROM_BEAN) THEN
      
        L_AUTH_STAT := 'B';
      
        DBG('l_auth_stat set as ' || L_AUTH_STAT);
      ELSE
        L_AUTH_STAT := 'U';
      END IF;
    
    END IF;
  
    DBG('Going to check the cache for - ' ||
        PKG_RTL_TELLER_REC.PRODUCT_CODE);
    IF NOT CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
      DBG('Failed to obtain the RT pref bec of - ' || P_ERR_CODE);
      L_RETAIL_LENDING_PRODUCT := NULL;
      P_ERR_CODE               := NULL;
      P_ERR_PARAM              := NULL;
      RETURN FALSE;
    ELSE
      L_RETAIL_LENDING_PRODUCT := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.RETAIL_LENDING_PRODUCT,
                                      'N');
      DBG('Value REtrieved from Fn_Get_Detm_Rt_Pref_Rec_Wrp..');
    END IF;
    DBG('l_retail_lending_product - ' || L_RETAIL_LENDING_PRODUCT);
  
    IF L_RETAIL_LENDING_PRODUCT = 'Y' THEN
      L_AUTH_STAT := 'U';
    END IF;
  
    IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE AND ICPKSS_BOD.G_FROM_TD <> TRUE THEN
      DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
      L_AUTH_STAT := 'B';
    END IF;
    IF PKG_ARC_ROW.COD_NET_CHARGES = 'Y' THEN
      CSPKSS_ARC.PR_NET_CHARGES(P_ACC_HAND,
                                PKG_ARC_ROW.CHG_FROM,
                                PKG_ARC_ROW.DR_ACC,
                                'TXN_AMT',
                                'OFS_AMT',
                                L_RET);
      IF L_RET = -1 THEN
        DBG('Netting failed');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('before acpkss.fn_achandoff ');
  
    IF GLOBALS_ADDON.FUND_BRANCH THEN
      BEGIN
        SELECT FUND_ID
          INTO PKG_RTL_TELLER_REC.FUND_ID
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = PKG_RTL_TELLER_REC.TXN_BRANCH
           AND CUST_AC_NO = PKG_RTL_TELLER_REC.TXN_ACC;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside when others of account select ' || SQLERRM);
          RETURN FALSE;
      END;
    
      UPDATE MITBS_CLASS_MAPPING
         SET FUND_MIS_1 = PKG_RTL_TELLER_REC.FUND_ID
       WHERE BRANCH_CODE = SUBSTR(PKG_RTL_TELLER_REC.TRN_REF_NO, 1, 3)
         AND UNIT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
         AND UNIT_TYPE = 'R';
    
    END IF;
  
    DBG('shan');
  
    BEGIN
      SELECT BRN_AVAIL_STAT
        INTO L_BRN_AVAILABLE
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    
      IF NVL(L_BRN_AVAILABLE, 'Y') = 'N' OR
         PKG_RTL_TELLER_REC.TRN_DT > GLOBAL.APPLICATION_DATE THEN
        PKG_RTL_TELLER_REC.TXN_TANKED := 'Y';
      ELSE
        PKG_RTL_TELLER_REC.TXN_TANKED := 'N';
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('any way this will never happen');
        RETURN FALSE;
    END;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 7;
      DBG('Calling depks_rtl_teller_cluster.fn_save for branch profitability ....');
      DBG('Before p_acc_hand.COUNT is ' || P_ACC_HAND.COUNT);
    
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                              PKG_ARC_ROW,
                                              PKG_LCY,
                                              P_ACC_HAND,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
        DBG('Failed in Calling depks_rtl_teller_cluster.fn_save for branch profitability  :::: ' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
      DBG('After p_acc_hand.COUNT is ' || P_ACC_HAND.COUNT);
    END IF;
  
    IF PKG_GENERATE_MT101 <> 'Y' THEN
      DBG('b4 fn_achandoff ');
    
      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        L_AUTH_STAT := 'B';
        DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B' || L_AUTH_STAT);
      END IF;
    
      DBG('p_acc_hand.count--->' || P_ACC_HAND.COUNT);
    
      BEGIN
        DBG('The function id is:' || GWPKS_UTIL.PKG_FUNC ||
            ' with action type as:' || GWPKS_UTIL.PKG_ACTTYPE ||
            ' with header action as:' ||
            CSPKS_REQ_GLOBAL.G_HEADER('ACTION'));
      
        IF NVL(GWPKS_UTIL.PKG_FUNC, '*') IN
           ('1300', '1350', '1301', '1320') OR
           NVL(GWPKSS_CLOSECUSTACC.G_PARENT_FUNCTIONID, '***') IN
           ('1300', '1350', '1301', '1320') THEN
        
          IF NVL(CSPKS_REQ_GLOBAL.G_HEADER('ACTION'), '*') = 'ENRICH' THEN
            DBG('Setting l_saveflag as false..');
          
            DBG('Going to set l_saveflag as FALSE');
            L_SAVEFLAG := FALSE;
          END IF;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('There is no header value set');
      END;
    
      IF GWPKS_UTIL.PKG_ACTTYPE = 'SCAUTOAUTH' THEN
        L_AUTH_STAT := 'B';
      
      END IF;
    
      IF L_SAVEFLAG THEN
        DBG('calling acpks');
      
        IF P_ACC_HAND.COUNT > 0 AND
           NVL(GWPKS_UTIL.PKG_ACTTYPE, '@@') <> 'SKIP' THEN
        
          DBG('pkg_rtl_teller_rec.trn_ref_no-->' ||
              PKG_RTL_TELLER_REC.TRN_REF_NO);
        
          DBG(' gwpks_util.g_firststepdone BEFORE ACCTNG-->' ||
              GWPKS_UTIL.G_FIRSTSTEPDONE);
          DBG('gwpks_util.g_twostepprocess BEFORE ACCTNG-->' ||
              GWPKS_UTIL.G_TWOSTEPPROCESS);
        
          IF NVL(GWPKS_UTIL.PKG_ACTTYPE, '@@') = 'ENRICH' AND
             NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' THEN
          
            L_PROCESS_ACCOUTING := FALSE;
          
          END IF;
        
          IF (NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' OR
             NVL(GWPKS_UTIL.PKG_FUNC, '***') = 'SCTT') AND
            
             NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
             NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'N' AND
             NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' THEN
            L_PROCESS_ACCOUTING := FALSE;
          END IF;
        
          L_ARC_ROW_BEFORE_ENT := PKG_ARC_ROW;
          DBG('ENTITY RT ----> Before entity Code Charge1 is l_arc_row_before_ent.cod_chg_amt ' ||
              L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT);
          DBG('ENTITY RT ----> Before entity Code Charge2 is l_arc_row_before_ent.cod_chg_amt1 ' ||
              L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT1);
          DBG('ENTITY RT ----> Before entity Code Charge3 is l_arc_row_before_ent.cod_chg_amt2 ' ||
              L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT2);
          DBG('ENTITY RT ----> Before entity Code Charge4 is l_arc_row_before_ent.cod_chg_amt3 ' ||
              L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT3);
          DBG('ENTITY RT ----> Before entity Code Charge5 is l_arc_row_before_ent.cod_chg_amt4 ' ||
              L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT4);
        
          IF (REPLACE(GWPKS_UTIL.PKG_CHG_DETS, '~', NULL) IS NOT NULL) THEN
          
            WHILE NVL(CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                              L_TOT_CHARGES,
                                              '~'),
                      ' ') <> 'EOPL' LOOP
              L_TOT_CHARGES := L_TOT_CHARGES + 1;
            END LOOP;
            L_TOT_CHARGES := L_TOT_CHARGES - 1;
            DBG('l_tot_charges IS ' || L_TOT_CHARGES);
          
            IF L_TOT_CHARGES > 1 THEN
              L_AMT_1 := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                 2,
                                                 '~');
            END IF;
          
            IF L_TOT_CHARGES > 3 THEN
              L_AMT_2 := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                 4,
                                                 '~');
            END IF;
          
            IF L_TOT_CHARGES > 5 THEN
              L_AMT_3 := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                 6,
                                                 '~');
            END IF;
          
            IF L_TOT_CHARGES > 7 THEN
              L_AMT_4 := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                 8,
                                                 '~');
            END IF;
          
            IF L_TOT_CHARGES > 9 THEN
              L_AMT_5 := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                 10,
                                                 '~');
            END IF;
          
            IF PKG_ARC_ROW.COD_BASIS = 6 AND
               PKG_RTL_TELLER_REC.WAIVER = 'N' AND L_AMT_1 = 0.00 THEN
              L_EXECUTE1 := TRUE;
              DBG('l_execute1 is True');
            END IF;
          
            IF PKG_ARC_ROW.COD_BASIS1 = 6 AND
               PKG_RTL_TELLER_REC.WAIVER1 = 'N' AND L_AMT_2 = 0.00 THEN
              L_EXECUTE2 := TRUE;
              DBG('l_execute2 is True');
            END IF;
          
            IF PKG_ARC_ROW.COD_BASIS2 = 6 AND
               PKG_RTL_TELLER_REC.WAIVER2 = 'N' AND L_AMT_3 = 0.00 THEN
              L_EXECUTE3 := TRUE;
              DBG('l_execute3 is True');
            END IF;
          
            IF PKG_ARC_ROW.COD_BASIS3 = 6 AND
               PKG_RTL_TELLER_REC.WAIVER3 = 'N' AND L_AMT_4 = 0.00 THEN
              L_EXECUTE4 := TRUE;
              DBG('l_execute4 is True');
            END IF;
          
            IF PKG_ARC_ROW.COD_BASIS4 = 6 AND
               PKG_RTL_TELLER_REC.WAIVER4 = 'N' AND L_AMT_5 = 0.00 THEN
              L_EXECUTE5 := TRUE;
              DBG('l_execute5 is True');
            END IF;
          END IF;
        
          DBG('ENTITY RT ----> Charge 1 From the Screen is --> l_amt_1 ' ||
              L_AMT_1);
          DBG('ENTITY RT ----> Charge 2 From the Screen is --> l_amt_2 ' ||
              L_AMT_2);
          DBG('ENTITY RT ----> Charge 3 From the Screen is --> l_amt_3 ' ||
              L_AMT_3);
          DBG('ENTITY RT ----> Charge 4 From the Screen is --> l_amt_4 ' ||
              L_AMT_4);
          DBG('ENTITY RT ----> Charge 5 From the Screen is --> l_amt_5 ' ||
              L_AMT_5);
        
          BEGIN
            SELECT COUNT(*) INTO L_PROCEED FROM STTM_CUST_RESTR_CODES;
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('exception while fetching data from sttm_cust_restr_codes');
              RETURN FALSE;
          END;
          DBG('The package function is:' || GWPKS_UTIL.PKG_FUNC);
        
          IF NVL(GWPKS_UTIL.PKG_FUNC, '*.*') = '1317' OR
             ICPKS_FCJ_ICDREDMN.G_FROMREDM THEN
            DBG('The call is for TD Redemption');
            L_TD_REDEMPTION_CALL := TRUE;
          END IF;
          IF NOT L_TD_REDEMPTION_CALL THEN
            DBG('Customer Code restriction API to be called');
          
            IF L_PROCEED > 0
              
               AND G_CLOSURE_CHARGE = 'N' THEN
            
              DBG('****************TOTAL CHARGE ENTRIES COUNT IS ' ||
                  P_ACC_HAND.COUNT);
            
              BEGIN
                SELECT AC_OR_GL
                  INTO L_ACC_TYPE_1
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_ACC_HAND(1).AC_NO
                   AND BRANCH_CODE = P_ACC_HAND(1).AC_BRANCH;
              EXCEPTION
              
                WHEN NO_DATA_FOUND THEN
                  DBG('NO DATA FOUND HENCE SETTTING ACCOUNT TYPE AS GL');
                  L_ACC_TYPE_1 := 'G';
                
                WHEN OTHERS THEN
                  DBG('Error while checking whether first accounting entry is account or GL');
              END;
            
              BEGIN
                SELECT AC_OR_GL
                  INTO L_ACC_TYPE_2
                  FROM STTB_ACCOUNT
                 WHERE AC_GL_NO = P_ACC_HAND(2).AC_NO
                   AND BRANCH_CODE = P_ACC_HAND(2).AC_BRANCH;
              EXCEPTION
              
                WHEN NO_DATA_FOUND THEN
                  DBG('NO DATA FOUND HENCE SETTTING ACCOUNT2 TYPE AS GL');
                  L_ACC_TYPE_2 := 'G';
                
                WHEN OTHERS THEN
                  DBG('Error while checking whether second accounting entry is account or GL');
              END;
            
              DBG('First accounting entry is ' || L_ACC_TYPE_1);
              DBG('Second accounting entry is ' || L_ACC_TYPE_2);
            
              IF PKG_RTL_TELLER_REC.BRANCH_CODE <>
                 PKG_RTL_TELLER_REC.TXN_BRANCH THEN
                DBG('This is Interbranch Transaction assiging the val Y');
                L_IB_FLAG := 'Y';
              ELSE
                DBG('This is NOT IB Transaction assiging the val N');
                L_IB_FLAG := 'N';
              END IF;
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                L_FN_CALL_ID      := 6;
              
                L_TB_CLUSTER_DATA('l_ib_flag') := L_IB_FLAG;
              
                DBG('Calling depks_rtl_teller_cluster.fn_derive_neg_rate....');
                IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                                        PKG_ARC_ROW,
                                                        PKG_LCY,
                                                        G_TXNAMT_FLAG,
                                                        G_OFSAMT_FLAG,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM) THEN
                  DBG('Failed in depks_rtl_teller_cluster.fn_save:::: ' ||
                      P_ERR_CODE);
                  RETURN FALSE;
                END IF;
              
                IF L_TB_CLUSTER_DATA.EXISTS('l_ib_flag') THEN
                  L_IB_FLAG := L_TB_CLUSTER_DATA('l_ib_flag');
                END IF;
              
              END IF;
            
              IF L_ACC_TYPE_1 = 'A' THEN
              
                DBG('**************Checking limit on first accounting entry ******');
                DBG('First accounting entry is of account type');
                DBG('Account number' || P_ACC_HAND(1).AC_NO);
              
                L_SUM   := NVL(P_ACC_HAND(1).FCY_AMOUNT,
                               P_ACC_HAND(1).LCY_AMOUNT);
                LEG_IND := P_ACC_HAND(1).DRCR_IND;
              
                P_DB_LEG_CCY := P_ACC_HAND(1).AC_CCY;
                P_CR_LEG_CCY := P_ACC_HAND(2).AC_CCY;
              
                IF P_ACC_HAND.COUNT > 3 THEN
                  FOR COUNT_LOOP IN 3 .. P_ACC_HAND.COUNT LOOP
                  
                    DBG('ROW NUMBER IN ATCBS_HANDOFF IS ' || COUNT_LOOP);
                  
                    DBG('CHARGE row ' || COUNT_LOOP ||
                        ' in handoff is --->' ||
                        NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                            P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT));
                    DBG('Charge account ' || COUNT_LOOP ||
                        ' in handoff is ---> ' || P_ACC_HAND(COUNT_LOOP)
                        .AC_NO);
                    DBG('Debit or credit indicator ' || COUNT_LOOP ||
                        'is --->' || P_ACC_HAND(COUNT_LOOP).DRCR_IND);
                  
                    IF P_ACC_HAND(1).AC_NO = P_ACC_HAND(COUNT_LOOP).AC_NO THEN
                      DBG('CHARGE ACCOUNT MATCHES WITH MAIN ACCOUNT');
                    
                      IF COUNT_LOOP = 3 OR COUNT_LOOP = 4 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS = 6 THEN
                          DBG('Entity is given as basis in arc maintenace first charge tab');
                          DBG('Entity name--->' || PKG_ARC_ROW.ENTITY_NAME);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(1)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 5 OR COUNT_LOOP = 6 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS1 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace second charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME1);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(1)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 7 OR COUNT_LOOP = 8 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS2 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace third charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME2);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(1)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 9 OR COUNT_LOOP = 10 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS3 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace fourth charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME3);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(1)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 11 OR COUNT_LOOP = 12 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS4 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace fourth charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME3);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(1)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    END IF;
                  END LOOP;
                END IF;
              
                DBG('CALCULATION OF CHARGES TO BE DEDUCTED FROM FIRST CUSTOMER IS DONE');
                DBG('TOTAL CHARGES FOR FIRST CUSTOMER' || L_SUM);
                DBG('****************************************************');
                DBG('TRANSACTION AMOUNT IS ' ||
                    PKG_RTL_TELLER_REC.TXN_AMOUNT);
                DBG('pkg_rtl_teller_rec.trn_ref_no' ||
                    PKG_RTL_TELLER_REC.TRN_REF_NO);
                DBG('pkg_rtl_teller_rec.product_code' ||
                    PKG_RTL_TELLER_REC.PRODUCT_CODE);
                DBG('pkg_rtl_teller_rec.branch_code' ||
                    PKG_RTL_TELLER_REC.BRANCH_CODE);
                DBG('pkg_rtl_teller_rec.scode' || PKG_RTL_TELLER_REC.SCODE);
                DBG('pkg_rtl_teller_rec.txn_acc' ||
                    PKG_RTL_TELLER_REC.TXN_ACC);
                DBG('pkg_rtl_teller_rec.txn_ccy' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
                DBG('pkg_rtl_teller_rec.ofs_ccy' ||
                    PKG_RTL_TELLER_REC.OFS_CCY);
                DBG('pkg_rtl_teller_rec.txn_amount' ||
                    PKG_RTL_TELLER_REC.TXN_AMOUNT);
                DBG('pkg_rtl_teller_rec.tot_chg_in_tcy' ||
                    PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
                DBG('pkg_rtl_teller_rec.trn_dt' ||
                    PKG_RTL_TELLER_REC.TRN_DT);
                DBG('credit leg currency' || P_CR_LEG_CCY);
                DBG('debit leg currency' || P_DB_LEG_CCY);
                DBG('TOTAL CHARGE TO BE PASSED INTO API IS' || L_SUM);
                DBG('****************************************************');
              
                IF NOT FN_CHECK_CUST_LIMIT(V_TBL_RESTR,
                                           P_ACC_HAND   (1).AC_NO,
                                           P_ACC_HAND   (1).AC_BRANCH,
                                           L_CUS_ERRCODE,
                                           L_ERR_PARAM,
                                           L_SUM,
                                           LEG_IND,
                                           'L') THEN
                  DBG('Called fn_check_cust_limit ');
                
                ELSE
                  DBG('came out of fn_check_limit');
                  DBG('OUTPUT OF CUSTOMER LIMIT API stpks_cust_rest_util_track');
                  DBG('Total number of restriction codes maintained on the customer is' ||
                      V_TBL_RESTR.COUNT);
                
                  IF V_TBL_RESTR.COUNT > 0 THEN
                    L_COUNT_REST     := V_TBL_RESTR.COUNT;
                    L_TOTAL_REST_COD := L_COUNT_REST;
                    DBG('Picking the restriction code that has maximum restriction amount' ||
                        V_TBL_RESTR.COUNT);
                    DBG('Copying values of v_tbl_Restr into temporary variable to handle if both accounts have restriction code maintenace');
                  
                    FOR COUNT_LOOP IN V_TBL_RESTR.FIRST .. V_TBL_RESTR.LAST LOOP
                    
                      V_TBL_RESTR_BOTH_ACC(COUNT_LOOP).RESTR_CODE := V_TBL_RESTR(COUNT_LOOP)
                                                                     .RESTR_CODE;
                      V_TBL_RESTR_BOTH_ACC(COUNT_LOOP).RESTR_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                    .RESTR_AMT;
                      V_TBL_RESTR_BOTH_ACC(COUNT_LOOP).RESTR_CCY := V_TBL_RESTR(COUNT_LOOP)
                                                                    .RESTR_CCY;
                      V_TBL_RESTR_BOTH_ACC(COUNT_LOOP).CURR_UTILIZED_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                            .CURR_UTILIZED_AMT;
                    
                    END LOOP;
                  
                    L_RSC_INDEX := V_TBL_RESTR.COUNT;
                    DBG('Final Index is ---->' || L_RSC_INDEX);
                    DBG('Final set of restiction code paramters for charges calculation are as follows---->');
                    DBG('Restriction code ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CODE);
                    DBG('Restriction amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_AMT);
                    DBG('Restriction currency ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CCY);
                    DBG('Current utilized amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .CURR_UTILIZED_AMT);
                  END IF;
                
                END IF;
              
                IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
                  DBG('Account Number NOT NULL and the value is ===> ' ||
                      PKG_RTL_TELLER_REC.TXN_ACC);
                  L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
                ELSE
                  L_TXN_AC_NO := NULL;
                END IF;
              
                IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
                  DBG('Branch is NOT NULL and the value is ===> ' ||
                      PKG_RTL_TELLER_REC.TXN_BRANCH);
                  L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                END IF;
              
                IF (GWPKS_UTIL.PKG_CHG_DETS IS NULL) OR
                   (L_EXECUTE1 = TRUE OR L_EXECUTE2 = TRUE OR
                   L_EXECUTE3 = TRUE OR L_EXECUTE4 = TRUE OR
                   L_EXECUTE5 = TRUE) THEN
                  IF PKG_ARC_ROW.COD_BASIS4 = 6 OR
                     PKG_ARC_ROW.COD_BASIS3 = 6 OR
                     PKG_ARC_ROW.COD_BASIS2 = 6 OR
                     PKG_ARC_ROW.COD_BASIS1 = 6 OR
                     PKG_ARC_ROW.COD_BASIS = 6 THEN
                    IF L_ACC_TYPE_1 = 'A' AND L_ACC_TYPE_2 != 'A' THEN
                      IF V_TBL_RESTR.COUNT > 0 THEN
                        IF NOT FN_GET_AC_ROW(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                             PKG_RTL_TELLER_REC.REL_CUSTOMER,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             L_IB_FLAG,
                                             PKG_ARC_ROW,
                                             P_ERR_CODE,
                                             L_ERR_PARAM,
                                             L_TXN_AC_NO,
                                             L_TXN_BRN,
                                             
                                             V_TBL_RESTR) THEN
                          DBG('ENTERED');
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                END IF;
              ELSE
                DBG(' TRANSACTION ACCOUNT IS OF GL TYPE');
              END IF;
            
              IF L_ACC_TYPE_2 = 'A' THEN
              
                DBG('**************Checking limit on second accounting entry ******');
                DBG('second accounting entry is of account type');
                DBG('Account number' || P_ACC_HAND(2).AC_NO);
              
                L_SUM   := NVL(P_ACC_HAND(2).FCY_AMOUNT,
                               P_ACC_HAND(2).LCY_AMOUNT);
                LEG_IND := P_ACC_HAND(2).DRCR_IND;
              
                P_DB_LEG_CCY := P_ACC_HAND(1).AC_CCY;
                P_CR_LEG_CCY := P_ACC_HAND(2).AC_CCY;
              
                IF P_ACC_HAND.COUNT > 3 THEN
                  FOR COUNT_LOOP IN 3 .. P_ACC_HAND.COUNT LOOP
                  
                    DBG('ROW NUMBER IN ATCBS_HANDOFF IS ' || COUNT_LOOP);
                  
                    DBG('CHARGE row ' || COUNT_LOOP ||
                        ' in handoff is --->' ||
                        NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                            P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT));
                    DBG('Charge account ' || COUNT_LOOP ||
                        ' in handoff is ---> ' || P_ACC_HAND(COUNT_LOOP)
                        .AC_NO);
                    DBG('Debit or credit indicator ' || COUNT_LOOP ||
                        'is --->' || P_ACC_HAND(COUNT_LOOP).DRCR_IND);
                  
                    IF P_ACC_HAND(2).AC_NO = P_ACC_HAND(COUNT_LOOP).AC_NO THEN
                    
                      IF COUNT_LOOP = 3 OR COUNT_LOOP = 4 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS = 6 THEN
                          DBG('Entity is given as basis in arc maintenace second charge tab');
                          DBG('Entity name--->' || PKG_ARC_ROW.ENTITY_NAME);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(2)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 5 OR COUNT_LOOP = 6 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS1 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace second charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME1);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(2)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 7 OR COUNT_LOOP = 8 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS2 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace third charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME2);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(2)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 9 OR COUNT_LOOP = 10 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS3 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace fourth charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME3);
                          L_SUM := L_SUM;
                        ELSE
                        
                          IF P_ACC_HAND(2)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                      IF COUNT_LOOP = 11 OR COUNT_LOOP = 12 THEN
                      
                        IF PKG_ARC_ROW.COD_BASIS4 = 6 THEN
                          DBG('Entity is given as basis in arc maintenace fourth charge tab');
                          DBG('Entity name--->' ||
                              PKG_ARC_ROW.ENTITY_NAME3);
                          L_SUM := L_SUM;
                          IF P_ACC_HAND(2)
                           .DRCR_IND = P_ACC_HAND(COUNT_LOOP).DRCR_IND THEN
                          
                            L_SUM := L_SUM +
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are same ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          
                          ELSE
                          
                            L_SUM := L_SUM -
                                     NVL(P_ACC_HAND(COUNT_LOOP).FCY_AMOUNT,
                                         P_ACC_HAND(COUNT_LOOP).LCY_AMOUNT);
                            DBG('DR_CR INDICATOR are different ' || P_ACC_HAND(COUNT_LOOP)
                                .DRCR_IND);
                          END IF;
                        
                        END IF;
                      
                      END IF;
                    
                    END IF;
                  END LOOP;
                END IF;
              
                DBG('CALCULATION OF CHARGES TO BE DEDUCTED FROM second CUSTOMER IS DONE');
                DBG('TOTAL CHARGES FOR second CUSTOMER' || L_SUM);
                DBG('****************************************************');
                DBG('TRANSACTION AMOUNT IS ' ||
                    PKG_RTL_TELLER_REC.TXN_AMOUNT);
                DBG('pkg_rtl_teller_rec.trn_ref_no' ||
                    PKG_RTL_TELLER_REC.TRN_REF_NO);
                DBG('pkg_rtl_teller_rec.product_code' ||
                    PKG_RTL_TELLER_REC.PRODUCT_CODE);
                DBG('pkg_rtl_teller_rec.branch_code' ||
                    PKG_RTL_TELLER_REC.BRANCH_CODE);
                DBG('pkg_rtl_teller_rec.scode' || PKG_RTL_TELLER_REC.SCODE);
                DBG('pkg_rtl_teller_rec.txn_acc' ||
                    PKG_RTL_TELLER_REC.TXN_ACC);
                DBG('pkg_rtl_teller_rec.txn_ccy' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
                DBG('pkg_rtl_teller_rec.ofs_ccy' ||
                    PKG_RTL_TELLER_REC.OFS_CCY);
                DBG('pkg_rtl_teller_rec.txn_amount' ||
                    PKG_RTL_TELLER_REC.TXN_AMOUNT);
                DBG('pkg_rtl_teller_rec.tot_chg_in_tcy' ||
                    PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
                DBG('pkg_rtl_teller_rec.trn_dt' ||
                    PKG_RTL_TELLER_REC.TRN_DT);
                DBG('TOTAL CHARGE TO BE PASSED INTO API IS' || L_SUM);
                DBG('****************************************************');
              
                IF NOT FN_CHECK_CUST_LIMIT(V_TBL_RESTR,
                                           P_ACC_HAND   (2).AC_NO,
                                           P_ACC_HAND   (2).AC_BRANCH,
                                           L_CUS_ERRCODE,
                                           L_ERR_PARAM,
                                           L_SUM,
                                           LEG_IND,
                                           'L') THEN
                  DBG('Called fn_check_cust_limit ');
                
                ELSE
                  DBG('came out of fn_check_limit');
                  DBG('OUTPUT OF CUSTOMER LIMIT API stpks_cust_rest_util_track');
                  DBG('Total number of restriction codes maintained on the customer is' ||
                      V_TBL_RESTR.COUNT);
                  IF V_TBL_RESTR.COUNT > 0 THEN
                    L_COUNT_REST := V_TBL_RESTR.COUNT;
                    DBG('Picking the restriction code that has maximum restriction amount' ||
                        V_TBL_RESTR.COUNT);
                    DBG('Copying values of v_tbl_Restr into temporary variable to handle if both accounts have restriction code maintenace');
                  
                    FOR COUNT_LOOP IN V_TBL_RESTR.FIRST .. V_TBL_RESTR.LAST LOOP
                      L_TOTAL_RES := L_TOTAL_REST_COD + COUNT_LOOP;
                      DBG('TOTAL RESTRICTION CODES TILL THIS POINT APPENDED ARE ' ||
                          L_TOTAL_RES);
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_CODE := V_TBL_RESTR(COUNT_LOOP)
                                                                      .RESTR_CODE;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                     .RESTR_AMT;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_CCY := V_TBL_RESTR(COUNT_LOOP)
                                                                     .RESTR_CCY;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).CURR_UTILIZED_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                             .CURR_UTILIZED_AMT;
                    
                    END LOOP;
                    L_RSC_INDEX := V_TBL_RESTR.COUNT;
                    DBG('Final Index is ---->' || L_RSC_INDEX);
                    DBG('Final set of restiction code paramters for charges calculation are as follows---->');
                    DBG('Restriction code ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CODE);
                    DBG('Restriction amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_AMT);
                    DBG('Restriction currency ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CCY);
                    DBG('Current utilized amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .CURR_UTILIZED_AMT);
                  END IF;
                
                END IF;
              
                IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
                  DBG('Account Number NOT NULL and the value is ===> ' ||
                      PKG_RTL_TELLER_REC.TXN_ACC);
                  L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
                ELSE
                  L_TXN_AC_NO := NULL;
                END IF;
              
                IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
                  DBG('Branch is NOT NULL and the value is ===> ' ||
                      PKG_RTL_TELLER_REC.TXN_BRANCH);
                  L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                END IF;
              
                IF (GWPKS_UTIL.PKG_CHG_DETS IS NULL) OR
                   (L_EXECUTE1 = TRUE OR L_EXECUTE2 = TRUE OR
                   L_EXECUTE3 = TRUE OR L_EXECUTE4 = TRUE OR
                   L_EXECUTE5 = TRUE) THEN
                  IF PKG_ARC_ROW.COD_BASIS4 = 6 OR
                     PKG_ARC_ROW.COD_BASIS3 = 6 OR
                     PKG_ARC_ROW.COD_BASIS2 = 6 OR
                     PKG_ARC_ROW.COD_BASIS1 = 6 OR
                     PKG_ARC_ROW.COD_BASIS = 6 THEN
                    IF L_ACC_TYPE_1 != 'A' AND L_ACC_TYPE_2 = 'A' THEN
                      IF V_TBL_RESTR.COUNT > 0 THEN
                        IF NOT FN_GET_AC_ROW(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                             PKG_RTL_TELLER_REC.REL_CUSTOMER,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             L_IB_FLAG,
                                             PKG_ARC_ROW,
                                             P_ERR_CODE,
                                             L_ERR_PARAM,
                                             L_TXN_AC_NO,
                                             L_TXN_BRN,
                                             
                                             V_TBL_RESTR
                                             
                                             ) THEN
                          DBG('ENTERED');
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                END IF;
              
              ELSE
                DBG('ACCOUNT IS OF GL TYPE');
              END IF;
            
              DBG('calling for cust limit check in case f FX sale.....');
              IF NVL(GWPKS_UTIL.PKG_FUNC, '***') = '8203' AND
                 PKG_RTL_TELLER_REC.REL_CUSTOMER IS NOT NULL THEN
                DBG('GOING TO CALL THE fn_check_cust_limit.....');
              
                LEG_IND      := 'C';
                P_DB_LEG_CCY := P_ACC_HAND(1).AC_CCY;
                P_CR_LEG_CCY := P_ACC_HAND(2).AC_CCY;
                DBG('leg_ind.....' || LEG_IND);
                DBG('p_db_leg_ccy.....' || P_DB_LEG_CCY);
                DBG('p_cr_leg_ccy.....' || P_CR_LEG_CCY);
              
                IF NOT FN_CHECK_CUST_LIMIT(V_TBL_RESTR,
                                           NULL,
                                           P_ACC_HAND(2).AC_BRANCH,
                                           L_CUS_ERRCODE,
                                           L_ERR_PARAM,
                                           L_SUM,
                                           LEG_IND,
                                           'L') THEN
                  DBG('Called fn_check_cust_limit ');
                
                ELSE
                  DBG('came out of fn_check_limit');
                  DBG('OUTPUT OF CUSTOMER LIMIT API stpks_cust_rest_util_track');
                  DBG('Total number of restriction codes maintained on the customer is' ||
                      V_TBL_RESTR.COUNT);
                  IF V_TBL_RESTR.COUNT > 0 THEN
                    L_COUNT_REST := V_TBL_RESTR.COUNT;
                    DBG('Picking the restriction code that has maximum restriction amount' ||
                        V_TBL_RESTR.COUNT);
                    DBG('Copying values of v_tbl_Restr into temporary variable to handle if both accounts have restriction code maintenace');
                  
                    FOR COUNT_LOOP IN V_TBL_RESTR.FIRST .. V_TBL_RESTR.LAST LOOP
                      L_TOTAL_RES := L_TOTAL_REST_COD + COUNT_LOOP;
                      DBG('TOTAL RESTRICTION CODES TILL THIS POINT APPENDED ARE ' ||
                          L_TOTAL_RES);
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_CODE := V_TBL_RESTR(COUNT_LOOP)
                                                                      .RESTR_CODE;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                     .RESTR_AMT;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).RESTR_CCY := V_TBL_RESTR(COUNT_LOOP)
                                                                     .RESTR_CCY;
                      V_TBL_RESTR_BOTH_ACC(L_TOTAL_RES).CURR_UTILIZED_AMT := V_TBL_RESTR(COUNT_LOOP)
                                                                             .CURR_UTILIZED_AMT;
                    
                    END LOOP;
                    L_RSC_INDEX := V_TBL_RESTR.COUNT;
                    DBG('Final Index is ---->' || L_RSC_INDEX);
                    DBG('Final set of restiction code paramters for charges calculation are as follows---->');
                    DBG('Restriction code ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CODE);
                    DBG('Restriction amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_AMT);
                    DBG('Restriction currency ' || V_TBL_RESTR(L_RSC_INDEX)
                        .RESTR_CCY);
                    DBG('Current utilized amount ' || V_TBL_RESTR(L_RSC_INDEX)
                        .CURR_UTILIZED_AMT);
                  END IF;
                
                END IF;
              END IF;
            
              IF L_ACC_TYPE_1 = 'A' AND L_ACC_TYPE_2 = 'A' THEN
              
                DBG('BOTH ARE ACCOUNTS AND TOTAL RESTRICTION CODE COUNT IS ' ||
                    V_TBL_RESTR_BOTH_ACC.COUNT);
                IF V_TBL_RESTR_BOTH_ACC.COUNT > 0 THEN
                
                  L_RSC_INDEX := V_TBL_RESTR_BOTH_ACC.COUNT;
                  DBG('Final Index is ---->' || L_RSC_INDEX);
                  DBG('final restriction code ' || V_TBL_RESTR_BOTH_ACC(L_RSC_INDEX)
                      .RESTR_CODE);
                  DBG('final restriction amount ' || V_TBL_RESTR_BOTH_ACC(L_RSC_INDEX)
                      .RESTR_AMT);
                  DBG('final restriction currency ' || V_TBL_RESTR_BOTH_ACC(L_RSC_INDEX)
                      .RESTR_CCY);
                  DBG('final current utilized amount is  ' || V_TBL_RESTR_BOTH_ACC(L_RSC_INDEX)
                      .CURR_UTILIZED_AMT);
                
                  IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
                    DBG('Account Number NOT NULL and the value is ===> ' ||
                        PKG_RTL_TELLER_REC.TXN_ACC);
                    L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
                  ELSE
                    L_TXN_AC_NO := NULL;
                  END IF;
                
                  IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
                    DBG('Branch is NOT NULL and the value is ===> ' ||
                        PKG_RTL_TELLER_REC.TXN_BRANCH);
                    L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                  END IF;
                
                END IF;
              
                IF (GWPKS_UTIL.PKG_CHG_DETS IS NULL) OR
                   (L_EXECUTE1 = TRUE OR L_EXECUTE2 = TRUE OR
                   L_EXECUTE3 = TRUE OR L_EXECUTE4 = TRUE OR
                   L_EXECUTE5 = TRUE) THEN
                  IF PKG_ARC_ROW.COD_BASIS4 = 6 OR
                     PKG_ARC_ROW.COD_BASIS3 = 6 OR
                     PKG_ARC_ROW.COD_BASIS2 = 6 OR
                     PKG_ARC_ROW.COD_BASIS1 = 6 OR
                     PKG_ARC_ROW.COD_BASIS = 6 THEN
                  
                    IF V_TBL_RESTR_BOTH_ACC.COUNT > 0 THEN
                      IF NOT FN_GET_AC_ROW(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                           L_REL_CUS,
                                           PKG_RTL_TELLER_REC.TXN_CCY,
                                           L_IB_FLAG,
                                           PKG_ARC_ROW,
                                           P_ERR_CODE,
                                           L_ERR_PARAM,
                                           L_TXN_AC_NO,
                                           L_TXN_BRN,
                                           
                                           V_TBL_RESTR_BOTH_ACC) THEN
                        DBG('ENTERED');
                      END IF;
                    END IF;
                  END IF;
                END IF;
              END IF;
            
              DBG('Handoff Before Modification of Charges based on Entity');
              PR_PRINT_ACCTNG_TABLE(P_ACC_HAND);
            
              IF PKG_ARC_ROW.COD_BASIS = 6 THEN
                DBG('ENTITY RT ----> Charge 1 is  Entity Based charge. ');
                IF GWPKS_UTIL.PKG_CHG_DETS IS NULL OR L_EXECUTE1 = TRUE THEN
                  DBG('ENTITY RT ----> Execute Entity Based code for Charge1 ');
                  IF CSPKS_ARC.G_RSC_MATCH1 = TRUE THEN
                    DBG('ENTITY RT ----> Restriction code match found for Charge 1.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT ||
                        ' With Charge ' || PKG_ARC_ROW.COD_CHG_AMT);
                  
                    L_AMT1               := NULL;
                    L_ACC_CHG_EXCH_RATE1 := NULL;
                    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                 PKG_ARC_ROW.COD_CHG_CCY,
                                                 PKG_LCY,
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE,
                                                     'STANDARD'),
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE,
                                                     'M'),
                                                 PKG_ARC_ROW.COD_CHG_AMT,
                                                 'Y',
                                                 L_AMT1,
                                                 L_ACC_CHG_EXCH_RATE1,
                                                 P_ERR_CODE) THEN
                      DBG('Bombed with amt1_to_amt2 b/w ' ||
                          PKG_ARC_ROW.COD_CHG_AMT || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY);
                    END IF;
                    DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT ||
                        ' and ' || PKG_ARC_ROW.COD_CHG_CCY);
                    DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                        PKG_LCY);
                  
                    P_ACC_HAND(3).LCY_AMOUNT := L_AMT1;
                    P_ACC_HAND(4).LCY_AMOUNT := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_AMT := PKG_ARC_ROW.COD_CHG_AMT;
                  
                    IF P_ACC_HAND(3).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(3).FCY_AMOUNT := PKG_ARC_ROW.COD_CHG_AMT;
                    END IF;
                  
                    IF P_ACC_HAND(4).FCY_AMOUNT IS NOT NULL THEN
                      L_AMT1               := NULL;
                      L_ACC_CHG_EXCH_RATE1 := NULL;
                      IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                   PKG_ARC_ROW.COD_CHG_CCY,
                                                   P_ACC_HAND(4).AC_CCY,
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE,
                                                       'STANDARD'),
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE,
                                                       'M'),
                                                   PKG_ARC_ROW.COD_CHG_AMT,
                                                   'Y',
                                                   L_AMT1,
                                                   L_ACC_CHG_EXCH_RATE1,
                                                   P_ERR_CODE) THEN
                        DBG('Bombed with amt1_to_amt2 b/w ' ||
                            PKG_ARC_ROW.COD_CHG_AMT || ' and ' ||
                            PKG_ARC_ROW.COD_CHG_CCY);
                      
                      END IF;
                      DBG('Values Went in are  ' ||
                          PKG_ARC_ROW.COD_CHG_AMT || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY);
                      DBG('Values Came out where ' || L_AMT1 || ' and ' || P_ACC_HAND(4)
                          .AC_CCY);
                    
                      P_ACC_HAND(4).FCY_AMOUNT := L_AMT1;
                    
                    END IF;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_ACY := NVL(P_ACC_HAND(4)
                                                         .FCY_AMOUNT,
                                                         P_ACC_HAND(4)
                                                         .LCY_AMOUNT);
                  
                  ELSE
                    DBG('ENTITY RT ----> Restriction code match Not  for Charge1.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT ||
                        ' With Charge 0');
                  
                    PKG_ARC_ROW.COD_CHG_AMT := 0;
                    PKG_RTL_TELLER_REC.CHG_AMT := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_ACY := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY := 0;
                    P_ACC_HAND(3).LCY_AMOUNT := 0;
                    P_ACC_HAND(4).LCY_AMOUNT := 0;
                  
                    P_ACC_HAND(3).AC_CCY := PKG_LCY;
                    P_ACC_HAND(4).AC_CCY := PKG_LCY;
                  
                    IF P_ACC_HAND(3).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(3).FCY_AMOUNT := 0;
                    END IF;
                  
                    IF P_ACC_HAND(4).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(4).FCY_AMOUNT := 0;
                    END IF;
                  
                  END IF;
                
                ELSE
                  PKG_ARC_ROW.COD_CHG_AMT := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT;
                  DBG('ENTITY RT ----> Charge 1 is  Entity Based charge.But it is not executed again.Charge is  ' ||
                      PKG_ARC_ROW.COD_CHG_AMT);
                END IF;
              ELSE
                DBG('ENTITY RT ----> Charge 1 is not Entity Based charge. ');
                PKG_ARC_ROW.COD_CHG_AMT := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT;
              
              END IF;
            
              IF PKG_ARC_ROW.COD_BASIS1 = 6 THEN
                DBG('ENTITY RT ----> Charge 2 is  Entity Based charge. ');
              
                IF GWPKS_UTIL.PKG_CHG_DETS IS NULL OR L_EXECUTE2 = TRUE THEN
                  DBG('ENTITY RT ----> Execute Entity Based code for Charge2 ');
                
                  IF CSPKS_ARC.G_RSC_MATCH2 = TRUE THEN
                    DBG('ENTITY RT ----> Restriction code match found for Charge 2.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT1 ||
                        ' With Charge ' || PKG_ARC_ROW.COD_CHG_AMT1);
                  
                    L_AMT1               := NULL;
                    L_ACC_CHG_EXCH_RATE1 := NULL;
                  
                    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                 PKG_ARC_ROW.COD_CHG_CCY1,
                                                 PKG_LCY,
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE1,
                                                     'STANDARD'),
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE1,
                                                     'M'),
                                                 PKG_ARC_ROW.COD_CHG_AMT1,
                                                 'Y',
                                                 L_AMT1,
                                                 L_ACC_CHG_EXCH_RATE1,
                                                 P_ERR_CODE) THEN
                      DBG('Bombed with amt1_to_amt2 b/w ' ||
                          PKG_ARC_ROW.COD_CHG_AMT1 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY1);
                    END IF;
                    DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT1 ||
                        ' and ' || PKG_ARC_ROW.COD_CHG_CCY1);
                    DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                        PKG_LCY);
                  
                    P_ACC_HAND(5).LCY_AMOUNT := L_AMT1;
                    P_ACC_HAND(6).LCY_AMOUNT := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_1 := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_AMT_1 := PKG_ARC_ROW.COD_CHG_AMT1;
                  
                    IF P_ACC_HAND(5).FCY_AMOUNT IS NOT NULL THEN
                    
                      P_ACC_HAND(5).FCY_AMOUNT := PKG_ARC_ROW.COD_CHG_AMT1;
                    END IF;
                  
                    IF P_ACC_HAND(6).FCY_AMOUNT IS NOT NULL THEN
                      L_AMT1               := NULL;
                      L_ACC_CHG_EXCH_RATE1 := NULL;
                      IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                   PKG_ARC_ROW.COD_CHG_CCY1,
                                                   P_ACC_HAND(6).AC_CCY,
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE1,
                                                       'STANDARD'),
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE1,
                                                       'M'),
                                                   PKG_ARC_ROW.COD_CHG_AMT1,
                                                   'Y',
                                                   L_AMT1,
                                                   L_ACC_CHG_EXCH_RATE1,
                                                   P_ERR_CODE) THEN
                        DBG('Bombed with amt1_to_amt2 b/w ' ||
                            PKG_ARC_ROW.COD_CHG_AMT1 || ' and ' ||
                            PKG_ARC_ROW.COD_CHG_CCY1);
                      END IF;
                      DBG('Values Went in are  ' ||
                          PKG_ARC_ROW.COD_CHG_AMT1 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY1);
                      DBG('Values Came out where ' || L_AMT1 || ' and ' || P_ACC_HAND(6)
                          .AC_CCY);
                    
                      P_ACC_HAND(6).FCY_AMOUNT := L_AMT1;
                    
                    END IF;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_1 := NVL(P_ACC_HAND(6)
                                                           .FCY_AMOUNT,
                                                           P_ACC_HAND(6)
                                                           .LCY_AMOUNT);
                  
                  ELSE
                    DBG('ENTITY RT ----> Restriction code match Not  for Charge2.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT1 ||
                        ' With Charge 0');
                    PKG_ARC_ROW.COD_CHG_AMT1 := 0;
                    PKG_RTL_TELLER_REC.CHG_AMT_1 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_1 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_1 := 0;
                    P_ACC_HAND(5).LCY_AMOUNT := 0;
                    P_ACC_HAND(6).LCY_AMOUNT := 0;
                  
                    P_ACC_HAND(5).AC_CCY := PKG_LCY;
                    P_ACC_HAND(6).AC_CCY := PKG_LCY;
                  
                    IF P_ACC_HAND(5).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(5).FCY_AMOUNT := 0;
                    END IF;
                  
                    IF P_ACC_HAND(6).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(6).FCY_AMOUNT := 0;
                    END IF;
                  
                  END IF;
                
                ELSE
                  PKG_ARC_ROW.COD_CHG_AMT1 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT1;
                  DBG('ENTITY RT ----> Charge 2 is  Entity Based charge.But it is not executed again.Charge is  ' ||
                      PKG_ARC_ROW.COD_CHG_AMT1);
                END IF;
              ELSE
                DBG('ENTITY RT ----> Charge 2 is not Entity Based charge. ');
                PKG_ARC_ROW.COD_CHG_AMT1 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT1;
              
              END IF;
            
              IF PKG_ARC_ROW.COD_BASIS2 = 6 THEN
                DBG('ENTITY RT ----> Charge 3 is  Entity Based charge. ');
                IF GWPKS_UTIL.PKG_CHG_DETS IS NULL OR L_EXECUTE3 = TRUE THEN
                  DBG('ENTITY RT ----> Execute Entity Based code for Charge3 ');
                  IF CSPKS_ARC.G_RSC_MATCH3 = TRUE THEN
                    DBG('ENTITY RT ----> Restriction code match found for Charge 3.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT2 ||
                        ' With Charge ' || PKG_ARC_ROW.COD_CHG_AMT2);
                  
                    L_AMT1               := NULL;
                    L_ACC_CHG_EXCH_RATE1 := NULL;
                  
                    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                 PKG_ARC_ROW.COD_CHG_CCY2,
                                                 PKG_LCY,
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE2,
                                                     'STANDARD'),
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE2,
                                                     'M'),
                                                 PKG_ARC_ROW.COD_CHG_AMT2,
                                                 'Y',
                                                 L_AMT1,
                                                 L_ACC_CHG_EXCH_RATE1,
                                                 P_ERR_CODE) THEN
                      DBG('Bombed with amt1_to_amt2 b/w ' ||
                          PKG_ARC_ROW.COD_CHG_AMT2 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY2);
                    
                    END IF;
                    DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT2 ||
                        ' and ' || PKG_ARC_ROW.COD_CHG_CCY2);
                    DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                        PKG_LCY);
                  
                    P_ACC_HAND(7).LCY_AMOUNT := L_AMT1;
                    P_ACC_HAND(8).LCY_AMOUNT := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_2 := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_AMT_2 := PKG_ARC_ROW.COD_CHG_AMT2;
                    IF P_ACC_HAND(7).FCY_AMOUNT IS NOT NULL THEN
                    
                      P_ACC_HAND(7).FCY_AMOUNT := PKG_ARC_ROW.COD_CHG_AMT2;
                    END IF;
                  
                    IF P_ACC_HAND(8).FCY_AMOUNT IS NOT NULL THEN
                      L_AMT1               := NULL;
                      L_ACC_CHG_EXCH_RATE1 := NULL;
                      IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                   PKG_ARC_ROW.COD_CHG_CCY2,
                                                   P_ACC_HAND(8).AC_CCY,
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE2,
                                                       'STANDARD'),
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE2,
                                                       'M'),
                                                   PKG_ARC_ROW.COD_CHG_AMT2,
                                                   'Y',
                                                   L_AMT1,
                                                   L_ACC_CHG_EXCH_RATE1,
                                                   P_ERR_CODE) THEN
                        DBG('Bombed with amt1_to_amt2 b/w ' ||
                            PKG_ARC_ROW.COD_CHG_AMT2 || ' and ' ||
                            PKG_ARC_ROW.COD_CHG_CCY2);
                      
                      END IF;
                      DBG('Values Went in are  ' ||
                          PKG_ARC_ROW.COD_CHG_AMT2 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY2);
                      DBG('Values Came out where ' || L_AMT1 || ' and ' || P_ACC_HAND(8)
                          .AC_CCY);
                    
                      P_ACC_HAND(8).FCY_AMOUNT := L_AMT1;
                    
                    END IF;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_2 := NVL(P_ACC_HAND(8)
                                                           .FCY_AMOUNT,
                                                           P_ACC_HAND(8)
                                                           .LCY_AMOUNT);
                  
                  ELSE
                  
                    DBG('ENTITY RT ----> Restriction code match Not  for Charge3.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT2 ||
                        ' With Charge 0');
                  
                    PKG_ARC_ROW.COD_CHG_AMT2 := 0;
                    PKG_RTL_TELLER_REC.CHG_AMT_2 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_2 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_2 := 0;
                    P_ACC_HAND(7).LCY_AMOUNT := 0;
                    P_ACC_HAND(8).LCY_AMOUNT := 0;
                  
                    P_ACC_HAND(7).AC_CCY := PKG_LCY;
                    P_ACC_HAND(8).AC_CCY := PKG_LCY;
                  
                    IF P_ACC_HAND(7).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(7).FCY_AMOUNT := 0;
                    END IF;
                  
                    IF P_ACC_HAND(8).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(8).FCY_AMOUNT := 0;
                    END IF;
                  
                  END IF;
                
                ELSE
                  PKG_ARC_ROW.COD_CHG_AMT2 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT2;
                  DBG('ENTITY RT ----> Charge 3 is  Entity Based charge.But it is not executed again.Charge is  ' ||
                      PKG_ARC_ROW.COD_CHG_AMT2);
                END IF;
              ELSE
                DBG('ENTITY RT ----> Charge 3 is not Entity Based charge. ');
                PKG_ARC_ROW.COD_CHG_AMT2 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT2;
              
              END IF;
            
              IF PKG_ARC_ROW.COD_BASIS3 = 6 THEN
                DBG('ENTITY RT ----> Charge 4 is  Entity Based charge. ');
                IF GWPKS_UTIL.PKG_CHG_DETS IS NULL OR L_EXECUTE4 = TRUE THEN
                  DBG('ENTITY RT ----> Execute Entity Based code for Charge4 ');
                  IF CSPKS_ARC.G_RSC_MATCH4 = TRUE THEN
                    DBG('ENTITY RT ----> Restriction code match found for Charge 4.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT3 ||
                        ' With Charge ' || PKG_ARC_ROW.COD_CHG_AMT3);
                  
                    L_AMT1               := NULL;
                    L_ACC_CHG_EXCH_RATE1 := NULL;
                  
                    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                 PKG_ARC_ROW.COD_CHG_CCY3,
                                                 PKG_LCY,
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE3,
                                                     'STANDARD'),
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE3,
                                                     'M'),
                                                 PKG_ARC_ROW.COD_CHG_AMT3,
                                                 'Y',
                                                 L_AMT1,
                                                 L_ACC_CHG_EXCH_RATE1,
                                                 P_ERR_CODE) THEN
                      DBG('Bombed with amt1_to_amt2 b/w ' ||
                          PKG_ARC_ROW.COD_CHG_AMT3 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY3);
                    END IF;
                    DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT3 ||
                        ' and ' || PKG_ARC_ROW.COD_CHG_CCY3);
                    DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                        PKG_LCY);
                  
                    P_ACC_HAND(9).LCY_AMOUNT := L_AMT1;
                    P_ACC_HAND(10).LCY_AMOUNT := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_3 := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_AMT_3 := PKG_ARC_ROW.COD_CHG_AMT3;
                    IF P_ACC_HAND(9).FCY_AMOUNT IS NOT NULL THEN
                    
                      P_ACC_HAND(9).FCY_AMOUNT := PKG_ARC_ROW.COD_CHG_AMT3;
                    END IF;
                  
                    IF P_ACC_HAND(10).FCY_AMOUNT IS NOT NULL THEN
                      L_AMT1               := NULL;
                      L_ACC_CHG_EXCH_RATE1 := NULL;
                      IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                   PKG_ARC_ROW.COD_CHG_CCY3,
                                                   P_ACC_HAND(10).AC_CCY,
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE3,
                                                       'STANDARD'),
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE3,
                                                       'M'),
                                                   PKG_ARC_ROW.COD_CHG_AMT3,
                                                   'Y',
                                                   L_AMT1,
                                                   L_ACC_CHG_EXCH_RATE1,
                                                   P_ERR_CODE) THEN
                        DBG('Bombed with amt1_to_amt2 b/w ' ||
                            PKG_ARC_ROW.COD_CHG_AMT3 || ' and ' ||
                            PKG_ARC_ROW.COD_CHG_CCY3);
                      
                      END IF;
                      DBG('Values Went in are  ' ||
                          PKG_ARC_ROW.COD_CHG_AMT3 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY3);
                      DBG('Values Came out where ' || L_AMT1 || ' and ' || P_ACC_HAND(10)
                          .AC_CCY);
                    
                      P_ACC_HAND(10).FCY_AMOUNT := L_AMT1;
                    
                    END IF;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_3 := NVL(P_ACC_HAND(10)
                                                           .FCY_AMOUNT,
                                                           P_ACC_HAND(10)
                                                           .LCY_AMOUNT);
                  
                  ELSE
                  
                    DBG('ENTITY RT ----> Restriction code match Not  for Charge4.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT3 ||
                        ' With Charge 0');
                  
                    PKG_ARC_ROW.COD_CHG_AMT3 := 0;
                    PKG_RTL_TELLER_REC.CHG_AMT_3 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_3 := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_3 := 0;
                    P_ACC_HAND(9).LCY_AMOUNT := 0;
                    P_ACC_HAND(10).LCY_AMOUNT := 0;
                  
                    P_ACC_HAND(9).AC_CCY := PKG_LCY;
                    P_ACC_HAND(10).AC_CCY := PKG_LCY;
                  
                    IF P_ACC_HAND(9).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(9).FCY_AMOUNT := 0;
                    END IF;
                  
                    IF P_ACC_HAND(10).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(10).FCY_AMOUNT := 0;
                    END IF;
                  
                  END IF;
                
                ELSE
                  PKG_ARC_ROW.COD_CHG_AMT3 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT3;
                  DBG('ENTITY RT ----> Charge 4 is  Entity Based charge.But it is not executed again.Charge is  ' ||
                      PKG_ARC_ROW.COD_CHG_AMT3);
                END IF;
              ELSE
                PKG_ARC_ROW.COD_CHG_AMT3 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT3;
                DBG('ENTITY RT ----> Charge 4 is not Entity Based charge. ');
              
              END IF;
            
              IF PKG_ARC_ROW.COD_BASIS4 = 6 THEN
                DBG('ENTITY RT ----> Charge 4 is  Entity Based charge. ');
                IF GWPKS_UTIL.PKG_CHG_DETS IS NULL OR L_EXECUTE5 = TRUE THEN
                  DBG('ENTITY RT ----> Execute Entity Based code for Charge5 ');
                  IF CSPKS_ARC.G_RSC_MATCH5 = TRUE THEN
                    DBG('ENTITY RT ----> Restriction code match found for Charge 5 Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT4 ||
                        ' With Charge ' || PKG_ARC_ROW.COD_CHG_AMT4);
                  
                    L_AMT1               := NULL;
                    L_ACC_CHG_EXCH_RATE1 := NULL;
                  
                    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                 PKG_ARC_ROW.COD_CHG_CCY4,
                                                 PKG_LCY,
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE4,
                                                     'STANDARD'),
                                                 NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE4,
                                                     'M'),
                                                 PKG_ARC_ROW.COD_CHG_AMT4,
                                                 'Y',
                                                 L_AMT1,
                                                 L_ACC_CHG_EXCH_RATE1,
                                                 P_ERR_CODE) THEN
                      DBG('Bombed with amt1_to_amt2 b/w ' ||
                          PKG_ARC_ROW.COD_CHG_AMT4 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY4);
                    
                    END IF;
                    DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT4 ||
                        ' and ' || PKG_ARC_ROW.COD_CHG_CCY4);
                    DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                        PKG_LCY);
                  
                    P_ACC_HAND(11).LCY_AMOUNT := L_AMT1;
                    P_ACC_HAND(12).LCY_AMOUNT := L_AMT1;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_4 := L_AMT1;
                    PKG_RTL_TELLER_REC.CHG_AMT_4    := PKG_ARC_ROW.COD_CHG_AMT4;
                    IF P_ACC_HAND(11).FCY_AMOUNT IS NOT NULL THEN
                    
                      P_ACC_HAND(11).FCY_AMOUNT := PKG_ARC_ROW.COD_CHG_AMT4;
                    END IF;
                  
                    IF P_ACC_HAND(12).FCY_AMOUNT IS NOT NULL THEN
                      L_AMT1               := NULL;
                      L_ACC_CHG_EXCH_RATE1 := NULL;
                      IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                                   PKG_ARC_ROW.COD_CHG_CCY4,
                                                   P_ACC_HAND(12).AC_CCY,
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE4,
                                                       'STANDARD'),
                                                   NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE4,
                                                       'M'),
                                                   PKG_ARC_ROW.COD_CHG_AMT4,
                                                   'Y',
                                                   L_AMT1,
                                                   L_ACC_CHG_EXCH_RATE1,
                                                   P_ERR_CODE) THEN
                        DBG('Bombed with amt1_to_amt2 b/w ' ||
                            PKG_ARC_ROW.COD_CHG_AMT4 || ' and ' ||
                            PKG_ARC_ROW.COD_CHG_CCY4);
                      
                      END IF;
                      DBG('Values Went in are  ' ||
                          PKG_ARC_ROW.COD_CHG_AMT4 || ' and ' ||
                          PKG_ARC_ROW.COD_CHG_CCY4);
                      DBG('Values Came out where ' || L_AMT1 || ' and ' || P_ACC_HAND(12)
                          .AC_CCY);
                    
                      P_ACC_HAND(12).FCY_AMOUNT := L_AMT1;
                    
                    END IF;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_4 := NVL(P_ACC_HAND(12)
                                                           .FCY_AMOUNT,
                                                           P_ACC_HAND(12)
                                                           .LCY_AMOUNT);
                  
                  ELSE
                  
                    DBG('ENTITY RT ----> Restriction code match Not  for Charge5.Hence Resetting ' ||
                        L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT4 ||
                        ' With Charge 0');
                  
                    PKG_ARC_ROW.COD_CHG_AMT4        := 0;
                    PKG_RTL_TELLER_REC.CHG_AMT_4    := 0;
                    PKG_RTL_TELLER_REC.CHG_IN_ACY_4 := 0;
                  
                    PKG_RTL_TELLER_REC.CHG_IN_LCY_4 := 0;
                    P_ACC_HAND(11).LCY_AMOUNT := 0;
                    P_ACC_HAND(12).LCY_AMOUNT := 0;
                  
                    P_ACC_HAND(11).AC_CCY := PKG_LCY;
                    P_ACC_HAND(12).AC_CCY := PKG_LCY;
                  
                    IF P_ACC_HAND(11).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(11).FCY_AMOUNT := 0;
                    END IF;
                  
                    IF P_ACC_HAND(12).FCY_AMOUNT IS NOT NULL THEN
                      P_ACC_HAND(12).FCY_AMOUNT := 0;
                    END IF;
                  
                  END IF;
                
                ELSE
                  PKG_ARC_ROW.COD_CHG_AMT4 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT4;
                  DBG('ENTITY RT ----> Charge 4 is  Entity Based charge.But it is not executed again.Charge is  ' ||
                      PKG_ARC_ROW.COD_CHG_AMT4);
                END IF;
              ELSE
                PKG_ARC_ROW.COD_CHG_AMT4 := L_ARC_ROW_BEFORE_ENT.COD_CHG_AMT4;
                DBG('ENTITY RT ----> Charge 5 is not Entity Based charge. ');
              
              END IF;
            
              DBG('ENTITY RT ----> AFTER entity Code Charge1 is pkg_arc_row.cod_chg_amt ' ||
                  PKG_ARC_ROW.COD_CHG_AMT);
              DBG('ENTITY RT ----> AFTER entity Code Charge2 is pkg_arc_row.cod_chg_amt1 ' ||
                  PKG_ARC_ROW.COD_CHG_AMT1);
              DBG('ENTITY RT ----> AFTER entity Code Charge3 is pkg_arc_row.cod_chg_amt2 ' ||
                  PKG_ARC_ROW.COD_CHG_AMT2);
              DBG('ENTITY RT ----> AFTER entity Code Charge4 is pkg_arc_row.cod_chg_amt3 ' ||
                  PKG_ARC_ROW.COD_CHG_AMT3);
              DBG('ENTITY RT ----> AFTER entity Code Charge5 is pkg_arc_row.cod_chg_amt4 ' ||
                  PKG_ARC_ROW.COD_CHG_AMT4);
            
              IF PKG_ARC_ROW.COD_BASIS4 = 6 OR PKG_ARC_ROW.COD_BASIS3 = 6 OR
                 PKG_ARC_ROW.COD_BASIS2 = 6 OR PKG_ARC_ROW.COD_BASIS1 = 6 OR
                 PKG_ARC_ROW.COD_BASIS = 6 THEN
              
                PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := 0;
              
                DBG('Modified Charges in Transaction currency');
                L_TCY1               := NULL;
                L_AMT1               := NULL;
                L_ACC_CHG_EXCH_RATE1 := NULL;
                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             PKG_ARC_ROW.COD_CHG_CCY,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE,
                                                 'STANDARD'),
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE,
                                                 'M'),
                                             PKG_ARC_ROW.COD_CHG_AMT,
                                             'Y',
                                             L_AMT1,
                                             L_ACC_CHG_EXCH_RATE1,
                                             P_ERR_CODE) THEN
                  DBG('Bombed with amt1_to_amt2 b/w ' ||
                      PKG_ARC_ROW.COD_CHG_AMT || ' and ' ||
                      PKG_ARC_ROW.COD_CHG_CCY);
                
                END IF;
                DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT ||
                    ' and ' || PKG_ARC_ROW.COD_CHG_CCY);
                DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
                L_TCY1 := L_AMT1;
              
                L_TCY2               := NULL;
                L_AMT1               := NULL;
                L_ACC_CHG_EXCH_RATE1 := NULL;
                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             PKG_ARC_ROW.COD_CHG_CCY1,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE1,
                                                 'STANDARD'),
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE1,
                                                 'M'),
                                             PKG_ARC_ROW.COD_CHG_AMT1,
                                             'Y',
                                             L_AMT1,
                                             L_ACC_CHG_EXCH_RATE1,
                                             P_ERR_CODE) THEN
                  DBG('Bombed with amt1_to_amt2 b/w ' ||
                      PKG_ARC_ROW.COD_CHG_AMT1 || ' and ' ||
                      PKG_ARC_ROW.COD_CHG_CCY1);
                END IF;
                DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT1 ||
                    ' and ' || PKG_ARC_ROW.COD_CHG_CCY1);
                DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
              
                L_TCY2 := L_AMT1;
              
                L_TCY3               := NULL;
                L_AMT1               := NULL;
                L_ACC_CHG_EXCH_RATE1 := NULL;
              
                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             PKG_ARC_ROW.COD_CHG_CCY2,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE2,
                                                 'STANDARD'),
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE2,
                                                 'M'),
                                             PKG_ARC_ROW.COD_CHG_AMT2,
                                             'Y',
                                             L_AMT1,
                                             L_ACC_CHG_EXCH_RATE1,
                                             P_ERR_CODE) THEN
                  DBG('Bombed with amt1_to_amt2 b/w ' ||
                      PKG_ARC_ROW.COD_CHG_AMT2 || ' and ' ||
                      PKG_ARC_ROW.COD_CHG_CCY2);
                
                END IF;
                DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT2 ||
                    ' and ' || PKG_ARC_ROW.COD_CHG_CCY2);
                DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
              
                L_TCY3 := L_AMT1;
              
                L_TCY4               := NULL;
                L_AMT1               := NULL;
                L_ACC_CHG_EXCH_RATE1 := NULL;
              
                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             PKG_ARC_ROW.COD_CHG_CCY3,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE3,
                                                 'STANDARD'),
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE3,
                                                 'M'),
                                             PKG_ARC_ROW.COD_CHG_AMT3,
                                             'Y',
                                             L_AMT1,
                                             L_ACC_CHG_EXCH_RATE1,
                                             P_ERR_CODE) THEN
                  DBG('Bombed with amt1_to_amt2 b/w ' ||
                      PKG_ARC_ROW.COD_CHG_AMT3 || ' and ' ||
                      PKG_ARC_ROW.COD_CHG_CCY3);
                
                END IF;
                DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT3 ||
                    ' and ' || PKG_ARC_ROW.COD_CHG_CCY3);
                DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                    PKG_RTL_TELLER_REC.TXN_CCY);
              
                L_TCY4 := L_AMT1;
              
                L_TCY5               := NULL;
                L_AMT1               := NULL;
                L_ACC_CHG_EXCH_RATE1 := NULL;
              
                IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                             PKG_ARC_ROW.COD_CHG_CCY4,
                                             PKG_RTL_TELLER_REC.TXN_CCY,
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE4,
                                                 'STANDARD'),
                                             NVL(PKG_ARC_ROW.COD_RATE_CODE_TYPE4,
                                                 'M'),
                                             PKG_ARC_ROW.COD_CHG_AMT4,
                                             'Y',
                                             L_AMT1,
                                             L_ACC_CHG_EXCH_RATE1,
                                             P_ERR_CODE) THEN
                  DBG('Bombed with amt1_to_amt2 b/w ' ||
                      PKG_ARC_ROW.COD_CHG_AMT4 || ' and ' ||
                      PKG_ARC_ROW.COD_CHG_CCY4);
                
                END IF;
                DBG('Values Went in are  ' || PKG_ARC_ROW.COD_CHG_AMT4 ||
                    ' and ' || PKG_ARC_ROW.COD_CHG_CCY4);
                DBG('Values Came out where ' || L_AMT1 || ' and ' ||
                    PKG_LCY);
              
                L_TCY5 := L_AMT1;
              
                PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := 0;
                PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := NVL(L_TCY1, 0) +
                                                     NVL(L_TCY2, 0) +
                                                     NVL(L_TCY3, 0) +
                                                     NVL(L_TCY4, 0) +
                                                     NVL(L_TCY5, 0);
              
              END IF;
            
              DBG('Total Charge in TCY IS ' ||
                  PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
              DBG('Handoff After Modification of Charges based on Entity');
              PR_PRINT_ACCTNG_TABLE(P_ACC_HAND);
            
            END IF;
          END IF;
        
          DBG('Before Call to fn_get_cashAmt ... SORUCE IS  :::    ' ||
              PKG_RTL_TELLER_REC.SCODE);
        
          DBG('gwpks_util.g_from_bean check');
        
          IF GWPKS_UTIL.G_FROM_BEAN AND
             CGPKS_CGUPLOAD.G_EXCEL_UPLOAD = FALSE
            
             AND PKG_RTL_TELLER_REC.SCODE IN ('FLEXBRANCH') THEN
            PKG_TXNLEGCASHAMT := 0;
            PKG_OFSLEGCASHAMT := 0;
            DBG('Before Call to fn_get_cashAmt ');
            IF NOT FN_GET_CASHAMT(P_ACC_HAND,
                                  L_TXNLEGCASHAMT,
                                  L_OFSLEGCASHAMT,
                                  P_ERR_CODE,
                                  P_ERR_PARAM) THEN
            
              DBG('Failed while getting   fn_get_cashAmt');
            
              RETURN FALSE;
            END IF;
            PKG_TXNLEGCASHAMT := L_TXNLEGCASHAMT;
            PKG_OFSLEGCASHAMT := L_OFSLEGCASHAMT;
          
            DBG('Finally We got pkg_txnlegcashAmt ' || PKG_TXNLEGCASHAMT);
            DBG('Finally We got pkg_ofslegcashAmt ' || PKG_OFSLEGCASHAMT);
          END IF;
        
          FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
            IF P_ACC_HAND.EXISTS(I) THEN
              L_HANDOFF_AMT := L_HANDOFF_AMT + P_ACC_HAND(I).LCY_AMOUNT;
            END IF;
          END LOOP;
          DBG('l_handoff_amt is ' || L_HANDOFF_AMT);
          DBG('pkg_rtl_teller_rec.scode ' || PKG_RTL_TELLER_REC.SCODE);
        
          IF L_HANDOFF_AMT = 0 THEN
            IF GWPKS_UTIL.G_FROM_BEAN AND
               PKG_RTL_TELLER_REC.SCODE = 'FLEXBRANCH' AND
               NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'Y' AND
               (NVL(GWPKS_UTIL.PKG_FUNC, '***') NOT IN ('1320')) THEN
              DBG('RT transcation...');
              P_ERR_CODE := 'DE-TUD-080';
              RETURN FALSE;
            ELSE
              DBG('Not a RT transcation...exception 1320');
              L_PROCESS_ACCOUTING := FALSE;
            END IF;
          END IF;
        
          IF L_PROCESS_ACCOUTING THEN
          
            IF PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' THEN
              P_ACC_HAND(2).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_VIRACCNO;
              L_AUTH_STAT := 'B';
            END IF;
          
            IF ((NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1401' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1408' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1006' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1008' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1000' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1001' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '8312' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '8309' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1010' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1014' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = 'LOCH' OR
               (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1406' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CHDP' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'MSCC' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'FTRQ' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'MSCD' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CHWL' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'DDLA' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'BCLA' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'BCSA' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'LOCH' OR
               PKG_RTL_TELLER_REC.PRODUCT_CODE = 'DDSA') THEN
            
              IF ((NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1401' OR
                 (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1408' OR
                 (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '8207' OR
                 (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = '1006' AND CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'VA_SYSTEM') =
                 'FCUBS') THEN
              
                P_ACC_HAND(2).VIRTUAL_AC_NO := NVL(DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC,
                                                   DEPKSS_RETAILTELLERUPLOAD.G_UI_OFS_ACC);
              
              ELSE
              
                BEGIN
                
                  BEGIN
                  
                    SELECT COUNT(1)
                      INTO L_VIR_COUNT
                      FROM STVW_AC_GL_ACCOUNTS
                     WHERE AC_GL_NO =
                           DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC
                       AND AC_CLASS = '10';
                    DBG('crl_count:' || L_VIR_COUNT);
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_VIR_COUNT := 0;
                  END;
                  DBG('Assigning value to hand off ' ||
                      DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC);
                
                  IF (P_ACC_HAND.EXISTS(2) AND L_VIR_COUNT > 0 AND
                     (GWPKS_UTIL.PKG_FUNC = '1401' OR
                     GWPKS_UTIL.PKG_FUNC = '1408' OR
                     GWPKS_UTIL.PKG_FUNC = '8312' OR
                     GWPKS_UTIL.PKG_FUNC = '8309' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CHDP' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'MSCC' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'DDLA' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'BCLA'
                     
                     )) THEN
                  
                    P_ACC_HAND(2).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC;
                    L_VIR_ACC1 := P_ACC_HAND(2).AC_NO;
                  END IF;
                  IF (P_ACC_HAND.EXISTS(2) AND L_VIR_COUNT > 0 AND
                     (GWPKS_UTIL.PKG_FUNC = '1008' OR
                     GWPKS_UTIL.PKG_FUNC = '1001' OR
                     GWPKS_UTIL.PKG_FUNC = '1010' OR
                     GWPKS_UTIL.PKG_FUNC = '1014' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'MSCD' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CHWL' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'BCSA' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'DDSA'
                     
                     )) THEN
                    P_ACC_HAND(1).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC;
                    L_VIR_ACC1 := P_ACC_HAND(1).AC_NO;
                  END IF;
                  IF ((NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1000' OR
                     NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1006' OR
                     (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = 'LOCH' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'FTRQ' OR
                     PKG_RTL_TELLER_REC.PRODUCT_CODE = 'LOCH') AND
                     P_ACC_HAND.COUNT > 1 AND P_ACC_HAND.EXISTS(1) AND
                     L_VIR_COUNT > 0) THEN
                  
                    P_ACC_HAND(1).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC;
                    L_VIR_ACC1 := P_ACC_HAND(1).AC_NO;
                  END IF;
                
                  IF DEPKSS_RETAILTELLERUPLOAD.G_UI_OFS_ACC IS NOT NULL THEN
                    BEGIN
                    
                      SELECT COUNT(1)
                        INTO L_VIR_COUNT
                        FROM STVW_AC_GL_ACCOUNTS
                       WHERE AC_GL_NO =
                             DEPKSS_RETAILTELLERUPLOAD.G_UI_OFS_ACC
                         AND AC_CLASS = '10';
                      DBG('dbt_count:' || L_VIR_COUNT);
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_VIR_COUNT := 0;
                    END;
                    IF ((NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1000' OR
                       NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1006' OR
                       (NVL(GWPKS_UTIL.PKG_FUNC, '***')) = 'LOCH' OR
                       PKG_RTL_TELLER_REC.PRODUCT_CODE = 'FTRQ' OR
                       PKG_RTL_TELLER_REC.PRODUCT_CODE = 'LOCH') AND
                       P_ACC_HAND.COUNT > 1 AND P_ACC_HAND.EXISTS(2) AND
                       L_VIR_COUNT > 0) THEN
                    
                      P_ACC_HAND(2).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_OFS_ACC;
                      L_VIR_ACC2 := P_ACC_HAND(2).AC_NO;
                    END IF;
                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('Failed in selecting the account');
                END;
              
                IF P_ACC_HAND.COUNT > 0 THEN
                  FOR I IN P_ACC_HAND.FIRST .. P_ACC_HAND.LAST LOOP
                  
                    DBG('p_acc_hand(i).cust_gl' || P_ACC_HAND(I).CUST_GL);
                    DBG('p_acc_hand(i).ac_no' || P_ACC_HAND(I).AC_NO);
                    DBG('pkg_rtl_teller_rec' || PKG_RTL_TELLER_REC.TXN_ACC);
                    DBG('l_vir_count' || L_VIR_COUNT);
                    IF ((P_ACC_HAND(I).AC_NO = L_VIR_ACC1 AND P_ACC_HAND(I)
                       .VIRTUAL_AC_NO IS NULL) OR
                       ((NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1406' OR
                       PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR') AND
                       PKG_RTL_TELLER_REC.TXN_ACC = P_ACC_HAND(I).AC_NO AND
                       L_VIR_COUNT > 0)) THEN
                      P_ACC_HAND(I).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_TXN_ACC;
                    ELSIF P_ACC_HAND(I).AC_NO = L_VIR_ACC2 AND P_ACC_HAND(I)
                          .VIRTUAL_AC_NO IS NULL THEN
                      P_ACC_HAND(I).VIRTUAL_AC_NO := DEPKSS_RETAILTELLERUPLOAD.G_UI_OFS_ACC;
                    
                    END IF;
                  
                  END LOOP;
                END IF;
              
              END IF;
            
            END IF;
          
            DBG('cspks_charge.g_action_type====> ' ||
                CSPKS_CHARGE.G_ACTION_TYPE);
            DBG('gwpks_util.pkg_func is ====> ' || GWPKS_UTIL.PKG_FUNC);
            IF GWPKS_UTIL.PKG_FUNC IN ('1320', '1300', '1301') AND
               GWPKS_UTIL.G_FROM_BEAN AND
               CSPKS_CHARGE.G_ACTION_TYPE = 'SAVEAUTOAUTH' THEN
              DBG('Account Amount====> ' ||
                  GWPKSS_CLOSECUSTACC.G_ACC_CLSAMT || ' pkg_cls_actAmt ' ||
                  PKG_CLS_ACTAMT);
            
              IF PKG_CLS_ACTAMT <> ABS(GWPKSS_CLOSECUSTACC.G_ACC_CLSAMT) THEN
                DBG('Account balance will be negative after this transaction,cannot be closed');
                P_ERR_CODE := 'ST-ACC-997';
                RETURN FALSE;
              END IF;
            END IF;
          
            DBG('Yahoo --> Going to start 5403 Hamish Jiddayah Payment-->');
            DBG('May Iknow the auth status before processing -->' ||
                L_AUTH_STAT);
            DBG('here 1-->' || GWPKS_UTIL.PKG_FUNC);
            IF GWPKS_UTIL.PKG_FUNC = '5403' THEN
              DBG('Now Going to Create Down Payment Record Starts');
              IF NOT TRPKS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                                'ZQDP',
                                                GLOBAL.APPLICATION_DATE,
                                                L_SERIAL_DOWNPAYMENT,
                                                L_REF_NO_DOWNPAYMENT,
                                                P_ERR_CODE) THEN
                DBG('Error while generating new PROCESS_REF_NO for 5403');
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                RETURN FALSE;
              END IF;
              DBG('Assigning to detbs_rtl_teller -->' ||
                  L_REF_NO_DOWNPAYMENT);
              UPDATE DETBS_RTL_TELLER
                 SET ESN        = 1,
                     EVENT_CODE = 'INIT',
                     HJ_REF_NO  = L_REF_NO_DOWNPAYMENT,
                     TXN_ACC    = GWPKS_CREATERETAILTLR.G_FNACCREF
               WHERE TRN_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
              DBG('Assigning to cltb_account_downpayment -->');
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PROCESS_REF_NO   := L_REF_NO_DOWNPAYMENT;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.BRANCH_CODE      := GLOBAL.CURRENT_BRANCH;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO        := GWPKS_CREATERETAILTLR.G_FNACCREF;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.CUSTOMER         := PKG_RTL_TELLER_REC.REL_CUSTOMER;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.ACC_CCY          := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT        := PKG_RTL_TELLER_REC.TXN_AMOUNT;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC      := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC_CCY  := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.VALUE_DATE       := PKG_RTL_TELLER_REC.VALUE_DT;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAY_MODE         := 'G';
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXCH_RATE        := PKG_RTL_TELLER_REC.EXCH_RATE;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_BRANCH   := GLOBAL.CURRENT_BRANCH;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AUTH_STAT        := 'U';
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.RECORD_STAT      := 'O';
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.MAKER_ID         := PKG_RTL_TELLER_REC.MAKER_ID;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.MAKER_DT_STAMP   := PKG_RTL_TELLER_REC.MAKER_DT_STAMP;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.CHECKER_ID       := PKG_RTL_TELLER_REC.CHECKER_ID;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.CHECKER_DT_STAMP := PKG_RTL_TELLER_REC.CHECKER_DT_STAMP;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.MODULE_CODE      := 'CI';
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXT_REF_NO       := PKG_RTL_TELLER_REC.XREF;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.NARRATIVE        := PKG_RTL_TELLER_REC.NARRATIVE;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PROD_CODE        := PKG_RTL_TELLER_REC.PRODUCT_CODE;
              L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY   := PKG_RTL_TELLER_REC.OFS_AMOUNT;
              DBG('Going to do Validation Before Save of Hamish Jiddayah Down Payment');
              DBG('Validating DP amount whether its NULL');
              IF NVL(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT, 0) <= 0 THEN
                OVPKSS.PR_APPENDTBL('CL-DPMT-005', '');
                L_VAL_RESULT := FALSE;
              END IF;
              DBG('Validation to not allow new downpayment for a account with unauthorised downpayments');
              SELECT COUNT(DPREFNO)
                INTO L_COUNT_DOWNPAY
                FROM CIVWS_ACCOUNT_DP_DET
               WHERE DPREFNO =
                     L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO
                 AND AUTHSTAT = 'U';
              DBG('count of downpayment entries' || L_COUNT_DOWNPAY);
              IF L_COUNT_DOWNPAY > 0 THEN
                OVPKSS.PR_APPENDTBL('CL-DPMT-038',
                                    L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO || '~');
              END IF;
              IF NVL(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT, 0) <= 0 THEN
                OVPKSS.PR_APPENDTBL('CL-DPMT-005', '');
                L_VAL_RESULT := FALSE;
              END IF;
            
              DBG('Validation to not allow new downpayment for a account with unauthorised downpayments');
              SELECT COUNT(DPREFNO)
                INTO L_COUNT_DOWNPAY
                FROM CIVWS_ACCOUNT_DP_DET
               WHERE DPREFNO =
                     L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO
                 AND AUTHSTAT = 'U';
              DBG('count of downpayment entries' || L_COUNT_DOWNPAY);
              IF L_COUNT_DOWNPAY > 0 THEN
                OVPKSS.PR_APPENDTBL('CL-DPMT-038',
                                    L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO || '~');
              END IF;
              IF L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO IS NOT NULL THEN
                L_ACCOUNT_REC := CLPKS_CACHE.FN_ACCOUNT_MASTER(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO,
                                                               GLOBAL.CURRENT_BRANCH);
                DBG('Validating DP amount whether it has crossed the outstanding');
                BEGIN
                
                  IF L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.ACC_CCY <>
                     L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC_CCY THEN
                    DBG('Account ccy differs from Payable acc ccy ');
                    DBG('Abt to do ccy conversion for ' ||
                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.ACC_CCY ||
                        ' and ' ||
                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC_CCY);
                    DBG('Going to call conversion function');
                    DBG('p_cltb_account_dp_rec.g_downpayment.exch_rate' ||
                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXCH_RATE);
                    IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.BRANCH_CODE,
                                                  L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC_CCY,
                                                  L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.ACC_CCY,
                                                  L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT,
                                                  'Y',
                                                  L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY,
                                                  L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXCH_RATE,
                                                  P_ERR_CODE) THEN
                      DBG('function is been invoked');
                      DBG('Currency conversion failure. Returning false');
                      RETURN FALSE;
                    END IF;
                    DBG('Conversion Amount' ||
                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY);
                  ELSE
                    L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY := L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT;
                  END IF;
                  L_CURRENT_DP_AMOUNT := L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY;
                  DBG('On going dp amount' || L_CURRENT_DP_AMOUNT);
                
                  SELECT NVL(SUM(AMT_IN_ACC_CCY), 0)
                    INTO L_SUM_DP
                    FROM CLTBS_ACCOUNT_DOWNPAYMENT
                   WHERE DP_REF_NO = L_ACCOUNT_REC.ACCOUNT_NUMBER
                     AND PROCESS_REF_NO <>
                         L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PROCESS_REF_NO
                     AND RECORD_STAT = 'O';
                  L_SUM_DP     := L_SUM_DP + L_CURRENT_DP_AMOUNT;
                  L_OS_DP_RECV := NVL(L_ACCOUNT_REC.DOWNPAYMENT_AMOUNT, 0) -
                                  L_SUM_DP;
                  DBG('l_sum_dp     : ' || L_SUM_DP);
                  DBG('l_os_dp_recv : ' || L_OS_DP_RECV);
                  DBG('l_account_rec.downpayment_amount   : ' ||
                      L_ACCOUNT_REC.DOWNPAYMENT_AMOUNT);
                
                  IF NVL(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY,
                         0) > (L_OS_DP_RECV + L_CURRENT_DP_AMOUNT) THEN
                    DBG('DP amount entered exceeds the outstanding dp receivable for this account');
                  
                    P_ERR_CODE  := 'CL-DPMT-042';
                    P_ERR_PARAM := NULL;
                    OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                  
                  END IF;
                
                  IF (L_OS_DP_RECV - NVL(L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY,
                                         0)) > 0 THEN
                    OVPKSS.PR_APPENDTBL('CL-DPMT-011',
                                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY || '~' ||
                                        L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO || '~' ||
                                        L_OS_DP_RECV || '~');
                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('No downpayments entered using this account no : ' ||
                        L_ACCOUNT_REC.ACCOUNT_NUMBER);
                END;
              END IF;
              IF L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO IS NOT NULL THEN
                SELECT CUSTOMER_ID, CURRENCY
                  INTO L_CUSTID, L_CCY_HAMISHJIDDAYAH
                  FROM CLTB_ACCOUNT_MASTER
                 WHERE ACCOUNT_NUMBER =
                       L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO
                   AND BRANCH_CODE =
                       L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.BRANCH_CODE;
                IF (L_CUSTID <>
                   L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.CUSTOMER) OR
                   (L_CCY_HAMISHJIDDAYAH <> PKG_RTL_TELLER_REC.TXN_CCY) THEN
                  DBG('Downpayment customer/currency does not match the account''s customer/currency');
                  P_ERR_CODE  := 'CL-DPMT-016';
                  P_ERR_PARAM := ' ';
                  OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                END IF;
              END IF;
              DBG('Going to Save Hamish DownPayment-->');
              INSERT INTO CLTBS_ACCOUNT_DOWNPAYMENT
                (MODULE_CODE,
                 PROCESS_REF_NO,
                 BRANCH_CODE,
                 DP_REF_NO,
                 PROD_CODE,
                 CUSTOMER,
                 ACC_CCY,
                 DP_AMOUNT,
                 PAYABLE_ACC,
                 PAYABLE_ACC_CCY,
                 VALUE_DATE,
                 PAY_MODE,
                 EXCH_RATE,
                 MAKER_ID,
                 MAKER_DT_STAMP,
                 RECORD_STAT,
                 AUTH_STAT,
                 MOD_NO,
                 ONCE_AUTH,
                 PAYABLE_BRANCH,
                 AMT_IN_ACC_CCY,
                 EXT_REF_NO,
                 NARRATIVE)
              VALUES
                (L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.MODULE_CODE,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PROCESS_REF_NO,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.BRANCH_CODE,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_REF_NO,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PROD_CODE,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.CUSTOMER,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.ACC_CCY,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.DP_AMOUNT,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_ACC_CCY,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.VALUE_DATE,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAY_MODE,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXCH_RATE,
                 GLOBAL.USER_ID,
                 CSFNS_TIMESTAMP,
                 'O',
                 'U',
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.MOD_NO,
                 'N',
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.PAYABLE_BRANCH,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.AMT_IN_ACC_CCY,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.EXT_REF_NO,
                 L_CLTB_ACCOUNT_DP_REC.G_DOWNPAYMENT.NARRATIVE);
              DBG('Save Happend Successfully or Not--> will Check Count' ||
                  SQL%ROWCOUNT);
              DBG('Create Down Payment Record Ends Yahoo');
            END IF;
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;
              IF NOT
                  DEPKS_RTL_TELLER_CLUSTER.FN_SAVE_HANDOFF(PKG_RTL_TELLER_REC,
                                                           P_ACC_HAND,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA) THEN
                RETURN FALSE;
              END IF;
            END IF;
          
            IF PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' THEN
              FOR L_INDEX IN P_ACC_HAND.FIRST .. P_ACC_HAND.LAST LOOP
                IF P_ACC_HAND(L_INDEX).LCY_AMOUNT <> 0 THEN
                  L_ACC_TAB(L_CNT) := P_ACC_HAND(L_INDEX);
                  L_CNT := L_CNT + 1;
                END IF;
              END LOOP;
              P_ACC_HAND := L_ACC_TAB;
              BEGIN
                DEBUG.PR_DEBUG('RT',
                               'final handoff from switch to accounting.....');
                PR_PRINT_ACCTNG_TABLE(L_ACC_TAB);
              EXCEPTION
                WHEN OTHERS THEN
                  DEBUG.PR_DEBUG('RT',
                                 'In OTHERS pr_print_acctng_table  ::::: ' ||
                                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              END;
            END IF;
          
            IF GWPKS_UTIL.G_FROM_BEAN AND
               PKG_RTL_TELLER_REC.SCODE IN ('FLEXBRANCH') THEN
              FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
                IF P_ACC_HAND.EXISTS(I) THEN
                  IF P_ACC_HAND(I).AMOUNT_TAG = 'TXN_AMT' THEN
                    L_TXN_AMT := P_ACC_HAND(I).LCY_AMOUNT;
                  END IF;
                  IF P_ACC_HAND(I).AMOUNT_TAG IN ('CHG_AMT1',
                                     'CHG_AMT2',
                                     'CHG_AMT3',
                                     'CHG_AMT4',
                                     'CHG_AMT5') AND P_ACC_HAND(I)
                     .DRCR_IND = 'D' THEN
                    L_CHG_AMT := L_CHG_AMT + P_ACC_HAND(I).LCY_AMOUNT;
                  END IF;
                END IF;
              END LOOP;
              DBG('l_txn_amt is ' || L_TXN_AMT || ' and l_chg_amt is ' ||
                  L_CHG_AMT);
              IF L_TXN_AMT > 0 AND L_CHG_AMT > L_TXN_AMT THEN
                DBG('Charges are greater than transaction amount');
                P_ERR_CODE  := 'DE-TUD-951';
                P_ERR_PARAM := NULL;
                OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
              END IF;
            END IF;
          
            IF NOT ACPKSS.FN_ACHANDOFF(PKG_RTL_TELLER_REC.TRN_REF_NO,
                                       1,
                                       PKG_APPLICATION_DATE,
                                       P_ACC_HAND,
                                       L_AUTH_STAT,
                                       'N',
                                       'Y',
                                       NVL(GLOBAL.USER_ID, 'SYSTEM'),
                                       P_ERR_CODE,
                                       P_ERR_PARAM) THEN
              RETURN FALSE;
            END IF;
          END IF;
          DBG('after calling acpkss.fn_achandoff');
        
          IF PKG_RTL_TELLER_REC.SCODE IN ('FLEXBRANCH') OR
             GWPKS_UTIL.PKG_FUNC = '1301' THEN
            DBG('Before Call to fn_get_actAmt ');
            IF NOT FN_GET_ACTAMT(P_ACC_HAND, P_ERR_CODE, P_ERR_PARAM) THEN
            
              DBG('Failed while getting   fn_get_actAmt');
            
              RETURN FALSE;
            END IF;
          END IF;
        
        END IF;
      END IF;
    END IF;
    DBG('Accounting ret ' || P_ERR_CODE);
  
    DBG('p_track_chg_entry_nsf  ' || P_TRACK_CHG_ENTRY_NSF);
  
    DBG('p_track_chg_entry_nsf  ' || P_TRACK_CHG_ENTRY_NSF);
    DBG('gwpks_util.g_twostepprocess  ' || GWPKS_UTIL.G_TWOSTEPPROCESS);
    DBG('gwpks_util.g_brnnewflow  ' || GWPKS_UTIL.G_BRNNEWFLOW);
    DBG('gwpks_util.g_firststepdone  ' || GWPKS_UTIL.G_FIRSTSTEPDONE);
  
    IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'N' AND
       NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' THEN
      DBG('bhaag milkha bhaag part1');
      L_TRACK_ACCOUNT := FALSE;
      DELETE CSTB_AUTO_SETTLE_BLOCK_TEMP
       WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
      DBG('After Deleting cstb_auto_settle_block_temp ');
    
    END IF;
  
    IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
       NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1001' THEN
      DBG('bhaag milkha bhaag part2');
      L_TRACK_ACCOUNT := FALSE;
    
    END IF;
  
    IF P_TRACK_CHG_ENTRY_NSF = 'Y' AND L_TRACK_ACCOUNT = TRUE
    
     THEN
      DBG('HAHAHAHHAHA');
      PR_TRACK_ACCOUNT(PKG_RTL_TELLER_REC.TRN_REF_NO,
                       G_TRACK_CHARGE_ENTRIES,
                       G_TRACK_ACCOUNT_ENTRIES);
      DBG('NSF Tracked ..updated for Receviables');
    
      BEGIN
        DBG('NSF Tracked... Before Total Tracked Calculation');
        SELECT SUM(AMOUNT_DUE)
          INTO TOT_AMOUNT_DUE
          FROM CSTB_AUTO_SETTLE_BLOCK
         WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('NSF Tracked...Not able to do Total');
      END;
      DBG('NSF Tracked..tot_amount_due ' || TOT_AMOUNT_DUE);
    
      IF NVL(TOT_AMOUNT_DUE, 0) > 0 THEN
      
        BEGIN
          DBG('NSF Tracked... Before Total Tracked Calculation');
          SELECT CCY
            INTO L_NSF_CCY
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO =
                 (SELECT ACCOUNT_NO
                    FROM CSTB_AUTO_SETTLE_BLOCK
                   WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
                     AND ROWNUM = 1);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('NSF Tracked...Not able find CCY for Account');
        END;
        DBG('NSF Tracked..l_ccy ' || L_NSF_CCY);
      
        P_ERR_CODE  := 'DE-TRACK02';
        P_ERR_PARAM := TOT_AMOUNT_DUE || '~' || L_NSF_CCY || '~;';
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      ELSE
        DBG('There is nothing going to get tracked..will raise override');
        P_ERR_CODE  := 'DE-TRACK03';
        P_ERR_PARAM := '~';
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      END IF;
    END IF;
  
    PR_UPDATE_REC;
    DBG('After pr_update_rec with gen_trn_advice flag as ' ||
        PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE);
  
    DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
        CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Scode, pkg_rtl_teller_rec.scode :::: ' ||
          PKG_RTL_TELLER_REC.SCODE);
      IF PKG_RTL_TELLER_REC.SCODE NOT IN ('FLEXSWITCH') THEN
        DBG('Advie flag, pkg_arc_row.generate_transaction_advice :::: ' ||
            PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE);
        DBG('ifpks_xml_parse_java.pkg_acttype ::::: ' ||
            NVL(IFPKS_XML_PARSE_JAVA.PKG_ACTTYPE, 'SAVEAUTOAUTH'));
        IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' AND
           NVL(IFPKS_XML_PARSE_JAVA.PKG_ACTTYPE, 'SAVEAUTOAUTH') IN
           ('SAVEAUTOAUTH') THEN
          DBG('pkg_rtl_teller_rec.trn_ref_no ::::: ' ||
              PKG_RTL_TELLER_REC.TRN_REF_NO);
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 1;
          IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                                  PKG_ARC_ROW,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM,
                                                  L_FN_CALL_ID,
                                                  L_TB_CLUSTER_DATA) THEN
            DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
            RETURN FALSE;
          END IF;
        
        END IF;
      END IF;
    
      DBG('pkg_rtl_teller_rec.trn_ref_no 2::::: ' ||
          PKG_RTL_TELLER_REC.TRN_REF_NO);
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 2;
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_SAVE(PKG_RTL_TELLER_REC,
                                              P_ERR_CODE,
                                              P_ERR_PARAM,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA) THEN
        DBG('Failed inside depks_rtl_teller_cluster.Fn_Save2');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('cspkss_charge.g_Sc_Skip_Main_Accntng--> ' ||
        CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG);
    DBG('pkg_rtl_teller_rec.scode--> ' || PKG_RTL_TELLER_REC.SCODE);
    DBG('pkg_arc_row.generate_transaction_advice--> ' ||
        PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE);
  
    IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' THEN
    
      IF PKG_RTL_TELLER_REC.SCODE NOT IN ('FLEXSWITCH') THEN
      
        IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
          PR_MESSAGING;
        END IF;
      
        DBG('gwpks_util.g_genmsg--> ' || GWPKS_UTIL.G_GENMSG);
        DBG('Pkg_Arc_Row.Generate_Transaction_Advice--> ' ||
            PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE);
        DBG('p_err_code--> ' || P_ERR_CODE);
      
        IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' AND
           P_ERR_CODE IS NULL THEN
          DBG('inside if..');
        
          PR_GEN_ADV_FOR_CONTRACT(P_ACC_HAND(1).TRN_REF_NO);
          NULL;
        
        ELSIF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' AND
              GWPKS_UTIL.G_OVD_CONF = TRUE THEN
          DBG('Generating advice for overrides');
          PR_GEN_ADV_FOR_CONTRACT(P_ACC_HAND(1).TRN_REF_NO);
          NULL;
        
        END IF;
      END IF;
    END IF;
    DBG('1405 screen changes here');
  
    DBG('gwpks_service_router.g_action' || GWPKS_SERVICE_ROUTER.G_ACTION);
    DBG('gwpks_util.pkg_acttype-->' || GWPKS_UTIL.PKG_ACTTYPE);
  
    IF GWPKS_UTIL.PKG_ACTTYPE = 'SAVEAUTOAUTH' THEN
    
      DBG('Inside Save Auto Auth');
    
      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...' ||
          P_DETB_RTL_TELLER_REC.PRODUCT_CODE);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(P_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
        DBG('Failed in obtaini the RT pref so assignin def val as N : err_code' ||
            P_ERR_CODE);
        L_PC_TXN    := 'N';
        L_FT_TXN    := 'N';
        P_ERR_CODE  := NULL;
        P_ERR_PARAM := NULL;
      ELSE
        L_PC_TXN := CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.PC_TXN;
        L_FT_TXN := CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.FT_TXN;
        DBG('Value of l_pc_txn is - ' || L_PC_TXN);
        DBG('Value of l_ft_txn is - ' || L_FT_TXN);
      END IF;
      DBG('Success Fn_Get_Detm_Rt_Pref_Rec_Wrp...');
    
      IF NVL(GWPKS_UTIL.PKG_FUNC, '*') NOT IN
         ('DDRV', 'BCRV', 'BCDI', 'DDDI') THEN
      
        DBG('befor calling fn_trnfbypc l_pc_txn' || L_PC_TXN);
        IF L_PC_TXN LIKE 'Y' THEN
          IF DEPKS_RETAILTELLERUPLOAD.G_PCDETAILS.PC_BANK_CODE IS NULL OR
             DEPKS_RETAILTELLERUPLOAD.G_PCDETAILS.PC_NETWORK_ID IS NULL OR
             DEPKS_RETAILTELLERUPLOAD.G_PCDETAILS.PC_ACCOUNT_NO IS NULL OR
             DEPKS_RETAILTELLERUPLOAD.G_PCDETAILS.BEN_ACCT_TYPE IS NULL THEN
            DBG('mandatory fields are null in pcdetails tab::::');
            P_ERR_CODE := 'RT-1000-01';
            RETURN FALSE;
          END IF;
          DBG('befor calling fn_trnfbypc');
          IF NOT FN_TRNFBYPC(P_DETB_RTL_TELLER_REC,
                             DEPKS_RETAILTELLERUPLOAD.G_PCDETAILS,
                             P_ERR_CODE,
                             P_ERR_PARAM) THEN
            RETURN FALSE;
            DBG('Failed in fn_trnfbypc');
          END IF;
          DBG('after calling fn_trnfbypc');
        END IF;
      
        DBG('befor calling fn_trnsbyft l_ft_txn' || L_FT_TXN);
        IF L_FT_TXN LIKE 'Y' THEN
          IF GWPKS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD1 IS NULL OR
             GWPKS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD2 IS NULL THEN
            DBG('mandatory fields are null in ftdetails callform::::');
            P_ERR_CODE := 'RT-1000-02';
            RETURN FALSE;
          END IF;
          DBG('befor calling fn_trnsbyft');
          IF NOT FN_TRNSBYFT(P_DETB_RTL_TELLER_REC,
                             PKG_ARC_ROW,
                             GWPKS_CREATERETAILTLR.G_FTDETAILS,
                             P_ERR_CODE,
                             P_ERR_PARAM) THEN
            RETURN FALSE;
            DBG('Failed in fn_trnsbyft');
          END IF;
          DBG('after calling fn_trnsbyft');
        END IF;
      
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WO of fn_save with...' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_SAVE;

  FUNCTION FN_SAVEPARTIALREV(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                             P_ERR_CODE            IN OUT VARCHAR2,
                             P_ERR_PARAM           IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    P_ACC_HAND             ACPKS.TBL_ACHOFF;
    I                      NUMBER := 1;
    L_RET                  NUMBER := 0;
    L_AUTH_STAT            VARCHAR2(1) := 'U';
    TOT_CHGS               PLS_INTEGER := 5;
    L_STAT                 VARCHAR2(4);
    L_ACC                  VARCHAR2(20);
    L_BRN                  VARCHAR2(3);
    L_CCY                  VARCHAR2(3);
    L_ACENTRIES_RETURNED_2 BOOLEAN := FALSE;
    L_CHARGES_RETURNED_2   BOOLEAN := FALSE;
  
    L_INDEX   NUMBER;
    L_ESN_MAX NUMBER;
  
  BEGIN
    PKG_RTL_TELLER_REC   := P_DETB_RTL_TELLER_REC;
    PKG_LCY              := GLOBAL.LCY;
    PKG_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
  
    IF NOT OVPKSS.GL_TBLERROR.COUNT <> 0 THEN
      DBG('ovpkss.gl_tblError is already initialized.');
    ELSE
      OVPKSS.PR_INITERRTBL;
    END IF;
  
    IF PKG_ARC_ROW.COD_BRANCH IS NULL THEN
      PR_SET_GLOBAL(P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NVL(PKG_PROD.PRODUCT_CODE, '!@#$') <>
       PKG_RTL_TELLER_REC.PRODUCT_CODE THEN
      IF NOT
          CSPKS_UTILS.FN_GETPRODUCT_DETAILS(PKG_RTL_TELLER_REC.PRODUCT_CODE) THEN
        DBG('From cstm_prod ' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
            SQLERRM);
        P_ERR_CODE := 'DE-TUD-003';
        RETURN FALSE;
      END IF;
      PKG_PROD := CSPKS_UTILS.PKG_PRODUCT;
    END IF;
    IF PKG_PROD.PRODUCT_TYPE = 'IL' THEN
      BEGIN
      
        SELECT INSTR_STAT, AC_NO, AC_BRANCH, AC_CCY
          INTO L_STAT, L_ACC, L_BRN, L_CCY
          FROM ISTM_INSTR_TXN
         WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Could b issue. Any case, shl trap later.');
        WHEN OTHERS THEN
          DBG('Some other err ' || SQLERRM);
          P_ERR_CODE  := 'IF-DAT013';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.XREF || '~';
          RETURN FALSE;
      END;
      IF PKG_RTL_TELLER_REC.PRODUCT_CODE <> 'BCLT' THEN
        IF L_STAT = 'LOST' THEN
          DBG('Instrument Reported to have been Lost.');
          P_ERR_CODE  := 'AC-RECLOST';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE || '~';
          RETURN FALSE;
        END IF;
      END IF;
    
    END IF;
    IF NOT FN_VALIDATE(P_ERR_CODE, P_ERR_PARAM) THEN
      RETURN FALSE;
    END IF;
  
    IF NOT CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND, L_RET);
    END IF;
    IF L_RET = -1 THEN
      DBG('Ac entries returned false...' || L_RET);
      RETURN FALSE;
    ELSIF L_RET = 2 THEN
      DBG('Ac entries need to be tracked...');
      L_ACENTRIES_RETURNED_2 := TRUE;
    END IF;
  
    IF ISPKSS_INSTRUMENTS.PKG_CHQ_PURCHASE AND P_ACC_HAND(1).EVENT = 'LIQD' THEN
      DBG('CALLING SWAP ACCOUNT...');
      ACPKSS.PR_SWAP_DRCR_IND_AMT(P_ACC_HAND);
    
      P_ACC_HAND(1).DONT_SHOWIN_STMT := 'Y';
    END IF;
  
    IF PKG_ARC_ROW.COD_CHG_TYPE IS NULL THEN
      TOT_CHGS := 0;
    ELSIF PKG_ARC_ROW.COD_CHG_TYPE1 IS NULL THEN
      TOT_CHGS := 1;
    ELSIF PKG_ARC_ROW.COD_CHG_TYPE2 IS NULL THEN
      TOT_CHGS := 2;
    ELSIF PKG_ARC_ROW.COD_CHG_TYPE3 IS NULL THEN
      TOT_CHGS := 3;
    ELSIF PKG_ARC_ROW.COD_CHG_TYPE4 IS NULL THEN
      TOT_CHGS := 4;
    END IF;
  
    PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := 0;
  
    IF TOT_CHGS > 0 THEN
      FOR I IN 1 .. TOT_CHGS LOOP
        IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
          PR_BUILD_CLOSE_CHG_ENTRIES(P_ACC_HAND,
                                     PKG_ARC_ROW,
                                     I,
                                     P_ERR_CODE,
                                     L_RET);
        ELSE
          PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                               PKG_ARC_ROW,
                               I,
                               P_ERR_CODE,
                               L_RET);
        END IF;
        IF L_RET = -1 THEN
          RETURN FALSE;
        ELSIF L_RET = 2 THEN
          L_CHARGES_RETURNED_2 := TRUE;
        END IF;
      END LOOP;
    END IF;
    IF L_ACENTRIES_RETURNED_2 OR L_CHARGES_RETURNED_2 THEN
      L_RET := 2;
    END IF;
    IF L_RET = 2 THEN
      PR_TRACK_ACCOUNT(PKG_RTL_TELLER_REC.TRN_REF_NO,
                       G_TRACK_CHARGE_ENTRIES,
                       G_TRACK_ACCOUNT_ENTRIES);
      DBG('TRacked ..going to return true to the form');
      PKG_RTL_TELLER_REC.RECORD_STAT := 'N';
      PR_UPDATE_REC;
      P_ACC_HAND.DELETE;
      P_ERR_CODE  := 'DE-TRACK01';
      P_ERR_PARAM := '~';
      RETURN TRUE;
    END IF;
    IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      DBG('b4 call to close ac entries...');
      PR_BUILD_CLOSE_AC_ENTRIES(P_ACC_HAND, L_RET);
    END IF;
    PR_PRINT_ACCTNG_TABLE(P_ACC_HAND);
    IF GWPKS_UTIL.G_FROM_BEAN THEN
      L_AUTH_STAT := 'B';
    
    ELSE
    
      IF NVL(GWPKS_UTIL.PKG_ACTTYPE, 'SAVEAUTOAUTH') IN ('SAVEAUTOAUTH') AND
         (GWPKS_UTIL.G_FROM_BEAN) THEN
      
        L_AUTH_STAT := 'B';
      
        DBG('l_auth_stat set as ' || L_AUTH_STAT);
      ELSE
        L_AUTH_STAT := 'U';
      END IF;
    
    END IF;
    IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE AND ICPKSS_BOD.G_FROM_TD <> TRUE THEN
      DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
      L_AUTH_STAT := 'B';
    END IF;
    IF PKG_ARC_ROW.COD_NET_CHARGES = 'Y' THEN
      CSPKSS_ARC.PR_NET_CHARGES(P_ACC_HAND,
                                PKG_ARC_ROW.CHG_FROM,
                                PKG_ARC_ROW.DR_ACC,
                                'TXN_AMT',
                                'OFS_AMT',
                                L_RET);
      IF L_RET = -1 THEN
        DBG('Netting failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    BEGIN
    
      SELECT MAX(EVENT_SR_NO)
        INTO L_ESN_MAX
        FROM ACTBS_HANDOFF
       WHERE TRN_REF_NO = P_ACC_HAND(1).TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      
        L_ESN_MAX := 1;
      WHEN OTHERS THEN
        DBG('Failed to pickup the max esn before calling fn_achandoff');
        RETURN FALSE;
    END;
  
    FOR I_INDEX IN P_ACC_HAND.FIRST .. P_ACC_HAND.LAST LOOP
      P_ACC_HAND(L_INDEX).EVENT_SR_NO := L_ESN_MAX + 1;
    END LOOP;
  
    IF NOT ACPKSS.FN_ACHANDOFF(P_ACC_HAND(1).TRN_REF_NO,
                               L_ESN_MAX + 1,
                               PKG_APPLICATION_DATE,
                               P_ACC_HAND,
                               L_AUTH_STAT,
                               'N',
                               'Y',
                               NVL(GLOBAL.USER_ID, 'SYSTEM'),
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
      RETURN FALSE;
    END IF;
    DBG('Accounting ret ' || P_ERR_CODE);
    IF P_ERR_CODE IS NULL THEN
      OVPKSS.PR_READTBL(P_ERR_CODE, P_ERR_PARAM);
      DBG('I got ' || P_ERR_CODE);
    END IF;
    PR_UPDATE_REC;
    DBG('After pr_update_rec with gen_trn_advice flag as ' ||
        PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE);
  
    IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
      PR_MESSAGING;
    END IF;
  
    IF GWPKS_UTIL.G_GENMSG = 'Y' AND P_ERR_CODE IS NULL THEN
      PR_GEN_ADV_FOR_CONTRACT(P_ACC_HAND(1).TRN_REF_NO);
      NULL;
    
    ELSIF GWPKS_UTIL.G_GENMSG = 'Y' AND GWPKS_UTIL.G_OVD_CONF = TRUE THEN
      DBG('Generating advice for overrides');
      PR_GEN_ADV_FOR_CONTRACT(P_ACC_HAND(1).TRN_REF_NO);
      NULL;
    
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WO of fn_save with...' || SQLERRM);
      RETURN FALSE;
  END FN_SAVEPARTIALREV;

  PROCEDURE PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                    P_RET      IN OUT NUMBER) IS
    L_EMPTY_REC ACTBS_HANDOFF%ROWTYPE;
    L_BRN       STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_TXN_FCY   NUMBER;
    L_TXN_LCY   NUMBER;
    L_TXN_RATE  NUMBER;
    L_OFS_FCY   NUMBER;
    L_OFS_LCY   NUMBER;
    L_OFS_RATE  NUMBER;
    L_TXN_CCY   VARCHAR2(3);
    L_OFS_CCY   VARCHAR2(3);
    L_AC_OR_GL  STTBS_ACCOUNT.AC_OR_GL%TYPE;
  
    LBAL                       STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_ACCOUNT_TRACKING_ALLOWED VARCHAR2(1);
    ACCENTRIES_NOT_TO_BE_PASSED EXCEPTION;
    L_ROWCOUNT NUMBER;
  
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_AMOUNTDUE_FORTXN CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_AMOUNTAVL_FORTXN CSTB_AUTO_SETTLE_BLOCK.AMOUNT_AVAILABLE%TYPE;
    L_AMOUNTDUE_FORCHG CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_AMOUNTAVL_FORCHG CSTB_AUTO_SETTLE_BLOCK.AMOUNT_AVAILABLE%TYPE;
  
    L_TXN_ACC             STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ACC_BR              VARCHAR2(3);
    L_AMOUNTOFSDUE_FORCHG CSTB_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_AMOUNTOFSAVL_FORCHG CSTB_AUTO_SETTLE_BLOCK.AMOUNT_AVAILABLE%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    PROCEDURE PR_GET_AMOUNTS(P_RET IN OUT NUMBER) IS
      L_ERR_CODE VARCHAR2(256);
      L_RATEFLG  NUMBER;
    BEGIN
      L_TXN_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
      L_OFS_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
    
      IF CSPKSS_CHARGE.G_FUNCTION_ID = 'CADCHBOO' THEN
        IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NOT NULL THEN
          DBG('Setting Transaction Amount as 0 for CADCHBOO');
          PKG_RTL_TELLER_REC.TXN_AMOUNT := 0;
          PKG_RTL_TELLER_REC.OFS_AMOUNT := 0;
        END IF;
      END IF;
    
      DBG('The transaction currency in pr_build_acctng_entries in 1 is:' ||
          L_TXN_CCY);
      DBG('The package local currency in pr_build_acctng_entries in 1 is:' ||
          L_OFS_CCY);
      DBG('The offset currency in pr_build_acctng_entries 1 is:' ||
          PKG_LCY);
      IF L_TXN_CCY = PKG_LCY THEN
        L_TXN_FCY  := NULL;
        L_TXN_LCY  := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        L_TXN_RATE := NULL;
      END IF;
      IF L_OFS_CCY = PKG_LCY THEN
        L_OFS_LCY  := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        L_OFS_FCY  := NULL;
        L_OFS_RATE := NULL;
      END IF;
    
      DBG('The exchange rate in rtl teller is:' ||
          PKG_RTL_TELLER_REC.EXCH_RATE);
      DBG('The lcy Exchange Rate is:' || PKG_RTL_TELLER_REC.LCY_EXCH_RATE ||
          ' with calculated exchange arte as:' || PKG_TXN_EXCH_RATE);
    
      IF L_TXN_CCY <> PKG_LCY THEN
        L_TXN_FCY := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        IF L_OFS_CCY = PKG_LCY THEN
          L_TXN_RATE := PKG_RTL_TELLER_REC.EXCH_RATE;
          L_TXN_LCY  := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        ELSE
        
          DBG('The txn and offset currencies are :' || L_OFS_CCY ||
              ' and ' || L_TXN_CCY);
          IF L_OFS_CCY = L_TXN_CCY THEN
            DBG('The txn and offset currencies are same');
            PKG_RTL_TELLER_REC.LCY_EXCH_RATE := NVL(PKG_RTL_TELLER_REC.LCY_EXCH_RATE,
                                                    PKG_TXN_EXCH_RATE);
          END IF;
        
          IF NVL(PKG_RTL_TELLER_REC.LCY_EXCH_RATE, 0) > 0 THEN
            L_TXN_RATE := PKG_RTL_TELLER_REC.LCY_EXCH_RATE;
            L_TXN_FCY  := PKG_RTL_TELLER_REC.TXN_AMOUNT;
            IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                         L_TXN_CCY,
                                         PKG_LCY,
                                         'STANDARD',
                                         'M',
                                         L_TXN_FCY,
                                         'Y',
                                         L_TXN_LCY,
                                         L_TXN_RATE,
                                         L_ERR_CODE) THEN
              DBG('Bombed with amt1_to_amt2 b/w ' || L_TXN_CCY || ' and ' ||
                  PKG_LCY);
              DBG('Values passed where ' || L_TXN_FCY || ' and ' ||
                  L_TXN_RATE);
              P_RET := -1;
              RETURN;
            END IF;
          ELSE
          
            L_TXN_LCY := PKG_RTL_TELLER_REC.LCY_AMOUNT;
          
            DBG('before call4 pkg_rtl_teller_rec.txn_amount : ' ||
                PKG_RTL_TELLER_REC.TXN_AMOUNT);
            DBG('before call4 l_txn_lcy : ' || L_TXN_LCY);
          
            IF PKG_RTL_TELLER_REC.TXN_AMOUNT <> 0 AND L_TXN_LCY <> 0 THEN
              DBG('THe package lcy is:' || PKG_LCY || ' with rate as :' ||
                  L_TXN_RATE);
            
              IF NOT CYPKS.FN_AMT_TO_RATE(L_TXN_CCY,
                                          PKG_LCY,
                                          PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                          L_TXN_LCY,
                                          L_TXN_RATE) THEN
                DBG('Bombed with getting exch rate b/w ' || L_TXN_CCY ||
                    ' and ' || PKG_LCY);
                DBG('Amts passed where ' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
                    ' and ' || L_TXN_LCY);
                P_RET := -1;
                RETURN;
              END IF;
            
            ELSE
            
              DBG('Inside CALL4 ELSE');
              DBG('Pkg_Rtl_Teller_Rec.Branch_Code ::: ' ||
                  PKG_RTL_TELLER_REC.BRANCH_CODE);
              DBG('l_Txn_Ccy :::: ' || L_TXN_CCY);
              DBG('Pkg_Lcy:::: ' || PKG_LCY);
              DBG('l_Txn_Rate :::: ' || L_TXN_RATE);
              DBG('l_rateflg :::: ' || L_RATEFLG);
              IF NOT CYPKS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                      L_TXN_CCY,
                                      PKG_LCY,
                                      'STANDARD',
                                      'M',
                                      L_TXN_RATE,
                                      L_RATEFLG,
                                      L_ERR_CODE) THEN
                DBG('Failed in fn_getRate for CALL1....' || L_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
              DBG('THe package lcy with rate null is:' || PKG_LCY ||
                  ' with rate as :' || L_TXN_RATE);
            
            END IF;
          
          END IF;
        END IF;
      END IF;
      IF L_OFS_CCY <> PKG_LCY THEN
        L_OFS_FCY := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        IF L_TXN_CCY = PKG_LCY THEN
          L_OFS_RATE := PKG_RTL_TELLER_REC.EXCH_RATE;
          L_OFS_LCY  := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        ELSIF L_OFS_CCY = L_TXN_CCY THEN
          L_OFS_LCY  := L_TXN_LCY;
          L_OFS_RATE := L_TXN_RATE;
        ELSE
        
          IF NVL(PKG_RTL_TELLER_REC.LCY_EXCH_RATE, 0) > 0 THEN
            L_OFS_RATE := PKG_RTL_TELLER_REC.LCY_EXCH_RATE;
            L_OFS_FCY  := PKG_RTL_TELLER_REC.OFS_AMOUNT;
            IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                         L_OFS_CCY,
                                         PKG_LCY,
                                         'STANDARD',
                                         'M',
                                         L_OFS_FCY,
                                         'Y',
                                         L_OFS_LCY,
                                         L_OFS_RATE,
                                         L_ERR_CODE) THEN
              DBG('Bombed with amt1_to_amt2 b/w ' || L_OFS_CCY || ' and ' ||
                  PKG_LCY);
              DBG('Values passed where ' || L_OFS_FCY || ' and ' ||
                  L_OFS_RATE);
              P_RET := -1;
              RETURN;
            END IF;
          ELSE
          
            L_OFS_LCY := L_TXN_LCY;
          
            DBG('before call5pkg_rtl_teller_rec.ofs_amount : ' ||
                PKG_RTL_TELLER_REC.OFS_AMOUNT);
            DBG('before call5 l_txn_lcy : ' || L_TXN_LCY);
          
            IF PKG_RTL_TELLER_REC.OFS_AMOUNT <> 0 AND L_TXN_LCY <> 0 THEN
            
              DBG('THe package off ccy is:' || PKG_LCY ||
                  ' with ofs rate as :' || L_OFS_RATE);
            
              IF NOT CYPKS.FN_AMT_TO_RATE(L_OFS_CCY,
                                          PKG_LCY,
                                          PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                          L_TXN_LCY,
                                          L_OFS_RATE) THEN
                DBG('Bombed with getting exch rate b/w ' || L_OFS_CCY ||
                    ' and ' || PKG_LCY);
                DBG('Amts passed where ' || PKG_RTL_TELLER_REC.OFS_AMOUNT ||
                    ' and ' || L_TXN_LCY);
                P_RET := -1;
                RETURN;
              END IF;
            
            ELSE
            
              DBG('Inside CALL5 ELSE');
              DBG('Pkg_Rtl_Teller_Rec.Branch_Code ::: ' ||
                  PKG_RTL_TELLER_REC.BRANCH_CODE);
              DBG('l_Txn_Ccy :::: ' || L_OFS_CCY);
              DBG('Pkg_Lcy:::: ' || PKG_LCY);
              DBG('l_Txn_Rate :::: ' || L_OFS_RATE);
              DBG('l_rateflg :::: ' || L_RATEFLG);
              IF NOT CYPKS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                      L_OFS_CCY,
                                      PKG_LCY,
                                      'STANDARD',
                                      'M',
                                      L_OFS_RATE,
                                      L_RATEFLG,
                                      L_ERR_CODE) THEN
                DBG('Failed in fn_getRate for CALL2....' || L_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
              DBG('THe package off ccy with rate null is:' || PKG_LCY ||
                  ' with ofs rate as :' || L_OFS_RATE);
            
            END IF;
          
          END IF;
        END IF;
      END IF;
    
      DBG('The transaction currency before exchange rate assignment is:' ||
          L_TXN_CCY);
      DBG('The offset currency before exchange rate assignment is:' ||
          L_OFS_CCY);
      DBG('The Local currency before exchange rate assignment is:' ||
          PKG_LCY);
      IF L_TXN_CCY <> PKG_LCY THEN
        PKG_RTL_TELLER_REC.LCY_EXCH_RATE := NVL(PKG_RTL_TELLER_REC.LCY_EXCH_RATE,
                                                PKG_TXN_EXCH_RATE);
      ELSE
        PKG_RTL_TELLER_REC.LCY_EXCH_RATE := 1;
      END IF;
      DBG('The LCY Exchange rate to be set in rtl teller record is:' ||
          PKG_RTL_TELLER_REC.LCY_EXCH_RATE);
    
    END PR_GET_AMOUNTS;
  BEGIN
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DBG('calling depks_rtl_teller_custom.fn_save');
      DEPKS_RTL_TELLER_CLUSTER.PR_PRE_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                           P_RET,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA);
      DBG('24570969##p_ret--> ' || P_RET);
      IF P_RET = -1 THEN
        DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
        RETURN;
      END IF;
    END IF;
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      DBG('pkg_rtl_teller_rec.ofs_amount :' ||
          PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('pkg_rtl_teller_rec.txn_amount :' ||
          PKG_RTL_TELLER_REC.TXN_AMOUNT);
      PKG_RTL_TELLER_REC.OFS_AMOUNT := NVL(PKG_RTL_TELLER_REC.OFS_AMOUNT, 0);
      PKG_RTL_TELLER_REC.TXN_AMOUNT := NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0);
      DBG('pkg_rtl_teller_rec.ofs_amount 2:' ||
          PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('pkg_rtl_teller_rec.txn_amount 2:' ||
          PKG_RTL_TELLER_REC.TXN_AMOUNT);
      IF PKG_RTL_TELLER_REC.OFS_AMOUNT != 0 OR
         PKG_RTL_TELLER_REC.TXN_AMOUNT != 0 THEN
        DBG('2nd insdie if');
      
        P_ACC_HAND(1) := L_EMPTY_REC;
        P_ACC_HAND(1).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
        P_ACC_HAND(1).MIS_HEAD := PKG_RTL_TELLER_REC.MIS_HEAD;
        P_ACC_HAND(1).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
        P_ACC_HAND(1).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
        P_ACC_HAND(1).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE, 'INIT');
        P_ACC_HAND(1).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
        DBG('related account:' ||
            CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT);
        P_ACC_HAND(1).RELATED_ACCOUNT := CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT;
        P_ACC_HAND(1).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
      
        IF PKG_RTL_TELLER_REC.PRODUCT_CODE IS NOT NULL THEN
          DBG('pkg_rtl_teller_rec.product_code' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          P_ACC_HAND(1).PRODUCT := PKG_RTL_TELLER_REC.PRODUCT_CODE;
          P_ACC_HAND(2).PRODUCT := PKG_RTL_TELLER_REC.PRODUCT_CODE;
        
        END IF;
      
        IF PKG_DR_VAL_DT IS NOT NULL THEN
          P_ACC_HAND(1).VALUE_DT := PKG_DR_VAL_DT;
          DBG('Assigning the debit date =' || PKG_DR_VAL_DT);
        ELSE
          P_ACC_HAND(1).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
        END IF;
      
        P_ACC_HAND(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        P_ACC_HAND(1).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
      
        P_ACC_HAND(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
        P_ACC_HAND(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
      
        P_ACC_HAND(1).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
        P_ACC_HAND(2).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
        DBG('Assigned the Xref to the main legs ' ||
            PKG_RTL_TELLER_REC.XREF);
      
        P_ACC_HAND(1).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
        P_ACC_HAND(2).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
      
        P_ACC_HAND(1).NETTING_IND := 'N';
        P_ACC_HAND(1).DRCR_IND := 'D';
        P_ACC_HAND(1).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
      
        DBG('Dr Acc ' || PKG_ARC_ROW.DR_ACC);
        PR_GET_AMOUNTS(P_RET);
        IF P_RET = -1 THEN
          DBG('Bombed in pr get amounts');
          RETURN;
        END IF;
      
        DBG('l_txn_ccy ' || L_TXN_CCY);
        DBG('pkg_lcy ' || PKG_LCY);
        DBG('l_ofs_ccy ' || L_OFS_CCY);
        DBG('l_txn_lcy ' || L_TXN_LCY);
        DBG('l_txn_fcy ' || L_TXN_FCY);
        DBG('l_txn_rate ' || L_TXN_RATE);
        DBG('l_ofs_lcy ' || L_OFS_LCY);
        DBG('l_ofs_fcy ' || L_OFS_FCY);
        DBG('l_ofs_rate ' || L_OFS_RATE);
      
        IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID := 3;
          L_TB_CLUSTER_DATA('L_BRN') := L_BRN;
          L_TB_CLUSTER_DATA('L_TXN_LCY') := L_TXN_LCY;
          L_TB_CLUSTER_DATA('PKG_LCY') := PKG_LCY;
          L_TB_CLUSTER_DATA('L_OFS_LCY') := L_OFS_LCY;
          L_TB_CLUSTER_DATA('L_OFS_FCY') := L_OFS_FCY;
          L_TB_CLUSTER_DATA('L_OFS_RATE') := L_OFS_RATE;
          DBG('b4 calling depks_rtl_teller_cluster.pr_build_acctng_entries');
          DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                            P_RET,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA);
          IF P_RET = -1 THEN
            DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                L_FN_CALL_ID);
            RETURN;
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('L_BRN') THEN
            L_BRN := L_TB_CLUSTER_DATA('L_BRN');
          END IF;
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
            P_ACC_HAND(1).TRN_CODE := PKG_RTL_TELLER_REC.TXN_TRN_CODE;
            P_ACC_HAND(1).AMOUNT_TAG := 'TXN_AMT';
            IF PKG_ARC_ROW.COD_TXN_BRN = '*.*' THEN
              L_BRN := GLOBAL.CURRENT_BRANCH;
            ELSE
              L_BRN := PKG_ARC_ROW.COD_TXN_BRN;
            END IF;
            P_ACC_HAND(1).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                           L_BRN);
            P_ACC_HAND(1).AC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
          
            IF NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
               NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
               NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1001' THEN
              P_ACC_HAND(1).AC_NO := NVL(PKG_ARC_ROW.COD_TXN_ACCOUNT,
                                         PKG_RTL_TELLER_REC.TXN_ACC);
            
            ELSE
            
              P_ACC_HAND(1).AC_NO := NVL(PKG_RTL_TELLER_REC.TXN_ACC,
                                         PKG_ARC_ROW.COD_TXN_ACCOUNT);
            END IF;
            P_ACC_HAND(1).FCY_AMOUNT := L_TXN_FCY;
            P_ACC_HAND(1).LCY_AMOUNT := L_TXN_LCY;
            P_ACC_HAND(1).EXCH_RATE := L_TXN_RATE;
          
            DBG('p_acc_hand(1).ac_no in TXN is ' || P_ACC_HAND(1).AC_NO);
            DBG('p_acc_hand(1).ac_branch in TXN is ' || P_ACC_HAND(1)
                .AC_BRANCH);
          ELSE
            P_ACC_HAND(1).TRN_CODE := PKG_RTL_TELLER_REC.OFS_TRN_CODE;
            P_ACC_HAND(1).AMOUNT_TAG := 'OFS_AMT';
            IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
              L_BRN := GLOBAL.CURRENT_BRANCH;
            ELSE
              L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
            END IF;
          
            P_ACC_HAND(1).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                           L_BRN);
          
            P_ACC_HAND(1).AC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
          
            P_ACC_HAND(1).AC_NO := NVL(PKG_RTL_TELLER_REC.OFS_ACC,
                                       PKG_ARC_ROW.COD_OFFSET_ACC);
            P_ACC_HAND(1).FCY_AMOUNT := L_OFS_FCY;
            P_ACC_HAND(1).LCY_AMOUNT := L_OFS_LCY;
            P_ACC_HAND(1).EXCH_RATE := L_OFS_RATE;
            DBG('p_acc_hand(1).ac_no in OFS is ' || P_ACC_HAND(1).AC_NO);
            DBG('p_acc_hand(1).ac_branch in OFS is ' || P_ACC_HAND(1)
                .AC_BRANCH);
          END IF;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 101;
          DBG('b4 calling depks_rtl_teller_cluster.pr_build_acctng_entries');
          DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                            P_RET,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA);
          IF P_RET = -1 THEN
            DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                L_FN_CALL_ID);
            RETURN;
          END IF;
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          BEGIN
            SELECT AC_OR_GL
              INTO L_AC_OR_GL
              FROM STTBS_ACCOUNT
             WHERE NVL(BRANCH_CODE, P_ACC_HAND(1).AC_BRANCH) = P_ACC_HAND(1)
                  .AC_BRANCH
               AND AC_GL_NO = P_ACC_HAND(1).AC_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_AC_OR_GL := 'X';
          END;
          BEGIN
            SELECT NVL(TRACK_RECEIVABLE, 'N')
              INTO L_ACCOUNT_TRACKING_ALLOWED
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = P_ACC_HAND(1).AC_NO
               AND BRANCH_CODE = P_ACC_HAND(1).AC_BRANCH;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_ACCOUNT_TRACKING_ALLOWED := 'X';
          END;
        
          BEGIN
            SELECT NVL(TRACK_RECEIVABLE, 'N')
              INTO L_TRACK_RECEIVABLE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
          EXCEPTION
          
            WHEN NO_DATA_FOUND THEN
              DBG('No data found for the record.. SETTING l_track_receivable to N ');
              L_TRACK_RECEIVABLE := 'N';
            
            WHEN OTHERS THEN
              DBG('It  Failed during selecting track_receivable from detb_rtl_teller with -->' ||
                  SQLERRM);
              DBG('Txn Ref No is --->' || PKG_RTL_TELLER_REC.TRN_REF_NO);
              P_RET := -1;
              RETURN;
          END;
          DBG('here l_track_receivable ' || L_TRACK_RECEIVABLE);
          DBG('Here pkg_rtl_teller_rec.trn_ref_no ' ||
              PKG_RTL_TELLER_REC.TRN_REF_NO);
          BEGIN
            SELECT AMOUNT_DUE, AMOUNT_AVAILABLE, ACCOUNT_NO, ACCOUNT_BR
              INTO L_AMOUNTDUE_FORTXN,
                   L_AMOUNTAVL_FORTXN,
                   L_TXN_ACC,
                   L_ACC_BR
              FROM CSTB_AUTO_SETTLE_BLOCK
             WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
               AND COMPONENT = 'TRANSACTION';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_AMOUNTDUE_FORTXN := 0;
              L_AMOUNTAVL_FORTXN := 0;
          END;
          DBG('Before Select for Charge in cstb_auto_settle_block ');
        
          DBG('pkg_rtl_teller_rec.txn_acc -->>> ' ||
              PKG_RTL_TELLER_REC.TXN_ACC);
          BEGIN
            L_AMOUNTDUE_FORCHG := 0;
            L_AMOUNTAVL_FORCHG := 0;
            FOR EACH_REC IN (SELECT *
                               FROM CSTB_AUTO_SETTLE_BLOCK
                              WHERE CONTRACT_REF_NO =
                                    PKG_RTL_TELLER_REC.TRN_REF_NO
                                AND COMPONENT = 'CHARGE') LOOP
            
              DBG('loop starts');
              IF (EACH_REC.ACCOUNT_NO = L_TXN_ACC) AND
                 (EACH_REC.ACCOUNT_BR = L_ACC_BR) THEN
                L_AMOUNTDUE_FORCHG := EACH_REC.AMOUNT_DUE;
                L_AMOUNTAVL_FORCHG := EACH_REC.AMOUNT_AVAILABLE;
              ELSE
                L_AMOUNTOFSDUE_FORCHG := EACH_REC.AMOUNT_DUE;
                L_AMOUNTOFSAVL_FORCHG := EACH_REC.AMOUNT_AVAILABLE;
              END IF;
            END LOOP;
          EXCEPTION
            WHEN OTHERS THEN
            
              DBG('Error occured as : ' || SQLERRM);
              L_AMOUNTDUE_FORCHG := 0;
              L_AMOUNTAVL_FORCHG := 0;
          END;
        
          DBG('--------Transaction------------');
          DBG('l_amountdue_fortxn ' || L_AMOUNTDUE_FORTXN);
          DBG('l_amountavl_fortxn ' || L_AMOUNTAVL_FORTXN);
          DBG('--------Charge------------');
          DBG('l_amountdue_forchg ' || L_AMOUNTDUE_FORCHG);
          DBG('l_amountavl_forchg ' || L_AMOUNTAVL_FORCHG);
        
          IF NVL(L_TRACK_RECEIVABLE, 'N') = 'Y'
            
             AND (L_AMOUNTAVL_FORTXN + L_AMOUNTAVL_FORCHG) >=
             (L_AMOUNTDUE_FORTXN + L_AMOUNTDUE_FORCHG) AND
             (L_AMOUNTOFSAVL_FORCHG >= L_AMOUNTOFSDUE_FORCHG) THEN
            DBG('This is a Batch Liquidtion Call Dnt Track again ');
            PKG_IS_TRACK_REQURD := 'N';
          END IF;
          DBG('pkg_is_track_requrd ' || PKG_IS_TRACK_REQURD);
          IF NVL(PKG_IS_TRACK_REQURD, 'Y') = 'Y' THEN
          
            DBG('ac_or gl is' || L_AC_OR_GL || ' - track receivable is ' ||
                PKG_RTL_TELLER_REC.TRACK_RECEIVABLE);
            IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
               L_AC_OR_GL = 'A' AND L_ACCOUNT_TRACKING_ALLOWED = 'Y' THEN
              DBG('inside the condn...will be checking for available balance now');
              IF NOT ACPKSS_MISC.FN_GETAVLBAL(P_ACC_HAND(1).AC_BRANCH,
                                              P_ACC_HAND(1).AC_NO,
                                              LBAL,
                                              'Y') THEN
                DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
              END IF;
              DBG('lbal is ' || LBAL);
              DBG('pkg_rtl_teller_rec.txn_amount is ' ||
                  PKG_RTL_TELLER_REC.TXN_AMOUNT);
              IF LBAL < NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0) THEN
              
                G_TRACK_ACCOUNT_ENTRIES := 'Y';
                BEGIN
                  INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
                    (MODULE,
                     PRODUCT,
                     CONTRACT_REF_NO,
                     COMPONENT,
                     BOOK_DATE,
                     ACCOUNT_NO,
                     ACCOUNT_BR,
                     AMOUNT_DUE,
                     AMOUNT_PAID,
                     AMOUNT_AVAILABLE,
                     AUTO_MANUAL,
                     STATUS,
                     AMTDUE_TAGCCY,
                     AMTPAID_TAGCCY)
                  VALUES
                    ('RT',
                     PKG_RTL_TELLER_REC.PRODUCT_CODE,
                     PKG_RTL_TELLER_REC.TRN_REF_NO,
                     'TRANSACTION',
                     PKG_RTL_TELLER_REC.VALUE_DT,
                     P_ACC_HAND(1).AC_NO,
                     P_ACC_HAND(1).AC_BRANCH,
                     NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0),
                     0
                     
                    ,
                     
                     LBAL,
                     NULL,
                     'U',
                     NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0),
                     0);
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('in exception...will update cstb_auto_settle_block instead');
                    UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
                       SET AMOUNT_DUE    = AMOUNT_DUE + NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                                            0),
                           AMTDUE_TAGCCY = AMTDUE_TAGCCY +
                                           NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                               0),
                           
                           AMOUNT_AVAILABLE = LBAL
                     WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
                       AND ACCOUNT_NO = P_ACC_HAND(1).AC_NO
                       AND COMPONENT = 'TRANSACTION';
                END;
                PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
                RAISE ACCENTRIES_NOT_TO_BE_PASSED;
              ELSE
              
                PKG_RTL_TELLER_REC.RECORD_STAT := 'A';
              END IF;
            END IF;
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          PKG_RECIVABLE_AMT_DET.TXN_AC_OR_GL          := L_AC_OR_GL;
          PKG_RECIVABLE_AMT_DET.TXN_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        
          P_ACC_HAND(2) := L_EMPTY_REC;
          P_ACC_HAND(2) := P_ACC_HAND(1);
        
          IF PKG_CR_VAL_DT IS NOT NULL THEN
            P_ACC_HAND(2).VALUE_DT := PKG_CR_VAL_DT;
            DBG('Assigning the credit date =' || PKG_CR_VAL_DT);
          END IF;
        
          DBG('The credit instrument code 1 is:' ||
              PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE);
          DBG('The debit instrument code 1 is:' ||
              PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
          P_ACC_HAND(2).INSTRUMENT_CODE := NVL(PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE,
                                               PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
        
          IF P_ACC_HAND(1).INSTRUMENT_CODE IS NULL AND P_ACC_HAND(2)
             .INSTRUMENT_CODE IS NOT NULL THEN
            P_ACC_HAND(1).INSTRUMENT_CODE := P_ACC_HAND(2).INSTRUMENT_CODE;
          END IF;
        
          P_ACC_HAND(2).DRCR_IND := 'C';
        
          IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
            GLOBAL.PR_RESET_SKIP_KERNEL;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID := 2;
            L_TB_CLUSTER_DATA('L_BRN') := L_BRN;
            L_TB_CLUSTER_DATA('L_TXN_LCY') := L_TXN_LCY;
            L_TB_CLUSTER_DATA('PKG_LCY') := PKG_LCY;
            L_TB_CLUSTER_DATA('L_OFS_LCY') := L_OFS_LCY;
            L_TB_CLUSTER_DATA('L_OFS_FCY') := L_OFS_FCY;
            L_TB_CLUSTER_DATA('L_OFS_RATE') := L_OFS_RATE;
            DBG('b4 calling depks_rtl_teller_cluster.pr_build_acctng_entries');
            DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                              P_RET,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA);
            IF P_RET = -1 THEN
              DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                  L_FN_CALL_ID);
              RETURN;
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('L_BRN') THEN
              L_BRN := L_TB_CLUSTER_DATA('L_BRN');
            END IF;
          END IF;
        
          IF NOT GLOBAL.G_SKIP_KERNEL THEN
          
            IF PKG_ARC_ROW.DR_ACC <> 'TXN' THEN
              P_ACC_HAND(2).TRN_CODE := PKG_RTL_TELLER_REC.TXN_TRN_CODE;
              P_ACC_HAND(2).AMOUNT_TAG := 'TXN_AMT';
              IF PKG_ARC_ROW.COD_TXN_BRN = '*.*' THEN
                L_BRN := GLOBAL.CURRENT_BRANCH;
              ELSE
                L_BRN := PKG_ARC_ROW.COD_TXN_BRN;
              END IF;
              P_ACC_HAND(2).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                             L_BRN);
              P_ACC_HAND(2).AC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            
              P_ACC_HAND(2).AC_NO := NVL(PKG_ARC_ROW.COD_TXN_ACCOUNT,
                                         PKG_RTL_TELLER_REC.TXN_ACC);
            
              P_ACC_HAND(2).FCY_AMOUNT := L_TXN_FCY;
              P_ACC_HAND(2).LCY_AMOUNT := L_TXN_LCY;
              P_ACC_HAND(2).EXCH_RATE := L_TXN_RATE;
            
            ELSE
              P_ACC_HAND(2).TRN_CODE := PKG_RTL_TELLER_REC.OFS_TRN_CODE;
              P_ACC_HAND(2).AMOUNT_TAG := 'OFS_AMT';
              IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
                L_BRN := GLOBAL.CURRENT_BRANCH;
              ELSE
                L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
              END IF;
              P_ACC_HAND(2).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                             L_BRN);
              P_ACC_HAND(2).AC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              P_ACC_HAND(2).AC_NO := NVL(PKG_RTL_TELLER_REC.OFS_ACC,
                                         PKG_ARC_ROW.COD_OFFSET_ACC);
              P_ACC_HAND(2).FCY_AMOUNT := L_OFS_FCY;
              P_ACC_HAND(2).LCY_AMOUNT := L_OFS_LCY;
              P_ACC_HAND(2).EXCH_RATE := L_OFS_RATE;
            END IF;
          
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 102;
            DBG('b4 calling depks_rtl_teller_cluster.pr_build_acctng_entries');
            DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                              P_RET,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA);
            IF P_RET = -1 THEN
              DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                  L_FN_CALL_ID);
              RETURN;
            END IF;
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 1;
          DBG('Calling depks_rtl_teller_custom.fn_save');
          DEPKS_RTL_TELLER_CLUSTER.PR_BUILD_ACCTNG_ENTRIES(P_ACC_HAND,
                                                           P_RET,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA);
          IF P_RET = -1 THEN
            DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
            RETURN;
          
          END IF;
        END IF;
      
      END IF;
      PKG_MAIN_ENTRIES_BUILT := TRUE;
    END IF;
  EXCEPTION
    WHEN ACCENTRIES_NOT_TO_BE_PASSED THEN
      P_RET := 2;
      DBG('returning 2 to fn_save from pr_build_acctng_entries ..no entries will be passed for this contract.Uninitiated');
    WHEN OTHERS THEN
      DBG('Err is ' || SQLERRM);
      P_RET := -1;
  END PR_BUILD_ACCTNG_ENTRIES;

  PROCEDURE PR_BUILD_CLOSE_AC_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                      P_RET      IN OUT NUMBER) IS
    L_EMPTY_REC ACTBS_HANDOFF%ROWTYPE;
    L_BRN       STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_TXN_FCY   NUMBER;
    L_TXN_LCY   NUMBER;
    L_TXN_RATE  NUMBER;
    L_OFS_FCY   NUMBER;
    L_OFS_LCY   NUMBER;
    L_OFS_RATE  NUMBER;
    L_TXN_CCY   VARCHAR2(3);
    L_OFS_CCY   VARCHAR2(3);
    L_ROW       NUMBER := 1;
    PROCEDURE PR_GET_AMOUNTS(P_RET IN OUT NUMBER) IS
      L_ERR_CODE VARCHAR2(256);
      L_RATEFLG  NUMBER;
    BEGIN
      DBG('----Inside pr_get_amounts----');
      L_TXN_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
      L_OFS_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
      DBG('Transaction currency :: l_txn_ccy :: ' || L_TXN_CCY);
      DBG('Offset currency :: l_ofs_ccy :: ' || L_OFS_CCY);
      DBG('Local currency :: pkg_lcy :: ' || PKG_LCY);
      DBG('Transaction amount :: pkg_rtl_teller_rec.txn_amount :: ' ||
          PKG_RTL_TELLER_REC.TXN_AMOUNT);
      DBG('Offset amount :: pkg_rtl_teller_rec.ofs_amount :: ' ||
          PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('Exchange rate :: pkg_rtl_teller_rec.exch_rate :: ' ||
          PKG_RTL_TELLER_REC.EXCH_RATE);
      DBG('Exchange rate :: pkg_rtl_teller_rec.exch_rate :: ' ||
          PKG_RTL_TELLER_REC.EXCH_RATE);
      DBG('Local currency amount :: pkg_rtl_teller_rec.lcy_amount :: ' ||
          PKG_RTL_TELLER_REC.LCY_AMOUNT);
      IF L_TXN_CCY = PKG_LCY THEN
        L_TXN_FCY  := NULL;
        L_TXN_LCY  := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        L_TXN_RATE := NULL;
      END IF;
      IF L_OFS_CCY = PKG_LCY THEN
        L_OFS_LCY  := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        L_OFS_FCY  := NULL;
        L_OFS_RATE := NULL;
      END IF;
      IF L_TXN_CCY <> PKG_LCY THEN
        L_TXN_FCY := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        IF L_OFS_CCY = PKG_LCY THEN
          L_TXN_RATE := PKG_RTL_TELLER_REC.EXCH_RATE;
          L_TXN_LCY  := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        ELSE
          DBG('Came here for getting the txn rate');
          L_TXN_LCY := PKG_RTL_TELLER_REC.LCY_AMOUNT;
        
          DBG('before call6  pkg_rtl_teller_rec.txn_amount : ' ||
              PKG_RTL_TELLER_REC.TXN_AMOUNT);
          DBG('before call6 l_txn_lcy : ' || L_TXN_LCY);
        
          IF PKG_RTL_TELLER_REC.TXN_AMOUNT <> 0 AND L_TXN_LCY <> 0 THEN
          
            DBG('THe package txn lcy is:' || PKG_LCY || ' with rate as :' ||
                L_TXN_RATE);
          
            IF L_OFS_CCY = L_TXN_CCY THEN
              DBG('The pre calculated exchange rate is:' ||
                  PKG_TXN_EXCH_RATE);
              L_TXN_RATE := PKG_TXN_EXCH_RATE;
              L_TXN_LCY  := NULL;
              IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                           L_TXN_CCY,
                                           PKG_LCY,
                                           'STANDARD',
                                           'M',
                                           L_TXN_FCY,
                                           'Y',
                                           L_TXN_LCY,
                                           L_TXN_RATE,
                                           L_ERR_CODE) THEN
                DBG('Bombed with amt1_to_amt2 b/w ' || L_TXN_CCY ||
                    ' and ' || PKG_LCY);
                DBG('Values passed where ' || L_TXN_FCY || ' and ' ||
                    L_TXN_RATE || ' and branch as:' ||
                    GLOBAL.CURRENT_BRANCH);
                P_RET := -1;
                RETURN;
              END IF;
            ELSE
            
              IF NOT CYPKS.FN_AMT_TO_RATE(L_TXN_CCY,
                                          PKG_LCY,
                                          PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                          L_TXN_LCY,
                                          L_TXN_RATE) THEN
                DBG('Bombed with getting exch rate b/w ' || L_TXN_CCY ||
                    ' and ' || PKG_LCY);
                DBG('Amts passed where ' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
                    ' and ' || L_TXN_LCY);
                P_RET := -1;
                RETURN;
              END IF;
            END IF;
          
          ELSE
          
            DBG('Inside CALL6 ELSE');
            DBG('Pkg_Rtl_Teller_Rec.Branch_Code ::: ' ||
                PKG_RTL_TELLER_REC.BRANCH_CODE);
            DBG('l_Txn_Ccy :::: ' || L_TXN_CCY);
            DBG('Pkg_Lcy:::: ' || PKG_LCY);
            DBG('l_Txn_Rate :::: ' || L_TXN_RATE);
            DBG('l_rateflg :::: ' || L_RATEFLG);
            DBG('pkg_prod.rate_code_preferred ::: ' ||
                PKG_PROD.RATE_CODE_PREFERRED);
            DBG('pkg_prod.rate_type_preferred :::: ' ||
                PKG_PROD.RATE_TYPE_PREFERRED);
          
            IF PKG_RTL_TELLER_REC.TXN_AMOUNT > 0 THEN
            
              IF NOT CYPKS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                      L_TXN_CCY,
                                      PKG_LCY,
                                      'STANDARD',
                                      'M',
                                      L_TXN_RATE,
                                      L_RATEFLG,
                                      L_ERR_CODE) THEN
                DBG('Failed in fn_getRate for CALL3.... ' || L_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
              DBG('compare pkg_rtl_teller_rec.txn_amount else part-1.' ||
                  PKG_RTL_TELLER_REC.TXN_AMOUNT);
            END IF;
          
            DBG('THe package lcy with txn rate null is:' || PKG_LCY ||
                ' with rate as :' || L_TXN_RATE);
          
          END IF;
        
          DBG('The l_txn_rate which is coming from cypks ::::::: ' ||
              L_TXN_RATE);
          IF DEPKS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' AND L_TXN_RATE < 0 THEN
            DBG('Came here when l_txn_rate :: ' || L_TXN_RATE ||
                ' is negative');
            L_TXN_RATE := -L_TXN_RATE;
          END IF;
        
        END IF;
      END IF;
      IF L_OFS_CCY <> PKG_LCY THEN
        L_OFS_FCY := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        IF L_TXN_CCY = PKG_LCY THEN
          L_OFS_RATE := PKG_RTL_TELLER_REC.EXCH_RATE;
          L_OFS_LCY  := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        ELSIF L_OFS_CCY = L_TXN_CCY THEN
          L_OFS_LCY  := L_TXN_LCY;
          L_OFS_RATE := L_TXN_RATE;
        ELSE
          DBG('Came here for getting the ofs rate');
          L_OFS_LCY := L_TXN_LCY;
        
          DBG('before call7 pkg_rtl_teller_rec.ofs_amount : ' ||
              PKG_RTL_TELLER_REC.OFS_AMOUNT);
          DBG('before call7 l_txn_lcy : ' || L_TXN_LCY);
        
          IF PKG_RTL_TELLER_REC.OFS_AMOUNT <> 0 AND L_TXN_LCY <> 0 THEN
          
            DBG('THe package lcy in cal 7 is:' || PKG_LCY ||
                ' with ofs rate as :' || L_OFS_RATE);
          
            IF NOT CYPKS.FN_AMT_TO_RATE(L_OFS_CCY,
                                        PKG_LCY,
                                        PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                        L_TXN_LCY,
                                        L_OFS_RATE) THEN
              DBG('Bombed with getting exch rate b/w ' || L_OFS_CCY ||
                  ' and ' || PKG_LCY);
              DBG('Amts passed where ' || PKG_RTL_TELLER_REC.OFS_AMOUNT ||
                  ' and ' || L_TXN_LCY);
              P_RET := -1;
              RETURN;
            END IF;
          
          ELSE
          
            DBG('Inside CALL7 ELSE');
            DBG('Pkg_Rtl_Teller_Rec.Branch_Code ::: ' ||
                PKG_RTL_TELLER_REC.BRANCH_CODE);
            DBG('l_Txn_Ccy :::: ' || L_OFS_CCY);
            DBG('Pkg_Lcy:::: ' || PKG_LCY);
            DBG('l_Txn_Rate :::: ' || L_OFS_RATE);
            DBG('l_rateflg :::: ' || L_RATEFLG);
            DBG('pkg_prod.rate_code_preferred ::: ' ||
                PKG_PROD.RATE_CODE_PREFERRED);
            DBG('pkg_prod.rate_type_preferred :::: ' ||
                PKG_PROD.RATE_TYPE_PREFERRED);
            IF NOT CYPKS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                    L_OFS_CCY,
                                    PKG_LCY,
                                    'STANDARD',
                                    'M',
                                    L_OFS_RATE,
                                    L_RATEFLG,
                                    L_ERR_CODE) THEN
              DBG('Failed in fn_getRate for CALL4.... ' || L_ERR_CODE);
              P_RET := -1;
              RETURN;
            END IF;
            DBG('THe package lcy with txn rate null is:' || PKG_LCY ||
                ' with rate as :' || L_OFS_RATE);
          
          END IF;
        
        END IF;
      END IF;
    END PR_GET_AMOUNTS;
  BEGIN
  
    DBG('inside close_ac_entries');
    IF G_ROW IS NULL THEN
      DBG('g_row is null');
      IF P_ACC_HAND.EXISTS(P_ACC_HAND.COUNT) THEN
        G_ROW := P_ACC_HAND.COUNT + 1;
      ELSE
        DBG('Going to assign g_row as 1');
        G_ROW := 1;
      END IF;
    END IF;
  
    DBG('value of g_row-->' || G_ROW);
    P_ACC_HAND(G_ROW) := L_EMPTY_REC;
    P_ACC_HAND(G_ROW).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
    P_ACC_HAND(G_ROW).MIS_HEAD := PKG_RTL_TELLER_REC.MIS_HEAD;
    P_ACC_HAND(G_ROW).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
    P_ACC_HAND(G_ROW).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
    P_ACC_HAND(G_ROW).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE, 'INIT');
    P_ACC_HAND(G_ROW).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
    P_ACC_HAND(G_ROW).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
    P_ACC_HAND(G_ROW).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
    P_ACC_HAND(G_ROW).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
  
    P_ACC_HAND(G_ROW).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
  
    P_ACC_HAND(G_ROW).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
    IF CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT IS NOT NULL THEN
      DBG('Assigning the dbgrelated for closure builinidng;' ||
          CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT);
      P_ACC_HAND(G_ROW).RELATED_ACCOUNT := CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT;
    END IF;
  
    P_ACC_HAND(G_ROW).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
    P_ACC_HAND(G_ROW + 1).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID,
                                         GLOBAL.USER_ID);
  
    P_ACC_HAND(G_ROW).NETTING_IND := 'N';
    P_ACC_HAND(G_ROW).DRCR_IND := 'D';
    P_ACC_HAND(G_ROW).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
    DBG('Dr Acc ' || PKG_ARC_ROW.DR_ACC);
    PR_GET_AMOUNTS(P_RET);
    IF P_RET = -1 THEN
      DBG('Bombed in pr get amounts');
      RETURN;
    END IF;
    DBG('l_txn_ccy ' || L_TXN_CCY);
    DBG('pkg_lcy ' || PKG_LCY);
    DBG('l_ofs_ccy ' || L_OFS_CCY);
    DBG('l_txn_lcy ' || L_TXN_LCY);
    DBG('l_txn_fcy ' || L_TXN_FCY);
    DBG('l_txn_rate ' || L_TXN_RATE);
    DBG('l_ofs_lcy ' || L_OFS_LCY);
    DBG('l_ofs_fcy ' || L_OFS_FCY);
    DBG('l_ofs_rate ' || L_OFS_RATE);
    IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
      P_ACC_HAND(G_ROW).TRN_CODE := PKG_RTL_TELLER_REC.TXN_TRN_CODE;
      P_ACC_HAND(G_ROW).AMOUNT_TAG := 'TXN_AMT';
      IF PKG_ARC_ROW.COD_TXN_BRN = '*.*' THEN
        L_BRN := GLOBAL.CURRENT_BRANCH;
      ELSE
        L_BRN := PKG_ARC_ROW.COD_TXN_BRN;
      END IF;
      P_ACC_HAND(G_ROW).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                         L_BRN);
      P_ACC_HAND(G_ROW).AC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
      P_ACC_HAND(G_ROW).AC_NO := NVL(PKG_RTL_TELLER_REC.TXN_ACC,
                                     PKG_ARC_ROW.COD_TXN_ACCOUNT);
      P_ACC_HAND(G_ROW).FCY_AMOUNT := L_TXN_FCY;
      P_ACC_HAND(G_ROW).LCY_AMOUNT := L_TXN_LCY;
      P_ACC_HAND(G_ROW).EXCH_RATE := L_TXN_RATE;
    ELSE
      P_ACC_HAND(G_ROW).TRN_CODE := PKG_RTL_TELLER_REC.OFS_TRN_CODE;
      P_ACC_HAND(G_ROW).AMOUNT_TAG := 'OFS_AMT';
      IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
        L_BRN := GLOBAL.CURRENT_BRANCH;
      ELSE
        L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
      END IF;
      P_ACC_HAND(G_ROW).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                         L_BRN);
      P_ACC_HAND(G_ROW).AC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
      P_ACC_HAND(G_ROW).AC_NO := NVL(PKG_RTL_TELLER_REC.OFS_ACC,
                                     PKG_ARC_ROW.COD_OFFSET_ACC);
      P_ACC_HAND(G_ROW).FCY_AMOUNT := L_OFS_FCY;
      P_ACC_HAND(G_ROW).LCY_AMOUNT := L_OFS_LCY;
      P_ACC_HAND(G_ROW).EXCH_RATE := L_OFS_RATE;
    END IF;
  
    DBG('The debit leg account closure lcy amount is:' || P_ACC_HAND(G_ROW)
        .LCY_AMOUNT || ' with fcy ammount as:' || P_ACC_HAND(G_ROW)
        .FCY_AMOUNT);
    PKG_CLS_ACTAMT := NVL(P_ACC_HAND(G_ROW).FCY_AMOUNT,
                          P_ACC_HAND(G_ROW).LCY_AMOUNT);
    IF P_ACC_HAND(G_ROW).LCY_AMOUNT = 0 THEN
      P_ACC_HAND(G_ROW).AC_CCY := PKG_LCY;
      P_ACC_HAND(G_ROW).FCY_AMOUNT := 0;
      P_ACC_HAND(G_ROW).LCY_AMOUNT := 0;
      P_ACC_HAND(G_ROW).EXCH_RATE := NULL;
    END IF;
  
    P_ACC_HAND(G_ROW + 1) := L_EMPTY_REC;
    P_ACC_HAND(G_ROW + 1) := P_ACC_HAND(G_ROW);
    P_ACC_HAND(G_ROW + 1).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE;
    P_ACC_HAND(G_ROW + 1).DRCR_IND := 'C';
    IF PKG_ARC_ROW.DR_ACC <> 'TXN' THEN
      P_ACC_HAND(G_ROW + 1).TRN_CODE := PKG_RTL_TELLER_REC.TXN_TRN_CODE;
      P_ACC_HAND(G_ROW + 1).AMOUNT_TAG := 'TXN_AMT';
      IF PKG_ARC_ROW.COD_TXN_BRN = '*.*' THEN
        L_BRN := GLOBAL.CURRENT_BRANCH;
      ELSE
        L_BRN := PKG_ARC_ROW.COD_TXN_BRN;
      END IF;
      P_ACC_HAND(G_ROW + 1).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                             L_BRN);
      P_ACC_HAND(G_ROW + 1).AC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
      P_ACC_HAND(G_ROW + 1).AC_NO := NVL(PKG_RTL_TELLER_REC.TXN_ACC,
                                         PKG_ARC_ROW.COD_TXN_ACCOUNT);
      P_ACC_HAND(G_ROW + 1).FCY_AMOUNT := L_TXN_FCY;
      P_ACC_HAND(G_ROW + 1).LCY_AMOUNT := L_TXN_LCY;
      P_ACC_HAND(G_ROW + 1).EXCH_RATE := L_TXN_RATE;
    ELSE
      P_ACC_HAND(G_ROW + 1).TRN_CODE := PKG_RTL_TELLER_REC.OFS_TRN_CODE;
      P_ACC_HAND(G_ROW + 1).AMOUNT_TAG := 'OFS_AMT';
      IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
        L_BRN := GLOBAL.CURRENT_BRANCH;
      ELSE
        L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
      END IF;
      P_ACC_HAND(G_ROW + 1).AC_BRANCH := NVL(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                             L_BRN);
    
      BEGIN
        IF DEPKS_RTL_TELLER.PKG_ARC_ROW.DR_ACC <> 'TXN' AND
           GWPKS_TDREDEMPTION.G_BRNCODE IS NOT NULL AND
           GWPKS_UTIL.PKG_FUNC = '1317' THEN
          P_ACC_HAND(G_ROW + 1).AC_BRANCH := GWPKS_TDREDEMPTION.G_BRNCODE;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in TD redemption');
      END;
    
      P_ACC_HAND(G_ROW + 1).AC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
      P_ACC_HAND(G_ROW + 1).AC_NO := NVL(PKG_RTL_TELLER_REC.OFS_ACC,
                                         PKG_ARC_ROW.COD_OFFSET_ACC);
      P_ACC_HAND(G_ROW + 1).FCY_AMOUNT := L_OFS_FCY;
      P_ACC_HAND(G_ROW + 1).LCY_AMOUNT := L_OFS_LCY;
      P_ACC_HAND(G_ROW + 1).EXCH_RATE := L_OFS_RATE;
    END IF;
  
    DBG('The credit leg account closure lcy amount is:' || P_ACC_HAND(G_ROW + 1)
        .LCY_AMOUNT || ' with fcy ammount as:' || P_ACC_HAND(G_ROW + 1)
        .FCY_AMOUNT);
  
    IF GWPKSS_CLOSECUSTACC.G_ACTAMT < 0 OR
       NVL(GWPKS_UTIL.PKG_FUNC, '$') = '1301' THEN
      DBG('pkg_cls_actAmt before--> ' || PKG_CLS_ACTAMT || '~' ||
          'p_acc_hand(g_row+1).ac_ccy--> ' || P_ACC_HAND(G_ROW + 1).AC_CCY || '~' ||
          'pkg_lcy--> ' || PKG_LCY);
      IF P_ACC_HAND(G_ROW + 1).AC_CCY <> PKG_LCY THEN
        PKG_CLS_ACTAMT := NVL(P_ACC_HAND(G_ROW + 1).FCY_AMOUNT,
                              P_ACC_HAND(G_ROW + 1).LCY_AMOUNT);
      ELSE
        PKG_CLS_ACTAMT := NVL(P_ACC_HAND(G_ROW + 1).LCY_AMOUNT,
                              P_ACC_HAND(G_ROW + 1).FCY_AMOUNT);
      END IF;
    END IF;
  
    IF P_ACC_HAND(G_ROW + 1).LCY_AMOUNT = 0 THEN
      P_ACC_HAND(G_ROW + 1).AC_CCY := PKG_LCY;
      P_ACC_HAND(G_ROW + 1).FCY_AMOUNT := 0;
      P_ACC_HAND(G_ROW + 1).LCY_AMOUNT := 0;
      P_ACC_HAND(G_ROW + 1).EXCH_RATE := NULL;
    END IF;
  
    P_RET := 0;
    G_ROW := NULL;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Err is ' || SQLERRM);
      P_RET := -1;
  END PR_BUILD_CLOSE_AC_ENTRIES;

  PROCEDURE PR_BUILD_CHG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                 P_CHG_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                 I          IN NUMBER,
                                 P_ERR_CODE IN OUT VARCHAR2,
                                 P_RET      IN OUT NUMBER) IS
    L_ACC_CCY_CHG        NUMBER(22, 3);
    L_ACC_CHG_EXCH_RATE  ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_COD_CHG_AMT        IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_COD_CHG_CCY        IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_COD_MIS_HEAD       IFTMS_ARC_MAINT.COD_MIS_HEAD1%TYPE;
    L_COD_CHG_TXN_CODE   IFTMS_ARC_MAINT.COD_CHG_TXN_CODE1%TYPE;
    L_COD_CHG_NETTING    IFTMS_ARC_MAINT.COD_CHG_NETTING1%TYPE;
    L_COD_CHG_GL         IFTMS_ARC_MAINT.COD_CHG_GL%TYPE;
    L_COD_RATE_CODE      IFTMS_ARC_MAINT.COD_RATE_CODE%TYPE;
    L_COD_RATE_CODE_TYPE IFTMS_ARC_MAINT.COD_RATE_CODE_TYPE%TYPE;
    L_CHG_ACC_CCY        IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_CHG_ACC            IFTMS_ARC_MAINT.COD_OFFSET_ACC%TYPE;
    L_CHG_ACC_BRN        IFTMS_ARC_MAINT.COD_OFFSET_BRN%TYPE;
    L_BRN                STTMS_BRANCH.BRANCH_CODE%TYPE;
    J                    NUMBER;
    L_CHG_LCY            NUMBER;
    L_LCY_CHG_EXCH_RATE  NUMBER;
    L_AC_OR_GL           STTBS_ACCOUNT.AC_OR_GL%TYPE;
  
    LBAL STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    ACCENTRIES_NOT_TO_BE_PASSED EXCEPTION;
    L_ACCOUNT_TRACKING_ALLOWED VARCHAR2(1);
    L_BRANCH                   STTMS_BRANCH.BRANCH_CODE%TYPE;
  
    L_THEIR_CHGS VARCHAR2(1);
    L_TEMP_CHG   NUMBER;
  
    L_CHG_TCY            NUMBER;
    L_TCY_CHG_EXCH_RATE  NUMBER;
    L_CHG_DESC           VARCHAR2(255);
    L_WAIVER             VARCHAR2(1);
    L_CHG_IN_TCY_CCY     VARCHAR2(3);
    L_LCY_CHG_EXCH_RATE1 NUMBER;
    L_PRODUCT_TYPE       CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_CHG_TYPE           VARCHAR2(1);
  
    L_PREDICTED_BAL STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
  
    L_TBL_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TBL_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_CHARGE_FLAG BOOLEAN := FALSE;
  
    L_COD_CHG_TRACK_PRF IFTMS_ARC_MAINT.COD_CHG_TRACK_PRF%TYPE;
    L_COD_CHG_LIQD_PRF  IFTMS_ARC_MAINT.COD_CHG_LIQD_PRF%TYPE;
    P_CHG_SEQ           NUMBER;
    P_COD_CHG_AMT_NSF   IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_COD_CHG_AMT_TEMP  IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_CHG_LCY_TEMP      NUMBER;
    L_CRDR_IND          CHAR;
  
    L_CHG_DR_LEG IFTMS_ARC_MAINT.CHG_DR_LEG%TYPE;
  
    L_ACC_CCY_CHG_TEMP       NUMBER(22, 3);
    L_ACC_CHG_EXCH_RATE_TEMP ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_COD_CHG_AMT_PRDTRACK   IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    LBAL2 STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
  
    L_PREDICTED_BAL_TEMP STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_ACCOUNT_TYPE       STTB_ACCOUNT.AC_OR_GL%TYPE;
  
  BEGIN
    DBG('To frame chg entries ' || I);
    DBG('Chg here is ' || P_CHG_ROW.COD_CHG_AMT);
    DBG('Coming here 1');
    DBG('skip accnt flag ->' || CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG ||
        '~Service charge g_action_code->' || CSPKSS_CHARGE.G_ACTION_CODE);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DBG('Calling depks_rtl_teller_custom.fn_save');
      DEPKS_RTL_TELLER_CLUSTER.PR_PRE_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                        P_CHG_ROW,
                                                        I,
                                                        P_RET,
                                                        P_ERR_CODE,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA);
      DBG('24570969##p_ret--> ' || P_RET);
      IF P_RET = -1 THEN
        DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
        RETURN;
      END IF;
    END IF;
    IF NOT DEPKS_RTL_TELLER.FN_SKIP_KERNEL THEN
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
        PR_CHG_PICKUP_REQD(TRUE);
      END IF;
    
      IF ICPKS_FCJ_ICDREDMN.G_TDREDEM_CHARGEPICKUP THEN
        DBG('icpks_fcj_icdredmn.g_tdredem_chargepickup IS TRUE');
      ELSE
        DBG('icpks_fcj_icdredmn.g_tdredem_chargepickup IS FALSE');
      END IF;
    
      IF PKG_CHG_PICKUP_REQD THEN
        DBG('pkg_chg_pickup_reqd IS TRUE');
      ELSE
        DBG('pkg_chg_pickup_reqd IS FALSE');
      END IF;
    
      IF GWPKS_ENRICHDDCONTRACTSERVICES.G_CHG_BY_CASH = 'Y' AND
         GWPKS_UTIL.PKG_FUNC = '8318' THEN
        DBG('-----Came here for 8318---------');
        DBG('Pkg_Rtl_Teller_Rec.Txn_Acc :::: ' ||
            PKG_RTL_TELLER_REC.TXN_ACC);
        DBG('p_chg_row.cod_txn_account :::: ' || P_CHG_ROW.COD_TXN_ACCOUNT);
      
        PKG_RTL_TELLER_REC.TXN_ACC := NVL(GWPKS_ENRICHDDCONTRACTSERVICES.G_TXN_ACC,
                                          P_CHG_ROW.COD_TXN_ACCOUNT);
      END IF;
    
      DBG('-----Came here for 8324 to check if charge by cash is Y ' ||
          DDPKS_UPLOAD_CONTRACT_CREATE.G_CHG_BY_CASH);
      IF (DDPKS_UPLOAD_CONTRACT_CREATE.G_CHG_BY_CASH = 'Y' AND
         GWPKS_UTIL.PKG_FUNC = '8324') THEN
        DBG('-----Came here for 8324--------- The product is ' ||
            PKG_RTL_TELLER_REC.PRODUCT_CODE);
        DBG('Pkg_Rtl_Teller_Rec.Txn_Acc :::: ' ||
            PKG_RTL_TELLER_REC.TXN_ACC);
        DBG('Pkg_Rtl_Teller_Rec.Txn_Acc :::: ' ||
            PKG_RTL_TELLER_REC.OFS_ACC);
        DBG('p_chg_row.cod_txn_account :::: ' || P_CHG_ROW.COD_TXN_ACCOUNT);
        DBG('g_txn_acc HERE IS  :::: ' ||
            GWPKS_ENRICHDDCONTRACTSERVICES.G_TXN_ACC);
        DBG('p_chg_row.cod_txn_account :::: ' || P_CHG_ROW.COD_OFFSET_ACC);
        IF P_CHG_ROW.COD_OFFSET_ACC IS NULL THEN
          DBG('-----The offset account is null over here .... for charge by cash, offset account cannot be null ---------');
          OVPKSS.PR_APPENDTBL('DE-TLR133', NULL);
          P_RET := -1;
          RETURN;
        
        END IF;
        DBG('Pkg_Rtl_Teller_Rec.Ofs_Acc :::: ' ||
            PKG_RTL_TELLER_REC.OFS_ACC);
        PKG_RTL_TELLER_REC.TXN_ACC := P_CHG_ROW.COD_OFFSET_ACC;
        DBG('Pkg_Rtl_Teller_Rec.cod_txn_account :::: ' ||
            PKG_RTL_TELLER_REC.OFS_ACC);
      END IF;
    
      IF PKG_CHG_PICKUP_REQD OR PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' OR
         CSPKS_CHARGE.G_CHARGE_PICKED = 'N' AND
         (PKG_RTL_TELLER_REC.SCODE IN ('FLEXCUBE', 'FLEXBRANCH') OR
         (P_CHG_ROW.COD_CHG_AMT IS NOT NULL OR
         P_CHG_ROW.COD_CHG_AMT1 IS NOT NULL OR
         P_CHG_ROW.COD_CHG_AMT2 IS NOT NULL OR
         P_CHG_ROW.COD_CHG_AMT3 IS NOT NULL OR
         P_CHG_ROW.COD_CHG_AMT4 IS NOT NULL))
      
       THEN
        IF I = 1 THEN
          DBG('Currency--> ' || P_CHG_ROW.COD_CHG_CCY);
          L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT;
          L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
          L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD1;
          L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE;
          L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING;
          L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL;
          L_THEIR_CHGS         := P_CHG_ROW.COD_THEIR_CHGS;
          L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC;
          L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE;
        
          PKG_RTL_TELLER_REC.CHG_AMT     := P_CHG_ROW.COD_CHG_AMT;
          PKG_RTL_TELLER_REC.CHG_CCY     := P_CHG_ROW.COD_CHG_CCY;
          PKG_RTL_TELLER_REC.MIS_HEAD_1  := P_CHG_ROW.COD_MIS_HEAD1;
          PKG_RTL_TELLER_REC.TXN_CODE    := P_CHG_ROW.COD_CHG_TXN_CODE;
          PKG_RTL_TELLER_REC.NETTING_IND := P_CHG_ROW.COD_CHG_NETTING;
          PKG_RTL_TELLER_REC.CHG_GL      := P_CHG_ROW.COD_CHG_GL;
          PKG_RTL_TELLER_REC.THEIR_CHGS  := P_CHG_ROW.COD_THEIR_CHGS;
          L_COD_CHG_TRACK_PRF            := P_CHG_ROW.COD_CHG_TRACK_PRF;
          L_COD_CHG_LIQD_PRF             := P_CHG_ROW.COD_CHG_LIQD_PRF;
        
          DBG('----The charge description values in pr_build_chg_entries------');
          DBG('p_chg_row.cod_chg_desc :: ' || P_CHG_ROW.COD_CHG_DESC);
          DBG('p_chg_row.cod_chg_desc1 :: ' || P_CHG_ROW.COD_CHG_DESC1);
          DBG('p_chg_row.cod_chg_desc2 :: ' || P_CHG_ROW.COD_CHG_DESC2);
          DBG('p_chg_row.cod_chg_desc3 :: ' || P_CHG_ROW.COD_CHG_DESC3);
          DBG('p_chg_row.cod_chg_desc4 :: ' || P_CHG_ROW.COD_CHG_DESC4);
          DBG('Assigning charge description values to pkg_rtl_teller_rec');
          PKG_RTL_TELLER_REC.CHG_DESC  := P_CHG_ROW.COD_CHG_DESC;
          PKG_RTL_TELLER_REC.CHG_DESC1 := P_CHG_ROW.COD_CHG_DESC1;
          PKG_RTL_TELLER_REC.CHG_DESC2 := P_CHG_ROW.COD_CHG_DESC2;
          PKG_RTL_TELLER_REC.CHG_DESC3 := P_CHG_ROW.COD_CHG_DESC3;
          PKG_RTL_TELLER_REC.CHG_DESC4 := P_CHG_ROW.COD_CHG_DESC4;
          L_CHG_DR_LEG                 := P_CHG_ROW.CHG_DR_LEG;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          DBG('Charge 0 Currency--->' || PKG_RTL_TELLER_REC.CHG_CCY);
          DBG('Charge Amount1-->>' || L_COD_CHG_AMT);
        
          IF P_CHG_ROW.COD_MAIN_OFFSET_FLAG = 'N' THEN
            J := 1;
          ELSE
          
            J := 3;
          END IF;
        
          DBG('depks_rtl_teller.g_charge_mode = ' ||
              DEPKS_RTL_TELLER.G_CHARGE_MODE);
          DBG('Pkg_Rtl_Teller_Rec.Product_Code= ' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          IF DEPKS_RTL_TELLER.G_CHARGE_MODE IS NOT NULL AND
             PKG_RTL_TELLER_REC.PRODUCT_CODE IN
             ('BCSA', 'BCSC', 'BCMA', 'BCMC', 'BCMG') THEN
            L_CHARGE_FLAG := TRUE;
          
            IF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
              L_CHG_ACC     := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
              L_CHG_ACC_CCY := DEPKS_RTL_TELLER.G_CHARGE_CCY;
            
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.CHARGE_ACC_BRN;
              DBG('l_chg_acc_brn is ' || L_CHG_ACC_BRN);
            
            ELSIF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'T' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
            
              L_CHG_ACC := NVL(PKG_CHG_ROW.COD_TXN_ACCOUNT,
                               PKG_ARC_ROW.COD_TXN_ACCOUNT);
            
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            
            END IF;
          
            DBG('Before replace' || DEPKS_RTL_TELLER.G_CHARGE_MODE);
            IF NOT GWPKS_UTIL.G_FROM_BEAN AND
               DEPKS_RTL_TELLER.G_CHARGE_MODE = 'C' AND
               PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('BCMA', 'BCMC', 'BCMG') THEN
              DBG('inside replace');
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := PKG_ARC_ROW.COD_OFFSET_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            END IF;
          
            DBG('l_Chg_Acc1' || L_CHG_ACC);
            DBG('l_Chg_Acc_Ccy1' || L_CHG_ACC_CCY);
            DBG('l_Chg_Acc_Brn1' || L_CHG_ACC_BRN);
          ELSE
          
            DBG('Pkg_Rtl_Teller_Rec.Product_Code is --' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' THEN
              L_CHARGE_FLAG := TRUE;
              L_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                                   P_CHG_ROW.COD_TXN_ACCOUNT);
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
              DBG('l_Chg_Acc for cxtr is ~~' || L_CHG_ACC);
              DBG('l_Chg_Acc_Ccy for cxtr is ~~' || L_CHG_ACC_CCY);
            ELSE
            
              DBG('p_Chg_Row.Chg_Dr_Leg apple = ' || P_CHG_ROW.CHG_DR_LEG);
              IF P_CHG_ROW.CHG_DR_LEG IS NOT NULL THEN
                L_CHARGE_FLAG := TRUE;
                IF P_CHG_ROW.CHG_DR_LEG = 'TXN_ACC' THEN
                  DBG('INSIDE TXN ACC CHARGE');
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
                  DBG('L_CHG_ACC_CCY=' || L_CHG_ACC_CCY);
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                ELSIF P_CHG_ROW.CHG_DR_LEG = 'OFS_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
                ELSE
                
                  IF P_CHG_ROW.COD_PROD_ACC_CLS IN ('ACWF', 'FTA8') THEN
                    --sampath added if for CSS
                    L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY; --sampath added for CSS
                  ELSE
                    --sampath added ELSE for CSS
                    L_CHG_ACC_CCY := GLOBAL.LCY;
                  END IF; --sampath added END IF for CSS
                
                  L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG;
                  L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
                END IF;
              END IF;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'Y' THEN
            DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 2 THEN
          L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT1;
          L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY1;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
          L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD2;
          L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE1;
          L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING1;
          L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL1;
          L_THEIR_CHGS         := P_CHG_ROW.COD_THEIR_CHGS1;
          L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC1;
          L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE1;
        
          PKG_RTL_TELLER_REC.CHG_AMT_1     := P_CHG_ROW.COD_CHG_AMT1;
          PKG_RTL_TELLER_REC.CHG_CCY_1     := P_CHG_ROW.COD_CHG_CCY1;
          PKG_RTL_TELLER_REC.MIS_HEAD_2    := P_CHG_ROW.COD_MIS_HEAD2;
          PKG_RTL_TELLER_REC.TXN_CODE_1    := P_CHG_ROW.COD_CHG_TXN_CODE1;
          PKG_RTL_TELLER_REC.NETTING_IND_1 := P_CHG_ROW.COD_CHG_NETTING1;
          PKG_RTL_TELLER_REC.CHG_GL_1      := P_CHG_ROW.COD_CHG_GL1;
          PKG_RTL_TELLER_REC.THEIR_CHGS1   := P_CHG_ROW.COD_THEIR_CHGS1;
          L_COD_CHG_TRACK_PRF              := P_CHG_ROW.COD_CHG_TRACK_PRF1;
          L_COD_CHG_LIQD_PRF               := P_CHG_ROW.COD_CHG_LIQD_PRF1;
          L_CHG_DR_LEG                     := P_CHG_ROW.CHG_DR_LEG_1;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          DBG('Charge 1 Currency--->' || PKG_RTL_TELLER_REC.CHG_CCY_1);
          DBG('Charge Amount2-->>' || L_COD_CHG_AMT);
        
          IF P_CHG_ROW.COD_MAIN_OFFSET_FLAG = 'N' THEN
            J := 3;
          ELSE
          
            J := 5;
          END IF;
        
          DBG('Pkg_Rtl_Teller_Rec.Comm_Mode = ' ||
              PKG_RTL_TELLER_REC.COMM_MODE);
          DBG('Pkg_Rtl_Teller_Rec.Product_Code= ' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          IF DEPKS_RTL_TELLER.G_CHARGE_MODE IS NOT NULL AND
             PKG_RTL_TELLER_REC.PRODUCT_CODE IN
             ('BCSA', 'BCSC', 'BCMA', 'BCMC', 'BCMG') THEN
            L_CHARGE_FLAG := TRUE;
          
            IF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
              L_CHG_ACC     := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
              L_CHG_ACC_CCY := DEPKS_RTL_TELLER.G_CHARGE_CCY;
            
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.CHARGE_ACC_BRN;
              DBG('l_chg_acc_brn is ' || L_CHG_ACC_BRN);
            
            ELSIF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'T' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
            
              L_CHG_ACC := NVL(PKG_CHG_ROW.COD_TXN_ACCOUNT,
                               PKG_ARC_ROW.COD_TXN_ACCOUNT);
            
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            
            END IF;
          
            IF NOT GWPKS_UTIL.G_FROM_BEAN AND
               DEPKS_RTL_TELLER.G_CHARGE_MODE = 'C' AND
               PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('BCMA', 'BCMC', 'BCMG') THEN
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := PKG_ARC_ROW.COD_OFFSET_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            END IF;
            DBG('l_Chg_Acc2' || L_CHG_ACC);
            DBG('l_Chg_Acc_Ccy2' || L_CHG_ACC_CCY);
            DBG('l_Chg_Acc_Brn2' || L_CHG_ACC_BRN);
          ELSE
          
            DBG('Pkg_Rtl_Teller_Rec.Product_Code is --' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' THEN
              L_CHARGE_FLAG := TRUE;
              L_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                                   P_CHG_ROW.COD_TXN_ACCOUNT);
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
              DBG('l_Chg_Acc for cxtr is ~~' || L_CHG_ACC);
              DBG('l_Chg_Acc_Ccy for cxtr is ~~' || L_CHG_ACC_CCY);
            ELSE
            
              DBG('p_Chg_Row.Chg_Dr_Leg_1 = ' || P_CHG_ROW.CHG_DR_LEG_1);
              IF P_CHG_ROW.CHG_DR_LEG_1 IS NOT NULL THEN
                L_CHARGE_FLAG := TRUE;
                IF P_CHG_ROW.CHG_DR_LEG_1 = 'TXN_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                ELSIF P_CHG_ROW.CHG_DR_LEG_1 = 'OFS_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
                ELSE
                
                  IF P_CHG_ROW.COD_PROD_ACC_CLS IN ('ACWF', 'FTA8') THEN
                    --sampath added IF for CSS
                  
                    L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY; --sampath added for CSS
                  ELSE
                    L_CHG_ACC_CCY := GLOBAL.LCY;
                  END IF; --sampath added END IF for CSS
                
                  L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_1;
                  L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
                END IF;
              END IF;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver1 ' || PKG_RTL_TELLER_REC.WAIVER1);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
            DBG('During Tracking Charge 2 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 3 THEN
          L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT2;
          L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY2;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
          L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD3;
          L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE2;
          L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING2;
          L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL2;
          L_THEIR_CHGS         := P_CHG_ROW.COD_THEIR_CHGS2;
          L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC2;
          L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE2;
        
          PKG_RTL_TELLER_REC.CHG_AMT_2     := P_CHG_ROW.COD_CHG_AMT2;
          PKG_RTL_TELLER_REC.CHG_CCY_2     := P_CHG_ROW.COD_CHG_CCY2;
          PKG_RTL_TELLER_REC.MIS_HEAD_3    := P_CHG_ROW.COD_MIS_HEAD3;
          PKG_RTL_TELLER_REC.TXN_CODE_2    := P_CHG_ROW.COD_CHG_TXN_CODE2;
          PKG_RTL_TELLER_REC.NETTING_IND_2 := P_CHG_ROW.COD_CHG_NETTING2;
          PKG_RTL_TELLER_REC.CHG_GL_2      := P_CHG_ROW.COD_CHG_GL2;
          PKG_RTL_TELLER_REC.THEIR_CHGS2   := P_CHG_ROW.COD_THEIR_CHGS2;
          L_COD_CHG_TRACK_PRF              := P_CHG_ROW.COD_CHG_TRACK_PRF2;
          L_COD_CHG_LIQD_PRF               := P_CHG_ROW.COD_CHG_LIQD_PRF2;
          L_CHG_DR_LEG                     := P_CHG_ROW.CHG_DR_LEG_2;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          DBG('Charge 2 Currency--->' || PKG_RTL_TELLER_REC.CHG_CCY_2);
          DBG('Charge Amount3-->>' || L_COD_CHG_AMT);
        
          IF P_CHG_ROW.COD_MAIN_OFFSET_FLAG = 'N' THEN
            J := 5;
          ELSE
          
            J := 7;
          END IF;
        
          DBG('Pkg_Rtl_Teller_Rec.Comm_Mode = ' ||
              PKG_RTL_TELLER_REC.COMM_MODE);
          DBG('Pkg_Rtl_Teller_Rec.Product_Code= ' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          IF DEPKS_RTL_TELLER.G_CHARGE_MODE IS NOT NULL AND
             PKG_RTL_TELLER_REC.PRODUCT_CODE IN
             ('BCSA', 'BCSC', 'BCMA', 'BCMC', 'BCMG') THEN
            L_CHARGE_FLAG := TRUE;
          
            IF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
              L_CHG_ACC     := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
              L_CHG_ACC_CCY := DEPKS_RTL_TELLER.G_CHARGE_CCY;
            
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.CHARGE_ACC_BRN;
              DBG('l_chg_acc_brn is ' || L_CHG_ACC_BRN);
            
            ELSIF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'T' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
            
              L_CHG_ACC := NVL(PKG_CHG_ROW.COD_TXN_ACCOUNT,
                               PKG_ARC_ROW.COD_TXN_ACCOUNT);
            
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            
            END IF;
          
            IF NOT GWPKS_UTIL.G_FROM_BEAN AND
               DEPKS_RTL_TELLER.G_CHARGE_MODE = 'C' AND
               PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('BCMA', 'BCMC', 'BCMG') THEN
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := PKG_ARC_ROW.COD_OFFSET_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            END IF;
            DBG('l_Chg_Acc3' || L_CHG_ACC);
            DBG('l_Chg_Acc_Ccy3' || L_CHG_ACC_CCY);
            DBG('l_Chg_Acc_Brn3' || L_CHG_ACC_BRN);
          ELSE
          
            DBG('Pkg_Rtl_Teller_Rec.Product_Code is --' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' THEN
              L_CHARGE_FLAG := TRUE;
              L_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                                   P_CHG_ROW.COD_TXN_ACCOUNT);
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
              DBG('l_Chg_Acc for cxtr is ~~' || L_CHG_ACC);
              DBG('l_Chg_Acc_Ccy for cxtr is ~~' || L_CHG_ACC_CCY);
            ELSE
            
              DBG('p_Chg_Row.Chg_Dr_Leg_2 = ' || P_CHG_ROW.CHG_DR_LEG_2);
              IF P_CHG_ROW.CHG_DR_LEG_2 IS NOT NULL THEN
                L_CHARGE_FLAG := TRUE;
                IF P_CHG_ROW.CHG_DR_LEG_2 = 'TXN_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                ELSIF P_CHG_ROW.CHG_DR_LEG_2 = 'OFS_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
                ELSE
                
                  IF P_CHG_ROW.COD_PROD_ACC_CLS IN ('ACWF', 'FTA8') THEN
                    --sampath added IF for CSS
                  
                    L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY; --sampath added for CSS
                  ELSE
                    --sampath added ELSE for CSS
                    L_CHG_ACC_CCY := GLOBAL.LCY;
                  END IF; --sampath added END IF for CSS
                
                  L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_2;
                  L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
                END IF;
              END IF;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver2 ' || PKG_RTL_TELLER_REC.WAIVER2);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'Y' THEN
            DBG('During Tracking Charge 3 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 4 THEN
          L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT3;
          L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY3;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
          L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD4;
          L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE3;
          L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING3;
          L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL3;
          L_THEIR_CHGS         := P_CHG_ROW.COD_THEIR_CHGS3;
          L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC3;
          L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE3;
        
          PKG_RTL_TELLER_REC.CHG_AMT_3 := P_CHG_ROW.COD_CHG_AMT3;
        
          PKG_RTL_TELLER_REC.CHG_CCY_3     := P_CHG_ROW.COD_CHG_CCY3;
          PKG_RTL_TELLER_REC.MIS_HEAD_4    := P_CHG_ROW.COD_MIS_HEAD4;
          PKG_RTL_TELLER_REC.TXN_CODE_3    := P_CHG_ROW.COD_CHG_TXN_CODE3;
          PKG_RTL_TELLER_REC.NETTING_IND_3 := P_CHG_ROW.COD_CHG_NETTING3;
          PKG_RTL_TELLER_REC.CHG_GL_3      := P_CHG_ROW.COD_CHG_GL3;
          PKG_RTL_TELLER_REC.THEIR_CHGS3   := P_CHG_ROW.COD_THEIR_CHGS3;
          L_COD_CHG_TRACK_PRF              := P_CHG_ROW.COD_CHG_TRACK_PRF3;
          L_COD_CHG_LIQD_PRF               := P_CHG_ROW.COD_CHG_LIQD_PRF3;
          L_CHG_DR_LEG                     := P_CHG_ROW.CHG_DR_LEG_3;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          DBG('Charge Amount4-->>' || L_COD_CHG_AMT);
        
          IF P_CHG_ROW.COD_MAIN_OFFSET_FLAG = 'N' THEN
            J := 7;
          ELSE
          
            J := 9;
          END IF;
        
          DBG('Pkg_Rtl_Teller_Rec.Comm_Mode = ' ||
              PKG_RTL_TELLER_REC.COMM_MODE);
          DBG('Pkg_Rtl_Teller_Rec.Product_Code= ' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          IF DEPKS_RTL_TELLER.G_CHARGE_MODE IS NOT NULL AND
             PKG_RTL_TELLER_REC.PRODUCT_CODE IN
             ('BCSA', 'BCSC', 'BCMA', 'BCMC', 'BCMG') THEN
            L_CHARGE_FLAG := TRUE;
          
            IF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
              L_CHG_ACC     := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
              L_CHG_ACC_CCY := DEPKS_RTL_TELLER.G_CHARGE_CCY;
            
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.CHARGE_ACC_BRN;
              DBG('l_chg_acc_brn is ' || L_CHG_ACC_BRN);
            
            ELSIF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'T' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
            
              L_CHG_ACC := NVL(PKG_CHG_ROW.COD_TXN_ACCOUNT,
                               PKG_ARC_ROW.COD_TXN_ACCOUNT);
            
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            
            END IF;
          
            IF NOT GWPKS_UTIL.G_FROM_BEAN AND
               DEPKS_RTL_TELLER.G_CHARGE_MODE = 'C' AND
               PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('BCMA', 'BCMC', 'BCMG') THEN
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := PKG_ARC_ROW.COD_OFFSET_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            END IF;
            DBG('l_Chg_Acc4' || L_CHG_ACC);
            DBG('l_Chg_Acc_Ccy4' || L_CHG_ACC_CCY);
            DBG('l_Chg_Acc_Brn4' || L_CHG_ACC_BRN);
          ELSE
          
            DBG('Pkg_Rtl_Teller_Rec.Product_Code is --' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' THEN
              L_CHARGE_FLAG := TRUE;
              L_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                                   P_CHG_ROW.COD_TXN_ACCOUNT);
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
              DBG('l_Chg_Acc for cxtr is ~~' || L_CHG_ACC);
              DBG('l_Chg_Acc_Ccy for cxtr is ~~' || L_CHG_ACC_CCY);
            ELSE
            
              DBG('p_Chg_Row.Chg_Dr_Leg_3 = ' || P_CHG_ROW.CHG_DR_LEG_3);
              IF P_CHG_ROW.CHG_DR_LEG_3 IS NOT NULL THEN
                L_CHARGE_FLAG := TRUE;
                IF P_CHG_ROW.CHG_DR_LEG_3 = 'TXN_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                ELSIF P_CHG_ROW.CHG_DR_LEG_3 = 'OFS_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
                ELSE
                  L_CHG_ACC_CCY := GLOBAL.LCY;
                  L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_3;
                  L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
                END IF;
              END IF;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver3 ' || PKG_RTL_TELLER_REC.WAIVER3);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
            DBG('During Tracking Charge 4 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 5 THEN
          L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT4;
          L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY4;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
          L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD5;
          L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE4;
          L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING4;
          L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL4;
          L_THEIR_CHGS         := P_CHG_ROW.COD_THEIR_CHGS4;
          L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC4;
          L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE4;
        
          PKG_RTL_TELLER_REC.CHG_AMT_4     := P_CHG_ROW.COD_CHG_AMT4;
          PKG_RTL_TELLER_REC.CHG_CCY_4     := P_CHG_ROW.COD_CHG_CCY4;
          PKG_RTL_TELLER_REC.MIS_HEAD_5    := P_CHG_ROW.COD_MIS_HEAD5;
          PKG_RTL_TELLER_REC.TXN_CODE_4    := P_CHG_ROW.COD_CHG_TXN_CODE4;
          PKG_RTL_TELLER_REC.NETTING_IND_4 := P_CHG_ROW.COD_CHG_NETTING4;
          PKG_RTL_TELLER_REC.CHG_GL_4      := P_CHG_ROW.COD_CHG_GL4;
          PKG_RTL_TELLER_REC.THEIR_CHGS4   := P_CHG_ROW.COD_THEIR_CHGS4;
          L_COD_CHG_TRACK_PRF              := P_CHG_ROW.COD_CHG_TRACK_PRF4;
          L_COD_CHG_LIQD_PRF               := P_CHG_ROW.COD_CHG_LIQD_PRF4;
          L_CHG_DR_LEG                     := P_CHG_ROW.CHG_DR_LEG_4;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          DBG('Charge Amount5-->>' || L_COD_CHG_AMT);
        
          IF P_CHG_ROW.COD_MAIN_OFFSET_FLAG = 'N' THEN
            J := 9;
          ELSE
          
            J := 11;
          END IF;
        
          DBG('Pkg_Rtl_Teller_Rec.Comm_Mode = ' ||
              PKG_RTL_TELLER_REC.COMM_MODE);
          DBG('Pkg_Rtl_Teller_Rec.Product_Code= ' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          IF DEPKS_RTL_TELLER.G_CHARGE_MODE IS NOT NULL AND
             PKG_RTL_TELLER_REC.PRODUCT_CODE IN
             ('BCSA', 'BCSC', 'BCMA', 'BCMC', 'BCMG') THEN
            L_CHARGE_FLAG := TRUE;
          
            IF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'A' THEN
              L_CHG_ACC     := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
              L_CHG_ACC_CCY := DEPKS_RTL_TELLER.G_CHARGE_CCY;
            
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.CHARGE_ACC_BRN;
              DBG('l_chg_acc_brn is ' || L_CHG_ACC_BRN);
            
            ELSIF DEPKS_RTL_TELLER.G_CHARGE_MODE = 'T' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
            
              L_CHG_ACC := NVL(PKG_CHG_ROW.COD_TXN_ACCOUNT,
                               PKG_ARC_ROW.COD_TXN_ACCOUNT);
            
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            
            END IF;
          
            IF NOT GWPKS_UTIL.G_FROM_BEAN AND
               DEPKS_RTL_TELLER.G_CHARGE_MODE = 'C' AND
               PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('BCMA', 'BCMC', 'BCMG') THEN
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := PKG_ARC_ROW.COD_OFFSET_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            END IF;
            DBG('l_Chg_Acc5' || L_CHG_ACC);
            DBG('l_Chg_Acc_Ccy5' || L_CHG_ACC_CCY);
            DBG('l_Chg_Acc_Brn5' || L_CHG_ACC_BRN);
          ELSE
          
            DBG('Pkg_Rtl_Teller_Rec.Product_Code is --' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'CXTR' THEN
              L_CHARGE_FLAG := TRUE;
              L_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                                   P_CHG_ROW.COD_TXN_ACCOUNT);
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
              DBG('l_Chg_Acc for cxtr is ~~' || L_CHG_ACC);
              DBG('l_Chg_Acc_Ccy for cxtr is ~~' || L_CHG_ACC_CCY);
            ELSE
            
              DBG('p_Chg_Row.Chg_Dr_Leg_4 = ' || P_CHG_ROW.CHG_DR_LEG_4);
              IF P_CHG_ROW.CHG_DR_LEG_4 IS NOT NULL THEN
                L_CHARGE_FLAG := TRUE;
                IF P_CHG_ROW.CHG_DR_LEG_4 = 'TXN_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
                ELSIF P_CHG_ROW.CHG_DR_LEG_4 = 'OFS_ACC' THEN
                  L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
                  L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
                  L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
                ELSE
                  L_CHG_ACC_CCY := GLOBAL.LCY;
                  L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_4;
                  L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
                END IF;
              END IF;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver4 ' || PKG_RTL_TELLER_REC.WAIVER4);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'Y' THEN
            DBG('During Tracking Charge 5 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        END IF;
      ELSE
        IF I = 1 THEN
          L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT;
          L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
          L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_1;
          L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE;
          L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND;
        
          L_COD_CHG_GL := NVL(PKG_RTL_TELLER_REC.CHG_GL,
                              PKG_RTL_TELLER_REC.THEIR_ACC);
        
          L_COD_CHG_GL       := NVL(L_COD_CHG_GL, P_CHG_ROW.COD_CHG_GL);
          L_COD_CHG_TXN_CODE := NVL(L_COD_CHG_TXN_CODE,
                                    P_CHG_ROW.COD_CHG_TXN_CODE);
        
          L_THEIR_CHGS        := P_CHG_ROW.COD_THEIR_CHGS;
          L_CHG_DESC          := P_CHG_ROW.COD_CHG_DESC;
          L_CHG_TYPE          := P_CHG_ROW.COD_CHG_TYPE;
          L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF;
          L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF;
          L_CHG_DR_LEG        := P_CHG_ROW.CHG_DR_LEG;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes 1');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          J := 3;
        
          DBG('p_Chg_Row.Chg_Dr_Leg = ' || P_CHG_ROW.CHG_DR_LEG);
          IF P_CHG_ROW.CHG_DR_LEG IS NOT NULL THEN
            L_CHARGE_FLAG := TRUE;
            IF P_CHG_ROW.CHG_DR_LEG = 'TXN_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSIF P_CHG_ROW.CHG_DR_LEG = 'OFS_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG;
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'Y' THEN
            DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 2 THEN
          L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_1;
          L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_1;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
          L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_2;
          L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_1;
          L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_1;
        
          L_COD_CHG_GL := NVL(PKG_RTL_TELLER_REC.CHG_GL_1,
                              PKG_RTL_TELLER_REC.THEIR_ACC1);
        
          L_COD_CHG_GL       := NVL(L_COD_CHG_GL, P_CHG_ROW.COD_CHG_GL1);
          L_COD_CHG_TXN_CODE := NVL(L_COD_CHG_TXN_CODE,
                                    P_CHG_ROW.COD_CHG_TXN_CODE1);
        
          L_THEIR_CHGS        := P_CHG_ROW.COD_THEIR_CHGS1;
          L_CHG_DESC          := P_CHG_ROW.COD_CHG_DESC1;
          L_CHG_TYPE          := P_CHG_ROW.COD_CHG_TYPE1;
          L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF1;
          L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF1;
          L_CHG_DR_LEG        := P_CHG_ROW.CHG_DR_LEG_1;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes 2');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          J := 5;
        
          DBG('p_Chg_Row.Chg_Dr_Leg_1 = ' || P_CHG_ROW.CHG_DR_LEG_1);
          IF P_CHG_ROW.CHG_DR_LEG_1 IS NOT NULL THEN
            L_CHARGE_FLAG := TRUE;
            IF P_CHG_ROW.CHG_DR_LEG_1 = 'TXN_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSIF P_CHG_ROW.CHG_DR_LEG_1 = 'OFS_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_1;
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver1 ' || PKG_RTL_TELLER_REC.WAIVER1);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
            DBG('During Tracking Charge 2 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 3 THEN
          L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_2;
          L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_2;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
          L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_3;
          L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_2;
          L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_2;
        
          L_COD_CHG_GL := NVL(PKG_RTL_TELLER_REC.CHG_GL_2,
                              PKG_RTL_TELLER_REC.THEIR_ACC2);
        
          L_COD_CHG_GL       := NVL(L_COD_CHG_GL, P_CHG_ROW.COD_CHG_GL2);
          L_COD_CHG_TXN_CODE := NVL(L_COD_CHG_TXN_CODE,
                                    P_CHG_ROW.COD_CHG_TXN_CODE2);
        
          L_THEIR_CHGS        := P_CHG_ROW.COD_THEIR_CHGS2;
          L_CHG_DESC          := P_CHG_ROW.COD_CHG_DESC2;
          L_CHG_TYPE          := P_CHG_ROW.COD_CHG_TYPE2;
          L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF2;
          L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF2;
          L_CHG_DR_LEG        := P_CHG_ROW.CHG_DR_LEG_2;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes 3');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          J := 7;
        
          DBG('p_Chg_Row.Chg_Dr_Leg_2 = ' || P_CHG_ROW.CHG_DR_LEG_2);
          IF P_CHG_ROW.CHG_DR_LEG_2 IS NOT NULL THEN
            L_CHARGE_FLAG := TRUE;
            IF P_CHG_ROW.CHG_DR_LEG_2 = 'TXN_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSIF P_CHG_ROW.CHG_DR_LEG_2 = 'OFS_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_2;
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver2 ' || PKG_RTL_TELLER_REC.WAIVER2);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
            DBG('During Tracking Charge 3 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 4 THEN
          L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_3;
          L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_3;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
          L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_4;
          L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_3;
          L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_3;
        
          L_COD_CHG_GL := NVL(PKG_RTL_TELLER_REC.CHG_GL_3,
                              PKG_RTL_TELLER_REC.THEIR_ACC3);
        
          L_COD_CHG_GL       := NVL(L_COD_CHG_GL, P_CHG_ROW.COD_CHG_GL3);
          L_COD_CHG_TXN_CODE := NVL(L_COD_CHG_TXN_CODE,
                                    P_CHG_ROW.COD_CHG_TXN_CODE3);
        
          L_THEIR_CHGS        := P_CHG_ROW.COD_THEIR_CHGS3;
          L_CHG_DESC          := P_CHG_ROW.COD_CHG_DESC3;
          L_CHG_TYPE          := P_CHG_ROW.COD_CHG_TYPE3;
          L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF3;
          L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF3;
          L_CHG_DR_LEG        := P_CHG_ROW.CHG_DR_LEG_3;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes 4');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          J := 9;
        
          DBG('p_Chg_Row.Chg_Dr_Leg_3 = ' || P_CHG_ROW.CHG_DR_LEG_3);
          IF P_CHG_ROW.CHG_DR_LEG_3 IS NOT NULL THEN
            L_CHARGE_FLAG := TRUE;
            IF P_CHG_ROW.CHG_DR_LEG_3 = 'TXN_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSIF P_CHG_ROW.CHG_DR_LEG_3 = 'OFS_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_3;
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver3 ' || PKG_RTL_TELLER_REC.WAIVER3);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'Y' THEN
            DBG('During Tracking Charge 4 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        ELSIF I = 5 THEN
          L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_4;
          L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_4;
          L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
          L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
          L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_5;
          L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_4;
          L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_4;
        
          L_COD_CHG_GL := NVL(PKG_RTL_TELLER_REC.CHG_GL_4,
                              PKG_RTL_TELLER_REC.THEIR_ACC4);
        
          L_COD_CHG_GL       := NVL(L_COD_CHG_GL, P_CHG_ROW.COD_CHG_GL4);
          L_COD_CHG_TXN_CODE := NVL(L_COD_CHG_TXN_CODE,
                                    P_CHG_ROW.COD_CHG_TXN_CODE4);
        
          L_THEIR_CHGS        := P_CHG_ROW.COD_THEIR_CHGS4;
          L_CHG_DESC          := P_CHG_ROW.COD_CHG_DESC4;
          L_CHG_TYPE          := P_CHG_ROW.COD_CHG_TYPE4;
          L_COD_CHG_TRACK_PRF := P_CHG_ROW.COD_CHG_TRACK_PRF4;
          L_COD_CHG_LIQD_PRF  := P_CHG_ROW.COD_CHG_LIQD_PRF4;
          L_CHG_DR_LEG        := P_CHG_ROW.CHG_DR_LEG_4;
        
          IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
             CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'N' AND
             NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
            DBG('setting cod chg amt to NULL since default waiver Yes 5');
            L_COD_CHG_AMT := NULL;
          END IF;
        
          J := 11;
        
          DBG('p_Chg_Row.Chg_Dr_Leg_4 = ' || P_CHG_ROW.CHG_DR_LEG_4);
          IF P_CHG_ROW.CHG_DR_LEG_4 IS NOT NULL THEN
            L_CHARGE_FLAG := TRUE;
            IF P_CHG_ROW.CHG_DR_LEG_4 = 'TXN_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
            ELSIF P_CHG_ROW.CHG_DR_LEG_4 = 'OFS_ACC' THEN
              L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
              L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
              L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
            ELSE
              L_CHG_ACC_CCY := GLOBAL.LCY;
              L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_4;
              L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          END IF;
        
          DBG('pkg_prod.product_code is ' || PKG_PROD.PRODUCT_CODE);
          DBG('GWPKS_UTIL.G_REJECTFLAG is ' || GWPKS_UTIL.G_REJECTFLAG);
          IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' AND
             NVL(PKG_PROD.PRODUCT_CODE, '!@#$') IN ('CQWL') THEN
            DBG('Pkg_Rtl_Teller_Rec.Txn_Acc set is ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          END IF;
        
          DBG('pkg_rtl_teller_rec.waiver4 ' || PKG_RTL_TELLER_REC.WAIVER4);
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
             NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'Y' THEN
            DBG('During Tracking Charge 5 got waived so will set CHG_AMT NULL ');
            L_COD_CHG_AMT := NULL;
          END IF;
        
        END IF;
      END IF;
      DBG('Amt is ' || L_COD_CHG_AMT);
      DBG('l_COD_CHG_TRACK_PRF is ' || L_COD_CHG_TRACK_PRF);
      DBG('l_COD_CHG_LIQD_PRF is ' || L_COD_CHG_LIQD_PRF);
    
      DBG(' check for amount');
      L_COD_CHG_AMT := NVL(L_COD_CHG_AMT, 0);
      DBG('l_cod_chg_amt is ' || L_COD_CHG_AMT);
    
      IF L_COD_CHG_AMT IS NOT NULL
      
       THEN
        DBG('Inside to build accounting entries');
      
        IF GWPKS_UTIL.G_FROM_SI THEN
          DBG('This is from SI');
          BEGIN
            SELECT DR_ACC_BR, DR_ACCOUNT, DR_ACC_CCY
              INTO L_CHG_ACC_BRN, L_CHG_ACC, L_CHG_ACC_CCY
              FROM SITBS_CONTRACT_MASTER
             WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.XREF
               AND EVENT_SEQ_NO =
                   (SELECT MAX(EVENT_SEQ_NO)
                      FROM SITBS_CONTRACT_MASTER
                     WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.XREF);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('In WOT of resolve charge on whom::' || SQLERRM);
          END;
          DBG('l_Chg_Acc_Brn:' || L_CHG_ACC_BRN);
          DBG('l_Chg_Acc:' || L_CHG_ACC);
          DBG('l_Chg_Acc_Ccy:' || L_CHG_ACC_CCY);
        
        ELSE
        
          DBG('Not SI Txn');
          IF L_CHARGE_FLAG = FALSE THEN
          
            PR_RESOLVE_CHG_WHOM(P_CHG_ROW,
                                L_THEIR_CHGS,
                                L_CHG_ACC_CCY,
                                L_CHG_ACC,
                                L_CHG_ACC_BRN);
          END IF;
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID := 2;
          L_TB_CLUSTER_DATA('Chg_Acc') := L_CHG_ACC;
          L_TB_CLUSTER_DATA('Chg_Acc_Brn') := L_CHG_ACC_BRN;
          L_TB_CLUSTER_DATA('Chg_Acc_Ccy') := L_CHG_ACC_CCY;
        
          L_TB_CLUSTER_DATA('ROUTE_CODE') := PKG_RTL_TELLER_REC.ROUTE_CODE;
          L_TB_CLUSTER_DATA('CHG_CCY') := PKG_RTL_TELLER_REC.CHG_CCY;
          L_TB_CLUSTER_DATA('CHARGE_ACCOUNT') := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
          L_TB_CLUSTER_DATA('TXN_CCY') := PKG_RTL_TELLER_REC.TXN_CCY;
          L_TB_CLUSTER_DATA('TXN_ACC') := PKG_RTL_TELLER_REC.TXN_ACC;
          L_TB_CLUSTER_DATA('TXN_BRANCH') := PKG_RTL_TELLER_REC.TXN_BRANCH;
          L_TB_CLUSTER_DATA('OFS_CCY') := PKG_RTL_TELLER_REC.OFS_CCY;
          L_TB_CLUSTER_DATA('OFS_ACC') := PKG_RTL_TELLER_REC.OFS_ACC;
          L_TB_CLUSTER_DATA('OFS_BRANCH') := PKG_RTL_TELLER_REC.OFS_BRANCH;
          L_TB_CLUSTER_DATA('XREF') := PKG_RTL_TELLER_REC.XREF;
          L_TB_CLUSTER_DATA('TRN_REF_NO') := PKG_RTL_TELLER_REC.TRN_REF_NO;
          L_TB_CLUSTER_DATA('DR_ACC') := PKG_ARC_ROW.DR_ACC;
          L_TB_CLUSTER_DATA('L_CHG_ACC_BRN') := L_CHG_ACC_BRN;
          L_TB_CLUSTER_DATA('L_CHG_ACC') := L_CHG_ACC;
          L_TB_CLUSTER_DATA('L_CHG_ACC_CCY') := L_CHG_ACC_CCY;
          L_TB_CLUSTER_DATA('L_THEIR_CHGS') := L_THEIR_CHGS;
        
          IF L_CHARGE_FLAG THEN
            L_TB_CLUSTER_DATA('L_CHARGE_FLAG') := 'T';
          ELSE
            L_TB_CLUSTER_DATA('L_CHARGE_FLAG') := 'F';
          END IF;
          DBG('Before calling depks_rtl_teller_cluster.pr_build_chg_entries');
        
          DBG('Calling depks_rtl_teller_cluster.fn_save');
          DEPKS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                        P_CHG_ROW,
                                                        I,
                                                        P_RET,
                                                        P_ERR_CODE,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA);
          IF L_TB_CLUSTER_DATA.EXISTS('Chg_Acc') THEN
            L_CHG_ACC := L_TB_CLUSTER_DATA('Chg_Acc');
            DBG('**Charge_Account swapped(l_chg_acc) : ' || L_CHG_ACC);
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('Chg_Acc_Brn') THEN
            L_CHG_ACC_BRN := L_TB_CLUSTER_DATA('Chg_Acc_Brn');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('Chg_Acc_Ccy') THEN
            L_CHG_ACC_CCY := L_TB_CLUSTER_DATA('Chg_Acc_Ccy');
          END IF;
        
          IF L_TB_CLUSTER_DATA.EXISTS('L_CHARGE_FLAG') THEN
            IF L_TB_CLUSTER_DATA('L_CHARGE_FLAG') = 'T' THEN
              L_CHARGE_FLAG := TRUE;
            ELSE
              L_CHARGE_FLAG := FALSE;
            END IF;
          END IF;
        
          IF P_RET = -1 THEN
            DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
            RETURN;
          END IF;
        END IF;
      
        DBG('Debiting Chgs from ' || L_CHG_ACC);
      
        IF L_CHG_ACC_CCY <> L_COD_CHG_CCY THEN
          DBG('Ccys are diff ');
          L_ACC_CHG_EXCH_RATE := NULL;
        
          IF L_COD_CHG_AMT > 0 THEN
          
            DBG('L_COD_CHG_CCY=' || L_COD_CHG_CCY);
            DBG('L_CHG_ACC_CCY=' || L_CHG_ACC_CCY);
            DBG('L_ACC_CCY_CHG=' || L_ACC_CCY_CHG);
            DBG('PKG_RTL_TELLER_REC.PRODUCT_CODE=' ||
                PKG_RTL_TELLER_REC.PRODUCT_CODE);
            DBG('PKG_RTL_TELLER_REC.TXN_CCY=' ||
                PKG_RTL_TELLER_REC.TXN_CCY);
            DBG('PKG_RTL_TELLER_REC.OFS_CCY=' ||
                PKG_RTL_TELLER_REC.OFS_CCY);
            DBG('PKG_TXN_ACC.AC_GL_CCY=' || PKG_TXN_ACC.AC_GL_CCY);
            DBG('PKG_PROD.RATE_TYPE_PREFERRED=' ||
                PKG_PROD.RATE_TYPE_PREFERRED);
            DBG('PKG_PROD.RATE_CODE_PREFERRED=' ||
                PKG_PROD.RATE_CODE_PREFERRED);
          
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE = 'DPOW' AND
               PKG_RTL_TELLER_REC.TXN_CCY IN ('KHR') AND
               PKG_RTL_TELLER_REC.OFS_CCY IN ('USD') AND
               PKG_TXN_ACC.AC_GL_CCY IN ('KHR') AND
               L_COD_CHG_CCY IN ('USD') AND L_CHG_ACC_CCY IN ('KHR') THEN
              --sampath cardless withdrawal
            
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                            L_COD_CHG_CCY,
                                            L_CHG_ACC_CCY,
                                            PKG_PROD.RATE_TYPE_PREFERRED,
                                            PKG_PROD.RATE_CODE_PREFERRED,
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_ACC_CCY_CHG,
                                            L_ACC_CHG_EXCH_RATE,
                                            P_ERR_CODE) THEN
                DBG('Failure in converting instr amt to ac ccy amt ' ||
                    P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
            ELSE
              --sampath cardless withdrawal
            
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                            L_COD_CHG_CCY,
                                            L_CHG_ACC_CCY,
                                            NVL(L_COD_RATE_CODE, 'STANDARD'),
                                            NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_ACC_CCY_CHG,
                                            L_ACC_CHG_EXCH_RATE,
                                            P_ERR_CODE) THEN
                DBG('Failure in converting instr amt to ac ccy amt ' ||
                    P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
            END IF; --sampath cardless withdrawal
          
          ELSE
            L_ACC_CCY_CHG := L_COD_CHG_AMT;
          END IF;
        
          DBG('Chg in acc ccy is ' || L_ACC_CCY_CHG || ' and rate ' ||
              L_ACC_CHG_EXCH_RATE);
        ELSE
          DBG('No confusion at all');
          L_ACC_CCY_CHG       := L_COD_CHG_AMT;
          L_ACC_CHG_EXCH_RATE := 1;
        END IF;
      
        DBG('l_acc_ccy_chg_temp IS ::: ' || L_ACC_CCY_CHG_TEMP);
        IF PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' THEN
          L_ACC_CCY_CHG_TEMP := L_ACC_CCY_CHG;
        END IF;
        DBG('l_acc_ccy_chg_temp IS ::: ' || L_ACC_CCY_CHG_TEMP);
      
        BEGIN
          SELECT AC_OR_GL
            INTO L_AC_OR_GL
            FROM STTBS_ACCOUNT
           WHERE BRANCH_CODE = L_CHG_ACC_BRN
             AND AC_GL_NO = L_CHG_ACC;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_AC_OR_GL := 'X';
        END;
        BEGIN
          SELECT NVL(TRACK_RECEIVABLE, 'N')
            INTO L_ACCOUNT_TRACKING_ALLOWED
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = L_CHG_ACC
             AND BRANCH_CODE = L_CHG_ACC_BRN;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ACCOUNT_TRACKING_ALLOWED := 'X';
        END;
      
        DBG('pkg_rtl_teller_rec.dr_acc  ' || PKG_RTL_TELLER_REC.DR_ACC);
        IF PKG_RTL_TELLER_REC.DR_ACC = 'TXN' THEN
          L_CRDR_IND := 'D';
        ELSIF PKG_RTL_TELLER_REC.DR_ACC = 'OFS' THEN
          L_CRDR_IND := 'C';
        END IF;
        DBG('l_crdr_ind  ' || L_CRDR_IND);
      
        DBG('pkg_is_track_requrd ' || PKG_IS_TRACK_REQURD);
        IF NVL(PKG_IS_TRACK_REQURD, 'Y') = 'Y' THEN
        
          IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
             L_AC_OR_GL = 'A' AND
             NVL(L_ACCOUNT_TRACKING_ALLOWED, 'N') = 'Y' THEN
            DBG('going to get avl balance for this txn');
          
            IF L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC THEN
              DBG('Charge on txn account');
              DBG('pkg_txn_bal_done : ' || PKG_TXN_BAL_DONE);
              IF NVL(PKG_TXN_BAL_DONE, 'N') = 'N' THEN
                IF NOT ACPKSS_MISC.FN_GETAVLBAL(L_CHG_ACC_BRN,
                                                L_CHG_ACC,
                                                PKG_LBAL_TXN,
                                                'Y') THEN
                  DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
                ELSE
                  DBG('Setting pkg_txn_bal_done to Y');
                  PKG_TXN_BAL_DONE := 'Y';
                END IF;
              END IF;
              DBG('pkg_lbal_txn : ' || PKG_LBAL_TXN);
              LBAL := PKG_LBAL_TXN;
            ELSE
              DBG('Charge on ofs account');
              DBG('pkg_ofs_bal_done : ' || PKG_OFS_BAL_DONE);
              IF NVL(PKG_OFS_BAL_DONE, 'N') = 'N' THEN
                IF NOT ACPKSS_MISC.FN_GETAVLBAL(L_CHG_ACC_BRN,
                                                L_CHG_ACC,
                                                PKG_LBAL_OFS,
                                                'Y') THEN
                  DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
                ELSE
                  DBG('Setting pkg_ofs_bal_done to Y');
                  PKG_OFS_BAL_DONE := 'Y';
                END IF;
              END IF;
              DBG('pkg_lbal_ofs : ' || PKG_LBAL_OFS);
              LBAL := PKG_LBAL_OFS;
            END IF;
          
            DBG('txn acc->' || PKG_RTL_TELLER_REC.TXN_ACC ||
                '~charge from account->' || L_CHG_ACC);
          
            DBG('l_crdr_ind : ' || L_CRDR_IND);
            IF L_CRDR_IND = 'D' THEN
            
              IF PKG_RTL_TELLER_REC.TXN_ACC = L_CHG_ACC AND
                 PKG_MAIN_ENTRIES_BUILT THEN
                DBG('inside if main entries built so..in if condition');
                L_PREDICTED_BAL := LBAL - PKG_RTL_TELLER_REC.TXN_AMOUNT;
              ELSE
                L_PREDICTED_BAL := LBAL;
              END IF;
            
            ELSE
              IF PKG_RTL_TELLER_REC.TXN_ACC = L_CHG_ACC AND
                 PKG_MAIN_ENTRIES_BUILT THEN
                DBG('inside if main entries built for deposite TXNs so..in if condition');
                L_PREDICTED_BAL := LBAL + PKG_RTL_TELLER_REC.TXN_AMOUNT;
              ELSE
                L_PREDICTED_BAL := LBAL;
              END IF;
            END IF;
          
            DBG('l_predicted_bal->' || L_PREDICTED_BAL);
          
            L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL;
            DBG('l_predicted_bal_temp before-->>>' || L_PREDICTED_BAL_TEMP);
            DBG('i : ' || I);
            DBG('l_chg_acc-->>> ' || L_CHG_ACC);
            DBG('pkg_rtl_teller_rec.txn_acc : ' ||
                PKG_RTL_TELLER_REC.TXN_ACC);
            DBG('pkg_rtl_teller_rec.ofs_acc : ' ||
                PKG_RTL_TELLER_REC.OFS_ACC);
            DBG('pkg_recivable_amt_det.CHG1_AC_NO : ' ||
                PKG_RECIVABLE_AMT_DET.CHG1_AC_NO);
            DBG('pkg_recivable_amt_det.CHG1_COD_CHG_AMT : ' ||
                PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT);
            DBG('pkg_recivable_amt_det.CHG1_TXN_OR_OFS : ' ||
                PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS);
            DBG('pkg_recivable_amt_det.CHG2_AC_NO : ' ||
                PKG_RECIVABLE_AMT_DET.CHG2_AC_NO);
            DBG('pkg_recivable_amt_det.CHG2_COD_CHG_AMT : ' ||
                PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT);
            DBG('pkg_recivable_amt_det.CHG2_TXN_OR_OFS : ' ||
                PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS);
            DBG('pkg_recivable_amt_det.CHG3_AC_NO : ' ||
                PKG_RECIVABLE_AMT_DET.CHG3_AC_NO);
            DBG('pkg_recivable_amt_det.CHG3_COD_CHG_AMT : ' ||
                PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT);
            DBG('pkg_recivable_amt_det.CHG3_TXN_OR_OFS : ' ||
                PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS);
            DBG('pkg_recivable_amt_det.CHG4_AC_NO : ' ||
                PKG_RECIVABLE_AMT_DET.CHG4_AC_NO);
            DBG('pkg_recivable_amt_det.CHG4_COD_CHG_AMT : ' ||
                PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT);
            DBG('pkg_recivable_amt_det.CHG4_TXN_OR_OFS : ' ||
                PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS);
            IF I = 2 THEN
              DBG('pkg_recivable_amt_det.CHG1_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS);
              DBG('Chking for deduction of chg1 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
            ELSIF I = 3 THEN
              DBG('pkg_recivable_amt_det.CHG1_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG2_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS);
              DBG('Chking for deduction of chg1 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg2 amount.. l_predicted_bal_temp : ' ||
                  L_PREDICTED_BAL_TEMP);
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
            ELSIF I = 4 THEN
              DBG('pkg_recivable_amt_det.CHG1_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG2_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG3_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS);
              DBG('Chking for deduction of chg1 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg2 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg3 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
            ELSIF I = 5 THEN
              DBG('pkg_recivable_amt_det.CHG1_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG2_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG3_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS);
              DBG('pkg_recivable_amt_det.CHG4_TXN_OR_OFS--->>>' ||
                  PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS);
              DBG('Chking for deduction of chg1 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg2 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg3 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            
              DBG('Chking for deduction of chg4 amount');
              IF (((L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS = 'TXN')) OR
                 ((L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) AND
                 (PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS = 'OFS'))) THEN
                L_PREDICTED_BAL_TEMP := L_PREDICTED_BAL_TEMP -
                                        NVL(PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT,
                                            0);
                DBG('l_predicted_bal_temp--->>>> ' || L_PREDICTED_BAL_TEMP);
              END IF;
            END IF;
            DBG('l_predicted_bal_temp after-->>>' || L_PREDICTED_BAL_TEMP);
            L_PREDICTED_BAL := L_PREDICTED_BAL_TEMP;
            DBG('l_predicted_bal -->>>' || L_PREDICTED_BAL);
          
            DBG('gwpks_util.pkg_acttype ' || GWPKS_UTIL.PKG_ACTTYPE);
            IF GWPKS_UTIL.PKG_ACTTYPE IS NOT NULL AND
               REPLACE(GWPKS_UTIL.PKG_TEMP_CHG_DETS, '~', NULL) IS NOT NULL THEN
            
              DBG('gwpks_util.pkg_temp_chg_dets ' ||
                  GWPKS_UTIL.PKG_TEMP_CHG_DETS);
              BEGIN
                L_WAIVER := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                    ((I - 1) * 7) + 1,
                                                    '~');
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              DBG('l_waiver ' || L_WAIVER);
              IF NVL(L_WAIVER, 'N') = 'Y' THEN
                DBG('Inside 1 ');
                L_ACC_CCY_CHG_TEMP := 0;
              ELSE
                DBG('Inside 2 ');
                L_ACC_CCY_CHG_TEMP := 0;
                DBG('l_acc_ccy_chg_temp ' || L_ACC_CCY_CHG_TEMP);
                L_COD_CHG_AMT_PRDTRACK := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                                  ((I - 1) * 7) + 3,
                                                                  '~');
                DBG('l_cod_chg_amt_temp ' || L_COD_CHG_AMT_TEMP);
                IF L_CHG_ACC_CCY <> L_COD_CHG_CCY THEN
                  DBG('Ccys are diff now have to convert charged passed from screen into Acy');
                  L_ACC_CHG_EXCH_RATE_TEMP := NULL;
                  IF NOT
                      CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                             L_COD_CHG_CCY,
                                             L_CHG_ACC_CCY,
                                             NVL(L_COD_RATE_CODE, 'STANDARD'),
                                             NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                             L_COD_CHG_AMT_PRDTRACK,
                                             'Y',
                                             L_ACC_CCY_CHG_TEMP,
                                             L_ACC_CHG_EXCH_RATE_TEMP,
                                             P_ERR_CODE) THEN
                    DBG('Failure in converting changed Charge amt to ac ccy amt ' ||
                        P_ERR_CODE);
                    P_RET := -1;
                    RETURN;
                  END IF;
                  DBG('Chg in acc ccy is ' || L_ACC_CCY_CHG_TEMP ||
                      ' and rate ' || L_ACC_CHG_EXCH_RATE_TEMP);
                ELSE
                  DBG('No confusion at all both are same');
                  L_ACC_CCY_CHG_TEMP       := L_COD_CHG_AMT_PRDTRACK;
                  L_ACC_CHG_EXCH_RATE_TEMP := 1;
                END IF;
              END IF;
            
            END IF;
            DBG('l_acc_ccy_chg_temp  ' || L_ACC_CCY_CHG_TEMP);
          
            IF L_PREDICTED_BAL < NVL(L_ACC_CCY_CHG_TEMP, 0)
            
             THEN
            
              DBG('Before deciding Insert in cstb_auto_settle_block_temp required or not.. ');
              IF NVL(L_ACC_CCY_CHG_TEMP, 0) > 0 THEN
              
                DBG('b4 inserting into track recievable for charges');
                G_TRACK_CHARGE_ENTRIES := 'Y';
              
                DBG('l_predicted_bal--->>>> ' || L_PREDICTED_BAL);
                IF NVL(L_PREDICTED_BAL, 0) > 0 THEN
                  LBAL2 := L_PREDICTED_BAL;
                ELSE
                  LBAL2 := 0;
                END IF;
                DBG('lbal2--->>>> ' || LBAL2);
              
                IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                  L_FN_CALL_ID      := 104;
                  DBG('b4 calling depks_rtl_teller_cluster.pr_build_chg_entries');
                  DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                                 P_CHG_ROW,
                                                                 I,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA,
                                                                 P_ERR_CODE,
                                                                 P_RET);
                  IF P_RET = -1 THEN
                    DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                        L_FN_CALL_ID);
                    RETURN;
                  END IF;
                END IF;
                IF NOT GLOBAL.G_SKIP_KERNEL THEN
                
                  BEGIN
                    INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
                      (MODULE,
                       PRODUCT,
                       CONTRACT_REF_NO,
                       COMPONENT,
                       BOOK_DATE,
                       ACCOUNT_NO,
                       ACCOUNT_BR,
                       AMOUNT_DUE,
                       AMOUNT_PAID,
                       AMOUNT_AVAILABLE,
                       AUTO_MANUAL,
                       STATUS,
                       AMTDUE_TAGCCY,
                       AMTPAID_TAGCCY)
                    VALUES
                      ('RT',
                       PKG_RTL_TELLER_REC.PRODUCT_CODE,
                       PKG_RTL_TELLER_REC.TRN_REF_NO,
                       'CHARGE',
                       PKG_RTL_TELLER_REC.VALUE_DT,
                       L_CHG_ACC
                       
                      ,
                       L_CHG_ACC_BRN
                       
                      ,
                       
                       NVL(L_ACC_CCY_CHG_TEMP, 0),
                       0
                       
                      ,
                       
                       LBAL2,
                       NULL,
                       'U',
                       NVL(L_COD_CHG_AMT, 0),
                       0);
                  EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                      DBG('in exception...will update cstb_auto_settle_block instead');
                      UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
                      
                         SET AMOUNT_DUE    = AMOUNT_DUE +
                                             NVL(L_ACC_CCY_CHG_TEMP, 0),
                             AMTDUE_TAGCCY = AMTDUE_TAGCCY +
                                             NVL(L_COD_CHG_AMT, 0),
                             
                             AMOUNT_AVAILABLE = AMOUNT_AVAILABLE + LBAL2
                       WHERE CONTRACT_REF_NO =
                             PKG_RTL_TELLER_REC.TRN_REF_NO
                            
                         AND ACCOUNT_NO = L_CHG_ACC
                            
                         AND COMPONENT = 'CHARGE';
                  END;
                END IF;
                GLOBAL.PR_RESET_SKIP_KERNEL;
              
                DBG('If gone for track receivable, setting the values');
                IF I = 1 THEN
                  PKG_RECIVABLE_AMT_DET.CHG1_TRACKED          := 'Y';
                  PKG_RECIVABLE_AMT_DET.CHG1_AC_NO            := L_CHG_ACC;
                  PKG_RECIVABLE_AMT_DET.CHG1_AC_BRANCH        := L_CHG_ACC_BRN;
                  PKG_RECIVABLE_AMT_DET.CHG1_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG1_AC_OR_GL         := L_AC_OR_GL;
                  IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS := 'TXN';
                  ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS := 'OFS';
                  END IF;
                  PKG_RECIVABLE_AMT_DET.CHG1_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
                ELSIF I = 2 THEN
                  PKG_RECIVABLE_AMT_DET.CHG2_TRACKED          := 'Y';
                  PKG_RECIVABLE_AMT_DET.CHG2_AC_NO            := L_CHG_ACC;
                  PKG_RECIVABLE_AMT_DET.CHG2_AC_BRANCH        := L_CHG_ACC_BRN;
                  PKG_RECIVABLE_AMT_DET.CHG2_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG2_AC_OR_GL         := L_AC_OR_GL;
                  IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS := 'TXN';
                  ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS := 'OFS';
                  END IF;
                  PKG_RECIVABLE_AMT_DET.CHG2_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
                ELSIF I = 3 THEN
                  PKG_RECIVABLE_AMT_DET.CHG3_TRACKED          := 'Y';
                  PKG_RECIVABLE_AMT_DET.CHG3_AC_NO            := L_CHG_ACC;
                  PKG_RECIVABLE_AMT_DET.CHG3_AC_BRANCH        := L_CHG_ACC_BRN;
                  PKG_RECIVABLE_AMT_DET.CHG3_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG3_AC_OR_GL         := L_AC_OR_GL;
                  IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS := 'TXN';
                  ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS := 'OFS';
                  END IF;
                  PKG_RECIVABLE_AMT_DET.CHG3_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
                ELSIF I = 4 THEN
                  PKG_RECIVABLE_AMT_DET.CHG4_TRACKED          := 'Y';
                  PKG_RECIVABLE_AMT_DET.CHG4_AC_NO            := L_CHG_ACC;
                  PKG_RECIVABLE_AMT_DET.CHG4_AC_BRANCH        := L_CHG_ACC_BRN;
                  PKG_RECIVABLE_AMT_DET.CHG4_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG4_AC_OR_GL         := L_AC_OR_GL;
                  IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS := 'TXN';
                  ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS := 'OFS';
                  END IF;
                  PKG_RECIVABLE_AMT_DET.CHG4_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
                ELSIF I = 5 THEN
                  PKG_RECIVABLE_AMT_DET.CHG5_TRACKED          := 'Y';
                  PKG_RECIVABLE_AMT_DET.CHG5_AC_NO            := L_CHG_ACC;
                  PKG_RECIVABLE_AMT_DET.CHG5_AC_BRANCH        := L_CHG_ACC_BRN;
                  PKG_RECIVABLE_AMT_DET.CHG5_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG5_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                                     0);
                  PKG_RECIVABLE_AMT_DET.CHG5_AC_OR_GL         := L_AC_OR_GL;
                  IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG5_TXN_OR_OFS := 'TXN';
                  ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
                    PKG_RECIVABLE_AMT_DET.CHG5_TXN_OR_OFS := 'OFS';
                  END IF;
                  PKG_RECIVABLE_AMT_DET.CHG5_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
                END IF;
              
                IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                  L_FN_CALL_ID      := 103;
                  DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                                 P_CHG_ROW,
                                                                 I,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA,
                                                                 P_ERR_CODE,
                                                                 P_RET);
                  IF P_RET = -1 THEN
                    DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                        L_FN_CALL_ID);
                    RETURN;
                  END IF;
                END IF;
                IF NOT GLOBAL.G_SKIP_KERNEL THEN
                
                  IF NVL(PKG_INS_SETTLE_BLK_DONE, 'N') = 'N' THEN
                    DBG('Previous charges are still not tracked');
                    IF NOT FN_INS_SETTLE_BLOCK(P_ACC_HAND, I) THEN
                      DBG('Error occured in insert of txn block as : ' ||
                          SQLERRM);
                    END IF;
                    DBG('Previous charges are tracked now');
                  END IF;
                
                  RAISE ACCENTRIES_NOT_TO_BE_PASSED;
                END IF;
                GLOBAL.PR_RESET_SKIP_KERNEL;
              
              ELSE
                DBG('As applied Charge is 0 so no need to track ');
                PKG_RTL_TELLER_REC.RECORD_STAT := 'A';
              END IF;
            
            ELSE
            
              PKG_RTL_TELLER_REC.RECORD_STAT := 'A';
            END IF;
          
          ELSIF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
                L_AC_OR_GL = 'A' THEN
          
            PKG_NSF_TRACKED := 'Y';
            P_CHG_SEQ       := I;
          
            DBG('P_module  ' || NVL(PKG_RTL_TELLER_REC.MODULE, 'RT'));
            DBG('p_trn_ref_no  ' || PKG_RTL_TELLER_REC.TRN_REF_NO);
            DBG('p_prod  ' || PKG_RTL_TELLER_REC.PRODUCT_CODE);
            DBG('p_txn_acc  ' || PKG_RTL_TELLER_REC.TXN_ACC);
            DBG('p_txn_amount  ' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
            DBG('p_value_dt  ' || PKG_RTL_TELLER_REC.VALUE_DT);
            DBG('p_chg_seq  ' || P_CHG_SEQ);
          
            DBG('l_chg_acc_brn  ' || L_CHG_ACC_BRN);
            DBG('l_chg_acc  ' || L_CHG_ACC);
            DBG('l_cod_chg_amt  ' || L_COD_CHG_AMT);
            DBG('l_chg_acc_ccy  ' || L_CHG_ACC_CCY);
            DBG('l_cod_chg_ccy  ' || L_COD_CHG_CCY);
            DBG('l_cod_chg_amt  ' || L_COD_CHG_AMT);
            DBG('l_cod_rate_code  ' || L_COD_RATE_CODE);
            DBG('l_cod_rate_code_type  ' || L_COD_RATE_CODE_TYPE);
            DBG('l_COD_CHG_TRACK_PRF  ' || L_COD_CHG_TRACK_PRF);
            DBG('p_chg_seq  ' || P_CHG_SEQ);
          
            DBG('pkg_arc_row.cod_net_charges   ' ||
                PKG_ARC_ROW.COD_NET_CHARGES);
          
            DBG('Before Call To cspks_arc. to decide for NSF Tracking ');
            IF NOT CSPKSS_ARC.FN_NSF_TRACKER(NVL(PKG_RTL_TELLER_REC.MODULE,
                                                 'RT'),
                                             PKG_RTL_TELLER_REC.TRN_REF_NO,
                                             PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                             PKG_RTL_TELLER_REC.BRANCH_CODE,
                                             PKG_RTL_TELLER_REC.TXN_ACC,
                                             PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                             PKG_RTL_TELLER_REC.VALUE_DT,
                                             PKG_MAIN_ENTRIES_BUILT,
                                             L_CHG_ACC_BRN,
                                             L_CHG_ACC,
                                             L_COD_CHG_AMT,
                                             L_CHG_ACC_CCY,
                                             L_COD_CHG_CCY,
                                             L_COD_RATE_CODE,
                                             L_COD_RATE_CODE_TYPE,
                                             L_COD_CHG_TRACK_PRF,
                                             P_CHG_SEQ,
                                             L_CRDR_IND,
                                             PKG_ARC_ROW.COD_NET_CHARGES,
                                             P_TRACK_CHG_ENTRY_NSF,
                                             P_COD_CHG_AMT_NSF,
                                             P_ERR_CODE,
                                             P_RET)
            
             THEN
              DBG('Failure in cspkss_arc.fn_nsf_tracker ' || P_ERR_CODE);
              P_RET := -1;
              RETURN;
            END IF;
            DBG('p_track_chg_entry_nsf  ' || P_TRACK_CHG_ENTRY_NSF);
            DBG('p_cod_chg_amt_NSF  ' || P_COD_CHG_AMT_NSF);
          
            L_COD_CHG_AMT_TEMP := L_COD_CHG_AMT;
            L_COD_CHG_AMT      := P_COD_CHG_AMT_NSF;
            IF L_COD_CHG_CCY <> PKG_LCY THEN
              L_LCY_CHG_EXCH_RATE := NULL;
              IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           L_COD_CHG_CCY,
                                           PKG_LCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_COD_CHG_AMT_TEMP,
                                           'Y',
                                           L_CHG_LCY_TEMP,
                                           L_LCY_CHG_EXCH_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            ELSE
              DBG('Am fine now');
              L_CHG_LCY_TEMP      := L_COD_CHG_AMT_TEMP;
              L_LCY_CHG_EXCH_RATE := 1;
            END IF;
          
            IF L_CHG_ACC_CCY <> L_COD_CHG_CCY THEN
              DBG('Ccys are diff ');
            
              L_ACC_CHG_EXCH_RATE := NVL(CSPKSS_ARC.G_ACC_CHG_EXCH_RATE_NSF,
                                         NULL);
            
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                            L_COD_CHG_CCY,
                                            L_CHG_ACC_CCY,
                                            NVL(L_COD_RATE_CODE, 'STANDARD'),
                                            NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_ACC_CCY_CHG,
                                            L_ACC_CHG_EXCH_RATE,
                                            P_ERR_CODE) THEN
                DBG('Failure in converting instr amt to ac ccy amt ' ||
                    P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
              DBG('Chg in acc ccy is ' || L_ACC_CCY_CHG || ' and rate ' ||
                  L_ACC_CHG_EXCH_RATE);
            ELSE
              DBG('No confusion at all 11111');
              L_ACC_CCY_CHG       := L_COD_CHG_AMT;
              L_ACC_CHG_EXCH_RATE := 1;
            END IF;
            DBG('NSF l_acc_ccy_chg  ' || L_ACC_CCY_CHG);
          
            DBG('l_cod_chg_amt_temp  ' || L_COD_CHG_AMT_TEMP);
            DBG('l_chg_lcy_temp  ' || L_CHG_LCY_TEMP);
            DBG('l_cod_chg_amt  ' || L_COD_CHG_AMT);
          END IF;
        
        END IF;
      
        DBG('If not gone for track receivable, setting the values');
        IF I = 1 THEN
          PKG_RECIVABLE_AMT_DET.CHG1_AC_NO            := L_CHG_ACC;
          PKG_RECIVABLE_AMT_DET.CHG1_AC_BRANCH        := L_CHG_ACC_BRN;
          PKG_RECIVABLE_AMT_DET.CHG1_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG1_AC_OR_GL         := L_AC_OR_GL;
          IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS := 'TXN';
          ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG1_TXN_OR_OFS := 'OFS';
          END IF;
          PKG_RECIVABLE_AMT_DET.CHG1_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        ELSIF I = 2 THEN
          PKG_RECIVABLE_AMT_DET.CHG2_AC_NO            := L_CHG_ACC;
          PKG_RECIVABLE_AMT_DET.CHG2_AC_BRANCH        := L_CHG_ACC_BRN;
          PKG_RECIVABLE_AMT_DET.CHG2_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG2_AC_OR_GL         := L_AC_OR_GL;
          IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS := 'TXN';
          ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG2_TXN_OR_OFS := 'OFS';
          END IF;
          PKG_RECIVABLE_AMT_DET.CHG2_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        ELSIF I = 3 THEN
          PKG_RECIVABLE_AMT_DET.CHG3_AC_NO            := L_CHG_ACC;
          PKG_RECIVABLE_AMT_DET.CHG3_AC_BRANCH        := L_CHG_ACC_BRN;
          PKG_RECIVABLE_AMT_DET.CHG3_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG3_AC_OR_GL         := L_AC_OR_GL;
          IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS := 'TXN';
          ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG3_TXN_OR_OFS := 'OFS';
          END IF;
          PKG_RECIVABLE_AMT_DET.CHG3_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        ELSIF I = 4 THEN
          PKG_RECIVABLE_AMT_DET.CHG4_AC_NO            := L_CHG_ACC;
          PKG_RECIVABLE_AMT_DET.CHG4_AC_BRANCH        := L_CHG_ACC_BRN;
          PKG_RECIVABLE_AMT_DET.CHG4_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG4_AC_OR_GL         := L_AC_OR_GL;
          IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS := 'TXN';
          ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG4_TXN_OR_OFS := 'OFS';
          END IF;
          PKG_RECIVABLE_AMT_DET.CHG4_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        ELSIF I = 5 THEN
          PKG_RECIVABLE_AMT_DET.CHG5_AC_NO            := L_CHG_ACC;
          PKG_RECIVABLE_AMT_DET.CHG5_AC_BRANCH        := L_CHG_ACC_BRN;
          PKG_RECIVABLE_AMT_DET.CHG5_ACCY_AMT_TRACKED := NVL(L_ACC_CCY_CHG_TEMP,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG5_COD_CHG_AMT      := NVL(L_COD_CHG_AMT,
                                                             0);
          PKG_RECIVABLE_AMT_DET.CHG5_AC_OR_GL         := L_AC_OR_GL;
          IF (L_CHG_ACC = PKG_RTL_TELLER_REC.TXN_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG5_TXN_OR_OFS := 'TXN';
          ELSIF (L_CHG_ACC = PKG_RTL_TELLER_REC.OFS_ACC) THEN
            PKG_RECIVABLE_AMT_DET.CHG5_TXN_OR_OFS := 'OFS';
          END IF;
          PKG_RECIVABLE_AMT_DET.CHG5_ACC_TRACK_ALLOWED := L_ACCOUNT_TRACKING_ALLOWED;
        END IF;
      
        DBG('Now for the lcy part');
      
        DBG('l_cod_chg_ccy is ' || L_COD_CHG_CCY || ' pkg_lcy is' ||
            PKG_LCY || ' and l_chg_acc_ccy is' || L_CHG_ACC_CCY);
        IF L_COD_CHG_CCY <> PKG_LCY AND L_COD_CHG_CCY <> L_CHG_ACC_CCY THEN
        
          L_LCY_CHG_EXCH_RATE := NVL(CSPKSS_ARC.G_ACC_CHG_EXCH_RATE_NSF,
                                     NULL);
        
          IF L_COD_CHG_AMT > 0 THEN
          
            IF PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('DPOW','NCSF') AND
               PKG_RTL_TELLER_REC.TXN_CCY IN ('KHR', 'USD') AND
               PKG_RTL_TELLER_REC.OFS_CCY IN ('USD', 'KHR') AND
               PKG_TXN_ACC.AC_GL_CCY IN ('KHR', 'USD') AND
               L_COD_CHG_CCY IN ('USD', 'KHR') AND
               L_CHG_ACC_CCY IN ('KHR', 'USD') THEN
              --sampath cardless withdrawal
            
              DBG('L_COD_CHG_AMT L_COD_CHG_AMT=' || L_COD_CHG_AMT);
              DBG('PKG_RTL_TELLER_REC.Exch_Rate=' ||
                  PKG_RTL_TELLER_REC.Exch_Rate);
            
              IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                            L_COD_CHG_CCY,
                                            L_CHG_ACC_CCY,
                                            PKG_PROD.RATE_TYPE_PREFERRED,
                                            PKG_PROD.RATE_CODE_PREFERRED,
                                            L_COD_CHG_AMT,
                                            'Y',
                                            L_CHG_LCY,
                                            PKG_RTL_TELLER_REC.Exch_Rate, --L_ACC_CHG_EXCH_RATE,
                                            P_ERR_CODE) THEN
                DBG('Failure in converting instr amt to ac ccy amt ' ||
                    P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
              L_LCY_CHG_EXCH_RATE := PKG_RTL_TELLER_REC.Exch_Rate;
            
            ELSE
              --sampath cardless withdrawal
              IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           L_COD_CHG_CCY,
                                           PKG_LCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_COD_CHG_AMT,
                                           'Y',
                                           L_CHG_LCY,
                                           L_LCY_CHG_EXCH_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
            END IF; --sampath cardless withdrawal
          
          ELSE
            L_CHG_LCY := L_COD_CHG_AMT;
          END IF;
        
        ELSIF L_COD_CHG_CCY <> PKG_LCY AND L_COD_CHG_CCY = L_CHG_ACC_CCY THEN
          DBG('Picking the mid rate for charge computation');
          L_LCY_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       L_COD_CHG_CCY,
                                       PKG_LCY,
                                       'STANDARD',
                                       'M',
                                       L_COD_CHG_AMT,
                                       'Y',
                                       L_CHG_LCY,
                                       L_LCY_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        
        ELSE
          DBG('Am fine now');
          L_CHG_LCY           := L_COD_CHG_AMT;
          L_LCY_CHG_EXCH_RATE := 1;
        END IF;
      
        L_LCY_CHG_EXCH_RATE1 := L_LCY_CHG_EXCH_RATE;
      
        P_ACC_HAND(J).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
        P_ACC_HAND(J).MIS_HEAD := L_COD_MIS_HEAD;
        P_ACC_HAND(J).AVLDAYS := 0;
        P_ACC_HAND(J).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
        P_ACC_HAND(J).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
        P_ACC_HAND(J).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE, 'INIT');
        P_ACC_HAND(J).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
      
        P_ACC_HAND(J).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
      
        P_ACC_HAND(J).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        P_ACC_HAND(J).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
        P_ACC_HAND(J).BATCH_NO := NULL;
        P_ACC_HAND(J).CURR_NO := NULL;
      
        P_ACC_HAND(J).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
        DBG('The utils makerid is:' || GWPKS_UTIL.G_MAKERID ||
            ' with global user as:' || GLOBAL.USER_ID);
      
        P_ACC_HAND(J).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
        P_ACC_HAND(J).DRCR_IND := 'C';
      
        BEGIN
          SELECT AC_OR_GL
            INTO L_ACCOUNT_TYPE
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = L_COD_CHG_GL;
        EXCEPTION
          WHEN OTHERS THEN
            L_ACCOUNT_TYPE := 'X';
        END;
        DBG('l_cod_chg_gl' || L_COD_CHG_GL);
        DBG('l_chg_acc' || L_CHG_ACC);
        DBG('l_account_type' || L_ACCOUNT_TYPE);
        IF (L_ACCOUNT_TYPE = 'G') THEN
          P_ACC_HAND(J).RELATED_ACCOUNT := L_CHG_ACC;
        END IF;
      
        IF ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT IS NOT NULL THEN
          DBG('Assigning the dbgrelated account for normal charges' ||
              ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT);
          P_ACC_HAND(J).RELATED_ACCOUNT := ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT;
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID       := 3;
          L_TBL_CLUSTER_DATA := L_TBL_CLUSTER_DATA_EMPTY;
          DBG('Calling depks_rtl_teller_cluster.pr_build_chg_entries.. ');
          DBG('Value of j is ' || J);
          L_TBL_CLUSTER_DATA('j') := J;
          DBG('Calling depks_rtl_teller_cluster.pr_build_chg_entries after assigning the value of j');
          DEPKS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                        P_CHG_ROW,
                                                        I,
                                                        
                                                        P_RET,
                                                        P_ERR_CODE,
                                                        L_FN_CALL_ID,
                                                        L_TBL_CLUSTER_DATA);
          DBG('Failed in depks_rtl_teller_cluster.pr_build_chg_entries..' ||
              P_ERR_CODE);
        
          IF P_RET = -1 THEN
            DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
            RETURN;
          END IF;
        
        END IF;
      
        P_ACC_HAND(J).TRN_CODE := L_COD_CHG_TXN_CODE;
        P_ACC_HAND(J).AMOUNT_TAG := 'CHG_AMT' || I;
        P_ACC_HAND(J).NETTING_IND := L_COD_CHG_NETTING;
        P_ACC_HAND(J).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
        P_ACC_HAND(J).AC_NO := L_COD_CHG_GL;
        P_ACC_HAND(J).AC_CCY := L_COD_CHG_CCY;
      
        IF PKG_RTL_TELLER_REC.PRODUCT_CODE IS NOT NULL THEN
          DBG('pkg_rtl_teller_rec.product_code' ||
              PKG_RTL_TELLER_REC.PRODUCT_CODE);
          P_ACC_HAND(J).PRODUCT := PKG_RTL_TELLER_REC.PRODUCT_CODE;
          P_ACC_HAND(J + 1).PRODUCT := PKG_RTL_TELLER_REC.PRODUCT_CODE;
        END IF;
      
        DBG('The credit instrument code 2 is:' ||
            PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE);
        DBG('The debit instrument code 2 is:' ||
            PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
      
        P_ACC_HAND(J).INSTRUMENT_CODE := NVL(PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE,
                                             PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
      
        IF P_CHG_ROW.COD_BRANCH = '*.*' THEN
          L_BRN := GLOBAL.CURRENT_BRANCH;
        ELSE
          L_BRN := P_CHG_ROW.COD_BRANCH;
        END IF;
        P_ACC_HAND(J).AC_BRANCH := L_BRN;
        P_ACC_HAND(J).LCY_AMOUNT := L_CHG_LCY;
        IF L_COD_CHG_CCY <> PKG_LCY THEN
          P_ACC_HAND(J).FCY_AMOUNT := L_COD_CHG_AMT;
          P_ACC_HAND(J).EXCH_RATE := L_LCY_CHG_EXCH_RATE;
        ELSE
          P_ACC_HAND(J).FCY_AMOUNT := NULL;
          P_ACC_HAND(J).EXCH_RATE := NULL;
        END IF;
        DBG('333333333');
      
        IF L_COD_CHG_AMT = 0 THEN
          P_ACC_HAND(J).AC_CCY := PKG_LCY;
          P_ACC_HAND(J).LCY_AMOUNT := 0;
        
          P_ACC_HAND(J).FCY_AMOUNT := 0;
          P_ACC_HAND(J).EXCH_RATE := NULL;
        
        END IF;
      
        DBG('In pr_build_chg_entries');
        DBG('The account currency is:' || L_CHG_ACC_CCY ||
            ' with charge ccy in Arc as:' || L_COD_CHG_CCY);
        DBG('The transaction currency is:' || PKG_RTL_TELLER_REC.TXN_CCY ||
            ' with offset currency as:' || PKG_RTL_TELLER_REC.OFS_CCY);
        IF (L_CHG_ACC_CCY <> L_COD_CHG_CCY) AND (L_COD_CHG_CCY = PKG_LCY) THEN
          DBG('The account currency exchange rate and LCY Exchange rate to be made same with chg lcy amount as:' ||
              L_CHG_LCY);
          DBG('The cod charge amount is:' || L_COD_CHG_AMT);
          L_CHG_LCY           := NVL(L_CHG_LCY, L_COD_CHG_AMT);
          L_LCY_CHG_EXCH_RATE := L_ACC_CHG_EXCH_RATE;
          DBG('The account currency rate is:' || L_LCY_CHG_EXCH_RATE ||
              ' with charge local lcy as:' || L_CHG_LCY);
        ELSE
        
          DBG('l_cod_chg_ccy is ' || L_COD_CHG_CCY || ' pkg_lcy is' ||
              PKG_LCY || ' and l_chg_acc_ccy is' || L_CHG_ACC_CCY);
          IF L_CHG_ACC_CCY <> PKG_LCY AND L_CHG_ACC_CCY <> L_COD_CHG_CCY THEN
          
            L_TEMP_CHG          := L_CHG_LCY;
            L_CHG_LCY           := NULL;
            L_LCY_CHG_EXCH_RATE := NULL;
          
            IF L_ACC_CCY_CHG > 0 THEN
            
              IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           PKG_LCY,
                                           L_CHG_ACC_CCY,
                                           NVL(L_COD_RATE_CODE, 'STANDARD'),
                                           NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                           L_ACC_CCY_CHG,
                                           'Y',
                                           L_CHG_LCY,
                                           L_LCY_CHG_EXCH_RATE,
                                           P_ERR_CODE) THEN
                DBG('Failed while findin xch rate ' || P_ERR_CODE);
                P_RET := -1;
                RETURN;
              END IF;
            
            ELSE
              L_CHG_LCY := L_ACC_CCY_CHG;
            END IF;
          
            L_CHG_LCY := L_TEMP_CHG;
          
          ELSIF L_CHG_ACC_CCY <> PKG_LCY AND L_CHG_ACC_CCY = L_COD_CHG_CCY THEN
            DBG('Picking the mid rate for charge computation');
            L_LCY_CHG_EXCH_RATE := NULL;
            IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                         L_CHG_ACC_CCY,
                                         PKG_LCY,
                                         'STANDARD',
                                         'M',
                                         L_ACC_CCY_CHG,
                                         'Y',
                                         L_CHG_LCY,
                                         L_LCY_CHG_EXCH_RATE,
                                         P_ERR_CODE) THEN
              DBG('Failed while findin xch rate ' || P_ERR_CODE);
              P_RET := -1;
              RETURN;
            END IF;
          
          ELSE
            DBG('Am fine now');
            L_CHG_LCY           := L_ACC_CCY_CHG;
            L_LCY_CHG_EXCH_RATE := 1;
          END IF;
        END IF;
      
        DBG(' PRODUCT CODE IS ' || PKG_RTL_TELLER_REC.PRODUCT_CODE);
      
        L_PRODUCT_TYPE := PKG_PROD.PRODUCT_TYPE;
      
        DBG(' product_type IS ' || L_PRODUCT_TYPE);
        IF L_PRODUCT_TYPE IN ('IL', 'IS', 'AT') THEN
          DBG('The product type is:' || L_PRODUCT_TYPE ||
              ' with product code as:' || PKG_RTL_TELLER_REC.PRODUCT_CODE);
          L_CHG_IN_TCY_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
        ELSE
          L_CHG_IN_TCY_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
        END IF;
        DBG(' l_chg_in_tcy_ccy IS ' || L_CHG_IN_TCY_CCY);
        DBG(' l_cod_chg_ccy    IS ' || L_COD_CHG_CCY);
      
        IF L_COD_CHG_CCY <> L_CHG_IN_TCY_CCY THEN
        
          L_CHG_TCY           := NULL;
          L_TCY_CHG_EXCH_RATE := NULL;
        
          DBG('l_tcy_chg_exch_rate ' || I || ' ' || L_LCY_CHG_EXCH_RATE1);
        
          IF L_COD_CHG_AMT > 0 THEN
          
            IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                         L_COD_CHG_CCY,
                                         L_CHG_IN_TCY_CCY,
                                         NVL(L_COD_RATE_CODE, 'STANDARD'),
                                         NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                         L_COD_CHG_AMT,
                                         'Y',
                                         L_CHG_TCY,
                                         L_TCY_CHG_EXCH_RATE,
                                         P_ERR_CODE) THEN
              DBG('Failed while findin xch rate ' || P_ERR_CODE);
              P_RET := -1;
              RETURN;
            END IF;
          
          ELSE
            L_CHG_TCY := L_COD_CHG_AMT;
          END IF;
        
        ELSE
          DBG('Am fine now');
          L_CHG_TCY           := L_COD_CHG_AMT;
          L_TCY_CHG_EXCH_RATE := 1;
        END IF;
      
        IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND L_AC_OR_GL = 'A' THEN
          IF L_COD_CHG_CCY <> L_CHG_IN_TCY_CCY AND L_COD_CHG_AMT_TEMP > 0 THEN
          
            L_CHG_TCY           := NULL;
            L_TCY_CHG_EXCH_RATE := NULL;
          
            DBG('l_tcy_chg_exch_rate ' || I || ' ' || L_LCY_CHG_EXCH_RATE1);
          
            IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                         L_COD_CHG_CCY,
                                         L_CHG_IN_TCY_CCY,
                                         NVL(L_COD_RATE_CODE, 'STANDARD'),
                                         NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                         L_COD_CHG_AMT_TEMP,
                                         'Y',
                                         L_CHG_TCY,
                                         L_TCY_CHG_EXCH_RATE,
                                         P_ERR_CODE) THEN
              DBG('Failed while findin xch rate ' || P_ERR_CODE);
              P_RET := -1;
              RETURN;
            END IF;
          ELSE
            DBG('Am fine now');
            L_CHG_TCY := L_COD_CHG_AMT_TEMP;
            DBG('l_chg_tcy 22222 ' || L_CHG_TCY);
            L_TCY_CHG_EXCH_RATE := 1;
          END IF;
        END IF;
      
        SELECT DECODE(L_CHG_ACC_BRN,
                      '*.*',
                      GLOBAL.CURRENT_BRANCH,
                      L_CHG_ACC_BRN)
          INTO L_BRANCH
          FROM DUAL;
        P_ACC_HAND(J + 1).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
        P_ACC_HAND(J + 1).MIS_HEAD := L_COD_MIS_HEAD;
        P_ACC_HAND(J + 1).AVLDAYS := 0;
        P_ACC_HAND(J + 1).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
        P_ACC_HAND(J + 1).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
        P_ACC_HAND(J + 1).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE,
                                       'INIT');
        P_ACC_HAND(J + 1).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
      
        P_ACC_HAND(J + 1).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
      
        P_ACC_HAND(J + 1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        P_ACC_HAND(J + 1).BATCH_NO := NULL;
        P_ACC_HAND(J + 1).CURR_NO := NULL;
      
        P_ACC_HAND(J + 1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                         GLOBAL.USER_ID);
        DBG('The utils makerid is:' || GWPKS_UTIL.G_MAKERID ||
            ' with global user as:' || GLOBAL.USER_ID);
      
        P_ACC_HAND(J + 1).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID,
                                         GLOBAL.USER_ID);
        P_ACC_HAND(J + 1).DRCR_IND := 'D';
        IF ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT IS NOT NULL THEN
          DBG('Assigning the dbgrelated accountfor noraml charges' ||
              ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT);
          P_ACC_HAND(J + 1).RELATED_ACCOUNT := ICPKS_FCJ_ICDREDMN.G_RELATEDPARTIAL_ACCOUNT;
        END IF;
      
        P_ACC_HAND(J + 1).TRN_CODE := L_COD_CHG_TXN_CODE;
        P_ACC_HAND(J + 1).AMOUNT_TAG := 'CHG_AMT' || I;
        P_ACC_HAND(J + 1).NETTING_IND := L_COD_CHG_NETTING;
        P_ACC_HAND(J + 1).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
        P_ACC_HAND(J + 1).AC_NO := L_CHG_ACC;
        P_ACC_HAND(J + 1).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
      
        P_ACC_HAND(J + 1).AC_BRANCH := L_BRANCH;
      
        IF L_COD_CHG_AMT = 0 THEN
          P_ACC_HAND(J + 1).AC_CCY := L_COD_CHG_CCY;
        ELSE
          P_ACC_HAND(J + 1).AC_CCY := L_CHG_ACC_CCY;
        END IF;
      
        P_ACC_HAND(J + 1).LCY_AMOUNT := L_CHG_LCY;
        P_ACC_HAND(J + 1).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
      
        DBG('The gwpks_util.pkg_func is:' || GWPKS_UTIL.PKG_FUNC);
        IF GWPKS_UTIL.PKG_FUNC = '6560' THEN
          DBG('The credit instrument code 6560:' ||
              GWPKS_REJECTCGCONTRACT.G_INSTR_NO);
          P_ACC_HAND(J + 1).INSTRUMENT_CODE := GWPKS_REJECTCGCONTRACT.G_INSTR_NO;
        END IF;
      
        DBG('The credit instrument code 3 is:' ||
            PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE);
        DBG('The debit instrument code 3 is:' ||
            PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
        IF P_ACC_HAND(J)
         .INSTRUMENT_CODE IS NULL AND P_ACC_HAND(J + 1).INSTRUMENT_CODE IS NOT NULL THEN
          P_ACC_HAND(J).INSTRUMENT_CODE := P_ACC_HAND(J + 1).INSTRUMENT_CODE;
        END IF;
      
        IF L_CHG_ACC_CCY <> PKG_LCY THEN
        
          IF L_COD_CHG_AMT = 0 THEN
            P_ACC_HAND(J + 1).FCY_AMOUNT := 0;
            P_ACC_HAND(J + 1).EXCH_RATE := NULL;
          ELSE
            P_ACC_HAND(J + 1).FCY_AMOUNT := L_ACC_CCY_CHG;
            P_ACC_HAND(J + 1).EXCH_RATE := L_LCY_CHG_EXCH_RATE;
          END IF;
        
        ELSE
          P_ACC_HAND(J + 1).FCY_AMOUNT := NULL;
          P_ACC_HAND(J + 1).EXCH_RATE := NULL;
        END IF;
      
        IF L_COD_CHG_AMT = 0 THEN
          P_ACC_HAND(J + 1).AC_CCY := PKG_LCY;
          P_ACC_HAND(J + 1).LCY_AMOUNT := 0;
        
          P_ACC_HAND(J + 1).FCY_AMOUNT := 0;
          P_ACC_HAND(J + 1).EXCH_RATE := NULL;
        END IF;
      
        IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND L_AC_OR_GL = 'A' THEN
          L_COD_CHG_AMT := L_COD_CHG_AMT_TEMP;
          DBG('l_cod_chg_amt_temp  ' || L_COD_CHG_AMT_TEMP);
          DBG('l_cod_chg_amt  ' || L_COD_CHG_AMT);
          DBG('l_chg_lcy_temp  ' || L_CHG_LCY_TEMP);
        END IF;
      
        IF I = 1 THEN
          PKG_RTL_TELLER_REC.CHG_IN_ACY := L_ACC_CCY_CHG;
        
          DBG('pkg_rtl_teller_rec.track_receivable ->' ||
              PKG_RTL_TELLER_REC.TRACK_RECEIVABLE || '~' || I);
          IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
             L_AC_OR_GL = 'A' AND
             PKG_RTL_TELLER_REC.TRACK_RECEIVABLE != 'Y' THEN
            PKG_RTL_TELLER_REC.CHG_IN_LCY := L_CHG_LCY_TEMP;
          ELSE
            PKG_RTL_TELLER_REC.CHG_IN_LCY := P_ACC_HAND(J + 1).LCY_AMOUNT;
          END IF;
        
          PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE := L_LCY_CHG_EXCH_RATE1;
        ELSIF I = 2 THEN
          PKG_RTL_TELLER_REC.CHG_IN_ACY_1 := L_ACC_CCY_CHG;
        
          DBG('pkg_rtl_teller_rec.track_receivable ->' ||
              PKG_RTL_TELLER_REC.TRACK_RECEIVABLE || '~' || I);
          IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
             L_AC_OR_GL = 'A' AND
             PKG_RTL_TELLER_REC.TRACK_RECEIVABLE != 'Y' THEN
            PKG_RTL_TELLER_REC.CHG_IN_LCY_1 := L_CHG_LCY_TEMP;
          ELSE
            PKG_RTL_TELLER_REC.CHG_IN_LCY_1 := P_ACC_HAND(J + 1).LCY_AMOUNT;
          END IF;
        
          PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1 := L_LCY_CHG_EXCH_RATE1;
        ELSIF I = 3 THEN
          PKG_RTL_TELLER_REC.CHG_IN_ACY_2 := L_ACC_CCY_CHG;
        
          DBG('pkg_rtl_teller_rec.track_receivable ->' ||
              PKG_RTL_TELLER_REC.TRACK_RECEIVABLE || '~' || I);
          IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
             L_AC_OR_GL = 'A' AND
             PKG_RTL_TELLER_REC.TRACK_RECEIVABLE != 'Y' THEN
            PKG_RTL_TELLER_REC.CHG_IN_LCY_2 := L_CHG_LCY_TEMP;
          ELSE
            PKG_RTL_TELLER_REC.CHG_IN_LCY_2 := P_ACC_HAND(J + 1).LCY_AMOUNT;
          END IF;
        
          PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2 := L_LCY_CHG_EXCH_RATE1;
        ELSIF I = 4 THEN
          PKG_RTL_TELLER_REC.CHG_IN_ACY_3 := L_ACC_CCY_CHG;
        
          DBG('pkg_rtl_teller_rec.track_receivable ->' ||
              PKG_RTL_TELLER_REC.TRACK_RECEIVABLE || '~' || I);
          IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
             L_AC_OR_GL = 'A' AND
             PKG_RTL_TELLER_REC.TRACK_RECEIVABLE != 'Y' THEN
            PKG_RTL_TELLER_REC.CHG_IN_LCY_3 := L_CHG_LCY_TEMP;
          ELSE
            PKG_RTL_TELLER_REC.CHG_IN_LCY_3 := P_ACC_HAND(J + 1).LCY_AMOUNT;
          END IF;
        
          PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3 := L_LCY_CHG_EXCH_RATE1;
        ELSIF I = 5 THEN
          PKG_RTL_TELLER_REC.CHG_IN_ACY_4 := L_ACC_CCY_CHG;
        
          DBG('pkg_rtl_teller_rec.track_receivable ->' ||
              PKG_RTL_TELLER_REC.TRACK_RECEIVABLE || '~' || I);
          IF NVL(L_COD_CHG_TRACK_PRF, 'N') NOT IN ('N') AND
             L_AC_OR_GL = 'A' AND
             PKG_RTL_TELLER_REC.TRACK_RECEIVABLE != 'Y' THEN
            PKG_RTL_TELLER_REC.CHG_IN_LCY_4 := L_CHG_LCY_TEMP;
          ELSE
            PKG_RTL_TELLER_REC.CHG_IN_LCY_4 := P_ACC_HAND(J + 1).LCY_AMOUNT;
          END IF;
        
          PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4 := L_LCY_CHG_EXCH_RATE1;
        END IF;
      
        IF GWPKS_UTIL.PKG_ACTTYPE IS NOT NULL THEN
        
          DBG('gwpks_util.pkg_temp_chg_dets ' ||
              GWPKS_UTIL.PKG_TEMP_CHG_DETS);
          BEGIN
            L_WAIVER := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                ((I - 1) * 7) + 1,
                                                '~');
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          DBG('l_waiver ' || L_WAIVER);
        
          DBG('Action code ->' || CSPKSS_CHARGE.G_ACTION_CODE);
          IF CSPKSS_CHARGE.G_ACTION_CODE = 'CHGPKUP' AND
             NVL(L_WAIVER, 'N') = 'N' THEN
            DBG('inside if assigning default charge waiver flage');
            L_WAIVER := CSPKSS_CHARGE.G_DEFAULT_WAIVER;
          END IF;
          DBG('waiver after :' || L_WAIVER);
        
          IF I = 1 THEN
            PKG_RTL_TELLER_REC.WAIVER := NVL(L_WAIVER, 'N');
            DBG('pkg_rtl_teller_rec.waiver :' || PKG_RTL_TELLER_REC.WAIVER);
          ELSIF I = 2 THEN
            PKG_RTL_TELLER_REC.WAIVER1 := NVL(L_WAIVER, 'N');
            DBG('pkg_rtl_teller_rec.waiver1 :' ||
                PKG_RTL_TELLER_REC.WAIVER1);
          ELSIF I = 3 THEN
            PKG_RTL_TELLER_REC.WAIVER2 := NVL(L_WAIVER, 'N');
            DBG('pkg_rtl_teller_rec.waiver :' ||
                PKG_RTL_TELLER_REC.WAIVER2);
          ELSIF I = 4 THEN
            PKG_RTL_TELLER_REC.WAIVER3 := NVL(L_WAIVER, 'N');
            DBG('pkg_rtl_teller_rec.waiver3 :' ||
                PKG_RTL_TELLER_REC.WAIVER3);
          ELSIF I = 5 THEN
            PKG_RTL_TELLER_REC.WAIVER4 := NVL(L_WAIVER, 'N');
            DBG('pkg_rtl_teller_rec.waiver4 :' ||
                PKG_RTL_TELLER_REC.WAIVER4);
          END IF;
        
          PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY +
                                               L_CHG_TCY;
        
          IF STPKSS_ACCOUNT_CLOSE.G_CLS_ONLINE_CHG_ROUTE = 'Y' THEN
          
            DBG('Here in depks_rtl_teller in online charge closure route....');
            G_ONLINE_CHARGE := PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY;
            DBG('g_online_charge :: ' || G_ONLINE_CHARGE);
          
            DBG('l_chg_dr_leg in Online charge closure route...' ||
                L_CHG_DR_LEG);
            IF L_CHG_DR_LEG = 'TXN_ACC' THEN
              DEPKS_RTL_TELLER.G_RED_AMT := DEPKS_RTL_TELLER.G_RED_AMT +
                                            L_CHG_TCY;
              PKG_RED_AMT                := DEPKSS_RTL_TELLER.G_RED_AMT;
              DBG('Value of pkg_red_amt in online charge closure route.... :: ' ||
                  PKG_RED_AMT);
              DBG('Value of depks_rtl_teller.g_red_amt in online charge closure route.... :: ' ||
                  DEPKS_RTL_TELLER.G_RED_AMT);
            END IF;
          
          END IF;
        
        END IF;
      
        IF CSPKSS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKSS_REQ_GLOBAL.P_CLUSTER, CSPKSS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID := 102;
          L_TB_CLUSTER_DATA('j') := J;
        
          L_TB_CLUSTER_DATA('lcy_amount') := L_CHG_LCY;
          L_TB_CLUSTER_DATA('l_chg_acc') := L_CHG_ACC;
          L_TB_CLUSTER_DATA('l_chg_acc_brn') := L_CHG_ACC_BRN;
          L_TB_CLUSTER_DATA('l_acc_ccy_chg') := L_ACC_CCY_CHG;
          L_TB_CLUSTER_DATA('l_cod_chg_ccy') := L_COD_CHG_CCY;
          L_TB_CLUSTER_DATA('l_chg_acc_ccy') := L_CHG_ACC_CCY;
          L_TB_CLUSTER_DATA('l_cod_chg_amt') := L_COD_CHG_AMT;
          L_TB_CLUSTER_DATA('l_ac_or_gl') := L_AC_OR_GL;
          L_TB_CLUSTER_DATA('l_predicted_bal') := L_PREDICTED_BAL;
        
          IF I = 1 THEN
            L_TB_CLUSTER_DATA('CHG1_TRACKED') := NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED,
                                                     'N');
            L_TB_CLUSTER_DATA('CHG1_ACC_TRACK_ALLOWED') := NVL(PKG_RECIVABLE_AMT_DET.CHG1_ACC_TRACK_ALLOWED,
                                                               'N');
          ELSIF I = 2 THEN
            L_TB_CLUSTER_DATA('CHG2_TRACKED') := NVL(PKG_RECIVABLE_AMT_DET.CHG2_TRACKED,
                                                     'N');
            L_TB_CLUSTER_DATA('CHG2_ACC_TRACK_ALLOWED') := NVL(PKG_RECIVABLE_AMT_DET.CHG2_ACC_TRACK_ALLOWED,
                                                               'N');
          ELSIF I = 3 THEN
            L_TB_CLUSTER_DATA('CHG3_TRACKED') := NVL(PKG_RECIVABLE_AMT_DET.CHG3_TRACKED,
                                                     'N');
            L_TB_CLUSTER_DATA('CHG3_ACC_TRACK_ALLOWED') := NVL(PKG_RECIVABLE_AMT_DET.CHG3_ACC_TRACK_ALLOWED,
                                                               'N');
          ELSIF I = 4 THEN
            L_TB_CLUSTER_DATA('CHG4_TRACKED') := NVL(PKG_RECIVABLE_AMT_DET.CHG4_TRACKED,
                                                     'N');
            L_TB_CLUSTER_DATA('CHG4_ACC_TRACK_ALLOWED') := NVL(PKG_RECIVABLE_AMT_DET.CHG4_ACC_TRACK_ALLOWED,
                                                               'N');
          ELSIF I = 5 THEN
            L_TB_CLUSTER_DATA('CHG5_TRACKED') := NVL(PKG_RECIVABLE_AMT_DET.CHG5_TRACKED,
                                                     'N');
            L_TB_CLUSTER_DATA('CHG5_ACC_TRACK_ALLOWED') := NVL(PKG_RECIVABLE_AMT_DET.CHG5_ACC_TRACK_ALLOWED,
                                                               'N');
          END IF;
          L_TB_CLUSTER_DATA('track_charge_entries') := 'N';
          L_TB_CLUSTER_DATA('balance_available') := 0;
          L_TB_CLUSTER_DATA('tax_on_charge') := 0;
          L_TB_CLUSTER_DATA('acy_tax_on_charge') := 0;
          DBG('b4 calling depks_rtl_teller_cluster.pr_build_chg_entries');
        
          DEPKSS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                         P_CHG_ROW,
                                                         I,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA,
                                                         P_ERR_CODE,
                                                         P_RET);
          IF P_RET = -1 THEN
            DBG('Failed in cluster/custom layer for l_fn_call_id >> ' ||
                L_FN_CALL_ID);
            RETURN;
          END IF;
          DBG('l_cod_chg_amt >>before  is ' || L_COD_CHG_AMT);
          DBG('l_acc_ccy_chg >> before  is ' || L_ACC_CCY_CHG);
          IF L_TB_CLUSTER_DATA('track_charge_entries') = 'Y' THEN
            DBG('l_cod_chg_amt >> is ' || L_COD_CHG_AMT);
            DBG('l_acc_ccy_chg >> is ' || L_ACC_CCY_CHG);
            LBAL          := TO_NUMBER(L_TB_CLUSTER_DATA('balance_available'));
            L_COD_CHG_AMT := L_COD_CHG_AMT +
                             TO_NUMBER(L_TB_CLUSTER_DATA('tax_on_charge'));
            L_ACC_CCY_CHG := L_ACC_CCY_CHG +
                             TO_NUMBER(L_TB_CLUSTER_DATA('acy_tax_on_charge'));
          
            G_TRACK_CHARGE_ENTRIES := 'Y';
            DBG('l_acc_ccy_chg value for first time ' || L_ACC_CCY_CHG);
          
            BEGIN
              INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
                (MODULE,
                 PRODUCT,
                 CONTRACT_REF_NO,
                 COMPONENT,
                 BOOK_DATE,
                 ACCOUNT_NO,
                 ACCOUNT_BR,
                 AMOUNT_DUE,
                 AMOUNT_PAID,
                 AMOUNT_AVAILABLE,
                 AUTO_MANUAL,
                 STATUS,
                 AMTDUE_TAGCCY,
                 AMTPAID_TAGCCY)
              VALUES
                ('RT',
                 PKG_RTL_TELLER_REC.PRODUCT_CODE,
                 PKG_RTL_TELLER_REC.TRN_REF_NO,
                 'CHARGE',
                 PKG_RTL_TELLER_REC.VALUE_DT,
                 L_CHG_ACC,
                 
                 L_CHG_ACC_BRN,
                 NVL(L_ACC_CCY_CHG, 0),
                 0,
                 LBAL,
                 NULL,
                 'U',
                 NVL(L_COD_CHG_AMT, 0),
                 0);
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG('in exception...will update cstb_auto_settle_block instead');
                UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
                   SET AMOUNT_DUE       = AMOUNT_DUE + NVL(L_ACC_CCY_CHG, 0),
                       AMTDUE_TAGCCY    = AMTDUE_TAGCCY +
                                          NVL(L_COD_CHG_AMT, 0),
                       AMOUNT_AVAILABLE = LBAL
                 WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
                      
                   AND ACCOUNT_NO = L_CHG_ACC
                   AND COMPONENT = 'CHARGE';
            END;
          
            RAISE ACCENTRIES_NOT_TO_BE_PASSED;
          ELSE
          
            PKG_RTL_TELLER_REC.RECORD_STAT := 'A';
          END IF;
        END IF;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
      DBG('To ret true now ');
      P_RET := 0;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
        DBG('Calling depks_rtl_teller_custom.fn_save');
        DEPKS_RTL_TELLER_CLUSTER.PR_BUILD_CHG_ENTRIES(P_ACC_HAND,
                                                      
                                                      P_CHG_ROW,
                                                      I,
                                                      P_RET,
                                                      
                                                      P_ERR_CODE,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
      
        IF P_RET = -1 THEN
          DBG('Failure has happened in depks_rtl_teller_cluster.pr_build_chg_entries');
          RETURN;
        
        END IF;
      END IF;
    
    END IF;
    RETURN;
  EXCEPTION
    WHEN ACCENTRIES_NOT_TO_BE_PASSED THEN
      P_RET := 2;
      DBG('returning 2 to fn_save from pr_build_chg_entries ..no entries will be passed for this contract..Uninitiated');
    WHEN OTHERS THEN
      DBG('Error in pr_build_chg_entries ' || SQLERRM);
      DBG('Error AT LINE ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_RET := -1;
      RETURN;
  END PR_BUILD_CHG_ENTRIES;

  PROCEDURE PR_BUILD_CLOSE_CHG_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                       P_CHG_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                       I          IN NUMBER,
                                       P_ERR_CODE IN OUT VARCHAR2,
                                       P_RET      IN OUT NUMBER) IS
    L_ACC_CCY_CHG        NUMBER(22, 3);
    L_ACC_CHG_EXCH_RATE  ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_COD_CHG_AMT        IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_COD_CHG_CCY        IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_COD_MIS_HEAD       IFTMS_ARC_MAINT.COD_MIS_HEAD1%TYPE;
    L_COD_CHG_TXN_CODE   IFTMS_ARC_MAINT.COD_CHG_TXN_CODE1%TYPE;
    L_COD_CHG_NETTING    IFTMS_ARC_MAINT.COD_CHG_NETTING1%TYPE;
    L_COD_CHG_GL         IFTMS_ARC_MAINT.COD_CHG_GL%TYPE;
    L_COD_RATE_CODE      IFTMS_ARC_MAINT.COD_RATE_CODE%TYPE;
    L_COD_RATE_CODE_TYPE IFTMS_ARC_MAINT.COD_RATE_CODE_TYPE%TYPE;
    L_CHG_ACC_CCY        IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_CHG_ACC            IFTMS_ARC_MAINT.COD_OFFSET_ACC%TYPE;
    L_CHG_ACC_BRN        IFTMS_ARC_MAINT.COD_OFFSET_BRN%TYPE;
    L_BRN                STTMS_BRANCH.BRANCH_CODE%TYPE;
    J                    NUMBER;
    L_CHG_LCY            NUMBER;
    L_LCY_CHG_EXCH_RATE  NUMBER;
    L_OFS_AMT            NUMBER;
    L_DR_CHG             NUMBER;
  
    L_CHG_TCY NUMBER := 0;
  
    L_TCY_CHG_EXCH_RATE  NUMBER;
    L_CHG_DESC           VARCHAR2(255);
    L_WAIVER             VARCHAR2(1);
    L_LCY_CHG_EXCH_RATE1 NUMBER;
  
    L_CHG_TYPE VARCHAR2(1);
  
    L_CHARGE_FLAG BOOLEAN := FALSE;
  
    L_ACC_GL_CCY_CHG IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_CHG_GL_ACC_CCY IFTMS_ARC_MAINT.COD_CHG_CCY%TYPE;
    L_CHG_GL_ACC     IFTMS_ARC_MAINT.COD_OFFSET_ACC%TYPE;
    L_CHG_GL_ACC_BRN IFTMS_ARC_MAINT.COD_OFFSET_BRN%TYPE;
  
    L_BRANCH             STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_TEMP_CHG           NUMBER;
    L_LCY_CHG_EXCH_RATE2 NUMBER;
  
    L_ACCOUNT_TYPE STTB_ACCOUNT.AC_OR_GL%TYPE;
  BEGIN
    DBG('To frame chg entries ' || I);
    DBG('Chg here is ' || P_CHG_ROW.COD_CHG_AMT);
    IF GWPKS_UTIL.G_FROM_BEAN OR CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      IF I = 1 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD1;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE;
      
        PKG_RTL_TELLER_REC.CHG_AMT     := P_CHG_ROW.COD_CHG_AMT;
        PKG_RTL_TELLER_REC.CHG_CCY     := P_CHG_ROW.COD_CHG_CCY;
        PKG_RTL_TELLER_REC.MIS_HEAD_1  := P_CHG_ROW.COD_MIS_HEAD1;
        PKG_RTL_TELLER_REC.TXN_CODE    := P_CHG_ROW.COD_CHG_TXN_CODE;
        PKG_RTL_TELLER_REC.NETTING_IND := P_CHG_ROW.COD_CHG_NETTING;
        PKG_RTL_TELLER_REC.CHG_GL      := P_CHG_ROW.COD_CHG_GL;
        J                              := 1;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 3;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg = ' || P_CHG_ROW.CHG_DR_LEG);
        IF P_CHG_ROW.CHG_DR_LEG IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
        DBG('Closure charge entries for waiver for 1:' ||
            PKG_RTL_TELLER_REC.WAIVER);
        DBG('Default waiver is:' || CSPKSS_CHARGE.G_DEFAULT_WAIVER);
        DBG('The action code is:' || CSPKSS_CHARGE.G_ACTION_CODE);
        IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
           CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'N' AND
           NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
          DBG('setting cod chg amt to NULL since default waiver Yes');
          L_COD_CHG_AMT := NULL;
        END IF;
        DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
        IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
           NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER, 'N') = 'Y' THEN
          DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
          L_COD_CHG_AMT := NULL;
        END IF;
      
      ELSIF I = 2 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT1;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY1;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD2;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE1;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING1;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL1;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC1;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE1;
      
        PKG_RTL_TELLER_REC.CHG_AMT_1     := P_CHG_ROW.COD_CHG_AMT1;
        PKG_RTL_TELLER_REC.CHG_CCY_1     := P_CHG_ROW.COD_CHG_CCY1;
        PKG_RTL_TELLER_REC.MIS_HEAD_2    := P_CHG_ROW.COD_MIS_HEAD2;
        PKG_RTL_TELLER_REC.TXN_CODE_1    := P_CHG_ROW.COD_CHG_TXN_CODE1;
        PKG_RTL_TELLER_REC.NETTING_IND_1 := P_CHG_ROW.COD_CHG_NETTING1;
        PKG_RTL_TELLER_REC.CHG_GL_1      := P_CHG_ROW.COD_CHG_GL1;
        J                                := 3;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 5;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_1 = ' || P_CHG_ROW.CHG_DR_LEG_1);
        IF P_CHG_ROW.CHG_DR_LEG_1 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_1 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_1 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_1;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
        DBG('Closure charge entries for waiver for 2:' ||
            PKG_RTL_TELLER_REC.WAIVER1);
        DBG('Default waiver is:' || CSPKSS_CHARGE.G_DEFAULT_WAIVER);
        DBG('The action code is:' || CSPKSS_CHARGE.G_ACTION_CODE);
        IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
           CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'N' AND
           NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
          DBG('setting cod chg amt to NULL since default waiver Yes');
          L_COD_CHG_AMT := NULL;
        END IF;
        DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
        IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
           NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER1, 'N') = 'Y' THEN
          DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
          L_COD_CHG_AMT := NULL;
        END IF;
      
      ELSIF I = 3 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT2;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY2;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD3;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE2;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING2;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL2;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC2;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE2;
      
        PKG_RTL_TELLER_REC.CHG_AMT_2     := P_CHG_ROW.COD_CHG_AMT2;
        PKG_RTL_TELLER_REC.CHG_CCY_2     := P_CHG_ROW.COD_CHG_CCY2;
        PKG_RTL_TELLER_REC.MIS_HEAD_3    := P_CHG_ROW.COD_MIS_HEAD3;
        PKG_RTL_TELLER_REC.TXN_CODE_2    := P_CHG_ROW.COD_CHG_TXN_CODE2;
        PKG_RTL_TELLER_REC.NETTING_IND_2 := P_CHG_ROW.COD_CHG_NETTING2;
        PKG_RTL_TELLER_REC.CHG_GL_2      := P_CHG_ROW.COD_CHG_GL2;
        J                                := 5;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 7;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_2 = ' || P_CHG_ROW.CHG_DR_LEG_2);
        IF P_CHG_ROW.CHG_DR_LEG_2 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_2 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_2 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_2;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
        DBG('Closure charge entries for waiver for 3:' ||
            PKG_RTL_TELLER_REC.WAIVER2);
        DBG('Default waiver is:' || CSPKSS_CHARGE.G_DEFAULT_WAIVER);
        DBG('The action code is:' || CSPKSS_CHARGE.G_ACTION_CODE);
        IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
           CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'N' AND
           NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
          DBG('setting cod chg amt to NULL since default waiver Yes');
          L_COD_CHG_AMT := NULL;
        END IF;
        DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
        IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
           NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER2, 'N') = 'Y' THEN
          DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
          L_COD_CHG_AMT := NULL;
        END IF;
      
      ELSIF I = 4 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT3;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY3;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD4;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE3;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING3;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL3;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC3;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE3;
      
        PKG_RTL_TELLER_REC.CHG_AMT_3 := P_CHG_ROW.COD_CHG_AMT3;
      
        PKG_RTL_TELLER_REC.CHG_CCY_3     := P_CHG_ROW.COD_CHG_CCY3;
        PKG_RTL_TELLER_REC.MIS_HEAD_4    := P_CHG_ROW.COD_MIS_HEAD4;
        PKG_RTL_TELLER_REC.TXN_CODE_3    := P_CHG_ROW.COD_CHG_TXN_CODE3;
        PKG_RTL_TELLER_REC.NETTING_IND_3 := P_CHG_ROW.COD_CHG_NETTING3;
        PKG_RTL_TELLER_REC.CHG_GL_3      := P_CHG_ROW.COD_CHG_GL3;
        J                                := 7;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 9;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_3 = ' || P_CHG_ROW.CHG_DR_LEG_3);
        IF P_CHG_ROW.CHG_DR_LEG_3 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_3 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_3 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_3;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
        DBG('Closure charge entries for waiver for 4:' ||
            PKG_RTL_TELLER_REC.WAIVER3);
        DBG('Default waiver is:' || CSPKSS_CHARGE.G_DEFAULT_WAIVER);
        DBG('The action code is:' || CSPKSS_CHARGE.G_ACTION_CODE);
        IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
           CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'N' AND
           NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
          DBG('setting cod chg amt to NULL since default waiver Yes');
          L_COD_CHG_AMT := NULL;
        END IF;
        DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
        IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
           NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER3, 'N') = 'Y' THEN
          DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
          L_COD_CHG_AMT := NULL;
        END IF;
      
      ELSIF I = 5 THEN
        L_COD_CHG_AMT        := P_CHG_ROW.COD_CHG_AMT4;
        L_COD_CHG_CCY        := P_CHG_ROW.COD_CHG_CCY4;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
        L_COD_MIS_HEAD       := P_CHG_ROW.COD_MIS_HEAD5;
        L_COD_CHG_TXN_CODE   := P_CHG_ROW.COD_CHG_TXN_CODE4;
        L_COD_CHG_NETTING    := P_CHG_ROW.COD_CHG_NETTING4;
        L_COD_CHG_GL         := P_CHG_ROW.COD_CHG_GL4;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC4;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE4;
      
        PKG_RTL_TELLER_REC.CHG_AMT_4     := P_CHG_ROW.COD_CHG_AMT4;
        PKG_RTL_TELLER_REC.CHG_CCY_4     := P_CHG_ROW.COD_CHG_CCY4;
        PKG_RTL_TELLER_REC.MIS_HEAD_5    := P_CHG_ROW.COD_MIS_HEAD5;
        PKG_RTL_TELLER_REC.TXN_CODE_4    := P_CHG_ROW.COD_CHG_TXN_CODE4;
        PKG_RTL_TELLER_REC.NETTING_IND_4 := P_CHG_ROW.COD_CHG_NETTING4;
        PKG_RTL_TELLER_REC.CHG_GL_4      := P_CHG_ROW.COD_CHG_GL4;
        J                                := 9;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 11;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_4 = ' || P_CHG_ROW.CHG_DR_LEG_4);
        IF P_CHG_ROW.CHG_DR_LEG_4 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_4 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_4 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_4;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
        DBG('Closure charge entries for waiver for 5:' ||
            PKG_RTL_TELLER_REC.WAIVER4);
        DBG('Default waiver is:' || CSPKSS_CHARGE.G_DEFAULT_WAIVER);
        DBG('The action code is:' || CSPKSS_CHARGE.G_ACTION_CODE);
        IF CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG = 'Y' AND
           CSPKSS_CHARGE.G_ACTION_CODE <> 'CHGPKUP' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'N' AND
           NVL(CSPKSS_CHARGE.G_DEFAULT_WAIVER, 'N') = 'Y' THEN
          DBG('setting cod chg amt to NULL since default waiver Yes');
          L_COD_CHG_AMT := NULL;
        END IF;
        DBG('pkg_rtl_teller_rec.waiver ' || PKG_RTL_TELLER_REC.WAIVER);
        IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
           NVL(PKG_IS_TRACK_REQURD, 'Y') = 'N' AND
           NVL(PKG_RTL_TELLER_REC.WAIVER4, 'N') = 'Y' THEN
          DBG('During Tracking Charge 1 got waived so will set CHG_AMT NULL ');
          L_COD_CHG_AMT := NULL;
        END IF;
      
      END IF;
    ELSE
      IF I = 1 THEN
        L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT;
        L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE;
        L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_1;
        L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE;
        L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND;
        L_COD_CHG_GL         := PKG_RTL_TELLER_REC.CHG_GL;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE;
      
        J := 1;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 3;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg = ' || P_CHG_ROW.CHG_DR_LEG);
        IF P_CHG_ROW.CHG_DR_LEG IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
      ELSIF I = 2 THEN
        L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_1;
        L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_1;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE1;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE1;
        L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_2;
        L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_1;
        L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_1;
        L_COD_CHG_GL         := PKG_RTL_TELLER_REC.CHG_GL_1;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC1;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE1;
      
        J := 3;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 5;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_1 = ' || P_CHG_ROW.CHG_DR_LEG_1);
        IF P_CHG_ROW.CHG_DR_LEG_1 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_1 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_1 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_1;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
      ELSIF I = 3 THEN
        L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_2;
        L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_2;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE2;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE2;
        L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_3;
        L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_2;
        L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_2;
        L_COD_CHG_GL         := PKG_RTL_TELLER_REC.CHG_GL_2;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC2;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE2;
        J                    := 5;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 7;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_2 = ' || P_CHG_ROW.CHG_DR_LEG_2);
        IF P_CHG_ROW.CHG_DR_LEG_2 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_2 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_2 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_2;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
      ELSIF I = 4 THEN
        L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_3;
        L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_3;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE3;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE3;
        L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_4;
        L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_3;
        L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_3;
        L_COD_CHG_GL         := PKG_RTL_TELLER_REC.CHG_GL_3;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC3;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE3;
        J                    := 7;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 9;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_3 = ' || P_CHG_ROW.CHG_DR_LEG_3);
        IF P_CHG_ROW.CHG_DR_LEG_3 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_3 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_3 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_3;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
      ELSIF I = 5 THEN
        L_COD_CHG_AMT        := PKG_RTL_TELLER_REC.CHG_AMT_4;
        L_COD_CHG_CCY        := PKG_RTL_TELLER_REC.CHG_CCY_4;
        L_COD_RATE_CODE      := P_CHG_ROW.COD_RATE_CODE4;
        L_COD_RATE_CODE_TYPE := P_CHG_ROW.COD_RATE_CODE_TYPE4;
        L_COD_MIS_HEAD       := PKG_RTL_TELLER_REC.MIS_HEAD_5;
        L_COD_CHG_TXN_CODE   := PKG_RTL_TELLER_REC.TXN_CODE_4;
        L_COD_CHG_NETTING    := PKG_RTL_TELLER_REC.NETTING_IND_4;
        L_COD_CHG_GL         := PKG_RTL_TELLER_REC.CHG_GL_4;
        L_CHG_DESC           := P_CHG_ROW.COD_CHG_DESC4;
        L_CHG_TYPE           := P_CHG_ROW.COD_CHG_TYPE4;
        J                    := 9;
      
        IF L_COD_CHG_AMT IS NOT NULL THEN
          G_ROW := 11;
        END IF;
      
        DBG('p_Chg_Row.Chg_Dr_Leg_4 = ' || P_CHG_ROW.CHG_DR_LEG_4);
        IF P_CHG_ROW.CHG_DR_LEG_4 IS NOT NULL THEN
          L_CHARGE_FLAG := TRUE;
          IF P_CHG_ROW.CHG_DR_LEG_4 = 'TXN_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSIF P_CHG_ROW.CHG_DR_LEG_4 = 'OFS_ACC' THEN
            L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          ELSE
            L_CHG_ACC_CCY := GLOBAL.LCY;
            L_CHG_ACC     := P_CHG_ROW.CHG_DR_LEG_4;
            L_CHG_ACC_BRN := GLOBAL.CURRENT_BRANCH;
          END IF;
        END IF;
      
      END IF;
    END IF;
    DBG('Amt is ' || L_COD_CHG_AMT);
  
    IF L_COD_CHG_AMT IS NOT NULL THEN
      IF L_CHARGE_FLAG = FALSE THEN
      
        DBG('ARC level Consideration');
        IF NVL(P_CHG_ROW.CHG_FROM, 'TXN') = 'TXN' THEN
          L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
          L_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
          L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        ELSE
          L_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
          L_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
          L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        END IF;
      END IF;
    
      IF L_CHG_ACC_BRN = '*.*' THEN
        L_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
      END IF;
    
      DBG('Debiting Chgs from ' || L_CHG_ACC);
      IF L_CHG_ACC_CCY <> L_COD_CHG_CCY THEN
        DBG('Ccys are diff ');
        L_ACC_CHG_EXCH_RATE := NULL;
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                      L_COD_CHG_CCY,
                                      L_CHG_ACC_CCY,
                                      NVL(L_COD_RATE_CODE, 'STANDARD'),
                                      NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                      L_COD_CHG_AMT,
                                      'Y',
                                      L_ACC_CCY_CHG,
                                      L_ACC_CHG_EXCH_RATE,
                                      P_ERR_CODE) THEN
          DBG('Failure in converting instr amt to ac ccy amt ' ||
              P_ERR_CODE);
          P_RET := -1;
          RETURN;
        END IF;
        DBG('Chg in acc ccy is ' || L_ACC_CCY_CHG || ' and rate ' ||
            L_ACC_CHG_EXCH_RATE);
      ELSE
        DBG('No confusion at all');
        L_ACC_CCY_CHG       := L_COD_CHG_AMT;
        L_ACC_CHG_EXCH_RATE := 1;
      END IF;
    
      DBG('Now for the Charge Currency lcy part');
      IF L_COD_CHG_CCY <> PKG_LCY THEN
        L_LCY_CHG_EXCH_RATE := NULL;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     L_COD_CHG_CCY,
                                     PKG_LCY,
                                     NVL(L_COD_RATE_CODE, 'STANDARD'),
                                     NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                     L_COD_CHG_AMT,
                                     'Y',
                                     L_CHG_LCY,
                                     L_LCY_CHG_EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Failed while findin xch rate ' || P_ERR_CODE);
          P_RET := -1;
          RETURN;
        END IF;
      ELSE
        DBG('Am fine now');
        L_CHG_LCY           := L_COD_CHG_AMT;
        L_LCY_CHG_EXCH_RATE := 1;
      END IF;
      L_LCY_CHG_EXCH_RATE1 := L_LCY_CHG_EXCH_RATE;
      DBG('The lcy exchange rate1 value is:' || L_LCY_CHG_EXCH_RATE1);
      DBG('In pr_build_close_chg_entries');
      DBG('The account currency is:' || L_CHG_ACC_CCY ||
          ' with charge ccy in Arc as:' || L_COD_CHG_CCY);
      DBG('The transaction currency is:' || PKG_RTL_TELLER_REC.TXN_CCY ||
          ' with offset currency as:' || PKG_RTL_TELLER_REC.OFS_CCY);
      IF (L_CHG_ACC_CCY <> L_COD_CHG_CCY) AND (L_COD_CHG_CCY = PKG_LCY) THEN
        DBG('The account currency exchange rate and LCY Exchange rate to be made same with chg lcy amount as:' ||
            L_CHG_LCY);
        DBG('The cod charge amount is:' || L_COD_CHG_AMT);
        L_CHG_LCY           := NVL(L_CHG_LCY, L_COD_CHG_AMT);
        L_LCY_CHG_EXCH_RATE := L_ACC_CHG_EXCH_RATE;
        DBG('The account currency rate is:' || L_LCY_CHG_EXCH_RATE ||
            ' with charge local lcy as:' || L_CHG_LCY);
      ELSE
      
        DBG('Now for the Account Currency lcy part');
        IF L_CHG_ACC_CCY <> PKG_LCY THEN
          L_LCY_CHG_EXCH_RATE := NULL;
        
          L_TEMP_CHG := L_CHG_LCY;
          L_CHG_LCY  := NULL;
        
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_LCY,
                                       L_CHG_ACC_CCY,
                                       NVL(L_COD_RATE_CODE, 'STANDARD'),
                                       NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                       L_ACC_CCY_CHG,
                                       'Y',
                                       L_CHG_LCY,
                                       L_LCY_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
          L_CHG_LCY := L_TEMP_CHG;
        ELSE
          DBG('Am fine now');
          L_CHG_LCY           := L_ACC_CCY_CHG;
          L_LCY_CHG_EXCH_RATE := 1;
        END IF;
      END IF;
      DBG('The charge local currency amount value is:' || L_CHG_LCY);
      L_LCY_CHG_EXCH_RATE2 := L_LCY_CHG_EXCH_RATE;
    
      DBG('The lcy exchange rate2 value is:' || L_LCY_CHG_EXCH_RATE2);
    
      DBG('THE OFS AMT IS 1 :' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('THE TXN AMT IS 1 :' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
      IF (NVL(GWPKS_UTIL.PKG_FUNC, '$') IN ('1300', '1320')) AND
         NVL(CSPKS_CHARGE.G_ACTION_TYPE, '***') <> 'SAVEAUTOAUTH' THEN
        DBG('Deducting charges before conversion');
        DBG('THE CHG AMT IS 1 :' || PKG_RED_AMT);
        PKG_RTL_TELLER_REC.TXN_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT -
                                         PKG_RED_AMT;
        DBG('THE TXN AMT IS 2 :' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
      END IF;
    
      IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
      
        IF PKG_RTL_TELLER_REC.EXCH_RATE IS NOT NULL THEN
          L_LCY_CHG_EXCH_RATE := PKG_RTL_TELLER_REC.EXCH_RATE;
        ELSE
          L_LCY_CHG_EXCH_RATE := NULL;
        END IF;
      
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     NVL(L_COD_RATE_CODE, 'STANDARD'),
                                     NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                     PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                     'Y',
                                     L_OFS_AMT,
                                     L_LCY_CHG_EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Failed while findin ofs amount ' || P_ERR_CODE);
          P_RET := -1;
          RETURN;
        END IF;
        PKG_RTL_TELLER_REC.OFS_AMOUNT := L_OFS_AMT;
      ELSE
        DBG('Cool ofs ccy = txn ccy');
        PKG_RTL_TELLER_REC.OFS_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      END IF;
      IF L_CHG_ACC_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
        L_LCY_CHG_EXCH_RATE := NULL;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     L_CHG_ACC_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     NVL(L_COD_RATE_CODE, 'STANDARD'),
                                     NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                     L_ACC_CCY_CHG,
                                     'Y',
                                     L_DR_CHG,
                                     L_LCY_CHG_EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Failed while findin chg amount ' || P_ERR_CODE);
          P_RET := -1;
          RETURN;
        END IF;
      
        IF NOT CSPKS_ACC_SERVICE.G_NEG_BAL THEN
          PKG_RTL_TELLER_REC.OFS_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT -
                                           L_DR_CHG;
        END IF;
      
      ELSE
        DBG('cool chg ccy = txn ccy');
      
        IF NOT CSPKS_ACC_SERVICE.G_NEG_BAL THEN
          PKG_RTL_TELLER_REC.OFS_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT -
                                           L_ACC_CCY_CHG;
        END IF;
      
      END IF;
      DBG('THE CHG IS ' || L_ACC_CCY_CHG);
      DBG('THE AMT IS ' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
      DBG('THE OFS AMT IS ' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
    
      IF NOT CSPKS_ACC_SERVICE.G_NEG_BAL THEN
        PKG_RTL_TELLER_REC.TXN_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT -
                                         L_ACC_CCY_CHG;
      END IF;
    
      DBG('THE AMT after DR IS ' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
    
      IF STPKS_ACCOUNT_CLOSE.G_PAYOUTTYPE = 'C' THEN
        DBG('Came here to calculate denom amount');
        G_DENOM_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        DBG('g_denom_amt ======>>> ' || G_DENOM_AMOUNT);
      END IF;
    
      DBG('The action type in pr_build_close_chg_entries is :: ' ||
          CSPKS_CHARGE.G_ACTION_TYPE);
      IF NVL(CSPKS_CHARGE.G_ACTION_TYPE, '***') = 'SAVEAUTOAUTH' AND
         DEPKS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        IF PKG_RTL_TELLER_REC.TXN_AMOUNT < 0 THEN
          DBG('Closing Balance is lesser than the Charge Amount');
          P_ERR_CODE := 'ST-CLS30';
          P_RET      := -1;
          RETURN;
        END IF;
      END IF;
    
      P_ACC_HAND(J).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
      P_ACC_HAND(J).MIS_HEAD := L_COD_MIS_HEAD;
      P_ACC_HAND(J).AVLDAYS := 0;
      P_ACC_HAND(J).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
      P_ACC_HAND(J).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
      P_ACC_HAND(J).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE, 'INIT');
      P_ACC_HAND(J).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
    
      P_ACC_HAND(J).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
    
      P_ACC_HAND(J).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
      P_ACC_HAND(J).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
      P_ACC_HAND(J).BATCH_NO := NULL;
      P_ACC_HAND(J).CURR_NO := NULL;
    
      P_ACC_HAND(J).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
      DBG('The utils makerid is:' || GWPKS_UTIL.G_MAKERID ||
          ' with global user as:' || GLOBAL.USER_ID);
    
      P_ACC_HAND(J).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID);
      P_ACC_HAND(J).DRCR_IND := 'C';
    
      BEGIN
        SELECT AC_OR_GL
          INTO L_ACCOUNT_TYPE
          FROM STTBS_ACCOUNT
         WHERE AC_GL_NO = L_COD_CHG_GL;
      EXCEPTION
        WHEN OTHERS THEN
          L_ACCOUNT_TYPE := 'X';
      END;
      DBG('l_cod_chg_gl' || L_COD_CHG_GL);
      DBG('l_chg_acc' || L_CHG_ACC);
      DBG('l_account_type' || L_ACCOUNT_TYPE);
      IF (L_ACCOUNT_TYPE = 'G') THEN
        P_ACC_HAND(J).RELATED_ACCOUNT := L_CHG_ACC;
      END IF;
    
      IF CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT IS NOT NULL THEN
        DBG('Assigning the dbgrelated account for clsor chareges  sds;' ||
            CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT);
        P_ACC_HAND(J).RELATED_ACCOUNT := CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT;
      END IF;
    
      P_ACC_HAND(J).TRN_CODE := L_COD_CHG_TXN_CODE;
      P_ACC_HAND(J).AMOUNT_TAG := 'CHG_AMT' || I;
      P_ACC_HAND(J).NETTING_IND := L_COD_CHG_NETTING;
      P_ACC_HAND(J).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
      P_ACC_HAND(J).AC_NO := L_COD_CHG_GL;
    
      P_ACC_HAND(J).AC_CCY := L_COD_CHG_CCY;
      P_ACC_HAND(J).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE;
      IF P_CHG_ROW.COD_BRANCH = '*.*' THEN
        L_BRN := GLOBAL.CURRENT_BRANCH;
      ELSE
        L_BRN := P_CHG_ROW.COD_BRANCH;
      END IF;
      P_ACC_HAND(J).AC_BRANCH := L_BRN;
      P_ACC_HAND(J).LCY_AMOUNT := L_CHG_LCY;
    
      IF L_COD_CHG_CCY <> PKG_LCY THEN
        P_ACC_HAND(J).FCY_AMOUNT := L_COD_CHG_AMT;
      
        P_ACC_HAND(J).EXCH_RATE := L_LCY_CHG_EXCH_RATE1;
      ELSE
        P_ACC_HAND(J).FCY_AMOUNT := NULL;
        P_ACC_HAND(J).EXCH_RATE := NULL;
      END IF;
      DBG('333333333');
      IF L_COD_CHG_AMT = 0 THEN
        DBG('Setter for C if charge amount is 0');
        P_ACC_HAND(J).AC_CCY := PKG_LCY;
        P_ACC_HAND(J).LCY_AMOUNT := 0;
        P_ACC_HAND(J).FCY_AMOUNT := 0;
        P_ACC_HAND(J).EXCH_RATE := NULL;
      
      END IF;
    
      IF L_COD_CHG_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
        L_CHG_TCY           := NULL;
        L_TCY_CHG_EXCH_RATE := NULL;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     L_COD_CHG_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     NVL(L_COD_RATE_CODE, 'STANDARD'),
                                     NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                     L_COD_CHG_AMT,
                                     'Y',
                                     L_CHG_TCY,
                                     L_TCY_CHG_EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Failed while findin xch rate ' || P_ERR_CODE);
          P_RET := -1;
          RETURN;
        END IF;
      ELSE
        DBG('Am fine now');
        L_CHG_TCY           := L_COD_CHG_AMT;
        L_TCY_CHG_EXCH_RATE := 1;
      END IF;
    
      IF DEPKS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          DBG('pkg_rtl_teller_rec.branch_code :::: ' ||
              PKG_RTL_TELLER_REC.BRANCH_CODE);
          DBG('pkg_rtl_teller_rec.txn_ccy :::: ' ||
              PKG_RTL_TELLER_REC.TXN_CCY);
          DBG('pkg_rtl_teller_rec.txn_ccy :::: ' ||
              PKG_RTL_TELLER_REC.OFS_CCY);
          DBG('l_cod_chg_ccy :::: ' || L_COD_CHG_CCY);
          DBG('l_cod_chg_amt ::::: ' || L_COD_CHG_AMT);
          L_CHG_TCY           := NULL;
          L_TCY_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       L_COD_CHG_CCY,
                                       PKG_RTL_TELLER_REC.TXN_CCY,
                                       NVL(L_COD_RATE_CODE, 'STANDARD'),
                                       NVL(L_COD_RATE_CODE_TYPE, 'M'),
                                       L_COD_CHG_AMT,
                                       'Y',
                                       L_CHG_TCY,
                                       L_TCY_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        END IF;
        DBG('pkg_rtl_teller_rec.branch_code ::::' ||
            PKG_RTL_TELLER_REC.BRANCH_CODE);
        DBG('l_cod_chg_ccy :::::' || L_COD_CHG_CCY);
        DBG('l_cod_chg_amt :::::' || L_COD_CHG_AMT);
      END IF;
    
      P_ACC_HAND(J + 1).MODULE := NVL(PKG_RTL_TELLER_REC.MODULE, 'RT');
      P_ACC_HAND(J + 1).MIS_HEAD := L_COD_MIS_HEAD;
      P_ACC_HAND(J + 1).AVLDAYS := 0;
      P_ACC_HAND(J + 1).TRN_REF_NO := PKG_RTL_TELLER_REC.TRN_REF_NO;
      P_ACC_HAND(J + 1).EVENT_SR_NO := NVL(PKG_RTL_TELLER_REC.ESN, 1);
      P_ACC_HAND(J + 1).EVENT := NVL(PKG_RTL_TELLER_REC.EVENT_CODE, 'INIT');
      P_ACC_HAND(J + 1).TRN_DT := PKG_RTL_TELLER_REC.TRN_DT;
    
      P_ACC_HAND(J + 1).VALUE_DT := PKG_RTL_TELLER_REC.VALUE_DT;
    
      P_ACC_HAND(J + 1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
      P_ACC_HAND(J + 1).BATCH_NO := NULL;
      P_ACC_HAND(J + 1).CURR_NO := NULL;
    
      P_ACC_HAND(J + 1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
      DBG('The j+1 utils makerid is:' || GWPKS_UTIL.G_MAKERID ||
          ' with global user as:' || GLOBAL.USER_ID);
    
      P_ACC_HAND(J + 1).AUTH_ID := NVL(GWPKS_UTIL.G_CHECKERID,
                                       GLOBAL.USER_ID);
      P_ACC_HAND(J + 1).DRCR_IND := 'D';
      IF CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT IS NOT NULL THEN
        DBG('Assigning the dbgrelated account for clsor chareges;' ||
            CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT);
        P_ACC_HAND(J + 1).RELATED_ACCOUNT := CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT;
      END IF;
    
      SELECT DECODE(L_CHG_ACC_BRN,
                    '*.*',
                    GLOBAL.CURRENT_BRANCH,
                    L_CHG_ACC_BRN)
        INTO L_BRANCH
        FROM DUAL;
      DBG('The debit leg account branch is:' || L_BRANCH ||
          ' with charge account branch as:' || L_CHG_ACC_BRN);
    
      P_ACC_HAND(J + 1).TRN_CODE := L_COD_CHG_TXN_CODE;
      P_ACC_HAND(J + 1).AMOUNT_TAG := 'CHG_AMT' || I;
      P_ACC_HAND(J + 1).NETTING_IND := L_COD_CHG_NETTING;
      P_ACC_HAND(J + 1).EXTERNAL_REF_NO := PKG_RTL_TELLER_REC.XREF;
      P_ACC_HAND(J + 1).AC_NO := L_CHG_ACC;
      P_ACC_HAND(J + 1).RELATED_CUSTOMER := PKG_RTL_TELLER_REC.REL_CUSTOMER;
    
      P_ACC_HAND(J + 1).AC_BRANCH := L_BRANCH;
    
      IF L_COD_CHG_AMT = 0 THEN
        P_ACC_HAND(J + 1).AC_CCY := L_COD_CHG_CCY;
      ELSE
        P_ACC_HAND(J + 1).AC_CCY := L_CHG_ACC_CCY;
      END IF;
    
      P_ACC_HAND(J + 1).LCY_AMOUNT := L_CHG_LCY;
      P_ACC_HAND(J + 1).INSTRUMENT_CODE := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
    
      DBG('The credit instrument code 4 is:' ||
          PKG_RTL_TELLER_REC.CR_INSTRUMENT_CODE);
      DBG('The debit instrument code 4 is:' ||
          PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
      IF P_ACC_HAND(J)
       .INSTRUMENT_CODE IS NULL AND P_ACC_HAND(J + 1).INSTRUMENT_CODE IS NOT NULL THEN
        P_ACC_HAND(J).INSTRUMENT_CODE := P_ACC_HAND(J + 1).INSTRUMENT_CODE;
      END IF;
    
      IF L_CHG_ACC_CCY <> PKG_LCY THEN
      
        IF L_COD_CHG_AMT = 0 THEN
          P_ACC_HAND(J + 1).FCY_AMOUNT := 0;
          P_ACC_HAND(J + 1).EXCH_RATE := NULL;
        ELSE
          P_ACC_HAND(J + 1).FCY_AMOUNT := L_ACC_CCY_CHG;
        
          P_ACC_HAND(J + 1).EXCH_RATE := L_LCY_CHG_EXCH_RATE2;
        END IF;
      
      ELSE
        P_ACC_HAND(J + 1).FCY_AMOUNT := NULL;
        P_ACC_HAND(J + 1).EXCH_RATE := NULL;
      END IF;
    
      IF L_COD_CHG_AMT = 0 THEN
        DBG('Setter for D if charge amount is 0');
        P_ACC_HAND(J + 1).AC_CCY := PKG_LCY;
        P_ACC_HAND(J + 1).LCY_AMOUNT := 0;
        P_ACC_HAND(J + 1).FCY_AMOUNT := 0;
        P_ACC_HAND(J + 1).EXCH_RATE := NULL;
      END IF;
    
      IF I = 1 THEN
        PKG_RTL_TELLER_REC.CHG_IN_ACY := L_ACC_CCY_CHG;
        PKG_RTL_TELLER_REC.CHG_IN_LCY := P_ACC_HAND(J + 1).LCY_AMOUNT;
      
        PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE := L_LCY_CHG_EXCH_RATE1;
      ELSIF I = 2 THEN
        PKG_RTL_TELLER_REC.CHG_IN_ACY_1 := L_ACC_CCY_CHG;
        PKG_RTL_TELLER_REC.CHG_IN_LCY_1 := P_ACC_HAND(J + 1).LCY_AMOUNT;
      
        PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1 := L_LCY_CHG_EXCH_RATE1;
      ELSIF I = 3 THEN
        PKG_RTL_TELLER_REC.CHG_IN_ACY_2 := L_ACC_CCY_CHG;
        PKG_RTL_TELLER_REC.CHG_IN_LCY_2 := P_ACC_HAND(J + 1).LCY_AMOUNT;
      
        PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2 := L_LCY_CHG_EXCH_RATE1;
      ELSIF I = 4 THEN
        PKG_RTL_TELLER_REC.CHG_IN_ACY_3 := L_ACC_CCY_CHG;
        PKG_RTL_TELLER_REC.CHG_IN_LCY_3 := P_ACC_HAND(J + 1).LCY_AMOUNT;
      
        PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3 := L_LCY_CHG_EXCH_RATE1;
      ELSIF I = 5 THEN
        PKG_RTL_TELLER_REC.CHG_IN_ACY_4 := L_ACC_CCY_CHG;
        PKG_RTL_TELLER_REC.CHG_IN_LCY_4 := P_ACC_HAND(J + 1).LCY_AMOUNT;
      
        PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4 := L_LCY_CHG_EXCH_RATE1;
      END IF;
    
      IF GWPKS_UTIL.PKG_ACTTYPE IS NOT NULL THEN
        DBG('gwpks_util.pkg_temp_chg_dets........ ' ||
            GWPKS_UTIL.PKG_TEMP_CHG_DETS);
        BEGIN
          L_WAIVER := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                              ((I - 1) * 7) + 1,
                                              '~');
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;
        DBG('l_waiver ' || L_WAIVER);
      
        IF I = 1 THEN
          PKG_RTL_TELLER_REC.WAIVER := NVL(L_WAIVER, 'N');
          DBG('pkg_rtl_teller_rec.waiver :' || PKG_RTL_TELLER_REC.WAIVER);
        ELSIF I = 2 THEN
          PKG_RTL_TELLER_REC.WAIVER1 := NVL(L_WAIVER, 'N');
          DBG('pkg_rtl_teller_rec.waiver1 :' || PKG_RTL_TELLER_REC.WAIVER1);
        ELSIF I = 3 THEN
          PKG_RTL_TELLER_REC.WAIVER2 := NVL(L_WAIVER, 'N');
          DBG('pkg_rtl_teller_rec.waiver :' || PKG_RTL_TELLER_REC.WAIVER);
        ELSIF I = 4 THEN
          PKG_RTL_TELLER_REC.WAIVER3 := NVL(L_WAIVER, 'N');
          DBG('pkg_rtl_teller_rec.waiver3 :' || PKG_RTL_TELLER_REC.WAIVER3);
        ELSIF I = 5 THEN
          PKG_RTL_TELLER_REC.WAIVER4 := NVL(L_WAIVER, 'N');
          DBG('pkg_rtl_teller_rec.waiver4 :' || PKG_RTL_TELLER_REC.WAIVER4);
        END IF;
      
        IF DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
          DBG('------In pr_build_close_chg_entries-------');
          DBG('l_chg_tcy :: ' || L_CHG_TCY);
          DBG('pkg_rtl_teller_rec.tot_chg_in_tcy will be:: ' ||
              PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
          DBG('Value of pkg_red_amt in pr_build_close_chg_entries :: ' ||
              PKG_RED_AMT);
          DEPKSS_RTL_TELLER.G_TOT_CHG := DEPKSS_RTL_TELLER.G_TOT_CHG +
                                         L_CHG_TCY +
                                        
                                         PKG_RED_AMT;
          DBG('Total charge i.e.,  depkss_rtl_teller.g_tot_chg :: ' ||
              DEPKSS_RTL_TELLER.G_TOT_CHG);
          DEPKSS_RTL_TELLER.G_ONLINE_CHARGE := 0;
          PKG_RED_AMT                       := 0;
          PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := DEPKSS_RTL_TELLER.G_TOT_CHG;
        ELSE
        
          PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY +
                                               L_CHG_TCY;
          DEPKSS_RTL_TELLER.G_TOT_CHG       := DEPKSS_RTL_TELLER.G_TOT_CHG +
                                               L_CHG_TCY;
        END IF;
      END IF;
    
    END IF;
  
    IF GWPKS_UTIL.PKG_ACTTYPE IS NOT NULL AND NVL(L_COD_CHG_AMT, 0) = 0 THEN
      DBG('Here in pr_build_close_chg_entries when l_cod_chg_amt is 0');
      DBG('gwpks_util.pkg_temp_chg_dets........ ' ||
          GWPKS_UTIL.PKG_TEMP_CHG_DETS);
      BEGIN
        L_WAIVER := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                            ((I - 1) * 7) + 1,
                                            '~');
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      DBG('l_waiver ' || L_WAIVER);
      IF I = 1 THEN
        PKG_RTL_TELLER_REC.WAIVER := NVL(L_WAIVER, 'N');
        DBG('pkg_rtl_teller_rec.waiver :' || PKG_RTL_TELLER_REC.WAIVER);
      ELSIF I = 2 THEN
        PKG_RTL_TELLER_REC.WAIVER1 := NVL(L_WAIVER, 'N');
        DBG('pkg_rtl_teller_rec.waiver1 :' || PKG_RTL_TELLER_REC.WAIVER1);
      ELSIF I = 3 THEN
        PKG_RTL_TELLER_REC.WAIVER2 := NVL(L_WAIVER, 'N');
        DBG('pkg_rtl_teller_rec.waiver :' || PKG_RTL_TELLER_REC.WAIVER);
      ELSIF I = 4 THEN
        PKG_RTL_TELLER_REC.WAIVER3 := NVL(L_WAIVER, 'N');
        DBG('pkg_rtl_teller_rec.waiver3 :' || PKG_RTL_TELLER_REC.WAIVER3);
      ELSIF I = 5 THEN
        PKG_RTL_TELLER_REC.WAIVER4 := NVL(L_WAIVER, 'N');
        DBG('pkg_rtl_teller_rec.waiver4 :' || PKG_RTL_TELLER_REC.WAIVER4);
      END IF;
    
      IF STPKS_ACCOUNT_CLOSE.G_PAYOUTTYPE = 'C' THEN
        DBG('Came here to calculate denom amount');
        G_DENOM_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        DBG('g_denom_amt ======>>> ' || G_DENOM_AMOUNT);
      END IF;
    
      DBG('------In pr_build_close_chg_entries when charge is 0-------');
      DBG('g_online_charge :: ' || G_ONLINE_CHARGE);
      DBG('pkg_red_amt :: ' || PKG_RED_AMT);
      DBG('depkss_rtl_teller.g_tot_chg before--> ' ||
          DEPKSS_RTL_TELLER.G_TOT_CHG);
      DEPKSS_RTL_TELLER.G_TOT_CHG := DEPKSS_RTL_TELLER.G_TOT_CHG +
                                     L_CHG_TCY +
                                    
                                     PKG_RED_AMT;
      DBG('Total charge i.e.,  depkss_rtl_teller.g_tot_chg :: ' ||
          DEPKSS_RTL_TELLER.G_TOT_CHG);
    
      DBG('pkg_rtl_teller_rec.tot_chg_in_tcy--> ' ||
          PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
      PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY := DEPKSS_RTL_TELLER.G_TOT_CHG;
    
      DEPKSS_RTL_TELLER.G_ONLINE_CHARGE := 0;
      PKG_RED_AMT                       := 0;
    END IF;
  
    DBG('pkg_rtl_teller_rec.tot_chg_in_tcy--> ' ||
        PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
    DBG('To ret true now ');
    P_RET := 0;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      P_RET := -1;
      RETURN;
  END PR_BUILD_CLOSE_CHG_ENTRIES;

  PROCEDURE PR_BUILD_XRATE_P_AND_L_ENTRIES(P_ACC_HAND IN OUT NOCOPY ACPKS.TBL_ACHOFF,
                                           P_ARC_ROW  IN IFTMS_ARC_MAINT%ROWTYPE,
                                           P_NEG_AMT  IN NUMBER,
                                           P_ERR_CODE IN OUT VARCHAR2,
                                           P_RET      IN OUT NUMBER) IS
  
    J              NUMBER;
    L_PROFIT_LOSS  VARCHAR2(1);
    L_PL_AMT       NUMBER;
    L_PL_DR_ACC    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PL_DR_BRN    STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PL_CR_ACC    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PL_CR_BRN    STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PL_AMT_LCY   NUMBER;
    L_PL_EXCH_RATE NUMBER;
  
    L_EMPTY_REC ACTBS_HANDOFF%ROWTYPE;
  
    L_TXN_RATE  NUMBER;
    L_TXN_AMT   NUMBER;
    L_RATE_FLAG NUMBER;
    L_ACC_CCY   VARCHAR2(3);
  
    L_PL_OFS_AMT       NUMBER;
    L_PL_OFS_EXCH_RATE NUMBER;
  
    L_TXN_LEG_CASH VARCHAR2(1);
    L_OFS_LEG_CASH VARCHAR2(1);
    L_DR_CCY       CYTM_CCY_DEFN.CCY_CODE%TYPE;
    L_CR_CCY       CYTM_CCY_DEFN.CCY_CODE%TYPE;
  
    L_FCY CYTM_CCY_DEFN.CCY_CODE%TYPE;
  
  BEGIN
    DBG('To frame PL entries ');
    DBG('p_neg_amt ' || P_NEG_AMT);
    DBG('l_uptb_txnlog.txn_amt_acy ' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
    DBG('p_arc_row.PROFIT_REVAL_GL ' || P_ARC_ROW.PROFIT_REVAL_GL);
    DBG('p_arc_row.LOSS_REVAL_GL ' || P_ARC_ROW.LOSS_REVAL_GL);
    DBG('p_arc_row.RATE_TYPE_INDICATOR ' || P_ARC_ROW.RATE_TYPE_INDICATOR);
  
    DBG('24570969##p_arc_row.Dr_Acc--> ' || P_ARC_ROW.DR_ACC);
    DBG('pkg_rtl_teller_rec.ofs_acc--> ' || PKG_RTL_TELLER_REC.OFS_ACC);
    DBG('pkg_rtl_teller_rec.txn_acc--> ' || PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('pkg_rtl_teller_rec.ofs_branch--> ' ||
        PKG_RTL_TELLER_REC.OFS_BRANCH);
    DBG('pkg_rtl_teller_rec.ofs_ccy--> ' || PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('p_arc_row.profit_reval_gl--> ' || P_ARC_ROW.PROFIT_REVAL_GL);
    DBG('p_arc_row.loss_reval_gl--> ' || P_ARC_ROW.LOSS_REVAL_GL);
    DBG('global.current_branch--> ' || GLOBAL.CURRENT_BRANCH);
  
    DBG('24570969##The transaction currency from rtl teller is--> ' ||
        PKG_RTL_TELLER_REC.TXN_CCY);
    DBG('The offset currency from rtl teller is--> ' ||
        PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('The package local currency is--> ' || PKG_LCY);
    DBG('pkg_Txn_Acc.Ac_Or_Gl--> ' || PKG_TXN_ACC.AC_OR_GL);
    DBG('pkg_OFS_Acc.Ac_Or_Gl--> ' || PKG_OFS_ACC.AC_OR_GL);
    DBG('pkg_Txn_Acc.Ac_Gl_Ccy--> ' || PKG_TXN_ACC.AC_GL_CCY);
    DBG('pkg_OFS_Acc.Ac_Gl_Ccy--> ' || PKG_OFS_ACC.AC_GL_CCY);
    DBG('pkg_rtl_teller_rec.TXN_ccy--> ' || PKG_RTL_TELLER_REC.TXN_CCY);
  
    DBG('l_acc_ccy--> ' || L_ACC_CCY);
  
    BEGIN
      SELECT NVL(TXN_LEG_CASH, 'N'), NVL(OFS_LEG_CASH, 'N')
        INTO L_TXN_LEG_CASH, L_OFS_LEG_CASH
        FROM CSTMS_BRN_STAT_FUNC_DEFN
       WHERE FUNCTIONID = GWPKS_UTIL.PKG_FUNC;
    EXCEPTION
      WHEN OTHERS THEN
        DBG(' Error - maintain statics atleast! ');
        RETURN;
    END;
  
    IF ((P_NEG_AMT < PKG_RTL_TELLER_REC.TXN_AMOUNT AND
       P_ARC_ROW.DR_ACC = 'TXN') OR
       (P_NEG_AMT > PKG_RTL_TELLER_REC.TXN_AMOUNT AND
       P_ARC_ROW.DR_ACC = 'OFS')) THEN
    
      DBG('PROFIT ');
      L_PROFIT_LOSS := 'P';
    
      L_PL_AMT := ABS(PKG_RTL_TELLER_REC.TXN_AMOUNT - P_NEG_AMT);
      DBG('l_pl_amt of profit--> ' || L_PL_AMT);
    
      IF L_TXN_LEG_CASH = 'N' AND L_OFS_LEG_CASH IN ('I', 'O') THEN
        L_PL_DR_ACC := PKG_RTL_TELLER_REC.OFS_ACC;
        L_PL_DR_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        L_DR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
        L_CR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      ELSIF L_TXN_LEG_CASH IN ('I', 'O') AND
            L_OFS_LEG_CASH IN ('I', 'O', 'N') THEN
        L_PL_DR_ACC := PKG_RTL_TELLER_REC.TXN_ACC;
        L_PL_DR_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        L_DR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
        L_CR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
      
      ELSE
        L_PL_DR_ACC := PKG_RTL_TELLER_REC.OFS_ACC;
        L_PL_DR_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        L_DR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
        L_CR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      
      END IF;
    
      L_PL_CR_ACC := P_ARC_ROW.PROFIT_REVAL_GL;
      L_PL_CR_BRN := GLOBAL.CURRENT_BRANCH;
      L_FCY       := L_DR_CCY;
    ELSE
      DBG('LOSS ');
      L_PROFIT_LOSS := 'L';
    
      L_PL_AMT := ABS(P_NEG_AMT - PKG_RTL_TELLER_REC.TXN_AMOUNT);
      DBG('l_pl_amt of loss--> ' || L_PL_AMT);
    
      L_PL_DR_ACC := P_ARC_ROW.LOSS_REVAL_GL;
      L_PL_DR_BRN := GLOBAL.CURRENT_BRANCH;
    
      IF L_TXN_LEG_CASH = 'N' AND L_OFS_LEG_CASH IN ('I', 'O') THEN
        L_PL_CR_ACC := PKG_RTL_TELLER_REC.OFS_ACC;
        L_PL_CR_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        L_CR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
        L_DR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      ELSIF L_TXN_LEG_CASH IN ('I', 'O') AND
            L_OFS_LEG_CASH IN ('I', 'O', 'N') THEN
        L_PL_CR_ACC := PKG_RTL_TELLER_REC.TXN_ACC;
        L_PL_CR_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        L_CR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
        L_DR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
      
      ELSE
        L_PL_CR_ACC := PKG_RTL_TELLER_REC.OFS_ACC;
        L_PL_CR_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        L_CR_CCY    := PKG_RTL_TELLER_REC.OFS_CCY;
        L_DR_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
      
      END IF;
    
      L_FCY := L_CR_CCY;
    END IF;
  
    DBG('24570969##l_profit_loss--> ' || L_PROFIT_LOSS);
    DBG('l_pl_dr_acc--> ' || L_PL_DR_ACC);
    DBG('l_pl_dr_brn--> ' || L_PL_DR_BRN);
    DBG('l_pl_cr_acc--> ' || L_PL_CR_ACC);
    DBG('l_pl_cr_brn--> ' || L_PL_CR_BRN);
    DBG('l_acc_ccy--> ' || L_ACC_CCY);
    DBG('l_fcy' || L_FCY);
  
    DBG('Pkg_Rtl_Teller_Rec.txn_ccy ' || PKG_RTL_TELLER_REC.TXN_CCY);
    DBG('l_pl_amt ' || L_PL_AMT);
  
    DBG('25688577##pkg_prod.rate_type_preferred--> ' ||
        PKG_PROD.RATE_TYPE_PREFERRED);
    DBG('pkg_prod.rate_code_preferred--> ' || PKG_PROD.RATE_CODE_PREFERRED);
    DBG('pkg_rtl_teller_rec.trn_ref_no--> ' ||
        PKG_RTL_TELLER_REC.TRN_REF_NO);
    DBG('pkg_rtl_teller_rec.ofs_ccy--> ' || PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('l_pl_ofs_amt before--> ' || L_PL_OFS_AMT);
    DBG('l_pl_ofs_exch_rate before--> ' || L_PL_OFS_EXCH_RATE);
  
    IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.TXN_CCY,
                                 PKG_RTL_TELLER_REC.OFS_CCY,
                                 L_PL_AMT,
                                 PKG_RTL_TELLER_REC.NEGOTIATED_RATE,
                                 'N',
                                 L_PL_OFS_AMT,
                                 P_ERR_CODE) THEN
      RETURN;
    END IF;
  
    DBG('l_pl_ofs_amt ' || L_PL_OFS_AMT);
    DBG('l_pl_ofs_exch_rate ' || L_PL_OFS_EXCH_RATE);
  
    DBG('25688577##pkg_prod.rate_type_preferred--> ' ||
        PKG_PROD.RATE_TYPE_PREFERRED);
    DBG('pkg_prod.rate_code_preferred--> ' || PKG_PROD.RATE_CODE_PREFERRED);
    DBG('pkg_rtl_teller_rec.trn_ref_no--> ' ||
        PKG_RTL_TELLER_REC.TRN_REF_NO);
    DBG('pkg_rtl_teller_rec.ofs_ccy--> ' || PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('pkg_lcy--> ' || PKG_LCY);
    DBG('l_pl_amt_lcy before--> ' || L_PL_AMT_LCY);
    DBG('l_pl_exch_rate before--> ' || L_PL_EXCH_RATE);
  
    IF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
    
      IF NOT CYPKSS.FN_AMT_ROUND(PKG_LCY, L_PL_OFS_AMT, L_PL_AMT_LCY) THEN
        P_ERR_CODE := 'CY-9004;';
        DBG('Failed in pl lcy rounding ' || P_ERR_CODE);
        RETURN;
      END IF;
    
      L_PL_EXCH_RATE := NULL;
      L_PL_AMT       := NULL;
    ELSE
      IF NOT
          CYPKS.FN_AMT1_TO_AMT2(SUBSTR(PKG_RTL_TELLER_REC.TRN_REF_NO, 1, 3),
                                
                                PKG_RTL_TELLER_REC.OFS_CCY,
                                PKG_LCY,
                                
                                'STANDARD',
                                'M',
                                
                                L_PL_OFS_AMT,
                                'Y',
                                L_PL_AMT_LCY,
                                L_PL_EXCH_RATE,
                                P_ERR_CODE) THEN
        DBG('Failed in pl lcy conversion ' || P_ERR_CODE);
        RETURN;
      END IF;
    END IF;
  
    DBG('l_pl_amt_lcy ' || L_PL_AMT_LCY);
    DBG('l_pl_exch_rate ' || L_PL_EXCH_RATE);
  
    DBG('l_pl_amt_lcy ' || L_PL_AMT_LCY);
  
    J := P_ACC_HAND.COUNT;
    DBG('j is  ' || J);
  
    J := J + 1;
  
    P_ACC_HAND(J) := L_EMPTY_REC;
    P_ACC_HAND(J).MODULE := 'RT';
    P_ACC_HAND(J).MIS_HEAD := P_ARC_ROW.COD_MIS_HEAD;
    P_ACC_HAND(J).TRN_REF_NO := P_ACC_HAND(1).TRN_REF_NO;
    P_ACC_HAND(J).EVENT_SR_NO := 1;
    P_ACC_HAND(J).EVENT := 'REVL';
    P_ACC_HAND(J).TRN_DT := P_ACC_HAND(1).TRN_DT;
    P_ACC_HAND(J).VALUE_DT := P_ACC_HAND(1).VALUE_DT;
    P_ACC_HAND(J).TXN_INIT_DATE := P_ACC_HAND(1).TXN_INIT_DATE;
    P_ACC_HAND(J).USER_ID := P_ACC_HAND(1).USER_ID;
    P_ACC_HAND(J).NETTING_IND := P_ACC_HAND(1).NETTING_IND;
    P_ACC_HAND(J).DRCR_IND := 'D';
    P_ACC_HAND(J).INSTRUMENT_CODE := P_ACC_HAND(1).INSTRUMENT_CODE;
    P_ACC_HAND(J).TRN_CODE := P_ACC_HAND(1).TRN_CODE;
    P_ACC_HAND(J).AMOUNT_TAG := 'REVL_AMT';
    P_ACC_HAND(J).AC_BRANCH := L_PL_DR_BRN;
  
    P_ACC_HAND(J).AC_CCY := L_FCY;
  
    P_ACC_HAND(J).FCY_AMOUNT := NULL;
    P_ACC_HAND(J).LCY_AMOUNT := L_PL_AMT_LCY;
    P_ACC_HAND(J).EXCH_RATE := NULL;
  
    P_ACC_HAND(J).AC_NO := L_PL_DR_ACC;
  
    P_ACC_HAND(J + 1) := L_EMPTY_REC;
    P_ACC_HAND(J + 1) := P_ACC_HAND(J);
    P_ACC_HAND(J + 1).DRCR_IND := 'C';
    P_ACC_HAND(J + 1).AMOUNT_TAG := 'REVL_AMT';
    P_ACC_HAND(J + 1).AC_BRANCH := L_PL_CR_BRN;
    P_ACC_HAND(J + 1).AC_NO := L_PL_CR_ACC;
  
    P_ACC_HAND(J + 1).FCY_AMOUNT := NULL;
    P_ACC_HAND(J + 1).LCY_AMOUNT := L_PL_AMT_LCY;
    P_ACC_HAND(J + 1).EXCH_RATE := NULL;
  
    P_ACC_HAND(J + 1).AC_CCY := L_FCY;
  
    DBG('To ret true now ');
    P_RET := 0;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in pr_build_xrate_p_and_l_entries  ' || SQLERRM);
      P_RET := -1;
      RETURN;
  END PR_BUILD_XRATE_P_AND_L_ENTRIES;

  PROCEDURE PR_PRINT_ACCTNG_TABLE(P_ACC_HAND IN ACPKS.TBL_ACHOFF) IS
    I      NUMBER;
    L_ROW  VARCHAR2(500);
    L_LINE VARCHAR2(500);
  BEGIN
  
    SELECT RPAD('-',
                20 + 15 + 15 + 15 + 15 + 1 + 1 + 3 + 3 + 3 + 6 + 3,
                '-')
      INTO L_LINE
      FROM DUAL;
    DBG(L_LINE);
    SELECT '|' || RPAD('Tag', 10, '.') || '|' || RPAD('Brn', 3, '.') || '|' ||
           RPAD('Acc', 20, '.') || '|' || RPAD('Lcy Amt', 15, '.') || '|' ||
           RPAD('Fcy Amt', 15, '.') || '|' || RPAD('Exch Rate', 15, '.') || '|' ||
           RPAD('D/C', 1, '.') || '|' || RPAD('Netting', 1, '.') || '|' ||
           RPAD('Ccy', 3, '.') || '|' || RPAD('TrnCode', 3, '.') || '|' ||
           RPAD('Brn', 3, '.') || '|'
      INTO L_ROW
      FROM DUAL;
    DBG(L_ROW);
    DBG(L_LINE);
  
    FOR I IN 1 .. P_ACC_HAND.COUNT LOOP
      IF P_ACC_HAND.EXISTS(I) THEN
        SELECT '|' || RPAD(P_ACC_HAND(I).AMOUNT_TAG, 10, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_NO, 20, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).LCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).FCY_AMOUNT, -1111), 15, '.') || '|' ||
               RPAD(NVL(P_ACC_HAND(I).EXCH_RATE, -1111), 15, '.') || '|' ||
               RPAD(P_ACC_HAND(I).DRCR_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).NETTING_IND, 1, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_CCY, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).TRN_CODE, 3, '.') || '|' ||
               RPAD(P_ACC_HAND(I).AC_BRANCH, 3, '.') || '|'
          INTO L_ROW
          FROM DUAL;
        DBG(L_ROW);
        DBG(L_LINE);
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END PR_PRINT_ACCTNG_TABLE;

  FUNCTION FN_VALIDATE(P_ERR_CODE  IN OUT VARCHAR2,
                       P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNT            NUMBER := 0;
    L_RET            NUMBER := 0;
    L_TXN_CCY_IS_FCY VARCHAR2(1);
    L_OFF_CCY_IS_FCY VARCHAR2(1);
    L_RATE_INDICATOR VARCHAR2(1);
    L_RATE_DATE      DATE;
    L_TXN_AMT_LCY    NUMBER;
    L_RATE           NUMBER;
    L_DR_LCY_RATE    NUMBER;
    L_CR_LCY_RATE    NUMBER;
    L_RATE_FLAG      NUMBER;
  
    L_NORM_VARIANCE NUMBER;
    L_MAX_VARIANCE  NUMBER;
  
    L_TEMP1         VARCHAR2(1);
    L_TEMP2         VARCHAR2(1);
    L_BRN_REC       CVPKS_UTILS.REC_BRNLCY;
    L_DATE_REC      STTMS_DATES%ROWTYPE;
    L_NEGO_VARIANCE NUMBER;
    L_TMP_TXN_AMT   NUMBER;
    L_TMP_OFS_AMT   NUMBER;
    L_CNT_NSF       NUMBER := 0;
    L_CHQDT         DATE;
    L_CLR_DATE      DATE;
    L_CLR_ALW       STTM_NSF_PARAM.CHQ_CLEAR_ALWD%TYPE;
    L_CLR_DAYS      STTM_NSF_PARAM.CHQ_CLEAR_DAYS%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_NORM_VAR_MIN NUMBER;
    L_MIN_VARIANCE NUMBER;
  
    L_CNT_CCY NUMBER := 0;
  
    CURSOR CUR_DISALLOWED_CCYS IS
      SELECT CCY_CODE
        FROM CSVW_PRODUCT_CURRENCIES
       WHERE PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE;
  
  BEGIN
    DBG('calling  pr_check_not_nulls...');
    PR_CHECK_NOT_NULLS(L_RET, P_ERR_CODE, P_ERR_PARAM);
  
    IF L_RET = -1 AND
       DEPKSS_RETAILTELLERUPLOAD.FN_IS_AN_ERROR_RAISED(L_RET) THEN
      DBG('Error found..');
    
      RETURN FALSE;
    END IF;
  
    DBG('Hook for skipping product allowed validation for PcBank Interface');
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Hook for skipping product allowed validation Starts');
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 3;
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_VALIDATE(L_FN_CALL_ID,
                                                  PKG_RTL_TELLER_REC,
                                                  L_RATE_INDICATOR,
                                                  L_TB_CLUSTER_DATA,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_validate with :::: ' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Skipping the Fn_Prod_Allowed_Acc call....');
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF NOT
          FN_PROD_ALLOWED_ACC(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM) THEN
        DBG('Failed inside fn_prod_allowed_acc');
        DBG('Error code-->' || P_ERR_CODE);
        DBG('Error param-->' || P_ERR_PARAM);
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
      END IF;
    
    ELSE
      DBG('Resetting the variable....');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DBG('Going to Validate Account class at User,Branch and role levels and GL against user');
    IF NOT FN_USER_ALLOWED_ACC(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM) THEN
      DBG('Fn_User_Allowed_Acc has returned false with error code as:' ||
          P_ERR_CODE);
      OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
    END IF;
  
    PKG_LCY              := GLOBAL.LCY;
    PKG_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
  
    PR_CROSS_VALIDATIONS(L_RET, P_ERR_CODE);
    IF L_RET = -1 THEN
      RETURN FALSE;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Hook for skipping pr_instr_no_vals 4');
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 4;
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_VALIDATE(L_FN_CALL_ID,
                                                  PKG_RTL_TELLER_REC,
                                                  L_RATE_INDICATOR,
                                                  L_TB_CLUSTER_DATA,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_validate with :::: ' ||
            P_ERR_CODE);
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF GWPKS_UTIL.PKG_FUNC NOT IN
         ('BCRV', 'DDRV', 'BCDI', 'DDDI', '8305', '8301', '1010') THEN
      
        PR_INSTR_NO_VALS(L_RET, P_ERR_CODE, P_ERR_PARAM);
      END IF;
      IF L_RET = -1 THEN
        RETURN FALSE;
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF (PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY) OR
       (PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY) OR
       (PKG_RTL_TELLER_REC.OFS_CCY <> PKG_LCY) THEN
    
      IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_LCY THEN
        L_TXN_CCY_IS_FCY := 'N';
      ELSE
        L_TXN_CCY_IS_FCY := 'Y';
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
        L_OFF_CCY_IS_FCY := 'N';
      ELSE
        L_OFF_CCY_IS_FCY := 'Y';
      END IF;
      DBG('The debit account is :' || PKG_ARC_ROW.DR_ACC);
    
      DBG('The l_Off_Ccy_Is_Fcy in fn_validate is :' || L_OFF_CCY_IS_FCY ||
          ' and l_Txn_Ccy_Is_Fcy in fn_validate is:' || L_TXN_CCY_IS_FCY);
      DBG('The product code in fn_validate is: ' ||
          PKG_ARC_ROW.COD_PROD_ACC_CLS);
      IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
        IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
          L_RATE_INDICATOR := 'S';
        ELSE
          L_RATE_INDICATOR := 'B';
        END IF;
        DBG('The product code in fn_validate is: ' ||
            PKG_ARC_ROW.COD_PROD_ACC_CLS);
      END IF;
      IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
      
        IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
          
           ('FXPW',
            'FXPA',
            'CRAC',
            'CRCA',
            'CRCM',
            'MCGT',
            'TCPW',
            'TCPN',
            'FTRQ',
            'MSCD',
            'LOCH')
          
           OR (NVL(PKG_TXN_ACC.AC_OR_GL, '**') = 'A' AND
               NVL(PKG_OFS_ACC.AC_OR_GL, '**') = 'A')
        
         THEN
          L_RATE_INDICATOR := 'B';
        END IF;
        IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
          
           ('FXSW', 'FXSA', 'TCSW', 'TCSN', 'MSCC') THEN
          L_RATE_INDICATOR := 'S';
        END IF;
      END IF;
    
      DBG('The Rate Indicator selected is :' || L_RATE_INDICATOR);
    
      IF (PKG_BRANCH_COND_RECORD.EXCH_RATE_HIST_REQUIRED = 'Y' AND
         PKG_RTL_TELLER_REC.VALUE_DT < PKG_RTL_TELLER_REC.TRN_DT) THEN
        L_RATE_DATE := PKG_RTL_TELLER_REC.VALUE_DT;
      ELSE
        L_RATE_DATE := PKG_RTL_TELLER_REC.TRN_DT;
      END IF;
    
      IF PKG_PROD.RATE_CODE_PREFERRED = 'M' THEN
        L_RATE_INDICATOR := 'M';
      END IF;
    
      DBG('In fn_validate, the value of pkg_arc_row.cod_main_offset_flag is :: ' ||
          PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG);
      IF NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'Y' THEN
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 2;
          IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_VALIDATE(L_FN_CALL_ID,
                                                      PKG_RTL_TELLER_REC,
                                                      L_RATE_INDICATOR,
                                                      L_TB_CLUSTER_DATA,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAM) THEN
            DBG('FAILED IN  depks_rtl_teller_cluster.fn_validate');
            RETURN FALSE;
          END IF;
        
          IF L_TB_CLUSTER_DATA.EXISTS('l_Rate') THEN
          
            L_RATE := L_TB_CLUSTER_DATA('l_Rate');
          END IF;
        
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF G_OFSAMT_FLAG THEN
            DBG('>> g_ofsamt_flag is true');
            IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     PKG_PROD.RATE_TYPE_PREFERRED,
                                     L_RATE_INDICATOR,
                                     L_RATE_DATE,
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     L_RATE,
                                     
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;
          ELSIF G_TXNAMT_FLAG THEN
            DBG('>> g_txnamt_flag is true');
          
            DBG('Hook for JMDFGL FCDB Exchange Rate manipulation given');
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              DBG('Hook for JMDFGL FCDB Exchange Rate manipulation Starts');
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;
              DBG('Gng to call depks_rtl_teller_cluster.fn_validate with rate code as :' ||
                  L_RATE_INDICATOR);
              IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_VALIDATE(L_FN_CALL_ID,
                                                          PKG_RTL_TELLER_REC,
                                                          L_RATE_INDICATOR,
                                                          L_TB_CLUSTER_DATA,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN
                DBG('Failed in depks_rtl_teller_cluster.fn_validate');
                RETURN FALSE;
              END IF;
            END IF;
            DBG('Rate code after call to depks_rtl_teller_cluster.fn_validate is :' ||
                L_RATE_INDICATOR);
            DBG('Hook for JMDFGL FCDB Exchange Rate manipulation Ends');
          
            IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_PROD.RATE_TYPE_PREFERRED,
                                     L_RATE_INDICATOR,
                                     L_RATE_DATE,
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     L_RATE,
                                     
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;
          ELSIF G_TXNAMT_FLAG = FALSE AND G_OFSAMT_FLAG = FALSE THEN
          
            DBG('THe previously calculated Exchange Rate is:' || L_RATE);
            DBG('The exchange rate sent from screen is:' ||
                PKG_RTL_TELLER_REC.EXCH_RATE);
            DBG('The transaction account is:' || PKG_TXN_ACC.AC_GL_NO ||
                ' with offset account as:' || PKG_OFS_ACC.AC_GL_NO);
            DBG('Is TXN CASA:' || PKG_TXN_ACC.AC_OR_GL ||
                ' with ofs CASA as:' || PKG_OFS_ACC.AC_OR_GL);
            DBG('The transaction accunt from rec type is:' ||
                PKG_RTL_TELLER_REC.TXN_ACC ||
                ' with transaction currency as:' ||
                PKG_RTL_TELLER_REC.TXN_CCY);
            DBG('The offset account from rec type is:' ||
                PKG_RTL_TELLER_REC.OFS_ACC || ' with offset ccy as:' ||
                PKG_RTL_TELLER_REC.OFS_CCY);
            DBG('The sttb txn account currency is:' ||
                PKG_TXN_ACC.AC_GL_CCY || ' with offset currency as:' ||
                PKG_OFS_ACC.AC_GL_CCY);
            DBG('The function id is:' || GWPKS_UTIL.PKG_FUNC);
            DBG('Pkg_Rtl_Teller_Rec.Branch_Code:' ||
                PKG_RTL_TELLER_REC.BRANCH_CODE);
            IF GWPKS_UTIL.G_FROM_BEAN
              
               AND GWPKS_UTIL.PKG_FUNC NOT IN
               ('1006', '1408', '1008', 'LOCH', '1320') AND
               NVL(PKG_TXN_ACC.AC_OR_GL, '*.*') = 'A' AND
               NVL(PKG_TXN_ACC.AC_GL_CCY, '*.*') =
               NVL(PKG_RTL_TELLER_REC.TXN_CCY, '**') THEN
            
              IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       PKG_RTL_TELLER_REC.TXN_CCY,
                                       PKG_PROD.RATE_TYPE_PREFERRED,
                                       L_RATE_INDICATOR,
                                       L_RATE_DATE,
                                       PKG_RTL_TELLER_REC.TRN_DT,
                                       L_RATE,
                                       L_RATE_FLAG,
                                       P_ERR_CODE) THEN
                RETURN FALSE;
              END IF;
            ELSE
            
              DBG('in the else part');
            
              DBG('PKG_RTL_TELLER_REC.TXN_CCY=' ||
                  PKG_RTL_TELLER_REC.TXN_CCY);
              DBG('PKG_RTL_TELLER_REC.OFS_CCY=' ||
                  PKG_RTL_TELLER_REC.OFS_CCY);
              DBG('PKG_TXN_ACC.AC_GL_CCY=' || PKG_TXN_ACC.AC_GL_CCY);
              DBG('PKG_PROD.RATE_TYPE_PREFERRED=' ||
                  PKG_PROD.RATE_TYPE_PREFERRED);
              DBG('L_RATE_INDICATOR=' || L_RATE_INDICATOR);
              DBG('L_RATE=' || L_RATE);
            
              IF PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('DPOW','NCSF') AND
                 PKG_RTL_TELLER_REC.TXN_CCY = 'KHR' AND
                 PKG_RTL_TELLER_REC.OFS_CCY = 'USD' AND
                 PKG_TXN_ACC.AC_GL_CCY = 'KHR' THEN
                --sampath cardless withdrawal
              
                IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                         PKG_RTL_TELLER_REC.OFS_CCY,
                                         PKG_RTL_TELLER_REC.TXN_CCY,
                                         PKG_PROD.RATE_TYPE_PREFERRED,
                                         L_RATE_INDICATOR,
                                         L_RATE_DATE,
                                         PKG_RTL_TELLER_REC.TRN_DT,
                                         L_RATE,
                                         
                                         L_RATE_FLAG,
                                         P_ERR_CODE) THEN
                  RETURN FALSE;
                END IF;
              
              ELSE
                --sampath cardless withdrawal
                IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                         PKG_RTL_TELLER_REC.TXN_CCY,
                                         PKG_RTL_TELLER_REC.OFS_CCY,
                                         PKG_PROD.RATE_TYPE_PREFERRED,
                                         L_RATE_INDICATOR,
                                         L_RATE_DATE,
                                         PKG_RTL_TELLER_REC.TRN_DT,
                                         L_RATE,
                                         
                                         L_RATE_FLAG,
                                         P_ERR_CODE) THEN
                  RETURN FALSE;
                END IF;
              END IF; --sampath cardless withdrawal
            END IF;
          END IF;
        
          IF L_RATE IS NULL THEN
            P_ERR_CODE := 'DE-TUD-029';
            RETURN FALSE;
          
          ELSE
            DBG('The exchange rate of rtl_teller b4 assignment is:' ||
                PKG_RTL_TELLER_REC.EXCH_RATE);
            DBG('The calculated Exchange rate from l_Rate is = ' || L_RATE);
            DBG('The action type is:' || GWPKS_UTIL.PKG_ACTTYPE);
          
            DBG('The product code is:' || PKG_RTL_TELLER_REC.PRODUCT_CODE ||
                ' with module as:' || PKG_RTL_TELLER_REC.MODULE);
          
            IF NVL(PKG_RTL_TELLER_REC.MODULE, '*.*') = 'DD' THEN
              DBG('The dd exchange rate is:' || PKG_DD_EXCH_RATE);
            
              L_RATE := NVL(PKG_DD_EXCH_RATE, L_RATE);
              DBG('This is a Instrument transaction with exchange rate:' ||
                  L_RATE);
            ELSE
            
              IF NVL(GWPKS_UTIL.PKG_ACTTYPE, '*') = 'INPUT' THEN
                PKG_RTL_TELLER_REC.EXCH_RATE := NVL(L_RATE,
                                                    PKG_RTL_TELLER_REC.EXCH_RATE);
                DBG('Pkg_Rtl_Teller_Rec.Exch_Rate = ' ||
                    PKG_RTL_TELLER_REC.EXCH_RATE);
              END IF;
            
            END IF;
          END IF;
        
        ELSE
          GLOBAL.G_SKIP_KERNEL := FALSE;
        END IF;
      
      END IF;
    ELSE
      L_RATE_INDICATOR := PKG_PROD.RATE_CODE_PREFERRED;
    END IF;
  
    DBG(' pkg_rtl_teller_rec.txn_acc -->' || PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('customer_no-->' || PKG_RTL_TELLER_REC.REL_CUSTOMER);
    DBG('branch_code-->' || PKG_RTL_TELLER_REC.TXN_BRANCH);
  
    DBG('depks_rtl_teller Gwpks_CreateRetailTlr.g_fnaccref' ||
        GWPKS_CREATERETAILTLR.G_FNACCREF);
  
    IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
      DBG('inside if to check if the check is blocked due to nsf');
    
      DBG('pkg_rtl_teller_rec.dr_instrument_code -->' ||
          PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE);
      IF PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE IS NOT NULL THEN
        DBG('inside if to chk the chq no not null');
        BEGIN
          PKG_INSTRUMENTNO_MM := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
          SELECT MIN(CHQ_DT)
            INTO L_CHQDT
            FROM STTB_CUST_CNF_CK_DET
           WHERE CUSTOMER_NO = PKG_RTL_TELLER_REC.REL_CUSTOMER
             AND ACCOUNT_NO = PKG_RTL_TELLER_REC.TXN_ACC
             AND BRANCH_CODE = PKG_RTL_TELLER_REC.TXN_BRANCH
             AND CHQ_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record');
            L_CHQDT := NULL;
        END;
      
        DBG('l_chqdt-->' || L_CHQDT);
        IF L_CHQDT IS NOT NULL THEN
          DBG('inside if when chq dt is not null');
          BEGIN
            SELECT CHQ_CLEAR_ALWD, CHQ_CLEAR_DAYS
              INTO L_CLR_ALW, L_CLR_DAYS
              FROM STTM_NSF_PARAM
             WHERE TYPE = 'NSF';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No data found for the record');
          END;
          DBG('clr allw-->' || L_CLR_ALW);
          DBG('l_clr_days-->' || L_CLR_DAYS);
          L_CLR_DATE := GLOBAL.APPLICATION_DATE;
          DBG('clearing date-->' || L_CLR_DATE);
          DBG('chq date-->' || L_CHQDT);
          IF (L_CLR_DATE > L_CHQDT + L_CLR_DAYS) THEN
            DBG('insdife if for clearance condn check');
            OVPKS.PR_APPENDTBL('DE-NSF002',
                               PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE || '~' ||
                               PKG_RTL_TELLER_REC.TXN_ACC || '~');
          END IF;
        
        ELSE
        
          DBG('inside else part when same chq is not presented');
        
          SELECT COUNT(1)
            INTO L_CNT_NSF
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = PKG_RTL_TELLER_REC.TXN_ACC
             AND BRANCH_CODE = PKG_RTL_TELLER_REC.BRANCH_CODE
             AND CHEQUE_BOOK_FACILITY = 'N'
             AND NSF_BLACKLIST_STATUS = 'Y';
        
          IF L_CNT_NSF > 0 THEN
            DBG('inside if cond to populate ovd as checked is blocked' ||
                L_CNT_NSF);
            OVPKS.PR_APPENDTBL('DE-NSF001',
                               PKG_RTL_TELLER_REC.TXN_ACC || '~');
          
          END IF;
        
        END IF;
      END IF;
    END IF;
  
    IF NVL(PKG_RTL_TELLER_REC.PRODUCT_CODE, '###') IN ('CHDP', 'FTRQ') THEN
      IF ((GWPKS_UTIL.PKG_ACTTYPE <> 'INPUT') OR
         (PKG_RTL_TELLER_REC.SCODE NOT IN
         ('FLEXCUBE', 'FLEXBRANCH', 'FLEXSWITCH'))) THEN
      
        DBG('Calling fn_validate_trust_ac');
        IF NOT
            FN_VALIDATE_TRUST_AC(PKG_RTL_TELLER_REC, P_ERR_CODE, P_ERR_PARAM) THEN
          DBG('Failed in fn_validate_trust_ac :');
          OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF PKG_RTL_TELLER_REC.LCY_AMOUNT > 0 AND
       CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE = FALSE AND
       GWPKS_UTIL.G_FROM_BEAN THEN
      IF PKG_RTL_TELLER_REC.LCY_AMOUNT > 0 AND
         CSPKS_ACC_SERVICE.G_CLOSE_OUT = 'N' THEN
        P_ERR_CODE := 'DE-TUD-057';
        RETURN FALSE;
      ELSE
        L_TXN_AMT_LCY := PKG_RTL_TELLER_REC.LCY_AMOUNT;
      END IF;
    END IF;
  
    DBG('cspkss_charge.g_Sc_Skip_Accntng ->' ||
        CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG);
    DBG('pkg_rtl_teller_rec.lcy_amount ->' ||
        PKG_RTL_TELLER_REC.LCY_AMOUNT);
    IF NVL(CSPKSS_CHARGE.G_SC_SKIP_MAIN_ACCNTNG, 'N') = 'Y' THEN
      PKG_RTL_TELLER_REC.LCY_AMOUNT := 0;
      L_TXN_AMT_LCY                 := 0;
    END IF;
    DBG('l_txn_amt_lcy->' || L_TXN_AMT_LCY);
  
    IF L_TXN_AMT_LCY IS NULL THEN
    
      IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY THEN
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                      PKG_RTL_TELLER_REC.TXN_CCY,
                                      PKG_LCY,
                                      PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                      'Y',
                                      L_TXN_AMT_LCY,
                                      L_RATE,
                                      P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
      ELSE
        L_TXN_AMT_LCY := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      END IF;
    END IF;
  
    DBG('The offset amount is:' || PKG_RTL_TELLER_REC.OFS_AMOUNT ||
        ' and the transaction amount is:' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
    DBG('The package exchange rate in fn validate is:' ||
        PKG_TXN_EXCH_RATE || ' and local rate is:' || L_RATE);
    DBG('The transaction currency is:' || PKG_RTL_TELLER_REC.TXN_CCY ||
        ' with local currency as:' || PKG_LCY);
  
    IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY
    
     THEN
    
      DBG('The transaction currency is:' || PKG_RTL_TELLER_REC.TXN_CCY ||
          ' with local currency as:' || PKG_LCY);
    
      IF PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('DPOW','NCSF') AND
         PKG_RTL_TELLER_REC.TXN_CCY = 'KHR' AND
         PKG_RTL_TELLER_REC.OFS_CCY = 'USD' AND
         PKG_TXN_ACC.AC_GL_CCY = 'KHR' THEN
        --sampath cardless withdrawal
      
        IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                 PKG_RTL_TELLER_REC.OFS_CCY,
                                 PKG_RTL_TELLER_REC.TXN_CCY,
                                 PKG_PROD.RATE_TYPE_PREFERRED,
                                 L_RATE_INDICATOR,
                                 L_RATE_DATE,
                                 PKG_RTL_TELLER_REC.TRN_DT,
                                 L_RATE,
                                 
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
      
      ELSE
        --sampath cardless withdrawal
      
        IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                 PKG_RTL_TELLER_REC.TXN_CCY,
                                 PKG_LCY,
                                 'STANDARD',
                                 'M',
                                 PKG_TXN_EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN FALSE;
        END IF;
      
      END IF; --sampath cardless withdrawal
    
      DBG('The offset currency is:' || PKG_RTL_TELLER_REC.OFS_CCY ||
          ' with local currency as:' || PKG_RTL_TELLER_REC.OFS_CCY);
      DBG('The transaction exchange rate set is:' || PKG_TXN_EXCH_RATE);
    END IF;
    
    DBG('PKG_RTL_TELLER_REC.OFS_AMOUNT=='||PKG_RTL_TELLER_REC.OFS_AMOUNT);
    
    IF PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL THEN
      IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_RTL_TELLER_REC.OFS_CCY THEN
        PKG_RTL_TELLER_REC.OFS_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      ELSIF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
        PKG_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT_LCY;
      ELSE
        P_ERR_CODE := 'DE-TUD-028';
        RETURN FALSE;
      END IF;
    END IF;
    
    DBG('PKG_RTL_TELLER_REC.TXN_CCY=='||PKG_RTL_TELLER_REC.TXN_CCY);
    DBG('PKG_RTL_TELLER_REC.OFS_CCY=='||PKG_RTL_TELLER_REC.OFS_CCY);
  
    IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
    
      DBG('Getting rate ' || PKG_RTL_TELLER_REC.BRANCH_CODE || ' ' ||
          PKG_RTL_TELLER_REC.TXN_CCY);
    
      DBG('The Transaction amount is: ' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
          ' and offset amount is:' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('The Offset Currency is: ' || PKG_RTL_TELLER_REC.OFS_CCY ||
          ' and trasnsaction ccy is:' || PKG_RTL_TELLER_REC.TXN_CCY);
    
      IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
        IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       PKG_RTL_TELLER_REC.TXN_CCY,
                                       NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                           'STANDARD'),
                                       NVL(L_RATE_INDICATOR, 'M'),
                                       PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                       'Y',
                                       L_TMP_TXN_AMT,
                                       PKG_RTL_TELLER_REC.EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
            RETURN FALSE;
          END IF;
        ELSE
          L_TMP_TXN_AMT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        END IF;
      
        PKG_RTL_TELLER_REC.TXN_AMOUNT := L_TMP_TXN_AMT;
      
      ELSIF PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL AND
            PKG_RTL_TELLER_REC.TXN_AMOUNT IS NOT NULL THEN
        DBG('The offset amt is null and txn_amount is nt null');
        IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.TXN_CCY,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                           'STANDARD'),
                                       NVL(L_RATE_INDICATOR, 'M'),
                                       PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                       'Y',
                                       L_TMP_OFS_AMT,
                                       PKG_RTL_TELLER_REC.EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
            RETURN FALSE;
          END IF;
          PKG_RTL_TELLER_REC.OFS_AMOUNT := L_TMP_OFS_AMT;
        END IF;
      END IF;
    
    ELSE
      DBG('Why Im here');
      L_RATE := 1;
    END IF;
  
    DBG('actual exchage rate--> ' || L_RATE);
    DBG('rate given--> ' || PKG_RTL_TELLER_REC.EXCH_RATE);
    DBG('Normal Rate from product--> ' || PKG_PROD.NORMAL_RATE_VARIANCE);
    DBG('Maximum Rate-->' || PKG_PROD.MAXIMUM_RATE_VARIANCE);
  
    IF PKG_RTL_TELLER_REC.EXCH_RATE IS NULL THEN
      DBG('Assignment when pkg_rtl_teller_rec.exch_rate is null');
      PKG_RTL_TELLER_REC.EXCH_RATE := L_RATE;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 10;
      DBG('calling bcpkss_bcctrprf_utils_cluster.fn_cliq_processing..');
      IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_VALIDATE(L_FN_CALL_ID,
                                                  PKG_RTL_TELLER_REC,
                                                  L_RATE_INDICATOR,
                                                  L_TB_CLUSTER_DATA,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAM) THEN
        DBG('Failed in depks_rtl_teller_cluster.fn_validate');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      L_NORM_VARIANCE := L_RATE +
                         (L_RATE * PKG_PROD.NORMAL_RATE_VARIANCE / 100.0);
      L_MAX_VARIANCE  := L_RATE +
                         (L_RATE * PKG_PROD.MAXIMUM_RATE_VARIANCE / 100.0);
    
      L_NORM_VAR_MIN := L_RATE -
                        (L_RATE * PKG_PROD.NORMAL_RATE_VARIANCE / 100.0);
      L_MIN_VARIANCE := L_RATE -
                        (L_RATE * PKG_PROD.MAXIMUM_RATE_VARIANCE / 100.0);
    
      DBG('Variances are ' || L_NORM_VARIANCE);
      DBG('Max is ' || L_MAX_VARIANCE);
      DBG('Got rate ' || PKG_RTL_TELLER_REC.EXCH_RATE);
    
      L_NEGO_VARIANCE := ((ABS(L_RATE - PKG_RTL_TELLER_REC.NEGOTIATED_RATE) /
                         PKG_RTL_TELLER_REC.EXCH_RATE) * 100);
      DBG('Got l_nego_variance:: ' || L_NEGO_VARIANCE);
      DBG('The Negotiated variance from pkg_rtl_teller_rec is:: ' ||
          PKG_RTL_TELLER_REC.NEGOTIATED_RATE);
      DBG('The Min variance is:: ' || L_MIN_VARIANCE);
      DBG('The NOrmal variance min is:: ' || L_NORM_VAR_MIN);
    
      DBG('l_norm_variance  AB:  ' || L_NORM_VARIANCE);
      DBG(' l_max_variance AB: ' || L_MAX_VARIANCE);
    
      IF (PKG_RTL_TELLER_REC.EXCH_RATE <> L_RATE AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') <> ('1317')) THEN
      
        DBG('The actual exchange rate is ' || L_RATE ||
            ' and keyed in rate is ' || PKG_RTL_TELLER_REC.EXCH_RATE);
      
        IF (PKG_RTL_TELLER_REC.EXCH_RATE < L_NORM_VAR_MIN AND
           PKG_RTL_TELLER_REC.EXCH_RATE >= L_MIN_VARIANCE) OR
          
           (PKG_RTL_TELLER_REC.NEGOTIATED_RATE < L_NORM_VAR_MIN AND
           PKG_RTL_TELLER_REC.NEGOTIATED_RATE >= L_MIN_VARIANCE) THEN
          DBG('Override - Checking for < min variance');
          P_ERR_CODE := 'DE-TUD-073';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
        END IF;
      
        IF (PKG_RTL_TELLER_REC.EXCH_RATE < L_MIN_VARIANCE) OR
           (PKG_RTL_TELLER_REC.NEGOTIATED_RATE < L_MIN_VARIANCE) THEN
          DBG('Error - Checking for < min variance');
          P_ERR_CODE := 'LC-COL21';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
          RETURN FALSE;
        END IF;
      
        IF (PKG_RTL_TELLER_REC.EXCH_RATE > L_NORM_VARIANCE AND
           PKG_RTL_TELLER_REC.EXCH_RATE <= L_MAX_VARIANCE) OR
           (PKG_RTL_TELLER_REC.NEGOTIATED_RATE > L_NORM_VARIANCE AND
           PKG_RTL_TELLER_REC.NEGOTIATED_RATE <= L_MAX_VARIANCE)
        
         THEN
          P_ERR_CODE := 'DE-TUD-067';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
        
        END IF;
      
        IF (PKG_RTL_TELLER_REC.EXCH_RATE > L_MAX_VARIANCE) OR
           (PKG_RTL_TELLER_REC.NEGOTIATED_RATE > L_MAX_VARIANCE)
        
         THEN
          P_ERR_CODE := 'LC-COL13';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
          RETURN FALSE;
        END IF;
      END IF;
    
    ELSE
      DBG('Resetting skip kernel variable..');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF PKG_RTL_TELLER_REC.TXN_CCY IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_CNT_CCY
        FROM CSVW_PRODUCT_CURRENCIES
       WHERE PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
         AND CCY_CODE = PKG_RTL_TELLER_REC.TXN_CCY;
      DBG('count for pkg_rtl_teller_rec.txn_ccy is  ' || L_CNT_CCY);
    
      IF L_CNT_CCY = 0 THEN
        P_ERR_CODE := 'DE-TUD-068';
        RETURN FALSE;
      END IF;
    END IF;
  
    IF PKG_RTL_TELLER_REC.OFS_CCY IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_CNT_CCY
        FROM CSVW_PRODUCT_CURRENCIES
       WHERE PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
         AND CCY_CODE = PKG_RTL_TELLER_REC.OFS_CCY;
      DBG('count for pkg_rtl_teller_rec.ofs_ccy is  ' || L_CNT_CCY);
    
      IF L_CNT_CCY = 0 THEN
        P_ERR_CODE := 'DE-TUD-068';
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('The local currency amount to be passed in detb_rtl_teller is:' ||
        PKG_RTL_TELLER_REC.LCY_AMOUNT);
    IF PKG_RTL_TELLER_REC.LCY_AMOUNT IS NULL THEN
      IF PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY AND
         PKG_RTL_TELLER_REC.OFS_CCY <> PKG_LCY THEN
      
        DBG('The lcy computation with txn ccy is:' ||
            PKG_RTL_TELLER_REC.TXN_CCY);
        DBG('The lcy computation with ofs ccy is:' ||
            PKG_RTL_TELLER_REC.TXN_CCY);
        DBG('The credit lcy rate before cypks computation is:' ||
            L_CR_LCY_RATE);
      
        IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_RTL_TELLER_REC.OFS_CCY THEN
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                        PKG_RTL_TELLER_REC.OFS_CCY,
                                        PKG_LCY,
                                        'STANDARD',
                                        'M',
                                        PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                        'Y',
                                        PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                        L_CR_LCY_RATE,
                                        P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;
          DBG('The lcy amount computed for txn =ofs ccy is:' ||
              PKG_RTL_TELLER_REC.LCY_AMOUNT);
          DBG('The credit lcy rate before cypks computation is:' ||
              L_CR_LCY_RATE);
        
          DBG('before call3 Pkg_Rtl_Teller_Rec.Txn_Amount : ' ||
              PKG_RTL_TELLER_REC.TXN_AMOUNT);
        
          IF PKG_RTL_TELLER_REC.LCY_AMOUNT <> 0 AND
             PKG_RTL_TELLER_REC.TXN_AMOUNT <> 0 THEN
            DBG('THe package lcy is:' || PKG_LCY ||
                ' with debit rate as :' || L_DR_LCY_RATE);
          
            IF NOT CYPKSS.FN_AMT_TO_RATE(PKG_LCY,
                                         PKG_RTL_TELLER_REC.TXN_CCY,
                                         PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                         PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                         L_DR_LCY_RATE) THEN
              P_ERR_CODE := 'CY-9000';
              RETURN FALSE;
            END IF;
          
          ELSE
            DBG('THe package lcy WITH RATE NULL is:' || PKG_LCY ||
                ' with debit rate as :' || L_DR_LCY_RATE);
            L_DR_LCY_RATE := NULL;
          END IF;
        
        ELSE
        
          IF G_OFSAMT_FLAG THEN
            DBG('G_OFSAMT_FLAG is true for lcy computation');
          
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                          PKG_RTL_TELLER_REC.TXN_CCY,
                                          PKG_LCY,
                                          NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                              'STANDARD'),
                                          
                                          L_RATE_INDICATOR,
                                          PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                          'Y',
                                          PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                          L_DR_LCY_RATE,
                                          P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;
          
            DBG('before call1 pkg_rtl_teller_rec.lcy_amount : ' ||
                PKG_RTL_TELLER_REC.LCY_AMOUNT);
            DBG('before call1 pkg_rtl_teller_rec.ofs_amount : ' ||
                PKG_RTL_TELLER_REC.OFS_AMOUNT);
          
            IF PKG_RTL_TELLER_REC.LCY_AMOUNT <> 0 AND
               PKG_RTL_TELLER_REC.OFS_AMOUNT <> 0 THEN
              DBG('THe package lcy is:' || PKG_LCY ||
                  ' with credit rate as :' || L_CR_LCY_RATE);
            
              IF NOT CYPKSS.FN_AMT_TO_RATE(PKG_LCY,
                                           PKG_RTL_TELLER_REC.OFS_CCY,
                                           PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                           PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                           L_CR_LCY_RATE) THEN
              
                P_ERR_CODE := 'CY-9000';
                RETURN FALSE;
              END IF;
            
            ELSE
              DBG('THe package lcy WITH RATE NULL is:' || PKG_LCY ||
                  ' with credit rate as :' || L_CR_LCY_RATE);
              L_CR_LCY_RATE := NULL;
            END IF;
          
          ELSIF G_TXNAMT_FLAG THEN
            DBG('G_TXNAMT_FLAG is true for lcy computation');
          
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                          PKG_RTL_TELLER_REC.OFS_CCY,
                                          PKG_LCY,
                                          NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                              'STANDARD'),
                                          
                                          L_RATE_INDICATOR,
                                          PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                          'Y',
                                          PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                          L_CR_LCY_RATE,
                                          P_ERR_CODE) THEN
              RETURN FALSE;
            END IF;
          
            DBG('before call2 pkg_rtl_teller_rec.lcy_amount : ' ||
                PKG_RTL_TELLER_REC.LCY_AMOUNT);
            DBG('before call2 pkg_rtl_teller_rec.txn_amount : ' ||
                PKG_RTL_TELLER_REC.TXN_AMOUNT);
          
            IF PKG_RTL_TELLER_REC.LCY_AMOUNT <> 0 AND
               PKG_RTL_TELLER_REC.TXN_AMOUNT <> 0 THEN
              DBG('THe package lcy is:' || PKG_LCY ||
                  ' with debit rate as :' || L_DR_LCY_RATE);
            
              IF NOT CYPKSS.FN_AMT_TO_RATE(PKG_LCY,
                                           PKG_RTL_TELLER_REC.TXN_CCY,
                                           PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                           PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                           L_DR_LCY_RATE) THEN
                P_ERR_CODE := 'CY-9000';
                RETURN FALSE;
              END IF;
            
            ELSE
              DBG('THe package lcy with rate null is:' || PKG_LCY ||
                  ' with debit rate as :' || L_DR_LCY_RATE);
              L_DR_LCY_RATE := NULL;
            END IF;
          
          ELSE
          
            DBG('pkg_rtl_teller_rec.txn_ccy--> ' ||
                PKG_RTL_TELLER_REC.TXN_CCY);
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                          PKG_RTL_TELLER_REC.TXN_CCY,
                                          PKG_LCY,
                                          NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                              'STANDARD'),
                                          L_RATE_INDICATOR,
                                          PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                          'Y',
                                          PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                          L_DR_LCY_RATE,
                                          P_ERR_CODE) THEN
              DBG('failing in lcy amount conversion..');
              RETURN FALSE;
            END IF;
          
            DBG('before call2 pkg_rtl_teller_rec.lcy_amount--> ' ||
                PKG_RTL_TELLER_REC.LCY_AMOUNT);
            DBG('debit rate is--> ' || L_DR_LCY_RATE);
            IF PKG_RTL_TELLER_REC.LCY_AMOUNT <> 0 AND
               PKG_RTL_TELLER_REC.OFS_AMOUNT <> 0 THEN
              DBG('pkg_lcy--> ' || PKG_LCY || '~' ||
                  'pkg_rtl_teller_rec.ofs_ccy--> ' ||
                  PKG_RTL_TELLER_REC.OFS_CCY);
              IF NOT CYPKSS.FN_AMT_TO_RATE(PKG_LCY,
                                           PKG_RTL_TELLER_REC.OFS_CCY,
                                           PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                           PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                           L_CR_LCY_RATE) THEN
                P_ERR_CODE := 'CY-9000';
                RETURN FALSE;
              END IF;
            ELSE
              DBG('THe package lcy with rate null is:' || PKG_LCY ||
                  ' with credit rate as :' || L_CR_LCY_RATE);
              L_CR_LCY_RATE := NULL;
            END IF;
          
          END IF;
        
        END IF;
      ELSE
        IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_LCY THEN
          PKG_RTL_TELLER_REC.LCY_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        ELSIF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
          PKG_RTL_TELLER_REC.LCY_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        END IF;
      END IF;
    
      L_TEMP1 := CYPKSS.FN_EURTYPE(PKG_RTL_TELLER_REC.TXN_CCY);
      L_TEMP2 := CYPKSS.FN_EURTYPE(PKG_RTL_TELLER_REC.OFS_CCY);
    
      IF CYPKSS.FN_EURTYPE(PKG_LCY) IN ('I', 'E') AND
         PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY THEN
        IF L_TEMP1 IN ('I', 'E') THEN
          L_RATE := NULL;
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                        PKG_RTL_TELLER_REC.TXN_CCY,
                                        PKG_LCY,
                                        PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                        'Y',
                                        PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                        L_RATE,
                                        P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;
        ELSIF L_TEMP2 IN ('I', 'E') AND L_TEMP1 = 'O' THEN
          L_RATE := NULL;
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                        PKG_RTL_TELLER_REC.TXN_CCY,
                                        PKG_LCY,
                                        PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                        'Y',
                                        PKG_RTL_TELLER_REC.LCY_AMOUNT,
                                        L_RATE,
                                        P_ERR_CODE) THEN
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('returning from fn_validate');
  
    RETURN TRUE;
  END FN_VALIDATE;

  FUNCTION FN_VALIDATE_TRUST_AC(PKG_RTL_TELLER_REC IN OUT NOCOPY DETBS_RTL_TELLER%ROWTYPE,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_AC_OR_GL        STTB_ACCOUNT.AC_OR_GL%TYPE;
    L_ESCROW_TRANSFER STTMS_CUST_ACCOUNT.ESCROW_TRANSFER%TYPE;
    L_ACCOUNT_CLASS   STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_TRUSTAC_CCY     STTMS_ACCLS_CCY_BALANCES.CCY_CODE%TYPE;
    L_TRUSTAC_LIMIT   STTMS_ACCLS_CCY_BALANCES.TRUSTAC_CASH_LIMIT%TYPE;
    L_TXN_LCY_AMOUNT  DETB_UPLOAD_RTL_TELLER.LCY_AMOUNT%TYPE;
    L_XRATE           NUMBER;
    L_DEPOSIT_ACC_BRN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_DEPOSIT_ACC     STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
  BEGIN
    DBG('In fn_validate_trust_ac.. ');
  
    DBG('Getting the Deposit/CR Account details.. ');
  
    IF (NVL(PKG_RTL_TELLER_REC.PRODUCT_CODE, '###') IN ('FTRQ')) THEN
    
      L_DEPOSIT_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
      L_DEPOSIT_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
    ELSE
      L_DEPOSIT_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
      L_DEPOSIT_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
    END IF;
  
    DBG('pkg_rtl_teller_rec.TXN_ACC--->' || L_DEPOSIT_ACC);
    DBG('pkg_rtl_teller_rec.TXN_BRANCH--->' || L_DEPOSIT_ACC_BRN);
    BEGIN
      SELECT AC_OR_GL
        INTO L_AC_OR_GL
        FROM STTBS_ACCOUNT
       WHERE AC_GL_NO = L_DEPOSIT_ACC
         AND BRANCH_CODE = L_DEPOSIT_ACC_BRN;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      
        DBG('No record found in sttms_cust_account');
    END;
    DBG('l_ac_or_gl--->' || L_AC_OR_GL);
  
    IF L_AC_OR_GL = 'A' THEN
    
      BEGIN
        SELECT ESCROW_TRANSFER, ACCOUNT_CLASS
          INTO L_ESCROW_TRANSFER, L_ACCOUNT_CLASS
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = L_DEPOSIT_ACC
           AND BRANCH_CODE = L_DEPOSIT_ACC_BRN;
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        
          DBG('No record found in sttms_cust_account');
      END;
      DBG('l_escrow_transfer-->' || L_ESCROW_TRANSFER);
      DBG('l_account_class-->' || L_ACCOUNT_CLASS);
    
      IF L_ESCROW_TRANSFER = 'Y' THEN
        DBG('pkg_rtl_teller_rec.Project_Name-->' ||
            PKG_RTL_TELLER_REC.PROJECT_NAME);
        DBG('pkg_rtl_teller_rec.Unit_Payment-->' ||
            PKG_RTL_TELLER_REC.UNIT_PAYMENT);
        DBG('pkg_rtl_teller_rec.Unit_Id-->' || PKG_RTL_TELLER_REC.UNIT_ID);
        DBG('pkg_rtl_teller_rec.Deposit_Slip_No-->' ||
            PKG_RTL_TELLER_REC.DEPOSIT_SLIP_NO);
      
        IF PKG_RTL_TELLER_REC.PROJECT_NAME IS NULL OR
           PKG_RTL_TELLER_REC.UNIT_PAYMENT IS NULL OR
           PKG_RTL_TELLER_REC.DEPOSIT_SLIP_NO IS NULL THEN
          DBG('Project Details are Mandatory');
          P_ERR_CODE   := 'DE-TUD-117';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      
        IF PKG_RTL_TELLER_REC.UNIT_PAYMENT = 'Y' THEN
          IF PKG_RTL_TELLER_REC.UNIT_ID IS NULL THEN
            DBG('Project Details are Mandatory');
            P_ERR_CODE   := 'DE-TUD-117';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;
        END IF;
      
        IF PKG_RTL_TELLER_REC.UNIT_PAYMENT = 'N' THEN
          IF PKG_RTL_TELLER_REC.UNIT_ID IS NOT NULL THEN
            DBG('Unit Id must not be maintained when Unit Payment is set as No');
            P_ERR_CODE   := 'DE-TUD-119';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;
        END IF;
      
        IF (NVL(PKG_RTL_TELLER_REC.PRODUCT_CODE, '###') IN ('CHDP')) THEN
        
          DBG('Now checking in STTMS_ACCLS_CCY_BALANCES for limit');
          BEGIN
            SELECT CCY_CODE, TRUSTAC_CASH_LIMIT
              INTO L_TRUSTAC_CCY, L_TRUSTAC_LIMIT
              FROM STTMS_ACCLS_CCY_BALANCES
             WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS
               AND CCY_CODE = PKG_RTL_TELLER_REC.TXN_CCY;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG('No record found in sttms_cust_account');
              L_TRUSTAC_LIMIT := NULL;
          END;
          DBG('l_trustac_ccy-->' || L_TRUSTAC_CCY);
          DBG('l_trustac_limit-->' || L_TRUSTAC_LIMIT);
        
          IF L_TRUSTAC_LIMIT IS NOT NULL THEN
          
            IF PKG_RTL_TELLER_REC.TXN_CCY <> L_TRUSTAC_CCY THEN
            
              DBG('pkg_rtl_teller_rec.txn_ccy--->' ||
                  PKG_RTL_TELLER_REC.TXN_CCY);
              DBG('pkg_rtl_teller_rec.txn_amount--->' ||
                  PKG_RTL_TELLER_REC.TXN_AMOUNT);
              DBG('l_txn_lcy_amount--->' || L_TXN_LCY_AMOUNT);
              DBG('l_Xrate--->' || L_XRATE);
            
              IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           PKG_RTL_TELLER_REC.TXN_CCY,
                                           L_TRUSTAC_CCY,
                                           PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                           'Y',
                                           L_TXN_LCY_AMOUNT,
                                           L_XRATE,
                                           P_ERR_CODE) THEN
                DBG('Currency Conversion from ' ||
                    PKG_RTL_TELLER_REC.TXN_CCY || ' to ' || L_TRUSTAC_CCY ||
                    ' failed.-->' || P_ERR_CODE);
                RETURN FALSE;
              ELSE
                DBG('Converted Amount is (' || PKG_RTL_TELLER_REC.TXN_CCY ||
                    ') : ' || L_TXN_LCY_AMOUNT);
              END IF;
            ELSE
              L_TXN_LCY_AMOUNT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
            END IF;
          
            DBG('l_txn_lcy_amount--->' || L_TXN_LCY_AMOUNT);
            DBG('l_trustac_limit--->' || L_TRUSTAC_LIMIT);
          
            IF L_TXN_LCY_AMOUNT > L_TRUSTAC_LIMIT THEN
              DBG('Transaction Amount is greater than the Deposit Limit for Trust Account');
              OVPKSS.PR_APPENDTBL('DE-TUD-118', NULL);
            END IF;
          ELSE
            DBG('l_trustac_limit is NULL');
            DBG('Now checking in STTMS_ACCOUNT_CLASS');
          
            SELECT TRUSTAC_CASH_LIMIT
              INTO L_TRUSTAC_LIMIT
              FROM STTMS_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS;
          
            DBG('l_txn_lcy_amount--->' || L_TXN_LCY_AMOUNT);
            DBG('l_trustac_limit--->' || L_TRUSTAC_LIMIT);
            DBG('pkg_rtl_teller_rec.txn_amount--->' ||
                PKG_RTL_TELLER_REC.TXN_AMOUNT);
            IF L_TRUSTAC_LIMIT IS NOT NULL THEN
              IF PKG_RTL_TELLER_REC.TXN_AMOUNT > L_TRUSTAC_LIMIT THEN
                DBG('Transaction Amount is greater than the Deposit Limit for Trust Account');
                OVPKSS.PR_APPENDTBL('DE-TUD-118', NULL);
              END IF;
            END IF;
          END IF;
        END IF;
      ELSE
        DBG('Account is not Escrow');
        IF PKG_RTL_TELLER_REC.PROJECT_NAME IS NOT NULL OR
           PKG_RTL_TELLER_REC.UNIT_ID IS NOT NULL OR
           PKG_RTL_TELLER_REC.DEPOSIT_SLIP_NO IS NOT NULL THEN
          DBG('Project Details should not be maintained for a Non Escrow Account');
          P_ERR_CODE   := 'DE-TUD-125';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('Returning Success From fn_validate_trust_ac');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('In when others of fn_validate_trust_ac :::: ' || SQLERRM);
      P_ERR_CODE   := 'FT-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_VALIDATE_TRUST_AC;

  PROCEDURE PR_CHECK_NOT_NULLS(P_RET      OUT NUMBER,
                               P_ERR_CODE IN OUT VARCHAR2,
                               P_PARAM    IN OUT VARCHAR2) IS
    L_WALKIN    VARCHAR2(9);
    L_TXN_LIMIT DETM_RT_PREFERENCES.TXN_LIMIT%TYPE;
    L_MODULE    CSTM_PRODUCT.MODULE%TYPE;
  
    L_RATE_FLAG     NUMBER;
    L_CHG           NUMBER;
    L_CHG_EXCH_RATE NUMBER;
    L_TOTTCYCHG     NUMBER;
    L_TMP_TXN_AMT   NUMBER;
  
    L_ERR_PARAM VARCHAR2(250);
  
    L_TXN_CCY_IS_FCY VARCHAR2(1);
    L_OFF_CCY_IS_FCY VARCHAR2(1);
    L_RATE_INDICATOR VARCHAR2(1);
  
    L_TRANSACTION_CURRENCY DETB_RTL_TELLER.TXN_CCY%TYPE;
    L_TRANSACTION_AMOUNT   DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    P_RET := 0;
  
    IF PKG_RTL_TELLER_REC.BRANCH_CODE IS NULL THEN
      P_ERR_CODE := 'DE-TUD-011';
      P_RET      := -1;
      RETURN;
    END IF;
  
    IF PKG_RTL_TELLER_REC.TXN_ACC IS NULL THEN
      P_ERR_CODE := 'DE-TUD-024';
      P_RET      := -1;
      RETURN;
    END IF;
  
    DBG('The product code is: ' || PKG_ARC_ROW.COD_PROD_ACC_CLS);
    DBG('The Product Debit leg is' || PKG_ARC_ROW.DR_ACC);
    IF (PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY AND
       PKG_RTL_TELLER_REC.EXCH_RATE IS NULL) OR
       (PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY AND
       PKG_RTL_TELLER_REC.EXCH_RATE IS NULL) OR
       (PKG_RTL_TELLER_REC.OFS_CCY <> PKG_LCY AND
       PKG_RTL_TELLER_REC.EXCH_RATE IS NULL) THEN
      IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_LCY THEN
        L_TXN_CCY_IS_FCY := 'N';
      ELSE
        L_TXN_CCY_IS_FCY := 'Y';
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
        L_OFF_CCY_IS_FCY := 'N';
      ELSE
        L_OFF_CCY_IS_FCY := 'Y';
      END IF;
    
      DBG('pr_check_not_nulls l_off_ccy_is_fcy in pr_check_not_nulls: ' ||
          L_OFF_CCY_IS_FCY);
      DBG('pr_check_not_nulls l_txn_ccy_is_fcy in pr_check_not_nulls: ' ||
          L_TXN_CCY_IS_FCY);
    
      DBG('The product code in pr_check_not_nulls is: ' ||
          PKG_ARC_ROW.COD_PROD_ACC_CLS);
      IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
        IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
          L_RATE_INDICATOR := 'S';
        ELSE
          L_RATE_INDICATOR := 'B';
        END IF;
        DBG('The product code in fn_validate is: ' ||
            PKG_ARC_ROW.COD_PROD_ACC_CLS);
      END IF;
      IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
      
        IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
          
           ('FXPW',
            'FXPA',
            'CRAC',
            'CRCA',
            'CRCM',
            'MCGT',
            'TCPW',
            'TCPN',
            'FTRQ',
            'MSCD',
            'LOCH')
          
           OR (NVL(PKG_TXN_ACC.AC_OR_GL, '**') = 'A' AND
               NVL(PKG_OFS_ACC.AC_OR_GL, '**') = 'A')
        
         THEN
          L_RATE_INDICATOR := 'B';
        END IF;
        IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
          
           ('FXSW', 'FXSA', 'TCSW', 'TCSN', 'MSCC') THEN
          L_RATE_INDICATOR := 'S';
        END IF;
      END IF;
    
      DBG('pr_check_not_nulls l_rate_indicator in pr_check_not_nulls: ' ||
          L_RATE_INDICATOR);
      IF NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M') = 'M' THEN
        L_RATE_INDICATOR := 'M';
      END IF;
      PKG_PROD.RATE_CODE_PREFERRED := NVL(L_RATE_INDICATOR,
                                          PKG_PROD.RATE_CODE_PREFERRED);
    END IF;
    DBG('>> now l_rate_indicator: ' || L_RATE_INDICATOR);
  
    DBG('pkg_rtl_teller_rec.ofs_amount : ' ||
        PKG_RTL_TELLER_REC.OFS_AMOUNT);
    DBG('pkg_rtl_teller_rec.txn_amount : ' ||
        PKG_RTL_TELLER_REC.TXN_AMOUNT);
    IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
      IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
      
        IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                 PKG_RTL_TELLER_REC.OFS_CCY,
                                 PKG_RTL_TELLER_REC.TXN_CCY,
                                 PKG_PROD.RATE_TYPE_PREFERRED,
                                 'M',
                                 PKG_RTL_TELLER_REC.TRN_DT,
                                 PKG_RTL_TELLER_REC.TRN_DT,
                                 PKG_RTL_TELLER_REC.EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN;
        END IF;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     'STANDARD',
                                     'M',
                                     PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                     'Y',
                                     L_TMP_TXN_AMT,
                                     PKG_RTL_TELLER_REC.EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
          RETURN;
        END IF;
      ELSE
        L_TMP_TXN_AMT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
      END IF;
    
      L_TOTTCYCHG := 0;
      IF PKG_ARC_ROW.COD_CHG_AMT IS NOT NULL THEN
        DBG('Inside check not nulls CHG');
        IF PKG_ARC_ROW.COD_CHG_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          L_CHG           := NULL;
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_ARC_ROW.COD_CHG_CCY,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       'STANDARD',
                                       'M',
                                       PKG_ARC_ROW.COD_CHG_AMT,
                                       'Y',
                                       L_CHG,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        ELSE
          DBG('Am fine now');
          L_CHG           := PKG_ARC_ROW.COD_CHG_AMT;
          L_CHG_EXCH_RATE := 1;
        END IF;
        L_TOTTCYCHG := L_TOTTCYCHG + L_CHG;
      END IF;
    
      IF PKG_ARC_ROW.COD_CHG_AMT1 IS NOT NULL THEN
        DBG('Inside check not nulls CHG');
        IF PKG_ARC_ROW.COD_CHG_CCY1 <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          L_CHG           := NULL;
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_ARC_ROW.COD_CHG_CCY1,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       'STANDARD',
                                       'M',
                                       PKG_ARC_ROW.COD_CHG_AMT1,
                                       'Y',
                                       L_CHG,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        ELSE
          DBG('Am fine now');
          L_CHG           := PKG_ARC_ROW.COD_CHG_AMT1;
          L_CHG_EXCH_RATE := 1;
        END IF;
        L_TOTTCYCHG := L_TOTTCYCHG + L_CHG;
      END IF;
    
      IF PKG_ARC_ROW.COD_CHG_AMT2 IS NOT NULL THEN
        DBG('Inside check not nulls CHG');
        IF PKG_ARC_ROW.COD_CHG_CCY2 <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          L_CHG           := NULL;
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_ARC_ROW.COD_CHG_CCY2,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       'STANDARD',
                                       'M',
                                       PKG_ARC_ROW.COD_CHG_AMT2,
                                       'Y',
                                       L_CHG,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        ELSE
          DBG('Am fine now');
          L_CHG           := PKG_ARC_ROW.COD_CHG_AMT2;
          L_CHG_EXCH_RATE := 1;
        END IF;
        L_TOTTCYCHG := L_TOTTCYCHG + L_CHG;
      END IF;
    
      IF PKG_ARC_ROW.COD_CHG_AMT3 IS NOT NULL THEN
        DBG('Inside check not nulls CHG');
        IF PKG_ARC_ROW.COD_CHG_CCY3 <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          L_CHG           := NULL;
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_ARC_ROW.COD_CHG_CCY3,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       'STANDARD',
                                       'M',
                                       PKG_ARC_ROW.COD_CHG_AMT3,
                                       'Y',
                                       L_CHG,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        ELSE
          DBG('Am fine now');
          L_CHG           := PKG_ARC_ROW.COD_CHG_AMT3;
          L_CHG_EXCH_RATE := 1;
        END IF;
        L_TOTTCYCHG := L_TOTTCYCHG + L_CHG;
      END IF;
    
      IF PKG_ARC_ROW.COD_CHG_AMT4 IS NOT NULL THEN
        DBG('Inside check not nulls CHG');
        IF PKG_ARC_ROW.COD_CHG_CCY4 <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          L_CHG           := NULL;
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_ARC_ROW.COD_CHG_CCY4,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       'STANDARD',
                                       'M',
                                       PKG_ARC_ROW.COD_CHG_AMT4,
                                       'Y',
                                       L_CHG,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Failed while findin xch rate ' || P_ERR_CODE);
            P_RET := -1;
            RETURN;
          END IF;
        ELSE
          DBG('Am fine now');
          L_CHG           := PKG_ARC_ROW.COD_CHG_AMT4;
          L_CHG_EXCH_RATE := 1;
        END IF;
        L_TOTTCYCHG := L_TOTTCYCHG + L_CHG;
      END IF;
    
      DBG('l_tmp_txn_amt = ' || L_TMP_TXN_AMT);
    
      PKG_RTL_TELLER_REC.TXN_AMOUNT := L_TMP_TXN_AMT;
    
    ELSIF PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL THEN
      DBG('Offset Amount is null.');
      DBG('pkg_rtl_teller_rec.txn_ccy = ' || PKG_RTL_TELLER_REC.TXN_CCY);
      DBG('pkg_rtl_teller_rec.ofs_ccy = ' || PKG_RTL_TELLER_REC.OFS_CCY);
      IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
      
        IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                 PKG_RTL_TELLER_REC.TXN_CCY,
                                 PKG_RTL_TELLER_REC.OFS_CCY,
                                 PKG_PROD.RATE_TYPE_PREFERRED,
                                 'M',
                                 PKG_RTL_TELLER_REC.TRN_DT,
                                 PKG_RTL_TELLER_REC.TRN_DT,
                                 PKG_RTL_TELLER_REC.EXCH_RATE,
                                 L_RATE_FLAG,
                                 P_ERR_CODE) THEN
          RETURN;
        END IF;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     'STANDARD',
                                     'M',
                                     PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                     'Y',
                                     L_TMP_TXN_AMT,
                                     PKG_RTL_TELLER_REC.EXCH_RATE,
                                     P_ERR_CODE) THEN
          DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
          RETURN;
        END IF;
      ELSE
        L_TMP_TXN_AMT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
      END IF;
    
      DBG('l_tmp_txn_amt = ' || L_TMP_TXN_AMT);
    
      PKG_RTL_TELLER_REC.OFS_AMOUNT := L_TMP_TXN_AMT;
    
      DBG('After pickup offset amount : pkg_rtl_teller_rec.ofs_amount = ' ||
          PKG_RTL_TELLER_REC.OFS_AMOUNT);
    
    END IF;
  
    IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
      P_ERR_CODE := 'DE-TUD-023';
      P_RET      := -1;
      RETURN;
    END IF;
  
    DBG('Calling Fn_Get_Product_Rec_Wrp for...' ||
        PKG_RTL_TELLER_REC.PRODUCT_CODE);
    IF CSPKSS_FUNCTION_CACHE.FN_GET_PRODUCT_REC_WRP(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                                    P_ERR_CODE,
                                                    L_ERR_PARAM) THEN
      L_MODULE := CSPKSS_FUNCTION_CACHE.G_TBL_CSTM_PROD_REC.MODULE;
      DBG('Product module...' || L_MODULE);
    ELSE
      DBG('Error in getting the product details...' || P_ERR_CODE);
      DBG('In when others of selecting module from cstm_product' ||
          SQLERRM);
      P_ERR_CODE := 'DE-TUD-070';
      P_RET      := -1;
      RETURN;
    END IF;
    DBG('Product details retrived...');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('The release type is:' || CSPKS_REQ_GLOBAL.G_RELEASE_TYPE ||
          ' and we are in pr check not nulls hook');
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 2;
      DBG('Gng to call depks_rtl_teller_cluster.Pr_Check_Not_Nulls with p_ret as :' ||
          P_RET);
      DEPKS_RTL_TELLER_CLUSTER.PR_CHECK_NOT_NULLS(P_RET,
                                                  P_ERR_CODE,
                                                  P_PARAM,
                                                  L_TB_CLUSTER_DATA,
                                                  L_FN_CALL_ID);
      IF P_RET = -1 THEN
        DBG('Failed in depks_rtl_teller_cluster.Pr_Check_Not_Nulls');
        RETURN;
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF L_MODULE <> 'CG' THEN
      
        DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp..' ||
            PKG_RTL_TELLER_REC.PRODUCT_CODE);
        IF NOT CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                                                 P_ERR_CODE,
                                                                 P_PARAM) THEN
          DBG('Failed in obtainin the RT pref bec of - ' || P_ERR_CODE);
          IF P_ERR_CODE = 'CS-FRC-001' THEN
            DBG('No record for this product in detms_rt_preferences');
            P_ERR_CODE := 'DE-TUD-069';
            P_PARAM    := NULL;
            P_RET      := -1;
            RETURN;
          ELSE
            P_ERR_CODE := 'DE-TUD-070';
            P_PARAM    := NULL;
            P_RET      := -1;
            RETURN;
          END IF;
        ELSE
          L_TXN_LIMIT := CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.TXN_LIMIT;
          DBG('In Fn_Get_Detm_Rt_Pref_Rec_Wrp..');
        END IF;
        DBG('Value of l_txn_limit - ' || L_TXN_LIMIT);
      
      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
      DBG('Pkg_Lcy::::' || PKG_LCY);
      DBG('pkg_rtl_teller_rec.txn_ccy::::' || PKG_RTL_TELLER_REC.TXN_CCY);
    
      DBG('The transaction limit set is:' || L_TXN_LIMIT);
      DBG('B4 txn limit validation in rtl teller, The transaction amount is:' ||
          PKG_RTL_TELLER_REC.TXN_AMOUNT);
      DBG('B4 txn limit validation in rtl teller, The Offset amount is:' ||
          PKG_RTL_TELLER_REC.OFS_AMOUNT);
      DBG('B4 txn limit validation in rtl teller,The offset currency is:' ||
          PKG_RTL_TELLER_REC.OFS_CCY);
      DBG('B4 txn limit validation in rtl teller,The transaction currency is:' ||
          PKG_RTL_TELLER_REC.TXN_CCY);
    
      DEBUG.PR_DEBUG('', 'Before call to pr_check_not_nulls_cluster ...');
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 4;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        DEPKS_RTL_TELLER_CLUSTER.PR_CHECK_NOT_NULLS(P_RET,
                                                    P_ERR_CODE,
                                                    P_PARAM,
                                                    L_TB_CLUSTER_DATA,
                                                    L_FN_CALL_ID);
        DEBUG.PR_DEBUG('',
                       'After depks_rtl_teller_cluster.pr_check_not_nulls ...');
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
          L_TRANSACTION_CURRENCY := PKG_RTL_TELLER_REC.OFS_CCY;
          L_TRANSACTION_AMOUNT   := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        ELSIF PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL THEN
          L_TRANSACTION_CURRENCY := PKG_RTL_TELLER_REC.TXN_CCY;
          L_TRANSACTION_AMOUNT   := PKG_RTL_TELLER_REC.TXN_AMOUNT;
        ELSE
        
          IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_LCY THEN
            L_TRANSACTION_CURRENCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_TRANSACTION_AMOUNT   := PKG_RTL_TELLER_REC.TXN_AMOUNT;
          ELSIF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
            L_TRANSACTION_CURRENCY := PKG_RTL_TELLER_REC.OFS_CCY;
            L_TRANSACTION_AMOUNT   := PKG_RTL_TELLER_REC.OFS_AMOUNT;
          ELSE
          
            L_TRANSACTION_CURRENCY := PKG_RTL_TELLER_REC.TXN_CCY;
            L_TRANSACTION_AMOUNT   := PKG_RTL_TELLER_REC.TXN_AMOUNT;
          END IF;
        END IF;
        DBG('The transaction currency in rtl teller is:' ||
            L_TRANSACTION_CURRENCY);
        DBG('The transaction amount in rtl teller is:' ||
            L_TRANSACTION_AMOUNT);
      
        IF L_TRANSACTION_CURRENCY <> PKG_LCY THEN
          DBG('the Local brn ccy is dif then txn ccy');
          L_CHG_EXCH_RATE := NULL;
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       
                                       L_TRANSACTION_CURRENCY,
                                       PKG_LCY,
                                       'STANDARD',
                                       'M',
                                       
                                       L_TRANSACTION_AMOUNT,
                                       'Y',
                                       L_TMP_TXN_AMT,
                                       L_CHG_EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
            RETURN;
          END IF;
          DBG('l_Tmp_Txn_Amt' || L_TMP_TXN_AMT);
          DBG('l_Txn_Limit' || L_TXN_LIMIT);
          IF L_TMP_TXN_AMT > L_TXN_LIMIT THEN
            DBG('failed here in depks_rtl_teller with txnlimit higher ');
            P_ERR_CODE := 'DE-TUD-099';
            P_RET      := -1;
            RETURN;
          END IF;
        ELSE
        
          IF L_TRANSACTION_AMOUNT > L_TXN_LIMIT THEN
            P_ERR_CODE := 'DE-TUD-099';
            P_RET      := -1;
            RETURN;
          END IF;
        END IF;
      
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF NOT (NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'N' AND
        PKG_ARC_ROW.CHG_FROM = 'TXN') THEN
    
      IF PKG_RTL_TELLER_REC.OFS_ACC IS NULL THEN
        P_ERR_CODE := 'DE-TUD-025';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
    IF NOT GWPKS_UTIL.G_FROM_BEAN THEN
    
      IF NOT (NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'N') THEN
      
        IF PKG_RTL_TELLER_REC.OFS_CCY IS NULL THEN
          P_ERR_CODE := 'DE-TUD-027';
          P_RET      := -1;
          RETURN;
        END IF;
      END IF;
      IF PKG_RTL_TELLER_REC.TXN_CCY IS NULL THEN
        P_ERR_CODE := 'DE-TUD-026';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
  
    IF PKG_RTL_TELLER_REC.TRN_DT IS NULL THEN
      PKG_RTL_TELLER_REC.TRN_DT := NVL(PKG_APPLICATION_DATE,
                                       GLOBAL.APPLICATION_DATE);
    END IF;
  
    IF NVL(GWPKS_UTIL.PKG_FUNC, '**') NOT IN
       ('BCRV', 'DDRV', 'BCDI', 'DDDI') THEN
    
      PR_CHK_ACC(PKG_RTL_TELLER_REC.TXN_ACC,
                 PKG_RTL_TELLER_REC.TXN_BRANCH,
                 PKG_TXN_CUST,
                 PKG_TXN_GL_TYPE,
                 PKG_RTL_TELLER_REC.TXN_CCY,
                 P_RET,
                 P_ERR_CODE,
                 P_PARAM);
    
      DBG('checking deceased with pkg_txn_cust');
    
      IF P_ERR_CODE IS NOT NULL AND
         DEPKSS_RETAILTELLERUPLOAD.FN_IS_AN_ERROR_RAISED(P_RET) THEN
      
        DBG('Failed in validate deceased becf - ' || P_ERR_CODE || '~' ||
            P_PARAM);
        P_RET := -1;
      END IF;
    
      IF P_RET = -1 THEN
        RETURN;
      END IF;
    END IF;
  
    DBG('pkg_arc_row.cod_main_offset_flag in pr_check_not_nulls before calling pr_chk_acc :: ' ||
        PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG);
    IF NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'Y' THEN
      IF NVL(GWPKS_UTIL.PKG_FUNC, '**') <> '1317' AND
         G_REDEMPTIONBYTD = 'N' THEN
        DBG('Calling ps_chk_acc for offset amount');
      
        PR_CHK_ACC(PKG_RTL_TELLER_REC.OFS_ACC,
                   PKG_RTL_TELLER_REC.OFS_BRANCH,
                   PKG_OFS_CUST,
                   PKG_OFS_GL_TYPE,
                   PKG_RTL_TELLER_REC.OFS_CCY,
                   P_RET,
                   P_ERR_CODE,
                   P_PARAM);
      
        DBG('checking deceased with ofs cust no');
      
        IF P_ERR_CODE IS NOT NULL AND
           DEPKSS_RETAILTELLERUPLOAD.FN_IS_AN_ERROR_RAISED(P_RET) THEN
        
          P_RET := -1;
        END IF;
      
        IF P_RET = -1 THEN
          RETURN;
        END IF;
      
        PR_VALIDATE_DECEASED(PKG_OFS_CUST,
                             PKG_RTL_TELLER_REC.OFS_ACC,
                             PKG_RTL_TELLER_REC.OFS_BRANCH,
                             P_ERR_CODE,
                             P_PARAM);
      
      END IF;
    END IF;
  
    IF NVL(GWPKS_UTIL.PKG_FUNC, '**') NOT IN
       ('BCRV', 'DDRV', 'BCDI', 'DDDI') THEN
    
      PR_VALIDATE_DECEASED(PKG_TXN_CUST,
                           PKG_RTL_TELLER_REC.TXN_ACC,
                           PKG_RTL_TELLER_REC.TXN_BRANCH,
                           P_ERR_CODE,
                           P_PARAM);
    
    END IF;
  
    DBG('pkg_rtl_teller_rec.rel_customer--->' ||
        PKG_RTL_TELLER_REC.REL_CUSTOMER);
    IF PKG_RTL_TELLER_REC.REL_CUSTOMER IS NULL THEN
      PKG_RTL_TELLER_REC.REL_CUSTOMER := NVL(PKG_TXN_CUST, PKG_OFS_CUST);
      IF PKG_RTL_TELLER_REC.REL_CUSTOMER IS NULL AND
         NVL(GWPKS_UTIL.PKG_FUNC, '*') != '5403' THEN
      
        DBG('global_frc.g_tbl_sttm_branch_rec.walkin_customer -->' ||
            GLOBAL_FRC.G_TBL_STTM_BRANCH_REC.WALKIN_CUSTOMER);
        PKG_RTL_TELLER_REC.REL_CUSTOMER := GLOBAL_FRC.G_TBL_STTM_BRANCH_REC.WALKIN_CUSTOMER;
      
      END IF;
    END IF;
  
    IF PKG_RTL_TELLER_REC.VALUE_DT IS NULL THEN
      PKG_RTL_TELLER_REC.VALUE_DT := PKG_RTL_TELLER_REC.TRN_DT;
    END IF;
  
    PKG_RTL_TELLER_REC.CHG_CONTRA_LEG := PKG_ARC_ROW.CHG_FROM;
  
    IF PKG_RTL_TELLER_REC.CHARGE_ACCOUNT IS NULL AND G_BC_CHARGE_CASH = 'N' THEN
      DBG(' pkg_rtl_teller_rec.charge_account is null so going to set it');
    
      IF PKG_ARC_ROW.CHG_FROM = 'TXN' THEN
        PKG_RTL_TELLER_REC.CHARGE_ACCOUNT := PKG_RTL_TELLER_REC.TXN_ACC;
      ELSE
        PKG_RTL_TELLER_REC.CHARGE_ACCOUNT := PKG_RTL_TELLER_REC.OFS_ACC;
      END IF;
    
    ELSE
      DBG(' pkg_rtl_teller_rec.charge_account if g_BC_charge_cash IS SET ');
      IF G_BC_CHARGE_CASH = 'Y' THEN
        PKG_RTL_TELLER_REC.CHARGE_ACCOUNT := PKG_ARC_ROW.COD_TXN_ACCOUNT;
      END IF;
    
    END IF;
  
    IF PKG_RTL_TELLER_REC.REL_CUSTOMER IS NULL AND
       NVL(GWPKS_UTIL.PKG_FUNC, '*') != '5403' THEN
      P_ERR_CODE := 'DE-TUD-034';
      P_RET      := -1;
      RETURN;
    END IF;
  
    IF PKG_RTL_TELLER_REC.MAKER_DT_STAMP IS NULL THEN
      PKG_RTL_TELLER_REC.MAKER_DT_STAMP := FN_SYSDATE;
      PKG_RTL_TELLER_REC.MAKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                                           (PKG_RTL_TELLER_REC.MAKER_DT_STAMP -
                                           TRUNC(PKG_RTL_TELLER_REC.MAKER_DT_STAMP));
    END IF;
  
    IF PKG_RTL_TELLER_REC.RECORD_STAT IS NULL THEN
      PKG_RTL_TELLER_REC.RECORD_STAT := 'O';
    END IF;
  
    P_RET := 0;
    RETURN;
  END PR_CHECK_NOT_NULLS;

  PROCEDURE PR_CROSS_VALIDATIONS(P_RET      OUT NUMBER,
                                 P_ERR_CODE IN OUT VARCHAR2) IS
  BEGIN
    PR_CHK_BRN(PKG_RTL_TELLER_REC.BRANCH_CODE, P_RET, P_ERR_CODE);
    IF P_RET = -1 THEN
      RETURN;
    END IF;
  
    PR_CHK_BRN(PKG_RTL_TELLER_REC.TXN_BRANCH, P_RET, P_ERR_CODE);
    IF P_RET = -1 THEN
      RETURN;
    END IF;
  
    PR_CHK_BRN(PKG_RTL_TELLER_REC.OFS_BRANCH, P_RET, P_ERR_CODE);
    IF P_RET = -1 THEN
      RETURN;
    END IF;
  
    IF CSPKSS_UTILS.FN_PRODUCT_ALLOWED(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                       PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       
                                       NULL,
                                       GLOBAL.USER_ID,
                                       PKG_RTL_TELLER_REC.REL_CUSTOMER,
                                       NULL,
                                       PKG_PROD.BRANCHES_LIST,
                                       NULL,
                                       NULL,
                                       'B') <> 'A' THEN
      P_RET      := -1;
      P_ERR_CODE := 'DE-TUD-006';
      RETURN;
    END IF;
  
    IF PKG_PROD.PRODUCT_END_DATE IS NOT NULL AND
       PKG_PROD.PRODUCT_END_DATE < PKG_RTL_TELLER_REC.TRN_DT THEN
      P_RET      := -1;
      P_ERR_CODE := 'DE-TUD-017';
      RETURN;
    END IF;
  
    IF PKG_PROD.PRODUCT_START_DATE > PKG_RTL_TELLER_REC.TRN_DT THEN
      P_RET      := -1;
      P_ERR_CODE := 'DE-TUD-018';
      RETURN;
    END IF;
  
  END PR_CROSS_VALIDATIONS;

  PROCEDURE PR_INSTR_NO_VALS(P_RET       OUT NUMBER,
                             P_ERR_CODE  IN OUT VARCHAR2,
                             P_ERR_PARAM IN OUT VARCHAR2) IS
    L_EXP_DATE DATE;
    L_CNT      NUMBER := 0;
    L_ACCREC   STTBS_ACCOUNT%ROWTYPE;
  BEGIN
    IF PKG_TXN_GL_TYPE = '3' OR PKG_OFS_GL_TYPE IN ('2', '3') THEN
      IF PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE IS NULL THEN
        P_ERR_CODE := 'DE-TUD-032';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
  
    L_CNT := 0;
  
    IF PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE IS NOT NULL THEN
    
      DBG('dr_instrument_code is not null ');
      DBG('pkg_rtl_teller_rec.module : ' || PKG_RTL_TELLER_REC.MODULE);
      DBG('pkg_rtl_teller_rec.txn_branch : ' ||
          PKG_RTL_TELLER_REC.TXN_BRANCH);
      DBG('pkg_rtl_teller_rec.txn_acc : ' || PKG_RTL_TELLER_REC.TXN_ACC);
    
      DBG('pkg_rtl_teller_rec.ofs_branch : ' ||
          PKG_RTL_TELLER_REC.OFS_BRANCH);
      DBG('pkg_rtl_teller_rec.ofs_acc : ' || PKG_RTL_TELLER_REC.OFS_ACC);
    
      DBG('pkg_rtl_teller_rec.product_Code : ' ||
          PKG_RTL_TELLER_REC.PRODUCT_CODE);
    
      IF PKG_RTL_TELLER_REC.PRODUCT_CODE IN ('MSCC', 'MSCD') THEN
        DBG('here 1');
        IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                        PKG_RTL_TELLER_REC.OFS_ACC,
                                        L_ACCREC) THEN
          P_RET := -1;
          RETURN;
        END IF;
      ELSE
        DBG('here 2');
        IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                        PKG_RTL_TELLER_REC.TXN_ACC,
                                        L_ACCREC) THEN
          P_RET := -1;
          RETURN;
        END IF;
      END IF;
    
      DBG('l_Accrec.Gl_Aclass_Type-->> ' || L_ACCREC.GL_ACLASS_TYPE);
      IF L_ACCREC.GL_ACLASS_TYPE IN (2, 3) AND
         NVL(PKG_RTL_TELLER_REC.MODULE, 'RT') = 'RT' THEN
        DBG('Skipping the validation so that partial reconcillation can be done');
      ELSE
        DBG('Proceed with the validation');
      
        DBG('The instrument code is:' ||
            PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE ||
            ' with product cde as:' || PKG_RTL_TELLER_REC.PRODUCT_CODE);
      
        IF SUBSTR(PKG_RTL_TELLER_REC.PRODUCT_CODE, 1, 3) NOT IN
           ('TTM', 'BCM') AND
           SUBSTR(PKG_RTL_TELLER_REC.PRODUCT_CODE, 1, 3) NOT IN ('BMC') THEN
          DBG('Skipped the validation for MultiBC Screens as they are one to many and hence uniqueness in dr_instr_code need not be there');
        
          SELECT COUNT(*)
            INTO L_CNT
            FROM DETBS_TELLER_MASTER
           WHERE INSTRUMENT_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
             AND TXN_ACCOUNT = PKG_RTL_TELLER_REC.TXN_ACC
             AND TXN_BRANCH = PKG_RTL_TELLER_REC.TXN_BRANCH
             AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
             AND RECORD_STAT <> 'V'
                
             AND NOT EXISTS
           (SELECT 1
                    FROM CATBS_ARCH_CHK_DTLS_HIST
                   WHERE CHECK_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
                     AND ACCOUNT_NO = PKG_RTL_TELLER_REC.TXN_ACC
                     AND BRANCH = PKG_RTL_TELLER_REC.TXN_BRANCH);
        
          IF L_CNT > 0 THEN
            P_ERR_CODE := 'DE-TUD-033';
            P_RET      := -1;
            RETURN;
          END IF;
        
          SELECT COUNT(*)
            INTO L_CNT
            FROM DETBS_RTL_TELLER
           WHERE DR_INSTRUMENT_CODE = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
             AND RECORD_STAT <> 'V'
             AND PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE
             AND TXN_ACC = PKG_RTL_TELLER_REC.TXN_ACC
             AND TXN_BRANCH = PKG_RTL_TELLER_REC.TXN_BRANCH
                
             AND NOT EXISTS
           (SELECT 1
                    FROM CATBS_ARCH_CHK_DTLS_HIST
                   WHERE CHECK_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
                     AND ACCOUNT_NO = PKG_RTL_TELLER_REC.TXN_ACC
                     AND BRANCH = PKG_RTL_TELLER_REC.TXN_BRANCH);
        
          IF L_CNT > 0 THEN
            DBG('second ....');
            P_ERR_CODE := 'DE-TUD-033';
            P_RET      := -1;
            RETURN;
          END IF;
        END IF;
      END IF;
      BEGIN
        IF TO_NUMBER(PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE) = 0 THEN
        
          P_ERR_CODE := 'DE-TUD-941';
        
          P_RET := -1;
          RETURN;
        END IF;
      EXCEPTION
        WHEN VALUE_ERROR THEN
          NULL;
      END;
    END IF;
  
    IF PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE IS NOT NULL THEN
      BEGIN
      
        SELECT NVL(EXPIRY_DATE, PKG_RTL_TELLER_REC.TRN_DT)
          INTO L_EXP_DATE
          FROM ISTMS_INSTR_TXN
         WHERE INSTR_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
           AND PAYABLE_BANK = PKG_RTL_TELLER_REC.REM_BANK;
      
        IF PKG_RTL_TELLER_REC.TRN_DT > L_EXP_DATE THEN
          P_ERR_CODE  := 'DE-TUD-901';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.TRN_DT || '~' || L_EXP_DATE || '~' ||
                         PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE || '~';
          P_RET       := -1;
          RETURN;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN OTHERS THEN
        
          SELECT NVL(EXPIRY_DATE, PKG_RTL_TELLER_REC.TRN_DT)
            INTO L_EXP_DATE
            FROM ISTMS_INSTR_TXN
           WHERE INSTR_NO = PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE
             AND PAYABLE_BANK = PKG_RTL_TELLER_REC.REM_BANK
             AND ROWNUM = 1;
        
          DBG('Bombing while getting the expiry date for instrument no' ||
              SQLERRM);
          P_ERR_CODE  := 'DE-TUD-900';
          P_ERR_PARAM := PKG_RTL_TELLER_REC.DR_INSTRUMENT_CODE || '~';
          P_RET       := -1;
          RETURN;
      END;
    END IF;
  END PR_INSTR_NO_VALS;

  PROCEDURE PR_CHK_BRN(P_BRN      IN VARCHAR2,
                       P_RET      OUT NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2) IS
    L_CNT NUMBER := 0;
  BEGIN
    L_CNT := 0;
    IF NVL(PKG_BRN, '#$%') <> P_BRN THEN
      BEGIN
        SELECT 1
          INTO L_CNT
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = P_BRN
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_CNT := 0;
      END;
      IF L_CNT <> 1 THEN
        P_ERR_CODE := 'DE-TUD-012';
        P_RET      := -1;
        RETURN;
      END IF;
      PKG_BRN := P_BRN;
    END IF;
    P_RET := 1;
  END PR_CHK_BRN;

  PROCEDURE PR_CHK_ACC(P_ACCOUNT  IN VARCHAR2,
                       P_BRANCH   IN VARCHAR2,
                       P_CUSTOMER OUT VARCHAR2,
                       P_GL_TYPE  OUT VARCHAR2,
                       P_CURRENCY IN OUT VARCHAR2,
                       P_RET      OUT NUMBER,
                       P_ERR_CODE IN OUT VARCHAR2,
                       P_PARAM    IN OUT VARCHAR2) IS
    LO_HO_RES     GLTM_GLMASTER.HO_RES%TYPE;
    L_HEAD_OFFICE STTMS_BRANCH.BRANCH_CODE%TYPE;
  
    L_CASH_GL_ALWD VARCHAR2(1);
  
  BEGIN
    DBG('Branch ' || P_BRANCH || ' Acc ' || P_ACCOUNT);
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRANCH, P_ACCOUNT, PKG_STTB_ACCOUNT) THEN
      P_ERR_CODE := 'DE-TUD-055';
      P_RET      := -1;
      RETURN;
    END IF;
  
    IF NOT (NVL(GWPKS_UTIL.PKG_FUNC, '*.*') = '1317' OR
        ICPKS_FCJ_ICDREDMN.G_FROMREDM)
    
     THEN
      IF PKG_STTB_ACCOUNT.GL_ACLASS_TYPE = '4' OR
         PKG_STTB_ACCOUNT.AUTH_STAT <> 'A' OR
         PKG_STTB_ACCOUNT.AC_GL_REC_STATUS <> 'O' THEN
        P_ERR_CODE := 'DE-TUD-055';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
  
    IF PKG_STTB_ACCOUNT.AC_OR_GL = 'G' THEN
      L_HEAD_OFFICE := GLOBAL.HEAD_OFFICE;
    
      DBG('Calling Fn_Get_Gl_Master_Rec_Wrp for the account...' ||
          P_ACCOUNT);
      IF NOT CSPKSS_FUNCTION_CACHE.FN_GET_GL_MASTER_REC_WRP(P_ACCOUNT,
                                                            P_ERR_CODE,
                                                            P_PARAM) THEN
        IF P_ERR_CODE = 'CS-FRC-001' THEN
        
          DBG('In No data found exception..');
          P_ERR_CODE := 'DE-TUD-049';
          P_RET      := -1;
          P_PARAM    := NULL;
          RETURN;
        ELSE
        
          DBG('WOT exception in Fn_Get_Gl_Master_Rec_Wrp..');
          P_ERR_CODE := NULL;
          P_PARAM    := NULL;
        END IF;
      ELSE
      
        DBG('Values from FRC - ' ||
            CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.HO_RES || '~' ||
            P_BRANCH || '~' || L_HEAD_OFFICE);
        IF (CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.HO_RES = 'A' OR
           (CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.HO_RES = 'B' AND
           (P_BRANCH <> L_HEAD_OFFICE)) OR (CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.HO_RES = 'H' AND
           (P_BRANCH = L_HEAD_OFFICE))) THEN
        
          DBG('Conditions are satisfied..');
          LO_HO_RES := CSPKSS_FUNCTION_CACHE.G_TBL_GLTM_GLMASTER_REC.HO_RES;
        ELSE
        
          DBG('In No data found exception..');
          P_ERR_CODE := 'DE-TUD-049';
          P_RET      := -1;
          P_PARAM    := NULL;
          RETURN;
        END IF;
      END IF;
    
      DBG('Success cspkss_function_cache...');
    
      IF PKG_STTB_ACCOUNT.GL_CCY_RES = 'S' THEN
        IF NVL(P_CURRENCY, PKG_STTB_ACCOUNT.AC_GL_CCY) <>
           PKG_STTB_ACCOUNT.AC_GL_CCY THEN
          P_ERR_CODE := 'DE-TUD-050';
          P_RET      := -1;
          RETURN;
        END IF;
        IF P_CURRENCY IS NULL THEN
          P_CURRENCY := PKG_STTB_ACCOUNT.AC_GL_CCY;
        END IF;
      
      ELSIF PKG_STTB_ACCOUNT.GL_CCY_RES = 'F' THEN
        IF P_CURRENCY = PKG_LCY THEN
          P_ERR_CODE := 'DE-TUD-051';
          P_RET      := -1;
          RETURN;
        END IF;
      ELSIF PKG_STTB_ACCOUNT.GL_CCY_RES = 'A' THEN
        IF P_CURRENCY IS NULL THEN
          P_CURRENCY := PKG_LCY;
        END IF;
      END IF;
      IF PKG_STTB_ACCOUNT.GL_STAT_BLOCKED = 'Y' THEN
        P_ERR_CODE := 'AC-VGL04';
        P_RET      := -1;
        RETURN;
      END IF;
    
    END IF;
    IF PKG_STTB_ACCOUNT.AC_OR_GL = 'A' THEN
      IF NVL(P_CURRENCY, PKG_STTB_ACCOUNT.AC_GL_CCY) <>
         PKG_STTB_ACCOUNT.AC_GL_CCY THEN
      
        P_ERR_CODE := 'ST-VALS046';
        P_PARAM    := P_PARAM ||
                      NVL(P_CURRENCY, PKG_STTB_ACCOUNT.AC_GL_CCY) || '~;';
        P_RET      := -1;
        RETURN;
      END IF;
    
      IF P_CURRENCY IS NULL THEN
        P_CURRENCY := PKG_STTB_ACCOUNT.AC_GL_CCY;
      END IF;
    
      IF P_CUSTOMER IS NULL THEN
        P_CUSTOMER := PKG_STTB_ACCOUNT.CUST_NO;
        IF P_CUSTOMER IS NULL THEN
        
          P_CUSTOMER := GLOBAL_FRC.G_TBL_STTM_BRANCH_REC.WALKIN_CUSTOMER;
        
        END IF;
      END IF;
      IF NVL(CLPKS_CONTEXT.G_FUNCTION_ID, '*.*') NOT IN
         ('CIDDPMNT', 'CLDPYMNT', 'CIDPYMNT', 'LEDPMNT') THEN
      
        IF PKG_STTB_ACCOUNT.AC_OPEN_DATE >
           NVL(PKG_RTL_TELLER_REC.VALUE_DT, GLOBAL.APPLICATION_DATE) THEN
        
          P_ERR_CODE := 'DE-TUD-943';
          P_PARAM    := P_PARAM || NVL(PKG_RTL_TELLER_REC.VALUE_DT,
                                       GLOBAL.APPLICATION_DATE) || '~' ||
                       
                        PKG_STTB_ACCOUNT.AC_OPEN_DATE || '~' ||
                        PKG_STTB_ACCOUNT.AC_GL_NO || '~;';
        
          DBG('VALUE DATE1 > OPENING DATE ' || P_PARAM);
          P_RET := -1;
          RETURN;
        END IF;
      END IF;
    ELSE
      IF P_CURRENCY IS NULL THEN
        P_ERR_CODE := 'DE-TUD-026';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
  
    IF CSPKSS_UTILS.FN_PRODUCT_ALLOWED(PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                       P_BRANCH,
                                       NULL,
                                       GLOBAL.USER_ID,
                                       P_CUSTOMER,
                                       PKG_STTB_ACCOUNT.CUSTOMER_CAT,
                                       PKG_PROD.BRANCHES_LIST,
                                       PKG_PROD.CURRENCIES_LIST,
                                       PKG_PROD.CATEGORIES_LIST,
                                       'C') <> 'A' THEN
      DBG('The customer category is:' || PKG_STTB_ACCOUNT.CUSTOMER_CAT);
      DBG('The customer is:' || P_CUSTOMER || ' with categories list as:' ||
          PKG_PROD.CATEGORIES_LIST);
      IF PKG_STTB_ACCOUNT.AC_OR_GL IN ('A', 'G') OR
         PKG_STTB_ACCOUNT.GL_CCY_RES = 'S' THEN
      
        DBG('The product disalllowed for the teller is:' ||
            PKG_RTL_TELLER_REC.PRODUCT_CODE);
      
        P_ERR_CODE := 'DE-TUD-111';
        P_PARAM    := PKG_RTL_TELLER_REC.PRODUCT_CODE || '~';
      
        P_RET := -1;
        RETURN;
      ELSE
        P_CURRENCY := '';
        P_ERR_CODE := 'DE-TUD-052';
        P_RET      := -1;
        RETURN;
      END IF;
    END IF;
  
  END PR_CHK_ACC;

  PROCEDURE PR_SUPERSCRIBE_ARC IS
    L_CCY         STTMS_CUST_ACCOUNT.CCY%TYPE;
    P_ERR_CODE    VARCHAR2(1000);
    P_ERR_PARAM   VARCHAR2(1000);
    I             NUMBER := 1;
    L_BRN         VARCHAR2(3);
    L_AMT1        IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_AMT2        IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_AMT3        IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_AMT4        IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_AMT5        IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_TMP_TXN_AMT NUMBER;
    L_RATE_FLAG   NUMBER;
    L_TMP_OFS_AMT NUMBER;
    L_WAIVER      VARCHAR2(1);
    L_IB_FLAG     VARCHAR2(1);
    L_TXN_AC_NO   DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_TXN_BRN     DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  
    L_TXN_CCY_IS_FCY VARCHAR2(1);
    L_OFF_CCY_IS_FCY VARCHAR2(1);
    L_RATE_INDICATOR VARCHAR2(1);
    L_RATE_DATE      DATE;
    L_BRN_REC        CVPKS_UTILS.REC_BRNLCY;
    L_DATE_REC       STTMS_DATES%ROWTYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    TYPE TY_CHG_AMT_REC IS RECORD(
      CHG_AMT NUMBER,
      CHG_CCY VARCHAR2(3));
    TYPE TB_CHG_AMT IS TABLE OF TY_CHG_AMT_REC INDEX BY BINARY_INTEGER;
    TB_CHG       TB_CHG_AMT;
    CHG_DETS_ROW NUMBER := 1;
  
    L_TBCHG_CCY DETB_RTL_TELLER.TXN_CCY%TYPE;
  
  BEGIN
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('Gng to call depks_rtl_teller_cluster.pr_pre_superscribe_arc');
      DEPKS_RTL_TELLER_CLUSTER.PR_PRE_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      G_OFSAMT_FLAG := FALSE;
      G_TXNAMT_FLAG := FALSE;
    
      DBG('pkg_rtl_teller_rec.txn_acc ::::::' ||
          PKG_RTL_TELLER_REC.TXN_ACC);
      DBG('pkg_arc_row.cod_txn_account ::::::' ||
          PKG_ARC_ROW.COD_TXN_ACCOUNT);
      DBG('pkg_arc_row.cod_txn_brn ::::::' || PKG_ARC_ROW.COD_TXN_BRN);
      DBG('l_ccy ::::::' || L_CCY);
      DBG('pkg_rtl_teller_rec.txn_ccy ::::::' ||
          PKG_RTL_TELLER_REC.TXN_CCY);
      DBG('pkg_rtl_teller_rec.txn_trn_code ::::::' ||
          PKG_RTL_TELLER_REC.TXN_TRN_CODE);
      DBG('pkg_arc_row.cod_main_txn_code ::::::' ||
          PKG_ARC_ROW.COD_MAIN_TXN_CODE);
      DBG('pkg_rtl_teller_rec.ofs_acc ::::::' ||
          PKG_RTL_TELLER_REC.OFS_ACC);
      DBG('pkg_arc_row.cod_offset_acc ::::::' ||
          PKG_ARC_ROW.COD_OFFSET_ACC);
      DBG('pkg_arc_row.cod_offset_brn ::::::' ||
          PKG_ARC_ROW.COD_OFFSET_BRN);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('Hook for audi 9009 nostro account Starts');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 4;
        DBG('Gng to call depks_rtl_teller_cluster.Pr_Superscribe_Arc with rate code as :' ||
            PKG_PROD.RATE_CODE_PREFERRED);
        DEPKS_RTL_TELLER_CLUSTER.PR_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                    PKG_RTL_TELLER_REC,
                                                    PKG_PROD.RATE_CODE_PREFERRED,
                                                    L_TB_CLUSTER_DATA,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM);
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed in depks_rtl_teller_cluster.Pr_Superscribe_Arc');
          RETURN;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.TXN_ACC IS NULL AND
         PKG_ARC_ROW.COD_TXN_ACCOUNT IS NOT NULL THEN
        IF FN_IS_GL(PKG_ARC_ROW.COD_TXN_BRN,
                    PKG_ARC_ROW.COD_TXN_ACCOUNT,
                    L_CCY) THEN
          PKG_RTL_TELLER_REC.TXN_ACC := PKG_ARC_ROW.COD_TXN_ACCOUNT;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.TXN_CCY IS NULL AND
         PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
        IF NOT FN_IS_GL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                        PKG_RTL_TELLER_REC.TXN_ACC,
                        L_CCY) THEN
          PKG_RTL_TELLER_REC.TXN_CCY := L_CCY;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.TXN_TRN_CODE IS NULL THEN
        PKG_RTL_TELLER_REC.TXN_TRN_CODE := PKG_ARC_ROW.COD_MAIN_TXN_CODE;
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_ACC IS NULL AND
         PKG_ARC_ROW.COD_OFFSET_ACC IS NOT NULL THEN
        DBG('Yes, here');
        IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
          L_BRN := GLOBAL.CURRENT_BRANCH;
        ELSE
          L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
        END IF;
      
        PKG_RTL_TELLER_REC.OFS_BRANCH := L_BRN;
        PKG_RTL_TELLER_REC.OFS_ACC    := PKG_ARC_ROW.COD_OFFSET_ACC;
      
      END IF;
    
      DBG('pkg_rtl_teller_rec.ofs_ccy ::::::' ||
          PKG_RTL_TELLER_REC.OFS_CCY);
      DBG('pkg_rtl_teller_rec.ofs_branch ::::::' ||
          PKG_RTL_TELLER_REC.OFS_BRANCH);
      DBG('pkg_rtl_teller_rec.ofs_acc ::::::' ||
          PKG_RTL_TELLER_REC.OFS_ACC);
      DBG('pkg_rtl_teller_rec.ofs_branch ::::::' ||
          PKG_RTL_TELLER_REC.OFS_BRANCH);
      IF DEPKS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        IF PKG_RTL_TELLER_REC.OFS_ACC IS NULL AND
           PKG_ARC_ROW.COD_OFFSET_ACC IS NULL AND
           PKG_RTL_TELLER_REC.OFS_CCY IS NULL THEN
          DBG('Here when offset account is null');
          IF PKG_ARC_ROW.COD_OFFSET_BRN = '*.*' THEN
            L_BRN := GLOBAL.CURRENT_BRANCH;
          ELSE
            L_BRN := PKG_ARC_ROW.COD_OFFSET_BRN;
          END IF;
          PKG_RTL_TELLER_REC.OFS_BRANCH := L_BRN;
          PKG_RTL_TELLER_REC.OFS_ACC    := PKG_ARC_ROW.COD_OFFSET_ACC;
          PKG_RTL_TELLER_REC.OFS_CCY    := PKG_RTL_TELLER_REC.TXN_CCY;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_CCY IS NULL AND
         PKG_RTL_TELLER_REC.OFS_BRANCH IS NOT NULL THEN
        DBG('Here also?');
        IF NOT FN_IS_GL(PKG_RTL_TELLER_REC.OFS_BRANCH,
                        PKG_RTL_TELLER_REC.OFS_ACC,
                        L_CCY) THEN
          PKG_RTL_TELLER_REC.OFS_CCY := L_CCY;
        ELSE
          DBG('GL ' || PKG_RTL_TELLER_REC.OFS_CCY);
          PKG_RTL_TELLER_REC.OFS_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_TRN_CODE IS NULL THEN
        PKG_RTL_TELLER_REC.OFS_TRN_CODE := PKG_ARC_ROW.COD_OFFSET_TXN_CODE;
      END IF;
    
      IF PKG_RTL_TELLER_REC.MIS_HEAD IS NULL AND
         PKG_ARC_ROW.COD_MIS_HEAD IS NOT NULL THEN
        PKG_RTL_TELLER_REC.MIS_HEAD := PKG_ARC_ROW.COD_MIS_HEAD;
      END IF;
    
      PKG_RTL_TELLER_REC.DR_ACC := PKG_ARC_ROW.DR_ACC;
    
      DBG('pkg_rtl_teller_rec.branch_code    : ' ||
          PKG_RTL_TELLER_REC.BRANCH_CODE);
      DBG('pkg_rtl_teller_rec.ofs_ccy        : ' ||
          PKG_RTL_TELLER_REC.OFS_CCY);
      DBG('pkg_rtl_teller_rec.txn_ccy        : ' ||
          PKG_RTL_TELLER_REC.TXN_CCY);
      DBG('pkg_prod.rate_type_preferred      : ' ||
          PKG_PROD.RATE_TYPE_PREFERRED);
      DBG('pkg_rtl_teller_rec.trn_dt         : ' ||
          PKG_RTL_TELLER_REC.TRN_DT);
    
      IF (PKG_RTL_TELLER_REC.OFS_CCY = PKG_RTL_TELLER_REC.TXN_CCY) THEN
      
        PKG_RTL_TELLER_REC.EXCH_RATE := 1;
      
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('Hook for audi 9009 nostro account Starts');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 5;
        DBG('Gng to call depks_rtl_teller_cluster.Pr_Superscribe_Arc with rate code as :' ||
            PKG_PROD.RATE_CODE_PREFERRED);
        DEPKS_RTL_TELLER_CLUSTER.PR_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                    PKG_RTL_TELLER_REC,
                                                    PKG_PROD.RATE_CODE_PREFERRED,
                                                    L_TB_CLUSTER_DATA,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM);
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed in depks_rtl_teller_cluster.Pr_Superscribe_Arc');
          RETURN;
        END IF;
      END IF;
    
      IF GLOBAL.CURRENT_BRANCH <> PKG_RTL_TELLER_REC.BRANCH_CODE THEN
        CVPKS_UTILS.GET_BRANCH_LCY(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                   L_BRN_REC);
        PKG_LCY := L_BRN_REC.BRN_LCY;
        CVPKS_UTILS.GET_BRN_DATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                 L_DATE_REC);
        PKG_APPLICATION_DATE := L_DATE_REC.TODAY;
      ELSE
        PKG_LCY              := GLOBAL.LCY;
        PKG_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
      END IF;
    
      DBG('CNSL TXN CCY: ' || PKG_RTL_TELLER_REC.TXN_CCY);
      DBG('CNSL OFS CCY: ' || PKG_RTL_TELLER_REC.OFS_CCY);
      DBG('CNSL PKG CCY: ' || PKG_LCY);
      DBG('CNSL EX RATE: ' || PKG_RTL_TELLER_REC.EXCH_RATE);
      DBG('CNSL pkg_arc_row.dr_acc: ' || PKG_ARC_ROW.DR_ACC);
    
      DBG('Pkg_Rtl_Teller_Rec.Txn_Branch is : ' ||
          PKG_RTL_TELLER_REC.TXN_BRANCH ||
          ' and Pkg_Rtl_Teller_Rec.Txn_Acc is ' ||
          PKG_RTL_TELLER_REC.TXN_ACC);
      DBG('Pkg_Rtl_Teller_Rec.Ofs_Branch is : ' ||
          PKG_RTL_TELLER_REC.OFS_BRANCH ||
          ' and Pkg_Rtl_Teller_Rec.Ofs_Acc is ' ||
          PKG_RTL_TELLER_REC.OFS_ACC);
      IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
        IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.TXN_BRANCH,
                                        PKG_RTL_TELLER_REC.TXN_ACC,
                                        PKG_TXN_ACC) THEN
          DBG('Failed while retreiving the pkg_Txn_Acc.Ac_Or_Gl details ');
        END IF;
        DBG('pkg_Txn_Acc.Ac_Or_Gl = ' || PKG_TXN_ACC.AC_OR_GL);
      END IF;
    
      IF PKG_RTL_TELLER_REC.OFS_ACC IS NOT NULL THEN
        IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TELLER_REC.OFS_BRANCH,
                                        PKG_RTL_TELLER_REC.OFS_ACC,
                                        PKG_OFS_ACC) THEN
          DBG('Failed while retreiving the pkg_Ofs_Acc.Ac_Or_Gl details ');
        END IF;
        DBG('pkg_Ofs_Acc.Ac_Or_Gl = ' || PKG_OFS_ACC.AC_OR_GL);
      END IF;
    
      IF ((PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY AND
         PKG_RTL_TELLER_REC.EXCH_RATE IS NULL) OR
         (PKG_RTL_TELLER_REC.TXN_CCY <> PKG_LCY AND
         PKG_RTL_TELLER_REC.EXCH_RATE IS NULL) OR
         (PKG_RTL_TELLER_REC.OFS_CCY <> PKG_LCY AND
         PKG_RTL_TELLER_REC.EXCH_RATE IS NULL)
         
         ) OR (GWPKS_UTIL.PKG_FUNC = '5402')
      
       THEN
      
        DBG('5402 pkg_rtl_teller_rec.txn_amount pr_superscribe_arc-->' ||
            PKG_RTL_TELLER_REC.TXN_AMOUNT);
        IF GWPKS_UTIL.PKG_FUNC = '5402' AND
           PKG_RTL_TELLER_REC.TXN_CCY <> PKG_RTL_TELLER_REC.OFS_CCY THEN
          PKG_RTL_TELLER_REC.TXN_AMOUNT := NULL;
        ELSIF GWPKS_UTIL.PKG_FUNC = '5402' AND
              PKG_RTL_TELLER_REC.TXN_CCY = PKG_RTL_TELLER_REC.OFS_CCY AND
              PKG_RTL_TELLER_REC.TXN_AMOUNT IS NOT NULL AND
              PKG_RTL_TELLER_REC.OFS_AMOUNT IS NOT NULL THEN
          PKG_RTL_TELLER_REC.TXN_AMOUNT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        END IF;
        DBG('5402 pr_superscribe_arc pkg_rtl_teller_rec.txn_amount -->' ||
            PKG_RTL_TELLER_REC.TXN_AMOUNT ||
            'Pkg_Rtl_Teller_Rec.ofs_amount-->' ||
            PKG_RTL_TELLER_REC.OFS_AMOUNT);
      
        IF PKG_RTL_TELLER_REC.TXN_CCY = PKG_LCY THEN
          L_TXN_CCY_IS_FCY := 'N';
        ELSE
          L_TXN_CCY_IS_FCY := 'Y';
        END IF;
      
        IF PKG_RTL_TELLER_REC.OFS_CCY = PKG_LCY THEN
          L_OFF_CCY_IS_FCY := 'N';
        ELSE
          L_OFF_CCY_IS_FCY := 'Y';
        END IF;
      
        DBG('CNSL l_off_ccy_is_fcy: ' || L_OFF_CCY_IS_FCY);
        DBG('CNSL l_txn_ccy_is_fcy: ' || L_TXN_CCY_IS_FCY);
      
        DBG('The product code in pr_subscribe_arc is: ' ||
            PKG_ARC_ROW.COD_PROD_ACC_CLS);
        IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
          IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
            L_RATE_INDICATOR := 'S';
          ELSE
            L_RATE_INDICATOR := 'B';
          END IF;
        END IF;
        DBG('The product code in pr_subscribe_arc is: ' ||
            PKG_ARC_ROW.COD_PROD_ACC_CLS);
        IF L_TXN_CCY_IS_FCY = 'Y' OR L_OFF_CCY_IS_FCY = 'Y' THEN
        
          IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
            
             ('FXPW',
              'FXPA',
              'CRAC',
              'CRCA',
              'CRCM',
              'MCGT',
              'TCPW',
              'TCPN',
              'FTRQ',
              'MSCD',
              'LOCH')
            
             OR (NVL(PKG_TXN_ACC.AC_OR_GL, '**') = 'A' AND
                 NVL(PKG_OFS_ACC.AC_OR_GL, '**') = 'A')
          
           THEN
            L_RATE_INDICATOR := 'B';
          END IF;
          IF NVL(PKG_ARC_ROW.COD_PROD_ACC_CLS, '#$#') IN
            
             ('FXSW', 'FXSA', 'TCSW', 'TCSN', 'MSCC') THEN
            L_RATE_INDICATOR := 'S';
          END IF;
        END IF;
      
        DBG('CNSL l_rate_indicator: ' || L_RATE_INDICATOR);
        IF NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M') = 'M' THEN
          L_RATE_INDICATOR := 'M';
        END IF;
        PKG_PROD.RATE_CODE_PREFERRED := NVL(L_RATE_INDICATOR,
                                            PKG_PROD.RATE_CODE_PREFERRED);
      END IF;
    
      DBG('THe txn amount is:' || PKG_RTL_TELLER_REC.TXN_AMOUNT ||
          ' with offset amount as:' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
    
      IF PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
        G_TXNAMT_FLAG := TRUE;
        IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        
          IF PKG_RTL_TELLER_REC.EXCH_RATE IS NULL AND
             PKG_RTL_TELLER_REC.TXN_AMOUNT IS NULL THEN
          
            DBG('Hook for JMDFGL FCDB Exchange Rate manipulation given');
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              DBG('Hook for JMDFGL FCDB Exchange Rate manipulation Starts');
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;
              DBG('Gng to call depks_rtl_teller_cluster.Pr_Superscribe_Arc with rate code as :' ||
                  PKG_PROD.RATE_CODE_PREFERRED);
              DEPKS_RTL_TELLER_CLUSTER.PR_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                          PKG_RTL_TELLER_REC,
                                                          PKG_PROD.RATE_CODE_PREFERRED,
                                                          L_TB_CLUSTER_DATA,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM);
              IF P_ERR_CODE IS NOT NULL THEN
                DBG('Failed in epks_rtl_teller_cluster.Pr_Superscribe_Arc');
                RETURN;
              END IF;
            END IF;
            DBG('Rate code after call to depks_rtl_teller_cluster.Pr_Superscribe_Arc is :' ||
                PKG_PROD.RATE_CODE_PREFERRED);
            DBG('Hook for JMDFGL FCDB Exchange Rate manipulation Ends');
          
            IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_PROD.RATE_TYPE_PREFERRED
                                     
                                    ,
                                     NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M'),
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     PKG_RTL_TELLER_REC.EXCH_RATE,
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              RETURN;
            END IF;
          END IF;
        
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.OFS_CCY,
                                       PKG_RTL_TELLER_REC.TXN_CCY
                                       
                                      ,
                                       NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                           'STANDARD')
                                       
                                      ,
                                       NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M'),
                                       PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                       'Y',
                                       L_TMP_TXN_AMT,
                                       PKG_RTL_TELLER_REC.EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
            RETURN;
          END IF;
        ELSE
          L_TMP_TXN_AMT := PKG_RTL_TELLER_REC.OFS_AMOUNT;
        END IF;
        PKG_RTL_TELLER_REC.TXN_AMOUNT := L_TMP_TXN_AMT;
      
      ELSIF PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL AND
            PKG_RTL_TELLER_REC.TXN_AMOUNT IS NOT NULL THEN
      
        DBG('In superscribe_arc, the value of pkg_arc_row.cod_main_offset_flag is :: ' ||
            PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG);
        IF NVL(PKG_ARC_ROW.COD_MAIN_OFFSET_FLAG, 'N') = 'Y' THEN
        
          G_OFSAMT_FLAG := TRUE;
        END IF;
      
        IF PKG_RTL_TELLER_REC.OFS_CCY <> PKG_RTL_TELLER_REC.TXN_CCY THEN
        
          IF PKG_RTL_TELLER_REC.EXCH_RATE IS NULL AND
             PKG_RTL_TELLER_REC.OFS_AMOUNT IS NULL THEN
          
            IF NOT CYPKSS.FN_GETRATE(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                     PKG_RTL_TELLER_REC.TXN_CCY,
                                     PKG_RTL_TELLER_REC.OFS_CCY,
                                     PKG_PROD.RATE_TYPE_PREFERRED
                                     
                                    ,
                                     NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M'),
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     PKG_RTL_TELLER_REC.TRN_DT,
                                     PKG_RTL_TELLER_REC.EXCH_RATE,
                                     L_RATE_FLAG,
                                     P_ERR_CODE) THEN
              RETURN;
            END IF;
          END IF;
        
          IF NOT CYPKS.FN_AMT1_TO_AMT2(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                       PKG_RTL_TELLER_REC.TXN_CCY,
                                       PKG_RTL_TELLER_REC.OFS_CCY
                                       
                                      ,
                                       NVL(PKG_PROD.RATE_TYPE_PREFERRED,
                                           'STANDARD')
                                       
                                      ,
                                       NVL(PKG_PROD.RATE_CODE_PREFERRED, 'M'),
                                       PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                       'Y',
                                       L_TMP_OFS_AMT,
                                       PKG_RTL_TELLER_REC.EXCH_RATE,
                                       P_ERR_CODE) THEN
            DBG('Bombed with amt1_to_amt2 b/w ' || P_ERR_CODE);
            RETURN;
          END IF;
          PKG_RTL_TELLER_REC.OFS_AMOUNT := L_TMP_OFS_AMT;
        END IF;
        DBG('setting');
      
      END IF;
    
      DLPKS_IFACE.G_SETTLE_ACC := PKG_ARC_ROW.COD_TXN_ACCOUNT;
      DLPKS_IFACE.G_SETTLE_BRN := PKG_ARC_ROW.COD_TXN_BRN;
      DLPKS_IFACE.G_SETTLE_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
      IF NVL(DLPKS_IFACE.G_SETTLE_BRN, '*.*') = '*.*' THEN
        DLPKS_IFACE.G_SETTLE_BRN := GLOBAL.CURRENT_BRANCH;
      END IF;
      DBG('ACC~BRN~CCY' || DLPKS_IFACE.G_SETTLE_ACC ||
          DLPKS_IFACE.G_SETTLE_BRN || DLPKS_IFACE.G_SETTLE_CCY);
    
      DBG('pkg_rtl_teller_rec.exch_rate      : ' ||
          PKG_RTL_TELLER_REC.EXCH_RATE);
      DBG('l_rate_flag                       : ' || L_RATE_FLAG);
      DBG('l_tmp_txn_amt                     : ' || L_TMP_TXN_AMT);
      DBG('pkg_sttb_account.cust_no :' || PKG_STTB_ACCOUNT.CUST_NO);
      DBG('pkg_rtl_teller_rec.rel_customer ' ||
          PKG_RTL_TELLER_REC.REL_CUSTOMER);
    
      DBG('checking the values 3 branch code---' ||
          PKG_RTL_TELLER_REC.BRANCH_CODE || '---values for curr brn' ||
          PKG_RTL_TELLER_REC.TXN_BRANCH);
      IF PKG_RTL_TELLER_REC.BRANCH_CODE <> PKG_RTL_TELLER_REC.TXN_BRANCH THEN
        DBG('assigning val yes');
        L_IB_FLAG := 'Y';
      ELSE
        L_IB_FLAG := 'N';
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('Hook Starts');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID := 3;
        L_TB_CLUSTER_DATA('l_ib_flag') := L_IB_FLAG;
        DBG('Gng to call depks_rtl_teller_cluster.Pr_Superscribe_Arc');
        DEPKS_RTL_TELLER_CLUSTER.PR_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                    PKG_RTL_TELLER_REC,
                                                    PKG_PROD.RATE_CODE_PREFERRED,
                                                    L_TB_CLUSTER_DATA,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM);
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed in depks_rtl_teller_cluster.Pr_Superscribe_Arc');
          RETURN;
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_ib_flag') THEN
          L_IB_FLAG := L_TB_CLUSTER_DATA('l_ib_flag');
        END IF;
      
      END IF;
    
      IF PKG_RTL_TELLER_REC.TXN_ACC IS NOT NULL THEN
        DBG('Account Number NOT NULL ');
        L_TXN_AC_NO := PKG_RTL_TELLER_REC.TXN_ACC;
      ELSE
        L_TXN_AC_NO := NULL;
      END IF;
      IF PKG_RTL_TELLER_REC.TXN_BRANCH IS NOT NULL THEN
        DBG('Branch is NOT NULL ');
        L_TXN_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
      END IF;
      DBG('Account Number ' || L_TXN_AC_NO);
      DBG('Branch ' || L_TXN_BRN);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('Going to call cluster');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 2;
        DEPKS_RTL_TELLER_CLUSTER.PR_SUPERSCRIBE_ARC(L_FN_CALL_ID,
                                                    PKG_RTL_TELLER_REC,
                                                    PKG_PROD.RATE_CODE_PREFERRED,
                                                    L_TB_CLUSTER_DATA,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM);
      
        IF P_ERR_CODE IS NOT NULL THEN
          DBG('Failed in epks_rtl_teller_cluster.Pr_Superscribe_Arc');
          RETURN;
        END IF;
      
        DBG('Succesfully returned from depks_rtl_teller_cluster.pr_set_global ');
      END IF;
    
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF NOT CSPKSS_ARC.FN_CHARGE_PICKUP(PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           PKG_RTL_TELLER_REC.PRODUCT_CODE,
                                           'P',
                                           PKG_RTL_TELLER_REC.BRANCH_CODE,
                                           PKG_RTL_TELLER_REC.TXN_CCY,
                                           PKG_RTL_TELLER_REC.REL_CUSTOMER,
                                           PKG_RTL_TELLER_REC.TXN_CCY,
                                           PKG_RTL_TELLER_REC.TXN_AMOUNT,
                                           PKG_PROD.RATE_TYPE_PREFERRED,
                                           PKG_PROD.RATE_CODE_PREFERRED,
                                           NULL
                                           
                                          ,
                                           NVL(PKG_STTB_ACCOUNT.CUST_NO,
                                               PKG_RTL_TELLER_REC.REL_CUSTOMER),
                                           L_IB_FLAG,
                                           PKG_CHG_ROW,
                                           P_ERR_CODE,
                                           P_ERR_PARAM,
                                           L_TXN_AC_NO,
                                           L_TXN_BRN) THEN
          RETURN;
        END IF;
      
      ELSE
        DBG('Resetting skip kernel here');
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
      DBG('#28511384 pkg_rtl_teller_rec.scode ' ||
          PKG_RTL_TELLER_REC.SCODE);
    
      IF PKG_RTL_TELLER_REC.SCODE IN ('FLEXSWITCH', 'FLEXCUBE') THEN
      
        IF GWPKS_UTIL.PKG_CHG_DETS IS NOT NULL THEN
          DBG('The package charge details before change is:' ||
              GWPKS_UTIL.PKG_CHG_DETS);
          DBG('The retail charge details before change is:' ||
              DEPKS_RTL_TELLER.PKG_CHG_DETS);
          DBG('The final arc pickup ccy is:' || PKG_CHG_ROW.COD_CHG_CCY1);
          DBG('The final arc pickup amount is:' ||
              PKG_CHG_ROW.COD_CHG_AMT1);
          DBG('The charge basis 2 from ARC is:' || PKG_CHG_ROW.COD_BASIS1);
          DBG('The charge basis 3 from ARC is:' || PKG_CHG_ROW.COD_BASIS2);
          DBG('The charge basis 4 from ARC is:' || PKG_CHG_ROW.COD_BASIS3);
          DBG('The charge basis 5 from ARC is:' || PKG_CHG_ROW.COD_BASIS4);
          DBG('The package chg details count is:' ||
              LENGTH(GWPKS_UTIL.PKG_CHG_DETS));
          WHILE CHG_DETS_ROW < LENGTH(GWPKS_UTIL.PKG_CHG_DETS) - 1 LOOP
            DBG('ssr with chg count as:' || CHG_DETS_ROW);
            L_TBCHG_CCY := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                   TO_NUMBER(CHG_DETS_ROW),
                                                   '~');
            DBG('The currency set from pkk chg dets is:' || L_TBCHG_CCY);
            IF L_TBCHG_CCY IS NULL THEN
              EXIT;
            ELSE
              TB_CHG(CHG_DETS_ROW).CHG_CCY := L_TBCHG_CCY;
            END IF;
            TB_CHG(CHG_DETS_ROW).CHG_AMT := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_CHG_DETS,
                                                                    TO_NUMBER(CHG_DETS_ROW) + 1,
                                                                    '~');
            DBG('The amount set from pkk chg dets is:' || TB_CHG(CHG_DETS_ROW)
                .CHG_AMT);
            CHG_DETS_ROW := CHG_DETS_ROW + 2;
          END LOOP;
        
          DBG('Outside the for loop of gwpks pkg chg dets intialise');
          IF PKG_CHG_ROW.COD_BASIS1 IS NOT NULL OR
             PKG_CHG_ROW.COD_BASIS2 IS NOT NULL OR
             PKG_CHG_ROW.COD_BASIS3 IS NOT NULL OR
             PKG_CHG_ROW.COD_BASIS4 IS NOT NULL THEN
            GWPKS_UTIL.PKG_CHG_DETS := '';
            GWPKS_UTIL.PKG_CHG_DETS := TB_CHG(1)
                                       .CHG_CCY || '~' || TB_CHG(1).CHG_AMT || '~';
            IF PKG_CHG_ROW.COD_BASIS1 IS NOT NULL THEN
              IF PKG_CHG_ROW.COD_BASIS1 = '1' THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS ||
                                           PKG_CHG_ROW.COD_CHG_CCY1 || '~' ||
                                           PKG_CHG_ROW.COD_CHG_AMT1 || '~';
              ELSE
                IF TB_CHG.EXISTS(3) THEN
                  GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(3)
                                            .CHG_CCY || '~' || TB_CHG(3)
                                            .CHG_AMT || '~';
                END IF;
              END IF;
            ELSE
              IF TB_CHG.EXISTS(3) THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(3)
                                          .CHG_CCY || '~' || TB_CHG(3)
                                          .CHG_AMT || '~';
              END IF;
            END IF;
            IF PKG_CHG_ROW.COD_BASIS2 IS NOT NULL THEN
              IF PKG_CHG_ROW.COD_BASIS2 IN ('1', '2') THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS ||
                                           PKG_CHG_ROW.COD_CHG_CCY2 || '~' ||
                                           PKG_CHG_ROW.COD_CHG_AMT2 || '~';
              ELSE
                IF TB_CHG.EXISTS(5) THEN
                  GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(5)
                                            .CHG_CCY || '~' || TB_CHG(5)
                                            .CHG_AMT || '~';
                END IF;
              END IF;
            ELSE
              IF TB_CHG.EXISTS(5) THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(5)
                                          .CHG_CCY || '~' || TB_CHG(5)
                                          .CHG_AMT || '~';
              END IF;
            END IF;
            IF PKG_CHG_ROW.COD_BASIS3 IS NOT NULL THEN
              IF PKG_CHG_ROW.COD_BASIS3 IN ('1', '2', '3') THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS ||
                                           PKG_CHG_ROW.COD_CHG_CCY3 || '~' ||
                                           PKG_CHG_ROW.COD_CHG_AMT3 || '~';
              ELSE
                IF TB_CHG.EXISTS(7) THEN
                  GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(7)
                                            .CHG_CCY || '~' || TB_CHG(7)
                                            .CHG_AMT || '~';
                END IF;
              END IF;
            ELSE
              IF TB_CHG.EXISTS(7) THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(7)
                                          .CHG_CCY || '~' || TB_CHG(7)
                                          .CHG_AMT || '~';
              END IF;
            END IF;
            IF PKG_CHG_ROW.COD_BASIS4 IS NOT NULL THEN
              IF PKG_CHG_ROW.COD_BASIS4 IN ('1', '2', '3', '4') THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS ||
                                           PKG_CHG_ROW.COD_CHG_CCY4 || '~' ||
                                           PKG_CHG_ROW.COD_CHG_AMT4 || '~';
              ELSE
                IF TB_CHG.EXISTS(9) THEN
                  GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(9)
                                            .CHG_CCY || '~' || TB_CHG(9)
                                            .CHG_AMT || '~';
                END IF;
              END IF;
            ELSE
              IF TB_CHG.EXISTS(9) THEN
                GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || TB_CHG(9)
                                          .CHG_CCY || '~' || TB_CHG(9)
                                          .CHG_AMT || '~';
              END IF;
            END IF;
          
            DEPKS_RTL_TELLER.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS;
          END IF;
        END IF;
      END IF;
    
      DBG('Charge recd ... ' || GWPKS_UTIL.PKG_CHG_DETS);
    
      DBG('After Charge Pickup : gwpks_util.pkg_actType = ' ||
          GWPKS_UTIL.PKG_ACTTYPE);
    
      DBG('After Charge Pickup : gwpks_util.pkg_actType = ' ||
          GWPKS_UTIL.PKG_ACTTYPE);
    
      DBG('If Charge recd ... ' || PKG_CHG_ROW.COD_CHG_AMT);
      DBG('pkg_chg_row.cod_chg_type ... ' || PKG_CHG_ROW.COD_CHG_TYPE);
      PKG_ARC_ROW.COD_CHG_AMT  := PKG_CHG_ROW.COD_CHG_AMT;
      PKG_ARC_ROW.COD_CHG_CCY  := PKG_CHG_ROW.COD_CHG_CCY;
      PKG_ARC_ROW.COD_CHG_AMT1 := PKG_CHG_ROW.COD_CHG_AMT1;
      PKG_ARC_ROW.COD_CHG_CCY1 := PKG_CHG_ROW.COD_CHG_CCY1;
      PKG_ARC_ROW.COD_CHG_AMT2 := PKG_CHG_ROW.COD_CHG_AMT2;
      PKG_ARC_ROW.COD_CHG_CCY2 := PKG_CHG_ROW.COD_CHG_CCY2;
      PKG_ARC_ROW.COD_CHG_AMT3 := PKG_CHG_ROW.COD_CHG_AMT3;
      PKG_ARC_ROW.COD_CHG_CCY3 := PKG_CHG_ROW.COD_CHG_CCY3;
      PKG_ARC_ROW.COD_CHG_AMT4 := PKG_CHG_ROW.COD_CHG_AMT4;
      PKG_ARC_ROW.COD_CHG_CCY4 := PKG_CHG_ROW.COD_CHG_CCY4;
    
      PKG_ARC_ROW.COD_CHG_DESC  := PKG_CHG_ROW.COD_CHG_DESC;
      PKG_ARC_ROW.COD_CHG_DESC1 := PKG_CHG_ROW.COD_CHG_DESC1;
      PKG_ARC_ROW.COD_CHG_DESC2 := PKG_CHG_ROW.COD_CHG_DESC2;
      PKG_ARC_ROW.COD_CHG_DESC3 := PKG_CHG_ROW.COD_CHG_DESC3;
      PKG_ARC_ROW.COD_CHG_DESC4 := PKG_CHG_ROW.COD_CHG_DESC4;
    
      PKG_ARC_ROW.COD_THEIR_CHGS  := PKG_CHG_ROW.COD_THEIR_CHGS;
      PKG_ARC_ROW.COD_THEIR_CHGS1 := PKG_CHG_ROW.COD_THEIR_CHGS1;
      PKG_ARC_ROW.COD_THEIR_CHGS2 := PKG_CHG_ROW.COD_THEIR_CHGS2;
      PKG_ARC_ROW.COD_THEIR_CHGS3 := PKG_CHG_ROW.COD_THEIR_CHGS3;
      PKG_ARC_ROW.COD_THEIR_CHGS4 := PKG_CHG_ROW.COD_THEIR_CHGS4;
    
      PKG_RTL_TELLER_REC.THEIR_CHGS  := PKG_CHG_ROW.COD_THEIR_CHGS;
      PKG_RTL_TELLER_REC.THEIR_CHGS1 := PKG_CHG_ROW.COD_THEIR_CHGS1;
      PKG_RTL_TELLER_REC.THEIR_CHGS2 := PKG_CHG_ROW.COD_THEIR_CHGS2;
      PKG_RTL_TELLER_REC.THEIR_CHGS3 := PKG_CHG_ROW.COD_THEIR_CHGS3;
      PKG_RTL_TELLER_REC.THEIR_CHGS4 := PKG_CHG_ROW.COD_THEIR_CHGS4;
    
      PKG_RTL_TELLER_REC.CHG_AMT   := PKG_CHG_ROW.COD_CHG_AMT;
      PKG_RTL_TELLER_REC.CHG_CCY   := PKG_CHG_ROW.COD_CHG_CCY;
      PKG_RTL_TELLER_REC.CHG_AMT_1 := PKG_CHG_ROW.COD_CHG_AMT1;
      PKG_RTL_TELLER_REC.CHG_CCY_1 := PKG_CHG_ROW.COD_CHG_CCY1;
      PKG_RTL_TELLER_REC.CHG_AMT_2 := PKG_CHG_ROW.COD_CHG_AMT2;
      PKG_RTL_TELLER_REC.CHG_CCY_2 := PKG_CHG_ROW.COD_CHG_CCY2;
      PKG_RTL_TELLER_REC.CHG_AMT_3 := PKG_CHG_ROW.COD_CHG_AMT3;
      PKG_RTL_TELLER_REC.CHG_CCY_3 := PKG_CHG_ROW.COD_CHG_CCY3;
      PKG_RTL_TELLER_REC.CHG_AMT_4 := PKG_CHG_ROW.COD_CHG_AMT4;
      PKG_RTL_TELLER_REC.CHG_CCY_4 := PKG_CHG_ROW.COD_CHG_CCY4;
    
      DBG('Charge Currency found --> ' || PKG_ARC_ROW.COD_CHG_CCY);
      DBG('Charge1 Currency found --> ' || PKG_CHG_ROW.COD_CHG_CCY1);
      DBG('Charge2 Currency found --> ' || PKG_CHG_ROW.COD_CHG_CCY2);
      DBG('Charge3 Currency found --> ' || PKG_CHG_ROW.COD_CHG_CCY3);
      DBG('Charge4 Currency found --> ' || PKG_CHG_ROW.COD_CHG_CCY4);
      DBG('Charge recd ... ' || DEPKSS_RTL_TELLER.PKG_CHG_DETS);
    
      IF (REPLACE(DEPKSS_RTL_TELLER.PKG_CHG_DETS, '~', NULL) IS NOT NULL)
      
       THEN
        DBG('Charge recd are ... ' || GWPKS_UTIL.PKG_CHG_DETS);
        DBG('Charge recd ... ' || DEPKSS_RTL_TELLER.PKG_CHG_DETS);
        WHILE NVL(CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                          I,
                                          '~'),
                  ' ') <> 'EOPL' LOOP
          I := I + 1;
        END LOOP;
        I := I - 1;
        DBG('i IS ' || I);
        IF I > 1 THEN
        
          L_AMT1                    := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                               2,
                                                               '~');
          L_WAIVER                  := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                               1,
                                                               '~');
          PKG_RTL_TELLER_REC.WAIVER := L_WAIVER;
          DBG('l_Waiver AFTER FIRST >1> ' || L_WAIVER);
          IF L_AMT1 IS NOT NULL THEN
            DBG('First Chg IS NOT NULL');
          
            IF L_WAIVER = 'N' AND L_AMT1 = 0.00 THEN
              PKG_ARC_ROW.COD_CHG_AMT := PKG_CHG_ROW.COD_CHG_AMT;
            ELSE
            
              PKG_ARC_ROW.COD_CHG_AMT := L_AMT1;
            END IF;
          
            PKG_ARC_ROW.COD_CHG_CCY := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                               1,
                                                               '~');
          ELSE
          
            DBG('First Chg IS VERY MUCH NULL');
            PKG_ARC_ROW.COD_CHG_AMT := NULL;
            PKG_ARC_ROW.COD_CHG_CCY := NULL;
          END IF;
        END IF;
        IF I > 3 THEN
          L_AMT2                     := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                4,
                                                                '~');
          L_WAIVER                   := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                                8,
                                                                '~');
          PKG_RTL_TELLER_REC.WAIVER1 := L_WAIVER;
          DBG('l_Waiver AFTER FIRST >2> ' || L_WAIVER);
        
          IF L_AMT2 IS NOT NULL OR PKG_CHG_ROW.COD_CHG_AMT1 IS NOT NULL THEN
            DBG('Second Chg IS NOT NULL');
          
            IF L_AMT2 IS NULL THEN
              L_AMT2 := PKG_CHG_ROW.COD_CHG_AMT1;
            END IF;
          
            IF L_WAIVER = 'N' AND L_AMT2 = 0.00 THEN
              PKG_ARC_ROW.COD_CHG_AMT1 := PKG_CHG_ROW.COD_CHG_AMT1;
            ELSE
            
              PKG_ARC_ROW.COD_CHG_AMT1 := L_AMT2;
            END IF;
          
            PKG_ARC_ROW.COD_CHG_CCY1 := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                3,
                                                                '~');
          ELSE
          
            DBG('Second Chg IS VERY MUCH NULL');
            PKG_ARC_ROW.COD_CHG_AMT1 := NULL;
            PKG_ARC_ROW.COD_CHG_CCY1 := NULL;
          END IF;
        END IF;
        IF I > 5 THEN
          L_AMT3                     := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                6,
                                                                '~');
          L_WAIVER                   := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                                15,
                                                                '~');
          PKG_RTL_TELLER_REC.WAIVER2 := L_WAIVER;
          DBG('l_Waiver AFTER FIRST >3> ' || L_WAIVER);
          IF L_AMT3 IS NOT NULL THEN
            DBG('Third Chg IS NOT NULL');
          
            IF L_WAIVER = 'N' AND L_AMT3 = 0.00 THEN
              PKG_ARC_ROW.COD_CHG_AMT2 := PKG_CHG_ROW.COD_CHG_AMT2;
            ELSE
            
              PKG_ARC_ROW.COD_CHG_AMT2 := L_AMT3;
            END IF;
          
            PKG_ARC_ROW.COD_CHG_CCY2 := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                5,
                                                                '~');
          ELSE
          
            DBG('Third Chg IS VERY MUCH NULL');
            PKG_ARC_ROW.COD_CHG_AMT2 := NULL;
            PKG_ARC_ROW.COD_CHG_CCY2 := NULL;
          END IF;
        END IF;
        IF I > 7 THEN
          L_AMT4                     := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                8,
                                                                '~');
          L_WAIVER                   := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                                22,
                                                                '~');
          PKG_RTL_TELLER_REC.WAIVER3 := L_WAIVER;
          DBG('l_Waiver AFTER FIRST >4> ' || L_WAIVER);
          IF L_AMT4 IS NOT NULL THEN
            DBG('Fourth Chg IS NOT NULL');
          
            IF L_WAIVER = 'N' AND L_AMT4 = 0.00 THEN
              PKG_ARC_ROW.COD_CHG_AMT3 := PKG_CHG_ROW.COD_CHG_AMT3;
            ELSE
            
              PKG_ARC_ROW.COD_CHG_AMT3 := L_AMT4;
            END IF;
          
            PKG_ARC_ROW.COD_CHG_CCY3 := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                7,
                                                                '~');
          ELSE
          
            DBG('Fourth Chg IS VERY MUCH NULL');
            PKG_ARC_ROW.COD_CHG_AMT3 := NULL;
            PKG_ARC_ROW.COD_CHG_CCY3 := NULL;
          END IF;
        END IF;
        IF I > 9 THEN
          L_AMT5                     := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                10,
                                                                '~');
          L_WAIVER                   := CSPKES_MISC.FN_GETPARAM(GWPKS_UTIL.PKG_TEMP_CHG_DETS,
                                                                29,
                                                                '~');
          PKG_RTL_TELLER_REC.WAIVER4 := L_WAIVER;
          DBG('l_Waiver AFTER FIRST >5> ' || L_WAIVER);
          IF L_AMT5 IS NOT NULL THEN
            DBG('Fifth Chg IS NOT NULL');
          
            IF L_WAIVER = 'N' AND L_AMT5 = 0.00 THEN
              PKG_ARC_ROW.COD_CHG_AMT4 := PKG_CHG_ROW.COD_CHG_AMT4;
            ELSE
            
              PKG_ARC_ROW.COD_CHG_AMT4 := L_AMT5;
            END IF;
          
            PKG_ARC_ROW.COD_CHG_CCY4 := CSPKES_MISC.FN_GETPARAM(DEPKSS_RTL_TELLER.PKG_CHG_DETS,
                                                                9,
                                                                '~');
          ELSE
          
            DBG('Fifth Chg IS VERY MUCH NULL');
            PKG_ARC_ROW.COD_CHG_AMT4 := NULL;
            PKG_ARC_ROW.COD_CHG_CCY4 := NULL;
          END IF;
        END IF;
      
      END IF;
    
      IF DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE = 'Y' THEN
        DBG('In pr_superscribe_arc setting depkss_rtl_teller.pkg_chg_dets and gwpks_util.pkg_chg_dets to null');
        DBG('depkss_rtl_teller.pkg_chg_dets before setting to null :: ' ||
            DEPKSS_RTL_TELLER.PKG_CHG_DETS);
        DBG('gwpks_util.pkg_chg_dets before setting to null :: ' ||
            GWPKS_UTIL.PKG_CHG_DETS);
        DEPKSS_RTL_TELLER.PKG_CHG_DETS := NULL;
        GWPKS_UTIL.PKG_CHG_DETS        := NULL;
      END IF;
    
      DBG('Charge Currency found here--> ' || PKG_ARC_ROW.COD_CHG_CCY);
      DBG('Charge1 Currency found here--> ' || PKG_CHG_ROW.COD_CHG_CCY1);
      DBG('Charge2 Currency found here--> ' || PKG_CHG_ROW.COD_CHG_CCY2);
      DBG('Charge3 Currency found here--> ' || PKG_CHG_ROW.COD_CHG_CCY3);
      DBG('Charge4 Currency found here--> ' || PKG_CHG_ROW.COD_CHG_CCY4);
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
  END PR_SUPERSCRIBE_ARC;

  FUNCTION FN_IS_GL(P_BRN IN VARCHAR2,
                    P_ACC IN VARCHAR2,
                    P_CCY OUT VARCHAR2) RETURN BOOLEAN IS
    L_GL STTBS_ACCOUNT.AC_OR_GL%TYPE;
  BEGIN
    IF NOT CVPKS_UTILS.GET_STTB_ACC(P_BRN, P_ACC, PKG_STTB_ACCOUNT) THEN
      RETURN FALSE;
    END IF;
    IF PKG_STTB_ACCOUNT.AC_OR_GL = 'G' THEN
      RETURN TRUE;
    ELSE
      P_CCY := PKG_STTB_ACCOUNT.AC_GL_CCY;
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FROM fn IS gl ' || SQLERRM);
      DBG('Err FOR ' || P_BRN || ' ' || P_ACC);
      P_CCY := NULL;
      RETURN FALSE;
  END FN_IS_GL;

  PROCEDURE PR_UPDATE_REC IS
  
    L_TB_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID      NUMBER;
    L_COUNT           NUMBER;
  
  BEGIN
  
    BEGIN
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        DBG('Ready to call depks_rtl_teller_cluster.pr_update_rec with trn ref noas:' ||
            PKG_RTL_TELLER_REC.TRN_REF_NO);
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA('trn_ref_no') := PKG_RTL_TELLER_REC.TRN_REF_NO;
        DEPKS_RTL_TELLER_CLUSTER.PR_UPDATE_REC(L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('The depks_rtl_teller_cluster.pr_update_rec has failed');
    END;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('Kernel code is continued');
    
      IF PKG_RTL_TELLER_REC.MAKER_ID IS NULL THEN
        DBG('----------Came here when maker id is null------------');
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('Inside branch transaction');
          DBG('global.user_id ::::: ' || GLOBAL.USER_ID);
          DBG('stpks_account_close.pkg_user_id :::: ' ||
              STPKS_ACCOUNT_CLOSE.PKG_USER_ID);
        
          PKG_RTL_TELLER_REC.MAKER_ID := NVL(STPKS_ACCOUNT_CLOSE.PKG_USER_ID,
                                             GLOBAL.USER_ID);
        ELSE
        
          PKG_RTL_TELLER_REC.MAKER_ID := NVL(GWPKS_UTIL.G_MAKERID, 'SYSTEM');
        
        END IF;
      END IF;
      IF PKG_RTL_TELLER_REC.CHECKER_ID IS NULL THEN
        IF PKG_RTL_TELLER_REC.AUTH_STAT = 'A' THEN
          IF GWPKS_UTIL.G_FROM_BEAN THEN
          
            PKG_RTL_TELLER_REC.CHECKER_ID := NVL(GWPKS_UTIL.G_CHECKERID,
                                                 GLOBAL.USER_ID);
          ELSE
            PKG_RTL_TELLER_REC.CHECKER_ID := 'SYSTEM';
          END IF;
        END IF;
      END IF;
    
      IF PKG_RTL_TELLER_REC.EXCH_RATE IS NULL THEN
        PKG_RTL_TELLER_REC.EXCH_RATE := 1;
      END IF;
    
      IF PKG_RTL_TELLER_REC.LIQN_DT IS NULL THEN
        PKG_RTL_TELLER_REC.LIQN_DT := GLOBAL.APPLICATION_DATE;
      END IF;
    
      DBG('The lcy exchange rate is to be updated with value as:' ||
          PKG_RTL_TELLER_REC.LCY_EXCH_RATE);
    
      IF NVL(PKG_RTL_TELLER_REC.PRODUCT_CODE, '***') IN ('TTIN') THEN
        DBG('pkg_rtl_teller_rec.Product_Code is:' ||
            PKG_RTL_TELLER_REC.PRODUCT_CODE);
      
        TEMP_RTL_TELLER_REC.CHG_AMT           := PKG_RTL_TELLER_REC.CHG_AMT;
        TEMP_RTL_TELLER_REC.CHG_CCY           := PKG_RTL_TELLER_REC.CHG_CCY;
        TEMP_RTL_TELLER_REC.MIS_HEAD_1        := PKG_RTL_TELLER_REC.MIS_HEAD_1;
        TEMP_RTL_TELLER_REC.TXN_CODE          := PKG_RTL_TELLER_REC.TXN_CODE;
        TEMP_RTL_TELLER_REC.NETTING_IND       := PKG_RTL_TELLER_REC.NETTING_IND;
        TEMP_RTL_TELLER_REC.CHG_GL            := PKG_RTL_TELLER_REC.CHG_GL;
        TEMP_RTL_TELLER_REC.CHG_DESC          := PKG_RTL_TELLER_REC.CHG_DESC;
        TEMP_RTL_TELLER_REC.CHG_IN_LCY        := PKG_RTL_TELLER_REC.CHG_IN_LCY;
        TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE := PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE;
        TEMP_RTL_TELLER_REC.CHG_IN_ACY        := PKG_RTL_TELLER_REC.CHG_IN_ACY;
        TEMP_RTL_TELLER_REC.WAIVER            := PKG_RTL_TELLER_REC.WAIVER;
        TEMP_RTL_TELLER_REC.CHG_TYPE          := PKG_RTL_TELLER_REC.CHG_TYPE;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE  := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE;
        TEMP_RTL_TELLER_REC.ACY_LCY_RATE      := PKG_RTL_TELLER_REC.ACY_LCY_RATE;
      
        TEMP_RTL_TELLER_REC.CHG_AMT_1          := PKG_RTL_TELLER_REC.CHG_AMT_1;
        TEMP_RTL_TELLER_REC.CHG_CCY_1          := PKG_RTL_TELLER_REC.CHG_CCY_1;
        TEMP_RTL_TELLER_REC.MIS_HEAD_2         := PKG_RTL_TELLER_REC.MIS_HEAD_2;
        TEMP_RTL_TELLER_REC.TXN_CODE_1         := PKG_RTL_TELLER_REC.TXN_CODE_1;
        TEMP_RTL_TELLER_REC.NETTING_IND_1      := PKG_RTL_TELLER_REC.NETTING_IND_1;
        TEMP_RTL_TELLER_REC.CHG_GL_1           := PKG_RTL_TELLER_REC.CHG_GL_1;
        TEMP_RTL_TELLER_REC.CHG_DESC1          := PKG_RTL_TELLER_REC.CHG_DESC1;
        TEMP_RTL_TELLER_REC.CHG_IN_LCY_1       := PKG_RTL_TELLER_REC.CHG_IN_LCY_1;
        TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1 := PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1;
        TEMP_RTL_TELLER_REC.CHG_IN_ACY_1       := PKG_RTL_TELLER_REC.CHG_IN_ACY_1;
        TEMP_RTL_TELLER_REC.WAIVER1            := PKG_RTL_TELLER_REC.WAIVER1;
        TEMP_RTL_TELLER_REC.CHG_TYPE1          := PKG_RTL_TELLER_REC.CHG_TYPE1;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_1 := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_1;
        TEMP_RTL_TELLER_REC.ACY_LCY_RATE_1     := PKG_RTL_TELLER_REC.ACY_LCY_RATE_1;
      
        TEMP_RTL_TELLER_REC.CHG_AMT_2          := PKG_RTL_TELLER_REC.CHG_AMT_2;
        TEMP_RTL_TELLER_REC.CHG_CCY_2          := PKG_RTL_TELLER_REC.CHG_CCY_2;
        TEMP_RTL_TELLER_REC.MIS_HEAD_3         := PKG_RTL_TELLER_REC.MIS_HEAD_3;
        TEMP_RTL_TELLER_REC.TXN_CODE_2         := PKG_RTL_TELLER_REC.TXN_CODE_2;
        TEMP_RTL_TELLER_REC.NETTING_IND_2      := PKG_RTL_TELLER_REC.NETTING_IND_2;
        TEMP_RTL_TELLER_REC.CHG_GL_2           := PKG_RTL_TELLER_REC.CHG_GL_2;
        TEMP_RTL_TELLER_REC.CHG_DESC2          := PKG_RTL_TELLER_REC.CHG_DESC2;
        TEMP_RTL_TELLER_REC.CHG_IN_LCY_2       := PKG_RTL_TELLER_REC.CHG_IN_LCY_2;
        TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2 := PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2;
        TEMP_RTL_TELLER_REC.CHG_IN_ACY_2       := PKG_RTL_TELLER_REC.CHG_IN_ACY_2;
        TEMP_RTL_TELLER_REC.WAIVER2            := PKG_RTL_TELLER_REC.WAIVER2;
        TEMP_RTL_TELLER_REC.CHG_TYPE2          := PKG_RTL_TELLER_REC.CHG_TYPE2;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_2 := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_2;
        TEMP_RTL_TELLER_REC.ACY_LCY_RATE_2     := PKG_RTL_TELLER_REC.ACY_LCY_RATE_2;
      
        TEMP_RTL_TELLER_REC.CHG_AMT_3          := PKG_RTL_TELLER_REC.CHG_AMT_3;
        TEMP_RTL_TELLER_REC.CHG_CCY_3          := PKG_RTL_TELLER_REC.CHG_CCY_3;
        TEMP_RTL_TELLER_REC.MIS_HEAD_4         := PKG_RTL_TELLER_REC.MIS_HEAD_4;
        TEMP_RTL_TELLER_REC.TXN_CODE_3         := PKG_RTL_TELLER_REC.TXN_CODE_3;
        TEMP_RTL_TELLER_REC.NETTING_IND_3      := PKG_RTL_TELLER_REC.NETTING_IND_3;
        TEMP_RTL_TELLER_REC.CHG_GL_3           := PKG_RTL_TELLER_REC.CHG_GL_3;
        TEMP_RTL_TELLER_REC.CHG_DESC3          := PKG_RTL_TELLER_REC.CHG_DESC3;
        TEMP_RTL_TELLER_REC.CHG_IN_LCY_3       := PKG_RTL_TELLER_REC.CHG_IN_LCY_3;
        TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3 := PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3;
        TEMP_RTL_TELLER_REC.CHG_IN_ACY_3       := PKG_RTL_TELLER_REC.CHG_IN_ACY_3;
        TEMP_RTL_TELLER_REC.WAIVER3            := PKG_RTL_TELLER_REC.WAIVER3;
        TEMP_RTL_TELLER_REC.CHG_TYPE3          := PKG_RTL_TELLER_REC.CHG_TYPE3;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3 := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3 := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3;
      
        TEMP_RTL_TELLER_REC.CHG_AMT_4          := PKG_RTL_TELLER_REC.CHG_AMT_4;
        TEMP_RTL_TELLER_REC.CHG_CCY_4          := PKG_RTL_TELLER_REC.CHG_CCY_4;
        TEMP_RTL_TELLER_REC.MIS_HEAD_5         := PKG_RTL_TELLER_REC.MIS_HEAD_5;
        TEMP_RTL_TELLER_REC.TXN_CODE_4         := PKG_RTL_TELLER_REC.TXN_CODE_4;
        TEMP_RTL_TELLER_REC.NETTING_IND_4      := PKG_RTL_TELLER_REC.NETTING_IND_4;
        TEMP_RTL_TELLER_REC.CHG_GL_4           := PKG_RTL_TELLER_REC.CHG_GL_4;
        TEMP_RTL_TELLER_REC.CHG_DESC4          := PKG_RTL_TELLER_REC.CHG_DESC4;
        TEMP_RTL_TELLER_REC.CHG_IN_LCY_4       := PKG_RTL_TELLER_REC.CHG_IN_LCY_4;
        TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4 := PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4;
        TEMP_RTL_TELLER_REC.CHG_IN_ACY_4       := PKG_RTL_TELLER_REC.CHG_IN_ACY_4;
        TEMP_RTL_TELLER_REC.WAIVER4            := PKG_RTL_TELLER_REC.WAIVER4;
        TEMP_RTL_TELLER_REC.CHG_TYPE4          := PKG_RTL_TELLER_REC.CHG_TYPE4;
        TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_4 := PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_4;
        TEMP_RTL_TELLER_REC.ACY_LCY_RATE_4     := PKG_RTL_TELLER_REC.ACY_LCY_RATE_4;
      
        TEMP_RTL_TELLER_REC.TOT_CHG_IN_TCY := PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY;
      END IF;
    
      UPDATE DETBS_RTL_TELLER
         SET TRN_REF_NO     = PKG_RTL_TELLER_REC.TRN_REF_NO,
             TXN_ACC        = PKG_RTL_TELLER_REC.TXN_ACC,
             TXN_CCY        = PKG_RTL_TELLER_REC.TXN_CCY,
             TXN_BRANCH     = PKG_RTL_TELLER_REC.TXN_BRANCH,
             TXN_TRN_CODE   = PKG_RTL_TELLER_REC.TXN_TRN_CODE,
             CHARGE_ACCOUNT = PKG_RTL_TELLER_REC.CHARGE_ACCOUNT
             
            ,
             OFS_ACC      = PKG_RTL_TELLER_REC.OFS_ACC,
             OFS_CCY      = PKG_RTL_TELLER_REC.OFS_CCY,
             OFS_BRANCH   = PKG_RTL_TELLER_REC.OFS_BRANCH,
             OFS_TRN_CODE = PKG_RTL_TELLER_REC.OFS_TRN_CODE,
             EXCH_RATE    = PKG_RTL_TELLER_REC.EXCH_RATE,
             LCY_AMOUNT   = PKG_RTL_TELLER_REC.LCY_AMOUNT,
             REL_CUSTOMER = PKG_RTL_TELLER_REC.REL_CUSTOMER,
             
             CHG_GL             = NVL(TEMP_RTL_TELLER_REC.CHG_GL,
                                      PKG_RTL_TELLER_REC.CHG_GL),
             CHG_CCY            = NVL(TEMP_RTL_TELLER_REC.CHG_CCY,
                                      PKG_RTL_TELLER_REC.CHG_CCY),
             CHG_AMT            = NVL(TEMP_RTL_TELLER_REC.CHG_AMT,
                                      PKG_RTL_TELLER_REC.CHG_AMT),
             CHG_IN_ACY         = NVL(TEMP_RTL_TELLER_REC.CHG_IN_ACY,
                                      PKG_RTL_TELLER_REC.CHG_IN_ACY),
             CHG_IN_LCY         = NVL(TEMP_RTL_TELLER_REC.CHG_IN_LCY,
                                      PKG_RTL_TELLER_REC.CHG_IN_LCY),
             CHG_CCY_ACY_RATE   = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE,
                                      PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE),
             ACY_LCY_RATE       = NVL(TEMP_RTL_TELLER_REC.ACY_LCY_RATE,
                                      PKG_RTL_TELLER_REC.ACY_LCY_RATE),
             NETTING_IND        = NVL(TEMP_RTL_TELLER_REC.NETTING_IND,
                                      PKG_RTL_TELLER_REC.NETTING_IND),
             TXN_CODE           = NVL(TEMP_RTL_TELLER_REC.TXN_CODE,
                                      PKG_RTL_TELLER_REC.TXN_CODE),
             MIS_HEAD_1         = NVL(TEMP_RTL_TELLER_REC.MIS_HEAD_1,
                                      PKG_RTL_TELLER_REC.MIS_HEAD_1),
             CHG_GL_1           = NVL(TEMP_RTL_TELLER_REC.CHG_GL_1,
                                      PKG_RTL_TELLER_REC.CHG_GL_1),
             CHG_CCY_1          = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_1,
                                      PKG_RTL_TELLER_REC.CHG_CCY_1),
             CHG_AMT_1          = NVL(TEMP_RTL_TELLER_REC.CHG_AMT_1,
                                      PKG_RTL_TELLER_REC.CHG_AMT_1),
             CHG_IN_ACY_1       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_ACY_1,
                                      PKG_RTL_TELLER_REC.CHG_IN_ACY_1),
             CHG_IN_LCY_1       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_LCY_1,
                                      PKG_RTL_TELLER_REC.CHG_IN_LCY_1),
             CHG_CCY_ACY_RATE_1 = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_1,
                                      PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_1),
             ACY_LCY_RATE_1     = NVL(TEMP_RTL_TELLER_REC.ACY_LCY_RATE_1,
                                      PKG_RTL_TELLER_REC.ACY_LCY_RATE_1),
             NETTING_IND_1      = NVL(TEMP_RTL_TELLER_REC.NETTING_IND_1,
                                      PKG_RTL_TELLER_REC.NETTING_IND_1),
             TXN_CODE_1         = NVL(TEMP_RTL_TELLER_REC.TXN_CODE_1,
                                      PKG_RTL_TELLER_REC.TXN_CODE_1),
             MIS_HEAD_2         = NVL(TEMP_RTL_TELLER_REC.MIS_HEAD_2,
                                      PKG_RTL_TELLER_REC.MIS_HEAD_2),
             CHG_GL_2           = NVL(TEMP_RTL_TELLER_REC.CHG_GL_2,
                                      PKG_RTL_TELLER_REC.CHG_GL_2),
             CHG_CCY_2          = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_2,
                                      PKG_RTL_TELLER_REC.CHG_CCY_2),
             CHG_AMT_2          = NVL(TEMP_RTL_TELLER_REC.CHG_AMT_2,
                                      PKG_RTL_TELLER_REC.CHG_AMT_2),
             CHG_IN_ACY_2       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_ACY_2,
                                      PKG_RTL_TELLER_REC.CHG_IN_ACY_2),
             CHG_IN_LCY_2       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_LCY_2,
                                      PKG_RTL_TELLER_REC.CHG_IN_LCY_2),
             CHG_CCY_ACY_RATE_2 = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_2,
                                      PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_2),
             ACY_LCY_RATE_2     = NVL(TEMP_RTL_TELLER_REC.ACY_LCY_RATE_2,
                                      PKG_RTL_TELLER_REC.ACY_LCY_RATE_2),
             NETTING_IND_2      = NVL(TEMP_RTL_TELLER_REC.NETTING_IND_2,
                                      PKG_RTL_TELLER_REC.NETTING_IND_2),
             TXN_CODE_2         = NVL(TEMP_RTL_TELLER_REC.TXN_CODE_2,
                                      PKG_RTL_TELLER_REC.TXN_CODE_2),
             MIS_HEAD_3         = NVL(TEMP_RTL_TELLER_REC.MIS_HEAD_3,
                                      PKG_RTL_TELLER_REC.MIS_HEAD_3),
             CHG_GL_3           = NVL(TEMP_RTL_TELLER_REC.CHG_GL_3,
                                      PKG_RTL_TELLER_REC.CHG_GL_3),
             CHG_CCY_3          = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_3,
                                      PKG_RTL_TELLER_REC.CHG_CCY_3),
             CHG_AMT_3          = NVL(TEMP_RTL_TELLER_REC.CHG_AMT_3,
                                      PKG_RTL_TELLER_REC.CHG_AMT_3),
             CHG_IN_ACY_3       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_ACY_3,
                                      PKG_RTL_TELLER_REC.CHG_IN_ACY_3),
             CHG_IN_LCY_3       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_LCY_3,
                                      PKG_RTL_TELLER_REC.CHG_IN_LCY_3),
             CHG_CCY_ACY_RATE_3 = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3,
                                      PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_3),
             ACY_LCY_RATE_3     = NVL(TEMP_RTL_TELLER_REC.ACY_LCY_RATE_3,
                                      PKG_RTL_TELLER_REC.ACY_LCY_RATE_3),
             NETTING_IND_3      = NVL(TEMP_RTL_TELLER_REC.NETTING_IND_3,
                                      PKG_RTL_TELLER_REC.NETTING_IND_3),
             TXN_CODE_3         = NVL(TEMP_RTL_TELLER_REC.TXN_CODE_3,
                                      PKG_RTL_TELLER_REC.TXN_CODE_3),
             MIS_HEAD_4         = NVL(TEMP_RTL_TELLER_REC.MIS_HEAD_4,
                                      PKG_RTL_TELLER_REC.MIS_HEAD_4),
             CHG_GL_4           = NVL(TEMP_RTL_TELLER_REC.CHG_GL,
                                      PKG_RTL_TELLER_REC.CHG_GL_4),
             CHG_CCY_4          = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_4,
                                      PKG_RTL_TELLER_REC.CHG_CCY_4),
             CHG_AMT_4          = NVL(TEMP_RTL_TELLER_REC.CHG_AMT_4,
                                      PKG_RTL_TELLER_REC.CHG_AMT_4),
             CHG_IN_ACY_4       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_ACY_4,
                                      PKG_RTL_TELLER_REC.CHG_IN_ACY_4),
             CHG_IN_LCY_4       = NVL(TEMP_RTL_TELLER_REC.CHG_IN_LCY_4,
                                      PKG_RTL_TELLER_REC.CHG_IN_LCY_4),
             CHG_CCY_ACY_RATE_4 = NVL(TEMP_RTL_TELLER_REC.CHG_CCY_ACY_RATE_4,
                                      PKG_RTL_TELLER_REC.CHG_CCY_ACY_RATE_4),
             ACY_LCY_RATE_4     = NVL(TEMP_RTL_TELLER_REC.ACY_LCY_RATE_4,
                                      PKG_RTL_TELLER_REC.ACY_LCY_RATE_4),
             NETTING_IND_4      = NVL(TEMP_RTL_TELLER_REC.NETTING_IND_4,
                                      PKG_RTL_TELLER_REC.NETTING_IND_4),
             TXN_CODE_4         = NVL(TEMP_RTL_TELLER_REC.TXN_CODE_4,
                                      PKG_RTL_TELLER_REC.TXN_CODE_4),
             MIS_HEAD_5         = NVL(TEMP_RTL_TELLER_REC.MIS_HEAD_5,
                                      PKG_RTL_TELLER_REC.MIS_HEAD_5),
             
             REM_ACC          = PKG_RTL_TELLER_REC.REM_ACC,
             REM_BANK         = PKG_RTL_TELLER_REC.REM_BANK,
             REM_BRANCH       = PKG_RTL_TELLER_REC.REM_BRANCH,
             ROUTING_NO       = PKG_RTL_TELLER_REC.ROUTING_NO,
             END_POINT        = PKG_RTL_TELLER_REC.END_POINT,
             SERIAL_NO        = PKG_RTL_TELLER_REC.SERIAL_NO,
             RECORD_STAT      = PKG_RTL_TELLER_REC.RECORD_STAT,
             AUTH_STAT        = PKG_RTL_TELLER_REC.AUTH_STAT,
             MAKER_ID         = PKG_RTL_TELLER_REC.MAKER_ID,
             CHECKER_ID       = PKG_RTL_TELLER_REC.CHECKER_ID,
             MAKER_DT_STAMP   = PKG_RTL_TELLER_REC.MAKER_DT_STAMP,
             CHECKER_DT_STAMP = PKG_RTL_TELLER_REC.CHECKER_DT_STAMP,
             MIS_HEAD         = PKG_RTL_TELLER_REC.MIS_HEAD,
             DR_ACC           = PKG_RTL_TELLER_REC.DR_ACC,
             VALUE_DT         = PKG_RTL_TELLER_REC.VALUE_DT
             
            ,
             THEIR_CHGS  = PKG_RTL_TELLER_REC.THEIR_CHGS,
             THEIR_CHGS1 = PKG_RTL_TELLER_REC.THEIR_CHGS1,
             THEIR_CHGS2 = PKG_RTL_TELLER_REC.THEIR_CHGS2,
             THEIR_CHGS3 = PKG_RTL_TELLER_REC.THEIR_CHGS3,
             THEIR_CHGS4 = PKG_RTL_TELLER_REC.THEIR_CHGS4,
             
             TOT_CHG_IN_TCY = PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY,
             
             FUND_ID     = PKG_RTL_TELLER_REC.FUND_ID,
             FUND_REF_NO = PKG_RTL_TELLER_REC.FUND_REF_NO,
             
             CHG_DESC           = NVL(TEMP_RTL_TELLER_REC.CHG_DESC,
                                      PKG_ARC_ROW.COD_CHG_DESC),
             CHG_DESC1          = NVL(TEMP_RTL_TELLER_REC.CHG_DESC1,
                                      PKG_ARC_ROW.COD_CHG_DESC1),
             CHG_DESC2          = NVL(TEMP_RTL_TELLER_REC.CHG_DESC2,
                                      PKG_ARC_ROW.COD_CHG_DESC2),
             CHG_DESC3          = NVL(TEMP_RTL_TELLER_REC.CHG_DESC3,
                                      PKG_ARC_ROW.COD_CHG_DESC3),
             CHG_DESC4          = NVL(TEMP_RTL_TELLER_REC.CHG_DESC4,
                                      PKG_ARC_ROW.COD_CHG_DESC4),
             CHG_TYPE           = NVL(TEMP_RTL_TELLER_REC.CHG_TYPE,
                                      PKG_ARC_ROW.COD_CHG_TYPE),
             CHG_TYPE1          = NVL(TEMP_RTL_TELLER_REC.CHG_TYPE1,
                                      PKG_ARC_ROW.COD_CHG_TYPE1),
             CHG_TYPE2          = NVL(TEMP_RTL_TELLER_REC.CHG_TYPE2,
                                      PKG_ARC_ROW.COD_CHG_TYPE2),
             CHG_TYPE3          = NVL(TEMP_RTL_TELLER_REC.CHG_TYPE3,
                                      PKG_ARC_ROW.COD_CHG_TYPE3),
             CHG_TYPE4          = NVL(TEMP_RTL_TELLER_REC.CHG_TYPE4,
                                      PKG_ARC_ROW.COD_CHG_TYPE4),
             LCY_CHG_EXCH_RATE  = NVL(TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE,
                                      PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE),
             LCY_CHG_EXCH_RATE1 = NVL(TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1,
                                      PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE1),
             LCY_CHG_EXCH_RATE2 = NVL(TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2,
                                      PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE2),
             LCY_CHG_EXCH_RATE3 = NVL(TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3,
                                      PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE3),
             LCY_CHG_EXCH_RATE4 = NVL(TEMP_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4,
                                      PKG_RTL_TELLER_REC.LCY_CHG_EXCH_RATE4),
             WAIVER             = NVL(TEMP_RTL_TELLER_REC.WAIVER,
                                      PKG_RTL_TELLER_REC.WAIVER),
             WAIVER1            = NVL(TEMP_RTL_TELLER_REC.WAIVER1,
                                      PKG_RTL_TELLER_REC.WAIVER1),
             WAIVER2            = NVL(TEMP_RTL_TELLER_REC.WAIVER2,
                                      PKG_RTL_TELLER_REC.WAIVER2),
             WAIVER3            = NVL(TEMP_RTL_TELLER_REC.WAIVER3,
                                      PKG_RTL_TELLER_REC.WAIVER3),
             WAIVER4            = NVL(TEMP_RTL_TELLER_REC.WAIVER4,
                                      PKG_RTL_TELLER_REC.WAIVER4),
             
             TXN_AMOUNT     = PKG_RTL_TELLER_REC.TXN_AMOUNT,
             OFS_AMOUNT     = PKG_RTL_TELLER_REC.OFS_AMOUNT,
             TXN_TANKED     = PKG_RTL_TELLER_REC.TXN_TANKED,
             CHG_CONTRA_LEG = PKG_RTL_TELLER_REC.CHG_CONTRA_LEG
             
            ,
             LIQN_DT          = PKG_RTL_TELLER_REC.LIQN_DT,
             TRACK_RECEIVABLE = PKG_RTL_TELLER_REC.TRACK_RECEIVABLE,
             LCY_EXCH_RATE    = PKG_RTL_TELLER_REC.LCY_EXCH_RATE
             
            ,
             ORG_EXCH_RATE = PKG_RTL_TELLER_REC.ORG_EXCH_RATE,
             ORG_AMOUNT    = PKG_RTL_TELLER_REC.ORG_AMOUNT,
             VIR_ACC_NO    = PKG_RTL_TELLER_REC.VIR_ACC_NO,
             TOKEN_NO      = PKG_RTL_TELLER_REC.TOKEN_NO
             
            ,
             CHG_DR_LEG   = DECODE(NVL(PKG_ARC_ROW.CHG_DR_LEG, '###'),
                                   'TXN_ACC',
                                   NULL,
                                   'OFS_ACC',
                                   NULL,
                                   '###',
                                   NULL,
                                   'GLS'),
             CHG_DR_LEG_1 = DECODE(NVL(PKG_ARC_ROW.CHG_DR_LEG_1, '###'),
                                   'TXN_ACC',
                                   NULL,
                                   'OFS_ACC',
                                   NULL,
                                   '###',
                                   NULL,
                                   'GLS'),
             CHG_DR_LEG_2 = DECODE(NVL(PKG_ARC_ROW.CHG_DR_LEG_2, '###'),
                                   'TXN_ACC',
                                   NULL,
                                   'OFS_ACC',
                                   NULL,
                                   '###',
                                   NULL,
                                   'GLS'),
             CHG_DR_LEG_3 = DECODE(NVL(PKG_ARC_ROW.CHG_DR_LEG_3, '###'),
                                   'TXN_ACC',
                                   NULL,
                                   'OFS_ACC',
                                   NULL,
                                   '###',
                                   NULL,
                                   'GLS'),
             CHG_DR_LEG_4 = DECODE(NVL(PKG_ARC_ROW.CHG_DR_LEG_4, '###'),
                                   'TXN_ACC',
                                   NULL,
                                   'OFS_ACC',
                                   NULL,
                                   '###',
                                   NULL,
                                   'GLS')
      
       WHERE TRN_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
    
      IF SQL%ROWCOUNT = 0
      
       THEN
      
        DBG('Inserting into detbs_rtl_teller');
      
        INSERT INTO DETBS_RTL_TELLER
        
        VALUES PKG_RTL_TELLER_REC;
      
      END IF;
    
      IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
      
        DBG('Here all the amounts were before dedudcting the charges..so updating latest values');
        DBG('txn_amount ~ ofs_amount:' || PKG_RTL_TELLER_REC.TXN_AMOUNT || '~' ||
            PKG_RTL_TELLER_REC.OFS_AMOUNT);
      
        DBG('exch_rate : ' || PKG_RTL_TELLER_REC.EXCH_RATE);
        DBG('xref : ' || PKG_RTL_TELLER_REC.XREF);
        DBG('ofs_ccy : ' || PKG_RTL_TELLER_REC.OFS_CCY);
        DBG('ofs_amount : ' || PKG_RTL_TELLER_REC.OFS_AMOUNT);
        IF NVL(GWPKS_UTIL.PKG_FUNC, '$') = '1300' THEN
          DBG('inserting values for screen : ' || GWPKS_UTIL.PKG_FUNC);
          SELECT COUNT(*)
            INTO L_COUNT
            FROM ISTM_INSTR_TXN
           WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
        
          DBG('l_count ' || L_COUNT);
        
          IF L_COUNT > 0 THEN
            UPDATE ISTM_INSTR_TXN
               SET INSTR_AMOUNT = PKG_RTL_TELLER_REC.TXN_AMOUNT,
                   ACY_AMOUNT   = PKG_RTL_TELLER_REC.TXN_AMOUNT,
                   OFS_AMOUNT   = PKG_RTL_TELLER_REC.OFS_AMOUNT
             WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
          ELSE
          
            INSERT INTO ISTM_INSTR_TXN
              (CONTRACT_REF_NO,
               VERSION_NO,
               INSTR_AMOUNT,
               ACY_AMOUNT,
               OFS_AMOUNT,
               EXCH_RATE,
               XREF,
               OFS_CCY)
            VALUES
              (PKG_RTL_TELLER_REC.TRN_REF_NO,
               '1',
               PKG_RTL_TELLER_REC.TXN_AMOUNT,
               PKG_RTL_TELLER_REC.TXN_AMOUNT,
               PKG_RTL_TELLER_REC.OFS_AMOUNT,
               PKG_RTL_TELLER_REC.EXCH_RATE,
               PKG_RTL_TELLER_REC.XREF,
               PKG_RTL_TELLER_REC.OFS_CCY);
          END IF;
        ELSE
        
          UPDATE ISTM_INSTR_TXN
             SET INSTR_AMOUNT = PKG_RTL_TELLER_REC.TXN_AMOUNT,
                 ACY_AMOUNT   = PKG_RTL_TELLER_REC.TXN_AMOUNT,
                 OFS_AMOUNT   = PKG_RTL_TELLER_REC.OFS_AMOUNT
           WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
        
        END IF;
      
        DBG('no of rows udpated:' || SQL%ROWCOUNT);
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
  END PR_UPDATE_REC;

  PROCEDURE PR_UPDATE_FAILURE(P_EXT_REF_NO IN VARCHAR2,
                              P_ERR_CODE   IN VARCHAR2) IS
  BEGIN
    UPDATE DETBS_RTL_TELLER
       SET RECORD_STAT = 'R', REPAIR_REASON = P_ERR_CODE
     WHERE XREF = P_EXT_REF_NO;
  END PR_UPDATE_FAILURE;

  PROCEDURE PR_UPDATE_SUCCESS(P_EXT_REF_NO IN VARCHAR2) IS
    L_CHECKER_DT_STAMP DATE;
    L_FT_PROBLEM       VARCHAR2(500);
  BEGIN
    DBG('-------------Inside pr_update_success---------------');
    L_CHECKER_DT_STAMP := FN_SYSDATE;
    L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                          (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
  
    IF PKG_RTL_TELLER_REC.SCODE = 'FLEXSWITCH' THEN
      DBG('pkg_rtl_teller_rec.trn_ref_no : ' ||
          PKG_RTL_TELLER_REC.TRN_REF_NO);
      IF NVL(GWPKS_UTIL.G_XREF, '*') != '*' THEN
        UPDATE DETBS_RTL_TELLER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = GLOBAL.USER_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP
         WHERE XREF = GWPKS_UTIL.G_XREF;
      ELSE
        UPDATE DETBS_RTL_TELLER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = GLOBAL.USER_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,
               RECORD_STAT      = DECODE(RECORD_STAT, 'O', 'A', RECORD_STAT)
         WHERE TRN_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO;
      END IF;
    ELSE
    
      IF PKG_RTL_TELLER_REC.FT_PROBLEM = 'Y' THEN
        L_FT_PROBLEM := 'Route Code not maintained for The Transaction';
      END IF;
      DBG('pkg_rtl_teller_rec.checker_id :::::: ' ||
          PKG_RTL_TELLER_REC.CHECKER_ID);
      DBG('gwpks_util.g_checkerid :::::: ' || GWPKS_UTIL.G_CHECKERID);
      DBG('global.user_id :::::: ' || GLOBAL.USER_ID);
      IF PKG_RTL_TELLER_REC.CHECKER_ID IS NULL THEN
      
        PKG_RTL_TELLER_REC.CHECKER_ID := NVL(GWPKS_UTIL.G_CHECKERID,
                                             GLOBAL.USER_ID);
      END IF;
      DBG('Pkg_Rtl_Teller_Rec.Record_Stat ::::: ' ||
          PKG_RTL_TELLER_REC.RECORD_STAT);
      DBG('Pkg_Rtl_Teller_Rec.Track_Receivable ::::: ' ||
          PKG_RTL_TELLER_REC.TRACK_RECEIVABLE);
      DBG('p_ext_ref_no :::::: ' || P_EXT_REF_NO);
    
      IF NVL(PKG_RTL_TELLER_REC.RECORD_STAT, 'X') = 'N' AND
         NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'X') = 'Y' THEN
        DBG('Came in IF to update Detb_Rtl_Teller');
        UPDATE DETBS_RTL_TELLER
           SET RECORD_STAT      = 'N',
               AUTH_STAT        = 'A',
               REPAIR_REASON    = L_FT_PROBLEM,
               CHECKER_ID       = PKG_RTL_TELLER_REC.CHECKER_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP
         WHERE XREF = P_EXT_REF_NO;
      ELSE
      
        DBG('Came in ELSE to update Detb_Rtl_Teller');
        UPDATE DETBS_RTL_TELLER
           SET RECORD_STAT      = 'A',
               AUTH_STAT        = 'A',
               REPAIR_REASON    = L_FT_PROBLEM,
               CHECKER_ID       = PKG_RTL_TELLER_REC.CHECKER_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP
         WHERE XREF = P_EXT_REF_NO;
      END IF;
    END IF;
  END PR_UPDATE_SUCCESS;

  PROCEDURE PR_UPDATE_ENRICH(P_EXT_REF_NO IN VARCHAR2) IS
    L_CHECKER_DT_STAMP DATE;
    L_FT_PROBLEM       VARCHAR2(500);
  BEGIN
    DBG('FROM PR_UPDATE_ENRICH');
    DBG('WILL UPDATE THE DETB_RTL_TELLER NOW');
  
  END PR_UPDATE_ENRICH;

  FUNCTION FN_DELETE(P_TRN_REF_NO IN VARCHAR2,
                     P_ERR_CODE   IN OUT VARCHAR2,
                     P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_XREF             VARCHAR2(16);
  BEGIN
    DBG('Inside the fn_delete OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_DELETE;
    BEGIN
    
      SELECT AUTH_STAT, XREF
        INTO L_AUTH_STAT, L_XREF
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_delete OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_DELETE;
        RETURN FALSE;
    END;
  
    IF NVL(L_AUTH_STAT, 'U') = 'U' THEN
    
      BEGIN
        SELECT NVL(TRACK_RECEIVABLE, 'N')
          INTO L_TRACK_RECEIVABLE
          FROM DETBS_RTL_TELLER
         WHERE TRN_REF_NO = P_TRN_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
              SQLERRM);
          DBG('Txn Ref No is --->' || P_TRN_REF_NO);
          P_ERR_CODE := 'DE-TUD-002';
          ROLLBACK TO RTL_DELETE;
          RETURN FALSE;
      END;
    
      IF L_TRACK_RECEIVABLE = 'Y' THEN
        LDPKSS_MANUAL_LIQUIDATION.PR_RESTORE_TRACKED_RECS(P_TRN_REF_NO);
      END IF;
    
      IF NOT ACPKS.FN_ACSERVICE(GLOBAL.CURRENT_BRANCH,
                                GLOBAL.APPLICATION_DATE,
                                GLOBAL.LCY,
                                P_TRN_REF_NO,
                                1,
                                'D',
                                GLOBAL.USER_ID,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
        DBG('Acpks.fn_acservice returns FALSE IN fn_delete OF Depks_Rtl_Teller PACKAGE...');
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_DELETE;
        RETURN FALSE;
      END IF;
    
      DBG('DELETING the ENTRY frm detbs_rtl_teller...');
      DELETE DETBS_RTL_TELLER WHERE TRN_REF_NO = P_TRN_REF_NO;
      DELETE MITBS_UPLOAD_CLASS_MAPPING WHERE EXTERNAL_REF_NO = L_XREF;
      DELETE MITB_CLASS_MAPPING
       WHERE UNIT_REF_NO = P_TRN_REF_NO
         AND UNIT_TYPE = 'R'
         AND BRANCH_CODE = SUBSTR(P_TRN_REF_NO, 1, 3);
      DELETE MSTB_DLY_MSG_OUT WHERE REFERENCE_NO = P_TRN_REF_NO;
    
    ELSE
      DBG('The given trn_ref_no IS authorised AND can NOT be deleted...');
      P_ERR_CODE := 'DE-TUD-002';
      ROLLBACK TO RTL_DELETE;
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_DELETE;

  FUNCTION FN_UNLOCK(P_TRN_REF_NO IN VARCHAR2,
                     P_ERR_CODE   IN OUT VARCHAR2,
                     P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT DETBS_RTL_TELLER.AUTH_STAT%TYPE;
  BEGIN
    DBG('Inside the fn_unlock OF Depks_Rtl_Teller PACKAGE...');
    BEGIN
      SELECT AUTH_STAT
        INTO L_AUTH_STAT
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_unlock OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        RETURN FALSE;
    END;
    IF NVL(L_AUTH_STAT, 'U') = 'U' THEN
      DBG('DELETING the ENTRY frm detbs_rtl_teller...');
      DBG('Calling fn_acservice OF Acpks FOR a/c entries...');
      IF NOT ACPKS.FN_ACSERVICE(GLOBAL.CURRENT_BRANCH,
                                GLOBAL.APPLICATION_DATE,
                                GLOBAL.LCY,
                                P_TRN_REF_NO,
                                1,
                                'D',
                                GLOBAL.USER_ID,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
        RETURN FALSE;
        DBG('Acpks.fn_acservice returns FALSE IN fn_unlock OF Depks_Rtl_Teller PACKAGE...');
      END IF;
    ELSE
      DBG('The given trn_ref_no IS authorised AND can NOT be deleted...');
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_UNLOCK;

  PROCEDURE PR_CHARGE_REVERSAL(P_AC_ENTS IN OUT NOCOPY ACPKS.TBL_ACHOFF) IS
  
    L_INDEX       NUMBER;
    L_REV_REQD    VARCHAR2(1);
    L_NET_CHARGES VARCHAR2(1);
    L_CHG_FROM    VARCHAR2(3);
    L_AMT_SUM     NUMBER;
    L_CONTRA_LEG  NUMBER;
    L_PROD        VARCHAR2(4);
  
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
  
    DBG('inside pr_chrge_reversal with product as ');
  
    BEGIN
      SELECT PRODUCT_CODE
        INTO L_PROD
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;
    
      DBG('Calling Fn_Get_Detm_Rt_Pref_Rec_Wrp...for the product...' ||
          L_PROD);
      IF NOT
          CSPKSS_FUNCTION_CACHE.FN_GET_DETM_RT_PREF_REC_WRP(L_PROD,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAM) THEN
        IF L_ERR_CODE = 'CS-FRC-001' THEN
          DBG('No data Found exception so assignin value as Y ..');
          L_REV_REQD  := 'Y';
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
        ELSE
          DBG('In others exception..');
          L_ERR_CODE  := NULL;
          L_ERR_PARAM := NULL;
          DBG('Proceed..');
        END IF;
      ELSE
        L_REV_REQD := NVL(CSPKSS_FUNCTION_CACHE.G_TBL_DETM_RT_PREF_REC.REVERSAL_INCLUDES_CHARGES,
                          'N');
        DBG('Value of l_rev_reqd is - ' || L_REV_REQD);
      END IF;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_REV_REQD := 'Y';
      WHEN OTHERS THEN
        DBG('Failed while checking if charge reversal is required');
      
    END;
  
    DBG('GWPKS_UTIL.G_REJECTFLAG => ' || GWPKS_UTIL.G_REJECTFLAG);
  
    IF L_REV_REQD = 'N' OR NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'Y' THEN
      BEGIN
        SELECT NVL(COD_NET_CHARGES, 'Y')
          INTO L_NET_CHARGES
          FROM IFTMS_ARC_MAINT
         WHERE COD_PROD_ACC_CLS = L_PROD;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NET_CHARGES := 'N';
        WHEN OTHERS THEN
          DBG('Failed while checking if charge netting is required');
        
      END;
      DBG('l_net_charges => ' || L_NET_CHARGES);
      IF L_NET_CHARGES = 'Y' THEN
        BEGIN
        
          SELECT CHG_CONTRA_LEG
            INTO L_CHG_FROM
            FROM DETBS_RTL_TELLER
           WHERE TRN_REF_NO = P_AC_ENTS(1).TRN_REF_NO;
        
        END;
        L_AMT_SUM := 0;
      
        IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
          DBG('INSIDE THE LOOP TO FETCH THE CHARGES');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN
                ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              DBG('l_index ' || L_INDEX);
              DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                  .AMOUNT_TAG);
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;
          
          END LOOP;
          DBG('OUT OF THE LOOP WITH l_amt_sum :- ' || L_AMT_SUM);
        
        ELSE
        
          DBG('INSIDE THE ELSE PART');
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF P_AC_ENTS(L_INDEX)
             .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
              L_AMT_SUM := L_AMT_SUM + P_AC_ENTS(L_INDEX).LCY_AMOUNT;
            END IF;
          
          END LOOP;
        
        END IF;
      
        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX).AMOUNT_TAG = (L_CHG_FROM || '_AMT') THEN
            P_AC_ENTS(L_INDEX).LCY_AMOUNT := P_AC_ENTS(L_INDEX)
                                             .LCY_AMOUNT - L_AMT_SUM;
          END IF;
        END LOOP;
      
      END IF;
    
      IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
        DBG('GOING FOR THE LOOP TO DLETE THE CHARGE ENTRIES');
      
        BEGIN
          DBG('pr_print_acctng_table is cmd in begin.....');
          PR_PRINT_ACCTNG_TABLE(P_AC_ENTS);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In OTHERS with line tracking  ::::: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
      
        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN
              ('CHG_AMT1', 'CHG_AMT2', 'CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            DBG('l_index ' || L_INDEX);
            DBG('p_ac_ents(l_index).AMOUNT_TAG => ' || P_AC_ENTS(L_INDEX)
                .AMOUNT_TAG);
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
        DBG('OUT OF LOOP');
      
        IF (P_AC_ENTS.COUNT > 2) AND GWPKS_UTIL.PKG_FUNC = 'LOCH' THEN
        
          FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
            IF L_INDEX > 2 THEN
              DBG('Removing the other entries when l_index for reject is ' ||
                  L_INDEX);
              P_AC_ENTS.DELETE(L_INDEX);
            END IF;
          END LOOP;
        END IF;
      
      ELSE
      
        FOR L_INDEX IN P_AC_ENTS.FIRST .. P_AC_ENTS.LAST LOOP
          IF P_AC_ENTS(L_INDEX)
           .AMOUNT_TAG IN ('CHG_AMT3', 'CHG_AMT4', 'CHG_AMT5') THEN
            P_AC_ENTS.DELETE(L_INDEX);
          END IF;
        END LOOP;
      
      END IF;
    END IF;
  
  END PR_CHARGE_REVERSAL;

  FUNCTION FN_CHARGE_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                             P_AMT_TAG    IN VARCHAR2,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_AMT_TAG          VARCHAR2(35) := P_AMT_TAG;
    L_TEMP_AC_ENTS     ACPKSS.TBL_ACHOFF;
    L_ACC_IDX          PLS_INTEGER := 1;
    L_PREV_AMT_TAG     VARCHAR2(35);
    L_EMPTY            ACPKSS.TBL_ACHOFF;
    L_PASS_AC_ENTS     ACPKSS.TBL_ACHOFF;
    TYPE L_TY_ENTRIES_TO_DELETE IS TABLE OF ACTB_DAILY_LOG.AMOUNT_TAG%TYPE INDEX BY ACTB_DAILY_LOG.AMOUNT_TAG%TYPE;
    L_TB_ENTRIES_TO_DELETE L_TY_ENTRIES_TO_DELETE;
    L_HOFF_IDX             INTEGER;
    L_IDX                  INTEGER;
  BEGIN
    DBG('Inside the fn_charge_reverse OF Depks_Rtl_Teller PACKAGE for amount tag->' ||
        L_AMT_TAG || ' and ref no ->' || P_TRN_REF_NO);
    SAVEPOINT RTL_CHARGE_REVERSE;
    DBG('Issued savepoint rtl_charge_reverse');
  
    IF L_AMT_TAG IS NULL THEN
      L_AMT_TAG := 'CHG';
    END IF;
    DBG('Amount tag here after assignment ->' || L_AMT_TAG);
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*'), NVL(TRACK_RECEIVABLE, 'N')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE, L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('inside no data');
        L_TRACK_RECEIVABLE := 'N';
        SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
          INTO L_AUTH_STAT, L_ROWID, L_SCODE
          FROM CSTBS_CLEARING_MASTER
         WHERE REFERENCE_NO = P_TRN_REF_NO;
      
      WHEN OTHERS THEN
        DBG('FROM fn_charge_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_CHARGE_REVERSE;
        RETURN FALSE;
    END;
  
    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
    
      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
    
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');
      IF ACPKSS.FN_ACENTRY_RETRIEVAL(P_TRN_REF_NO, 1, L_AC_ENTS) > 0 THEN
        DBG('Doing the actual reversal...');
      
        DBG('B4 Rremoving charge entries dlg tbl count is ->' ||
            L_AC_ENTS.COUNT);
        L_TEMP_AC_ENTS := L_AC_ENTS;
        DBG('l_temp_ac_ents here b4 delete  ->' || L_TEMP_AC_ENTS.COUNT);
      
        DBG('l_ac_ents here B4  ->' || L_AC_ENTS.COUNT);
        DBG('l_temp_ac_ents here after delete  ->' || L_TEMP_AC_ENTS.COUNT);
        L_AC_ENTS.DELETE;
        DBG('l_ac_ents here after delete  ->' || L_AC_ENTS.COUNT);
      
        L_HOFF_IDX := 0;
        L_IDX      := L_TEMP_AC_ENTS.FIRST;
        WHILE L_IDX IS NOT NULL LOOP
          DBG('l_hoff_idx value inside loop ->' || L_HOFF_IDX);
        
          DBG('l_hoff_idx value inside loop after addin ->' || L_HOFF_IDX);
          DBG('Amount tag here 1st->' || L_TEMP_AC_ENTS(L_IDX).AMOUNT_TAG ||
              'drcr ind->' || L_TEMP_AC_ENTS(L_IDX).DRCR_IND);
          DBG('l_amt_tag here is ->' || L_AMT_TAG);
          IF L_TEMP_AC_ENTS(L_IDX)
           .AMOUNT_TAG LIKE 'CHG%' AND L_AMT_TAG = 'CHG' THEN
            DBG('l_idx in if ->' || L_IDX);
          
            DBG('l_hoff_idx value in if ->' || L_HOFF_IDX);
            L_HOFF_IDX := L_HOFF_IDX + 1;
            L_AC_ENTS(L_HOFF_IDX) := L_TEMP_AC_ENTS(L_IDX);
            L_AC_ENTS(L_HOFF_IDX).EVENT_SR_NO := 2;
            L_AC_ENTS(L_HOFF_IDX).EVENT := 'REVR';
            L_AC_ENTS(L_HOFF_IDX).FCY_AMOUNT := L_AC_ENTS(L_HOFF_IDX)
                                                .FCY_AMOUNT * -1;
            L_AC_ENTS(L_HOFF_IDX).LCY_AMOUNT := L_AC_ENTS(L_HOFF_IDX)
                                                .LCY_AMOUNT * -1;
          
            L_AC_ENTS(L_HOFF_IDX).TRN_DT := GLOBAL.APPLICATION_DATE;
            L_AC_ENTS(L_HOFF_IDX).USER_ID := NVL(L_AC_ENTS(L_HOFF_IDX)
                                                 .USER_ID,
                                                 GLOBAL.USER_ID);
            L_AC_ENTS(L_HOFF_IDX).TRN_DT := GLOBAL.APPLICATION_DATE;
            L_AC_ENTS(L_HOFF_IDX).USER_ID := NVL(L_AC_ENTS(L_HOFF_IDX)
                                                 .USER_ID,
                                                 GLOBAL.USER_ID);
          ELSIF L_TEMP_AC_ENTS(L_IDX).AMOUNT_TAG LIKE 'CHG_%' AND L_TEMP_AC_ENTS(L_IDX)
                .AMOUNT_TAG = L_AMT_TAG THEN
            DBG('l_idx in else ->' || L_IDX);
            L_HOFF_IDX := L_HOFF_IDX + 1;
          
            L_AC_ENTS(L_HOFF_IDX) := L_TEMP_AC_ENTS(L_IDX);
            L_AC_ENTS(L_HOFF_IDX).EVENT_SR_NO := 2;
            L_AC_ENTS(L_HOFF_IDX).EVENT := 'REVR';
            L_AC_ENTS(L_HOFF_IDX).FCY_AMOUNT := L_AC_ENTS(L_HOFF_IDX)
                                                .FCY_AMOUNT * -1;
            L_AC_ENTS(L_HOFF_IDX).LCY_AMOUNT := L_AC_ENTS(L_HOFF_IDX)
                                                .LCY_AMOUNT * -1;
          
            L_AC_ENTS(L_HOFF_IDX).TRN_DT := GLOBAL.APPLICATION_DATE;
            L_AC_ENTS(L_HOFF_IDX).USER_ID := NVL(L_AC_ENTS(L_HOFF_IDX)
                                                 .USER_ID,
                                                 GLOBAL.USER_ID);
            L_AC_ENTS(L_HOFF_IDX).TRN_DT := GLOBAL.APPLICATION_DATE;
            L_AC_ENTS(L_HOFF_IDX).USER_ID := NVL(L_AC_ENTS(L_HOFF_IDX)
                                                 .USER_ID,
                                                 GLOBAL.USER_ID);
            DBG('l_hoff_idx value in else ->' || L_HOFF_IDX);
          END IF;
          DBG('l_hoff_idx value b4 loop ->' || L_HOFF_IDX);
          L_IDX := L_TEMP_AC_ENTS.NEXT(L_IDX);
          DBG('l_idx value b4 loop ->' || L_IDX);
        END LOOP;
        DBG('l_ac_ents here after having only charge entries ->' ||
            L_AC_ENTS.COUNT);
        PR_PRINT_ACCTNG_TABLE(L_AC_ENTS);
      
        DBG('l_pass_ac_ents actual table coutn is ->' ||
            L_PASS_AC_ENTS.COUNT);
      
        DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');
      
        L_AUTHORISE := 'B';
        DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' || L_AUTHORISE);
      
        DBG('l_ac_ents here b4 calling handoff->' || L_AC_ENTS.COUNT);
        IF L_AC_ENTS.COUNT > 0 THEN
          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_CHARGE_REVERSE;
            RETURN FALSE;
          ELSE
            DBG('reversal handoff is sucess so updating the charge here ');
            UPDATE DETBS_RTL_TELLER
               SET MAINT_CHARGE_APPLIED = 'N'
             WHERE TRN_REF_NO = P_TRN_REF_NO;
            DBG('success after updating charge applied to N');
          END IF;
        END IF;
      
        FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
          DBG('l_prev_amt_tag ->' || L_PREV_AMT_TAG ||
              '~Amount tag here is ->' || L_AC_ENTS(L_RECNO).AMOUNT_TAG ||
              '~ track recievable ->' || L_TRACK_RECEIVABLE ||
              '~l_amt_tag->' || L_AMT_TAG);
          IF L_PREV_AMT_TAG IS NULL OR
             L_PREV_AMT_TAG <> L_AC_ENTS(L_RECNO).AMOUNT_TAG THEN
            IF L_AC_ENTS(L_RECNO)
             .AMOUNT_TAG LIKE 'CHG%' AND L_TRACK_RECEIVABLE = 'Y' AND
                L_AMT_TAG = 'CHG' THEN
              DBG('b4 calling overloaded pr update tracked balances FOR CHARGE');
              LDPKSS_MANUAL_LIQUIDATION.PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO,
                                                                   'RT',
                                                                   L_AC_ENTS(L_RECNO)
                                                                   .AMOUNT_TAG);
            ELSIF L_AC_ENTS(L_RECNO)
             .AMOUNT_TAG LIKE 'CHG_%' AND L_TRACK_RECEIVABLE = 'Y' AND L_AC_ENTS(L_RECNO)
                  .AMOUNT_TAG = L_AMT_TAG THEN
            
              LDPKSS_MANUAL_LIQUIDATION.PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO,
                                                                   'RT',
                                                                   L_AC_ENTS(L_RECNO)
                                                                   .AMOUNT_TAG);
              L_AMT_TAG          := NULL;
              L_TRACK_RECEIVABLE := 'N';
            END IF;
            BEGIN
              INSERT INTO DETBS_RTL_CHARGE_REVERSAL
                (TRN_REF_NO, AMOUNT_TAG, CHG_CCY, CHG_AMT, STATUS)
              VALUES
                (L_AC_ENTS(L_RECNO).TRN_REF_NO,
                 L_AC_ENTS(L_RECNO).AMOUNT_TAG,
                 L_AC_ENTS(L_RECNO).AC_CCY,
                 L_AC_ENTS(L_RECNO).LCY_AMOUNT,
                 'V');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('faile while inserting into rtl charge table But still continues->' ||
                    SQLERRM);
            END;
          END IF;
          L_PREV_AMT_TAG := L_AC_ENTS(L_RECNO).AMOUNT_TAG;
        END LOOP;
      
      ELSE
        DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
        DBG('Rolling back to savepoint rtl reverse');
        ROLLBACK TO RTL_CHARGE_REVERSE;
        RETURN FALSE;
      END IF;
    ELSE
      DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_CHARGE_REVERSE;
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_CHARGE_REVERSE;

  FUNCTION FN_REVERSE(P_TRN_REF_NO IN VARCHAR2,
                      P_ERR_CODE   IN OUT VARCHAR2,
                      P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_AUTH_STAT        DETBS_RTL_TELLER.AUTH_STAT%TYPE;
    L_AC_ENTS          ACPKS.TBL_ACHOFF;
    L_ROWID            ROWID;
    L_AUTHORISE        VARCHAR2(1);
    L_CHECKER_DT_STAMP DATE;
    L_TRACK_RECEIVABLE VARCHAR2(1);
    L_SCODE            DETBS_RTL_TELLER.SCODE%TYPE;
    L_CHECK_ENTRIES    BOOLEAN := TRUE;
    L_SETTLE_COUNT     NUMBER := 0;
    L_ON_ERROR         BOOLEAN := FALSE;
    L_BOOK_DATE        DATE;
  
    L_ACC_TYPE_1   VARCHAR2(20);
    L_ACC_TYPE_2   VARCHAR2(20);
    L_BRANCH       DETBS_RTL_TELLER.BRANCH_CODE%TYPE;
    L_PRODUCT_CODE DETBS_RTL_TELLER.PRODUCT_CODE%TYPE;
    L_MODULE       CSTM_PRODUCT.MODULE%TYPE;
    V_TBL_RESTR    STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR;
    L_EVENT_CODE   DETB_RTL_TELLER.EVENT_CODE%TYPE;
    L_TRN_DATE     DETB_RTL_TELLER.TRN_DT%TYPE;
    L_PRDGRP       CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_DETB_ROW     DETB_RTL_TELLER%ROWTYPE;
    L_REV_UTIL     NUMBER := 0;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Inside the fn_reverse OF Depks_Rtl_Teller PACKAGE...');
    SAVEPOINT RTL_REVERSE;
    DBG('Issued savepoint rtl reverse');
    BEGIN
      SELECT AUTH_STAT, ROWID, NVL(SCODE, '*')
        INTO L_AUTH_STAT, L_ROWID, L_SCODE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
            P_TRN_REF_NO || '~' || SQLERRM);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
  
    BEGIN
      SELECT NVL(TRACK_RECEIVABLE, 'N')
        INTO L_TRACK_RECEIVABLE
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while selecting track_receivable from detb_rtl_teller with -->' ||
            SQLERRM);
        DBG('Txn Ref No is --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
  
    BEGIN
      DBG('Initial value of l_settle_count ' || L_SETTLE_COUNT);
      DBG('Query to get record count from cstb_auto_settle_block');
      SELECT COUNT(*)
        INTO L_SETTLE_COUNT
        FROM CSTB_AUTO_SETTLE_BLOCK
       WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the record.. cstb_auto_settle_block ');
        L_SETTLE_COUNT := 0;
      WHEN OTHERS THEN
        DBG('Failed while selecting entries from cstb_auto_settle_block with -->' ||
            SQLERRM);
        DBG('contract_ref_no --->' || P_TRN_REF_NO);
        P_ERR_CODE := 'DE-TUD-002';
        ROLLBACK TO RTL_REVERSE;
        RETURN FALSE;
    END;
    DBG('l_settle_count ' || L_SETTLE_COUNT);
  
    IF L_AUTH_STAT = 'A' OR L_AUTH_STAT IS NULL THEN
      DBG('Proceeding for Reversal with l_auth_stat  ' || L_AUTH_STAT ||
          ' and l_settle_count ' || L_SETTLE_COUNT);
    
      DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
            P_TRN_REF_NO);
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
      
        IF L_CHECK_ENTRIES THEN
          L_TB_CLUSTER_DATA('l_check_entries') := 'T';
        ELSE
          L_TB_CLUSTER_DATA('l_check_entries') := 'F';
        END IF;
      
        IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
          DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_check_entries') THEN
          IF L_TB_CLUSTER_DATA('l_check_entries') = 'T' THEN
            L_CHECK_ENTRIES := TRUE;
          ELSE
            L_CHECK_ENTRIES := FALSE;
          END IF;
        END IF;
      
      END IF;
    
      IF L_SETTLE_COUNT > 0 THEN
        DBG('Before Validation For Same Day Reversal ');
        BEGIN
          SELECT BOOK_DATE
            INTO L_BOOK_DATE
            FROM CSTB_AUTO_SETTLE_BLOCK
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO
             AND ROWNUM = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the record.. cstb_auto_settle_block ');
            L_BOOK_DATE := NULL;
          WHEN OTHERS THEN
            DBG('Failed while selecting BOOK_DATE from cstb_auto_settle_block with -->' ||
                SQLERRM);
            DBG('contract_ref_no --->' || P_TRN_REF_NO);
            P_ERR_CODE := 'DE-TUD-002';
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
        END;
        DBG('l_BOOK_DATE ' || L_BOOK_DATE);
      
        IF L_BOOK_DATE <> GLOBAL.APPLICATION_DATE THEN
          DBG('For Tracked Transaction Only same date Reversal is Allwoed.');
          P_ERR_CODE := 'DE-TUD-946';
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      END IF;
    
      IF GWPKS_UTIL.G_FROM_BEAN OR L_SCODE = 'FLEXSWITCH' THEN
        PR_AUTH_REVERSAL_REQD(TRUE);
      END IF;
      IF PKG_AUTH_REVERSAL_REQD THEN
      
        L_AUTHORISE := 'B';
      ELSE
        L_AUTHORISE := 'U';
      END IF;
      DBG('Getting a/c entries BY calling Acpks.fn_acEntry_Retrieval...');
    
      IF NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
         NVL(GWPKS_UTIL.PKG_FUNC, '***') = '1401' AND
         NVL(GWPKS_UTIL.G_TWOSTEPPROCESSNO, '1') = '1' THEN
        L_CHECK_ENTRIES := FALSE;
      END IF;
      DBG('after setting check entries.');
      IF L_CHECK_ENTRIES THEN
        DBG(' going to check for entries .');
      
        IF ACPKS.FN_ACENTRY_RETRIEVAL(P_TRN_REF_NO, 1, L_AC_ENTS) > 0 THEN
          DBG('Doing the actual reversal...');
        
          IF L_TRACK_RECEIVABLE = 'Y' OR L_SETTLE_COUNT > 0 THEN
          
            IF NVL(GWPKS_UTIL.G_REJECTFLAG, 'N') = 'N' THEN
              DBG(' Before Call to pr_update_tracked_balances ');
              PR_UPDATE_TRACKED_BALANCES(P_TRN_REF_NO);
            END IF;
            DBG('After Call to pr_update_tracked_balances ');
          END IF;
        
          PR_CHARGE_REVERSAL(L_AC_ENTS);
        
          FOR L_RECNO IN L_AC_ENTS.FIRST .. L_AC_ENTS.LAST LOOP
            L_AC_ENTS(L_RECNO).EVENT_SR_NO := 2;
            L_AC_ENTS(L_RECNO).EVENT := 'REVR';
            L_AC_ENTS(L_RECNO).FCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .FCY_AMOUNT * -1;
            L_AC_ENTS(L_RECNO).LCY_AMOUNT := L_AC_ENTS(L_RECNO)
                                             .LCY_AMOUNT * -1;
          
            DBG('gwpks_util.g_branch_date:::' || GWPKS_UTIL.G_BRANCH_DATE);
            DBG('global.application_date:::' || GLOBAL.APPLICATION_DATE);
            IF GWPKS_UTIL.G_BRANCH_DATE > GLOBAL.APPLICATION_DATE AND
               GWPKS_UTIL.G_FROM_BEAN THEN
              L_AC_ENTS(L_RECNO).TRN_DT := GWPKS_UTIL.G_BRANCH_DATE;
            ELSE
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;
          
            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          
            IF NOT GWPKS_UTIL.G_FROM_BEAN THEN
            
              L_AC_ENTS(L_RECNO).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;
          
            L_AC_ENTS(L_RECNO).USER_ID := NVL(L_AC_ENTS(L_RECNO).USER_ID,
                                              GLOBAL.USER_ID);
          END LOOP;
          IF CSPKS_ACC_SERVICE.G_AUTO_AC_CLOSURE THEN
            DBG('Setting l_auth_stat as B since g_auto_ac_closure is true ...');
            L_AUTH_STAT := 'B';
          END IF;
          DBG('Putting back the reversal entries BY calling Acpks.fn_achandoff...');
        
          IF GWPKS_UTIL.G_REJECTFLAG = 'Y' THEN
            L_AUTHORISE := 'B';
            DBG('THE ACTION CODE FLAG IS FORCEFULLY SET TO B ' ||
                L_AUTHORISE);
          END IF;
        
          IF NOT ACPKS.FN_ACHANDOFF(P_TRN_REF_NO,
                                    2,
                                    GLOBAL.APPLICATION_DATE,
                                    L_AC_ENTS,
                                    L_AUTHORISE,
                                    'N',
                                    'Y',
                                    GLOBAL.USER_ID,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('Failed IN Acpks.fn_achandoff OF fn_reversal IN Depks_Rtl_Teller...');
            DBG('Rolling back to savepoint rtl reverse');
            ROLLBACK TO RTL_REVERSE;
            RETURN FALSE;
          END IF;
        
          DBG('Cspks_Req_Global.g_Release_Type :::: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            DBG('p_trn_ref_no while calling depks_rtl_teller_cluster.fn_reverse ::::: ' ||
                P_TRN_REF_NO);
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 1;
            IF NOT DEPKS_RTL_TELLER_CLUSTER.FN_REVERSE(P_TRN_REF_NO,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
              DBG('Failed inside depks_rtl_teller_cluster.Fn_Save');
              DBG('Rolling back to savepoint rtl reverse');
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
            END IF;
          END IF;
        
        ELSE
          DBG('No entries corresponding TO this p_trn_ref_no IN actb_daily_log...');
          DBG('Rolling back to savepoint rtl reverse');
          ROLLBACK TO RTL_REVERSE;
          RETURN FALSE;
        END IF;
      
        BEGIN
          SELECT COUNT(*)
            INTO L_REV_UTIL
            FROM STTB_CUST_LIMIT_TRACKING
           WHERE CONTRACT_REF_NO = P_TRN_REF_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                P_TRN_REF_NO || '~' || SQLERRM);
        END;
      
        IF L_REV_UTIL > 0 THEN
          BEGIN
            SELECT BRANCH_CODE, PRODUCT_CODE
              INTO L_BRANCH, L_PRODUCT_CODE
              FROM DETBS_RTL_TELLER
             WHERE TRN_REF_NO = P_TRN_REF_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FROM fn_reverse OF Depks_Rtl_Teller PACKAGE... ' ||
                  P_TRN_REF_NO || '~' || SQLERRM);
              P_ERR_CODE := 'DE-TUD-002';
              ROLLBACK TO RTL_REVERSE;
              RETURN FALSE;
          END;
        
          SELECT MODULE, PRODUCT_GROUP
            INTO L_MODULE, L_PRDGRP
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = L_PRODUCT_CODE;
        
          DBG('l_module' || L_MODULE);
        
          IF NOT
              STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(L_SCODE,
                                                               L_MODULE,
                                                               L_BRANCH,
                                                               P_TRN_REF_NO,
                                                               NULL,
                                                               NULL,
                                                               L_EVENT_CODE,
                                                               1,
                                                               L_PRDGRP,
                                                               L_TRN_DATE,
                                                               NULL,
                                                               '',
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               'D',
                                                               V_TBL_RESTR,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM) THEN
            DBG('error Code' || P_ERR_CODE);
            DBG('error params' || P_ERR_PARAM);
          ELSE
            DBG('NTHNG');
          END IF;
        END IF;
      
      END IF;
    ELSE
    
      IF L_SETTLE_COUNT > 0 THEN
        DBG('Cannot proceed to reversal with l_settle_count ' ||
            L_SETTLE_COUNT);
        DBG('This TRANSACTION is NSF tracked Hence cannot be reversed...');
        L_ON_ERROR := TRUE;
      ELSE
        DBG('This TRANSACTION IS unauthorised AND can NOT be reversed...');
        L_ON_ERROR := TRUE;
      END IF;
    
    END IF;
  
    IF L_ON_ERROR THEN
      DBG('Reversal cannot be processed ');
      DBG('contract_ref_no --->' || P_TRN_REF_NO);
      P_ERR_CODE := 'DE-TUD-945';
      DBG('Rolling back to savepoint rtl reverse');
      ROLLBACK TO RTL_REVERSE;
      RETURN FALSE;
    END IF;
  
    DBG('Now UPDATING the Record_stat OF detbs_rtl_teller FOR the trn_ref_no...' ||
        P_TRN_REF_NO);
  
    IF L_AUTHORISE = 'B' THEN
      L_CHECKER_DT_STAMP := FN_SYSDATE;
      L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                            (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
      DBG('Checker date stamp is' || L_CHECKER_DT_STAMP);
      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'A',
             CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
             CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,
             
             REVR_DT = GLOBAL.APPLICATION_DATE
      
       WHERE ROWID = L_ROWID;
    ELSE
    
      UPDATE DETBS_RTL_TELLER
         SET RECORD_STAT      = 'V',
             AUTH_STAT        = 'U',
             CHECKER_ID       = NULL,
             CHECKER_DT_STAMP = NULL
             
            ,
             REVR_DT = GLOBAL.APPLICATION_DATE
      
       WHERE ROWID = L_ROWID;
    
    END IF;
    DBG('RECORD stat IS updated FOR the trn_ref_no IN detbs_rtl_teller...' ||
        P_TRN_REF_NO);
    RETURN TRUE;
  END FN_REVERSE;

  PROCEDURE PR_MSGGEN(P_REF VARCHAR2, P_ERROR_CODE OUT VARCHAR2) IS
    L_CURS MSPKSS.MODULE_PROC_CURTYPE;
    CURSOR CUR_MSGS IS
      SELECT * FROM MSTBS_DLY_MSG_OUT WHERE REFERENCE_NO = P_REF;
    L_EACH_MSG CUR_MSGS%ROWTYPE;
  BEGIN
    DBG('Inside pr_msggen procedure for ref ' || P_REF);
    FT_TRN := TRUE;
    IF CUR_MSGS%ISOPEN THEN
      CLOSE CUR_MSGS;
    END IF;
    OPEN CUR_MSGS;
    LOOP
      FETCH CUR_MSGS
        INTO L_EACH_MSG;
      EXIT WHEN CUR_MSGS%NOTFOUND;
      IF L_CURS%ISOPEN THEN
        CLOSE L_CURS;
      END IF;
      OPEN L_CURS FOR
        SELECT * FROM MSTBS_DLY_MSG_OUT WHERE DCN = L_EACH_MSG.DCN;
      PR_MSGGEN(L_CURS, P_ERROR_CODE);
    END LOOP;
    DBG('Finished pr_msggen');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in pr_msggen is ' || SQLERRM);
      P_ERROR_CODE := 'DE-FT005';
  END PR_MSGGEN;

  FUNCTION FN_RTL_TELLER_AUTH(P_BRANCH     IN VARCHAR2,
                              P_TRN_REF_NO IN VARCHAR2,
                              P_AUTH_ID    IN VARCHAR2,
                              P_LCY        IN VARCHAR2,
                              P_ERR_CODE   IN OUT VARCHAR2,
                              P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ESN ACTBS_DAILY_LOG.EVENT_SR_NO%TYPE;
  BEGIN
  
    BEGIN
      SELECT MAX(EVENT_SR_NO)
        INTO L_ESN
        FROM ACTBS_DAILY_LOG
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    EXCEPTION
    
      WHEN NO_DATA_FOUND THEN
        DBG('in no data found go for centralized table');
        IF NOT ACPKS_OTHERS.FN_GET_MAX_ESN(PTRANREFNO => P_TRN_REF_NO,
                                           P_ESN      => L_ESN,
                                           PERRCODE   => P_ERR_CODE,
                                           PPARAM     => P_ERR_PARAM) THEN
          DBG('failed hence assigning to 1');
          L_ESN := 1;
        END IF;
      
      WHEN OTHERS THEN
        L_ESN := 1;
    END;
    IF L_ESN IS NULL THEN
      L_ESN := 1;
    END IF;
    DBG('caling fn_rtl_teller_auth---l_esn--' || L_ESN);
    DBG('caling fn_rtl_teller_auth---p_trn_ref_no--' || P_TRN_REF_NO);
    IF NOT FN_RTL_TELLER_AUTH(P_BRANCH,
                              P_TRN_REF_NO,
                              P_AUTH_ID,
                              P_LCY,
                              L_ESN,
                              P_ERR_CODE,
                              P_ERR_PARAM)
    
     THEN
      RETURN FALSE;
    ELSE
      RETURN TRUE;
    END IF;
  END FN_RTL_TELLER_AUTH;

  FUNCTION FN_RTL_TELLER_AUTH(P_BRANCH     IN VARCHAR2,
                              P_TRN_REF_NO IN VARCHAR2,
                              P_AUTH_ID    IN VARCHAR2,
                              P_LCY        IN VARCHAR2,
                              P_ESN        IN NUMBER,
                              P_ERR_CODE   IN OUT VARCHAR2,
                              P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CHECKER_DT_STAMP DATE;
  BEGIN
    DBG('Calling fn_rtl_teller_auth for ' || P_TRN_REF_NO);
    DBG('p_trn_ref_no ' || P_TRN_REF_NO);
    DBG('p_esn ' || P_ESN);
    L_CHECKER_DT_STAMP := FN_SYSDATE;
    L_CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE +
                          (L_CHECKER_DT_STAMP - TRUNC(L_CHECKER_DT_STAMP));
    IF NOT ACPKSS.FN_ACSERVICE(P_BRANCH,
                               GLOBAL.APPLICATION_DATE,
                               P_LCY,
                               P_TRN_REF_NO,
                               P_ESN,
                               'A',
                               P_AUTH_ID,
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
      RETURN FALSE;
    ELSE
      IF NVL(GWPKS_UTIL.G_XREF, '*') != '*' THEN
        UPDATE DETBS_RTL_TELLER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = P_AUTH_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP
         WHERE XREF = GWPKS_UTIL.G_XREF;
      ELSE
        UPDATE DETBS_RTL_TELLER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = P_AUTH_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,
               RECORD_STAT      = DECODE(RECORD_STAT, 'O', 'A', RECORD_STAT)
         WHERE TRN_REF_NO = P_TRN_REF_NO;
      END IF;
    END IF;
  
    IF PKG_RTL_TELLER_REC.TRN_REF_NO IS NULL THEN
      SELECT *
        INTO PKG_RTL_TELLER_REC
        FROM DETBS_RTL_TELLER
       WHERE TRN_REF_NO = P_TRN_REF_NO;
    END IF;
  
    IF GWPKS_UTIL.G_MSGTYPE <> '400' THEN
      PR_GEN_ADV_FOR_CONTRACT(P_TRN_REF_NO);
    END IF;
  
    DBG('The route Code is ' || PKG_RTL_TELLER_REC.ROUTE_CODE);
    IF PKG_RTL_TELLER_REC.ROUTE_CODE IS NOT NULL THEN
      DBG('Calling pr_msgins ' || PKG_RTL_TELLER_REC.XREF);
      PR_MSGINS(PKG_RTL_TELLER_REC.XREF, P_ERR_CODE);
      DBG('After Calling pr_msgins ' || P_ERR_CODE);
      IF P_ERR_CODE IS NOT NULL THEN
        RETURN FALSE;
      END IF;
      PR_MSGGEN(PKG_RTL_TELLER_REC.TRN_REF_NO, P_ERR_CODE);
    ELSE
    
      NULL;
    END IF;
    DBG('Successful completion of fn_rtl_teller_auth');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('fn_teller_auth_returned false ' || SQLERRM);
      RETURN FALSE;
  END FN_RTL_TELLER_AUTH;

  PROCEDURE PR_GEN_ADV_FOR_CONTRACT(P_TRN_REF_NO VARCHAR2) IS
  BEGIN
    DBG('IN pr_gen_adv_for_contract ' || P_TRN_REF_NO);
    FOR EACH_DCN IN (SELECT DCN
                       FROM MSTBS_DLY_MSG_OUT
                      WHERE REFERENCE_NO = P_TRN_REF_NO) LOOP
      PR_GENERATE_ADVICE(EACH_DCN.DCN);
    END LOOP;
    DBG('END OF pr_gen_adv_for_contract');
  END PR_GEN_ADV_FOR_CONTRACT;

  PROCEDURE PR_MSGINS(P_XREF VARCHAR2, P_ERRCODE OUT VARCHAR2) IS
    CURSOR CR_RTL_TELLER(P_REF VARCHAR2) IS
      SELECT * FROM DETBS_RTL_TELLER WHERE XREF = P_REF;
    CURSOR CR_ARC_SETTLE(P_REF VARCHAR2) IS
      SELECT * FROM CSTBS_ARC_SETTLE WHERE XREF = P_REF;
    CURSOR CR_ADDRESS(P_CIF VARCHAR2) IS
      SELECT *
        FROM MSTMS_CUST_ADDRESS
       WHERE CUSTOMER_NO = P_CIF
         AND ONCE_AUTH = 'Y'
         AND MEDIA = 'SWIFT';
    REC_DERTLTELLER DETBS_RTL_TELLER%ROWTYPE;
    REC_ARCSETTLE   CSTBS_ARC_SETTLE%ROWTYPE;
    L_NCIF          STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_RCIF          STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    NOSTROFLAG      VARCHAR2(1);
    L_COUNT         NUMBER;
    LO_ADDRESS1     MSTBS_MSG_HANDOFF.ADDRESS1%TYPE;
    LO_ADDRESS2     MSTBS_MSG_HANDOFF.ADDRESS2%TYPE;
    LO_ADDRESS3     MSTBS_MSG_HANDOFF.ADDRESS3%TYPE;
    LO_ADDRESS4     MSTBS_MSG_HANDOFF.ADDRESS4%TYPE;
    LO_MEDIUM       MSTBS_MSG_HANDOFF.MEDIA%TYPE;
    LO_MESSAGE      MSTBS_MSG_HANDOFF.MSG_TYPE%TYPE;
    L_RNAME         STTM_CUSTOMER%ROWTYPE;
    REC_ADDRESS     MSTMS_CUST_ADDRESS%ROWTYPE;
    REC_NOSTRO      ISTMS_BIC_DIRECTORY%ROWTYPE;
    REC_RECEIVER    ISTMS_BIC_DIRECTORY%ROWTYPE;
    REC_ARCSETTLE1  CSTBS_ARC_SETTLE%ROWTYPE;
  
    L_TFR_AMT     NUMBER;
    L_SNDRCHG1    NUMBER;
    L_SNDRCHGCCY1 VARCHAR2(3);
    L_SNDRCHG2    NUMBER;
    L_SNDRCHGCCY2 VARCHAR2(3);
    L_SNDRCHG3    NUMBER;
    L_SNDRCHGCCY3 VARCHAR2(3);
    L_SNDRCHG4    NUMBER;
    L_SNDRCHGCCY4 VARCHAR2(3);
    L_SNDRCHG5    NUMBER;
    L_SNDRCHGCCY5 VARCHAR2(3);
    L_RVRCHG1     NUMBER;
    L_RVRCHGCCY1  VARCHAR2(3);
    L_RVRCHG2     NUMBER;
    L_RVRCHGCCY2  VARCHAR2(3);
    L_RVRCHG3     NUMBER;
    L_RVRCHGCCY3  VARCHAR2(3);
    L_RVRCHG4     NUMBER;
    L_RVRCHGCCY4  VARCHAR2(3);
    L_RVRCHG5     NUMBER;
    L_RVRCHGCCY5  VARCHAR2(3);
  
  BEGIN
    DBG('Inside pr_msgins for xref ' || P_XREF);
    FT_TRN := TRUE;
    OPEN CR_RTL_TELLER(P_XREF);
    FETCH CR_RTL_TELLER
      INTO REC_DERTLTELLER;
    CLOSE CR_RTL_TELLER;
    DBG('rec_dertlteller.dr_acc ' || REC_DERTLTELLER.DR_ACC);
    OPEN CR_ARC_SETTLE(P_XREF);
    FETCH CR_ARC_SETTLE
      INTO REC_ARCSETTLE;
    CLOSE CR_ARC_SETTLE;
    DBG('rec_arcsettle ' || REC_ARCSETTLE.RECEIVER);
    PKG_RTL_TELLER_REC := REC_DERTLTELLER;
    PR_SET_GLOBAL(P_ERRCODE);
    IF REC_DERTLTELLER.DR_ACC = 'TXN' THEN
      DBG('This is IDC Transaction DR The Nostro Cr the Customer Sending Credit Advice to the Customer');
    
      IF PKG_GENERATE_MT101 <> 'Y' THEN
      
        IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
        
          PR_INS_MSG_HANDOFF('CR ADVICE');
        ELSE
        
          DBG('This is ODC Transaction Dr the Customer Cr the Nostro Sending Dr advice to the Customer');
          DBG('Receiver gets the MT100 or MT103 IF CIF OF NOSTRO <> CIF OF RECIEVER Send MT202 to The CIF Of Receiver');
          PR_INS_MSG_HANDOFF('DR ADVICE');
          SELECT DECODE(B.AC_CLASS_TYPE, 'N', 'Y', 'N')
            INTO NOSTROFLAG
            FROM STTBS_ACCOUNT ACC, STTMS_ACCOUNT_CLASS B
           WHERE AC_OR_GL = 'A'
             AND AC_GL_NO = REC_DERTLTELLER.TXN_ACC
             AND BRANCH_CODE = REC_DERTLTELLER.TXN_BRANCH
             AND B.ACCOUNT_CLASS = ACC.AC_CLASS;
          LO_MEDIUM := 'SWIFT';
          BEGIN
            SELECT CUST_NO
              INTO L_NCIF
              FROM STTMS_CUST_ACCOUNT
             WHERE CUST_AC_NO = REC_DERTLTELLER.TXN_ACC
               AND BRANCH_CODE = REC_DERTLTELLER.TXN_BRANCH;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed to get the CIF of the Nostro');
          END;
          DBG('Getting the bic code ' || L_NCIF);
          BEGIN
            SELECT *
              INTO REC_NOSTRO
              FROM ISTMS_BIC_DIRECTORY
             WHERE CUSTOMER_NO = L_NCIF;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed while getting the nostro bic');
          END;
        
          L_TFR_AMT := REC_DERTLTELLER.TXN_AMOUNT;
          DBG('Set transfer amount for 33 B as ' || L_TFR_AMT);
          PR_FETCH_CHG_DETAILS(REC_DERTLTELLER,
                               L_SNDRCHG1,
                               L_SNDRCHGCCY1,
                               L_SNDRCHG2,
                               L_SNDRCHGCCY2,
                               L_SNDRCHG3,
                               L_SNDRCHGCCY3,
                               L_SNDRCHG4,
                               L_SNDRCHGCCY4,
                               L_SNDRCHG5,
                               L_SNDRCHGCCY5,
                               L_RVRCHG1,
                               L_RVRCHGCCY1
                               
                               );
        
          IF REC_ARCSETTLE.RECEIVER IS NULL THEN
            DBG('Receiver is NULL, so Cust transfer');
            LO_MESSAGE := 'CUST_TRANSFER';
            DBG('Selecting CIF of remitter for field 50');
            BEGIN
              SELECT A.*
                INTO L_RNAME
                FROM STTMS_CUSTOMER A, STTMS_CUST_ACCOUNT B
               WHERE B.CUST_AC_NO = REC_DERTLTELLER.OFS_ACC
                 AND B.BRANCH_CODE = REC_DERTLTELLER.OFS_BRANCH
                 AND B.CUST_NO = A.CUSTOMER_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in selection of remitter customer');
            END;
          
            IF REC_ARCSETTLE.ORDERING_CUSTOMER1 ||
               REC_ARCSETTLE.ORDERING_CUSTOMER2 ||
               REC_ARCSETTLE.ORDERING_CUSTOMER3 ||
               REC_ARCSETTLE.ORDERING_CUSTOMER4 ||
               REC_ARCSETTLE.ORDERING_CUSTOMER5 IS NULL THEN
              REC_ARCSETTLE.ORDERING_CUSTOMER1 := L_RNAME.CUSTOMER_NAME1;
              REC_ARCSETTLE.ORDERING_CUSTOMER2 := L_RNAME.ADDRESS_LINE1;
              REC_ARCSETTLE.ORDERING_CUSTOMER3 := L_RNAME.ADDRESS_LINE2;
              REC_ARCSETTLE.ORDERING_CUSTOMER4 := L_RNAME.ADDRESS_LINE3;
              REC_ARCSETTLE.ORDERING_CUSTOMER5 := L_RNAME.ADDRESS_LINE4;
            END IF;
          
            DBG('Inserting into mstbs_msg_handoff for customer Transfer');
            INSERT INTO MSTBS_MSG_HANDOFF
              (BRANCH,
               REFERENCE_NO,
               ESN,
               MSG_TYPE,
               RECEIVER,
               NAME,
               SERIAL_NO,
               CCY,
               PRODUCT,
               AMOUNT,
               MEDIA,
               PRIORITY,
               MODULE,
               ADDRESS1,
               ADDRESS2,
               ADDRESS3,
               ADDRESS4,
               FORMAT,
               DIRECTIVE_STATUS,
               PROCESSED_FLAG,
               SUPPRESS_FLAG)
            VALUES
              (REC_DERTLTELLER.TXN_BRANCH,
               REC_DERTLTELLER.TRN_REF_NO,
               1,
               LO_MESSAGE,
               REC_NOSTRO.BIC_CODE,
               REC_NOSTRO.BANK_NAME,
               1,
               REC_DERTLTELLER.TXN_CCY,
               SUBSTR(REC_DERTLTELLER.XREF, 4, 4)
               
              ,
               L_TFR_AMT,
               LO_MEDIUM,
               1,
               'RT',
               REC_NOSTRO.BIC_CODE,
               NULL,
               NULL,
               NULL,
               '',
               'B',
               'N',
               'N');
            DBG('Inserting into istbs_msgho for customer Transfer');
            INSERT INTO ISTBS_MSGHO
              (CONTRACT_REF_NO,
               EVENT_SEQ_NO,
               MSG_TYPE,
               RECEIVER,
               SERIAL_NO,
               ACC_BRANCH,
               ACCOUNT,
               TAG_CCY,
               ACC_CCY,
               EX_RATE,
               SETTLEMENT_AMT,
               VALUE_DATE,
               PAY_RECEIVE,
               INSTRUMENT_TYPE,
               INSTRUMENT_NO,
               CHARGES_DETAILS,
               OUR_CORRESPONDENT,
               ACC_WITH_INSTN1,
               ACC_WITH_INSTN2,
               ACC_WITH_INSTN3,
               ACC_WITH_INSTN4,
               ACC_WITH_INSTN5,
               RCVR_CORRESP1,
               RCVR_CORRESP2,
               RCVR_CORRESP3,
               RCVR_CORRESP4,
               RCVR_CORRESP5,
               INTERMEDIARY1,
               INTERMEDIARY2,
               INTERMEDIARY3,
               INTERMEDIARY4,
               INTERMEDIARY5,
               SNDR_TO_RCVR_INFO1,
               SNDR_TO_RCVR_INFO2,
               SNDR_TO_RCVR_INFO3,
               SNDR_TO_RCVR_INFO4,
               SNDR_TO_RCVR_INFO5,
               SNDR_TO_RCVR_INFO6,
               BENEF_INSTITUTION1,
               BENEF_INSTITUTION2,
               BENEF_INSTITUTION3,
               BENEF_INSTITUTION4,
               BENEF_INSTITUTION5,
               ULT_BENEFICIARY1,
               ULT_BENEFICIARY2,
               ULT_BENEFICIARY3,
               ULT_BENEFICIARY4,
               ULT_BENEFICIARY5,
               ORDERING_INSTITUTION1,
               ORDERING_INSTITUTION2,
               ORDERING_INSTITUTION3,
               ORDERING_INSTITUTION4,
               ORDERING_INSTITUTION5,
               INT_REIM_INST1,
               INT_REIM_INST2,
               INT_REIM_INST3,
               INT_REIM_INST4,
               INT_REIM_INST5,
               ORDERING_CUSTOMER1,
               ORDERING_CUSTOMER2,
               ORDERING_CUSTOMER3,
               ORDERING_CUSTOMER4,
               ORDERING_CUSTOMER5,
               PAYMENT_DETAILS1,
               PAYMENT_DETAILS2,
               PAYMENT_DETAILS3,
               PAYMENT_DETAILS4,
               ERI_CCY,
               ERI_AMOUNT,
               BENEF_INST1_FOR_COVER,
               BENEF_INST2_FOR_COVER,
               BENEF_INST3_FOR_COVER,
               BENEF_INST4_FOR_COVER,
               BENEF_INST5_FOR_COVER)
            VALUES
              (REC_DERTLTELLER.TRN_REF_NO,
               1,
               LO_MESSAGE,
               REC_NOSTRO.BIC_CODE,
               1,
               REC_DERTLTELLER.TXN_BRANCH,
               REC_DERTLTELLER.TXN_ACC,
               REC_DERTLTELLER.TXN_CCY,
               REC_DERTLTELLER.TXN_CCY,
               REC_DERTLTELLER.EXCH_RATE
               
              ,
               L_TFR_AMT,
               REC_ARCSETTLE.CR_VALUE_DT,
               REC_ARCSETTLE.PAY_RECEIVE,
               REC_ARCSETTLE.INSTRUMENT_TYPE,
               REC_ARCSETTLE.INSTRUMENT_NO,
               REC_ARCSETTLE.CHARGES_DETAILS,
               REC_ARCSETTLE.OUR_CORRESPONDENT,
               REC_ARCSETTLE.ACC_WITH_INSTN1,
               REC_ARCSETTLE.ACC_WITH_INSTN2,
               REC_ARCSETTLE.ACC_WITH_INSTN3,
               REC_ARCSETTLE.ACC_WITH_INSTN4,
               REC_ARCSETTLE.ACC_WITH_INSTN5,
               REC_ARCSETTLE.RCVR_CORRESP1,
               REC_ARCSETTLE.RCVR_CORRESP2,
               REC_ARCSETTLE.RCVR_CORRESP3,
               REC_ARCSETTLE.RCVR_CORRESP4,
               REC_ARCSETTLE.RCVR_CORRESP5,
               REC_ARCSETTLE.INTERMEDIARY1,
               REC_ARCSETTLE.INTERMEDIARY2,
               REC_ARCSETTLE.INTERMEDIARY3,
               REC_ARCSETTLE.INTERMEDIARY4,
               REC_ARCSETTLE.INTERMEDIARY5,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO1,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO2,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO3,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO4,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO5,
               REC_ARCSETTLE.SNDR_TO_RCVR_INFO6,
               REC_ARCSETTLE.BENEF_INSTITUTION1,
               REC_ARCSETTLE.BENEF_INSTITUTION2,
               REC_ARCSETTLE.BENEF_INSTITUTION3,
               REC_ARCSETTLE.BENEF_INSTITUTION4,
               REC_ARCSETTLE.BENEF_INSTITUTION5,
               REC_ARCSETTLE.ULT_BENEFICIARY1,
               REC_ARCSETTLE.ULT_BENEFICIARY2,
               REC_ARCSETTLE.ULT_BENEFICIARY3,
               REC_ARCSETTLE.ULT_BENEFICIARY4,
               REC_ARCSETTLE.ULT_BENEFICIARY5,
               REC_ARCSETTLE.ORDERING_INSTITUTION1,
               REC_ARCSETTLE.ORDERING_INSTITUTION2,
               REC_ARCSETTLE.ORDERING_INSTITUTION3,
               REC_ARCSETTLE.ORDERING_INSTITUTION4,
               REC_ARCSETTLE.ORDERING_INSTITUTION5,
               REC_ARCSETTLE.INT_REIM_INST1,
               REC_ARCSETTLE.INT_REIM_INST2,
               REC_ARCSETTLE.INT_REIM_INST3,
               REC_ARCSETTLE.INT_REIM_INST4,
               REC_ARCSETTLE.INT_REIM_INST5,
               REC_ARCSETTLE.ORDERING_CUSTOMER1,
               REC_ARCSETTLE.ORDERING_CUSTOMER2,
               REC_ARCSETTLE.ORDERING_CUSTOMER3,
               REC_ARCSETTLE.ORDERING_CUSTOMER4,
               REC_ARCSETTLE.ORDERING_CUSTOMER5,
               REC_ARCSETTLE.PAYMENT_DETAILS1,
               REC_ARCSETTLE.PAYMENT_DETAILS2,
               REC_ARCSETTLE.PAYMENT_DETAILS3,
               REC_ARCSETTLE.PAYMENT_DETAILS4,
               REC_ARCSETTLE.ERI_CCY,
               REC_ARCSETTLE.ERI_AMOUNT,
               REC_ARCSETTLE.BENEF_INST1_FOR_COVER,
               REC_ARCSETTLE.BENEF_INST2_FOR_COVER,
               REC_ARCSETTLE.BENEF_INST3_FOR_COVER,
               REC_ARCSETTLE.BENEF_INST4_FOR_COVER,
               REC_ARCSETTLE.BENEF_INST5_FOR_COVER);
            DBG('Inserting into istbs_contract_details');
            INSERT INTO ISTBS_CONTRACT_DETAILS
              (CONTRACT_REF_NO,
               EVENT_SEQ_NO,
               AMOUNT_TAG,
               BANK_OPER_CODE,
               INSTR_CODE,
               TRAN_TYPE_CODE,
               REGULATORY_REP1,
               REGULATORY_REP2,
               REGULATORY_REP3,
               ENVELOPE_CONTENTS1,
               ENVELOPE_CONTENTS2,
               ENVELOPE_CONTENTS3,
               ENVELOPE_CONTENTS4,
               ENVELOPE_CONTENTS5,
               SNDR_CHGS1,
               SNDR_CHGS2,
               SNDR_CHGS3,
               SNDR_CHGS4,
               SNDR_CHGS5,
               CCY_SNDR_CHGS1,
               CCY_SNDR_CHGS2,
               CCY_SNDR_CHGS3,
               CCY_SNDR_CHGS4,
               CCY_SNDR_CHGS5,
               RCVR_CHGS1,
               CCY_RCVR_CHGS1)
            VALUES
              (REC_DERTLTELLER.TRN_REF_NO,
               1,
               'TXN_AMT',
               REC_ARCSETTLE.BANK_OPER_CODE,
               REC_ARCSETTLE.INSTR_CODE,
               REC_ARCSETTLE.TRAN_TYPE_CODE,
               REC_ARCSETTLE.REGULATORY_REP1,
               REC_ARCSETTLE.REGULATORY_REP2,
               REC_ARCSETTLE.REGULATORY_REP3,
               REC_ARCSETTLE.ENVELOPE_CONTENTS1,
               REC_ARCSETTLE.ENVELOPE_CONTENTS2,
               REC_ARCSETTLE.ENVELOPE_CONTENTS3,
               REC_ARCSETTLE.ENVELOPE_CONTENTS4,
               REC_ARCSETTLE.ENVELOPE_CONTENTS5,
               L_SNDRCHG1,
               L_SNDRCHG2,
               L_SNDRCHG3,
               L_SNDRCHG4,
               L_SNDRCHG5,
               L_SNDRCHGCCY1,
               L_SNDRCHGCCY2,
               L_SNDRCHGCCY3,
               L_SNDRCHGCCY4,
               L_SNDRCHGCCY5,
               L_RVRCHG1,
               L_RVRCHGCCY1);
          ELSE
            IF REC_NOSTRO.BIC_CODE <> REC_ARCSETTLE.RECEIVER THEN
              DBG('bic of nostro <> receiver send mt202 to nostro and mt100 to reciver');
              LO_MESSAGE := 'COVER';
              DBG('Inserting into mstbs_msg_handoff for Cover');
              INSERT INTO MSTBS_MSG_HANDOFF
                (BRANCH,
                 REFERENCE_NO,
                 ESN,
                 MSG_TYPE,
                 RECEIVER,
                 NAME,
                 SERIAL_NO,
                 CCY,
                 PRODUCT,
                 AMOUNT,
                 MEDIA,
                 PRIORITY,
                 MODULE,
                 ADDRESS1,
                 ADDRESS2,
                 ADDRESS3,
                 ADDRESS4,
                 FORMAT,
                 DIRECTIVE_STATUS,
                 PROCESSED_FLAG,
                 SUPPRESS_FLAG)
              VALUES
                (REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_NOSTRO.BIC_CODE,
                 REC_NOSTRO.BANK_NAME,
                 1,
                 REC_DERTLTELLER.TXN_CCY,
                 SUBSTR(REC_DERTLTELLER.XREF, 4, 4)
                 
                ,
                 L_TFR_AMT,
                 LO_MEDIUM,
                 1,
                 'RT',
                 REC_NOSTRO.BIC_CODE,
                 NULL,
                 NULL,
                 NULL,
                 '',
                 'B',
                 'N',
                 'N');
              DBG('Inserting into istbs_msgho for Cover');
              REC_ARCSETTLE1                    := REC_ARCSETTLE;
              REC_ARCSETTLE1.OUR_CORRESPONDENT  := NULL;
              REC_ARCSETTLE1.RECEIVER           := REC_NOSTRO.BIC_CODE;
              REC_ARCSETTLE1.INT_REIM_INST1     := NULL;
              REC_ARCSETTLE1.INT_REIM_INST2     := NULL;
              REC_ARCSETTLE1.INT_REIM_INST3     := NULL;
              REC_ARCSETTLE1.INT_REIM_INST4     := NULL;
              REC_ARCSETTLE1.INT_REIM_INST5     := NULL;
              REC_ARCSETTLE1.RCVR_CORRESP1      := NULL;
              REC_ARCSETTLE1.RCVR_CORRESP2      := NULL;
              REC_ARCSETTLE1.RCVR_CORRESP3      := NULL;
              REC_ARCSETTLE1.RCVR_CORRESP4      := NULL;
              REC_ARCSETTLE1.RCVR_CORRESP5      := NULL;
              REC_ARCSETTLE1.BENEF_INSTITUTION1 := REC_ARCSETTLE.ACC_WITH_INSTN1;
              REC_ARCSETTLE1.BENEF_INSTITUTION2 := REC_ARCSETTLE.ACC_WITH_INSTN2;
              REC_ARCSETTLE1.BENEF_INSTITUTION3 := REC_ARCSETTLE.ACC_WITH_INSTN3;
              REC_ARCSETTLE1.BENEF_INSTITUTION4 := REC_ARCSETTLE.ACC_WITH_INSTN4;
              REC_ARCSETTLE1.BENEF_INSTITUTION5 := REC_ARCSETTLE.ACC_WITH_INSTN5;
              REC_ARCSETTLE1.ACC_WITH_INSTN1    := REC_ARCSETTLE.INTERMEDIARY1;
              REC_ARCSETTLE1.ACC_WITH_INSTN2    := REC_ARCSETTLE.INTERMEDIARY2;
              REC_ARCSETTLE1.ACC_WITH_INSTN3    := REC_ARCSETTLE.INTERMEDIARY3;
              REC_ARCSETTLE1.ACC_WITH_INSTN4    := REC_ARCSETTLE.INTERMEDIARY4;
              REC_ARCSETTLE1.ACC_WITH_INSTN5    := REC_ARCSETTLE.INTERMEDIARY5;
              REC_ARCSETTLE1.INTERMEDIARY1      := REC_ARCSETTLE.RECEIVER;
              REC_ARCSETTLE1.INTERMEDIARY2      := NULL;
              REC_ARCSETTLE1.INTERMEDIARY3      := NULL;
              REC_ARCSETTLE1.INTERMEDIARY4      := NULL;
              REC_ARCSETTLE1.INTERMEDIARY5      := NULL;
              INSERT INTO ISTBS_MSGHO
                (CONTRACT_REF_NO,
                 EVENT_SEQ_NO,
                 MSG_TYPE,
                 RECEIVER,
                 SERIAL_NO,
                 ACC_BRANCH,
                 ACCOUNT,
                 TAG_CCY,
                 ACC_CCY,
                 EX_RATE,
                 SETTLEMENT_AMT,
                 VALUE_DATE,
                 PAY_RECEIVE,
                 INSTRUMENT_TYPE,
                 INSTRUMENT_NO,
                 CHARGES_DETAILS,
                 OUR_CORRESPONDENT,
                 ACC_WITH_INSTN1,
                 ACC_WITH_INSTN2,
                 ACC_WITH_INSTN3,
                 ACC_WITH_INSTN4,
                 ACC_WITH_INSTN5,
                 RCVR_CORRESP1,
                 RCVR_CORRESP2,
                 RCVR_CORRESP3,
                 RCVR_CORRESP4,
                 RCVR_CORRESP5,
                 INTERMEDIARY1,
                 INTERMEDIARY2,
                 INTERMEDIARY3,
                 INTERMEDIARY4,
                 INTERMEDIARY5,
                 SNDR_TO_RCVR_INFO1,
                 SNDR_TO_RCVR_INFO2,
                 SNDR_TO_RCVR_INFO3,
                 SNDR_TO_RCVR_INFO4,
                 SNDR_TO_RCVR_INFO5,
                 SNDR_TO_RCVR_INFO6,
                 BENEF_INSTITUTION1,
                 BENEF_INSTITUTION2,
                 BENEF_INSTITUTION3,
                 BENEF_INSTITUTION4,
                 BENEF_INSTITUTION5,
                 ULT_BENEFICIARY1,
                 ULT_BENEFICIARY2,
                 ULT_BENEFICIARY3,
                 ULT_BENEFICIARY4,
                 ULT_BENEFICIARY5,
                 ORDERING_INSTITUTION1,
                 ORDERING_INSTITUTION2,
                 ORDERING_INSTITUTION3,
                 ORDERING_INSTITUTION4,
                 ORDERING_INSTITUTION5,
                 INT_REIM_INST1,
                 INT_REIM_INST2,
                 INT_REIM_INST3,
                 INT_REIM_INST4,
                 INT_REIM_INST5,
                 ORDERING_CUSTOMER1,
                 ORDERING_CUSTOMER2,
                 ORDERING_CUSTOMER3,
                 ORDERING_CUSTOMER4,
                 ORDERING_CUSTOMER5,
                 PAYMENT_DETAILS1,
                 PAYMENT_DETAILS2,
                 PAYMENT_DETAILS3,
                 PAYMENT_DETAILS4,
                 ERI_CCY,
                 ERI_AMOUNT,
                 BENEF_INST1_FOR_COVER,
                 BENEF_INST2_FOR_COVER,
                 BENEF_INST3_FOR_COVER,
                 BENEF_INST4_FOR_COVER,
                 BENEF_INST5_FOR_COVER)
              VALUES
                (REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_NOSTRO.BIC_CODE,
                 1,
                 REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TXN_ACC,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.EXCH_RATE,
                 
                 L_TFR_AMT,
                 REC_ARCSETTLE.CR_VALUE_DT,
                 REC_ARCSETTLE1.PAY_RECEIVE,
                 REC_ARCSETTLE1.INSTRUMENT_TYPE,
                 REC_ARCSETTLE1.INSTRUMENT_NO,
                 REC_ARCSETTLE1.CHARGES_DETAILS,
                 REC_ARCSETTLE1.OUR_CORRESPONDENT,
                 REC_ARCSETTLE1.ACC_WITH_INSTN1,
                 REC_ARCSETTLE1.ACC_WITH_INSTN2,
                 REC_ARCSETTLE1.ACC_WITH_INSTN3,
                 REC_ARCSETTLE1.ACC_WITH_INSTN4,
                 REC_ARCSETTLE1.ACC_WITH_INSTN5,
                 REC_ARCSETTLE1.RCVR_CORRESP1,
                 REC_ARCSETTLE1.RCVR_CORRESP2,
                 REC_ARCSETTLE1.RCVR_CORRESP3,
                 REC_ARCSETTLE1.RCVR_CORRESP4,
                 REC_ARCSETTLE1.RCVR_CORRESP5,
                 REC_ARCSETTLE1.INTERMEDIARY1,
                 REC_ARCSETTLE1.INTERMEDIARY2,
                 REC_ARCSETTLE1.INTERMEDIARY3,
                 REC_ARCSETTLE1.INTERMEDIARY4,
                 REC_ARCSETTLE1.INTERMEDIARY5,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO1,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO2,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO3,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO4,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO5,
                 REC_ARCSETTLE1.SNDR_TO_RCVR_INFO6,
                 REC_ARCSETTLE1.BENEF_INSTITUTION1,
                 REC_ARCSETTLE1.BENEF_INSTITUTION2,
                 REC_ARCSETTLE1.BENEF_INSTITUTION3,
                 REC_ARCSETTLE1.BENEF_INSTITUTION4,
                 REC_ARCSETTLE1.BENEF_INSTITUTION5,
                 REC_ARCSETTLE1.ULT_BENEFICIARY1,
                 REC_ARCSETTLE1.ULT_BENEFICIARY2,
                 REC_ARCSETTLE1.ULT_BENEFICIARY3,
                 REC_ARCSETTLE1.ULT_BENEFICIARY4,
                 REC_ARCSETTLE1.ULT_BENEFICIARY5,
                 REC_ARCSETTLE1.ORDERING_INSTITUTION1,
                 REC_ARCSETTLE1.ORDERING_INSTITUTION2,
                 REC_ARCSETTLE1.ORDERING_INSTITUTION3,
                 REC_ARCSETTLE1.ORDERING_INSTITUTION4,
                 REC_ARCSETTLE1.ORDERING_INSTITUTION5,
                 REC_ARCSETTLE1.INT_REIM_INST1,
                 REC_ARCSETTLE1.INT_REIM_INST2,
                 REC_ARCSETTLE1.INT_REIM_INST3,
                 REC_ARCSETTLE1.INT_REIM_INST4,
                 REC_ARCSETTLE1.INT_REIM_INST5,
                 REC_ARCSETTLE1.ORDERING_CUSTOMER1,
                 REC_ARCSETTLE1.ORDERING_CUSTOMER2,
                 REC_ARCSETTLE1.ORDERING_CUSTOMER3,
                 REC_ARCSETTLE1.ORDERING_CUSTOMER4,
                 REC_ARCSETTLE1.ORDERING_CUSTOMER5,
                 REC_ARCSETTLE1.PAYMENT_DETAILS1,
                 REC_ARCSETTLE1.PAYMENT_DETAILS2,
                 REC_ARCSETTLE1.PAYMENT_DETAILS3,
                 REC_ARCSETTLE1.PAYMENT_DETAILS4,
                 REC_ARCSETTLE1.ERI_CCY,
                 REC_ARCSETTLE1.ERI_AMOUNT,
                 REC_ARCSETTLE1.BENEF_INST1_FOR_COVER,
                 REC_ARCSETTLE1.BENEF_INST2_FOR_COVER,
                 REC_ARCSETTLE1.BENEF_INST3_FOR_COVER,
                 REC_ARCSETTLE1.BENEF_INST4_FOR_COVER,
                 REC_ARCSETTLE1.BENEF_INST5_FOR_COVER);
              LO_MESSAGE := 'CUST_TRANSFER';
              BEGIN
                SELECT *
                  INTO REC_RECEIVER
                  FROM ISTMS_BIC_DIRECTORY
                 WHERE BIC_CODE = REC_ARCSETTLE.RECEIVER;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Could not get bic details of the receiver ' ||
                      REC_ARCSETTLE.RECEIVER);
              END;
              DBG('Inserting into mstbs_msg_handoff for CUST_TRANSFER after COVER');
              INSERT INTO MSTBS_MSG_HANDOFF
                (BRANCH,
                 REFERENCE_NO,
                 ESN,
                 MSG_TYPE,
                 RECEIVER,
                 NAME,
                 SERIAL_NO,
                 CCY,
                 PRODUCT,
                 AMOUNT,
                 MEDIA,
                 PRIORITY,
                 MODULE,
                 ADDRESS1,
                 ADDRESS2,
                 ADDRESS3,
                 ADDRESS4,
                 FORMAT,
                 DIRECTIVE_STATUS,
                 PROCESSED_FLAG,
                 SUPPRESS_FLAG)
              VALUES
                (REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_RECEIVER.BIC_CODE,
                 REC_RECEIVER.BANK_NAME,
                 1,
                 REC_DERTLTELLER.TXN_CCY,
                 SUBSTR(REC_DERTLTELLER.XREF, 4, 4)
                 
                ,
                 L_TFR_AMT,
                 LO_MEDIUM,
                 1,
                 'RT',
                 REC_RECEIVER.BIC_CODE,
                 NULL,
                 NULL,
                 NULL,
                 '',
                 'B',
                 'N',
                 'N');
              DBG('Selecting CIF of remitter for field 50');
              BEGIN
                SELECT A.*
                  INTO L_RNAME
                  FROM STTMS_CUSTOMER A, STTMS_CUST_ACCOUNT B
                 WHERE B.CUST_AC_NO = REC_DERTLTELLER.OFS_ACC
                   AND B.BRANCH_CODE = REC_DERTLTELLER.OFS_BRANCH
                   AND B.CUST_NO = A.CUSTOMER_NO;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed in selection of remitter details');
              END;
            
              IF REC_ARCSETTLE.ORDERING_CUSTOMER1 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER2 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER3 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER4 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER5 IS NULL THEN
                REC_ARCSETTLE.ORDERING_CUSTOMER1 := L_RNAME.CUSTOMER_NAME1;
                REC_ARCSETTLE.ORDERING_CUSTOMER2 := L_RNAME.ADDRESS_LINE1;
                REC_ARCSETTLE.ORDERING_CUSTOMER3 := L_RNAME.ADDRESS_LINE2;
                REC_ARCSETTLE.ORDERING_CUSTOMER4 := L_RNAME.ADDRESS_LINE3;
                REC_ARCSETTLE.ORDERING_CUSTOMER5 := L_RNAME.ADDRESS_LINE4;
              END IF;
              DBG('Inserting into istbs_msgho for customer Transfer after COVER');
              INSERT INTO ISTBS_MSGHO
                (CONTRACT_REF_NO,
                 EVENT_SEQ_NO,
                 MSG_TYPE,
                 RECEIVER,
                 SERIAL_NO,
                 ACC_BRANCH,
                 ACCOUNT,
                 TAG_CCY,
                 ACC_CCY,
                 EX_RATE,
                 SETTLEMENT_AMT,
                 VALUE_DATE,
                 PAY_RECEIVE,
                 INSTRUMENT_TYPE,
                 INSTRUMENT_NO,
                 CHARGES_DETAILS,
                 OUR_CORRESPONDENT,
                 ACC_WITH_INSTN1,
                 ACC_WITH_INSTN2,
                 ACC_WITH_INSTN3,
                 ACC_WITH_INSTN4,
                 ACC_WITH_INSTN5,
                 RCVR_CORRESP1,
                 RCVR_CORRESP2,
                 RCVR_CORRESP3,
                 RCVR_CORRESP4,
                 RCVR_CORRESP5,
                 INTERMEDIARY1,
                 INTERMEDIARY2,
                 INTERMEDIARY3,
                 INTERMEDIARY4,
                 INTERMEDIARY5,
                 SNDR_TO_RCVR_INFO1,
                 SNDR_TO_RCVR_INFO2,
                 SNDR_TO_RCVR_INFO3,
                 SNDR_TO_RCVR_INFO4,
                 SNDR_TO_RCVR_INFO5,
                 SNDR_TO_RCVR_INFO6,
                 BENEF_INSTITUTION1,
                 BENEF_INSTITUTION2,
                 BENEF_INSTITUTION3,
                 BENEF_INSTITUTION4,
                 BENEF_INSTITUTION5,
                 ULT_BENEFICIARY1,
                 ULT_BENEFICIARY2,
                 ULT_BENEFICIARY3,
                 ULT_BENEFICIARY4,
                 ULT_BENEFICIARY5,
                 ORDERING_INSTITUTION1,
                 ORDERING_INSTITUTION2,
                 ORDERING_INSTITUTION3,
                 ORDERING_INSTITUTION4,
                 ORDERING_INSTITUTION5,
                 INT_REIM_INST1,
                 INT_REIM_INST2,
                 INT_REIM_INST3,
                 INT_REIM_INST4,
                 INT_REIM_INST5,
                 ORDERING_CUSTOMER1,
                 ORDERING_CUSTOMER2,
                 ORDERING_CUSTOMER3,
                 ORDERING_CUSTOMER4,
                 ORDERING_CUSTOMER5,
                 PAYMENT_DETAILS1,
                 PAYMENT_DETAILS2,
                 PAYMENT_DETAILS3,
                 PAYMENT_DETAILS4,
                 ERI_CCY,
                 ERI_AMOUNT,
                 BENEF_INST1_FOR_COVER,
                 BENEF_INST2_FOR_COVER,
                 BENEF_INST3_FOR_COVER,
                 BENEF_INST4_FOR_COVER,
                 BENEF_INST5_FOR_COVER)
              VALUES
                (REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_RECEIVER.BIC_CODE,
                 1,
                 REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TXN_ACC,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.EXCH_RATE,
                 
                 L_TFR_AMT,
                 REC_ARCSETTLE.CR_VALUE_DT,
                 REC_ARCSETTLE.PAY_RECEIVE,
                 REC_ARCSETTLE.INSTRUMENT_TYPE,
                 REC_ARCSETTLE.INSTRUMENT_NO,
                 REC_ARCSETTLE.CHARGES_DETAILS,
                 REC_NOSTRO.BIC_CODE,
                 REC_ARCSETTLE.ACC_WITH_INSTN1,
                 REC_ARCSETTLE.ACC_WITH_INSTN2,
                 REC_ARCSETTLE.ACC_WITH_INSTN3,
                 REC_ARCSETTLE.ACC_WITH_INSTN4,
                 REC_ARCSETTLE.ACC_WITH_INSTN5,
                 REC_ARCSETTLE.RCVR_CORRESP1,
                 REC_ARCSETTLE.RCVR_CORRESP2,
                 REC_ARCSETTLE.RCVR_CORRESP3,
                 REC_ARCSETTLE.RCVR_CORRESP4,
                 REC_ARCSETTLE.RCVR_CORRESP5,
                 REC_ARCSETTLE.INTERMEDIARY1,
                 REC_ARCSETTLE.INTERMEDIARY2,
                 REC_ARCSETTLE.INTERMEDIARY3,
                 REC_ARCSETTLE.INTERMEDIARY4,
                 REC_ARCSETTLE.INTERMEDIARY5,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO1,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO2,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO3,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO4,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO5,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO6,
                 REC_ARCSETTLE.BENEF_INSTITUTION1,
                 REC_ARCSETTLE.BENEF_INSTITUTION2,
                 REC_ARCSETTLE.BENEF_INSTITUTION3,
                 REC_ARCSETTLE.BENEF_INSTITUTION4,
                 REC_ARCSETTLE.BENEF_INSTITUTION5,
                 REC_ARCSETTLE.ULT_BENEFICIARY1,
                 REC_ARCSETTLE.ULT_BENEFICIARY2,
                 REC_ARCSETTLE.ULT_BENEFICIARY3,
                 REC_ARCSETTLE.ULT_BENEFICIARY4,
                 REC_ARCSETTLE.ULT_BENEFICIARY5,
                 REC_ARCSETTLE.ORDERING_INSTITUTION1,
                 REC_ARCSETTLE.ORDERING_INSTITUTION2,
                 REC_ARCSETTLE.ORDERING_INSTITUTION3,
                 REC_ARCSETTLE.ORDERING_INSTITUTION4,
                 REC_ARCSETTLE.ORDERING_INSTITUTION5,
                 REC_ARCSETTLE.INT_REIM_INST1,
                 REC_ARCSETTLE.INT_REIM_INST2,
                 REC_ARCSETTLE.INT_REIM_INST3,
                 REC_ARCSETTLE.INT_REIM_INST4,
                 REC_ARCSETTLE.INT_REIM_INST5,
                 REC_ARCSETTLE.ORDERING_CUSTOMER1,
                 REC_ARCSETTLE.ORDERING_CUSTOMER2,
                 REC_ARCSETTLE.ORDERING_CUSTOMER3,
                 REC_ARCSETTLE.ORDERING_CUSTOMER4,
                 REC_ARCSETTLE.ORDERING_CUSTOMER5,
                 REC_ARCSETTLE.PAYMENT_DETAILS1,
                 REC_ARCSETTLE.PAYMENT_DETAILS2,
                 REC_ARCSETTLE.PAYMENT_DETAILS3,
                 REC_ARCSETTLE.PAYMENT_DETAILS4,
                 REC_ARCSETTLE.ERI_CCY,
                 REC_ARCSETTLE.ERI_AMOUNT,
                 REC_ARCSETTLE.BENEF_INST1_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST2_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST3_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST4_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST5_FOR_COVER);
              DBG('Inserting into istbs_contract_details after COVER');
              INSERT INTO ISTBS_CONTRACT_DETAILS
                (CONTRACT_REF_NO,
                 EVENT_SEQ_NO,
                 AMOUNT_TAG,
                 BANK_OPER_CODE,
                 INSTR_CODE,
                 TRAN_TYPE_CODE,
                 REGULATORY_REP1,
                 REGULATORY_REP2,
                 REGULATORY_REP3,
                 ENVELOPE_CONTENTS1,
                 ENVELOPE_CONTENTS2,
                 ENVELOPE_CONTENTS3,
                 ENVELOPE_CONTENTS4,
                 ENVELOPE_CONTENTS5,
                 SNDR_CHGS1,
                 SNDR_CHGS2,
                 SNDR_CHGS3,
                 SNDR_CHGS4,
                 SNDR_CHGS5,
                 CCY_SNDR_CHGS1,
                 CCY_SNDR_CHGS2,
                 CCY_SNDR_CHGS3,
                 CCY_SNDR_CHGS4,
                 CCY_SNDR_CHGS5,
                 RCVR_CHGS1,
                 CCY_RCVR_CHGS1)
              VALUES
                (REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 'TXN_AMT',
                 REC_ARCSETTLE.BANK_OPER_CODE,
                 REC_ARCSETTLE.INSTR_CODE,
                 REC_ARCSETTLE.TRAN_TYPE_CODE,
                 REC_ARCSETTLE.REGULATORY_REP1,
                 REC_ARCSETTLE.REGULATORY_REP2,
                 REC_ARCSETTLE.REGULATORY_REP3,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS1,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS2,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS3,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS4,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS5,
                 L_SNDRCHG1,
                 L_SNDRCHG2,
                 L_SNDRCHG3,
                 L_SNDRCHG4,
                 L_SNDRCHG5,
                 L_SNDRCHGCCY1,
                 L_SNDRCHGCCY2,
                 L_SNDRCHGCCY3,
                 L_SNDRCHGCCY4,
                 L_SNDRCHGCCY5,
                 L_RVRCHG1,
                 L_RVRCHGCCY1);
            ELSE
              DBG('bic of nostro = receiver send mt100 to reciver');
              LO_MESSAGE := 'CUST_TRANSFER';
              BEGIN
                SELECT *
                  INTO REC_RECEIVER
                  FROM ISTMS_BIC_DIRECTORY
                 WHERE BIC_CODE = REC_ARCSETTLE.RECEIVER;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Could not get bic details of the receiver ' ||
                      REC_ARCSETTLE.RECEIVER);
              END;
              DBG('Inserting into mstbs_msg_handoff for CUST_TRANSFER WITHOUT COVER');
              DBG('Selecting CIF of remitter for field 50');
              BEGIN
                SELECT A.*
                  INTO L_RNAME
                  FROM STTMS_CUSTOMER A, STTMS_CUST_ACCOUNT B
                 WHERE B.CUST_AC_NO = REC_DERTLTELLER.OFS_ACC
                   AND B.BRANCH_CODE = REC_DERTLTELLER.OFS_BRANCH
                   AND B.CUST_NO = A.CUSTOMER_NO;
              
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed in selection of remitter details');
              END;
            
              IF REC_ARCSETTLE.ORDERING_CUSTOMER1 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER2 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER3 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER4 ||
                 REC_ARCSETTLE.ORDERING_CUSTOMER5 IS NULL THEN
                REC_ARCSETTLE.ORDERING_CUSTOMER1 := L_RNAME.CUSTOMER_NAME1;
                REC_ARCSETTLE.ORDERING_CUSTOMER2 := L_RNAME.ADDRESS_LINE1;
                REC_ARCSETTLE.ORDERING_CUSTOMER3 := L_RNAME.ADDRESS_LINE2;
                REC_ARCSETTLE.ORDERING_CUSTOMER4 := L_RNAME.ADDRESS_LINE3;
                REC_ARCSETTLE.ORDERING_CUSTOMER5 := L_RNAME.ADDRESS_LINE4;
              END IF;
            
              INSERT INTO MSTBS_MSG_HANDOFF
                (BRANCH,
                 REFERENCE_NO,
                 ESN,
                 MSG_TYPE,
                 RECEIVER,
                 NAME,
                 SERIAL_NO,
                 CCY,
                 PRODUCT,
                 AMOUNT,
                 MEDIA,
                 PRIORITY,
                 MODULE,
                 ADDRESS1,
                 ADDRESS2,
                 ADDRESS3,
                 ADDRESS4,
                 FORMAT,
                 DIRECTIVE_STATUS,
                 PROCESSED_FLAG,
                 SUPPRESS_FLAG)
              VALUES
                (REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_RECEIVER.BIC_CODE,
                 REC_RECEIVER.BANK_NAME,
                 1,
                 REC_DERTLTELLER.TXN_CCY,
                 SUBSTR(REC_DERTLTELLER.XREF, 4, 4)
                 
                ,
                 L_TFR_AMT,
                 LO_MEDIUM,
                 1,
                 'RT',
                 REC_RECEIVER.BIC_CODE,
                 NULL,
                 NULL,
                 NULL,
                 '',
                 'B',
                 'N',
                 'N');
              DBG('Inserting into istbs_msgho for customer Transfer without COVER');
              INSERT INTO ISTBS_MSGHO
                (CONTRACT_REF_NO,
                 EVENT_SEQ_NO,
                 MSG_TYPE,
                 RECEIVER,
                 SERIAL_NO,
                 ACC_BRANCH,
                 ACCOUNT,
                 TAG_CCY,
                 ACC_CCY,
                 EX_RATE,
                 SETTLEMENT_AMT,
                 VALUE_DATE,
                 PAY_RECEIVE,
                 INSTRUMENT_TYPE,
                 INSTRUMENT_NO,
                 CHARGES_DETAILS,
                 OUR_CORRESPONDENT,
                 ACC_WITH_INSTN1,
                 ACC_WITH_INSTN2,
                 ACC_WITH_INSTN3,
                 ACC_WITH_INSTN4,
                 ACC_WITH_INSTN5,
                 RCVR_CORRESP1,
                 RCVR_CORRESP2,
                 RCVR_CORRESP3,
                 RCVR_CORRESP4,
                 RCVR_CORRESP5,
                 INTERMEDIARY1,
                 INTERMEDIARY2,
                 INTERMEDIARY3,
                 INTERMEDIARY4,
                 INTERMEDIARY5,
                 SNDR_TO_RCVR_INFO1,
                 SNDR_TO_RCVR_INFO2,
                 SNDR_TO_RCVR_INFO3,
                 SNDR_TO_RCVR_INFO4,
                 SNDR_TO_RCVR_INFO5,
                 SNDR_TO_RCVR_INFO6,
                 BENEF_INSTITUTION1,
                 BENEF_INSTITUTION2,
                 BENEF_INSTITUTION3,
                 BENEF_INSTITUTION4,
                 BENEF_INSTITUTION5,
                 ULT_BENEFICIARY1,
                 ULT_BENEFICIARY2,
                 ULT_BENEFICIARY3,
                 ULT_BENEFICIARY4,
                 ULT_BENEFICIARY5,
                 ORDERING_INSTITUTION1,
                 ORDERING_INSTITUTION2,
                 ORDERING_INSTITUTION3,
                 ORDERING_INSTITUTION4,
                 ORDERING_INSTITUTION5,
                 INT_REIM_INST1,
                 INT_REIM_INST2,
                 INT_REIM_INST3,
                 INT_REIM_INST4,
                 INT_REIM_INST5,
                 ORDERING_CUSTOMER1,
                 ORDERING_CUSTOMER2,
                 ORDERING_CUSTOMER3,
                 ORDERING_CUSTOMER4,
                 ORDERING_CUSTOMER5,
                 PAYMENT_DETAILS1,
                 PAYMENT_DETAILS2,
                 PAYMENT_DETAILS3,
                 PAYMENT_DETAILS4,
                 ERI_CCY,
                 ERI_AMOUNT,
                 BENEF_INST1_FOR_COVER,
                 BENEF_INST2_FOR_COVER,
                 BENEF_INST3_FOR_COVER,
                 BENEF_INST4_FOR_COVER,
                 BENEF_INST5_FOR_COVER)
              VALUES
                (REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 LO_MESSAGE,
                 REC_RECEIVER.BIC_CODE,
                 1,
                 REC_DERTLTELLER.TXN_BRANCH,
                 REC_DERTLTELLER.TXN_ACC,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.TXN_CCY,
                 REC_DERTLTELLER.EXCH_RATE,
                 
                 L_TFR_AMT,
                 REC_ARCSETTLE.CR_VALUE_DT,
                 REC_ARCSETTLE.PAY_RECEIVE,
                 REC_ARCSETTLE.INSTRUMENT_TYPE,
                 REC_ARCSETTLE.INSTRUMENT_NO,
                 REC_ARCSETTLE.CHARGES_DETAILS,
                 REC_ARCSETTLE.OUR_CORRESPONDENT,
                 REC_ARCSETTLE.ACC_WITH_INSTN1,
                 REC_ARCSETTLE.ACC_WITH_INSTN2,
                 REC_ARCSETTLE.ACC_WITH_INSTN3,
                 REC_ARCSETTLE.ACC_WITH_INSTN4,
                 REC_ARCSETTLE.ACC_WITH_INSTN5,
                 REC_ARCSETTLE.RCVR_CORRESP1,
                 REC_ARCSETTLE.RCVR_CORRESP2,
                 REC_ARCSETTLE.RCVR_CORRESP3,
                 REC_ARCSETTLE.RCVR_CORRESP4,
                 REC_ARCSETTLE.RCVR_CORRESP5,
                 REC_ARCSETTLE.INTERMEDIARY1,
                 REC_ARCSETTLE.INTERMEDIARY2,
                 REC_ARCSETTLE.INTERMEDIARY3,
                 REC_ARCSETTLE.INTERMEDIARY4,
                 REC_ARCSETTLE.INTERMEDIARY5,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO1,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO2,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO3,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO4,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO5,
                 REC_ARCSETTLE.SNDR_TO_RCVR_INFO6,
                 REC_ARCSETTLE.BENEF_INSTITUTION1,
                 REC_ARCSETTLE.BENEF_INSTITUTION2,
                 REC_ARCSETTLE.BENEF_INSTITUTION3,
                 REC_ARCSETTLE.BENEF_INSTITUTION4,
                 REC_ARCSETTLE.BENEF_INSTITUTION5,
                 REC_ARCSETTLE.ULT_BENEFICIARY1,
                 REC_ARCSETTLE.ULT_BENEFICIARY2,
                 REC_ARCSETTLE.ULT_BENEFICIARY3,
                 REC_ARCSETTLE.ULT_BENEFICIARY4,
                 REC_ARCSETTLE.ULT_BENEFICIARY5,
                 REC_ARCSETTLE.ORDERING_INSTITUTION1,
                 REC_ARCSETTLE.ORDERING_INSTITUTION2,
                 REC_ARCSETTLE.ORDERING_INSTITUTION3,
                 REC_ARCSETTLE.ORDERING_INSTITUTION4,
                 REC_ARCSETTLE.ORDERING_INSTITUTION5,
                 REC_ARCSETTLE.INT_REIM_INST1,
                 REC_ARCSETTLE.INT_REIM_INST2,
                 REC_ARCSETTLE.INT_REIM_INST3,
                 REC_ARCSETTLE.INT_REIM_INST4,
                 REC_ARCSETTLE.INT_REIM_INST5,
                 REC_ARCSETTLE.ORDERING_CUSTOMER1,
                 REC_ARCSETTLE.ORDERING_CUSTOMER2,
                 REC_ARCSETTLE.ORDERING_CUSTOMER3,
                 REC_ARCSETTLE.ORDERING_CUSTOMER4,
                 REC_ARCSETTLE.ORDERING_CUSTOMER5,
                 REC_ARCSETTLE.PAYMENT_DETAILS1,
                 REC_ARCSETTLE.PAYMENT_DETAILS2,
                 REC_ARCSETTLE.PAYMENT_DETAILS3,
                 REC_ARCSETTLE.PAYMENT_DETAILS4,
                 REC_ARCSETTLE.ERI_CCY,
                 REC_ARCSETTLE.ERI_AMOUNT,
                 REC_ARCSETTLE.BENEF_INST1_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST2_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST3_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST4_FOR_COVER,
                 REC_ARCSETTLE.BENEF_INST5_FOR_COVER);
              DBG('Inserting into istbs_contract_details without COVER');
              INSERT INTO ISTBS_CONTRACT_DETAILS
                (CONTRACT_REF_NO,
                 EVENT_SEQ_NO,
                 AMOUNT_TAG,
                 BANK_OPER_CODE,
                 INSTR_CODE,
                 TRAN_TYPE_CODE,
                 REGULATORY_REP1,
                 REGULATORY_REP2,
                 REGULATORY_REP3,
                 ENVELOPE_CONTENTS1,
                 ENVELOPE_CONTENTS2,
                 ENVELOPE_CONTENTS3,
                 ENVELOPE_CONTENTS4,
                 ENVELOPE_CONTENTS5,
                 SNDR_CHGS1,
                 SNDR_CHGS2,
                 SNDR_CHGS3,
                 SNDR_CHGS4,
                 SNDR_CHGS5,
                 CCY_SNDR_CHGS1,
                 CCY_SNDR_CHGS2,
                 CCY_SNDR_CHGS3,
                 CCY_SNDR_CHGS4,
                 CCY_SNDR_CHGS5,
                 RCVR_CHGS1,
                 CCY_RCVR_CHGS1)
              VALUES
                (REC_DERTLTELLER.TRN_REF_NO,
                 1,
                 'TXN_AMT',
                 REC_ARCSETTLE.BANK_OPER_CODE,
                 REC_ARCSETTLE.INSTR_CODE,
                 REC_ARCSETTLE.TRAN_TYPE_CODE,
                 REC_ARCSETTLE.REGULATORY_REP1,
                 REC_ARCSETTLE.REGULATORY_REP2,
                 REC_ARCSETTLE.REGULATORY_REP3,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS1,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS2,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS3,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS4,
                 REC_ARCSETTLE.ENVELOPE_CONTENTS5,
                 L_SNDRCHG1,
                 L_SNDRCHG2,
                 L_SNDRCHG3,
                 L_SNDRCHG4,
                 L_SNDRCHG5,
                 L_SNDRCHGCCY1,
                 L_SNDRCHGCCY2,
                 L_SNDRCHGCCY3,
                 L_SNDRCHGCCY4,
                 L_SNDRCHGCCY5,
                 L_RVRCHG1,
                 L_RVRCHGCCY1);
            END IF;
          END IF;
        
        END IF;
      ELSE
      
        DBG('This is ODC Transaction Dr the Customer Cr the Nostro Sending Dr advice to the Customer');
        DBG('Receiver gets the MT100 or MT103 IF CIF OF NOSTRO <> CIF OF RECIEVER Send MT202 to The CIF Of Receiver');
        IF PKG_ARC_ROW.GENERATE_TRANSACTION_ADVICE = 'Y' THEN
          PR_INS_MSG_HANDOFF('DR ADVICE');
        END IF;
      
        SELECT DECODE(B.AC_CLASS_TYPE, 'N', 'Y', 'N')
          INTO NOSTROFLAG
          FROM STTBS_ACCOUNT ACC, STTMS_ACCOUNT_CLASS B
         WHERE AC_OR_GL = 'A'
           AND AC_GL_NO = REC_DERTLTELLER.TXN_ACC
           AND BRANCH_CODE = REC_DERTLTELLER.TXN_BRANCH
           AND B.ACCOUNT_CLASS = ACC.AC_CLASS;
        LO_MEDIUM := 'SWIFT';
        BEGIN
          SELECT CUST_NO
            INTO L_NCIF
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = REC_DERTLTELLER.TXN_ACC
             AND BRANCH_CODE = REC_DERTLTELLER.TXN_BRANCH;
        
        EXCEPTION
          WHEN OTHERS THEN
          
            DBG('Failed to get the CIF of the Nostro');
        END;
        DBG('Getting the bic code ' || L_NCIF);
        BEGIN
          SELECT *
            INTO REC_NOSTRO
            FROM ISTMS_BIC_DIRECTORY
           WHERE CUSTOMER_NO = L_NCIF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed while getting the nostro bic');
        END;
        UPDATE CSTBS_ARC_SETTLE
           SET OUR_CORRESPONDENT = L_NCIF
         WHERE XREF = P_XREF;
      
        L_TFR_AMT := REC_DERTLTELLER.TXN_AMOUNT;
        DBG('Set transfer amount for 33 B as ' || L_TFR_AMT);
        PR_FETCH_CHG_DETAILS(REC_DERTLTELLER,
                             L_SNDRCHG1,
                             L_SNDRCHGCCY1,
                             L_SNDRCHG2,
                             L_SNDRCHGCCY2,
                             L_SNDRCHG3,
                             L_SNDRCHGCCY3,
                             L_SNDRCHG4,
                             L_SNDRCHGCCY4,
                             L_SNDRCHG5,
                             L_SNDRCHGCCY5,
                             L_RVRCHG1,
                             L_RVRCHGCCY1
                             
                             );
      
        IF PKG_GENERATE_MT101 = 'Y' THEN
          DBG('Generating MT101 request for transfer');
          LO_MESSAGE := 'REQ_TRANSFER';
          BEGIN
            SELECT *
              INTO REC_RECEIVER
              FROM ISTMS_BIC_DIRECTORY
             WHERE BIC_CODE =
                   NVL(REC_ARCSETTLE.RECEIVER, ILPKS_THIRD_PARTY.G_BIC_CODE);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Could not get bic details of the receiver ' ||
                  REC_ARCSETTLE.RECEIVER);
          END;
          DBG('Inserting into mstbs_msg_handoff for REQ_TRANSFER WITHOUT COVER');
          DBG('Selecting CIF of remitter for field 50');
          BEGIN
            SELECT A.*
              INTO L_RNAME
              FROM STTMS_CUSTOMER A, STTMS_CUST_ACCOUNT B
             WHERE B.CUST_AC_NO = REC_DERTLTELLER.OFS_ACC
               AND B.BRANCH_CODE = REC_DERTLTELLER.OFS_BRANCH
               AND B.CUST_NO = A.CUSTOMER_NO;
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in selection of remitter details');
          END;
        
          IF REC_ARCSETTLE.ORDERING_CUSTOMER1 ||
             REC_ARCSETTLE.ORDERING_CUSTOMER2 ||
             REC_ARCSETTLE.ORDERING_CUSTOMER3 ||
             REC_ARCSETTLE.ORDERING_CUSTOMER4 ||
             REC_ARCSETTLE.ORDERING_CUSTOMER5 IS NULL THEN
            REC_ARCSETTLE.ORDERING_CUSTOMER1 := L_RNAME.CUSTOMER_NAME1;
            REC_ARCSETTLE.ORDERING_CUSTOMER2 := L_RNAME.ADDRESS_LINE1;
            REC_ARCSETTLE.ORDERING_CUSTOMER3 := L_RNAME.ADDRESS_LINE2;
            REC_ARCSETTLE.ORDERING_CUSTOMER4 := L_RNAME.ADDRESS_LINE3;
            REC_ARCSETTLE.ORDERING_CUSTOMER5 := L_RNAME.ADDRESS_LINE4;
          END IF;
        
          INSERT INTO MSTBS_MSG_HANDOFF
            (BRANCH,
             REFERENCE_NO,
             ESN,
             MSG_TYPE,
             RECEIVER,
             NAME,
             SERIAL_NO,
             CCY,
             PRODUCT,
             AMOUNT,
             MEDIA,
             PRIORITY,
             MODULE,
             ADDRESS1,
             ADDRESS2,
             ADDRESS3,
             ADDRESS4,
             FORMAT,
             DIRECTIVE_STATUS,
             PROCESSED_FLAG,
             SUPPRESS_FLAG)
          VALUES
            (REC_DERTLTELLER.TXN_BRANCH,
             REC_DERTLTELLER.TRN_REF_NO,
             1,
             LO_MESSAGE,
             REC_RECEIVER.BIC_CODE,
             REC_RECEIVER.BANK_NAME,
             1,
             REC_DERTLTELLER.TXN_CCY,
             SUBSTR(REC_DERTLTELLER.TRN_REF_NO, 4, 4)
             
            ,
             L_TFR_AMT,
             LO_MEDIUM,
             1,
             'RT',
             REC_RECEIVER.BIC_CODE,
             NULL,
             NULL,
             NULL,
             '',
             'B',
             'N',
             'N');
          DBG('Inserting into istbs_msgho for Request for Transfer without COVER');
          DBG('value date from the detb_rtl_teller table' ||
              REC_DERTLTELLER.VALUE_DT);
          INSERT INTO ISTBS_MSGHO
            (CONTRACT_REF_NO,
             EVENT_SEQ_NO,
             MSG_TYPE,
             RECEIVER,
             SERIAL_NO,
             ACC_BRANCH,
             ACCOUNT,
             TAG_CCY,
             ACC_CCY,
             EX_RATE,
             SETTLEMENT_AMT,
             VALUE_DATE,
             PAY_RECEIVE,
             INSTRUMENT_TYPE,
             INSTRUMENT_NO,
             CHARGES_DETAILS,
             OUR_CORRESPONDENT,
             ACC_WITH_INSTN1,
             ACC_WITH_INSTN2,
             ACC_WITH_INSTN3,
             ACC_WITH_INSTN4,
             ACC_WITH_INSTN5,
             RCVR_CORRESP1,
             RCVR_CORRESP2,
             RCVR_CORRESP3,
             RCVR_CORRESP4,
             RCVR_CORRESP5,
             INTERMEDIARY1,
             INTERMEDIARY2,
             INTERMEDIARY3,
             INTERMEDIARY4,
             INTERMEDIARY5,
             SNDR_TO_RCVR_INFO1,
             SNDR_TO_RCVR_INFO2,
             SNDR_TO_RCVR_INFO3,
             SNDR_TO_RCVR_INFO4,
             SNDR_TO_RCVR_INFO5,
             SNDR_TO_RCVR_INFO6,
             BENEF_INSTITUTION1,
             BENEF_INSTITUTION2,
             BENEF_INSTITUTION3,
             BENEF_INSTITUTION4,
             BENEF_INSTITUTION5,
             ULT_BENEFICIARY1,
             ULT_BENEFICIARY2,
             ULT_BENEFICIARY3,
             ULT_BENEFICIARY4,
             ULT_BENEFICIARY5,
             ORDERING_INSTITUTION1,
             ORDERING_INSTITUTION2,
             ORDERING_INSTITUTION3,
             ORDERING_INSTITUTION4,
             ORDERING_INSTITUTION5,
             INT_REIM_INST1,
             INT_REIM_INST2,
             INT_REIM_INST3,
             INT_REIM_INST4,
             INT_REIM_INST5,
             ORDERING_CUSTOMER1,
             ORDERING_CUSTOMER2,
             ORDERING_CUSTOMER3,
             ORDERING_CUSTOMER4,
             ORDERING_CUSTOMER5,
             PAYMENT_DETAILS1,
             PAYMENT_DETAILS2,
             PAYMENT_DETAILS3,
             PAYMENT_DETAILS4,
             ERI_CCY,
             ERI_AMOUNT,
             BENEF_INST1_FOR_COVER,
             BENEF_INST2_FOR_COVER,
             BENEF_INST3_FOR_COVER,
             BENEF_INST4_FOR_COVER,
             BENEF_INST5_FOR_COVER)
          VALUES
            (REC_DERTLTELLER.TRN_REF_NO,
             1,
             LO_MESSAGE,
             REC_RECEIVER.BIC_CODE,
             1,
             REC_DERTLTELLER.TXN_BRANCH,
             REC_DERTLTELLER.TXN_ACC,
             REC_DERTLTELLER.TXN_CCY,
             REC_DERTLTELLER.TXN_CCY,
             REC_DERTLTELLER.EXCH_RATE,
             
             L_TFR_AMT,
             REC_DERTLTELLER.VALUE_DT,
             REC_ARCSETTLE.PAY_RECEIVE,
             REC_ARCSETTLE.INSTRUMENT_TYPE,
             REC_ARCSETTLE.INSTRUMENT_NO,
             REC_ARCSETTLE.CHARGES_DETAILS,
             REC_ARCSETTLE.OUR_CORRESPONDENT,
             REC_ARCSETTLE.ACC_WITH_INSTN1,
             REC_ARCSETTLE.ACC_WITH_INSTN2,
             REC_ARCSETTLE.ACC_WITH_INSTN3,
             REC_ARCSETTLE.ACC_WITH_INSTN4,
             REC_ARCSETTLE.ACC_WITH_INSTN5,
             REC_ARCSETTLE.RCVR_CORRESP1,
             REC_ARCSETTLE.RCVR_CORRESP2,
             REC_ARCSETTLE.RCVR_CORRESP3,
             REC_ARCSETTLE.RCVR_CORRESP4,
             REC_ARCSETTLE.RCVR_CORRESP5,
             REC_ARCSETTLE.INTERMEDIARY1,
             REC_ARCSETTLE.INTERMEDIARY2,
             REC_ARCSETTLE.INTERMEDIARY3,
             REC_ARCSETTLE.INTERMEDIARY4,
             REC_ARCSETTLE.INTERMEDIARY5,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO1,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO2,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO3,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO4,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO5,
             REC_ARCSETTLE.SNDR_TO_RCVR_INFO6,
             REC_ARCSETTLE.BENEF_INSTITUTION1,
             REC_ARCSETTLE.BENEF_INSTITUTION2,
             REC_ARCSETTLE.BENEF_INSTITUTION3,
             REC_ARCSETTLE.BENEF_INSTITUTION4,
             REC_ARCSETTLE.BENEF_INSTITUTION5,
             REC_ARCSETTLE.ULT_BENEFICIARY1,
             REC_ARCSETTLE.ULT_BENEFICIARY2,
             REC_ARCSETTLE.ULT_BENEFICIARY3,
             REC_ARCSETTLE.ULT_BENEFICIARY4,
             REC_ARCSETTLE.ULT_BENEFICIARY5,
             REC_ARCSETTLE.ORDERING_INSTITUTION1,
             REC_ARCSETTLE.ORDERING_INSTITUTION2,
             REC_ARCSETTLE.ORDERING_INSTITUTION3,
             REC_ARCSETTLE.ORDERING_INSTITUTION4,
             REC_ARCSETTLE.ORDERING_INSTITUTION5,
             REC_ARCSETTLE.INT_REIM_INST1,
             REC_ARCSETTLE.INT_REIM_INST2,
             REC_ARCSETTLE.INT_REIM_INST3,
             REC_ARCSETTLE.INT_REIM_INST4,
             REC_ARCSETTLE.INT_REIM_INST5,
             REC_ARCSETTLE.ORDERING_CUSTOMER1,
             REC_ARCSETTLE.ORDERING_CUSTOMER2,
             REC_ARCSETTLE.ORDERING_CUSTOMER3,
             REC_ARCSETTLE.ORDERING_CUSTOMER4,
             REC_ARCSETTLE.ORDERING_CUSTOMER5,
             REC_ARCSETTLE.PAYMENT_DETAILS1,
             REC_ARCSETTLE.PAYMENT_DETAILS2,
             REC_ARCSETTLE.PAYMENT_DETAILS3,
             REC_ARCSETTLE.PAYMENT_DETAILS4,
             REC_ARCSETTLE.ERI_CCY,
             REC_ARCSETTLE.ERI_AMOUNT,
             REC_ARCSETTLE.BENEF_INST1_FOR_COVER,
             REC_ARCSETTLE.BENEF_INST2_FOR_COVER,
             REC_ARCSETTLE.BENEF_INST3_FOR_COVER,
             REC_ARCSETTLE.BENEF_INST4_FOR_COVER,
             REC_ARCSETTLE.BENEF_INST5_FOR_COVER);
          DBG('Inserting into istbs_contract_details without COVER');
          INSERT INTO ISTBS_CONTRACT_DETAILS
            (CONTRACT_REF_NO,
             EVENT_SEQ_NO,
             AMOUNT_TAG,
             BANK_OPER_CODE,
             INSTR_CODE,
             TRAN_TYPE_CODE,
             REGULATORY_REP1,
             REGULATORY_REP2,
             REGULATORY_REP3,
             ENVELOPE_CONTENTS1,
             ENVELOPE_CONTENTS2,
             ENVELOPE_CONTENTS3,
             ENVELOPE_CONTENTS4,
             ENVELOPE_CONTENTS5,
             SNDR_CHGS1,
             SNDR_CHGS2,
             SNDR_CHGS3,
             SNDR_CHGS4,
             SNDR_CHGS5,
             CCY_SNDR_CHGS1,
             CCY_SNDR_CHGS2,
             CCY_SNDR_CHGS3,
             CCY_SNDR_CHGS4,
             CCY_SNDR_CHGS5,
             RCVR_CHGS1,
             CCY_RCVR_CHGS1)
          VALUES
            (REC_DERTLTELLER.TRN_REF_NO,
             1,
             'TXN_AMT',
             REC_ARCSETTLE.BANK_OPER_CODE,
             REC_ARCSETTLE.INSTR_CODE,
             REC_ARCSETTLE.TRAN_TYPE_CODE,
             REC_ARCSETTLE.REGULATORY_REP1,
             REC_ARCSETTLE.REGULATORY_REP2,
             REC_ARCSETTLE.REGULATORY_REP3,
             REC_ARCSETTLE.ENVELOPE_CONTENTS1,
             REC_ARCSETTLE.ENVELOPE_CONTENTS2,
             REC_ARCSETTLE.ENVELOPE_CONTENTS3,
             REC_ARCSETTLE.ENVELOPE_CONTENTS4,
             REC_ARCSETTLE.ENVELOPE_CONTENTS5,
             L_SNDRCHG1,
             L_SNDRCHG2,
             L_SNDRCHG3,
             L_SNDRCHG4,
             L_SNDRCHG5,
             L_SNDRCHGCCY1,
             L_SNDRCHGCCY2,
             L_SNDRCHGCCY3,
             L_SNDRCHGCCY4,
             L_SNDRCHGCCY5,
             L_RVRCHG1,
             L_RVRCHGCCY1);
        END IF;
      
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('Exception in pr_msgins is ' || SQLERRM);
  END PR_MSGINS;

  PROCEDURE PR_MSGGEN(P_MSG_CUR    MSPKSS.MODULE_PROC_CURTYPE,
                      P_ERROR_CODE OUT VARCHAR2) IS
    CURSOR CR_MSGHO(P_REF VARCHAR2, P_MSG VARCHAR2) IS
      SELECT *
        FROM ISTBS_MSGHO
       WHERE CONTRACT_REF_NO = P_REF
         AND MSG_TYPE = P_MSG;
  
    REC_MSGHO   ISTBS_MSGHO%ROWTYPE;
    L_GEN_MT103 VARCHAR2(1);
    X           MSTBS_DLY_MSG_OUT%ROWTYPE;
  
    L_ERR_CODE  ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
  
    L_ERR_CODE  := NULL;
    L_ERR_PARAM := NULL;
    IF NOT GLOBALS_FRC.FN_GET_BRN_REC_WRP(GLOBAL.CURRENT_BRANCH,
                                          L_ERR_CODE,
                                          L_ERR_PARAM) THEN
      DEBUG.PR_DEBUG('AC', 'Failed in the FRC function..');
    ELSE
      DEBUG.PR_DEBUG('AC', 'Success from FRC..');
    END IF;
  
    FT_TRN := TRUE;
    FETCH P_MSG_CUR
      INTO X;
    OPEN CR_MSGHO(X.REFERENCE_NO, X.MSG_TYPE);
    FETCH CR_MSGHO
      INTO REC_MSGHO;
    CLOSE CR_MSGHO;
    DBG('Inside pr_msggen procedure ' || X.DCN);
    DBG('Message type ' || X.MSG_TYPE);
    DBG('Media ' || X.MEDIA);
    IF X.MEDIA = 'SWIFT' THEN
      IF X.MSG_TYPE = 'CUST_TRANSFER' THEN
        DBG('Checking if 103 is to be generated for ' || X.RECEIVER);
      
        BEGIN
          SELECT GEN_MT103
            INTO L_GEN_MT103
            FROM ISTMS_BIC_DIRECTORY
           WHERE BIC_CODE = X.RECEIVER;
          DBG('Flag in bic directory is ' || L_GEN_MT103);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In exception ' || SQLERRM);
            L_GEN_MT103 := NULL;
        END;
        IF L_GEN_MT103 IS NULL THEN
          DBG('Next chk for the branch ' || GLOBAL.CURRENT_BRANCH);
        
          L_GEN_MT103 := GLOBAL_FRC.G_TBL_STTM_BRANCH_REC.GEN_MT103;
        
        END IF;
      
        IF L_GEN_MT103 = 'Y' THEN
          DBG('Calling ispks_adv1.fn_mt103');
          IF NOT ISPKS_ADV1.FN_MT103(X, REC_MSGHO) THEN
          
            DBG('Failed in ispks_adv1.fn_mt103 generation');
          END IF;
        ELSE
          DBG('Calling ispks_adv1.fn_mt100');
          IF NOT ISPKS_ADV1.FN_MT100(X, REC_MSGHO) THEN
          
            DBG('Failed in ispks_adv1.fn_mt100 generation');
          END IF;
        END IF;
      ELSIF X.MSG_TYPE = 'COVER' THEN
        DBG('Calling ispks_adv1.fn_mt202');
        IF NOT ISPKS_ADV1.FN_MT202(X, REC_MSGHO) THEN
        
          DBG('Failed in ispks_adv1.fn_mt202 generation');
        END IF;
      
      ELSIF X.MSG_TYPE = 'REQ_TRANSFER' THEN
      
        IF PKG_GENERATE_MT101 = 'Y' THEN
          DBG('b4 generating 101');
          IF NOT ISPKS_ADV1.FN_MT101(X, REC_MSGHO) THEN
            DBG('Failed in ispks_adv1.fn_mt101 generation');
          
          END IF;
        
        END IF;
      END IF;
    
    END IF;
    IF X.MSG_TYPE IN ('DR ADVICE', 'CR ADVICE') THEN
      DBG('Calling Debit or credit advice ');
      FT_TRN := FALSE;
      PR_GEN_ADV_FOR_CONTRACT(X.REFERENCE_NO);
    END IF;
    DBG('Coming out of pr_msggen procedure');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in pr_msggen ' || SQLERRM);
      P_ERROR_CODE := 'DE-FT005';
  END PR_MSGGEN;

  PROCEDURE PR_GENERATE_ICDODCADVICE(P_TRN_REF_NO VARCHAR2) IS
    P_DLY_MSG_CUR MSTBS_MSG_HANDOFF%ROWTYPE;
    P_BAD_DCN     VARCHAR2(1000);
    CURSOR CUR_MSG IS
      SELECT * FROM MSTBS_DLY_MSG_OUT WHERE REFERENCE_NO = P_TRN_REF_NO;
  BEGIN
    DBG('IN pr_generate_icdodcadvice ' || P_TRN_REF_NO);
    OPEN CUR_MSG;
    LOOP
      FETCH CUR_MSG
        INTO P_DLY_MSG_CUR;
      EXIT WHEN CUR_MSG%NOTFOUND;
      DBG('Message Type is ' || P_DLY_MSG_CUR.MSG_TYPE);
      DBG('DCN is ' || P_DLY_MSG_CUR.DCN);
      IF P_DLY_MSG_CUR.MSG_TYPE IN ('COVER', 'CUST_TRANSFER') THEN
        FT_TRN := TRUE;
      ELSE
        FT_TRN := FALSE;
      END IF;
      IF NOT MSPKSS.FN_GEN_MSG_OUT(P_DLY_MSG_CUR, P_BAD_DCN) THEN
        DBG('Failed in mspks');
      END IF;
    END LOOP;
    DBG('END OF pr_generate_icdodcadvice');
  END PR_GENERATE_ICDODCADVICE;

  PROCEDURE PR_CHG_PICKUP_REQD(P_VALUE BOOLEAN) IS
  BEGIN
    PKG_CHG_PICKUP_REQD := P_VALUE;
  END;

  PROCEDURE PR_AUTH_REVERSAL_REQD(P_VALUE BOOLEAN) IS
  BEGIN
    PKG_AUTH_REVERSAL_REQD := P_VALUE;
  END;

  PROCEDURE PR_TRACK_ACCOUNT(TRN_REF_NO              IN VARCHAR2,
                             G_TRACK_CHARGE_ENTRIES  IN VARCHAR2,
                             G_TRACK_ACCOUNT_ENTRIES IN VARCHAR2) IS
    LACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    LACBR      STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    LAVAIL     CSTBS_AUTO_SETTLE_BLOCK.AMOUNT_AVAILABLE%TYPE;
    LCOMPONENT CSTBS_AUTO_SETTLE_BLOCK.COMPONENT%TYPE;
  
    LBAL_TXN       STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    LBAL_OFS       STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL      STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL_USED STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
    L_AVL_BAL_LEFT STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;
  
    L_TXN_BAL_DONE VARCHAR2(1) := 'N';
    L_OFS_BAL_DONE VARCHAR2(1) := 'N';
  
  BEGIN
    DBG('inside pr_track_account for ref no ' ||
        PKG_RTL_TELLER_REC.TRN_REF_NO);
    IF NVL(G_TRACK_ACCOUNT_ENTRIES, 'X') = 'Y' THEN
      LCOMPONENT := 'TRANSACTION';
    ELSIF NVL(G_TRACK_CHARGE_ENTRIES, 'X') = 'Y' THEN
      LCOMPONENT := 'CHARGE';
    END IF;
  
    IF NVL(PKG_NSF_TRACKED, 'N') = 'Y' THEN
      DBG('nsf tracking is there.. So updating available balance now..');
      DBG('pkg_rtl_teller_rec.txn_acc-->>>' || PKG_RTL_TELLER_REC.TXN_ACC);
    
      FOR EACH_REC IN (SELECT *
                         FROM CSTB_AUTO_SETTLE_BLOCK_TEMP
                        WHERE CONTRACT_REF_NO = TRN_REF_NO) LOOP
      
        DBG('each_rec.account_no : ' || EACH_REC.ACCOUNT_NO);
        DBG('each_rec.account_br : ' || EACH_REC.ACCOUNT_BR);
        DBG('each_rec.component : ' || EACH_REC.COMPONENT);
        DBG('each_rec.amount_due : ' || EACH_REC.AMOUNT_DUE);
        DBG('each_rec.amount_available : ' || EACH_REC.AMOUNT_AVAILABLE);
      
        L_AVL_BAL := 0;
      
        IF EACH_REC.ACCOUNT_NO = PKG_RTL_TELLER_REC.TXN_ACC THEN
          DBG('Charge on txn account');
          DBG('l_txn_bal_done : ' || L_TXN_BAL_DONE);
          IF NVL(L_TXN_BAL_DONE, 'N') = 'N' THEN
            IF NOT ACPKSS_MISC.FN_GETAVLBAL(EACH_REC.ACCOUNT_BR,
                                            EACH_REC.ACCOUNT_NO,
                                            LBAL_TXN,
                                            'Y') THEN
              DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
            ELSE
              DBG('Setting l_txn_bal_done to Y');
              L_TXN_BAL_DONE := 'Y';
            END IF;
            DBG('lbal_txn : ' || LBAL_TXN);
            DBG('l_avl_bal_left -->> ' || L_AVL_BAL_LEFT);
            DBG('pkg_rtl_teller_rec.txn_amount : ' ||
                PKG_RTL_TELLER_REC.TXN_AMOUNT);
            DBG('cspkss_arc.g_acc_ccy_chg_txn_NSF : ' ||
                CSPKSS_ARC.G_ACC_CCY_CHG_TXN_NSF);
          
            L_AVL_BAL_LEFT := LBAL_TXN;
          END IF;
          DBG('l_avl_bal_left here is  : ' || L_AVL_BAL_LEFT);
          IF L_AVL_BAL_LEFT > 0 THEN
            DBG('Balance left greater than 0');
            IF L_AVL_BAL_LEFT >= EACH_REC.AMOUNT_DUE THEN
              DBG('Coming txn here 1');
              L_AVL_BAL      := EACH_REC.AMOUNT_DUE;
              L_AVL_BAL_LEFT := L_AVL_BAL_LEFT - EACH_REC.AMOUNT_DUE;
            ELSE
              DBG('Coming txn here 2');
              L_AVL_BAL      := L_AVL_BAL_LEFT;
              L_AVL_BAL_LEFT := 0;
            END IF;
          ELSE
            DBG('Balance left is less than 0.. Setting available balance to 0');
            L_AVL_BAL      := 0;
            L_AVL_BAL_LEFT := 0;
          END IF;
        
        ELSE
          DBG('Charge on ofs account');
          DBG('l_ofs_bal_done : ' || L_OFS_BAL_DONE);
          IF NVL(L_OFS_BAL_DONE, 'N') = 'N' THEN
            IF NOT ACPKSS_MISC.FN_GETAVLBAL(EACH_REC.ACCOUNT_BR,
                                            EACH_REC.ACCOUNT_NO,
                                            LBAL_OFS,
                                            'Y') THEN
              DBG('bombed while callling acpkss_misc.fn_GetAvlBal');
            ELSE
              DBG('Setting l_ofs_bal_done to Y');
              L_OFS_BAL_DONE := 'Y';
            END IF;
            DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT);
            DBG('lbal_ofs : ' || LBAL_OFS);
            DBG('cspkss_arc.g_acc_ccy_chg_ofs_NSF : ' ||
                CSPKSS_ARC.G_ACC_CCY_CHG_OFS_NSF);
          
            L_AVL_BAL_LEFT := LBAL_OFS;
          END IF;
          DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT);
          IF L_AVL_BAL_LEFT > 0 THEN
            DBG('Balance left greater than 0');
            IF L_AVL_BAL_LEFT >= EACH_REC.AMOUNT_DUE THEN
              DBG('Coming ofs here 1');
              L_AVL_BAL      := EACH_REC.AMOUNT_DUE;
              L_AVL_BAL_LEFT := L_AVL_BAL_LEFT - EACH_REC.AMOUNT_DUE;
            ELSE
              DBG('Coming ofs here 2');
              L_AVL_BAL      := L_AVL_BAL_LEFT;
              L_AVL_BAL_LEFT := 0;
            END IF;
          ELSE
            DBG('Balance left is less than 0.. Setting available balance to 0');
            L_AVL_BAL      := 0;
            L_AVL_BAL_LEFT := 0;
          END IF;
        END IF;
      
        DBG('l_avl_bal : ' || L_AVL_BAL);
        DBG('l_avl_bal_left : ' || L_AVL_BAL_LEFT);
      
        UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
           SET AMOUNT_AVAILABLE = AMOUNT_AVAILABLE + L_AVL_BAL
         WHERE CONTRACT_REF_NO = TRN_REF_NO
           AND ACCOUNT_NO = EACH_REC.ACCOUNT_NO
           AND COMPONENT = EACH_REC.COMPONENT;
      END LOOP;
    END IF;
  
    BEGIN
      INSERT INTO CSTBS_AUTO_SETTLE_BLOCK
        (SELECT *
           FROM CSTB_AUTO_SETTLE_BLOCK_TEMP
          WHERE CONTRACT_REF_NO = TRN_REF_NO
         
         );
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
    DELETE CSTB_AUTO_SETTLE_BLOCK_TEMP WHERE CONTRACT_REF_NO = TRN_REF_NO;
  
    FOR EACH_REC IN (SELECT ACCOUNT_NO, ACCOUNT_BR, AMOUNT_AVAILABLE
                       FROM CSTBS_AUTO_SETTLE_BLOCK
                      WHERE CONTRACT_REF_NO = TRN_REF_NO) LOOP
      DBG('each_rec.account_no : ' || EACH_REC.ACCOUNT_NO);
      DBG('each_rec.account_br : ' || EACH_REC.ACCOUNT_BR);
      DBG('each_rec.amount_available : ' || EACH_REC.AMOUNT_AVAILABLE);
    
      ACPKS_CUSTBAL_PROCESS.PR_UPDATE_RECEIVABLE_AMT(EACH_REC.ACCOUNT_NO,
                                                     EACH_REC.ACCOUNT_BR,
                                                     'I',
                                                     NVL(EACH_REC.AMOUNT_AVAILABLE,
                                                         0));
      DEBUG.PR_DEBUG('LD', 'after updating recievable');
    
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in when others of pr_track_account with ' || SQLERRM);
  END PR_TRACK_ACCOUNT;

  PROCEDURE PR_SET_DR_VAL_DT(P_DT DATE) IS
  BEGIN
    PKG_DR_VAL_DT := P_DT;
  END;

  PROCEDURE PR_SET_CR_VAL_DT(P_DT DATE) IS
  BEGIN
    PKG_CR_VAL_DT := P_DT;
  END;

  PROCEDURE PR_RESOLVE_CHG_WHOM(P_CHG_ROW     IN IFTMS_ARC_MAINT%ROWTYPE,
                                P_THEIR_CHGS  IN VARCHAR2,
                                P_CHG_ACC_CCY OUT VARCHAR2,
                                P_CHG_ACC     OUT VARCHAR2,
                                P_CHG_ACC_BRN OUT VARCHAR2) IS
    L_CHG_WHOM VARCHAR2(1);
  
    L_FN_CALL_ID             NUMBER;
    L_TBL_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TBL_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    IF PKG_RTL_TELLER_REC.ROUTE_CODE IS NULL THEN
      DBG('The ususal code now.');
      IF NVL(P_CHG_ROW.CHG_FROM, 'TXN') = 'TXN' THEN
      
        IF GWPKS_UTIL.PKG_FUNC IN ('BCRV', 'DDRV', 'BCDI', 'DDDI') THEN
          DBG('Charge currency in BCRV' || PKG_RTL_TELLER_REC.CHG_CCY);
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
          P_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.CHARGE_ACCOUNT,
                               P_CHG_ROW.COD_TXN_ACCOUNT);
          P_CHG_ACC_BRN := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                               P_CHG_ROW.COD_TXN_BRN);
        
        ELSE
        
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
        
          P_CHG_ACC     := NVL(PKG_RTL_TELLER_REC.TXN_ACC,
                               P_CHG_ROW.COD_TXN_ACCOUNT);
          P_CHG_ACC_BRN := NVL(PKG_RTL_TELLER_REC.TXN_BRANCH,
                               P_CHG_ROW.COD_TXN_BRN);
        
        END IF;
      ELSE
        P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
        P_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
        P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
      END IF;
    ELSE
      DBG('ODC Txn ' || PKG_RTL_TELLER_REC.XREF);
      SELECT CHARGES_DETAILS
        INTO L_CHG_WHOM
        FROM CSTB_ARC_SETTLE
       WHERE XREF = PKG_RTL_TELLER_REC.XREF;
      DBG('Charge ' || L_CHG_WHOM);
      DBG('Dr Acc for the txn is ' || PKG_ARC_ROW.DR_ACC);
      DBG('Is it their chgs? ' || P_THEIR_CHGS);
      IF NVL(L_CHG_WHOM, 'O') = 'O' THEN
        IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
          P_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
          P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        ELSE
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
          P_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
          P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        END IF;
      ELSIF L_CHG_WHOM = 'B' THEN
        IF PKG_ARC_ROW.DR_ACC = 'OFS' THEN
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
          P_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
          P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
        ELSE
          P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
          P_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
          P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
        END IF;
      ELSIF L_CHG_WHOM = 'U' THEN
        IF P_THEIR_CHGS = 'N' THEN
          IF PKG_ARC_ROW.DR_ACC = 'TXN' THEN
            P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            P_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSE
            P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            P_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          END IF;
        ELSE
          IF PKG_ARC_ROW.DR_ACC = 'OFS' THEN
            P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.TXN_CCY;
            P_CHG_ACC     := PKG_RTL_TELLER_REC.TXN_ACC;
            P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.TXN_BRANCH;
          ELSE
            P_CHG_ACC_CCY := PKG_RTL_TELLER_REC.OFS_CCY;
            P_CHG_ACC     := PKG_RTL_TELLER_REC.OFS_ACC;
            P_CHG_ACC_BRN := PKG_RTL_TELLER_REC.OFS_BRANCH;
          END IF;
        END IF;
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 1;
      L_TBL_CLUSTER_DATA := L_TBL_CLUSTER_DATA_EMPTY;
      L_TBL_CLUSTER_DATA('ROUTE_CODE') := PKG_RTL_TELLER_REC.ROUTE_CODE;
      L_TBL_CLUSTER_DATA('CHG_CCY') := PKG_RTL_TELLER_REC.CHG_CCY;
      L_TBL_CLUSTER_DATA('CHARGE_ACCOUNT') := PKG_RTL_TELLER_REC.CHARGE_ACCOUNT;
      L_TBL_CLUSTER_DATA('TXN_CCY') := PKG_RTL_TELLER_REC.TXN_CCY;
      L_TBL_CLUSTER_DATA('TXN_ACC') := PKG_RTL_TELLER_REC.TXN_ACC;
      L_TBL_CLUSTER_DATA('TXN_BRANCH') := PKG_RTL_TELLER_REC.TXN_BRANCH;
      L_TBL_CLUSTER_DATA('OFS_CCY') := PKG_RTL_TELLER_REC.OFS_CCY;
      L_TBL_CLUSTER_DATA('OFS_ACC') := PKG_RTL_TELLER_REC.OFS_ACC;
      L_TBL_CLUSTER_DATA('OFS_BRANCH') := PKG_RTL_TELLER_REC.OFS_BRANCH;
      L_TBL_CLUSTER_DATA('XREF') := PKG_RTL_TELLER_REC.XREF;
      L_TBL_CLUSTER_DATA('TRN_REF_NO') := PKG_RTL_TELLER_REC.TRN_REF_NO;
      L_TBL_CLUSTER_DATA('DR_ACC') := PKG_ARC_ROW.DR_ACC;
      L_TBL_CLUSTER_DATA('L_CHARGE_FLAG') := 'F';
    
      DEPKS_RTL_TELLER_CLUSTER.PR_RESOLVE_CHG_WHOM(P_CHG_ROW,
                                                   P_THEIR_CHGS,
                                                   P_CHG_ACC_CCY,
                                                   P_CHG_ACC,
                                                   P_CHG_ACC_BRN,
                                                   L_FN_CALL_ID,
                                                   L_TBL_CLUSTER_DATA);
    END IF;
  
    DBG('Returning from resolve chg whom.');
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
      RAISE;
  END PR_RESOLVE_CHG_WHOM;

  PROCEDURE PR_FETCH_CHG_DETAILS(P_RTL_TELLER  IN DETBS_RTL_TELLER%ROWTYPE,
                                 P_SNDRCHG1    OUT NUMBER,
                                 P_SNDRCHGCCY1 OUT VARCHAR2,
                                 P_SNDRCHG2    OUT NUMBER,
                                 P_SNDRCHGCCY2 OUT VARCHAR2,
                                 P_SNDRCHG3    OUT NUMBER,
                                 P_SNDRCHGCCY3 OUT VARCHAR2,
                                 P_SNDRCHG4    OUT NUMBER,
                                 P_SNDRCHGCCY4 OUT VARCHAR2,
                                 P_SNDRCHG5    OUT NUMBER,
                                 P_SNDRCHGCCY5 OUT VARCHAR2,
                                 P_RVRCHG1     OUT NUMBER,
                                 P_RVRCHGCCY1  OUT VARCHAR2
                                 
                                 ) IS
    L_SNDR_CHG_CNT NUMBER;
    L_RVR_CHG_CNT  NUMBER;
    L_SC           NUMBER;
    L_CHG          NUMBER;
    L_CCY          VARCHAR2(3);
    PROCEDURE PR_RESOLVE_CHG(P_CNT IN NUMBER,
                             P_SC  OUT NUMBER,
                             P_CHG OUT NUMBER,
                             P_CCY OUT VARCHAR2) IS
    BEGIN
      IF P_CNT = 1 THEN
        IF NVL(P_RTL_TELLER.CHG_AMT, 0) = 0 THEN
          P_SC := -1;
        ELSE
          IF NVL(P_RTL_TELLER.THEIR_CHGS, 'N') = 'Y' THEN
            P_SC := 0;
          ELSE
            P_SC := 1;
          END IF;
          P_CHG := P_RTL_TELLER.CHG_AMT;
          P_CCY := P_RTL_TELLER.CHG_CCY;
        END IF;
      ELSIF P_CNT = 2 THEN
        IF NVL(P_RTL_TELLER.CHG_AMT_1, 0) = 0 THEN
          P_SC := -1;
        ELSE
          IF NVL(P_RTL_TELLER.THEIR_CHGS1, 'N') = 'Y' THEN
            P_SC := 0;
          ELSE
            P_SC := 1;
          END IF;
          P_CHG := P_RTL_TELLER.CHG_AMT_1;
          P_CCY := P_RTL_TELLER.CHG_CCY_1;
        END IF;
      ELSIF P_CNT = 3 THEN
        IF NVL(P_RTL_TELLER.CHG_AMT_2, 0) = 0 THEN
          P_SC := -1;
        ELSE
          IF NVL(P_RTL_TELLER.THEIR_CHGS2, 'N') = 'Y' THEN
            P_SC := 0;
          ELSE
            P_SC := 1;
          END IF;
          P_CHG := P_RTL_TELLER.CHG_AMT_2;
          P_CCY := P_RTL_TELLER.CHG_CCY_2;
        END IF;
      ELSIF P_CNT = 4 THEN
        IF NVL(P_RTL_TELLER.CHG_AMT_3, 0) = 0 THEN
          P_SC := -1;
        ELSE
          IF NVL(P_RTL_TELLER.THEIR_CHGS3, 'N') = 'Y' THEN
            P_SC := 0;
          ELSE
            P_SC := 1;
          END IF;
          P_CHG := P_RTL_TELLER.CHG_AMT_3;
          P_CCY := P_RTL_TELLER.CHG_CCY_3;
        END IF;
      ELSIF P_CNT = 5 THEN
        IF NVL(P_RTL_TELLER.CHG_AMT_4, 0) = 0 THEN
          P_SC := -1;
        ELSE
          IF NVL(P_RTL_TELLER.THEIR_CHGS4, 'N') = 'Y' THEN
            P_SC := 0;
          ELSE
            P_SC := 1;
          END IF;
          P_CHG := P_RTL_TELLER.CHG_AMT_4;
          P_CCY := P_RTL_TELLER.CHG_CCY_4;
        END IF;
      END IF;
    END PR_RESOLVE_CHG;
  BEGIN
    L_SNDR_CHG_CNT := 0;
    L_RVR_CHG_CNT  := 0;
    FOR I IN 1 .. 5 LOOP
      L_CHG := 0;
      L_CCY := NULL;
      L_SC  := 0;
      PR_RESOLVE_CHG(I, L_SC, L_CHG, L_CCY);
      DBG('I - ' || I || ' Senders ' || L_SC || ' Amt ' || L_CHG || '-' ||
          L_CCY);
      IF L_SC = 1 THEN
        L_SNDR_CHG_CNT := L_SNDR_CHG_CNT + 1;
        IF L_SNDR_CHG_CNT = 1 THEN
          P_SNDRCHG1    := L_CHG;
          P_SNDRCHGCCY1 := L_CCY;
        ELSIF L_SNDR_CHG_CNT = 2 THEN
          P_SNDRCHG2    := L_CHG;
          P_SNDRCHGCCY2 := L_CCY;
        ELSIF L_SNDR_CHG_CNT = 3 THEN
          P_SNDRCHG3    := L_CHG;
          P_SNDRCHGCCY3 := L_CCY;
        ELSIF L_SNDR_CHG_CNT = 4 THEN
          P_SNDRCHG4    := L_CHG;
          P_SNDRCHGCCY4 := L_CCY;
        ELSIF L_SNDR_CHG_CNT = 5 THEN
          P_SNDRCHG5    := L_CHG;
          P_SNDRCHGCCY5 := L_CCY;
        END IF;
      ELSIF L_SC = 0 THEN
        L_RVR_CHG_CNT := L_RVR_CHG_CNT + 1;
        IF L_RVR_CHG_CNT = 1 THEN
          P_RVRCHG1    := L_CHG;
          P_RVRCHGCCY1 := L_CCY;
        ELSIF L_RVR_CHG_CNT = 2 THEN
          P_RVRCHG1 := P_RVRCHG1 + L_CHG;
        END IF;
      ELSE
        NULL;
      END IF;
    END LOOP;
  END PR_FETCH_CHG_DETAILS;

  FUNCTION FN_CHECK_CUST_LIMIT(L_TBL_RESTR             IN OUT NOCOPY STPKS_CUST_RESTR_UTIL_TRACK.V_TAB_RESTR,
                               TXN_ACC                 IN DETBS_RTL_TELLER.TXN_ACC%TYPE,
                               ACC_BRANCH              IN ACTBS_HANDOFF.AC_BRANCH%TYPE,
                               P_ERR_CODE              IN OUT VARCHAR2,
                               P_ERR_PARAM             IN OUT VARCHAR2,
                               TOTAL_CHARGE            IN NUMBER,
                               P_LEG_INDICATOR         IN VARCHAR2,
                               P_LINK_DELINK_INDICATOR IN VARCHAR2)
    RETURN BOOLEAN IS
  
    L_ERR_TYPE  VARCHAR2(2);
    L_MODULE    CSTM_PRODUCT.MODULE%TYPE;
    L_PRDGRP    CSTM_PRODUCT.PRODUCT_GROUP%TYPE;
    L_CUSTACCNO STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PRODUCT   PKG_RTL_TELLER_REC.PRODUCT_CODE%TYPE;
    L_ACC       DETBS_RTL_TELLER.TXN_ACC%TYPE;
    L_REL_CUS   DETBS_RTL_TELLER.REL_CUSTOMER%TYPE;
    L_TOT_AMT   NUMBER;
  
  BEGIN
  
    DBG('pkg_rtl_teller_rec.trn_ref_no' || PKG_RTL_TELLER_REC.TRN_REF_NO);
    DBG('pkg_rtl_teller_rec.product_code' ||
        PKG_RTL_TELLER_REC.PRODUCT_CODE);
    DBG('pkg_rtl_teller_rec.branch_code' || PKG_RTL_TELLER_REC.BRANCH_CODE);
    DBG('pkg_rtl_teller_rec.scode' || PKG_RTL_TELLER_REC.SCODE);
    DBG('pkg_rtl_teller_rec.txn_acc' || PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('pkg_rtl_teller_rec.txn_ccy' || PKG_RTL_TELLER_REC.TXN_CCY);
    DBG('pkg_rtl_teller_rec.ofs_ccy' || PKG_RTL_TELLER_REC.OFS_CCY);
    DBG('pkg_rtl_teller_rec.txn_amount' || PKG_RTL_TELLER_REC.TXN_AMOUNT);
    DBG('pkg_rtl_teller_rec.tot_chg_in_tcy' ||
        PKG_RTL_TELLER_REC.TOT_CHG_IN_TCY);
    DBG('pkg_rtl_teller_rec.trn_dt' || PKG_RTL_TELLER_REC.TRN_DT);
    DBG('pkg_rtl_teller_rec.RELATED_CUSTOMER' ||
        PKG_RTL_TELLER_REC.REL_CUSTOMER || PKG_RTL_TELLER_REC.CHG_AMT);
  
    DBG('*****************************************************');
    DBG('Total charge ampount is ' || TOTAL_CHARGE);
  
    DBG('The offset Amount is  pkg_rtl_teller_rec.ofs_amount ' ||
        PKG_RTL_TELLER_REC.OFS_AMOUNT);
  
    DBG('CREDIT DEBIT LEG INDICATOR');
  
    BEGIN
      SELECT MODULE
        INTO L_MODULE
        FROM CSTM_PRODUCT
       WHERE PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE;
    
      DBG('l_module' || L_MODULE);
    
      SELECT PRODUCT_GROUP
        INTO L_PRDGRP
        FROM CSTM_PRODUCT
       WHERE PRODUCT_CODE = PKG_RTL_TELLER_REC.PRODUCT_CODE;
    
      DBG('l_prdgrp' || L_PRDGRP);
    
      IF TXN_ACC IS NULL THEN
        L_REL_CUS := PKG_RTL_TELLER_REC.REL_CUSTOMER;
        DBG('related customer from screen is ,,,' || L_REL_CUS);
      ELSE
        L_ACC := TXN_ACC;
        SELECT CUST_NO
          INTO L_REL_CUS
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = L_ACC
           AND BRANCH_CODE = ACC_BRANCH;
        DBG('l_rel_cus is ..' || L_REL_CUS);
      END IF;
    
      DBG('Inside fn_check_cust_limit');
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('In No_data_found ' || SQLERRM);
        RETURN TRUE;
    END;
  
    DBG('BEFORE API');
  
    IF PKG_RTL_TELLER_REC.SCODE IN ('FLEXSWITCH') THEN
      DBG('Source is FLEXSWITCH');
      L_TOT_AMT := PKG_RTL_TELLER_REC.TXN_AMOUNT;
    ELSE
      L_TOT_AMT := TOTAL_CHARGE;
    END IF;
  
    IF NOT STPKS_CUST_RESTR_UTIL_TRACK.FN_PROCESS_CHK_LIMIT(PKG_RTL_TELLER_REC.SCODE,
                                                            L_MODULE,
                                                            
                                                            ACC_BRANCH,
                                                            PKG_RTL_TELLER_REC.TRN_REF_NO,
                                                            L_REL_CUS,
                                                            L_ACC,
                                                            PKG_RTL_TELLER_REC.EVENT_CODE,
                                                            1,
                                                            L_PRDGRP,
                                                            PKG_RTL_TELLER_REC.TRN_DT,
                                                            
                                                            PKG_RTL_TELLER_REC.OFS_AMOUNT,
                                                            PKG_RTL_TELLER_REC.OFS_CCY,
                                                            P_DB_LEG_CCY,
                                                            P_CR_LEG_CCY,
                                                            P_LEG_INDICATOR,
                                                            'L',
                                                            L_TBL_RESTR,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
      DBG('error Code' || P_ERR_CODE);
      DBG('error params' || P_ERR_PARAM);
    ELSE
    
      DBG('NTHNG');
    
    END IF;
  
    RETURN TRUE;
  END FN_CHECK_CUST_LIMIT;

  FUNCTION FN_INS_TXN_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF, I IN NUMBER)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Here to insert for TXN BLOCK');
    DBG('pkg_rtl_teller_rec.track_receivable : ' ||
        PKG_RTL_TELLER_REC.TRACK_RECEIVABLE);
    DBG('pkg_recivable_amt_det.TXN_AC_OR_GL : ' ||
        PKG_RECIVABLE_AMT_DET.TXN_AC_OR_GL);
    DBG('pkg_recivable_amt_det.TXN_ACC_TRACK_ALLOWED : ' ||
        PKG_RECIVABLE_AMT_DET.TXN_ACC_TRACK_ALLOWED);
    DBG('pkg_rtl_teller_rec.txn_amount : ' ||
        PKG_RTL_TELLER_REC.TXN_AMOUNT);
    IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
       NVL(PKG_RECIVABLE_AMT_DET.TXN_AC_OR_GL, '*') = 'A' AND
       NVL(PKG_RECIVABLE_AMT_DET.TXN_ACC_TRACK_ALLOWED, 'N') = 'Y' THEN
      BEGIN
        INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
          (MODULE,
           PRODUCT,
           CONTRACT_REF_NO,
           COMPONENT,
           BOOK_DATE,
           ACCOUNT_NO,
           ACCOUNT_BR,
           AMOUNT_DUE,
           AMOUNT_PAID,
           AMOUNT_AVAILABLE,
           AUTO_MANUAL,
           STATUS,
           AMTDUE_TAGCCY,
           AMTPAID_TAGCCY)
        VALUES
          ('RT',
           PKG_RTL_TELLER_REC.PRODUCT_CODE,
           PKG_RTL_TELLER_REC.TRN_REF_NO,
           'TRANSACTION',
           PKG_RTL_TELLER_REC.VALUE_DT,
           P_ACC_HAND(1).AC_NO,
           P_ACC_HAND(1).AC_BRANCH,
           NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0),
           0,
           NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0),
           NULL,
           'U',
           NVL(PKG_RTL_TELLER_REC.TXN_AMOUNT, 0),
           0);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('in exception...will update cstb_auto_settle_block instead : ' ||
              SQLERRM);
      END;
    END IF;
    RETURN TRUE;
  END FN_INS_TXN_BLOCK;

  FUNCTION FN_INS_CHG_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF,
                            P_SEQ      IN NUMBER) RETURN BOOLEAN IS
    L_CHG_ACC                  IFTMS_ARC_MAINT.COD_OFFSET_ACC%TYPE;
    L_CHG_ACC_BRN              IFTMS_ARC_MAINT.COD_OFFSET_BRN%TYPE;
    L_ACC_CCY_CHG_TEMP         NUMBER(22, 3);
    L_COD_CHG_AMT              IFTMS_ARC_MAINT.COD_CHG_AMT%TYPE;
    L_AC_OR_GL                 STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_ACCOUNT_TRACKING_ALLOWED VARCHAR2(1);
  BEGIN
  
    DBG('Here to insert for chg BLOCK');
    DBG('p_seq : ' || P_SEQ);
  
    IF P_SEQ = 1 THEN
      DBG('sequence 1');
      DBG('pkg_recivable_amt_det.CHG1_AC_NO : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_AC_NO);
      DBG('pkg_recivable_amt_det.CHG1_AC_BRANCH : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_AC_BRANCH);
      DBG('pkg_recivable_amt_det.CHG1_ACCY_AMT_TRACKED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_ACCY_AMT_TRACKED);
      DBG('pkg_recivable_amt_det.CHG1_COD_CHG_AMT : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT);
      DBG('pkg_recivable_amt_det.CHG1_AC_OR_GL : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_AC_OR_GL);
      DBG('pkg_recivable_amt_det.CHG1_ACC_TRACK_ALLOWED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG1_ACC_TRACK_ALLOWED);
      L_CHG_ACC                  := PKG_RECIVABLE_AMT_DET.CHG1_AC_NO;
      L_CHG_ACC_BRN              := PKG_RECIVABLE_AMT_DET.CHG1_AC_BRANCH;
      L_ACC_CCY_CHG_TEMP         := PKG_RECIVABLE_AMT_DET.CHG1_ACCY_AMT_TRACKED;
      L_COD_CHG_AMT              := PKG_RECIVABLE_AMT_DET.CHG1_COD_CHG_AMT;
      L_AC_OR_GL                 := PKG_RECIVABLE_AMT_DET.CHG1_AC_OR_GL;
      L_ACCOUNT_TRACKING_ALLOWED := PKG_RECIVABLE_AMT_DET.CHG1_ACC_TRACK_ALLOWED;
    ELSIF P_SEQ = 2 THEN
      DBG('sequence 2');
      DBG('pkg_recivable_amt_det.CHG2_AC_NO : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_AC_NO);
      DBG('pkg_recivable_amt_det.CHG2_AC_BRANCH : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_AC_BRANCH);
      DBG('pkg_recivable_amt_det.CHG2_ACCY_AMT_TRACKED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_ACCY_AMT_TRACKED);
      DBG('pkg_recivable_amt_det.CHG2_COD_CHG_AMT : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT);
      DBG('pkg_recivable_amt_det.CHG2_AC_OR_GL : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_AC_OR_GL);
      DBG('pkg_recivable_amt_det.CHG2_ACC_TRACK_ALLOWED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG2_ACC_TRACK_ALLOWED);
      L_CHG_ACC                  := PKG_RECIVABLE_AMT_DET.CHG2_AC_NO;
      L_CHG_ACC_BRN              := PKG_RECIVABLE_AMT_DET.CHG2_AC_BRANCH;
      L_ACC_CCY_CHG_TEMP         := PKG_RECIVABLE_AMT_DET.CHG2_ACCY_AMT_TRACKED;
      L_COD_CHG_AMT              := PKG_RECIVABLE_AMT_DET.CHG2_COD_CHG_AMT;
      L_AC_OR_GL                 := PKG_RECIVABLE_AMT_DET.CHG2_AC_OR_GL;
      L_ACCOUNT_TRACKING_ALLOWED := PKG_RECIVABLE_AMT_DET.CHG2_ACC_TRACK_ALLOWED;
    ELSIF P_SEQ = 3 THEN
      DBG('sequence 3');
      DBG('pkg_recivable_amt_det.CHG3_AC_NO : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_AC_NO);
      DBG('pkg_recivable_amt_det.CHG3_AC_BRANCH : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_AC_BRANCH);
      DBG('pkg_recivable_amt_det.CHG3_ACCY_AMT_TRACKED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_ACCY_AMT_TRACKED);
      DBG('pkg_recivable_amt_det.CHG3_COD_CHG_AMT : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT);
      DBG('pkg_recivable_amt_det.CHG3_AC_OR_GL : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_AC_OR_GL);
      DBG('pkg_recivable_amt_det.CHG3_ACC_TRACK_ALLOWED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG3_ACC_TRACK_ALLOWED);
      L_CHG_ACC                  := PKG_RECIVABLE_AMT_DET.CHG3_AC_NO;
      L_CHG_ACC_BRN              := PKG_RECIVABLE_AMT_DET.CHG3_AC_BRANCH;
      L_ACC_CCY_CHG_TEMP         := PKG_RECIVABLE_AMT_DET.CHG3_ACCY_AMT_TRACKED;
      L_COD_CHG_AMT              := PKG_RECIVABLE_AMT_DET.CHG3_COD_CHG_AMT;
      L_AC_OR_GL                 := PKG_RECIVABLE_AMT_DET.CHG3_AC_OR_GL;
      L_ACCOUNT_TRACKING_ALLOWED := PKG_RECIVABLE_AMT_DET.CHG3_ACC_TRACK_ALLOWED;
    ELSIF P_SEQ = 4 THEN
      DBG('sequence 4');
      DBG('pkg_recivable_amt_det.CHG4_AC_NO : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_AC_NO);
      DBG('pkg_recivable_amt_det.CHG4_AC_BRANCH : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_AC_BRANCH);
      DBG('pkg_recivable_amt_det.CHG4_ACCY_AMT_TRACKED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_ACCY_AMT_TRACKED);
      DBG('pkg_recivable_amt_det.CHG4_COD_CHG_AMT : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT);
      DBG('pkg_recivable_amt_det.CHG4_AC_OR_GL : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_AC_OR_GL);
      DBG('pkg_recivable_amt_det.CHG4_ACC_TRACK_ALLOWED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG4_ACC_TRACK_ALLOWED);
      L_CHG_ACC                  := PKG_RECIVABLE_AMT_DET.CHG4_AC_NO;
      L_CHG_ACC_BRN              := PKG_RECIVABLE_AMT_DET.CHG4_AC_BRANCH;
      L_ACC_CCY_CHG_TEMP         := PKG_RECIVABLE_AMT_DET.CHG4_ACCY_AMT_TRACKED;
      L_COD_CHG_AMT              := PKG_RECIVABLE_AMT_DET.CHG4_COD_CHG_AMT;
      L_AC_OR_GL                 := PKG_RECIVABLE_AMT_DET.CHG4_AC_OR_GL;
      L_ACCOUNT_TRACKING_ALLOWED := PKG_RECIVABLE_AMT_DET.CHG4_ACC_TRACK_ALLOWED;
    ELSIF P_SEQ = 5 THEN
      DBG('sequence 5');
      DBG('pkg_recivable_amt_det.CHG5_AC_NO : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_AC_NO);
      DBG('pkg_recivable_amt_det.CHG5_AC_BRANCH : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_AC_BRANCH);
      DBG('pkg_recivable_amt_det.CHG5_ACCY_AMT_TRACKED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_ACCY_AMT_TRACKED);
      DBG('pkg_recivable_amt_det.CHG5_COD_CHG_AMT : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_COD_CHG_AMT);
      DBG('pkg_recivable_amt_det.CHG5_AC_OR_GL : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_AC_OR_GL);
      DBG('pkg_recivable_amt_det.CHG5_ACC_TRACK_ALLOWED : ' ||
          PKG_RECIVABLE_AMT_DET.CHG5_ACC_TRACK_ALLOWED);
      L_CHG_ACC                  := PKG_RECIVABLE_AMT_DET.CHG5_AC_NO;
      L_CHG_ACC_BRN              := PKG_RECIVABLE_AMT_DET.CHG5_AC_BRANCH;
      L_ACC_CCY_CHG_TEMP         := PKG_RECIVABLE_AMT_DET.CHG5_ACCY_AMT_TRACKED;
      L_COD_CHG_AMT              := PKG_RECIVABLE_AMT_DET.CHG5_COD_CHG_AMT;
      L_AC_OR_GL                 := PKG_RECIVABLE_AMT_DET.CHG5_AC_OR_GL;
      L_ACCOUNT_TRACKING_ALLOWED := PKG_RECIVABLE_AMT_DET.CHG5_ACC_TRACK_ALLOWED;
    END IF;
  
    DBG('pkg_rtl_teller_rec.track_receivable : ' ||
        PKG_RTL_TELLER_REC.TRACK_RECEIVABLE);
    DBG('l_ac_or_gl-->>> ' || L_AC_OR_GL);
    DBG('l_acc_ccy_chg_temp-->>> ' || L_ACC_CCY_CHG_TEMP);
    DBG('l_account_tracking_allowed-->>> ' || L_ACCOUNT_TRACKING_ALLOWED);
  
    IF NVL(PKG_RTL_TELLER_REC.TRACK_RECEIVABLE, 'N') = 'Y' AND
       L_AC_OR_GL = 'A' AND NVL(L_ACCOUNT_TRACKING_ALLOWED, 'N') = 'Y' AND
       NVL(L_ACC_CCY_CHG_TEMP, 0) > 0 THEN
      BEGIN
        INSERT INTO CSTB_AUTO_SETTLE_BLOCK_TEMP
          (MODULE,
           PRODUCT,
           CONTRACT_REF_NO,
           COMPONENT,
           BOOK_DATE,
           ACCOUNT_NO,
           ACCOUNT_BR,
           AMOUNT_DUE,
           AMOUNT_PAID,
           AMOUNT_AVAILABLE,
           AUTO_MANUAL,
           STATUS,
           AMTDUE_TAGCCY,
           AMTPAID_TAGCCY)
        VALUES
          ('RT',
           PKG_RTL_TELLER_REC.PRODUCT_CODE,
           PKG_RTL_TELLER_REC.TRN_REF_NO,
           'CHARGE',
           PKG_RTL_TELLER_REC.VALUE_DT,
           L_CHG_ACC,
           L_CHG_ACC_BRN,
           NVL(L_ACC_CCY_CHG_TEMP, 0),
           0,
           NVL(L_ACC_CCY_CHG_TEMP, 0),
           NULL,
           'U',
           NVL(L_COD_CHG_AMT, 0),
           0);
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          DBG('in exception...will update cstb_auto_settle_block instead');
          UPDATE CSTB_AUTO_SETTLE_BLOCK_TEMP
             SET AMOUNT_DUE       = AMOUNT_DUE + NVL(L_ACC_CCY_CHG_TEMP, 0),
                 AMTDUE_TAGCCY    = AMTDUE_TAGCCY + NVL(L_COD_CHG_AMT, 0),
                 AMOUNT_AVAILABLE = AMOUNT_AVAILABLE +
                                    NVL(L_ACC_CCY_CHG_TEMP, 0)
           WHERE CONTRACT_REF_NO = PKG_RTL_TELLER_REC.TRN_REF_NO
             AND ACCOUNT_NO = L_CHG_ACC
             AND COMPONENT = 'CHARGE';
      END;
    END IF;
    DBG('Retruning true from insert chg block');
    RETURN TRUE;
  END FN_INS_CHG_BLOCK;

  FUNCTION FN_INS_SETTLE_BLOCK(P_ACC_HAND IN ACPKS.TBL_ACHOFF, I IN NUMBER)
    RETURN BOOLEAN IS
    L_AC_OR_GL                 STTBS_ACCOUNT.AC_OR_GL%TYPE;
    L_ACCOUNT_TRACKING_ALLOWED STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE%TYPE;
  
  BEGIN
    DBG('Here to insert for auto_settle_block');
  
    IF I = 1 THEN
      DBG('For Charge 1');
      IF (NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED, 'N') = 'Y' AND
         NVL(PKG_RECIVABLE_AMT_DET.TXN_TRACKED, 'N') = 'N') THEN
        IF NOT FN_INS_TXN_BLOCK(P_ACC_HAND, I) THEN
          DBG('Error occured in insert of txn block as : ' || SQLERRM);
        ELSE
          DBG('Txn tracked now');
          PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
        END IF;
      END IF;
      DBG('For Charge 1 success');
    
    ELSIF I = 2 THEN
      DBG('For Charge 2');
      IF NVL(PKG_RECIVABLE_AMT_DET.CHG2_TRACKED, 'N') = 'Y' THEN
        DBG('Charge 2 is tracked');
        IF NVL(PKG_RECIVABLE_AMT_DET.TXN_TRACKED, 'N') = 'N' THEN
          DBG('Txn not tracked');
          IF NOT FN_INS_TXN_BLOCK(P_ACC_HAND, I) THEN
            DBG('Error occured in insert of txn block as : ' || SQLERRM);
          ELSE
            DBG('Txn tracked now');
            PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('Txn track for chg2 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED, 'N') = 'N' THEN
          DBG('Charge 1 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 1) THEN
            DBG('Error occured in insert of txn block as : ' || SQLERRM);
          ELSE
            DBG('Charge 1 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG1_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg1 track for chg2 done');
      END IF;
      DBG('For Charge 2 success');
    
    ELSIF I = 3 THEN
      DBG('For Charge 3');
      IF NVL(PKG_RECIVABLE_AMT_DET.CHG3_TRACKED, 'N') = 'Y' THEN
        DBG('Charge 3 is tracked');
        IF NVL(PKG_RECIVABLE_AMT_DET.TXN_TRACKED, 'N') = 'N' THEN
          DBG('Txn not tracked');
          IF NOT FN_INS_TXN_BLOCK(P_ACC_HAND, I) THEN
            DBG('Error occured in insert of txn block as : ' || SQLERRM);
          ELSE
            DBG('Txn tracked now');
            PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('Txn track for chg3 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED, 'N') = 'N' THEN
          DBG('Charge 1 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 1) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 1 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG1_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg1 track for chg3 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG2_TRACKED, 'N') = 'N' THEN
          DBG('Charge 2 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 2) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 2 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG2_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg2 track for chg3 done');
      END IF;
      DBG('For Charge 3 success');
    
    ELSIF I = 4 THEN
      DBG('For Charge 4');
      IF NVL(PKG_RECIVABLE_AMT_DET.CHG4_TRACKED, 'N') = 'Y' THEN
        DBG('Charge 4 is tracked');
        IF NVL(PKG_RECIVABLE_AMT_DET.TXN_TRACKED, 'N') = 'N' THEN
          DBG('Txn not tracked');
          IF NOT FN_INS_TXN_BLOCK(P_ACC_HAND, I) THEN
            DBG('Error occured in insert of txn block as : ' || SQLERRM);
          ELSE
            DBG('Txn tracked now');
            PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('Txn track for chg4 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED, 'N') = 'N' THEN
          DBG('Charge 1 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 1) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 1 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG1_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg1 track for chg4 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG2_TRACKED, 'N') = 'N' THEN
          DBG('Charge 2 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 2) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 2 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG2_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg2 track for chg4 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG3_TRACKED, 'N') = 'N' THEN
          DBG('Charge 3 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 3) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 3 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG3_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg3 track for chg4 done');
      END IF;
      DBG('For Charge 4 success');
    
    ELSIF I = 5 THEN
      DBG('For Charge 5');
      IF NVL(PKG_RECIVABLE_AMT_DET.CHG5_TRACKED, 'N') = 'Y' THEN
        DBG('Charge 5 is tracked');
        IF NVL(PKG_RECIVABLE_AMT_DET.TXN_TRACKED, 'N') = 'N' THEN
          DBG('Txn not tracked');
          IF NOT FN_INS_TXN_BLOCK(P_ACC_HAND, I) THEN
            DBG('Error occured in insert of txn block as : ' || SQLERRM);
          ELSE
            DBG('Txn tracked now');
            PKG_RECIVABLE_AMT_DET.TXN_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('Txn track for chg5 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG1_TRACKED, 'N') = 'N' THEN
          DBG('Charge 1 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 1) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 1 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG1_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg1 track for chg5 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG2_TRACKED, 'N') = 'N' THEN
          DBG('Charge 2 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 2) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 2 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG2_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg2 track for chg5 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG3_TRACKED, 'N') = 'N' THEN
          DBG('Charge 3 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 3) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 3 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG3_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg3 track for chg5 done');
        IF NVL(PKG_RECIVABLE_AMT_DET.CHG4_TRACKED, 'N') = 'N' THEN
          DBG('Charge 4 not tracked');
          IF NOT FN_INS_CHG_BLOCK(P_ACC_HAND, 4) THEN
            DBG('Error occured in insert of chg1 block as : ' || SQLERRM);
          ELSE
            DBG('Charge 4 tracked now');
            PKG_RECIVABLE_AMT_DET.CHG4_TRACKED := 'Y';
          END IF;
        END IF;
        DBG('chg3 track for chg5 done');
      END IF;
      DBG('For Charge 5 success');
    END IF;
  
    PKG_INS_SETTLE_BLK_DONE := 'Y';
    DBG('Returning true from insert settle block');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error occured as : ' || SQLERRM);
  END FN_INS_SETTLE_BLOCK;

END DEPKS_RTL_TELLER;
