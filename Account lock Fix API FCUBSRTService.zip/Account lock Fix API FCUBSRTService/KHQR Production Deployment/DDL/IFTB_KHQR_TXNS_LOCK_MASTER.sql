-- Create table
create table IFTB_KHQR_TXNS_LOCK_MASTER
(
  fc_xref_no         VARCHAR2(25),
  trn_ref_no         VARCHAR2(25),
  txn_date           TIMESTAMP(6),
  debit_txn_branch   VARCHAR2(3),
  debit_txn_account  VARCHAR2(20),
  debit_txn_ccy      VARCHAR2(3),
  credit_ofs_branch  VARCHAR2(3),
  credit_ofs_amount  NUMBER(22,3),
  credit_ofs_account VARCHAR2(20),
  credit_ofs_ccy     VARCHAR2(3),
  status             CHAR(1) default 'U',
  error_code         VARCHAR2(25),
  error_message      VARCHAR2(255)
)
/
alter table IFTB_KHQR_TXNS_LOCK_MASTER add primary key (FC_XREF_NO)
/