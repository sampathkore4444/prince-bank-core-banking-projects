insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('KHQR_PROCESS_LOCKTXNS', 'NAME', 'VARCHAR', 'OFSS');

COMMIT;
