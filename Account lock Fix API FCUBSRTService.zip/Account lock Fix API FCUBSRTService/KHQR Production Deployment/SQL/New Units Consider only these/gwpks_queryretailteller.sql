CREATE OR REPLACE

PACKAGE BODY gwpks_queryretailteller AS































































































































































































































































































































































































   
   G_SKIP_KERNEL  BOOLEAN := FALSE;
   G_SKIP_CLUSTER BOOLEAN := FALSE;
   G_SKIP_CUSTOM  BOOLEAN := FALSE;   
   
  G_LENGTH        NUMBER := 0;
    G_CNT_LVL2 NUMBER := 0;
    G_CNT_LVL3 NUMBER := 0;
  PKG_RTL_TLR DETBS_RTL_TELLER%ROWTYPE; 
    PROCEDURE DBG(X VARCHAR2) IS
        L_LEN NUMBER := 0;
        L_IND NUMBER := 1;
    BEGIN
        GWPKS_DEBUG.PR_DBG('Gwpks_QueryRetailTeller:' || X, 5);
        IF LENGTH(X) < 255
        THEN
            DEBUG.PR_DEBUG('IF', 'Gwpks_QueryRetailTeller >' || X);
        
        ELSE
        
            L_LEN := LENGTH(X);
            WHILE L_IND < L_LEN
            LOOP
                DEBUG.PR_DEBUG('IF', 'Gwpks_QueryRetailTeller >' || SUBSTR(X, L_IND, 255));
                L_IND := L_IND + 255;
            END LOOP;
        END IF;
    
    END DBG;

 
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
   BEGIN
      DEBUG.PR_DEBUG('IF', 'In Pr_Skip_Handler OF gwpks_queryretailteller ..');

    GWPKS_QUERYRETAILTLR_CLUSTER.PR_SKIP_HANDLER(P_STAGE);
    GWPKS_QUERYRETAILTLR_CUSTOM.PR_SKIP_HANDLER(P_STAGE);

   END PR_SKIP_HANDLER;

   PROCEDURE PR_SET_SKIP_KERNEL IS
   BEGIN
    G_SKIP_KERNEL := TRUE;
   END PR_SET_SKIP_KERNEL;

   PROCEDURE PR_SET_ACTIVATE_KERNEL IS
   BEGIN
    G_SKIP_KERNEL := FALSE;
   END PR_SET_ACTIVATE_KERNEL;

   PROCEDURE PR_SET_SKIP_CLUSTER IS
   BEGIN
    G_SKIP_CLUSTER := TRUE;
   END PR_SET_SKIP_CLUSTER;

   PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
   BEGIN
    G_SKIP_CLUSTER := FALSE;
   END PR_SET_ACTIVATE_CLUSTER;

   FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
   BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
        (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
   END FN_SKIP_CUSTOM;

   FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
   BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
 
   END FN_SKIP_CLUSTER;
   
     


    FUNCTION FN_BUILD_SDDETAILS(P_TY_RTUPLD  IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC
                               ,P_PARENT_RES IN VARCHAR2
                               ,P_PARENT     IN OUT VARCHAR2
                               ,P_KEY        IN OUT VARCHAR2
                               ,P_DATA       IN OUT VARCHAR2
                               ,P_FORMAT     IN OUT VARCHAR2
                               ,P_NODE       IN OUT VARCHAR2
                               ,P_CNT_LVL    IN OUT VARCHAR2
                               ,P_ERR_CODE   IN OUT VARCHAR2
                               ,P_ERR_PARAM  IN OUT VARCHAR2)

     RETURN BOOLEAN IS

        L_DTF      VARCHAR(10) := 'RRRR-MM-DD';
        L_DTSTAMPF VARCHAR(24) := 'RRRR-MM-DD HH24:MI:SS AM';
        L_SAFEDEPOSITDET DLTBS_CONTRACT_LIQ_SUMMARY%ROWTYPE;
        L_PAYMNTCCY      DLVW_CONTRACT_PAYMENT.CNTCCY%TYPE;
        L_PAY_CNT           NUMBER;
        L_DLCONTRACT_REC    DLTB_CONTRACT_MASTER%ROWTYPE;
        L_DLPYMNT_REC       DLVW_CONTRACT_PAYMENT%ROWTYPE;
        L_DLPYMNTSMRY_REC   DLVW_PAYMENT_SUMMARY%ROWTYPE;
        L_SERIAL_NO         NUMBER;
        L_CHG_AMT           NUMBER;
        L_DUE_DATE          DATE;
        L_NEXT_DUE_DATE     DATE;
        L_CCY               DLTB_CALC.CURRENCY%TYPE;

        
        L_EXCHNGE_RATE      ACTB_DAILY_LOG.EXCH_RATE%TYPE;
        L_SETLMNT_AMT DETB_RTL_TELLER.TXN_AMOUNT%TYPE;
       
    BEGIN
    
    




















    
        DBG(' test999.1..');
    DBG('Selecting records from dltb_calc where status will not be U....'); 
        BEGIN
            
        DBG('The action type is:'||GWPKS_UTIL.PKG_ACTTYPE);
        IF NVL(GWPKS_UTIL.PKG_ACTTYPE,'*.*') = 'SAVEAUTOAUTH' THEN           
            SELECT SUM(CHARGE_AMOUNT)
                  ,CURRENCY
                  ,DUE_DATE
                  ,NEXT_DUE_DATE
            INTO   L_CHG_AMT
                  ,L_CCY
                  ,L_DUE_DATE
                  ,L_NEXT_DUE_DATE
            FROM   DLTB_CALC
            WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF AND
                   SEQ_NO =
                   (SELECT MAX(SEQ_NO)
                         FROM DLTB_CALC
                        WHERE CONTRACT_REF_NO =
                              P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF
                          AND STATUS = 'P')
            GROUP  BY CURRENCY
                     ,DUE_DATE
                     ,NEXT_DUE_DATE;
        ELSE 
        
                        SELECT SUM(CHARGE_AMOUNT)
                  ,CURRENCY
                  ,DUE_DATE
                  ,NEXT_DUE_DATE
            INTO   L_CHG_AMT
                  ,L_CCY
                  ,L_DUE_DATE
                  ,L_NEXT_DUE_DATE
            FROM   DLTB_CALC
            WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF AND
                   SEQ_NO =
                   (SELECT MIN(SEQ_NO)
                    FROM   DLTB_CALC
                    WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF AND STATUS = 'U') 
            GROUP  BY CURRENCY
                     ,DUE_DATE
                     ,NEXT_DUE_DATE;
         END IF; 
        EXCEPTION
            WHEN OTHERS THEN
                DBG('Failed in Slecting From dltb_calc in buildsddetails.. ');
                P_ERR_CODE   := 'DL-RVMP01';
                P_ERR_PARAM  := NULL;
                RETURN FALSE;
        END;
    DBG('Successfully selected a record from dltb_calc ....'); 
    
        DBG(' test7777777777777.1..');
    DBG('Successfully selected a record from dltb_contract_master ....');
        BEGIN
            SELECT *
            INTO   L_DLCONTRACT_REC
            FROM   DLTB_CONTRACT_MASTER
            WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF AND
                   EVENT_SEQ_NO =
                   (SELECT MAX(EVENT_SEQ_NO)
                    FROM   DLTB_CONTRACT_MASTER
                    WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF);
           
           L_DLCONTRACT_REC.SETTLEMENT_ACCOUNT:=NVL(P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_PAY_SUMMARY.SETLACC,L_DLCONTRACT_REC.SETTLEMENT_ACCOUNT);
           L_DLCONTRACT_REC.SETTLEMENT_BRANCH:=NVL(P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_PAY_SUMMARY.SETLBRN,L_DLCONTRACT_REC.SETTLEMENT_BRANCH);
           L_DLCONTRACT_REC.SETTLEMENT_CCY:=NVL(P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_PAY_SUMMARY.SETLCCY,L_DLCONTRACT_REC.SETTLEMENT_CCY);
            
        EXCEPTION
            WHEN OTHERS THEN
                DBG('Failed in Slecting From dltb_contract_master in buildsddetails.. ');
                P_ERR_CODE   := 'DL-RVMP01';
                P_ERR_PARAM  := NULL;
                RETURN FALSE;
        END;
         
         DBG('the settlemnt ccy>>'||L_DLCONTRACT_REC.SETTLEMENT_CCY||'PAYMENT CURRENCY>>'||L_CCY);
        IF  L_DLCONTRACT_REC.SETTLEMENT_CCY <> L_CCY THEN
                  IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                 L_CCY,
                                 L_DLCONTRACT_REC.SETTLEMENT_CCY,
                                 'STANDARD',
                                  'M',
                                 L_CHG_AMT,
                                 'Y',
                                 L_SETLMNT_AMT,
                                 L_EXCHNGE_RATE,
                                 P_ERR_CODE) THEN  
                                  DBG('Bombed with amt1_to_amt2 b/w ');
                      
                 END IF;   
        ELSE
        L_SETLMNT_AMT := L_CHG_AMT;  

        END IF;
         DBG('the settlemnt amount in ccy>>'||L_DLCONTRACT_REC.SETTLEMENT_CCY||'is>>'||L_SETLMNT_AMT);
        

        DBG(' test777.1..');
        
       




        


        DBG(' test888.1..');
        SELECT COUNT(*)
        INTO   L_SERIAL_NO
        FROM   DLTB_CONTRACT_LIQ_SUMMARY
        WHERE  CONTRACT_REF_NO = P_TY_RTUPLD.TY_SAFEDEPODETAILS.TY_CONTRACT_PAY.FCCREF;

        P_CNT_LVL := P_CNT_LVL + 1;
        P_PARENT  := P_PARENT || P_PARENT_RES || '>';
        P_KEY     := P_KEY || 'XREF' || '~' || 'FCCREF' || '~' || 'ESN' || '~' || 'VALDT' || '~' || 'CNTAMT' || '~' ||
                     'DUEDT' || '~' || 'NXTDUEDT' || '~' || 'SETLCCY' || '~' || 'SETLACC' || '~' || 'SETLBRN' || '~' ||
                     'CNTCCY' || '~' || 'CIFID' || '~' || 'CUST' || '~' || 
           'SETLAMT' || '~' ||  
'>';

        P_DATA := P_DATA || P_TY_RTUPLD.TY_UPLD_RTL_TELLER.XREF || '~' || L_DLCONTRACT_REC.CONTRACT_REF_NO || '~' ||
                  L_DLCONTRACT_REC.EVENT_SEQ_NO || '~' || TO_CHAR(GLOBAL.APPLICATION_DATE, 'RRRR-MM-DD') || '~' ||
                  L_CHG_AMT || '~' || TO_CHAR(L_DUE_DATE, 'RRRR-MM-DD') || '~' ||
                  TO_CHAR(L_NEXT_DUE_DATE, 'RRRR-MM-DD') || '~' || L_DLCONTRACT_REC.SETTLEMENT_CCY || '~' ||
                  L_DLCONTRACT_REC.SETTLEMENT_ACCOUNT || '~' || L_DLCONTRACT_REC.SETTLEMENT_BRANCH || '~' ||
                  L_CCY || '~' || L_DLCONTRACT_REC.CIF_ID || '~' || L_DLCONTRACT_REC.CUST_NAME || '~' || 
          NVL(L_SETLMNT_AMT,P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD18) || '~' ||  
'>';

        P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
        DBG('p_format ==> ' || P_FORMAT);
        DBG('p_parent ==> ' || P_PARENT);
        DBG('p_data ==> ' || P_DATA);
        DBG('p_key ==> ' || P_KEY);

        DBG('Returning Successfully from fn_build_SDdetails');

        RETURN TRUE;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBG('in NO_DATA_FOUND fn_build_SDdetails' || SQLERRM);
            P_ERR_CODE := 'WB-TXN-001'; 

            RETURN FALSE;
        WHEN OTHERS THEN
            DBG('in WOT fn_build_SDdetails' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building the Reply' || '~';
            DBG(SQLCODE || SQLERRM);
            RETURN FALSE;
    END FN_BUILD_SDDETAILS;
    
  
    FUNCTION FN_BUILD_SUBSYSPARENT(P_FCCREF       IN VARCHAR2
                                  ,P_PARENT       IN OUT VARCHAR2
                                  ,P_TAG          IN OUT VARCHAR2
                                  ,P_DATA         IN OUT VARCHAR2
                                  ,P_NODE         IN VARCHAR2
                                  ,P_FORMAT       IN OUT VARCHAR2
                                  ,P_PARENT_LEVEL IN OUT NUMBER
                                  ,P_ERR_CODE     IN OUT VARCHAR2
                                  ,P_ERR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN AS
    
    BEGIN
    
        P_PARENT       := P_PARENT || 'Csvws-Contract' || '>'; 
        P_TAG          := P_TAG || 'FCCREF' || '>';
        P_DATA         := P_DATA || P_FCCREF || '>';
        P_PARENT_LEVEL := P_PARENT_LEVEL + 1;
        P_FORMAT       := P_FORMAT || P_NODE || '.' || P_PARENT_LEVEL || '>';
    
        DBG('The function fn_build_subsysparent completed');
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-OTHR-001';
            P_ERR_PARAM := P_FCCREF || '~';
            RETURN FALSE;
    END FN_BUILD_SUBSYSPARENT;

    

    
    
    FUNCTION FN_REPLY_CHGDETS(P_SOURCE    IN VARCHAR2
                             ,P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                             ,P_DATA      IN OUT VARCHAR2
                             ,P_KEY       IN OUT VARCHAR2
                             ,P_PARENT    IN OUT VARCHAR2
                             ,P_FORMAT    IN OUT VARCHAR2
                             ,P_NODE      IN OUT VARCHAR2
                             ,P_CNT_LVL   IN OUT VARCHAR2
                             ,P_ERR_CODE  IN OUT VARCHAR2
                             ,P_ERR_PARAM IN OUT VARCHAR2)
    
     RETURN BOOLEAN IS
    
        
        
    
    L_TS_LIST      VARCHAR2(100) := 'CHGCOMP~WAIVER~CHGAMT~CHGCCY~MISHEAD~TXNCODE~NETTINGIND~CHGGL~TYPE~LCYCHG~XRATE~TCYCHG~TCYXRATE~';
    
    
        
    L_TS_VALUE     VARCHAR2(5000);
        L_PARENT_CNT   NUMBER := 0;
        L_CNT          NUMBER := 0;
        L_DETB_RTL_TLR DETBS_RTL_TELLER%ROWTYPE;
        L_CHGCOMP      VARCHAR2(255);
        L_WAIVER       VARCHAR2(1) := 'N';
        L_CHGAMT       DETBS_RTL_TELLER.CHG_AMT%TYPE;
        L_CHGCCY       DETBS_RTL_TELLER.CHG_CCY%TYPE;
        L_MISHEAD      DETBS_RTL_TELLER.MIS_HEAD_1%TYPE;
        L_TXNCODE      DETBS_RTL_TELLER.TXN_CODE%TYPE;
        L_NETTINGIND   DETBS_RTL_TELLER.NETTING_IND%TYPE;
        L_CHGGL        DETBS_RTL_TELLER.CHG_GL%TYPE;
    
        L_TYPE      VARCHAR2(1);
        L_LCYCHG    DETBS_RTL_TELLER.CHG_IN_LCY%TYPE;
        L_XRATE     DETBS_RTL_TELLER.CHG_CCY_ACY_RATE%TYPE;
        L_TCYCHG    DETBS_RTL_TELLER.CHG_IN_ACY%TYPE;
    
    
        L_TS_LIST1  VARCHAR2(100) := 'CHGCOMP~WAIVER~CHGAMT~CHGCCY~TYPE~LCYCHG~XRATE~CHGGL~THEIRACC~NETTINGIND~TXNCODE~CHGACY~MISHEAD~'; 
        
    
    
    L_TS_VALUE1 VARCHAR2(5000); 
        L_THR_ACC   VARCHAR2(5); 
    
    
    


    
        
    
    BEGIN
        DBG('Inside Function fn_reply_chgdets');
    
    IF PKG_RTL_TLR.TRN_REF_NO IS NULL 
    THEN 
    
      SELECT *
      INTO   L_DETB_RTL_TLR
      FROM   DETBS_RTL_TELLER
      WHERE  TRN_REF_NO = P_FCCREF;
    
    ELSE
      DBG('Already got no need to query again 1');
      L_DETB_RTL_TLR := PKG_RTL_TLR;
    END IF;
    
        LOOP
        
            L_CNT := L_CNT + 1;
            DBG('building reply for charge ' || L_CNT);
            EXIT WHEN L_CNT > 5;
            IF L_CNT = 1
            THEN
                L_CHGAMT     := L_DETB_RTL_TLR.CHG_AMT;
                L_CHGCCY     := L_DETB_RTL_TLR.CHG_CCY;
                L_MISHEAD    := L_DETB_RTL_TLR.MIS_HEAD_1;
                L_TXNCODE    := L_DETB_RTL_TLR.TXN_CODE;
                L_NETTINGIND := L_DETB_RTL_TLR.NETTING_IND;
                L_CHGGL      := L_DETB_RTL_TLR.CHG_GL;
                L_CHGCOMP    := L_DETB_RTL_TLR.CHG_DESC;
            
                L_CHGCCY := L_DETB_RTL_TLR.CHG_CCY;
                L_LCYCHG := L_DETB_RTL_TLR.CHG_IN_LCY;
                L_XRATE  := L_DETB_RTL_TLR.LCY_CHG_EXCH_RATE;
                L_TCYCHG := L_DETB_RTL_TLR.CHG_IN_ACY;
                L_WAIVER := L_DETB_RTL_TLR.WAIVER;
                L_TYPE   := L_DETB_RTL_TLR.CHG_TYPE;
            
            ELSIF L_CNT = 2
            THEN
                L_CHGAMT     := L_DETB_RTL_TLR.CHG_AMT_1;
                L_CHGCCY     := L_DETB_RTL_TLR.CHG_CCY_1;
                L_MISHEAD    := L_DETB_RTL_TLR.MIS_HEAD_2;
                L_TXNCODE    := L_DETB_RTL_TLR.TXN_CODE_1;
                L_NETTINGIND := L_DETB_RTL_TLR.NETTING_IND_1;
                L_CHGGL      := L_DETB_RTL_TLR.CHG_GL_1;
                L_CHGCOMP    := L_DETB_RTL_TLR.CHG_DESC1;
            
                L_CHGCCY := L_DETB_RTL_TLR.CHG_CCY_1;
                L_LCYCHG := L_DETB_RTL_TLR.CHG_IN_LCY_1;
                L_XRATE  := L_DETB_RTL_TLR.LCY_CHG_EXCH_RATE1;
                L_TCYCHG := L_DETB_RTL_TLR.CHG_IN_ACY_1;
                L_WAIVER := L_DETB_RTL_TLR.WAIVER1;
                L_TYPE   := L_DETB_RTL_TLR.CHG_TYPE1;
            ELSIF L_CNT = 3
            THEN
                L_CHGAMT     := L_DETB_RTL_TLR.CHG_AMT_2;
                L_CHGCCY     := L_DETB_RTL_TLR.CHG_CCY_2;
                L_MISHEAD    := L_DETB_RTL_TLR.MIS_HEAD_3;
                L_TXNCODE    := L_DETB_RTL_TLR.TXN_CODE_2;
                L_NETTINGIND := L_DETB_RTL_TLR.NETTING_IND_2;
                L_CHGGL      := L_DETB_RTL_TLR.CHG_GL_2;
                L_CHGCOMP    := L_DETB_RTL_TLR.CHG_DESC2;
            
                L_CHGCCY := L_DETB_RTL_TLR.CHG_CCY_2;
                L_LCYCHG := L_DETB_RTL_TLR.CHG_IN_LCY_2;
                L_XRATE  := L_DETB_RTL_TLR.LCY_CHG_EXCH_RATE2;
                L_TCYCHG := L_DETB_RTL_TLR.CHG_IN_ACY_2;
                L_WAIVER := L_DETB_RTL_TLR.WAIVER2;
                L_TYPE   := L_DETB_RTL_TLR.CHG_TYPE2;
            ELSIF L_CNT = 4
            THEN
                L_CHGAMT     := L_DETB_RTL_TLR.CHG_AMT_3;
                L_CHGCCY     := L_DETB_RTL_TLR.CHG_CCY_3;
                L_MISHEAD    := L_DETB_RTL_TLR.MIS_HEAD_4;
                L_TXNCODE    := L_DETB_RTL_TLR.TXN_CODE_3;
                L_NETTINGIND := L_DETB_RTL_TLR.NETTING_IND_3;
                L_CHGGL      := L_DETB_RTL_TLR.CHG_GL_3;
                L_CHGCOMP    := L_DETB_RTL_TLR.CHG_DESC3;
            
                L_CHGCCY := L_DETB_RTL_TLR.CHG_CCY_3;
                L_LCYCHG := L_DETB_RTL_TLR.CHG_IN_LCY_3;
                L_XRATE  := L_DETB_RTL_TLR.LCY_CHG_EXCH_RATE3;
                L_TCYCHG := L_DETB_RTL_TLR.CHG_IN_ACY_3;
                L_WAIVER := L_DETB_RTL_TLR.WAIVER3;
                L_TYPE   := L_DETB_RTL_TLR.CHG_TYPE3;
            ELSIF L_CNT = 5
            THEN
                L_CHGAMT     := L_DETB_RTL_TLR.CHG_AMT_4;
                L_CHGCCY     := L_DETB_RTL_TLR.CHG_CCY_4;
                L_MISHEAD    := L_DETB_RTL_TLR.MIS_HEAD_5;
                L_TXNCODE    := L_DETB_RTL_TLR.TXN_CODE_4;
                L_NETTINGIND := L_DETB_RTL_TLR.NETTING_IND_4;
                L_CHGGL      := L_DETB_RTL_TLR.CHG_GL_4;
                L_CHGCOMP    := L_DETB_RTL_TLR.CHG_DESC4;
            
                L_CHGCCY := L_DETB_RTL_TLR.CHG_CCY_4;
                L_LCYCHG := L_DETB_RTL_TLR.CHG_IN_LCY_4;
                L_XRATE  := L_DETB_RTL_TLR.LCY_CHG_EXCH_RATE4;
                L_TCYCHG := L_DETB_RTL_TLR.CHG_IN_ACY_4;
                L_WAIVER := L_DETB_RTL_TLR.WAIVER4;
                L_TYPE   := L_DETB_RTL_TLR.CHG_TYPE4;
            END IF;
            
            IF L_CHGAMT IS NOT NULL
            THEN
                P_CNT_LVL  := P_CNT_LVL + 1;
                L_TS_VALUE := L_CHGCOMP || '~' || L_WAIVER || '~' || L_CHGAMT || '~' || L_CHGCCY || '~' || L_MISHEAD || '~' ||
                              L_TXNCODE || '~' || L_NETTINGIND || '~' || L_CHGGL || '~' || L_TYPE || '~' || L_LCYCHG || '~' ||
                              L_XRATE || '~' || L_TCYCHG || '~' || L_XRATE || '~';
                
            
                
                L_TS_VALUE1 := L_CHGCOMP || '~' || L_WAIVER || '~' || L_CHGAMT || '~' || L_CHGCCY || '~' || L_TYPE || '~' ||
                               L_LCYCHG || '~' || L_XRATE || '~' || L_CHGGL || '~' || '' || '~' || L_NETTINGIND || '~' ||
                               L_TXNCODE || '~' || L_TCYCHG || '~' || L_MISHEAD || '~';
                
        
        


























      
                
        
            
                










 
            
                IF P_SOURCE = 'FLEXBRANCH'
                THEN
                    
                    P_PARENT := P_PARENT || 'Blk-Charge-Details>';
                
                    P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
                    P_KEY    := P_KEY || L_TS_LIST || '>';
                    P_DATA   := P_DATA || L_TS_VALUE || '>';
                ELSE
                
                    P_PARENT := P_PARENT || 'Wbvws-Charge-Details>';
                    P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
                    P_KEY    := P_KEY || L_TS_LIST1 || '>';
                    P_DATA   := P_DATA || L_TS_VALUE1 || '>';
                
                END IF;
            
                DBG('p_format==>' || P_FORMAT);
                DBG('p_parent==>' || P_PARENT);
            
            END IF;
            
        END LOOP;
    
        DBG('Successfully Returns From the Functionfn_Build_CHGS ');
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_reply_chgdets' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building Charge Details';
        
            RETURN TRUE;
    END FN_REPLY_CHGDETS;
    
    
   
    FUNCTION FN_REPLY_PROJECT(P_SOURCE    IN VARCHAR2
                             ,P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                             ,P_DATA      IN OUT VARCHAR2
                             ,P_KEY       IN OUT VARCHAR2
                             ,P_PARENT    IN OUT VARCHAR2
                             ,P_FORMAT    IN OUT VARCHAR2
                             ,P_NODE      IN OUT VARCHAR2
                             ,P_CNT_LVL   IN OUT VARCHAR2
                             ,P_ERR_CODE  IN OUT VARCHAR2
                             ,P_ERR_PARAM IN OUT VARCHAR2)

     RETURN BOOLEAN IS

        L_TS_LIST      VARCHAR2(100) := 'UNITID~PROJECTNAME~UNITPAYMENT~DEPOSITSLIPNO~';
        L_TS_VALUE     VARCHAR2(5000);
        L_PARENT_CNT   NUMBER := 0;
        L_CNT          NUMBER := 0;
        L_DETB_RTL_TLR DETBS_RTL_TELLER%ROWTYPE;



    BEGIN
        DBG('Inside Function fn_reply_project');
    
    IF PKG_RTL_TLR.TRN_REF_NO IS NULL 
    THEN 
    
      SELECT *
      INTO   L_DETB_RTL_TLR
      FROM   DETBS_RTL_TELLER
      WHERE  TRN_REF_NO = P_FCCREF;
    
    ELSE
      DBG('Already got no need to query again 2');
      L_DETB_RTL_TLR := PKG_RTL_TLR;
    END IF;
    
        P_CNT_LVL  := P_CNT_LVL + 1;
        L_TS_VALUE := L_DETB_RTL_TLR.UNIT_ID || '~' || L_DETB_RTL_TLR.PROJECT_NAME || '~' || L_DETB_RTL_TLR.UNIT_PAYMENT || '~' || L_DETB_RTL_TLR.DEPOSIT_SLIP_NO || '~' ;
              
                IF P_SOURCE = 'FLEXBRANCH'
                THEN
                    P_PARENT := P_PARENT || 'Blk-Project-Details>';
                    P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
                    P_KEY    := P_KEY || L_TS_LIST || '>';
                    P_DATA   := P_DATA || L_TS_VALUE || '>';
                END IF;

                DBG('p_format==>' || P_FORMAT);
                DBG('p_parent==>' || P_PARENT);

        DBG('Successfully Returns From the fn_reply_project ');
        RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_reply_project' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building Project Details';

            RETURN TRUE;
    END FN_REPLY_PROJECT;
    
   
    
    FUNCTION FN_REPLY_MCKDETS(P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                             ,P_DATA      IN OUT VARCHAR2
                             ,P_KEY       IN OUT VARCHAR2
                             ,P_PARENT    IN OUT VARCHAR2
                             ,P_FORMAT    IN OUT VARCHAR2
                             ,P_NODE      IN OUT VARCHAR2
                             ,P_CNT_LVL   IN OUT VARCHAR2
                             ,P_ERR_CODE  IN OUT VARCHAR2
                             ,P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
    
        L_TS_LIST    VARCHAR2(100);
        L_TS_VALUE   VARCHAR2(5000);
        L_PARENT_CNT NUMBER := 0;
        L_CNT        NUMBER := 0;
    
        CURSOR MCK_DET IS
            SELECT *
            FROM   ISVW_MCK_DETAILS
            WHERE  CONTRACT_REF_NO = P_FCCREF;
    
    BEGIN
        DBG('Inside Function fn_reply_mckdets');
        FOR EACH_REC IN MCK_DET
        LOOP
            DBG('Inside  mck_dets loop');
            P_CNT_LVL := P_CNT_LVL + 1;
            
            P_PARENT := P_PARENT || 'Blk-Cheque-Details>';
            P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
        
            P_KEY  := P_KEY || 'SRNO' || '~' || 'PAYBRN' || '~' || 'CHQNO' || '~' || 'STAT' || '~' || 'EXPDT' || '~' ||
                      'BENFNAME' || '~' || 'BENFADDR1' || '~' || 'BENFADDR2' || '~' || 'BENFADDR3' || '~' ||
                      'BENFADDR4' || '~' || 'CRNO' || '~' || 'ISB' || '~' || 'OTHERDETLS1' || '~' || 'OTHERDETLSTYPE1' || '~' ||
                      'OTHERDETLS2' || '~' || 'OTHERDETLSTYPE2' || '~' || 'OTHERDETLS3' || '~' || 'OTHERDETLSTYPE3' || '~' ||
                      'OTHERDETLS4' || '~' || 'OTHERDETLSTYPE4' || '~' || 'OTHERDETLS5' || '~' || 'OTHERDETLSTYPE5' || '~' ||
                      'OTHERDETLS6' || '~' || 'OTHERDETLSTYPE6' || '~>';
            P_DATA := P_DATA || EACH_REC.EVENT_SEQ_NO || '~' || EACH_REC.PAYABLE_BRANCH || '~' ||
                      EACH_REC.INSTRUMENT_NO || '~' 
                      || '~' || EACH_REC.EXPIRY_DATE || '~' || EACH_REC.ULT_BENEFICIARY1 || '~' ||
                      EACH_REC.ULT_BENEFICIARY2 || '~' || EACH_REC.ULT_BENEFICIARY3 || '~' || EACH_REC.ULT_BENEFICIARY4 || '~' ||
                      EACH_REC.ULT_BENEFICIARY5 || '~' 
                      || '~' || EACH_REC.ISSUING_BANK || '~' || EACH_REC.OTHER_DETAILS1 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE1 || '~' || EACH_REC.OTHER_DETAILS2 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE2 || '~' || EACH_REC.OTHER_DETAILS3 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE3 || '~' || EACH_REC.OTHER_DETAILS4 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE4 || '~' || EACH_REC.OTHER_DETAILS5 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE5 || '~' || EACH_REC.OTHER_DETAILS6 || '~' ||
                      EACH_REC.OTHER_DETAILS_TYPE6 || '~>';
            DBG('p_format==>' || P_FORMAT);
            DBG('p_parent==>' || P_PARENT);
        
        END LOOP;
    
        DBG('Successfully Returns From the fn_reply_mckdets ');
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_reply_mckdets' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building cheque Details';
        
            RETURN TRUE;
    END FN_REPLY_MCKDETS;

    
    FUNCTION FN_REPLY_MSGDETS(P_XREF      IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                             ,P_DATA      IN OUT VARCHAR2
                             ,P_KEY       IN OUT VARCHAR2
                             ,P_PARENT    IN OUT VARCHAR2
                             ,P_FORMAT    IN OUT VARCHAR2
                             ,P_NODE      IN OUT VARCHAR2
                             ,P_CNT_LVL   IN OUT VARCHAR2
                             ,P_ERR_CODE  IN OUT VARCHAR2
                             ,P_ERR_PARAM IN OUT VARCHAR2)
    
     RETURN BOOLEAN IS
    
        L_TS_LIST    VARCHAR2(100);
        L_TS_VALUE   VARCHAR2(5000);
        L_PARENT_CNT NUMBER := 0;
        L_CNT        NUMBER := 0;
    
        CURSOR MSG_DET IS
            SELECT *
            FROM   CSTBS_ARC_SETTLE
            WHERE  XREF = P_XREF;
    
    BEGIN
        DBG('Inside Function fn_reply_msgdets');
        FOR EACH_REC IN MSG_DET
        LOOP
        
            DBG('inside loop');
            P_CNT_LVL := P_CNT_LVL + 1;
            
            P_PARENT := P_PARENT || 'Blk-Message-Details>';
            P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
        
            P_KEY  := P_KEY || 'TYPE' || '~' || 'OPERCD' || '~' || 'INSTRCD' || '~' || 'TXNCD' || '~' || 'VDATECR' || '~' ||
                      'ORDCUST1' || '~' || 'ORDCUST2' || '~' || 'ORDCUST3' || '~' || 'ORDCUST4' || '~' || 'ORDCUST5' || '~' ||
                      'RECEIVER' || '~' || 'PAYDET1' || '~' || 'PAYDET2' || '~' || 'PAYDET3' || '~' || 'PAYDET4' || '~' ||
                      'SRI1' || '~' || 'SRI2' || '~' || 'SRI3' || '~' || 'SRI4' || '~' || 'SRI5' || '~' || 'SRI6' || '~' ||
                      'CHGDET' || '~' || 'REGREP1' || '~' || 'REGREP2' || '~' || 'REGREP3' || '~' || 'ECONT1' || '~' ||
                      'ECONT2' || '~' || 'ECONT3' || '~' || 'ECONT4' || '~' || 'ECONT5' || '~' || 'VDATEDR' || '~>';
            P_DATA := P_DATA || EACH_REC.TRANSFER_TYPE || '~' || EACH_REC.BANK_OPER_CODE || '~' || EACH_REC.INSTR_CODE || '~' ||
                      EACH_REC.TRAN_TYPE_CODE || '~' || (TO_CHAR(GLOBAL.APPLICATION_DATE, 'RRRR-MM-DD')) || '~' ||
                      EACH_REC.ORDERING_CUSTOMER1 || '~' || EACH_REC.ORDERING_CUSTOMER2 || '~' ||
                      EACH_REC.ORDERING_CUSTOMER3 || '~' || EACH_REC.ORDERING_CUSTOMER4 || '~' ||
                      EACH_REC.ORDERING_CUSTOMER5 || '~' || EACH_REC.RECEIVER || '~' || EACH_REC.PAYMENT_DETAILS1 || '~' ||
                      EACH_REC.PAYMENT_DETAILS2 || '~' || EACH_REC.PAYMENT_DETAILS3 || '~' || EACH_REC.PAYMENT_DETAILS4 || '~' ||
                      EACH_REC.SNDR_TO_RCVR_INFO1 || '~' || EACH_REC.SNDR_TO_RCVR_INFO2 || '~' ||
                      EACH_REC.SNDR_TO_RCVR_INFO3 || '~' || EACH_REC.SNDR_TO_RCVR_INFO4 || '~' ||
                      EACH_REC.SNDR_TO_RCVR_INFO5 || '~' || EACH_REC.SNDR_TO_RCVR_INFO6 || '~' ||
                      EACH_REC.CHARGES_DETAILS || '~' || EACH_REC.REGULATORY_REP1 || '~' || EACH_REC.REGULATORY_REP2 || '~' ||
                      EACH_REC.REGULATORY_REP3 || '~' || EACH_REC.ENVELOPE_CONTENTS1 || '~' ||
                      EACH_REC.ENVELOPE_CONTENTS2 || '~' || EACH_REC.ENVELOPE_CONTENTS3 || '~' ||
                      EACH_REC.ENVELOPE_CONTENTS4 || '~' || EACH_REC.ENVELOPE_CONTENTS5 || '~' ||
                      (TO_CHAR(GLOBAL.APPLICATION_DATE, 'RRRR-MM-DD')) || '~>';
            DBG('p_format==>' || P_FORMAT);
            DBG('p_parent==>' || P_PARENT);
        
        
        END LOOP;
    
        DBG('Successfully Returns From the fn_reply_msgdets ');
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_reply_msgdets' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building Charge Details';
        
            RETURN TRUE;
    END FN_REPLY_MSGDETS;
    
    
    
    
      
      FUNCTION FN_REPLY_PCDETAILS(P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                                 ,P_DATA      IN OUT VARCHAR2
                                 ,P_KEY       IN OUT VARCHAR2
                                 ,P_PARENT    IN OUT VARCHAR2
                                 ,P_FORMAT    IN OUT VARCHAR2
                                 ,P_NODE      IN OUT VARCHAR2
                                 ,P_CNT_LVL   IN OUT VARCHAR2
                                 ,P_ERR_CODE  IN OUT VARCHAR2
                                 ,P_ERR_PARAM IN OUT VARCHAR2)


     RETURN BOOLEAN IS

        L_TS_LIST    VARCHAR2(100);
        L_TS_VALUE   VARCHAR2(5000);
        L_PARENT_CNT NUMBER := 0;
        L_CNT        NUMBER := 0;
        L_PC_BANKCODE VARCHAR2(20);
        L_AC_OR_GL   STTBS_ACCOUNT.AC_OR_GL%TYPE;
        L_CUST_NAME   DETB_PCTRN.CUST_NAME%TYPE;
        L_CUST_ADDR1   DETB_PCTRN.CUST_ADDR1%TYPE;
        L_CUST_ADDR2   DETB_PCTRN.CUST_ADDR2%TYPE;
        L_CUST_ADDR3   DETB_PCTRN.CUST_ADDR3%TYPE;
        L_MOBILENO_EMAILID  DETB_PCTRN.MOBILENO_EMAILID%TYPE;
        L_COMM_MODE DETB_PCTRN.COMM_MODE%TYPE;
        L_MOBILE_NUMBER STTM_CUST_PERSONAL.MOBILE_NUMBER%TYPE;
        L_E_MAIL  STTM_CUST_PERSONAL.E_MAIL%TYPE;
        L_PC_TXN    DETM_RT_PREFERENCES.PC_TXN%TYPE;
        V_MOBILENO_EMAILID DETB_PCTRN.MOBILENO_EMAILID%TYPE;
        
        CURSOR PC_DET IS
            SELECT *
            FROM   DETB_PCTRN
            WHERE   TRN_REF_NO  = P_FCCREF;

    BEGIN
        DBG('Inside Function Fn_Reply_pcdetails');
        DBG('trn_ref_no------>'||P_FCCREF);
        DBG('-------VALIDATION CHECK FOR TAX DETAILS LIMIT IN FN_REPLY_PCDETAILS STARTS.......... ');
        DBG('gwpks_service_router.g_action'||GWPKS_SERVICE_ROUTER.G_ACTION);
    DBG('Txn acc ->'||PKG_RTL_TLR.TXN_ACC);
         IF GWPKS_SERVICE_ROUTER.G_ACTION = 'INPUT' THEN
             BEGIN
                SELECT AC_OR_GL INTO  L_AC_OR_GL
                 FROM STTBS_ACCOUNT
         
         WHERE AC_GL_NO = PKG_RTL_TLR.TXN_ACC; 
                


            
        
        EXCEPTION
                WHEN OTHERS THEN
                  L_AC_OR_GL := 'G';
                  DBG('l_ac_or_gl' || L_AC_OR_GL);
             END; 
       DBG('Pkg_rtl_tlr.product_code ->'||PKG_RTL_TLR.PRODUCT_CODE);
             BEGIN
               SELECT PC_TXN
                 INTO L_PC_TXN
                 FROM DETM_RT_PREFERENCES
          
         WHERE PRODUCT_CODE = PKG_RTL_TLR.PRODUCT_CODE; 
                


             
        
             EXCEPTION
               WHEN OTHERS THEN
                 L_PC_TXN := NVL(L_PC_TXN, 'N');
             END;
             DBG('l_ac_or_gl' || L_AC_OR_GL);
             DBG('p_Fccref' || P_FCCREF);
       DBG('Rel customer is ->'||PKG_RTL_TLR.REL_CUSTOMER);
             IF L_AC_OR_GL = 'A'  AND L_PC_TXN = 'Y'  
       THEN
                BEGIN
          
          





















 
          IF PKG_RTL_TLR.REL_CUSTOMER IS NULL
          THEN
            SELECT A.CUSTOMER_NAME1,
                A.ADDRESS_LINE1,
                A.ADDRESS_LINE2,
                A.ADDRESS_LINE3
               INTO L_CUST_NAME,
                L_CUST_ADDR1,
                L_CUST_ADDR2,
                L_CUST_ADDR3
               FROM STTM_CUSTOMER A
              WHERE A.CUSTOMER_NO =
                (SELECT CUST_NO
                   FROM STTB_ACCOUNT
                  WHERE AC_GL_NO = PKG_RTL_TLR.TXN_ACC); 
          ELSE
            SELECT A.CUSTOMER_NAME1,
                A.ADDRESS_LINE1,
                A.ADDRESS_LINE2,
                A.ADDRESS_LINE3
               INTO L_CUST_NAME,
                L_CUST_ADDR1,
                L_CUST_ADDR2,
                L_CUST_ADDR3
               FROM STTM_CUSTOMER A WHERE A.CUSTOMER_NO = PKG_RTL_TLR.REL_CUSTOMER;
          END IF;
          
                EXCEPTION
                WHEN OTHERS THEN 
                  DBG('failed in default the cust details to pc details tab' );
                END; 
                P_CNT_LVL := P_CNT_LVL + 1;
                P_PARENT := P_PARENT || 'Blk_Detb_Pctrn>';
                P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
    
                P_KEY  := P_KEY || 'CUST_NAME' || '~' || 'CUST_ADDR1' || '~' || 'CUST_ADDR2' || '~' || 'CUST_ADDR3' || '~' || 'PC_BANK_CODE' || '~' ||
                          'PC_ACCOUNT_NO' || '~' || 'PC_PROD_CAT' || '~' || 'PC_NETWORK_ID' || '~' || 'BEN_ACCT_TYPE' || '~' || 'BEN_NAME' || '~' ||
                          'BEN_ADDR1' || '~' || 'BEN_ADDR2' || '~' || 'BEN_ADDR3' || '~' || 'SENDER_RECVR_INFO1' || '~' || 'SENDER_RECVR_INFO2' || '~' ||
                          'SENDER_RECVR_INFO3' || '~' || 'COMM_MODE' || '~' ||  'MOBILE_NUMBER' ||'~' || 'EMAIL_ID' || '~>'; 
                P_DATA := P_DATA || L_CUST_NAME || '~' || L_CUST_ADDR1 || '~' || L_CUST_ADDR2 || '~' ||
                          L_CUST_ADDR3 || '~' ||'' || '~' || '' || '~' ||
                          '' || '~' || '' || '~' ||
                          '' || '~' || '' || '~' || '' || '~' ||
                          '' || '~' || '' || '~' || '' || '~' ||
                          ''||'~'||''||'~'||''||'~'||
                          L_MOBILENO_EMAILID||'~'||L_MOBILENO_EMAILID|| '~>'; 
                DBG('p_format==>' || P_FORMAT);
                DBG('p_parent==>' || P_PARENT);
                
               DBG('here here ac_or gl if ' );  
             END IF;
              DBG('here here INPUT if ' ); 
         END IF;
        
        BEGIN
        SELECT 
               PC_BANK_CODE INTO L_PC_BANKCODE
               FROM DETB_PCTRN 
               WHERE TRN_REF_NO = P_FCCREF;
        EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        L_PC_BANKCODE := NULL;
        END;
        DBG('PC_BANK_CODE'|| L_PC_BANKCODE);
        DBG('-------VALIDATION CHECK FOR TAX DETAILS LIMIT IN FN_REPLY_PCDETAILS ENDS.......... ');
        IF L_PC_BANKCODE IS NOT NULL
        THEN
        FOR EACH_REC IN PC_DET
        LOOP

            DBG('inside loop');
            P_CNT_LVL := P_CNT_LVL + 1;
            
            P_PARENT := P_PARENT || 'Blk_Detb_Pctrn>';
            P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';

            P_KEY  := P_KEY || 'CUST_NAME' || '~' || 'CUST_ADDR1' || '~' || 'CUST_ADDR2' || '~' || 'CUST_ADDR3' || '~' || 'PC_BANK_CODE' || '~' ||
                      'PC_ACCOUNT_NO' || '~' || 'PC_PROD_CAT' || '~' || 'PC_NETWORK_ID' || '~' || 'BEN_ACCT_TYPE' || '~' || 'BEN_NAME' || '~' ||
                      'BEN_ADDR1' || '~' || 'BEN_ADDR2' || '~' || 'BEN_ADDR3' || '~' || 'SENDER_RECVR_INFO1' || '~' || 'SENDER_RECVR_INFO2' || '~' ||
                      'SENDER_RECVR_INFO3' || '~' || 'COMM_MODE' || '~' ||  'MOBILE_NUMBER' ||'~' || 'EMAIL_ID' || '~>'; 
            P_DATA := P_DATA || EACH_REC.CUST_NAME || '~' || EACH_REC.CUST_ADDR1 || '~' || EACH_REC.CUST_ADDR2 || '~' ||
                      EACH_REC.CUST_ADDR3 || '~' ||EACH_REC.PC_BANK_CODE || '~' || EACH_REC.PC_ACCOUNT_NO || '~' ||
                      EACH_REC.PC_PROD_CAT || '~' || EACH_REC.PC_NETWORK_ID || '~' ||
                      EACH_REC.BEN_ACCT_TYPE || '~' || EACH_REC.BEN_NAME || '~' || EACH_REC.BEN_ADDR1 || '~' ||
                      EACH_REC.BEN_ADDR2 || '~' || EACH_REC.BEN_ADDR3 || '~' || EACH_REC.SENDER_RECVR_INFO1 || '~' ||
                      EACH_REC.SENDER_RECVR_INFO2||'~'||EACH_REC.SENDER_RECVR_INFO3||'~'||EACH_REC.COMM_MODE||'~'||
                      EACH_REC.MOBILENO_EMAILID||'~'|| EACH_REC.MOBILENO_EMAILID||'~>';
            DBG('p_format==>' || P_FORMAT);
            DBG('p_parent==>' || P_PARENT);

        
        END LOOP;
        END IF;
        DBG('Successfully Returns From the Fn_Reply_pcdetails ');
        RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function Fn_Reply_pcdetails' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building pc reply Details';

            RETURN TRUE;
    END FN_REPLY_PCDETAILS;    
    
    

FUNCTION FN_SPLIT_AMT_IN_WORDS(P_AMT_IN_WORDS IN VARCHAR2,
                               P_AMT_WORDS_1  OUT VARCHAR2,
                               P_AMT_WORDS_2  OUT VARCHAR2,
                               P_AMT_WORDS_3  OUT VARCHAR2,
                               P_LENGTH_WORDS IN VARCHAR2,
                               P_ERRS   IN OUT VARCHAR2,
                               P_PRMS   IN OUT VARCHAR2
                                  ) RETURN BOOLEAN IS
    L_LINE_NO NUMBER;
   L_AMT_WORDS_TEMP  VARCHAR2(1000);
   L_POSITION       NUMBER:=0;
   L_POSITION_2 NUMBER:=0;
    BEGIN
      DBG('Inside function fn_split_amt_in_words');
      L_LINE_NO := CEIL(P_LENGTH_WORDS/G_LENGTH);
       DBG('>> l_line_no:: '|| L_LINE_NO);
   FOR I IN 1 .. L_LINE_NO LOOP
     IF I=1 THEN
          L_AMT_WORDS_TEMP:=SUBSTR( P_AMT_IN_WORDS, 1 ,G_LENGTH );
          DBG('>> l_amt_words_TEMP for i=1 :: '|| L_AMT_WORDS_TEMP);
          L_POSITION := INSTR(L_AMT_WORDS_TEMP,' ',-1);
          DBG('>> the position is  :: '|| L_POSITION);
         P_AMT_WORDS_1:=SUBSTR( P_AMT_IN_WORDS, 1 ,L_POSITION );
          DBG('>> l_amt_words_final1:: '|| P_AMT_WORDS_1);
     ELSE
          DBG('>> now in the else loop:: ');
          L_AMT_WORDS_TEMP:=SUBSTR( P_AMT_IN_WORDS, L_POSITION ,L_POSITION+G_LENGTH );
           DBG('>> l_amt_words_TEMP for else :: '|| L_AMT_WORDS_TEMP);
            IF I<>L_LINE_NO THEN
            L_POSITION_2 := INSTR(L_AMT_WORDS_TEMP,' ',-1);
            ELSE
              L_POSITION_2 := P_LENGTH_WORDS;
            END IF;
          DBG('>> the position is for else :: '|| L_POSITION);
          DBG('>> the l_POSITION_2 is for else :: '|| L_POSITION_2);
          IF I=2 THEN
              DBG('>> the position is for else :: i ===2 !!!!!!!!! '|| L_POSITION);
          P_AMT_WORDS_2:=SUBSTR( P_AMT_IN_WORDS, L_POSITION ,L_POSITION_2 );
           L_POSITION := L_POSITION+L_POSITION_2;
          DBG('>> l_amt_words_final2:: '|| P_AMT_WORDS_2);
          DBG('>> l_POSITION  after process 1 now is :: '|| L_POSITION);
          DBG('>> l_POSITION_2   after process 1  now is :: '|| L_POSITION_2);
          ELSE
             DBG('>> the position is for else :: i ===3 !!!!!!!!! '|| L_POSITION);
          P_AMT_WORDS_3:=SUBSTR( P_AMT_IN_WORDS, L_POSITION ,L_POSITION_2 );
          DBG('>> l_amt_words_final3:: '|| P_AMT_WORDS_3);
          END IF;

      END IF;
     DBG('in WHEN OTHERS ...'|| SQLERRM);
  END LOOP;
  RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_DDContract_Res_PK' || SQLERRM);
            P_ERRS := 'DD-UPLOTH';
            P_PRMS := 'fn_DDContract_Res_PK ~' || SQLCODE;
            RETURN FALSE;
END FN_SPLIT_AMT_IN_WORDS;

    
    FUNCTION FN_REPLY_FTDETAILS(P_TY_RTUPLD  IN DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC
                               ,P_FCCREF    IN DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                               ,P_DATA      IN OUT VARCHAR2
                               ,P_KEY       IN OUT VARCHAR2
                               ,P_PARENT    IN OUT VARCHAR2
                               ,P_FORMAT    IN OUT VARCHAR2
                               ,P_NODE      IN OUT VARCHAR2
                               ,P_CNT_LVL   IN OUT VARCHAR2
                               ,P_ERR_CODE  IN OUT VARCHAR2
                               ,P_ERR_PARAM IN OUT VARCHAR2)

     RETURN BOOLEAN IS

    BEGIN
        DBG('Inside Function fn_reply_ftdetails');
        
         
   PR_SKIP_HANDLER('Pre_What_To_Do');
        IF NOT GWPKS_QUERYRETAILTELLER.FN_SKIP_CUSTOM THEN
            DBG('Calling gwpks_queryretailtlr_custom.fn_reply_ftdetails_Pre..');
           IF NOT GWPKS_QUERYRETAILTLR_CUSTOM.FN_REPLY_FTDETAILS_PRE( P_TY_RTUPLD,P_FCCREF,P_DATA,P_KEY,P_PARENT,P_FORMAT,P_NODE,P_CNT_LVL,P_ERR_CODE,P_ERR_PARAM ) THEN
            DBG('Failed in call to gwpks_queryretailtlr_custom.fn_reply_ftdetails_Pre');
            RETURN FALSE;
           END IF;

            END IF;

        IF NOT GWPKS_QUERYRETAILTELLER.FN_SKIP_CLUSTER THEN
            DBG('gwpks_queryretailtlr_cluster.fn_reply_ftdetails_Pre..');
            IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_REPLY_FTDETAILS_PRE( P_TY_RTUPLD,P_FCCREF,P_DATA,P_KEY,P_PARENT,P_FORMAT,P_NODE,P_CNT_LVL,P_ERR_CODE,P_ERR_PARAM ) THEN
             DBG('Failed in call to gwpks_queryretailtlr_cluster.fn_reply_ftdetails_Pre');
             RETURN FALSE;
    END IF;
        END IF;

       IF NOT GWPKS_QUERYRETAILTELLER.FN_SKIP_KERNEL THEN
        

        P_CNT_LVL  := P_CNT_LVL + 1;
        P_PARENT := P_PARENT || 'Blk-FT-Details>';
        P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
        
        P_KEY    := P_KEY || 'FTPRDCODE' || '~' || 'TNSCCY' || '~' || 'COUNTRY' || '~' || 'RECEIVER' || '~' ||
                    'ACC1' || '~' || 'ACC2' || '~' || 'ACC3' || '~' || 'ACC4' || '~' || 'ACC5' || '~' ||
                    'REMINFO1' || '~' || 'REMINFO2' || '~' || 'REMINFO3' || '~' || 'REMINFO4' || '~' ||
                    'COUNTRY2' || '~' || 'ULTBENDET1' || '~' || 'ULTBENDET2' || '~' || 'ULTBENDET3' || '~' ||
                    'ULTBENDET4' || '~' || 'ULTBENDET5' || '~>';
        
        P_DATA   := P_DATA || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD1 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD2 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD3 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD4 || '~' ||
                    GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD5 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD6 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD7 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD8 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD9 || '~' ||
                    GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD10 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD11 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD12 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD13 || '~' ||
                    GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD14 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD15 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD16 || '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD17 || '~' ||
                    GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD18|| '~' || GWPKSS_CREATERETAILTLR.G_FTDETAILS.CHAR_FIELD19 || '~>';
                    

                DBG('p_format==>' || P_FORMAT);
                DBG('p_parent==>' || P_PARENT);

        
  END IF;
      PR_SKIP_HANDLER('Post_what_to_do');
      IF NOT GWPKS_QUERYRETAILTELLER.FN_SKIP_CLUSTER THEN
          DBG('Calling gwpks_queryretailtlr_cluster.fn_reply_ftdetails_Post..');
          IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_REPLY_FTDETAILS_POST( P_TY_RTUPLD,P_FCCREF,P_DATA,P_KEY,P_PARENT,P_FORMAT,P_NODE,P_CNT_LVL,P_ERR_CODE,P_ERR_PARAM ) THEN
           DBG('Failed in call to gwpks_queryretailtlr_cluster.fn_reply_ftdetails_Post');
             RETURN FALSE;
          END IF;
    END IF;

      IF NOT GWPKS_QUERYRETAILTELLER.FN_SKIP_CUSTOM THEN
         DBG('Calling gwpks_queryretailtlr_custom.fn_reply_ftdetails_Post..');
         IF NOT GWPKS_QUERYRETAILTLR_CUSTOM.FN_REPLY_FTDETAILS_POST( P_TY_RTUPLD,P_FCCREF,P_DATA,P_KEY,P_PARENT,P_FORMAT,P_NODE,P_CNT_LVL,P_ERR_CODE,P_ERR_PARAM ) THEN
         DBG('Failed in call to gwpks_queryretailtlr_cluster.fn_reply_ftdetails_Post');
             RETURN FALSE;
          END IF;
       END IF;
         

        DBG('Successfully Returns From the fn_reply_ftdetails ');
        RETURN TRUE;

    EXCEPTION
        WHEN OTHERS THEN
            DBG('Error Inside Function fn_reply_ftdetails' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building FT Details';

            RETURN TRUE;
    END FN_REPLY_FTDETAILS;
    
    



    
    FUNCTION FN_BUILD_RTDETAILS(P_SOURCE       IN VARCHAR2
                               ,P_PARENT_RES   IN VARCHAR2
                               ,P_REFERENCE_NO IN VARCHAR2
                               ,P_TY_RTUPLD    IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC  
                               ,P_PARENT       IN OUT VARCHAR2
                               ,P_KEY          IN OUT VARCHAR2
                               ,P_DATA         IN OUT VARCHAR2
                               ,P_FORMAT       IN OUT VARCHAR2
                               ,P_NODE         IN OUT VARCHAR2
                               ,P_ERR_CODE     IN OUT VARCHAR2
                               ,P_ERR_PARAM    IN OUT VARCHAR2)
    
     RETURN BOOLEAN IS
    
  L_DTF      VARCHAR(10) := 'RRRR-MM-DD';
  L_DTSTAMPF VARCHAR(24) := 'RRRR-MM-DD HH24:MI:SS AM';

  L_DENMAMT1       NUMBER;
  L_DENMAMT2       NUMBER;
  L_TOT_CHG_IN_ACY NUMBER;
  L_ACTAMT         NUMBER;
  L_DR_ACC         DETBS_RTL_TELLER.DR_ACC%TYPE;
  L_TXN_AMT        DETBS_RTL_TELLER.TXN_AMOUNT%TYPE;
  L_OFS_AMT        DETBS_RTL_TELLER.OFS_AMOUNT%TYPE;
  L_CUST_ACCOUNT   STTM_CUST_ACCOUNT%ROWTYPE; 
  
  L_ROUTE_CODE      CSTBS_ARC_SETTLE.ROUTE_CODE%TYPE;
  L_FLAG          VARCHAR2(1):='N';
  L_ACC_WITH_INSTN1   CSTBS_ARC_SETTLE.ACC_WITH_INSTN1%TYPE;  
  L_ACC_WITH_INSTN2   CSTBS_ARC_SETTLE.ACC_WITH_INSTN2%TYPE;
  L_ACC_WITH_INSTN3   CSTBS_ARC_SETTLE.ACC_WITH_INSTN3%TYPE;
  L_ACC_WITH_INSTN4   CSTBS_ARC_SETTLE.ACC_WITH_INSTN4%TYPE;
  L_ACC_WITH_INSTN5   CSTBS_ARC_SETTLE.ACC_WITH_INSTN5%TYPE;
  L_STTB_ACC_REC      STTBS_ACCOUNT%ROWTYPE;
  L_CUSTOMER_REC      STTMS_CUSTOMER%ROWTYPE;
  L_TXN_CODE        VARCHAR2(1);
  
  L_TXN_ACC_DESC  STTB_ACCOUNT.AC_GL_DESC%TYPE := '';
  L_OFS_ACC_DESC  STTB_ACCOUNT.AC_GL_DESC%TYPE := '';
  
  
  
  L_RE_PAY_AMT        NUMBER;
  L_AMOUNT_FINANCED   NUMBER;
  L_AMOUNT_DISBURSED  NUMBER;
  L_HJPAYBLE          NUMBER;
  
  
  L_CHG_CONTRA_LEG DETBS_RTL_TELLER.CHG_CONTRA_LEG%TYPE;
  
  
  L_FN_CALL_ID            NUMBER;
  L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
  
  
  L_ACCOUNT   DETBS_RTL_TELLER.TXN_ACC%TYPE;
  L_BRANCH    DETBS_RTL_TELLER.TXN_BRANCH%TYPE;
  
  L_VIRR_ACC_NAME STTM_VIRTUAL_ACCOUNTS.VIR_ACC_NAME%TYPE;
  L_AC_OR_GL VARCHAR(100);
  L_ACCEPT_STAT VARCHAR2(20);
  
  L_TXNACC_AMT STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE; 
  L_TXNACC_NO STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  L_TXNACC_BRN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
  L_OFSACC_AMT STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE; 
  L_OFSACC_NO STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  L_OFSACC_BRN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
  L_DOWNPAYREFERENCE VARCHAR2(40); 
  L_UI_TXN_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  L_UI_OFS_ACC   STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
  
  L_CUST_NO STTM_CUST_ACCOUNT.CUST_NO%TYPE;
  L_CUSTOMER_NO STTM_CUST_ACCOUNT.CUST_NO%TYPE;
  L_STTB_ACC_DET STTBS_ACCOUNT%ROWTYPE; 
  
  L_CLTB_ACCOUNT_MASTER  CLTB_ACCOUNT_MASTER%ROWTYPE;
  
  L_CUSTOMER_LANGUAGE  STTM_CUSTOMER.LANGUAGE %TYPE;
  L_AMT_IN_WORDS      VARCHAR2(1000);
  L_LENGTH_AMT_WORDS NUMBER;
  L_AMT_IN_WORDS_1 VARCHAR2(1000);
  L_AMT_IN_WORDS_2 VARCHAR2(1000);
  L_AMT_IN_WORDS_3 VARCHAR2(1000);
  
  L_PARAM_VAL CSTB_PARAM.PARAM_VAL %TYPE; 
  
  L_TXN_LOCK_COUNT NUMBER:=0; --sampath starts Account balance lock error changes
 
    BEGIN
    
        DBG('Inside  fn_build_rtdetails');
        DBG('p_reference_no  :' || P_REFERENCE_NO);
        L_ACTAMT   := 0;
        L_DENMAMT1 := 0;
        L_DENMAMT2 := 0;
        BEGIN
          
      












      
      BEGIN
          DBG('The operation code is:'||CSPKS_REQ_GLOBAL.G_HEADER('OPERATION'));
          IF CSPKS_REQ_GLOBAL.G_HEADER('OPERATION') = 'ReverseTransaction' THEN
          IF DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO IS NULL THEN
          DBG('The depks_rtl_teller.pkg_rtl_teller_rec is not set');
             DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC := PKG_RTL_TLR;         
          END IF;
          END IF;
        EXCEPTION
        WHEN OTHERS THEN
        DBG('The global header object not set at 2');
      END;
      
      L_DR_ACC := PKG_RTL_TLR.DR_ACC;
      L_TXN_AMT := PKG_RTL_TLR.TXN_AMOUNT;
      L_OFS_AMT := PKG_RTL_TLR.OFS_AMOUNT;
      L_TOT_CHG_IN_ACY :=(NVL(PKG_RTL_TLR.CHG_IN_ACY, 0) +
                NVL(PKG_RTL_TLR.CHG_IN_ACY_1, 0) + NVL(PKG_RTL_TLR.CHG_IN_ACY_2, 0) +
                NVL(PKG_RTL_TLR.CHG_IN_ACY_3, 0) + NVL(PKG_RTL_TLR.CHG_IN_ACY_4, 0));
            DBG('l_dr_acc :' || L_DR_ACC);
            DBG('l_txn_amt :' || L_TXN_AMT);
            DBG('l_ofs_amt :' || L_OFS_AMT);
            DBG('l_tot_chg_in_acy :' || L_TOT_CHG_IN_ACY);
          
        EXCEPTION
            WHEN OTHERS THEN
                DBG('Failed while calculating total charge in acy' || SQLERRM);
        END;
        
        
        L_DENMAMT1 := L_OFS_AMT ;
        
        
        






    
        














        
        IF GWPKS_UTIL.PKG_FUNC IN ('8203', '5401','5402','5403','3401') 
        THEN
        
            
      
      











      L_TOT_CHG_IN_ACY := PKG_RTL_TLR.TOT_CHG_IN_TCY;
      
            
            DBG('l_Tot_Chg_In_Acy ' || L_TOT_CHG_IN_ACY);
            L_ACTAMT := L_OFS_AMT + L_TOT_CHG_IN_ACY;
            
        ELSIF GWPKS_UTIL.PKG_FUNC IN ('8004')  
            OR  NVL(GWPKS_CREATERETAILTLR.G_PARENT_FUNCTIONID,'*.*') IN ('8004') 
        THEN
            
      
      











      L_TOT_CHG_IN_ACY := PKG_RTL_TLR.TOT_CHG_IN_TCY;
      
            
            DBG('l_Tot_Chg_In_Acy ' || L_TOT_CHG_IN_ACY);
            L_ACTAMT := L_OFS_AMT - L_TOT_CHG_IN_ACY;
        
        ELSIF GWPKS_UTIL.PKG_FUNC IN ('5001') THEN
         L_ACTAMT:= L_TXN_AMT + L_TOT_CHG_IN_ACY;
         
        ELSIF L_DR_ACC = 'TXN'
        THEN
            
            DBG('l_dr_acc=TXN');
            
            IF GWPKS_UTIL.PKG_FUNC IN ('LOCH') 
            THEN 
                DBG('Inside LOCH');
                L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT;
            
            ELSE
                
                IF DEPKS_RTL_TELLER.PKG_ARC_ROW.CHG_FROM = 'TXN'
                THEN
                    DBG('Depks_Rtl_Teller.pkg_arc_row.Chg_From=TXN');
                    L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT + L_TOT_CHG_IN_ACY;
                ELSE
                    DBG('Depks_Rtl_Teller.pkg_arc_row.Chg_From=OFS');
                    L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT;
                END IF;
                
            END IF;
        ELSIF L_DR_ACC = 'OFS'
        THEN
            
            DBG('l_dr_acc=OFS');
            
            
            IF DEPKS_RTL_TELLER.PKG_ARC_ROW.CHG_FROM = 'TXN'
            THEN
                L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT - L_TOT_CHG_IN_ACY;
            ELSE
                L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT;
            END IF;
            
        END IF;
    
        DBG('l_actamt :' || L_ACTAMT);
  
  DBG('l_Tot_Chg_In_Acy>> :' || L_TOT_CHG_IN_ACY);
        DBG('l_Tot_Chg_In_Acy>> :' || L_TOT_CHG_IN_ACY);
        IF L_CHG_CONTRA_LEG = 'OFS'
        THEN
            IF L_DR_ACC = 'TXN'
            THEN
            L_DENMAMT2 := L_OFS_AMT - L_TOT_CHG_IN_ACY;          
            DBG('l_denmamt2>>11 :' || L_DENMAMT2);
           
            ELSIF L_DR_ACC = 'OFS'
            THEN
            L_DENMAMT2 := L_OFS_AMT + L_TOT_CHG_IN_ACY;
            DBG('l_denmamt2>>22 :' || L_DENMAMT2);                     
            END IF;
            
        ELSE 
            L_DENMAMT2 := L_OFS_AMT;
           
        END IF;
    
        DBG('l_chgamttil>> :' || L_DENMAMT2);
  
        
        DBG('depks_rtl_teller.pkg_rtl_teller_rec.txn_acc == '||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC);
         
        DBG('depks_rtl_teller.pkg_rtl_teller_rec.product_code:::'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.PRODUCT_CODE);
    DBG('depks_rtl_teller.pkg_rtl_teller_rec.ofs_acc:::'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_ACC);
    DBG('depks_rtl_teller.pkg_rtl_teller_rec.txn_acc:::'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC);
    DBG('depks_rtl_teller.pkg_rtl_teller_rec.ofs_branch:::'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_BRANCH);
    DBG('depks_rtl_teller.pkg_rtl_teller_rec.branch_code:::'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.BRANCH_CODE);
        IF (DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.PRODUCT_CODE ='FTRQ') THEN
           L_ACCOUNT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_ACC;
       L_BRANCH := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.OFS_BRANCH;
        ELSE
           L_ACCOUNT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC;
       L_BRANCH := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_BRANCH;
        END IF;
    DBG('l_account'||L_ACCOUNT);
       
        BEGIN
            SELECT *
            INTO   L_CUST_ACCOUNT
            FROM   STTM_CUST_ACCOUNT
           
            
            WHERE  CUST_AC_NO = L_ACCOUNT
            AND BRANCH_CODE =L_BRANCH;
            
      
      





















   
    
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
         NULL;
                
        END;
    
        DBG(' l_cust_account beneficiary address1 '||L_CUST_ACCOUNT.ADDRESS1);
        DBG(' l_cust_account beneficiary address2 '||L_CUST_ACCOUNT.ADDRESS2);
        DBG(' l_cust_account beneficiary address3 '||L_CUST_ACCOUNT.ADDRESS3);
        DBG(' l_cust_account beneficiary address4 '||L_CUST_ACCOUNT.ADDRESS4);
        DBG(' Pkg_rtl_tlr.Benef_Addr1 '||PKG_RTL_TLR.BENEF_ADDR1);
        DBG(' Pkg_rtl_tlr.Benef_Addr2 '||PKG_RTL_TLR.BENEF_ADDR2);
        DBG(' Pkg_rtl_tlr.Benef_Addr3 '||PKG_RTL_TLR.BENEF_ADDR3);
        DBG(' Pkg_rtl_tlr.Benef_Addr4 '||PKG_RTL_TLR.BENEF_ADDR4);
        
        IF (DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.PRODUCT_CODE ='FTRQ') THEN
           PKG_RTL_TLR.BENEF_ADDR1 := L_CUST_ACCOUNT.ADDRESS1;
           PKG_RTL_TLR.BENEF_ADDR2 := L_CUST_ACCOUNT.ADDRESS2;
           PKG_RTL_TLR.BENEF_ADDR3 := L_CUST_ACCOUNT.ADDRESS3;
           PKG_RTL_TLR.BENEF_ADDR4 := L_CUST_ACCOUNT.ADDRESS4;
       
        END IF;
        
        DBG(' beneficiary address '||L_CUST_ACCOUNT.ADDRESS1);
        
    
        BEGIN 
         DBG('The transaction account is:'||PKG_RTL_TLR.TXN_ACC);
     DBG('The offset account is:'||PKG_RTL_TLR.OFS_ACC);
     DBG('The transaction branch is:'||PKG_RTL_TLR.TXN_BRANCH);
     DBG('The offset branch is:'|| PKG_RTL_TLR.OFS_BRANCH);         
     SELECT AC_GL_DESC
     INTO L_TXN_ACC_DESC
           FROM STTBS_ACCOUNT
          WHERE PKG_RTL_TLR.TXN_ACC = AC_GL_NO
          AND PKG_RTL_TLR.TXN_BRANCH = NVL(BRANCH_CODE, PKG_RTL_TLR.TXN_BRANCH);   
        
            SELECT AC_GL_DESC
            INTO L_OFS_ACC_DESC
               FROM STTBS_ACCOUNT
              WHERE PKG_RTL_TLR.OFS_ACC = AC_GL_NO
                AND PKG_RTL_TLR.OFS_BRANCH = NVL(BRANCH_CODE, PKG_RTL_TLR.OFS_BRANCH);
    DBG('The offset account description is:'|| L_OFS_ACC_DESC);             
    DBG('The transaction account description is:'|| L_TXN_ACC_DESC);          
        EXCEPTION
           WHEN OTHERS THEN
                DBG('In OTHERS with line tracking...... ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        END;
        
        
         DBG('Finally We got pkg_txnlegcashAmt '|| DEPKS_RTL_TELLER.PKG_TXNLEGCASHAMT);
         DBG('Finally We got pkg_ofslegcashAmt '|| DEPKS_RTL_TELLER.PKG_OFSLEGCASHAMT);         
        

    
         DBG('For Special CASE function in query retail teller:'||GWPKS_UTIL.PKG_FUNC);
         IF GWPKS_UTIL.PKG_FUNC NOT IN ('1300','1301','1317','1320','1350','3401','5001','5401',
         'IPTDMM','TDMM','TDTP','5402','5403') THEN 
         
         DBG(' depks_rtl_teller.pkg_TxnactAmt '||DEPKS_RTL_TELLER.PKG_TXNACTAMT );
         IF DEPKS_RTL_TELLER.PKG_TXNACTAMT  IS NOT NULL
         THEN
         L_ACTAMT := DEPKS_RTL_TELLER.PKG_TXNACTAMT;         
         END IF;           
     
     BEGIN
       DBG('The gwpkss_reverseretailtlr.pkg_account_amt is:'||GWPKSS_REVERSERETAILTLR.PKG_ACCOUNT_AMT);
       DBG('The account amount b4 reverse operation is:'||L_ACTAMT);
       IF CSPKS_REQ_GLOBAL.G_HEADER('OPERATION') = 'ReverseTransaction' THEN
        L_ACTAMT := NVL(GWPKSS_REVERSERETAILTLR.PKG_ACCOUNT_AMT,L_ACTAMT);
       END IF;
       EXCEPTION
       WHEN OTHERS THEN
       DBG('The global header object not found');
     END;
     
           
    DBG('the virtual account number is'||DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO);
    BEGIN
  IF DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO <> 'NULL' THEN
  DBG('Virtual account hence getting the account name');
      SELECT VIR_ACC_NAME
      INTO L_VIRR_ACC_NAME
      FROM STTM_VIRTUAL_ACCOUNTS
      WHERE VIR_ACC_NO=DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO AND CCY = PKG_RTL_TLR.TXN_CCY;
   END IF;
  EXCEPTION
  WHEN OTHERS THEN
   DBG('Failed while getting the virtual account name');
   END;
     DBG('The virrual account name is'||L_VIRR_ACC_NAME);
    
         DBG('Finally l_actamt :' || L_ACTAMT); 
    END IF; 
    
        
        
        IF ((GWPKS_UTIL.PKG_FUNC='1406' AND PKG_RTL_TLR.PRODUCT_CODE='CXTR') OR
             (GWPKS_UTIL.PKG_FUNC='1461' AND PKG_RTL_TLR.PRODUCT_CODE='ECAS'))
        THEN
            DBG('l_dr_acc=OFS AND 1406');
            BEGIN
              SELECT AC_OR_GL
              INTO L_AC_OR_GL
              FROM STTB_ACCOUNT
              WHERE AC_GL_NO =DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('failed in selecting the account type..' || SQLERRM);
            END;
            
           IF L_AC_OR_GL<> 'A'
            THEN
            DBG('NON ACC');
                L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT + L_TOT_CHG_IN_ACY;
            ELSE
              DBG('IN ELSE');
                L_ACTAMT := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_AMOUNT;
            END IF;
        END IF;

         IF PKG_RTL_TLR.TXN_ACC IS NOT NULL AND GWPKS_UTIL.PKG_FUNC  IN ('5401')  THEN
           BEGIN
             SELECT  A.AMOUNT_FINANCED
             ,A.AMOUNT_DISBURSED       
       INTO L_CLTB_ACCOUNT_MASTER.AMOUNT_FINANCED, 
       L_CLTB_ACCOUNT_MASTER.AMOUNT_DISBURSED
             FROM CLTB_ACCOUNT_MASTER A
             WHERE  ACCOUNT_NUMBER = PKG_RTL_TLR.TXN_ACC;
           EXCEPTION
              WHEN OTHERS THEN
                DBG('failed in selecting the amount_financed/amount_disbursed...' || SQLERRM);
            END;                
          END IF;

        
        
         DBG('gwpks_util.pkg_actType '||GWPKS_UTIL.PKG_ACTTYPE);    
        IF GWPKS_UTIL.PKG_ACTTYPE IN ('REVERSE') THEN
        DBG('Inside ..');
        L_ACTAMT := NVL(GWPKSS_REVERSERETAILTLR.PKG_ACCOUNT_AMT,L_ACTAMT);
       END IF;
        DBG(' 2 Finally l_actamt :' || L_ACTAMT);   
		
		--sampath starts Account balance lock error
    IF DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.PRODUCT_CODE = 'KHQR' --SUBSTR(Depks_rtl_teller.pkg_rtl_teller_rec.TRN_REF_NO, 4, 4) = 'KHQR'
       AND ((Depks_rtl_teller.pkg_rtl_teller_rec.txn_acc = '000072693' AND
       Depks_rtl_teller.pkg_rtl_teller_rec.ofs_acc = '389210047') OR
       (Depks_rtl_teller.pkg_rtl_teller_rec.txn_acc = '000072707' AND
       Depks_rtl_teller.pkg_rtl_teller_rec.ofs_acc = '389210047')) THEN
       
       dbg('Depks_rtl_teller.pkg_rtl_teller_rec.txn_amount='||Depks_rtl_teller.pkg_rtl_teller_rec.txn_amount);
       dbg('Depks_rtl_teller.pkg_rtl_teller_rec.ofs_amount='||Depks_rtl_teller.pkg_rtl_teller_rec.ofs_amount);
       dbg('PKG_RTL_TLR.TXN_AMOUNT='||PKG_RTL_TLR.TXN_AMOUNT);
       dbg('PKG_RTL_TLR.OFS_AMOUNT='||PKG_RTL_TLR.OFS_AMOUNT);
       
       BEGIN
         SELECT COUNT(1) INTO L_TXN_LOCK_COUNT FROM IFTB_KHQR_TXNS_LOCK_MASTER A 
         WHERE A.FC_XREF_NO = Depks_rtl_teller.pkg_rtl_teller_rec.xref
         AND A.TRN_REF_NO = Depks_rtl_teller.pkg_rtl_teller_rec.trn_ref_no;
       EXCEPTION
         WHEN OTHERS THEN
         L_TXN_LOCK_COUNT := 0;
       END;
       
     IF L_TXN_LOCK_COUNT = 1 THEN --DEPKS_RTL_TELLER.G_TXN_LOCK_FLAG  THEN
    
      IF PKG_RTL_TLR.TXN_AMOUNT /*Depks_rtl_teller.pkg_rtl_teller_rec.txn_amount */is null then
      
        IF Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy = 'USD' AND
           Depks_rtl_teller.pkg_rtl_teller_rec.OFS_CCY = 'KHR' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT /
                                                            Depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy = 'KHR' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.OFS_CCY = 'USD' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT *
                                                            depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy = 'KHR' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.OFS_CCY = 'KHR' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy = 'USD' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.OFS_CCY = 'USD' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.txn_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.TXN_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
        END IF;
      
      ELSIF PKG_RTL_TLR.ofs_amount /*Depks_rtl_teller.pkg_rtl_teller_rec.ofs_amount*/ is null then
      
        IF Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy = 'USD' AND
           Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY = 'KHR' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT /
                                                            Depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.ofs_amount := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy = 'KHR' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY = 'USD' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT *
                                                            depks_rtl_teller.pkg_rtl_teller_rec.EXCH_RATE;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.ofs_amount := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy = 'KHR' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY = 'KHR' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.ofs_amount := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
        ELSIF Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy = 'USD' AND
              Depks_rtl_teller.pkg_rtl_teller_rec.TXN_CCY = 'USD' THEN
        
          Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT := Depks_rtl_teller.pkg_rtl_teller_rec.TXN_AMOUNT;
        
          IF NOT
              cypks.fn_amt_round(Depks_rtl_teller.pkg_rtl_teller_rec.ofs_ccy,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT,
                                 Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT) THEN
            RETURN FALSE;
          END IF;
          
          PKG_RTL_TLR.ofs_amount := Depks_rtl_teller.pkg_rtl_teller_rec.OFS_AMOUNT;
        
        END IF;
      
      END IF;
    
      Depks_rtl_teller.pkg_rtl_teller_rec.MAKER_DT_STAMP := SYSDATE;
      PKG_RTL_TLR.MAKER_DT_STAMP := SYSDATE;
      
      Depks_rtl_teller.pkg_rtl_teller_rec.Value_Dt       := Depks_rtl_teller.pkg_rtl_teller_rec.Trn_Dt;
      PKG_RTL_TLR.Value_Dt := Depks_rtl_teller.pkg_rtl_teller_rec.Trn_Dt;
      
      PKG_RTL_TLR.TXN_TRN_CODE := 'KQR';
      PKG_RTL_TLR.OFS_TRN_CODE := 'KQR';
      
      --Extra
      PKG_RTL_TLR.TRACK_RECEIVABLE := 'N';
      PKG_RTL_TLR.LCY_EXCH_RATE := 1;
      PKG_RTL_TLR.DR_ACC := 'TXN';
      PKG_RTL_TLR.CHARGE_ACCOUNT := '389210047';
      PKG_RTL_TLR.TOT_CHG_IN_TCY := 0;
      
      END IF;
    
    END IF;
    --sampath ends Account balance lock error
        
           IF NVL(GWPKS_UTIL.PKG_FUNC, '***') = 'SCTT' AND 
             NVL(GWPKS_UTIL.G_TWOSTEPPROCESS, 'N') = 'Y' AND
             NVL(GWPKS_UTIL.G_FIRSTSTEPDONE, 'N') = 'Y' AND
             NVL(GWPKS_UTIL.G_BRNNEWFLOW, 'N') = 'Y' THEN  
             DBG('updating the acceptance status to completed');
             L_ACCEPT_STAT:= 'Completed';
             END IF; 
        
    
      BEGIN
        DBG('About to check for Advice specific Customer language with global language as:'||GLOBAL.LANG);
          SELECT LANGUAGE INTO L_CUSTOMER_LANGUAGE FROM STTM_CUSTOMER WHERE CUSTOMER_NO =PKG_RTL_TLR.REL_CUSTOMER;
          DBG('The language for the customer is:'||L_CUSTOMER_LANGUAGE);
        EXCEPTION
         WHEN NO_DATA_FOUND THEN
         DBG('There is no data maintained for the customer language');
         L_CUSTOMER_LANGUAGE := GLOBAL.LANG;
         WHEN OTHERS THEN
        DBG('In When others of Advice specific Customer language with error code as:'||SQLCODE||' and message as:'||SQLERRM);
        DBG(SQLCODE || SQLERRM);
        END;

    IF L_DR_ACC = 'TXN' THEN

       DBG('Main leg is TXN: here i am with:: ccy '|| PKG_RTL_TLR.TXN_CCY || '  amt:: '|| PKG_RTL_TLR.TXN_AMOUNT);
      L_AMT_IN_WORDS := CSPKES_MISC.FN_NUM2WORDS(L_CUSTOMER_LANGUAGE, 
                            PKG_RTL_TLR.TXN_AMOUNT,
                            PKG_RTL_TLR.TXN_CCY);
      DBG('>> l_amt_in_words:: '|| L_AMT_IN_WORDS);


    ELSIF L_DR_ACC = 'OFS' THEN
         DBG('Main leg is OFS: here i am with:: ccy '|| PKG_RTL_TLR.OFS_CCY || '  amt:: '|| NVL(PKG_RTL_TLR.OFS_AMOUNT, PKG_RTL_TLR.LCY_AMOUNT));
        L_AMT_IN_WORDS := CSPKES_MISC.FN_NUM2WORDS(L_CUSTOMER_LANGUAGE, 
                            NVL(PKG_RTL_TLR.OFS_AMOUNT, PKG_RTL_TLR.LCY_AMOUNT),
                            PKG_RTL_TLR.OFS_CCY);
        DBG('>> l_amt_in_words:: '|| L_AMT_IN_WORDS);
          
    END IF;
           
     BEGIN
     SELECT PARAM_VALUE INTO G_LENGTH FROM CSTM_BRANCH_LOC_PARAMS
     WHERE PARAM_NAME ='LENGTH_AMT_WORDS';
    DBG('the amximum no of words to be included in single line is'||G_LENGTH);
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    DBG('There is no data maintained for the length of amount in words :');
    G_LENGTH := 80;
    WHEN OTHERS THEN
    DBG('IN others for getting the max length of amount in words for advice');
    DBG(SQLCODE || SQLERRM);
    END;

    L_LENGTH_AMT_WORDS := LENGTH(L_AMT_IN_WORDS);
     DBG(' the length of amount in words  is**...'|| L_LENGTH_AMT_WORDS);
     
    IF  L_LENGTH_AMT_WORDS >G_LENGTH THEN
      DBG('GOING to split  amount in words**');
      IF NOT FN_SPLIT_AMT_IN_WORDS(L_AMT_IN_WORDS,L_AMT_IN_WORDS_1,L_AMT_IN_WORDS_2,L_AMT_IN_WORDS_3,L_LENGTH_AMT_WORDS,P_ERR_CODE,P_ERR_PARAM)THEN
      RETURN FALSE;
      END IF;
      DBG(' l_amt_words_final1**...'|| L_AMT_IN_WORDS_1);
        DBG('l_amt_words_final2**..'|| L_AMT_IN_WORDS_2);
        DBG('l_amt_words_final3**...'|| L_AMT_IN_WORDS_3);
    ELSE
      DBG('IN else will not split the amount in words**');
      L_AMT_IN_WORDS_1 :=L_AMT_IN_WORDS;
    END IF;            
     
        P_PARENT := P_PARENT || P_PARENT_RES || '>';
        P_KEY    := P_KEY || 'XREF' || '~' || 'FCCREF' || '~' || 'PRD' || '~' || 'ESN' || '~' || 'EVNTCD' || '~' ||
                    'BRN' || '~' || 'MODULE' || '~' || 'TXNBRN' || '~' || 'TXNACC' || '~' || 'TXNCCY' || '~' ||
                    'TXNAMT' || '~' || 'TXNTRN' || '~' || 'OFFSETBRN' || '~' || 'OFFSETACC' || '~' || 'OFFSETCCY' || '~' ||
                    'OFFSETAMT' || '~' || 'OFFSETTRN' || '~' || 'XRATE' || '~' || 'LCYAMT' || '~' || 'TXNDATE' || '~' ||
                    'VALDATE' || '~' || 'RELCUST' || '~' || 'REMACCOUNT' || '~' || 'REMBANK' || '~' || 'REMBRANCH' || '~' ||
                    'ROUTINGNO' || '~' || 'ENDPOINT' || '~' || 'SERIALNO' || '~' || 'ROUTECODE' || '~' || 'DRINSTCD' || '~' ||
                    'CRINSTCD' || '~' || 'TCYCHGAMT' || '~' || 'TCYCHGAMT1' || '~' || 'TCYCHGAMT2' || '~' ||
                    'TCYCHGAMT3' || '~' || 'TCYCHGAMT4' || '~' || 'TCYTOTCHGAMT' || '~' || 'REPREASON' || '~' ||
                    'NARRATIVE' || '~' || 'TRACKREVERSE' || '~' || 'LCYXRATE' || '~' || 'MAKERID' || '~' ||
                    'MAKERSTAMP' || '~' || 'CHECKERID' || '~' || 'CHECKERSTAMP' || '~' || 'MODNO' || '~' || 'RECSTAT' || '~' ||
                    'AUTHSTAT' || '~' || 'SCODE' || '~' || 'LCYCHGAMT' || '~' || 'CHGACYXRATE' || '~' || 'CHGLCYXRATE' || '~' ||
                    'LCYCHGAMT1' || '~' || 'CHGACYXRATE1' || '~' || 'CHGLCYXRATE1' || '~' || 'LCYCHGAMT2' || '~' ||
                    'CHGACYXRATE2' || '~' || 'CHGLCYXRATE2' || '~' || 'LCYCHGAMT3' || '~' || 'CHGACYXRATE3' || '~' ||
                    'CHGLCYXRATE3' || '~' || 'LCYCHGAMT4' || '~' || 'CHGACYXRATE4' || '~' || 'CHGLCYXRATE4' || '~' ||
                    'DRACC' || '~' || 'FTPRBLM' || '~' || 'TIMERECV' || '~' || 'THEIRCHGS' || '~' || 'THEIRCHGS1' || '~' ||
                    'THEIRCHGS2' || '~' || 'THEIRCHGS3' || '~' || 'THEIRCHGS4' || '~' || 'THEIRACC' || '~' ||
                    'THEIRACC1' || '~' || 'THEIRACC2' || '~' || 'THEIRACC3' || '~' || 'THEIRACC4' || '~' || 'BATCHNO' || '~' ||
                    'CALCHG' || '~' || 'TXNDRCR' || '~' || 'BOOKDATE' || '~' || 'CLGBNK' || '~' || 'OFFSETLCYAMT' || '~' ||
                    'TRANCOUNT' || '~' || 'FT' || '~' || 'UTLBNF1' || '~' || 'UTLBNF2' || '~' || 'UTLBNF3' || '~' ||
                    'UTLBNF4' || '~' || 'ULTBNF5' || '~' || 'AWI1' || '~' || 'AWI2' || '~' || 'AWI3' || '~' || 'AWI4' || '~' ||
                    'AWI5' || '~' || 'COUNTRY' || '~' || 'LCYTOTCHGAMT' || '~' || 'DENMCCY1' || '~' || 'DENMAMT1' || '~' ||
                    'DENMCCY2' || '~' || 'DENMAMT2' || '~' || 'ACCTITLE1' || '~' || 'ACCTITLE2' || '~' || 'ACTAMT' || '~' ||
                   
                    'BENFNAME' || '~' || 'BENFADDR1' || '~' || 'BENFADDR2' || '~' || 'BENFADDR3' || '~' || 'BENFADDR4' || '~' ||
                    'OTHERDETLS1' || '~' || 'INSTRDATE'
                   || '~' ||'CHEQUE_ISSUE_DATE' 
                    || '~' || 'CUSTNAME' 
                    
                    || '~' || 'HJPAYBLE' 
                    ||'~'||'RE_PAY_AMT' 
                    ||'~'||'AMOUNT_FINANCED' 
                    ||'~'||'AMOUNT_DISBURSED'
                    
                    
                    ||'~'||'FNACCREF'
                    ||'~'||'HJREF'
                    
          || '~' || 'REJECTFLAG' 
                    || '~' || 'NEGOTRATE' || '~' || 'NEGOTREFNO' ||'~' ||
                    'PROJECTNAME' ||'~' ||'UNITPAYMENT'||'~' ||'UNITID'||'~' ||'DEPOSITSLIPNO'
                    ||'~'||'ACCTITLE23' 
                    ||'~' ||'CREDITCARDNO'||'~' ||'CREDITCARDNAME'||'~' 
                    ||'REJECT_CODE' 
                    ||'~' ||'TOTIL' 
                    || '~' || 'TOKENNO' 
                    || '~' || 'VIRACCNO' 
                    ||'~'||'UI_TXN_ACC' 
          ||'~' ||'UI_OFS_ACC' 
                      || '~' || 'TXNLEGCASHAMT' 
                     || '~' || 'OFSLEGCASHAMT' 
                    
                    || '~' || 'DENOM_VARIANCE' 
                    || '~' || 'ORG_EXCH_RATE'
                    || '~' || 'ORG_AMOUNT'
                    
                    
                    || '~' || 'AMOUNT_FINANCED'|| '~' || 'AMOUNT_DISBURSED'
                    
                        || '~' || 'PARENT_FN_ID' 
          || '~' || 'ADV_ACC'
|| '~' || 'ACCTYPE'
               ||'~'||'COMM_MODE'||'~'||'MOBILE_NUMBER'||'~'||'EMAIL_ID' ||'~'||'COUNTRYFT' 
               ||'~'||'DAYS'||'~'||'MONTHS'||'~'||'YEARS' ||'~'||'DOCNUMBER' 
               ||'~'||'DOCTYPE'||'~'||'DOCCATEGORY'||'~'||'SDBREFNO' ||'~'||'FUNDREFNO' 
         ||'~'||'TOTILID'||'~'||'BRNIBTILUPDATE'||'~'||'FRMTILID'||'~'||'ACPTSTAT'
               ||'~'||'ACCCY'||'~'||'CHRACC'   
               
               ||'~'||'AMT_IN_WORDS'||'~'||'AMT_IN_WORDS_1'||'~'||'AMT_IN_WORDS_2'||'~'||'AMT_IN_WORDS_3'
               
                    || '~' ||'TXNHOSTACCBAL~'||'TXNHOSTACCNO~'||'TXNHOSTACCBRN~'||'OFSHOSTACCBAL~'||'OFSHOSTACCNO~'||
          
          
          'OFSHOSTACCBRN~'||'PARAM_VAL~'||'~>';
          
            
    
    


































































      






















     IF NOT CVPKSS_UTILS.GET_STTB_ACC(PKG_RTL_TLR.TXN_BRANCH,
                      PKG_RTL_TLR.TXN_ACC,
                      L_STTB_ACC_REC
                      )
     THEN
      DBG('not able to gett sttb acc record');
     END IF;
     
   IF NOT ACPKSS_MISC.FN_GETAVLBAL(PKG_RTL_TLR.TXN_BRANCH,
                    PKG_RTL_TLR.TXN_ACC,
                    L_TXNACC_AMT,
                    'Y')
    THEN
      DBG('Unable to fetch Transaction account Amount');
    ELSE
       L_TXNACC_NO :=  PKG_RTL_TLR.TXN_ACC;
       L_TXNACC_BRN := PKG_RTL_TLR.TXN_BRANCH;
    END IF;

    IF NOT ACPKSS_MISC.FN_GETAVLBAL(PKG_RTL_TLR.OFS_BRANCH,
                                    PKG_RTL_TLR.OFS_ACC,
                                    L_OFSACC_AMT,
                                    'Y')
    THEN
      DBG('Unable to fetch Transaction account Amount');
    ELSE
       L_OFSACC_NO :=  PKG_RTL_TLR.OFS_ACC;
       L_OFSACC_BRN := PKG_RTL_TLR.OFS_BRANCH;
    END IF;
    DBG('Offset account:'||PKG_RTL_TLR.OFS_ACC||' from branch:'||PKG_RTL_TLR.OFS_BRANCH||' has a balance of:'||L_OFSACC_AMT);
    DBG('Txn account:'||PKG_RTL_TLR.TXN_ACC||' from branch:'||PKG_RTL_TLR.TXN_BRANCH||' has a balance of:'||L_TXNACC_AMT);
    
    
    
  IF GWPKS_UTIL.PKG_FUNC IN ('1406') AND PKG_RTL_TLR.CHARGE_ACCOUNT IS NOT NULL THEN
   DBG('getting the customer for charge account');
   DBG('Pkg_rtl_tlr.txn_branch'||PKG_RTL_TLR.TXN_BRANCH);
   DBG('Pkg_rtl_tlr.Charge_Account'||PKG_RTL_TLR.CHARGE_ACCOUNT);
    IF NOT CVPKS_UTILS.GET_STTB_ACC(PKG_RTL_TLR.TXN_BRANCH, PKG_RTL_TLR.CHARGE_ACCOUNT, L_STTB_ACC_DET) THEN
     DBG('not able to gett sttb acc record');
    END IF;
   IF L_STTB_ACC_DET.AC_OR_GL = 'A' THEN
     DBG('here0000');
       BEGIN
        SELECT CUST_NO
          INTO L_CUST_NO
          FROM STTB_ACCOUNT
         WHERE AC_GL_NO = PKG_RTL_TLR.CHARGE_ACCOUNT
           AND BRANCH_CODE = PKG_RTL_TLR.TXN_BRANCH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In No_data_found hmmmm ' || SQLERRM);
          L_CUSTOMER_NO:=PKG_RTL_TLR.REL_CUSTOMER;
          RETURN TRUE;
      END;
     L_CUSTOMER_NO:=L_CUST_NO;
   ELSIF L_STTB_ACC_DET.AC_OR_GL = 'G' THEN
     L_CUSTOMER_NO:=PKG_RTL_TLR.REL_CUSTOMER;
   END IF;
   
    DBG('the customer for charge account is'||L_CUSTOMER_NO);
   
  ELSE
    DBG('in the else for setting customer');
    L_CUSTOMER_NO:=PKG_RTL_TLR.REL_CUSTOMER;
 END IF;    
    
     
     IF NOT CVPKSS_UTILS.GET_CUST_NO(L_CUSTOMER_NO, 
                      L_CUSTOMER_REC 
                      )
     THEN
      DBG('not able to gett sttb acc record');
     END IF;
     IF PKG_RTL_TLR.DR_ACC ='OFS'
     THEN
      L_TXN_CODE := 'C';
     ELSE
      L_TXN_CODE :=  'D';
     END IF;
     DBG('l_txn_code ->'||L_TXN_CODE);
     DBG('The debit instrument code is:'||PKG_RTL_TLR.DR_INSTRUMENT_CODE);
     DBG('The Credit instrument code is:'||PKG_RTL_TLR.CR_INSTRUMENT_CODE);
     
     DBG('The package retail teller Istrument date is:'||PKG_RTL_TLR.INSTR_DATE);
     DBG('The Cheque issue date is:'||P_TY_RTUPLD.TY_UPLD_RTL_TELLER.CHEQUE_ISSUE_DATE);
     DBG('The package retail teller chq issue date is:'||PKG_RTL_TLR.CHEQUE_ISSUE_DATE);
    
              
    DBG('customer_name1 ->'||L_CUSTOMER_REC.CUSTOMER_NAME1);
    DBG('short_name ->'||L_CUSTOMER_REC.SHORT_NAME);  
  
  
 IF PKG_RTL_TLR.PRODUCT_CODE='CXTR'  THEN
    IF  GWPKS_CREATERETAILTLR.G_SHORT_NAME IS NOT NULL THEN
    L_CUSTOMER_REC.CUSTOMER_NAME1 := GWPKS_CREATERETAILTLR.G_SHORT_NAME;
    END IF; 
    DBG('short_name for international transfer ->'||L_CUSTOMER_REC.CUSTOMER_NAME1);
 END IF;
  
          
          IF GWPKS_UTIL.PKG_FUNC = '5402' THEN
           DBG('depks_rtl_teller.pkg_rtl_teller_rec.txn_acc-->'||DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC);
          BEGIN
          SELECT (SUM(NVL(A.AMOUNT_DUE,0) - NVL(A.AMOUNT_SETTLED,0)))
          INTO   L_RE_PAY_AMT
          FROM   CLTB_ACCOUNT_SCHEDULES A,
                 STTMS_DATES B
          WHERE  A.BRANCH_CODE           = B.BRANCH_CODE
          AND    A.SCHEDULE_DUE_DATE      <= B.TODAY
          AND    NVL(A.SCHEDULE_FLAG,'X') <> 'M'
          AND    A.ACCOUNT_NUMBER         = DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC;

          
          EXCEPTION
         WHEN OTHERS THEN
           DBG('Failed in getting the Account Details during pickup fn_build_rtdetaila to Function id 5402');
           RETURN FALSE;
         END;
      END IF;

  IF GWPKS_UTIL.PKG_FUNC IN ('5401','5402') THEN
          BEGIN
          
          SELECT  CAM.AMOUNT_FINANCED
                  ,CAM.AMOUNT_DISBURSED
          INTO    L_AMOUNT_FINANCED,L_AMOUNT_DISBURSED
          FROM    CLTB_ACCOUNT_MASTER CAM
          WHERE   CAM.ACCOUNT_NUMBER = DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TXN_ACC;
         EXCEPTION
         WHEN OTHERS THEN
           DBG('Failed in getting the Account Details during pickup fn_build_rtdetaila to Function id 5402');
           RETURN FALSE;
         END;
         END IF; 
   
         DBG('l_amount_financed--> '||L_AMOUNT_FINANCED || '~' || 'l_amount_disbursed--> '||L_AMOUNT_DISBURSED);
          
         DBG('l_hjpayble-->'||L_HJPAYBLE||'l_re_pay_amt-->'||L_RE_PAY_AMT||'gwpks_util.pkg_acttype'||GWPKS_UTIL.PKG_ACTTYPE||'l_txn_amt-->'||L_TXN_AMT);
         IF GWPKS_UTIL.PKG_ACTTYPE = 'ENRICH' THEN          
           L_HJPAYBLE   := L_RE_PAY_AMT; 
           L_RE_PAY_AMT := L_TXN_AMT;
           DBG('Pkg_rtl_tlr.txn_ccy-->'||PKG_RTL_TLR.TXN_CCY||'Pkg_rtl_tlr.ofs_ccy-->'||PKG_RTL_TLR.OFS_CCY);         
        IF L_RE_PAY_AMT > L_HJPAYBLE THEN
          DBG('Only the Outstanding Amount of current dated can be settled, Adjust Transaction Amount Accordingly');
          DBG('Amt To liquidated is greater than total outstanding amt');
          P_ERR_CODE  := 'RT-CL-003;';
          P_ERR_PARAM := '';         
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          RETURN FALSE;
         END IF;
         END IF;
         
         
     IF GWPKS_UTIL.PKG_FUNC = '5403' THEN
           BEGIN
             SELECT PROCESS_REF_NO 
             INTO   L_DOWNPAYREFERENCE
             FROM   CLTB_ACCOUNT_DOWNPAYMENT 
             WHERE  EXT_REF_NO = PKG_RTL_TLR.XREF;
           EXCEPTION WHEN OTHERS THEN 
             DBG('l_downpayreference --> Not Found on Pickup valid Scenario'||L_DOWNPAYREFERENCE);
           END; 
       L_HJPAYBLE := P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.NUM_FIELD3;
         END IF;
     
     IF P_SOURCE NOT IN ('FLEXBRANCH','FLEXCUBE') THEN 
     
     L_UI_TXN_ACC := DEPKS_RETAILTELLERUPLOAD.G_UI_TXN_ACC ;
     L_UI_OFS_ACC := DEPKS_RETAILTELLERUPLOAD.G_UI_OFS_ACC;
     
     END IF ;
     
     DBG('g_viraccno: '||DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO||'~g_ui_ofs_acc: '||DEPKS_RETAILTELLERUPLOAD.G_UI_OFS_ACC||'~Pkg_rtl_tlr.txn_acc: '||PKG_RTL_TLR.TXN_ACC||'~Depks_RetailTellerUpload.g_ui_txn_acc: '||DEPKS_RETAILTELLERUPLOAD.G_UI_TXN_ACC);
         
     
      
      
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM)
        THEN
                DBG('going to Call gwpks_queryretailtlr_cluster.fn_build_rtdetails');
                L_FN_CALL_ID := 2;
                L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        L_TB_CLUSTER_DATA('PKG_RTL_TLR.Narrative'):=NVL(PKG_RTL_TLR.NARRATIVE,0);
                L_TB_CLUSTER_DATA('L_TXNACC_AMT'):=L_TXNACC_AMT;
                IF NOT  GWPKS_QUERYRETAILTLR_CLUSTER.FN_BUILD_RTDETAILS(P_SOURCE       
                               ,P_PARENT_RES   
                               ,P_REFERENCE_NO 
                               ,P_TY_RTUPLD    
                               ,P_PARENT       
                               ,P_KEY         
                               ,P_DATA         
                               ,P_FORMAT       
                               ,P_NODE         
                 ,L_FN_CALL_ID
                               ,L_TB_CLUSTER_DATA
                               ,P_ERR_CODE     
                               ,P_ERR_PARAM    
                                )
                THEN
                  DBG('gwpks_queryretailtlr_cluster.fn_build_rtdetails failed with :-( ' ||P_ERR_CODE || ':' || P_ERR_PARAM);
                  L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                  RETURN FALSE;
                END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('L_TXNACC_AMT') THEN
          L_TXNACC_AMT := L_TB_CLUSTER_DATA('L_TXNACC_AMT');
        END IF; 
        END IF;  
      
     

     L_PARAM_VAL := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('PAYMENT_PROCESSOR'),'E'); 
     DBG('l_PARAM_VAL'||L_PARAM_VAL);
     P_DATA := P_DATA ||  PKG_RTL_TLR.XREF || '~' || PKG_RTL_TLR.TRN_REF_NO || '~' || PKG_RTL_TLR.PRODUCT_CODE || '~' 
                || '~' 
                || '~' || PKG_RTL_TLR.BRANCH_CODE || '~' 
                || '~' || PKG_RTL_TLR.TXN_BRANCH || '~' || NVL(L_UI_TXN_ACC,PKG_RTL_TLR.TXN_ACC) || '~' || PKG_RTL_TLR.TXN_CCY || '~' || PKG_RTL_TLR.TXN_AMOUNT || '~' || PKG_RTL_TLR.TXN_TRN_CODE || '~' ||
                PKG_RTL_TLR.OFS_BRANCH || '~' || NVL(L_UI_OFS_ACC,PKG_RTL_TLR.OFS_ACC) || '~' || PKG_RTL_TLR.OFS_CCY || '~' || NVL(PKG_RTL_TLR.OFS_AMOUNT, PKG_RTL_TLR.LCY_AMOUNT) || '~' ||
                PKG_RTL_TLR.OFS_TRN_CODE || '~' || PKG_RTL_TLR.EXCH_RATE || '~' || PKG_RTL_TLR.LCY_AMOUNT || '~' || TO_CHAR(PKG_RTL_TLR.TRN_DT, L_DTF) || '~' ||
                TO_CHAR(PKG_RTL_TLR.VALUE_DT, L_DTF) || '~' || PKG_RTL_TLR.REL_CUSTOMER || '~' || PKG_RTL_TLR.REM_ACC || '~' || PKG_RTL_TLR.REM_BANK || '~' ||
                PKG_RTL_TLR.REM_BRANCH || '~' || PKG_RTL_TLR.ROUTING_NO || '~' || PKG_RTL_TLR.END_POINT || '~' || PKG_RTL_TLR.SERIAL_NO || '~' || L_ROUTE_CODE
        || '~' ||  PKG_RTL_TLR.DR_INSTRUMENT_CODE || '~' 
        || PKG_RTL_TLR.CR_INSTRUMENT_CODE 
                || '~' || PKG_RTL_TLR.CHG_IN_ACY || '~' || PKG_RTL_TLR.CHG_IN_ACY_1 || '~' || PKG_RTL_TLR.CHG_IN_ACY_2 || '~' || PKG_RTL_TLR.CHG_IN_ACY_3 || '~' ||
                PKG_RTL_TLR.CHG_IN_ACY_4 || '~' || PKG_RTL_TLR.TOT_CHG_IN_TCY || '~' || PKG_RTL_TLR.REPAIR_REASON || '~' || PKG_RTL_TLR.NARRATIVE || '~' ||
                PKG_RTL_TLR.TRACK_RECEIVABLE || '~' || PKG_RTL_TLR.LCY_EXCH_RATE || '~' || PKG_RTL_TLR.MAKER_ID || '~' ||
                TO_CHAR(PKG_RTL_TLR.MAKER_DT_STAMP, L_DTSTAMPF) || '~' || PKG_RTL_TLR.CHECKER_ID || '~' || TO_CHAR(PKG_RTL_TLR.CHECKER_DT_STAMP, L_DTSTAMPF) || '~' ||
                PKG_RTL_TLR.MOD_NO || '~' || PKG_RTL_TLR.RECORD_STAT || '~' || PKG_RTL_TLR.AUTH_STAT || '~' 
                || '~' || PKG_RTL_TLR.CHG_IN_LCY || '~' || PKG_RTL_TLR.CHG_CCY_ACY_RATE || '~' || PKG_RTL_TLR.ACY_LCY_RATE || '~' || PKG_RTL_TLR.CHG_IN_LCY_1 || '~' ||
                PKG_RTL_TLR.CHG_CCY_ACY_RATE_1 || '~' || PKG_RTL_TLR.ACY_LCY_RATE_1 || '~' || PKG_RTL_TLR.CHG_IN_LCY_2 || '~' || PKG_RTL_TLR.CHG_CCY_ACY_RATE_2 || '~' ||
                PKG_RTL_TLR.ACY_LCY_RATE_2 || '~' || PKG_RTL_TLR.CHG_IN_LCY_3 || '~' || PKG_RTL_TLR.CHG_CCY_ACY_RATE_3 || '~' || PKG_RTL_TLR.ACY_LCY_RATE_3 || '~' ||
                PKG_RTL_TLR.CHG_IN_LCY_4 || '~' || PKG_RTL_TLR.CHG_CCY_ACY_RATE_4 || '~' || PKG_RTL_TLR.ACY_LCY_RATE_4 || '~' || PKG_RTL_TLR.DR_ACC 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' || L_TXN_CODE 
                || '~' || TO_CHAR(PKG_RTL_TLR.TRN_DT, L_DTF) 
                || '~' 
                || '~' 
                || '~' 
                || '~' || L_FLAG 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' 
                || '~' || L_ACC_WITH_INSTN1 
                || '~' || L_ACC_WITH_INSTN2 
                || '~' || L_ACC_WITH_INSTN3 
                || '~' || L_ACC_WITH_INSTN4 
                || '~' || L_ACC_WITH_INSTN5 
                || '~' 
                || '~' || (NVL(PKG_RTL_TLR.CHG_IN_LCY, 0) + NVL(PKG_RTL_TLR.CHG_IN_LCY_1, 0) + 
        NVL(PKG_RTL_TLR.CHG_IN_LCY_2, 0) + NVL(PKG_RTL_TLR.CHG_IN_LCY_3, 0) +
                NVL(PKG_RTL_TLR.CHG_IN_LCY_4, 0)) 
                || '~' || PKG_RTL_TLR.OFS_CCY 
                || '~' || L_DENMAMT1 
                || '~' 
                || '~' || L_DENMAMT2 
        
              
               
         
        
        || '~' || NVL(DEPKSS_RETAILTELLERUPLOAD.G_ACCTITLE1,L_TXN_ACC_DESC) || '~' ||NVL(DEPKSS_RETAILTELLERUPLOAD.G_ACCTITLE2,L_OFS_ACC_DESC)
         
        
                || '~' || L_ACTAMT 
               
                || '~' || PKG_RTL_TLR.BENEF_NAME || '~' || NVL(PKG_RTL_TLR.BENEF_ADDR1,L_CUST_ACCOUNT.ADDRESS1) || '~' || NVL(PKG_RTL_TLR.BENEF_ADDR2,L_CUST_ACCOUNT.ADDRESS2) || '~' || NVL(PKG_RTL_TLR.BENEF_ADDR3,L_CUST_ACCOUNT.ADDRESS3) || '~' || NVL(PKG_RTL_TLR.BENEF_ADDR4,L_CUST_ACCOUNT.ADDRESS4) 
               || '~' || PKG_RTL_TLR.PASSPORTIC_NO
                || '~' || TO_CHAR(PKG_RTL_TLR.INSTR_DATE, L_DTF) 
               || '~' || TO_CHAR(NVL(P_TY_RTUPLD.TY_UPLD_RTL_TELLER.CHEQUE_ISSUE_DATE,PKG_RTL_TLR.CHEQUE_ISSUE_DATE),L_DTF)
               
                             || '~' ||NVL(L_VIRR_ACC_NAME,NVL(L_CUSTOMER_REC.CUSTOMER_NAME1,L_CUSTOMER_REC.SHORT_NAME))
                
                ||'~'||L_HJPAYBLE 
                ||'~'||L_RE_PAY_AMT 
                ||'~'||L_AMOUNT_FINANCED 
                ||'~'||L_AMOUNT_DISBURSED                 
                
                
                ||'~'||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD16
                ||'~'||L_DOWNPAYREFERENCE            
                
                || '~' || GWPKS_UTIL.G_REJECTFLAG 
                || '~' ||PKG_RTL_TLR.NEGOTIATED_RATE || '~' || PKG_RTL_TLR.NEGOTIATION_REF_NO ||'~' ||
                         PKG_RTL_TLR.PROJECT_NAME|| '~' ||PKG_RTL_TLR.UNIT_PAYMENT|| '~' ||
                         PKG_RTL_TLR.UNIT_ID|| '~' ||PKG_RTL_TLR.DEPOSIT_SLIP_NO
                ||'~'||  L_STTB_ACC_REC.AC_GL_DESC ||
                '~' ||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD8||'~' ||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD9|| 
            
        
        '~' ||PKG_RTL_TLR.REJECT_CODE|| '~' || CSPKS_ARC.G_OFFSET_TILL ||  
        
                '~' || PKG_RTL_TLR.TOKEN_NO || 
                '~' || DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO || 
                 '~' || DEPKS_RETAILTELLERUPLOAD.G_UI_TXN_ACC || 
         '~' || DEPKS_RETAILTELLERUPLOAD.G_UI_OFS_ACC || 
   '~' || DEPKS_RTL_TELLER.PKG_TXNLEGCASHAMT || 
    '~' || DEPKS_RTL_TELLER.PKG_OFSLEGCASHAMT|| 
             
                '~' || DEPKS_RETAILTELLERUPLOAD.G_DENOM_VARIANCE ||
                '~' || PKG_RTL_TLR.ORG_EXCH_RATE ||
                '~' || PKG_RTL_TLR.ORG_AMOUNT ||
              
              
                '~' || L_CLTB_ACCOUNT_MASTER.AMOUNT_FINANCED ||'~' || L_CLTB_ACCOUNT_MASTER.AMOUNT_DISBURSED ||
              
                          '~' || GWPKS_CREATERETAILTLR.G_PARENT_FUNCTIONID || 
        '~' ||NVL(DEPKS_RETAILTELLERUPLOAD.G_VIRACCNO,NVL(DEPKS_RETAILTELLERUPLOAD.G_UI_TXN_ACC,PKG_RTL_TLR.TXN_ACC)) ||
'~' ||DEPKS_RETAILTELLERUPLOAD.G_ACCTYPE ||
        '~'||PKG_RTL_TLR.COMM_MODE||'~'||PKG_RTL_TLR.MOBILE_NUMBER||'~'||PKG_RTL_TLR.EMAIL_ID ||'~'||PKG_RTL_TLR.COUNTRY 
              ||'~'||PKG_RTL_TLR.DAYS||'~'||PKG_RTL_TLR.MONTHS||'~'||PKG_RTL_TLR.YEARS||'~'||PKG_RTL_TLR.DOC_NUMBER  
              ||'~'||PKG_RTL_TLR.DOC_TYPE||'~'||PKG_RTL_TLR.DOC_CATEGORY||'~'||PKG_RTL_TLR.SDB_REF_NO||'~'||PKG_RTL_TLR.FUND_REF_NO  
        ||'~'||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD3||'~'||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD90 
              ||'~'||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD2 ||'~'||L_ACCEPT_STAT||
              '~'||P_TY_RTUPLD.TY_CSTBS_UI_COLUMNS.CHAR_FIELD3||'~'||PKG_RTL_TLR.CHARGE_ACCOUNT ||   
              
              '~'||L_AMT_IN_WORDS||'~'||L_AMT_IN_WORDS_1||'~'||L_AMT_IN_WORDS_2||'~'||L_AMT_IN_WORDS_3||
              
        '~'||L_TXNACC_AMT||'~'||L_TXNACC_NO||'~'||L_TXNACC_BRN||'~'||L_OFSACC_AMT ||'~'||L_OFSACC_NO||'~'||L_OFSACC_BRN|| 
        '~'||L_PARAM_VAL ||'~'|| 
    '~>'  ; 
        
    DBG('The customer name to be sent for RT transactions is:'||L_CUSTOMER_REC.SHORT_NAME); 
        P_FORMAT := P_NODE || '>';
    DBG('p_data ==>' || P_DATA);
        DBG('p_format ==>' || P_FORMAT);
        DBG('p_parent ==>' || P_PARENT);
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 1;
            L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
           DBG('Calling gwpks_queryretailtlr_cluster.fn_build_rtdetails');
            IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_BUILD_RTDETAILS(P_SOURCE,
                                                                   P_PARENT_RES,
                                                                   P_REFERENCE_NO,
                                                                   P_TY_RTUPLD,
                                                                   P_PARENT,
                                                                   P_KEY,
                                                                   P_DATA,
                                                                   P_FORMAT,
                                                                   P_NODE,
                                                                   L_FN_CALL_ID,
                                                                   L_TB_CLUSTER_DATA,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAM) THEN
              DBG('Failed in call to fn_build_rtdetails..');
              RETURN FALSE;
            END IF;
          END IF;
    
        DBG('Returning Successfully from fn_build_rtdetails');
    
        RETURN TRUE;
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBG('in NO_DATA_FOUND fn_build_rtdetails' || SQLERRM);
            P_ERR_CODE  := 'WB-TXN-001'; 
            P_ERR_PARAM := P_REFERENCE_NO || '~';
            RETURN FALSE;
        WHEN OTHERS THEN
            DBG('in WOT fn_build_rtdetails' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building the Reply' || '~';
            DBG(SQLCODE || SQLERRM);
            RETURN FALSE;
    END FN_BUILD_RTDETAILS;
    
    FUNCTION FN_BUILD_PKREPLY(P_PARENT_RES IN VARCHAR2
                             ,P_FCCREF     IN VARCHAR2
                             ,P_XREF       IN VARCHAR2
                             ,P_PARENT     IN OUT VARCHAR2
                             ,P_TAG        IN OUT VARCHAR2
                             ,P_DATA       IN OUT VARCHAR2
                             ,P_FORMAT     IN OUT VARCHAR2
                             ,P_ERR_CODE   IN OUT VARCHAR2
                             ,P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
        L_FCCREF DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
    
    BEGIN
        P_PARENT := P_PARENT_RES || '>';
        P_TAG    := 'XREF~FCCREF~';
        P_DATA   := P_XREF || '~' || P_FCCREF || '~' || '>';
        P_FORMAT := '1>';
    
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            DBG('in WOT of fn_build_pkreply' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Building PK Reply';
            RETURN FALSE;
    END FN_BUILD_PKREPLY;
    
  
    FUNCTION FN_BUILD_DPMTDETS(P_SOURCE     IN VARCHAR2,
                           P_PARENT     IN OUT VARCHAR2,
               P_KEY        IN OUT VARCHAR2,
                           P_FORMAT     IN OUT VARCHAR2,
               P_DATA       IN OUT VARCHAR2,
                           P_NODE       IN OUT VARCHAR2,
               P_CNT_LVL    IN OUT VARCHAR2,
                           P_ERR_CODE   IN OUT VARCHAR2,
                           P_ERR_PARAM  IN OUT VARCHAR2
            ) RETURN BOOLEAN IS

    L_TS_LIST    VARCHAR2(100) := 'PROCESS_REF_NO~DP_REF_NO~ACC_CCY~DP_AMOUNT~PAYABLE_ACC_CCY~VALUE_DATE~';
    L_TS_LIST1   VARCHAR2(100) := 'CHAR_FIELD1~CHAR_FIELD3~NUM_FIELD3~NUM_FIELD1~NUM_FIELD5~';
    L_TS_VALUES  VARCHAR2(1000);
    L_TS_VALUES1 VARCHAR2(1000);
    L_NODE       VARCHAR2(100);
    L_PROCESS_REF         CLTBS_ACCOUNT_DOWNPAYMENT.PROCESS_REF_NO%TYPE;
    L_TRANS_REFNO         CLTBS_ACCOUNT_DOWNPAYMENT.DP_REF_NO%TYPE;
    L_CCY                 CLTBS_ACCOUNT_DOWNPAYMENT.PAYABLE_ACC_CCY%TYPE;
    L_DP_AMOUNT           CLTBS_ACCOUNT_DOWNPAYMENT.DP_AMOUNT%TYPE;
    L_VAL_DATE            CLTBS_ACCOUNT_DOWNPAYMENT.VALUE_DATE%TYPE;
    L_AMT_IN_CCY          CLTBS_ACCOUNT_DOWNPAYMENT.AMT_IN_ACC_CCY%TYPE;
    L_ACCOUNT_NUM         CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER%TYPE;
    L_ACC_CCY             CLTBS_ACCOUNT_MASTER.CURRENCY%TYPE;
    L_DOWN_PAYMENT        CLTBS_ACCOUNT_MASTER.DOWNPAYMENT_AMOUNT%TYPE;
    L_COUNT               NUMBER := 0;
    L_TOTAL_DP_AMOUNT NUMBER:= 0;
    L_DP_ACC NUMBER;
    L_FUTURE_DPRECEIVABLE NUMBER;
      CURSOR C_CLTBS_ACCOUNT_DOWNPAYMENT IS
         SELECT *
         FROM CLTBS_ACCOUNT_DOWNPAYMENT
         WHERE DP_REF_NO = GWPKS_CREATERETAILTLR.G_FNACCREF AND RECORD_STAT <>'V';
    BEGIN
      DBG('Inside function fn_build_dpmtdets');
      DBG('gwpks_createretailtlr.g_fnaccref' ||GWPKS_CREATERETAILTLR.G_FNACCREF);
      
      BEGIN
        SELECT ACCOUNT_NUMBER, CURRENCY, DOWNPAYMENT_AMOUNT
           INTO L_ACCOUNT_NUM, L_ACC_CCY, L_DOWN_PAYMENT
           FROM CLTBS_ACCOUNT_MASTER
           WHERE ACCOUNT_NUMBER = GWPKS_CREATERETAILTLR.G_FNACCREF;
       
        SELECT NVL(SUM(NVL(AMT_IN_ACC_CCY, 0)), 0) 
          INTO L_DP_ACC
          FROM CLTBS_ACCOUNT_DOWNPAYMENT
          WHERE DP_REF_NO = GWPKS_CREATERETAILTLR.G_FNACCREF AND RECORD_STAT <>'V' ;
        EXCEPTION
        WHEN OTHERS THEN
        DBG('FAILED IN SQL STATEMENT');
        END;
        DBG('l_dp_acc'||L_DP_ACC);
        L_FUTURE_DPRECEIVABLE := NVL(L_DOWN_PAYMENT,0)- NVL(L_DP_ACC,0);
      DBG('l_account_nuM' || L_ACCOUNT_NUM);
      DBG('l_acc_ccy' || L_ACC_CCY);
      DBG('l_down_payment' || L_DOWN_PAYMENT);
      DBG('l_future_dpreceivable'||L_FUTURE_DPRECEIVABLE);
      IF L_DOWN_PAYMENT IS NOT NULL THEN
        DBG('CAME FOR THE IF CONDITION');
        DBG('p_source' || P_SOURCE);
        P_CNT_LVL := P_CNT_LVL + 1;
         
         L_TS_VALUES1 := L_ACCOUNT_NUM || '~' || L_ACC_CCY|| '~' ||
                 L_DOWN_PAYMENT || '~' || L_FUTURE_DPRECEIVABLE|| '~' || L_DP_ACC || '~';
         IF P_SOURCE = 'FLEXBRANCH' THEN
          DBG('INSIDE THE CONDITION');
          DBG('p_parent' || P_PARENT);
          DBG('p_format' || P_FORMAT);
          DBG('p_node' || P_NODE);
          DBG('p_key' || P_KEY);
          DBG('p_data' || P_DATA);
          DBG('l_ts_list1' || L_TS_LIST1);
          DBG('l_ts_values1' || L_TS_VALUES1);
          P_PARENT := P_PARENT || 'BLK_ACC_DETAILS>';
          P_FORMAT := P_FORMAT || P_NODE || '.' || P_CNT_LVL || '>';
          P_KEY    := P_KEY || L_TS_LIST1 || '>';
          P_DATA   := P_DATA || L_TS_VALUES1 || '>';
          DBG('Fail111');
          END IF;
      END IF;
      DBG(' p_node  ' || P_NODE);
      L_NODE := P_NODE || '.' || P_CNT_LVL;
      DBG('loop targetl_node ' || L_NODE);
      
      FOR REC IN C_CLTBS_ACCOUNT_DOWNPAYMENT LOOP
          DBG('loop target');
          L_COUNT := L_COUNT + 1;
          L_PROCESS_REF := REC.PROCESS_REF_NO;
          L_DP_AMOUNT   := REC.DP_AMOUNT;
          L_TRANS_REFNO := REC.DP_REF_NO;
          L_CCY         := REC.PAYABLE_ACC_CCY;
          L_VAL_DATE    := REC.VALUE_DATE;
          L_AMT_IN_CCY  := REC.AMT_IN_ACC_CCY;
    
           DBG('l_process_ref' || L_PROCESS_REF);
           DBG('l_dp_amount' || L_DP_AMOUNT);
           DBG('l_ccy' || L_CCY);
           DBG('l_dp_amount' || L_DP_AMOUNT);
          IF L_DP_AMOUNT IS NOT NULL THEN
            DBG('CAME FOR THE IF CONDITION');
            DBG('p_source' || P_SOURCE);
            
            L_TS_VALUES := L_PROCESS_REF || '~' || L_TRANS_REFNO || '~' || L_CCY || '~' ||
                   L_DP_AMOUNT || '~' || L_AMT_IN_CCY || '~' ||
                   L_VAL_DATE || '~';
              
              
              DBG('INSIDE THE CONDITION');
              DBG('p_parent' || P_PARENT);
              DBG('p_format' || P_FORMAT);
              DBG('p_node' || P_NODE);
              DBG('p_key' || P_KEY);
              DBG('p_data' || P_DATA);
              DBG('l_ts_list' || L_TS_LIST);
              DBG('l_ts_values' || L_TS_VALUES);
              P_PARENT := P_PARENT || 'Blk-Acc-Dpmt>';
              
              P_FORMAT := P_FORMAT || L_NODE || '.' || L_COUNT || '>';
              P_KEY    := P_KEY || L_TS_LIST || '>';
              P_DATA   := P_DATA || L_TS_VALUES || '>';
              DBG('Fail111');
              
          END IF;
      END LOOP;
        DBG('p_parent  ' || P_PARENT );
        DBG('p_format  ' || P_FORMAT );
        DBG('p_key  ' || P_KEY );
        DBG('p_data  ' || P_DATA );
      
        RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
      DBG('Failed in the function fn_build_dpmtdets' || SQLERRM);
            P_ERR_CODE  := 'RT-OTHR-001';
            P_ERR_PARAM := 'Build_dpmtdets';
    RETURN FALSE;
  END FN_BUILD_DPMTDETS;
   
    FUNCTION FN_BUILD_FSREPLY(P_SOURCE     IN VARCHAR2
                             ,P_PARENT_RES IN VARCHAR2
                             ,P_FCCREF     IN VARCHAR2
                             ,P_TY_RTUPLD  IN OUT NOCOPY DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC 
                             ,P_XREF       IN VARCHAR2
                             ,P_PARENT     IN OUT VARCHAR2
                             ,P_TAG        IN OUT VARCHAR2
                             ,P_DATA       IN OUT VARCHAR2
                             ,P_FORMAT     IN OUT VARCHAR2
                             ,P_ERR_CODE   IN OUT VARCHAR2
                             ,P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
        L_FCCREF  DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
        L_NODE    VARCHAR2(105) := '1';
        L_CNT_LVL NUMBER := 0;
    L_PARENT_RES_SD VARCHAR2(105);
        L_PRODUCT VARCHAR2(4);
    
        
        VAL_TYPE UDTM_FIELDS.VAL_TYPE%TYPE;
      L_DATATYPE UDTM_FIELDS.FIELD_TYPE%TYPE; 
        
         
        L_FN_CALL_ID NUMBER;
        L_TB_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
        L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
        L_TB_CUSTOM_DATA GLOBAL.TY_TB_CUSTOM_DATA;
        L_TB_CUSTOM_DATA_EMPTY GLOBAL.TY_TB_CUSTOM_DATA;
        
        ERROR_EXCEPTION EXCEPTION;
        L_MANDATORY  UDTMS_FIELDS.MANDATORY%TYPE; 
        L_MANDATORY_MIS  GLTMS_MIS_CLASS.MANDATORY%TYPE; 
    
    BEGIN
       
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN (CSPKS_REQ_GLOBAL.P_CUSTOM) 
    THEN 
    L_FN_CALL_ID     := 1; 
    L_TB_CLUSTER_DATA('l_node')    := L_NODE;
    L_TB_CLUSTER_DATA('l_cnt_lvl') := L_CNT_LVL;
    IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_PRE_BUILD_FSREPLY(P_SOURCE 
                         ,P_PARENT_RES 
                         ,P_FCCREF 
                         ,P_TY_RTUPLD 
                         ,P_XREF 
                         ,P_PARENT 
                         ,P_TAG 
                         ,P_DATA
                         ,P_FORMAT
                         ,P_ERR_CODE
                         ,P_ERR_PARAM
                         ,L_TB_CLUSTER_DATA
                         ,L_FN_CALL_ID) 
                        THEN 
    DBG('Failed in  fn_build_fsreply' || SQLERRM); 
    RETURN FALSE; 
    END IF; 
    END IF; 
    
        DBG('Inside the function fn_build_fsreply ');
        DBG('p_fccref :' || P_FCCREF);
    
    BEGIN
      SELECT * INTO PKG_RTL_TLR
      FROM  DETBS_RTL_TELLER  
      WHERE  TRN_REF_NO = P_FCCREF;
    EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed here while selectiing for retail tlr record->'||SQLERRM);
      P_ERR_CODE  := 'GW-MMPD1';
            P_ERR_PARAM :=  'Reference No '|| P_FCCREF ||'~';
            RETURN FALSE;
    END;
    
        IF NOT FN_BUILD_RTDETAILS(P_SOURCE
                                 ,P_PARENT_RES
                                 ,P_FCCREF
                                 ,P_TY_RTUPLD 
                                 ,P_PARENT
                                 ,P_TAG
                                 ,P_DATA
                                 ,P_FORMAT
                                 ,L_NODE
                                 ,P_ERR_CODE
                                 ,P_ERR_PARAM)
        THEN
            DBG('FAILED IN fn_build_rtdetails' || SQLERRM);
            RETURN FALSE;
        END IF;
        DBG('Gwpks_Util.Pkg_Func' || GWPKS_UTIL.PKG_FUNC);
        
        IF GWPKS_UTIL.PKG_FUNC = '1406' THEN 
    DBG('About to build Blk-Ft-Details for International Cash transfer screen , being the callform used by 1406 alone');
          IF NOT FN_REPLY_FTDETAILS(P_TY_RTUPLD
                                   ,P_FCCREF  
                                   ,P_DATA              
                                   ,P_TAG
                                   ,P_PARENT
                                   ,P_FORMAT
                                   ,L_NODE
                                   ,L_CNT_LVL
                                   ,P_ERR_CODE
                                   ,P_ERR_PARAM)
          THEN
              DBG('FAILED IN fn_build_rtdetails' || SQLERRM);
              RETURN FALSE;
          END IF;
        END IF;
        
        
        IF GWPKS_UTIL.PKG_FUNC = '1405' THEN 
         IF NOT FN_REPLY_PCDETAILS(P_FCCREF
                                 ,P_DATA
                                 ,P_TAG
                                 ,P_PARENT
                                 ,P_FORMAT
                                 ,L_NODE
                                 ,L_CNT_LVL
                                 ,P_ERR_CODE
                                 ,P_ERR_PARAM)
        THEN
            DBG('FAILED IN FN_REPLY_PCDETAILS' || SQLERRM);
            RETURN FALSE;
        END IF;
        END IF;
        
    
        IF P_SOURCE = 'FLEXCUBE'
        THEN
            DBG('Source is FLEXCUBE');
            IF NOT FN_BUILD_SUBSYSPARENT(P_FCCREF
                                        ,P_PARENT
                                        ,P_TAG
                                        ,P_DATA
                                        ,L_NODE
                                        ,P_FORMAT
                                        ,L_CNT_LVL
                                        ,P_ERR_CODE
                                        ,P_ERR_PARAM)
            THEN
                DBG('Failed in Fn_Build_Subsysparent..');
                RETURN FALSE;
            END IF;
            L_NODE := '1.' || L_CNT_LVL;
        ELSE
            L_NODE := '1';
        
        END IF;
        DBG(' l_node ' || L_NODE);
        DBG('p_format:::::::::::::' || P_FORMAT);
        DBG('calling  fn_reply_chgdets...');
    
        IF NOT FN_REPLY_CHGDETS(P_SOURCE
                               ,P_FCCREF
                               ,P_DATA
                               ,P_TAG
                               ,P_PARENT
                               ,P_FORMAT
                               ,L_NODE
                               ,L_CNT_LVL
                               ,P_ERR_CODE
                               ,P_ERR_PARAM)
        THEN
            DBG('Failed in fn_reply_chgdets..');
            RETURN FALSE;
        END IF;
   
     IF GWPKS_UTIL.PKG_FUNC  IN ( '1401', '1006') THEN
        IF NOT FN_REPLY_PROJECT(P_SOURCE
                               ,P_FCCREF
                               ,P_DATA
                               ,P_TAG
                               ,P_PARENT
                               ,P_FORMAT
                               ,L_NODE
                               ,L_CNT_LVL
                               ,P_ERR_CODE
                               ,P_ERR_PARAM)
        THEN
            DBG('Failed in fn_reply_project..');
            RETURN FALSE;
        END IF;
     END IF;  
   
    
    



    DBG('gwpks_util.pkg_func :::: ' || GWPKS_UTIL.PKG_FUNC);
        IF GWPKS_UTIL.PKG_FUNC IN ('5401','5402') THEN 
    
            DBG('BEFORE Gwpks_QueryRTLending.Fn_Reply_Baldets');
            DBG('p_Source ' || P_SOURCE);
            DBG('p_Fccref ' || P_FCCREF);
            DBG('p_Data ' || P_DATA);
            DBG('p_Tag ' || P_TAG);
            DBG('p_Parent ' || P_PARENT);
            DBG('p_Format ' || P_FORMAT);
            DBG('l_Node ' || L_NODE);
            DBG('l_Cnt_Lvl ' || L_CNT_LVL);
            DBG('p_Source ' || P_SOURCE);
        
            IF NOT GWPKS_QUERYRTLENDING.FN_REPLY_BALDETS(P_SOURCE
                                                        ,P_FCCREF
                                                        ,P_DATA
                                                        , 
                                                         P_TAG
                                                        , 
                                                         P_PARENT
                                                        ,P_FORMAT
                                                        ,L_NODE
                                                        ,L_CNT_LVL
                                                        ,P_ERR_CODE
                                                        ,P_ERR_PARAM
                                                        ,NULL)
            THEN
                DBG('Failed in fn_reply_baldets..');
                RETURN FALSE;
            END IF;
        END IF; 
    
        DBG('p_Data ' || P_DATA);
        DBG('p_Tag ' || P_TAG);
        DBG('p_Parent ' || P_PARENT);
        DBG('p_Format ' || P_FORMAT);
        DBG('l_Node ' || L_NODE);
        DBG('l_Cnt_Lvl ' || L_CNT_LVL);
    
        DBG('calling  fn_reply_cheque details...');
        IF NOT FN_REPLY_MCKDETS(P_FCCREF, P_DATA, P_TAG, P_PARENT, P_FORMAT, L_NODE, L_CNT_LVL, P_ERR_CODE, P_ERR_PARAM)
        THEN
            DBG('Failed in  fn_reply_cheque details..');
            RETURN FALSE;
        END IF;
    
        DBG('Callin ggwpks_build_subsystem_ts.fn_build_misdetails...');
        IF NOT GWPKS_BUILD_SUBSYSTEM_TS.FN_BUILD_MISDETAILS(P_FCCREF
                                                           ,P_PARENT
                                                           ,P_TAG
                                                           ,P_DATA
                                                           ,L_NODE
                                                           ,P_FORMAT
                                                           ,L_CNT_LVL
                                                           ,P_ERR_CODE
                                                           ,P_ERR_PARAM)
        
        THEN
        
            DBG('FAiled in Gwpks_Build_Subsystem_Ts.Fn_Build_Misdetails..');
            RETURN FALSE;
        END IF;
   
     IF CSPKS_FEATURE.FN_INSTALLED('CUSTMIS') THEN  
        FOR EACH_MIS IN (SELECT * FROM 
            MITMS_DEFAULT_CODES
            WHERE KEY_ID=PKG_RTL_TLR.PRODUCT_CODE
            AND MIS_TYPE IN('T','O')) LOOP                       
                           
      DBG('Mis Class'||EACH_MIS.MIS_CLASS); 
      BEGIN                    
        SELECT MANDATORY
      INTO   L_MANDATORY_MIS
      FROM   GLTMS_MIS_CLASS
      WHERE  MIS_TYPE= EACH_MIS.MIS_TYPE
      AND    MIS_CLASS= EACH_MIS.MIS_CLASS
      AND    AUTH_STAT='A'
      AND    RECORD_STAT='O';
      DBG('l_mandatory_mis'||L_MANDATORY_MIS);
      
      EXCEPTION 
      WHEN OTHERS THEN
       L_MANDATORY_MIS :='N';      
      END;
      DBG('gwpks_util.pkg_acttype'||GWPKS_UTIL.PKG_ACTTYPE||'l_mandatory_mis'||L_MANDATORY_MIS||'gwpks_util.g_pickupclicked'||GWPKS_UTIL.G_PICKUPCLICKED);                     
    IF  NVL(GWPKS_UTIL.PKG_ACTTYPE,'***') = 'SAVEAUTOAUTH' AND NVL(L_MANDATORY_MIS,'N') ='Y' AND NVL(GWPKS_UTIL.G_PICKUPCLICKED,'N') = 'N' THEN 
            DBG('Here to Validate Mis');    
            DBG('PICKUP IS MANDATORY' ||GWPKS_UTIL.PKG_ACTTYPE ||'~'||L_MANDATORY_MIS );           
            OVPKS.PR_APPENDTBL('DE-TUD-960', 'PICKUP IS MANDATORY FOR MIS');
            RAISE ERROR_EXCEPTION ;
        END IF;                 
    END LOOP; 
      END IF;
   
    
      
    
    










        IF P_SOURCE <> 'FLEXBRANCH' OR GWPKSS_UTIL.G_UDFBUILT
    
        THEN
            IF NOT GWPKS_BUILD_SUBSYSTEM_TS.FN_BUILD_CONT_UDFDETAILS(P_FCCREF
                                                                    ,'1'
                                                                    ,P_PARENT
                                                                    ,P_TAG
                                                                    ,P_DATA
                                                                    ,L_NODE
                                                                    ,P_FORMAT
                                                                    ,L_CNT_LVL
                                                                    ,P_ERR_CODE
                                                                    ,P_ERR_PARAM)
            THEN
                DBG('FAield in Gwpks_Build_Subsystem_Ts.Fn_Build_Cont_Udfdetails..');
                RETURN FALSE;
            END IF;
        ELSIF
         

    
    







   GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH')
   
     
        THEN
            
      
      












        L_PRODUCT := PKG_RTL_TLR.PRODUCT_CODE;
        DBG('l_product ->'||L_PRODUCT);
      
            FOR EACH_UDF IN (SELECT FIELD_NAME
                                   ,UDF_TYPE
                                   ,FIELD_DESCRIPTION
                   ,MANDATORY 
                   ,DEFAULT_VALUE
                             FROM   IFVW_USER_FIELDS
                             WHERE  FUNCTION_ID IN (L_PRODUCT) AND RECORD_STAT = 'O' AND AUTH_STAT = 'A'
                             ORDER  BY FIELD_NO)
            LOOP
                
                
                DBG('Field_Name : ' || EACH_UDF.FIELD_NAME);
                 
                
                
                SELECT VAL_TYPE,FIELD_TYPE, MANDATORY
                INTO VAL_TYPE,L_DATATYPE, L_MANDATORY
                
                FROM   UDTM_FIELDS
                WHERE  FIELD_NAME = EACH_UDF.FIELD_NAME;
            
                DBG('The mandatory UDF tag value in call1 is:'||L_MANDATORY);

                DBG('Val_Type ' || VAL_TYPE);
            
                DBG('Inside UDF Loop');
                
                 
         




                  IF GWPKS_UTIL.PKG_ACTTYPE = 'ENRICH' OR NVL(EACH_UDF.MANDATORY,'N') = 'N' THEN
                  
                  DBG('am here to build again...');
                  
        
                
        P_DATA := P_DATA || EACH_UDF.FIELD_NAME || '~' || EACH_UDF.DEFAULT_VALUE || '~' || VAL_TYPE || '~' || L_DATATYPE || '~' || EACH_UDF.MANDATORY ||'~' ||'>';
        
                P_TAG  := P_TAG || 'FIELD_NAME' || '~' || 'FIELD_VALUE' || '~' || 'VAL_TYPE' || '~' || 'DATATYP' || '~' ||'MANDATORY' ||'~' || '>';
                
                
                
        
            
                P_PARENT  := P_PARENT || 'Blk-Udf-Details' || '>';
                L_CNT_LVL := L_CNT_LVL + 1;
                P_FORMAT  := P_FORMAT || L_NODE || '.' || L_CNT_LVL || '>';
                
                
                
                ELSIF GWPKS_UTIL.PKG_ACTTYPE = 'SAVEAUTOAUTH' THEN 
                
                
                  DBG('PICKUP IS MANDATORY' ||GWPKS_UTIL.PKG_ACTTYPE );           
                  OVPKS.PR_APPENDTBL('DE-TUD-948', 'PICKUP IS MANDATORY FOR UDF');
                  RAISE ERROR_EXCEPTION ;
                END IF;  
                
            
            END LOOP;
        END IF;
    
        IF NOT FN_REPLY_MSGDETS(P_XREF, P_DATA, P_TAG, P_PARENT, P_FORMAT, L_NODE, L_CNT_LVL, P_ERR_CODE, P_ERR_PARAM)
        THEN
            DBG('Failed in fn_reply_chgdets..');
            RETURN FALSE;
        END IF;

    
   IF GWPKS_UTIL.PKG_FUNC = '3401' THEN
     L_PARENT_RES_SD := 'Blk-Safedeposit-Details';    
    IF NOT FN_BUILD_SDDETAILS(   P_TY_RTUPLD
                                 ,L_PARENT_RES_SD
                                 ,P_PARENT
                                 ,P_TAG
                                 ,P_DATA
                                 ,P_FORMAT
                                 ,L_NODE
                                 ,L_CNT_LVL
                                 ,P_ERR_CODE
                                 ,P_ERR_PARAM)

        THEN
            DBG('FAILED IN queryretailteller fn_build_SDdetails in ' || SQLERRM);
            RETURN FALSE;
        END IF;

        DBG('p_parent>> ' || P_PARENT);
        DBG('p_tag>> ' || P_TAG);
        DBG('p_data>> ' || P_DATA);
        DBG('p_format>> ' || P_FORMAT);
        END IF;
       
       
        IF GWPKS_UTIL.PKG_FUNC = '5403' AND GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH', 'SAVEAUTOAUTH')
        THEN
            IF NOT FN_BUILD_DPMTDETS(P_SOURCE    
                             ,P_PARENT 
               ,P_TAG
               ,P_FORMAT
                             ,P_DATA      
                             ,L_NODE 
               ,L_CNT_LVL
                             ,P_ERR_CODE   
                             ,P_ERR_PARAM  
              )
                             
            THEN
        DBG('fn_build_dpmtdets  called Fail');
                RETURN FALSE;
            END IF;
                DBG('fn_build_dpmtdets  called Successfully ');
        END IF; 
        
        
    
   



































    
        
     IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('CALLING gwpks_queryretailtlr_cluster.fn_build_fsreply FOR 1......');
    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_FN_CALL_ID := 1;
      IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_BUILD_FSREPLY(P_SOURCE,
                                                           P_PARENT_RES,
                                                           P_FCCREF,
                                                           P_TY_RTUPLD,
                                                           P_XREF,
                                                           P_PARENT,
                                                           P_TAG,
                                                           P_DATA,
                                                           P_FORMAT,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN
        DBG('Failed in gwpks_queryretailtlr_cluster.fn_build_fsreply..' ||P_ERR_CODE);
        RETURN FALSE;
      
      END IF;
    END IF;
  
        DBG('p_parent>>' || P_PARENT);
        DBG('p_tag>>' || P_TAG);
    
        DBG('Returning true from  the function fn_build_fsreply ');
          
            
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN (CSPKS_REQ_GLOBAL.P_CUSTOM) 
    THEN 
    L_FN_CALL_ID     := 1; 
    L_TB_CLUSTER_DATA('l_node')    := L_NODE;
    L_TB_CLUSTER_DATA('l_cnt_lvl') := L_CNT_LVL;
    IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_POST_BUILD_FSREPLY(P_SOURCE 
                         ,P_PARENT_RES 
                         ,P_FCCREF 
                         ,P_TY_RTUPLD 
                         ,P_XREF 
                         ,P_PARENT 
                         ,P_TAG 
                         ,P_DATA
                         ,P_FORMAT
                         ,P_ERR_CODE
                         ,P_ERR_PARAM
                         ,L_TB_CLUSTER_DATA
                         ,L_FN_CALL_ID) 
                        THEN 
    DBG('Failed in  fn_build_fsreply' || SQLERRM); 
    RETURN FALSE; 
    END IF; 
    END IF; 
    
        RETURN TRUE;
    
    EXCEPTION  
        
        WHEN ERROR_EXCEPTION THEN
            DBG('Inside error exception of fn_buiild_fsreply....' || SQLERRM);
            DBG('Error in error_exception of fn_buiild_fsreply....');
            RETURN FALSE;
        
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-MMPD1';
            P_ERR_PARAM := 'In the fn_build_fsreply';
            RETURN FALSE;
    END FN_BUILD_FSREPLY;
    

    PROCEDURE PR_PROCESS_MSG(P_IS_IN_MSG_CLOB IN VARCHAR2
                             
                             
                            ,P_REC_MSG_HEADER  IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER
                            ,P_IS_OUT_MSG_CLOB OUT VARCHAR2
                             
                             
                            ,P_INSTR_REC IN OUT NOCOPY GWPKS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS
                            ,P_FLAG      OUT NUMBER
                            ,P_ERR_CODE  IN OUT VARCHAR2
                            ,P_ERR_PARAM IN OUT VARCHAR2) AS
    
        L_IS_IN_MSG_CLOB     VARCHAR2(1) := P_IS_IN_MSG_CLOB; 
        L_IN_MSG             CLOB;
        L_ERR_CODE           ERTB_MSGS.ERR_CODE%TYPE;
        L_ERR_PARAM          VARCHAR2(32767);
        L_PARENTS_LIST       VARCHAR2(32767);
        L_PARENTS_FORMAT     VARCHAR2(32767);
        L_TS_TAG_NAMES       VARCHAR2(32767);
        L_TS_TAG_VALUES      VARCHAR2(32767);
        L_TS_TAG_FORMAT      VARCHAR2(32767);
        L_TS_CLOB_TAG_NAMES  CLOB;
        L_TS_CLOB_TAG_VALUES CLOB;
        L_TS_CLOB_TAG_FORMAT CLOB;
        L_FCCREF             DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
        L_XREF               DETBS_RTL_TELLER.XREF%TYPE;
        P_DATA               VARCHAR2(32767);
        P_PARENT             VARCHAR2(32767);
        P_FORMAT             VARCHAR2(32767);
        P_TAG                VARCHAR2(32767);
        I                    NUMBER;
        L_TAG_NAME           VARCHAR2(50);
        L_TAG_VALUE          VARCHAR2(255);
        L_PROCESS_STATUS     VARCHAR2(1);
        L_PARENT_RES         VARCHAR2(100);
        L_PARENT             VARCHAR2(32767);
        L_KEY                VARCHAR2(32767);
        L_FORMAT             VARCHAR2(32767);
        L_DATA               VARCHAR2(32767);
        ERROR_EXCEPTION EXCEPTION;
        L_ERR_TBL          OVPKSS.TBL_ERROR;
        L_ERR_TAG_NAMES    VARCHAR2(1000);
        L_ERR_TAG_VALUES   VARCHAR2(1000);
        L_TY_UPTXN_DETAILS UPTB_PTXN_LOG%ROWTYPE;
        P_NEW_PARENT       VARCHAR2(32767); 
        P_IS_TAG_CLOB      VARCHAR2(32767);
        L_TY_RTUPLD        DEPKS_RETAILTELLERUPLOAD.TYP_RETAILTELLERUPLD_REC; 
    
    BEGIN
    
        DBG('inside pr_process_msg');
        SAVEPOINT SP_OPERATION;
    
        DBG('Taking the Incoming Message into CLOB Always..:' || P_IS_IN_MSG_CLOB);
        
        







        
        P_IS_OUT_MSG_CLOB := 'Y';
    
        P_FLAG := -1;
    IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
      DBG('Before callimg  gwpks_xml_parser.fn_parse_xml');
    
      IF NOT GWPKS_XML_PARSER.FN_XML_PARSER(P_REC_MSG_HEADER.SOURCE
                          
                          
                         ,L_PARENTS_LIST
                         ,L_PARENTS_FORMAT
                         ,L_TS_TAG_NAMES
                         ,L_TS_TAG_VALUES
                         ,L_TS_TAG_FORMAT
                         ,L_TS_CLOB_TAG_NAMES
                         ,L_TS_CLOB_TAG_VALUES
                         ,L_TS_CLOB_TAG_FORMAT
                         ,L_IS_IN_MSG_CLOB
                         ,P_IS_TAG_CLOB
                         ,P_ERR_CODE
                         ,P_ERR_PARAM)
      THEN
        DBG('FAILED IN gwpks_xml_parser.fn_parse_xml in Gwpks_QueryRetailTeller');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RAISE ERROR_EXCEPTION;
      END IF;
    
        ELSE
              L_PARENTS_LIST       := GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST;
              L_PARENTS_FORMAT     := '';
              L_TS_TAG_NAMES       := GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST;
              L_TS_TAG_VALUES      := GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST;
              L_TS_TAG_FORMAT      := '';
              L_TS_CLOB_TAG_NAMES  := '';
              L_TS_CLOB_TAG_VALUES := '';
              L_TS_CLOB_TAG_FORMAT := '';
              L_IS_IN_MSG_CLOB     := 'N';
              P_IS_TAG_CLOB        := 'N';
              P_ERR_CODE           := '';
              P_ERR_PARAM          := '';
         END IF;
    
        I := 1;
    
        L_PARENT := CSPKES_MISC.FN_GETPARAM(L_PARENTS_LIST, 1, '>');
    
        WHILE NVL(CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '~'), '??') <> 'EOPL'
        LOOP
            L_TAG_NAME := NVL(CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '~'), '??');
        
            L_TAG_VALUE := CSPKES_MISC.FN_GETPARAM(L_TS_TAG_VALUES, I, '~');
        
            IF L_TAG_NAME = 'FCCREF'
            THEN
                L_FCCREF := L_TAG_VALUE;
                DBG('l_fccref ' || L_FCCREF);
            END IF;
            IF L_TAG_NAME = 'XREF'
            THEN
                L_XREF := L_TAG_VALUE;
                DBG('l_xref ' || L_XREF);
            END IF;
        
            I := I + 1;
        
        END LOOP;
    
        L_PARENT_RES := 'Rtvws-Transaction-Details';
    
        DBG('Calling Fn_Resolve_Ref ..');
        IF NOT DEPKS_RETAILTELLERUPLOAD.FN_RESOLVE_REF(L_XREF, L_FCCREF, P_ERR_CODE, P_ERR_PARAM)
        THEN
            OVPKS.PR_INITERRTBL;
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            DBG('Failed in Fn_Resolve_Ref ' || P_ERR_CODE || '  ' || P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
    
        DBG('going to call the fn: fn_build_FSReply WITH l_parent AS ' || L_PARENT);
    
        IF SUBSTR(P_INSTR_REC.MSG_XCHANGE_PATTERN, 3, 2) = 'PK'
        THEN
            L_PARENT_RES := 'Rtvws-Transaction-Details-PK';
            IF NOT GWPKS_QUERYRETAILTELLER.FN_BUILD_PKREPLY(L_PARENT_RES
                                                           ,L_FCCREF
                                                           ,L_XREF
                                                           ,P_PARENT
                                                           ,P_TAG
                                                           ,P_DATA
                                                           ,P_FORMAT
                                                           ,P_ERR_CODE
                                                           ,P_ERR_PARAM)
            THEN
                DBG('FAILED IN fn_build_FSReply');
                OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                RAISE ERROR_EXCEPTION;
            END IF;
        ELSE
            L_PARENT_RES := 'Rtvws-Transaction-Details';
            
        
            IF NOT GWPKSS_EXT_RETAILTELLERSERVICE.FN_PRE_QUERYTRANSACTION(P_REC_MSG_HEADER
                                                                         ,P_INSTR_REC
                                                                         ,L_FCCREF
                                                                         ,L_XREF
                                                                         ,P_ERR_CODE
                                                                         ,P_ERR_PARAM)
            THEN
                DBG('Function gwpkss_ext_retailtellerservice.fn_pre_QueryTransaction returned FALSE');
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                RAISE ERROR_EXCEPTION;
            END IF;
        
            
            IF NOT FN_BUILD_FSREPLY(P_REC_MSG_HEADER.SOURCE
                                   ,L_PARENT_RES
                                   ,L_FCCREF
                                   ,L_TY_RTUPLD 
                                   ,L_XREF
                                   ,P_PARENT
                                   ,P_TAG
                                   ,P_DATA
                                   ,P_FORMAT
                                   ,P_ERR_CODE
                                   ,P_ERR_PARAM)
            THEN
                DBG('FAILED IN fn_build_FSReply');
                OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                RAISE ERROR_EXCEPTION;
            END IF;
        END IF;
        
    
        IF NOT GWPKSS_EXT_RETAILTELLERSERVICE.FN_POST_QUERYTRANSACTION(P_REC_MSG_HEADER
                                                                      ,P_INSTR_REC
                                                                      ,L_FCCREF
                                                                      ,L_XREF
                                                                      ,P_PARENT
                                                                      ,P_TAG
                                                                      ,P_DATA
                                                                      ,P_FORMAT
                                                                      ,P_ERR_CODE
                                                                      ,P_ERR_PARAM)
        THEN
            DBG('Function gwpkss_ext_retailtellerservice.fn_post_QueryTransaction returned FALSE');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
    
        
    
        DBG('p_parent = ' || P_PARENT);
        DBG('p_tag = ' || P_TAG);
        DBG('p_data = ' || P_DATA);
        DBG('p_format = ' || P_FORMAT);
        OVPKS.PR_APPENDTBL('ST-SAVE-023', P_ERR_PARAM);
        GWPKS_RETAILTELLERSERVICE.G_STATUS := 'S'; 
        IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
    
      IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                         ,P_INSTR_REC
                          
                          
                         ,P_IS_IN_MSG_CLOB
                         ,P_PARENT
                         ,P_FORMAT
                         ,P_TAG
                         ,P_DATA
                         ,L_TS_TAG_FORMAT
                         ,L_TS_CLOB_TAG_NAMES
                         ,L_TS_CLOB_TAG_VALUES
                         ,L_TS_CLOB_TAG_FORMAT
                         ,'S'
                          
                          
                         ,P_IS_OUT_MSG_CLOB)
      THEN
        DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
        RAISE ERROR_EXCEPTION;
      END IF;
    
       ELSE
        GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
        GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
        GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
        GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
      END IF;
    
        P_FLAG := 0;
        DBG(' Gateway package for Gwpks_QueryRetailTeller  returned successfully-- Status Flg: ' || P_FLAG);
        P_ERR_CODE := NULL;
    EXCEPTION
    
        WHEN ERROR_EXCEPTION THEN
            DBG('Inside error exception' || SQLERRM);
            DBG('Calling gwpkss_xml_crtr.fn_xml_creator for Error');
            P_ERR_CODE := NULL;
            GWPKS_RETAILTELLERSERVICE.G_STATUS := 'E'; 
            IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
      
        IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                           ,P_INSTR_REC
                            
                            
                           ,P_IS_IN_MSG_CLOB
                           ,P_PARENT
                           ,P_FORMAT
                           ,P_TAG
                           ,P_DATA
                           ,L_TS_TAG_FORMAT
                           ,L_TS_CLOB_TAG_NAMES
                           ,L_TS_CLOB_TAG_VALUES
                           ,L_TS_CLOB_TAG_FORMAT
                           ,'E'
                            
                            
                           ,P_IS_OUT_MSG_CLOB)
        THEN
          DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
          RAISE ERROR_EXCEPTION;
        END IF;
      
            ELSE
              GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
              GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
              GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
              GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
      END IF;
      
            P_FLAG := 0;
        
        WHEN OTHERS THEN
            P_ERR_CODE := NULL;
            DBG('In When Others of gwpks_create_MMcontract.pr_process_msg..');
            DBG(SQLERRM);
            ROLLBACK TO SP_OPERATION;
            OVPKS.PR_INITERRTBL;
            OVPKS.PR_APPENDTBL('GW-OTHR-001', P_ERR_PARAM);
            GWPKS_RETAILTELLERSERVICE.G_STATUS := 'E'; 
            IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
        
        IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                           ,P_INSTR_REC
                            
                            
                           ,P_IS_IN_MSG_CLOB
                           ,P_PARENT
                           ,P_FORMAT
                           ,P_TAG
                           ,P_DATA
                           ,L_TS_TAG_FORMAT
                           ,L_TS_CLOB_TAG_NAMES
                           ,L_TS_CLOB_TAG_VALUES
                           ,L_TS_CLOB_TAG_FORMAT
                           ,'E'
                            
                            
                           ,P_IS_OUT_MSG_CLOB)
        THEN
          DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
        END IF;
      
            ELSE
              GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
              GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
              GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
              GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
      END IF;
      
        
            P_FLAG := 0;
    END PR_PROCESS_MSG;
    








    FUNCTION FN_RESOLVE_REF_DEDQUERY(P_EXT_REF    IN OUT DETBS_RTL_TELLER.XREF%TYPE
                                    ,P_FCC_REF    IN OUT DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                                    ,P_ERR_CODE   IN OUT VARCHAR2
                                    ,P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN;

    FUNCTION FN_BUILD_SUBSYSPARENT_DEDQUERY(P_FCCREF       IN VARCHAR2
                                           ,P_PARENT       IN OUT VARCHAR2
                                           ,P_TAG          IN OUT VARCHAR2
                                           ,P_DATA         IN OUT VARCHAR2
                                           ,P_NODE         IN VARCHAR2
                                           ,P_FORMAT       IN OUT VARCHAR2
                                           ,P_PARENT_LEVEL IN OUT NUMBER
                                           ,P_ERR_CODE     IN OUT VARCHAR2
                                           ,P_ERR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN AS
    
    BEGIN
    
        P_PARENT       := P_PARENT || 'CSVWS_CONTRACT' || '>';
        P_TAG          := P_TAG || 'FCCREF' || '>';
        P_DATA         := P_DATA || P_FCCREF || '>';
        P_PARENT_LEVEL := P_PARENT_LEVEL + 1;
        P_FORMAT       := P_FORMAT || P_NODE || '.' || P_PARENT_LEVEL || '>';
    
        DBG('The function fn_build_subsysparent completed');
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-OTHR-001';
            P_ERR_PARAM := P_FCCREF || '~';
            RETURN FALSE;
    END FN_BUILD_SUBSYSPARENT_DEDQUERY;

    

    
    FUNCTION FN_BUILD_PKRESPONSE_DEDQUERY(P_PARENT_RES   IN VARCHAR2
                                         ,P_REFERENCE_NO IN VARCHAR2
                                         ,P_PARENT       IN OUT VARCHAR2
                                         ,P_TAG          IN OUT VARCHAR2
                                         ,P_DATA         IN OUT VARCHAR2
                                         ,P_FORMAT       IN OUT VARCHAR2
                                         ,P_ERR_CODE     IN OUT VARCHAR2
                                         ,P_ERR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
    
        L_EXT_REF DETBS_RTL_TELLER.XREF%TYPE;
    
    BEGIN
        DBG('p_parent in the fn_build_pkresponse' || P_PARENT_RES);
        DBG('p_tag' || P_TAG);
        DBG('p_data' || P_DATA);
        DBG('p_format' || P_FORMAT);
    
        RETURN TRUE;
        DBG('Functiom fn_build_PKResponse completed');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBG('No valid data found for the external refernce number in cstbs_contract');
            RETURN TRUE;
            NULL;
        
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-MMPD1';
            P_ERR_PARAM := P_REFERENCE_NO || '~';
            RETURN FALSE;
    END FN_BUILD_PKRESPONSE_DEDQUERY;
    
    FUNCTION FN_BUILD_RTDETAILS_DEDQUERY(P_SOURCE       IN VARCHAR2
                                        ,P_PARENT_RES   IN VARCHAR2
                                        ,P_REFERENCE_NO IN VARCHAR2
                                        ,P_PARENT       IN OUT VARCHAR2
                                        ,P_TAG          IN OUT VARCHAR2
                                        ,P_DATA         IN OUT VARCHAR2
                                        ,P_FORMAT       IN OUT VARCHAR2
                                        ,P_ERR_CODE     IN OUT VARCHAR2
                                        ,P_ERR_PARAM    IN OUT VARCHAR2)
    
     RETURN BOOLEAN IS
        L_UP_REC       RTVWS_TRANSACTION_DETAILS%ROWTYPE;
        L_UP_REC1      RTVWS_TRANSACTION_DETAILS%ROWTYPE;
        L_ROOT_COUNT   NUMBER := 0;
        L_FIRST_CHILDS NUMBER := 0;
        L_PARENT_CNT   NUMBER := 0;
        L_PARENT_LEVEL NUMBER := 0;
    
    BEGIN
   
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
     DBG('Calling gwpks_queryretailtlr_cluster.fn_pre_build_rtdetl_dedquery');
      IF NOT GWPKS_QUERYRETAILTLR_CLUSTER.FN_PRE_BUILD_RTDETL_DEDQUERY(P_SOURCE,
                                                             P_PARENT_RES,
                                                             P_REFERENCE_NO,
                                                             P_PARENT,
                                                             P_TAG,
                                                             P_DATA,
                                                             P_FORMAT,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
        DBG('Failed in call to fn_pre_build_rtdetl_dedquery..');
        RETURN FALSE;
      END IF;
    END IF;
  IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
        DBG('p_parent_res ' || P_PARENT_RES);
        P_PARENT := P_PARENT || P_PARENT_RES || '>';
        P_TAG    := P_TAG ||
                    'XREF~PRD~BATCHNO~TXNACC~TXNCCY~TXNAMT~TXNBRN~OFFSETACC~OFFSETCCY~OFFSETAMT~XRATE~LCYAMT~TXNDATE~VALDATE~RELCUST~CHRACC~CHGGL~CHGCCY~CHGAMT~TCYTOTCHGAMT~NETTINGIND~TXNCODE~REMACCOUNT~REMBANK~REMBRANCH~ROUTINGNO~ENDPOINT~SERIALNO~MISHEAD~ROUTECODE~ROUTEDESC~FCCREF~TXNTRN~OFFSETBRN~OFFSETTRN~TXNDR~TXNCR~MISHEAD1~CHGGL1~CHGCCY1~CHGAMT1~TCYTOTCHGAMT1~NETTINGIND1~TXNCODE1~MISHEAD2~CHGGL2~CHGCCY2~CHGAMT2~TCYTOTCHGAMT2~NETTINGIND2~TXNCODE2~MISHEAD3~CHGGL3~CHGCCY3~CHGAMT3~TCYTOTCHGAMT3~NETTINGIND3~TXNCODE3~MISHEAD4~CHGGL4~CHGCCY4~CHGAMT4~TCYTOTCHGAMT4~NETTINGIND4~TXNCODE4~MISHEAD5~REPREASON~NARRATIVE~TRACKREVERSE~LCYXRATE~MAKERID~MAKERSTAMP~CHECKERID~CHECKERSTAMP~MODNO~CONTSTAT~AUTHSTAT~';
        P_TAG    := P_TAG ||
                   
                   
                    'STREMINST1~STREMINST2~STREMINST3~STREMINST4~STREMINST5~STINTRMED1~STINTRMED2~STINTRMED3~STINTRMED4~STINTRMED5~STRECORRESP1~STRECORRESP2~STRECORRESP3~STRECORRESP4~STRECORRESP5~STACWTINST1~STACWTINST2~STACWTINST3~STACWTINST4~STACWTINST5~SNDRTORCV1~SNDRTORCV2~SNDRTORCV3~SNDRTORCV4~SNDRTORCV5~SNDRTORCV6~RECVINTER1~RECVINTER2~RECVINTER3~RECVINTER4~RECVINTER5~BENEFINS1~BENEFINS2~BENEFINS3~BENEFINS4~BENEFINS5~BENEFINST1~BENEFINST2~BENEFINST3~BENEFINST4~BENEFINST5~STULTBEN1~STULTBEN2~STULTBEN3~STULTBEN4~STULTBEN5~STRECEIVER~COVERREQ~CHARGESDETAILS~REGULATORY1~REGULATORY2~REGULATORY3~ENVELOP1~ENVELOP2~ENVELOP3~ENVELOP4~ENVELOP5~BANKOPER~INSTRCODE~TRNTYPCD~TXNTANKED~REIMCTRY~INTERMCNTRY~RECCORRESCTRY~ACCINSTCTRY~RECINTERCTRY~BENINSTCTRY~BENINSTCOVERCTRY~ULTBENCTRY~' || '>';
        
    
        SELECT A.XREF XREF
              ,A.PRODUCT_CODE PRD
              ,A.BRANCH_CODE BATCHNO
              ,A.TXN_ACC TXNACC
              ,A.TXN_CCY TXNCCY
              ,A.TXN_AMOUNT TXNAMT
              ,A.TXN_BRANCH TXNBRN
              ,A.OFS_ACC OFFSETACC
              ,A.OFS_CCY OFFSETCCY
              ,A.OFS_AMOUNT OFFSETAMT
              ,A.EXCH_RATE XRATE
              ,A.LCY_AMOUNT LCYAMT
              ,A.TRN_DT TXNDATE
              ,A.VALUE_DT VALDATE
              ,A.REL_CUSTOMER RELCUST
              ,A.CHARGE_ACCOUNT CHRACC
              ,A.CHG_GL CHGGL
              ,A.CHG_CCY CHGCCY
              ,A.CHG_AMT CHGAMT
              ,A.CHG_IN_ACY TCYTOTCHGAMT
              ,A.NETTING_IND NETTINGIND
              ,A.TXN_CODE TXNCODE
              ,A.REM_ACC REMACCOUNT
              ,A.REM_BANK REMBANK
              ,A.REM_BRANCH REMBRANCH
              ,A.ROUTING_NO ROUTINGNO
              ,A.END_POINT ENDPOINT
              ,A.SERIAL_NO SERIALNO
              ,A.MIS_HEAD MISHEAD
              ,A.ROUTE_CODE ROUTECODE
              ,'' ROUTEDESC
              ,'' STREMINST1
              ,'' STINTRMED1
              ,'' STRECORRESP1
              ,'' STACWTINST1
              ,'' STULTBEN1
              ,'' STRECEIVER
              ,A.TRN_REF_NO FCCREF
              ,A.TXN_TRN_CODE TXNTRN
              ,A.OFS_BRANCH OFFSETBRN
              ,A.OFS_TRN_CODE OFFSETTRN
              ,A.DR_INSTRUMENT_CODE TXNDR
              ,A.CR_INSTRUMENT_CODE TXNCR
              ,A.MIS_HEAD_1 MISHEAD1
              ,A.CHG_GL_1 CHGGL1
              ,A.CHG_CCY_1 CHGCCY1
              ,A.CHG_AMT_1 CHGAMT1
              ,A.CHG_IN_ACY_1 TCYTOTCHGAMT1
              ,A.NETTING_IND_1 NETTINGIND1
              ,A.TXN_CODE_1 TXNCODE1
              ,A.MIS_HEAD_2 MISHEAD2
              ,A.CHG_GL_2 CHGGL2
              ,A.CHG_CCY_2 CHGCCY2
              ,A.CHG_AMT_2 CHGAMT2
              ,A.CHG_IN_ACY_2 TCYTOTCHGAMT2
              ,A.NETTING_IND_2 NETTINGIND2
              ,A.TXN_CODE_2 TXNCODE2
              ,A.MIS_HEAD_3 MISHEAD3
              ,A.CHG_GL_3 CHGGL3
              ,A.CHG_CCY_3 CHGCCY3
              ,A.CHG_AMT_3 CHGAMT3
              ,A.CHG_IN_ACY_3 TCYTOTCHGAMT3
              ,A.NETTING_IND_3 NETTINGIND3
              ,A.TXN_CODE_3 TXNCODE3
              ,A.MIS_HEAD_4 MISHEAD4
              ,A.CHG_GL_4 CHGGL4
              ,A.CHG_CCY_4 CHGCCY4
              ,A.CHG_AMT_4 CHGAMT4
              ,A.CHG_IN_ACY_4 TCYTOTCHGAMT4
              ,A.NETTING_IND_4 NETTINGIND4
              ,A.TXN_CODE_4 TXNCODE4
              ,A.MIS_HEAD_5 MISHEAD5
              ,A.REPAIR_REASON REPREASON
              ,A.NARRATIVE NARRATIVE
              ,A.TRACK_RECEIVABLE TRACKREVERSE
              ,A.LCY_EXCH_RATE LCYXRATE
              ,A.MAKER_ID MAKERID
              ,A.MAKER_DT_STAMP MAKERDT
              ,A.CHECKER_ID CHECKERID
              ,A.CHECKER_DT_STAMP CHECKERDT
              ,A.MOD_NO MODNO
              ,A.RECORD_STAT CONTSTAT
              ,A.AUTH_STAT AUTHSTAT
        ,A.CHEQUE_ISSUE_DATE
                
              ,'' SRCCODE
              ,'' TRNNAR      
                              
              ,'' STREMINST2
              ,'' STREMINST3
              ,'' STREMINST4
              ,'' STREMINST5
              ,'' STINTRMED2
              ,'' STINTRMED3
              ,'' STINTRMED4
              ,'' STINTRMED5
              ,'' STRECORRESP2
              ,'' STRECORRESP3
              ,'' STRECORRESP4
              ,'' STRECORRESP5
              ,'' STACWTINST2
              ,'' STACWTINST3
              ,'' STACWTINST4
              ,'' STACWTINST5
              ,'' COVERREQ
              ,'' SNDRTORCV1
              ,'' SNDRTORCV2
              ,'' SNDRTORCV3
              ,'' SNDRTORCV4
              ,'' SNDRTORCV5
              ,'' SNDRTORCV6
              ,'' RECVINTER1
              ,'' RECVINTER2
              ,'' RECVINTER3
              ,'' RECVINTER4
              ,'' RECVINTER5
              ,'' BENEFINS1
              ,'' BENEFINS2
              ,'' BENEFINS3
              ,'' BENEFINS4
              ,'' BENEFINS5
              ,'' BENEFINST1
              ,'' BENEFINST2
              ,'' BENEFINST3
              ,'' BENEFINST4
              ,'' BENEFINST5
              ,'' STULTBEN2
              ,'' STULTBEN3
              ,'' STULTBEN4
              ,'' STULTBEN5
              ,'' CHARGESDETAILS
              ,'' REGULATORY1
              ,'' REGULATORY2
              ,'' REGULATORY3
              ,'' ENVELOP1
              ,'' ENVELOP2
              ,'' ENVELOP3
              ,'' ENVELOP4
              ,'' ENVELOP5
              ,'' BANKOPER
              ,'' INSTRCODE
              ,'' TRNTYPCD
              ,A.TXN_TANKED 
               
              ,'' REIMCTRY
              ,'' INTERMCNTRY
              ,'' RECCORRESCTRY
              ,'' ACCINSTCTRY
              ,'' RECINTERCTRY
              ,'' BENINSTCTRY
              ,'' BENINSTCOVERCTRY
              ,'' ULTBENCTRY   

              ,'' MODULE
              ,'' BRNDESC
              ,'' PRODDESC
              ,'' DBTACCBAL
              ,'' CRDACCBAL                

         ,A.VIR_ACC_NO 
             ,''  TRNCDDESC  
             ,A.SDB_REF_NO 
        
    
                 , '' TXNBRNDESC
                 , '' OFSBRNDESC
                 , '' OFSTRNCDDESC
                 , '' TXNACDESC
                 , '' OFSACDESC
                 
        
        INTO   L_UP_REC
        FROM   DETBS_RTL_TELLER A
        WHERE  A.TRN_REF_NO = P_REFERENCE_NO;
    
        BEGIN
            SELECT '' XREF
                  ,'' PRD
                  ,'' BATCHNO
                  ,'' TXNACC
                  ,'' TXNCCY
                  ,'' TXNAMT
                  ,'' TXNBRN
                  ,'' OFFSETACC
                  ,'' OFFSETCCY
                  ,'' OFFSETAMT
                  ,'' XRATE
                  ,'' LCYAMT
                  ,'' TXNDATE
                  ,'' VALDATE
                  ,'' RELCUST
                  ,'' CHRACC
                  ,'' CHGGL
                  ,'' CHGCCY
                  ,'' CHGAMT
                  ,'' TCYTOTCHGAMT
                  ,'' NETTINGIND
                  ,'' TXNCODE
                  ,'' REMACCOUNT
                  ,'' REMBANK
                  ,'' REMBRANCH
                  ,'' ROUTINGNO
                  ,'' ENDPOINT
                  ,'' SERIALNO
                  ,'' MISHEAD
                  ,'' ROUTECODE
                  ,B.ROUTE_DESC ROUTEDESC
                  ,B.INT_REIM_INST1 STREMINST1
                  ,B.INTERMEDIARY1 STINTRMED1
                  ,B.RCVR_CORRESP1 STRECORRESP1
                  ,B.ACC_WITH_INSTN1 STACWTINST1
                  ,B.ULT_BENEFICIARY1 STULTBEN1
                  ,B.RECEIVER STRECEIVER
                  ,'' FCCREF
                  ,'' TXNTRN
                  ,'' OFFSETBRN
                  ,'' OFFSETTRN
                  ,'' TXNDR
                  ,'' TXNCR
                  ,'' MISHEAD1
                  ,'' CHGGL1
                  ,'' CHGCCY1
                  ,'' CHGAMT1
                  ,'' TCYTOTCHGAMT1
                  ,'' NETTINGIND1
                  ,'' TXNCODE1
                  ,'' MISHEAD2
                  ,'' CHGGL2
                  ,'' CHGCCY2
                  ,'' CHGAMT2
                  ,'' TCYTOTCHGAMT2
                  ,'' NETTINGIND2
                  ,'' TXNCODE2
                  ,'' MISHEAD3
                  ,'' CHGGL3
                  ,'' CHGCCY3
                  ,'' CHGAMT3
                  ,'' TCYTOTCHGAMT3
                  ,'' NETTINGIND3
                  ,'' TXNCODE3
                  ,'' MISHEAD4
                  ,'' CHGGL4
                  ,'' CHGCCY4
                  ,'' CHGAMT4
                  ,'' TCYTOTCHGAMT4
                  ,'' NETTINGIND4
                  ,'' TXNCODE4
                  ,'' MISHEAD5
                  ,'' REPREASON
                  ,'' NARRATIVE
                  ,'' TRACKREVERSE
                  ,'' LCYXRATE
                  ,'' MAKERID
                  ,'' MAKERDT
                  ,'' CHECKERID
                  ,'' CHECKERDT
                  ,'' MODNO
                  ,'' CONTSTAT
                  ,'' AUTHSTAT
          ,'' CHEQISSDT

                  ,'' SRCCODE
                  ,'' TRNNAR               

                  ,B.INT_REIM_INST2 STREMINST2
                  ,B.INT_REIM_INST3 STREMINST3
                  ,B.INT_REIM_INST4 STREMINST4
                  ,B.INT_REIM_INST5 STREMINST5
                  ,B.INTERMEDIARY2 STINTRMED2
                  ,B.INTERMEDIARY3 STINTRMED3
                  ,B.INTERMEDIARY4 STINTRMED4
                  ,B.INTERMEDIARY5 STINTRMED5
                  ,B.RCVR_CORRESP2 STRECORRESP2
                  ,B.RCVR_CORRESP3 STRECORRESP3
                  ,B.RCVR_CORRESP4 STRECORRESP4
                  ,B.RCVR_CORRESP5 STRECORRESP5
                  ,B.ACC_WITH_INSTN2 STACWTINST2
                  ,B.ACC_WITH_INSTN3 STACWTINST3
                  ,B.ACC_WITH_INSTN4 STACWTINST4
                  ,B.ACC_WITH_INSTN5 STACWTINST5
                  ,B.COVER_REQUIRED COVERREQ
                  ,B.SNDR_TO_RCVR_INFO1 SNDRTORCV1
                  ,B.SNDR_TO_RCVR_INFO2 SNDRTORCV2
                  ,B.SNDR_TO_RCVR_INFO3 SNDRTORCV3
                  ,B.SNDR_TO_RCVR_INFO4 SNDRTORCV4
                  ,B.SNDR_TO_RCVR_INFO5 SNDRTORCV5
                  ,B.SNDR_TO_RCVR_INFO6 SNDRTORCV6
                  ,B.RECV_INTERMEDIARY1 RECVINTER1
                  ,B.RECV_INTERMEDIARY2 RECVINTER2
                  ,B.RECV_INTERMEDIARY3 RECVINTER3
                  ,B.RECV_INTERMEDIARY4 RECVINTER4
                  ,B.RECV_INTERMEDIARY5 RECVINTER5
                  ,B.BENEF_INSTITUTION1 BENEFINS1
                  ,B.BENEF_INSTITUTION2 BENEFINS2
                  ,B.BENEF_INSTITUTION3 BENEFINS3
                  ,B.BENEF_INSTITUTION4 BENEFINS4
                  ,B.BENEF_INSTITUTION5 BENEFINS5
                  ,B.BENEF_INST1_FOR_COVER BENEFINST1
                  ,B.BENEF_INST2_FOR_COVER BENEFINST2
                  ,B.BENEF_INST3_FOR_COVER BENEFINST3
                  ,B.BENEF_INST4_FOR_COVER BENEFINST4
                  ,B.BENEF_INST5_FOR_COVER BENEFINST5
                  ,B.ULT_BENEFICIARY2 STULTBEN2
                  ,B.ULT_BENEFICIARY3 STULTBEN3
                  ,B.ULT_BENEFICIARY4 STULTBEN4
                  ,B.ULT_BENEFICIARY5 STULTBEN5
                  ,B.CHARGES_DETAILS CHARGESDETAILS
                  ,B.REGULATORY_REP1 REGULATORY1
                  ,B.REGULATORY_REP2 REGULATORY2
                  ,B.REGULATORY_REP3 REGULATORY3
                  ,B.ENVELOPE_CONTENTS1 ENVELOP1
                  ,B.ENVELOPE_CONTENTS2 ENVELOP2
                  ,B.ENVELOPE_CONTENTS3 ENVELOP3
                  ,B.ENVELOPE_CONTENTS4 ENVELOP4
                  ,B.ENVELOPE_CONTENTS5 ENVELOP5
                  ,B.BANK_OPER_CODE BANKOPER
                  ,B.INSTR_CODE INSTRCODE
                  ,B.TRAN_TYPE_CODE TRNTYPCD
                  ,'' TXN_TANKED 
                   
                  ,B.REIM_CTRY             REIMCTRY
                  ,B.INTERMEDIARY_CTRY     INTERMCNTRY
                  ,B.RECEIVER_CORRESP_CTRY RECCORRESCTRY
                  ,B.ACCT_WITH_INST_CTRY   ACCINSTCTRY
                  ,B.RECVR_INTERMED_CTRY   RECINTERCTRY
                  ,B.BEN_INST_CTRY         BENINSTCTRY
                  ,B.BEN_INST_COVER_CTRY   BENINSTCOVERCTRY
                  ,B.ULT_BEN_CTRY          ULTBENCTRY

                  ,'' MODULE
                  ,'' BRNDESC
                  ,'' PRODDESC
                  ,'' DBTACCBAL
                  ,'' CRDACCBAL 
           , '' VIRACCNO 

            
                 ,''  TRNCDDESC  
         , '' SDBREFNO 
           
                 , '' TXNBRNDESC
                 , '' OFSBRNDESC
                 , '' OFSTRNCDDESC
                 , '' TXNACDESC
                 , '' OFSACDESC
                 
            INTO   L_UP_REC1
            FROM   CSTBS_ARC_SETTLE B
            WHERE  B.XREF = L_UP_REC.XREF;
        EXCEPTION
            WHEN OTHERS THEN
                DBG('No Record for the Reference Number in cstbs_arc_settle');
                L_UP_REC1.ROUTEDESC := '';
        END;
        L_ROOT_COUNT := L_ROOT_COUNT + 1; 
        P_DATA       := L_UP_REC.XREF || '~' || L_UP_REC.PRD || '~' || L_UP_REC.BATCHNO || '~' || L_UP_REC.TXNACC || '~' ||
                        L_UP_REC.TXNCCY || '~' || L_UP_REC.TXNAMT || '~' || L_UP_REC.TXNBRN || '~' ||
                        L_UP_REC.OFFSETACC || '~' || L_UP_REC.OFFSETCCY || '~' || L_UP_REC.OFFSETAMT || '~' ||
                        L_UP_REC.XRATE || '~' || L_UP_REC.LCYAMT || '~' || TO_CHAR(L_UP_REC.TXNDATE, 'RRRR-MM-DD') || '~' ||
                        TO_CHAR(L_UP_REC.VALDATE, 'RRRR-MM-DD') || '~' || L_UP_REC.RELCUST || '~' || L_UP_REC.CHRACC || '~' ||
                        L_UP_REC.CHGGL || '~' || L_UP_REC.CHGCCY || '~' || L_UP_REC.CHGAMT || '~' ||
                        L_UP_REC.TCYTOTCHGAMT || '~' || L_UP_REC.NETTINGIND || '~' || L_UP_REC.TXNCODE || '~' ||
                        L_UP_REC.REMACCOUNT || '~' || L_UP_REC.REMBANK || '~' || L_UP_REC.REMBRANCH || '~' ||
                        L_UP_REC.ROUTINGNO || '~' || L_UP_REC.ENDPOINT || '~' || L_UP_REC.SERIALNO || '~' ||
                        L_UP_REC.MISHEAD || '~' || L_UP_REC.ROUTECODE || '~' || L_UP_REC1.ROUTEDESC || '~' ||
                        L_UP_REC.FCCREF || '~' || L_UP_REC.TXNTRN || '~' || L_UP_REC.OFFSETBRN || '~' ||
                        L_UP_REC.OFFSETTRN || '~' || L_UP_REC.TXNDR || '~' || L_UP_REC.TXNCR || '~' ||
                        L_UP_REC.MISHEAD1 || '~' || L_UP_REC.CHGGL1 || '~' || L_UP_REC.CHGCCY1 || '~' ||
                        L_UP_REC.CHGAMT1 || '~' || L_UP_REC.TCYTOTCHGAMT1 || '~' || L_UP_REC.NETTINGIND1 || '~' ||
                        L_UP_REC.TXNCODE1 || '~' || L_UP_REC.MISHEAD2 || '~' || L_UP_REC.CHGGL2 || '~' ||
                        L_UP_REC.CHGCCY2 || '~' || L_UP_REC.CHGAMT2 || '~' || L_UP_REC.TCYTOTCHGAMT2 || '~' ||
                        L_UP_REC.NETTINGIND2 || '~' || L_UP_REC.TXNCODE2 || '~' || L_UP_REC.MISHEAD3 || '~' ||
                        L_UP_REC.CHGGL3 || '~' || L_UP_REC.CHGCCY3 || '~' || L_UP_REC.CHGAMT3 || '~' ||
                        L_UP_REC.TCYTOTCHGAMT3 || '~' || L_UP_REC.NETTINGIND3 || '~' || L_UP_REC.TXNCODE3 || '~' ||
                        L_UP_REC.MISHEAD4 || '~' || L_UP_REC.CHGGL4 || '~' || L_UP_REC.CHGCCY4 || '~' ||
                        L_UP_REC.CHGAMT4 || '~' || L_UP_REC.TCYTOTCHGAMT4 || '~' || L_UP_REC.NETTINGIND4 || '~' ||
                        L_UP_REC.TXNCODE4 || '~' || L_UP_REC.MISHEAD5 || '~' || L_UP_REC.REPREASON || '~' ||
                        L_UP_REC.NARRATIVE || '~' || L_UP_REC.TRACKREVERSE || '~' || L_UP_REC.LCYXRATE || '~' ||
                        L_UP_REC.MAKERID || '~' || TO_CHAR(L_UP_REC.MAKERDT, STPKS_FCMAINT_SERVICE.G_DATE_TIME_FORMAT) || '~' ||
                        L_UP_REC.CHECKERID || '~' ||
                        TO_CHAR(L_UP_REC.CHECKERDT, STPKS_FCMAINT_SERVICE.G_DATE_TIME_FORMAT) || '~' || L_UP_REC.MODNO || '~' ||
                        L_UP_REC.CONTSTAT || '~' || L_UP_REC.AUTHSTAT || '~';
    
        
        P_DATA := P_DATA || L_UP_REC1.STREMINST1 || '~' || L_UP_REC1.STREMINST2 || '~' || L_UP_REC1.STREMINST3 || '~' ||
                  L_UP_REC1.STREMINST4 || '~' || L_UP_REC1.STINTRMED1 || '~' || L_UP_REC1.STINTRMED2 || '~' ||
                  L_UP_REC1.STINTRMED3 || '~' || L_UP_REC1.STINTRMED4 || '~' || L_UP_REC1.STINTRMED5 || '~' ||
                  L_UP_REC1.STREMINST5 || '~' || L_UP_REC1.STRECORRESP1 || '~' || L_UP_REC1.STRECORRESP2 || '~' ||
                  L_UP_REC1.STRECORRESP3 || '~' || L_UP_REC1.STRECORRESP4 || '~' || L_UP_REC1.STRECORRESP5 || '~' ||
                  L_UP_REC1.STACWTINST1 || '~' || L_UP_REC1.STACWTINST2 || '~' || L_UP_REC1.STACWTINST3 || '~' ||
                  L_UP_REC1.STACWTINST4 || '~' || L_UP_REC1.STACWTINST5 || '~' || L_UP_REC1.SNDRTORCV1 || '~' ||
                  L_UP_REC1.SNDRTORCV2 || '~' || L_UP_REC1.SNDRTORCV3 || '~' || L_UP_REC1.SNDRTORCV4 || '~' ||
                  L_UP_REC1.SNDRTORCV5 || '~' || L_UP_REC1.SNDRTORCV6 || '~' || L_UP_REC1.RECVINTER1 || '~' ||
                  L_UP_REC1.RECVINTER2 || '~' || L_UP_REC1.RECVINTER3 || '~' || L_UP_REC1.RECVINTER4 || '~' ||
                  L_UP_REC1.RECVINTER5 || '~' || L_UP_REC1.BENEFINS1 || '~' || L_UP_REC1.BENEFINS2 || '~' ||
                  L_UP_REC1.BENEFINS3 || '~' || L_UP_REC1.BENEFINS4 || '~' || L_UP_REC1.BENEFINS5 || '~' ||
                  L_UP_REC1.BENEFINST1 || '~' || L_UP_REC1.BENEFINST2 || '~' || L_UP_REC1.BENEFINST3 || '~' ||
                  L_UP_REC1.BENEFINST4 || '~' || L_UP_REC1.BENEFINST5 || '~' || L_UP_REC1.STULTBEN1 || '~' ||
                  L_UP_REC1.STULTBEN2 || '~' || L_UP_REC1.STULTBEN3 || '~' || L_UP_REC1.STULTBEN4 || '~' ||
                  L_UP_REC1.STULTBEN5 || '~' || L_UP_REC1.STRECEIVER || '~' || L_UP_REC1.COVERREQ || '~' ||
                  L_UP_REC1.CHARGESDETAILS || '~' || L_UP_REC1.REGULATORY1 || '~' || L_UP_REC1.REGULATORY2 || '~' ||
                  L_UP_REC1.REGULATORY3 || '~' || L_UP_REC1.ENVELOP1 || '~' || L_UP_REC1.ENVELOP2 || '~' ||
                  L_UP_REC1.ENVELOP3 || '~' || L_UP_REC1.ENVELOP4 || '~' || L_UP_REC1.ENVELOP5 || '~' ||
                  L_UP_REC1.BANKOPER || '~' || L_UP_REC1.INSTRCODE || '~' || L_UP_REC1.TRNTYPCD || '~' ||
                 
                 
                  L_UP_REC.TXNTANKED || '~' || L_UP_REC1.REIMCTRY || '~' || L_UP_REC1.INTERMCNTRY || '~' ||
                  L_UP_REC1.RECCORRESCTRY || '~' || L_UP_REC1.ACCINSTCTRY || '~' || L_UP_REC1.RECINTERCTRY || '~' ||
                  L_UP_REC1.BENINSTCTRY || '~' || L_UP_REC1.BENINSTCOVERCTRY || '~' || L_UP_REC1.ULTBENCTRY || '~' || '~>';
        
    
        
        P_FORMAT := L_ROOT_COUNT || '>'; 
        P_PARENT := P_PARENT_RES || '>';
        DBG(P_FORMAT);
    
        IF P_SOURCE = 'FLEXCUBE'
        THEN
            DBG('Source is FLEXCUBE');
            IF NOT FN_BUILD_SUBSYSPARENT_DEDQUERY(P_REFERENCE_NO
                                                 ,P_PARENT
                                                 ,P_TAG
                                                 ,P_DATA
                                                 ,L_ROOT_COUNT
                                                 ,P_FORMAT
                                                 ,L_FIRST_CHILDS
                                                 ,P_ERR_CODE
                                                 ,P_ERR_PARAM)
            THEN
                DBG('Failed in Fn_Build_Subsysparent..');
                RETURN FALSE;
            END IF;
            L_PARENT_CNT := L_ROOT_COUNT || '.' || L_FIRST_CHILDS;
        ELSE
            L_PARENT_CNT := L_ROOT_COUNT;
        
        END IF;
    
        DBG('p_format:::::::::::::' || P_FORMAT);
    
        IF NOT FN_REPLY_CHGDETS(P_SOURCE
                               ,P_REFERENCE_NO
                               ,P_DATA
                               ,P_TAG
                               ,P_PARENT
                               ,P_FORMAT
                               ,L_ROOT_COUNT
                               ,L_FIRST_CHILDS
                               ,P_ERR_CODE
                               ,P_ERR_PARAM)
        THEN
            DBG('Failed in fn_reply_chgdets..');
            RETURN FALSE;
        END IF;
    
        IF NOT GWPKS_BUILD_SUBSYSTEM_TS.FN_BUILD_MISDETAILS(P_REFERENCE_NO
                                                           ,P_PARENT
                                                           ,P_TAG
                                                           ,P_DATA
                                                           ,L_PARENT_CNT
                                                           ,P_FORMAT
                                                           ,L_PARENT_LEVEL
                                                           ,P_ERR_CODE
                                                           ,P_ERR_PARAM)
        
        THEN
        
            DBG('FAiled in Gwpks_Build_Subsystem_Ts.Fn_Build_Misdetails..');
            RETURN FALSE;
        END IF;
    
        DBG('CAlling Gwpks_Build_Subsystem_Ts.Fn_Build_Cont_Udfdetails..');
        IF NOT GWPKS_BUILD_SUBSYSTEM_TS.FN_BUILD_CONT_UDFDETAILS(P_REFERENCE_NO
                                                                ,'1'
                                                                ,P_PARENT
                                                                ,P_TAG
                                                                ,P_DATA
                                                                ,L_PARENT_CNT
                                                                ,P_FORMAT
                                                                ,L_PARENT_LEVEL
                                                                ,P_ERR_CODE
                                                                ,P_ERR_PARAM)
        THEN
            DBG('FAield in Gwpks_Build_Subsystem_Ts.Fn_Build_Cont_Udfdetails..');
            RETURN FALSE;
        END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
    
        DBG('Returning Successfully from FN_BUILD_RTDETAILS');
    
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-UPMT1'; 
            P_ERR_PARAM := P_REFERENCE_NO || '~';
            DBG(SQLCODE || SQLERRM);
            RETURN FALSE;
    END FN_BUILD_RTDETAILS_DEDQUERY;
    

    FUNCTION FN_BUILD_FSREPLY_DEDQUERY(P_SOURCE     IN VARCHAR2
                                      ,P_PARENT_RES IN VARCHAR2
                                      ,P_FCCREF     IN VARCHAR2
                                      ,P_XREF       IN VARCHAR2
                                      ,P_PARENT     IN OUT VARCHAR2
                                      ,P_TAG        IN OUT VARCHAR2
                                      ,P_DATA       IN OUT VARCHAR2
                                      ,P_FORMAT     IN OUT VARCHAR2
                                      ,P_ERR_CODE   IN OUT VARCHAR2
                                      ,P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
        L_FCCREF DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
    BEGIN
        DBG('Inside the function fn_build_FSReply ');
    
        IF NOT FN_BUILD_RTDETAILS_DEDQUERY(P_SOURCE
                                          ,P_PARENT_RES
                                          ,P_FCCREF
                                          ,P_PARENT
                                          ,P_TAG
                                          ,P_DATA
                                          ,P_FORMAT
                                          ,P_ERR_CODE
                                          ,P_ERR_PARAM)
        THEN
            DBG('FAILED IN fn_build_UPDetails');
            P_ERR_CODE  := 'GW-SUBS-01';
            P_ERR_PARAM := '';
            RETURN FALSE;
        END IF;
        DBG('AFTER MM');
        DBG('p_parent>>' || P_PARENT);
        DBG('p_tag>>' || P_TAG);
        DBG('p_data>>' || P_DATA);
        DBG('Returning true from  the function fn_build_FSReply ');
    
        RETURN TRUE;
    
    EXCEPTION
        WHEN OTHERS THEN
            P_ERR_CODE  := 'GW-MMPD1';
            P_ERR_PARAM := 'In the fn_build_fsreply';
            RETURN FALSE;
    END FN_BUILD_FSREPLY_DEDQUERY;
    

    PROCEDURE PR_PROCESS_MSG_DEDQUERY(P_IS_IN_MSG_CLOB IN VARCHAR2
                                      
                                      
                                     ,P_REC_MSG_HEADER  IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER
                                     ,P_IS_OUT_MSG_CLOB OUT VARCHAR2
                                      
                                      
                                     ,P_INSTR_REC IN OUT NOCOPY GWPKS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS
                                     ,P_FLAG      OUT NUMBER
                                     ,P_ERR_CODE  IN OUT VARCHAR2
                                     ,P_ERR_PARAM IN OUT VARCHAR2) AS
    
        
        L_IS_IN_MSG_CLOB     VARCHAR2(1) := P_IS_IN_MSG_CLOB; 
        L_IN_MSG             CLOB;
        L_ERR_CODE           ERTB_MSGS.ERR_CODE%TYPE;
        L_ERR_PARAM          VARCHAR2(32767);
        L_PARENTS_LIST       VARCHAR2(32767);
        L_PARENTS_FORMAT     VARCHAR2(32767);
        L_TS_TAG_NAMES       VARCHAR2(32767);
        L_TS_TAG_VALUES      VARCHAR2(32767);
        L_TS_TAG_FORMAT      VARCHAR2(32767);
        L_TS_CLOB_TAG_NAMES  CLOB;
        L_TS_CLOB_TAG_VALUES CLOB;
        L_TS_CLOB_TAG_FORMAT CLOB;
        L_TREF               DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
        L_XREF               DETBS_RTL_TELLER.XREF%TYPE;
        P_DATA               VARCHAR2(32767);
        P_PARENT             VARCHAR2(32767);
        P_FORMAT             VARCHAR2(32767);
        P_TAG                VARCHAR2(32767);
        I                    NUMBER;
        L_TAG_NAME           VARCHAR2(50);
        L_TAG_VALUE          VARCHAR2(255);
        L_PROCESS_STATUS     VARCHAR2(1);
        L_PARENT_RES         VARCHAR2(100);
        L_PARENT             VARCHAR2(32767);
        L_KEY                VARCHAR2(32767);
        L_FORMAT             VARCHAR2(32767);
        L_DATA               VARCHAR2(32767);
        ERROR_EXCEPTION EXCEPTION;
        L_ERR_TBL          OVPKSS.TBL_ERROR;
        L_ERR_TAG_NAMES    VARCHAR2(1000);
        L_ERR_TAG_VALUES   VARCHAR2(1000);
        L_TY_UPTXN_DETAILS UPTB_PTXN_LOG%ROWTYPE;
        P_NEW_PARENT       VARCHAR2(32767); 
        P_IS_TAG_CLOB      VARCHAR2(32767);
    BEGIN
    
        DBG('inside Pr_Process_Msg_Dedquery >>>>');
        SAVEPOINT SP_OPERATION;
    
        DBG('Taking the Incoming Message into CLOB Always..:' || P_IS_IN_MSG_CLOB);
        
        








        
        P_FLAG := -1;
    IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
      DBG('Before callimg  gwpks_xml_parser.fn_parse_xml');
      IF NOT GWPKS_XML_PARSER.FN_XML_PARSER(P_REC_MSG_HEADER.SOURCE
                          
                          
                         ,L_PARENTS_LIST
                         ,L_PARENTS_FORMAT
                         ,L_TS_TAG_NAMES
                         ,L_TS_TAG_VALUES
                         ,L_TS_TAG_FORMAT
                         ,L_TS_CLOB_TAG_NAMES
                         ,L_TS_CLOB_TAG_VALUES
                         ,L_TS_CLOB_TAG_FORMAT
                         ,L_IS_IN_MSG_CLOB
                         ,P_IS_TAG_CLOB
                         ,P_ERR_CODE
                         ,P_ERR_PARAM)
      THEN
        DBG('FAILED IN gwpks_xml_parser.fn_parse_xml in gwpks_queryretailteller');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
        RAISE ERROR_EXCEPTION;
      END IF;
    
    ELSE
      L_PARENTS_LIST       := GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST;
      L_PARENTS_FORMAT     := '';
      L_TS_TAG_NAMES       := GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST;
      L_TS_TAG_VALUES      := GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST;
      L_TS_TAG_FORMAT      := '';
      L_TS_CLOB_TAG_NAMES  := '';
      L_TS_CLOB_TAG_VALUES := '';
      L_TS_CLOB_TAG_FORMAT := '';
      L_IS_IN_MSG_CLOB     := 'N';
      P_IS_TAG_CLOB        := 'N';
      P_ERR_CODE           := '';
      P_ERR_PARAM          := '';
     END IF;
     
    
        I := 1;
    
        L_PARENT := CSPKES_MISC.FN_GETPARAM(L_PARENTS_LIST, 1, '>');
    
    
    DBG('The message clob is:'||L_IS_IN_MSG_CLOB);
     IF L_IS_IN_MSG_CLOB = 'Y' THEN
        
      WHILE NVL(CSPKES_MISC.FN_GETPARAM(L_TS_CLOB_TAG_NAMES, I, '~'), '??') <> 'EOPL'
      LOOP
        L_TAG_NAME := NVL(CSPKES_MISC.FN_GETPARAM(L_TS_CLOB_TAG_NAMES, I, '~'), '??');

        L_TAG_VALUE := CSPKES_MISC.FN_GETPARAM(L_TS_CLOB_TAG_VALUES, I, '~');

        IF L_TAG_NAME = 'FCCREF'
        THEN
          L_TREF := L_TAG_VALUE;

        END IF;
        IF L_TAG_NAME = 'XREF'
        THEN
          L_XREF := L_TAG_VALUE;

        END IF;

        I := I + 1;

      END LOOP;
        
        ELSE
    
    
        WHILE NVL(CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '~'), '??') <> 'EOPL'
        LOOP
            L_TAG_NAME := NVL(CSPKES_MISC.FN_GETPARAM(L_TS_TAG_NAMES, I, '~'), '??');
        
            L_TAG_VALUE := CSPKES_MISC.FN_GETPARAM(L_TS_TAG_VALUES, I, '~');
        
            IF L_TAG_NAME = 'FCCREF'
            THEN
                L_TREF := L_TAG_VALUE;
            
            END IF;
            IF L_TAG_NAME = 'XREF'
            THEN
                L_XREF := L_TAG_VALUE;
            
            END IF;
        
            I := I + 1;
        
        END LOOP;
    END IF; 
        L_PARENT_RES := 'Rtvws-Transaction-Details';
    
        DBG('Calling Fn_Resolve_Ref ..');
        IF NOT FN_RESOLVE_REF_DEDQUERY(L_XREF, L_TREF, P_ERR_CODE, P_ERR_PARAM)
        THEN
            OVPKS.PR_INITERRTBL;
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            DBG('Failed in Fn_Resolve_Ref ' || P_ERR_CODE || '  ' || P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
    
        DBG('going to call the fn: fn_build_FSReply WITH l_parent AS ' || L_PARENT);
        
    
        IF NOT GWPKSS_EXT_RETAILTELLERSERVICE.FN_PRE_QUERYTRANSACTION(P_REC_MSG_HEADER
                                                                     ,P_INSTR_REC
                                                                     ,L_TREF
                                                                     ,L_XREF
                                                                     ,P_ERR_CODE
                                                                     ,P_ERR_PARAM)
        THEN
            DBG('Function gwpkss_ext_retailtellerservice.fn_pre_QueryTransaction returned FALSE');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
    
        
        IF NOT FN_BUILD_FSREPLY_DEDQUERY(P_REC_MSG_HEADER.SOURCE
                                        ,L_PARENT_RES
                                        ,L_TREF
                                        ,L_XREF
                                        ,P_PARENT
                                        ,P_TAG
                                        ,P_DATA
                                        ,P_FORMAT
                                        ,P_ERR_CODE
                                        ,P_ERR_PARAM)
        THEN
            DBG('FAILED IN fn_build_FSReply');
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
        
    
        IF NOT GWPKSS_EXT_RETAILTELLERSERVICE.FN_POST_QUERYTRANSACTION(P_REC_MSG_HEADER
                                                                      ,P_INSTR_REC
                                                                      ,L_TREF
                                                                      ,L_XREF
                                                                      ,P_PARENT
                                                                      ,P_TAG
                                                                      ,P_DATA
                                                                      ,P_FORMAT
                                                                      ,P_ERR_CODE
                                                                      ,P_ERR_PARAM)
        THEN
            DBG('Function gwpkss_ext_retailtellerservice.fn_post_QueryTransaction returned FALSE');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            RAISE ERROR_EXCEPTION;
        END IF;
    
        
    
        DBG('p_parent = ' || P_PARENT);
        DBG('p_tag = ' || P_TAG);
        DBG('p_data = ' || P_DATA);
        DBG('p_format = ' || P_FORMAT);
        
        IF NVL(L_IS_IN_MSG_CLOB, 'N') = 'Y'
        THEN
            L_TS_CLOB_TAG_NAMES  := P_TAG;
            L_TS_CLOB_TAG_VALUES := P_DATA;
        END IF;
        
     GWPKS_RETAILTELLERSERVICE.G_STATUS := 'S'; 
     IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
    
        IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                                             ,P_INSTR_REC
                                              
                                              
                                             ,P_IS_IN_MSG_CLOB
                                             ,P_PARENT
                                             ,P_FORMAT
                                             ,P_TAG
                                             ,P_DATA
                                             ,L_TS_TAG_FORMAT
                                             ,L_TS_CLOB_TAG_NAMES
                                             ,L_TS_CLOB_TAG_VALUES
                                             ,L_TS_CLOB_TAG_FORMAT
                                             ,'S'
                                              
                                              
                                             ,P_IS_OUT_MSG_CLOB)
        THEN
            DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
            RAISE ERROR_EXCEPTION;
        END IF;
   
     ELSE
          GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
          GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
          GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
          GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
      END IF;
    
    
        P_FLAG      := -1; 
        P_ERR_PARAM := NULL; 
        P_ERR_CODE  := NULL; 
        DBG(' Gateway package for gwpks_queryretailteller  returned successfully-- Status Flg: ' || P_FLAG);
    
    EXCEPTION
    
        WHEN ERROR_EXCEPTION THEN
            DBG('Inside error exception');
            DBG(SQLERRM);
            GWPKS_RETAILTELLERSERVICE.G_STATUS := 'E'; 
            IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
      
        DBG('Calling gwpkss_xml_crtr.fn_xml_creator for Error');
        IF NOT GWPKS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                          ,P_INSTR_REC
                           
                           
                           
                          ,L_IS_IN_MSG_CLOB 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,NULL 
                          ,'E'
                           
                           
                          ,P_IS_OUT_MSG_CLOB)
        
        THEN
          DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
        END IF;
      
            ELSE
                GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
                GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
                GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
                GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
            END IF;
      
      
            DBG('DEC :' || P_IS_OUT_MSG_CLOB);
            
            P_FLAG      := -1; 
            P_ERR_PARAM := NULL; 
            P_ERR_CODE  := NULL; 
    
        WHEN OTHERS THEN
        
            DBG('In When Others of gwpks_create_MMcontract.pr_process_msg..');
            DBG(SQLERRM);
            ROLLBACK TO SP_OPERATION;
            OVPKS.PR_INITERRTBL;
            OVPKS.PR_APPENDTBL('GW-OTHR-001', P_ERR_PARAM);
            GWPKS_RETAILTELLERSERVICE.G_STATUS := 'E'; 
            IF GWPKS_RETAILTELLERSERVICE.G_FLAG = 'N' THEN 
      
        IF NOT GWPKSS_XML_CRTR.FN_XML_CREATOR(P_REC_MSG_HEADER
                           ,P_INSTR_REC
                            
                            
                           ,P_IS_IN_MSG_CLOB
                           ,P_PARENT
                           ,P_FORMAT
                           ,P_TAG
                           ,P_DATA
                           ,L_TS_TAG_FORMAT
                           ,L_TS_CLOB_TAG_NAMES
                           ,L_TS_CLOB_TAG_VALUES
                           ,L_TS_CLOB_TAG_FORMAT
                           ,'E'
                            
                            
                           ,P_IS_OUT_MSG_CLOB)
        THEN
          DBG('FAILED IN gwpkss_xml_crtr.fn_xml_creator ');
        END IF;
      
            ELSE
                GWPKS_RETAILTELLERSERVICE.G_PARENTS_NAME_LIST := P_PARENT;
                GWPKS_RETAILTELLERSERVICE.G_TAG_NAME_LIST := P_TAG;
                GWPKS_RETAILTELLERSERVICE.G_TAG_VALUES_LIST := P_DATA;
                GWPKS_RETAILTELLERSERVICE.G_PARENTS_FMT_LIST := P_FORMAT;
            END IF;
      
        
            P_FLAG := 0;
    END PR_PROCESS_MSG_DEDQUERY;

    FUNCTION FN_RESOLVE_REF_DEDQUERY(P_EXT_REF    IN OUT DETBS_RTL_TELLER.XREF%TYPE
                                    ,P_FCC_REF    IN OUT DETBS_RTL_TELLER.TRN_REF_NO%TYPE
                                    ,P_ERR_CODE   IN OUT VARCHAR2
                                    ,P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    
        L_ACT_EXT_REF DETBS_RTL_TELLER.XREF%TYPE;
        L_ACT_FCC_REF DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
        L_COUNT       NUMBER;
    
    BEGIN
        DBG('Inside Fn_Resolve_Ref_Dedquery.....................................................');
        DBG('In fn_resolve_ref..Parameters are ');
        DBG('p_Ext_Ref-->' || P_EXT_REF);
        DBG('p_Fcc_Ref-->' || P_FCC_REF);
    
        IF P_FCC_REF IS NOT NULL
        THEN
            L_ACT_FCC_REF := P_FCC_REF;
            BEGIN
                SELECT XREF
                INTO   L_ACT_EXT_REF
                FROM   DETBS_RTL_TELLER
                WHERE  TRN_REF_NO = P_FCC_REF AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                      
                       AND NVL(MODULE, 'RT') <> 'DD'; 
            
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    DBG('Transaction Not Found in FLEXCUBE..');
                    P_ERR_CODE   := 'WB-TXN-001';
                    P_ERR_PARAMS := P_FCC_REF;
                    RETURN FALSE;
            END;
            DBG('External Ref No In FCC :' || L_ACT_EXT_REF);
            IF NVL(P_EXT_REF, NVL(L_ACT_EXT_REF, '*')) <> NVL(L_ACT_EXT_REF, '*')
            THEN
                DBG('Reference Numbers Sent Do Not Match with FLEXCUBE..' || P_EXT_REF || ':' || P_FCC_REF);
                P_ERR_CODE   := 'FT-REFR-002';
                P_ERR_PARAMS := P_EXT_REF || '~' || P_FCC_REF;
                RETURN FALSE;
            END IF;
            P_EXT_REF := L_ACT_EXT_REF;
        ELSIF P_EXT_REF IS NOT NULL
        THEN
            L_ACT_EXT_REF := P_EXT_REF;
            DBG('Entered into Else block');
            DBG('p_ext_ref :' || P_EXT_REF);
            BEGIN
                SELECT TRN_REF_NO
                INTO   L_ACT_FCC_REF
                FROM   DETBS_RTL_TELLER
                WHERE  XREF = P_EXT_REF AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                      
                       AND NVL(MODULE, 'RT') <> 'DD'; 
            
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    DBG('Transaction Not Found in FLEXCUBE..');
                    P_ERR_CODE   := 'WB-TXN-001';
                    P_ERR_PARAMS := P_EXT_REF;
                    RETURN FALSE;
            END;
            DBG('FCC  Ref No            :' || L_ACT_FCC_REF);
            IF NVL(P_FCC_REF, NVL(L_ACT_FCC_REF, '*')) <> NVL(L_ACT_FCC_REF, '*')
            THEN
                DBG('Reference Numbers Sent Do Not Match with FLEXCUBE..' || P_EXT_REF || ':' || P_FCC_REF);
                P_ERR_CODE   := 'FT-REFR-002';
                P_ERR_PARAMS := P_EXT_REF || '~' || P_FCC_REF;
                RETURN FALSE;
            END IF;
            P_FCC_REF := L_ACT_FCC_REF;
        ELSE
            DBG('Both External Reference No and FCC Ref No are NULL..');
            P_ERR_CODE   := 'FT-REFR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
        END IF;
    
        RETURN TRUE;
    EXCEPTION
        WHEN OTHERS THEN
            DEBUG.PR_DEBUG('**', 'In when others of gwpks_queryretailteller.fn_resolve_ref ..');
            DEBUG.PR_DEBUG('**', SQLERRM);
            P_ERR_CODE   := 'FT-OTHR-001';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
    END FN_RESOLVE_REF_DEDQUERY;

END GWPKS_QUERYRETAILTELLER;