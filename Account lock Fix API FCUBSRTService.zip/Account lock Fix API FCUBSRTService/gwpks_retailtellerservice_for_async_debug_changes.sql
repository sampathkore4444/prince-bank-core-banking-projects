CREATE OR REPLACE PACKAGE BODY gwpks_retailtellerservice AS

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF',
                   '[DEBUG] ' || 'gwpks_retailtellerservice :' || P_DBG);
  END DBG;

  PROCEDURE DBG(P_DBG_IND IN VARCHAR2, P_DBG IN VARCHAR2) IS
  BEGIN
    IF P_DBG_IND = 'E' THEN
      DEBUG.PR_DEBUG('IF',
                     '[ERROR]' || 'gwpks_retailtellerservice :' || P_DBG);
    ELSE
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG]' || 'gwpks_retailtellerservice :' || P_DBG);
    END IF;
  END DBG;

  PROCEDURE PR_SERVICE_HANDLER(P_IS_IN_MSG_CLOB IN VARCHAR2

                              ,
                               P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                               P_IS_OUT_MSG_CLOB OUT VARCHAR2

                              ,
                               P_INSTR_REC IN OUT GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                               P_ERR_CODE  IN OUT VARCHAR2,
                               P_ERR_PARAM IN OUT VARCHAR2) AS
    P_FLAG NUMBER;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN

    DBG('inside gwpks_retailtellerservice.pr_service_handler');
    DBG('p_rec_msg_header.service_name      :' ||
        P_REC_MSG_HEADER.SERVICE_NAME);
    DBG('p_rec_msg_header.operation_code    :' ||
        P_REC_MSG_HEADER.OPERATION_CODE);
    DBG('p_rec_msg_header.source_operation  :' ||
        P_REC_MSG_HEADER.SOURCE_OPERATION);
    DBG('p_rec_msg_header.branch_code        :' ||
        P_REC_MSG_HEADER.BRANCH_CODE);
    DBG('p_rec_msg_header.user_id            :' ||
        P_REC_MSG_HEADER.USER_ID);
    DBG('p_rec_msg_header.source            :' || P_REC_MSG_HEADER.SOURCE);

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DBG('The action flag sent to the gwpks_retailtlrservice_cluster.pr_service_handler is:' ||
          P_FLAG);
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('p_flag') := TO_CHAR(P_FLAG);
      GWPKS_RETAILTLRSERVICE_CLUSTER.PR_SERVICE_HANDLER(P_IS_IN_MSG_CLOB,
                                                        P_REC_MSG_HEADER,
                                                        P_IS_OUT_MSG_CLOB,
                                                        P_INSTR_REC,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM);

    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF (P_REC_MSG_HEADER.OPERATION_CODE = 'CreateTransaction' OR
         P_REC_MSG_HEADER.OPERATION_CODE = 'CreateRTTransaction') THEN
        DBG('About to Call Gwpkss_CreateRetailTlr.pr_process_msg  ');
        GWPKSS_CREATERETAILTLR.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                             ,
                                              P_REC_MSG_HEADER,
                                              P_IS_OUT_MSG_CLOB

                                             ,
                                              P_INSTR_REC,
                                              P_FLAG,
                                              P_ERR_CODE,
                                              P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'PickupARC' THEN
        DBG('About to call the function Gwpks_PickupARC.pr_process_msg    ');
        GWPKS_PICKUPARC.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                      ,
                                       P_REC_MSG_HEADER,
                                       P_IS_OUT_MSG_CLOB

                                      ,
                                       P_INSTR_REC,
                                       P_FLAG,
                                       P_ERR_CODE,
                                       P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE IN
            ('CreateIntraTransaction', 'CreateIntraLiqTransaction') THEN
        DBG('CALLING gwpks_creatertintrabank.pr_process_msg WITH operation_code =' ||
            P_REC_MSG_HEADER.OPERATION_CODE);
        GWPKS_CREATERTINTRABANK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                              ,
                                               P_REC_MSG_HEADER,
                                               P_IS_OUT_MSG_CLOB

                                              ,
                                               P_INSTR_REC,
                                               P_FLAG,
                                               P_ERR_CODE,
                                               P_ERR_PARAM);
      ELSIF P_REC_MSG_HEADER.OPERATION_CODE IN
            ('EnrichIntraTransaction', 'EnrichIntraLiqTransaction') THEN
        DBG('CALLING Gwpks_EnrichRTIntraBank.pr_process_msg WITH operation_code =' ||
            P_REC_MSG_HEADER.OPERATION_CODE);
        GWPKS_ENRICHRTINTRABANK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                              ,
                                               P_REC_MSG_HEADER,
                                               P_IS_OUT_MSG_CLOB

                                              ,
                                               P_INSTR_REC,
                                               P_FLAG,
                                               P_ERR_CODE,
                                               P_ERR_PARAM);
      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'Queryinterbranch' THEN
        DBG('CALLING gwpks_queryrtliqintrabank.pr_process_msg WITH operation_code  ---------Queryinterbranch');
        GWPKS_QUERYRTLIQINTRABANK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                                ,
                                                 P_REC_MSG_HEADER,
                                                 P_IS_OUT_MSG_CLOB

                                                ,
                                                 P_INSTR_REC,
                                                 P_FLAG,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM);
      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'ReverseIntraTransaction' THEN
        DBG('About to call the function gwpks_reversertintrabank.pr_process_msg    ');
        GWPKS_REVERSERTINTRABANK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                               ,
                                                P_REC_MSG_HEADER,
                                                P_IS_OUT_MSG_CLOB

                                               ,
                                                P_INSTR_REC,
                                                P_FLAG,
                                                P_ERR_CODE,
                                                P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'ReverseTransaction' THEN
        DBG('About to call the function Gwpkss_ReverseRetailTlr.pr_process_msg    ');
        GWPKSS_REVERSERETAILTLR.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                              ,
                                               P_REC_MSG_HEADER,
                                               P_IS_OUT_MSG_CLOB

                                              ,
                                               P_INSTR_REC,
                                               P_FLAG,
                                               P_ERR_CODE,
                                               P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'AuthorizeTransaction' THEN
        DBG('About to call the function Gwpkss_AuthorizeRetailTlr.pr_process_msg    ');
        GWPKSS_AUTHORIZERETAILTLR.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                                ,
                                                 P_REC_MSG_HEADER,
                                                 P_IS_OUT_MSG_CLOB

                                                ,
                                                 P_INSTR_REC,
                                                 P_FLAG,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'QueryTransaction' THEN
        DBG('About to Call gwpks_Queryretailteller.pr_process_msg  ');
        IF P_REC_MSG_HEADER.SOURCE = 'FLEXCUBE' THEN

          GWPKS_QUERYRETAILTELLER.PR_PROCESS_MSG_DEDQUERY(P_IS_IN_MSG_CLOB

                                                         ,
                                                          P_REC_MSG_HEADER,
                                                          P_IS_OUT_MSG_CLOB

                                                         ,
                                                          P_INSTR_REC,
                                                          P_FLAG,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM);

        ELSE
          GWPKS_QUERYRETAILTELLER.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                                ,
                                                 P_REC_MSG_HEADER,
                                                 P_IS_OUT_MSG_CLOB

                                                ,
                                                 P_INSTR_REC,
                                                 P_FLAG,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM);
        END IF;

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'QueryRTlending' THEN
        GWPKS_QUERYRTLENDING.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                            P_REC_MSG_HEADER,
                                            P_IS_OUT_MSG_CLOB,
                                            P_INSTR_REC,
                                            P_FLAG,
                                            P_ERR_CODE,
                                            P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'EnrichTransaction' THEN
        DBG('About to Call Gwpks_EnrichRetailTlr.pr_process_msg  ');
        GWPKS_ENRICHRETAILTLR.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB

                                            ,
                                             P_REC_MSG_HEADER,
                                             P_IS_OUT_MSG_CLOB

                                            ,
                                             P_INSTR_REC,
                                             P_FLAG,
                                             P_ERR_CODE,
                                             P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'BranchIVUpload' THEN
        DBG('About to Call gwpks_brnivupload.pr_process_msg  ');
        GWPKS_BRNIVUPLOAD.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                         P_REC_MSG_HEADER,
                                         P_IS_OUT_MSG_CLOB,
                                         P_INSTR_REC,
                                         P_FLAG,
                                         P_ERR_CODE,
                                         P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'BranchEOD' THEN
        DBG('About to Call gwpks_brneodmaint.pr_process_msg  ');
        GWPKS_BRNEODMAINT.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                         P_REC_MSG_HEADER,
                                         P_IS_OUT_MSG_CLOB,
                                         P_INSTR_REC,
                                         P_FLAG,
                                         P_ERR_CODE,
                                         P_ERR_PARAM);
      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'OfflineUpload' THEN
        DBG('About to Call stpks_brn_offline_upld.pr_process_msg  ');
        STPKS_BRN_OFFLINE_UPLD.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                              P_REC_MSG_HEADER,
                                              P_IS_OUT_MSG_CLOB,
                                              P_INSTR_REC,
                                              P_FLAG,
                                              P_ERR_CODE,
                                              P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'QuerySDRental' THEN
        DBG('About to Call gwpks_querysafedepositdetails.pr_process_msg  ');
        GWPKS_QUERYSAFEDEPOSITDETAILS.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                                     P_REC_MSG_HEADER,
                                                     P_IS_OUT_MSG_CLOB,
                                                     P_INSTR_REC,
                                                     P_FLAG,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'CalcExchangeAmt' THEN
        GWPKS_ENRICHRETAILTLR.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                             P_REC_MSG_HEADER,
                                             P_IS_OUT_MSG_CLOB,
                                             P_INSTR_REC,
                                             P_FLAG,
                                             P_ERR_CODE,
                                             P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'ResolveVirtualAcc' THEN
        DBG('Some other Operation code ... just to resolve virtual acc: ' ||
            P_REC_MSG_HEADER.OPERATION_CODE);
        GWPKS_ENRICHRETAILTLR.PR_PROCESS_VIRTACC(P_IS_IN_MSG_CLOB,
                                                 P_REC_MSG_HEADER,
                                                 P_IS_OUT_MSG_CLOB,
                                                 P_INSTR_REC,
                                                 P_FLAG,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'CreateAccPassbook' THEN
        DBG('Calling Gwpks_NewPassBook');
        GWPKS_NEWPASSBOOK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                         P_REC_MSG_HEADER,
                                         P_IS_OUT_MSG_CLOB,
                                         P_INSTR_REC,
                                         P_FLAG,
                                         P_ERR_CODE,
                                         P_ERR_PARAM);

      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'UpdateAccPassbook' THEN
        DBG('Calling gwpks_updatepassbook');
        GWPKS_UPDATEPASSBOOK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                            P_REC_MSG_HEADER,
                                            P_IS_OUT_MSG_CLOB,
                                            P_INSTR_REC,
                                            P_FLAG,
                                            P_ERR_CODE,
                                            P_ERR_PARAM);
      ELSIF P_REC_MSG_HEADER.OPERATION_CODE = 'RePrintAccPassbook' THEN
        DBG('Calling gwpks_reprintpassbook');
        GWPKS_REPRINTPASSBOOK.PR_PROCESS_MSG(P_IS_IN_MSG_CLOB,
                                             P_REC_MSG_HEADER,
                                             P_IS_OUT_MSG_CLOB,
                                             P_INSTR_REC,
                                             P_FLAG,
                                             P_ERR_CODE,
                                             P_ERR_PARAM);

      ELSE
        DBG('Some other Operation code Specified : ' ||
            P_REC_MSG_HEADER.OPERATION_CODE);
        RETURN;
        DBG('Some other Operation code Specified : ' ||
            P_REC_MSG_HEADER.OPERATION_CODE);
        ROLLBACK TO CUSTOMER;
        RETURN;

      END IF;

    ELSE
      IF L_TB_CLUSTER_DATA.EXISTS('p_flag') THEN
        DBG('THe p_flag from cluster is:' || P_FLAG);
        P_FLAG := TO_NUMBER(L_TB_CLUSTER_DATA('p_flag'));
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('Return successfully from Gwpks_CustomerService.pr_service_handler');
  END PR_SERVICE_HANDLER;

  PROCEDURE PR_CAL_PROCESSTIME(P_STARTTIME   IN NUMBER,
                               P_END_TIME    OUT NUMBER,
                               P_DBSESSIONID OUT NUMBER) IS
  BEGIN
    BEGIN
      SELECT ROUND(SECONDS * 1000 + MINUTES * 60 + HOURS * 3600, 3) "Respose time(Secs)"
        INTO P_END_TIME
        FROM (SELECT (EXTRACT(SECOND FROM SYSTIMESTAMP)) SECONDS,
                     (EXTRACT(MINUTE FROM SYSTIMESTAMP)) MINUTES,
                     (EXTRACT(HOUR FROM SYSTIMESTAMP)) HOURS
                FROM DUAL);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in calculating time' || SQLERRM);
        P_END_TIME := 0;
    END;
    BEGIN
      SELECT SYS_CONTEXT('userenv', 'sessionid') SESSION_ID
        INTO P_DBSESSIONID
        FROM DUAL;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in calculating time' || SQLERRM);
        P_DBSESSIONID := 0;
    END;

    DBG('end_time : ' || P_END_TIME);
    P_END_TIME := P_END_TIME - P_STARTTIME;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Pr_Cal_Processtime :' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

  END PR_CAL_PROCESSTIME;

  PROCEDURE PR_STRT_PROCESSTIME(P_STARTTIME IN OUT NUMBER) IS
  BEGIN
    BEGIN
      SELECT ROUND(SECONDS * 1000 + MINUTES * 60 + HOURS * 3600, 3) "Respose time(Secs)"
        INTO P_STARTTIME
        FROM (SELECT (EXTRACT(SECOND FROM SYSTIMESTAMP)) SECONDS,
                     (EXTRACT(MINUTE FROM SYSTIMESTAMP)) MINUTES,
                     (EXTRACT(HOUR FROM SYSTIMESTAMP)) HOURS
                FROM DUAL);
    EXCEPTION
      WHEN OTHERS THEN
        P_STARTTIME := 0;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of Pr_Strt_Processtime :' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

  END PR_STRT_PROCESSTIME;

  PROCEDURE PR_SERVICE_HANDLER_JAVA(P_USER              IN SMTB_USER.USER_ID%TYPE,
                                    P_BRANCH            IN STTM_BRANCH.BRANCH_CODE%TYPE,
                                    P_HEADER_NAMES      IN OUT VARCHAR2,
                                    P_HEADER_VALS       IN OUT VARCHAR2,
                                    P_ADDL_NAMES        IN OUT VARCHAR2,
                                    P_ADDL_VALS         IN OUT VARCHAR2,
                                    P_PARENTS_NAME_LIST IN OUT CHARARRAYTYP_TY,
                                    P_PARENTS_FMT_LIST  IN OUT CHARARRAYTYP_TY,
                                    P_TAG_NAME_LIST     IN OUT CHARARRAYTYP_TY,
                                    P_TAG_VALUES_LIST   IN OUT CHARARRAYTYP_TY,
                                    P_ERROR_NODES       IN OUT VARCHAR2,
                                    P_STATUS            IN OUT VARCHAR2,
                                    P_TIMELOG           IN OUT VARCHAR2,
                                    P_DB_LOG            OUT CLOB) AS

    L_REC_MSG_HEADER GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER;
    L_ADDL           GWPKSS_SERVICE_ROUTER.ADDL_TAB;
    L_INSTR_REC      GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS;

    E_FAILURE_EXCEPTION  EXCEPTION;
    E_OVERRIDE_EXCEPTION EXCEPTION;

    L_HEADER_NAMES VARCHAR2(2000) := P_HEADER_NAMES;
    L_HEADER_VALS  VARCHAR2(2000) := P_HEADER_VALS;
    L_ADDL_NAMES   VARCHAR2(2000) := P_ADDL_NAMES;
    L_ADDL_VALS    VARCHAR2(2000) := P_ADDL_VALS;
    L_ATTR_NAMES   VARCHAR2(2000);
    L_ATTR_VALS    VARCHAR2(2000);

    L_NAME_POS  NUMBER;
    L_VAL_POS   NUMBER;
    L_ANAME_POS NUMBER;
    L_AVAL_POS  NUMBER;
    L_ADDL_POS  NUMBER;
    L_HDR_NAME  VARCHAR2(100);
    L_HDR_VAL   VARCHAR2(200);
    L_ADDL_NAME VARCHAR2(100);
    L_ADDL_VAL  VARCHAR2(200);
    L_ATTR_NAME VARCHAR2(100);
    L_ATTR_VAL  VARCHAR2(200);

    L_VA_PARENTS_LIST   CSPKS_REQ_GLOBAL.TY_VC_ARRAY;
    L_VA_PARENTS_FORMAT CSPKS_REQ_GLOBAL.TY_VC_ARRAY;
    L_VA_TAG_NAMES      CSPKS_REQ_GLOBAL.TY_VC_ARRAY;
    L_VA_TAG_VALUES     CSPKS_REQ_GLOBAL.TY_VC_ARRAY;

    L_PARENT_LIST_INDEX NUMBER;
    L_PARENT_FMT_INDEX  NUMBER;
    L_TAG_NAMES_INDEX   NUMBER;
    L_TAG_VALUES_INDEX  NUMBER;

    L_STATUS     VARCHAR2(50) := P_STATUS;
    L_ERR_CODE   VARCHAR2(32767);
    L_ERR_PARAMS VARCHAR2(32767);

    L_IS_CLOB VARCHAR2(32767);

    L_FLD_SEP VARCHAR2(32767) := '>';

    L_PARENTS_LIST   VARCHAR2(32767);
    L_PARENTS_FORMAT VARCHAR2(32767);
    L_TAG_NAME       VARCHAR2(32767);
    L_TAG_VALUES     VARCHAR2(32767);
    L_INDEX          NUMBER;
    L_COUNT          NUMBER;
    L_ERR_NODE       VARCHAR2(32767);
    L_ERR_PARAM      VARCHAR2(32767);
    L_ERR_MESSAGE    VARCHAR2(32767);
    L_ERR_TYPE       ERTBS_MSGS.TYPE%TYPE;

    L_START_TIME  NUMBER;
    L_END_TIME    NUMBER;
    L_DBSESSIONID NUMBER;

    L_CNT        NUMBER := 1;
    L_DEBUG_MODE BOOLEAN := FALSE;

    L_DENOM_FLAG              BOOLEAN := FALSE;
    L_DENOM_PARENTS_NAME_LIST VARCHAR2(32767) := '';
    L_DENOM_PARENTS_FMT_LIST  VARCHAR2(32767) := '';
    L_DENOM_TAG_NAME_LIST     VARCHAR2(32767) := '';
    L_DENOM_TAG_VALUES_LIST   VARCHAR2(32767) := '';

    L_FLAG       BOOLEAN;
    L_DEBUG_CHAR VARCHAR2(1);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    SAVEPOINT SP_PROCESS_REQUEST;

    PR_STRT_PROCESSTIME(L_START_TIME);
    GLOBAL.PR_INIT(P_BRANCH, P_USER);

    CSPKS_REQ_GLOBAL.PR_MSG_INIT;

    G_PARENTS_NAME_LIST := '';
    G_PARENTS_FMT_LIST  := '';
    G_TAG_NAME_LIST     := '';
    G_TAG_VALUES_LIST   := '';

    L_NAME_POS := NVL(INSTR(L_HEADER_NAMES, '~'), 0);
    L_VAL_POS  := NVL(INSTR(L_HEADER_VALS, '~'), 0);

    L_DEBUG_MODE := FALSE;
    L_DEBUG_CHAR := 'N';
    WHILE (L_NAME_POS > 0) LOOP
      L_HDR_NAME     := SUBSTR(L_HEADER_NAMES, 1, L_NAME_POS - 1);
      L_HEADER_NAMES := SUBSTR(L_HEADER_NAMES,
                               L_NAME_POS + 1,
                               LENGTH(L_HEADER_NAMES));
      L_HDR_VAL      := SUBSTR(L_HEADER_VALS, 1, L_VAL_POS - 1);
      L_HEADER_VALS  := SUBSTR(L_HEADER_VALS,
                               L_VAL_POS + 1,
                               LENGTH(L_HEADER_VALS));
      IF L_HDR_NAME = 'SOURCE' THEN
        L_REC_MSG_HEADER.SOURCE := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'SERVICE' THEN
        L_REC_MSG_HEADER.SERVICE_NAME := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'OPERATION' THEN
        L_REC_MSG_HEADER.OPERATION_CODE := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'SOURCE_OPERATION' THEN
        L_REC_MSG_HEADER.SOURCE_OPERATION := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'BRANCH' THEN
        L_REC_MSG_HEADER.BRANCH_CODE := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'USERID' THEN
        L_REC_MSG_HEADER.USER_ID := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'UBSCOMP' THEN
        L_REC_MSG_HEADER.UBSCOMP := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'MODULEID' THEN
        L_REC_MSG_HEADER.MODULEID := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'DEPT' THEN
        L_REC_MSG_HEADER.DEPT := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'LOC' THEN
        L_REC_MSG_HEADER.LOC := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'MULTITRIPID' THEN
        L_REC_MSG_HEADER.MULTITRIPID := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'FUNCTIONID' THEN
        L_REC_MSG_HEADER.FUNCTIONID := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'ACTION' THEN
        L_REC_MSG_HEADER.ACTION := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'MSGSTAT' THEN
        L_REC_MSG_HEADER.MSGSTAT := L_HDR_VAL;

      ELSIF L_HDR_NAME = 'MSGID' THEN

        L_REC_MSG_HEADER.MSGID := L_HDR_VAL;
      ELSIF L_HDR_NAME = 'DEBUG_MODE' THEN
        L_DEBUG_MODE := TRUE;
        L_DEBUG_CHAR := 'Y';
      END IF;

      L_NAME_POS := NVL(INSTR(L_HEADER_NAMES, '~'), 0);
      L_VAL_POS  := NVL(INSTR(L_HEADER_VALS, '~'), 0);

    END LOOP;
    L_ANAME_POS := NVL(INSTR(L_ADDL_NAMES, '~'), 0);
    L_AVAL_POS  := NVL(INSTR(L_ADDL_VALS, '~'), 0);

    DBG(' p_user ==> ' || P_USER);
    DBG(' p_branch ==> ' || P_BRANCH);
    DBG(' p_header_names ==> ' || P_HEADER_NAMES);
    DBG(' p_header_vals ==> ' || P_HEADER_VALS);
    DBG(' p_error_nodes ==> ' || P_ERROR_NODES);
    DBG(' p_status ==> ' || P_STATUS);
    
      --sampath starts
        DEBUG.PR_SET_ASYNC_REF(P_USER || '_' ||
                               P_BRANCH || '_' ||
                               REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'),
                                       ':'));
        --sampath ends

    DBG('Addl Names  : ' || L_ADDL_NAMES);
    DBG('Addl Values : ' || L_ADDL_VALS);
    WHILE (L_ANAME_POS > 0) LOOP
      L_ADDL_NAME  := SUBSTR(L_ADDL_NAMES, 1, L_ANAME_POS - 1);
      L_ADDL_NAMES := SUBSTR(L_ADDL_NAMES,
                             L_ANAME_POS + 1,
                             LENGTH(L_ADDL_NAMES));
      L_ADDL_VAL   := SUBSTR(L_ADDL_VALS, 1, L_AVAL_POS - 1);
      L_ADDL_VALS  := SUBSTR(L_ADDL_VALS,
                             L_AVAL_POS + 1,
                             LENGTH(L_ADDL_VALS));

      DBG('Name: ' || L_ADDL_NAME || '  ' || 'Value: ' || L_ADDL_VAL);
      IF L_ADDL_NAME IS NOT NULL THEN
        L_REC_MSG_HEADER.ADDL(L_ADDL_NAME).VALUE := L_ADDL_VAL;
      END IF;

      L_ANAME_POS := NVL(INSTR(L_ADDL_NAMES, '~'), 0);
      L_AVAL_POS  := NVL(INSTR(L_ADDL_VALS, '~'), 0);

      DBG('Addl Names  : ' || L_ADDL_NAME);
      DBG('Addl Values : ' || L_ADDL_VAL);
    END LOOP;

    CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') := L_REC_MSG_HEADER.SOURCE;

    L_INSTR_REC.CORRELATION_PATTERN      := '';
    L_INSTR_REC.MSG_XCHANGE_PATTERN      := '';
    L_INSTR_REC.MSG_ID                   := '';
    L_INSTR_REC.CORREL_ID                := '';
    L_INSTR_REC.SOURCE_USER              := '';
    L_INSTR_REC.REQ_MSG_REF_NO           := '';
    L_INSTR_REC.RES_MSG_REF_NO           := '';
    L_INSTR_REC.BRN_APP_DATE             := '';
    L_INSTR_REC.FC_TRN_REF_NO            := '';
    L_INSTR_REC.GATEWAY_TYPE             := '';
    L_INSTR_REC.LOGGING_REQD             := '';
    L_INSTR_REC.MULTITRIP_REQD           := '';
    L_INSTR_REC.REPLY_REQD               := '';
    L_INSTR_REC.ROUTING_TYPE             := '';
    L_INSTR_REC.DISTRIBUTED_INSTALLATION := '';

    DBG('*********************************************************************');
    DBG('                   ' || L_REC_MSG_HEADER.FUNCTIONID || ' ' ||
        L_REC_MSG_HEADER.ACTION);
    DBG('*********************************************************************');

    L_PARENT_LIST_INDEX := 0;
    L_PARENT_FMT_INDEX  := 0;
    L_TAG_NAMES_INDEX   := 0;
    L_TAG_VALUES_INDEX  := 0;

    L_VA_PARENTS_LIST.DELETE;
    L_VA_PARENTS_FORMAT.DELETE;
    L_VA_TAG_NAMES.DELETE;
    L_VA_TAG_VALUES.DELETE;

    L_INDEX           := P_TAG_NAME_LIST.FIRST;
    L_TAG_NAMES_INDEX := 0;

    WHILE (L_INDEX IS NOT NULL) LOOP
      L_TAG_NAMES_INDEX := L_TAG_NAMES_INDEX + 1;
      L_VA_TAG_NAMES(L_TAG_NAMES_INDEX) := P_TAG_NAME_LIST(L_INDEX);
      G_TAG_NAME_LIST := G_TAG_NAME_LIST || P_TAG_NAME_LIST(L_INDEX) ||
                         L_FLD_SEP;
      L_INDEX := P_TAG_NAME_LIST.NEXT(L_INDEX);
    END LOOP;
    L_TAG_NAME := L_VA_TAG_NAMES(1);

    L_INDEX            := P_TAG_VALUES_LIST.FIRST;
    L_TAG_VALUES_INDEX := 0;
    WHILE (L_INDEX IS NOT NULL) LOOP
      L_TAG_VALUES_INDEX := L_TAG_VALUES_INDEX + 1;
      L_VA_TAG_VALUES(L_TAG_VALUES_INDEX) := P_TAG_VALUES_LIST(L_INDEX);
      G_TAG_VALUES_LIST := G_TAG_VALUES_LIST || P_TAG_VALUES_LIST(L_INDEX) ||
                           L_FLD_SEP;
      L_INDEX := P_TAG_VALUES_LIST.NEXT(L_INDEX);
    END LOOP;
    L_TAG_VALUES := L_VA_TAG_VALUES(1);

    L_INDEX             := P_PARENTS_NAME_LIST.FIRST;
    L_PARENT_LIST_INDEX := 0;
    WHILE (L_INDEX IS NOT NULL) LOOP
      L_PARENT_LIST_INDEX := L_PARENT_LIST_INDEX + 1;
      L_VA_PARENTS_LIST(L_PARENT_LIST_INDEX) := P_PARENTS_NAME_LIST(L_INDEX);
      G_PARENTS_NAME_LIST := G_PARENTS_NAME_LIST ||
                             P_PARENTS_NAME_LIST(L_INDEX) || L_FLD_SEP;

      DBG('The parent index is:' || P_PARENTS_NAME_LIST(L_INDEX));
      IF P_PARENTS_NAME_LIST(L_INDEX) IN
         ('Denomination-Fxse',
          'Denomination-Details-fx',
          'Denomination-Se',
          'Denomination-Details',
          'Denomination-Details-Fx') THEN
        L_DENOM_FLAG := TRUE;
        IF P_PARENTS_NAME_LIST(L_INDEX) = 'Denomination-Se' THEN
          L_DENOM_PARENTS_NAME_LIST := L_DENOM_PARENTS_NAME_LIST ||
                                       'BLK_DENOMINATION_SE' || '>';
        ELSIF P_PARENTS_NAME_LIST(L_INDEX) = 'Denomination-Fxse' THEN
          L_DENOM_PARENTS_NAME_LIST := L_DENOM_PARENTS_NAME_LIST ||
                                       'BLK_DENOMINATION_FXSE' || '>';
        ELSIF P_PARENTS_NAME_LIST(L_INDEX) IN
              ('Denomination-Details-Fx', 'Denomination-Details-fx') THEN
          L_DENOM_PARENTS_NAME_LIST := L_DENOM_PARENTS_NAME_LIST ||
                                       'BLK_DENOMINATION_DETAILS_FX' || '>';
        ELSE
          L_DENOM_PARENTS_NAME_LIST := L_DENOM_PARENTS_NAME_LIST ||
                                       'BLK_DENOMINATION_DETAILS' || '>';
        END IF;
        L_DENOM_PARENTS_FMT_LIST := L_DENOM_PARENTS_FMT_LIST ||
                                    P_PARENTS_FMT_LIST(L_INDEX) || '>';
        L_DENOM_TAG_NAME_LIST    := L_DENOM_TAG_NAME_LIST ||
                                    P_TAG_NAME_LIST(L_INDEX) || '>';
        L_DENOM_TAG_VALUES_LIST  := L_DENOM_TAG_VALUES_LIST ||
                                    P_TAG_VALUES_LIST(L_INDEX) || '>';
        DBG('Denom Parent:' || L_DENOM_PARENTS_NAME_LIST);
        DBG('Denom Format:' || L_DENOM_PARENTS_FMT_LIST);
        DBG('Denom TagNames:' || L_DENOM_TAG_NAME_LIST);
        DBG('Denom TagNames:' || L_DENOM_TAG_VALUES_LIST);
      END IF;
      L_INDEX := P_PARENTS_NAME_LIST.NEXT(L_INDEX);

    END LOOP;
    L_PARENTS_LIST := L_VA_PARENTS_LIST(1);

    L_INDEX            := P_PARENTS_FMT_LIST.FIRST;
    L_PARENT_FMT_INDEX := 0;
    WHILE (L_INDEX IS NOT NULL) LOOP
      L_PARENT_FMT_INDEX := L_PARENT_FMT_INDEX + 1;
      L_VA_PARENTS_FORMAT(L_PARENT_FMT_INDEX) := P_PARENTS_FMT_LIST(L_INDEX);
      G_PARENTS_FMT_LIST := G_PARENTS_FMT_LIST ||
                            P_PARENTS_FMT_LIST(L_INDEX) || L_FLD_SEP;
      L_INDEX := P_PARENTS_FMT_LIST.NEXT(L_INDEX);
    END LOOP;
    L_PARENTS_FORMAT := L_VA_PARENTS_FORMAT(1);

    DBG('TagNames:' || G_TAG_NAME_LIST);
    DBG('TagValues:' || G_TAG_VALUES_LIST);
    DBG('BlockNames:' || G_PARENTS_NAME_LIST);
    DBG('Format:' || G_PARENTS_FMT_LIST);

    G_FLAG                              := 'Y';
    DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC := NULL;
    BEGIN
      PR_SERVICE_HANDLER('N',
                         L_REC_MSG_HEADER,
                         L_IS_CLOB,
                         L_INSTR_REC,
                         L_ERR_NODE,
                         L_ERR_PARAM);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Exception :' || SQLERRM);
        DBG('Trace :' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        OVPKS.PR_APPENDTBL('ST-OTH-001', '');
    END;
    L_STATUS := GWPKS_RETAILTELLERSERVICE.G_STATUS;

    DBG('About to build Errors..');
    L_COUNT := OVPKS.GL_TBLERROR.COUNT;

    DBG('Error Count : ' || L_COUNT);

    IF L_DENOM_FLAG THEN
      DBG('Before Denom Add');
      DBG('TagNames:' || G_TAG_NAME_LIST);
      DBG('TagValues:' || G_TAG_VALUES_LIST);
      DBG('BlockNames:' || G_PARENTS_NAME_LIST);
      DBG('Format:' || G_PARENTS_FMT_LIST);

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('calling gwpks_retailtlrservice_cluster.pr_service_handler_Java....');
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_denom_parents_name_list') := L_DENOM_PARENTS_NAME_LIST;
        L_TB_CLUSTER_DATA('l_denom_parents_fmt_list') := L_DENOM_PARENTS_FMT_LIST;
        L_TB_CLUSTER_DATA('l_denom_tag_name_list') := L_DENOM_TAG_NAME_LIST;
        L_TB_CLUSTER_DATA('l_denom_tag_values_list') := L_DENOM_TAG_VALUES_LIST;
        GWPKS_RETAILTLRSERVICE_CLUSTER.PR_SERVICE_HANDLER_JAVA(P_USER,
                                                               P_BRANCH,
                                                               P_HEADER_NAMES,
                                                               P_HEADER_VALS,
                                                               P_ADDL_NAMES,
                                                               P_ADDL_VALS,
                                                               P_PARENTS_NAME_LIST,
                                                               P_PARENTS_FMT_LIST,
                                                               P_TAG_NAME_LIST,
                                                               P_TAG_VALUES_LIST,
                                                               P_ERROR_NODES,
                                                               P_STATUS,
                                                               P_TIMELOG,
                                                               P_DB_LOG,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA);
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_denom_parents_name_list') THEN
        L_DENOM_PARENTS_NAME_LIST := L_TB_CLUSTER_DATA('l_denom_parents_name_list');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_denom_parents_fmt_list') THEN
        L_DENOM_PARENTS_FMT_LIST := L_TB_CLUSTER_DATA('l_denom_parents_fmt_list');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_denom_tag_name_list') THEN
        L_DENOM_TAG_NAME_LIST := L_TB_CLUSTER_DATA('l_denom_tag_name_list');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_denom_tag_values_list') THEN
        L_DENOM_TAG_VALUES_LIST := L_TB_CLUSTER_DATA('l_denom_tag_values_list');
      END IF;

      G_PARENTS_NAME_LIST := G_PARENTS_NAME_LIST ||
                             L_DENOM_PARENTS_NAME_LIST;
      G_PARENTS_FMT_LIST  := G_PARENTS_FMT_LIST || L_DENOM_PARENTS_FMT_LIST;
      G_TAG_NAME_LIST     := G_TAG_NAME_LIST || L_DENOM_TAG_NAME_LIST;
      G_TAG_VALUES_LIST   := G_TAG_VALUES_LIST || L_DENOM_TAG_VALUES_LIST;
      DBG('After Denom Add');
      DBG('TagNames:' || G_TAG_NAME_LIST);
      DBG('TagValues:' || G_TAG_VALUES_LIST);
      DBG('BlockNames:' || G_PARENTS_NAME_LIST);
      DBG('Format:' || G_PARENTS_FMT_LIST);
    END IF;

    P_PARENTS_NAME_LIST.DELETE;
    P_TAG_NAME_LIST.DELETE;
    P_TAG_VALUES_LIST.DELETE;
    P_PARENTS_FMT_LIST.DELETE;

    IF NOT GWPKS_REPLY_UTILS.FN_ENRICH_PARENTTAG(L_REC_MSG_HEADER.SOURCE,
                                                 L_REC_MSG_HEADER.MODULEID,
                                                 G_PARENTS_NAME_LIST) THEN
      DBG('FAILED IN gwpks_reply_utils.fn_enrich_parenttag');
    END IF;

    L_CNT := 1;
    WHILE (CSPKES_MISC.FN_GETPARAM(G_PARENTS_NAME_LIST, L_CNT, '>') <>
          'EOPL' AND
          NVL(CSPKES_MISC.FN_GETPARAM(G_PARENTS_NAME_LIST, L_CNT, '>'),
               'NOVALUE') <> 'NOVALUE') LOOP
      P_PARENTS_NAME_LIST.EXTEND;
      P_PARENTS_NAME_LIST(L_CNT) := RTRIM(CSPKES_MISC.FN_GETPARAM(G_PARENTS_NAME_LIST,
                                                                  L_CNT,
                                                                  '>'),
                                          '>');
      L_CNT := L_CNT + 1;
    END LOOP;

    L_CNT := 1;
    WHILE (CSPKES_MISC.FN_GETPARAM(G_TAG_NAME_LIST, L_CNT, '>') <> 'EOPL' AND
          NVL(CSPKES_MISC.FN_GETPARAM(G_TAG_NAME_LIST, L_CNT, '>'),
               'NOVALUE') <> 'NOVALUE') LOOP
      P_TAG_NAME_LIST.EXTEND;
      P_TAG_NAME_LIST(L_CNT) := RTRIM(CSPKES_MISC.FN_GETPARAM(G_TAG_NAME_LIST,
                                                              L_CNT,
                                                              '>'),
                                      '>');
      L_CNT := L_CNT + 1;
    END LOOP;

    L_CNT := 1;
    WHILE (CSPKES_MISC.FN_GETPARAM(G_TAG_VALUES_LIST, L_CNT, '>') <> 'EOPL' AND
          NVL(CSPKES_MISC.FN_GETPARAM(G_TAG_VALUES_LIST, L_CNT, '>'),
               'NOVALUE') <> 'NOVALUE') LOOP
      P_TAG_VALUES_LIST.EXTEND;
      P_TAG_VALUES_LIST(L_CNT) := RTRIM(CSPKES_MISC.FN_GETPARAM(G_TAG_VALUES_LIST,
                                                                L_CNT,
                                                                '>'),
                                        '>');
      L_CNT := L_CNT + 1;
    END LOOP;

    L_CNT := 1;
    WHILE (CSPKES_MISC.FN_GETPARAM(G_PARENTS_FMT_LIST, L_CNT, '>') <>
          'EOPL' AND
          NVL(CSPKES_MISC.FN_GETPARAM(G_PARENTS_FMT_LIST, L_CNT, '>'),
               'NOVALUE') <> 'NOVALUE') LOOP
      P_PARENTS_FMT_LIST.EXTEND;
      P_PARENTS_FMT_LIST(L_CNT) := RTRIM(CSPKES_MISC.FN_GETPARAM(G_PARENTS_FMT_LIST,
                                                                 L_CNT,
                                                                 '>'),
                                         '>');
      L_CNT := L_CNT + 1;
    END LOOP;

    OVPKSS_ADDON.PR_INIT('ALL', L_REC_MSG_HEADER.FUNCTIONID);
    FOR I IN 1 .. L_COUNT LOOP
      OVPKSS.GL_TBLERROR(I).ERR_CODE := OVPKSS_ADDON.FN_RET_OVD_CODE(OVPKSS.GL_TBLERROR(I)
                                                                     .ERR_CODE);
      L_ERR_CODE := OVPKS.GL_TBLERROR(I).ERR_CODE;
      L_ERR_PARAM := OVPKS.GL_TBLERROR(I).PARAMS;
      L_ERR_PARAM := RTRIM(L_ERR_PARAM, '~');

      IF L_ERR_CODE IS NOT NULL THEN
        L_ERR_TYPE := CSPKS_REQ_UTILS.FN_GEN_ERROR_MESSAGE(L_ERR_CODE,
                                                           L_ERR_PARAM,
                                                           L_ERR_MESSAGE);
      END IF;
      DBG('l_err_type>>' || L_ERR_TYPE);
      IF (L_STATUS IN ('O', 'M') AND L_ERR_TYPE NOT IN ('E')) THEN
        P_ERROR_NODES := P_ERROR_NODES || L_ERR_CODE || '!' ||
                         L_ERR_MESSAGE || '~';
      ELSIF (L_STATUS IN ('E', 'F') AND L_ERR_TYPE IN ('E', 'O')) THEN
        P_ERROR_NODES := P_ERROR_NODES || L_ERR_CODE || '!' ||
                         L_ERR_MESSAGE || '~';
      ELSIF (L_STATUS IN ('S', 'P') AND L_ERR_TYPE IN ('I')) THEN
        P_ERROR_NODES := P_ERROR_NODES || L_ERR_CODE || '!' ||
                         L_ERR_MESSAGE || '~';
      END IF;
    END LOOP;

    DBG('Error Node : ' || P_ERROR_NODES);
    DBG('Status : ' || L_STATUS);

    IF L_STATUS IN ('O', 'M') THEN
      DBG('Oevrride Scenario..');
      RAISE E_OVERRIDE_EXCEPTION;
    ELSIF L_STATUS IN ('E', 'F') THEN
      DBG('Failure Scenario..');
      RAISE E_FAILURE_EXCEPTION;
    END IF;

    P_STATUS := L_STATUS;
    DBG('Returning Succesfully..');
    PR_CAL_PROCESSTIME(L_START_TIME, L_END_TIME, L_DBSESSIONID);
    P_TIMELOG := L_END_TIME || '~' || L_DBSESSIONID;

    CSPKS_REQ_GLOBAL.G_FCDATA_REQ := 'N';

    P_DB_LOG := REAL_DEBUG.FN_GET_DEBUG_STR;

    DEBUG.PR_CLOSE;

  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('In Failure Exception Of Fn_Process_Requests..');
      BEGIN
        ROLLBACK TO SP_PROCESS_REQUEST;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      PR_CAL_PROCESSTIME(L_START_TIME, L_END_TIME, L_DBSESSIONID);
      P_TIMELOG := L_END_TIME || '~' || L_DBSESSIONID;

      CSPKS_REQ_GLOBAL.G_FCDATA_REQ := 'N';
      P_STATUS                      := 'F';

      P_DB_LOG := REAL_DEBUG.FN_GET_DEBUG_STR;

      DEBUG.PR_CLOSE;

    WHEN E_OVERRIDE_EXCEPTION THEN
      DBG('In Override Exception Of Fn_Process_Requests..');
      BEGIN
        ROLLBACK TO SP_PROCESS_REQUEST;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      IF NOT CSPKS_REQ_UTILS.FN_LOG_OVERRIDES(L_REC_MSG_HEADER.MULTITRIPID,
                                              1,
                                              L_ERR_CODE,
                                              L_ERR_PARAM) THEN
        DBG('Failed in Cspks_Service.Fn_Process_Msg..');
      END IF;

      PR_CAL_PROCESSTIME(L_START_TIME, L_END_TIME, L_DBSESSIONID);
      P_TIMELOG := L_END_TIME || '~' || L_DBSESSIONID;

      CSPKS_REQ_GLOBAL.G_FCDATA_REQ := 'N';
      P_STATUS                      := 'O';

      P_DB_LOG := REAL_DEBUG.FN_GET_DEBUG_STR;
      DEBUG.PR_CLOSE;

    WHEN OTHERS THEN
      DBG('In When Others of Cspks_Req_Global_Wrapper :' || SQLERRM);
      DBG('Trace : ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_CAL_PROCESSTIME(L_START_TIME, L_END_TIME, L_DBSESSIONID);
      P_TIMELOG := L_END_TIME || '~' || L_DBSESSIONID;

      CSPKS_REQ_GLOBAL.G_FCDATA_REQ := 'N';

      P_DB_LOG := REAL_DEBUG.FN_GET_DEBUG_STR;
      DEBUG.PR_CLOSE;

  END PR_SERVICE_HANDLER_JAVA;

END GWPKS_RETAILTELLERSERVICE;
