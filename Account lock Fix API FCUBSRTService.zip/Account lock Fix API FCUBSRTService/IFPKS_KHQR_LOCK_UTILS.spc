CREATE OR REPLACE PACKAGE IFPKS_KHQR_LOCK_UTILS AS

  PROCEDURE PR_PROCESS_KHQR_LOCK_PAYMENTS /*(P_PARAM_NAMES VARCHAR2,
                                                                                         P_PARAM_VALS  VARCHAR2)*/
  ;

  PROCEDURE PR_PROCESS_KHQR_LOCK_PYMNTS(PARAMNAME  VARCHAR2,
                                        PARAMVALUE VARCHAR2);

END IFPKS_KHQR_LOCK_UTILS;
