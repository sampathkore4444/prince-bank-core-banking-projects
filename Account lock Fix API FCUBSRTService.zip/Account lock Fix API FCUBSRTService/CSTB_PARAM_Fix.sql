prompt Importing table CSTB_PARAM...
set feedback off
set define off
insert into CSTB_PARAM (PARAM_NAME, PARAM_VAL)
values ('MAX_RETRY_ON_ACCOUNT_UPDATE', '50');

insert into CSTB_PARAM (PARAM_NAME, PARAM_VAL)
values ('SLEEP_TIME_ON_ACCOUNT_UPDATE', '.5');

prompt Done.
