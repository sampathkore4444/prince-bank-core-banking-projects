CREATE OR REPLACE PACKAGE BODY IFPKS_RIAB_LOCK_UTILS AS

  PROCEDURE PR_UPDATE_ERROR_DTLS(P_FC_XREF_NO IN VARCHAR2,
                                 P_STATUS     IN CHAR,
                                 P_ERR_CODE   IN VARCHAR2,
                                 P_ERR_MSG    IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    UPDATE IFTB_RIAB_TXNS_LOCK_MASTER A
       SET A.STATUS        = P_STATUS,
           A.ERROR_CODE    = P_ERR_CODE,
           A.ERROR_MESSAGE = P_ERR_MSG
     WHERE A.FC_XREF_NO = P_FC_XREF_NO;
  
    COMMIT;
  
  END PR_UPDATE_ERROR_DTLS;

  PROCEDURE PR_PROCESS_RIAB_LOCK_PAYMENTS /*(P_PARAM_NAMES VARCHAR2,
                                                                                       P_PARAM_VALS  VARCHAR2)*/
   AS
  
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    pkg_detb_rtl_teller_rec detbs_rtl_teller%ROWTYPE;
    L_SERIAL_NO             VARCHAR2(16);
    L_TRN_REF_NO            Actb_Daily_Log.TRN_REF_NO%TYPE;
  
    P_ERR_CODE   VARCHAR2(255);
    P_ERR_PARAMS VARCHAR2(255);
  
    L_ARC_MAINT IFTM_ARC_MAINT%ROWTYPE;
  
    L_CCY_CODE  CYTM_CCY_DEFN_MASTER.CCY_CODE%TYPE;
    L_EXCH_RATE ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG NUMBER;
  
    L_TXN_AMT IFTB_AIA_MASTER.TXN_AMOUNT%TYPE;
  
    l_prod     CSTM_PRODUCT%ROWTYPE;
    l_chg1_amt iftm_arc_maint.cod_chg_amt%type;
  
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'N';
    L_RETRY_COUNT  NUMBER := 0;
  
    l_rate              NUMBER;
    l_charge_amt        NUMBER := 0;
    L_CSTB_PARAM_CUSTOM CSTB_PARAM_CUSTOM%ROWTYPE;
  
    CURSOR C1 IS
      SELECT * FROM IFTB_RIAB_TXNS_LOCK_MASTER WHERE STATUS = 'U';
  
    PROCEDURE DBG(P_MSG VARCHAR2) IS
      L_MSG VARCHAR2(32767);
    BEGIN
      IF DEBUG.PKG_DEBUG_ON <> 2 THEN
        L_MSG := 'IFPKS_RIAB_LOCK_UTILS ==>' || P_MSG;
        DEBUG.PR_DEBUG('IF', L_MSG);
      END IF;
    END DBG;
  
  BEGIN
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        --GLOBAL.pr_init('001', 'SYSTEM');
      
        SAVEPOINT A;
      
        --Get Account details
        IF G.TXN_CCY = 'USD' THEN
          BEGIN
            SELECT *
              INTO L_CSTB_PARAM_CUSTOM
              FROM CSTB_PARAM_CUSTOM
             WHERE PARAM_NAME = 'PGW_RIA_OUT_USD_ACCOUNT';
          EXCEPTION
            WHEN OTHERS THEN
              L_CSTB_PARAM_CUSTOM := NULL;
          END;
        ELSE
          BEGIN
            SELECT *
              INTO L_CSTB_PARAM_CUSTOM
              FROM CSTB_PARAM_CUSTOM
             WHERE PARAM_NAME = 'PGW_RIA_OUT_USD_ACCOUNT';
          EXCEPTION
            WHEN OTHERS THEN
              L_CSTB_PARAM_CUSTOM := NULL;
          END;
        
        END IF;
      
        GLOBAL.PR_INIT('991', 'SYSTEM');
      
        pkg_detb_rtl_teller_rec.product_code := 'RIAB'; --product code
      
        --Get Product Details
        BEGIN
          SELECT *
            INTO L_PROD
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = pkg_detb_rtl_teller_rec.product_code
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            L_PROD := null;
        END;
      
        --GET REFERENCE NO
        IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                           PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TRN_REF_NO,
                                           P_ERR_CODE) THEN
          DBG('FAILED IN GENERATION TRANSACTION REF NO');
          ROLLBACK TO A;
          CONTINUE;
        ELSE
          DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
        END IF;
      
        L_TRN_REF_NO := G.FC_XREF_NO; --pls check
      
        --GET BEN CUSTOMER DETAILS
        BEGIN
          SELECT X.*
            INTO L_CUST
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO IN
                 (SELECT CUST_NO
                    FROM STTM_CUST_ACCOUNT
                   WHERE CUST_AC_NO = L_CSTB_PARAM_CUSTOM.PARAM_VAL);
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('IF', 'FAILED IN GETTING CUSTOMER DETAILS');
        END;
      
        PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;
      
        --Get Arc Maintenance
        SELECT *
          INTO L_ARC_MAINT
          FROM IFTM_ARC_MAINT A
         WHERE A.COD_PROD_ACC_CLS = pkg_detb_rtl_teller_rec.product_code
           AND ROWNUM = 1;
      
        PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := '991';
        PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO; --pls check
      
        PKG_DETB_RTL_TELLER_REC.TXN_ACC    := G.TXN_ACCOUNT;
        PKG_DETB_RTL_TELLER_REC.TXN_CCY    := G.TXN_CCY; -- GLOBAL.LCY;
        PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := '991'; --GLOBAL.CURRENT_BRANCH;
        --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;
      
        --XRATE CALCULATION STARTS
      
        /*IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
        
          IF NOT CYPKSS.FN_GETRATE(PKG_DETB_RTL_TELLER_REC.BRANCH_CODE,
                                   L_CUST_ACCOUNT.CCY,
                                   'USD', --L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                   'STANDARD', --L_PROD.RATE_TYPE_PREFERRED,
                                   'M', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                   GLOBAL.APPLICATION_DATE,
                                   GLOBAL.APPLICATION_DATE,
                                   L_EXCH_RATE,
                                   L_RATE_FLAG,
                                   P_ERR_CODE) THEN
            DBG('FAILED IN FN_GETRATE');
            ROLLBACK TO A;
            CONTINUE;
          END IF;
        ELSE
          L_EXCH_RATE := 1;
        END IF;*/
      
        L_EXCH_RATE := 1;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        /* IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
          --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
          IF NOT CYPKSS.FN_AMT1_TO_AMT2(L_CUST_ACCOUNT.CCY,
                                        'USD',
                                        G.OFS_AMOUNT,
                                        L_EXCH_RATE,
                                        'Y',
                                        L_TXN_AMT,
                                        P_ERR_PARAMS) THEN
            DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
            ROLLBACK TO A;
            CONTINUE;
          END IF;
        
          PKG_DETB_RTL_TELLER_REC.LCY_AMOUNT := L_TXN_AMT;
        
        ELSE
          L_TXN_AMT := G.OFS_AMOUNT; -- l_payment_amount;
        
        END IF;*/
      
        L_TXN_AMT := G.TXN_AMOUNT;
      
        DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);
      
        PKG_DETB_RTL_TELLER_REC.OFS_ACC    := '000072693'; --;G.CUST_AC_NO;
        PKG_DETB_RTL_TELLER_REC.OFS_CCY    := G.OFS_CCY;
        PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := G.TXN_AMOUNT; -- L_TXN_AMT;
      
        PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := '993'; --GLOBAL.current_branch;
      
        PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := G.TXN_AMOUNT;
      
        PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
        PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
        PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
        PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
        PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
        PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
        PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
        PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
        PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
        PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
        PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
        PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
        PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
        PKG_DETB_RTL_TELLER_REC.ESN              := 1;
        PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
        PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
        PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;
        PKG_DETB_RTL_TELLER_REC.XREF             := G.FC_XREF_NO; --pls check
      
        --Charge Details
      
        SELECT cust_no, ccy
          INTO l_rel_customer, l_ac_ccy
          FROM sttm_cust_account
         WHERE cust_ac_no = G.TXN_ACCOUNT; -- G.CUST_AC_NO;
      
        dbg('got l_rel_customer' || l_rel_customer);
      
        /*IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.current_branch,
                                           'KHQR',
                                           'P',
                                           'AI01',
                                           '*.*',
                                           l_rel_customer,
                                           '*.*',
                                           l_payment_amount,
                                           l_prod.rate_type_preferred,
                                           l_prod.rate_code_preferred,
                                           NULL,
                                           l_rel_customer,
                                           l_ib_flag,
                                           depks_rtl_teller.pkg_arc_row,
                                           p_err_code,
                                           p_err_params,
                                           G.TXN_ACCOUNT, --G.CUST_AC_NO,
                                           GLOBAL.current_branch) THEN
          dbg('CHARGE PICKUP failed');
          ROLLBACK TO A;
          CONTINUE;
        END IF;
        
        DBG('PKG_ARC_ROW.COD_CHG_TYPE=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE);
        DBG('PKG_ARC_ROW.COD_CHG_GL=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_GL);
        DBG('PKG_ARC_ROW.COD_CHG_CCY=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_CCY);
        DBG('PKG_ARC_ROW.COD_CHG_TXN_CODE=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TXN_CODE);
        DBG('PKG_ARC_ROW.COD_CHG_AMT=' ||
            DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT);
        
        DBG('l_arc_maint.COD_CHG_TYPE=' || l_arc_maint.COD_CHG_TYPE);
        DBG('l_arc_maint.COD_CHG_GL=' || l_arc_maint.COD_CHG_GL);
        DBG('l_arc_maint.COD_CHG_CCY=' || l_arc_maint.COD_CHG_CCY);
        DBG('l_arc_maint.COD_CHG_TXN_CODE=' ||
            l_arc_maint.COD_CHG_TXN_CODE);
        DBG('l_arc_maint.COD_CHG_AMT=' || l_arc_maint.COD_CHG_AMT);
        
        pkg_detb_rtl_teller_rec.charge_account := G.TXN_ACCOUNT; -- G.CUST_AC_NO;
        
        dbg('l_arc_maint.cod_chg_gl=' || l_arc_maint.cod_chg_gl);
        dbg('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
        dbg('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
        
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := l_arc_maint.cod_chg_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := l_arc_maint.cod_chg_amt;
        
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT=' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
        
        dbg('L_CUST_ACCOUNT.CCY=' || L_CUST_ACCOUNT.CCY);
        
        IF l_arc_maint.cod_chg_ccy <> L_CUST_ACCOUNT.CCY THEN
          IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                        l_arc_maint.cod_chg_ccy,
                                        L_CUST_ACCOUNT.CCY,
                                        l_prod.rate_type_preferred,
                                        l_prod.rate_code_preferred,
                                        l_arc_maint.cod_chg_amt,
                                        'Y',
                                        l_charge_amt,
                                        l_rate,
                                        p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            ROLLBACK TO A;
            CONTINUE;
            --RETURN FALSE;
          END IF;
        
          pkg_detb_rtl_teller_rec.chg_in_acy       := l_charge_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := l_rate;
        
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := l_charge_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;
        
        DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
            pkg_detb_rtl_teller_rec.chg_in_acy);
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
            pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
        
        DBG('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
        DBG('l_arc_maint.cod_chg_rate=' || l_arc_maint.cod_chg_rate);
        DBG('l_arc_maint.cod_chg_netting=' || l_arc_maint.cod_chg_netting);
        DBG('l_arc_maint.cod_chg_txn_code=' ||
            l_arc_maint.cod_chg_txn_code);
        DBG('l_arc_maint.cod_mis_head=' || l_arc_maint.cod_mis_head);
        DBG('l_arc_maint.cod_chg_desc=' || l_arc_maint.cod_chg_desc);
        DBG('l_arc_maint.cod_chg_type=' || l_arc_maint.cod_chg_type);
        DBG('PKG_ARC_ROW.CHARGE_CODE=' || l_arc_maint.CHARGE_CODE);
        
        pkg_detb_rtl_teller_rec.chg_in_lcy   := l_arc_maint.cod_chg_amt;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := l_arc_maint.cod_chg_rate; --p_ifdrftpm.v_iftbs_rft_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := 'N';
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
        
        DBG('pkg_detb_rtl_teller_rec.chg_type=' ||
            pkg_detb_rtl_teller_rec.chg_type);*/
      
        DBG('Calling depks_rtl_teller.fn_save');
      
        IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                        P_ERR_CODE,
                                        P_ERR_PARAMS) THEN
          dbg('FAILED IN FN_SAVE');
        
          ROLLBACK TO A;
        
          DBG('P_ERR_CODE=' || P_ERR_CODE);
          DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
        
          /* update IFTB_RIAB_TXNS_LOCK_MASTER A
            set A.ERROR_CODE = P_ERR_CODE, A.ERROR_MESSAGE = P_ERR_PARAMS
          where A.DIG_REF_NO = G.DIG_REF_NO;*/
        
          PR_UPDATE_ERROR_DTLS(G.FC_XREF_NO, 'E', P_ERR_CODE, P_ERR_PARAMS);
        
          CONTINUE;
        
        ELSE
        
          DBG('SUCCESS IN FN_SAVE');
        
          DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
          IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(PKG_DETB_RTL_TELLER_REC.BRANCH_CODE,
                                                      L_TRN_REF_NO,
                                                      GLOBAL.USER_ID,
                                                      GLOBAL.LCY,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
            DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
            DBG('FAILED TO PROCESS TRANSACTION');
            DBG('ROLLINGBACK TO SAVEPOINT A');
          
            ROLLBACK TO A;
          
            PR_UPDATE_ERROR_DTLS(G.FC_XREF_NO,
                                 'E',
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
          
            CONTINUE;
          
          ELSE
          
            DBG('SUCCESS IN FN_AUTH');
          
            UPDATE IFTB_RIAB_TXNS_LOCK_MASTER A
               SET A.FC_XREF_NO = L_TRN_REF_NO, A.STATUS = 'P'
             WHERE A.FC_XREF_NO = G.FC_XREF_NO;
          
            COMMIT;
          
          END IF;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
          ROLLBACK TO A;
          CONTINUE;
      END;
    
    END LOOP;
  
  END PR_PROCESS_RIAB_LOCK_PAYMENTS;

  PROCEDURE PR_PROCESS_RIAB_LOCK_PYMNTS(PARAMNAME  VARCHAR2,
                                        PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_KHQR_INWARD_PYMNTS');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_PROCESS_RIAB_LOCK_PAYMENTS;
  
    DEBUG.PR_DEBUG('IF',
                   'Successful return from PR_PROCESS_KHQR_INWARD_PYMNTS');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_KHQR_INWARD_PYMNTS' ||
                     SQLERRM);
  END PR_PROCESS_RIAB_LOCK_PYMNTS;

END IFPKS_RIAB_LOCK_UTILS;
