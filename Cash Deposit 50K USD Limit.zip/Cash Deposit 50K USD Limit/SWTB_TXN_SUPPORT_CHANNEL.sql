prompt Importing table SWTB_TXN_SUPPORT_CHANNEL...
set feedback off
set define off
insert into SWTB_TXN_SUPPORT_CHANNEL (FC_LITERAL, DESCRIPTION, ATM_SUPPORT, POS_SUPPORT, IVR_SUPPORT, CHANNEL)
values ('CDP', null, null, null, null, 'DMC');

prompt Done.
