insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('CDP', 'O', 'DPOD', 'O', 'A', 1, 'SAMPATH2', to_date('03-04-2021 15:26:22', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('03-04-2021 15:26:23', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'PRINCE', 'ALL', 'DMC');

COMMIT;
