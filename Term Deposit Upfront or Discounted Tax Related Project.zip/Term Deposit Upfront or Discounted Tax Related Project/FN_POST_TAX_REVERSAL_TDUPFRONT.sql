CREATE OR REPLACE FUNCTION FN_POST_TAX_REVERSAL_TDUPFRONT(P_TD_ACC   IN VARCHAR2,
                                                          P_TD_ACBRN IN VARCHAR2,
                                                          P_TDCCY    IN VARCHAR2 /*,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                P_CASA_ACC IN VARCHAR2,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                P_CASA_CCY IN VARCHAR2*/)
  RETURN BOOLEAN AS

  -- Enter the details.
  -- Accouting entries are posted as Authorised entries.
  -- Input both FINANCIAL CYCLE and PERIOD_CODE for back period entries
  -- System will consider current fin_cycle & current period if fields are null

  l_init_acc_hoff   actbs_handoff%ROWTYPE;
  l_acc_hoff        acpkss.tbl_achoff;
  l_hoff_count      INTEGER := 0;
  L_error_code      VARCHAR2(200);
  L_error_parameter VARCHAR2(200);

  l_contract_ref_no     cstbs_contract.contract_ref_no%TYPE; -- := '100RAVITEST12458';
  l_event_sr_no         cstbs_contract_event_log.event_seq_no%TYPE := '1';
  l_ac_no               sttm_cust_account.cust_ac_no%TYPE; -- := '000032234';
  l_ac_ccy              sttm_cust_account.ccy%TYPE; -- := 'USD';
  l_fcy_amount          actbs_daily_log.fcy_amount%TYPE; -- := 10000000;
  l_counterparty        sttm_cust_account.cust_no%TYPE := '';
  l_mishead             actbs_daily_log.mis_head%TYPE := '';
  l_amount_tag          actbs_daily_log.amount_tag%TYPE := 'TAX_ADJ';
  l_event               actbs_daily_log.event%TYPE := 'DEBK';
  l_drcrind             VARCHAR2(1) := 'D';
  l_trn_code            sttms_trn_code.trn_code%TYPE := 'TAJ';
  l_cavw_entries        cavw_entries%rowtype;
  l_acvw_all_ac_entries acvw_all_ac_entries%rowtype;

  L_EXCH_RATE ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  L_RATE_FLAG NUMBER;
  l_serial_no  VARCHAR2(16);
  
  L_ICTM_TDPAYIN_DETAILS ICTM_TDPAYIN_DETAILS%ROWTYPE;

BEGIN

   global.pr_init(P_TD_ACBRN, GLOBAL.user_id);
   
   --get payin account
  BEGIN
  
    SELECT *
      INTO L_ICTM_TDPAYIN_DETAILS
      FROM ICTM_TDPAYIN_DETAILS A
     WHERE A.ACC = P_TD_ACC
       AND A.BRN = P_TD_ACBRN
       AND A.CCY = P_TDCCY;
  
  EXCEPTION
    WHEN OTHERS THEN
      L_ICTM_TDPAYIN_DETAILS := NULL;
  END;

  debug.pr_debug('AC',
                 'PAY IN ACCOUNT NO=' ||
                 L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC);

  debug.pr_debug('AC',
                 'PAY IN ACCOUNT BRANCH=' ||
                 L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN);

  --global.pr_init(P_TD_ACBRN, 'SYSTEM');

  --derive lcy and fcy amounts from td
  SELECT *
    into l_cavw_entries --nvl(sum(nvl(fcy_amount, lcy_amount)), 0)
  --into L_TOTAL_TAX_AMOUNT
    FROM cavw_entries a
   WHERE a.ac_branch = L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN--P_TD_ACBRN --'012'
        --( /*ac_no='000060115' or */
     and related_account = P_TD_ACC --'000060871' --'000060119')
     --and event = 'DEBK'
     and trn_code = 'TDX'
     and a.drcr_ind = 'D'
     and ac_entry_sr_no in (select max(ac_entry_sr_no)
                              from cavw_entries a
                             WHERE a.ac_branch = L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN--P_TD_ACBRN --'012'
                                  --( /*ac_no='000060115' or */
                               and related_account = P_TD_ACC --'000060871' --'000060119')
                               --and event = 'DEBK'
                               and trn_code = 'TDX'
                               and a.drcr_ind = 'D');

  debug.pr_debug('AC',
                 'ORIGINAL DEBIT LCY AMOUNT=' || l_cavw_entries.lcy_amount);
  debug.pr_debug('AC',
                 'ORIGINAL DEBIT FCY AMOUNT=' || l_cavw_entries.fcy_amount);

  --credit
  SELECT *
    into l_acvw_all_ac_entries --nvl(sum(nvl(fcy_amount, lcy_amount)), 0)
    FROM acvw_all_ac_entries a
   WHERE -- trn_ref_no =
  --and ac_entry_sr_no =
   a.ac_branch = P_TD_ACBRN --'012'
  --( /*ac_no='000060115' or */
   and related_account = P_TD_ACC --'000060871' --'000060119')
   --and event = 'DEBK'
   and trn_code = 'TDX'
   and a.drcr_ind = 'C'
   and ac_entry_sr_no in (select max(ac_entry_sr_no)
                        from acvw_all_ac_entries a
                       WHERE -- trn_ref_no =
                      --and ac_entry_sr_no =
                       a.ac_branch = P_TD_ACBRN --'012'
                      --( /*ac_no='000060115' or */
                   and related_account = P_TD_ACC --'000060871' --'000060119')
                   --and event = 'DEBK'
                   and trn_code = 'TDX'
                   and a.drcr_ind = 'C');

  debug.pr_debug('AC',
                 'ORIGINAL CREDIT LCY AMOUNT=' ||
                 l_acvw_all_ac_entries.lcy_amount);
  debug.pr_debug('AC',
                 'ORIGINAL CREDIT FCY AMOUNT=' ||
                 l_acvw_all_ac_entries.fcy_amount);

  IF NOT trpkss.fn_get_product_refno(P_TD_ACBRN,
                                     'TDRE',
                                     global.application_date,
                                     l_serial_no,
                                     l_contract_ref_no,
                                     L_error_code) THEN
    debug.pr_debug('AC','Failed in generation Transaction Ref No');
    RETURN FALSE;
  ELSE
    debug.pr_debug('AC','l_contract_ref_no=' || l_contract_ref_no);

  END IF;

  l_init_acc_hoff := NULL;
  l_acc_hoff(l_hoff_count) := l_init_acc_hoff;
  l_acc_hoff(l_hoff_count).module := 'IC';
  l_acc_hoff(l_hoff_count).trn_ref_no := l_contract_ref_no;--l_cavw_entries.trn_ref_no; --l_contract_ref_no;
  l_acc_hoff(l_hoff_count).event_sr_no := l_event_sr_no;
  l_acc_hoff(l_hoff_count).event := l_event;
  l_acc_hoff(l_hoff_count).ac_branch := L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN;--P_TD_ACBRN;
  l_acc_hoff(l_hoff_count).ac_no := l_cavw_entries.ac_no; --l_ac_no;
  l_acc_hoff(l_hoff_count).ac_ccy := l_cavw_entries.ac_ccy; --l_ac_ccy;
  l_acc_hoff(l_hoff_count).drcr_ind := l_drcrind; --debit
  l_acc_hoff(l_hoff_count).trn_code := l_trn_code;
  l_acc_hoff(l_hoff_count).amount_tag := l_amount_tag;

  --l_acc_hoff(l_hoff_count).lcy_amount := -l_cavw_entries.lcy_amount; --40200000000;

  /* IF l_acvw_all_ac_entries.AC_CCY = l_cavw_entries.ac_ccy AND l_Craccccy <> global.Lcy THEN

    p_Acc_Hoff(l_Acc_Hoff_Cnt).Fcy_Amount := l_Amount(1);

  ELSIF l_Craccccy = l_Draccccy AND l_Craccccy = global.Lcy THEN

    p_Acc_Hoff(l_Acc_Hoff_Cnt).Fcy_Amount := NULL;

    --02082017 Modifications ends

  ELSE

    Dbg('before calling cypkss.fn_amt1_to_amt2(1)');
    Dbg(' P_ccy fcy = ' || P_ccy);
    Dbg(' l_Acc_Hoff_Cnt.ac_ccy fcy = ' || p_Acc_Hoff(l_Acc_Hoff_Cnt)
        .Ac_Ccy);
    Dbg('Exch_Rate earlier = ' || p_Acc_Hoff(l_Acc_Hoff_Cnt).Exch_Rate);
    IF NOT Cypkss.Fn_Amt1_To_Amt2(p_Brn,
                                  P_ccy, ----25052017 modifications
                                  p_Acc_Hoff  (l_Acc_Hoff_Cnt).Ac_Ccy,
                                  'STANDARD',
                                  'M',
                                  p_amount,
                                  'Y',
                                  p_Acc_Hoff  (l_Acc_Hoff_Cnt).Fcy_Amount,
                                  p_Acc_Hoff  (l_Acc_Hoff_Cnt).Exch_Rate,
                                  p_Error_Code) THEN
      Dbg('Error while computing LCY ' || p_Error_Code);
      p_Error_Code := SQLCODE;
      RETURN FALSE;
    END IF;
  END IF;*/

  IF (l_acvw_all_ac_entries.AC_CCY = 'KHR' AND
     l_cavw_entries.ac_ccy = 'KHR') OR
     (l_acvw_all_ac_entries.AC_CCY <> l_cavw_entries.ac_ccy) THEN

    IF l_cavw_entries.fcy_amount IS NOT NULL OR
       L_ACVW_ALL_AC_ENTRIES.FCY_AMOUNT IS NOT NULL THEN

      l_acc_hoff(l_hoff_count).fcy_amount := NVL(-l_cavw_entries.fcy_amount,
                                                 -L_ACVW_ALL_AC_ENTRIES.FCY_AMOUNT); --l_fcy_amount;

      --for other leg
      l_acc_hoff(l_hoff_count + 1).fcy_amount := NVL(-l_cavw_entries.fcy_amount,
                                                     -L_ACVW_ALL_AC_ENTRIES.FCY_AMOUNT); --l_fcy_amount;

      --derive lcy amount using above fcy amount

      --derive rate
      IF --(l_acvw_all_ac_entries.AC_CCY <> 'KHR' AND
      --l_cavw_entries.ac_ccy <> 'KHR') OR
       (l_acvw_all_ac_entries.AC_CCY <> l_cavw_entries.ac_ccy) THEN

        IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                CASE
                                  WHEN l_acvw_all_ac_entries.AC_CCY = 'USD' THEN
                                   l_acvw_all_ac_entries.AC_CCY --TD CURRENCY
                                  WHEN l_cavw_entries.ac_ccy = 'USD' THEN
                                   l_cavw_entries.ac_ccy
                                END,

                                CASE
                                  WHEN l_acvw_all_ac_entries.AC_CCY = 'KHR' THEN
                                   l_acvw_all_ac_entries.AC_CCY --CASA CURRENCY
                                  WHEN l_cavw_entries.ac_ccy = 'KHR' THEN
                                   l_cavw_entries.ac_ccy
                                END,

                                'COMM',

                                /*CASE l_acvw_all_ac_entries.AC_CCY
                                                                                                                                                                                                                                                                                                                                                                                               WHEN 'USD' THEN
                                                                                                                                                                                                                                                                                                                                                                                                'S'
                                                                                                                                                                                                                                                                                                                                                                                               WHEN 'KHR' THEN
                                                                                                                                                                                                                                                                                                                                                                                                'B'
                                                                                                                                                                                                                                                                                                                                                                                             END,*/
                                CASE
                                  WHEN l_acvw_all_ac_entries.AC_CCY = 'USD' AND
                                       l_cavw_entries.AC_CCY = 'KHR' THEN
                                   'S'
                                  WHEN l_acvw_all_ac_entries.AC_CCY = 'KHR' AND
                                       l_cavw_entries.AC_CCY = 'USD' THEN
                                   'B'
                                END,
                                L_EXCH_RATE,
                                L_RATE_FLAG,
                                L_ERROR_CODE) THEN

          RETURN FALSE;

        ELSE

          DEBUG.PR_DEBUG('AC', 'DERIVED EXCHANGE RATE=' || L_EXCH_RATE);

          --IF l_acvw_all_ac_entries.AC_CCY = 'KHR' AND l_cavw_entries.ac_ccy = 'USD' THEN
          --derive lcy amount
          IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                        CASE
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'KHR' THEN
                                           l_acvw_all_ac_entries.AC_CCY
                                          WHEN l_cavw_entries.ac_ccy = 'USD' THEN
                                           l_cavw_entries.ac_ccy
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'USD' THEN
                                           l_cavw_entries.ac_ccy
                                          WHEN l_cavw_entries.ac_ccy = 'KHR' THEN
                                           l_cavw_entries.ac_ccy
                                        END,

                                        CASE
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'KHR' THEN
                                           l_cavw_entries.ac_ccy
                                          WHEN l_cavw_entries.ac_ccy = 'USD' THEN
                                           l_acvw_all_ac_entries.AC_CCY
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'USD' THEN
                                           l_acvw_all_ac_entries.ac_ccy
                                          WHEN l_cavw_entries.ac_ccy = 'KHR' THEN
                                           l_acvw_all_ac_entries.AC_CCY
                                        END,

                                        'COMM',

                                        CASE
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'USD' AND
                                               l_cavw_entries.AC_CCY = 'KHR' THEN
                                           'S'
                                          WHEN l_acvw_all_ac_entries.AC_CCY = 'KHR' AND
                                               l_cavw_entries.AC_CCY = 'USD' THEN
                                           'B'
                                        END,
                                        l_acc_hoff(l_hoff_count).Fcy_Amount,
                                        'Y',
                                        l_acc_hoff(l_hoff_count).Lcy_Amount,
                                        L_EXCH_RATE, --l_acc_hoff(l_hoff_count).Exch_Rate,
                                        L_ERROR_CODE) THEN
            DEBUG.pr_debug('AC',
                           'Error while computing LCY ' || L_ERROR_CODE);
            L_ERROR_CODE := SQLCODE;
            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT=' || l_acc_hoff(l_hoff_count)
                           .Lcy_Amount);

            l_acc_hoff(l_hoff_count).Lcy_Amount := l_acc_hoff(l_hoff_count) --MINUS NOT REQUIRED AS FCY IS MINUS SO LCY AUTO MINUS
                                                   .Lcy_Amount;

            --ROUND LCY AMOUNT
            IF NOT
                cypks.fn_amt_round(GLOBAL.lcy,
                                   l_acc_hoff(l_hoff_count).Lcy_Amount,
                                   l_acc_hoff(l_hoff_count).Lcy_Amount) THEN
              RETURN FALSE;
            END IF;

            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING=' || l_acc_hoff(l_hoff_count)
                           .Lcy_Amount);

            --for other leg
            l_acc_hoff(l_hoff_count + 1).Lcy_Amount := l_acc_hoff(l_hoff_count)
                                                       .Lcy_Amount;

          END IF;

        END IF;

      ELSE

        --get mid rate
        IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                l_acvw_all_ac_entries.AC_CCY, --TD CURRENCY
                                GLOBAL.lcy, --l_cavw_entries.ac_ccy, --CASA CURRENCY
                                'STANDARD',

                                'M',

                                L_EXCH_RATE,
                                L_RATE_FLAG,
                                L_ERROR_CODE) THEN

          RETURN FALSE;

        ELSE

          DEBUG.PR_DEBUG('AC',
                         'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                         L_EXCH_RATE);

          --derive lcy amount
          IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                        l_acvw_all_ac_entries.AC_CCY,
                                        GLOBAL.lcy, --l_cavw_entries.ac_ccy,
                                        'STANDARD',
                                        'M',
                                        l_acc_hoff                  (l_hoff_count)
                                        .Fcy_Amount,
                                        'Y',
                                        l_acc_hoff                  (l_hoff_count)
                                        .Lcy_Amount,
                                        L_EXCH_RATE,
                                        L_ERROR_CODE) THEN
            DEBUG.pr_debug('AC',
                           'Error while computing LCY ' || L_ERROR_CODE);
            L_ERROR_CODE := SQLCODE;
            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT FOR MID RATE=' || l_acc_hoff(l_hoff_count)
                           .Lcy_Amount);

            l_acc_hoff(l_hoff_count).Lcy_Amount := l_acc_hoff(l_hoff_count)
                                                   .Lcy_Amount;

            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT FOR MID RATE AFTER SIGN=' || l_acc_hoff(l_hoff_count)
                           .Lcy_Amount);

            --ROUND LCY AMOUNT
            IF NOT
                cypks.fn_amt_round(GLOBAL.lcy,
                                   l_acc_hoff(l_hoff_count).Lcy_Amount,
                                   l_acc_hoff(l_hoff_count).Lcy_Amount) THEN
              RETURN FALSE;
            END IF;

            DEBUG.PR_DEBUG('AC',
                           'DERIVED LCY AMOUNT AFTER ROUNDING FOR MID RATE=' || l_acc_hoff(l_hoff_count)
                           .Lcy_Amount);

            --for other leg
            l_acc_hoff(l_hoff_count + 1).Lcy_Amount := l_acc_hoff(l_hoff_count)
                                                       .Lcy_Amount;

          END IF;

        END IF;

      END IF;

    END IF;

  ELSE
    debug.pr_debug('AC','IN ELSE CONDITION');
    l_acc_hoff(l_hoff_count).fcy_amount := null;
    l_acc_hoff(l_hoff_count).LCY_AMOUNT := -L_CAVW_ENTRIES.LCY_AMOUNT;
    L_EXCH_RATE := 1;

    --for other leg
    l_acc_hoff(l_hoff_count + 1).fcy_amount := null;
    l_acc_hoff(l_hoff_count + 1).LCY_AMOUNT := -L_CAVW_ENTRIES.LCY_AMOUNT;

  END IF;

  /*

  IF l_acvw_all_ac_entries.AC_CCY <> l_cavw_entries.ac_ccy THEN
    --l_acvw_all_ac_entries.AC_CCY

    IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                            l_acvw_all_ac_entries.AC_CCY, --TD CURRENCY
                            l_cavw_entries.ac_ccy, --CASA CURRENCY
                            'COMM',

                            CASE l_acvw_all_ac_entries.AC_CCY
                              WHEN 'USD' THEN
                               'S'
                              WHEN 'KHR' THEN
                               'B'
                            END,

                            L_EXCH_RATE,
                            L_RATE_FLAG,
                            L_ERROR_CODE) THEN

      RETURN FALSE;

    END IF;

  ELSE

    L_EXCH_RATE := 1;

  END IF;*/

  DEBUG.PR_DEBUG('AC', 'L_EXCH_RATE L_EXCH_RATE=' || L_EXCH_RATE);

  l_acc_hoff(l_hoff_count).exch_rate := L_EXCH_RATE; --l_cavw_entries.exch_rate; --4020; --pls check
  /*
  --derive lcy
  IF l_acvw_all_ac_entries.AC_CCY <> l_cavw_entries.ac_ccy AND l_acc_hoff(l_hoff_count)
    .Fcy_Amount IS NOT NULL THEN

    IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                  l_acvw_all_ac_entries.AC_CCY,
                                  l_cavw_entries.ac_ccy,
                                  'COMM',
                                  'B',
                                  l_acc_hoff                  (l_hoff_count)
                                  .Fcy_Amount,
                                  'Y',
                                  l_acc_hoff                  (l_hoff_count)
                                  .Lcy_Amount,
                                  l_acc_hoff                  (l_hoff_count)
                                  .Exch_Rate,
                                  L_ERROR_CODE) THEN
      DEBUG.pr_debug('AC', 'Error while computing LCY ' || L_ERROR_CODE);
      L_ERROR_CODE := SQLCODE;
      RETURN FALSE;

    ELSE

      l_acc_hoff(l_hoff_count).Lcy_Amount := -l_acc_hoff(l_hoff_count)
                                             .Lcy_Amount;

    END IF;

  END IF;
  */

  l_acc_hoff(l_hoff_count).related_customer := l_counterparty;
  l_acc_hoff(l_hoff_count).trn_dt := global.application_date;
  l_acc_hoff(l_hoff_count).value_dt := global.application_date;
  l_acc_hoff(l_hoff_count).instrument_code := NULL;
  l_acc_hoff(l_hoff_count).netting_ind := 'N';
  l_acc_hoff(l_hoff_count).user_id := global.user_id;
  l_acc_hoff(l_hoff_count).mis_head := l_mishead;
  l_acc_hoff(l_hoff_count).financial_cycle := NULL; -- Input both the financial cycle and Period code to post back period entries
  l_acc_hoff(l_hoff_count).period_code := NULL;
  l_acc_hoff(l_hoff_count).auth_id := global.user_id;
  l_acc_hoff(l_hoff_count).batch_no := NULL;
  l_acc_hoff(l_hoff_count).curr_no := 0;
  l_acc_hoff(l_hoff_count).bank_code := NULL;
  l_acc_hoff(l_hoff_count).avldays := NULL;
  l_acc_hoff(l_hoff_count).balance_upd := NULL;
  l_acc_hoff(l_hoff_count).auth_stat := NULL;
  l_acc_hoff(l_hoff_count).delete_stat := NULL;
  l_acc_hoff(l_hoff_count).TYPE := NULL;
  l_acc_hoff(l_hoff_count).print_stat := 'N';
  l_acc_hoff(l_hoff_count).on_line := 'Y';
  l_acc_hoff(l_hoff_count).related_account := l_acvw_all_ac_entries.RELATED_ACCOUNT;
  l_acc_hoff(l_hoff_count).related_customer := l_acvw_all_ac_entries.RELATED_CUSTOMER;
  l_acc_hoff(l_hoff_count).external_ref_no := l_contract_ref_no;--l_acvw_all_ac_entries.EXTERNAL_REF_NO;

  l_hoff_count := l_hoff_count + 1;
  l_acc_hoff(l_hoff_count).module := 'IC';
  l_acc_hoff(l_hoff_count).trn_ref_no := l_contract_ref_no;-- l_cavw_entries.trn_ref_no; --l_contract_ref_no;
  l_acc_hoff(l_hoff_count).event_sr_no := '2';
  l_acc_hoff(l_hoff_count).event := l_event;
  l_acc_hoff(l_hoff_count).ac_branch := P_TD_ACBRN;--L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN;--P_TD_ACBRN;
  l_acc_hoff(l_hoff_count).ac_no := l_acvw_all_ac_entries.AC_NO;-- '384000021'; --hardcode
  l_acc_hoff(l_hoff_count).ac_ccy := P_TDCCY; --'USD'; --l_ac_ccy; can't be always USD it depends on TD currency
  l_acc_hoff(l_hoff_count).drcr_ind := 'C';
  l_acc_hoff(l_hoff_count).trn_code := l_trn_code;
  l_acc_hoff(l_hoff_count).amount_tag := l_amount_tag;

  -- IF l_acvw_all_ac_entries.fcy_amount IS NOT NULL THEN

  --  l_acc_hoff(l_hoff_count).fcy_amount := -l_acvw_all_ac_entries.fcy_amount;

  -- ELSE

  --   l_acc_hoff(l_hoff_count).fcy_amount := null; --l_fcy_amount;
  /*IF P_CASA_CCY <> P_TDCCY THEN
  IF NOT Cypkss.Fn_Amt1_To_Amt2(P_TD_ACBRN,
                                P_CASA_CCY, ----25052017 modifications
                                l_acc_hoff  (l_hoff_count).Ac_Ccy,
                                'COMM',
                                'S',
                                p_amount,
                                'Y',
                                p_Acc_Hoff  (l_Acc_Hoff_Cnt).Fcy_Amount,
                                p_Acc_Hoff  (l_Acc_Hoff_Cnt).Exch_Rate,
                                p_Error_Code) THEN
    Dbg('Error while computing LCY ' || p_Error_Code);
    p_Error_Code := SQLCODE;
    RETURN FALSE;
  END IF;*/

  -- END IF;

  DEBUG.PR_DEBUG('AC',
                 'l_acvw_all_ac_entries.EXCH_RATE=' ||
                 l_acvw_all_ac_entries.EXCH_RATE);

  l_acc_hoff(l_hoff_count).exch_rate := L_EXCH_RATE; --l_acvw_all_ac_entries.EXCH_RATE; -- 4020; --pls check system should derive lets see
  --l_acc_hoff(l_hoff_count).lcy_amount := -l_acvw_all_ac_entries.lcy_amount; ---l_cavw_entries.lcy_amount; --40200000000;
  l_acc_hoff(l_hoff_count).related_customer := '';
  l_acc_hoff(l_hoff_count).trn_dt := global.application_date;
  l_acc_hoff(l_hoff_count).value_dt := global.application_date;
  l_acc_hoff(l_hoff_count).instrument_code := NULL;
  l_acc_hoff(l_hoff_count).netting_ind := 'N';
  l_acc_hoff(l_hoff_count).user_id := global.user_id;
  l_acc_hoff(l_hoff_count).auth_id := global.user_id;
  l_acc_hoff(l_hoff_count).mis_head := l_mishead;
  l_acc_hoff(l_hoff_count).financial_cycle := NULL;
  l_acc_hoff(l_hoff_count).period_code := NULL;
  l_acc_hoff(l_hoff_count).batch_no := NULL;
  l_acc_hoff(l_hoff_count).curr_no := 0;
  l_acc_hoff(l_hoff_count).bank_code := NULL;
  l_acc_hoff(l_hoff_count).avldays := NULL;
  l_acc_hoff(l_hoff_count).balance_upd := NULL;
  l_acc_hoff(l_hoff_count).auth_stat := NULL;
  l_acc_hoff(l_hoff_count).delete_stat := NULL;
  l_acc_hoff(l_hoff_count).TYPE := NULL;
  l_acc_hoff(l_hoff_count).print_stat := 'N';
  l_acc_hoff(l_hoff_count).on_line := 'Y';
  l_acc_hoff(l_hoff_count).related_account := l_acvw_all_ac_entries.RELATED_ACCOUNT;
  l_acc_hoff(l_hoff_count).related_customer := l_acvw_all_ac_entries.RELATED_CUSTOMER;
  l_acc_hoff(l_hoff_count).external_ref_no := l_contract_ref_no;--l_acvw_all_ac_entries.EXTERNAL_REF_NO;

  IF NOT acpkss.fn_achandoff(l_cavw_entries.trn_ref_no, --l_contract_ref_no,
                             1,
                             global.application_date,
                             l_acc_hoff,
                             'B', -- Put U to post the entry as Unauthorized
                             'N', --suspense
                             'N', --balancing
                             global.user_id,
                             l_error_code,
                             l_error_parameter) THEN
    DBMS_OUTPUT.PUT_LINE('failed in accounting handoff function');
    DBMS_OUTPUT.PUT_LINE('error code --> ' || l_error_code);
    DBMS_OUTPUT.PUT_LINE('error parameter --> ' || l_error_parameter);
    ROLLBACK;
    RETURN FALSE;
  ELSE
    DBMS_OUTPUT.PUT_LINE('Success - ACC ENTRY');
    DBMS_OUTPUT.PUT_LINE('error code --> ' || l_error_code);
    DBMS_OUTPUT.PUT_LINE('error parameter --> ' || l_error_parameter);
    --commit;
    RETURN TRUE;
  END IF;

  RETURN FALSE;

EXCEPTION

  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('AC', 'FAILED IN FN_POST_TAX_REVERSAL_TDUPFRONT');
    DEBUG.PR_DEBUG('AC',
                   'ERROR CODE IN FN_POST_TAX_REVERSAL_TDUPFRONT=' ||
                   SQLCODE);
    DEBUG.PR_DEBUG('AC',
                   'ERROR MESSAGE IN FN_POST_TAX_REVERSAL_TDUPFRONT=' ||
                   SQLERRM);
    DEBUG.PR_DEBUG('AC',
                   'ERROR LINE NUMBER=' ||
                   DBMS_UTILITY.format_error_backtrace);

    RETURN FALSE;

END FN_POST_TAX_REVERSAL_TDUPFRONT;
