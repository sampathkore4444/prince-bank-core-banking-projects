CREATE OR REPLACE PACKAGE BODY icpks_maint_custom IS

  PROCEDURE DBG(X VARCHAR2) IS
    L_LEN NUMBER := 0;
    L_IND NUMBER := 1;
  BEGIN
    IF LENGTH(X) < 255 THEN
      DEBUG.PR_DEBUG('IC', 'icpks_maint_custom-->' || X);
    ELSE
      L_LEN := LENGTH(X);
      WHILE L_IND < L_LEN LOOP
        DEBUG.PR_DEBUG('IC',
                       'icpks_maint_custom-->' || SUBSTR(X, L_IND, 255));
        L_IND := L_IND + 255;
      END LOOP;
    END IF;
  END DBG;

  FUNCTION FN_GET_EXT_SDE_VALS(P_BRN     ICTBS_CALC_QUEUE.BRN%TYPE,
                               P_ACC     ICTBS_CALC_QUEUE.ACC%TYPE,
                               P_SDE_ID  VARCHAR2,
                               P_FROM_DT DATE,
                               P_END_DT  DATE)
    RETURN ICPKS_MAINT.TB_ACC_SDE_VALS IS

    --sampath starts
    L_FROM_DATE DATE;
    --sampath ends
	
	 --sampath starts
    L_TD_UPFRONT_PREMAT_FLAG       NUMBER := 0;
    L_TD_UPFRONT_BOOK_FLAG         NUMBER := 0;
    L_TD_UPFRONT_AUTOROLLOVER_FLAG NUMBER := 0;
    --sampath ends

    L_TB_ACC_SDE_VALS ICPKS_MAINT.TB_ACC_SDE_VALS;
  BEGIN
    DBG('Inside fn_get_ext_sde_vals');
    DBG('p_sde_id: ' || P_SDE_ID);

    --sampath starts
    IF P_SDE_ID = 'TRACK_DAYS' THEN

      DBG('ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE=' ||
          ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE);

      L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;

      DBG('L_FROM_DATE=' || L_FROM_DATE);

      DBG('P_END_DT=' || P_END_DT);

      --ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;

      ICPKSS_CALC.G_DAYS_INT := GLOBAL.APPLICATION_DATE -
                                ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;-- + 1;

      DBG('ICPKSS_CALC.G_DAYS_INT=' || ICPKSS_CALC.G_DAYS_INT);

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := ICPKSS_CALC.G_DAYS_INT;
	  
	  DBG('Days From Start Initial--> ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    END IF;

    --sampath ends
	
	--sampath starts
    IF P_SDE_ID = 'TD_UPFRONT_PREMAT_FLAG' THEN
    
      DBG('INSIDE TD UPFRONT PRE MATURE FLAG' ||
          ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE);
    
      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;
    
      DBG('L_FROM_DATE=' || L_FROM_DATE);
    
      DBG('P_END_DT=' || P_END_DT);
    
    
      L_TD_UPFRONT_PREMAT_FLAG := CASE ICPKS_MAINT.G_FULL_REDEM
                                    WHEN 'Y' THEN
                                     1
                                    ELSE
                                     0
                                  END;
    
      DBG('L_TD_UPFRONT_PREMAT_FLAG=' || L_TD_UPFRONT_PREMAT_FLAG);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_PREMAT_FLAG;
    
    END IF;
  
    IF P_SDE_ID = 'TD_UPFRONT_BOOK_FLAG' THEN
    
      DBG('INSIDE TD UPFRONT BOOK FLAG');
    
      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;
    
      DBG('L_FROM_DATE=' || L_FROM_DATE);
    
      DBG('P_END_DT=' || P_END_DT);
    
    
      L_TD_UPFRONT_BOOK_FLAG := CASE
                                 stpks_stdcusac_utils_2.G_TD_UPFRONT_BOOK_FLAG
                                  WHEN 'Y' THEN
                                   1
                                  ELSE
                                   0
                                END;
    
      DBG('L_TD_UPFRONT_BOOK_FLAG=' || L_TD_UPFRONT_BOOK_FLAG);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_BOOK_FLAG;
    
      DBG('TD UPFRONT BOOK FLAG= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    IF P_SDE_ID = 'TD_UPFRONT_AUTOROLLOVER_FLAG' THEN
    
      DBG('INSIDE TD AUTO ROLLOVER FLAG');
    
      --L_FROM_DATE := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;
    
      DBG('L_FROM_DATE=' || L_FROM_DATE);
    
      DBG('P_END_DT=' || P_END_DT);

    
      L_TD_UPFRONT_AUTOROLLOVER_FLAG := CASE
                                          WHEN ICPKS_BOD.pkg_ictm_acc.auto_rollover = 'Y' AND
                                               ICPKS_BOD_CUSTOM.G_TD_UPFRONT_ROLLOVER_AMT_FLAG = 'Y' THEN
                                           1
                                          ELSE
                                           0
                                        END;
    
      DBG('L_TD_UPFRONT_AUTOROLLOVER_FLAG=' ||
          L_TD_UPFRONT_AUTOROLLOVER_FLAG);
    
      L_TB_ACC_SDE_VALS.DELETE;
    
      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := L_TD_UPFRONT_AUTOROLLOVER_FLAG;
    
      DBG('TD UPFRONT AUTOROLLOVER FLAG= ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);
    
    END IF;
  
    --sampath ends

    DBG('Returning from fn_get_ext_sde_vals');
    RETURN L_TB_ACC_SDE_VALS;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_ext_sde_vals');
      RETURN L_TB_ACC_SDE_VALS;
  END FN_GET_EXT_SDE_VALS;

  FUNCTION FN_GET_IL_SDE(P_BRANCH_CODE     IN ILTBS_SYS_ACCOUNT.SYSTEM_ACCOUNT_BRANCH%TYPE,
                         P_SYS_AC_NO       IN ILTBS_SYS_ACCOUNT.SYSTEM_ACCOUNT%TYPE,
                         P_FROM_DT         IN ILTBS_VD_BALANCES.VALUE_DATE%TYPE,
                         P_TO_DT           IN ILTBS_VD_BALANCES.VALUE_DATE%TYPE,
                         P_SDE_ID          IN ICTMS_SDE.SDE_ID%TYPE,
                         P_TB_ACC_SDE_VALS IN OUT ICPKSS_MAINT.TB_ACC_SDE_VALS,
                         P_ERROR_CODE      IN OUT VARCHAR2,
                         P_ERROR_PARAMETER IN OUT VARCHAR2,
                         P_FN_CALL_ID      IN NUMBER,
                         P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_get_il_sde');

    DBG('Returning from fn_get_il_sde');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_il_sde');
      RETURN FALSE;
  END FN_GET_IL_SDE;

  FUNCTION FN_GET_SDE_VALS(P_BRN            ICTBS_CALC_QUEUE.BRN%TYPE,
                           P_ACC            ICTBS_CALC_QUEUE.ACC%TYPE,
                           P_SDE_ID         VARCHAR2,
                           P_FROM_DT        DATE,
                           P_END_DT         DATE,
                           P_FN_CALL_ID     NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN ICPKS_MAINT.TB_ACC_SDE_VALS IS
    L_TB_ACC_SDE_VALS ICPKS_MAINT.TB_ACC_SDE_VALS;

    /*--sampath starts
    L_FROM_DATE DATE;
    --sampath ends*/
  BEGIN
    DBG('Inside icpks_maint_custom.fn_get_sde_vals for sde_id ' ||
        P_SDE_ID);

    /* --sampath starts
    IF P_SDE_ID = 'TRACK_DAYS' THEN

      L_FROM_DATE            := ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE;
      ICPKSS_CALC.G_DAYS_INT := P_END_DT - L_FROM_DATE + 1;

      L_TB_ACC_SDE_VALS.DELETE;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).SDE_VAL := ICPKSS_CALC.G_DAYS_INT;

    END IF;

    DBG('Days From Start Initial--> ' || L_TB_ACC_SDE_VALS(1).SDE_VAL);

    --sampath ends*/

    DBG('Returning successfully from icpks_maint_cluster.fn_get_sde_vals');
    RETURN L_TB_ACC_SDE_VALS;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of fn_get_il_sde' || SQLERRM);
      RETURN L_TB_ACC_SDE_VALS;
  END FN_GET_SDE_VALS;

  FUNCTION FN_GET_LIQN_DT(P_BRN            IN VARCHAR2,
                          P_ACC            IN VARCHAR2,
                          P_PROD           IN VARCHAR2,
                          P_FN_CALL_ID     IN NUMBER,
                          P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN DATE IS
    L_NEXT_LIQ_DT DATE;
  BEGIN
    DBG('Inside icpks_maint_custom.fn_get_liqn_dt');

    DBG('Returning from icpks_maint_custom.fn_get_liqn_dt');
    RETURN L_NEXT_LIQ_DT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('When others exception of icpks_maint_custom.fn_get_liqn_dt');
      RETURN NULL;
  END FN_GET_LIQN_DT;

END ICPKS_MAINT_CUSTOM;
