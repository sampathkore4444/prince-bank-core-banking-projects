CREATE OR REPLACE FUNCTION FN_POST_TAX_REVERSAL_TDUPFRONT1(P_PROD  IN VARCHAR2,
                                                           P_TDACC IN VARCHAR2,
                                                           
                                                           P_TDBRN IN VARCHAR2,
                                                           
                                                           P_TDCCY   IN VARCHAR2,
                                                           P_CASAACC IN VARCHAR2,
                                                           P_CASABRN IN VARCHAR2,
                                                           P_CASACCY IN VARCHAR2)
  RETURN BOOLEAN IS

  l_cavw_entries          cavw_entries%rowtype;
  L_DRCR                  VARCHAR2(1);
  tb_AccHandoff           acpkss.tbl_AcHoff;
  RELATED_CUSTOMER        VARCHAR2(20);
  L_NETTING_INDICATOR     VARCHAR2(1);
  L_MIS_HEAD              VARCHAR2(20);
  L_RATE_FLAG             NUMBER;
  L_EXCH_RATE             ACTB_DAILY_LOG.EXCH_RATE%TYPE;
  L_LCY_AMOUNT            ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  L_FCY_AMOUNT            ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
  L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
  L_PLAN                  VARCHAR2(25);
  L_12TH_LIQUIDATION_DATE ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
  L_24TH_LIQUIDATION_DATE ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

  L_EVENT VARCHAR2(4) := 'DEBK';

  l_serial_no VARCHAR2(16);

  l_contract_ref_no cstbs_contract.contract_ref_no%TYPE;

  L_LIQUIDAITON_COUNT NUMBER := 0;

  L_REVERSE_TAX ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;

  L_error_code      VARCHAR2(200);
  L_error_parameter VARCHAR2(200);

  L_ACCOUNT_CLASS STTM_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'FN_POST_TAX_REVERSAL_TDUPFRONT1 ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;
BEGIN

  --GLOBAL.pr_init(P_TDBRN, 'SYSTEM');

  DBG('FN_POST_TAX_REVERSAL_TDUPFRONT1');

  DBG('P_TDACC=' || P_TDACC);
  DBG('P_TDBRN=' || P_TDBRN);
  DBG('P_TDCCY=' || P_TDCCY);

  L_NETTING_INDICATOR := 'N';
  L_MIS_HEAD          := NULL;

  IF NOT trpkss.fn_get_product_refno(P_TDBRN,
                                     'TDRE',
                                     global.application_date,
                                     l_serial_no,
                                     l_contract_ref_no,
                                     L_error_code) THEN
    debug.pr_debug('AC', 'Failed in generation Transaction Ref No');
    RETURN FALSE;
  ELSE
    debug.pr_debug('AC', 'l_contract_ref_no=' || l_contract_ref_no);
  
  END IF;

  --get td account class
  BEGIN
    SELECT A.ACCOUNT_CLASS
      INTO L_ACCOUNT_CLASS
      FROM STTM_CUST_ACCOUNT A
     WHERE A.CUST_AC_NO = P_TDACC
       AND A.BRANCH_CODE = P_TDBRN;
  EXCEPTION
    WHEN OTHERS THEN
      L_ACCOUNT_CLASS := NULL;
  END;

  IF P_TDCCY = 'KHR' AND P_CASACCY = 'KHR' THEN
  
    BEGIN
      SELECT NVL(SUM(A.FCY_AMOUNT), 0)
        INTO L_REVERSE_TAX
        FROM CAVW_ENTRIES A
       WHERE A.AC_NO = P_CASAACC
         AND A.PRODUCT = 'DEBK'
         AND A.related_account = P_TDACC
         AND A.EVENT = 'DEBK'
         AND A.AMOUNT_TAG = 'TAX'
         AND A.TRN_CODE = 'TDX'
         AND A.drcr_ind = 'D';
    
    EXCEPTION
    
      WHEN OTHERS THEN
      
        L_REVERSE_TAX := 0;
      
    END;
  
  ELSE
  
    BEGIN
    
      SELECT NVL(SUM(A.LCY_AMOUNT), 0) /*DECODE(P_CASACCY,
                                                        'USD',
                                                        NVL(SUM(A.LCY_AMOUNT), 0),
                                                        NVL(SUM(A.FCY_AMOUNT), 0))*/
        INTO L_REVERSE_TAX
        FROM CAVW_ENTRIES A
       WHERE A.AC_NO = P_CASAACC
         AND A.PRODUCT = 'DEBK'
         AND A.related_account = P_TDACC
         AND A.EVENT = 'DEBK'
         AND A.AMOUNT_TAG = 'TAX'
         AND A.TRN_CODE = 'TDX'
         AND A.drcr_ind = 'D';
    
    EXCEPTION
    
      WHEN OTHERS THEN
      
        L_REVERSE_TAX := 0;
      
    END;
  
  END IF;

  DBG('L_REVERSE_TAX=' || L_REVERSE_TAX);

  IF L_REVERSE_TAX <= 0 THEN
  
    RETURN TRUE;
  
  END IF;

  IF P_TDCCY = 'KHR' AND P_CASACCY = 'USD' THEN
    --TD Account currency is KHR and Payout CASA Currency is KHR
  
    DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_TDCCY);
    DBG('INSIDE IF P_CASACCY ACCOUNT CURRENCY=' || P_CASACCY);
  
    --Get Rate
    IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                            P_TDCCY, --KHR
                            P_CASACCY, --USD
                            'COMM',
                            
                            'S',
                            
                            L_EXCH_RATE,
                            L_RATE_FLAG,
                            L_error_code) THEN
    
      RETURN FALSE;
    
    ELSE
    
      DEBUG.PR_DEBUG('AC',
                     'DERIVED EXCHANGE RATE FOR SELL RATE=' || L_EXCH_RATE);
    
      --convert Amount using above Rate
      --derive lcy amount    
      IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                    
                                    P_CASACCY,
                                    P_TDCCY,
                                    'COMM',
                                    'S',
                                    L_REVERSE_TAX, --USD amount LCYAMOUNT
                                    'Y',
                                    L_FCY_AMOUNT, --usd amount
                                    L_EXCH_RATE,
                                    L_error_code) THEN
        DEBUG.pr_debug('AC', 'Error while computing FCY ' || L_error_code);
        L_error_code := SQLCODE;
        RETURN FALSE;
      
      ELSE
      
        DEBUG.PR_DEBUG('AC',
                       'DERIVED FCY AMOUNT FOR SELL RATE=' || L_FCY_AMOUNT);
      
      END IF;
    
    END IF;
  
    L_LCY_AMOUNT := L_REVERSE_TAX;
  
    L_FCY_AMOUNT := L_FCY_AMOUNT;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'KHR' THEN
    --TD Account currency is USD and Payout CASA Currency is KHR
  
    DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_TDCCY);
    DBG('INSIDE IF P_CASACCY ACCOUNT CURRENCY=' || P_CASACCY);
  
    --Get Rate
    IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                            P_TDCCY, --USD
                            P_CASACCY, --KHR
                            'COMM',
                            
                            'B',
                            
                            L_EXCH_RATE,
                            L_RATE_FLAG,
                            L_error_code) THEN
    
      RETURN FALSE;
    
    ELSE
    
      DEBUG.PR_DEBUG('AC',
                     'DERIVED EXCHANGE RATE FOR BUY RATE=' || L_EXCH_RATE);
    
      --convert Amount using above Rate
      --derive lcy amount    
      IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                    P_TDCCY,
                                    P_CASACCY,
                                    'COMM',
                                    'S',
                                    L_REVERSE_TAX, --USD amount
                                    'Y',
                                    L_FCY_AMOUNT, --KHR amount
                                    L_EXCH_RATE,
                                    L_error_code) THEN
        DEBUG.pr_debug('AC', 'Error while computing LCY ' || L_error_code);
        L_error_code := SQLCODE;
        RETURN FALSE;
      
      ELSE
      
        DEBUG.PR_DEBUG('AC',
                       'DERIVED FCY AMOUNT FOR SELL RATE=' || L_FCY_AMOUNT);
      
      END IF;
    
    END IF;
  
    L_LCY_AMOUNT := L_REVERSE_TAX;
  
    L_FCY_AMOUNT := L_FCY_AMOUNT;
  
  ELSIF P_TDCCY = 'KHR' AND P_CASACCY = 'KHR' THEN
  
    DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_TDCCY);
    DBG('INSIDE IF P_CASACCY ACCOUNT CURRENCY=' || P_CASACCY);
  
    --Get Rate
    IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                            P_TDCCY, --KHR
                            GLOBAL.LCY, --P_CASACCY, --KHR
                            'STANDARD',
                            
                            'M',
                            
                            L_EXCH_RATE,
                            L_RATE_FLAG,
                            L_error_code) THEN
    
      RETURN FALSE;
    
    ELSE
    
      DEBUG.PR_DEBUG('AC',
                     'DERIVED EXCHANGE RATE FOR MID RATE=' || L_EXCH_RATE);
    
      --convert Amount using above Rate
      --derive lcy amount    
      IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                    P_TDCCY,
                                    GLOBAL.lcy, --usd to get lcy amount
                                    'STANDARD',
                                    'M',
                                    L_REVERSE_TAX, --KHR amount nothing but FCY Amount
                                    'Y',
                                    L_LCY_AMOUNT, --USD amount nothing but LCY Amount
                                    L_EXCH_RATE,
                                    L_error_code) THEN
        DEBUG.pr_debug('AC', 'Error while computing LCY ' || L_error_code);
        L_error_code := SQLCODE;
        RETURN FALSE;
      
      ELSE
      
        DEBUG.PR_DEBUG('AC',
                       'DERIVED LCY AMOUNT FOR SELL RATE=' || L_LCY_AMOUNT);
      
      END IF;
    
    END IF;
  
    L_LCY_AMOUNT := L_LCY_AMOUNT;
  
    L_FCY_AMOUNT := L_REVERSE_TAX;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'USD' THEN
  
    DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_TDCCY);
    DBG('INSIDE IF P_CASACCY ACCOUNT CURRENCY=' || P_CASACCY);
  
    L_LCY_AMOUNT := L_REVERSE_TAX;
  
    L_FCY_AMOUNT := NULL;
  
  END IF;

  TB_ACCHANDOFF(1) := NULL;

  TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
  TB_ACCHANDOFF(1).MODULE := 'IC';
  TB_ACCHANDOFF(1).AMOUNT_TAG := 'TAX_ADJ';
  TB_ACCHANDOFF(1).EVENT := L_EVENT;
  TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
  TB_ACCHANDOFF(1).TRN_CODE := 'TAJ'; -- P_TXN_CODE; --pls check
  TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(1).TRN_REF_NO := l_contract_ref_no;
  TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

  TB_ACCHANDOFF(1).VALUE_DT := GLOBAL.application_date;
  TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_TDACC;
  TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
  TB_ACCHANDOFF(1).EXTERNAL_REF_NO := l_contract_ref_no;
  TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
  TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

  TB_ACCHANDOFF(1).AC_BRANCH := P_TDBRN;

  IF L_ACCOUNT_CLASS IN ('TD41', 'TD42', 'TD45', 'TD46', 'TD49', 'TD50') THEN
  
    TB_ACCHANDOFF(1).AC_NO := '384000021'; --debit TAX GL
  
  ELSIF L_ACCOUNT_CLASS IN ('TD43', 'TD44', 'TD47', 'TD48', 'TD51', 'TD52') THEN
  
    TB_ACCHANDOFF(1).AC_NO := '384000022';
  
  END IF;

  TB_ACCHANDOFF(1).AC_CCY := P_TDCCY; -- P_CASACCY; --fixed during pro savings for clever savings 

  IF P_TDCCY = 'KHR' AND P_CASACCY = 'USD' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'KHR' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'KHR' AND P_CASACCY = 'KHR' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'USD' THEN
  
    TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
    TB_ACCHANDOFF(1).EXCH_RATE := NULL;
  
  END IF;

  TB_ACCHANDOFF(1).PRODUCT := P_PROD;

  DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
  DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
  DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
  DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
  DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
  DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
  DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
  DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
  DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
  DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
  DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
  DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
  DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
  DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
  DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
  DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
  DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
  DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
  DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
  DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
  DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

  DBG(' Finished debit leg');

  TB_ACCHANDOFF(2) := NULL;

  TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
  TB_ACCHANDOFF(2).MODULE := 'IC';
  TB_ACCHANDOFF(2).AMOUNT_TAG := 'TAX_ADJ';
  TB_ACCHANDOFF(2).EVENT := L_EVENT;
  TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
  TB_ACCHANDOFF(2).TRN_CODE := 'TAJ';
  TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(2).TRN_REF_NO := l_contract_ref_no;
  TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

  TB_ACCHANDOFF(2).VALUE_DT := GLOBAL.application_date;
  TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
  TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_TDACC;
  TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
  TB_ACCHANDOFF(2).EXTERNAL_REF_NO := l_contract_ref_no;
  TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
  TB_ACCHANDOFF(2).DRCR_IND := 'C';

  TB_ACCHANDOFF(2).AC_BRANCH := P_CASABRN;

  TB_ACCHANDOFF(2).AC_NO := P_CASAACC; --Credit CASA

  TB_ACCHANDOFF(2).AC_CCY := P_CASACCY;

  IF P_TDCCY = 'KHR' AND P_CASACCY = 'USD' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'KHR' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'KHR' AND P_CASACCY = 'KHR' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
    TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;
  
  ELSIF P_TDCCY = 'USD' AND P_CASACCY = 'USD' THEN
  
    TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
    TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
    TB_ACCHANDOFF(2).EXCH_RATE := NULL;
  
  END IF;

  TB_ACCHANDOFF(2).PRODUCT := 'DEBK'; --P_PROD

  DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
  DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
  DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
  DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
  DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
  DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
  DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
  DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
  DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
  DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
  DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
  DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
  DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
  DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
  DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
  DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
  DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
  DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
  DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
  DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
  DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

  DBG(' Finished credit leg');

  IF NOT ACPKSS.FN_ACHANDOFF(l_contract_ref_no,
                             1,
                             GLOBAL.APPLICATION_DATE,
                             TB_ACCHANDOFF,
                             'B',
                             'N',
                             'N',
                             GLOBAL.USER_ID,
                             L_error_code,
                             L_error_parameter) THEN
    ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);
  
    IF L_error_code IS NOT NULL THEN
      OVPKS.PR_APPENDTBL(L_error_code, L_error_parameter);
    END IF;
  
    L_error_code := L_error_code;
  
  ELSE
  
    DBG('SUCCESS IN REVERSING THE TOPUP_TAX');
  
  END IF;

  RETURN TRUE;

EXCEPTION
  WHEN OTHERS THEN
    DBG('Exception in FN_POST_TAX_REVERSAL_TDUPFRONT1' || SQLERRM);
    RETURN FALSE;
END FN_POST_TAX_REVERSAL_TDUPFRONT1;
