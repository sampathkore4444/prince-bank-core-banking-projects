CREATE OR REPLACE

PACKAGE BODY Icpks_Onliq_New AS

  TYPE REC_STTM_CUSTACC IS TABLE OF STTMS_CUST_ACCOUNT%ROWTYPE INDEX BY BINARY_INTEGER;
  TYPE REC_ICTM_ACC IS TABLE OF ICTMS_ACC%ROWTYPE INDEX BY BINARY_INTEGER;

  TYPE REC_INT_ACC_CLOSE IS TABLE OF ICTM_RULE.INT_ACC_CLOSE%TYPE INDEX BY BINARY_INTEGER;

  TB_INT_ACC_CLOSE REC_INT_ACC_CLOSE;
  TB_STTM_CUSTACC  REC_STTM_CUSTACC;
  TB_ICTM_ACC      REC_ICTM_ACC;
  L_COMMIT_FREQ    NUMBER := 5000;
  APPDT            DATE;

  UID SMTB_USER.USER_ID%TYPE;

  PKG_LIQ_DT DATE;

  PKG_VDBAL      CSTBS_PARAM.PARAM_VAL%TYPE;
  L_ENTRY_PASSED ICTBS_ENTRIES_HISTORY.ENTRY_PASSED%TYPE;

  L_TB_BRN                   ICPKS_TEST.T1;
  L_TB_ACC                   ICPKS_TEST.T2;
  L_TB_PROD                  ICPKS_TEST.T3;
  L_TB_SC_MAP_DT             ICPKS_TEST.T4;
  L_TB_GC_MAP_DT             ICPKS_TEST.T5;
  L_TB_LAST_CALC_DT          ICPKS_TEST.T6;
  L_TB_LAST_LIQ_DT           ICPKS_TEST.T7;
  L_TB_NEXT_LIQ_DT           ICPKS_TEST.T8;
  L_TB_LAST_ACCR_DT          ICPKS_TEST.T9;
  L_TB_NEXT_ACCR_DT          ICPKS_TEST.T10;
  L_TB_LAST_SCHD_LIQ_DT      ICPKS_TEST.T11;
  L_TB_INC_MTH               ICPKS_TEST.T12;
  L_TB_NEXT_SCHD_LIQ_DT      ICPKS_TEST.T13;
  L_TB_FIRST_CALC_DT         ICPKS_TEST.T14;
  L_TB_NEXT_SCHD_ACCR_DT     ICPKS_TEST.T15;
  L_TB_PROD_TYPE             ICPKS_TEST.T16;
  L_TB_HAS_ACCR              ICPKS_TEST.T17;
  L_TB_NEXT_CALC_DT          ICPKS_TEST.T18;
  L_TB_PROD_ACCR             ICPKS_TEST.T19;
  L_TB_HAS_PROBLEMS          ICPKS_TEST.T20;
  L_TB_BKVAL_MINCALC_DATE    ICPKS_TEST.T21;
  L_TB_BKVAL_RECALC_FLAG     ICPKS_TEST.T22;
  L_TB_FIRST_FIRST_CALC_DATE ICPKS_TEST.T23;
  L_TB_IMAT_PROBLEMS         ICPKS_TEST.T24;
  L_TB_DEPOSIT               ICPKS_TEST.T25;
  L_TB_ACLASS                ICPKS_TEST.T26;
  L_TB_CCY                   ICPKS_TEST.T27;
  L_TB_NEXT_EVENT_DT         ICPKS_TEST.T28;
  L_TB_ROWID                 ICPKS_TEST.T29;
  L_TB_PROCESS               ICPKS_TEST.T30;
  L_TB_DEFER_LIQ_DT          ICPKS_TEST.T31;
  TAB_ACC_DET                IC_ONLIQ.TY_ACC_REC;

  L_TB_SYS_AC_LEVEL ICPKS_TEST.T34;
  L_TB_SUBLEVEL     ICPKS_TEST.T35;
  G_ACC_SEL_TYPE    VARCHAR2(10);
  VD_ERR            VARCHAR2(1000);

  G_SLEEP_TIMER NUMBER := 30;
  PROCEDURE LOG_PROBLEM(P_ROWNUM NUMBER, P_OP VARCHAR2, P_ERR VARCHAR2);

  PROCEDURE DBG(MSG VARCHAR2) IS
  BEGIN
    IF (DEBUG.PKG_DEBUG_ON <> 2) THEN
      DEBUG.PR_DEBUG('IC', 'Icpks_Onliq_New  ==>' || MSG);
    END IF;
  END;

  PROCEDURE FIND_KEY(P_PROD      VARCHAR2,
                     P_ICTMPRINT IN OUT ICPKS_TEST.REC_PRINT);
  PROCEDURE PR_UPD_ACCPR(RECNO NUMBER, P_DT DATE);
  PROCEDURE PR_DUMMMY_TAB_DELETE(RECNO NUMBER);
  PROCEDURE PR_PROC_CHG_ACLASS(P_BRN     VARCHAR2,
                               P_ACLASS  VARCHAR2,
                               P_LIQ_DT  DATE,
                               P_PR_LIST VARCHAR2);
  PROCEDURE PR_PROC_CHG_ALL(P_BRN     VARCHAR2,
                            P_PR_LIST VARCHAR2,
                            P_LIQ_DT  DATE);
  PROCEDURE PR_PROC_CHG_SELECTED_ACC(P_BRN      VARCHAR2,
                                     P_ACC_LIST VARCHAR2,
                                     P_LIQ_DT   DATE,
                                     P_PR_LIST  VARCHAR2);

  PROCEDURE PR_NEW_ACC_LIST(P_BRANCH       VARCHAR2,
                            P_ACC_LIST     VARCHAR2,
                            P_NEW_ACC_LIST OUT VARCHAR2);

  PROCEDURE PR_LOG_BOOK_ERR(P_BRN  VARCHAR2,
                            P_ACC  VARCHAR2,
                            P_PROD VARCHAR2,
                            P_OP   ICTBS_BOOK_ERR.OP%TYPE,
                            P_ERRM ICTBS_BOOK_ERR.ERRM%TYPE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('Going to insert into ictbs_book_err');
    INSERT INTO ICTBS_BOOK_ERR
      (BRN, OP, PROD, ACC, ERRM)
    VALUES
      (P_BRN, P_OP, P_PROD, P_ACC, P_ERRM);
  
    IF G_REFERENCE_NO IS NOT NULL THEN
      INSERT INTO ICTB_ONLIQ_DETAILS
      VALUES
        (G_REFERENCE_NO, P_BRN, P_ACC, P_PROD, P_ERRM);
    END IF;
  
    COMMIT;
    DBG('Booking Err for OP-> ' || P_OP || ' ACC-> ' || P_ACC ||
        ' PROD-> ' || P_PROD);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of pr_log_book_err ' || SQLERRM);
  END PR_LOG_BOOK_ERR;

  PROCEDURE PR_CALL_ICONLIQ(P_BRN          VARCHAR2,
                            P_ACC_SEL_TYPE VARCHAR2,
                            P_ACC_LIST     VARCHAR2,
                            P_PR_LIST      VARCHAR2,
                            P_LIQ_DT       DATE) IS
    PROC_ACC    STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_CURR_ITEM NUMBER := 1;
    BKCALC_BOMB EXCEPTION;
    PROC_ACLASS     STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    CHGLIQ          BINARY_INTEGER;
    CHGLOOP         BINARY_INTEGER;
    MAINT_ERR_CODE  VARCHAR2(2550);
    MAINT_ERR_PARAM VARCHAR2(32000);
  
    P_NEW_ACC_LIST VARCHAR2(3000);
  
    L_ERC VARCHAR2(4000);
    L_ERP VARCHAR2(32000);
  
    P_ERRCODE VARCHAR2(1000) := NULL;
    P_ERRMSG  VARCHAR2(1000) := NULL;
  
    PROC_FAILED EXCEPTION;
  
    L_WHAT   VARCHAR2(255);
    N_PART   NUMBER;
    K        NUMBER;
    RETSTAT  INTEGER;
    L_SEQ_NO CSTB_CUSTACSEQ.SEQ_NO%TYPE := 1;
  
    VD_ERR VARCHAR2(255);
    VD_ERP VARCHAR2(255);
  
    L_JOB_NAME USER_SCHEDULER_JOBS.JOB_NAME%TYPE;
    CURSOR C_JOB IS
      SELECT 1
        FROM USER_SCHEDULER_JOBS
       WHERE JOB_ACTION LIKE '%pr_update_for_seq%';
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_LOCKED_ACCOUNT BOOLEAN := FALSE;
    PROCEDURE PR_RELEASE_LOCK IS
    BEGIN
      IF L_LOCKED_ACCOUNT THEN
        IF NOT ICPKS_INTRADAY_UTILS.FN_RELEASE_LOCK(P_ACC_LIST,
                                                    P_BRN,
                                                    ICPKS_PARTITION_INFO.G_THIS_PART,
                                                    P_ERRCODE) THEN
          DBG('Attention..Some issue in releasing the lock..' || P_ERRCODE);
        ELSE
          DBG('Lock relased successfully');
          L_LOCKED_ACCOUNT := FALSE;
        END IF;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO exception in releasing the lock for acc' || P_ACC_LIST || '~' ||
            SQLERRM);
    END PR_RELEASE_LOCK;
  
  BEGIN
  
    DBG('Global.func_type' || GLOBAL.FUNC_TYPE);
    IF NVL(GLOBAL.FUNC_TYPE, '*') = 'B' AND
       ICPKS_ONLIQ_NEW.G_REFERENCE_NO IS NULL THEN
      GLOBAL.PR_INIT(P_BRN);
    END IF;
  
    IF P_ACC_LIST IS NOT NULL AND P_BRN IS NOT NULL THEN
      BEGIN
        SELECT NVL(SEQ_NO, 1)
          INTO L_SEQ_NO
          FROM CSTB_CUSTACSEQ
         WHERE BRANCH_CODE = P_BRN
           AND CUST_AC_NO = P_ACC_LIST;
      EXCEPTION
        WHEN OTHERS THEN
          L_SEQ_NO := 1;
      END;
    END IF;
    ICPKS_PARTITION_INFO.G_THIS_PART := L_SEQ_NO;
  
    IF P_ACC_SEL_TYPE = 'S' THEN
      IF NOT CSPKS_ACC_SERVICE.G_CLOSE_OUT_WITHDRAWL THEN
        IF NOT ICPKS_INTRADAY_UTILS.FN_GET_LOCK_WRAPPER(P_ACC_LIST,
                                                        P_BRN,
                                                        ICPKS_PARTITION_INFO.G_THIS_PART,
                                                        P_ERRCODE) THEN
          DBG('Intraday Accrual is in progress for this account...pls try after sometime..' ||
              P_ERRCODE);
        
          PR_LOG_BOOK_ERR(P_BRN,
                          P_ACC_LIST,
                          'ALL',
                          'O',
                          'Intraday Accrual is in progress for this account...pls try after sometime..');
          RAISE PROC_FAILED;
        
        ELSE
          DBG('Got the Lock successfully.. Can proceed with Online Liquidation');
          L_LOCKED_ACCOUNT := TRUE;
        END IF;
      ELSE
        DBG('g_close_out_withdrawl is true..This call is from cspks_acc_Service.pr_close_out_withdrawl..lock already got..');
      END IF;
    
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKSS_ONLIQ_NEW_CLUSTER.PR_CALL_ICONLIQ(P_BRN,
                                               P_ACC_SEL_TYPE,
                                               P_ACC_LIST,
                                               P_PR_LIST,
                                               P_LIQ_DT,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      ICPKS_TEST.G_ONLIQ_FLAG := 'Y';
      IF NOT ICPKSS_TEST.FN_MARK_BKCALC_FOR_UDEVALS(P_BRN) THEN
        RAISE BKCALC_BOMB;
      END IF;
    
      PKG_LIQ_DT       := P_LIQ_DT;
      ICPKS_TEST.LCY   := GLOBAL.LCY;
      ICPKS_TEST.UID   := NVL(GLOBAL.USER_ID, 'SYSTEM');
      ICPKS_TEST.APPDT := GLOBAL.APPLICATION_DATE;
    
      IF NOT (GWPKS_UTIL.G_FROM_BEAN AND
          NVL(GWPKS_UTIL.PKG_ACTTYPE, 'SAVEAUTOAUTH') <> 'SAVEAUTOAUTH') THEN
        DBG('getting inside this if condition');
      
        IF P_ACC_SEL_TYPE = 'S' THEN
          ICPKSS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN => P_BRN,
                                               P_ACC => P_ACC_LIST);
        ELSE
        
          ICPKSS_UDE.PR_MAKE_UDE_ROW;
        END IF;
      
      END IF;
    
      ICPKS_TEST.DYN_NWD := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                         GLOBAL.CURRENT_BRANCH,
                                                         P_LIQ_DT,
                                                         'N',
                                                         1);
      ICPKS_TEST.NWD := ICPKS_TEST.DYN_NWD;
      ICPKS_TEST.PKG_LIQ_NETTING := 'N';
      ICPKS_TEST.TB_BASIC_HOFF(1).EVENT := 'IACR';
      ICPKS_TEST.TB_BASIC_HOFF(1).MODULE := 'IC';
      ICPKS_TEST.TB_BASIC_HOFF(1).EVENT_SR_NO := 1;
      ICPKS_TEST.TB_BASIC_HOFF(1).TRN_DT := APPDT;
    
      ICPKS_TEST.TB_BASIC_HOFF(1).AC_BRANCH := P_BRN;
    
      ICPKS_TEST.TB_BASIC_HOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, UID);
    
      ICPKS_TEST.TB_BASIC_HOFF(1).BATCH_NO := 0;
      ICPKS_TEST.TB_BASIC_HOFF(1).CURR_NO := 0;
      ICPKS_TEST.TB_BASIC_HOFF(1).AVLDAYS := 0;
      ICPKS_TEST.TB_BASIC_HOFF(1).TXN_INIT_DATE := APPDT;
    
      IF NOT ILPKSS_SERVICES.FN_RESOLVE_NEW_IL_PROD(P_BRN, NULL, NULL) THEN
        DBG('Failed in fn_stop_ic_for_il');
        RETURN;
      END IF;
    
      IF NOT ICPKSS_RESOLVE_MAINT.FN_STOP_IC_FOR_IL(P_BRN,
                                                    
                                                    MAINT_ERR_CODE,
                                                    MAINT_ERR_PARAM) THEN
        DBG('Failed in fn_stop_ic_for_il');
        RETURN;
      END IF;
    
      IF P_ACC_SEL_TYPE = 'S' THEN
        DBG('This is a selected account case');
        ICPKSS_BOOK.PR_ACCRUAL_REVERSAL(P_BRN);
      
        PR_NEW_ACC_LIST(P_BRN, P_ACC_LIST, P_NEW_ACC_LIST);
      
        LOOP
        
          PROC_ACC := CSPKES_MISC.FN_GETPARAM(P_NEW_ACC_LIST,
                                              L_CURR_ITEM,
                                              '~');
        
          EXIT WHEN PROC_ACC = 'EOPL';
          L_CURR_ITEM := L_CURR_ITEM + 1;
          DBG('This for account ' || ' - ' || PROC_ACC);
        
          UPDATE ICTB_ACC_PR
             SET HAS_PROBLEMS = 'N'
           WHERE BRN = P_BRN
             AND ACC = P_ACC_LIST
             AND HAS_PROBLEMS = 'Y';
        
          IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_BRN,
                                                     PROC_ACC,
                                                     MAINT_ERR_CODE,
                                                     MAINT_ERR_PARAM) THEN
            DBG('Resolution failed for acc ' || PROC_ACC);
            PR_RELEASE_LOCK;
            RETURN;
          END IF;
        
          IF NOT
              (GWPKS_UTIL.G_FROM_BEAN AND
              NVL(GWPKS_UTIL.PKG_ACTTYPE, 'SAVEAUTOAUTH') <> 'SAVEAUTOAUTH') THEN
            DBG('getting inside this if condition');
          
            ICPKSS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN => P_BRN,
                                                 P_ACC => PROC_ACC);
          
          END IF;
        
          G_ACC_SEL_TYPE := P_ACC_SEL_TYPE;
        
          IF PKG_VDBAL = 'OFFLINE' THEN
            IF NOT ACPKSS_VDBAL.FN_ACC_UPDATE(P_BRN, PROC_ACC, L_ERC, L_ERP) THEN
              DBG('acpkss_vdbal.fn_acc_update returned false');
              RETURN;
            END IF;
          END IF;
        
          DBG('Call Fn_Mark_Bkcalc_For_Udevals after resolution');
          IF NOT ICPKSS_TEST.FN_MARK_BKCALC_FOR_UDEVALS(P_BRN, PROC_ACC) THEN
            DBG('Fn_Mark_Bkcalc_For_Udevals returned false');
            RETURN;
          END IF;
        
          IF ICPKS_BOD.G_FROMBOD THEN
            DBG('1.Icpks_bod.G_FromBOD is TRUE');
          ELSE
            DBG('2.Icpks_bod.G_FromBOD is FALSE');
          END IF;
          IF NOT ICPKS_BOD.G_FROMBOD THEN
            IF NOT ICPKSS_BOD.FN_LIQUIDATE_DEBIT_INT(P_BRN,
                                                     PROC_ACC,
                                                     APPDT,
                                                     'M',
                                                     'I',
                                                     L_ERC,
                                                     L_ERP) THEN
              IF L_ERC = 'IC-DRINT17' THEN
                DBG('No Available Balance - Failed to process the account' ||
                    PROC_ACC);
              ELSE
                DBG('Failed in fn_Liquidate_Debit_Int ' || L_ERC);
              
                RAISE PROC_FAILED;
              END IF;
            END IF;
          
            IF NOT ICPKSS_BOD.FN_LIQUIDATE_DEBIT_INT(P_BRN,
                                                     PROC_ACC,
                                                     APPDT,
                                                     'M',
                                                     'C',
                                                     L_ERC,
                                                     L_ERP) THEN
              IF L_ERC = 'IC-DRINT17' THEN
                DBG('No Available Balance - Failed to process the account' ||
                    PROC_ACC);
              ELSE
                DBG('Failed in fn_Liquidate_Debit_Int ' || L_ERC);
              
                RAISE PROC_FAILED;
              END IF;
            END IF;
          
            IF NOT ICPKS_CHARGE.FN_LIQUIDATE_CHARGES(P_BRN,
                                                     L_ERC,
                                                     ICPKS_PARTITION_INFO.G_THIS_PART,
                                                     PROC_ACC) THEN
              DBG('Failed in collecting recievables ' || L_ERC);
              RAISE PROC_FAILED;
            END IF;
          
          END IF;
        
          PR_PROC_SELECTED_ACC(P_BRN, PROC_ACC, P_LIQ_DT, P_PR_LIST);
        
          DELETE FROM ICTB_INTRADAY_ACC_PR_BKUP
           WHERE BRN = P_BRN
             AND ACC = PROC_ACC;
          DBG('Cleared ICTB_INTRADAY_ACC_PR_BKUP' || SQL%ROWCOUNT);
        
          BEGIN
            PR_CALL_PROCESS(P_BRN, P_LIQ_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
              RAISE PROC_FAILED;
          END;
        
          IF (ICPKS_BOD.G_FROM_TD AND NOT (ICPKS_BOD.G_FROMBOD)) THEN
            DBG('Calling Func for Tax Refund for premat redemption');
            IF NOT FN_PROC_REFUND_TAX(P_BRN, PROC_ACC, P_ERRCODE, P_ERRMSG) THEN
              DBG('set up issue');
              PR_RELEASE_LOCK;
              P_ERRCODE := 'IC-OL023';
              RETURN;
            END IF;
          
          END IF;
        
        END LOOP;
      ELSIF P_ACC_SEL_TYPE = 'A' THEN
        G_ACC_SEL_TYPE := P_ACC_SEL_TYPE;
        DBG('all accounts taken care of :' || ' - ' || 'Jai Hind');
      
        IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN,
                                                   MAINT_ERR_CODE,
                                                   MAINT_ERR_PARAM) THEN
          RETURN;
        END IF;
        ICPKS_UDE.PR_MAKE_UDE_ROW;
      
        IF PKG_VDBAL = 'OFFLINE' THEN
        
          DELETE ICTB_JOB_CTL
           WHERE BRN = P_BRN
             AND FUNCTION_ID = 'VDBALUPD';
          COMMIT;
        
          N_PART := NVL(CSPKS_PARALLEL_STREAM.FN_STREAM_COUNT('VDBALUPD',
                                                              P_BRN),
                        0);
          IF N_PART = 1 THEN
          
            IF NOT ACPKSS_VDBAL.FN_BATCH_UPDATE(P_BRN, L_ERC, L_ERP) THEN
              DBG('fn_batch_update returned false');
              RETURN;
            END IF;
          
          ELSE
            FOR I IN 1 .. N_PART LOOP
            
              L_WHAT := 'BEGIN' || CHR(10);
              L_WHAT := L_WHAT || 'acpkss_vdbal.PR_UPDATE_FOR_VDBAL_SEQ (' ||
                        CHR(39) || P_BRN || CHR(39) || ',' || I || ');' ||
                        CHR(10);
              L_WHAT := L_WHAT || 'debug.pr_close_db;' || CHR(10);
              L_WHAT := L_WHAT || 'END;' || CHR(10);
            
              L_JOB_NAME := 'P_' || I ||
                            TO_CHAR(GLOBAL.APPLICATION_DATE, 'DDMMRRRR') ||
                            TO_CHAR(SYSDATE, 'HH24MISS') || 'IC' || P_BRN;
              DBG('The Job Name for VDBALUPD is ' || L_JOB_NAME);
              DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => L_JOB_NAME,
                                        JOB_TYPE   => 'PLSQL_BLOCK',
                                        JOB_ACTION => L_WHAT,
                                        
                                        REPEAT_INTERVAL => NULL,
                                        ENABLED         => TRUE,
                                        COMMENTS        => 'VDBALUPD');
            
              DBG('l_what ' || L_WHAT);
              INSERT INTO ICTB_JOB_CTL
                (BRN, PROCESS, JOB, STATUS, FUNCTION_ID)
              VALUES
                (P_BRN,
                 I
                 
                ,
                 L_JOB_NAME,
                 NULL,
                 'VDBALUPD');
              COMMIT;
            END LOOP;
            LOOP
              DBG('Looping for finish');
            
              DBMS_LOCK.SLEEP(G_SLEEP_TIMER);
              OPEN C_JOB;
              FETCH C_JOB
                INTO K;
              IF C_JOB%NOTFOUND THEN
                K := 0;
              END IF;
              CLOSE C_JOB;
              EXIT WHEN K = 0;
            END LOOP;
            BEGIN
            
              SELECT COUNT(*)
                INTO RETSTAT
                FROM ICTB_JOB_CTL
               WHERE STATUS <> 0
                 AND BRN = P_BRN
                 AND FUNCTION_ID = 'VDBALUPD';
            
            EXCEPTION
              WHEN OTHERS THEN
                RETSTAT := 999;
            END;
            IF RETSTAT <> 0 THEN
              DBG('Some Job for cust acc rebuild failed.');
            
              RETURN;
            END IF;
          
          END IF;
        
        END IF;
      
        PR_PROC_ALL(P_BRN, P_PR_LIST, P_LIQ_DT);
        ICPKSS_BOOK.PR_ACCRUAL_REVERSAL(P_BRN);
      
      ELSIF P_ACC_SEL_TYPE = 'C' THEN
        DBG('all accounts taken care of :' || ' - ' || 'Jai Hind');
      
        IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN,
                                                   MAINT_ERR_CODE,
                                                   MAINT_ERR_PARAM) THEN
          RETURN;
        END IF;
        ICPKS_UDE.PR_MAKE_UDE_ROW;
      
        IF PKG_VDBAL = 'OFFLINE' THEN
        
          DELETE ICTB_JOB_CTL
           WHERE BRN = P_BRN
             AND FUNCTION_ID = 'VDBALUPD';
          COMMIT;
        
          N_PART := NVL(CSPKS_PARALLEL_STREAM.FN_STREAM_COUNT('VDBALUPD',
                                                              P_BRN),
                        0);
          IF N_PART = 1 THEN
          
            IF NOT ACPKSS_VDBAL.FN_BATCH_UPDATE(P_BRN, L_ERC, L_ERP) THEN
              DBG('fn_batch_update returned false');
              RETURN;
            END IF;
          
          ELSE
            FOR I IN 1 .. N_PART LOOP
            
              L_WHAT := 'BEGIN' || CHR(10);
              L_WHAT := L_WHAT || 'acpkss_vdbal.PR_UPDATE_FOR_VDBAL_SEQ (' ||
                        CHR(39) || P_BRN || CHR(39) || ',' || I || ');' ||
                        CHR(10);
              L_WHAT := L_WHAT || 'debug.pr_close_db;' || CHR(10);
              L_WHAT := L_WHAT || 'END;' || CHR(10);
            
              L_JOB_NAME := 'P_' || I ||
                            TO_CHAR(GLOBAL.APPLICATION_DATE, 'DDMMRRRR') ||
                            TO_CHAR(SYSDATE, 'HH24MISS') || 'IC' || P_BRN;
              DBG('The Job Name for VDBALUPD is ' || L_JOB_NAME);
            
              DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => L_JOB_NAME,
                                        JOB_TYPE   => 'PLSQL_BLOCK',
                                        JOB_ACTION => L_WHAT,
                                        
                                        REPEAT_INTERVAL => NULL,
                                        ENABLED         => TRUE,
                                        COMMENTS        => 'VDBALUPD');
            
              DBG('l_what ' || L_WHAT);
              INSERT INTO ICTB_JOB_CTL
                (BRN, PROCESS, JOB, STATUS, FUNCTION_ID)
              VALUES
                (P_BRN,
                 I
                 
                ,
                 L_JOB_NAME,
                 NULL,
                 'VDBALUPD');
              COMMIT;
            END LOOP;
            LOOP
              DBG('Looping for finish');
            
              DBMS_LOCK.SLEEP(G_SLEEP_TIMER);
              OPEN C_JOB;
              FETCH C_JOB
                INTO K;
              IF C_JOB%NOTFOUND THEN
                K := 0;
              END IF;
              CLOSE C_JOB;
              EXIT WHEN K = 0;
            END LOOP;
            BEGIN
            
              SELECT COUNT(*)
                INTO RETSTAT
                FROM ICTB_JOB_CTL
               WHERE STATUS <> 0
                 AND BRN = P_BRN
                 AND FUNCTION_ID = 'VDBALUPD';
            
            EXCEPTION
              WHEN OTHERS THEN
                RETSTAT := 999;
            END;
            IF RETSTAT <> 0 THEN
              DBG('Some Job for cust acc rebuild failed.');
            
              RETURN;
            END IF;
          
          END IF;
        
        END IF;
      
        DBG('All accounts are liquidating...');
        LOOP
        
          PROC_ACLASS := CSPKES_MISC.FN_GETPARAM(P_ACC_LIST,
                                                 L_CURR_ITEM,
                                                 '~');
          EXIT WHEN PROC_ACLASS = 'EOPL';
          L_CURR_ITEM := L_CURR_ITEM + 1;
          DBG('This for account class ' || ' - ' || PROC_ACLASS);
          PR_PROC_ACLASS(P_BRN, PROC_ACLASS, P_LIQ_DT, P_PR_LIST);
          ICPKSS_BOOK.PR_ACCRUAL_REVERSAL(P_BRN);
          BEGIN
            PR_CALL_PROCESS(P_BRN, P_LIQ_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
              RAISE PROC_FAILED;
          END;
        END LOOP;
      
      ELSIF P_ACC_SEL_TYPE = 'G' THEN
        DBG('This condition is for ILM group wise liquidation....');
        LOOP
          PROC_ACC := CSPKES_MISC.FN_GETPARAM(P_ACC_LIST, L_CURR_ITEM, '~');
          EXIT WHEN PROC_ACC = 'EOPL';
          L_CURR_ITEM := L_CURR_ITEM + 1;
        
          DBG('This for account ' || ' - ' || PROC_ACC);
        
          G_ACC_SEL_TYPE := P_ACC_SEL_TYPE;
        
          PR_PROC_SELECTED_ACC(P_BRN, PROC_ACC, P_LIQ_DT, P_PR_LIST);
          PR_CALL_PROCESS(P_BRN, P_LIQ_DT);
        
        END LOOP;
      
      END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    DBG('Done with interest products lets see the charges');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKSS_ONLIQ_NEW_CLUSTER.PR_CALL_ICONLIQ(P_BRN,
                                               P_ACC_SEL_TYPE,
                                               P_ACC_LIST,
                                               P_PR_LIST,
                                               P_LIQ_DT,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF NOT ICPKSS_CHARGE.FN_ONLIQ_CHARGE(P_BRN,
                                           P_ACC_LIST,
                                           P_PR_LIST,
                                           P_ACC_SEL_TYPE,
                                           P_LIQ_DT,
                                           MAINT_ERR_CODE) THEN
        RETURN;
      END IF;
    
      DBG('Done with charges');
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    IF P_ACC_SEL_TYPE <> 'S' THEN
      IF NOT
          ICPKSS_ACCR_INT.FN_SET_ACC_ACCR(P_BRN, NULL, NULL, VD_ERR, VD_ERP) THEN
        DBG('icpks_accr_int.fn_set_acc_accr retured false');
        DBG('Vd Err ' || VD_ERR);
        DBG('Vd Erp ' || VD_ERP);
      
        INSERT INTO ICTBS_BOOK_ERR
          (BRN, OP, PROD, ACC, ERRM)
        VALUES
          (GLOBAL.CURRENT_BRANCH, 'B', NULL, NULL, VD_ERP);
        COMMIT;
      END IF;
    ELSE
      L_CURR_ITEM := 0;
      LOOP
        PROC_ACC := CSPKES_MISC.FN_GETPARAM(P_ACC_LIST, L_CURR_ITEM, '~');
        EXIT WHEN PROC_ACC = 'EOPL';
        L_CURR_ITEM := L_CURR_ITEM + 1;
      
        IF NOT ICPKSS_ACCR_INT.FN_SET_ACC_ACCR(P_BRN,
                                               PROC_ACC,
                                               NULL,
                                               VD_ERR,
                                               VD_ERP) THEN
          DBG('icpks_accr_int.fn_set_acc_accr retured false');
          DBG('Vd Err ' || VD_ERR);
          DBG('Vd Erp ' || VD_ERP);
        
          INSERT INTO ICTBS_BOOK_ERR
            (BRN, OP, PROD, ACC, ERRM)
          VALUES
            (GLOBAL.CURRENT_BRANCH, 'B', NULL, NULL, VD_ERP);
        
        END IF;
      END LOOP;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKSS_ONLIQ_NEW_CLUSTER.PR_CALL_ICONLIQ(P_BRN,
                                               P_ACC_SEL_TYPE,
                                               P_ACC_LIST,
                                               P_PR_LIST,
                                               P_LIQ_DT,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
    END IF;
  
    PR_RELEASE_LOCK;
  EXCEPTION
    WHEN BKCALC_BOMB THEN
      DBG('some major Haath...back calc udes gave haaaaaaaaaath');
    
      IF NOT STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN AND
         NOT STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
      
        ROLLBACK;
      END IF;
      RAISE;
    WHEN PROC_FAILED THEN
      DBG('Do process failed!!');
      PR_RELEASE_LOCK;
    
      IF NOT STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN AND
         NOT STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
      
        ROLLBACK;
      END IF;
      RAISE;
    WHEN OTHERS THEN
      DBG('Some major haaaath..' || SQLERRM);
      PR_RELEASE_LOCK;
    
      IF NOT STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN AND
         NOT STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
      
        ROLLBACK;
      END IF;
      RAISE;
  END PR_CALL_ICONLIQ;

  PROCEDURE PR_PROC_ALL(P_BRN VARCHAR2, P_PR_LIST VARCHAR2, P_LIQ_DT DATE) IS
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             NEXT_EVENT_DT,
             DEFER_LIQ_DT,
             ROWID
             
            ,
             P.SYS_AC_LEVEL,
             P.SUBLEVEL
      
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
            
         AND ((P_PR_LIST = 'ALL' AND EXISTS
              (SELECT 1
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = P.PROD
                   AND NVL(ZAKAT_PRODUCT, 'N') = 'N')) OR
             INSTR(P_PR_LIST, P.PROD || '~') != 0)
            
         AND P.PROD_TYPE IN ('I', 'P')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
         AND NVL(STOP_IC, 'N') = 'N'
            
         AND NOT EXISTS (SELECT PRODUCT_CODE
                FROM ICTMS_PR_INT
               WHERE PRODUCT_CODE = P.PROD
                 AND IL_PRODUCT = 'Y')
      UNION
      SELECT P.BRN,
             P.ACC,
             P.PROD,
             P.SC_MAP_DT,
             P.GC_MAP_DT,
             P.LAST_CALC_DT,
             P.LAST_LIQ_DT,
             P.NEXT_LIQ_DT,
             P.LAST_ACCR_DT,
             P.NEXT_ACCR_DT,
             P.LAST_SCHD_LIQ_DT,
             P.INC_MTH,
             P.NEXT_SCHD_LIQ_DT,
             P.FIRST_CALC_DT,
             P.NEXT_SCHD_ACCR_DT,
             P.PROD_TYPE,
             P.HAS_ACCR,
             P.NEXT_CALC_DT,
             P.PROD_ACCR,
             P.HAS_PROBLEMS,
             P.BKVAL_MINCALC_DATE,
             P.BKVAL_RECALC_FLAG,
             P.FIRST_FIRST_CALC_DATE,
             
             IMAT_PROBLEMS,
             DEPOSIT,
             
             P.ACLASS,
             P.CCY,
             P.NEXT_EVENT_DT,
             
             DEFER_LIQ_DT,
             
             P.ROWID,
             
             P.SYS_AC_LEVEL,
             P.SUBLEVEL
        FROM ICTBS_ACC_PR P, ILTB_SYS_ACCOUNT A, ICTMS_PR_INT C
       WHERE (P.BRN = P_BRN OR A.SYSTEM_ACCOUNT_BRANCH = P_BRN OR
             A.BRANCH_CODE = P_BRN)
         AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
         AND P.PROD_TYPE IN ('I', 'P')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND
            
             NVL(HAS_PROBLEMS, 'N') <> 'Y'
         AND NVL(P.STOP_IC, 'N') = 'N'
         AND C.PRODUCT_CODE = P.PROD
         AND C.IL_PRODUCT = 'Y'
            
         AND A.SYSTEM_ACCOUNT_BRANCH = P.BRN
         AND A.SYSTEM_ACCOUNT = P.ACC
      
       ORDER BY NEXT_LIQ_DT;
  
    VD_ERR     VARCHAR2(1000);
    VD_EPAR    VARCHAR2(1000);
    RECNO      NUMBER := 0;
    FLEX       NUMBER := 0;
    LAST_RECNO NUMBER := 0;
    L_ACC      STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN      STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS   STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY      STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD     ICTBS_ACC_PR.PROD%TYPE;
    J          NUMBER := 0;
    VDBAL_UPD_BOMB EXCEPTION;
    L_PROB_ACC  BOOLEAN := FALSE;
    L_PROB_PROD BOOLEAN := FALSE;
    MAINT_ERR   VARCHAR2(100);
    MAINT_ERRP  VARCHAR2(1000);
    NOPROCESS EXCEPTION;
  
    PROC_FAILED EXCEPTION;
  
  BEGIN
    DBG('Inside proc all');
    OPEN CUR_ACCPR;
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID
             
            ,
             ICPKSS_TEST.TB_SYS_AC_LEVEL,
             ICPKSS_TEST.TB_SUBLEVEL
             
             LIMIT L_COMMIT_FREQ;
    
      IF NVL(ICPKS_TEST.TB_ACC.COUNT, 0) = 0 THEN
        RAISE NOPROCESS;
      END IF;
    
      FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
      END LOOP;
    
      FOR J IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(J),
                                         ICPKS_TEST.TB_ACC(J),
                                         ICPKS_TEST.TB_CCY(J),
                                         VD_ERR,
                                         VD_EPAR) THEN
          DBG('Bombed in update log this and delete the same');
          PR_DELETE_ACCPR_ROW(RECNO);
        END IF;
      END LOOP;
    
      IF NOT
          ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN, MAINT_ERR, MAINT_ERRP) THEN
        RETURN;
      END IF;
    
      IF ILPKSS_SERVICES.FN_RESOLVE_NEW_IL_PROD(P_BRN, NULL, NULL) THEN
        NULL;
      
      END IF;
    
      DBG('VD bal update is done and we have ' ||
          NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
      RECNO := ICPKS_TEST.TB_ROWID.FIRST;
      WHILE RECNO <= ICPKS_TEST.TB_ROWID.LAST LOOP
        IF NVL(L_ACC, '***') <> NVL(ICPKS_TEST.TB_ACC(RECNO), '####') OR
           NVL(L_BRN, '***') <> NVL(ICPKS_TEST.TB_BRN(RECNO), '####') THEN
          L_PROB_ACC := FALSE;
          IF NOT FN_CHK_ICACC(RECNO) THEN
            DBG('Problem with the account');
            L_PROB_ACC := TRUE;
            PR_DELETE_ACCPR_ROW(RECNO);
          END IF;
        ELSE
          IF NOT L_PROB_ACC THEN
            TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
            TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
          END IF;
        END IF;
        IF NOT L_PROB_ACC THEN
          DBG('acconut seems OK this case' || L_PROD || ' - ' ||
              ICPKS_TEST.TB_ACC(RECNO));
        
          IF NVL(L_PROD, '^^^^') <> NVL(ICPKS_TEST.TB_PROD(RECNO), '****') THEN
          
            DBG('bofore fn_chk_prod 1');
            IF NOT FN_CHK_PROD(RECNO) THEN
              DBG('Product is invalid');
              PR_DELETE_ACCPR_ROW(RECNO);
            END IF;
          END IF;
        END IF;
        L_ACC  := ICPKS_TEST.TB_ACC(RECNO);
        L_BRN  := ICPKS_TEST.TB_BRN(RECNO);
        L_PROD := ICPKS_TEST.TB_PROD(RECNO);
        RECNO  := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
      END LOOP;
    
      DBG('SVS COUNT HERE IS ' || ICPKS_TEST.TB_ACC.COUNT);
      IF NVL(ICPKS_TEST.TB_ACC.COUNT, 0) <> 0 THEN
        BEGIN
          PR_CALL_PROCESS(P_BRN, P_LIQ_DT);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE PROC_FAILED;
        END;
      END IF;
    
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
  EXCEPTION
    WHEN NOPROCESS THEN
      DBG('no accounts to process');
    WHEN VDBAL_UPD_BOMB THEN
      DBG('Failed in vd bal update' || VD_ERR || ' - ' || VD_EPAR);
      RAISE;
    
    WHEN PROC_FAILED THEN
      DBG('Do process failed!!');
      IF ICPKS_BOD.G_FROMBOD THEN
        DBG('This is from BOD..let us not rollback here');
      ELSE
        ROLLBACK;
      END IF;
      RAISE;
    
    WHEN OTHERS THEN
      DBG('In when others then ' || ' - ' || SQLERRM);
      RAISE;
  END PR_PROC_ALL;

  PROCEDURE PR_PROC_SELECTED_ACC(P_BRN      VARCHAR2,
                                 P_ACC_LIST VARCHAR2,
                                 P_LIQ_DT   DATE,
                                 P_PR_LIST  VARCHAR2) IS
  
    TYPE T IS REF CURSOR;
    CUR_ACCPR T;
  
    RECNO          BINARY_INTEGER;
    L_ACC          STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN          STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS       STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY          STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD         ICTBS_ACC_PR.PROD%TYPE;
    L_PROB_PROD    BOOLEAN := FALSE;
    L_PROB_ACC     BOOLEAN := FALSE;
    VD_ERR         VARCHAR2(1000);
    VD_PERR        VARCHAR2(1000);
    L_DEFERRED_FLG ICTMS_PR_INT.DEFERRED_FLAG%TYPE;
    L_ACCOUNT_TYPE STTM_CUST_ACCOUNT.ACCOUNT_TYPE%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside pr proc selected acc');
  
    IF ICPKS_BOD.G_FROMBOD THEN
      DBG('Icpks_bod.G_FromBOD is TRUE');
    ELSE
      DBG('Icpks_bod.G_FromBOD is FALSE');
    END IF;
  
    DBG('Open the cursor with..' || ' - ' || P_ACC_LIST);
  
    BEGIN
      SELECT NVL(DEFERRED_FLAG, 'N')
        INTO L_DEFERRED_FLG
        FROM ICTMS_PR_INT
       WHERE PRODUCT_CODE = SUBSTR(P_PR_LIST, 1, 4);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Not able to select the Deferred_Flag :: ' || SQLERRM);
        L_DEFERRED_FLG := 'N';
    END;
    DBG('l_Deferred_Flg: ' || L_DEFERRED_FLG);
    DBG('Icpks_Test.Tb_Rowid.count: ' || ICPKS_TEST.TB_ROWID.COUNT);
    DBG('p_Brn: ' || P_BRN || ' p_Acc_List: ' || P_ACC_LIST ||
        ' p_Pr_List: ' || P_PR_LIST);
    DBG('p_Liq_Dt: ' || P_LIQ_DT || ' global.application_date: ' ||
        GLOBAL.APPLICATION_DATE);
  
    BEGIN
      SELECT ACCOUNT_TYPE
        INTO L_ACCOUNT_TYPE
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC_LIST;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('l_account_type could not be found');
    END;
    DBG('l_account_type for ' || P_BRN || '~' || P_ACC_LIST || '~' ||
        L_ACCOUNT_TYPE);
  
    DBG('uclaimed process from bod :' || ICPKS_BOD.UNCLAIMED_PROCESS);
  
    IF NVL(ICPKS_BOD.UNCLAIMED_PROCESS, 'Y') = 'N' THEN
      DBG('INside unclaimed N .. unclaimed case');
      OPEN CUR_ACCPR FOR
        SELECT BRN,
               ACC,
               PROD,
               SC_MAP_DT,
               GC_MAP_DT,
               LAST_CALC_DT,
               LAST_LIQ_DT,
               NEXT_LIQ_DT,
               LAST_ACCR_DT,
               NEXT_ACCR_DT,
               LAST_SCHD_LIQ_DT,
               INC_MTH,
               NEXT_SCHD_LIQ_DT,
               FIRST_CALC_DT,
               NEXT_SCHD_ACCR_DT,
               PROD_TYPE,
               HAS_ACCR,
               NEXT_CALC_DT,
               PROD_ACCR,
               HAS_PROBLEMS,
               BKVAL_MINCALC_DATE,
               BKVAL_RECALC_FLAG,
               FIRST_FIRST_CALC_DATE,
               IMAT_PROBLEMS,
               DEPOSIT,
               ACLASS,
               CCY,
               
               NEXT_EVENT_DT,
               NEXT_LIQ_DT,
               ROWID
               
              ,
               NULL,
               NULL
        
          FROM ICTW_ACCPR_SEL P
         WHERE P.BRN = P_BRN
           AND P.ACC = P_ACC_LIST
              
           AND ((P_PR_LIST = 'ALL'
               
               AND ((L_ACCOUNT_TYPE = 'Y') OR
               (L_ACCOUNT_TYPE <> 'Y'
               
               AND EXISTS
                (SELECT 1
                          FROM ICTMS_PR_INT
                         WHERE PRODUCT_CODE = P.PROD
                           AND NVL(ZAKAT_PRODUCT, 'N') = 'N')))) OR
               INSTR(P_PR_LIST, P.PROD || '~') != 0)
              
           AND P.PROD_TYPE IN ('I', 'P')
              
           AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
           AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
           AND NVL(STOP_IC, 'N') = 'Y'
         ORDER BY P.NEXT_LIQ_DT;
    
    ELSE
      DBG('Inside unclaimed Y ... not for unclaimed ');
      OPEN CUR_ACCPR FOR
        SELECT BRN,
               ACC,
               PROD,
               SC_MAP_DT,
               GC_MAP_DT,
               LAST_CALC_DT,
               LAST_LIQ_DT,
               NEXT_LIQ_DT,
               LAST_ACCR_DT,
               NEXT_ACCR_DT,
               LAST_SCHD_LIQ_DT,
               INC_MTH,
               NEXT_SCHD_LIQ_DT,
               FIRST_CALC_DT,
               NEXT_SCHD_ACCR_DT,
               PROD_TYPE,
               HAS_ACCR,
               NEXT_CALC_DT,
               PROD_ACCR,
               HAS_PROBLEMS,
               BKVAL_MINCALC_DATE,
               BKVAL_RECALC_FLAG,
               FIRST_FIRST_CALC_DATE,
               IMAT_PROBLEMS,
               DEPOSIT,
               ACLASS,
               CCY,
               
               NEXT_EVENT_DT,
               DEFER_LIQ_DT,
               ROWID
               
              ,
               SYS_AC_LEVEL,
               SUBLEVEL
        
          FROM ICTBS_ACC_PR P
         WHERE P.BRN = P_BRN
           AND P.ACC = P_ACC_LIST
              
           AND ((P_PR_LIST = 'ALL'
               
               AND ((L_ACCOUNT_TYPE = 'Y') OR
               (L_ACCOUNT_TYPE <> 'Y'
               
               AND EXISTS
                (SELECT 1
                          FROM ICTMS_PR_INT
                         WHERE PRODUCT_CODE = P.PROD
                           AND NVL(ZAKAT_PRODUCT, 'N') = 'N')))) OR
               INSTR(P_PR_LIST, P.PROD || '~') != 0)
              
           AND P.PROD_TYPE IN ('I', 'P')
              
           AND ((NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT) OR
               (NVL(P.LAST_LIQ_DT, SYSDATE - 1000) = P_LIQ_DT AND
               L_DEFERRED_FLG = 'Y' AND
               P.DEFER_LIQ_DT <= GLOBAL.APPLICATION_DATE AND
               P.DEFER_LIQ_DT > P.LAST_LIQ_DT))
              
           AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
           AND NVL(STOP_IC, 'N') = 'N'
              
           AND NOT EXISTS (SELECT *
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = P.PROD
                   AND IL_PRODUCT = 'Y')
        
        UNION
        SELECT P.BRN,
               P.ACC,
               P.PROD,
               P.SC_MAP_DT,
               P.GC_MAP_DT,
               P.LAST_CALC_DT,
               P.LAST_LIQ_DT,
               P.NEXT_LIQ_DT,
               P.LAST_ACCR_DT,
               P.NEXT_ACCR_DT,
               P.LAST_SCHD_LIQ_DT,
               P.INC_MTH,
               P.NEXT_SCHD_LIQ_DT,
               P.FIRST_CALC_DT,
               P.NEXT_SCHD_ACCR_DT,
               P.PROD_TYPE,
               P.HAS_ACCR,
               P.NEXT_CALC_DT,
               P.PROD_ACCR,
               P.HAS_PROBLEMS,
               P.BKVAL_MINCALC_DATE,
               P.BKVAL_RECALC_FLAG,
               P.FIRST_FIRST_CALC_DATE,
               
               IMAT_PROBLEMS,
               DEPOSIT,
               
               P.ACLASS,
               P.CCY,
               P.NEXT_EVENT_DT,
               
               DEFER_LIQ_DT,
               
               P.ROWID,
               
               P.SYS_AC_LEVEL,
               P.SUBLEVEL
          FROM ICTBS_ACC_PR        P,
               ILTBS_SYS_ACCOUNT   B,
               STTMS_ACCOUNT_CLASS C,
               ICTMS_PR_INT        D
         WHERE P.BRN = P_BRN
              
           AND B.SYSTEM_ACCOUNT_BRANCH = P.BRN
           AND B.SYSTEM_ACCOUNT = P_ACC_LIST
           AND B.SYSTEM_ACCOUNT = P.ACC
              
           AND C.ACCOUNT_CLASS = P.ACLASS
           AND NVL(C.ILM_APPLICABLE, 'N') = 'Y'
           AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
           AND P.PROD_TYPE IN ('I', 'P')
           AND D.PRODUCT_CODE = P.PROD
              
           AND D.IL_PRODUCT = 'Y'
              
           AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
           AND
              
               NVL(HAS_PROBLEMS, 'N') <> 'Y'
           AND NVL(P.STOP_IC, 'N') = 'N'
        
         ORDER BY SYS_AC_LEVEL, SUBLEVEL, NEXT_LIQ_DT;
    
    END IF;
  
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID
             
            ,
             ICPKSS_TEST.TB_SYS_AC_LEVEL,
             ICPKSS_TEST.TB_SUBLEVEL
             
             LIMIT L_COMMIT_FREQ;
      DBG('After bulk collect');
    
      IF NVL(ICPKSS_TEST.TB_ROWID.COUNT, 0) <> 0 THEN
        FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
          ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
        END LOOP;
      
        RECNO := ICPKSS_TEST.TB_ROWID.FIRST;
        WHILE RECNO <= ICPKSS_TEST.TB_ROWID.LAST LOOP
          BEGIN
            DBG('RecNo = ' || RECNO);
            DBG('Product in loop is ' || ICPKS_TEST.TB_PROD(RECNO));
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('MISSING PRODUCT WILL BOIMB');
          END;
        
          IF NOT
              ILPKSS_SERVICES.FN_RESOLVE_NEW_IL_PROD(ICPKSS_TEST.TB_BRN(RECNO),
                                                     ICPKSS_TEST.TB_ACC(RECNO),
                                                     ICPKSS_TEST.TB_PROD(RECNO)) THEN
            DBG('Error in doing resolution for il products ');
          END IF;
        
          IF NVL(L_ACC, '***') <> ICPKS_TEST.TB_ACC(RECNO) OR
             NVL(L_BRN, '***') <> ICPKS_TEST.TB_BRN(RECNO) THEN
            L_PROB_ACC := FALSE;
            IF NOT FN_CHK_ICACC(RECNO) THEN
              DBG('Problem with the account');
              L_PROB_ACC := TRUE;
              PR_DELETE_ACCPR_ROW(RECNO);
            ELSE
            
              IF NOT ICPKS_BOD.G_FROMBOD THEN
              
                DBG('You will see this only in EOD and NOT IN BOD');
              
                IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(ICPKSS_TEST.TB_BRN(RECNO),
                                                           ICPKSS_TEST.TB_ACC(RECNO),
                                                           VD_ERR,
                                                           VD_PERR) THEN
                  NULL;
                END IF;
              
                DBG('Purush !!!!');
              
                IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(RECNO),
                                                 ICPKS_TEST.TB_ACC(RECNO),
                                                 ICPKS_TEST.TB_CCY(RECNO),
                                                 VD_ERR,
                                                 VD_PERR) THEN
                  DBG('Bombed in update log this and delete the same');
                  PR_DELETE_ACCPR_ROW(RECNO);
                END IF;
              END IF;
            
            END IF;
          ELSE
            IF NOT L_PROB_ACC THEN
              TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
              TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
            END IF;
          END IF;
          DBG('Ramesh -' || RECNO || ' - ' || L_PROD);
          IF NOT L_PROB_ACC THEN
            DBG('No problem with account lets check the product' || L_PROD || '--' ||
                ICPKS_TEST.TB_PROD(RECNO));
          
            IF NVL(L_PROD, '%%%%') <>
               NVL(ICPKS_TEST.TB_PROD(RECNO), '****') THEN
            
              L_PROB_PROD := FALSE;
              DBG('before calling fn_chk_prod 2');
              IF NOT FN_CHK_PROD(RECNO) THEN
                DBG('Product is invalid');
                PR_DELETE_ACCPR_ROW(RECNO);
                L_PROB_PROD := TRUE;
              END IF;
            END IF;
          END IF;
        
          RECNO := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
        END LOOP;
      END IF;
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
    DBG('Just before leaving we have...' ||
        NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKS_ONLIQ_NEW_CLUSTER.PR_PROC_SELECTED_ACC(P_BRN,
                                                   P_ACC_LIST,
                                                   P_LIQ_DT,
                                                   P_PR_LIST,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA);
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Problems with selected acc.' || ' - ' || SQLERRM);
      RAISE;
  END PR_PROC_SELECTED_ACC;

  PROCEDURE PR_PROC_ACLASS(P_BRN     VARCHAR2,
                           P_ACLASS  VARCHAR2,
                           P_LIQ_DT  DATE,
                           P_PR_LIST VARCHAR2) IS
  
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             
             NEXT_EVENT_DT,
             DEFER_LIQ_DT,
             ROWID
             
            ,
             P.SYS_AC_LEVEL,
             P.SUBLEVEL
      
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
         AND P.ACLASS = P_ACLASS
            
         AND ((P_PR_LIST = 'ALL' AND EXISTS
              (SELECT 1
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = P.PROD
                   AND NVL(ZAKAT_PRODUCT, 'N') = 'N')) OR
             INSTR(P_PR_LIST, P.PROD || '~') != 0)
            
         AND P.PROD_TYPE IN ('I', 'P')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
         AND NVL(STOP_IC, 'N') = 'N'
            
         AND NOT EXISTS (SELECT *
                FROM ICTMS_PR_INT
               WHERE PRODUCT_CODE = P.PROD
                 AND IL_PRODUCT = 'Y')
      UNION
      SELECT P.BRN,
             P.ACC,
             P.PROD,
             P.SC_MAP_DT,
             P.GC_MAP_DT,
             P.LAST_CALC_DT,
             P.LAST_LIQ_DT,
             P.NEXT_LIQ_DT,
             P.LAST_ACCR_DT,
             P.NEXT_ACCR_DT,
             P.LAST_SCHD_LIQ_DT,
             P.INC_MTH,
             P.NEXT_SCHD_LIQ_DT,
             P.FIRST_CALC_DT,
             P.NEXT_SCHD_ACCR_DT,
             P.PROD_TYPE,
             P.HAS_ACCR,
             P.NEXT_CALC_DT,
             P.PROD_ACCR,
             P.HAS_PROBLEMS,
             P.BKVAL_MINCALC_DATE,
             P.BKVAL_RECALC_FLAG,
             P.FIRST_FIRST_CALC_DATE,
             
             IMAT_PROBLEMS,
             DEPOSIT,
             
             P.ACLASS,
             P.CCY,
             P.NEXT_EVENT_DT,
             
             DEFER_LIQ_DT,
             
             P.ROWID,
             
             P.SYS_AC_LEVEL,
             P.SUBLEVEL
        FROM ICTBS_ACC_PR P, ILTBS_SYS_ACCOUNT A, ICTMS_PR_INT C
       WHERE P.BRN = P_BRN
         AND P.ACLASS = P_ACLASS
         AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
         AND P.PROD_TYPE IN ('I', 'P')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND
            
             NVL(HAS_PROBLEMS, 'N') <> 'Y'
         AND NVL(P.STOP_IC, 'N') = 'N'
         AND C.PRODUCT_CODE = P.PROD
         AND C.IL_PRODUCT = 'Y'
      
       ORDER BY NEXT_LIQ_DT;
    RECNO       BINARY_INTEGER;
    L_ACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN       STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS    STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY       STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD      ICTBS_ACC_PR.PROD%TYPE;
    L_PROB_PROD BOOLEAN := FALSE;
    L_PROB_ACC  BOOLEAN := FALSE;
    VD_ERR      VARCHAR2(1000);
    VD_PERR     VARCHAR2(1000);
  
    L_ACCOUNT STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
  BEGIN
    DBG('Open the cursor for account class' || ' - ' || P_ACLASS);
    OPEN CUR_ACCPR;
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID
             
            ,
             ICPKSS_TEST.TB_SYS_AC_LEVEL,
             ICPKSS_TEST.TB_SUBLEVEL
             
             LIMIT L_COMMIT_FREQ;
      DBG('After bulk collect');
    
      IF NVL(ICPKS_TEST.TB_ROWID.COUNT, 0) <> 0 THEN
        FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
          ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
        END LOOP;
      END IF;
    
      RECNO := ICPKSS_TEST.TB_ROWID.FIRST;
      WHILE RECNO <= ICPKSS_TEST.TB_ROWID.LAST LOOP
      
        IF ICPKSS_TEST.TB_SYS_AC_LEVEL(RECNO) IS NOT NULL THEN
          BEGIN
            SELECT ACCOUNT
              INTO L_ACCOUNT
              FROM ILTBS_SYS_ACCOUNT
             WHERE SYSTEM_ACCOUNT_BRANCH = ICPKSS_TEST.TB_BRN(RECNO)
               AND SYSTEM_ACCOUNT = ICPKSS_TEST.TB_ACC(RECNO);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_ACCOUNT := NULL;
          END;
        
          IF L_ACCOUNT IS NOT NULL THEN
            ICPKSS_RESOLVE_MAINT.PR_RESOLVE_IL(ICPKSS_TEST.TB_BRN(RECNO),
                                               L_ACCOUNT,
                                               ICPKSS_TEST.TB_PROD(RECNO),
                                               ICPKSS_TEST.TB_ACC(RECNO),
                                               GLOBAL.APPLICATION_DATE);
          END IF;
        END IF;
      
        IF NVL(L_ACC, '***') <> ICPKS_TEST.TB_ACC(RECNO) OR
           NVL(L_BRN, '***') <> ICPKS_TEST.TB_BRN(RECNO) THEN
          L_ACC      := ICPKS_TEST.TB_ACC(RECNO);
          L_BRN      := ICPKS_TEST.TB_BRN(RECNO);
          L_PROB_ACC := FALSE;
          IF NOT FN_CHK_ICACC(RECNO) THEN
            DBG('Problem with the account');
            L_PROB_ACC := TRUE;
            PR_DELETE_ACCPR_ROW(RECNO);
          ELSE
          
            IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(RECNO),
                                             ICPKS_TEST.TB_ACC(RECNO),
                                             ICPKS_TEST.TB_CCY(RECNO),
                                             VD_ERR,
                                             VD_PERR) THEN
              DBG('Bombed in update log this and delete the same');
              PR_DELETE_ACCPR_ROW(RECNO);
            END IF;
          END IF;
        ELSE
          IF NOT L_PROB_ACC THEN
            TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
            TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
          END IF;
        END IF;
      
        IF NOT L_PROB_ACC THEN
          DBG('No problem with account lets check the product---' ||
              L_PROD || '--' || ICPKS_TEST.TB_PROD(RECNO));
        
          IF NVL(L_PROD, '%%%%') <> NVL(ICPKS_TEST.TB_PROD(RECNO), '****') THEN
          
            DBG('Will Now Check for ' || ICPKS_TEST.TB_PROD(RECNO));
            L_PROD      := ICPKS_TEST.TB_PROD(RECNO);
            L_PROB_PROD := FALSE;
            DBG('here before fn_chk_prod 3');
            IF NOT FN_CHK_PROD(RECNO) THEN
              DBG('Product is invalid');
              PR_DELETE_ACCPR_ROW(RECNO);
              L_PROB_PROD := TRUE;
            END IF;
          END IF;
        END IF;
        RECNO := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
      END LOOP;
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
    DBG('Just before leaving we have...' ||
        NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Problems with selected aclass.' || ' - ' || SQLERRM);
  END PR_PROC_ACLASS;

  PROCEDURE PR_LOG_BOOK_ERR(P_ROWNUM NUMBER,
                            P_OP     ICTBS_BOOK_ERR.OP%TYPE,
                            P_ERRM   ICTBS_BOOK_ERR.ERRM%TYPE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('Going to insert into ictbs_book_err');
    INSERT INTO ICTBS_BOOK_ERR
      (BRN, OP, PROD, ACC, ERRM)
    VALUES
      (ICPKS_TEST.TB_BRN(P_ROWNUM),
       P_OP,
       ICPKS_TEST.TB_PROD(P_ROWNUM),
       ICPKS_TEST.TB_ACC(P_ROWNUM),
       P_ERRM);
  
    IF G_REFERENCE_NO IS NOT NULL THEN
      INSERT INTO ICTB_ONLIQ_DETAILS
      VALUES
        (G_REFERENCE_NO,
         ICPKS_TEST.TB_BRN(P_ROWNUM),
         ICPKS_TEST.TB_ACC(P_ROWNUM),
         ICPKS_TEST.TB_PROD(P_ROWNUM),
         P_ERRM);
    END IF;
  
    COMMIT;
    DBG('Booking Err for OP-> ' || P_OP || ' ACC-> ' ||
        ICPKS_TEST.TB_ACC(P_ROWNUM) || ' PROD-> ' ||
        ICPKS_TEST.TB_PROD(P_ROWNUM));
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of pr_log_book_err ' || SQLERRM);
  END PR_LOG_BOOK_ERR;

  PROCEDURE PR_PURGE_PLSQL_TABS IS
  BEGIN
    DBG('Going to Delete the problematic plsql tables');
    ICPKS_TEST.TB_ICENT_HIST_BRN.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_CURACCR_LCY.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ACC.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_PROD.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_FRM_NO.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_AMT.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_RUN_DATE.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ACCR.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_LIQN.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ENTRY_TYPE.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_CCY.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_LCY_AMT.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_LAST_CUR_ACCR.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ENTRY_PASSED.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_UPD.DELETE;
    ICPKS_TEST.TB_ICENT_HIST_ADJ.DELETE;
    ICPKS_TEST.TB_ICENT.DELETE;
    DBG('Successfully came out of pr_purge_plsql_tables');
  END PR_PURGE_PLSQL_TABS;

  PROCEDURE PR_CALL_PROCESS(P_BRN VARCHAR2, P_LIQ_DT DATE) IS
    L_ACC    ICTBS_ACC_PR.ACC%TYPE;
    L_BRN    ICTBS_ACC_PR.BRN%TYPE;
    RECNO    BINARY_INTEGER;
    L_DUE_DT DATE;
    ERRMSG   VARCHAR2(1000);
    EPRM     VARCHAR2(1000);
    VD_ERR   VARCHAR2(100);
    VD_PAR   VARCHAR2(1000);
    VDBAL_UPD_BOMB EXCEPTION;
    BKVAL_BOMBED   EXCEPTION;
  
    DO_PROCESS   EXCEPTION;
    ACTNG_FAILED EXCEPTION;
  
    H BINARY_INTEGER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    RECORD         BINARY_INTEGER;
    L_NOTHING_TODO BOOLEAN := FALSE;
    BUGTEST1       BINARY_INTEGER;
    L_PAY_MTHD     VARCHAR2(1);
    L_TB_PRODUCT   ICTMS_ACC_PR.PROD%TYPE;
  
    L_TB_HOFF_CONS  ACPKSS.TBL_ACHOFF;
    L_SEQ           BINARY_INTEGER;
    L_RECORD_COUNT  NUMBER;
    L_NOTHING_TODO1 BOOLEAN := FALSE;
  
    L_DEFERRED_FLG ICTMS_PR_INT.DEFERRED_FLAG%TYPE;
  
    L_ERR_TYPE ERTBS_MSGS.TYPE%TYPE;
  
    L_PREV_MONTH    NUMBER;
    L_CURRENT_MONTH NUMBER;
    L_PREV_YEAR     NUMBER;
    L_CURRENT_YEAR  NUMBER;
  
    PROCEDURE PR_SPLIT_INT_PAYOUT IS
    
      L_CNT          NUMBER := 0;
      J              NUMBER := 0;
      L_INT_TOLIQ    NUMBER(22, 3) := 0;
      L_ERRCODE      VARCHAR2(10);
      L_ERRMSG       VARCHAR2(150);
      L_TDPAYOUT_REC ICTM_TDPAYOUT_DETAILS%ROWTYPE;
      L_TOTALAMT     NUMBER(22, 3) := 0;
      G_LCY          CYTMS_CCY_DEFN.CCY_CODE%TYPE := GLOBAL.LCY;
      FCYAMT         NUMBER;
      EXRATE         NUMBER;
      L_TB_HOFF_CONS ACTBS_HANDOFF%ROWTYPE;
      LCYAMT         NUMBER;
    
      CURSOR CR_TDPAYOUT_REC(P_ACCOUNT VARCHAR2,
                             P_BRANCH  VARCHAR2,
                             P_CCY     VARCHAR2) IS
        SELECT *
          FROM ICTMS_TDPAYOUT_DETAILS
         WHERE ACC = P_ACCOUNT
           AND BRN = P_BRANCH
           AND CCY = P_CCY
           AND NVL(PAYOUT_COMPONENT, 'P') = 'I'
         ORDER BY SEQNO;
    
    BEGIN
      DBG('Inside Pr_split_int_payout');
      ICPKS_BOD.G_PAYOUT_COMPONENT := NULL;
      SELECT COUNT(*)
        INTO L_CNT
        FROM ICTMS_TDPAYOUT_DETAILS
       WHERE ACC = ICPKS_TEST.TB_ACC(RECNO)
         AND BRN = ICPKS_TEST.TB_BRN(RECNO)
         AND CCY = ICPKS_TEST.TB_CCY(RECNO)
         AND NVL(PAYOUT_COMPONENT, 'P') = 'I';
      DBG('Rowcount for ictm_tdpayout_details :' || L_CNT);
    
      IF L_CNT > 0 THEN
        ICPKS_BOD.G_PAYOUT_COMPONENT := 'I';
        DBG('separate the liqn amt based on the payout details given ');
        DBG('looping for TD Payouts');
        DBG('icpks_bod.pkg_ictm_acc.book_acc : ' ||
            ICPKS_BOD.PKG_ICTM_ACC.BOOK_ACC);
      
        IF ICPKS_TEST.TB_HOFF_CONS.COUNT > 0 THEN
          FOR I IN ICPKS_TEST.TB_HOFF_CONS.FIRST .. ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
          
            IF ICPKS_TEST.TB_HOFF_CONS(I)
             .EVENT = 'ILIQ' AND ICPKS_TEST.TB_HOFF_CONS(I)
               .AC_NO =
                NVL(ICPKS_BOD.PKG_ICTM_ACC.BOOK_ACC, TB_ICTM_ACC(1).BOOK_ACC) THEN
            
              DBG('lcy_amount-->' || ICPKS_TEST.TB_HOFF_CONS(I).LCY_AMOUNT);
              DBG('Fcy_amount-->' || ICPKS_TEST.TB_HOFF_CONS(I).FCY_AMOUNT);
              DBG('DRCR IND-->' || ICPKS_TEST.TB_HOFF_CONS(I).DRCR_IND);
            
              IF ICPKS_TEST.TB_HOFF_CONS(I).AC_CCY = G_LCY THEN
                IF ICPKS_TEST.TB_HOFF_CONS(I).DRCR_IND = 'C' THEN
                  L_INT_TOLIQ := L_INT_TOLIQ + ICPKS_TEST.TB_HOFF_CONS(I)
                                .LCY_AMOUNT;
                ELSE
                  L_INT_TOLIQ := L_INT_TOLIQ - ICPKS_TEST.TB_HOFF_CONS(I)
                                .LCY_AMOUNT;
                END IF;
              
              ELSE
                IF ICPKS_TEST.TB_HOFF_CONS(I).DRCR_IND = 'C' THEN
                  L_INT_TOLIQ := L_INT_TOLIQ + ICPKS_TEST.TB_HOFF_CONS(I)
                                .FCY_AMOUNT;
                ELSE
                  L_INT_TOLIQ := L_INT_TOLIQ - ICPKS_TEST.TB_HOFF_CONS(I)
                                .FCY_AMOUNT;
                END IF;
              END IF;
            
              IF ICPKS_TEST.TB_HOFF_CONS(I).DRCR_IND = 'C' THEN
                L_TB_HOFF_CONS := ICPKS_TEST.TB_HOFF_CONS(I);
              END IF;
            
            END IF;
          END LOOP;
          ICPKS_TEST.TB_HOFF_CONS.DELETE;
        END IF;
      
        IF L_INT_TOLIQ > 0 THEN
        
          FOR L_TDPAYOUT_REC IN CR_TDPAYOUT_REC(ICPKS_TEST.TB_ACC(RECNO),
                                                ICPKS_TEST.TB_BRN(RECNO),
                                                ICPKS_TEST.TB_CCY(RECNO)) LOOP
          
            EXRATE := NULL;
            FCYAMT := NULL;
            LCYAMT := NULL;
          
            DBG('TD payout type -> ' || L_TDPAYOUT_REC.PAYOUTTYPE);
            DBG('l_cnt is :' || L_CNT);
            DBG('l_totalamt is  :' || L_TOTALAMT);
            DBG('l_int_toliq-->' || L_INT_TOLIQ);
          
            IF NOT ICPKS_BOD.FN_GETTDPAYOUT_OFSDET(L_TDPAYOUT_REC,
                                                   L_ERRCODE,
                                                   ERRMSG) THEN
              DBG('fn_gettdpayout_ofsdet failes with following error msgs ' ||
                  ERRMSG);
              RAISE ACTNG_FAILED;
            END IF;
          
            IF (L_CNT = 1) THEN
              L_TDPAYOUT_REC.REDMAMT := (L_INT_TOLIQ - L_TOTALAMT);
              DBG('l_tdpayout_rec.redmamt for l_cnt 1 is  :' ||
                  L_TDPAYOUT_REC.REDMAMT);
            ELSE
              L_TDPAYOUT_REC.REDMAMT := (L_INT_TOLIQ *
                                        L_TDPAYOUT_REC.PERCENTAGE) / 100;
            
              IF NOT CYPKSS.FN_AMT_ROUND(L_TB_HOFF_CONS.AC_CCY,
                                         L_TDPAYOUT_REC.REDMAMT,
                                         L_TDPAYOUT_REC.REDMAMT) THEN
                DEBUG.PR_DEBUG('CG',
                               'failed in cypkss.fn_amt_round for l_tdpayout_rec.redmamt');
                RAISE ACTNG_FAILED;
              END IF;
            
              L_TOTALAMT := L_TOTALAMT + L_TDPAYOUT_REC.REDMAMT;
              DBG('l_totalamt is  :' || L_TOTALAMT);
              DBG('l_tdpayout_rec.redmamt for else is  :' ||
                  L_TDPAYOUT_REC.REDMAMT);
            END IF;
          
            DBG('td payout redmamt after rounding: ' ||
                L_TDPAYOUT_REC.REDMAMT);
          
            IF L_TDPAYOUT_REC.OFFSET_CCY IS NULL THEN
              L_TDPAYOUT_REC.OFFSET_CCY := ICPKS_TEST.TB_CCY(RECNO);
              L_TDPAYOUT_REC.OFFSET_BRN := GLOBAL.CURRENT_BRANCH;
            END IF;
          
            DBG('Defauling TD Payouts' || L_TDPAYOUT_REC.PAYOUTTYPE);
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 1;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.brn') := L_TDPAYOUT_REC.BRN;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.acc') := L_TDPAYOUT_REC.ACC;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.ccy') := L_TDPAYOUT_REC.CCY;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.payouttype') := L_TDPAYOUT_REC.PAYOUTTYPE;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.bankcode') := L_TDPAYOUT_REC.BANKCODE;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_brn') := L_TDPAYOUT_REC.OFFSET_BRN;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_acc') := L_TDPAYOUT_REC.OFFSET_ACC;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_ccy') := L_TDPAYOUT_REC.OFFSET_CCY;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.percentage') := L_TDPAYOUT_REC.PERCENTAGE;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.redmamt') := L_TDPAYOUT_REC.REDMAMT;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.benfname') := L_TDPAYOUT_REC.BENFNAME;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.benfadd1') := L_TDPAYOUT_REC.BENFADD1;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.benfadd2') := L_TDPAYOUT_REC.BENFADD2;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.otherdets') := L_TDPAYOUT_REC.OTHERDETS;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.narrative') := L_TDPAYOUT_REC.NARRATIVE;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.xrate') := L_TDPAYOUT_REC.XRATE;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.ref_no') := L_TDPAYOUT_REC.REF_NO;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.seqno') := L_TDPAYOUT_REC.SEQNO;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.payout_component') := L_TDPAYOUT_REC.PAYOUT_COMPONENT;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.instno') := L_TDPAYOUT_REC.INSTNO;
              L_TB_CLUSTER_DATA('l_tdpayout_rec.waive_issue_chg') := L_TDPAYOUT_REC.WAIVE_ISSUE_CHG;
            
              ICPKS_ONLIQ_NEW_CLUSTER.PR_CALL_PROCESS(P_BRN,
                                                      P_LIQ_DT,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
            
              L_TDPAYOUT_REC.OFFSET_ACC := L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_acc');
              L_TDPAYOUT_REC.OFFSET_BRN := L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_brn');
              L_TDPAYOUT_REC.OFFSET_CCY := L_TB_CLUSTER_DATA('l_tdpayout_rec.offset_ccy');
            
              DBG(' The return value of offset brn Acc' ||
                  L_TDPAYOUT_REC.OFFSET_ACC);
              DBG('The return value of offset brn is ' ||
                  L_TDPAYOUT_REC.OFFSET_BRN);
              DBG('The return value of offset ccy is ' ||
                  L_TDPAYOUT_REC.OFFSET_CCY);
            
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            ICPKS_BOD.REC_ACC_PR.BRN    := ICPKS_TEST.TB_BRN(RECNO);
            ICPKS_BOD.REC_ACC_PR.ACC    := ICPKS_TEST.TB_ACC(RECNO);
            ICPKS_BOD.REC_ACC_PR.CCY    := ICPKS_TEST.TB_CCY(RECNO);
            ICPKS_BOD.PKG_TDPAYOUT_DETS := L_TDPAYOUT_REC;
          
            DBG('l_tdpayout_rec.offset_acc-->' ||
                L_TDPAYOUT_REC.OFFSET_ACC);
            DBG('g_lcy-->' || G_LCY);
            DBG('l_tdpayout_rec.offset_ccy-->' ||
                L_TDPAYOUT_REC.OFFSET_CCY);
          
            IF L_TDPAYOUT_REC.PAYOUTTYPE IN ('S', 'G') THEN
              DBG('GOING TO INSERT NEW RECORD');
            
              J := J + 1;
            
              ICPKS_TEST.TB_HOFF_CONS(J).MODULE := L_TB_HOFF_CONS.MODULE;
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_REF_NO := L_TB_HOFF_CONS.TRN_REF_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).EVENT_SR_NO := L_TB_HOFF_CONS.EVENT_SR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).EVENT := L_TB_HOFF_CONS.EVENT;
            
              ICPKS_TEST.TB_HOFF_CONS(J).AC_NO := L_TB_HOFF_CONS.AC_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).AC_CCY := L_TB_HOFF_CONS.AC_CCY;
              ICPKS_TEST.TB_HOFF_CONS(J).AC_BRANCH := L_TB_HOFF_CONS.AC_BRANCH;
              ICPKS_TEST.TB_HOFF_CONS(J).DRCR_IND := 'D';
            
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_CODE := L_TB_HOFF_CONS.TRN_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).AMOUNT_TAG := L_TB_HOFF_CONS.AMOUNT_TAG;
            
              DBG('icpks_test.tb_hoff_cons(j).AC_CCY-->' || ICPKS_TEST.TB_HOFF_CONS(J)
                  .AC_CCY);
              IF ICPKS_TEST.TB_HOFF_CONS(J).AC_CCY = G_LCY THEN
                ICPKS_TEST.TB_HOFF_CONS(J).FCY_AMOUNT := '';
                ICPKS_TEST.TB_HOFF_CONS(J).EXCH_RATE := '';
              
                ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT := L_TDPAYOUT_REC.REDMAMT;
                LCYAMT := ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT;
              
              ELSE
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(ICPKS_TEST.TB_HOFF_CONS(J)
                                                   .AC_BRANCH,
                                                   
                                                   ICPKS_TEST.TB_HOFF_CONS(J)
                                                   .AC_CCY,
                                                   G_LCY,
                                                   L_TDPAYOUT_REC.REDMAMT,
                                                   'Y',
                                                   
                                                   LCYAMT,
                                                   EXRATE,
                                                   ERRMSG) THEN
                  DBG('ERROR icpkss_util.fn_amt1_to_amt2');
                  RAISE ACTNG_FAILED;
                END IF;
                DBG('FCYAMT-->' || FCYAMT);
                DBG('EXRATE-->' || EXRATE);
              
                ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT := LCYAMT;
                ICPKS_TEST.TB_HOFF_CONS(J).FCY_AMOUNT := L_TDPAYOUT_REC.REDMAMT;
              
                ICPKS_TEST.TB_HOFF_CONS(J).EXCH_RATE := EXRATE;
              END IF;
            
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_CUSTOMER := L_TB_HOFF_CONS.RELATED_CUSTOMER;
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_ACCOUNT := L_TB_HOFF_CONS.RELATED_ACCOUNT;
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_REFERENCE := L_TB_HOFF_CONS.RELATED_REFERENCE;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_FLAG := L_TB_HOFF_CONS.MIS_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_HEAD := L_TB_HOFF_CONS.MIS_HEAD;
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_DT := L_TB_HOFF_CONS.TRN_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).VALUE_DT := L_TB_HOFF_CONS.VALUE_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).TXN_INIT_DATE := L_TB_HOFF_CONS.TXN_INIT_DATE;
              ICPKS_TEST.TB_HOFF_CONS(J).FINANCIAL_CYCLE := L_TB_HOFF_CONS.FINANCIAL_CYCLE;
              ICPKS_TEST.TB_HOFF_CONS(J).PERIOD_CODE := L_TB_HOFF_CONS.PERIOD_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).INSTRUMENT_CODE := L_TB_HOFF_CONS.INSTRUMENT_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).BATCH_NO := L_TB_HOFF_CONS.BATCH_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).CURR_NO := L_TB_HOFF_CONS.CURR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).USER_ID := L_TB_HOFF_CONS.USER_ID;
              ICPKS_TEST.TB_HOFF_CONS(J).BANK_CODE := L_TB_HOFF_CONS.BANK_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).AVLDAYS := L_TB_HOFF_CONS.AVLDAYS;
              ICPKS_TEST.TB_HOFF_CONS(J).BALANCE_UPD := L_TB_HOFF_CONS.BALANCE_UPD;
              ICPKS_TEST.TB_HOFF_CONS(J).TYPE := L_TB_HOFF_CONS.TYPE;
              ICPKS_TEST.TB_HOFF_CONS(J).AUTH_ID := L_TB_HOFF_CONS.AUTH_ID;
              ICPKS_TEST.TB_HOFF_CONS(J).PRINT_STAT := L_TB_HOFF_CONS.PRINT_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).AUTH_STAT := L_TB_HOFF_CONS.AUTH_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).CATEGORY := L_TB_HOFF_CONS.CATEGORY;
            
              ICPKS_TEST.TB_HOFF_CONS(J).CUST_GL := L_TB_HOFF_CONS.CUST_GL;
            
              ICPKS_TEST.TB_HOFF_CONS(J).DISTRIBUTED := L_TB_HOFF_CONS.DISTRIBUTED;
              ICPKS_TEST.TB_HOFF_CONS(J).NODE := L_TB_HOFF_CONS.NODE;
              ICPKS_TEST.TB_HOFF_CONS(J).DELETE_STAT := L_TB_HOFF_CONS.DELETE_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).ON_LINE := L_TB_HOFF_CONS.ON_LINE;
              ICPKS_TEST.TB_HOFF_CONS(J).UPDACT := L_TB_HOFF_CONS.UPDACT;
              ICPKS_TEST.TB_HOFF_CONS(J).NODE_SR_NO := L_TB_HOFF_CONS.NODE_SR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).NETTING_IND := L_TB_HOFF_CONS.NETTING_IND;
              ICPKS_TEST.TB_HOFF_CONS(J).IB := L_TB_HOFF_CONS.IB;
              ICPKS_TEST.TB_HOFF_CONS(J).FLG_POSITION_STATUS := L_TB_HOFF_CONS.FLG_POSITION_STATUS;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_UPDATE_FLAG := L_TB_HOFF_CONS.GLMIS_UPDATE_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).PRODUCT_ACCRUAL := L_TB_HOFF_CONS.PRODUCT_ACCRUAL;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_UPDATE_STATUS := L_TB_HOFF_CONS.GLMIS_UPDATE_STATUS;
              ICPKS_TEST.TB_HOFF_CONS(J).VDBAL_UPDATE_FLAG := L_TB_HOFF_CONS.VDBAL_UPDATE_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).PRODUCT := L_TB_HOFF_CONS.PRODUCT;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_VAL_UPD_FLAG := L_TB_HOFF_CONS.GLMIS_VAL_UPD_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).EXTERNAL_REF_NO := L_TB_HOFF_CONS.EXTERNAL_REF_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).PROCESSED_FLAG := L_TB_HOFF_CONS.PROCESSED_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_SPREAD := L_TB_HOFF_CONS.MIS_SPREAD;
              ICPKS_TEST.TB_HOFF_CONS(J).CUST_GL_UPDATE := L_TB_HOFF_CONS.CUST_GL_UPDATE;
              ICPKS_TEST.TB_HOFF_CONS(J).DONT_SHOWIN_STMT := L_TB_HOFF_CONS.DONT_SHOWIN_STMT;
              ICPKS_TEST.TB_HOFF_CONS(J).IC_BAL_INCLUSION := L_TB_HOFF_CONS.IC_BAL_INCLUSION;
              ICPKS_TEST.TB_HOFF_CONS(J).AML_EXCEPTION := L_TB_HOFF_CONS.AML_EXCEPTION;
              ICPKS_TEST.TB_HOFF_CONS(J).ORIG_PNL_GL := L_TB_HOFF_CONS.ORIG_PNL_GL;
              ICPKS_TEST.TB_HOFF_CONS(J).STMT_DT := L_TB_HOFF_CONS.STMT_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).ENTRY_SEQ_NO := 1;
              ICPKS_TEST.TB_HOFF_CONS(J).IL_BVT_PROCESSED := L_TB_HOFF_CONS.IL_BVT_PROCESSED;
            
              J := J + 1;
            
              ICPKS_TEST.TB_HOFF_CONS(J).MODULE := L_TB_HOFF_CONS.MODULE;
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_REF_NO := L_TB_HOFF_CONS.TRN_REF_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).EVENT_SR_NO := L_TB_HOFF_CONS.EVENT_SR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).EVENT := L_TB_HOFF_CONS.EVENT;
            
              ICPKS_TEST.TB_HOFF_CONS(J).AC_NO := L_TDPAYOUT_REC.OFFSET_ACC;
              ICPKS_TEST.TB_HOFF_CONS(J).AC_CCY := L_TDPAYOUT_REC.OFFSET_CCY;
              ICPKS_TEST.TB_HOFF_CONS(J).AC_BRANCH := L_TDPAYOUT_REC.OFFSET_BRN;
              ICPKS_TEST.TB_HOFF_CONS(J).DRCR_IND := 'C';
            
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_CODE := L_TB_HOFF_CONS.TRN_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).AMOUNT_TAG := L_TB_HOFF_CONS.AMOUNT_TAG;
            
              DBG('icpks_test.tb_hoff_cons(j).AC_CCY-->' || ICPKS_TEST.TB_HOFF_CONS(J)
                  .AC_CCY);
              IF ICPKS_TEST.TB_HOFF_CONS(J).AC_CCY = G_LCY THEN
                ICPKS_TEST.TB_HOFF_CONS(J).FCY_AMOUNT := '';
                ICPKS_TEST.TB_HOFF_CONS(J).EXCH_RATE := '';
              
                ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT := LCYAMT;
              ELSIF ICPKS_TEST.TB_HOFF_CONS(J)
               .AC_CCY = ICPKS_TEST.TB_HOFF_CONS(J - 1).AC_CCY THEN
                ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT := ICPKS_TEST.TB_HOFF_CONS(J - 1)
                                                         .LCY_AMOUNT;
                ICPKS_TEST.TB_HOFF_CONS(J).FCY_AMOUNT := ICPKS_TEST.TB_HOFF_CONS(J - 1)
                                                         .FCY_AMOUNT;
                ICPKS_TEST.TB_HOFF_CONS(J).EXCH_RATE := ICPKS_TEST.TB_HOFF_CONS(J - 1)
                                                        .EXCH_RATE;
              
              ELSE
              
                FCYAMT := NULL;
                EXRATE := NULL;
              
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(ICPKS_TEST.TB_HOFF_CONS(J)
                                                   .AC_BRANCH,
                                                   G_LCY,
                                                   ICPKS_TEST.TB_HOFF_CONS(J)
                                                   .AC_CCY,
                                                   
                                                   LCYAMT,
                                                   'Y',
                                                   FCYAMT,
                                                   EXRATE,
                                                   ERRMSG) THEN
                  DBG('ERROR icpkss_util.fn_amt1_to_amt2');
                  RAISE ACTNG_FAILED;
                END IF;
                DBG('FCYAMT-->' || FCYAMT);
                DBG('EXRATE-->' || EXRATE);
              
                ICPKS_TEST.TB_HOFF_CONS(J).FCY_AMOUNT := FCYAMT;
                ICPKS_TEST.TB_HOFF_CONS(J).EXCH_RATE := EXRATE;
                ICPKS_TEST.TB_HOFF_CONS(J).LCY_AMOUNT := LCYAMT;
              END IF;
            
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_CUSTOMER := L_TB_HOFF_CONS.RELATED_CUSTOMER;
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_ACCOUNT := L_TB_HOFF_CONS.RELATED_ACCOUNT;
              ICPKS_TEST.TB_HOFF_CONS(J).RELATED_REFERENCE := L_TB_HOFF_CONS.RELATED_REFERENCE;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_FLAG := L_TB_HOFF_CONS.MIS_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_HEAD := L_TB_HOFF_CONS.MIS_HEAD;
              ICPKS_TEST.TB_HOFF_CONS(J).TRN_DT := L_TB_HOFF_CONS.TRN_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).VALUE_DT := L_TB_HOFF_CONS.VALUE_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).TXN_INIT_DATE := L_TB_HOFF_CONS.TXN_INIT_DATE;
              ICPKS_TEST.TB_HOFF_CONS(J).FINANCIAL_CYCLE := L_TB_HOFF_CONS.FINANCIAL_CYCLE;
              ICPKS_TEST.TB_HOFF_CONS(J).PERIOD_CODE := L_TB_HOFF_CONS.PERIOD_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).INSTRUMENT_CODE := L_TB_HOFF_CONS.INSTRUMENT_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).BATCH_NO := L_TB_HOFF_CONS.BATCH_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).CURR_NO := L_TB_HOFF_CONS.CURR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).USER_ID := L_TB_HOFF_CONS.USER_ID;
              ICPKS_TEST.TB_HOFF_CONS(J).BANK_CODE := L_TB_HOFF_CONS.BANK_CODE;
              ICPKS_TEST.TB_HOFF_CONS(J).AVLDAYS := L_TB_HOFF_CONS.AVLDAYS;
              ICPKS_TEST.TB_HOFF_CONS(J).BALANCE_UPD := L_TB_HOFF_CONS.BALANCE_UPD;
              ICPKS_TEST.TB_HOFF_CONS(J).TYPE := L_TB_HOFF_CONS.TYPE;
              ICPKS_TEST.TB_HOFF_CONS(J).AUTH_ID := L_TB_HOFF_CONS.AUTH_ID;
              ICPKS_TEST.TB_HOFF_CONS(J).PRINT_STAT := L_TB_HOFF_CONS.PRINT_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).AUTH_STAT := L_TB_HOFF_CONS.AUTH_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).CATEGORY := L_TB_HOFF_CONS.CATEGORY;
            
              IF L_TDPAYOUT_REC.PAYOUTTYPE = 'S' THEN
                ICPKS_TEST.TB_HOFF_CONS(J).CUST_GL := 'A';
              ELSE
                ICPKS_TEST.TB_HOFF_CONS(J).CUST_GL := 'G';
              END IF;
            
              ICPKS_TEST.TB_HOFF_CONS(J).DISTRIBUTED := L_TB_HOFF_CONS.DISTRIBUTED;
              ICPKS_TEST.TB_HOFF_CONS(J).NODE := L_TB_HOFF_CONS.NODE;
              ICPKS_TEST.TB_HOFF_CONS(J).DELETE_STAT := L_TB_HOFF_CONS.DELETE_STAT;
              ICPKS_TEST.TB_HOFF_CONS(J).ON_LINE := L_TB_HOFF_CONS.ON_LINE;
              ICPKS_TEST.TB_HOFF_CONS(J).UPDACT := L_TB_HOFF_CONS.UPDACT;
              ICPKS_TEST.TB_HOFF_CONS(J).NODE_SR_NO := L_TB_HOFF_CONS.NODE_SR_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).NETTING_IND := L_TB_HOFF_CONS.NETTING_IND;
              ICPKS_TEST.TB_HOFF_CONS(J).IB := L_TB_HOFF_CONS.IB;
              ICPKS_TEST.TB_HOFF_CONS(J).FLG_POSITION_STATUS := L_TB_HOFF_CONS.FLG_POSITION_STATUS;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_UPDATE_FLAG := L_TB_HOFF_CONS.GLMIS_UPDATE_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).PRODUCT_ACCRUAL := L_TB_HOFF_CONS.PRODUCT_ACCRUAL;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_UPDATE_STATUS := L_TB_HOFF_CONS.GLMIS_UPDATE_STATUS;
              ICPKS_TEST.TB_HOFF_CONS(J).VDBAL_UPDATE_FLAG := L_TB_HOFF_CONS.VDBAL_UPDATE_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).PRODUCT := L_TB_HOFF_CONS.PRODUCT;
              ICPKS_TEST.TB_HOFF_CONS(J).GLMIS_VAL_UPD_FLAG := L_TB_HOFF_CONS.GLMIS_VAL_UPD_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).EXTERNAL_REF_NO := L_TB_HOFF_CONS.EXTERNAL_REF_NO;
              ICPKS_TEST.TB_HOFF_CONS(J).PROCESSED_FLAG := L_TB_HOFF_CONS.PROCESSED_FLAG;
              ICPKS_TEST.TB_HOFF_CONS(J).MIS_SPREAD := L_TB_HOFF_CONS.MIS_SPREAD;
              ICPKS_TEST.TB_HOFF_CONS(J).CUST_GL_UPDATE := L_TB_HOFF_CONS.CUST_GL_UPDATE;
              ICPKS_TEST.TB_HOFF_CONS(J).DONT_SHOWIN_STMT := L_TB_HOFF_CONS.DONT_SHOWIN_STMT;
              ICPKS_TEST.TB_HOFF_CONS(J).IC_BAL_INCLUSION := L_TB_HOFF_CONS.IC_BAL_INCLUSION;
              ICPKS_TEST.TB_HOFF_CONS(J).AML_EXCEPTION := L_TB_HOFF_CONS.AML_EXCEPTION;
              ICPKS_TEST.TB_HOFF_CONS(J).ORIG_PNL_GL := L_TB_HOFF_CONS.ORIG_PNL_GL;
              ICPKS_TEST.TB_HOFF_CONS(J).STMT_DT := L_TB_HOFF_CONS.STMT_DT;
              ICPKS_TEST.TB_HOFF_CONS(J).ENTRY_SEQ_NO := 2;
              ICPKS_TEST.TB_HOFF_CONS(J).IL_BVT_PROCESSED := L_TB_HOFF_CONS.IL_BVT_PROCESSED;
            
            ELSIF L_TDPAYOUT_REC.PAYOUTTYPE IN ('B', 'D') THEN
              DBG('*** calling BC Payout  ***');
              DBG('BC Payout for credit leg ***');
              ICPKS_BOD.PR_LIQDBY_BC;
            ELSIF L_TDPAYOUT_REC.PAYOUTTYPE = 'P' THEN
              DBG('*** calling PC Payout  ***');
              DBG('PC Payout for credit leg ***');
              ICPKS_BOD.PR_LIQDBY_PC;
            ELSE
              DBG('Invalid Setup for the Deposit interest payout');
            
            END IF;
            DBG('ILIQ for all the payouts starts');
            L_CNT  := L_CNT - 1;
            FCYAMT := '';
            EXRATE := '';
          END LOOP;
        
          DBG('Have come here for td interest liquidation on maturity-TDLIQ');
          DBG('p_Brn transaction branch in pr_call_process-->' || P_BRN);
          DBG('p_Brn transaction ACCOUNT in pr_call_process-->' ||
              ICPKS_TEST.G_ICTM_ACC.ACC);
          IF NOT ICPKSS_BOD.FN_CUSTLIM_TDLIQ('FLEXCUBE',
                                             'TDLIQ',
                                             ICPKS_TEST.G_ICTM_ACC.ACC,
                                             P_BRN,
                                             ERRMSG,
                                             EPRM,
                                             ICPKS_TEST.TB_HOFF_CONS,
                                             NULL) THEN
            L_ERR_TYPE := OVPKSS.FN_GETTYPE(ERRMSG);
            DBG('err_code--' || ERRMSG);
            DBG('l_err_type--' || L_ERR_TYPE);
            DBG('eprm--' || EPRM);
            IF L_ERR_TYPE = 'E' THEN
              DBG('Failed in fn_Custlim_tdliq-->' || SQLERRM);
              ICPKSS_TEST.TB_HOFF_CONS.DELETE;
              IF NVL(GLOBAL.FUNC_TYPE, '*') <> 'B' THEN
                OVPKSS.PR_APPENDTBL(ERRMSG, EPRM);
              END IF;
              RAISE ACTNG_FAILED;
            ELSE
              DBG('Going to proceed as the error type is override');
            END IF;
          END IF;
        
          IF ICPKS_TEST.TB_HOFF_CONS.COUNT <> 0 THEN
            IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                       1,
                                       APPDT,
                                       ICPKS_TEST.TB_HOFF_CONS,
                                       'B',
                                       'Y',
                                       'N',
                                       UID,
                                       ERRMSG,
                                       EPRM) THEN
              DBG('In pr do process acpkss gave hand' || ' - ' || ERRMSG);
              ICPKSS_TEST.TB_HOFF_CONS.DELETE;
            
              OVPKSS.PR_APPENDTBL(ERRMSG, EPRM);
            
              RAISE ACTNG_FAILED;
            END IF;
          END IF;
        
        END IF;
        ICPKS_BOD.G_PAYOUT_COMPONENT := NULL;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('failed in Pr_split_int_payout' || SQLERRM);
        ICPKS_BOD.G_PAYOUT_COMPONENT := NULL;
        DBG('set g_payout_component to null!!');
        RAISE;
    END PR_SPLIT_INT_PAYOUT;
  
    PROCEDURE PR_RESET_VARIABLES IS
    BEGIN
      IF ICPKS_TEST.TB_ACC.COUNT = 0 OR ICPKS_TEST.TB_BRN.COUNT = 0 OR
         ICPKS_TEST.TB_PROD.COUNT = 0 THEN
        ICPKS_TEST.TB_BRN                   := L_TB_BRN;
        ICPKS_TEST.TB_ACC                   := L_TB_ACC;
        ICPKS_TEST.TB_PROD                  := L_TB_PROD;
        ICPKS_TEST.TB_SC_MAP_DT             := L_TB_SC_MAP_DT;
        ICPKS_TEST.TB_GC_MAP_DT             := L_TB_GC_MAP_DT;
        ICPKS_TEST.TB_LAST_CALC_DT          := L_TB_LAST_CALC_DT;
        ICPKS_TEST.TB_LAST_LIQ_DT           := L_TB_LAST_LIQ_DT;
        ICPKS_TEST.TB_NEXT_LIQ_DT           := L_TB_NEXT_LIQ_DT;
        ICPKS_TEST.TB_LAST_ACCR_DT          := L_TB_LAST_ACCR_DT;
        ICPKS_TEST.TB_NEXT_ACCR_DT          := L_TB_NEXT_ACCR_DT;
        ICPKS_TEST.TB_LAST_SCHD_LIQ_DT      := L_TB_LAST_SCHD_LIQ_DT;
        ICPKS_TEST.TB_INC_MTH               := L_TB_INC_MTH;
        ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT      := L_TB_NEXT_SCHD_LIQ_DT;
        ICPKS_TEST.TB_FIRST_CALC_DT         := L_TB_FIRST_CALC_DT;
        ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT     := L_TB_NEXT_SCHD_ACCR_DT;
        ICPKS_TEST.TB_PROD_TYPE             := L_TB_PROD_TYPE;
        ICPKS_TEST.TB_HAS_ACCR              := L_TB_HAS_ACCR;
        ICPKS_TEST.TB_NEXT_CALC_DT          := L_TB_NEXT_CALC_DT;
        ICPKS_TEST.TB_PROD_ACCR             := L_TB_PROD_ACCR;
        ICPKS_TEST.TB_HAS_PROBLEMS          := L_TB_HAS_PROBLEMS;
        ICPKS_TEST.TB_BKVAL_MINCALC_DATE    := L_TB_BKVAL_MINCALC_DATE;
        ICPKS_TEST.TB_BKVAL_RECALC_FLAG     := L_TB_BKVAL_RECALC_FLAG;
        ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE := L_TB_FIRST_FIRST_CALC_DATE;
        ICPKS_TEST.TB_IMAT_PROBLEMS         := L_TB_IMAT_PROBLEMS;
        ICPKS_TEST.TB_DEPOSIT               := L_TB_DEPOSIT;
        ICPKS_TEST.TB_ACLASS                := L_TB_ACLASS;
        ICPKS_TEST.TB_CCY                   := L_TB_CCY;
        ICPKS_TEST.TB_NEXT_EVENT_DT         := L_TB_NEXT_EVENT_DT;
        ICPKS_TEST.TB_ROWID                 := L_TB_ROWID;
        ICPKS_TEST.TB_DEFER_LIQ_DT          := L_TB_DEFER_LIQ_DT;
        ICPKSS_TEST.TB_SYS_AC_LEVEL         := L_TB_SYS_AC_LEVEL;
        ICPKSS_TEST.TB_SUBLEVEL             := L_TB_SUBLEVEL;
      END IF;
      L_NOTHING_TODO  := FALSE;
      L_NOTHING_TODO1 := FALSE;
    END;
  
  BEGIN
    DBG('Inside Pr_Call_Process');
  
    ICPKS_BOD.G_PAYOUT_COMPONENT := NULL;
    RECORD                       := ICPKS_TEST.TB_ROWID.FIRST;
    WHILE RECORD <= ICPKSS_TEST.TB_ROWID.LAST LOOP
      DBG('the dates are' || ICPKS_TEST.TB_NEXT_LIQ_DT(RECORD) || ' - ' ||
          ICPKS_TEST.TB_NEXT_ACCR_DT(RECORD));
      RECORD := ICPKS_TEST.TB_ROWID.NEXT(RECORD);
    END LOOP;
    RECNO := ICPKS_TEST.TB_ROWID.FIRST;
    WHILE RECNO <= ICPKSS_TEST.TB_ROWID.LAST LOOP
    
      BEGIN
        SAVEPOINT DO_PROCESS;
      
        L_NOTHING_TODO := FALSE;
        DBG('Just inside the loop...before assigning ' ||
            ICPKS_TEST.TB_BRN.COUNT);
        DBG('Inside real loop ' || ' - ' ||
            ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) || ' - ' ||
            ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO));
        L_TB_BRN                   := ICPKS_TEST.TB_BRN;
        L_TB_ACC                   := ICPKS_TEST.TB_ACC;
        L_TB_PROD                  := ICPKS_TEST.TB_PROD;
        L_TB_SC_MAP_DT             := ICPKS_TEST.TB_SC_MAP_DT;
        L_TB_GC_MAP_DT             := ICPKS_TEST.TB_GC_MAP_DT;
        L_TB_LAST_CALC_DT          := ICPKS_TEST.TB_LAST_CALC_DT;
        L_TB_LAST_LIQ_DT           := ICPKS_TEST.TB_LAST_LIQ_DT;
        L_TB_NEXT_LIQ_DT           := ICPKS_TEST.TB_NEXT_LIQ_DT;
        L_TB_LAST_ACCR_DT          := ICPKS_TEST.TB_LAST_ACCR_DT;
        L_TB_NEXT_ACCR_DT          := ICPKS_TEST.TB_NEXT_ACCR_DT;
        L_TB_LAST_SCHD_LIQ_DT      := ICPKS_TEST.TB_LAST_SCHD_LIQ_DT;
        L_TB_INC_MTH               := ICPKS_TEST.TB_INC_MTH;
        L_TB_NEXT_SCHD_LIQ_DT      := ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT;
        L_TB_FIRST_CALC_DT         := ICPKS_TEST.TB_FIRST_CALC_DT;
        L_TB_NEXT_SCHD_ACCR_DT     := ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT;
        L_TB_PROD_TYPE             := ICPKS_TEST.TB_PROD_TYPE;
        L_TB_HAS_ACCR              := ICPKS_TEST.TB_HAS_ACCR;
        L_TB_NEXT_CALC_DT          := ICPKS_TEST.TB_NEXT_CALC_DT;
        L_TB_PROD_ACCR             := ICPKS_TEST.TB_PROD_ACCR;
        L_TB_HAS_PROBLEMS          := ICPKS_TEST.TB_HAS_PROBLEMS;
        L_TB_BKVAL_MINCALC_DATE    := ICPKS_TEST.TB_BKVAL_MINCALC_DATE;
        L_TB_BKVAL_RECALC_FLAG     := ICPKS_TEST.TB_BKVAL_RECALC_FLAG;
        L_TB_FIRST_FIRST_CALC_DATE := ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE;
        L_TB_IMAT_PROBLEMS         := ICPKS_TEST.TB_IMAT_PROBLEMS;
        L_TB_DEPOSIT               := ICPKS_TEST.TB_DEPOSIT;
        L_TB_ACLASS                := ICPKS_TEST.TB_ACLASS;
        L_TB_CCY                   := ICPKS_TEST.TB_CCY;
        L_TB_NEXT_EVENT_DT         := ICPKS_TEST.TB_NEXT_EVENT_DT;
        L_TB_ROWID                 := ICPKS_TEST.TB_ROWID;
      
        L_TB_DEFER_LIQ_DT := ICPKS_TEST.TB_DEFER_LIQ_DT;
      
        L_TB_SYS_AC_LEVEL := ICPKSS_TEST.TB_SYS_AC_LEVEL;
        L_TB_SUBLEVEL     := ICPKSS_TEST.TB_SUBLEVEL;
      
        DBG('After assigning to local variables' || L_TB_ROWID.COUNT);
      
        ICPKS_TEST.TB_BRN.DELETE;
        ICPKS_TEST.TB_ACC.DELETE;
        ICPKS_TEST.TB_PROD.DELETE;
        ICPKS_TEST.TB_SC_MAP_DT.DELETE;
        ICPKS_TEST.TB_GC_MAP_DT.DELETE;
        ICPKS_TEST.TB_LAST_CALC_DT.DELETE;
        ICPKS_TEST.TB_LAST_LIQ_DT.DELETE;
        ICPKS_TEST.TB_NEXT_LIQ_DT.DELETE;
        ICPKS_TEST.TB_LAST_ACCR_DT.DELETE;
        ICPKS_TEST.TB_NEXT_ACCR_DT.DELETE;
        ICPKS_TEST.TB_LAST_SCHD_LIQ_DT.DELETE;
        ICPKS_TEST.TB_INC_MTH.DELETE;
        ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT.DELETE;
        ICPKS_TEST.TB_FIRST_CALC_DT.DELETE;
        ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT.DELETE;
        ICPKS_TEST.TB_PROD_TYPE.DELETE;
        ICPKS_TEST.TB_HAS_ACCR.DELETE;
        ICPKS_TEST.TB_NEXT_CALC_DT.DELETE;
        ICPKS_TEST.TB_PROD_ACCR.DELETE;
        ICPKS_TEST.TB_HAS_PROBLEMS.DELETE;
        ICPKS_TEST.TB_BKVAL_MINCALC_DATE.DELETE;
        ICPKS_TEST.TB_BKVAL_RECALC_FLAG.DELETE;
        ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE.DELETE;
        ICPKS_TEST.TB_IMAT_PROBLEMS.DELETE;
        ICPKS_TEST.TB_DEPOSIT.DELETE;
        ICPKS_TEST.TB_ACLASS.DELETE;
        ICPKS_TEST.TB_CCY.DELETE;
      
        ICPKS_TEST.TB_NEXT_EVENT_DT.DELETE;
        ICPKS_TEST.TB_DEFER_LIQ_DT.DELETE;
      
        ICPKSS_TEST.TB_SYS_AC_LEVEL.DELETE;
        ICPKSS_TEST.TB_SUBLEVEL.DELETE;
      
        DBG('After assigning to local plsql tables');
        L_TB_PROD_ACCR(RECNO) := 'N';
      
        BEGIN
          SELECT DEFERRED_FLAG
            INTO L_DEFERRED_FLG
            FROM ICTMS_PR_INT
           WHERE PRODUCT_CODE = L_TB_PROD(RECNO);
        EXCEPTION
          WHEN OTHERS THEN
            L_DEFERRED_FLG := NULL;
            DBG('ERROR IN DEFERRED FLAG SELECTION ' || SQLERRM);
        END;
        DBG('L_TB_DEPOSIT(RECNO)' || L_TB_DEPOSIT(RECNO));
      
        DBG('L_DEFERRED_FLG' || L_DEFERRED_FLG);
      
        IF NVL(L_DEFERRED_FLG, 'N') <> 'Y' OR ICPKS_BOD.G_FROMBOD = FALSE OR
           L_TB_NEXT_LIQ_DT(RECNO) = L_TB_DEFER_LIQ_DT(RECNO) THEN
          L_ENTRY_PASSED := 'Y';
        ELSE
          L_ENTRY_PASSED := 'N';
        END IF;
      
        IF NVL(L_ACC, '***') <> NVL(L_TB_ACC(RECNO), '###') OR
           NVL(L_BRN, '***') <> NVL(L_TB_BRN(RECNO), '####') THEN
          DBG('ASSIGNED SOMETHING FOR ACCOUNT AND BRANCH');
          ICPKS_TEST.G_STTM_CUSTACC := TB_STTM_CUSTACC(RECNO);
          ICPKS_TEST.G_ICTM_ACC     := TB_ICTM_ACC(RECNO);
          DBG('SANITY CHECK ---> ' || ICPKS_TEST.G_ICTM_ACC.ACC || ' - ' ||
              ICPKS_TEST.G_STTM_CUSTACC.CCY || ' -' ||
              ICPKS_TEST.G_STTM_CUSTACC.CUST_NO);
        END IF;
      
        IF ICPKS_BOD.G_FROMBOD = FALSE THEN
          DBG('BOD flag from icbod is FALSE .. Continue with BKVAL CALC');
        ELSE
          DBG('BOD flag from icbod is TRUE .. Skip BKVAL CALC');
        END IF;
      
        IF ICPKS_BOD.G_FROMBOD = FALSE THEN
          IF NOT ICPKSS_TEST.FN_BKVAL_CALC(L_TB_BRN(RECNO), L_TB_ACC(RECNO)) THEN
            RAISE BKVAL_BOMBED;
          END IF;
        END IF;
      
        L_TB_BKVAL_RECALC_FLAG(RECNO) := 'N';
        L_TB_BKVAL_MINCALC_DATE(RECNO) := NULL;
        DBG('back valuation done');
        ICPKS_TEST.TB_BRN                   := L_TB_BRN;
        ICPKS_TEST.TB_ACC                   := L_TB_ACC;
        ICPKS_TEST.TB_PROD                  := L_TB_PROD;
        ICPKS_TEST.TB_SC_MAP_DT             := L_TB_SC_MAP_DT;
        ICPKS_TEST.TB_GC_MAP_DT             := L_TB_GC_MAP_DT;
        ICPKS_TEST.TB_LAST_CALC_DT          := L_TB_LAST_CALC_DT;
        ICPKS_TEST.TB_LAST_LIQ_DT           := L_TB_LAST_LIQ_DT;
        ICPKS_TEST.TB_NEXT_LIQ_DT           := L_TB_NEXT_LIQ_DT;
        ICPKS_TEST.TB_LAST_ACCR_DT          := L_TB_LAST_ACCR_DT;
        ICPKS_TEST.TB_NEXT_ACCR_DT          := L_TB_NEXT_ACCR_DT;
        ICPKS_TEST.TB_LAST_SCHD_LIQ_DT      := L_TB_LAST_SCHD_LIQ_DT;
        ICPKS_TEST.TB_INC_MTH               := L_TB_INC_MTH;
        ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT      := L_TB_NEXT_SCHD_LIQ_DT;
        ICPKS_TEST.TB_FIRST_CALC_DT         := L_TB_FIRST_CALC_DT;
        ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT     := L_TB_NEXT_SCHD_ACCR_DT;
        ICPKS_TEST.TB_PROD_TYPE             := L_TB_PROD_TYPE;
        ICPKS_TEST.TB_HAS_ACCR              := L_TB_HAS_ACCR;
        ICPKS_TEST.TB_NEXT_CALC_DT          := L_TB_NEXT_CALC_DT;
        ICPKS_TEST.TB_PROD_ACCR             := L_TB_PROD_ACCR;
        ICPKS_TEST.TB_HAS_PROBLEMS          := L_TB_HAS_PROBLEMS;
        ICPKS_TEST.TB_BKVAL_MINCALC_DATE    := L_TB_BKVAL_MINCALC_DATE;
        ICPKS_TEST.TB_BKVAL_RECALC_FLAG     := L_TB_BKVAL_RECALC_FLAG;
        ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE := L_TB_FIRST_FIRST_CALC_DATE;
        ICPKS_TEST.TB_IMAT_PROBLEMS         := L_TB_IMAT_PROBLEMS;
        ICPKS_TEST.TB_DEPOSIT               := L_TB_DEPOSIT;
        ICPKS_TEST.TB_ACLASS                := L_TB_ACLASS;
        ICPKS_TEST.TB_CCY                   := L_TB_CCY;
        ICPKS_TEST.TB_NEXT_EVENT_DT         := L_TB_NEXT_EVENT_DT;
        ICPKS_TEST.TB_ROWID                 := L_TB_ROWID;
        ICPKS_TEST.TB_DEFER_LIQ_DT          := L_TB_DEFER_LIQ_DT;
      
        ICPKSS_TEST.TB_SYS_AC_LEVEL := L_TB_SYS_AC_LEVEL;
        ICPKSS_TEST.TB_SUBLEVEL     := L_TB_SUBLEVEL;
      
        DBG('after reassign of the things');
        DBG('After reassinging the dates' || ' - ' ||
            ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) || '~' ||
            ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO));
      
        H := CSPKSS_UTILS.FN_HASH40(ICPKS_TEST.TB_PROD(RECNO));
      
        DBG('I AM ' || ICPKS_TEST.TB_PROD(RECNO));
      
        DBG('After assigning the details' ||
            ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO));
      
        IF ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) < P_LIQ_DT THEN
          DBG('inside overdue case');
          L_DUE_DT := ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO);
          ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) := L_DUE_DT;
          ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := L_DUE_DT;
        
          IF NVL(L_DEFERRED_FLG, 'N') <> 'Y' OR ICPKS_BOD.G_FROMBOD = FALSE THEN
            ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO) := L_DUE_DT;
          END IF;
        
          IF ICPKS_TEST.TB_HAS_ACCR(RECNO) = 'Y' THEN
            ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) := L_DUE_DT;
          END IF;
          DBG('In overdue case the details are going as' || ' - ' ||
              L_DUE_DT);
        ELSE
        
          DBG('Norml case and dates are being reset');
          IF TB_INT_ACC_CLOSE.EXISTS(H) THEN
            DBG('WONT BOMB');
          ELSE
            DBG('******WILL BOMB FOR ' || H);
            L_NOTHING_TODO := TRUE;
          END IF;
        
          IF NOT L_NOTHING_TODO THEN
          
            IF NVL(TB_INT_ACC_CLOSE(H), 'N') <> 'N' THEN
            
              L_DUE_DT := P_LIQ_DT;
              ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) := L_DUE_DT;
              ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := L_DUE_DT;
            
              IF NVL(L_DEFERRED_FLG, 'N') <> 'Y' OR
                 ICPKS_BOD.G_FROMBOD = FALSE THEN
                ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO) := L_DUE_DT;
              END IF;
            
              IF ICPKS_TEST.TB_HAS_ACCR(RECNO) = 'Y' THEN
                ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) := L_DUE_DT;
              END IF;
            
            ELSE
            
              SELECT EXTRACT(MONTH FROM ICPKS_TEST.TB_FIRST_CALC_DT(RECNO)),
                     EXTRACT(MONTH FROM P_LIQ_DT),
                     EXTRACT(YEAR FROM ICPKS_TEST.TB_FIRST_CALC_DT(RECNO)),
                     EXTRACT(YEAR FROM P_LIQ_DT)
                INTO L_PREV_MONTH,
                     L_CURRENT_MONTH,
                     L_PREV_YEAR,
                     L_CURRENT_YEAR
                FROM DUAL;
              DBG('Current Liquidation Month is  ' || L_CURRENT_MONTH);
              DBG('Previous Liquidation Month is ' || L_PREV_MONTH);
              DBG('Current Liquidation Year      ' || L_CURRENT_YEAR);
              DBG('Previous Liquidation Year     ' || L_PREV_YEAR);
              IF (L_CURRENT_MONTH <> L_PREV_MONTH OR
                 L_CURRENT_YEAR <> L_PREV_YEAR) THEN
              
                IF LAST_DAY(P_LIQ_DT) = P_LIQ_DT AND
                   GLOBAL.APPLICATION_DATE > P_LIQ_DT THEN
                  L_DUE_DT := LAST_DAY(ADD_MONTHS(P_LIQ_DT + 1, -1));
                ELSE
                
                  L_DUE_DT := LAST_DAY(ADD_MONTHS(P_LIQ_DT, -1));
                END IF;
                ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) := L_DUE_DT;
                ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := L_DUE_DT;
                ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO) := L_DUE_DT;
                ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) := L_DUE_DT;
              
                DBG('Icpks_Test.Tb_Last_Liq_Dt(Recno) is :' ||
                    ICPKS_TEST.TB_LAST_LIQ_DT(RECNO));
                DBG('l_due_dt is :' || L_DUE_DT);
                IF L_DUE_DT = ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) THEN
                  DBG('Liquidation has already happened');
                  L_NOTHING_TODO := TRUE;
                ELSE
                
                  L_NOTHING_TODO := FALSE;
                END IF;
              ELSE
              
                DBG('this do not require anything at this point');
                ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) := P_LIQ_DT;
                L_NOTHING_TODO := TRUE;
              END IF;
            END IF;
          END IF;
        
        END IF;
      
        IF NOT L_NOTHING_TODO THEN
        
          DBG('Going to call do process with' || '~' || L_DUE_DT);
        
          BEGIN
            PR_DO_PROCESS(RECNO, L_DUE_DT);
          EXCEPTION
            WHEN OTHERS THEN
              RAISE DO_PROCESS;
          END;
        
          IF NVL(ICPKS_TEST.TB_HOFF_CONS.COUNT, 0) <> 0 THEN
            DBG('INSIDE pr do process account changed so pass entries for prev account');
            IF NOT ICPKS_FCJ_ICDREDMN.G_FROMREDM THEN
              DBG('before calling Pr_Initerrtbl');
              OVPKSS.PR_INITERRTBL;
            END IF;
            BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.FIRST;
            WHILE BUGTEST1 <= ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
              DBG('bug test1' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).EVENT || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                  .AMOUNT_TAG);
              DBG('amounts are' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                  .LCY_AMOUNT);
              BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.NEXT(BUGTEST1);
            END LOOP;
          
            DBG('raju raju raju count of hoff cons :' ||
                ICPKS_TEST.TB_HOFF_CONS.COUNT);
            IF ICPKS_TEST.TB_ACC.COUNT > 0 THEN
              DBG('account # and prod  :' ||
                  ICPKS_TEST.TB_ACC(ICPKS_TEST.TB_ACC.FIRST) || '~' ||
                  ICPKS_TEST.TB_PROD(ICPKS_TEST.TB_PROD.FIRST));
            END IF;
          
            IF ICPKS_TEST.TB_PROD.COUNT <> 0 THEN
              BEGIN
                L_TB_PRODUCT := ICPKS_TEST.TB_PROD(ICPKS_TEST.TB_PROD.FIRST);
                DBG('Prod value rt :' || L_TB_PRODUCT);
                SELECT PAYMENT_METHOD
                  INTO L_PAY_MTHD
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = L_TB_PRODUCT;
              
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Error in select payment mthd from ictm_pr_int :' ||
                      SQLERRM);
              END;
            END IF;
          
            DBG('Unclaimed Process :' || ICPKS_BOD.UNCLAIMED_PROCESS);
            DBG('Int to Unclaimed  :' ||
                ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED);
            DBG('Payment Method    :' || L_PAY_MTHD);
          
            IF ICPKS_BOD.UNCLAIMED_PROCESS = 'N' AND
               ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' THEN
              DBG('delete accrual entries ');
            
              BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.FIRST;
              WHILE BUGTEST1 <= ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
                IF ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).EVENT = 'IACR' THEN
                  DBG('raju raju raju into delete accr');
                  ICPKS_TEST.TB_HOFF_CONS.DELETE(BUGTEST1);
                END IF;
                BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.NEXT(BUGTEST1);
              END LOOP;
            
            END IF;
          
            IF L_PAY_MTHD = 'D' OR (ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' AND
               ICPKS_BOD.UNCLAIMED_PROCESS = 'Y') THEN
              DBG('raju raju raju before delete');
              DBG('rtseshad payment method is N / Unclaimed is Y ');
              BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.FIRST;
              WHILE BUGTEST1 <= ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
              
                --sampath starts              
                IF L_TB_PRODUCT IN ('TDSR',
                                    'TDSN',
                                    'TDLR',
                                    'TDLN',
                                    'TCSR',
                                    'TCLR',
                                    'TCSM',
                                    'TCLN') AND
                   ICPKS_BOD_CUSTOM.G_TD_UPFRONT_ROLLOVER_AMT_FLAG = 'Y' THEN
                
                  DBG('ICPKS_BOD_CUSTOM.G_TD_UPFRONT_ROLLOVER_AMT_FLAG=' ||
                      ICPKS_BOD_CUSTOM.G_TD_UPFRONT_ROLLOVER_AMT_FLAG);
                
                  DBG('ICPKS_MAINT.G_FULL_REDEM=' ||
                      ICPKS_MAINT.G_FULL_REDEM);
                  DBG('ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).EVENT=' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                      .EVENT);
                  DBG('ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).AMOUNT_TAG=' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                      .AMOUNT_TAG);
                
                  DBG('ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).LCY_AMOUNT=' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                      .LCY_AMOUNT);
                
                  DBG('ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).FCY_AMOUNT=' || ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                      .FCY_AMOUNT);
                
                  IF ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                   .EVENT = 'ILIQ' AND ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                     
                     .AMOUNT_TAG IN ('TAX', 'ILIQ_ADJ') THEN
                  
                    DBG('raju raju raju into delete liq new version');
                  
                    ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).LCY_AMOUNT := 0;
                    ICPKS_TEST.TB_HOFF_CONS(BUGTEST1).FCY_AMOUNT := 0;
                  
                    -- ICPKS_TEST.TB_HOFF_CONS.DELETE(BUGTEST1);               
                  
                  END IF;
                
                ELSE
                  --sampath changes
                
                  IF ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                   .EVENT = 'ILIQ' AND ICPKS_TEST.TB_HOFF_CONS(BUGTEST1)
                     
                     .AMOUNT_TAG NOT IN ('TAX', 'TAX_ADJ', 'ILIQ') THEN
                  
                    DBG('raju raju raju into delete liq');
                    ICPKS_TEST.TB_HOFF_CONS.DELETE(BUGTEST1);
                  END IF;
                
                END IF; --sampath ends
              
                BUGTEST1 := ICPKS_TEST.TB_HOFF_CONS.NEXT(BUGTEST1);
              END LOOP;
            
            END IF;
            DBG('raju raju raju after pay_mthd N loop');
            DBG('raju raju raju count after delete :' ||
                ICPKS_TEST.TB_HOFF_CONS.COUNT);
          
            DBG('HERE RAJU BABA 1');
            L_TB_HOFF_CONS.DELETE;
            L_RECORD_COUNT := 1;
            L_SEQ          := ICPKS_TEST.TB_HOFF_CONS.FIRST;
            WHILE L_SEQ <= ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
              DBG('here...');
              L_TB_HOFF_CONS(L_RECORD_COUNT) := ICPKS_TEST.TB_HOFF_CONS(L_SEQ);
            
              IF L_TB_HOFF_CONS(L_RECORD_COUNT).EXTERNAL_REF_NO IS NULL THEN
                L_TB_HOFF_CONS(L_RECORD_COUNT).EXTERNAL_REF_NO := ICPKS_ICDLIQAC_KERNEL.G_XREF;
              END IF;
            
              L_SEQ          := ICPKS_TEST.TB_HOFF_CONS.NEXT(L_SEQ);
              L_RECORD_COUNT := L_RECORD_COUNT + 1;
            END LOOP;
          
            DBG('icpks_test.tb_hoff_cons count is :' ||
                ICPKS_TEST.TB_HOFF_CONS.COUNT);
            DBG('l_tb_hoff_cons          count is :' ||
                L_TB_HOFF_CONS.COUNT);
          
            ICPKS_TEST.TB_HOFF_CONS.DELETE;
          
            ICPKS_TEST.TB_HOFF_CONS := L_TB_HOFF_CONS;
            DBG('icpks_test.tb_hoff_cons count is :' ||
                ICPKS_TEST.TB_HOFF_CONS.COUNT);
          
            IF ICPKS_TEST.TB_HOFF_CONS.COUNT <> 0 THEN
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID      := 1;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              
                L_TB_CLUSTER_DATA('ACC') := ICPKS_TEST.TB_ACC(RECNO);
                L_TB_CLUSTER_DATA('BRN') := ICPKS_TEST.TB_BRN(RECNO);
                L_TB_CLUSTER_DATA('PROD') := ICPKS_TEST.TB_PROD(RECNO);
                L_TB_CLUSTER_DATA('CCY') := ICPKS_TEST.TB_CCY(RECNO);
              
                ICPKSS_ONLIQ_NEW_CLUSTER.PR_CALL_PROCESS(P_BRN,
                                                         P_LIQ_DT,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA);
              END IF;
            
              DBG('Have come here for casa interest liquidation-CASALIQ ');
              DBG('p_Brn transaction branch in pr_call_process-->' ||
                  P_BRN);
              DBG('Icpks_Test.g_Ictm_Acc.Acc' || ICPKS_TEST.G_ICTM_ACC.ACC);
              IF NOT ICPKSS_BOD.FN_CUSTLIM_TDLIQ('FLEXCUBE',
                                                 'CASALIQ',
                                                 ICPKS_TEST.G_ICTM_ACC.ACC,
                                                 P_BRN,
                                                 ERRMSG,
                                                 EPRM,
                                                 ICPKS_TEST.TB_HOFF_CONS,
                                                 NULL) THEN
              
                L_ERR_TYPE := OVPKSS.FN_GETTYPE(ERRMSG);
                DBG('err_code--' || ERRMSG);
                DBG('l_err_type--' || L_ERR_TYPE);
                DBG('eprm--' || EPRM);
                IF L_ERR_TYPE = 'E' THEN
                  DBG('Failed in fn_Custlim_tdliq-->' || SQLERRM);
                  ICPKSS_TEST.TB_HOFF_CONS.DELETE;
                  IF NVL(GLOBAL.FUNC_TYPE, '*') <> 'B' THEN
                    OVPKSS.PR_APPENDTBL(ERRMSG, EPRM);
                  END IF;
                  RAISE ACTNG_FAILED;
                ELSE
                  DBG('Going to proceed as the error type is override');
                END IF;
              END IF;
            
              IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                         1,
                                         APPDT,
                                         ICPKS_TEST.TB_HOFF_CONS,
                                         'B',
                                         'Y',
                                         'N',
                                         UID,
                                         ERRMSG,
                                         EPRM) THEN
                DBG('In pr do process acpkss gave hand' || ' - ' || ERRMSG);
                ICPKSS_TEST.TB_HOFF_CONS.DELETE;
              
                OVPKSS.PR_APPENDTBL(ERRMSG, EPRM);
              
                RAISE ACTNG_FAILED;
              
              END IF;
              PR_SPLIT_INT_PAYOUT();
            END IF;
            DBG('Posted entries sucessfully..in do process for :' ||
                P_LIQ_DT || ' - ' || L_ACC);
            ICPKS_TEST.TB_HOFF_CONS.DELETE;
          ELSE
            DBG('No entries for acc :' || ICPKS_TEST.TB_ACC(RECNO));
          END IF;
        
          PR_UPD_ACCPR(RECNO, L_DUE_DT);
        
          IF ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) < P_LIQ_DT THEN
            DBG('This fellow wants it again');
            LOOP
            
              IF ICPKS_BOD.G_FROMBOD = FALSE THEN
                DBG('BOD flag from icbod is FALSE .. Continue with VDBAL UPDATE');
              ELSE
                DBG('BOD flag from icbod is TRUE .. Skip VDBAL UPDATE');
              END IF;
            
              IF ICPKS_BOD.G_FROMBOD = FALSE THEN
                IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(RECNO),
                                                 ICPKS_TEST.TB_ACC(RECNO),
                                                 ICPKS_TEST.TB_CCY(RECNO),
                                                 VD_ERR,
                                                 VD_PAR) THEN
                  DBG('Vd bal....' || VD_ERR || ' - ' || VD_PAR);
                  RAISE VDBAL_UPD_BOMB;
                END IF;
              END IF;
            
              IF ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) < P_LIQ_DT THEN
                DBG('Making aragements to come here again..rare case isnt it');
                L_DUE_DT := ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO);
                ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) := L_DUE_DT;
                ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := L_DUE_DT;
              
                IF NVL(L_DEFERRED_FLG, 'N') <> 'Y' OR
                   ICPKS_BOD.G_FROMBOD = FALSE THEN
                  ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO) := L_DUE_DT;
                END IF;
              
                IF ICPKS_TEST.TB_HAS_ACCR(RECNO) = 'Y' THEN
                  ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) := L_DUE_DT;
                END IF;
              
                BEGIN
                  PR_DO_PROCESS(RECNO, ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO));
                EXCEPTION
                  WHEN OTHERS THEN
                    RAISE DO_PROCESS;
                END;
              
              ELSE
              
                IF TB_INT_ACC_CLOSE.EXISTS(H) THEN
                  DBG('WONT BOMB1');
                ELSE
                  DBG('******WILL BOMB FOR 1' || H);
                  L_NOTHING_TODO1 := TRUE;
                END IF;
              
                IF NOT L_NOTHING_TODO1 THEN
                
                  IF NVL(TB_INT_ACC_CLOSE(H), 'N') <> 'N' THEN
                  
                    L_DUE_DT := P_LIQ_DT;
                    ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) := L_DUE_DT;
                    ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := L_DUE_DT;
                  
                    IF NVL(L_DEFERRED_FLG, 'N') <> 'Y' OR
                       ICPKS_BOD.G_FROMBOD = FALSE THEN
                      ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO) := L_DUE_DT;
                    END IF;
                  
                    IF ICPKS_TEST.TB_HAS_ACCR(RECNO) = 'Y' THEN
                      ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) := L_DUE_DT;
                    END IF;
                  
                    BEGIN
                      PR_DO_PROCESS(RECNO, P_LIQ_DT);
                    EXCEPTION
                      WHEN OTHERS THEN
                        RAISE DO_PROCESS;
                    END;
                  
                  ELSE
                  
                    DBG('bhayya in the loop there is nothing to do for our man');
                    ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) := P_LIQ_DT;
                  END IF;
                
                ELSE
                  DBG('bhayya in the loop there is nothing to do for our man');
                  ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) := P_LIQ_DT;
                END IF;
              
              END IF;
            
              DBG('HERE RAJU BABA 2');
              L_TB_HOFF_CONS.DELETE;
              L_RECORD_COUNT := 1;
              L_SEQ          := ICPKS_TEST.TB_HOFF_CONS.FIRST;
              WHILE L_SEQ <= ICPKS_TEST.TB_HOFF_CONS.LAST LOOP
                DBG('here...');
                L_TB_HOFF_CONS(L_RECORD_COUNT) := ICPKS_TEST.TB_HOFF_CONS(L_SEQ);
                L_SEQ := ICPKS_TEST.TB_HOFF_CONS.NEXT(L_SEQ);
                L_RECORD_COUNT := L_RECORD_COUNT + 1;
              END LOOP;
            
              DBG('icpks_test.tb_hoff_cons count is :' ||
                  ICPKS_TEST.TB_HOFF_CONS.COUNT);
              DBG('l_tb_hoff_cons          count is :' ||
                  L_TB_HOFF_CONS.COUNT);
            
              ICPKS_TEST.TB_HOFF_CONS.DELETE;
            
              ICPKS_TEST.TB_HOFF_CONS := L_TB_HOFF_CONS;
              DBG('icpks_test.tb_hoff_cons count is :' ||
                  ICPKS_TEST.TB_HOFF_CONS.COUNT);
            
              IF NVL(ICPKS_TEST.TB_HOFF_CONS.COUNT, 0) <> 0 THEN
                DBG('INSIDE pr do process account changed so pass entries for prev account');
                IF NOT ICPKS_FCJ_ICDREDMN.G_FROMREDM THEN
                  DBG('before calling Pr_Initerrtbl');
                  OVPKSS.PR_INITERRTBL;
                END IF;
                IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                           1,
                                           APPDT,
                                           ICPKS_TEST.TB_HOFF_CONS,
                                           'B',
                                           'Y',
                                           'N',
                                           UID,
                                           ERRMSG,
                                           EPRM) THEN
                  DBG('In pr do process acpkss gave hand' || ' - ' ||
                      ERRMSG);
                  ICPKSS_TEST.TB_HOFF_CONS.DELETE;
                  OVPKSS.PR_APPENDTBL(ERRMSG, EPRM);
                  RAISE ACTNG_FAILED;
                END IF;
                PR_SPLIT_INT_PAYOUT();
                DBG('Posted entries sucessfully..in do process for :' ||
                    P_LIQ_DT || ' - ' || L_ACC);
                ICPKS_TEST.TB_HOFF_CONS.DELETE;
              ELSE
                DBG('No entries for acc :' || L_ACC);
              END IF;
            
              PR_UPD_ACCPR(RECNO, L_DUE_DT);
              ICPKS_TEST.TB_BKVAL_MINCALC_DATE(RECNO) := NULL;
              ICPKS_TEST.TB_BKVAL_RECALC_FLAG(RECNO) := 'N';
              EXIT WHEN ICPKS_TEST.TB_LAST_LIQ_DT(RECNO) >= P_LIQ_DT;
            END LOOP;
          END IF;
        END IF;
        PR_UPD_ACCPR(RECNO, P_LIQ_DT);
      
      EXCEPTION
        WHEN DO_PROCESS THEN
          DBG('When Do_Process of Pr_call_Process with  ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_RESET_VARIABLES;
          PR_LOG_BOOK_ERR(RECNO,
                          'A',
                          'Do_Process Exception of Pr_call_Process with ' ||
                          SQLERRM);
          DBG('ROLLBACK to do_process ');
          ROLLBACK TO DO_PROCESS;
        
          IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER OR ICPKS_BOD.G_FROMBOD OR
             STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN THEN
          
            RAISE;
          END IF;
        
        WHEN ACTNG_FAILED THEN
          DBG('When Actng_Failed of Pr_call_Process with  ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_RESET_VARIABLES;
          PR_LOG_BOOK_ERR(RECNO,
                          'A',
                          'Actng_Failed Exception of Pr_call_Process with ' ||
                          ERRMSG || SQLERRM);
          PR_PURGE_PLSQL_TABS;
          DBG('ROLLBACK to do_process ');
          ROLLBACK TO DO_PROCESS;
        
          IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER OR ICPKS_BOD.G_FROMBOD OR
             STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN THEN
          
            RAISE;
          END IF;
        
        WHEN BKVAL_BOMBED THEN
          DBG('When Bkval_Bombed of Pr_call_Process with  ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_RESET_VARIABLES;
          PR_LOG_BOOK_ERR(RECNO,
                          'A',
                          'Bkval_Bombed Exception of Pr_call_Process with ' ||
                          SQLERRM);
          DBG('ROLLBACK to do_process ');
          ROLLBACK TO DO_PROCESS;
        
          IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER OR ICPKS_BOD.G_FROMBOD OR
             STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN THEN
          
            RAISE;
          END IF;
        
        WHEN VDBAL_UPD_BOMB THEN
          DBG('When Vdbal_Upd_Bomb of Pr_call_Process with  ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_RESET_VARIABLES;
          PR_LOG_BOOK_ERR(RECNO,
                          'A',
                          'Vdbal_Upd_Bomb Exception of Pr_call_Process with ' ||
                          VD_ERR || '  ' || VD_PAR || SQLERRM);
          DBG('ROLLBACK to do_process ');
          ROLLBACK TO DO_PROCESS;
        
          IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER OR ICPKS_BOD.G_FROMBOD OR
             STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN THEN
          
            RAISE;
          END IF;
        
        WHEN OTHERS THEN
          DBG('In When others of Pr_call_Process with ' || SQLERRM ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_RESET_VARIABLES;
          PR_LOG_BOOK_ERR(RECNO,
                          'A',
                          'When others Exception of Pr_call_Process with ' ||
                          SQLERRM);
          DBG('ROLLBACK to do_process ');
          ROLLBACK TO DO_PROCESS;
        
          IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER OR ICPKS_BOD.G_FROMBOD OR
             STPKS_ACCOUNT_CLOSE.G_ICLIQ_FROM_BEAN THEN
          
            RAISE;
          END IF;
        
      END;
    
      RECNO := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
    END LOOP;
    PR_DUMMMY_TAB_DELETE(RECNO);
    DBG('After dummy table clean up');
    DBG('Going out of do process happiliy..no spell check');
  EXCEPTION
  
    WHEN OTHERS THEN
      DBG('I dont know bombed' || SQLERRM);
      DBG('I dont know bombed lets trace' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
      RAISE;
    
  END PR_CALL_PROCESS;

  FUNCTION FN_CHK_ICACC(RECNO NUMBER) RETURN BOOLEAN IS
    CURSOR CUR_CHK_CCY(P_CCY VARCHAR2) IS
      SELECT *
        FROM CYTM_CCY_DEFN
       WHERE CCY_CODE = P_CCY
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
  
    CURSOR CUR_CHK_ACC_ILM(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT S.*
        FROM STTMS_CUST_ACCOUNT S, ILTB_SYS_ACCOUNT B
       WHERE S.CUST_AC_NO = B.ACCOUNT
         AND
            
             S.BRANCH_CODE = B.BRANCH_CODE
         AND
            
             (S.BRANCH_CODE = P_BRN OR B.SYSTEM_ACCOUNT_BRANCH = P_BRN)
         AND (S.CUST_AC_NO = P_ACC OR B.SYSTEM_ACCOUNT = P_ACC)
         AND S.RECORD_STAT = 'O'
         AND S.AUTH_STAT = 'A'
         AND ROWNUM < 2;
  
    CURSOR CUR_CHK_ACC(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTMS_CUST_ACCOUNT S
       WHERE S.BRANCH_CODE = P_BRN
         AND S.CUST_AC_NO = P_ACC
         AND S.RECORD_STAT = 'O'
         AND S.AUTH_STAT = 'A';
  
    CURSOR CUR_CHK_ICTMACC(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
    
      SELECT I.*
        FROM ICTM_ACC I, ILTB_SYS_ACCOUNT B
       WHERE
      
       (I.ACC = B.ACCOUNT)
       AND (I.BRN = B.SYSTEM_ACCOUNT_BRANCH)
       AND (I.BRN = P_BRN OR B.SYSTEM_ACCOUNT_BRANCH = P_BRN)
       AND (I.ACC = P_ACC OR B.SYSTEM_ACCOUNT = P_ACC)
      
      UNION
      
      SELECT I.*
        FROM ICTM_ACC I
       WHERE I.ACC = P_ACC
         AND I.BRN = P_BRN
            
         AND NVL(I.ACC_TYPE, '#') != 'S';
  
    IN_ACCLOOP BOOLEAN := FALSE;
    IN_ICLOOP  BOOLEAN := FALSE;
    IN_CCYLOOP BOOLEAN := FALSE;
  
    L_SYS_ACCOUNT VARCHAR2(1);
    L_IL_PRODUCT  ICTMS_PR_INT.IL_PRODUCT%TYPE;
    L_CUST_AC_NO  ICTBS_ACC_SYS_MAP.CUST_AC_NO%TYPE;
  
  BEGIN
  
    BEGIN
      SELECT IL_PRODUCT
        INTO L_IL_PRODUCT
        FROM ICTMS_PR_INT
       WHERE PRODUCT_CODE = ICPKSS_TEST.TB_PROD(RECNO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_IL_PRODUCT := 'N';
    END;
  
    IF L_IL_PRODUCT = 'Y' THEN
      SELECT ACCOUNT
        INTO L_CUST_AC_NO
        FROM ILTBS_SYS_ACCOUNT
      
       WHERE SYSTEM_ACCOUNT_BRANCH = ICPKSS_TEST.TB_BRN(RECNO)
         AND SYSTEM_ACCOUNT = ICPKSS_TEST.TB_ACC(RECNO);
    
      L_SYS_ACCOUNT := 'Y';
    ELSE
      L_CUST_AC_NO  := ICPKSS_TEST.TB_ACC(RECNO);
      L_SYS_ACCOUNT := 'N';
    END IF;
  
    IF GLOBALS_ADDON.ILM_INSTALLED = 'Y' THEN
    
      FOR K IN CUR_CHK_ACC_ILM(ICPKSS_TEST.TB_BRN(RECNO),
                               ICPKSS_TEST.TB_ACC(RECNO)) LOOP
        TB_STTM_CUSTACC(RECNO) := K;
        IN_ACCLOOP := TRUE;
      END LOOP;
    END IF;
  
    FOR K IN CUR_CHK_ACC(ICPKSS_TEST.TB_BRN(RECNO),
                         ICPKSS_TEST.TB_ACC(RECNO)) LOOP
      TB_STTM_CUSTACC(RECNO) := K;
      IN_ACCLOOP := TRUE;
    END LOOP;
  
    IF IN_ACCLOOP THEN
      DBG('sttm cust account is OK');
      FOR J IN CUR_CHK_ICTMACC(ICPKSS_TEST.TB_BRN(RECNO),
                               ICPKSS_TEST.TB_ACC(RECNO)) LOOP
        IN_ICLOOP := TRUE;
      
        IF L_SYS_ACCOUNT = 'Y' THEN
        
          DBG('Inside the l_sys_account');
          DBG('Branch passed ' || ICPKSS_TEST.TB_BRN(RECNO));
          DBG('Account passed ' || ICPKSS_TEST.TB_ACC(RECNO));
          DBG('The product value is -->' || L_IL_PRODUCT);
          IF L_IL_PRODUCT = 'Y' THEN
            DBG('Inside il product');
            BEGIN
              SELECT ACCOUNT,
                     'N',
                     SYSTEM_ACCOUNT,
                     BOOKING_ACC_BRANCH,
                     BOOKING_ACC,
                     EFF_DATE,
                     BOOKING_ACC_CCY
                INTO L_CUST_AC_NO,
                     TB_ICTM_ACC (RECNO).ACC_TYPE,
                     TB_ICTM_ACC (RECNO).CALC_ACC,
                     TB_ICTM_ACC (RECNO).BOOK_BRN,
                     TB_ICTM_ACC (RECNO).BOOK_ACC,
                     TB_ICTM_ACC (RECNO).INT_START_DATE,
                     TB_ICTM_ACC (RECNO).BOOK_CCY
                FROM ILTBS_SYS_ACCOUNT
              
               WHERE SYSTEM_ACCOUNT_BRANCH = ICPKSS_TEST.TB_BRN(RECNO)
                 AND SYSTEM_ACCOUNT = ICPKSS_TEST.TB_ACC(RECNO)
                 AND ACC_TYPE = 'C';
            
              DBG('After select 1');
              DBG('Selected booking ccy is -->' || TB_ICTM_ACC(RECNO)
                  .BOOK_CCY);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('In W-O-T of the selection from iltb_sys_account' ||
                    SQLERRM);
                SELECT ACCOUNT,
                       'N',
                       SYSTEM_ACCOUNT,
                       BOOKING_ACC_BRANCH,
                       BOOKING_ACC,
                       EFF_DATE,
                       BOOKING_ACC_CCY
                  INTO L_CUST_AC_NO,
                       TB_ICTM_ACC (RECNO).ACC_TYPE,
                       TB_ICTM_ACC (RECNO).CALC_ACC,
                       TB_ICTM_ACC (RECNO).BOOK_BRN,
                       TB_ICTM_ACC (RECNO).BOOK_ACC,
                       TB_ICTM_ACC (RECNO).INT_START_DATE,
                       TB_ICTM_ACC (RECNO).BOOK_CCY
                  FROM ILTBS_SYS_ACCOUNT
                
                 WHERE SYSTEM_ACCOUNT_BRANCH = ICPKSS_TEST.TB_BRN(RECNO)
                   AND SYSTEM_ACCOUNT = ICPKSS_TEST.TB_ACC(RECNO)
                   AND ROWNUM < 2;
            END;
          
          ELSE
          
            SELECT CUST_AC_NO,
                   AC_TYPE,
                   CALC_SYSTEM_AC_NO,
                   INT_BOOK_AC_BRANCH,
                   INT_BOOK_AC_NO,
                   INT_BOOK_AC_CCY,
                   START_DATE,
                   WITH_ACCOUNTING
              INTO L_CUST_AC_NO,
                   TB_ICTM_ACC                  (RECNO).ACC_TYPE,
                   TB_ICTM_ACC                  (RECNO).CALC_ACC,
                   TB_ICTM_ACC                  (RECNO).BOOK_BRN,
                   TB_ICTM_ACC                  (RECNO).BOOK_ACC,
                   TB_ICTM_ACC                  (RECNO).BOOK_CCY,
                   TB_ICTM_ACC                  (RECNO).INT_START_DATE,
                   ICPKSS_TEST.G_WITH_ACCOUNTING
              FROM ICTBS_ACC_SYS_MAP
             WHERE AC_BRANCH = ICPKSS_TEST.TB_BRN(RECNO)
               AND POOL_SYSTEM_AC_NO = ICPKSS_TEST.TB_ACC(RECNO);
          END IF;
        
          TB_ICTM_ACC(RECNO).BRN := J.BRN;
          TB_ICTM_ACC(RECNO).ACC := J.ACC;
          TB_ICTM_ACC(RECNO).HAS_IS := J.HAS_IS;
          TB_ICTM_ACC(RECNO).LAST_IS_DATE := J.LAST_IS_DATE;
        
          TB_ICTM_ACC(RECNO).COMBVT_DATE := J.COMBVT_DATE;
        
        ELSE
        
          TB_ICTM_ACC(RECNO) := J;
        END IF;
      
      END LOOP;
    
      IF IN_ICLOOP THEN
      
        FOR I IN CUR_CHK_CCY(TB_STTM_CUSTACC(RECNO).CCY) LOOP
          IN_CCYLOOP := TRUE;
        END LOOP;
      
        IF NOT IN_CCYLOOP THEN
          DBG('currenyc has some haath' || ICPKS_TEST.TB_CCY(RECNO));
          RETURN FALSE;
        END IF;
      
      ELSE
        DBG('Haaath with ictm_acc' || ICPKS_TEST.TB_ACC(RECNO) || ' - ' ||
            ICPKS_TEST.TB_BRN(RECNO));
        RETURN FALSE;
      END IF;
    ELSE
      DBG('Haaath with sttms_cust acc' || ICPKS_TEST.TB_ACC(RECNO) ||
          ' - ' || ICPKS_TEST.TB_BRN(RECNO));
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Jai Hind...problem in some case' || SQLERRM);
      RETURN FALSE;
  END FN_CHK_ICACC;

  FUNCTION FN_CHK_PROD(ROWNUM NUMBER) RETURN BOOLEAN IS
    CURSOR CUR_CHK_PROD(P_PROD VARCHAR2) IS
      SELECT *
        FROM ICTMS_PRODUCT_DEFINITION
       WHERE PRODUCT_CODE = P_PROD
         AND PRODUCT_TYPE IN ('I', 'P')
         AND OK = 'Y';
    CURSOR CUR_ICPRINT(P_PROD VARCHAR2) IS
      SELECT * FROM ICTMS_PR_INT WHERE PRODUCT_CODE = P_PROD;
  
    CURSOR CUR_ICRULE(P_RULE VARCHAR2) IS
      SELECT *
        FROM ICTMS_RULE
       WHERE RULE_ID = P_RULE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    CURSOR CUR_RULEFRM(P_RULE VARCHAR2) IS
      SELECT * FROM ICTMS_RULE_FRM WHERE RULE_ID = P_RULE;
  
    H BINARY_INTEGER;
  
    IN_RULELOOP    BOOLEAN;
    IN_PRODOK_LOOP BOOLEAN;
    PROCEDURE POP_STR(STR_VAL VARCHAR2,
                      STR_POS VARCHAR2,
                      
                      K BINARY_INTEGER)
    
     IS
    BEGIN
      DBG('Inside pop_str');
      IF STR_POS = 1 THEN
        ICPKS_TEST.TB_PRINT(K).FRM_VAL_STR := STR_VAL ||
                                              RPAD(NVL(SUBSTR(ICPKS_TEST.TB_PRINT(K)
                                                              .FRM_VAL_STR,
                                                              2),
                                                       ' '),
                                                   (L_COMMIT_FREQ - 1));
      ELSE
        ICPKS_TEST.TB_PRINT(K).FRM_VAL_STR := RPAD(NVL(SUBSTR(ICPKS_TEST.TB_PRINT(K)
                                                              .FRM_VAL_STR,
                                                              1,
                                                              STR_POS - 1),
                                                       ' '),
                                                   STR_POS - 1) || STR_VAL ||
                                              RPAD(NVL(SUBSTR(ICPKS_TEST.TB_PRINT(K)
                                                              .FRM_VAL_STR,
                                                              STR_POS + 1),
                                                       ' '),
                                                   (L_COMMIT_FREQ - STR_POS));
      END IF;
    END POP_STR;
  
  BEGIN
    FOR I IN CUR_CHK_PROD(ICPKS_TEST.TB_PROD(ROWNUM)) LOOP
      H := CSPKSS_UTILS.FN_HASH40(ICPKSS_TEST.TB_PROD(ROWNUM));
    
      DBG('The prod ' || ' - ' || ICPKSS_TEST.TB_PROD(ROWNUM) || ' - ' || H);
    
      DBG('insdie icpksstest.tbprint exist:' || H);
      FOR EACH_ROW IN CUR_ICPRINT(ICPKSS_TEST.TB_PROD(ROWNUM)) LOOP
        FOR K IN CUR_ICRULE(EACH_ROW.RULE) LOOP
          DBG('assigning tb int acc close :' || H);
        
          TB_INT_ACC_CLOSE(H) := K.INT_ACC_CLOSE;
          IN_RULELOOP := TRUE;
        END LOOP;
        IF NOT ICPKSS_TEST.TB_PRINT.EXISTS(H) THEN
        
          IF IN_RULELOOP THEN
            ICPKS_TEST.TB_PRINT(H).PRODUCT_CODE := EACH_ROW.PRODUCT_CODE;
            ICPKS_TEST.TB_PRINT(H).RULE := EACH_ROW.RULE;
            ICPKS_TEST.TB_PRINT(H).LIQN_DAYS := EACH_ROW.LIQN_DAYS;
            ICPKS_TEST.TB_PRINT(H).LIQN_MONTHS := EACH_ROW.LIQN_MONTHS;
            ICPKS_TEST.TB_PRINT(H).LIQN_YEARS := EACH_ROW.LIQN_YEARS;
            ICPKS_TEST.TB_PRINT(H).LIQN_START_ACCOUNT := EACH_ROW.LIQN_START_ACCOUNT;
            ICPKS_TEST.TB_PRINT(H).LIQN_START_DATE := EACH_ROW.LIQN_START_DATE;
            ICPKS_TEST.TB_PRINT(H).LIQN_EOM := EACH_ROW.LIQN_EOM;
            ICPKS_TEST.TB_PRINT(H).ACCR_PROD_LEVEL := EACH_ROW.ACCR_PROD_LEVEL;
            ICPKS_TEST.TB_PRINT(H).ACCR_FREQ := EACH_ROW.ACCR_FREQ;
            ICPKS_TEST.TB_PRINT(H).ACCR_MONTH := EACH_ROW.ACCR_MONTH;
            ICPKS_TEST.TB_PRINT(H).ACCR_EOM := EACH_ROW.ACCR_EOM;
            ICPKS_TEST.TB_PRINT(H).ACCR_DAY := EACH_ROW.ACCR_DAY;
            ICPKS_TEST.TB_PRINT(H).UDE_CCY := EACH_ROW.UDE_CCY;
            ICPKS_TEST.TB_PRINT(H).FIRST_CALC_DATE := EACH_ROW.FIRST_CALC_DATE;
            ICPKS_TEST.TB_PRINT(H).FIRST_ACCR_DATE := EACH_ROW.FIRST_ACCR_DATE;
            ICPKS_TEST.TB_PRINT(H).BACK_CALC_FLAG := EACH_ROW.BACK_CALC_FLAG;
            ICPKS_TEST.TB_PRINT(H).LIQN_BF_MTHEND := EACH_ROW.LIQN_BF_MTHEND;
            ICPKS_TEST.TB_PRINT(H).DAYS_BF_MTHEND := EACH_ROW.DAYS_BF_MTHEND;
            ICPKS_TEST.TB_PRINT(H).PNL_REPLACE := EACH_ROW.PNL_REPLACE;
          
            ICPKS_TEST.TB_PRINT(H).DEFERRED_FLAG := EACH_ROW.DEFERRED_FLAG;
            ICPKS_TEST.TB_PRINT(H).CALC_DAYS := EACH_ROW.CALC_DAYS;
          
            ICPKSS_TEST.TB_PRINT(H).IL_TYPE := EACH_ROW.IL_TYPE;
            ICPKSS_TEST.TB_PRINT(H).IL_PRODUCT := EACH_ROW.IL_PRODUCT;
          
            IF EACH_ROW.ACCR_FREQ = 'M' THEN
              ICPKS_TEST.TB_PRINT(H).MTH_COUNT := 1;
            ELSIF EACH_ROW.ACCR_FREQ = 'Q' THEN
              ICPKS_TEST.TB_PRINT(H).MTH_COUNT := 3;
            ELSIF EACH_ROW.ACCR_FREQ = 'S' THEN
              ICPKS_TEST.TB_PRINT(H).MTH_COUNT := 6;
            ELSIF EACH_ROW.ACCR_FREQ = 'A' THEN
              ICPKS_TEST.TB_PRINT(H).MTH_COUNT := 12;
            END IF;
          
            FOR LVAR IN CUR_RULEFRM(EACH_ROW.RULE) LOOP
              POP_STR(LVAR.TAX_PAY_CCY_FLAG, LVAR.FRM_NO, H);
            
              IF LVAR.BOOK_FLAG = 'T' THEN
                ICPKSS_TEST.TB_PRINT(H).TAX_CATEGORY := LVAR.TAX_CATEGORY;
                DBG('Setting the Tax Category ' || ICPKSS_TEST.TB_PRINT(H)
                    .TAX_CATEGORY);
              END IF;
            
              BEGIN
                SELECT 'Y'
                  INTO ICPKSS_TEST.TB_PRINT(H).IS_FMT
                  FROM ICTM_IS_FMT
                 WHERE RULE_ID = ICPKSS_TEST.TB_PRINT(H).RULE
                   AND ROWNUM = 1;
              EXCEPTION
                WHEN OTHERS THEN
                  ICPKSS_TEST.TB_PRINT(H).IS_FMT := 'N';
              END;
            
            END LOOP;
          END IF;
        ELSE
          DBG('think it falls here without populating');
          RETURN TRUE;
        END IF;
      END LOOP;
      IN_PRODOK_LOOP := TRUE;
    END LOOP;
  
    IF NOT IN_PRODOK_LOOP THEN
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('No product jai hind' || SQLERRM);
      RETURN FALSE;
  END FN_CHK_PROD;

  PROCEDURE PR_DELETE_ACCPR_ROW(RECNO NUMBER) IS
  BEGIN
    ICPKS_TEST.TB_BRN.DELETE(RECNO);
    ICPKS_TEST.TB_ACC.DELETE(RECNO);
    ICPKS_TEST.TB_PROD.DELETE(RECNO);
    ICPKS_TEST.TB_SC_MAP_DT.DELETE(RECNO);
    ICPKS_TEST.TB_GC_MAP_DT.DELETE(RECNO);
    ICPKS_TEST.TB_LAST_CALC_DT.DELETE(RECNO);
    ICPKS_TEST.TB_LAST_LIQ_DT.DELETE(RECNO);
    ICPKS_TEST.TB_NEXT_LIQ_DT.DELETE(RECNO);
    ICPKS_TEST.TB_LAST_ACCR_DT.DELETE(RECNO);
    ICPKS_TEST.TB_NEXT_ACCR_DT.DELETE(RECNO);
    ICPKS_TEST.TB_LAST_SCHD_LIQ_DT.DELETE(RECNO);
    ICPKS_TEST.TB_INC_MTH.DELETE(RECNO);
    ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT.DELETE(RECNO);
    ICPKS_TEST.TB_FIRST_CALC_DT.DELETE(RECNO);
    ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT.DELETE(RECNO);
    ICPKS_TEST.TB_PROD_TYPE.DELETE(RECNO);
    ICPKS_TEST.TB_HAS_ACCR.DELETE(RECNO);
    ICPKS_TEST.TB_NEXT_CALC_DT.DELETE(RECNO);
    ICPKS_TEST.TB_PROD_ACCR.DELETE(RECNO);
    ICPKS_TEST.TB_HAS_PROBLEMS.DELETE(RECNO);
    ICPKS_TEST.TB_BKVAL_MINCALC_DATE.DELETE(RECNO);
    ICPKS_TEST.TB_BKVAL_RECALC_FLAG.DELETE(RECNO);
    ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE.DELETE(RECNO);
    ICPKS_TEST.TB_IMAT_PROBLEMS.DELETE(RECNO);
    ICPKS_TEST.TB_DEPOSIT.DELETE(RECNO);
    ICPKS_TEST.TB_ACLASS.DELETE(RECNO);
    ICPKS_TEST.TB_CCY.DELETE(RECNO);
  
    ICPKS_TEST.TB_NEXT_EVENT_DT.DELETE(RECNO);
    ICPKS_TEST.TB_DEFER_LIQ_DT.DELETE(RECNO);
  
    BEGIN
      TB_STTM_CUSTACC.DELETE(RECNO);
      TB_ICTM_ACC.DELETE(RECNO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Our man is not yet populated');
    END;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('delete has some haath');
  END PR_DELETE_ACCPR_ROW;

  PROCEDURE PR_DO_PROCESS(RECNO NUMBER, P_LIQ_DT DATE) IS
    I             NUMBER;
    J             NUMBER := 0;
    L_START_INDEX BINARY_INTEGER;
    LAST_REC      NUMBER := 0;
    H             BINARY_INTEGER;
    L_EXIST       BOOLEAN;
    L_END_INDEX   BINARY_INTEGER;
    L_COUNT       NUMBER := 0;
    L_UPD         BOOLEAN;
    REPOP_PROD    ICTBS_ACC_PR.PROD%TYPE;
    REPOP_ACLASS  ICTBS_ACC_PR.ACLASS%TYPE;
    REPOP_CCY     ICTBS_ACC_PR.CCY%TYPE;
    PREV_COUNT    NUMBER := 0;
    L_UDE_ID      ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_UDE_VALUE   ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_RATE_CODE   ICTMS_PR_INT_UDEVALS.RATE_CODE%TYPE;
    K             NUMBER := 0;
    L_ENTRY_COUNT NUMBER := 0;
    X             VARCHAR2(10);
    Y             VARCHAR2(10);
    POS           NUMBER;
    POS1          NUMBER;
    CALC_ACC      STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    R_PRINT       ICPKSS_TEST.REC_PRINT;
    L_ACC         STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN         STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS      STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY         STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD        ICTBS_ACC_PR.PROD%TYPE;
    L_REC_PRINT   ICPKSS_TEST.REC_PRINT;
  
    L_ERROR_CODE VARCHAR2(1000);
    ERRMSG       VARCHAR2(1000);
  
    L_ZAKAT_EXEMPT VARCHAR2(1);
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_VAL_DT DATE;
  BEGIN
    DBG('Inside Pr_Do_Process');
    ICPKSS_TEST.TB_ICENT.DELETE;
    SAVEPOINT ONLIQ_IN_ACTION;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      ICPKS_ONLIQ_NEW_CLUSTER.PR_DO_PROCESS(RECNO,
                                            P_LIQ_DT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
    END IF;
  
    DBG('Entered into do process for' || ICPKS_TEST.TB_ACC(RECNO) || ' - ' ||
        ICPKS_TEST.TB_CCY(RECNO));
    IF NVL(ICPKS_TEST.TB_ACLASS(RECNO), '***') <> NVL(L_ACLASS, '###') OR
       NVL(ICPKS_TEST.TB_CCY(RECNO), '****') <> NVL(L_CCY, '###') THEN
      SELECT AC_CLASS_TYPE
        INTO ICPKS_TEST.G_ACC_TYPE
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = ICPKS_TEST.TB_ACLASS(RECNO);
    END IF;
  
    IF NVL(ICPKS_TEST.TB_ACC(RECNO), '***') <> NVL(L_ACC, '###') OR
       NVL(ICPKS_TEST.TB_BRN(RECNO), '***') <> NVL(L_BRN, '###') THEN
      SELECT DEFAULT_MEDIA
        INTO ICPKS_TEST.G_DEFAULT_MEDIA
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = ICPKS_TEST.G_STTM_CUSTACC.CUST_NO;
    END IF;
  
    DBG('Global parameters are set');
    IF NVL(ICPKS_TEST.TB_PROD(RECNO), '****') <> NVL(L_PROD, '###') THEN
      ICPKS_TEST.PR_CACHE_PROD(ICPKS_TEST.TB_PROD(RECNO),
                               ICPKS_TEST.G_STTM_CUSTACC.ACC_STATUS);
    END IF;
    DBG('after cache product' || ICPKS_TEST.TB_ACLASS(RECNO));
  
    DBG('calc ho ya naho hame to select karna hi hai');
    FOR CUR_ICENT IN (SELECT E.*, E.ROWID ROW_ID
                        FROM ICTBS_ENTRIES E
                       WHERE E.BRN = ICPKS_TEST.TB_BRN(RECNO)
                         AND E.ACC = ICPKS_TEST.TB_ACC(RECNO)
                         AND E.PROD = ICPKS_TEST.TB_PROD(RECNO)) LOOP
      J := J + 1;
      ICPKS_TEST.TB_ICENT(J).ACC := CUR_ICENT.ACC;
      ICPKS_TEST.TB_ICENT(J).BRN := CUR_ICENT.BRN;
      ICPKS_TEST.TB_ICENT(J).PROD := CUR_ICENT.PROD;
      ICPKS_TEST.TB_ICENT(J).FRM_NO := CUR_ICENT.FRM_NO;
      ICPKS_TEST.TB_ICENT(J).AMT := NVL(CUR_ICENT.AMT, 0);
      ICPKS_TEST.TB_ICENT(J).ACCRUED_AMT := NVL(CUR_ICENT.ACCRUED_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).AMT_TO_ACCRUE := NVL(CUR_ICENT.AMT_TO_ACCRUE,
                                                  0);
      ICPKS_TEST.TB_ICENT(J).CUR_RUN_ACCR := NVL(CUR_ICENT.CUR_RUN_ACCR, 0);
      ICPKS_TEST.TB_ICENT(J).ENT_DT := CUR_ICENT.ENT_DT;
      ICPKS_TEST.TB_ICENT(J).DRCR := CUR_ICENT.DRCR;
      ICPKS_TEST.TB_ICENT(J).HAS_ACCR := CUR_ICENT.HAS_ACCR;
      ICPKS_TEST.TB_ICENT(J).DAILY_AMT := NVL(CUR_ICENT.DAILY_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).NEXT_CALC_DUE_DATE := CUR_ICENT.NEXT_CALC_DUE_DATE;
      ICPKS_TEST.TB_ICENT(J).ACQUIRED_AMT := NVL(CUR_ICENT.ACQUIRED_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).ACQUIRED_ADJ := NVL(CUR_ICENT.ACQUIRED_ADJ, 0);
      ICPKS_TEST.TB_ICENT(J).ROW_ID := CUR_ICENT.ROW_ID;
      DBG('got entrie no : ' || J || '~' || CUR_ICENT.AMT);
      DBG('The acquired amount is coming here as ' || ICPKS_TEST.TB_ICENT(J)
          .ACQUIRED_AMT);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID := 2;
        L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        L_TB_CLUSTER_DATA('Cur_Icent.Acc') := CUR_ICENT.ACC;
        L_TB_CLUSTER_DATA('Cur_Icent.Brn') := CUR_ICENT.BRN;
        L_TB_CLUSTER_DATA('Cur_Icent.Prod') := CUR_ICENT.PROD;
        L_TB_CLUSTER_DATA('Cur_Icent.Frm_No') := CUR_ICENT.FRM_NO;
        L_TB_CLUSTER_DATA('j') := J;
        ICPKS_ONLIQ_NEW_CLUSTER.PR_DO_PROCESS(RECNO,
                                              P_LIQ_DT,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA);
      END IF;
    
    END LOOP;
  
    DBG('ictb entries gave me :' || ICPKS_TEST.TB_ICENT.COUNT);
  
    DBG('Date Aye/Na Aaye - Aaj calc bhi karnahai' ||
        ICPKS_TEST.TB_ACC(RECNO) || ICPKS_TEST.TB_BRN(RECNO));
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      IF ICPKS_TEST.TB_BRN.EXISTS(RECNO) THEN
        L_TB_CLUSTER_DATA('Icpks_Test.Tb_Brn(Recno)') := ICPKS_TEST.TB_BRN(RECNO);
      END IF;
      ICPKS_ONLIQ_NEW_CLUSTER.PR_DO_PROCESS(RECNO,
                                            P_LIQ_DT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
      IF L_TB_CLUSTER_DATA.EXISTS('Icpks_Test.Tb_Brn(Recno)') THEN
        ICPKS_TEST.TB_BRN(RECNO) := L_TB_CLUSTER_DATA('Icpks_Test.Tb_Brn(Recno)');
      END IF;
    END IF;
  
    ICPKSS_CALC.G_ICTB_ACC_PR.BRN               := ICPKS_TEST.TB_BRN(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.ACC               := ICPKS_TEST.TB_ACC(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD              := ICPKS_TEST.TB_PROD(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT         := ICPKS_TEST.TB_SC_MAP_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT         := ICPKS_TEST.TB_GC_MAP_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT      := ICPKS_TEST.TB_LAST_CALC_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT       := ICPKS_TEST.TB_LAST_LIQ_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT       := ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT      := ICPKS_TEST.TB_LAST_ACCR_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT  := ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH           := ICPKS_TEST.TB_INC_MTH(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT  := ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT     := ICPKS_TEST.TB_FIRST_CALC_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE         := ICPKS_TEST.TB_PROD_TYPE(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR          := ICPKS_TEST.TB_HAS_ACCR(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT      := ICPKS_TEST.TB_NEXT_CALC_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR         := ICPKS_TEST.TB_PROD_ACCR(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT      := ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO);
    ICPKSS_CALC.G_ICTB_ACC_PR.BKVAL_RECALC_FLAG := ICPKS_TEST.TB_BKVAL_RECALC_FLAG(RECNO);
    ICPKSS_CALC.G_CUST_ACC.CCY                  := ICPKS_TEST.TB_CCY(RECNO);
    ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS        := ICPKS_TEST.TB_ACLASS(RECNO);
  
    ICPKS_UDE.PR_PREPARE_GC(ICPKS_TEST.TB_BRN(RECNO),
                            ICPKS_TEST.TB_ACLASS(RECNO),
                            ICPKS_TEST.TB_CCY(RECNO),
                            ICPKS_TEST.TB_PROD(RECNO),
                            ICPKS_TEST.TB_FIRST_CALC_DT(RECNO),
                            P_LIQ_DT,
                            ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO));
  
    IF NVL(ICPKS_TEST.G_ICTM_ACC.ACC_TYPE, 'N') = 'N' THEN
      ICPKS_SDE.PR_PREPARE_SDE(ICPKS_TEST.TB_BRN(RECNO),
                               ICPKS_TEST.TB_ACC(RECNO),
                               ICPKS_TEST.TB_CCY(RECNO),
                               RECNO,
                               RECNO);
    ELSE
      DBG('This is a consolidated account');
      ICPKS_SDE.PR_PREPARE_SDE_CONSOL(ICPKS_TEST.TB_BRN(RECNO),
                                      ICPKS_TEST.TB_ACC(RECNO),
                                      ICPKS_TEST.TB_CCY(RECNO),
                                      RECNO,
                                      RECNO);
    END IF;
  
    DBG('calling icpkss_calc.set_acc_details for penalty value setting with recno' ||
        ICPKS_TEST.TB_ACC(RECNO));
    ICPKSS_CALC.SET_ACC_DETAILS(ICPKS_TEST.TB_BRN(RECNO),
                                ICPKS_TEST.TB_ACC(RECNO));
    DBG('After set_acc_details');
  
    ICPKS_TEST.PR_CALC(ICPKS_TEST.TB_BRN(RECNO),
                       ICPKS_TEST.TB_ACC(RECNO),
                       ICPKS_TEST.TB_PROD(RECNO),
                       P_LIQ_DT,
                       ICPKS_TEST.TB_ICENT);
  
    FIND_KEY(ICPKS_TEST.TB_PROD(RECNO), L_REC_PRINT);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
      L_FN_CALL_ID      := 5;
    
      ICPKS_ONLIQ_NEW_CLUSTER.PR_DO_PROCESS(RECNO,
                                            P_LIQ_DT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
    
    END IF;
  
    IF L_REC_PRINT.TAX_CATEGORY IS NULL THEN
      ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) + 1;
    ELSE
      IF L_REC_PRINT.DEFERRED_FLAG = 'Y' THEN
        ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := LEAST(ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO),
                                                   NVL(ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO),
                                                       ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO)));
      ELSE
        ICPKS_TEST.TB_NEXT_CALC_DT(RECNO) := ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO);
      END IF;
    END IF;
  
    IF ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS = 'N' THEN
      ICPKS_TEST.TB_LAST_CALC_DT(RECNO) := APPDT;
    ELSE
      ICPKS_TEST.TB_LAST_CALC_DT(RECNO) := P_LIQ_DT;
    END IF;
  
    L_ENTRY_COUNT := ICPKS_TEST.TB_ICENT.COUNT;
    IF L_ENTRY_COUNT <> 0 THEN
    
      BEGIN
        SELECT NVL(ZAKAT_EXEMPTION, 'N')
          INTO L_ZAKAT_EXEMPT
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = ICPKS_TEST.TB_BRN(RECNO)
           AND CUST_AC_NO = ICPKS_TEST.TB_ACC(RECNO);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
      END;
    
      IF ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) <= P_LIQ_DT AND
         ICPKS_TEST.TB_HAS_ACCR(RECNO) = 'Y' THEN
        DBG('PR_ACCRUE BEING CALLED' || ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO) || '~' ||
            ICPKS_TEST.TB_LAST_ACCR_DT(RECNO) || '~' || APPDT);
        ICPKS_TEST.TB_BASIC_HOFF(1).EVENT := 'IACR';
        ICPKS_TEST.TB_BASIC_HOFF(1).TRN_DT := APPDT;
      
        IF ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS = 'N' THEN
        
          IF CSPKS_ACC_SERVICE.G_CLOSE_OUT_WITHDRAWL AND
             CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH',
                                        ICPKS_TEST.TB_BRN(RECNO)) AND
             TDPKS_UTILS.G_INTRADAY_POSTING
          
           THEN
            SELECT MAX(VALUE_DT)
              INTO L_VAL_DT
              FROM ICTB_DEFERRED_ENTRIES
             WHERE AC_BRANCH = ICPKS_TEST.TB_BRN(RECNO)
               AND RELATED_ACCOUNT = ICPKS_TEST.TB_ACC(RECNO)
               AND INTRADAY = 'Y';
            DBG('l_val_Dt=' || L_VAL_DT);
          END IF;
        
          ICPKS_TEST.TB_BASIC_HOFF(1).VALUE_DT := NVL(L_VAL_DT,
                                                      ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO));
        
        ELSE
          ICPKS_TEST.TB_BASIC_HOFF(1).VALUE_DT := GREATEST(ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO),
                                                           NVL(ICPKS_TEST.TB_LAST_ACCR_DT(RECNO),
                                                               ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO)));
        END IF;
      
        ICPKS_TEST.TB_PROD_ACCR(RECNO) := 'N';
      
        BEGIN
          ICPKS_TEST.PR_ACCRUE(P_LIQ_DT, RECNO, ICPKS_TEST.TB_ICENT);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE;
        END;
      
        IF NOT ICPKSS_TEST.G_POP_ACCR_ENTRY THEN
          DBG('No accrual entry for this account posted..need not updated accr entries for ' ||
              ICPKS_TEST.TB_ACC(RECNO));
          ICPKSS_TEST.G_TB_SKIPPED_ACCTS(ICPKS_TEST.TB_BRN(RECNO) || ICPKS_TEST.TB_ACC(RECNO) || ICPKS_TEST.TB_PROD(RECNO)) := 1;
        END IF;
      
        DBG('Here comes the original guy accrdt' || ' - ' ||
            ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO));
      END IF;
    
      IF (ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO) <= P_LIQ_DT AND
         NVL(ICPKS_TEST.TB_HAS_PROBLEMS(RECNO), 'N') <> 'Y') THEN
        DBG('Today is liquidation date' || ICPKS_TEST.TB_ICENT.COUNT);
        ICPKS_TEST.PKG_LIQ_NETTING := 'N';
      
        BEGIN
          ICPKS_TEST.PR_LIQ_INT(P_LIQ_DT, RECNO, ICPKS_TEST.TB_ICENT);
        EXCEPTION
          WHEN OTHERS THEN
            RAISE;
        END;
      
      END IF;
    
      LAST_REC := NVL(ICPKS_TEST.TB_ICENT_UPD_ACC.LAST, 0);
      FOR I IN ICPKS_TEST.TB_ICENT.FIRST .. ICPKS_TEST.TB_ICENT.LAST LOOP
        DBG('inserting for entries update' || '~' || LAST_REC);
        ICPKS_TEST.TB_ICENT_UPD_ACC(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I).ACC;
        ICPKS_TEST.TB_ICENT_UPD_AMT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I).AMT;
        ICPKS_TEST.TB_ICENT_UPD_ACCRUED_AMT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                             .ACCRUED_AMT;
        ICPKS_TEST.TB_ICENT_UPD_AMT_TO_ACCRUE(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                               .AMT_TO_ACCRUE;
        ICPKS_TEST.TB_ICENT_UPD_CUR_RUN_ACCR(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                              .CUR_RUN_ACCR;
        ICPKS_TEST.TB_ICENT_UPD_ENT_DT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                        .ENT_DT;
        ICPKS_TEST.TB_ICENT_UPD_DRCR(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I).DRCR;
        ICPKS_TEST.TB_ICENT_UPD_DAILY_AMT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                           .DAILY_AMT;
        ICPKS_TEST.TB_ICENT_UPD_NEXT_CALC_DUE_DT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                                  .NEXT_CALC_DUE_DATE;
        ICPKS_TEST.TB_ICENT_UPD_ACQUIRED_AMT(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                              .ACQUIRED_AMT;
        ICPKS_TEST.TB_ICENT_UPD_ACQUIRED_ADJ(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                              .ACQUIRED_ADJ;
        ICPKS_TEST.TB_ICENT_UPD_ROWID(LAST_REC + I) := ICPKS_TEST.TB_ICENT(I)
                                                       .ROW_ID;
      END LOOP;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID := 3;
        L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        L_TB_CLUSTER_DATA('Last_Rec') := LAST_REC;
        ICPKS_ONLIQ_NEW_CLUSTER.PR_DO_PROCESS(RECNO,
                                              P_LIQ_DT,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA);
      END IF;
    
    END IF;
    L_ACC  := ICPKS_TEST.TB_ACC(RECNO);
    L_BRN  := ICPKS_TEST.TB_BRN(RECNO);
    L_PROD := ICPKS_TEST.TB_PROD(RECNO);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Bombed in pr_do_process for ' || P_LIQ_DT || '~' ||
          ICPKS_TEST.TB_ACC(RECNO));
      DBG('Error is...' || SQLERRM);
      ROLLBACK TO ONLIQ_IN_ACTION;
      LOG_PROBLEM(RECNO, 'A', 'doprocess');
      ICPKSS_TEST.TB_ICENT.DELETE;
    
      RAISE;
  END PR_DO_PROCESS;

  PROCEDURE FIND_KEY(P_PROD      VARCHAR2,
                     P_ICTMPRINT IN OUT ICPKS_TEST.REC_PRINT) IS
    H BINARY_INTEGER;
  
  BEGIN
    H := CSPKSS_UTILS.FN_HASH40(P_PROD);
  
    P_ICTMPRINT := ICPKS_TEST.TB_PRINT(H);
  
  END FIND_KEY;

  PROCEDURE PR_UPD_ACCPR(RECNO NUMBER, P_DT DATE) IS
    K      NUMBER := 0;
    BUG1   PLS_INTEGER := -1;
    VD_ERP VARCHAR2(1000);
  
    L_SEQ_NO NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_IDX       PLS_INTEGER;
    L_UPD_COUNT NUMBER;
  
    L_IS_HOLIDAY VARCHAR2(1);
    L_REC_PR_INT ICTM_PR_INT%ROWTYPE;
  
  BEGIN
    DBG('Going to update accpr..');
  
    IF NVL(ICPKS_BOD.UNCLAIMED_PROCESS, 'Y') = 'Y' THEN
    
      DBG('updating ICTBS_ACC_PR');
      UPDATE ICTBS_ACC_PR
         SET NEXT_ACCR_DT        = ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO),
             NEXT_LIQ_DT         = ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO),
             NEXT_EVENT_DT       = ICPKS_TEST.TB_NEXT_EVENT_DT(RECNO),
             NEXT_CALC_DT        = ICPKS_TEST.TB_NEXT_CALC_DT(RECNO),
             NEXT_SCHD_ACCR_DT   = ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(RECNO),
             NEXT_SCHD_LIQ_DT    = ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(RECNO),
             HAS_PROBLEMS        = ICPKS_TEST.TB_HAS_PROBLEMS(RECNO),
             LAST_SCHD_LIQ_DT    = ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(RECNO),
             LAST_ACCR_DT        = ICPKS_TEST.TB_LAST_ACCR_DT(RECNO),
             LAST_LIQ_DT         = ICPKS_TEST.TB_LAST_LIQ_DT(RECNO),
             LAST_CALC_DT        = ICPKS_TEST.TB_LAST_CALC_DT(RECNO),
             BKVAL_RECALC_FLAG   = 'N',
             BKVAL_MINCALC_DATE  = NULL,
             FIRST_CALC_DT       = ICPKS_TEST.TB_FIRST_CALC_DT(RECNO),
             DEFER_LIQ_DT        = ICPKS_TEST.TB_DEFER_LIQ_DT(RECNO),
             RECALC_ACCR_ON_LIQN = 'Y'
       WHERE ROWID = ICPKS_TEST.TB_ROWID(RECNO)
         AND NVL(STOP_IC, 'N') = 'N';
    
    ELSIF ICPKS_BOD.UNCLAIMED_PROCESS = 'N' THEN
      DBG('may i come in');
      UPDATE ICTW_ACCPR_SEL
         SET NEXT_ACCR_DT       = ICPKS_TEST.TB_NEXT_ACCR_DT(RECNO),
             NEXT_LIQ_DT        = ICPKS_TEST.TB_NEXT_LIQ_DT(RECNO),
             NEXT_EVENT_DT      = ICPKS_TEST.TB_NEXT_EVENT_DT(RECNO),
             NEXT_CALC_DT       = ICPKS_TEST.TB_NEXT_CALC_DT(RECNO),
             NEXT_SCHD_ACCR_DT  = ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(RECNO),
             NEXT_SCHD_LIQ_DT   = ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(RECNO),
             HAS_PROBLEMS       = ICPKS_TEST.TB_HAS_PROBLEMS(RECNO),
             LAST_SCHD_LIQ_DT   = ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(RECNO),
             LAST_ACCR_DT       = ICPKS_TEST.TB_LAST_ACCR_DT(RECNO),
             LAST_LIQ_DT        = ICPKS_TEST.TB_LAST_LIQ_DT(RECNO),
             LAST_CALC_DT       = ICPKS_TEST.TB_LAST_CALC_DT(RECNO),
             BKVAL_RECALC_FLAG  = 'N',
             BKVAL_MINCALC_DATE = NULL,
             FIRST_CALC_DT      = ICPKS_TEST.TB_FIRST_CALC_DT(RECNO)
       WHERE ROWID = ICPKS_TEST.TB_ROWID(RECNO);
    
      DBG('nothing but wind');
    END IF;
    DBG('Done with the update of accpr');
  
    IF ICPKS_TEST.TB_ICENT_HIST_ACC.COUNT > 0 THEN
      DBG('Printing Icpks_Test.tb_icent_hist_acc');
      L_IDX := ICPKS_TEST.TB_ICENT_HIST_ACC.FIRST;
      WHILE L_IDX IS NOT NULL LOOP
        DBG(ICPKS_TEST.TB_ICENT_HIST_ACC(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_PROD(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_FRM_NO(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_ENT_DT(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_AMT(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_RUN_DATE(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_LIQN(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_ENTRY_TYPE(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_CCY(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_LCY_AMT(L_IDX) || '~' ||
            ICPKS_TEST.TB_ICENT_HIST_LAST_CUR_ACCR(L_IDX));
      
        L_IDX := ICPKS_TEST.TB_ICENT_HIST_ACC.NEXT(L_IDX);
      END LOOP;
    
    END IF;
  
    L_REC_PR_INT := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(ICPKS_TEST.TB_PROD(RECNO));
    IF NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N' THEN
      IF NOT CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                      GLOBAL.CURRENT_BRANCH,
                                      P_DT,
                                      L_IS_HOLIDAY) THEN
        DBG('cepkss_date.fn_isholiday has returned false... but continuing');
        NULL;
      END IF;
      DBG('g_ic_accr_on_holidays is N and l_is_holiday is ' ||
          L_IS_HOLIDAY);
    ELSE
      L_IS_HOLIDAY := 'W';
    END IF;
    L_IS_HOLIDAY := NVL(L_IS_HOLIDAY, 'W');
    DBG('l_is_holiday=' || L_IS_HOLIDAY || 'Accr_freq-' ||
        L_REC_PR_INT.ACCR_FREQ);
  
    BEGIN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        ICPKS_ONLIQ_NEW_CLUSTER.PR_UPD_ACCPR(RECNO,
                                             P_DT,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
      END IF;
    
      IF ICPKS_TEST.TB_ICENT_HIST_ACC.COUNT <> 0 THEN
      
        DBG('Entries_history has to be delt with for ' || P_DT ||
            'l_is_holiday=' || L_IS_HOLIDAY);
      
        FOR K IN ICPKS_TEST.TB_ICENT_HIST_ACC.FIRST .. ICPKS_TEST.TB_ICENT_HIST_ACC.LAST LOOP
        
          BEGIN
            SELECT NVL(SEQ_NO, 1)
              INTO L_SEQ_NO
              FROM CSTB_CUSTACSEQ
             WHERE BRANCH_CODE = ICPKS_TEST.TB_ICENT_HIST_BRN(K)
               AND CUST_AC_NO = ICPKS_TEST.TB_ICENT_HIST_ACC(K);
          EXCEPTION
            WHEN OTHERS THEN
              L_SEQ_NO := 1;
          END;
        
          IF ICPKSS_TEST.TB_ICENT_HIST_LIQN(K) = 'Y' THEN
            BEGIN
              INSERT INTO ICTBS_ENTRIES_HISTORY
                (BRN,
                 ACC,
                 PROD,
                 FRM_NO,
                 ENT_DT,
                 AMT,
                 ACCRUED_AMT,
                 CUR_RUN_ACCR,
                 AMT_TO_ACCRUE,
                 RUN_DATE,
                 ACCR,
                 LIQN,
                 ENTRY_TYPE,
                 CCY,
                 LCY_AMT,
                 LAST_CUR_RUN_ACCR,
                 CUR_RUN_ACCR_LCY,
                 ENTRY_PASSED
                 
                ,
                 PROCESS,
                 DRCR
                 
                 )
              VALUES
                (ICPKS_TEST.TB_ICENT_HIST_BRN(K),
                 ICPKS_TEST.TB_ICENT_HIST_ACC(K),
                 ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                 ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K),
                 P_DT,
                 ICPKS_TEST.TB_ICENT_HIST_AMT(K),
                 ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(K),
                 0,
                 ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(K),
                 GLOBAL.APPLICATION_DATE,
                 ICPKS_TEST.TB_ICENT_HIST_ACCR(K),
                 ICPKS_TEST.TB_ICENT_HIST_LIQN(K),
                 'O',
                 ICPKS_TEST.TB_ICENT_HIST_CCY(K),
                 ICPKS_TEST.TB_ICENT_HIST_LCY_AMT(K),
                 ICPKS_TEST.TB_ICENT_HIST_LAST_CUR_ACCR(K),
                 0,
                 ICPKS_TEST.TB_ICENT_HIST_ENTRY_PASSED(K)
                 
                ,
                 L_SEQ_NO,
                 ICPKS_CACHE.FN_DRCR_IND(ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                                         ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K))
                 
                 );
            
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG('This entry already exists...');
                DBG('L_ENTRY_PASSED' || L_ENTRY_PASSED);
                UPDATE ICTBS_ENTRIES_HISTORY
                   SET AMT          = ICPKS_TEST.TB_ICENT_HIST_AMT(K),
                       LIQN         = 'Y',
                       ENTRY_TYPE   = 'O',
                       LCY_AMT      = ICPKS_TEST.TB_ICENT_HIST_LCY_AMT(K),
                       RUN_DATE     = GLOBAL.APPLICATION_DATE,
                       ENTRY_PASSED = L_ENTRY_PASSED
                 WHERE BRN = ICPKS_TEST.TB_ICENT_HIST_BRN(K)
                   AND ACC = ICPKS_TEST.TB_ICENT_HIST_ACC(K)
                   AND PROD = ICPKS_TEST.TB_ICENT_HIST_PROD(K)
                   AND FRM_NO = ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K)
                   AND ENT_DT = P_DT;
            END;
          
          END IF;
        
          IF ICPKSS_TEST.TB_ICENT_HIST_ACCR(K) = 'Y' THEN
            DBG('l_is_holiday~Icpks_Test.tb_icent_hist_cur_run_accr(k)=' ||
                L_IS_HOLIDAY || '~' ||
                ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(K));
            IF L_IS_HOLIDAY = 'W' OR
               (L_IS_HOLIDAY = 'H'
               
               AND NOT
                ICPKSS_TEST.G_TB_SKIPPED_ACCTS.EXISTS(ICPKS_TEST.TB_ICENT_HIST_BRN(K) ||
                                                           ICPKS_TEST.TB_ICENT_HIST_ACC(K) ||
                                                           ICPKS_TEST.TB_ICENT_HIST_PROD(K))) THEN
            
              IF NVL(ICPKS_TEST.TB_ICENT_HIST_AMT(K), 0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(K), 0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(K), 0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(K), 0) = 0 THEN
                BEGIN
                  INSERT INTO ICTBS_ENTRIES_HIST_ZEROACCR
                    (BRN,
                     ACC,
                     PROD,
                     FRM_NO,
                     ENT_DT,
                     AMT,
                     ACCRUED_AMT,
                     CUR_RUN_ACCR,
                     AMT_TO_ACCRUE,
                     RUN_DATE,
                     ENTRY_TYPE,
                     CCY,
                     LCY_AMT,
                     LAST_CUR_RUN_ACCR,
                     CUR_RUN_ACCR_LCY,
                     ENTRY_PASSED,
                     PROCESS,
                     DRCR)
                  VALUES
                    (ICPKS_TEST.TB_ICENT_HIST_BRN(K),
                     ICPKS_TEST.TB_ICENT_HIST_ACC(K),
                     ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                     ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K),
                     P_DT,
                     ICPKS_TEST.TB_ICENT_HIST_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(K),
                     ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(K),
                     GLOBAL.APPLICATION_DATE,
                     'O',
                     ICPKS_TEST.TB_ICENT_HIST_CCY(K),
                     ICPKS_TEST.TB_ICENT_HIST_LCY_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_LAST_CUR_ACCR(K),
                     ICPKS_TEST.TB_ICENT_HIST_CURACCR_LCY(K),
                     ICPKS_TEST.TB_ICENT_HIST_ENTRY_PASSED(K),
                     L_SEQ_NO,
                     ICPKS_CACHE.FN_DRCR_IND(ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                                             ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K)));
                
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('Exception in Dup_Val_On_Index');
                  
                    DBG('Zero Accr Ins Failed For : ' ||
                        ICPKS_TEST.TB_ICENT_HIST_ACC(K) || '~' ||
                        ICPKS_TEST.TB_ICENT_HIST_PROD(K) || '~' ||
                        ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K) || '~' || P_DT || '~');
                  
                  WHEN OTHERS THEN
                    DBG('WO exception in insert into Ictbs_Entries_Hist_zeroaccr ' ||
                        SQLERRM);
                END;
              
              ELSE
              
                BEGIN
                  INSERT INTO ICTBS_ENTRIES_HISTORY_ACCR
                    (BRN,
                     ACC,
                     PROD,
                     FRM_NO,
                     ENT_DT,
                     AMT,
                     ACCRUED_AMT,
                     CUR_RUN_ACCR,
                     AMT_TO_ACCRUE,
                     RUN_DATE,
                     ENTRY_TYPE,
                     CCY,
                     LCY_AMT,
                     CUR_RUN_ACCR_LCY,
                     ENTRY_PASSED,
                     PROCESS,
                     DRCR)
                  VALUES
                    (ICPKS_TEST.TB_ICENT_HIST_BRN(K),
                     ICPKS_TEST.TB_ICENT_HIST_ACC(K),
                     ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                     ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K),
                     P_DT,
                     ICPKS_TEST.TB_ICENT_HIST_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(K),
                     ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(K),
                     GLOBAL.APPLICATION_DATE,
                     'O',
                     ICPKS_TEST.TB_ICENT_HIST_CCY(K),
                     ICPKS_TEST.TB_ICENT_HIST_LCY_AMT(K),
                     ICPKS_TEST.TB_ICENT_HIST_CURACCR_LCY(K),
                     ICPKS_TEST.TB_ICENT_HIST_ENTRY_PASSED(K),
                     L_SEQ_NO,
                     ICPKS_CACHE.FN_DRCR_IND(ICPKS_TEST.TB_ICENT_HIST_PROD(K),
                                             ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K)));
                
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('Exception in Dup_Val_On_Index');
                  
                    DBG('Accr Ins Failed For : ' ||
                        ICPKS_TEST.TB_ICENT_HIST_ACC(K) || '~' ||
                        ICPKS_TEST.TB_ICENT_HIST_PROD(K) || '~' ||
                        ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K) || '~' || P_DT || '~');
                  
                    UPDATE ICTBS_ENTRIES_HISTORY_ACCR
                       SET AMT           = ICPKS_TEST.TB_ICENT_HIST_AMT(K),
                           ACCRUED_AMT   = ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT(K),
                           CUR_RUN_ACCR  = ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(K),
                           AMT_TO_ACCRUE = ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE(K)
                     WHERE BRN = ICPKS_TEST.TB_ICENT_HIST_BRN(K)
                       AND ACC = ICPKS_TEST.TB_ICENT_HIST_ACC(K)
                       AND PROD = ICPKS_TEST.TB_ICENT_HIST_PROD(K)
                       AND FRM_NO = ICPKS_TEST.TB_ICENT_HIST_FRM_NO(K)
                       AND ENT_DT = P_DT;
                  
                  WHEN OTHERS THEN
                    DBG('WO exception in insert into Ictbs_Entries_History_accr ' ||
                        SQLERRM);
                END;
              
              END IF;
            END IF;
          END IF;
        
          ICPKS_TEST.TB_ICENT_HIST_BRN.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_CURACCR_LCY.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_ACC.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_PROD.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_FRM_NO.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_AMT.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_ACCRUED_AMT.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_RUN_DATE.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_ACCR.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_LIQN.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_ENTRY_TYPE.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_CCY.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_LCY_AMT.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_LAST_CUR_ACCR.DELETE(K);
          ICPKS_TEST.TB_ICENT_HIST_ENTRY_PASSED.DELETE(K);
        END LOOP;
      END IF;
    EXCEPTION
    
      WHEN OTHERS THEN
        DBG('We should never come here but for safety reason!!!!!' ||
            SQLERRM);
    END;
  
    DBG('after entries history');
    BEGIN
      IF NVL(ICPKS_TEST.TB_ICENT_HIST_UPD.COUNT, 0) <> 0 THEN
        FOR EACH_ROW IN ICPKS_TEST.TB_ICENT_HIST_UPD.FIRST .. ICPKS_TEST.TB_ICENT_HIST_UPD.LAST LOOP
        
          DBG('Upd For : ' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).ACC || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).PROD || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
              .FRM_NO || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
              .ENT_DT || '~' || P_DT || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).AMT || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
              .ACCRUED_AMT || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
              .AMT_TO_ACCRUE || '~' || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
              .CUR_RUN_ACCR || '~');
        
          IF ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).LIQN = 'N' THEN
            IF L_IS_HOLIDAY = 'W' OR
               (L_IS_HOLIDAY = 'H'
               
               AND NOT
                ICPKSS_TEST.G_TB_SKIPPED_ACCTS.EXISTS(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW)
                                                           .BRN || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).ACC || ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).PROD)) THEN
            
              IF NVL(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).ACCRUED_AMT, 0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).AMT_TO_ACCRUE,
                     0) = 0 AND
                 NVL(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR, 0) = 0 THEN
                ICPKS_TEST.PR_UPD_ACCR_ENT(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                           'Z',
                                           'Y',
                                           L_SEQ_NO,
                                           P_DT,
                                           L_UPD_COUNT);
                IF L_UPD_COUNT = 0 THEN
                  ICPKS_TEST.PR_UPD_ACCR_ENT(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                             'Z',
                                             'N',
                                             L_SEQ_NO,
                                             P_DT,
                                             L_UPD_COUNT);
                END IF;
              ELSE
                ICPKS_TEST.PR_UPD_ACCR_ENT(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                           'A',
                                           'Y',
                                           L_SEQ_NO,
                                           P_DT,
                                           L_UPD_COUNT);
                IF L_UPD_COUNT = 0 THEN
                  ICPKS_TEST.PR_UPD_ACCR_ENT(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                             'A',
                                             'N',
                                             L_SEQ_NO,
                                             P_DT,
                                             L_UPD_COUNT);
                END IF;
              END IF;
            END IF;
          ELSE
          
            UPDATE ICTBS_ENTRIES_HISTORY
               SET AMT = ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).AMT
             WHERE BRN = ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).BRN
               AND ACC = ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).ACC
               AND PROD = ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).PROD
               AND FRM_NO = ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).FRM_NO
               AND ENT_DT =
                   NVL(ICPKS_TEST.TB_ICENT_HIST_UPD(EACH_ROW).ENT_DT, P_DT);
          
          END IF;
        END LOOP;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('some problem with entries history update' || SQLERRM);
    END;
    DBG('DELETEING ENTRIES HISTORY TABLE');
    ICPKS_TEST.TB_ICENT_HIST_UPD.DELETE;
  
    DBG('History update is also completed');
  
    DBG('Not So Fast. Backvalued Adjustments Still Have 2 Be Done');
    IF NVL(ICPKS_TEST.TB_ICENT_HIST_ADJ.COUNT, 0) <> 0 THEN
      BUG1 := ICPKS_TEST.TB_ICENT_HIST_ADJ.FIRST;
      WHILE BUG1 <= ICPKS_TEST.TB_ICENT_HIST_ADJ.LAST LOOP
        DBG(ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1)
            .FRM_NO || ' ' || ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).ENT_DT ||
             ' adjustments are being done' || ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).ACC || '~' || ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).AMT);
        DBG('lcy amount is ' || ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).LCY_AMT);
        UPDATE ICTBS_ENTRIES_HISTORY E
           SET E.AMT     = E.AMT + ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).AMT,
               E.LCY_AMT = E.LCY_AMT + ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1)
                          .LCY_AMT
         WHERE E.BRN = ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).BRN
           AND E.ACC = ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).ACC
           AND E.PROD = ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).PROD
           AND E.FRM_NO = ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).FRM_NO
           AND E.ENT_DT = ICPKS_TEST.TB_ICENT_HIST_ADJ(BUG1).ENT_DT;
        BUG1 := ICPKS_TEST.TB_ICENT_HIST_ADJ.NEXT(BUG1);
      END LOOP;
    END IF;
  
    DBG('PLEASE DELETE TABLES WHEN DONE...... NOW DELETING ADJ_HISTORY');
    ICPKS_TEST.TB_ICENT_HIST_ADJ.DELETE;
    BEGIN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
        ICPKS_ONLIQ_NEW_CLUSTER.PR_UPD_ACCPR(RECNO,
                                             P_DT,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
      END IF;
    
      IF NVL(ICPKS_TEST.TB_ICENT.COUNT, 0) <> 0 THEN
        K := ICPKS_TEST.TB_ICENT.FIRST;
        WHILE K <= ICPKS_TEST.TB_ICENT.LAST LOOP
          UPDATE ICTBS_ENTRIES
             SET AMT           = 0,
                 ACCRUED_AMT   = 0,
                 AMT_TO_ACCRUE = 0,
                 CUR_RUN_ACCR  = 0,
                 DAILY_AMT     = 0,
                 ACQUIRED_AMT  = 0,
                 ACQUIRED_ADJ  = 0
           WHERE ROWID = ICPKS_TEST.TB_ICENT(K).ROW_ID;
        
          IF NOT ICPKSS_ACCR_INT.FN_SET_ACC_ACCR(ICPKS_TEST.TB_ICENT(K).BRN,
                                                 ICPKS_TEST.TB_ICENT(K).ACC,
                                                 NULL,
                                                 VD_ERR,
                                                 VD_ERP) THEN
            DBG('icpks_accr_int.fn_set_acc_accr retured false');
            DBG('Vd Err ' || VD_ERR);
            DBG('Vd Erp ' || VD_ERP);
          END IF;
        
          K := ICPKS_TEST.TB_ICENT.NEXT(K);
        END LOOP;
      END IF;
      DBG('Now Deleting ICTB_ENTRIES');
      ICPKS_TEST.TB_ICENT.DELETE;
    
      IF ICPKSS_TEST.G_TB_SKIPPED_ACCTS.COUNT > 0 THEN
        DBG('Clearing g_tb_skipped_Accts table.here ...count was ' ||
            ICPKSS_TEST.G_TB_SKIPPED_ACCTS.COUNT);
        ICPKSS_TEST.G_TB_SKIPPED_ACCTS.DELETE;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Done with all');
    END;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Chalo chale mitwa!!!' || SQLERRM);
      RAISE;
  END PR_UPD_ACCPR;

  PROCEDURE PR_DUMMMY_TAB_DELETE(RECNO NUMBER) IS
  BEGIN
    L_TB_BRN.DELETE;
    L_TB_ACC.DELETE;
    L_TB_PROD.DELETE;
    L_TB_SC_MAP_DT.DELETE;
    L_TB_GC_MAP_DT.DELETE;
    L_TB_LAST_CALC_DT.DELETE;
    L_TB_LAST_LIQ_DT.DELETE;
    L_TB_NEXT_LIQ_DT.DELETE;
    L_TB_LAST_ACCR_DT.DELETE;
    L_TB_NEXT_ACCR_DT.DELETE;
    L_TB_LAST_SCHD_LIQ_DT.DELETE;
    L_TB_INC_MTH.DELETE;
    L_TB_NEXT_SCHD_LIQ_DT.DELETE;
    L_TB_FIRST_CALC_DT.DELETE;
    L_TB_NEXT_SCHD_ACCR_DT.DELETE;
    L_TB_PROD_TYPE.DELETE;
    L_TB_HAS_ACCR.DELETE;
    L_TB_NEXT_CALC_DT.DELETE;
    L_TB_PROD_ACCR.DELETE;
    L_TB_HAS_PROBLEMS.DELETE;
    L_TB_BKVAL_MINCALC_DATE.DELETE;
    L_TB_BKVAL_RECALC_FLAG.DELETE;
    L_TB_FIRST_FIRST_CALC_DATE.DELETE;
    L_TB_IMAT_PROBLEMS.DELETE;
    L_TB_DEPOSIT.DELETE;
    L_TB_ACLASS.DELETE;
    L_TB_CCY.DELETE;
    L_TB_NEXT_EVENT_DT.DELETE;
    L_TB_ROWID.DELETE;
  
    L_TB_DEFER_LIQ_DT.DELETE;
  END PR_DUMMMY_TAB_DELETE;

  PROCEDURE LOG_PROBLEM(P_ROWNUM NUMBER, P_OP VARCHAR2, P_ERR VARCHAR2) IS
  BEGIN
    INSERT INTO ICTBS_BOOK_ERR
      (BRN, OP, PROD, ERRM)
    VALUES
      (ICPKS_TEST.TB_BRN(P_ROWNUM),
       P_OP,
       ICPKS_TEST.TB_PROD(P_ROWNUM),
       'Online liq failed with ==> ' || P_ERR);
    ICPKS_TEST.TB_HAS_PROBLEMS(P_ROWNUM) := 'Y';
  END LOG_PROBLEM;

  PROCEDURE PR_PROC_CHG_ALL(P_BRN     VARCHAR2,
                            P_PR_LIST VARCHAR2,
                            P_LIQ_DT  DATE) IS
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             NEXT_EVENT_DT,
             DEFER_LIQ_DT,
             ROWID
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
         AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
         AND
            
             P.PROD_TYPE IN ('C', 'PC')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
       ORDER BY P.NEXT_LIQ_DT;
  
    VD_ERR     VARCHAR2(1000);
    VD_EPAR    VARCHAR2(1000);
    RECNO      NUMBER := 0;
    FLEX       NUMBER := 0;
    LAST_RECNO NUMBER := 0;
    L_ACC      STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN      STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS   STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY      STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD     ICTBS_ACC_PR.PROD%TYPE;
    J          NUMBER := 0;
    VDBAL_UPD_BOMB EXCEPTION;
    L_PROB_ACC  BOOLEAN := FALSE;
    L_PROB_PROD BOOLEAN := FALSE;
    MAINT_ERR   VARCHAR2(100);
    MAINT_ERRP  VARCHAR2(1000);
    NOTHINGTOPROCESS EXCEPTION;
  BEGIN
    DBG('Inside proc all');
    OPEN CUR_ACCPR;
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID LIMIT L_COMMIT_FREQ;
    
      IF NVL(ICPKS_TEST.TB_ACC.COUNT, 0) = 0 THEN
        RAISE NOTHINGTOPROCESS;
      END IF;
    
      FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
      END LOOP;
    
      FOR J IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(J),
                                         ICPKS_TEST.TB_ACC(J),
                                         ICPKS_TEST.TB_CCY(J),
                                         VD_ERR,
                                         VD_EPAR) THEN
          DBG('Bombed in update log this and delete the same');
          PR_DELETE_ACCPR_ROW(RECNO);
        END IF;
      END LOOP;
    
      IF NOT
          ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN, MAINT_ERR, MAINT_ERRP) THEN
        RETURN;
      END IF;
    
      DBG('VD bal update is done and we have ' ||
          NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
      RECNO := ICPKS_TEST.TB_ROWID.FIRST;
      WHILE RECNO <= ICPKS_TEST.TB_ROWID.LAST LOOP
        IF NVL(L_ACC, '***') <> NVL(ICPKS_TEST.TB_ACC(RECNO), '####') OR
           NVL(L_BRN, '***') <> NVL(ICPKS_TEST.TB_BRN(RECNO), '####') THEN
          L_PROB_ACC := FALSE;
          IF NOT FN_CHK_ICACC(RECNO) THEN
            DBG('Problem with the account');
            L_PROB_ACC := TRUE;
            PR_DELETE_ACCPR_ROW(RECNO);
          END IF;
        ELSE
          IF NOT L_PROB_ACC THEN
            TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
            TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
          END IF;
        END IF;
        L_ACC  := ICPKS_TEST.TB_ACC(RECNO);
        L_BRN  := ICPKS_TEST.TB_BRN(RECNO);
        L_PROD := ICPKS_TEST.TB_PROD(RECNO);
        RECNO  := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
      END LOOP;
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
  EXCEPTION
    WHEN NOTHINGTOPROCESS THEN
      DBG('no charges product');
    WHEN VDBAL_UPD_BOMB THEN
      DBG('Failed in vd bal update' || VD_ERR || ' - ' || VD_EPAR);
      RAISE;
    WHEN OTHERS THEN
      DBG('In when others then ' || ' - ' || SQLERRM);
      RAISE;
  END PR_PROC_CHG_ALL;

  PROCEDURE PR_PROC_CHG_SELECTED_ACC(P_BRN      VARCHAR2,
                                     P_ACC_LIST VARCHAR2,
                                     P_LIQ_DT   DATE,
                                     P_PR_LIST  VARCHAR2) IS
  
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             
             NEXT_EVENT_DT,
             DEFER_LIQ_DT,
             ROWID
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
         AND P.ACC = P_ACC_LIST
         AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
         AND
            
             P.PROD_TYPE IN ('C', 'PC')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
       ORDER BY P.NEXT_LIQ_DT;
    RECNO       BINARY_INTEGER;
    L_ACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN       STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS    STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY       STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD      ICTBS_ACC_PR.PROD%TYPE;
    L_PROB_PROD BOOLEAN := FALSE;
    L_PROB_ACC  BOOLEAN := FALSE;
    VD_ERR      VARCHAR2(1000);
    VD_PERR     VARCHAR2(1000);
    NOTHING_TO_PROCESS EXCEPTION;
  BEGIN
    DBG('Open the cursor with..' || ' - ' || P_ACC_LIST);
    OPEN CUR_ACCPR;
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID LIMIT L_COMMIT_FREQ;
      DBG('After bulk collect');
    
      IF NVL(ICPKS_TEST.TB_ROWID.COUNT, 0) = 0 THEN
      
        DBG('raising nothing to do');
        RAISE NOTHING_TO_PROCESS;
      END IF;
    
      FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
      END LOOP;
    
      RECNO := ICPKSS_TEST.TB_ROWID.FIRST;
      WHILE RECNO <= ICPKSS_TEST.TB_ROWID.LAST LOOP
        BEGIN
          DBG('RecNo = ' || RECNO);
          DBG('Product in loop is ' || ICPKS_TEST.TB_PROD(RECNO));
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('MISSING PRODUCT WILL BOIMB');
        END;
        IF NVL(L_ACC, '***') <> ICPKS_TEST.TB_ACC(RECNO) OR
           NVL(L_BRN, '***') <> ICPKS_TEST.TB_BRN(RECNO) THEN
          L_PROB_ACC := FALSE;
          IF NOT FN_CHK_ICACC(RECNO) THEN
            DBG('Problem with the account');
            L_PROB_ACC := TRUE;
            PR_DELETE_ACCPR_ROW(RECNO);
          ELSE
          
            DBG('Purush !!!!');
          
            IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(RECNO),
                                             ICPKS_TEST.TB_ACC(RECNO),
                                             ICPKS_TEST.TB_CCY(RECNO),
                                             VD_ERR,
                                             VD_PERR) THEN
              DBG('Bombed in update log this and delete the same');
              PR_DELETE_ACCPR_ROW(RECNO);
            END IF;
          END IF;
        ELSE
          IF NOT L_PROB_ACC THEN
            TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
            TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
          END IF;
        END IF;
        DBG('Ramesh ' || RECNO || ' - ' || L_PROD);
      
        RECNO := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
      END LOOP;
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
    DBG('Just before leaving we have...' ||
        NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
  EXCEPTION
    WHEN NOTHING_TO_PROCESS THEN
      DBG('our man dont have to do anything');
    WHEN OTHERS THEN
      DBG('Problems with selected acc.' || ' - ' || SQLERRM);
      RAISE;
  END PR_PROC_CHG_SELECTED_ACC;

  PROCEDURE PR_PROC_CHG_ACLASS(P_BRN     VARCHAR2,
                               P_ACLASS  VARCHAR2,
                               P_LIQ_DT  DATE,
                               P_PR_LIST VARCHAR2) IS
  
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             
             NEXT_EVENT_DT,
             DEFER_LIQ_DT,
             ROWID
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
         AND P.ACLASS = P_ACLASS
         AND (P_PR_LIST = 'ALL' OR INSTR(P_PR_LIST, P.PROD || '~') != 0)
         AND
            
             P.PROD_TYPE IN ('C', 'PC')
            
         AND NVL(P.LAST_LIQ_DT, SYSDATE - 1000) <> P_LIQ_DT
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
       ORDER BY P.NEXT_LIQ_DT;
    RECNO       BINARY_INTEGER;
    L_ACC       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN       STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACLASS    STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY       STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_PROD      ICTBS_ACC_PR.PROD%TYPE;
    L_PROB_PROD BOOLEAN := FALSE;
    L_PROB_ACC  BOOLEAN := FALSE;
    VD_ERR      VARCHAR2(1000);
    VD_PERR     VARCHAR2(1000);
    NOTHING_TO_PROCESS EXCEPTION;
  BEGIN
    DBG('Open the cursor for account class' || ' - ' || P_ACLASS);
    OPEN CUR_ACCPR;
    LOOP
      ICPKSS_HASH_PR.INIT_HASH_PR;
      FETCH CUR_ACCPR BULK COLLECT
        INTO ICPKS_TEST.TB_BRN,
             ICPKS_TEST.TB_ACC,
             ICPKS_TEST.TB_PROD,
             ICPKS_TEST.TB_SC_MAP_DT,
             ICPKS_TEST.TB_GC_MAP_DT,
             ICPKS_TEST.TB_LAST_CALC_DT,
             ICPKS_TEST.TB_LAST_LIQ_DT,
             ICPKS_TEST.TB_NEXT_LIQ_DT,
             ICPKS_TEST.TB_LAST_ACCR_DT,
             ICPKS_TEST.TB_NEXT_ACCR_DT,
             ICPKS_TEST.TB_LAST_SCHD_LIQ_DT,
             ICPKS_TEST.TB_INC_MTH,
             ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT,
             ICPKS_TEST.TB_FIRST_CALC_DT,
             ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT,
             ICPKS_TEST.TB_PROD_TYPE,
             ICPKS_TEST.TB_HAS_ACCR,
             ICPKS_TEST.TB_NEXT_CALC_DT,
             ICPKS_TEST.TB_PROD_ACCR,
             ICPKS_TEST.TB_HAS_PROBLEMS,
             ICPKS_TEST.TB_BKVAL_MINCALC_DATE,
             ICPKS_TEST.TB_BKVAL_RECALC_FLAG,
             ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE,
             ICPKS_TEST.TB_IMAT_PROBLEMS,
             ICPKS_TEST.TB_DEPOSIT,
             ICPKS_TEST.TB_ACLASS,
             ICPKS_TEST.TB_CCY,
             
             ICPKS_TEST.TB_NEXT_EVENT_DT,
             ICPKS_TEST.TB_DEFER_LIQ_DT,
             ICPKS_TEST.TB_ROWID LIMIT L_COMMIT_FREQ;
      DBG('After bulk collect');
      IF NVL(ICPKS_TEST.TB_ROWID.COUNT, 0) = 0 THEN
      
        DBG('raising nothing to do');
        RAISE NOTHING_TO_PROCESS;
      END IF;
    
      FOR P IN ICPKSS_TEST.TB_ROWID.FIRST .. ICPKSS_TEST.TB_ROWID.LAST LOOP
        ICPKSS_HASH_PR.SET_ACC_ROWS(ICPKS_TEST.TB_ACC(P), P);
      END LOOP;
    
      RECNO := ICPKSS_TEST.TB_ROWID.FIRST;
      WHILE RECNO <= ICPKSS_TEST.TB_ROWID.LAST LOOP
        IF NVL(L_ACC, '***') <> ICPKS_TEST.TB_ACC(RECNO) OR
           NVL(L_BRN, '***') <> ICPKS_TEST.TB_BRN(RECNO) THEN
          L_ACC      := ICPKS_TEST.TB_ACC(RECNO);
          L_BRN      := ICPKS_TEST.TB_BRN(RECNO);
          L_PROB_ACC := FALSE;
          IF NOT FN_CHK_ICACC(RECNO) THEN
            DBG('Problem with the account');
            L_PROB_ACC := TRUE;
            PR_DELETE_ACCPR_ROW(RECNO);
          ELSE
          
            IF NOT ACPKS_VDBAL.FN_ACC_UPDATE(ICPKS_TEST.TB_BRN(RECNO),
                                             ICPKS_TEST.TB_ACC(RECNO),
                                             ICPKS_TEST.TB_CCY(RECNO),
                                             VD_ERR,
                                             VD_PERR) THEN
              DBG('Bombed in update log this and delete the same');
              PR_DELETE_ACCPR_ROW(RECNO);
            END IF;
          END IF;
        ELSE
          IF NOT L_PROB_ACC THEN
            TB_STTM_CUSTACC(RECNO) := TB_STTM_CUSTACC(RECNO - 1);
            TB_ICTM_ACC(RECNO) := TB_ICTM_ACC(RECNO - 1);
          END IF;
        END IF;
        RECNO := ICPKS_TEST.TB_ROWID.NEXT(RECNO);
      END LOOP;
      EXIT WHEN CUR_ACCPR%NOTFOUND;
    END LOOP;
    CLOSE CUR_ACCPR;
    DBG('Just before leaving we have...' ||
        NVL(ICPKS_TEST.TB_ROWID.COUNT, 0));
  EXCEPTION
    WHEN NOTHING_TO_PROCESS THEN
      DBG('our man dont have to do anything');
    WHEN OTHERS THEN
      DBG('Problems with selected aclass.' || ' - ' || SQLERRM);
  END PR_PROC_CHG_ACLASS;

  PROCEDURE PR_NEW_ACC_LIST(P_BRANCH       VARCHAR2,
                            P_ACC_LIST     VARCHAR2,
                            P_NEW_ACC_LIST OUT VARCHAR2) IS
    L_ACC_LIST     VARCHAR2(3000);
    L_NEW_ACC_LIST VARCHAR2(3000);
    PROC_ACC       ICTBS_ACC_PR.ACC%TYPE;
  
    L_CURR_ITEM NUMBER := 1;
  
    CURSOR C_ACC_LIST(C_ACCOUNT VARCHAR2) IS
      SELECT DISTINCT A.SYSTEM_ACCOUNT
        FROM ILTBS_SYS_ACCOUNT A, ICTB_ACC_PR B
       WHERE A.BRANCH_CODE = P_BRANCH
         AND A.ACCOUNT = C_ACCOUNT
         AND B.BRN = A.BRANCH_CODE
         AND B.ACC = A.SYSTEM_ACCOUNT
         AND B.STOP_IC = 'N';
  BEGIN
    L_ACC_LIST     := P_ACC_LIST;
    L_NEW_ACC_LIST := NULL;
    LOOP
      PROC_ACC := CSPKES_MISC.FN_GETPARAM(L_ACC_LIST, L_CURR_ITEM, '~');
      EXIT WHEN PROC_ACC = 'EOPL';
      L_CURR_ITEM := L_CURR_ITEM + 1;
      FOR REC IN C_ACC_LIST(PROC_ACC) LOOP
        IF L_NEW_ACC_LIST IS NULL THEN
          L_NEW_ACC_LIST := REC.SYSTEM_ACCOUNT;
        ELSE
          L_NEW_ACC_LIST := L_NEW_ACC_LIST || '~' || REC.SYSTEM_ACCOUNT;
        END IF;
      END LOOP;
      IF L_NEW_ACC_LIST IS NULL THEN
        L_NEW_ACC_LIST := PROC_ACC;
      ELSE
        L_NEW_ACC_LIST := L_NEW_ACC_LIST || '~' || PROC_ACC;
      END IF;
    END LOOP;
    P_NEW_ACC_LIST := L_NEW_ACC_LIST;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Problems with selected accounts - ' || SQLERRM);
  END;

  FUNCTION FN_PROC_REFUND_TAX(P_BRN     IN VARCHAR2,
                              P_ACC     IN VARCHAR2,
                              P_ERRCODE IN OUT VARCHAR2,
                              P_ERRMSG  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_PROD             ICTMS_ACC_PR.PROD%TYPE;
    L_REFUND_TAX       ICTMS_PR_INT.REFUND_TAX%TYPE;
    L_RULE             ICTMS_PR_INT.RULE%TYPE;
    L_FRM_NO           ICTMS_RULE_FRM.FRM_NO%TYPE;
    L_TOT_TAX_PAID     NUMBER;
    TB_TAXACCHANDOFF   ACPKSS.TBL_ACHOFF;
    RECNO              BINARY_INTEGER;
    L_SERIAL_NO        VARCHAR2(15);
    L_TXN_REF_NO       VARCHAR2(16);
    L_ERR_CODES        ERTBS_MSGS.ERR_CODE%TYPE;
    L_TAX_PAYABLE_GL   VARCHAR2(9);
    L_BRN              VARCHAR2(3);
    L_ACC              VARCHAR2(20);
    L_CCY              VARCHAR2(3);
    L_TXN_CODE         VARCHAR2(3);
    G_APPLICATION_DATE DATE;
  
    PROCEDURE PR_BUILD_TAXTBHANDOFF(P_TAG_AMT  IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                    P_BRN      IN VARCHAR2,
                                    P_ACC      IN VARCHAR2,
                                    P_CCY      IN VARCHAR2,
                                    P_COUNT    IN NUMBER,
                                    P_DRCR_IND IN VARCHAR2,
                                    P_REF_NO   IN VARCHAR2,
                                    P_TRN_CODE IN VARCHAR2) IS
      ECODE VARCHAR2(2000) := NULL;
      L_EXP_SKIP EXCEPTION;
      L_TAG_AMT_LCY STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
      L_XRATE       ACTBS_HANDOFF.EXCH_RATE%TYPE;
    BEGIN
    
      DBG('In pr_Build_TaxtbHandOff ... for building table for acct handoff');
    
      G_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
    
      DBG('Application Date is :' || G_APPLICATION_DATE);
    
      TB_TAXACCHANDOFF(P_COUNT) := NULL;
      TB_TAXACCHANDOFF(P_COUNT).USER_ID := GLOBAL.USER_ID;
      TB_TAXACCHANDOFF(P_COUNT).EVENT := 'ILIQ';
      TB_TAXACCHANDOFF(P_COUNT).MODULE := 'IC';
      TB_TAXACCHANDOFF(P_COUNT).AMOUNT_TAG := 'TAX_REFUND';
      TB_TAXACCHANDOFF(P_COUNT).DRCR_IND := P_DRCR_IND;
      TB_TAXACCHANDOFF(P_COUNT).EVENT_SR_NO := 1;
      TB_TAXACCHANDOFF(P_COUNT).TRN_CODE := P_TRN_CODE;
      TB_TAXACCHANDOFF(P_COUNT).TRN_REF_NO := P_REF_NO;
      TB_TAXACCHANDOFF(P_COUNT).TRN_DT := G_APPLICATION_DATE;
      TB_TAXACCHANDOFF(P_COUNT).VALUE_DT := G_APPLICATION_DATE;
      TB_TAXACCHANDOFF(P_COUNT).TXN_INIT_DATE := G_APPLICATION_DATE;
      TB_TAXACCHANDOFF(P_COUNT).NETTING_IND := 'N';
    
      TB_TAXACCHANDOFF(P_COUNT).AC_BRANCH := P_BRN;
      TB_TAXACCHANDOFF(P_COUNT).AC_NO := P_ACC;
      TB_TAXACCHANDOFF(P_COUNT).AC_CCY := P_CCY;
    
      DBG('Acct CCy is :' || P_CCY);
      DBG('Global CCy is :' || GLOBAL.LCY);
    
      IF P_CCY = GLOBAL.LCY THEN
        L_TAG_AMT_LCY := P_TAG_AMT;
      
      ELSIF P_CCY != GLOBAL.LCY AND L_TAG_AMT_LCY IS NULL THEN
        L_XRATE := NULL;
        IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_BRN,
                                           P_CCY,
                                           GLOBAL.LCY,
                                           P_TAG_AMT,
                                           'Y',
                                           L_TAG_AMT_LCY,
                                           L_XRATE,
                                           ECODE) THEN
          DBG('Debit Interest Liquidation Failed in ICPKSS_UTIL.fn_amt1_to_amt2' ||
              ECODE);
          RAISE L_EXP_SKIP;
        ELSE
          TB_TAXACCHANDOFF(P_COUNT).FCY_AMOUNT := P_TAG_AMT;
          TB_TAXACCHANDOFF(P_COUNT).EXCH_RATE := L_XRATE;
        END IF;
      END IF;
    
      TB_TAXACCHANDOFF(P_COUNT).LCY_AMOUNT := L_TAG_AMT_LCY;
    
    EXCEPTION
      WHEN L_EXP_SKIP THEN
        DBG('CCY conversion failed-->' || SQLERRM);
        P_ERRMSG := SQLERRM;
      WHEN OTHERS THEN
        DBG('pr_Build_DItbHandOff failed-->' || SQLERRM);
        P_ERRMSG := SQLERRM;
    END PR_BUILD_TAXTBHANDOFF;
  
  BEGIN
  
    DBG('In Tax Refund Func for premat redemption');
  
    BEGIN
      SELECT PROD INTO L_PROD FROM ICTM_ACC_PR WHERE ACC = P_ACC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Setup problem ... this case will never come');
        RETURN FALSE;
    END;
  
    DBG('IC Product for the selected acc is :' || L_PROD);
  
    BEGIN
      SELECT A.REFUND_TAX, A.RULE
        INTO L_REFUND_TAX, L_RULE
        FROM ICTMS_PR_INT A
       WHERE A.PRODUCT_CODE = L_PROD;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Tax rule not defined....');
        L_REFUND_TAX := 'N';
    END;
  
    DBG('Tax Rule for IC Product and Acc combination is :' || L_RULE);
    DBG('Tax Rule for IC Product and Acc combination is :' || L_FRM_NO);
    DBG('Refund Tax flag for the IC product is :' || L_REFUND_TAX);
  
    IF (L_REFUND_TAX = 'Y') THEN
    
      BEGIN
        SELECT FRM_NO
          INTO L_FRM_NO
          FROM ICTMS_RULE_FRM
         WHERE RULE_ID = L_RULE
           AND BOOK_FLAG = 'T'
           AND ROWNUM = 1;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Formula no for tax' || SQLERRM);
      END;
      DBG('Frm no for IC Product and Acc combination is :' || L_FRM_NO);
    
      BEGIN
        DBG('Refund Tax flag for the IC product is Y ..continue processing ');
      
        SELECT SUM(AMT)
          INTO L_TOT_TAX_PAID
          FROM ICTB_ENTRIES_HISTORY
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PROD = L_PROD
           AND FRM_NO = L_FRM_NO
           AND LIQN = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('retrieving tax paid amount has failed');
          RETURN FALSE;
      END;
    
      DBG('Total Tax Paid is :' || L_TOT_TAX_PAID);
    
      IF (L_TOT_TAX_PAID IS NULL) THEN
        L_TOT_TAX_PAID := 0;
      END IF;
    
      IF (L_TOT_TAX_PAID > 0) THEN
        DBG('Total Tax Paid is > 0 ..so refund tax as this is premature closure ');
      
        BEGIN
        
          SELECT CCY
            INTO L_CCY
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = P_BRN
             AND CUST_AC_NO = P_ACC
             AND RECORD_STAT <> 'C'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('retrieving tax paid amount has failed');
            RETURN FALSE;
        END;
      
        DBG('Get the txn ref no ...... ');
      
        IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_BRN,
                                           L_PROD,
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           L_TXN_REF_NO,
                                           L_ERR_CODES) THEN
          DBG('pr_Build_TaxtbHandOff ' || L_ERR_CODES);
          RETURN FALSE;
        END IF;
      
        DBG('Transaction Reference No ' || L_TXN_REF_NO);
        DBG('Get the tax payable GL code ...... ');
      
        BEGIN
        
          SELECT B.ACCOUNT_HEAD, A.TRANSACTION_CODE
            INTO L_TAX_PAYABLE_GL, L_TXN_CODE
            FROM CSTM_PRODUCT_EVENT_ACCT_ENTRY A,
                 CSTM_BRANCH_PRODRTH_DETAIL    B
           WHERE A.PRODUCT_CODE = L_PROD
             AND B.PRODUCT_CODE = A.PRODUCT_CODE
             AND A.AMT_TAG = 'TAX'
             AND A.DR_CR_INDICATOR = 'C'
             AND A.EVENT_CODE = 'ILIQ'
             AND B.ACCOUNTING_ROLE = A.ACCOUNT_ROLE_CODE
             AND B.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
             AND B.STATUS = 'NORM'
             AND B.PRODUCT_CODE IN
                 (SELECT PRODUCT_CODE
                    FROM CSTM_BRANCH_PRODRTH_MASTER
                   WHERE PRODUCT_CODE = L_PROD
                     AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                     AND STATUS = 'NORM'
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A');
        
        EXCEPTION
        
          WHEN NO_DATA_FOUND THEN
            SELECT B.ACCOUNT_HEAD, A.TRANSACTION_CODE
              INTO L_TAX_PAYABLE_GL, L_TXN_CODE
              FROM CSTM_PRODUCT_EVENT_ACCT_ENTRY A, CSTM_PRODUCT_ACCROLE B
             WHERE A.PRODUCT_CODE = L_PROD
               AND B.PRODUCT_CODE = A.PRODUCT_CODE
               AND A.AMT_TAG = 'TAX'
               AND A.DR_CR_INDICATOR = 'C'
               AND A.EVENT_CODE = 'ILIQ'
               AND B.ACCOUNTING_ROLE = A.ACCOUNT_ROLE_CODE;
          
          WHEN OTHERS THEN
            DBG('setup problem ..failed in getting tax payable gl value');
            RETURN FALSE;
        END;
      
        DBG('The tax payable GL code ......is :' || L_TAX_PAYABLE_GL);
      
        PR_BUILD_TAXTBHANDOFF(L_TOT_TAX_PAID,
                              P_BRN,
                              P_ACC,
                              L_CCY,
                              1,
                              'C',
                              L_TXN_REF_NO,
                              L_TXN_CODE);
      
        DBG('Dr the Tax Payable GL ' || L_TAX_PAYABLE_GL);
      
        PR_BUILD_TAXTBHANDOFF(L_TOT_TAX_PAID,
                              P_BRN,
                              L_TAX_PAYABLE_GL,
                              L_CCY,
                              2,
                              'D',
                              L_TXN_REF_NO,
                              L_TXN_CODE);
      
        DBG('Before calling the acpkss.fn_achandoff function - handoffcount:' ||
            TB_TAXACCHANDOFF.COUNT);
      
        IF TB_TAXACCHANDOFF.COUNT > 0 THEN
          IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                     1,
                                     G_APPLICATION_DATE,
                                     TB_TAXACCHANDOFF,
                                     'B',
                                     'N',
                                     'Y',
                                     GLOBAL.USER_ID,
                                     P_ERRCODE,
                                     P_ERRMSG) THEN
            DBG('Acc Handoff Failed with ' || P_ERRCODE);
          
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error in fn_proc_refund_tax proc: ' || SQLERRM);
      RETURN FALSE;
  END FN_PROC_REFUND_TAX;

BEGIN
  APPDT := GLOBAL.APPLICATION_DATE;
  UID   := GLOBAL.USER_ID;

  BEGIN
  
    PKG_VDBAL := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('VDBAL_UPDATE'),
                     'ONLINE');
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      PKG_VDBAL := 'ONLINE';
  END;

  BEGIN
    G_SLEEP_TIMER := NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('IC_JOB_SLEEP_TIMER'),
                         30);
  EXCEPTION
    WHEN OTHERS THEN
      G_SLEEP_TIMER := 30;
  END;

END ICPKS_ONLIQ_NEW;
