CREATE OR REPLACE EDITIONABLE PACKAGE "P1FCHPRFM"."STPKS_STDCUSAC_UTILS_2" IS

  /*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2009 - 2013  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
-----------------------------------------------------------------------------------------------
  CHANGE HISTORY

  Changed By         :  Jayanth
  SFR No             :  -
  Change Description :  Initial Checkin
  Search Tag         :

  Changed By         :  Jayanth
  SFR No             :  1252
  Change Description :  Added parameter p_prev_stdcusac in fn_modify_acc
  Search Tag         :  FC10.3 - SFR#1252

  Changed By         :  Jayanth
  SFR No             :  1216
  Change Description :  Added function fn_populate_acc_type
  Search Tag         :  FC10.3 - SFR#1216

  Changed By         :  Rohit Bhan
  Change Description :  FCUBS 11.1 FOR Requirement MB0197
  Changed on         :  27-Mar-2010
  Search Tag         :  FCUBS 11.1 MB0197

  Changed By         :  Dipti
  Change Description :  FCUBS 11.2 FOR Multiline Changes
  Changed on         :  20-Sept-2010
  Search Tag         :  FCUBS 11.2 Multiline Linkages Changes

  Changed By         : Sandeep Sang
  SFR No             : 9NT1442 SFR#1238
  Modified on        : 17-DEC-2010
  Search string      : 9NT1442 SFR#1238
  Modified Reason    : Added the function Fn_Assign

     Changed Date      : 10-feb-2011
     Changed By        : Hemalatha N
     SFR Number        : 3976
     Search String     : SNORAS RETRO SFR# 3976 10-FEB-2011 Hemalatha
     Change Description: changes Call Stpks_Stdcusac_Main.Fn_Maint_Log global to update record log while closing account.

    Modified By           : Gokulnath M
    Modified On           : 2-Sep-2011
    Modified Reason       : 9NT1466 CIF-CASA_11.3.1 IUT changes
    Search String         : 9NT1466 CIF-CASA_11.3.1 IUT changes

    Changed By        : Arumugam S
    Changed On        : 06-Sep-2011
    Change Desc       : 9NT1462-Std docs
    Search Tag        : 9NT1462-Std docs

	Changed By        : Sathish H
    Changed On        : 14-Sep-2011
    Change Desc       : 9NT 1466 OD Linkages Fn_autocreate_coll_pool has been made global.
    Search Tag        : 9NT 1466 OD COLLATERAL LINKAGES BY SATHISH

  Changed by         : Shayam Sundar R
  Changed On         : 19-Apr-2013
  Change Description : FCUBS_12.0.2_DEV Joint holder Maintanence,Added a Function Fn_Add_Joint_Acc.
  Search String      : 9NT1587_FCUBS_12.0.2_DEV_Joint holder Maintanence_CHANGES
**
** Modified by        : Nalandhan G
** Modified On        : 23-Jun-2014
** Modified Reason    : Declared function Fn_Custadvice_Entires and fn_pickup_media.
** Search String      : 9NT1606_12_0_3_RETRO_19045839

    Modified By           : Gokulnath M
    Modified On           : 01-Sep-2014
    Modified Reason       : Moved the function Fn_updatelimitutil from kernel package to utils
    Search String         : 9NT1606_12.0.3_RETRO_TRUST_BANK_19465653
**
**   Modified by       : Shayam Sundar Ragunathan
**   Modified on       : 03-Jul-2015
**   Modified reason   : Added extra parameter for Function Fn_autocreate_coll_pool
**   Search string     : PNTFLX01016_FCUBS_12.1.0_ITR1_21368630

Changed By            : Althamis Aboobakker
Changed on            : 29-Jul-2015
Change Description    : Added the code to populate the where clause for the generic interface STOCUSAC.
Search string	      : PNTFLX01011_12.1_ITR1_21519677
**
** Modified By          : Nalandhan G
** Modified On          : 02-Aug-2016
** Modified Reason      : Changed the Parameter in Fn_updatelimitutil into the Generic form
                          Commented the unused code logic of pkg_no_prev_line variable
                          Added a additional parameter in Fn_updatelimitutil to initiate utilization
                          of limits during amount block
** Search String        : 9NT1606_12_0_3_CNSL_FHB_21537113
** Search String        : 9NT1606_12_2_RETRO_12_0_3_23654756
**
** Modified By         : Thiru
** Modified On         : 12-Sep-2018
** Modified Reason     : Backward-ported 14.0/14.1 - Account Balance Netting - Replacement for balance netting thru ELCM for the Bug#28466061
** Search String       : 14.0Patch - AccNetting

Modified By         : Saisudha Rathinavelu
Modified On         : 26-Sep-2018
Modified Reason     : Provided Extensible hooks.
Search String       : Bug#28700894

**
  -------------------------------------------------------------------------------------------------------
  */
  
--sampath starts
	G_TD_UPFRONT_BOOK_FLAG CHAR(1);
--sampath ends

  g_cr_user             smtb_user.user_id%type; --fc10.5 str2 sfr#1089 start
  g_ac_closure          boolean := false; --fc10.5 str2 sfr#1089 end
  g_ac_dormancy_closure varchar2(1) := 'N'; --Added for FCUBS 11.1 MB0197 on 27-Mar-10
  g_InitialFunding      boolean := false; --12.5_IUT_181/14.0Patch - AccNetting
  --pkg_no_prev_line    CHAR(1); --9NT1606_12.0.3_RETRO_TRUST_BANK_19465653 --9NT1606_12_2_RETRO_12_0_3_23654756 Commented
  g_stocusac VARCHAR2(1000) := 'PROCESS_REF_NO = GIPKS_INTERFACE_TRIGGER.g_ProcessRefNo and FLD1=''CUSTACC''';  --PNTFLX01011_12.1_ITR1_21519677 Changes
  --12.4_EXTN_Bug#28700894 Changes starts here
  PROCEDURE Pr_Set_Skip_Kernel;
  PROCEDURE Pr_Set_Activate_Kernel;
  PROCEDURE Pr_Set_Skip_Cluster;
  PROCEDURE Pr_Set_Activate_Cluster;
  FUNCTION Fn_Skip_Kernel RETURN BOOLEAN;
  FUNCTION Fn_Skip_Custom RETURN BOOLEAN;
  FUNCTION Fn_Skip_Cluster RETURN BOOLEAN;
  --12.4_EXTN_Bug#28700894 Changes ends here

  FUNCTION fn_modify_acc(p_Function_Id   IN VARCHAR2,
                         p_prev_stdcusac IN stpks_stdcusac_main.ty_stdcusac, --FC10.3 - SFR#1252
                         p_stdcusac      IN OUT stpks_stdcusac_main.ty_stdcusac,
                         p_action_code   IN VARCHAR2,
                         p_source        IN varchar2,
                         p_Err_Code      IN OUT VARCHAR2,                    --9NT1462-Std docs
                         p_Err_Params    IN OUT VARCHAR2) RETURN BOOLEAN;                  --9NT1462-Std docs

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_basic_default(p_Function_Id IN VARCHAR2,
                            p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_populate_amtdt(p_Function_Id IN VARCHAR2,
                             p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_auth_custacc(p_Function_Id IN VARCHAR2,
                           p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac,
                           p_action_code IN VARCHAR2,
                           p_source      IN VARCHAR2) RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_copy_init(p_Function_Id IN VARCHAR2,
                        p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_copy_acc(p_Function_Id IN VARCHAR2,
                       p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_delete_acc(p_Function_Id IN VARCHAR2,
                         p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_reopen_acc(p_Function_Id IN VARCHAR2,
                         p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac,
                         p_post_upld   IN BOOLEAN DEFAULT FALSE)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_get_acc_closure_det(p_Function_Id IN VARCHAR2,
                                  p_stcaclos    IN OUT stpks_stcaclos_main.ty_stcaclos,
                                  p_source      IN cotms_source.source_code%TYPE,
                                  p_close_reqd  OUT CHAR) RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_close_acc(p_Function_Id IN VARCHAR2,
                        p_stcaclos    IN OUT stpks_stcaclos_main.ty_stcaclos,
                        p_source      IN cotms_source.source_code%TYPE,
                        p_action_code IN VARCHAR2) RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_preclose_acc(p_Function_Id IN VARCHAR2,
                           p_stcaclos    IN OUT stpks_stcaclos_main.ty_stcaclos,
                           p_source      IN cotms_source.source_code%TYPE,
                           p_action_code IN VARCHAR2) RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  FUNCTION fn_post_close_acc(p_Function_Id IN VARCHAR2,
                             p_brn         IN sttms_cust_account.branch_code%TYPE,
                             p_acc         IN sttms_cust_account.cust_ac_no%TYPE)
    RETURN BOOLEAN;

  -------------------------------------------------------------------------------------------------------
  --FC10.3 - SFR#1216 - Begins
  FUNCTION fn_populate_acc_type(p_Function_Id   IN VARCHAR2,
                                p_prev_stdcusac IN stpks_stdcusac_main.ty_stdcusac,
                                p_stdcusac      IN OUT stpks_stdcusac_main.ty_stdcusac)
    RETURN BOOLEAN;
  --FC10.3 - SFR#1216 - Ends

  -------------------------------------------------------------------------------------------------------
  --FC10.3 - SFR#2151 - Begins
  FUNCTION fn_block(p_Function_Id IN VARCHAR2,
                    p_cust_no     IN sttms_customer.customer_no%TYPE)
    RETURN BOOLEAN;
  --FC10.3 - SFR#2151 - Ends

  --FCUBS11.2 Multiline Changes starts

  FUNCTION fn_populate_reinit_acc(p_Function_Id   IN VARCHAR2,
                                  p_prev_stdcusac IN stpks_stdcusac_main.ty_stdcusac,
                                  p_stdcusac      IN OUT stpks_stdcusac_main.ty_stdcusac,
                                  err_code        IN OUT Varchar2,
                                  err_params      IN OUT Varchar2)
  RETURN BOOLEAN;


  FUNCTION fn_set_reinit_acc(p_function_id IN VARCHAR2,
                            p_status      IN VARCHAR2,
                            p_ac_no       IN VARCHAR2,
                            p_branch      IN VARCHAR2,
                            p_error       IN OUT VARCHAR2,
                            p_err_params  IN OUT VARCHAR2)
RETURN BOOLEAN;
 --FCUBS11.2 Multiline Changes ends
 --9NT 1466 OD COLLATERAL LINKAGES BY SATHISH Starts
 FUNCTION Fn_autocreate_coll_pool(p_Gedapool IN elpks_collateral_service.Ty_Gedapool,
                                  p_Rec_Custacc IN Sttms_Cust_Account%ROWTYPE,--PNTFLX01016_FCUBS_12.1.0_ITR1_21368630
                                  p_gedcollat OUT elpks_collateral_service.Ty_Gedcollat,
                                  p_Gedcpool OUT elpks_collateral_service.ty_gedcpool,
                                  p_action_code IN VARCHAR2,
                                  p_err_code  IN OUT VARCHAR2,
                                  p_Err_Param IN OUT VARCHAR2) RETURN BOOLEAN;
 --9NT 1466 OD COLLATERAL LINKAGES BY SATHISH Ends
   --9NT1428 FCUBS 11.2 CHANGES BY ASLAM Startz
  FUNCTION fn_createclring_contract(p_function_id  IN VARCHAR2,
                                    p_acc_no       IN sttm_cust_account.cust_ac_no%TYPE,
                                    p_brn          IN sttm_branch.branch_code%TYPE,
                                    p_ccy          IN sttm_cust_account.ccy%TYPE,
                                    p_tdpayin      IN  ictms_tdpayin_details%ROWTYPE,
                                    p_err_code     IN OUT ertbs_msgs.err_code%TYPE) RETURN BOOLEAN ;

  --9NT1428 FCUBS 11.2 CHANGES BY ASLAM Endz
  --SNORAS RETRO SFR# 3976 10-FEB-2011 Hemalatha Starts
   Function Fn_Maint_Custac_Log( p_Source        In Varchar2
	                            ,p_Action_Code   In Varchar2
	                            ,p_Post_Upl_Stat In Varchar2
	                            ,p_Stdcusac      In Stpks_Stdcusac_Main.Ty_Stdcusac
	                            ,p_Prev_Stdcusac In Stpks_Stdcusac_Main.Ty_Stdcusac
	                            ,p_Wrk_Stdcusac  In Stpks_Stdcusac_Main.Ty_Stdcusac
	                            ,p_Err_Code      In Out Varchar2
	                            ,p_Err_Params    In Out Varchar2
	                             )Return Boolean;
  --SNORAS RETRO SFR# 3976 10-FEB-2011 Hemalatha Ends
-------------------------------------------------------------------------------------------------------
   --9NT1442 SFR#1238 Starts
   FUNCTION Fn_Assign(p_Function_Id IN VARCHAR2
                     ,p_Stdcusac    IN OUT Stpks_Stdcusac_Main.Ty_Stdcusac) RETURN BOOLEAN;
   --9NT1442 SFR#1238 Ends
-------------------------------------------------------------------------------------------------------
--9NT1466 CIF-CASA_11.3.1 IUT changes
FUNCTION Fn_Custacc_Entries(p_Function_Id  IN VARCHAR2
                              ,p_Wrk_Stdcusac IN OUT Sttms_Cust_Account%ROWTYPE) RETURN BOOLEAN;
--9NT1466 CIF-CASA_11.3.1 IUT changes
-------------------------------------------------------------------------------------------------------

--9NT1587_FCUBS_12.0.2_DEV_Joint holder Maintanence_CHANGES STARTS
FUNCTION Fn_Add_Joint_Acc(p_Source IN VARCHAR2
                         ,p_Function_Id IN VARCHAR2
                         ,p_Wrk_Stdcusac IN Stpks_Stdcusac_Main.Ty_Stdcusac
                         ,p_Err_Code      IN OUT VARCHAR2
                         ,p_Err_Params    IN OUT VARCHAR2) RETURN BOOLEAN;

FUNCTION Fn_Joint_Holder_Conversion(p_Source IN VARCHAR2
                                   ,p_Function_Id IN VARCHAR2
                                   ,p_Err_Code      IN OUT VARCHAR2
                                   ,p_Err_Params    IN OUT VARCHAR2) RETURN BOOLEAN;
--9NT1587_FCUBS_12.0.2_DEV_Joint holder Maintanence_CHANGES ENDS
--9NT1606_12_0_3_RETRO_19045839 starts
-------------------------------------------------------------------------------------------------------
FUNCTION Fn_Custadvice_Entires(p_Function_Id  IN VARCHAR2
                              ,p_Wrk_Stdcusac IN OUT Sttms_Cust_Account%ROWTYPE) RETURN BOOLEAN;
-------------------------------------------------------------------------------------------------------
FUNCTION Fn_Pickup_Media(p_acc      IN VARCHAR2
                        ,p_brn      IN VARCHAR2
                        ,p_cust     IN VARCHAR
                        ,p_msg_type IN VARCHAR2
                        ,p_module   IN VARCHAR2)
RETURN VARCHAR2;
-------------------------------------------------------------------------------------------------------
--9NT1606_12_0_3_RETRO_19045839 ends
--9NT1606_12.0.3_RETRO_TRUST_BANK_19465653 starts
--Fn_updatelimitutil will update the utilization while attaching the line during modification if the account with debit balance
-------------------------------------------------------------------------------------------------------
FUNCTION Fn_updatelimitutil(p_acc IN sttm_cust_account.cust_ac_no%TYPE,
                            p_brn IN sttm_cust_account.branch_code%TYPE,
                            --9NT1606_12_2_RETRO_12_0_3_23654756 Changes Starts
                            /*
                            p_Prev_Stdcusac IN Stpks_Stdcusac_Main.Ty_Stdcusac,
                            p_Wrk_Stdcusac  IN OUT Stpks_Stdcusac_Main.Ty_Stdcusac,
                            */
                            p_flag IN CHAR, --'N'>No Amount Block 'Y'> Amount Block 'R' > Line Removal
                            --9NT1606_12_2_RETRO_12_0_3_23654756 Changes Ends
                            p_errcode  OUT VARCHAR2,
                            p_errparam OUT VARCHAR2)
RETURN BOOLEAN;
-------------------------------------------------------------------------------------------------------
--9NT1606_12.0.3_RETRO_TRUST_BANK_19465653 ends
END stpks_stdcusac_utils_2;
/