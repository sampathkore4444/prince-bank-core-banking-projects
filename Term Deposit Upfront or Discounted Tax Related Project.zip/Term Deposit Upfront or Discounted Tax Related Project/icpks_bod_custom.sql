CREATE OR REPLACE

PACKAGE BODY icpks_bod_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'icpks_bod_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;

  FUNCTION ICFN_BOD(P_BRN            VARCHAR2,
                    P_DT             DATE,
                    P_PROCESS        NUMBER,
                    P_FN_CALL_ID     IN NUMBER,
                    P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN NUMBER IS
  BEGIN
    RETURN 1;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IC',
                     'In When Others of icpks_bod_custom.icfn_bod ..');
      DEBUG.PR_DEBUG('IC', SQLERRM);
      RETURN 0;
  END ICFN_BOD;

  PROCEDURE PR_ROLLOVER_DEPOSIT(P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_rollover_deposit');
  
    DBG('P_FN_CALL_ID P_FN_CALL_ID=' || P_FN_CALL_ID);
  
    --sampath starts
    IF P_FN_CALL_ID = '30' THEN
    
      IF P_TB_CUSTOM_DATA.EXISTS('l_rollover_amt') THEN
      
        IF NVL(P_TB_CUSTOM_DATA('l_rollover_amt'), 0) > 0 THEN
        
          G_TD_UPFRONT_ROLLOVER_AMT_FLAG := 'Y';
        
        END IF;
      
      END IF;
    
    END IF;
    --sampath ends
  
    DBG('End  of icpks_bod_custom.pr_rollover_deposit');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_rollover_deposit' ||
          SQLERRM);
  END PR_ROLLOVER_DEPOSIT;

  PROCEDURE PR_AUTO_EXTENSION_DEPOSIT(P_FN_CALL_ID     NUMBER,
                                      P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.Pr_Auto_Extension_Deposit');
    DBG('End  of icpks_bod_custom.Pr_Auto_Extension_Deposit');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.Pr_Auto_Extension_Deposit' ||
          SQLERRM);
  END PR_AUTO_EXTENSION_DEPOSIT;

  PROCEDURE PR_MATURITY_DEPOSIT(P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_maturity_deposit');
    DBG('End  of icpks_bod_custom.pr_maturity_deposit');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_maturity_deposit' ||
          SQLERRM);
  END PR_MATURITY_DEPOSIT;

  FUNCTION FN_SUPERSCRIBE_IC(P_BRN            IN OUT VARCHAR2,
                             P_ACCOUNT        IN OUT VARCHAR2,
                             P_TY_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_TY_ICCTDFPO    IN OUT ICPKS_ICCTDFPO_MAIN.TY_ICCTDFPO,
                             P_SOURCE         IN VARCHAR2,
                             P_FN_CALL_ID     IN NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_superscribe_ic');
    DBG('End  of icpks_bod_custom.fn_superscribe_ic');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_superscribe_ic' || SQLERRM);
      RETURN FALSE;
  END FN_SUPERSCRIBE_IC;

  PROCEDURE PR_LIQDBY_TD(P_FN_CALL_ID     NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_liqdby_td');
    DBG('End  of icpks_bod_custom.pr_liqdby_td');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_liqdby_td' || SQLERRM);
  END PR_LIQDBY_TD;

  PROCEDURE PR_POP_NEW_RATES_DURING_ROLL(P_ACC            IN ICTMS_ACC.ACC%TYPE,
                                         P_BRN            IN ICTMS_ACC.BRN%TYPE,
                                         P_CCY            IN STTMS_CUST_ACCOUNT.CCY%TYPE,
                                         P_ACLASS         IN STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                                         P_PROD           IN ICTBS_ACC_PR.PROD%TYPE,
                                         P_PROCESS_DT     IN DATE,
                                         P_FN_CALL_ID     NUMBER,
                                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.Pr_Pop_New_Rates_During_Roll');
    DBG('End  of icpks_bod_custom.Pr_Pop_New_Rates_During_Roll');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.Pr_Pop_New_Rates_During_Roll' ||
          SQLERRM);
  END PR_POP_NEW_RATES_DURING_ROLL;

  FUNCTION FN_TD_BOOK(TDACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                      TDBRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                      TDCCY            IN STTM_CUST_ACCOUNT.CCY%TYPE,
                      ERR_CODE         OUT ERTBS_MSGS.ERR_CODE%TYPE,
                      ERR_PARAM        OUT ERTBS_MSGS.MESSAGE%TYPE,
                      P_FN_CALL_ID     NUMBER,
                      P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_td_book');
    DBG('End  of icpks_bod_custom.fn_td_book');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_td_book' || SQLERRM);
      RETURN FALSE;
  END FN_TD_BOOK;

  FUNCTION FN_REINSTATE_DEPOSIT(P_BRANCH          ICTMS_ACC.BRN%TYPE,
                                P_ACC             ICTMS_ACC.ACC%TYPE,
                                P_NXT_MATURITY_DT ICTMS_ACC.MATURITY_DATE%TYPE,
                                P_ERR_CODE        IN OUT ERTBS_MSGS.ERR_CODE%TYPE,
                                P_ERR_MSG         IN OUT ERTBS_MSGS.MESSAGE%TYPE,
                                P_FN_CALL_ID      NUMBER,
                                P_TB_CUSTOM_DATA  IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_reinstate_deposit');
    DBG('End  of icpks_bod_custom.fn_reinstate_deposit');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_reinstate_deposit' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REINSTATE_DEPOSIT;

  PROCEDURE PR_SET_TBHANDOFF(P_AMT_TAG        IN VARCHAR2,
                             P_TAG_CCY        IN VARCHAR2,
                             P_TAG_AMT        IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                             P_BRN            IN VARCHAR2,
                             P_ACC            IN VARCHAR2,
                             P_CCY            IN VARCHAR2,
                             PKG_LOOKUP_ROW   IN BINARY_INTEGER,
                             P_TAG_AMT_LCY    IN OUT STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                             P_XRATE          IN OUT ACTBS_HANDOFF.EXCH_RATE%TYPE,
                             P_FN_CALL_ID     NUMBER,
                             P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_set_tbhandoff');
    DBG('End  of icpks_bod_custom.pr_set_tbhandoff');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_set_tbhandoff' || SQLERRM);
  END PR_SET_TBHANDOFF;

  PROCEDURE PR_SET_TBHANDOFF_DCD(P_TD_ACC         IN VARCHAR2,
                                 P_AMT_TAG        IN VARCHAR2,
                                 P_TAG_CCY        IN VARCHAR2,
                                 P_TAG_AMT        IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                 P_BRN            IN VARCHAR2,
                                 P_ACC            IN VARCHAR2,
                                 P_CCY            IN VARCHAR2,
                                 PKG_LOOKUP_ROW   IN BINARY_INTEGER,
                                 P_TAG_AMT_LCY    IN OUT STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                 P_XRATE          IN OUT ACTBS_HANDOFF.EXCH_RATE%TYPE,
                                 P_FN_CALL_ID     NUMBER,
                                 P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_set_tbhandoff_dcd');
    DBG('End  of icpks_bod_custom.pr_set_tbhandoff_dcd');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_set_tbhandoff_dcd' ||
          SQLERRM);
  END PR_SET_TBHANDOFF_DCD;

  PROCEDURE PR_LIQUIDATE_PRINC(PKG_LOOKUP_ROW   IN BINARY_INTEGER,
                               P_FN_CALL_ID     NUMBER,
                               P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_liquidate_princ');
    DBG('End  of icpks_bod_custom.pr_liquidate_princ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_liquidate_princ' || SQLERRM);
  END PR_LIQUIDATE_PRINC;

  FUNCTION FN_POPULATE_TDROLLOVER(P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                  P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                  P_PRODUCT        IN ICTBS_ACC_PR.PROD%TYPE,
                                  P_ACY_AVL_BAL    IN STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                  P_ICTM_ACC       IN ICPKS_BOD.CR_ICTM_ACC%ROWTYPE,
                                  P_ROLLOVER_AMT   IN ICTMS_ACC.ROLLOVER_AMT%TYPE,
                                  P_ERRCODE        OUT VARCHAR2,
                                  P_ERRMSG         OUT VARCHAR2,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_populate_tdrollover');
    DBG('End  of icpks_bod_custom.fn_populate_tdrollover');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_populate_tdrollover' ||
          SQLERRM);
      RETURN FALSE;
  END FN_POPULATE_TDROLLOVER;

  FUNCTION FN_PAYMENT_TXN(P_XREF             IN VARCHAR2,
                          P_BRANCH_CODE      IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                          P_ACC_NO           IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                          P_CCY              IN VARCHAR2,
                          P_TRNDT            IN DATE,
                          P_REDMAMT          IN NUMBER,
                          P_KEY              IN VARCHAR2,
                          P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_MSG          IN OUT VARCHAR2,
                          P_FN_CALL_ID       IN OUT NUMBER,
                          P_TB_CUSTOM_DATA   IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_payment_txn');
    DBG('End  of icpks_bod_custom.fn_payment_txn');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_payment_txn' || SQLERRM);
      RETURN FALSE;
  END FN_PAYMENT_TXN;

  PROCEDURE PR_LIQUIDATE_INTEREST(P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_liquidate_interest');
    DBG('End  of icpks_bod_custom.pr_liquidate_interest');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_liquidate_interest' ||
          SQLERRM);
  END PR_LIQUIDATE_INTEREST;

  PROCEDURE PR_LIQDBY_PC(P_FN_CALL_ID     NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_liqdby_pc');
    DBG('End  of icpks_bod_custom.pr_liqdby_pc');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_liqdby_pc' || SQLERRM);
  END PR_LIQDBY_PC;

  FUNCTION FN_MANUALROLLOVER_ADDLAMT(P_REDEM_REF_NO   IN VARCHAR2,
                                     P_BRN            IN VARCHAR2,
                                     P_ACC            IN VARCHAR2,
                                     P_CCY            IN VARCHAR2,
                                     P_CUST           IN VARCHAR2,
                                     P_ERR_CODE       OUT VARCHAR2,
                                     P_ERR_PARAMS     OUT VARCHAR2,
                                     P_FN_CALL_ID     NUMBER,
                                     P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_manualrollover_addlamt');
    DBG('End  of icpks_bod_custom.fn_manualrollover_addlamt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_manualrollover_addlamt' ||
          SQLERRM);
      RETURN FALSE;
  END FN_MANUALROLLOVER_ADDLAMT;

  FUNCTION FN_LIQUIDATE_DEBIT_INT(P_BRANCH         IN VARCHAR2,
                                  P_BOOK_ACC       IN ICTBS_DR_INT_DUE.BOOK_ACC%TYPE,
                                  P_VALUE_DT       IN ICTBS_DR_INT_DUE.DUE_DT%TYPE,
                                  P_MODE           IN VARCHAR2,
                                  P_PROD_TYPE      IN VARCHAR2,
                                  P_ERR_CODE       OUT VARCHAR2,
                                  P_ERR_MSG        OUT VARCHAR2,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN AS
  BEGIN
    DBG('Start of icpks_bod_custom.FN_LIQUIDATE_DEBIT_INT');
  
    DBG('End  of icpks_bod_custom.FN_LIQUIDATE_DEBIT_INT');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.FN_LIQUIDATE_DEBIT_INT' ||
          SQLERRM);
  END FN_LIQUIDATE_DEBIT_INT;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_PRE_PAYMENT_TXN_1405(P_DETB_RTL_TELLER_REC IN DETBS_RTL_TELLER%ROWTYPE,
                                   P_TRNDT               IN DATE,
                                   P_TXNAMT              IN NUMBER,
                                   P_KEY                 IN VARCHAR2,
                                   P_PCPAYOUTDETS_REC    IN OUT DETBS_PCTRN%ROWTYPE,
                                   P_ERR_CODE            IN OUT VARCHAR2,
                                   P_ERR_MSG             IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start of icpks_bod_custom.fn_pre_payment_txn_1405');
    DBG('End  of icpks_bod_custom.fn_pre_payment_txn_1405');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.fn_pre_payment_txn_1405' ||
          SQLERRM);
      RETURN FALSE;
  END FN_PRE_PAYMENT_TXN_1405;

  PROCEDURE PR_ROLLOVER_DEPOSIT(P_PR_INT_ACLASS  IN OUT ICTMS_PR_INT_ACLASS%ROWTYPE,
                                P_FN_CALL_ID     NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start of icpks_bod_custom.pr_rollover_deposit');
    DBG('End  of icpks_bod_custom.pr_rollover_deposit');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in icpks_bod_custom.pr_rollover_deposit' ||
          SQLERRM);
  END PR_ROLLOVER_DEPOSIT;

END ICPKS_BOD_CUSTOM;
