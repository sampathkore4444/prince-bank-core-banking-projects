CREATE OR REPLACE

PACKAGE BODY icpks_fcj_icdredmn AS

  PKG_SOURCE COTMS_SOURCE_PREF.SOURCE_CODE%TYPE;
  PKG_MODULE COTMS_SOURCE_PREF.MODULE_CODE%TYPE;

  PKG_RATE_CHART    STTM_ACCOUNT_CLASS.TD_RATECHART_ALLOW%TYPE;
  PKG_PENALTY_APPLY NUMBER := 1;

  G_BROKEN_AMOUNT NUMBER;
  G_TENOR         NUMBER;
  PKG_CLOSE_MODE  STTMS_CUSTAC_CLOSE_MODE.CLOSE_MODE%TYPE;
  G_BALREC        STTM_ACCOUNT_BALANCE%ROWTYPE;

  G_REDEM_INT_PAYOUT     ICTMS_ACC.REDM_INT_PAYOUT%TYPE;
  G_REDEM_INT_OFFSET_ACC ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;

  FUNCTION FN_DO_MEMO_ACCRUAL(P_BRN        IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              P_ACC        IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_START_DATE IN DATE,
                              P_END_DATE   IN DATE,
                              P_RULE       IN ICTM_PR_INT.RULE%TYPE,
                              P_PROD       IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                              P_ERR_CODE   IN OUT VARCHAR2,
                              P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_ADDPAYIN_DEFAULT(P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                               P_ADDNLPAYINREC IN OUT TY_TB_ADDNLPAYINDETAILS,
                               P_ERR_CODE      IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_VALIDATE_REDEMINTPAYOUT(P_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                      P_ERR_CODE     IN OUT VARCHAR2,
                                      P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'icpks_fcj_icdredmn ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;

  PROCEDURE PR_SET_REDM_INT_PARAMS(P_ICDREDMN      TDVWS_TD_REDEMPTION%ROWTYPE,
                                   P_TY_PAYOUTDETS IN OUT TY_TB_PAYOUTDETS) IS
    L_OFFSET_ACC ICTM_TDPAYOUT_DETAILS.OFFSET_ACC%TYPE;
  BEGIN
    DBG('Start of pr_set_redm_int_params');
    IF P_ICDREDMN.REDEM_INT_PAYOUT = 'I' THEN
      BEGIN
        SELECT OFFSET_ACC
          INTO L_OFFSET_ACC
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Err in getting Interest Payout from STDCUSTD' || SQLERRM);
          BEGIN
            SELECT BOOK_ACC
              INTO L_OFFSET_ACC
              FROM ICTMS_ACC
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No Payout For this account maintained');
          END;
      END;
      G_REDEM_INT_PAYOUT     := P_ICDREDMN.REDEM_INT_PAYOUT;
      G_REDEM_INT_OFFSET_ACC := L_OFFSET_ACC;
    ELSIF P_ICDREDMN.REDEM_INT_PAYOUT = 'R' THEN
      BEGIN
        SELECT OFFSET_ACC
          INTO L_OFFSET_ACC
          FROM ICTM_TDREDMPAYOUT_DETAILS
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO
           AND REDM_PAYOUT_COMP = 'I'
           AND REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
      
        WHEN NO_DATA_FOUND THEN
          IF P_TY_PAYOUTDETS.COUNT > 0 THEN
            FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
              IF P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP = 'I' THEN
                L_OFFSET_ACC := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                EXIT;
              END IF;
            END LOOP;
          END IF;
        WHEN OTHERS THEN
          DBG('Failed in getting the data' || SQLERRM);
          L_OFFSET_ACC := NULL;
        
      END;
      G_REDEM_INT_PAYOUT     := P_ICDREDMN.REDEM_INT_PAYOUT;
      G_REDEM_INT_OFFSET_ACC := L_OFFSET_ACC;
    ELSIF P_ICDREDMN.REDEM_INT_PAYOUT = 'P' THEN
      G_REDEM_INT_PAYOUT     := P_ICDREDMN.REDEM_INT_PAYOUT;
      G_REDEM_INT_OFFSET_ACC := P_ICDREDMN.AC_NO;
    END IF;
    DBG('Return from pr_set_redm_int_params' || G_REDEM_INT_PAYOUT || '~' ||
        G_REDEM_INT_OFFSET_ACC);
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in pr_set_redm_int_params' || SQLERRM);
  END PR_SET_REDM_INT_PARAMS;

  PROCEDURE PR_GET_REDM_INT_PARAMS(P_TYPE OUT VARCHAR2, P_ACC OUT VARCHAR2) IS
  BEGIN
    P_TYPE := G_REDEM_INT_PAYOUT;
    P_ACC  := G_REDEM_INT_OFFSET_ACC;
  END PR_GET_REDM_INT_PARAMS;

  FUNCTION FN_IS_REDM_INT_PAYOUT(P_BRN        IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                 P_ACC        IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_OFFSET_ACC OUT ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE)
    RETURN BOOLEAN IS
    L_REDM_INT_PAYOUT_CNT INTEGER := 0;
    L_OFFSET_ACC          ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Start of fn_is_Redm_Int_payout for' || P_ACC || P_BRN);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DBG('Calling icpks_fcj_icdredmn_cluster.fn_is_Redm_Int_payout');
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_IS_REDM_INT_PAYOUT(P_BRN,
                                                           P_ACC,
                                                           P_OFFSET_ACC,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA) THEN
        DBG('Failure has happened in icpks_fcj_icdredmn_cluster.fn_is_Redm_Int_payout');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_REDM_INT_PAYOUT_CNT
          FROM ICTMS_ACC
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND REDM_INT_PAYOUT = 'R';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('no data found' || SQLERRM);
          L_REDM_INT_PAYOUT_CNT := 0;
      END;
      DBG('l_redm_int_payout_cnt' || L_REDM_INT_PAYOUT_CNT);
      DBG('g_redemrefno@@' || ICPKS_FCJ_ICDREDMN.G_REDEMREFNO ||
          '>> p_brn' || P_BRN || '>> p_acc' || P_ACC);
      IF L_REDM_INT_PAYOUT_CNT > 0 THEN
        DBG('Interest payout account has to be define separately during redemption');
        DBG('icpks_fcj_icdredmn.g_redemrefno-->' ||
            ICPKS_FCJ_ICDREDMN.G_REDEMREFNO);
        IF ICPKS_FCJ_ICDREDMN.G_REDEMREFNO IS NOT NULL THEN
          BEGIN
            SELECT OFFSET_ACC
              INTO L_OFFSET_ACC
              FROM ICTM_TDREDMPAYOUT_DETAILS
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND REDM_PAYOUT_COMP = 'I'
               AND REDEM_REF_NO = ICPKS_FCJ_ICDREDMN.G_REDEMREFNO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in getting the data' || SQLERRM);
              L_OFFSET_ACC := NULL;
          END;
          DBG('l_offset_acc-->' || L_OFFSET_ACC);
          IF L_OFFSET_ACC IS NOT NULL THEN
            P_OFFSET_ACC := L_OFFSET_ACC;
            DBG('p_offset_acc-->' || P_OFFSET_ACC);
          END IF;
        END IF;
        RETURN TRUE;
      ELSE
        DBG('Redemption Interest will be payout to interest booking account');
        RETURN FALSE;
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
      RETURN TRUE;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_is_Redm_Int_payout' || SQLERRM);
      RETURN FALSE;
  END FN_IS_REDM_INT_PAYOUT;

  FUNCTION FN_AMT_TAX_LIQ_TILLDATE(P_TB_INT DBMS_SQL.NUMBER_TABLE)
    RETURN NUMBER IS
    L_INDEX PLS_INTEGER;
  
    L_TEMP NUMBER := 0;
  BEGIN
    IF P_TB_INT.COUNT > 0 THEN
      L_INDEX := P_TB_INT.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        DBG('Printing table:' || L_INDEX || '~' || P_TB_INT(L_INDEX));
        IF P_TB_INT(L_INDEX) != 0 THEN
          L_TEMP := L_TEMP + P_TB_INT(L_INDEX);
        END IF;
        L_INDEX := P_TB_INT.NEXT(L_INDEX);
      END LOOP;
      RETURN L_TEMP;
    END IF;
    RETURN L_TEMP;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO exception in pr_print_int' || SQLERRM);
  END FN_AMT_TAX_LIQ_TILLDATE;

  PROCEDURE PR_REN_RED(P_WRK_ICDREDMN IN OUT TDVWS_TD_REDEMPTION%ROWTYPE) IS
  BEGIN
    IF P_WRK_ICDREDMN.ACTION_FLAG = 'R' THEN
      P_WRK_ICDREDMN.TENOR_DD            := '';
      P_WRK_ICDREDMN.TENOR_MM            := '';
      P_WRK_ICDREDMN.TENOR_YY            := '';
      P_WRK_ICDREDMN.NEXT_MAT_DATE       := '';
      P_WRK_ICDREDMN.INTRATE_CUMAMT_REQD := '';
      P_WRK_ICDREDMN.ADD_FUNDS           := '';
      P_WRK_ICDREDMN.ADDITIONAL_AMT      := '';
    ELSIF P_WRK_ICDREDMN.ACTION_FLAG = 'E' THEN
      P_WRK_ICDREDMN.REDEMPTION_AMT  := '';
      P_WRK_ICDREDMN.REDEMPTION_BY   := 'D';
      P_WRK_ICDREDMN.REDEMPTION_MODE := NULL;
      P_WRK_ICDREDMN.WAVE_PENALTY    := 'N';
    
      P_WRK_ICDREDMN.REDEM_INT_PAYOUT := '';
    END IF;
  END PR_REN_RED;

  PROCEDURE PR_GET_RATE_AND_AMT(P_CCY1      IN VARCHAR2,
                                P_CCY2      IN VARCHAR2,
                                P_AMT1      IN NUMBER,
                                P_RATE      IN OUT NUMBER,
                                P_AMT2      IN OUT NUMBER,
                                P_RATE_CODE IN OUT VARCHAR2,
                                P_RATE_TYPE IN OUT VARCHAR2) IS
    P_ERR_CODE    VARCHAR2(1000);
    L_PRM_OFS_AMT NUMBER(30);
  BEGIN
    L_PRM_OFS_AMT := '';
    DBG('Get rate and amt ' || P_RATE_TYPE || ' and ' || P_RATE_CODE);
  
    IF NOT CYPKS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                 P_CCY1,
                                 P_CCY2,
                                 NVL(P_RATE_TYPE, 'STANDARD'),
                                 NVL(P_RATE_CODE, 'M'),
                                 P_AMT1,
                                 'Y',
                                 P_AMT2,
                                 P_RATE,
                                 P_ERR_CODE) THEN
      DBG('Failed to get rates or rates not maintained for the currency');
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
    ELSE
      DBG('Chg Acy amount got successfully for the chg amount-> ' ||
          P_AMT2);
      DBG('Exch Rate Got successfully -> ' || P_RATE);
    END IF;
  
  END;

  FUNCTION FN_REDBY_TD(P_SOURCE        IN VARCHAR2,
                       P_WRK_ICDREDMN  IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_TY_STDCUSAC   IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                       P_REDM_MODE     IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_REDBY_PC(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                       P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_REDBY_BC(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                       L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                       P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_REDBY_SAVINGS(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                            P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                            L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                            P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_REDBY_GL(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                       P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN;
  FUNCTION FN_REDBY_CASH(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                         P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                         L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                         P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_ROLLOVER(P_WRK_ICDREDMN IN OUT TDVWS_TD_REDEMPTION%ROWTYPE)
    RETURN BOOLEAN;

  FUNCTION FN_SCAN_ERROR_LIST(P_FINAL_ERROR_TYPE OUT CHAR,
                              P_ERROR_CODE       IN OUT VARCHAR2,
                              P_ERROR_PARAMETER  IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_MANDATORY_REDEMPTION(P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                   P_TY_PAYOUTDETS IN OUT TY_TB_PAYOUTDETS)
    RETURN BOOLEAN IS
  
    L_RET        NUMBER := 1;
    L_ERR_PARAMS VARCHAR2(100);
    L_ERR_CODE   VARCHAR2(50);
  BEGIN
    DBG('Inside fn_mandatory_redemption');
  
    FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
      DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS(I).INSTNO);
    END LOOP;
  
    DBG('Mandatory check - Branch Code');
    IF P_ICDREDMN.BRN_CODE IS NULL THEN
      DBG('BRANCH CODE IS MANDATORY');
    
      CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                   '1317',
                                   'ST-MAND-001',
                                   '@TDVWS_TD_REDEMPTION.BRN_CODE');
    
      L_RET := -1;
    END IF;
  
    DBG('Mandatory check - TERM DEPOSIT ACCOUNT NUMBER');
    IF P_ICDREDMN.AC_NO IS NULL THEN
      DBG('TERM DEPOSIT ACCOUNT NUMBER IS MANDATORY');
    
      CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                   '1317',
                                   'ST-MAND-001',
                                   '@CSTBS_UI_COLUMNS.CHAR_FIELD2');
    
      L_RET := -1;
    END IF;
  
    DBG('Mandatory check - ACTION FLAG');
    IF P_ICDREDMN.ACTION_FLAG IS NULL THEN
      DBG('Select action - Renewal/Redemption');
      OVPKSS.PR_APPENDTBL('TD-REDM16',
                          'Select action - Renewal/Redemption');
      L_RET := -1;
    END IF;
  
    DBG('p_icdredmn.redemption_by :' || P_ICDREDMN.REDEMPTION_BY);
    DBG('Defaulting redemption by to M for multimode');
    IF P_ICDREDMN.REDEMPTION_BY IS NULL THEN
      P_ICDREDMN.REDEMPTION_BY := 'M';
    END IF;
  
    IF L_RET < 1 THEN
      DBG('Mandatory check failed in fn_mandatory_redemption');
      RETURN FALSE;
    END IF;
  
    IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(NULL,
                                           P_ICDREDMN.AC_NO,
                                           P_ICDREDMN.BRN_CODE,
                                           'N',
                                           L_ERR_PARAMS,
                                           L_ERR_CODE) THEN
      DBG('FAILED IN fn_check_cust' || SQLERRM);
      OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAMS);
      RETURN FALSE;
    END IF;
  
    DBG('returning true from fn_mandatory_redemption');
    RETURN TRUE;
  END FN_MANDATORY_REDEMPTION;
  FUNCTION FN_MANDATORY_PAYOUTDETAILS(P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                      P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                      P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                      P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                      P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
  
   RETURN BOOLEAN IS
    L_FLD VARCHAR2(1000);
    L_CNT NUMBER;
    L_RET NUMBER := 1;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside fn_mandatory_payoutdetails');
  
    FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
      DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS(I).INSTNO);
    END LOOP;
  
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
        DBG('p_ty_payoutdets(i).payouttype::' || P_TY_PAYOUTDETS(I)
            .PAYOUTTYPE);
      
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('B', 'D') THEN
          DBG('Mandatory check - BANK CODE ' ||
              P_BCPAYOUTDETS_REC.BANKCODE);
          IF P_BCPAYOUTDETS_REC.BANKCODE IS NULL THEN
            DBG('BANK CODE IS MANDATORY ');
          
            L_FLD := '@ICTMS_BCPAYOUT_DETAILS.BANKCODE';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         'CTDR',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
          DBG('Mandatory check - CHEQUE CURRENCY ' ||
              P_BCPAYOUTDETS_REC.CHQ_CCY);
        
          DBG('Mandatory check - CHEQUE DATE' ||
              P_BCPAYOUTDETS_REC.CHQ_DATE);
          IF P_BCPAYOUTDETS_REC.CHQ_DATE IS NULL THEN
            DBG('CHEQUE DATE IS MANDATORY');
          
            L_FLD := '@ICTMS_BCPAYOUT_DETAILS.CHQ_DATE';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         'CTDR',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
        ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'S' THEN
          DBG('Mandatory check - SAVINGS ACCOUNT BRANCH CODE');
          IF P_TY_PAYOUTDETS(I).OFFSET_BRN IS NULL THEN
            DBG('SAVINGS ACCOUNT BRANCH CODE IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_BRN';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
          DBG('Mandatory check - SAVINGS ACCOUNT NUMBER');
          IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NULL THEN
            DBG('SAVINGS ACCOUNT NUMBER IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_ACC';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
        ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'G' THEN
          DBG('GENERAL LEDGER NUMBER IS MANDATORY');
          IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NULL THEN
            DBG('GENERAL LEDGER NUMBER IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_ACC';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
        ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'L' THEN
          DBG('CL Account NUMBER IS MANDATORY');
          IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NULL THEN
            DBG('CL Account NUMBER IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_ACC';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
          IF P_TY_PAYOUTDETS(I).OFFSET_BRN IS NULL THEN
            DBG('CL Account Branch IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.OFFSET_BRN';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
            L_RET := -1;
          END IF;
        
        ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
        
          DBG('TRANSACTION CURRENCY IS MANDATORY');
        
        ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'P' THEN
          IF P_PCPAYOUTDETS_REC.PCBANKCODE IS NULL THEN
            DBG('PC BANK CODE IS MANDATORY ');
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         'CTDR',
                                         'ST-MAND-001',
                                         '@ICTMS_PCPAYOUT_DETAILS.PCBANKCODE');
          
            L_RET := -1;
          END IF;
          IF P_PCPAYOUTDETS_REC.PCOFFSET_ACC IS NULL THEN
            DBG('PC Account  IS MANDATORY ');
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         'CTDR',
                                         'ST-MAND-001',
                                         '@ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC');
          
            L_RET := -1;
          END IF;
        
        END IF;
      END LOOP;
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_ret') := L_RET;
      L_FN_CALL_ID := 1;
    
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MANDATORY_PAYOUTDETAILS(P_ICDREDMN,
                                                                P_TY_PAYOUTDETS,
                                                                P_BCPAYOUTDETS_REC,
                                                                P_PCPAYOUTDETS_REC,
                                                                P_TY_STDCUSAC,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
        DBG('Failed while calling fn_mandatory_payoutdetails in cluster package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_ret') THEN
        L_RET := L_TB_CLUSTER_DATA('l_ret');
      END IF;
    
    END IF;
  
    IF L_RET < 1 THEN
      DBG('mandatory check failed in fn_mandatory_payoutdetails');
      RETURN FALSE;
    END IF;
  
    DBG('mandatory check done in fn_mandatory_payoutdetails');
    RETURN TRUE;
  
  END FN_MANDATORY_PAYOUTDETAILS;

  FUNCTION FN_DEFAULT_PAYOUTDETAILS(P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                    P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                    P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                    P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                    P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
  
   RETURN BOOLEAN IS
    L_FLD VARCHAR2(1000);
    L_CNT NUMBER;
    L_RET NUMBER := 0;
  
    L_ROW_AMT       NUMBER(22, 3) := 0;
    L_TOTAL         NUMBER(22, 3) := 0;
    L_AMT           NUMBER(22, 3) := 0;
    L_TOTAL_PER     NUMBER(22, 3) := 0;
    L_SEQNO         NUMBER := 0;
    INTEREST_AMOUNT NUMBER := 0;
    TAX_AMOUNT      NUMBER := 0;
    L_BOOK_ACC      ICTMS_ACC.BOOK_ACC%TYPE;
  
    L_PRODUCT        ICTMS_PR_INT.PRODUCT_CODE%TYPE;
    L_PAYMENT_METHOD ICTMS_PR_INT.PAYMENT_METHOD%TYPE;
  
    L_TOTAL_ROUNDEDOFF NUMBER(22, 3) := 0;
    L_ERR_CODE         VARCHAR2(15);
    L_ERR_PARAMS       VARCHAR2(100);
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_ICTM_PR_INT      ICTMS_PR_INT%ROWTYPE;
    L_PAYOUT_COUNT     NUMBER;
    L_PRINCIPAL_FLG    BOOLEAN := FALSE;
    L_LAST_PRINC_INDEX PLS_INTEGER;
    L_REC_ICTM_ACC     ICTM_ACC%ROWTYPE;
  BEGIN
    DBG('Inside');
  
    FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
      DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS(I).INSTNO);
    END LOOP;
  
    DBG('Inside fn_default_payoutdetails');
    BEGIN
      SELECT NVL(MAX(SEQNO), 1)
        INTO L_SEQNO
        FROM ICTM_TDREDMPAYOUT_DETAILS
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO
         AND CCY = P_ICDREDMN.CCY;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_SEQNO := 1;
    END;
  
    BEGIN
      SELECT A.TD_RATECHART_ALLOW
        INTO PKG_RATE_CHART
        FROM STTM_ACCOUNT_CLASS A, STTM_CUST_ACCOUNT B
       WHERE B.BRANCH_CODE = P_ICDREDMN.BRN_CODE
         AND B.CUST_AC_NO = P_ICDREDMN.AC_NO
         AND A.ACCOUNT_CLASS = B.ACCOUNT_CLASS;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        PKG_RATE_CHART := 'N';
    END;
  
    BEGIN
      SELECT PROD
        INTO L_PRODUCT
        FROM ICTMS_ACC_PR
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT of product select--> ' || SQLERRM);
        RETURN FALSE;
      
    END;
  
    L_ICTM_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PRODUCT);
  
    DBG('Payment Method is--> ' || L_ICTM_PR_INT.PAYMENT_METHOD);
  
    SELECT DECODE(P_ICDREDMN.WAIVE_INTEREST, 'Y', 1, 'N', '0')
      INTO ICPKS_BOD.G_WAVE_INTEREST
      FROM DUAL;
  
    DBG('l_seqno for the ME is :' || L_SEQNO);
    DBG('ME count :' || P_TY_PAYOUTDETS.COUNT);
  
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      DBG('Redemption Amount is:' || P_ICDREDMN.REDEMPTION_AMT);
    
      FOR K IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
        DBG(' Redemption Payout Component =' || P_TY_PAYOUTDETS(K)
            .REDM_PAYOUT_COMP);
        IF P_TY_PAYOUTDETS(K).REDM_PAYOUT_COMP = 'P' THEN
          DBG('Principal component  index =' || K);
          L_LAST_PRINC_INDEX := K;
        END IF;
      END LOOP;
      DBG('Principal last index =' || L_LAST_PRINC_INDEX);
    
      FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
      
        P_TY_PAYOUTDETS(I).BRN := P_ICDREDMN.BRN_CODE;
        P_TY_PAYOUTDETS(I).ACC := P_ICDREDMN.AC_NO;
        P_TY_PAYOUTDETS(I).CCY := P_ICDREDMN.CCY;
        P_TY_PAYOUTDETS(I).SEQNO := L_SEQNO;
        IF P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP = 'P' THEN
          L_PRINCIPAL_FLG := TRUE;
          IF P_TY_PAYOUTDETS(I).REDMAMT IS NULL THEN
            IF P_TY_PAYOUTDETS(I).PERCENTAGE IS NOT NULL THEN
            
              IF I = L_LAST_PRINC_INDEX
              
               THEN
              
                DBG('Available amount after redemption is' ||
                    L_TOTAL_ROUNDEDOFF);
              
                P_TY_PAYOUTDETS(I).REDMAMT := P_ICDREDMN.REDEMPTION_AMT -
                                              L_TOTAL_ROUNDEDOFF;
              
                L_TOTAL_PER := L_TOTAL_PER + P_TY_PAYOUTDETS(I).PERCENTAGE;
                DBG('REDMamt for count 1 :' || P_TY_PAYOUTDETS(I).REDMAMT);
                DBG('l_total_per for count 1 :' || L_TOTAL_PER);
              ELSE
                L_ROW_AMT := (P_TY_PAYOUTDETS(I)
                             .PERCENTAGE * P_ICDREDMN.REDEMPTION_AMT) /
                             100.00;
                L_TOTAL := L_TOTAL + L_ROW_AMT;
                P_TY_PAYOUTDETS(I).REDMAMT := L_ROW_AMT;
                L_TOTAL_PER := L_TOTAL_PER + P_TY_PAYOUTDETS(I).PERCENTAGE;
                DBG('REDMamt for  :' || I || 'is :' || P_TY_PAYOUTDETS(I)
                    .REDMAMT);
                DBG('l_total for  :' || I || 'is :' || L_TOTAL);
                DBG('l_total_per for  :' || I || 'is :' || L_TOTAL_PER);
              END IF;
            
              FOR M IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
                DBG(' Redemption Payout Component =' || P_TY_PAYOUTDETS(M)
                    .REDM_PAYOUT_COMP);
                IF P_TY_PAYOUTDETS(M).REDM_PAYOUT_COMP = 'I' THEN
                  DBG('interest component  index =' || M);
                  DBG('To default the interest amount');
                  IF P_TY_PAYOUTDETS(M).REDMAMT IS NULL THEN
                    P_TY_PAYOUTDETS(M).REDMAMT := NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_INT,
                                                      0) - NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_TAX,
                                                               0) -
                                                  NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_PENALTY,
                                                      0);
                    DBG('redemption amoutn for interest ---->' || P_TY_PAYOUTDETS(M)
                        .REDMAMT);
                  END IF;
                END IF;
              END LOOP;
            
            ELSIF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
                       'N') = 'N') THEN
            
              DBG('Both Percentage or Payout Amount cannot be null');
              L_RET := 1;
              OVPKSS.PR_APPENDTBL('TD-RED-20', '');
            END IF;
          ELSE
            IF P_TY_PAYOUTDETS(I).REDMAMT IS NOT NULL THEN
              L_AMT := L_AMT + P_TY_PAYOUTDETS(I).REDMAMT;
            
              IF I = L_LAST_PRINC_INDEX
                
                 AND P_TY_PAYOUTDETS(I).PERCENTAGE IS NOT NULL AND
                 GWPKS_UTIL.G_FROM_BEAN THEN
                DBG('Available amount after redemption in Else part is' ||
                    L_TOTAL_ROUNDEDOFF);
                P_TY_PAYOUTDETS(I).REDMAMT := P_ICDREDMN.REDEMPTION_AMT -
                                              L_TOTAL_ROUNDEDOFF;
                L_AMT := P_ICDREDMN.REDEMPTION_AMT;
                L_TOTAL_PER := 100;
              END IF;
            
              DBG('REDMamt for  :' || I || 'is :' || P_TY_PAYOUTDETS(I)
                  .REDMAMT);
              DBG('l_amt for  :' || I || 'is :' || L_AMT);
            
            ELSIF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
                       'N') = 'N') THEN
            
              DBG('Both Percentage or Payout Amount cannot be null');
              L_RET := 1;
              OVPKSS.PR_APPENDTBL('TD-RED-20', '');
            
            END IF;
          END IF;
        END IF;
      
        IF I < L_LAST_PRINC_INDEX AND
           NVL(P_TY_PAYOUTDETS(I).REDMAMT, 0) <> 0
        
         THEN
          DBG('calling cypks amount rounding');
          IF NOT CYPKSS.FN_AMT_ROUND(P_ICDREDMN.CCY,
                                     P_TY_PAYOUTDETS(I).REDMAMT,
                                     P_TY_PAYOUTDETS(I).REDMAMT) THEN
            DBG('failed in amt rounding: ' || SQLERRM);
            RETURN FALSE;
          END IF;
        
        END IF;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 1;
        
          IF NOT
              ICPKS_FCJ_ICDREDMN_CLUSTER.FN_DEFAULT_PAYOUTDETAILS(P_ICDREDMN,
                                                                  P_TY_PAYOUTDETS,
                                                                  P_BCPAYOUTDETS_REC,
                                                                  P_PCPAYOUTDETS_REC,
                                                                  P_TY_STDCUSAC,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
            DBG('Failed while calling fn_default_payoutdetails in cluster package' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;
      
        L_TOTAL_ROUNDEDOFF := L_TOTAL_ROUNDEDOFF +
                              NVL(P_TY_PAYOUTDETS(I).REDMAMT, 0);
      
        DBG('Available amount after redemption in count ' || I || 'is:' ||
            L_TOTAL_ROUNDEDOFF);
      
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('B', 'D') THEN
          DBG('BC check CCY :' || P_BCPAYOUTDETS_REC.CHQ_CCY);
          IF P_BCPAYOUTDETS_REC.CHQ_CCY IS NULL THEN
            P_BCPAYOUTDETS_REC.CHQ_CCY := P_ICDREDMN.CCY;
            P_BCPAYOUTDETS_REC.CCY     := P_ICDREDMN.CCY;
          END IF;
          P_BCPAYOUTDETS_REC.CHQ_PERCENT := P_TY_PAYOUTDETS(I).PERCENTAGE;
          P_BCPAYOUTDETS_REC.CHQ_AMT     := P_TY_PAYOUTDETS(I).REDMAMT;
        
        END IF;
      
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'P' THEN
          DBG('PC check CCY :' || P_PCPAYOUTDETS_REC.CCY);
          IF P_PCPAYOUTDETS_REC.CCY IS NULL THEN
            P_PCPAYOUTDETS_REC.CCY := P_ICDREDMN.CCY;
          END IF;
          P_PCPAYOUTDETS_REC.PCPERCENTAGE := P_TY_PAYOUTDETS(I).PERCENTAGE;
          P_PCPAYOUTDETS_REC.TXNAMT       := P_TY_PAYOUTDETS(I).REDMAMT;
        END IF;
      
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('S', 'G', 'C') THEN
          DBG('PC check CCY :' || P_PCPAYOUTDETS_REC.CCY);
          IF P_TY_PAYOUTDETS(I).CCY IS NULL THEN
            P_TY_PAYOUTDETS(I).CCY := P_ICDREDMN.CCY;
          END IF;
        END IF;
      
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'Y' THEN
          DBG('Branch code :' || P_ICDREDMN.BRN_CODE);
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY          := P_ICDREDMN.CCY;
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE  := P_ICDREDMN.BRN_CODE;
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
        
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO := P_ICDREDMN.CUST_ID;
        
        END IF;
        L_SEQNO := L_SEQNO + 1;
      END LOOP;
    
      IF NOT L_PRINCIPAL_FLG THEN
        DBG('Principal payout Not maintained for the account');
        OVPKSS.PR_APPENDTBL('TD-RED-27', '');
        L_RET := 1;
      END IF;
    
    ELSIF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
               'N') = 'N') THEN
    
      DBG('Payout Cannot be null');
      OVPKSS.PR_APPENDTBL('TD-RED-22', '');
      L_RET := 1;
    
    END IF;
    DBG('l_amt ~ l_total ~ redemption_amt :' || L_AMT || ' ~ ' || L_TOTAL || '~' ||
        P_ICDREDMN.REDEMPTION_AMT);
    DBG('l_total_per :' || L_TOTAL_PER);
    IF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
            'N') = 'N') AND L_PRINCIPAL_FLG THEN
      IF (L_TOTAL_PER = 0 AND (L_AMT <> P_ICDREDMN.REDEMPTION_AMT)) THEN
        DBG('Total Amount should be equal to redemption amount');
        OVPKSS.PR_APPENDTBL('TD-RED-21', '');
        L_RET := 1;
      END IF;
    
      IF NOT (L_TOTAL_PER = 0 OR L_TOTAL_PER = 100) THEN
        DBG('Total Percentage is not consistent');
        OVPKSS.PR_APPENDTBL('TD-RED-22', '');
        L_RET := 1;
      END IF;
    END IF;
    IF L_RET > 0 THEN
      DBG('returning false from fn_default_payoutdetails');
      RETURN FALSE;
    END IF;
    DBG('returning true from fn_default_payoutdetails');
    RETURN TRUE;
  END FN_DEFAULT_PAYOUTDETAILS;

  FUNCTION FN_TDACCGEN(P_FUNCTION_ID IN VARCHAR2,
                       P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_ACC_PARAM_REC STTMS_ACC_PARAM%ROWTYPE;
    L_MASK_BRANCH   STTMS_ACC_PARAM.BRANCH_CODE%TYPE;
    L_DEPNO         STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  BEGIN
    DBG('Inside fn_tdaccgen');
  
    DBG('Selecting from sttms_acc_param');
    BEGIN
      SELECT *
        INTO L_ACC_PARAM_REC
        FROM STTMS_ACC_PARAM
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      L_MASK_BRANCH := GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT *
          INTO L_ACC_PARAM_REC
          FROM STTMS_ACC_PARAM
         WHERE BRANCH_CODE = '***';
        L_MASK_BRANCH := '***';
    END;
  
    DBG('Auto gen flag: ' || L_ACC_PARAM_REC.AC_AUTOGEN_FLAG);
    IF NVL(L_ACC_PARAM_REC.AC_AUTOGEN_FLAG, 'N') = 'N' THEN
      DBG('Auto generation is turned off');
      DBG('Not An Autogenerated Account. Can not be generated. Failed: Raise an error');
    
      BEGIN
        IF NOT ICPKS_BOD.FN_GEN_CHILTD_ACCNT_NO(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                L_DEPNO) THEN
          DBG('Failed in generating acc no...');
          RETURN FALSE;
        END IF;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := L_DEPNO;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO  := L_DEPNO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Exception  in generating acc no...');
          RETURN FALSE;
      END;
    
    ELSE
      DBG('Acc autogen is Y');
      DBG('Acc mask: ' || L_ACC_PARAM_REC.CUSTOMER_ACC_MASK);
      IF NOT STPKS_STDCUSAC_UTILS_0.FN_ACC_AUTOGEN(P_FUNCTION_ID,
                                                   LENGTH(L_ACC_PARAM_REC.CUSTOMER_ACC_MASK),
                                                   P_STDCUSAC) THEN
        DBG('Unable to generate account.. fn_acc_autogen has returned false');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('fn_tdaccgen Returning true...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_tdaccgen with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', '');
      RETURN FALSE;
  END FN_TDACCGEN;

  FUNCTION FN_VALIDATE_DENOM_DEP(P_ACTION_CODE   IN VARCHAR2,
                                 P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                 P_TY_PAYOUTDETS IN OUT TY_TB_PAYOUTDETS,
                                 P_TY_ICDREDMN   IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                 P_ERR_CODE      IN OUT VARCHAR2,
                                 P_ERR_PARM      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_TD_BAL       NUMBER;
    L_BLOCK_AMT    NUMBER := 0;
    L_CERT_COUNT   NUMBER := 0;
    L_DENM_DEPOSIT VARCHAR2(1) := 'N';
  BEGIN
    DBG('Start of Fn_Validate_Denom_Dep');
  
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
        IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'Y' THEN
          BEGIN
            SELECT DENM_DEPOSIT
              INTO L_DENM_DEPOSIT
              FROM STTM_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS =
                   (SELECT ACCOUNT_CLASS
                      FROM STTM_CUST_ACCOUNT
                     WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
                       AND BRANCH_CODE = P_ICDREDMN.BRN_CODE);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in selecting account class..' || SQLERRM);
          END;
        
          IF NVL(L_DENM_DEPOSIT, 'N') = 'Y' THEN
            P_ERR_CODE := 'TD-DNDP-02';
            P_ERR_PARM := NULL;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARM);
            RETURN FALSE;
          
          END IF;
        END IF;
      END LOOP;
    END IF;
    BEGIN
      SELECT COUNT(*)
        INTO L_CERT_COUNT
        FROM STTMS_CUST_ACCOUNT A, STTMS_ACCOUNT_CLASS B
       WHERE A.ACCOUNT_CLASS = B.ACCOUNT_CLASS
         AND B.DENM_DEPOSIT = 'Y'
         AND A.CUST_AC_NO = P_ICDREDMN.AC_NO
         AND A.BRANCH_CODE = P_ICDREDMN.BRN_CODE;
      DBG('l_Cert_Count-->' || NVL(L_CERT_COUNT, 0));
      IF NVL(L_CERT_COUNT, 0) > 0 AND
         P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT = 0 THEN
        DBG('Please issue certificates before redemption for the Denomination Deposit Account');
        OVPKSS.PR_APPENDTBL('TD-RED-30', P_ERR_PARM);
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in count of Denomination deposit');
    END;
  
    IF P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT > 0 THEN
    
      SELECT NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0)
        INTO L_TD_BAL
        FROM ICTMS_TD_DETAILS
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
      DBG('l_td_bal-->' || L_TD_BAL);
    
      FOR I IN P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.FIRST .. P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.LAST LOOP
      
        IF P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).BLOCK_OR_REDEM = 'R' THEN
          L_BLOCK_AMT := L_BLOCK_AMT + P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                        .CERTIFICATE_AMOUNT;
        END IF;
      END LOOP;
      DBG('l_Block_Amt = ' || L_BLOCK_AMT);
      DBG('p_Icdredmn.Redemption_Amt = ' || P_ICDREDMN.REDEMPTION_AMT);
    
      IF L_CERT_COUNT > 0 THEN
        IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
          IF NVL(L_BLOCK_AMT, 0) != NVL(L_TD_BAL, 0) THEN
            P_ERR_CODE := 'TD-RED-25';
            P_ERR_PARM := '';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARM);
            RETURN FALSE;
          END IF;
        ELSE
          IF L_BLOCK_AMT != P_ICDREDMN.REDEMPTION_AMT THEN
            P_ERR_CODE := 'TD-RED-25';
            P_ERR_PARM := '';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARM);
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('End of Fn_Validate_Denom_Dep');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Validate_Denom_Dep');
      DBG('Line No = ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||
          ', SQLERRM = ' || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_DENOM_DEP;

  FUNCTION FN_VALIDATE_RENEWAL(P_BRN       VARCHAR2,
                               P_ACC       VARCHAR2,
                               P_ERR_CODE  OUT VARCHAR2,
                               P_ERR_PARAM OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR CUR_PAYOUT_DET IS
      SELECT *
        FROM ICTM_TDPAYOUT_DETAILS
       WHERE BRN = P_BRN
         AND ACC = P_ACC;
  
    TYPE TY_TB_PAYOUT_DET IS TABLE OF CUR_PAYOUT_DET%ROWTYPE INDEX BY BINARY_INTEGER;
    L_TB_PAYOUT_DET   TY_TB_PAYOUT_DET;
    L_IDX             PLS_INTEGER;
    L_AC_STAT_FROZEN  STTMS_CUST_ACCOUNT.AC_STAT_FROZEN%TYPE;
    L_AC_STAT_NO_DR   STTMS_CUST_ACCOUNT.AC_STAT_NO_DR%TYPE;
    L_AC_STAT_NO_CR   STTMS_CUST_ACCOUNT.AC_STAT_NO_CR%TYPE;
    L_AC_STAT_DORMANT STTMS_CUST_ACCOUNT.AC_STAT_DORMANT%TYPE;
  BEGIN
    DBG('Start of fn_validate_renewal');
    IF CUR_PAYOUT_DET%ISOPEN THEN
      CLOSE CUR_PAYOUT_DET;
    END IF;
    OPEN CUR_PAYOUT_DET;
  
    FETCH CUR_PAYOUT_DET BULK COLLECT
      INTO L_TB_PAYOUT_DET;
    IF L_TB_PAYOUT_DET.COUNT > 0 THEN
      L_IDX := L_TB_PAYOUT_DET.FIRST;
      WHILE L_IDX IS NOT NULL LOOP
        IF L_TB_PAYOUT_DET(L_IDX).PAYOUTTYPE = 'S' THEN
          DBG('l_tb_payout_Det(l_idx).offset_brn--->' || L_TB_PAYOUT_DET(L_IDX)
              .OFFSET_BRN);
          DBG('l_tb_payout_Det(l_idx).offset_acc--->' || L_TB_PAYOUT_DET(L_IDX)
              .OFFSET_ACC);
        
          BEGIN
            SELECT NVL(AC_STAT_FROZEN, 'N'),
                   NVL(AC_STAT_NO_DR, 'N'),
                   NVL(AC_STAT_NO_CR, 'N'),
                   NVL(AC_STAT_DORMANT, 'N')
              INTO L_AC_STAT_FROZEN,
                   L_AC_STAT_NO_DR,
                   L_AC_STAT_NO_CR,
                   L_AC_STAT_DORMANT
              FROM STTMS_CUST_ACCOUNT
             WHERE BRANCH_CODE = L_TB_PAYOUT_DET(L_IDX).OFFSET_BRN
               AND CUST_AC_NO = L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_ERR_CODE  := 'ST-ACC-115';
              P_ERR_PARAM := L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC;
              RETURN FALSE;
            
          END;
        
          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(L_TB_PAYOUT_DET(L_IDX)
                                                      .OFFSET_BRN,
                                                      L_TB_PAYOUT_DET(L_IDX)
                                                      .OFFSET_ACC,
                                                      'Y',
                                                      G_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          L_AC_STAT_DORMANT := NVL(G_BALREC.AC_STAT_DORMANT, 'N');
        
          DBG('l_ac_stat_frozen~l_ac_stat_no_dr~l_ac_stat_dormant-->' ||
              L_AC_STAT_FROZEN || '~' || L_AC_STAT_NO_DR || '~' ||
              L_AC_STAT_DORMANT);
          IF L_AC_STAT_FROZEN = 'Y' THEN
            P_ERR_CODE  := 'AC-VAC04';
            P_ERR_PARAM := L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          
          END IF;
          IF L_AC_STAT_NO_DR = 'Y' THEN
            P_ERR_CODE  := 'AC-VAC07';
            P_ERR_PARAM := L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;
          IF L_AC_STAT_NO_CR = 'Y' THEN
            P_ERR_CODE  := 'AC-VAC03';
            P_ERR_PARAM := L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;
        
          IF L_AC_STAT_DORMANT = 'Y' THEN
            DBG('Dormant account');
            P_ERR_CODE  := 'AC-VAC05';
            P_ERR_PARAM := L_TB_PAYOUT_DET(L_IDX).OFFSET_ACC;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          
          END IF;
        
        END IF;
        L_IDX := L_TB_PAYOUT_DET.NEXT(L_IDX);
      END LOOP;
    END IF;
    DBG('Returning true from fn_validate_renewal');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception ' || SQLERRM);
      RETURN FALSE;
  END FN_VALIDATE_RENEWAL;

  FUNCTION FN_PROCESS_DENOM_CERT(P_SOURCE      IN VARCHAR2,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_ICDREDMN    IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                 P_TY_ICDREDMN IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARM    IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT          NUMBER := 0;
    L_NEW_STATUS     VARCHAR2(1) := 'N';
    L_DENOM_DEP_CERT STPKS_STCDENDP_MAIN.TY_STCDENDP;
  
  BEGIN
    DBG('Start of Fn_Process_Denom_Cert');
  
    IF P_ACTION_CODE IN ('TDRedemption') AND P_SOURCE IN ('FLEXBRANCH') THEN
      DBG('Inserting Into STTMS_DENOM_REDMN_BLK..');
      BEGIN
        L_COUNT := P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK.COUNT;
        DBG('p_Icdredmn.Redem_Ref_No = ' || P_ICDREDMN.REDEM_REF_NO ||
            ', l_Count = ' || L_COUNT);
        IF L_COUNT > 0 THEN
          FOR I IN 1 .. L_COUNT LOOP
            P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I).REFERENCE_NO := P_ICDREDMN.REDEM_REF_NO;
          END LOOP;
          FORALL L_INDEX IN 1 .. L_COUNT
            INSERT INTO STTM_DENOM_REDMN_BLK
            VALUES P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK
              (L_INDEX);
        
          FOR I IN 1 .. L_COUNT LOOP
            SELECT DECODE(P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                          .BLOCK_OR_REDEM,
                          'R',
                          'R',
                          'N',
                          'I')
              INTO L_NEW_STATUS
              FROM DUAL;
            DBG('l_New_Status = ' || L_NEW_STATUS);
            IF L_NEW_STATUS = 'R' THEN
              UPDATE STTM_DENOM_DEP_CERTIF
                 SET NEW_STATUS         = L_NEW_STATUS,
                     STATUS_CHANGE_DATE = GLOBAL.APPLICATION_DATE
                     
                    ,
                     PREVIOUS_STATUS      = 'I',
                     STATUS_CHANGE_REASON = 'Deposit Redeemed'
              
               WHERE CUST_AC_NO = P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .CUST_AC_NO
                 AND BRANCH_CODE = P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .BRANCH_CODE
                 AND CERTIFICATE_NO = P_TY_ICDREDMN.V_STTMS_DENOM_REDMN_BLK(I)
                    .CERTIFICATE_NO;
              DBG('SQL%UPDATE Count ' || SQL%ROWCOUNT);
            END IF;
          END LOOP;
        
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert into STTMS_DENOM_REDMN_BLK..');
          DBG(SQLERRM);
          P_ERR_CODE := 'ST-UPLD-001';
          P_ERR_PARM := '@STTM_DENOM_REDMN_BLK';
          RETURN FALSE;
      END;
    END IF;
  
    DBG('End of Fn_Process_Denom_Cert');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn_Process_Denom_Cert');
      DBG('Line No = ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||
          ', SQLERRM = ' || SQLERRM);
      RETURN FALSE;
  END FN_PROCESS_DENOM_CERT;

  FUNCTION FN_VALIDATE_REDEMPTION(P_ACTION_CODE   IN VARCHAR2,
                                  P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                  P_TY_ICDREDMN   IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                  P_TY_PAYOUTDETS IN OUT TY_TB_PAYOUTDETS)
  
   RETURN BOOLEAN IS
    L_CNT        NUMBER;
    L_STAT_BLOCK VARCHAR2(1);
    L_COUNT      NUMBER;
    AL_PRMAT_REQ VARCHAR2(1);
    TD_COUNT     NUMBER;
    L_SD_REF_NO  VARCHAR2(16);
  
    L_STAT_BLOCK VARCHAR2(1);
  
    L_ACY_ACCRUED_CR_IC    STTMS_CUST_ACCOUNT.ACY_ACCRUED_CR_IC%TYPE;
    L_LIAB_ID              STTMS_CUSTOMER.LIABILITY_NO%TYPE;
    L_PRM_ACCOUNT_CLASS    STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_PRM_RECORD_STAT      STTMS_CUST_ACCOUNT.RECORD_STAT%TYPE;
    L_PRM_GRACE_DAYS       STTMS_ACCOUNT_CLASS.GRACE_PERIOD%TYPE;
    L_PARTIAL_LIQD         STTMS_ACCOUNT_CLASS.PARTIAL_LIQUIDATION%TYPE;
    L_PARTIAL_LIQD_AMT_BLK STTMS_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK%TYPE;
    L_ACCOUNT              STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PRM_MATURITY_DATE    DATE;
  
    L_PRM_AVL_AMT      NUMBER;
    L_PRM_OFS_AMT      NUMBER;
    P_ERROR_CODES      VARCHAR2(2000);
    P_ERROR_PARAMS     VARCHAR2(2000);
    P_ERR_CODE         VARCHAR2(2000);
    P_ERR_PARAMS       VARCHAR2(2000);
    L_MATURITY_DATE    DATE;
    L_TEMP             NUMBER;
    X                  VARCHAR2(200);
    L_FLD              VARCHAR2(200);
    L_PRM_PRODUCT_CODE ISTMS_INSTR_PROD.PROD%TYPE;
    L_RATE_CODE        CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE        CSTMS_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    RET                BOOLEAN;
    L_LOV_CNT          NUMBER;
    L_FINAL_ERROR_TYPE CHAR(1);
    L_COUNT7           NUMBER;
    SUCCESS_EXCEPTION EXCEPTION;
    L_WHAT_TO_DO  CHAR(1);
    L_AUTH_STATUS CHAR(1);
    L_PRODUCT     VARCHAR2(4);
    L_TRNREF      DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
    L_BRN_AVAIL   VARCHAR2(1);
  
    L_CUST_NO     STTMS_CUST_ACCOUNT.CUST_NO%TYPE := NULL;
    L_BRN         STTMS_CUSTOMER.LOCAL_BRANCH%TYPE := NULL;
    L_RECORD_STAT LMTMS_POOL.RECORD_STAT%TYPE;
  
    L_CUST_FROZEN              STTM_CUSTOMER.FROZEN%TYPE;
    L_CUST_WHEREABOUTS_UNKNOWN STTM_CUSTOMER.WHEREABOUTS_UNKNOWN%TYPE;
    L_CUST_DECEASED            STTM_CUSTOMER.DECEASED%TYPE;
  
    L_AC_CLASS_TYPE      STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_RDFLAG             STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_ACCLASS            VARCHAR2(10);
    L_CNT_DCD            NUMBER;
    L_CASCADE_MONTH      ICTM_ACC.CASCADE_MONTH%TYPE;
    L_NEXT_MATURITY_DATE DATE;
    L_AC_OPEN_DATE       STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
  
    L_WITHDRAW_UNIT    LDTM_CLUSTER_DETAILS.WITHDRAW_UNIT%TYPE;
    L_MIN_BOOK_AMT     LDTM_CLUSTER_DETAILS.MIN_BOOK_AMT%TYPE;
    L_PAYMENT_METHOD   ICTMS_PR_INT.PAYMENT_METHOD%TYPE;
    L_TD_AMOUNT        ICTM_TD.TD_AMOUNT%TYPE;
    L_MIN_AMOUNT       STTMS_ACCOUNT_CLASS.MIN_AMOUNT%TYPE;
    L_CNT_DISCNTD_BLKS NUMBER;
    L_REDEM_STATUS     NUMBER;
    L_IS_HOLIDAY       VARCHAR2(1);
  
    L_TB_CLUSTER_DATA       GLOBAL. TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL. TY_TB_CLUSTER_DATA;
  
    L_AC_STAT_FROZEN  STTMS_CUST_ACCOUNT.AC_STAT_FROZEN%TYPE;
    L_AC_STAT_NO_DR   STTMS_CUST_ACCOUNT.AC_STAT_NO_DR%TYPE;
    L_AC_STAT_NO_CR   STTMS_CUST_ACCOUNT.AC_STAT_NO_CR%TYPE;
    L_AC_STAT_DORMANT STTMS_CUST_ACCOUNT.AC_STAT_DORMANT%TYPE;
  
    L_BLK_CNT NUMBER := 0;
    CURSOR CR_LINKED_REC(P_LIAB_ID LMTMS_POOL_COLLATERAL_LINKAGES.LIAB_ID%TYPE,
                         P_BRN     LMTMS_POOL_COLLATERAL_LINKAGES.BRANCH_CODE%TYPE,
                         P_AC_NO   LMTMS_POOL_COLLATERAL_LINKAGES.COLLATERAL_CODE%TYPE) IS
      SELECT *
        FROM LMTMS_POOL_COLLATERAL_LINKAGES
       WHERE LIAB_ID = P_LIAB_ID
         AND BRANCH_CODE = P_BRN
         AND COLLATERAL_CODE = P_AC_NO;
  
    L_BRANCH        STTMS_BRANCH%ROWTYPE;
    L_PR_INT        ICTMS_PR_INT%ROWTYPE;
    L_ACCOUNT_CLASS STTMS_ACCOUNT_CLASS%ROWTYPE;
  
  BEGIN
    DBG('Inside fn_validate_redemption');
  
    BEGIN
      SELECT NVL(AC_STAT_FROZEN, 'N'),
             NVL(AC_STAT_NO_DR, 'N'),
             NVL(AC_STAT_NO_CR, 'N')
             
            ,
             CUST_NO
        INTO L_AC_STAT_FROZEN,
             L_AC_STAT_NO_DR,
             L_AC_STAT_NO_CR
             
            ,
             L_CUST_NO
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
         AND CUST_AC_NO = P_ICDREDMN.AC_NO
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in obtaining the data' || SQLERRM);
    END;
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                'Y',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
    L_AC_STAT_DORMANT := NVL(G_BALREC.AC_STAT_DORMANT, 'N');
  
    DBG('l_ac_stat_frozen~l_ac_stat_no_dr~l_ac_stat_no_cr~l_ac_stat_dormant-->' ||
        L_AC_STAT_FROZEN || '~' || L_AC_STAT_NO_DR || '~' ||
        L_AC_STAT_NO_CR || '~' || L_AC_STAT_DORMANT);
    IF L_AC_STAT_FROZEN = 'Y' THEN
      DBG('Account is frozen');
      OVPKSS.PR_APPENDTBL('AC-VAC04', P_ICDREDMN.AC_NO);
    END IF;
  
    IF L_AC_STAT_NO_DR = 'Y' THEN
      DBG('Account is marked as no debit');
      OVPKSS.PR_APPENDTBL('AC-VAC07', P_ICDREDMN.AC_NO);
    END IF;
  
    IF L_AC_STAT_NO_CR = 'Y' THEN
      DBG('Account is marked as no credit');
      OVPKSS.PR_APPENDTBL('AC-VAC03', P_ICDREDMN.AC_NO);
    END IF;
  
    IF L_AC_STAT_DORMANT = 'Y' THEN
      DBG('Dormant account');
      OVPKSS.PR_APPENDTBL('AC-VAC05', P_ICDREDMN.AC_NO);
    END IF;
  
    BEGIN
      SELECT NVL(FROZEN, 'N'),
             NVL(WHEREABOUTS_UNKNOWN, 'N'),
             NVL(DECEASED, 'N')
        INTO L_CUST_FROZEN, L_CUST_WHEREABOUTS_UNKNOWN, L_CUST_DECEASED
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = L_CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get customer liability number and local branch ' ||
            SQLERRM);
    END;
    IF L_CUST_FROZEN = 'Y' THEN
      DBG('Frozeb');
      OVPKSS.PR_APPENDTBL('AC-VAC15', L_CUST_NO);
    END IF;
    IF L_CUST_WHEREABOUTS_UNKNOWN = 'Y' THEN
      DBG('Whereabouts_Unknown');
      OVPKSS.PR_APPENDTBL('AC-VAC17', L_CUST_NO);
    END IF;
    IF L_CUST_DECEASED = 'Y' THEN
      DBG('Deceased');
      OVPKSS.PR_APPENDTBL('AC-VAC18', L_CUST_NO);
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_VALIDATE_REDEMPTION(P_ACTION_CODE,
                                                            P_ICDREDMN,
                                                            P_TY_PAYOUTDETS,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA) THEN
        DBG('Failed in icpks_fcj_icdredmn_cluster.fn_validate_redemption');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      L_FLD := 'XREF';
      IF (P_ICDREDMN.XREF IS NOT NULL) THEN
        DBG('In check 1 for xref input');
        DBG('In external reference number validation' || P_ICDREDMN.XREF);
        SELECT COUNT(*)
          INTO L_COUNT7
          FROM DETBS_RTL_TELLER
         WHERE XREF = P_ICDREDMN.XREF;
        IF NVL(L_COUNT7, 0) > 0 THEN
          DBG('Duplicate  Xref number  Exists');
          OVPKSS.PR_APPENDTBL('TD-RED-14', L_FLD);
        
          RETURN FALSE;
        END IF;
      
        IF NVL(L_COUNT7, 0) < 0 THEN
          DBG('Record doesn Exists for this XREF number ');
          RETURN FALSE;
        END IF;
      END IF;
    
      IF P_ICDREDMN.REDEMPTION_MODE = 'Y' AND P_ICDREDMN.ACTION_FLAG = 'R' THEN
        SELECT COUNT(1)
          INTO L_CNT_DCD
          FROM ICTMS_DCD_MASTER
         WHERE TD_ACC = P_ICDREDMN.AC_NO
           AND TD_BRN = P_ICDREDMN.BRN_CODE;
      
        IF L_CNT_DCD > 1 THEN
          DBG('Partial redemption not allowed for DCD account ');
          OVPKSS.PR_APPENDTBL('TD-DCD-20', '');
          RETURN FALSE;
        END IF;
      
      END IF;
    
      DBG('Redemption amount --> ' || P_ICDREDMN.REDEMPTION_AMT);
      DBG('Account amount    --> ' || P_ICDREDMN.ACC_AMT);
    
      FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
        DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS(I).INSTNO);
      END LOOP;
    
      IF P_ICDREDMN.REDEMPTION_MODE = 'Y' AND P_ICDREDMN.ACTION_FLAG = 'R' THEN
      
        IF P_ICDREDMN.ACC_AMT IS NULL THEN
          DBG('>> fetching td acc amt...if null...');
        
          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                      P_ICDREDMN.AC_NO,
                                                      'Y',
                                                      G_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
        
          P_ICDREDMN.ACC_AMT := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
        
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 3;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              ICPKS_FCJ_ICDREDMN_CLUSTER.FN_VALIDATE_REDEMPTION(P_ACTION_CODE,
                                                                P_ICDREDMN,
                                                                P_TY_PAYOUTDETS,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
            DBG('Failed in icpks_fcj_icdredmn_cluster.fn_validate_redemption');
            RETURN FALSE;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF NVL(P_ICDREDMN.REDEMPTION_AMT, 0) =
             NVL(P_ICDREDMN.ACC_AMT, 0) + NVL(G_BALREC.ACY_BLOCKED_AMT, 0) THEN
            DBG('Redemption amount should be less than account amount');
            OVPKSS.PR_APPENDTBL('IC-REDMN-13', '');
            RETURN FALSE;
          END IF;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
      END IF;
    
      IF NVL(GWPKS_UTIL.PKG_FUNC, '****') IN ('1317') THEN
        IF NOT FN_VALIDATE_DENOM_DEP(P_ACTION_CODE,
                                     P_ICDREDMN,
                                     P_TY_PAYOUTDETS,
                                     P_TY_ICDREDMN,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Validate_Denom_Dep');
          RETURN FALSE;
        END IF;
      END IF;
    
      L_LOV_CNT := 0;
    
      DBG('Going to LOV Validate Branch Code');
      IF P_ICDREDMN.BRN_CODE IS NOT NULL THEN
      
        L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_ICDREDMN.BRN_CODE);
      
        IF L_BRANCH.BRANCH_CODE IS NULL THEN
          DBG('Invalid value For Branch code');
          L_FLD := P_ICDREDMN.BRN_CODE;
          OVPKSS.PR_APPENDTBL('ST-VALS-012', L_FLD || '~' || 'BRANCH CODE');
        END IF;
      END IF;
    
      DBG('Going to LOV Validate Term Deposit Account Number');
      IF P_ICDREDMN.AC_NO IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_LOV_CNT
          FROM STTM_CUST_ACCOUNT A, ICTM_ACC_PR B
         WHERE A.ACCOUNT_CLASS IN
               (SELECT DISTINCT ACCOUNT_CLASS
                  FROM STTM_ACCOUNT_CLASS
                 WHERE AC_CLASS_TYPE = 'Y'
                   AND ONCE_AUTH = 'Y'
                   AND RECORD_STAT <> 'C')
              
           AND A.CUST_NO IN (SELECT C.CUSTOMER_NO
                               FROM STTM_CUSTOMER C
                              WHERE ((C.GROUP_CODE IS NOT NULL AND EXISTS
                                     (SELECT 1
                                         FROM STVWS_USER_GROUP G
                                        WHERE G.USER_ID = GLOBAL.USER_ID
                                          AND G.GROUP_CODE = C.GROUP_CODE)) OR
                                    C.GROUP_CODE IS NULL)
                                   
                                AND ((C.ACCESS_GROUP IS NOT NULL AND EXISTS
                                     (SELECT 1
                                         FROM STVWS_USER_ACCESS G
                                        WHERE G.USER_ID = GLOBAL.USER_ID
                                          AND G.ACCESS_GROUP = C.ACCESS_GROUP)) OR
                                    C.ACCESS_GROUP IS NULL))
              
           AND A.ONCE_AUTH = 'Y'
           AND A.RECORD_STAT = 'O'
           AND A.BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND A.BRANCH_CODE = B.BRN
           AND A.CUST_AC_NO = B.ACC
           AND B.WAIVE = 'N'
           AND B.PROD IN (SELECT D.PRODUCT_CODE
                            FROM ICTMS_PRODUCT_DEFINITION D, ICTMS_PR_INT E
                           WHERE NVL(D.TAX, 'N') = 'N'
                             AND D.PRODUCT_CODE = E.PRODUCT_CODE
                                
                             AND E.PAYMENT_METHOD IN ('B', 'D'))
           AND A.CUST_AC_NO = P_ICDREDMN.AC_NO;
        DBG('l_lov_cnt :: ' || L_LOV_CNT);
      
        IF L_LOV_CNT < 1 THEN
          DBG('Invalid value For Term Deposit Account Number');
          L_FLD := P_ICDREDMN.AC_NO;
          OVPKSS.PR_APPENDTBL('ST-VALS-012',
                              L_FLD || '~' || 'Term Deposit Account Number');
        END IF;
      END IF;
    
      DBG('LOV Validations completed');
    
      SELECT COUNT(*)
        INTO TD_COUNT
        FROM SFTMS_CUST_SUBSCRIPTION
       WHERE TD_AC_NO = P_ICDREDMN.AC_NO
         AND TD_BRN = P_ICDREDMN.BRN_CODE;
    
      IF TD_COUNT > 0 THEN
      
        SELECT DISTINCT SD_REF_NO
          INTO L_SD_REF_NO
          FROM SFTM_CUST_SUBSCRIPTION
         WHERE TD_AC_NO = P_ICDREDMN.AC_NO
           AND TD_BRN = P_ICDREDMN.BRN_CODE;
      
        SELECT ALLOW_PREMATURE_RED
          INTO AL_PRMAT_REQ
          FROM SFTBS_CONTRACT_MASTER
         WHERE CONTRACT_REF_NO = L_SD_REF_NO
           AND EVENT_SEQ_NO =
               (SELECT MAX(EVENT_SEQ_NO)
                  FROM SFTBS_CONTRACT_MASTER
                 WHERE CONTRACT_REF_NO = L_SD_REF_NO);
      
        IF AL_PRMAT_REQ = 'N' AND P_ICDREDMN.REDEMPTION_MODE IN ('Y', 'N') THEN
          DBG('Partial\Full Redemption are not allowed for this term Deposit');
          OVPKSS.PR_APPENDTBL('SF-CUSB25',
                              'Partial\Full Redemption are not allowed for this term Deposit.');
        END IF;
      END IF;
      DBG('PRE-MATURE Redemption validation Ends....');
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_VALIDATE_REDEMPTION(P_ACTION_CODE,
                                                              P_ICDREDMN,
                                                              P_TY_PAYOUTDETS,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
          DBG('Failed in icpks_fcj_icdredmn_cluster.fn_validate_redemption');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        DBG('GOING TO VALIDATE AUTO DEPOSIT ACCOUNT NUMBER');
        BEGIN
        
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
             AND CUST_AC_NO = P_ICDREDMN.AC_NO
             AND MASTER_ACCOUNT_NO IS NOT NULL;
        
          IF P_ICDREDMN.ACTION_FLAG = 'R' AND L_COUNT > 0 THEN
            DBG('Auto Deposit Account not allowed for Redemption');
            OVPKSS.PR_APPENDTBL('SF-CUAD01', NULL);
          
            RETURN FALSE;
          END IF;
        
        END;
      
      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
      DBG('VALIDATED AUTO DEPOSTI ACCOUNT NUMBER');
      DBG('GOING TO SELECT VALUE INTO PARAMETERS');
      BEGIN
        SELECT ACY_AVL_BAL, ACCOUNT_CLASS, RECORD_STAT, ACY_ACCRUED_CR_IC
          INTO L_PRM_AVL_AMT,
               L_PRM_ACCOUNT_CLASS,
               L_PRM_RECORD_STAT,
               L_ACY_ACCRUED_CR_IC
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In Exception when SELECTing VALUEs INTO PARAMETERS');
      END;
    
      IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                  P_ICDREDMN.AC_NO,
                                                  'Y',
                                                  G_BALREC) THEN
        DEBUG.PR_DEBUG('AC',
                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                       SQLERRM);
      END IF;
      L_PRM_AVL_AMT := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
    
      BEGIN
        SELECT PROD
          INTO L_PRODUCT
          FROM ICTMS_ACC_PR
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of product select--> ' || SQLERRM);
          RETURN FALSE;
        
      END;
    
      DBG('Product is--> ' || L_PRODUCT);
    
      L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PRODUCT);
    
      DBG('Account Amount is-->' || P_ICDREDMN.ACC_AMT);
      DBG('Redemption Amount is-->' || P_ICDREDMN.REDEMPTION_AMT);
    
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' AND
         L_PR_INT.PAYMENT_METHOD <> 'D' THEN
        DBG('Assinging the Account Balance to Redemption Amount');
        P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.ACC_AMT;
      
      ELSIF P_ICDREDMN.REDEMPTION_MODE = 'N' AND
            L_PR_INT.PAYMENT_METHOD = 'D' THEN
        DBG('Assigning the Redemption Amount for discounted deposits');
      
        SELECT TD_AMOUNT - NVL(REDEM_AMT, 0)
          INTO L_TD_AMOUNT
          FROM ICTM_TD_DETAILS
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO;
        DBG('TD Amount is-->' || L_TD_AMOUNT);
        P_ICDREDMN.REDEMPTION_AMT := L_TD_AMOUNT;
      
      END IF;
    
      IF P_ICDREDMN.CCY IS NULL THEN
      
        BEGIN
          SELECT CCY
            INTO P_ICDREDMN.CCY
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
             AND CUST_AC_NO = P_ICDREDMN.AC_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ICDREDMN.CCY := '';
        END;
      END IF;
    
      IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
        DBG('Checking if the redemption amount is less than 0');
        IF P_ICDREDMN.REDEMPTION_AMT < 0 THEN
          L_FLD := 'Redemption Amount';
          DBG('Redemption amount cannot be less than 0');
        
          DBG('26655389##l_fld--> ' || L_FLD);
        
          CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                       '1317',
                                       'SV-MA35',
                                       L_FLD);
        
          RETURN FALSE;
        END IF;
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CATMS_AMOUNT_BLOCKS
         WHERE ACCOUNT = P_ICDREDMN.AC_NO
           AND BRANCH = P_ICDREDMN.BRN_CODE
           AND NVL(EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
               GLOBAL.APPLICATION_DATE
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
        IF L_COUNT > 0 AND (P_ICDREDMN.REDEMPTION_MODE = 'N'
           
           OR (P_ICDREDMN.REDEMPTION_MODE = 'Y' AND
           P_ICDREDMN.REDEMPTION_AMT >
           NVL(L_PRM_AVL_AMT, P_ICDREDMN.ACC_AMT)))
          
           AND NVL(L_PR_INT.PAYMENT_METHOD, 'B') <> 'D' THEN
          DBG('nOT SUPPORTED FOR FULL REDEMPTION000');
          OVPKSS.PR_APPENDTBL('FT-UPCE0115', NULL);
        END IF;
      
        DBG('Checking if the redemption amount is greater than the account balance');
      
        IF L_PAYMENT_METHOD = 'D' THEN
          SELECT COUNT(1)
            INTO L_BLK_CNT
            FROM CATMS_AMOUNT_BLOCKS
           WHERE ACCOUNT = P_ICDREDMN.AC_NO
             AND BRANCH = P_ICDREDMN.BRN_CODE
             AND NVL(EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
                 GLOBAL.APPLICATION_DATE
             AND AMOUNT_BLOCK_TYPE <> 'D'
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A';
        END IF;
        DBG('l_blk_cnt' || L_BLK_CNT);
        IF P_ICDREDMN.REDEMPTION_AMT >
           NVL(L_PRM_AVL_AMT, P_ICDREDMN.ACC_AMT) AND
           (L_PAYMENT_METHOD <> 'D' OR
           (L_PAYMENT_METHOD = 'D' AND
           (P_ICDREDMN.REDEMPTION_MODE = 'Y' OR
           (P_ICDREDMN.REDEMPTION_MODE = 'N' AND L_BLK_CNT > 0)))) THEN
        
          OVPKSS.PR_APPENDTBL('TD-REDM12', NULL);
          DBG('Redemption amount cannot be greater than available balance');
        
        END IF;
      END IF;
    
      IF P_ICDREDMN.REDEMPTION_MODE = 'Y' AND P_ICDREDMN.ACTION_FLAG = 'R' THEN
        BEGIN
          SELECT NVL(WITHDRAW_UNIT, 0), NVL(MIN_BOOK_AMT, 0)
            INTO L_WITHDRAW_UNIT, L_MIN_BOOK_AMT
            FROM LDTM_CLUSTER_DETAILS
           WHERE CLUSTER_ID IN
                 (SELECT CLUSTER_ID
                    FROM STTM_ACCOUNT_CLASS
                   WHERE ACCOUNT_CLASS IN
                         (SELECT ACCOUNT_CLASS
                            FROM STTM_CUST_ACCOUNT
                           WHERE CUST_AC_NO = P_ICDREDMN.AC_NO))
             AND CURRENCY = P_ICDREDMN.CCY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for withdrawal unit fetch');
            L_WITHDRAW_UNIT := 0;
          WHEN OTHERS THEN
            DBG('Other err while wothdrawal unit fetch' || SQLERRM);
            L_WITHDRAW_UNIT := 0;
        END;
      
        IF NVL(L_WITHDRAW_UNIT, -1) > 0 THEN
          IF MOD(P_ICDREDMN.REDEMPTION_AMT, L_WITHDRAW_UNIT) <> 0 THEN
            OVPKSS.PR_APPENDTBL('TD-REDM-31', NULL);
          END IF;
        
          IF L_MIN_BOOK_AMT IS NOT NULL AND L_MIN_BOOK_AMT > 0 THEN
            IF (P_ICDREDMN.ACC_AMT - P_ICDREDMN.REDEMPTION_AMT) <
               L_MIN_BOOK_AMT THEN
              DBG('l_min_book_amt' || L_MIN_BOOK_AMT);
              OVPKSS.PR_APPENDTBL('ST-VAL-334', NULL);
            END IF;
          END IF;
        END IF;
      
        BEGIN
          SELECT NVL(MIN_AMOUNT, 0)
            INTO L_MIN_AMOUNT
            FROM STTMS_ACCLS_MINMAX_AMT_CCY
           WHERE ACCOUNT_CLASS IN
                 (SELECT ACCOUNT_CLASS
                    FROM STTM_CUST_ACCOUNT
                   WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
                     AND BRANCH_CODE = P_ICDREDMN.BRN_CODE)
             AND CCY = P_ICDREDMN.CCY;
          DBG('Selecting minimum amount : ' || L_MIN_AMOUNT);
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT NVL(MIN_AMOUNT, 0)
                INTO L_MIN_AMOUNT
                FROM STTMS_ACCLS_MINMAX_AMT_CCY
               WHERE ACCOUNT_CLASS IN
                     (SELECT ACCOUNT_CLASS
                        FROM STTM_CUST_ACCOUNT
                       WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
                         AND BRANCH_CODE = P_ICDREDMN.BRN_CODE)
                 AND CCY = '*.*';
              DBG('Selecting minimum amount for ccy *.* : ' ||
                  L_MIN_AMOUNT);
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_MIN_AMOUNT := 0;
              
                DBG('Assigning Mininum  Amount has zero when it is not maintained');
            END;
          WHEN OTHERS THEN
            DBG('Min Amount not maintained for any currency');
        END;
      
        IF (P_ICDREDMN.ACC_AMT - P_ICDREDMN.REDEMPTION_AMT) < L_MIN_AMOUNT THEN
          DBG('l_min_amount' || L_MIN_AMOUNT);
          OVPKSS.PR_APPENDTBL('ST-VAL-334', NULL);
        END IF;
      
      END IF;
    
      DBG('VALIDATED TERM DEPOSTI ACCOUNT NUMBER');
    
      DBG('GOING TO VALIDATE ACTION FLAG');
      BEGIN
        IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
          DBG('IF REDEMPTION');
        
          DBG(' p_icdredmn.acc_amt::' || P_ICDREDMN.ACC_AMT);
        
          IF P_ICDREDMN.ACC_AMT < 0 AND L_COUNT = 0 THEN
            DBG('There is no balance in account for redemption');
            L_FLD := NULL;
            OVPKSS.PR_APPENDTBL('TD-REDM11', L_FLD);
            P_ICDREDMN.ACTION_FLAG   := NULL;
            P_ICDREDMN.TENOR_DD      := '';
            P_ICDREDMN.TENOR_MM      := '';
            P_ICDREDMN.TENOR_YY      := '';
            P_ICDREDMN.NEXT_MAT_DATE := '';
          
            RETURN FALSE;
          END IF;
        END IF;
      
        DBG('IN 254123625');
      
        DBG('Check Waive Interest');
        DBG('p_icdredmn.action_flag' || P_ICDREDMN.ACTION_FLAG);
        DBG('p_icdredmn.redemption_mode' || P_ICDREDMN.REDEMPTION_MODE);
        DBG('p_icdredmn.wave_penalty' || P_ICDREDMN.WAVE_PENALTY);
      
        IF P_ICDREDMN.ACTION_FLAG = 'R' AND P_ICDREDMN.WAVE_PENALTY = 'Y' THEN
          OVPKSS.PR_APPENDTBL('TD-RED-33', NULL);
          DBG('Waive Penalty is checked');
        END IF;
      
        IF P_ICDREDMN.ACTION_FLAG = 'R' AND
           P_ICDREDMN.REDEMPTION_MODE = 'Y' AND
           (P_ICDREDMN.WAIVE_INTEREST = 'Y') THEN
        
          DBG('Waive Interest can be checked only for Full Redemption');
        
          L_FLD := NULL;
          OVPKSS.PR_APPENDTBL('TD-RED-24', L_FLD);
          RETURN FALSE;
        END IF;
      
        DBG('p_icdredmn.action_flag::' || P_ICDREDMN.ACTION_FLAG);
        IF P_ICDREDMN.ACTION_FLAG = 'E' THEN
          DBG('IF RENEWAL');
          SELECT MATURITY_DATE, CASCADE_MONTH
            INTO L_MATURITY_DATE, L_CASCADE_MONTH
            FROM ICTMS_ACC
           WHERE ACC = P_ICDREDMN.AC_NO
             AND BRN = P_ICDREDMN.BRN_CODE;
        
          DBG('CHECKING FOR MATURED ACC');
          IF (GLOBAL.APPLICATION_DATE < L_MATURITY_DATE) THEN
            DBG('Only matured accounts can be renewed');
            L_FLD := NULL;
            OVPKSS.PR_APPENDTBL('TD-REDM21', L_FLD);
            P_ICDREDMN.ACTION_FLAG := NULL;
          
            RETURN FALSE;
          END IF;
        
          DBG('SELECTING TENOR VALUES VALUES');
        
          IF (P_ICDREDMN.TENOR_DD IS NULL AND P_ICDREDMN.TENOR_MM IS NULL AND
             P_ICDREDMN.TENOR_YY IS NULL) THEN
          
            L_ACCOUNT_CLASS := CSPKS_FUNCTION_CACHE.FN_GET_ACC_CLASS_REC_FRC(L_PRM_ACCOUNT_CLASS);
          
            P_ICDREDMN.TENOR_DD := L_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS;
            P_ICDREDMN.TENOR_MM := L_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS;
            P_ICDREDMN.TENOR_YY := L_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS;
            L_PRM_GRACE_DAYS    := L_ACCOUNT_CLASS.GRACE_PERIOD;
          
          ELSE
          
            L_ACCOUNT_CLASS := CSPKS_FUNCTION_CACHE.FN_GET_ACC_CLASS_REC_FRC(L_PRM_ACCOUNT_CLASS);
          
            L_PRM_GRACE_DAYS := L_ACCOUNT_CLASS.GRACE_PERIOD;
          END IF;
        
          L_PRM_MATURITY_DATE := L_MATURITY_DATE;
          L_TEMP              := NVL(P_ICDREDMN.TENOR_MM, 0) +
                                 (NVL(P_ICDREDMN.TENOR_YY, 0) * 12);
        
          IF NOT CEPKS_DATE.FN_ISHOLIDAY('LCL',
                                         GLOBAL.CURRENT_BRANCH,
                                         L_PRM_MATURITY_DATE +
                                         NVL(L_PRM_GRACE_DAYS, 0),
                                         L_IS_HOLIDAY) THEN
            DBG('Failed to get holiday for the given date');
          END IF;
          IF L_IS_HOLIDAY = 'W' THEN
          
            IF (GLOBAL.APPLICATION_DATE >
               (L_PRM_MATURITY_DATE + NVL(L_PRM_GRACE_DAYS, 0))) THEN
              DBG('Grace period for the account has expired');
              L_FLD := NULL;
              OVPKSS.PR_APPENDTBL('TD-REDM10', L_FLD);
              P_ICDREDMN.ACTION_FLAG := NULL;
              P_ICDREDMN.TENOR_DD    := '';
              P_ICDREDMN.TENOR_MM    := '';
              P_ICDREDMN.TENOR_YY    := '';
            
              RETURN FALSE;
            END IF;
          END IF;
          P_ICDREDMN.NEXT_MAT_DATE := ADD_MONTHS(L_MATURITY_DATE, L_TEMP) +
                                      NVL(P_ICDREDMN.TENOR_DD, 0);
        
          DBG('p_icdredmn.next_mat_date--->' || P_ICDREDMN.NEXT_MAT_DATE || '~' ||
              L_CASCADE_MONTH);
          IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_ICDREDMN.TENOR_DD, 0) = 0 THEN
          
            L_NEXT_MATURITY_DATE := P_ICDREDMN.NEXT_MAT_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_MATURITY_DATE,
                                                        P_ICDREDMN.NEXT_MAT_DATE) THEN
              P_ICDREDMN.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE;
            END IF;
          END IF;
          DBG('p_icdredmn.next_mat_date1--->' || P_ICDREDMN.NEXT_MAT_DATE);
        
          IF NOT FN_VALIDATE_RENEWAL(P_ICDREDMN.BRN_CODE,
                                     P_ICDREDMN.AC_NO,
                                     P_ERR_CODE,
                                     P_ERR_PARAMS) THEN
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        
        END IF;
        DBG('GOING TO CALL PR_REN_RED');
        PR_REN_RED(P_ICDREDMN);
        DBG('PR_REN_RED done');
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DEBUG.PR_DEBUG('**',
                         'In when others of validation of action flag in icpks_fcj_icdredmn_addon.fn_post_default_and_validate ..');
          DEBUG.PR_DEBUG('**', SQLERRM);
          OVPKSS.PR_APPENDTBL('ST-OTHR-001', '');
          RETURN FALSE;
      END;
      DBG('ACTION FLAG VALIDATED');
    
      DBG('gOING TO VALIDATE TENOR DATE');
    
      IF P_ICDREDMN.TENOR_DD < 0 THEN
        DBG('TENOR DAYS cannot be less than zero');
        L_FLD := 'TENOR DAYS';
      
        DBG('l_fld--> ' || L_FLD);
      
        CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE', '1317', 'SV-MA35', L_FLD);
      
        RETURN FALSE;
      
      END IF;
    
      L_TEMP                   := NVL(P_ICDREDMN.TENOR_MM, 0) +
                                  (NVL(P_ICDREDMN.TENOR_YY, 0) * 12);
      P_ICDREDMN.NEXT_MAT_DATE := ADD_MONTHS(L_PRM_MATURITY_DATE, L_TEMP) +
                                  NVL(P_ICDREDMN.TENOR_DD, 0);
    
      DBG('p_icdredmn.next_mat_date2--->' || P_ICDREDMN.NEXT_MAT_DATE || '~' ||
          L_CASCADE_MONTH);
      IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_ICDREDMN.TENOR_DD, 0) = 0 THEN
      
        L_NEXT_MATURITY_DATE := P_ICDREDMN.NEXT_MAT_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_PRM_MATURITY_DATE,
                                                    P_ICDREDMN.NEXT_MAT_DATE) THEN
          P_ICDREDMN.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE;
        END IF;
      END IF;
      DBG('p_icdredmn.next_mat_date2--->' || P_ICDREDMN.NEXT_MAT_DATE);
    
      DBG('TENOR DATE VALIDATED');
    
      DBG('gOING TO VALIDATE TENOR MONTH');
    
      IF P_ICDREDMN.TENOR_MM < 0 THEN
        DBG('TENOR MONTH cannot be less than zero');
        L_FLD := 'TENOR MONTH';
      
        DBG('l_fld--> ' || L_FLD);
      
        CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE', '1317', 'SV-MA35', L_FLD);
      
        RETURN FALSE;
      END IF;
    
      L_TEMP                   := NVL(P_ICDREDMN.TENOR_MM, 0) +
                                  (NVL(P_ICDREDMN.TENOR_YY, 0) * 12);
      P_ICDREDMN.NEXT_MAT_DATE := ADD_MONTHS(L_PRM_MATURITY_DATE, L_TEMP) +
                                  NVL(P_ICDREDMN.TENOR_DD, 0);
    
      DBG('p_icdredmn.next_mat_date3--->' || P_ICDREDMN.NEXT_MAT_DATE || '~' ||
          L_CASCADE_MONTH);
      IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_ICDREDMN.TENOR_DD, 0) = 0 THEN
      
        L_NEXT_MATURITY_DATE := P_ICDREDMN.NEXT_MAT_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_PRM_MATURITY_DATE,
                                                    P_ICDREDMN.NEXT_MAT_DATE) THEN
          P_ICDREDMN.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE;
        END IF;
      END IF;
      DBG('p_icdredmn.next_mat_date3--->' || P_ICDREDMN.NEXT_MAT_DATE);
    
      DBG('TENOR MONTH VALIDATED');
    
      DBG('gOING TO VALIDATE TENOR YEAR');
    
      IF P_ICDREDMN.TENOR_YY < 0 THEN
        DBG('TENOR YEAR cannot be less than zero');
        L_FLD := 'TENOR YEAR';
      
        DBG('l_fld--> ' || L_FLD);
      
        CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE', '1317', 'SV-MA35', L_FLD);
      
        RETURN FALSE;
      END IF;
    
      L_TEMP                   := NVL(P_ICDREDMN.TENOR_MM, 0) +
                                  (NVL(P_ICDREDMN.TENOR_YY, 0) * 12);
      P_ICDREDMN.NEXT_MAT_DATE := ADD_MONTHS(L_PRM_MATURITY_DATE, L_TEMP) +
                                  NVL(P_ICDREDMN.TENOR_DD, 0);
    
      DBG('p_icdredmn.next_mat_date4--->' || P_ICDREDMN.NEXT_MAT_DATE || '~' ||
          L_CASCADE_MONTH);
      IF NVL(L_CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_ICDREDMN.TENOR_DD, 0) = 0 THEN
      
        L_NEXT_MATURITY_DATE := P_ICDREDMN.NEXT_MAT_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(L_PRM_MATURITY_DATE,
                                                    P_ICDREDMN.NEXT_MAT_DATE) THEN
          P_ICDREDMN.NEXT_MAT_DATE := L_NEXT_MATURITY_DATE;
        END IF;
      END IF;
      DBG('p_icdredmn.next_mat_date3--->' || P_ICDREDMN.NEXT_MAT_DATE);
    
      DBG('TENOR YEAR VALIDATED');
    
      BEGIN
        SELECT CUST_NO
          INTO L_CUST_NO
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to get customer number ' || SQLERRM);
      END;
      IF L_CUST_NO IS NOT NULL THEN
        BEGIN
          SELECT NVL(LIABILITY_NO, CUSTOMER_NO),
                 NVL(LOCAL_BRANCH, P_ICDREDMN.BRN_CODE)
            INTO L_LIAB_ID, L_BRN
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = L_CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed to get customer liability number and local branch ' ||
                SQLERRM);
        END;
        IF L_LIAB_ID IS NOT NULL AND L_BRN IS NOT NULL THEN
          IF ELPKS.LIMITS_MODULE = 'LM' THEN
          
            FOR I IN CR_LINKED_REC(L_LIAB_ID, L_BRN, P_ICDREDMN.AC_NO) LOOP
              BEGIN
                SELECT RECORD_STAT
                  INTO L_RECORD_STAT
                  FROM LMTMS_POOL
                 WHERE LIAB_ID = I.LIAB_ID
                   AND POOL_CODE = I.POOL_CODE;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed to get customer liability number and local branch ' ||
                      SQLERRM);
              END;
            
              IF NVL(L_RECORD_STAT, 'C') = 'O' THEN
                DBG('Collateral is linked to a Pool ' || I.POOL_CODE);
                IF I.LINKED_PERCENT_NUMBER IS NULL THEN
                  OVPKSS.PR_APPENDTBL('LM-COLLAT34',
                                      P_ICDREDMN.AC_NO || '~' ||
                                      I.POOL_CODE || '~' || I.LINKED_AMOUNT);
                  RETURN FALSE;
                ELSE
                  OVPKSS.PR_APPENDTBL('LM-COLLAT35',
                                      P_ICDREDMN.AC_NO || '~' ||
                                      I.POOL_CODE || '~' ||
                                      I.LINKED_PERCENT_NUMBER || '~' ||
                                      I.LINKED_AMOUNT);
                  RETURN FALSE;
                END IF;
              END IF;
            END LOOP;
          
          ELSE
            IF NOT
                ELPKS_COLLATERAL_SERVICE.FN_POLL_COLLAT_LINKAGE_CURSOR(L_LIAB_ID,
                                                                       L_BRN,
                                                                       P_ICDREDMN.AC_NO) THEN
              DBG('Failed in function elpks_collateral_service.fn_poll_collat_linkage_cursor');
            END IF;
          
          END IF;
        
        END IF;
      END IF;
    
      IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
        DBG('Mandatory check - REDEMPTION BY');
      
        DBG('Mandatory check - REDEMPTION MODE');
        IF P_ICDREDMN.REDEMPTION_MODE IS NULL THEN
          DBG('REDEMPTION MODE IS MANDATORY');
        
          L_FLD := '@CSTBS_UI_COLUMNS.CHAR_FIELD8';
        
          CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                       '1317',
                                       'ST-MAND-001',
                                       L_FLD);
        
        END IF;
        BEGIN
          DBG('p_icdredmn.ac_no' || P_ICDREDMN.AC_NO);
          SELECT A.PARTIAL_LIQUIDATION
            INTO L_PARTIAL_LIQD
            FROM STTM_ACCOUNT_CLASS A, STTM_CUST_ACCOUNT B
           WHERE B.CUST_AC_NO = P_ICDREDMN.AC_NO
             AND A.ACCOUNT_CLASS = B.ACCOUNT_CLASS;
          DBG('l_partial_liqd flag : ' || L_PARTIAL_LIQD);
          IF L_PARTIAL_LIQD = 'N' THEN
            DBG(' SOUMYADEEP ');
            IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
              OVPKSS.PR_APPENDTBL('ST-00015', NULL);
              RETURN FALSE;
            END IF;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED : In Exception While select the partial liquidation flag');
        END;
        DBG('Partial liquidation with amount block for account: ' ||
            P_ICDREDMN.AC_NO);
        BEGIN
        
          SELECT ACCOUNT_CLASS, CUST_AC_NO
            INTO L_ACCLASS, L_ACCOUNT
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
             AND BRANCH_CODE = P_ICDREDMN.BRN_CODE;
        
          L_ACCOUNT_CLASS := CSPKS_FUNCTION_CACHE.FN_GET_ACC_CLASS_REC_FRC(L_ACCLASS);
        
          SELECT COUNT(1)
            INTO L_CNT_DISCNTD_BLKS
            FROM CATMS_AMOUNT_BLOCKS
           WHERE ACCOUNT = P_ICDREDMN.AC_NO
             AND BRANCH = P_ICDREDMN.BRN_CODE
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A'
             AND AMOUNT_BLOCK_TYPE = 'D';
        
          DBG('Amount Block check for discounted depoit has count-partial liqd wd blk as -->' ||
              L_CNT_DISCNTD_BLKS ||
              L_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK);
        
          DBG('Redemption Mode is-->' || P_ICDREDMN.REDEMPTION_MODE);
        
          IF L_CNT_DISCNTD_BLKS > 0 AND L_PAYMENT_METHOD = 'D' AND
             L_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK = 'N' AND
             L_ACCOUNT = P_ICDREDMN.AC_NO AND
             P_ICDREDMN.REDEMPTION_MODE = 'Y'
          
           THEN
            DBG('Amount Blocks exist for the Discounted Deposit Account');
            OVPKSS.PR_APPENDTBL('ST-0001', NULL);
          END IF;
        
          SELECT COUNT(1)
            INTO L_CNT_DISCNTD_BLKS
            FROM CATMS_AMOUNT_BLOCKS
           WHERE ACCOUNT = P_ICDREDMN.AC_NO
             AND BRANCH = P_ICDREDMN.BRN_CODE
             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A'
             AND AMOUNT_BLOCK_TYPE <> 'D';
        
          DBG('Amount Block check for discounted depoit has count-partial liqd wd blk as -->' ||
              L_CNT_DISCNTD_BLKS ||
              L_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK);
        
          DBG('Redemption Mode is-->' || P_ICDREDMN.REDEMPTION_MODE);
          IF L_CNT_DISCNTD_BLKS > 0 AND L_PAYMENT_METHOD = 'D' AND
             P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            DBG('Amount Blocks exist for the Discounted Deposit Account');
            OVPKSS.PR_APPENDTBL('CA-05006', NULL);
            RETURN FALSE;
          END IF;
        
          IF L_COUNT > 0 AND L_PARTIAL_LIQD_AMT_BLK = 'N' AND
             L_ACCOUNT = P_ICDREDMN.AC_NO AND
             L_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK <> 'D'
          
           THEN
            DBG('Partial liquidation with amount block flag is not checked and some amount has been blocked');
            IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
              OVPKSS.PR_APPENDTBL('ST-00016', NULL);
            END IF;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED : In Exception While select the partial liquidation with amount block flag');
        END;
      
        L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_ICDREDMN.BRN_CODE);
      
        IF (P_ICDREDMN.TRN_DT > GLOBAL.APPLICATION_DATE OR
           L_BRANCH.BRN_AVAIL_STAT = 'N') AND
           P_ICDREDMN.REDEMPTION_MODE = 'N'
        
         THEN
          DBG('nOT SUPPORTED FOR FULL REDEMPTION');
        
          OVPKSS.PR_APPENDTBL('TD-RED-18', NULL);
        
        END IF;
      
        BEGIN
          SELECT A.AC_CLASS_TYPE, A.RD_FLAG
            INTO L_AC_CLASS_TYPE, L_RDFLAG
            FROM STTM_ACCOUNT_CLASS A, STTM_CUST_ACCOUNT B
           WHERE A.ACCOUNT_CLASS = B.ACCOUNT_CLASS
             AND B.BRANCH_CODE = P_ICDREDMN.BRN_CODE
             AND B.CUST_AC_NO = P_ICDREDMN.AC_NO;
        END;
        DBG('Checking for partial redemption for RD Accounts: ' ||
            L_AC_CLASS_TYPE || '~' || L_RDFLAG || '~' ||
            P_ICDREDMN.ACTION_FLAG);
        IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
          DBG('the Action flag is Redemption');
          IF L_AC_CLASS_TYPE = 'Y' AND L_RDFLAG = 'Y' AND
             P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
          
            DBG('Partial Redemption NOT SUPPORTED FOR Recurring Deposit Accounts.');
            L_FLD := 'TERM DEPOSIT ACCOUNT NUMBER';
            OVPKSS.PR_APPENDTBL('TD-RED-19', L_FLD);
          
          END IF;
        END IF;
      
        BEGIN
          SELECT COUNT(*)
            INTO L_REDEM_STATUS
            FROM ICTB_TDREDEMPTION_MASTER
           WHERE ACC_NO = P_ICDREDMN.AC_NO
             AND BRANCH_CODE = P_ICDREDMN.BRN_CODE
             AND NVL(AUTH_STATUS, 'U') = 'U'
             AND NVL(CONTRACT_STATUS, 'A') = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            L_REDEM_STATUS := 0;
            DBG('Redem status is null' || SQLERRM);
        END;
        DBG('l_redem_status' || L_REDEM_STATUS);
        IF (L_REDEM_STATUS > 0) THEN
          DBG('Cannot Proceed');
          OVPKSS.PR_APPENDTBL('IC-REDMN-14', '');
        END IF;
      
        DBG('Mandatory check - REDEMPTION AMOUNT');
        IF NVL(P_ICDREDMN.REDEMPTION_AMT, 0) <= 0 THEN
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' AND L_PAYMENT_METHOD <> 'D' THEN
            DBG('Redemption mode is Full.. So defaulting the redemption Amount to p_icdredmn.ACC_AMT :: ' ||
                P_ICDREDMN.ACC_AMT);
            P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.ACC_AMT;
            DBG('Redemption amt assigned to acc_bal :: ' ||
                P_ICDREDMN.ACC_AMT);
          ELSIF P_ICDREDMN.REDEMPTION_MODE = 'N' AND L_PAYMENT_METHOD = 'D' THEN
            DBG('Redemption mode is Full but it is a discounted deposit so amt is' ||
                P_ICDREDMN.REDEMPTION_AMT);
            P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.REDEMPTION_AMT;
          ELSE
            DBG('Redemption mode is partial');
            DBG('REDEMPTION AMOUNT IS MANDATORY');
          
            L_FLD := '@ICTMS_TDREDMPAYOUT_DETAILS.REDMAMT';
          
            CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                         '1317',
                                         'ST-MAND-001',
                                         L_FLD);
          
          END IF;
        END IF;
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    RETURN TRUE;
  END FN_VALIDATE_REDEMPTION;

  FUNCTION FN_VALIDATE_PAYOUTDETAILS(P_ACTION_CODE      IN VARCHAR2,
                                     P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                     P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                     P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                     P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                     P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_BC_PRODCODE      OUT VARCHAR2,
                                     P_ACC_PRODCODE     OUT VARCHAR2,
                                     P_GL_PRODCODE      OUT VARCHAR2,
                                     P_CASH_PRODCODE    OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
    L_LOV_CNT           NUMBER;
    L_FLD               VARCHAR2(1000);
    L_STAT_BLOCK        VARCHAR2(1);
    L_PRM_PRODUCT_CODE  ISTMS_INSTR_PROD.PROD%TYPE;
    L_RATE_CODE         CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE         CSTMS_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    L_PRM_AVL_AMT       NUMBER;
    L_PRM_OFS_AMT       NUMBER;
    P_SOURCE            VARCHAR2(100) := 'FLEXCUBE';
    L_PRM_MATURITY_DATE DATE;
    L_TEMP              NUMBER;
  
    L_BC_CNT      NUMBER := 0;
    L_PC_CNT      NUMBER := 0;
    L_TD_CNT      NUMBER := 0;
    L_GL_CNT      NUMBER := 0;
    L_CASH_CNT    NUMBER := 0;
    L_DD_CNT      NUMBER := 0;
    L_CL_CUSTOMER CLTB_ACCOUNT_MASTER.CUSTOMER_ID%TYPE;
  
    L_INSTR_STAT   ISTMS_INSTR_PROD.INSTR_STAT%TYPE;
    L_INSTR_TYPE   ISTMS_INSTR_PROD.INSTR_TYPE%TYPE;
    L_INSTR_NO     NUMBER;
    L_INSTR_STATUS ISTMS_INSTRUMENT_DETAIL.STATUS%TYPE;
  
    L_COUNT             NUMBER;
    L_TOT_PAYOUT_AMOUNT NUMBER := 0;
  
    L_AC_STAT_FROZEN STTMS_CUST_ACCOUNT.AC_STAT_FROZEN%TYPE;
  
    L_AC_STAT_NO_CR   STTMS_CUST_ACCOUNT.AC_STAT_NO_CR%TYPE;
    L_AC_STAT_DORMANT STTMS_CUST_ACCOUNT.AC_STAT_DORMANT%TYPE;
  
    L_TY_PAYOUTDETS TY_TB_PAYOUTDETS;
  
    L_CCY_REC CYTMS_CCY_DEFN%ROWTYPE;
    L_BRANCH  STTMS_BRANCH%ROWTYPE;
  
    L_TY_STDCUSAC STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_IDX1        NUMBER := 0;
  
    CURSOR CUR_TD_JNT_HOLDERS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTMS_AC_LINKED_ENTITIES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    TYPE TY_TD_JNT_HOLDERS IS TABLE OF STTMS_AC_LINKED_ENTITIES%ROWTYPE INDEX BY BINARY_INTEGER;
    L_TY_TD_JNT_HOLDERS TY_TD_JNT_HOLDERS;
  
    L_CUST_NO                  STTMS_CUST_ACCOUNT.CUST_NO%TYPE := NULL;
    L_CUST_FROZEN              STTM_CUSTOMER.FROZEN%TYPE;
    L_CUST_WHEREABOUTS_UNKNOWN STTM_CUSTOMER.WHEREABOUTS_UNKNOWN%TYPE;
    L_CUST_DECEASED            STTM_CUSTOMER.DECEASED%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG(' p_ty_payoutdets.COUNT =' || P_TY_PAYOUTDETS.COUNT);
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
        DBG(' Redemption Payout Component =' || P_TY_PAYOUTDETS(I)
            .REDM_PAYOUT_COMP);
        IF P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP = 'P' THEN
          L_TY_PAYOUTDETS(L_TY_PAYOUTDETS.COUNT + 1) := P_TY_PAYOUTDETS(I);
        END IF;
      END LOOP;
      DBG(' l_ty_payoutdets.COUNT =' || L_TY_PAYOUTDETS.COUNT);
    
    END IF;
  
    IF L_TY_PAYOUTDETS.COUNT > 1 THEN
      FOR I IN L_TY_PAYOUTDETS.FIRST .. L_TY_PAYOUTDETS.LAST LOOP
        IF I <> L_TY_PAYOUTDETS.LAST THEN
          L_TOT_PAYOUT_AMOUNT := NVL(L_TOT_PAYOUT_AMOUNT, 0) +
                                 NVL(L_TY_PAYOUTDETS(I).REDMAMT, 0);
        END IF;
      END LOOP;
      IF L_TOT_PAYOUT_AMOUNT > P_ICDREDMN.ACC_AMT THEN
        DBG('Sum of the payout amount excluding the last payout account exceed the available balance of the term deposit');
        OVPKS.PR_APPENDTBL('AC-OVD20', '');
      END IF;
    END IF;
    L_TY_PAYOUTDETS.DELETE;
  
    FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
      DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS(I).INSTNO);
      L_INSTR_NO := P_TY_PAYOUTDETS(I).INSTNO;
      DBG('l_instr_no::' || L_INSTR_NO);
      DBG('p_ty_payoutdets(i).payouttype:;' || P_TY_PAYOUTDETS(I)
          .PAYOUTTYPE);
      IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'B' THEN
        L_INSTR_TYPE := 'BCI';
      END IF;
      DBG('l_instr_type::' || L_INSTR_TYPE);
    END LOOP;
  
    DBG('Going to LOV Validate Bank Code' || P_BCPAYOUTDETS_REC.BANKCODE);
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
        IF (P_ACTION_CODE NOT IN ('TDRedemAuth')) THEN
        
          IF P_TY_PAYOUTDETS(I)
           .PERCENTAGE < 0 OR P_TY_PAYOUTDETS(I).PERCENTAGE > 100 THEN
            OVPKSS.PR_APPENDTBL('ST-ACC-209', '');
            RETURN FALSE;
          END IF;
        
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'B' THEN
          
            L_BC_CNT := L_BC_CNT + 1;
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'D' THEN
            L_DD_CNT := L_DD_CNT + 1;
          END IF;
        
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('B', 'D') THEN
          
            IF P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_LOV_CNT
                FROM DETMS_CLG_BANK_CODE
               WHERE RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y'
                 AND CLG_BANK_CODE = P_BCPAYOUTDETS_REC.BANKCODE;
              DBG('l_lov_cnt :: ' || L_LOV_CNT);
            
              IF L_LOV_CNT < 1 THEN
                DBG('Invalid value For Bank Code');
                L_FLD := P_BCPAYOUTDETS_REC.BANKCODE;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'Bank Code');
              END IF;
            END IF;
          
            DBG('Going to LOV Validate Cheque Currency');
            IF P_BCPAYOUTDETS_REC.CHQ_CCY IS NOT NULL THEN
            
              SELECT COUNT(*)
                INTO L_LOV_CNT
                FROM CYTMS_CCY_DEFN
               WHERE RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y'
                 AND CCY_CODE = P_BCPAYOUTDETS_REC.CHQ_CCY;
            
              DBG('l_lov_cnt :: ' || L_LOV_CNT);
            
              IF L_LOV_CNT < 1
              
               THEN
                DBG('Invalid value For Cheque Currency');
                L_FLD := P_BCPAYOUTDETS_REC.CHQ_CCY;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'Cheque Currency');
              END IF;
            END IF;
          
            DBG('Check Date = ' || P_BCPAYOUTDETS_REC.CHQ_DATE);
          
            IF P_BCPAYOUTDETS_REC.CHARGES < 0 THEN
              L_FLD := 'Bank Charges';
              DBG('Bank Charges cannot be less than 0');
            
              DBG('l_fld--> ' || L_FLD);
            
              CSPKS_REQ_UTILS.PR_LOG_ERROR('FLEXCUBE',
                                           '1317',
                                           'SV-MA35',
                                           L_FLD);
            
            END IF;
          
            DBG('Validated Charges');
          
          END IF;
        
          DBG('Going to LOV Validate CL Branch Code');
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'L' THEN
            IF P_TY_PAYOUTDETS(I).OFFSET_BRN IS NOT NULL THEN
              DBG('~~~~~ ::' || P_TY_PAYOUTDETS(I).OFFSET_BRN || '::');
            
              L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_TY_PAYOUTDETS(I)
                                                        .OFFSET_BRN);
              IF L_BRANCH.BRANCH_CODE IS NULL THEN
              
                DBG('Invalid value For CL Branch code');
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_BRN;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'CL Branch code');
              END IF;
            END IF;
            DBG('Going to LOV Validate CL Account Number');
            DBG('p_ty_payoutdets(i).acc-->' || P_TY_PAYOUTDETS(I).ACC);
            DBG('p_ty_payoutdets(i).offset_acc-->' || P_TY_PAYOUTDETS(I)
                .OFFSET_ACC);
            DBG('p_ty_payoutdets(i).offset_brn-->' || P_TY_PAYOUTDETS(I)
                .OFFSET_BRN);
            IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_LOV_CNT
                FROM STTB_ACCOUNT A, CLTB_ACCOUNT_APPS_MASTER B
               WHERE A.AC_OR_GL = 'L'
                 AND B.ACCOUNT_STATUS <> 'L'
                 AND A.AC_GL_NO = B.ACCOUNT_NUMBER
                 AND A.BRANCH_CODE = B.BRANCH_CODE
                 AND NVL(B.PACKING_CREDIT, 'N') = 'N'
                 AND B.MATURITY_DATE >
                     (SELECT MATURITY_DATE
                        FROM ICTM_ACC
                       WHERE ACC = P_TY_PAYOUTDETS(I).ACC)
                 AND A.AC_GL_NO = P_TY_PAYOUTDETS(I).OFFSET_ACC
                 AND A.BRANCH_CODE = P_TY_PAYOUTDETS(I).OFFSET_BRN;
              DBG('l_lov_cnt :: ' || L_LOV_CNT);
              IF L_LOV_CNT < 1 THEN
                DBG('Invalid value For CL Account Number');
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'CL Account Number');
              END IF;
            END IF;
            SELECT CUSTOMER_ID
              INTO L_CL_CUSTOMER
              FROM CLTB_ACCOUNT_APPS_MASTER
             WHERE ACCOUNT_NUMBER = P_TY_PAYOUTDETS(I).OFFSET_ACC
               AND BRANCH_CODE = P_TY_PAYOUTDETS(I).OFFSET_BRN;
            DBG('td cust id-->' || P_ICDREDMN.CUST_ID);
            DBG('l_cl_customer-->' || L_CL_CUSTOMER);
            IF P_ICDREDMN.CUST_ID <> L_CL_CUSTOMER THEN
              DBG('customer differnent');
              OVPKSS.PR_APPENDTBL('ST-ACC-247',
                                  L_CL_CUSTOMER || '~' ||
                                  P_ICDREDMN.CUST_ID);
            END IF;
          END IF;
        
          DBG('Going to LOV Validate Savings Branch Code');
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'S' THEN
            IF P_TY_PAYOUTDETS(I).OFFSET_BRN IS NOT NULL THEN
              DBG('~~~~~ ::' || P_TY_PAYOUTDETS(I).OFFSET_BRN || '::');
            
              L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_TY_PAYOUTDETS(I)
                                                        .OFFSET_BRN);
              IF L_BRANCH.BRANCH_CODE IS NULL
              
               THEN
                DBG('Invalid value For Savings Branch code');
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_BRN;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'Savings Branch code');
              END IF;
            END IF;
          
            DBG('Going to LOV Validate Savings Account Number');
            IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NOT NULL THEN
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID      := 1;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                DBG('calling icpks_fcj_icdredmn_cluster.fn_validate_payoutdetails');
                IF NOT
                    ICPKS_FCJ_ICDREDMN_CLUSTER.FN_VALIDATE_PAYOUTDETAILS(P_ACTION_CODE,
                                                                         P_ICDREDMN,
                                                                         P_TY_PAYOUTDETS,
                                                                         P_BCPAYOUTDETS_REC,
                                                                         P_PCPAYOUTDETS_REC,
                                                                         P_TY_STDCUSAC,
                                                                         P_BC_PRODCODE,
                                                                         P_ACC_PRODCODE,
                                                                         P_GL_PRODCODE,
                                                                         P_CASH_PRODCODE,
                                                                         L_FN_CALL_ID,
                                                                         L_TB_CLUSTER_DATA) THEN
                  DBG('icpks_fcj_icdredmn_cluster.fn_validate_payoutdetails failed with :-');
                  RETURN FALSE;
                END IF;
              END IF;
              IF NOT GLOBAL.G_SKIP_KERNEL THEN
              
                SELECT COUNT(*)
                  INTO L_LOV_CNT
                  FROM STTM_CUST_ACCOUNT
                 WHERE ONCE_AUTH = 'Y'
                   AND RECORD_STAT <> 'C'
                   AND BRANCH_CODE = P_TY_PAYOUTDETS(I).OFFSET_BRN
                   AND ACCOUNT_CLASS IN
                       (SELECT DISTINCT ACCOUNT_CLASS
                          FROM STTM_ACCOUNT_CLASS
                        
                         WHERE AC_CLASS_TYPE IN ('S', 'U')
                              
                           AND ONCE_AUTH = 'Y'
                           AND RECORD_STAT <> 'C')
                   AND CUST_AC_NO = P_TY_PAYOUTDETS(I).OFFSET_ACC;
                DBG('l_lov_cnt :: ' || L_LOV_CNT);
              
                IF L_LOV_CNT < 1 THEN
                  DBG('Invalid value For Savings Account Number');
                  L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                  OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                      L_FLD || '~' ||
                                      'Savings Account Number');
                END IF;
              
              ELSE
                GLOBAL.PR_RESET_SKIP_KERNEL;
              END IF;
            
              BEGIN
                SELECT NVL(AC_STAT_FROZEN, 'N')
                       
                      ,
                       NVL(AC_STAT_NO_CR, 'N'),
                       NVL(AC_STAT_DORMANT, 'N'),
                       CUST_NO
                  INTO L_AC_STAT_FROZEN
                       
                      ,
                       L_AC_STAT_NO_CR,
                       L_AC_STAT_DORMANT,
                       L_CUST_NO
                  FROM STTMS_CUST_ACCOUNT
                 WHERE BRANCH_CODE = P_TY_PAYOUTDETS(I).OFFSET_BRN
                   AND CUST_AC_NO = P_TY_PAYOUTDETS(I).OFFSET_ACC
                   AND AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                  OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                      L_FLD || '~' ||
                                      'Savings Account Number');
              END;
            
              IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_TY_PAYOUTDETS(I)
                                                          .OFFSET_BRN,
                                                          P_TY_PAYOUTDETS(I)
                                                          .OFFSET_ACC,
                                                          'Y',
                                                          G_BALREC) THEN
                DEBUG.PR_DEBUG('AC',
                               'Failed in Get_Sttm_Account_Balance .. : ' ||
                               SQLERRM);
              END IF;
              L_AC_STAT_DORMANT := NVL(G_BALREC.AC_STAT_DORMANT, 'N');
            
              DBG('l_ac_stat_frozen~l_ac_stat_no_cr~l_ac_stat_dormant-->' ||
                  L_AC_STAT_FROZEN || '~' || L_AC_STAT_NO_CR || '~' ||
                  L_AC_STAT_DORMANT);
              IF L_AC_STAT_FROZEN = 'Y' THEN
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                OVPKSS.PR_APPENDTBL('AC-VAC04', L_FLD);
              END IF;
            
              IF L_AC_STAT_NO_CR = 'Y' THEN
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                OVPKSS.PR_APPENDTBL('AC-VAC03', L_FLD);
              END IF;
            
              IF L_AC_STAT_DORMANT = 'Y' THEN
                DBG('Dormant account');
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                OVPKSS.PR_APPENDTBL('AC-VAC05', L_FLD);
              END IF;
            
              BEGIN
                SELECT NVL(FROZEN, 'N'),
                       NVL(WHEREABOUTS_UNKNOWN, 'N'),
                       NVL(DECEASED, 'N')
                  INTO L_CUST_FROZEN,
                       L_CUST_WHEREABOUTS_UNKNOWN,
                       L_CUST_DECEASED
                  FROM STTMS_CUSTOMER
                 WHERE CUSTOMER_NO = L_CUST_NO;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed to get customer liability number and local branch ' ||
                      SQLERRM);
              END;
              IF L_CUST_FROZEN = 'Y' THEN
                DBG('Frozeb');
                OVPKSS.PR_APPENDTBL('AC-VAC15', L_CUST_NO);
              END IF;
              IF L_CUST_WHEREABOUTS_UNKNOWN = 'Y' THEN
                DBG('Whereabouts_Unknown');
                OVPKSS.PR_APPENDTBL('AC-VAC17', L_CUST_NO);
              END IF;
              IF L_CUST_DECEASED = 'Y' THEN
                DBG('Deceased');
                OVPKSS.PR_APPENDTBL('AC-VAC18', L_CUST_NO);
              END IF;
            
            END IF;
          
            DBG('Going to LOV Validate Transaction Currency');
          
            DBG('account block  - savings ');
            BEGIN
              SELECT AC_STAT_BLOCK
                INTO L_STAT_BLOCK
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_TY_PAYOUTDETS(I).OFFSET_ACC
                 AND BRANCH_CODE = P_TY_PAYOUTDETS(I).OFFSET_BRN;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_STAT_BLOCK := 'N';
            END;
            IF L_STAT_BLOCK = 'Y' THEN
              DBG('Saving Account is blocked ');
              OVPKSS.PR_APPENDTBL('CA-VAC011', NULL);
            
            END IF;
          
            L_IDX1 := L_IDX1 + 1;
            L_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_IDX1).OFFSET_BRN := P_TY_PAYOUTDETS(I)
                                                                         .OFFSET_BRN;
            L_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_IDX1).OFFSET_ACC := P_TY_PAYOUTDETS(I)
                                                                         .OFFSET_ACC;
            L_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_IDX1).PAYOUTTYPE := P_TY_PAYOUTDETS(I)
                                                                         .PAYOUTTYPE;
          
          END IF;
        
          DBG('Going to LOV Validate General Ledger Number');
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'G' THEN
            L_GL_CNT := L_GL_CNT + 1;
            IF P_TY_PAYOUTDETS(I).OFFSET_ACC IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_LOV_CNT
                FROM GLTMS_GLMASTER
               WHERE ONCE_AUTH = 'Y'
                    
                 AND CATEGORY IN ('1', '2', '3', '4')
                 AND POSTING_RES = 'Y'
                 AND LEAF = 'Y'
                 AND CUSTOMER = 'I'
                 AND GL_CODE = P_TY_PAYOUTDETS(I).OFFSET_ACC;
              DBG('l_lov_cnt :: ' || L_LOV_CNT);
            
              IF L_LOV_CNT < 1 THEN
                DBG('Invalid value For General Ledger Number');
                L_FLD := P_TY_PAYOUTDETS(I).OFFSET_ACC;
                OVPKSS.PR_APPENDTBL('ST-VALS-012',
                                    L_FLD || '~' || 'General Ledger Number');
              END IF;
            END IF;
          
          END IF;
        
          DBG('Going to Cash ');
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
            L_CASH_CNT := L_CASH_CNT + 1;
          END IF;
        
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'Y' THEN
            L_TD_CNT := L_TD_CNT + 1;
          END IF;
        
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'P' THEN
            L_PC_CNT := L_PC_CNT + 1;
          END IF;
        
          IF L_BC_CNT > 1 OR L_CASH_CNT > 1 OR L_TD_CNT > 1 OR L_PC_CNT > 1 THEN
            DBG('Cannot have multiple Payout option except Account ');
            OVPKSS.PR_APPENDTBL('ST-ACC-211', '');
            RETURN FALSE;
          END IF;
        END IF;
      
        IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
          DBG('GOING TO VALIDATE REDEMPTION BY');
          DBG('payouttype is -->' || P_TY_PAYOUTDETS(I).PAYOUTTYPE);
          BEGIN
            IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'B' THEN
            
              BEGIN
                SELECT PROD
                  INTO P_BC_PRODCODE
                  FROM ISTMS_INSTR_PROD
                 WHERE INSTR_TYPE = 'BCA'
                   AND INSTR_STAT = 'INIT';
              
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                
                  OVPKSS.PR_APPENDTBL('ST-ACC-358', '');
                  RETURN FALSE;
              END;
            
            ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'D' THEN
              BEGIN
                SELECT PROD
                  INTO P_BC_PRODCODE
                  FROM ISTMS_INSTR_PROD
                 WHERE INSTR_TYPE = 'DDA'
                   AND INSTR_STAT = 'INIT';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                
                  OVPKSS.PR_APPENDTBL('ST-ACC-359', '');
                  RETURN FALSE;
              END;
            
            ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'S' THEN
              P_ACC_PRODCODE := P_ICDREDMN.PRODUCT_CODE;
              DBG('pay out type is S and the product code is ' ||
                  P_ACC_PRODCODE);
            
              IF P_ICDREDMN.PRODUCT_CODE IS NULL THEN
                BEGIN
                  SELECT LINKED_RT_PRODUCT
                    INTO P_ACC_PRODCODE
                    FROM STTMS_CUSTAC_CLOSE_MODE
                   WHERE CLOSE_MODE = 'FT'
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A'
                        
                     AND DRCR_IND = 'D';
                
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                  
                    OVPKSS.PR_APPENDTBL('ST-ACC-357', '');
                    RETURN FALSE;
                END;
              END IF;
            
            ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('G', 'L') THEN
              P_GL_PRODCODE := P_ICDREDMN.PRODUCT_CODE;
              DBG('pay out type is G\L and the product code is ' ||
                  P_GL_PRODCODE);
            
              IF P_ICDREDMN.PRODUCT_CODE IS NULL THEN
                BEGIN
                  SELECT LINKED_RT_PRODUCT, CLOSE_MODE
                    INTO P_GL_PRODCODE, PKG_CLOSE_MODE
                    FROM STTMS_CUSTAC_CLOSE_MODE
                  
                   WHERE CLOSE_MODE = DECODE(P_TY_PAYOUTDETS(I).PAYOUTTYPE,
                                             'G',
                                             'GL',
                                             'FT')
                        
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A'
                        
                     AND DRCR_IND = 'D';
                
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    BEGIN
                      SELECT LINKED_RT_PRODUCT, CLOSE_MODE
                        INTO P_GL_PRODCODE, PKG_CLOSE_MODE
                        FROM STTMS_CUSTAC_CLOSE_MODE
                       WHERE CLOSE_MODE = 'FT'
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A'
                         AND DRCR_IND = 'D';
                    
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      
                        OVPKSS.PR_APPENDTBL('ST-ACC-357', '');
                        RETURN FALSE;
                    END;
                END;
                DBG('pkg_close_mode is -->' || PKG_CLOSE_MODE);
              END IF;
            
            ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
              P_CASH_PRODCODE := P_ICDREDMN.PRODUCT_CODE;
              DBG('pay out type is C and the product code is ' ||
                  P_CASH_PRODCODE);
            
              IF P_ICDREDMN.PRODUCT_CODE IS NULL THEN
                SELECT LINKED_RT_PRODUCT
                  INTO P_CASH_PRODCODE
                  FROM STTMS_CUSTAC_CLOSE_MODE
                 WHERE CLOSE_MODE = 'CASH'
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A'
                      
                   AND DRCR_IND = 'D';
              
              END IF;
            END IF;
          
          END;
        END IF;
      
      END LOOP;
      IF (P_ACTION_CODE NOT IN ('TDRedemAuth')) THEN
      
        IF L_BC_CNT >= 1 AND L_DD_CNT >= 1 THEN
          DBG('In multi mode term deposit payout a combination of bankers cheque and demand draft cannot be choosen');
          OVPKSS.PR_APPENDTBL('ST-ACC-326', NULL);
          RETURN FALSE;
        END IF;
      
        IF L_BC_CNT = 0 AND L_DD_CNT = 0 THEN
        
          IF (P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.CHQ_DATE IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.BENFNAME IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.OTHERDETS IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.NARRATIVE IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.COUNTRY_CODE IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.CCY IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.BENFADD1 IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.BENFADD2 IS NOT NULL) OR
             (P_BCPAYOUTDETS_REC.BENFADD3 IS NOT NULL) THEN
            DBG('BC/DD DETAILS CANNOT BE MAINTAINED WHEN PAYOUT TYPE IS NOT BANKERS CHEQUE/DEMAND DRAFT');
            OVPKSS.PR_APPENDTBL('TD-RED-100', NULL);
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    
    END IF;
  
    DBG('coming inside inst no if');
    DBG('l_instr_no::' || L_INSTR_NO);
    DBG('l_instr_type::' || L_INSTR_TYPE);
    DBG('l_instr_stat::' || L_INSTR_STAT);
  
    IF L_INSTR_TYPE LIKE 'DD%' OR L_INSTR_TYPE LIKE 'BC%'
    
     THEN
      IF L_INSTR_NO IS NOT NULL THEN
      
        DBG('l_instr_status --> ' || L_INSTR_STATUS);
        DBG('l_instr_type::' || L_INSTR_TYPE);
        DBG('l_instr_no:;' || L_INSTR_NO);
        DBG('p_bcpayoutdets_rec.ccy::' || P_BCPAYOUTDETS_REC.CCY);
        DBG('p_bcpayoutdets_rec.bankcode::' || P_BCPAYOUTDETS_REC.BANKCODE);
        SELECT STATUS
          INTO L_INSTR_STATUS
          FROM ISTMS_INSTRUMENT_DETAIL
        
         WHERE INSTRUMENT_TYPE = L_INSTR_TYPE
           AND CHEQUE_NO = L_INSTR_NO
           AND BRANCH = P_BCPAYOUTDETS_REC.BRN
           AND NVL(CCY, P_BCPAYOUTDETS_REC.CCY) = P_BCPAYOUTDETS_REC.CCY
           AND NVL(ISSUER_CODE, P_BCPAYOUTDETS_REC.BANKCODE) =
               P_BCPAYOUTDETS_REC.BANKCODE;
      
        DBG('l_instr_status::' || L_INSTR_STATUS);
        IF L_INSTR_STATUS = 'U' THEN
          DBG('Instrument is already Used and it cannot be used again !!!');
          OVPKS.PR_APPENDTBL('DD-ERR11', 'Instrument Number ');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    DBG('Instrument is not yet Used Instr_status = ' || L_INSTR_STATUS);
  
    IF P_ACTION_CODE NOT IN ('TDRedemCompute') THEN
      L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_ICDREDMN.AC_NO;
      L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_ICDREDMN.BRN_CODE;
      L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY         := P_ICDREDMN.CCY;
      L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO     := P_ICDREDMN.CUST_ID;
    
      DBG('TD brn-->' || L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('TD acc-->' || L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      BEGIN
        SELECT JOINT_AC_INDICATOR
          INTO L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR
          FROM STTM_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED INS ELECT' || SQLERRM);
      END;
      DBG('JOINT_AC_INDICATOR-->' ||
          L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);
      IF CUR_TD_JNT_HOLDERS%ISOPEN THEN
        CLOSE CUR_TD_JNT_HOLDERS;
      END IF;
      OPEN CUR_TD_JNT_HOLDERS(P_ICDREDMN.BRN_CODE, P_ICDREDMN.AC_NO);
      FETCH CUR_TD_JNT_HOLDERS BULK COLLECT
        INTO L_TY_TD_JNT_HOLDERS;
      CLOSE CUR_TD_JNT_HOLDERS;
      DBG('TD joint holders count-->' || L_TY_TD_JNT_HOLDERS.COUNT);
      IF L_TY_TD_JNT_HOLDERS.COUNT > 0 THEN
        FOR K IN L_TY_TD_JNT_HOLDERS.FIRST .. L_TY_TD_JNT_HOLDERS.LAST LOOP
          L_TY_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(K) := L_TY_TD_JNT_HOLDERS(K);
        END LOOP;
      END IF;
      DBG('calling stpks_stdcusac_utils_1.fn_validate_joint_holders');
      DBG('REDEMPTION PAYOUT COUNT' || P_TY_PAYOUTDETS.COUNT);
      DBG('CASA PAYOUT details' ||
          L_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
    
      IF L_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_VALIDATE_JOINT_HOLDERS('ICDREDMN',
                                                             L_TY_STDCUSAC) THEN
          DBG('FAILED IN STPKS_STDCUSAC_UTILS_1.fn_validate_joint_holders' ||
              SQLERRM);
        END IF;
      
      END IF;
    
    END IF;
    DBG('Before exiting function fn_validate_instrument_no with Success');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When others of ddpks_upload_contract_create.fn_validate_instrument_no.. No data found ');
      DBG(SQLERRM);
      OVPKS.PR_APPENDTBL('DD-ERR11',
                         'fn_validate_instrument_no ' || SQLCODE);
      DBG('Before exiting function fn_validate_instrument_no ');
    
      RETURN TRUE;
  END FN_VALIDATE_PAYOUTDETAILS;

  FUNCTION FN_UPLOAD_PAYOUTDETS(P_SOURCE           IN OUT VARCHAR2,
                                P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_BC_PRODCODE      IN OUT VARCHAR2,
                                P_ACC_PRODCODE     IN OUT VARCHAR2,
                                P_GL_PRODCODE      IN OUT VARCHAR2,
                                P_CASH_PRODCODE    IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
    RET            BOOLEAN := FALSE;
    L_REDM_MODE    VARCHAR2(1) := 'Y';
    L_ERR_CODE     VARCHAR2(50);
    L_ERR_PARAM    VARCHAR2(50);
    L_REDEM_AMT    ICTM_TD_DETAILS.REDEM_AMT%TYPE;
    L_PRODUCT      VARCHAR2(4);
    L_PAY_METHOD   VARCHAR2(1);
    L_AVL_BAL      STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_TO_DATE      ICTB_INT_LIQ_DETAILS.FROM_DATE%TYPE;
    L_FIRST_INSERT VARCHAR2(1);
  
    L_WHAT_TO_DO  VARCHAR2(1);
    L_AUTH_STATUS VARCHAR2(1);
  
    L_ICTMS_ACC ICTMS_ACC%ROWTYPE;
  
    L_REC_PR_INT    ICTM_PR_INT%ROWTYPE;
    L_REC_ACC_PR    ICTMS_ACC_PR%ROWTYPE;
    L_CUST_ACC_REC  STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_TOPUP_CNT     NUMBER := 0;
  
    L_TOPUP_FLAG VARCHAR2(1);
  
    L_TMP_OVDTABLE1 OVPKS.TBL_ERROR;
    L_TMP_OVDTABLE2 OVPKS.TBL_ERROR;
    L_COUNT         NUMBER;
    L_INDEX         PLS_INTEGER;
  
    L_ACY_AVL_BAL STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_TY_PAYOUTDETS     TY_TB_PAYOUTDETS;
    L_TMP_TY_PAYOUTDETS TY_TB_PAYOUTDETS;
    L_IDX               PLS_INTEGER;
    I                   PLS_INTEGER;
    L_LAST_PRINC_INDEX  PLS_INTEGER;
    L_INDEX1            PLS_INTEGER;
  
  BEGIN
    DBG('the payout type count :' || P_TY_PAYOUTDETS.COUNT);
    DBG('p_icdredmn.redemption_mode IS  :' || P_ICDREDMN.REDEMPTION_MODE);
    DBG('redemption BY IS  :' || P_ICDREDMN.REDEMPTION_BY);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 5;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                                          P_ICDREDMN,
                                                          P_TY_PAYOUTDETS,
                                                          P_BCPAYOUTDETS_REC,
                                                          P_PCPAYOUTDETS_REC,
                                                          P_TY_STDCUSAC,
                                                          P_BC_PRODCODE,
                                                          P_ACC_PRODCODE,
                                                          P_GL_PRODCODE,
                                                          P_CASH_PRODCODE,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA) THEN
        DBG('Failed in call 4 to icpks_fcj_icdredmn_cluster.fn_upload_payoutdets');
        RETURN FALSE;
      END IF;
    END IF;
  
    BEGIN
      SELECT SEQ_NO
        INTO ICPKS_PARTITION_INFO.G_THIS_PART
        FROM CSTB_CUSTACSEQ
       WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
         AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      DBG('Intraday: icpks_partition_info.g_This_Part: ' ||
          ICPKS_PARTITION_INFO.G_THIS_PART);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Intraday: icpks_partition_info.g_This_Part will not be set.' ||
            SQLERRM);
    END;
    IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH', P_ICDREDMN.BRN_CODE) THEN
    
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
        DBG('Intraday: Calling icpks_deferred_entries.pr_post_entries  ' ||
            P_ICDREDMN.BRN_CODE || ' Acc: ' || P_ICDREDMN.AC_NO ||
            ' Seq No: ' || ICPKS_PARTITION_INFO.G_THIS_PART);
        IF NOT TDPKS_UTILS.FN_POST_INTRADAY_ACCR(P_ICDREDMN.BRN_CODE,
                                                 P_ICDREDMN.AC_NO,
                                                 L_ERR_CODE,
                                                 L_ERR_PARAM) THEN
          DBG('Failed in posting the intraday accrual entries');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
      ICPKSS_MAINT.PR_SET_REDEM_AMT(P_ICDREDMN.REDEMPTION_AMT);
      G_RELATEDPARTIAL_ACCOUNT := P_ICDREDMN.AC_NO;
      DBG('g_relatedpartial_account BY IS  :' || G_RELATEDPARTIAL_ACCOUNT);
    
      ICPKS_BOD.G_PENALTY := P_ICDREDMN.REDEMPTION_AMT;
      DBG('icpks_bod.g_penalty is:' || ICPKS_BOD.G_PENALTY);
    
    ELSE
      L_REDEM_AMT := NVL(P_ICDREDMN.ACC_AMT, 0);
      ICPKSS_MAINT.PR_SET_REDEM_AMT(L_REDEM_AMT);
    END IF;
    IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
    
      ICPKSS_MAINT.PR_SET_FULL_REDEM('Y');
    ELSE
      ICPKSS_MAINT.PR_SET_FULL_REDEM('N');
    END IF;
    CSPKS_ACC_SERVICE.G_RELATEDCLOSED_ACCOUNT := P_ICDREDMN.AC_NO;
  
    L_REC_ACC_PR := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ICDREDMN.AC_NO,
                                                    P_ICDREDMN.BRN_CODE);
    L_PRODUCT    := L_REC_ACC_PR.PROD;
  
    ICPKSS_UTIL.DBG('prod is :' || L_PRODUCT);
  
    L_REC_PR_INT := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(L_PRODUCT);
  
    L_PAY_METHOD := L_REC_PR_INT.PAYMENT_METHOD;
    ICPKSS_UTIL.DBG('Payment method is :' || L_PAY_METHOD);
  
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.BRN_CODE,
                                     P_ICDREDMN.AC_NO,
                                     L_CUST_ACC_REC) THEN
      DBG('Failed in select from sttm_cust_account');
    END IF;
  
    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_CUST_ACC_REC.ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  L_ERR_CODE);
  
    PKG_RATE_CHART := NVL(L_ACC_CLASS_REC.TD_RATECHART_ALLOW, 'N');
    ICPKSS_UTIL.DBG('pkg_rate_chart is :' || PKG_RATE_CHART);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                                          P_ICDREDMN,
                                                          P_TY_PAYOUTDETS,
                                                          P_BCPAYOUTDETS_REC,
                                                          P_PCPAYOUTDETS_REC,
                                                          P_TY_STDCUSAC,
                                                          P_BC_PRODCODE,
                                                          P_ACC_PRODCODE,
                                                          P_GL_PRODCODE,
                                                          P_CASH_PRODCODE,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA) THEN
        DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    IF P_ICDREDMN.REDEMPTION_MODE = 'N' AND NVL(PKG_RATE_CHART, 'N') = 'N' AND
       L_PAY_METHOD <> 'D' THEN
      DBG('correcting ictbs_int_liq_details table for full redemption cases');
    
      SELECT *
        INTO ICPKSS_CALC.G_ICTB_ACC_PR
        FROM ICTBS_ACC_PR
       WHERE ACC = P_ICDREDMN.AC_NO
         AND BRN = P_ICDREDMN.BRN_CODE
         AND PROD = L_PRODUCT;
    
      IF NOT
          STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                      P_ICDREDMN.BRN_CODE) THEN
        IF ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT =
           GLOBAL.APPLICATION_DATE - 1 THEN
          DELETE FROM ICTBS_INT_LIQ_DETAILS
           WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
             AND ACCOUNT_NUMBER = P_ICDREDMN.AC_NO
             AND TO_DATE = ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT;
        END IF;
      END IF;
    END IF;
  
    ICPKS_FCJ_ICDREDMN.G_REDEMREFNO := P_ICDREDMN.REDEM_REF_NO;
    DBG('icpks_fcj_icdredmn.g_redemrefno' ||
        ICPKS_FCJ_ICDREDMN.G_REDEMREFNO);
    IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
    
      IF STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                     P_ICDREDMN.BRN_CODE) THEN
        L_TOPUP_FLAG := 'Y';
      ELSE
        L_TOPUP_FLAG := 'N';
      END IF;
      DBG('l_topup_flag=' || L_TOPUP_FLAG);
    
      IF L_TOPUP_FLAG = 'Y' THEN
      
        IF NOT STPKS_STDTDTOP_UTILS.FN_REDEM_TD(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                L_ERR_CODE,
                                                L_ERR_PARAM) THEN
          DBG('l_err_code  ' || L_ERR_CODE);
          OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
          RETURN FALSE;
        END IF;
      ELSE
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID      := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              ICPKS_FCJ_ICDREDMN_CLUSTER.FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                                              P_ICDREDMN,
                                                              P_TY_PAYOUTDETS,
                                                              P_BCPAYOUTDETS_REC,
                                                              P_PCPAYOUTDETS_REC,
                                                              P_TY_STDCUSAC,
                                                              P_BC_PRODCODE,
                                                              P_ACC_PRODCODE,
                                                              P_GL_PRODCODE,
                                                              P_CASH_PRODCODE,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
            DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_upload_payoutdets');
            RETURN FALSE;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF NOT STPKS_TD_REDEMPTION.FN_BROKEN_PARTIAL_TD(P_ICDREDMN.BRN_CODE,
                                                          P_ICDREDMN.AC_NO,
                                                          L_ERR_CODE,
                                                          L_ERR_PARAM) THEN
            DBG('l_err_code  ' || L_ERR_CODE);
            OVPKSS.PR_APPENDTBL(L_ERR_CODE, NULL);
            RETURN FALSE;
          END IF;
        
        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;
      
      END IF;
    END IF;
  
    L_ICTMS_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ICDREDMN.AC_NO,
                                               P_ICDREDMN.BRN_CODE);
  
    DBG('Success Select');
  
    DBG('move_pric_to_unclaimed' || L_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED);
    DBG('move_int_to_unclaimed' || L_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED);
  
    IF L_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' OR
       L_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' THEN
    
      UPDATE ICTB_ACC_PR
         SET STOP_IC = 'N'
       WHERE BRN = L_ICTMS_ACC.BRN
         AND ACC = L_ICTMS_ACC.ACC
         AND STOP_IC = 'Y';
    
      DBG('Updated Stop_ic to N');
    
    END IF;
  
    IF L_PAY_METHOD = 'D' THEN
      ICPKSS_UTIL.DBG('Function call to pass interest adjustment entries for Discounted Deposit..............');
      IF NOT FN_INT_ADJ(P_ICDREDMN.AC_NO,
                        P_ICDREDMN.BRN_CODE,
                        P_ICDREDMN.CCY,
                        P_ICDREDMN.REDEMPTION_AMT,
                        L_PRODUCT,
                        GLOBAL.APPLICATION_DATE,
                        P_ICDREDMN.REDEMPTION_MODE,
                        L_ERR_CODE,
                        L_ERR_PARAM) THEN
        ICPKSS_UTIL.DBG('Failed in fn_int_adj for discounted deposit..............');
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
      ELSE
        ICPKSS_UTIL.DBG('Returning Successfully from fn_int_adj..............');
      END IF;
    END IF;
  
    IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
    
      IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                  P_ICDREDMN.AC_NO,
                                                  'Y',
                                                  G_BALREC) THEN
        DEBUG.PR_DEBUG('AC',
                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                       SQLERRM);
      END IF;
      L_ACY_AVL_BAL := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
    
      DBG('l_Acy_avl_bal ' || L_ACY_AVL_BAL);
      ICPKS_BOD.G_PENALTY := L_ACY_AVL_BAL;
    END IF;
  
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                                            P_ICDREDMN,
                                                            P_TY_PAYOUTDETS,
                                                            P_BCPAYOUTDETS_REC,
                                                            P_PCPAYOUTDETS_REC,
                                                            P_TY_STDCUSAC,
                                                            P_BC_PRODCODE,
                                                            P_ACC_PRODCODE,
                                                            P_GL_PRODCODE,
                                                            P_CASH_PRODCODE,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA) THEN
          DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
        
        END IF;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      IF OVPKS.GL_TBLERROR.COUNT > 0 THEN
        DBG('ovpks.Gl_Tblerror.count =' || OVPKS.GL_TBLERROR.COUNT);
        L_TMP_OVDTABLE1 := OVPKS.GL_TBLERROR;
        OVPKS.PR_INITERRTBL;
      END IF;
    
      DBG(' p_ty_payoutdets.COUNT INITIALLY =' || P_TY_PAYOUTDETS.COUNT);
      IF P_TY_PAYOUTDETS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
          L_TMP_TY_PAYOUTDETS(I) := P_TY_PAYOUTDETS(I);
          DBG(' Redemption Payout Component =' || P_TY_PAYOUTDETS(I)
              .REDM_PAYOUT_COMP);
          IF P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP = 'P' THEN
            L_TY_PAYOUTDETS(I) := P_TY_PAYOUTDETS(I);
            L_LAST_PRINC_INDEX := I;
          END IF;
        END LOOP;
        DBG(' l_last_princ_index=' || L_LAST_PRINC_INDEX);
        DBG(' l_ty_payoutdets.COUNT =' || L_TY_PAYOUTDETS.COUNT);
        IF L_TY_PAYOUTDETS.COUNT > 0 THEN
          P_TY_PAYOUTDETS.DELETE;
          L_IDX := L_TY_PAYOUTDETS.FIRST;
          WHILE L_IDX IS NOT NULL LOOP
            DBG(' l_idx =' || L_IDX);
            P_TY_PAYOUTDETS(L_IDX) := L_TY_PAYOUTDETS(L_IDX);
            L_IDX := L_TY_PAYOUTDETS.NEXT(L_IDX);
          END LOOP;
        END IF;
      END IF;
      DBG(' p_ty_payoutdets.COUNT2 =' || P_TY_PAYOUTDETS.COUNT);
    
      IF P_TY_PAYOUTDETS.COUNT > 0 THEN
        I := P_TY_PAYOUTDETS.FIRST;
        WHILE I IS NOT NULL LOOP
          DBG('i =' || I);
          DBG('l_last_princ_index=' || L_LAST_PRINC_INDEX);
          IF I = L_LAST_PRINC_INDEX
          
           THEN
            L_REDM_MODE := P_ICDREDMN.REDEMPTION_MODE;
          END IF;
          G_NARRATIVE := P_TY_PAYOUTDETS(I).NARRATIVE;
        
          IF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('B', 'D')
          
           THEN
            DBG('Redemption By is Bank..So calling fn_redby_bc :' ||
                P_BC_PRODCODE);
            RET := FN_REDBY_BC(P_ICDREDMN,
                               P_TY_PAYOUTDETS(I),
                               P_BCPAYOUTDETS_REC,
                               P_BC_PRODCODE,
                               L_REDM_MODE);
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'P' THEN
            DBG('Redemption By is PC..So calling fn_redby_pc');
            RET := FN_REDBY_PC(P_ICDREDMN,
                               P_TY_PAYOUTDETS(I),
                               P_PCPAYOUTDETS_REC,
                               L_REDM_MODE);
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'Y' THEN
            DBG('Redemption By is TD..So calling fn_redby_td');
            RET := FN_REDBY_TD(P_SOURCE,
                               P_ICDREDMN,
                               P_TY_PAYOUTDETS(I),
                               P_TY_STDCUSAC,
                               L_REDM_MODE);
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'S' THEN
            DBG('Redemption By is Savings..So calling fn_redby_savings :' ||
                P_ACC_PRODCODE);
            RET := FN_REDBY_SAVINGS(P_ICDREDMN,
                                    P_TY_PAYOUTDETS(I),
                                    P_ACC_PRODCODE,
                                    L_REDM_MODE);
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE IN ('G', 'L') THEN
            DBG('Redemption By is GL..So calling fn_redby_gl :' ||
                P_GL_PRODCODE);
          
            P_TY_PAYOUTDETS(I).OFFSET_BRN := NVL(P_TY_PAYOUTDETS(I)
                                                 .OFFSET_BRN,
                                                 GLOBAL.CURRENT_BRANCH);
            DBG('p_ty_payoutdets(i).offset_brn :' || P_TY_PAYOUTDETS(I)
                .OFFSET_BRN);
          
            RET := FN_REDBY_GL(P_ICDREDMN,
                               P_TY_PAYOUTDETS(I),
                               P_GL_PRODCODE,
                               L_REDM_MODE);
            DBG('Return from fn_redby_gl ');
          ELSIF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
            DBG('Redemption By is CASH..So calling fn_redby_cash' ||
                P_CASH_PRODCODE);
            RET := FN_REDBY_CASH(P_ICDREDMN,
                                 P_TY_PAYOUTDETS(I),
                                 P_CASH_PRODCODE,
                                 L_REDM_MODE);
            DBG('Return from fn_redby_cash ');
          END IF;
        
          IF NOT RET THEN
            RETURN FALSE;
          END IF;
          I := P_TY_PAYOUTDETS.NEXT(I);
        END LOOP;
      END IF;
    
      DBG(' l_tmp_ty_payoutdets.COUNT =' || L_TMP_TY_PAYOUTDETS.COUNT);
      IF L_TMP_TY_PAYOUTDETS.COUNT > 0 THEN
        L_INDEX1 := L_TMP_TY_PAYOUTDETS.FIRST;
        WHILE L_INDEX1 IS NOT NULL LOOP
          IF L_TMP_TY_PAYOUTDETS(L_INDEX1).REDM_PAYOUT_COMP = 'I' THEN
            P_TY_PAYOUTDETS(L_INDEX1) := L_TMP_TY_PAYOUTDETS(L_INDEX1);
          END IF;
          L_INDEX1 := L_TMP_TY_PAYOUTDETS.NEXT(L_INDEX1);
        END LOOP;
      END IF;
      DBG(' p_ty_payoutdets.COUNT =' || P_TY_PAYOUTDETS.COUNT);
      L_TMP_TY_PAYOUTDETS.DELETE;
      L_TY_PAYOUTDETS.DELETE;
    
      IF L_TMP_OVDTABLE1.COUNT > 0 THEN
        L_TMP_OVDTABLE2 := OVPKS.GL_TBLERROR;
        OVPKS.PR_INITERRTBL;
      
        L_INDEX := L_TMP_OVDTABLE1.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP
          L_COUNT := OVPKS.GL_TBLERROR.COUNT + 1;
          OVPKS.GL_TBLERROR(L_COUNT) := L_TMP_OVDTABLE1(L_INDEX);
          L_INDEX := L_TMP_OVDTABLE1.NEXT(L_INDEX);
        END LOOP;
      
        IF L_TMP_OVDTABLE2.COUNT > 0 THEN
          L_INDEX := L_TMP_OVDTABLE2.FIRST;
          WHILE L_INDEX IS NOT NULL LOOP
            L_COUNT := OVPKS.GL_TBLERROR.COUNT + 1;
            OVPKS.GL_TBLERROR(L_COUNT) := L_TMP_OVDTABLE2(L_INDEX);
            L_INDEX := L_TMP_OVDTABLE2.NEXT(L_INDEX);
          END LOOP;
        END IF;
      
      END IF;
    
    END IF;
    DBG('Returning true');
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                'Y',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
    L_AVL_BAL := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0) +
                 NVL(G_BALREC.ACY_BLOCKED_AMT, 0) +
                 NVL(G_BALREC.ACY_ECA_BLOCKED_AMT, 0);
  
    DBG('l_pay_method got here is ->' || L_PAY_METHOD);
    IF NOT
        STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                    P_ICDREDMN.BRN_CODE) THEN
      IF NVL(L_PAY_METHOD, 'B') <> 'D' THEN
        BEGIN
          BEGIN
            SELECT LIQ1.TO_DATE
              INTO L_TO_DATE
              FROM ICTBS_INT_LIQ_DETAILS LIQ1
             WHERE LIQ1.ACCOUNT_NUMBER = P_ICDREDMN.AC_NO
               AND LIQ1.BRANCH_CODE = P_ICDREDMN.BRN_CODE
               AND LIQ1.TO_DATE =
                   (SELECT MAX(TO_DATE)
                      FROM ICTBS_INT_LIQ_DETAILS LIQ2
                     WHERE LIQ2.ACCOUNT_NUMBER = P_ICDREDMN.AC_NO
                       AND LIQ2.BRANCH_CODE = P_ICDREDMN.BRN_CODE);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_TO_DATE      := GLOBAL.APPLICATION_DATE;
              L_FIRST_INSERT := 'Y';
          END;
          IF L_TO_DATE < GLOBAL.APPLICATION_DATE OR L_FIRST_INSERT = 'Y' THEN
            INSERT INTO ICTBS_INT_LIQ_DETAILS
              (BRANCH_CODE, ACCOUNT_NUMBER, FROM_DATE, TO_DATE, LIQ_AMT)
            VALUES
              (P_ICDREDMN.BRN_CODE,
               P_ICDREDMN.AC_NO,
               GLOBAL.APPLICATION_DATE - 1,
               GLOBAL.APPLICATION_DATE,
               L_AVL_BAL);
            DBG('33333333');
          ELSE
            DBG('Inside Else');
            UPDATE ICTBS_INT_LIQ_DETAILS
               SET LIQ_AMT = L_AVL_BAL
             WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
               AND ACCOUNT_NUMBER = P_ICDREDMN.AC_NO
               AND TO_DATE = L_TO_DATE;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Inside w-o-f1' || SQLERRM);
        END;
      END IF;
    END IF;
  
    CSPKS_UPLOAD.PR_INIT(NVL(PKG_SOURCE, 'FLEXCUBE'), 'ICDREDMN');
    IF NOT CSPKSS_UPLOAD.FN_WHAT_TO_DO(NVL(PKG_SOURCE, 'FLEXCUBE'),
                                       NVL(PKG_MODULE, 'RT'),
                                       L_WHAT_TO_DO,
                                       L_AUTH_STATUS,
                                       L_ERR_CODE,
                                       L_ERR_PARAM) THEN
      DBG('cspkss_upload.fn_what_to_do returned FALSE');
      RETURN FALSE;
    END IF;
    DBG('l_what_to_do:' || L_WHAT_TO_DO);
    DBG('l_auth_status:' || L_AUTH_STATUS);
    IF L_WHAT_TO_DO = 'R' THEN
      DBG('Failure From fn_upload_payoutdets');
      RETURN FALSE;
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                                          P_ICDREDMN,
                                                          P_TY_PAYOUTDETS,
                                                          P_BCPAYOUTDETS_REC,
                                                          P_PCPAYOUTDETS_REC,
                                                          P_TY_STDCUSAC,
                                                          P_BC_PRODCODE,
                                                          P_ACC_PRODCODE,
                                                          P_GL_PRODCODE,
                                                          P_CASH_PRODCODE,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA) THEN
        DBG('Failed in call 4 to icpks_fcj_icdredmn_cluster.fn_upload_payoutdets');
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  END FN_UPLOAD_PAYOUTDETS;

  FUNCTION FN_DEFAULT_PAYOUT_CHGDETS(P_PAYOUT_CHGDETS IN OUT GWPKS_TDREDEMPTION.TY_PAYOUT_CHGDTLS,
                                     P_REFNO          IN VARCHAR2)
  
   RETURN BOOLEAN IS
  
    L_ARC_MAINT    IFTMS_ARC_MAINT%ROWTYPE;
    L_ERR_CODE     ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM    ERTBS_MSGS.MESSAGE%TYPE;
    L_ACTUAL_COUNT NUMBER := 0;
    L_TBL_CHGDETS  TBL_CHGDETS;
    L_ROW_FOUND    BOOLEAN := FALSE;
  BEGIN
    DBG('Inside Fn_Default_Payout_Chgdets');
    DBG('p_payout_chgdets.count ' || P_PAYOUT_CHGDETS.COUNT);
  
    DEPKS_RTL_TELLER.PKG_CHG_DETS := NULL;
    GWPKS_UTIL.PKG_CHG_DETS       := NULL;
    GWPKS_UTIL.PKG_TEMP_CHG_DETS  := NULL;
  
    IF P_PAYOUT_CHGDETS.COUNT > 0 THEN
      FOR L_ROW IN 1 .. P_PAYOUT_CHGDETS.COUNT LOOP
        IF P_REFNO = P_PAYOUT_CHGDETS(L_ROW).TRN_REF_NO THEN
          IF NVL(P_PAYOUT_CHGDETS(L_ROW).WAIVER, 'N') = 'N' THEN
            GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || P_PAYOUT_CHGDETS(L_ROW)
                                      .CHG_CCY || '~' || P_PAYOUT_CHGDETS(L_ROW)
                                      .CHG_AMT || '~';
          ELSE
            GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || P_PAYOUT_CHGDETS(L_ROW)
                                      .CHG_CCY || '~' || '0' || '~';
          END IF;
        
          DBG('The charge amount is zero:::' || P_PAYOUT_CHGDETS(L_ROW)
              .CHG_AMT);
          DBG('p_payout_chgdets(l_Row).waiver--> ' || P_PAYOUT_CHGDETS(L_ROW)
              .WAIVER);
          IF (P_PAYOUT_CHGDETS(L_ROW)
             .CHG_AMT = 0 AND P_PAYOUT_CHGDETS(L_ROW).WAIVER = 'N') THEN
            DBG('Setting waiver as Y when charge amount is 0..');
            P_PAYOUT_CHGDETS(L_ROW).WAIVER := 'Y';
            DBG('The waiver is set to Y:::' || P_PAYOUT_CHGDETS(L_ROW)
                .WAIVER);
          END IF;
        
          DEPKS_RTL_TELLER.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS;
          GWPKS_UTIL.PKG_TEMP_CHG_DETS  := GWPKS_UTIL.PKG_TEMP_CHG_DETS || P_PAYOUT_CHGDETS(L_ROW)
                                          .WAIVER || '~' || P_PAYOUT_CHGDETS(L_ROW)
                                          .CHG_CCY || '~' || P_PAYOUT_CHGDETS(L_ROW)
                                          .CHG_AMT || '~' || '~' || '~' || '~~';
        END IF;
      END LOOP;
    END IF;
  
    DBG('Gwpks_Util.Pkg_Chg_Dets ' || GWPKS_UTIL.PKG_CHG_DETS);
    DBG('Depks_Rtl_Teller.pkg_chg_dets ' || DEPKS_RTL_TELLER.PKG_CHG_DETS);
    DBG('>> Gwpks_Util.Pkg_Temp_Chg_Dets: ' ||
        GWPKS_UTIL.PKG_TEMP_CHG_DETS);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception caught in Fn_Default_Payout_Chgdets with : ' ||
          SQLCODE || ':' || SQLERRM);
      OVPKSS.PR_APPENDTBL('GW-RTL-003', NULL);
      RETURN FALSE;
  END FN_DEFAULT_PAYOUT_CHGDETS;

  FUNCTION FN_DEFAULT_CHGDETS(P_TBL_CHGDETS IN OUT TBL_CHGDETS)
  
   RETURN BOOLEAN IS
  
    L_ARC_MAINT    IFTMS_ARC_MAINT%ROWTYPE;
    L_ERR_CODE     ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM    ERTBS_MSGS.MESSAGE%TYPE;
    L_ACTUAL_COUNT NUMBER := 0;
    L_TBL_CHGDETS  TBL_CHGDETS;
    L_ROW_FOUND    BOOLEAN := FALSE;
  BEGIN
    DBG('Inside fn_default_chgdets');
  
    DBG('p_tbl_chgdets.count ' || P_TBL_CHGDETS.COUNT);
  
    IF P_TBL_CHGDETS.COUNT > 0 THEN
      FOR L_ROW IN 1 .. P_TBL_CHGDETS.COUNT LOOP
        IF NVL(P_TBL_CHGDETS(L_ROW).WAIVER, 'N') = 'N' THEN
        
          GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || P_TBL_CHGDETS(L_ROW)
                                    .COD_CHG_CCY || '~' || P_TBL_CHGDETS(L_ROW)
                                    .CHG_AMT || '~';
        ELSE
        
          GWPKS_UTIL.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS || P_TBL_CHGDETS(L_ROW)
                                    .COD_CHG_CCY || '~' || '0' || '~';
        END IF;
      
        DEPKS_RTL_TELLER.PKG_CHG_DETS := GWPKS_UTIL.PKG_CHG_DETS;
      
        GWPKS_UTIL.PKG_TEMP_CHG_DETS := GWPKS_UTIL.PKG_TEMP_CHG_DETS || P_TBL_CHGDETS(L_ROW)
                                       .WAIVER || '~' || P_TBL_CHGDETS(L_ROW)
                                       .COD_CHG_CCY || '~' || P_TBL_CHGDETS(L_ROW)
                                       .CHG_AMT || '~' || '~' || '~' || '~~';
      END LOOP;
    END IF;
  
    DBG('Depks_Iface.pkg_chg_dets ' || GWPKS_UTIL.PKG_CHG_DETS);
    DBG('Depks_Rtl_Teller.pkg_chg_dets ' || DEPKS_RTL_TELLER.PKG_CHG_DETS);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception caught in fn_default_chgdets with : ' || SQLCODE || ':' ||
          SQLERRM);
      OVPKSS.PR_APPENDTBL('GW-RTL-003', NULL);
    
      RETURN FALSE;
    
  END FN_DEFAULT_CHGDETS;

  FUNCTION FN_PICKUP_SUBSYSTEMS(P_ICDREDMN     IN TDVWS_TD_REDEMPTION%ROWTYPE,
                                P_TBL_CHGDETS  IN OUT TBL_CHGDETS,
                                P_UPL_MIS_DET  IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                                P_UPL_UDF_DET  IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                P_TBL_NODE_REC IN TBL_NODE,
                                P_PRODUCT      IN VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE  VARCHAR2(200);
    L_ERR_PARAM VARCHAR2(2000);
  
  BEGIN
  
    DBG('Inside fn_pickup_subsystems.............');
    IF P_TBL_NODE_REC.EXISTS('Mis-Details') THEN
    
      DBG('Calling MIS Referral...');
      IF NOT MIPKSS_REFERRAL.FN_GET_CON_DEFAULT(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.FCCREF,
                                                NULL,
                                                NULL) THEN
        DBG('mipkss_referral.fn_get_con_default');
        OVPKS.PR_APPENDTBL('TD-RED-15', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_TBL_NODE_REC.EXISTS('Udf-Details') THEN
      DBG('Pickup UDFDETAILS');
      DBG('Calling UDF Defaulting...');
    
      IF NOT UVPKSS_SERVICES.FN_DEFAULT_FROM_PRODUCT(P_ICDREDMN.FCCREF,
                                                     1,
                                                     P_PRODUCT,
                                                     L_ERR_CODE,
                                                     L_ERR_PARAM) THEN
        DBG('uvpkss_services.fn_default_from_product');
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    
      IF NOT UVPKSS_UDF_UPLOAD.FN_PICKUP_CONT_UDF(P_ICDREDMN.FCCREF,
                                                  'RT',
                                                  P_PRODUCT,
                                                  L_ERR_CODE,
                                                  L_ERR_PARAM) THEN
        DBG('uvpkss_services.fn_default_from_product');
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Successfully fn_validate_subsystems.......');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in function fn_upload with error : ' || SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', NULL);
      RETURN FALSE;
  END FN_PICKUP_SUBSYSTEMS;

  FUNCTION FN_UPLOAD_SUBSYSTEMS(P_ICDREDMN     IN TDVWS_TD_REDEMPTION%ROWTYPE,
                                P_TBL_CHGDETS  IN OUT TBL_CHGDETS,
                                P_UPL_MIS_DET  IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                                P_UPL_UDF_DET  IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                P_TBL_NODE_REC IN TBL_NODE,
                                P_PRODUCT      IN VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE  VARCHAR2(200);
    L_ERR_PARAM VARCHAR2(2000);
  
  BEGIN
    DBG('Inside fn_upload_subsystems.............');
  
    IF NOT FN_PICKUP_SUBSYSTEMS(P_ICDREDMN,
                                P_TBL_CHGDETS,
                                P_UPL_MIS_DET,
                                P_UPL_UDF_DET,
                                P_TBL_NODE_REC,
                                P_PRODUCT) THEN
    
      DBG('error...');
    END IF;
  
    IF P_TBL_NODE_REC.EXISTS('Mis-Details') THEN
    
      DBG('Uploading Mis-Details');
    
      DBG('p_upl_mis_det.COMPMIS1' || P_UPL_MIS_DET.COMP_MIS_1);
      DBG('p_upl_mis_det.COMPMIS2' || P_UPL_MIS_DET.COMP_MIS_2);
      DBG('p_upl_mis_det.Costcod1' || P_UPL_MIS_DET.COST_CODE1);
      DBG('p_upl_mis_det.Costcod2' || P_UPL_MIS_DET.COST_CODE2);
      IF NOT
          MIPKS_VALIDATE.FN_MIS_UPLOAD_TYPE(P_UPL_MIS_DET, P_ICDREDMN.FCCREF) THEN
        DBG('Falied in Uvpks_udf_upload.fn_Contract_Udf_Upload_Type');
        OVPKS.PR_APPENDTBL('TD-RED-16', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_TBL_NODE_REC.EXISTS('Udf-Details') AND
       NVL(GWPKS_UTIL.PKG_ACTTYPE, '***') IN ('SAVEAUTOAUTH') THEN
    
      DBG('Uploading Udfdetails');
      DBG('Calling Uvpks_udf_upload.fn_Contract_Udf_Upload_Type for UDF Upload..');
      DBG('product code' || P_PRODUCT);
      IF NOT UVPKSS_UDF_UPLOAD.FN_CONTRACT_UDF_UPLOAD_TYPE('GWCRTRT',
                                                           P_ICDREDMN.XREF,
                                                           P_ICDREDMN.FCCREF,
                                                           1,
                                                           P_PRODUCT,
                                                           'NEW',
                                                           P_UPL_UDF_DET,
                                                           L_ERR_CODE,
                                                           L_ERR_PARAM) THEN
        DBG('Falied in Uvpks_udf_upload.fn_Contract_Udf_Upload_Type');
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Successfully fn_upload_subsystems.......');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in function fn_upload with error : ' || SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', NULL);
      RETURN FALSE;
  END FN_UPLOAD_SUBSYSTEMS;

  FUNCTION FN_VALIDATE_SUBSYSTEMS(P_ICDREDMN    IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                  P_TBL_NODE    IN TBL_NODE,
                                  P_TBL_CHGDETS IN OUT TBL_CHGDETS,
                                  P_UPL_MIS_DET IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                                  P_UPL_UDF_DET IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                  L_PRODUCT     IN VARCHAR2)
  
   RETURN BOOLEAN IS
  
    L_TXN_CCY VARCHAR2(3);
  
    L_ERR_CODE  VARCHAR2(200);
    L_ERR_PARAM VARCHAR2(2000);
  
  BEGIN
  
    DBG('INSIDE fn_validate_subsystems');
    DBG('p_icdredmn.SAVINGS_TXN_CCY' || P_ICDREDMN.SAVINGS_TXN_CCY);
    DBG('p_icdredmn.GL_TXN_CCY' || P_ICDREDMN.GL_TXN_CCY);
    DBG('p_icdredmn.xref' || P_ICDREDMN.XREF);
  
    IF P_ICDREDMN.REDEMPTION_BY = 'S' THEN
    
      L_TXN_CCY := P_ICDREDMN.SAVINGS_TXN_CCY;
    
    ELSIF P_ICDREDMN.REDEMPTION_BY IN ('G', 'C') THEN
    
      L_TXN_CCY := P_ICDREDMN.GL_TXN_CCY;
    
    END IF;
  
    IF P_TBL_NODE.EXISTS('Mis-Details') THEN
    
      DBG('PRODUCT CODE' || L_PRODUCT);
    
    END IF;
  
    DBG('GOING HERE THE CONTROL FLOW');
    IF P_TBL_NODE.EXISTS('Udf-Details') THEN
      DBG('INSIDE Udf-Details');
      DBG('PRODUCT CODE' || L_PRODUCT);
      IF NOT UVPKSS_UDF_UPLOAD.FN_VALIDATE_CONTRACT_UDF(P_UPL_UDF_DET,
                                                        L_PRODUCT,
                                                        'NEW',
                                                        L_ERR_CODE,
                                                        L_ERR_PARAM) THEN
        DBG('Falied in UDF Validation in Uvpks_udf_upload.fn_Validate_Contract_Udf');
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    END IF;
    DBG('SUCESSFULLY CAME OUT....');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in fn_validate_subsystems ' || SQLERRM);
      OVPKSS.PR_APPENDTBL('ST-OTHR-001', NULL);
      RETURN FALSE;
    
  END FN_VALIDATE_SUBSYSTEMS;

  FUNCTION FN_QUERY_REDEMPTION_MASTER(P_ICDREDMN   IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                      P_ERR_CODE   IN OUT VARCHAR2,
                                      P_ERR_PARAMS IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
  BEGIN
    DBG('Inside fn_query_redemption_master...');
    SELECT REDEM_REF_NO,
           BRANCH_CODE,
           ACC_NO,
           CUST_ID,
           ACC_DESC,
           ACC_AMT,
           ACTION_FLAG,
           TENOR_DD,
           TENOR_MM,
           TENOR_YY,
           NEXT_MAT_DATE,
           REDEMPTION_BY,
           CCY,
           REDEMPTION_MODE,
           REDEMPTION_AMT,
           WAVE_PENALTY,
           BANK_CD,
           BANK_TXN_CCY,
           BANK_EXCH_RATE,
           BANK_TXN_AMT,
           CHQ_DATE,
           CHARGES,
           BENEF_NAME,
           PASSPORT_NO,
           ADDR1,
           ADDR2,
           BANK_NARRATIVE,
           SAVINGS_BRN_CODE,
           SAVINGS_ACC_NO,
           SAVINGS_TXN_CCY,
           SAVINGS_EXCH_RATE,
           SAVINGS_TXN_AMT,
           SAVINGS_NARRATIVE,
           GL_NO,
           GL_TXN_CCY,
           GL_EXCH_RATE,
           GL_TXN_AMT,
           GL_NARRATIVE,
           SCODE,
           XREF,
           FCCREF,
           PAYBRN,
           MICR_NO,
           ADDR3,
           TRN_DT,
           BANK_CTRY_CODE,
           WAIVE_INTEREST,
           GL_BRANCH,
           ALLOW_PREPAYMENT,
           SUPPRESS_REDEMPTION_ADVICE,
           
           MAKER_ID,
           CHECKER_ID,
           MAKER_DT_STAMP,
           CHECKER_DT_STAMP,
           AUTH_STATUS,
           CONTRACT_STATUS,
           PRODUCT_CODE,
           INTRATE_CUMAMT_REQD,
           ADD_FUNDS,
           ADDITIONAL_AMT,
           REDEM_INT_PAYOUT
      INTO P_ICDREDMN.REDEM_REF_NO,
           P_ICDREDMN.BRN_CODE,
           P_ICDREDMN.AC_NO,
           P_ICDREDMN.CUST_ID,
           P_ICDREDMN.ACC_DESC,
           P_ICDREDMN.ACC_AMT,
           P_ICDREDMN.ACTION_FLAG,
           P_ICDREDMN.TENOR_DD,
           P_ICDREDMN.TENOR_MM,
           P_ICDREDMN.TENOR_YY,
           P_ICDREDMN.NEXT_MAT_DATE,
           P_ICDREDMN.REDEMPTION_BY,
           P_ICDREDMN.CCY,
           P_ICDREDMN.REDEMPTION_MODE,
           P_ICDREDMN.REDEMPTION_AMT,
           P_ICDREDMN.WAVE_PENALTY,
           P_ICDREDMN.BANK_CD,
           P_ICDREDMN.BANK_TXN_CCY,
           P_ICDREDMN.BANK_EXCH_RATE,
           P_ICDREDMN.BANK_TXN_AMT,
           P_ICDREDMN.CHQ_DATE,
           P_ICDREDMN.CHARGES,
           P_ICDREDMN.BENEF_NAME,
           P_ICDREDMN.PASSPORT_NO,
           P_ICDREDMN.ADDR1,
           P_ICDREDMN.ADDR2,
           P_ICDREDMN.BANK_NARRATIVE,
           P_ICDREDMN.SAVINGS_BRN_CODE,
           P_ICDREDMN.SAVINGS_ACC_NO,
           P_ICDREDMN.SAVINGS_TXN_CCY,
           P_ICDREDMN.SAVINGS_EXCH_RATE,
           P_ICDREDMN.SAVINGS_TXN_AMT,
           P_ICDREDMN.SAVINGS_NARRATIVE,
           P_ICDREDMN.GL_NO,
           P_ICDREDMN.GL_TXN_CCY,
           P_ICDREDMN.GL_EXCH_RATE,
           P_ICDREDMN.GL_TXN_AMT,
           P_ICDREDMN.GL_NARRATIVE,
           P_ICDREDMN.SCODE,
           P_ICDREDMN.XREF,
           P_ICDREDMN.FCCREF,
           P_ICDREDMN.PAYBRN,
           P_ICDREDMN.MICR_NO,
           P_ICDREDMN.ADDR3,
           P_ICDREDMN.TRN_DT,
           P_ICDREDMN.BANK_CTRY_CODE,
           P_ICDREDMN.WAIVE_INTEREST,
           P_ICDREDMN.GL_BRANCH,
           P_ICDREDMN.ALLOW_PREPAYMENT,
           P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE,
           
           P_ICDREDMN.MAKERID,
           P_ICDREDMN.CHECKERID,
           P_ICDREDMN.MAKERSTAMP,
           P_ICDREDMN.CHECKERSTAMP,
           P_ICDREDMN.AUTHSTAT,
           P_ICDREDMN.PRODUCT_CODE,
           P_ICDREDMN.CONTSTAT,
           P_ICDREDMN.INTRATE_CUMAMT_REQD,
           P_ICDREDMN.ADD_FUNDS,
           P_ICDREDMN.ADDITIONAL_AMT,
           P_ICDREDMN.REDEM_INT_PAYOUT
      FROM ICTB_TDREDEMPTION_MASTER
     WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('Invalid Redemption Reference Number...');
      P_ERR_CODE   := 'IC-REDMN-08';
      P_ERR_PARAMS := P_ICDREDMN.REDEM_REF_NO || '~';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_QUERY_REDEMPTION_MASTER;

  FUNCTION FN_QUERY_REDEMPTION_TBLS(P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                    P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                    P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                    P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                    P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
    L_CNT NUMBER;
  
    CURSOR C_ICTM_TDREDMPAYOUT_DETAILS IS
      SELECT *
        FROM ICTM_TDREDMPAYOUT_DETAILS
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
    CURSOR C_ICTB_REDEM_ACC_PR IS
      SELECT BRN,
             ACC,
             PROD,
             WAIVE,
             GEN_UCA,
             RECORD_STAT,
             ONCE_AUTH,
             UDE_CCY,
             MIN_AMT,
             MAX_AMT,
             FREE_TXN,
             CONT_VAR_ROLL
        FROM ICTB_REDEM_ACC_PR
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
    CURSOR C_ICTB_REDEM_ACC_EFFDT IS
      SELECT BRN, ACC, PROD, UDE_EFF_DT, RECORD_STAT, ONCE_AUTH
        FROM ICTB_REDEM_ACC_EFFDT
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
    CURSOR C_ICTB_REDEM_ACC_UDEVALS IS
      SELECT BRN,
             ACC,
             PROD,
             UDE_EFF_DT,
             UDE_ID,
             UDE_VALUE,
             RATE_CODE,
             AUTH_STAT,
             RECORD_STAT,
             BASE_RATE,
             BASE_SPREAD,
             TD_RATE_CODE,
             UDE_VARIANCE
        FROM ICTB_REDEM_ACC_UDEVALS
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
    CURSOR C_ICTB_REDEM_CHILDTDPAYOUT IS
      SELECT BRN,
             ACC,
             CCY,
             PAYOUTTYPE,
             BANKCODE,
             OFFSET_BRN,
             OFFSET_ACC,
             OFFSET_CCY,
             PERCENTAGE,
             REDMAMT,
             BENFNAME,
             BENFADD1,
             BENFADD2,
             OTHERDETS,
             NARRATIVE,
             XRATE,
             REF_NO,
             SEQNO,
             PAYOUT_COMPONENT,
             '',
             ''
        FROM ICTB_REDEM_CHILDTDPAYOUT
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
    CURSOR C_ICTM_TDREDPAYIN_DETAILS IS
      SELECT *
        FROM ICTM_TDREDPAYIN_DETAILS
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
  
  BEGIN
    DBG('p_icdredmn.redem_ref_no ---> ' || P_ICDREDMN.REDEM_REF_NO);
  
    DBG('Going to query ictb_tdredemption_master...');
    IF P_ICDREDMN.REDEM_REF_NO IS NOT NULL THEN
      BEGIN
        SELECT REDEM_REF_NO,
               BRANCH_CODE,
               ACC_NO,
               CUST_ID,
               ACC_DESC,
               ACC_AMT,
               ACTION_FLAG,
               TENOR_DD,
               TENOR_MM,
               TENOR_YY,
               NEXT_MAT_DATE,
               REDEMPTION_BY,
               CCY,
               REDEMPTION_MODE,
               REDEMPTION_AMT,
               WAVE_PENALTY,
               BANK_CD,
               BANK_TXN_CCY,
               BANK_EXCH_RATE,
               BANK_TXN_AMT,
               CHQ_DATE,
               CHARGES,
               BENEF_NAME,
               PASSPORT_NO,
               ADDR1,
               ADDR2,
               BANK_NARRATIVE,
               SAVINGS_BRN_CODE,
               SAVINGS_ACC_NO,
               SAVINGS_TXN_CCY,
               SAVINGS_EXCH_RATE,
               SAVINGS_TXN_AMT,
               SAVINGS_NARRATIVE,
               GL_NO,
               GL_TXN_CCY,
               GL_EXCH_RATE,
               GL_TXN_AMT,
               GL_NARRATIVE,
               SCODE,
               XREF,
               FCCREF,
               PAYBRN,
               MICR_NO,
               ADDR3,
               TRN_DT,
               BANK_CTRY_CODE,
               WAIVE_INTEREST,
               GL_BRANCH,
               ALLOW_PREPAYMENT,
               SUPPRESS_REDEMPTION_ADVICE,
               
               MAKER_ID,
               CHECKER_ID,
               MAKER_DT_STAMP,
               CHECKER_DT_STAMP,
               AUTH_STATUS,
               CONTRACT_STATUS,
               INTEREST_RATE,
               MATURITY_AMOUNT,
               PRODUCT_CODE,
               INTRATE_CUMAMT_REQD,
               ADD_FUNDS,
               ADDITIONAL_AMT,
               REDEM_INT_PAYOUT
          INTO P_ICDREDMN.REDEM_REF_NO,
               P_ICDREDMN.BRN_CODE,
               P_ICDREDMN.AC_NO,
               P_ICDREDMN.CUST_ID,
               P_ICDREDMN.ACC_DESC,
               P_ICDREDMN.ACC_AMT,
               P_ICDREDMN.ACTION_FLAG,
               P_ICDREDMN.TENOR_DD,
               P_ICDREDMN.TENOR_MM,
               P_ICDREDMN.TENOR_YY,
               P_ICDREDMN.NEXT_MAT_DATE,
               P_ICDREDMN.REDEMPTION_BY,
               P_ICDREDMN.CCY,
               P_ICDREDMN.REDEMPTION_MODE,
               P_ICDREDMN.REDEMPTION_AMT,
               P_ICDREDMN.WAVE_PENALTY,
               P_ICDREDMN.BANK_CD,
               P_ICDREDMN.BANK_TXN_CCY,
               P_ICDREDMN.BANK_EXCH_RATE,
               P_ICDREDMN.BANK_TXN_AMT,
               P_ICDREDMN.CHQ_DATE,
               P_ICDREDMN.CHARGES,
               P_ICDREDMN.BENEF_NAME,
               P_ICDREDMN.PASSPORT_NO,
               P_ICDREDMN.ADDR1,
               P_ICDREDMN.ADDR2,
               P_ICDREDMN.BANK_NARRATIVE,
               P_ICDREDMN.SAVINGS_BRN_CODE,
               P_ICDREDMN.SAVINGS_ACC_NO,
               P_ICDREDMN.SAVINGS_TXN_CCY,
               P_ICDREDMN.SAVINGS_EXCH_RATE,
               P_ICDREDMN.SAVINGS_TXN_AMT,
               P_ICDREDMN.SAVINGS_NARRATIVE,
               P_ICDREDMN.GL_NO,
               P_ICDREDMN.GL_TXN_CCY,
               P_ICDREDMN.GL_EXCH_RATE,
               P_ICDREDMN.GL_TXN_AMT,
               P_ICDREDMN.GL_NARRATIVE,
               P_ICDREDMN.SCODE,
               P_ICDREDMN.XREF,
               P_ICDREDMN.FCCREF,
               P_ICDREDMN.PAYBRN,
               P_ICDREDMN.MICR_NO,
               P_ICDREDMN.ADDR3,
               P_ICDREDMN.TRN_DT,
               P_ICDREDMN.BANK_CTRY_CODE,
               P_ICDREDMN.WAIVE_INTEREST,
               P_ICDREDMN.GL_BRANCH,
               P_ICDREDMN.ALLOW_PREPAYMENT,
               P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE,
               
               P_ICDREDMN.MAKERID,
               P_ICDREDMN.CHECKERID,
               P_ICDREDMN.MAKERSTAMP,
               P_ICDREDMN.CHECKERSTAMP,
               P_ICDREDMN.AUTHSTAT,
               P_ICDREDMN.CONTSTAT,
               P_ICDREDMN.INTEREST_RATE,
               P_ICDREDMN.MATURITY_AMOUNT,
               P_ICDREDMN.PRODUCT_CODE,
               P_ICDREDMN.INTRATE_CUMAMT_REQD,
               P_ICDREDMN.ADD_FUNDS,
               P_ICDREDMN.ADDITIONAL_AMT,
               P_ICDREDMN.REDEM_INT_PAYOUT
          FROM ICTB_TDREDEMPTION_MASTER
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Invalid Redemption Reference Number...');
          P_ERR_CODE   := 'IC-REDMN-08';
          P_ERR_PARAMS := P_ICDREDMN.REDEM_REF_NO || '~';
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
      END;
    
      IF P_ICDREDMN.ACTION_FLAG <> 'T' THEN
        BEGIN
          SELECT TD_AMOUNT
            INTO P_ICDREDMN.PRINCIPAL_AMOUNT
            FROM ICTM_TD_DETAILS
           WHERE ACC = P_ICDREDMN.AC_NO
             AND BRN = P_ICDREDMN.BRN_CODE;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in ICTM_TD_DEATILS Query');
        END;
      END IF;
    
      DBG('Going to query ictm_tdredmpayout_details...');
      IF C_ICTM_TDREDMPAYOUT_DETAILS%ISOPEN THEN
        CLOSE C_ICTM_TDREDMPAYOUT_DETAILS;
      END IF;
    
      OPEN C_ICTM_TDREDMPAYOUT_DETAILS;
      FETCH C_ICTM_TDREDMPAYOUT_DETAILS BULK COLLECT
        INTO P_TY_PAYOUTDETS;
      CLOSE C_ICTM_TDREDMPAYOUT_DETAILS;
      DBG('Number of Records queried...: ' || P_TY_PAYOUTDETS.COUNT);
    
      DBG('Going to query ictm_tdredpayin_details...');
      IF C_ICTM_TDREDPAYIN_DETAILS%ISOPEN THEN
        CLOSE C_ICTM_TDREDPAYIN_DETAILS;
      END IF;
    
      OPEN C_ICTM_TDREDPAYIN_DETAILS;
      FETCH C_ICTM_TDREDPAYIN_DETAILS BULK COLLECT
        INTO G_TY_TB_ADDNAPYIN;
      CLOSE C_ICTM_TDREDPAYIN_DETAILS;
      DBG('Number of Records queried...: ' || G_TY_TB_ADDNAPYIN.COUNT);
    
      DBG('Going to query ictb_redem_by_td...');
      BEGIN
        SELECT BRANCH_CODE,
               CUST_AC_NO,
               AC_DESC,
               CUST_NO,
               CCY,
               ACCOUNT_CLASS,
               ACCOUNT_TYPE,
               JOINT_AC_INDICATOR,
               AC_OPEN_DATE,
               ALT_AC_NO,
               DR_GL,
               CR_GL
        
          INTO P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL,
               P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL
        
          FROM ICTB_REDEM_BY_TD
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_by_td...' || SQLCODE || SQLERRM);
      END;
    
      DBG('Going to query ictb_redem_by_pc...');
      BEGIN
        SELECT BRN,
               ACC,
               CCY,
               PCBANKCODE,
               PCOFFSET_BRN,
               PCOFFSET_ACC,
               PCOFFSET_CCY,
               BENFNAME,
               BENFADD1,
               BENFADD2,
               OTHERDETS,
               NARRATIVE,
               CUSTBANKCODE,
               CUSTACCNO,
               CGNEWTWORKCODE,
               TXNCCY,
               TXNAMT,
               XRATE,
               REFNO,
               PCPERCENTAGE
          INTO P_PCPAYOUTDETS_REC.BRN,
               P_PCPAYOUTDETS_REC.ACC,
               P_PCPAYOUTDETS_REC.CCY,
               P_PCPAYOUTDETS_REC.PCBANKCODE,
               P_PCPAYOUTDETS_REC.PCOFFSET_BRN,
               P_PCPAYOUTDETS_REC.PCOFFSET_ACC,
               P_PCPAYOUTDETS_REC.PCOFFSET_CCY,
               P_PCPAYOUTDETS_REC.BENFNAME,
               P_PCPAYOUTDETS_REC.BENFADD1,
               P_PCPAYOUTDETS_REC.BENFADD2,
               P_PCPAYOUTDETS_REC.OTHERDETS,
               P_PCPAYOUTDETS_REC.NARRATIVE,
               P_PCPAYOUTDETS_REC.CUSTBANKCODE,
               P_PCPAYOUTDETS_REC.CUSTACCNO,
               P_PCPAYOUTDETS_REC.CGNEWTWORKCODE,
               P_PCPAYOUTDETS_REC.TXNCCY,
               P_PCPAYOUTDETS_REC.TXNAMT,
               P_PCPAYOUTDETS_REC.XRATE,
               P_PCPAYOUTDETS_REC.REFNO,
               P_PCPAYOUTDETS_REC.PCPERCENTAGE
          FROM ICTB_REDEM_BY_PC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_by_pc...' || SQLCODE || SQLERRM);
      END;
    
      DBG('Going to query ictb_redem_by_bc...');
      BEGIN
        SELECT BRN,
               ACC,
               CCY,
               REF_NO,
               SCODE,
               XREF,
               MICR_NO,
               TRN_DT,
               BANKCODE,
               CHQ_AMT,
               CHQ_CCY,
               CHQ_DATE,
               XRATE,
               PAYBRN,
               WAVE_PENALTY,
               CHARGES,
               BENFNAME,
               BENFADD1,
               BENFADD2,
               BENFADD3,
               OTHERDETS,
               NARRATIVE,
               COUNTRY_CODE,
               CHQ_PERCENT
          INTO P_BCPAYOUTDETS_REC.BRN,
               P_BCPAYOUTDETS_REC.ACC,
               P_BCPAYOUTDETS_REC.CCY,
               P_BCPAYOUTDETS_REC.REF_NO,
               P_BCPAYOUTDETS_REC.SCODE,
               P_BCPAYOUTDETS_REC.XREF,
               P_BCPAYOUTDETS_REC.MICR_NO,
               P_BCPAYOUTDETS_REC.TRN_DT,
               P_BCPAYOUTDETS_REC.BANKCODE,
               P_BCPAYOUTDETS_REC.CHQ_AMT,
               P_BCPAYOUTDETS_REC.CHQ_CCY,
               P_BCPAYOUTDETS_REC.CHQ_DATE,
               P_BCPAYOUTDETS_REC.XRATE,
               P_BCPAYOUTDETS_REC.PAYBRN,
               P_BCPAYOUTDETS_REC.WAVE_PENALTY,
               P_BCPAYOUTDETS_REC.CHARGES,
               P_BCPAYOUTDETS_REC.BENFNAME,
               P_BCPAYOUTDETS_REC.BENFADD1,
               P_BCPAYOUTDETS_REC.BENFADD2,
               P_BCPAYOUTDETS_REC.BENFADD3,
               P_BCPAYOUTDETS_REC.OTHERDETS,
               P_BCPAYOUTDETS_REC.NARRATIVE,
               P_BCPAYOUTDETS_REC.COUNTRY_CODE,
               P_BCPAYOUTDETS_REC.CHQ_PERCENT
          FROM ICTB_REDEM_BY_BC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_by_bc...' || SQLCODE || SQLERRM);
      END;
    
      BEGIN
        SELECT BRN,
               ACC,
               CCY,
               REF_NO,
               SCODE,
               XREF,
               MICR_NO,
               TRN_DT,
               BANKCODE,
               CHQ_AMT,
               CHQ_CCY,
               CHQ_DATE,
               XRATE,
               PAYBRN,
               WAVE_PENALTY,
               CHARGES,
               BENFNAME,
               BENFADD1,
               BENFADD2,
               BENFADD3,
               OTHERDETS,
               NARRATIVE,
               COUNTRY_CODE,
               CHQ_PERCENT
          INTO P_BCPAYOUTDETS_REC.BRN,
               P_BCPAYOUTDETS_REC.ACC,
               P_BCPAYOUTDETS_REC.CCY,
               P_BCPAYOUTDETS_REC.REF_NO,
               P_BCPAYOUTDETS_REC.SCODE,
               P_BCPAYOUTDETS_REC.XREF,
               P_BCPAYOUTDETS_REC.MICR_NO,
               P_BCPAYOUTDETS_REC.TRN_DT,
               P_BCPAYOUTDETS_REC.BANKCODE,
               P_BCPAYOUTDETS_REC.CHQ_AMT,
               P_BCPAYOUTDETS_REC.CHQ_CCY,
               P_BCPAYOUTDETS_REC.CHQ_DATE,
               P_BCPAYOUTDETS_REC.XRATE,
               P_BCPAYOUTDETS_REC.PAYBRN,
               P_BCPAYOUTDETS_REC.WAVE_PENALTY,
               P_BCPAYOUTDETS_REC.CHARGES,
               P_BCPAYOUTDETS_REC.BENFNAME,
               P_BCPAYOUTDETS_REC.BENFADD1,
               P_BCPAYOUTDETS_REC.BENFADD2,
               P_BCPAYOUTDETS_REC.BENFADD3,
               P_BCPAYOUTDETS_REC.OTHERDETS,
               P_BCPAYOUTDETS_REC.NARRATIVE,
               P_BCPAYOUTDETS_REC.COUNTRY_CODE,
               P_BCPAYOUTDETS_REC.CHQ_PERCENT
          FROM ICTMS_BCPAYOUT_DETAILS
         WHERE REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('p_icdredmn.redem_ref_no > ' || P_ICDREDMN.REDEM_REF_NO);
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_by_bc...' || SQLCODE || SQLERRM);
      END;
    
      DBG('Going to query ictb_redem_acc...');
      BEGIN
        SELECT BRN,
               ACC,
               CALC_ACC,
               BOOK_ACC,
               HAS_IS,
               INT_START_DATE,
               LAST_IS_DATE,
               ACC_TYPE,
               BOOK_BRN,
               AUTO_ROLLOVER,
               CLOSE_ON_MATURITY,
               MOVE_INT_TO_UNCLAIMED,
               MOVE_PRIC_TO_UNCLAIMED,
               MATURITY_DATE,
               PRINC_LIQ_AC,
               ROLLOVER_TYPE,
               ROLLOVER_AMT,
               PRINC_LIQ_BRANCH,
               NEXT_MATURITY_DATE,
               BOOK_CCY,
               HAS_DRCR_ADV,
               RD_FLAG,
               RD_AUTO_PMNT_TAKEDOWN,
               RD_MOVE_MAT_TO_UNCLAIMED,
               RD_MOVE_FUNDS_ON_OVD,
               RD_TAKEDOWN_DAYS,
               RD_TAKEDOWN_MONTHS,
               RD_TAKEDOWN_YEARS,
               RD_PAYMENT_ACC,
               RD_PAYMENT_BRN,
               RD_PAYMENT_CCY,
               RD_INSTALLMENT_AMT,
               RD_PAY_SCHDT,
               CHARGE_BOOK_BRN,
               CHARGE_BOOK_ACC,
               CHARGE_BOOK_CCY,
               OVERRIDE_AMT_BLOCK,
               CHG_START_DATE,
               BVT_DATE,
               COMBVT_DATE,
               TENOR_CODE,
               AUTO_EXTENSION,
               LIQUIDATION_AMT,
               LAST_ROLLOVER_DATE,
               ALLOW_PREPAYMENT,
               
               DEP_TENOR_DAYS,
               DEP_TENOR_MONTHS,
               DEP_TENOR_YEARS,
               DEP_TENOR_PREF,
               ROLL_TENOR_PREF,
               ROLL_TENOR_DAYS,
               ROLL_TENOR_MONTHS,
               ROLL_TENOR_YEARS,
               CASCADE_MONTH
        
          INTO P_TY_STDCUSAC.V_ICTMS_ACC.BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.CALC_ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.HAS_IS,
               P_TY_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.LAST_IS_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.ACC_TYPE,
               P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
               P_TY_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
               P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
               P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
               P_TY_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT,
               P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH,
               P_TY_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_CCY,
               P_TY_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_FLAG,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT,
               P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
               P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_CCY,
               P_TY_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK,
               P_TY_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.BVT_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.COMBVT_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.TENOR_CODE,
               P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_EXTENSION,
               P_TY_STDCUSAC.V_ICTMS_ACC.LIQUIDATION_AMT,
               P_TY_STDCUSAC.V_ICTMS_ACC.LAST_ROLLOVER_DATE,
               P_TY_STDCUSAC.V_ICTMS_ACC.ALLOW_PREPAYMENT,
               
               P_TY_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
               P_TY_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
               P_TY_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
               P_TY_STDCUSAC.V_ICTMS_ACC.DEP_TENOR_PREF,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
               P_TY_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS
               
              ,
               P_TY_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH
          FROM ICTB_REDEM_ACC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_acc...' || SQLCODE || SQLERRM);
      END;
    
      DBG('Going to query ictb_redem_acc_pr...');
      IF C_ICTB_REDEM_ACC_PR%ISOPEN THEN
        CLOSE C_ICTB_REDEM_ACC_PR;
      END IF;
    
      OPEN C_ICTB_REDEM_ACC_PR;
      FETCH C_ICTB_REDEM_ACC_PR BULK COLLECT
        INTO P_TY_STDCUSAC.V_ICTMS_ACC_PR;
      CLOSE C_ICTB_REDEM_ACC_PR;
      DBG('Number of Records queried...: ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
    
      DBG('Going to query ictb_redem_acc_effdt...');
      IF C_ICTB_REDEM_ACC_EFFDT%ISOPEN THEN
        CLOSE C_ICTB_REDEM_ACC_EFFDT;
      END IF;
    
      OPEN C_ICTB_REDEM_ACC_EFFDT;
      FETCH C_ICTB_REDEM_ACC_EFFDT BULK COLLECT
        INTO P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT;
      CLOSE C_ICTB_REDEM_ACC_EFFDT;
      DBG('Number of Records queried...: ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
    
      DBG('Going to query ictb_redem_acc_udevals...');
      IF C_ICTB_REDEM_ACC_UDEVALS%ISOPEN THEN
        CLOSE C_ICTB_REDEM_ACC_UDEVALS;
      END IF;
    
      OPEN C_ICTB_REDEM_ACC_UDEVALS;
      FETCH C_ICTB_REDEM_ACC_UDEVALS BULK COLLECT
        INTO P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS;
      CLOSE C_ICTB_REDEM_ACC_UDEVALS;
      DBG('Number of Records queried...: ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
    
      DBG('Going to query ictb_redem_childtdpayout...');
      IF C_ICTB_REDEM_CHILDTDPAYOUT%ISOPEN THEN
        CLOSE C_ICTB_REDEM_CHILDTDPAYOUT;
      END IF;
    
      OPEN C_ICTB_REDEM_CHILDTDPAYOUT;
      FETCH C_ICTB_REDEM_CHILDTDPAYOUT BULK COLLECT
        INTO P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS;
      CLOSE C_ICTB_REDEM_CHILDTDPAYOUT;
      DBG('Number of Records queried...: ' ||
          P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
    
      DBG('Going to query ictb_redem_childpcpayout...');
      BEGIN
        SELECT BRN,
               ACC,
               CCY,
               PCBANKCODE,
               PCOFFSET_BRN,
               PCOFFSET_ACC,
               PCOFFSET_CCY,
               PCPERCENTAGE,
               BENFNAME,
               BENFADD1,
               BENFADD2,
               OTHERDETS,
               NARRATIVE,
               XRATE,
               REFNO
          INTO P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_BRN,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_CCY,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFNAME,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD1,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD2,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.OTHERDETS,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.NARRATIVE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.XRATE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.REFNO
          FROM ICTB_REDEM_CHILDPCPAYOUT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_childpcpayout...' || SQLCODE ||
              SQLERRM);
      END;
    
      DBG('Going to query ictb_redem_childbcpayout...');
      BEGIN
        SELECT BRN,
               ACC,
               CCY,
               REF_NO,
               SCODE,
               XREF,
               MICR_NO,
               TRN_DT,
               BANKCODE,
               CHQ_AMT,
               CHQ_CCY,
               CHQ_DATE,
               CHQ_PERCENT,
               XRATE,
               PAYBRN,
               WAVE_PENALTY,
               CHARGES,
               BENFNAME,
               BENFADD1,
               BENFADD2,
               BENFADD3,
               OTHERDETS,
               NARRATIVE,
               COUNTRY_CODE
          INTO P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.REF_NO,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.SCODE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XREF,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.MICR_NO,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.TRN_DT,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_AMT,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_CCY,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XRATE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYBRN,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.WAVE_PENALTY,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHARGES,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFNAME,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD1,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD2,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD3,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.OTHERDETS,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.NARRATIVE,
               P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.COUNTRY_CODE
          FROM ICTB_REDEM_CHILDBCPAYOUT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select ictb_redem_childpcpayout...' || SQLCODE ||
              SQLERRM);
      END;
      DBG('All Inserted Record queried Successfully....');
    ELSE
      DBG('Mandatory field Redemption Reference Number missing.');
      P_ERR_CODE   := 'IC-REDMN-09';
      P_ERR_PARAMS := '';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to Query Redemption details. ' || SQLCODE || SQLERRM);
      P_ERR_CODE   := 'IC-REDMN-06';
      P_ERR_PARAMS := SUBSTR(SQLCODE || ':' || SQLERRM, 1, 255);
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_QUERY_REDEMPTION_TBLS;

  FUNCTION FN_DELETE_REDEMPTION_TBLS(P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                     P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                     P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                     P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                     P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_delete_redemption_tbls...');
    IF P_ICDREDMN.REDEM_REF_NO IS NOT NULL THEN
      DELETE FROM ICTB_TDREDEMPTION_MASTER
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO
         AND AUTH_STATUS = 'U';
    
      DBG('Number of Rows deleted in ictb_tdredemption_master  ==> ' ||
          SQL%ROWCOUNT);
      IF SQL%ROWCOUNT > 0 THEN
        DELETE FROM ICTM_TDREDMPAYOUT_DETAILS
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictm_tdredmpayout_details ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_BY_TD
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_by_td          ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_BY_PC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_by_pc          ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_BY_BC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_by_bc          ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_ACC
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_acc            ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_ACC_PR
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_acc_pr         ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_ACC_EFFDT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_acc_effdt      ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_ACC_UDEVALS
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_acc_udevals    ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_CHILDTDPAYOUT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_childtdpayout  ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_CHILDPCPAYOUT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_childpcpayout  ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM ICTB_REDEM_CHILDBCPAYOUT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Number of Rows deleted in ictb_redem_childbcpayout  ==> ' ||
            SQL%ROWCOUNT);
      
        DELETE FROM STTB_RECORD_LOG
         WHERE KEY_ID =
               '~ICTB_TDREDEMPTION_MASTER~' || P_ICDREDMN.REDEM_REF_NO || '~';
        DBG('Number of Rows deleted in ictb_redem_childbcpayout  ==> ' ||
            SQL%ROWCOUNT);
      
      ELSE
        P_ERR_CODE   := 'IC-REDMN-07';
        P_ERR_PARAMS := 'It may not be a un-authorized Record.';
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('All Deletes Completed Successfully....');
    ELSE
      P_ERR_CODE   := 'IC-REDMN-07';
      P_ERR_PARAMS := 'Redemption Reference Number Missing.';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to Delete Redemption details. ' || SQLCODE || SQLERRM);
      P_ERR_CODE   := 'IC-REDMN-07';
      P_ERR_PARAMS := SUBSTR(SQLCODE || ':' || SQLERRM, 1, 255);
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_DELETE_REDEMPTION_TBLS;

  FUNCTION FN_UPDATE_REDEMPTION_TBLS(P_SOURCE           IN VARCHAR2,
                                     P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                     P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                     P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                     P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                     P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_TY_ICDREDMN      IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                     P_AUTH_STATUS      IN ICTB_TDREDEMPTION_MASTER.AUTH_STATUS%TYPE,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('p_icdredmn.redem_ref_no ---> ' || P_ICDREDMN.REDEM_REF_NO);
    IF P_ICDREDMN.REDEM_REF_NO IS NOT NULL THEN
      IF P_SOURCE NOT IN ('FLEXCUBE', 'FLEXBRANCH') THEN
        IF NVL(P_AUTH_STATUS, 'U') = 'A' THEN
          P_ICDREDMN.AUTHSTAT := P_AUTH_STATUS;
        ELSE
          P_ICDREDMN.AUTHSTAT := 'U';
        END IF;
      END IF;
    
      UPDATE ICTB_TDREDEMPTION_MASTER
         SET BRANCH_CODE                = P_ICDREDMN.BRN_CODE,
             ACC_NO                     = P_ICDREDMN.AC_NO,
             CUST_ID                    = P_ICDREDMN.CUST_ID,
             ACC_DESC                   = P_ICDREDMN.ACC_DESC,
             ACC_AMT                    = P_ICDREDMN.ACC_AMT,
             ACTION_FLAG                = P_ICDREDMN.ACTION_FLAG,
             TENOR_DD                   = P_ICDREDMN.TENOR_DD,
             TENOR_MM                   = P_ICDREDMN.TENOR_MM,
             TENOR_YY                   = P_ICDREDMN.TENOR_YY,
             NEXT_MAT_DATE              = P_ICDREDMN.NEXT_MAT_DATE,
             REDEMPTION_BY              = P_ICDREDMN.REDEMPTION_BY,
             CCY                        = P_ICDREDMN.CCY,
             REDEMPTION_MODE            = P_ICDREDMN.REDEMPTION_MODE,
             REDEMPTION_AMT             = P_ICDREDMN.REDEMPTION_AMT,
             WAVE_PENALTY               = P_ICDREDMN.WAVE_PENALTY,
             BANK_CD                    = P_ICDREDMN.BANK_CD,
             BANK_TXN_CCY               = P_ICDREDMN.BANK_TXN_CCY,
             BANK_EXCH_RATE             = P_ICDREDMN.BANK_EXCH_RATE,
             BANK_TXN_AMT               = P_ICDREDMN.BANK_TXN_AMT,
             CHQ_DATE                   = P_ICDREDMN.CHQ_DATE,
             CHARGES                    = P_ICDREDMN.CHARGES,
             BENEF_NAME                 = P_ICDREDMN.BENEF_NAME,
             PASSPORT_NO                = P_ICDREDMN.PASSPORT_NO,
             ADDR1                      = P_ICDREDMN.ADDR1,
             ADDR2                      = P_ICDREDMN.ADDR2,
             BANK_NARRATIVE             = P_ICDREDMN.BANK_NARRATIVE,
             SAVINGS_BRN_CODE           = P_ICDREDMN.SAVINGS_BRN_CODE,
             SAVINGS_ACC_NO             = P_ICDREDMN.SAVINGS_ACC_NO,
             SAVINGS_TXN_CCY            = P_ICDREDMN.SAVINGS_TXN_CCY,
             SAVINGS_EXCH_RATE          = P_ICDREDMN.SAVINGS_EXCH_RATE,
             SAVINGS_TXN_AMT            = P_ICDREDMN.SAVINGS_TXN_AMT,
             SAVINGS_NARRATIVE          = P_ICDREDMN.SAVINGS_NARRATIVE,
             GL_NO                      = P_ICDREDMN.GL_NO,
             GL_TXN_CCY                 = P_ICDREDMN.GL_TXN_CCY,
             GL_EXCH_RATE               = P_ICDREDMN.GL_EXCH_RATE,
             GL_TXN_AMT                 = P_ICDREDMN.GL_TXN_AMT,
             GL_NARRATIVE               = P_ICDREDMN.GL_NARRATIVE,
             SCODE                      = P_ICDREDMN.SCODE,
             XREF                       = P_ICDREDMN.XREF,
             FCCREF                     = P_ICDREDMN.FCCREF,
             PAYBRN                     = P_ICDREDMN.PAYBRN,
             MICR_NO                    = P_ICDREDMN.MICR_NO,
             ADDR3                      = P_ICDREDMN.ADDR3,
             TRN_DT                     = P_ICDREDMN.TRN_DT,
             BANK_CTRY_CODE             = P_ICDREDMN.BANK_CTRY_CODE,
             WAIVE_INTEREST             = P_ICDREDMN.WAIVE_INTEREST,
             GL_BRANCH                  = P_ICDREDMN.GL_BRANCH,
             ALLOW_PREPAYMENT           = P_ICDREDMN.ALLOW_PREPAYMENT,
             SUPPRESS_REDEMPTION_ADVICE = P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE,
             MUDARABAH_REDMN            = 'N',
             MAKER_ID                   = P_ICDREDMN.MAKERID,
             CHECKER_ID                 = P_ICDREDMN.CHECKERID,
             MAKER_DT_STAMP             = P_ICDREDMN.MAKERSTAMP,
             CHECKER_DT_STAMP           = P_ICDREDMN.CHECKERSTAMP,
             AUTH_STATUS                = P_ICDREDMN.AUTHSTAT,
             CONTRACT_STATUS            = P_ICDREDMN.CONTSTAT,
             INTEREST_RATE              = P_ICDREDMN.INTEREST_RATE,
             MATURITY_AMOUNT            = P_ICDREDMN.MATURITY_AMOUNT,
             PRODUCT_CODE               = P_ICDREDMN.PRODUCT_CODE
       WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
    
      DBG('Total number of records in ICTM_TDREDMPAYOUT_DETAILS: ' ||
          P_TY_PAYOUTDETS.COUNT);
    
      IF P_TY_PAYOUTDETS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
          DBG('offset account to be updated is: ' || P_TY_PAYOUTDETS(I)
              .OFFSET_ACC);
          DBG('COMPONENT to be updatedIS: ' || P_TY_PAYOUTDETS(I)
              .REDM_PAYOUT_COMP);
          DBG('account to be updated is : ' || P_TY_PAYOUTDETS(I).ACC ||
              'and branch is>>' || P_TY_PAYOUTDETS(I).BRN);
          P_TY_PAYOUTDETS(I).REDEM_REF_NO := P_ICDREDMN.REDEM_REF_NO;
        
          UPDATE ICTM_TDREDMPAYOUT_DETAILS
             SET CCY              = P_TY_PAYOUTDETS(I).CCY,
                 PAYOUTTYPE       = P_TY_PAYOUTDETS(I).PAYOUTTYPE,
                 OFFSET_BRN       = P_TY_PAYOUTDETS(I).OFFSET_BRN,
                 OFFSET_ACC       = P_TY_PAYOUTDETS(I).OFFSET_ACC,
                 OFFSET_CCY       = P_TY_PAYOUTDETS(I).OFFSET_CCY,
                 PERCENTAGE       = P_TY_PAYOUTDETS(I).PERCENTAGE,
                 REDMAMT          = P_TY_PAYOUTDETS(I).REDMAMT,
                 NARRATIVE        = P_TY_PAYOUTDETS(I).NARRATIVE,
                 REF_NO           = P_TY_PAYOUTDETS(I).REF_NO,
                 SEQNO            = P_TY_PAYOUTDETS(I).SEQNO,
                 XRATE            = P_TY_PAYOUTDETS(I).XRATE,
                 INSTNO           = P_TY_PAYOUTDETS(I).INSTNO,
                 WAIVE_ISSUE_CHG  = P_TY_PAYOUTDETS(I).WAIVE_ISSUE_CHG,
                 REDM_PAYOUT_COMP = P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP
           WHERE BRN = P_TY_PAYOUTDETS(I).BRN
             AND ACC = P_TY_PAYOUTDETS(I).ACC
             AND SEQNO = P_TY_PAYOUTDETS(I).SEQNO
             AND REDEM_REF_NO = P_TY_PAYOUTDETS(I).REDEM_REF_NO;
        
          DBG('updated ' || I || ' - Record.');
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_sttms_cust_account.cust_ac_no    : ' ||
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('p_ty_stdcusac.v_sttms_cust_account.account_class : ' ||
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
      IF P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL OR
         P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NOT NULL THEN
        UPDATE ICTB_REDEM_BY_TD
           SET BRANCH_CODE        = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
               CUST_AC_NO         = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
               AC_DESC            = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC,
               CUST_NO            = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
               CCY                = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
               ACCOUNT_CLASS      = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
               ACCOUNT_TYPE       = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE,
               JOINT_AC_INDICATOR = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR,
               AC_OPEN_DATE       = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
               ALT_AC_NO          = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
               DR_GL              = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL,
               CR_GL              = P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('UPDATED record in ictb_redem_by_td...' || SQL%ROWCOUNT);
      END IF;
    
      DBG('PC: p_pcpayoutdets_rec.pcbankcode : ' ||
          P_PCPAYOUTDETS_REC.PCBANKCODE);
      IF P_PCPAYOUTDETS_REC.PCBANKCODE IS NOT NULL THEN
        UPDATE ICTB_REDEM_BY_PC
           SET BRN            = P_ICDREDMN.BRN_CODE,
               ACC            = P_ICDREDMN.AC_NO,
               CCY            = P_PCPAYOUTDETS_REC.CCY,
               PCBANKCODE     = P_PCPAYOUTDETS_REC.PCBANKCODE,
               PCOFFSET_BRN   = P_PCPAYOUTDETS_REC.PCOFFSET_BRN,
               PCOFFSET_ACC   = P_PCPAYOUTDETS_REC.PCOFFSET_ACC,
               PCOFFSET_CCY   = P_PCPAYOUTDETS_REC.PCOFFSET_CCY,
               BENFNAME       = P_PCPAYOUTDETS_REC.BENFNAME,
               BENFADD1       = P_PCPAYOUTDETS_REC.BENFADD1,
               BENFADD2       = P_PCPAYOUTDETS_REC.BENFADD2,
               OTHERDETS      = P_PCPAYOUTDETS_REC.OTHERDETS,
               NARRATIVE      = P_PCPAYOUTDETS_REC.NARRATIVE,
               CUSTBANKCODE   = P_PCPAYOUTDETS_REC.CUSTBANKCODE,
               CUSTACCNO      = P_PCPAYOUTDETS_REC.CUSTACCNO,
               CGNEWTWORKCODE = P_PCPAYOUTDETS_REC.CGNEWTWORKCODE,
               TXNCCY         = P_PCPAYOUTDETS_REC.TXNCCY,
               TXNAMT         = P_PCPAYOUTDETS_REC.TXNAMT,
               XRATE          = P_PCPAYOUTDETS_REC.XRATE,
               REFNO          = P_PCPAYOUTDETS_REC.REFNO,
               PCPERCENTAGE   = P_PCPAYOUTDETS_REC.PCPERCENTAGE
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('Record successfully UPDATED into PC PAYOUT DET TABLE...');
      END IF;
    
      DBG('BC: p_bcpayoutdets_rec.bankcode : ' ||
          P_BCPAYOUTDETS_REC.BANKCODE);
    
      IF P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL THEN
        UPDATE ICTB_REDEM_BY_BC
           SET BRN          = P_ICDREDMN.BRN_CODE,
               ACC          = P_ICDREDMN.AC_NO,
               CCY          = P_BCPAYOUTDETS_REC.CCY,
               REF_NO       = P_BCPAYOUTDETS_REC.REF_NO,
               SCODE        = P_BCPAYOUTDETS_REC.SCODE,
               XREF         = P_BCPAYOUTDETS_REC.XREF,
               MICR_NO      = P_BCPAYOUTDETS_REC.MICR_NO,
               TRN_DT       = P_BCPAYOUTDETS_REC.TRN_DT,
               BANKCODE     = P_BCPAYOUTDETS_REC.BANKCODE,
               CHQ_AMT      = P_BCPAYOUTDETS_REC.CHQ_AMT,
               CHQ_CCY      = P_BCPAYOUTDETS_REC.CHQ_CCY,
               CHQ_DATE     = P_BCPAYOUTDETS_REC.CHQ_DATE,
               XRATE        = P_BCPAYOUTDETS_REC.XRATE,
               PAYBRN       = P_BCPAYOUTDETS_REC.PAYBRN,
               WAVE_PENALTY = P_BCPAYOUTDETS_REC.WAVE_PENALTY,
               CHARGES      = P_BCPAYOUTDETS_REC.CHARGES,
               BENFNAME     = P_BCPAYOUTDETS_REC.BENFNAME,
               BENFADD1     = P_BCPAYOUTDETS_REC.BENFADD1,
               BENFADD2     = P_BCPAYOUTDETS_REC.BENFADD2,
               BENFADD3     = P_BCPAYOUTDETS_REC.BENFADD3,
               OTHERDETS    = P_BCPAYOUTDETS_REC.OTHERDETS,
               NARRATIVE    = P_BCPAYOUTDETS_REC.NARRATIVE,
               COUNTRY_CODE = P_BCPAYOUTDETS_REC.COUNTRY_CODE,
               CHQ_PERCENT  = P_BCPAYOUTDETS_REC.CHQ_PERCENT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('Record Successfully updated into ictb_redem_by_bc table...');
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc.acc ---> ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
    
      IF P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL THEN
        UPDATE ICTMS_BCPAYOUT_DETAILS
           SET REF_NO       = P_ICDREDMN.REDEM_REF_NO,
               SCODE        = P_BCPAYOUTDETS_REC.SCODE,
               XREF         = P_BCPAYOUTDETS_REC.XREF,
               MICR_NO      = P_BCPAYOUTDETS_REC.MICR_NO,
               TRN_DT       = P_BCPAYOUTDETS_REC.TRN_DT,
               BANKCODE     = P_BCPAYOUTDETS_REC.BANKCODE,
               CHQ_AMT      = P_BCPAYOUTDETS_REC.CHQ_AMT,
               CHQ_CCY      = P_BCPAYOUTDETS_REC.CHQ_CCY,
               CHQ_DATE     = P_BCPAYOUTDETS_REC.CHQ_DATE,
               XRATE        = P_BCPAYOUTDETS_REC.XRATE,
               PAYBRN       = P_BCPAYOUTDETS_REC.PAYBRN,
               BENFNAME     = P_BCPAYOUTDETS_REC.BENFNAME,
               OTHERDETS    = P_BCPAYOUTDETS_REC.OTHERDETS,
               NARRATIVE    = P_BCPAYOUTDETS_REC.NARRATIVE,
               COUNTRY_CODE = P_BCPAYOUTDETS_REC.COUNTRY_CODE,
               BENFADD1     = P_BCPAYOUTDETS_REC.BENFADD1,
               BENFADD2     = P_BCPAYOUTDETS_REC.BENFADD2,
               BENFADD3     = P_BCPAYOUTDETS_REC.BENFADD3
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO
           AND CCY = P_ICDREDMN.CCY;
      END IF;
    
      IF P_TY_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
        UPDATE ICTB_REDEM_ACC
           SET CALC_ACC                 = P_TY_STDCUSAC.V_ICTMS_ACC.CALC_ACC,
               BOOK_ACC                 = P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
               HAS_IS                   = P_TY_STDCUSAC.V_ICTMS_ACC.HAS_IS,
               INT_START_DATE           = P_TY_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
               LAST_IS_DATE             = P_TY_STDCUSAC.V_ICTMS_ACC.LAST_IS_DATE,
               ACC_TYPE                 = P_TY_STDCUSAC.V_ICTMS_ACC.ACC_TYPE,
               BOOK_BRN                 = P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
               AUTO_ROLLOVER            = P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
               CLOSE_ON_MATURITY        = P_TY_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
               MOVE_INT_TO_UNCLAIMED    = P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
               MOVE_PRIC_TO_UNCLAIMED   = P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
               MATURITY_DATE            = P_TY_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
               PRINC_LIQ_AC             = P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC,
               ROLLOVER_TYPE            = P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
               ROLLOVER_AMT             = P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT,
               PRINC_LIQ_BRANCH         = P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH,
               NEXT_MATURITY_DATE       = P_TY_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
               BOOK_CCY                 = P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_CCY,
               HAS_DRCR_ADV             = P_TY_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV,
               RD_FLAG                  = P_TY_STDCUSAC.V_ICTMS_ACC.RD_FLAG,
               RD_AUTO_PMNT_TAKEDOWN    = P_TY_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN,
               RD_MOVE_MAT_TO_UNCLAIMED = P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED,
               RD_MOVE_FUNDS_ON_OVD     = P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD,
               RD_TAKEDOWN_DAYS         = P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS,
               RD_TAKEDOWN_MONTHS       = P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
               RD_TAKEDOWN_YEARS        = P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
               RD_PAYMENT_ACC           = P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC,
               RD_PAYMENT_BRN           = P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN,
               RD_PAYMENT_CCY           = P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY,
               RD_INSTALLMENT_AMT       = P_TY_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT,
               RD_PAY_SCHDT             = P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
               CHARGE_BOOK_BRN          = P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN,
               CHARGE_BOOK_ACC          = P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC,
               CHARGE_BOOK_CCY          = P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_CCY,
               OVERRIDE_AMT_BLOCK       = P_TY_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK,
               CHG_START_DATE           = P_TY_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
               BVT_DATE                 = P_TY_STDCUSAC.V_ICTMS_ACC.BVT_DATE,
               COMBVT_DATE              = P_TY_STDCUSAC.V_ICTMS_ACC.COMBVT_DATE,
               TENOR_CODE               = P_TY_STDCUSAC.V_ICTMS_ACC.TENOR_CODE,
               AUTO_EXTENSION           = P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_EXTENSION,
               LIQUIDATION_AMT          = P_TY_STDCUSAC.V_ICTMS_ACC.LIQUIDATION_AMT,
               LAST_ROLLOVER_DATE       = P_TY_STDCUSAC.V_ICTMS_ACC.LAST_ROLLOVER_DATE,
               ALLOW_PREPAYMENT         = P_TY_STDCUSAC.V_ICTMS_ACC.ALLOW_PREPAYMENT
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO
           AND BRN = P_TY_STDCUSAC.V_ICTMS_ACC.BRN
           AND ACC = P_TY_STDCUSAC.V_ICTMS_ACC.ACC;
      
        DBG('Succesfully UPDATED into ictb_redem_acc table...');
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_pr.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
          DBG('p_ty_stdcusac.v_ictms_acc_pr(i).acc  ---> ' || P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC);
          DBG('p_ty_stdcusac.v_ictms_acc_pr(i).prod ---> ' || P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
          IF P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD IS NOT NULL THEN
            UPDATE ICTB_REDEM_ACC_PR
               SET PROD          = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD,
                   WAIVE         = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).WAIVE,
                   GEN_UCA       = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).GEN_UCA,
                   RECORD_STAT   = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I)
                                   .RECORD_STAT,
                   ONCE_AUTH     = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ONCE_AUTH,
                   UDE_CCY       = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).UDE_CCY,
                   MIN_AMT       = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).MIN_AMT,
                   MAX_AMT       = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).MAX_AMT,
                   FREE_TXN      = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).FREE_TXN,
                   CONT_VAR_ROLL = P_TY_STDCUSAC.V_ICTMS_ACC_PR(I)
                                   .CONT_VAR_ROLL
             WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO
               AND BRN = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).BRN,
                             P_TY_STDCUSAC.V_ICTMS_ACC.BRN)
               AND ACC = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC,
                             P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          
            DBG('Successfully updated into ictb redem acc pr table...: ' || I);
          ELSE
            DBG('Product code is mandatory column. Can not be null...Just omitted');
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_effdt.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
          IF P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT IS NOT NULL THEN
            UPDATE ICTB_REDEM_ACC_EFFDT
               SET PROD        = P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD,
                   UDE_EFF_DT  = P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                 .UDE_EFF_DT,
                   RECORD_STAT = P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                 .RECORD_STAT,
                   ONCE_AUTH   = P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ONCE_AUTH
             WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO
               AND BRN = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).BRN,
                             P_TY_STDCUSAC.V_ICTMS_ACC.BRN)
               AND ACC = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC,
                             P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          
            DBG('Successfully inserted into ictb redem acc effdt...: ' || I);
          ELSE
            DBG('Effective date cannot be null for ' || P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD || '~' ||
                P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_udevals.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT LOOP
          IF P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID IS NOT NULL THEN
            UPDATE ICTB_REDEM_ACC_UDEVALS
               SET UDE_VALUE = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                               .UDE_VALUE,
                   RATE_CODE    = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .RATE_CODE,
                   AUTH_STAT    = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .AUTH_STAT,
                   RECORD_STAT  = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .RECORD_STAT,
                   BASE_RATE    = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .BASE_RATE,
                   BASE_SPREAD  = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .BASE_SPREAD,
                   TD_RATE_CODE = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .TD_RATE_CODE,
                   UDE_VARIANCE = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                                  .UDE_VARIANCE
             WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO
               AND BRN = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BRN,
                             P_TY_STDCUSAC.V_ICTMS_ACC.BRN)
               AND ACC = NVL(P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC,
                             P_TY_STDCUSAC.V_ICTMS_ACC.ACC)
                  
               AND PROD = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD
               AND UDE_EFF_DT = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                  .UDE_EFF_DT
               AND UDE_ID = P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID
            
            ;
          
            DBG('Successfully UPDATED into ictb redem acc udevals...: ' || I);
          ELSE
            DBG('UDE ID can not be null for ' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD || '~' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                .UDE_EFF_DT || '~' || P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_tdpayout_details.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT LOOP
          UPDATE ICTB_REDEM_CHILDTDPAYOUT
             SET BRN        = NVL(P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BRN,
                                  P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS.BRN),
                 ACC        = NVL(P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC,
                                  P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS.ACC),
                 CCY        = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY,
                 PAYOUTTYPE = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .PAYOUTTYPE,
                 BANKCODE   = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .BANKCODE,
                 OFFSET_BRN = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .OFFSET_BRN,
                 OFFSET_ACC = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .OFFSET_ACC,
                 OFFSET_CCY = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .OFFSET_CCY,
                 PERCENTAGE = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .PERCENTAGE,
                 REDMAMT    = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .REDMAMT,
                 BENFNAME   = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .BENFNAME,
                 BENFADD1   = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .BENFADD1,
                 BENFADD2   = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .BENFADD2,
                 OTHERDETS  = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .OTHERDETS,
                 NARRATIVE  = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .NARRATIVE,
                 XRATE      = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).XRATE,
                 REF_NO     = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                              .REF_NO,
                 SEQNO      = P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO
           WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
          DBG('Succesfully inserted into  ictb child td payout :' || I);
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.ty_icctdfpo.v_ictms_pcpayout_details.pcbankcode ---> ' ||
          P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE);
      IF P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE IS NOT NULL THEN
        UPDATE ICTB_REDEM_CHILDPCPAYOUT
           SET BRN          = NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN,
                                  P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
               ACC          = NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC,
                                  P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
               CCY          = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY,
               PCBANKCODE   = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE,
               PCOFFSET_BRN = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_BRN,
               PCOFFSET_ACC = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC,
               PCOFFSET_CCY = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_CCY,
               PCPERCENTAGE = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE,
               BENFNAME     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFNAME,
               BENFADD1     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD1,
               BENFADD2     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD2,
               OTHERDETS    = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.OTHERDETS,
               NARRATIVE    = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.NARRATIVE,
               XRATE        = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.XRATE,
               REFNO        = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.REFNO
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('Successfully updated into child pc payout details...');
      END IF;
    
      DBG('p_ty_stdcusac.ty_icctdfpo.v_ictms_bcpayout_details.bankcode : ' ||
          P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE);
      IF P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE IS NOT NULL THEN
        UPDATE ICTB_REDEM_CHILDBCPAYOUT
           SET BRN          = NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN,
                                  P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
               ACC          = NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC,
                                  P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
               CCY          = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY,
               REF_NO       = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.REF_NO,
               SCODE        = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.SCODE,
               XREF         = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XREF,
               MICR_NO      = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.MICR_NO,
               TRN_DT       = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.TRN_DT,
               BANKCODE     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE,
               CHQ_AMT      = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_AMT,
               CHQ_CCY      = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_CCY,
               CHQ_DATE     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE,
               CHQ_PERCENT  = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT,
               XRATE        = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XRATE,
               PAYBRN       = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYBRN,
               WAVE_PENALTY = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.WAVE_PENALTY,
               CHARGES      = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHARGES,
               BENFNAME     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFNAME,
               BENFADD1     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD1,
               BENFADD2     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD2,
               BENFADD3     = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD3,
               OTHERDETS    = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.OTHERDETS,
               NARRATIVE    = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.NARRATIVE,
               COUNTRY_CODE = P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.COUNTRY_CODE
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
      
        DBG('Successfully Inserted into child bc payout details...');
      END IF;
      DBG('All Inserts Completed Successfully....');
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to Insert Redemption details. ' || SQLCODE || SQLERRM);
      P_ERR_CODE   := 'IC-REDMN-01';
      P_ERR_PARAMS := SUBSTR(SQLCODE || ':' || SQLERRM, 1, 255);
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_UPDATE_REDEMPTION_TBLS;

  FUNCTION FN_INSERT_REDEMPTION_TBLS(P_SOURCE           IN VARCHAR2,
                                     P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                     P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                     P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                     P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                     P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_TY_ICDREDMN      IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                                     P_AUTH_STATUS      IN ICTB_TDREDEMPTION_MASTER.AUTH_STATUS%TYPE,
                                     P_ERR_CODE         IN OUT VARCHAR2,
                                     P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_COUNT NUMBER := 0;
  BEGIN
    DBG('p_icdredmn.redem_ref_no ---> ' || P_ICDREDMN.REDEM_REF_NO);
    IF P_ICDREDMN.REDEM_REF_NO IS NOT NULL THEN
      P_ICDREDMN.MAKERSTAMP := NVL(P_ICDREDMN.MAKERSTAMP,
                                   BCPKSS_UTILS.FN_GET_DATE_TIME(GLOBAL.APPLICATION_DATE));
      P_ICDREDMN.CONTSTAT   := NVL(P_ICDREDMN.CONTSTAT, 'A');
      P_ICDREDMN.MAKERID    := NVL(P_ICDREDMN.MAKERID, GLOBAL.USER_ID);
      P_ICDREDMN.AUTHSTAT   := NVL(P_ICDREDMN.AUTHSTAT,
                                   NVL(P_AUTH_STATUS, 'U'));
    
      IF P_SOURCE NOT IN ('FLEXCUBE', 'FLEXBRANCH') THEN
        IF NVL(P_AUTH_STATUS, 'U') = 'A' THEN
          P_ICDREDMN.AUTHSTAT := P_AUTH_STATUS;
        ELSE
          P_ICDREDMN.AUTHSTAT := 'U';
        END IF;
      END IF;
    
      INSERT INTO ICTB_TDREDEMPTION_MASTER
        (REDEM_REF_NO,
         BRANCH_CODE,
         ACC_NO,
         CUST_ID,
         ACC_DESC,
         ACC_AMT,
         ACTION_FLAG,
         TENOR_DD,
         TENOR_MM,
         TENOR_YY,
         NEXT_MAT_DATE,
         REDEMPTION_BY,
         CCY,
         REDEMPTION_MODE,
         REDEMPTION_AMT,
         WAVE_PENALTY,
         BANK_CD,
         BANK_TXN_CCY,
         BANK_EXCH_RATE,
         BANK_TXN_AMT,
         CHQ_DATE,
         CHARGES,
         BENEF_NAME,
         PASSPORT_NO,
         ADDR1,
         ADDR2,
         BANK_NARRATIVE,
         SAVINGS_BRN_CODE,
         SAVINGS_ACC_NO,
         SAVINGS_TXN_CCY,
         SAVINGS_EXCH_RATE,
         SAVINGS_TXN_AMT,
         SAVINGS_NARRATIVE,
         GL_NO,
         GL_TXN_CCY,
         GL_EXCH_RATE,
         GL_TXN_AMT,
         GL_NARRATIVE,
         SCODE,
         XREF,
         FCCREF,
         PAYBRN,
         MICR_NO,
         ADDR3,
         TRN_DT,
         BANK_CTRY_CODE,
         WAIVE_INTEREST,
         GL_BRANCH,
         ALLOW_PREPAYMENT,
         SUPPRESS_REDEMPTION_ADVICE,
         MUDARABAH_REDMN,
         MAKER_ID,
         CHECKER_ID,
         MAKER_DT_STAMP,
         CHECKER_DT_STAMP,
         AUTH_STATUS,
         CONTRACT_STATUS,
         INTEREST_RATE,
         MATURITY_AMOUNT,
         PRODUCT_CODE,
         REDEM_INT_PAYOUT)
      VALUES
        (P_ICDREDMN.REDEM_REF_NO,
         P_ICDREDMN.BRN_CODE,
         P_ICDREDMN.AC_NO,
         P_ICDREDMN.CUST_ID,
         P_ICDREDMN.ACC_DESC,
         P_ICDREDMN.ACC_AMT,
         P_ICDREDMN.ACTION_FLAG,
         P_ICDREDMN.TENOR_DD,
         P_ICDREDMN.TENOR_MM,
         P_ICDREDMN.TENOR_YY,
         P_ICDREDMN.NEXT_MAT_DATE,
         P_ICDREDMN.REDEMPTION_BY,
         P_ICDREDMN.CCY,
         P_ICDREDMN.REDEMPTION_MODE,
         P_ICDREDMN.REDEMPTION_AMT,
         P_ICDREDMN.WAVE_PENALTY,
         P_ICDREDMN.BANK_CD,
         P_ICDREDMN.BANK_TXN_CCY,
         P_ICDREDMN.BANK_EXCH_RATE,
         P_ICDREDMN.BANK_TXN_AMT,
         P_ICDREDMN.CHQ_DATE,
         P_ICDREDMN.CHARGES,
         P_ICDREDMN.BENEF_NAME,
         P_ICDREDMN.PASSPORT_NO,
         P_ICDREDMN.ADDR1,
         P_ICDREDMN.ADDR2,
         P_ICDREDMN.BANK_NARRATIVE,
         P_ICDREDMN.SAVINGS_BRN_CODE,
         P_ICDREDMN.SAVINGS_ACC_NO,
         P_ICDREDMN.SAVINGS_TXN_CCY,
         P_ICDREDMN.SAVINGS_EXCH_RATE,
         P_ICDREDMN.SAVINGS_TXN_AMT,
         P_ICDREDMN.SAVINGS_NARRATIVE,
         P_ICDREDMN.GL_NO,
         P_ICDREDMN.GL_TXN_CCY,
         P_ICDREDMN.GL_EXCH_RATE,
         P_ICDREDMN.GL_TXN_AMT,
         P_ICDREDMN.GL_NARRATIVE,
         P_ICDREDMN.SCODE,
         P_ICDREDMN.XREF,
         P_ICDREDMN.FCCREF,
         P_ICDREDMN.PAYBRN,
         P_ICDREDMN.MICR_NO,
         P_ICDREDMN.ADDR3,
         P_ICDREDMN.TRN_DT,
         P_ICDREDMN.BANK_CTRY_CODE,
         P_ICDREDMN.WAIVE_INTEREST,
         P_ICDREDMN.GL_BRANCH,
         P_ICDREDMN.ALLOW_PREPAYMENT,
         P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE,
         'N',
         P_ICDREDMN.MAKERID,
         P_ICDREDMN.CHECKERID,
         P_ICDREDMN.MAKERSTAMP,
         P_ICDREDMN.CHECKERSTAMP,
         P_ICDREDMN.AUTHSTAT,
         P_ICDREDMN.CONTSTAT,
         P_ICDREDMN.INTEREST_RATE,
         P_ICDREDMN.MATURITY_AMOUNT,
         P_ICDREDMN.PRODUCT_CODE,
         P_ICDREDMN.REDEM_INT_PAYOUT);
      DBG('Total number of records in ICTM_TDREDMPAYOUT_DETAILS: ' ||
          P_TY_PAYOUTDETS.COUNT);
    
      IF P_TY_PAYOUTDETS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
        
          DBG('offset account to be inserted is: ' || P_TY_PAYOUTDETS(I)
              .OFFSET_ACC);
          DBG('COMPONENT IS: ' || P_TY_PAYOUTDETS(I).REDM_PAYOUT_COMP);
          DBG('account is : ' || P_TY_PAYOUTDETS(I).ACC ||
              'and branch is>>' || P_TY_PAYOUTDETS(I).BRN);
        
          P_TY_PAYOUTDETS(I).REDEM_REF_NO := P_ICDREDMN.REDEM_REF_NO;
          INSERT INTO ICTM_TDREDMPAYOUT_DETAILS VALUES P_TY_PAYOUTDETS (I);
          DBG('Inserted ' || I || ' - Record.');
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_sttms_cust_account.cust_ac_no    : ' ||
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('p_ty_stdcusac.v_sttms_cust_account.account_class : ' ||
          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
      IF P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL OR
         P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_BY_TD
          (REDEM_REF_NO,
           BRANCH_CODE,
           CUST_AC_NO,
           AC_DESC,
           CUST_NO,
           CCY,
           ACCOUNT_CLASS,
           ACCOUNT_TYPE,
           JOINT_AC_INDICATOR,
           AC_OPEN_DATE,
           ALT_AC_NO,
           DR_GL,
           CR_GL,
           DEFTFROM)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL,
           P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL,
           'A');
        DBG('Inserted record in ictb_redem_by_td...' || SQL%ROWCOUNT);
      END IF;
    
      DBG('PC: p_pcpayoutdets_rec.pcbankcode : ' ||
          P_PCPAYOUTDETS_REC.PCBANKCODE);
      IF P_PCPAYOUTDETS_REC.PCBANKCODE IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_BY_PC
          (REDEM_REF_NO,
           BRN,
           ACC,
           CCY,
           PCBANKCODE,
           PCOFFSET_BRN,
           PCOFFSET_ACC,
           PCOFFSET_CCY,
           BENFNAME,
           BENFADD1,
           BENFADD2,
           OTHERDETS,
           NARRATIVE,
           CUSTBANKCODE,
           CUSTACCNO,
           CGNEWTWORKCODE,
           TXNCCY,
           TXNAMT,
           XRATE,
           REFNO,
           PCPERCENTAGE)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           
           P_ICDREDMN.BRN_CODE,
           P_ICDREDMN.AC_NO,
           
           P_PCPAYOUTDETS_REC.CCY,
           P_PCPAYOUTDETS_REC.PCBANKCODE,
           P_PCPAYOUTDETS_REC.PCOFFSET_BRN,
           P_PCPAYOUTDETS_REC.PCOFFSET_ACC,
           P_PCPAYOUTDETS_REC.PCOFFSET_CCY,
           P_PCPAYOUTDETS_REC.BENFNAME,
           P_PCPAYOUTDETS_REC.BENFADD1,
           P_PCPAYOUTDETS_REC.BENFADD2,
           P_PCPAYOUTDETS_REC.OTHERDETS,
           P_PCPAYOUTDETS_REC.NARRATIVE,
           P_PCPAYOUTDETS_REC.CUSTBANKCODE,
           P_PCPAYOUTDETS_REC.CUSTACCNO,
           P_PCPAYOUTDETS_REC.CGNEWTWORKCODE,
           P_PCPAYOUTDETS_REC.TXNCCY,
           P_PCPAYOUTDETS_REC.TXNAMT,
           P_PCPAYOUTDETS_REC.XRATE,
           P_PCPAYOUTDETS_REC.REFNO,
           P_PCPAYOUTDETS_REC.PCPERCENTAGE);
        DBG('Record successfully inserted into PC PAYOUT DET TABLE...');
      END IF;
    
      DBG('BC: p_bcpayoutdets_rec.bankcode : ' ||
          P_BCPAYOUTDETS_REC.BANKCODE);
      IF P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_BY_BC
          (REDEM_REF_NO,
           BRN,
           ACC,
           CCY,
           REF_NO,
           SCODE,
           XREF,
           MICR_NO,
           TRN_DT,
           BANKCODE,
           CHQ_AMT,
           CHQ_CCY,
           CHQ_DATE,
           XRATE,
           PAYBRN,
           WAVE_PENALTY,
           CHARGES,
           BENFNAME,
           BENFADD1,
           BENFADD2,
           BENFADD3,
           OTHERDETS,
           NARRATIVE,
           COUNTRY_CODE,
           CHQ_PERCENT)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           
           P_ICDREDMN.BRN_CODE,
           P_ICDREDMN.AC_NO,
           
           P_BCPAYOUTDETS_REC.CCY,
           P_BCPAYOUTDETS_REC.REF_NO,
           P_BCPAYOUTDETS_REC.SCODE,
           P_BCPAYOUTDETS_REC.XREF,
           P_BCPAYOUTDETS_REC.MICR_NO,
           P_BCPAYOUTDETS_REC.TRN_DT,
           P_BCPAYOUTDETS_REC.BANKCODE,
           P_BCPAYOUTDETS_REC.CHQ_AMT,
           P_BCPAYOUTDETS_REC.CHQ_CCY,
           P_BCPAYOUTDETS_REC.CHQ_DATE,
           P_BCPAYOUTDETS_REC.XRATE,
           P_BCPAYOUTDETS_REC.PAYBRN,
           P_BCPAYOUTDETS_REC.WAVE_PENALTY,
           P_BCPAYOUTDETS_REC.CHARGES,
           P_BCPAYOUTDETS_REC.BENFNAME,
           P_BCPAYOUTDETS_REC.BENFADD1,
           P_BCPAYOUTDETS_REC.BENFADD2,
           P_BCPAYOUTDETS_REC.BENFADD3,
           P_BCPAYOUTDETS_REC.OTHERDETS,
           P_BCPAYOUTDETS_REC.NARRATIVE,
           P_BCPAYOUTDETS_REC.COUNTRY_CODE,
           P_BCPAYOUTDETS_REC.CHQ_PERCENT);
        DBG('Record Successfully inserted into BC PAYOUT DET table...');
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc.acc ---> ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
    
      IF P_BCPAYOUTDETS_REC.BANKCODE IS NOT NULL THEN
        INSERT INTO ICTMS_BCPAYOUT_DETAILS
          (BRN,
           ACC,
           CCY,
           REF_NO,
           SCODE,
           XREF,
           MICR_NO,
           TRN_DT,
           BANKCODE,
           CHQ_AMT,
           CHQ_CCY,
           CHQ_DATE,
           XRATE,
           PAYBRN,
           BENFNAME,
           OTHERDETS,
           NARRATIVE,
           COUNTRY_CODE,
           BENFADD1,
           BENFADD2,
           BENFADD3)
        VALUES
          (P_ICDREDMN.BRN_CODE,
           P_ICDREDMN.AC_NO,
           P_ICDREDMN.CCY,
           P_ICDREDMN.REDEM_REF_NO,
           P_BCPAYOUTDETS_REC.SCODE,
           P_BCPAYOUTDETS_REC.XREF,
           P_BCPAYOUTDETS_REC.MICR_NO,
           P_BCPAYOUTDETS_REC.TRN_DT,
           P_BCPAYOUTDETS_REC.BANKCODE,
           P_BCPAYOUTDETS_REC.CHQ_AMT,
           P_BCPAYOUTDETS_REC.CHQ_CCY,
           P_BCPAYOUTDETS_REC.CHQ_DATE,
           P_BCPAYOUTDETS_REC.XRATE,
           P_BCPAYOUTDETS_REC.PAYBRN,
           P_BCPAYOUTDETS_REC.BENFNAME,
           P_BCPAYOUTDETS_REC.OTHERDETS,
           P_BCPAYOUTDETS_REC.NARRATIVE,
           P_BCPAYOUTDETS_REC.COUNTRY_CODE,
           P_BCPAYOUTDETS_REC.BENFADD1,
           P_BCPAYOUTDETS_REC.BENFADD2,
           P_BCPAYOUTDETS_REC.BENFADD3);
      END IF;
    
      IF P_TY_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_ACC
          (REDEM_REF_NO,
           BRN,
           ACC,
           CALC_ACC,
           BOOK_ACC,
           HAS_IS,
           INT_START_DATE,
           LAST_IS_DATE,
           ACC_TYPE,
           BOOK_BRN,
           AUTO_ROLLOVER,
           CLOSE_ON_MATURITY,
           MOVE_INT_TO_UNCLAIMED,
           MOVE_PRIC_TO_UNCLAIMED,
           MATURITY_DATE,
           PRINC_LIQ_AC,
           ROLLOVER_TYPE,
           ROLLOVER_AMT,
           PRINC_LIQ_BRANCH,
           NEXT_MATURITY_DATE,
           BOOK_CCY,
           HAS_DRCR_ADV,
           RD_FLAG,
           RD_AUTO_PMNT_TAKEDOWN,
           RD_MOVE_MAT_TO_UNCLAIMED,
           RD_MOVE_FUNDS_ON_OVD,
           RD_TAKEDOWN_DAYS,
           RD_TAKEDOWN_MONTHS,
           RD_TAKEDOWN_YEARS,
           RD_PAYMENT_ACC,
           RD_PAYMENT_BRN,
           RD_PAYMENT_CCY,
           RD_INSTALLMENT_AMT,
           RD_PAY_SCHDT,
           CHARGE_BOOK_BRN,
           CHARGE_BOOK_ACC,
           CHARGE_BOOK_CCY,
           OVERRIDE_AMT_BLOCK,
           CHG_START_DATE,
           BVT_DATE,
           COMBVT_DATE,
           TENOR_CODE,
           AUTO_EXTENSION,
           LIQUIDATION_AMT,
           LAST_ROLLOVER_DATE,
           ALLOW_PREPAYMENT)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           P_TY_STDCUSAC.V_ICTMS_ACC.BRN,
           P_TY_STDCUSAC.V_ICTMS_ACC.ACC,
           P_TY_STDCUSAC.V_ICTMS_ACC.CALC_ACC,
           P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
           P_TY_STDCUSAC.V_ICTMS_ACC.HAS_IS,
           P_TY_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.LAST_IS_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.ACC_TYPE,
           P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
           P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
           P_TY_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
           P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
           P_TY_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
           P_TY_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC,
           P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
           P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT,
           P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH,
           P_TY_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_CCY,
           P_TY_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_FLAG,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT,
           P_TY_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
           P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN,
           P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC,
           P_TY_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_CCY,
           P_TY_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK,
           P_TY_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.BVT_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.COMBVT_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.TENOR_CODE,
           P_TY_STDCUSAC.V_ICTMS_ACC.AUTO_EXTENSION,
           P_TY_STDCUSAC.V_ICTMS_ACC.LIQUIDATION_AMT,
           P_TY_STDCUSAC.V_ICTMS_ACC.LAST_ROLLOVER_DATE,
           P_TY_STDCUSAC.V_ICTMS_ACC.ALLOW_PREPAYMENT);
        DBG('Succesfully Inserted into ictb_redem_acc table...');
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_pr.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
          DBG('p_ty_stdcusac.v_ictms_acc_pr(i).acc  ---> ' || P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC);
          DBG('p_ty_stdcusac.v_ictms_acc_pr(i).prod ---> ' || P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
          IF P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD IS NOT NULL THEN
            INSERT INTO ICTB_REDEM_ACC_PR
              (REDEM_REF_NO,
               BRN,
               ACC,
               PROD,
               WAIVE,
               GEN_UCA,
               RECORD_STAT,
               ONCE_AUTH,
               UDE_CCY,
               MIN_AMT,
               MAX_AMT,
               FREE_TXN,
               CONT_VAR_ROLL)
            VALUES
              (P_ICDREDMN.REDEM_REF_NO,
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).BRN,
                   P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC,
                   P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).PROD,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).WAIVE,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).GEN_UCA,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ONCE_AUTH,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).UDE_CCY,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).MIN_AMT,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).MAX_AMT,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).FREE_TXN,
               P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).CONT_VAR_ROLL);
            DBG('Successfully inserted into ictb redem acc pr table...: ' || I);
          ELSE
            DBG('Product code is mandatory column. Can not be null...Just omitted');
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_effdt.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
          IF P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT IS NOT NULL THEN
            INSERT INTO ICTB_REDEM_ACC_EFFDT
              (REDEM_REF_NO,
               BRN,
               ACC,
               PROD,
               UDE_EFF_DT,
               RECORD_STAT,
               ONCE_AUTH)
            VALUES
              (P_ICDREDMN.REDEM_REF_NO,
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).BRN,
                   P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC,
                   P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
               P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD,
               P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT,
               P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).RECORD_STAT,
               P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ONCE_AUTH);
            DBG('Successfully inserted into ictb redem acc effdt...: ' || I);
          ELSE
            DBG('Effective date cannot be null for ' || P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD || '~' ||
                P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_acc_udevals.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT LOOP
          IF P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID IS NOT NULL THEN
            INSERT INTO ICTB_REDEM_ACC_UDEVALS
              (REDEM_REF_NO,
               BRN,
               ACC,
               PROD,
               UDE_EFF_DT,
               UDE_ID,
               UDE_VALUE,
               RATE_CODE,
               AUTH_STAT,
               RECORD_STAT,
               BASE_RATE,
               BASE_SPREAD,
               TD_RATE_CODE,
               UDE_VARIANCE)
            VALUES
              (P_ICDREDMN.REDEM_REF_NO,
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BRN,
                   P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
               NVL(P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC,
                   P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_EFF_DT,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VALUE,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RATE_CODE,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).AUTH_STAT,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RECORD_STAT,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BASE_RATE,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BASE_SPREAD,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).TD_RATE_CODE,
               P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VARIANCE);
            DBG('Successfully inserted into ictb redem acc udevals...: ' || I);
          ELSE
            DBG('UDE ID can not be null for ' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD || '~' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
                .UDE_EFF_DT || '~' || P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
          END IF;
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.v_ictms_tdpayout_details.COUNT : ' ||
          P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
      IF P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT LOOP
          INSERT INTO ICTB_REDEM_CHILDTDPAYOUT
            (REDEM_REF_NO,
             BRN,
             ACC,
             CCY,
             PAYOUTTYPE,
             BANKCODE,
             OFFSET_BRN,
             OFFSET_ACC,
             OFFSET_CCY,
             PERCENTAGE,
             REDMAMT,
             BENFNAME,
             BENFADD1,
             BENFADD2,
             OTHERDETS,
             NARRATIVE,
             XRATE,
             REF_NO,
             SEQNO)
          VALUES
            (P_ICDREDMN.REDEM_REF_NO,
             
             NVL(P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BRN,
                 P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS.BRN),
             NVL(P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC,
                 P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS.ACC),
             
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BANKCODE,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_BRN,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_CCY,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PERCENTAGE,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).REDMAMT,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFNAME,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFADD1,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BENFADD2,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OTHERDETS,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).NARRATIVE,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).XRATE,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).REF_NO,
             P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO);
          DBG('Succesfully inserted into  ictb child td payout :' || I);
        END LOOP;
      END IF;
    
      DBG('p_ty_stdcusac.ty_icctdfpo.v_ictms_pcpayout_details.pcbankcode ---> ' ||
          P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE);
      IF P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_CHILDPCPAYOUT
          (REDEM_REF_NO,
           BRN,
           ACC,
           CCY,
           PCBANKCODE,
           PCOFFSET_BRN,
           PCOFFSET_ACC,
           PCOFFSET_CCY,
           PCPERCENTAGE,
           BENFNAME,
           BENFADD1,
           BENFADD2,
           OTHERDETS,
           NARRATIVE,
           XRATE,
           REFNO)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
           NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCBANKCODE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_BRN,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_ACC,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCOFFSET_CCY,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFNAME,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD1,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BENFADD2,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.OTHERDETS,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.NARRATIVE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.XRATE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.REFNO);
        DBG('Successfully inserted into child pc payout details...');
      END IF;
    
      DBG('p_ty_stdcusac.ty_icctdfpo.v_ictms_bcpayout_details.bankcode : ' ||
          P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE);
      IF P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE IS NOT NULL THEN
        INSERT INTO ICTB_REDEM_CHILDBCPAYOUT
          (REDEM_REF_NO,
           BRN,
           ACC,
           CCY,
           REF_NO,
           SCODE,
           XREF,
           MICR_NO,
           TRN_DT,
           BANKCODE,
           CHQ_AMT,
           CHQ_CCY,
           CHQ_DATE,
           CHQ_PERCENT,
           XRATE,
           PAYBRN,
           WAVE_PENALTY,
           CHARGES,
           BENFNAME,
           BENFADD1,
           BENFADD2,
           BENFADD3,
           OTHERDETS,
           NARRATIVE,
           COUNTRY_CODE)
        VALUES
          (P_ICDREDMN.REDEM_REF_NO,
           NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN,
               P_TY_STDCUSAC.V_ICTMS_ACC.BRN),
           NVL(P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC,
               P_TY_STDCUSAC.V_ICTMS_ACC.ACC),
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.REF_NO,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.SCODE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XREF,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.MICR_NO,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.TRN_DT,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BANKCODE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_AMT,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_CCY,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.XRATE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYBRN,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.WAVE_PENALTY,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHARGES,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFNAME,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD1,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD2,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BENFADD3,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.OTHERDETS,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.NARRATIVE,
           P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.COUNTRY_CODE);
        DBG('Successfully Inserted into child bc payout details...');
      END IF;
      DBG('All Inserts Completed Successfully....');
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to Insert Redemption details. ' || SQLCODE || SQLERRM);
      P_ERR_CODE   := 'IC-REDMN-01';
      P_ERR_PARAMS := SUBSTR(SQLCODE || ':' || SQLERRM, 1, 255);
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      RETURN FALSE;
  END FN_INSERT_REDEMPTION_TBLS;

  FUNCTION FN_RECALC(P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                     P_EXT_REF       IN STTM_ACCLSR_PAYOUT_DTL.EXT_REF_NO%TYPE,
                     P_TY_PAYOUTDETS IN OUT TY_TB_PAYOUTDETS,
                     P_ERR_CODE      IN OUT VARCHAR2,
                     P_ERR_PARAM     IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR C_DETB_RTL_TELLER(P_REFNO VARCHAR2) IS
      SELECT *
        FROM DETB_RTL_TELLER
       WHERE XREF = P_EXT_REF
         AND TRN_REF_NO = P_REFNO;
  
  BEGIN
    DBG('>>>Coming into fn_recalc');
    DBG('p_payoutype :: ' || P_TY_PAYOUTDETS.COUNT);
  
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
        DBG('p_Ty_Payoutdets(i).REF_NO:: ' || P_TY_PAYOUTDETS(I).REF_NO);
        FOR L_DETB_PAYOUT_DTLS IN C_DETB_RTL_TELLER(P_TY_PAYOUTDETS(I)
                                                    .REF_NO) LOOP
          DBG('l_detb_payout_dtls.txn_amount :: ' ||
              L_DETB_PAYOUT_DTLS.TXN_AMOUNT);
          DBG('l_detb_payout_dtls.ofs_amount :: ' ||
              L_DETB_PAYOUT_DTLS.OFS_AMOUNT);
          DBG('l_detb_payout_dtls.trn_ref_no :: ' ||
              L_DETB_PAYOUT_DTLS.TRN_REF_NO);
        
          DBG('depks_rtl_teller.pkg_rtl_teller_rec.dr_acc :: ' ||
              DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.DR_ACC);
          IF DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.DR_ACC = 'TXN' THEN
            UPDATE STTM_ACCLSR_PAYOUT_DTL
               SET REDAMT = L_DETB_PAYOUT_DTLS.TXN_AMOUNT
             WHERE TRN_REF_NO = L_DETB_PAYOUT_DTLS.TRN_REF_NO;
          
            IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
              P_ICDREDMN.GL_TXN_AMT := L_DETB_PAYOUT_DTLS.TXN_AMOUNT;
              DBG('p_Icdredmn.gl_txn_amt for TXN :: ' ||
                  P_ICDREDMN.GL_TXN_AMT);
            END IF;
          
          ELSIF DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.DR_ACC = 'OFS' THEN
            UPDATE STTM_ACCLSR_PAYOUT_DTL
               SET REDAMT = L_DETB_PAYOUT_DTLS.OFS_AMOUNT
             WHERE TRN_REF_NO = L_DETB_PAYOUT_DTLS.TRN_REF_NO;
          
            IF P_TY_PAYOUTDETS(I).PAYOUTTYPE = 'C' THEN
              P_ICDREDMN.GL_TXN_AMT := L_DETB_PAYOUT_DTLS.OFS_AMOUNT;
              DBG('p_Icdredmn.gl_txn_amt for OFS :: ' ||
                  P_ICDREDMN.GL_TXN_AMT);
            END IF;
          END IF;
        
        END LOOP;
      END LOOP;
    END IF;
    DBG('SUCCESSFULLY CAME FROM FN_RECALC');
    RETURN TRUE;
  END FN_RECALC;

  FUNCTION FN_RDAMT(P_FROM_DATE          IN DATE,
                    P_TO_DATE            IN DATE,
                    P_BRN_CODE           ICTM_ACC.BRN%TYPE,
                    P_AC_NO              ICTM_ACC.ACC%TYPE,
                    P_RD_INSTALLMENT_AMT IN ICTM_ACC.RD_INSTALLMENT_AMT%TYPE,
                    P_RD_SCHEDULE_YEARS  IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE,
                    P_RD_SCHEDULE_MONTHS IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE,
                    P_RD_SCHEDULE_DAYS   IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE,
                    P_RD_PAY_SCHDT       IN OUT ICTM_ACC.RD_PAY_SCHDT%TYPE,
                    P_TOTAL_AMOUNT       IN OUT NUMBER) RETURN BOOLEAN IS
    L_COUNT     NUMBER := 0;
    L_FROM_DATE DATE;
    L_LAST_DATE DATE;
  
  BEGIN
  
    DBG('frm_date' || P_FROM_DATE);
    DBG('to_date' || P_TO_DATE);
    L_FROM_DATE := P_FROM_DATE;
  
    L_LAST_DATE := ADD_MONTHS(L_FROM_DATE,
                              12 * NVL(P_RD_SCHEDULE_YEARS, 0) +
                              NVL(P_RD_SCHEDULE_MONTHS, 0)) +
                   NVL(P_RD_SCHEDULE_DAYS, 0) - 1;
    DBG('l_last_date' || L_LAST_DATE);
  
    SELECT COUNT(*)
      INTO L_COUNT
      FROM STTM_RD_PAYMENTS_DET
     WHERE BRANCH_CODE = P_BRN_CODE
       AND RD_AC_NO = P_AC_NO
       AND
          
           DUE_DATE BETWEEN P_FROM_DATE AND P_TO_DATE;
    DBG('l_count-->' || L_COUNT);
  
    IF L_COUNT > 0 THEN
      P_TOTAL_AMOUNT := P_TOTAL_AMOUNT +
                        NVL(P_RD_INSTALLMENT_AMT * L_COUNT, 0);
      DBG('Total Amount' || P_TOTAL_AMOUNT);
      DBG('rd_installment_amt' || P_RD_INSTALLMENT_AMT);
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_rdamt with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_RDAMT;

  FUNCTION FN_MATURITY_AMOUNT_CALC(P_SOURCE           IN OUT VARCHAR2,
                                   P_MODULE           IN VARCHAR2,
                                   P_ACTION_CODE      IN OUT VARCHAR2,
                                   P_MULTI_TRIP_ID    IN OUT VARCHAR2,
                                   P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                   P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                                   P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                                   P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                                   P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   P_TBL_NODE         IN TBL_NODE,
                                   P_TBL_CHGDETS      IN OUT TBL_CHGDETS,
                                   P_UPL_MIS_DET      IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                                   P_UPL_UDF_DET      IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                                   P_OVERRIDE_FLAG    OUT VARCHAR2,
                                   P_ERR_TBL          IN OUT OVPKS.TBL_ERROR)
    RETURN BOOLEAN IS
    TOT_AMOUNT         NUMBER;
    TOT_INT_AMT        ICTB_ENTRIES.AMT%TYPE;
    L_FIN_YEAR         STTMS_FIN_CYCLE.FIN_CYCLE%TYPE;
    G_CALC_FROM        DATE;
    G_CALC_TO          DATE;
    L_TOT_AMOUNT       NUMBER;
    L_ADJ_AMOUNT       NUMBER := 0;
    L_INT_AMT          NUMBER := 0;
    L_LAST_DT          DATE;
    L_CCY              STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_ACCOUNT_CLASS    STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_PRODUCT_CODE     ICTM_PR_INT.PRODUCT_CODE%TYPE;
    L_LIQ_DAYS         ICTM_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS       ICTM_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YEARS        ICTM_PR_INT.LIQN_YEARS%TYPE;
    L_RULE             ICTM_PR_INT.RULE%TYPE;
    L_AC_OPEN_DATE     DATE;
    L_INT_START_DATE   DATE;
    L_LAST_DT1         DATE;
    L_AVG_BAL          NUMBER;
    L_NEWTENOR         NUMBER;
    L_ORIGINALTENOR    NUMBER;
    L_REDEM_AMT        ICTM_TD_DETAILS.REDEM_AMT%TYPE;
    L_REMAIN_AMT       ICTMS_TD_DETAILS.REDEM_AMT%TYPE;
    L_PROCESS          VARCHAR2(20);
    L_REMAIN_TD_AMOUNT ICTMS_TD_DETAILS.TD_AMOUNT%TYPE := 0;
    L_REDEM_AMOUNT     ICTMS_TD_DETAILS.REDEM_AMT%TYPE;
    L_RED_BAL          ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_RED_BAL1         ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_CALC_TO          DATE;
    L_ADJ_AMOUNT1      ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_ADJ_AMOUNT2      ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_TEMP_ORGTNR      NUMBER;
  
    L_FLAG         NUMBER := 0;
    L_BOOK_ACC     ICTMS_ACC.ACC%TYPE;
    L_PAYOUT_COUNT NUMBER;
  
    L_PROD    VARCHAR2(4);
    L_ADV_REQ VARCHAR2(1);
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_PR_INT_PAYMENT ICTM_PR_INT.PAYMENT_METHOD%TYPE;
    L_TD_DETAILS     ICTM_TD_DETAILS%ROWTYPE;
    L_AC_CLASS_TYPE  STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_RDFLAG         STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_ACCLASS        VARCHAR2(10);
    L_ICTM_ACC       ICTM_ACC%ROWTYPE;
    P_ERROR_CODES    VARCHAR2(2000);
    P_ERROR_PARAMS   VARCHAR2(2000);
    P_ERR_CODE       VARCHAR2(2000);
    P_ERR_PARAMS     VARCHAR2(2000);
    L_TOTAL_AMOUNT   NUMBER := 0;
    L_NEXT_LIQ_DT    ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_MATURITY_DATE  DATE;
    L_PAYOUT_AMT     NUMBER(22, 3) := 0;
  
    L_INV_TAX_AMOUNT NUMBER(22, 3) := 0;
    L_INV_INT_AMOUNT NUMBER(22, 3) := 0;
    L_TOT_TAX_AMOUNT NUMBER(22, 3) := 0;
    L_TOT_INT_AMOUNT NUMBER(22, 3) := 0;
  
    L_CAPITALIZATION BOOLEAN := FALSE;
  
    L_BRANCH STTMS_BRANCH%ROWTYPE;
    L_PR_INT ICTMS_PR_INT%ROWTYPE;
  
    L_LIQD_AMT  DBMS_SQL.NUMBER_TABLE;
    L_TAX_AMT   DBMS_SQL.NUMBER_TABLE;
    L_IACQUIRED ICTBS_ENTRIES.AMT%TYPE;
  
    L_PENALTY2         NUMBER := 0;
    L_CALC_PEN_INT_TAX NUMBER := 0;
  
    IS_LIQN      VARCHAR2(1) := 'Y';
    L_OFFSET_ACC ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;
  BEGIN
  
    ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
    ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
    IF P_ACTION_CODE IN ('TDRedemSave',
                         'TDRedemCompute',
                         'TDRedemAuthQry',
                         'TDRedemAuth',
                         'EnrichTDRedemption') THEN
      BEGIN
        DBG('Inside Projected Maturity Amount Calc::: ');
        SELECT DECODE(P_ICDREDMN.WAIVE_INTEREST, 'Y', 1, 'N', '0')
          INTO ICPKS_BOD.G_WAVE_INTEREST
          FROM DUAL;
      
        L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_ICDREDMN.BRN_CODE);
      
        BEGIN
        
          SELECT NVL(SUM(AMT), 0)
            INTO TOT_INT_AMT
            FROM ICTBS_ENTRIES_HISTORY E
           WHERE E.BRN = P_ICDREDMN.BRN_CODE
             AND E.ACC = P_ICDREDMN.AC_NO
             AND E.ENT_DT >=
                 (SELECT FC_START_DATE
                    FROM STTMS_FIN_CYCLE
                   WHERE FIN_CYCLE = L_BRANCH.CURRENT_CYCLE);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Getting Interst amount');
        END;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID      := 1;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        
          IF NOT
              ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                 P_MODULE,
                                                                 P_ACTION_CODE,
                                                                 P_MULTI_TRIP_ID,
                                                                 P_ICDREDMN,
                                                                 P_TY_PAYOUTDETS,
                                                                 P_BCPAYOUTDETS_REC,
                                                                 P_PCPAYOUTDETS_REC,
                                                                 P_TY_STDCUSAC,
                                                                 P_TBL_NODE,
                                                                 P_TBL_CHGDETS,
                                                                 P_UPL_MIS_DET,
                                                                 P_UPL_UDF_DET,
                                                                 P_OVERRIDE_FLAG,
                                                                 P_ERR_TBL,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
            DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_maturity_amount_calc');
            RETURN FALSE;
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('l_prod') THEN
            L_PROD := L_TB_CLUSTER_DATA('l_prod');
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
          BEGIN
          
            SELECT PROD
              INTO L_PROD
              FROM ICTBS_ACC_PR
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO
               AND PROD_TYPE = 'I';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed in selecting Product Code from ictb_redem_acc_pr.................');
          END;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      END;
    
      DBG('Product is ::: ' || L_PROD);
      DBG('p_icdredmn.brn_code-->' || P_ICDREDMN.BRN_CODE);
      DBG('p_icdredmn.ac_no--->' || P_ICDREDMN.AC_NO);
      DBG('p_icdredmn.redemption_amt-->' || P_ICDREDMN.REDEMPTION_AMT);
    
      IF P_ACTION_CODE IN
         ('TDRedemCompute', 'TDRedemSave', 'EnrichTDRedemption') THEN
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID := 1;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
          IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                    P_MODULE,
                                                    P_ACTION_CODE,
                                                    P_MULTI_TRIP_ID,
                                                    P_ICDREDMN,
                                                    P_TY_PAYOUTDETS,
                                                    P_BCPAYOUTDETS_REC,
                                                    P_PCPAYOUTDETS_REC,
                                                    P_TY_STDCUSAC,
                                                    P_TBL_NODE,
                                                    P_TBL_CHGDETS,
                                                    P_UPL_MIS_DET,
                                                    P_UPL_UDF_DET,
                                                    P_OVERRIDE_FLAG,
                                                    P_ERR_TBL,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA) THEN
            DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
          ELSE
            IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
              PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
            END IF;
          END IF;
        END IF;
      
        L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PROD);
      
        IF L_PR_INT.PAYMENT_METHOD = 'B' THEN
        
          SAVEPOINT PR_CALC;
          DBG('Entered');
        
          BEGIN
            SELECT *
              INTO L_ICTM_ACC
              FROM ICTM_ACC
             WHERE ACC = P_ICDREDMN.AC_NO
               AND BRN = P_ICDREDMN.BRN_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Inside of When others of ICTM_ACC' || SQLERRM);
          END;
        
          IF NVL(P_ICDREDMN.WAIVE_INTEREST, 'N') = 'N' THEN
            ICPKS_BOD.G_WAVE_INTEREST := 0;
          ELSE
            ICPKS_BOD.G_WAVE_INTEREST := 1;
          END IF;
          DBG('Entered111');
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            L_REMAIN_AMT := P_ICDREDMN.ACC_AMT;
          ELSE
            L_REMAIN_AMT := P_ICDREDMN.ACC_AMT - P_ICDREDMN.REDEMPTION_AMT;
          END IF;
          DBG('Entered222');
        
          DBG('Entered3333');
        
          DBG('Total Amount--->' || TOT_AMOUNT);
        
          BEGIN
            SELECT B.CCY,
                   C.AC_CLASS_TYPE,
                   C.ACCOUNT_CLASS,
                   D.PRODUCT_CODE,
                   D.LIQN_DAYS,
                   D.LIQN_MONTHS,
                   D.LIQN_YEARS,
                   D.RULE,
                   B.AC_OPEN_DATE,
                   TRUNC(NVL((GLOBAL.APPLICATION_DATE - E.INT_START_DATE),
                             1)) "NEWTENOR",
                   TRUNC(NVL((E.MATURITY_DATE - E.INT_START_DATE), 1)) "ORGINALTENOR",
                   E.INT_START_DATE
              INTO L_CCY,
                   L_AC_CLASS_TYPE,
                   L_ACCOUNT_CLASS,
                   L_PRODUCT_CODE,
                   L_LIQ_DAYS,
                   L_LIQ_MONTHS,
                   L_LIQ_YEARS,
                   L_RULE,
                   L_AC_OPEN_DATE,
                   L_NEWTENOR,
                   L_ORIGINALTENOR,
                   L_INT_START_DATE
            
              FROM STTMS_CUST_ACCOUNT  B,
                   STTMS_ACCOUNT_CLASS C,
                   ICTM_PR_INT         D,
                   ICTMS_ACC           E,
                   ICTM_PR_INT_ACLASS  F,
                   ICTBS_ACC_PR        G
             WHERE B.ACCOUNT_CLASS = C.ACCOUNT_CLASS
               AND B.BRANCH_CODE = E.BRN
               AND C.AC_CLASS_TYPE IN ('Y', 'S')
               AND B.CUST_AC_NO = E.ACC
               AND B.RECORD_STAT = 'O'
               AND B.AUTH_STAT = 'A'
               AND C.ACCOUNT_CLASS = F.ACLASS
               AND G.ACC = E.ACC
               AND G.BRN = E.BRN
               AND G.PROD = D.PRODUCT_CODE
               AND G.DEPOSIT = 'Y'
                  
               AND F.PRODUCT_CODE = D.PRODUCT_CODE
               AND F.RECORD_STAT = 'N'
               AND B.CCY = F.CCY
               AND (EXISTS (SELECT X.ACC
                              FROM ICTM_ACC_PR X
                             WHERE ACC = B.CUST_AC_NO
                               AND BRN = B.BRANCH_CODE
                               AND X.WAIVE = 'N') OR NOT EXISTS
                    (SELECT X.ACC
                       FROM ICTM_ACC_PR X
                      WHERE ACC = B.CUST_AC_NO
                        AND BRN = B.BRANCH_CODE))
               AND B.CUST_AC_NO = P_ICDREDMN.AC_NO
               AND B.BRANCH_CODE = P_ICDREDMN.BRN_CODE;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_CCY            := NULL;
              L_AC_CLASS_TYPE  := NULL;
              L_ACCOUNT_CLASS  := NULL;
              L_PRODUCT_CODE   := NULL;
              L_LIQ_DAYS       := NULL;
              L_LIQ_MONTHS     := NULL;
              L_LIQ_YEARS      := NULL;
              L_RULE           := NULL;
              L_AC_OPEN_DATE   := NULL;
              L_NEWTENOR       := NULL;
              L_ORIGINALTENOR  := NULL;
              L_INT_START_DATE := NULL;
              DBG('In no data found :: ' ||
                  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          END;
        
          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                      P_ICDREDMN.AC_NO,
                                                      'Y',
                                                      G_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          L_TOT_AMOUNT := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
        
          SELECT NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0)
            INTO L_AVG_BAL
            FROM ICTMS_TD_DETAILS
           WHERE BRN = P_ICDREDMN.BRN_CODE
             AND ACC = P_ICDREDMN.AC_NO;
          DBG('l_avg_bal-->' || L_AVG_BAL);
        
          IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
            ICPKSS_MAINT.PR_SET_REDEM_AMT(P_ICDREDMN.REDEMPTION_AMT);
            G_RELATEDPARTIAL_ACCOUNT := P_ICDREDMN.AC_NO;
            DBG('g_relatedpartial_account BY IS  :' ||
                G_RELATEDPARTIAL_ACCOUNT);
          
            ICPKS_BOD.G_PENALTY := P_ICDREDMN.REDEMPTION_AMT;
            DBG('icpks_bod.g_penalty is:' || ICPKS_BOD.G_PENALTY);
          
            DBG('p_icdredmn.WAVE_PENALTY is:' || P_ICDREDMN.WAVE_PENALTY);
            ICPKS_BOD.G_WAVE_PENALTY := P_ICDREDMN.WAVE_PENALTY;
            DBG('icpks_bod.g_wave_penalty is:' || ICPKS_BOD.G_WAVE_PENALTY);
          
          ELSE
            L_REDEM_AMT := NVL(P_ICDREDMN.ACC_AMT, 0);
            ICPKSS_MAINT.PR_SET_REDEM_AMT(L_REDEM_AMT);
          END IF;
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
          
            ICPKSS_MAINT.PR_SET_FULL_REDEM('Y');
          ELSE
            ICPKSS_MAINT.PR_SET_FULL_REDEM('N');
          END IF;
        
          L_AC_OPEN_DATE := L_INT_START_DATE;
        
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
          
            DBG('P_ICDREDMN.WAIVE_INTEREST:' || P_ICDREDMN.WAIVE_INTEREST);
            DBG('P_ICDREDMN.wave_penalty:' || P_ICDREDMN.WAVE_PENALTY);
            IF NVL(P_ICDREDMN.WAIVE_INTEREST, 'N') = 'Y' AND
               NVL(P_ICDREDMN.WAVE_PENALTY, 'N') = 'Y' THEN
              DBG('Waive Interest and Wave Penalty is Y');
            
              IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                          P_ICDREDMN.AC_NO,
                                                          'Y',
                                                          G_BALREC) THEN
                DEBUG.PR_DEBUG('AC',
                               'Failed in Get_Sttm_Account_Balance .. : ' ||
                               SQLERRM);
              END IF;
              P_ICDREDMN.MATURITY_AMOUNT := NVL(G_BALREC.ACY_CURR_ACC_BAL,
                                                0);
            
              P_ICDREDMN.INTEREST_AMOUNT := 0;
              P_ICDREDMN.TAX_AMOUNT      := 0;
              P_ICDREDMN.PAYOUT_AMOUNT   := P_ICDREDMN.MATURITY_AMOUNT;
            
            ELSE
            
              L_AC_OPEN_DATE := L_INT_START_DATE;
            
              IF L_ICTM_ACC.MATURITY_DATE <= GLOBAL.APPLICATION_DATE THEN
                P_ICDREDMN.MATURITY_AMOUNT := L_ICTM_ACC.MATURITY_AMOUNT;
                P_ICDREDMN.INTEREST_RATE   := L_ICTM_ACC.INTEREST_RATE;
              ELSE
              
                IF NOT STPKS_TD_REDEMPTION.FN_APPLY_RATE(P_ICDREDMN.BRN_CODE,
                                                         P_ICDREDMN.AC_NO,
                                                         L_AC_CLASS_TYPE,
                                                         L_ACCOUNT_CLASS,
                                                         L_PRODUCT_CODE,
                                                         L_CCY,
                                                         L_AVG_BAL,
                                                         L_NEWTENOR,
                                                         L_ORIGINALTENOR,
                                                         L_AC_OPEN_DATE,
                                                         'F') THEN
                  P_ERR_CODE := 'IC-MU0008';
                  DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                      SQLERRM);
                
                END IF;
              
                IF NOT
                    ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_ICDREDMN.BRN_CODE,
                                                        P_ICDREDMN.AC_NO,
                                                        P_ERROR_CODES,
                                                        P_ERROR_PARAMS) THEN
                  DBG('maint Resolution for acc gave error ' ||
                      P_ERROR_CODES || '~' || P_ERROR_PARAMS);
                END IF;
              
                BEGIN
                  SELECT COUNT(1)
                    INTO L_PAYOUT_COUNT
                    FROM ICTM_TDPAYOUT_DETAILS
                   WHERE BRN = P_ICDREDMN.BRN_CODE
                     AND ACC = P_ICDREDMN.AC_NO
                     AND PAYOUT_COMPONENT = 'I';
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('No Payout For Interest');
                    L_PAYOUT_COUNT := 0;
                END;
                IF L_PAYOUT_COUNT = 0 AND
                   L_ICTM_ACC.BOOK_ACC = L_ICTM_ACC.ACC THEN
                  L_CAPITALIZATION := TRUE;
                END IF;
              
                FOR J IN 1 .. 2 LOOP
                  IF J = 1 THEN
                    G_CALC_FROM := L_AC_OPEN_DATE;
                  
                    SELECT MAX(ENT_DT)
                      INTO G_CALC_TO
                      FROM ICTBS_ENTRIES_HISTORY A
                     WHERE A.ACC = P_ICDREDMN.AC_NO
                       AND A.BRN = P_ICDREDMN.BRN_CODE
                       AND A.LIQN = 'Y'
                       AND A.ENTRY_PASSED = 'Y';
                  
                    DBG('g_calc_to when j=1 is : ' || G_CALC_TO);
                    IF G_CALC_TO IS NULL THEN
                      IS_LIQN   := 'N';
                      G_CALC_TO := L_AC_OPEN_DATE - 1;
                    
                      ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
                      ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
                    ELSE
                      ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := TRUE;
                      ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
                    
                    END IF;
                  
                    PKG_PENALTY_APPLY := 0;
                  ELSE
                  
                    G_CALC_FROM := G_CALC_TO + 1;
                  
                    G_CALC_TO := NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                     GLOBAL.APPLICATION_DATE) - 1;
                  
                    PKG_PENALTY_APPLY               := 1;
                    ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
                    ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
                  END IF;
                
                  DBG('From Date--->' || G_CALC_FROM);
                  DBG('To Date----->' || G_CALC_TO);
                
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 2;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('Pkg_Rate_Chart') := PKG_RATE_CHART;
                    L_TB_CLUSTER_DATA('j') := J;
                    L_TB_CLUSTER_DATA('g_calc_from') := G_CALC_FROM;
                    IF NOT
                        ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                           P_MODULE,
                                                                           P_ACTION_CODE,
                                                                           P_MULTI_TRIP_ID,
                                                                           P_ICDREDMN,
                                                                           P_TY_PAYOUTDETS,
                                                                           P_BCPAYOUTDETS_REC,
                                                                           P_PCPAYOUTDETS_REC,
                                                                           P_TY_STDCUSAC,
                                                                           P_TBL_NODE,
                                                                           P_TBL_CHGDETS,
                                                                           P_UPL_MIS_DET,
                                                                           P_UPL_UDF_DET,
                                                                           P_OVERRIDE_FLAG,
                                                                           P_ERR_TBL,
                                                                           L_FN_CALL_ID,
                                                                           L_TB_CLUSTER_DATA) THEN
                      DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
                    ELSE
                      IF L_TB_CLUSTER_DATA.EXISTS('Pkg_Rate_Chart') THEN
                        PKG_RATE_CHART := L_TB_CLUSTER_DATA('Pkg_Rate_Chart');
                      END IF;
                    
                      IF L_TB_CLUSTER_DATA.EXISTS('g_calc_from') THEN
                        G_CALC_FROM := L_TB_CLUSTER_DATA('g_calc_from');
                      END IF;
                    
                    END IF;
                  END IF;
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                
                  IF J = 1 AND PKG_RATE_CHART = 'Y' THEN
                  
                    IF NOT
                        STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                    P_ICDREDMN.BRN_CODE) THEN
                      IF NVL(L_ICTM_ACC.RD_FLAG, 'N') = 'N' AND
                         IS_LIQN = 'Y' THEN
                        BEGIN
                          DELETE FROM ICTBS_INT_LIQ_DETAILS
                           WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
                             AND ACCOUNT_NUMBER = P_ICDREDMN.AC_NO;
                        EXCEPTION
                          WHEN OTHERS THEN
                            DBG('FAiled in Deleting ');
                        END;
                      END IF;
                    END IF;
                  
                    IF IS_LIQN = 'N' THEN
                      DBG('No Liquidation has happened. Adjusting l_avg_bal');
                      DBG('iAM HERE TO take l_avg_bal');
                      BEGIN
                        SELECT LIQ_AMT
                          INTO L_AVG_BAL
                          FROM ICTBS_INT_LIQ_DETAILS I
                         WHERE I.BRANCH_CODE = P_ICDREDMN.BRN_CODE
                           AND I.ACCOUNT_NUMBER = P_ICDREDMN.AC_NO
                           AND TO_DATE =
                               (SELECT MAX(TO_DATE)
                                  FROM ICTBS_INT_LIQ_DETAILS J
                                 WHERE J.BRANCH_CODE = P_ICDREDMN.BRN_CODE
                                   AND J.ACCOUNT_NUMBER = P_ICDREDMN.AC_NO);
                        DBG('l_avg_bal got here BEFORE EXCEPTION is ->' ||
                            L_AVG_BAL);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('Inside when others of l_avg_bal');
                          SELECT (NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0))
                            INTO L_AVG_BAL
                            FROM ICTMS_TD_DETAILS J
                           WHERE J.BRN = P_ICDREDMN.BRN_CODE
                             AND J.ACC = P_ICDREDMN.AC_NO;
                          DBG('l_avg_bal got as :' || L_AVG_BAL);
                      END;
                    END IF;
                  
                    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                       NVL(L_LIQ_DAYS, 0) = 0 THEN
                      IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
                        L_LAST_DT := G_CALC_FROM;
                      ELSE
                        L_LAST_DT := G_CALC_TO;
                      END IF;
                    ELSE
                    
                      L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                              12 * L_LIQ_YEARS +
                                              L_LIQ_MONTHS) + L_LIQ_DAYS - 1;
                    
                      SELECT LEAST(NVL(MIN(ENT_DT), L_LAST_DT), L_LAST_DT)
                        INTO L_LAST_DT
                        FROM ICTBS_ENTRIES_HISTORY A
                       WHERE A.ACC = P_ICDREDMN.AC_NO
                         AND A.BRN = P_ICDREDMN.BRN_CODE
                         AND A.LIQN = 'Y'
                         AND A.PROD = L_PRODUCT_CODE
                         AND A.ENT_DT >= L_INT_START_DATE
                         AND A.ENTRY_PASSED = 'Y';
                    
                      IF L_LAST_DT > G_CALC_TO THEN
                        L_LAST_DT := G_CALC_TO;
                      END IF;
                    
                    END IF;
                  
                    DBG('l_last_dt-->' || L_LAST_DT);
                    DBG('g_calc_to-->' || G_CALC_TO);
                    DBG('From Date111--->' || G_CALC_FROM);
                  
                    IF L_ICTM_ACC.RD_FLAG = 'Y' THEN
                    
                      BEGIN
                        IF NOT FN_RDAMT(G_CALC_FROM,
                                        G_CALC_TO,
                                        P_ICDREDMN.BRN_CODE,
                                        P_ICDREDMN.AC_NO,
                                        L_ICTM_ACC.RD_INSTALLMENT_AMT,
                                        L_ICTM_ACC.RD_TAKEDOWN_YEARS,
                                        L_ICTM_ACC.RD_TAKEDOWN_MONTHS,
                                        L_ICTM_ACC.RD_TAKEDOWN_DAYS,
                                        L_ICTM_ACC.RD_PAY_SCHDT,
                                        L_AVG_BAL) THEN
                          DBG('failed in the function call');
                        END IF;
                      
                        DBG('success');
                      
                        DBG('l_total_amount' || L_AVG_BAL);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('failed here');
                      END;
                    
                      INSERT INTO ICTBS_INT_LIQ_DETAILS
                        (ACCOUNT_NUMBER,
                         BRANCH_CODE,
                         FROM_DATE,
                         TO_DATE,
                         LIQ_AMT)
                      VALUES
                        (L_ICTM_ACC.ACC,
                         L_ICTM_ACC.BRN,
                         G_CALC_FROM - 1,
                         G_CALC_FROM,
                         L_AVG_BAL);
                    END IF;
                    WHILE (L_LAST_DT <= G_CALC_TO) LOOP
                      DBG('From Date111--->' || G_CALC_FROM);
                      DBG('To Date111----->' || G_CALC_TO);
                      DBG('l_last_dt----->' || L_LAST_DT);
                    
                      IF L_LAST_DT = G_CALC_TO AND
                         G_CALC_TO = GLOBAL.APPLICATION_DATE - 1 THEN
                        DBG('this is for redemption on very first day of after liquidation');
                        PKG_PENALTY_APPLY := 1;
                      END IF;
                    
                      IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                G_CALC_FROM,
                                                L_LAST_DT,
                                                L_RULE,
                                                L_PRODUCT_CODE,
                                                P_ERROR_CODES,
                                                P_ERROR_PARAMS) THEN
                        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        DBG('ERROR IN STPKS_TD_REDEMPTION.PR_BROKEN_TD---> ' ||
                            SQLERRM);
                      
                      END IF;
                    
                      BEGIN
                        DBG('The product code is:' || L_PRODUCT_CODE);
                        SELECT SUM(AMT)
                          INTO L_ADJ_AMOUNT
                          FROM ICTW_MEMO_BOOKING
                         WHERE BRN = P_ICDREDMN.BRN_CODE
                           AND ACC = P_ICDREDMN.AC_NO
                           AND PROD = L_PRODUCT_CODE
                           AND DRCR_IND = 'C';
                        DBG('The interest amount is:' || L_ADJ_AMOUNT);
                        P_ICDREDMN.INTEREST_AMOUNT := L_ADJ_AMOUNT;
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('The exception is  raised as:' || SQLERRM);
                          NULL;
                      END;
                    
                      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                        INTO L_ADJ_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE;
                    
                      DBG('l_adj_amount----->' || L_ADJ_AMOUNT);
                    
                      L_CALC_PEN_INT_TAX := L_CALC_PEN_INT_TAX +
                                            L_ADJ_AMOUNT;
                      DBG('l_calc_pen_int_tax in j=1----->' ||
                          L_CALC_PEN_INT_TAX);
                      SELECT SUM(AMT)
                        INTO L_PENALTY2
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE
                         AND DRCR_IND = 'D'
                         AND IS_TAX <> 'Y';
                    
                      DBG('l_penalty2' || L_PENALTY2);
                    
                      SELECT NVL(SUM(DECODE(IS_TAX,
                                            'Y',
                                            DECODE(DRCR_IND, 'D', AMT))),
                                 0)
                        INTO P_ICDREDMN.TAX_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE;
                      P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.REDEMPTION_AMT +
                                                  NVL(P_ICDREDMN.INTEREST_AMOUNT,
                                                      0) - NVL(P_ICDREDMN.TAX_AMOUNT,
                                                               0);
                      DBG('Tax Amount ' || P_ICDREDMN.TAX_AMOUNT);
                      DBG('Interest Amount ' || P_ICDREDMN.INTEREST_AMOUNT);
                      DBG('Payout Amount ' || P_ICDREDMN.PAYOUT_AMOUNT);
                    
                      IF L_CAPITALIZATION THEN
                        L_AVG_BAL := L_AVG_BAL + L_ADJ_AMOUNT;
                      END IF;
                      DBG('l_avg_bal----->' || L_AVG_BAL);
                      IF L_ICTM_ACC.RD_FLAG = 'Y' THEN
                      
                        BEGIN
                          IF NOT FN_RDAMT(G_CALC_FROM,
                                          L_LAST_DT,
                                          P_ICDREDMN.BRN_CODE,
                                          P_ICDREDMN.AC_NO,
                                          L_ICTM_ACC.RD_INSTALLMENT_AMT,
                                          L_ICTM_ACC.RD_TAKEDOWN_YEARS,
                                          L_ICTM_ACC.RD_TAKEDOWN_MONTHS,
                                          L_ICTM_ACC.RD_TAKEDOWN_DAYS,
                                          L_ICTM_ACC.RD_PAY_SCHDT,
                                          L_AVG_BAL) THEN
                            DBG('failed in the function call');
                          END IF;
                          DBG('l_total_amount' || L_AVG_BAL);
                          BEGIN
                            INSERT INTO ICTBS_INT_LIQ_DETAILS
                              (ACCOUNT_NUMBER,
                               BRANCH_CODE,
                               FROM_DATE,
                               TO_DATE,
                               LIQ_AMT)
                            VALUES
                              (P_ICDREDMN.AC_NO,
                               P_ICDREDMN.BRN_CODE,
                               G_CALC_FROM,
                               L_LAST_DT,
                               L_AVG_BAL);
                          EXCEPTION
                            WHEN OTHERS THEN
                              DBG('Failed ---->' || SQLERRM);
                          END;
                        
                        EXCEPTION
                          WHEN OTHERS THEN
                            DBG('failed here');
                        END;
                      ELSE
                        IF NOT
                            STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                        P_ICDREDMN.BRN_CODE) THEN
                          IF L_CAPITALIZATION THEN
                            BEGIN
                              INSERT INTO ICTBS_INT_LIQ_DETAILS
                                (ACCOUNT_NUMBER,
                                 BRANCH_CODE,
                                 FROM_DATE,
                                 TO_DATE,
                                 LIQ_AMT)
                              VALUES
                                (P_ICDREDMN.AC_NO,
                                 P_ICDREDMN.BRN_CODE,
                                 G_CALC_FROM,
                                 L_LAST_DT,
                                 L_AVG_BAL);
                            EXCEPTION
                              WHEN OTHERS THEN
                                DBG('Failed ---->' || SQLERRM);
                            END;
                          END IF;
                        
                          DBG('Deleting ictw_memo_booking');
                        END IF;
                      END IF;
                      DELETE FROM ICTW_MEMO_BOOKING A
                       WHERE A.BRN = P_ICDREDMN.BRN_CODE
                         AND A.ACC = P_ICDREDMN.AC_NO
                         AND A.PROD = L_PRODUCT_CODE;
                    
                      IF NVL(L_LIQ_YEARS, 0) = 0 AND
                         NVL(L_LIQ_MONTHS, 0) = 0 AND
                         NVL(L_LIQ_DAYS, 0) = 0 THEN
                        EXIT;
                      END IF;
                    
                      EXIT WHEN L_LAST_DT >= G_CALC_TO;
                      G_CALC_FROM := L_LAST_DT + 1;
                      L_LAST_DT   := ADD_MONTHS(L_LAST_DT,
                                                12 * L_LIQ_YEARS +
                                                L_LIQ_MONTHS) + L_LIQ_DAYS;
                      DBG('l_last_dt---->' || L_LAST_DT);
                    
                      IF L_LAST_DT >= G_CALC_TO THEN
                        L_LAST_DT := G_CALC_TO;
                        DBG('l_last_dt in if2' || L_LAST_DT);
                      END IF;
                    
                    END LOOP;
                  
                  ELSIF J = 2 THEN
                  
                    DBG('Here j is 2');
                    DBG('g_calc_from--->' || G_CALC_FROM);
                    DBG('g_calc_to--->' || G_CALC_TO);
                    DELETE FROM ICTW_MEMO_BOOKING A
                     WHERE A.BRN = P_ICDREDMN.BRN_CODE
                       AND A.ACC = P_ICDREDMN.AC_NO
                       AND A.PROD = L_PRODUCT_CODE;
                    IF L_ICTM_ACC.RD_FLAG = 'Y' THEN
                    
                      BEGIN
                        IF NOT FN_RDAMT(G_CALC_FROM,
                                        G_CALC_TO,
                                        P_ICDREDMN.BRN_CODE,
                                        P_ICDREDMN.AC_NO,
                                        L_ICTM_ACC.RD_INSTALLMENT_AMT,
                                        L_ICTM_ACC.RD_TAKEDOWN_YEARS,
                                        L_ICTM_ACC.RD_TAKEDOWN_MONTHS,
                                        L_ICTM_ACC.RD_TAKEDOWN_DAYS,
                                        L_ICTM_ACC.RD_PAY_SCHDT,
                                        L_AVG_BAL) THEN
                          DBG('failed in the function call');
                        END IF;
                        DBG('l_total_amount' || L_AVG_BAL);
                        IF NOT
                            STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                        P_ICDREDMN.BRN_CODE) THEN
                          IF L_CAPITALIZATION THEN
                            BEGIN
                              INSERT INTO ICTBS_INT_LIQ_DETAILS
                                (ACCOUNT_NUMBER,
                                 BRANCH_CODE,
                                 FROM_DATE,
                                 TO_DATE,
                                 LIQ_AMT)
                              VALUES
                                (P_ICDREDMN.AC_NO,
                                 P_ICDREDMN.BRN_CODE,
                                 G_CALC_FROM,
                                 G_CALC_TO,
                                 L_AVG_BAL);
                            EXCEPTION
                              WHEN OTHERS THEN
                                DBG('Failed ---->' || SQLERRM);
                            END;
                          END IF;
                        END IF;
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('failed here');
                      END;
                    
                    END IF;
                  
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CUSTOM,
                        CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                      L_FN_CALL_ID := 3;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('Pkg_Rate_Chart') := PKG_RATE_CHART;
                      IF NOT
                          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                             P_MODULE,
                                                                             P_ACTION_CODE,
                                                                             P_MULTI_TRIP_ID,
                                                                             P_ICDREDMN,
                                                                             P_TY_PAYOUTDETS,
                                                                             P_BCPAYOUTDETS_REC,
                                                                             P_PCPAYOUTDETS_REC,
                                                                             P_TY_STDCUSAC,
                                                                             P_TBL_NODE,
                                                                             P_TBL_CHGDETS,
                                                                             P_UPL_MIS_DET,
                                                                             P_UPL_UDF_DET,
                                                                             P_OVERRIDE_FLAG,
                                                                             P_ERR_TBL,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                        DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
                      ELSE
                        IF L_TB_CLUSTER_DATA.EXISTS('Pkg_Rate_Chart') THEN
                          PKG_RATE_CHART := L_TB_CLUSTER_DATA('Pkg_Rate_Chart');
                        END IF;
                      END IF;
                    END IF;
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  
                    IF PKG_RATE_CHART = 'N' THEN
                    
                      IF NOT
                          CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                               P_ICDREDMN.AC_NO,
                                                               'Y',
                                                               G_BALREC) THEN
                        DEBUG.PR_DEBUG('AC',
                                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                                       SQLERRM);
                      END IF;
                      L_AVG_BAL := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
                    
                    END IF;
                  
                    IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                              P_ICDREDMN.AC_NO,
                                              G_CALC_FROM,
                                              G_CALC_TO,
                                              L_RULE,
                                              L_PRODUCT_CODE,
                                              P_ERROR_CODES,
                                              P_ERROR_PARAMS) THEN
                      DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      DBG('ERROR IN STPKS_TD_REDEMPTION.PR_BROKEN_TD---> ' ||
                          SQLERRM);
                    
                    END IF;
                  
                    SELECT SUM(AMT)
                      INTO L_ADJ_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE
                       AND DRCR_IND = 'D'
                       AND IS_TAX = 'Y';
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD5 := L_ADJ_AMOUNT;
                    DBG('Tax amount is ' || L_ADJ_AMOUNT);
                  
                    SELECT SUM(AMT)
                      INTO L_ADJ_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE
                       AND DRCR_IND = 'D'
                       AND IS_TAX <> 'Y';
                  
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD4 := NVL(L_ADJ_AMOUNT,
                                                                                         0) +
                                                                                     NVL(L_PENALTY2,
                                                                                         0);
                    DBG('Penalty ' || L_ADJ_AMOUNT);
                  
                    SELECT SUM(AMT)
                      INTO L_ADJ_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE
                       AND DRCR_IND = 'C';
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD6 := L_ADJ_AMOUNT;
                    DBG('Interest ' || L_ADJ_AMOUNT);
                  
                    DBG('The b4 interest amount in full redemption 1 is:' ||
                        P_ICDREDMN.INTEREST_AMOUNT);
                    P_ICDREDMN.INTEREST_AMOUNT            := L_ADJ_AMOUNT;
                    STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST := P_ICDREDMN.INTEREST_AMOUNT;
                    DBG('The after interest amount in full redemption 1 is:' ||
                        P_ICDREDMN.INTEREST_AMOUNT);
                  
                    SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                      INTO L_ADJ_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE;
                  
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD3 := L_ADJ_AMOUNT -
                                                                                     NVL(L_PENALTY2,
                                                                                         0);
                    DBG('l_tot_amount33----->' || L_TOT_AMOUNT);
                  
                    L_CALC_PEN_INT_TAX := L_CALC_PEN_INT_TAX + L_ADJ_AMOUNT;
                    DBG('l_calc_pen_int_tax in j=2----->' ||
                        L_CALC_PEN_INT_TAX);
                  
                    DBG('l_tot_amount33----->' || L_TOT_AMOUNT);
                    L_TOT_AMOUNT := L_TOT_AMOUNT + L_ADJ_AMOUNT;
                    DBG('l_adj_amount----->' || L_ADJ_AMOUNT);
                    DBG('l_tot_amount22----->' || L_TOT_AMOUNT);
                    DBG('l_avg_bal----->' || L_AVG_BAL);
                    IF L_CAPITALIZATION THEN
                      L_AVG_BAL := L_AVG_BAL + L_ADJ_AMOUNT;
                      DBG('l_avg_bal22----->' || L_AVG_BAL);
                    END IF;
                  
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CUSTOM,
                        CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                      L_FN_CALL_ID := 4;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('Pkg_Rate_Chart') := PKG_RATE_CHART;
                      IF NOT
                          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                             P_MODULE,
                                                                             P_ACTION_CODE,
                                                                             P_MULTI_TRIP_ID,
                                                                             P_ICDREDMN,
                                                                             P_TY_PAYOUTDETS,
                                                                             P_BCPAYOUTDETS_REC,
                                                                             P_PCPAYOUTDETS_REC,
                                                                             P_TY_STDCUSAC,
                                                                             P_TBL_NODE,
                                                                             P_TBL_CHGDETS,
                                                                             P_UPL_MIS_DET,
                                                                             P_UPL_UDF_DET,
                                                                             P_OVERRIDE_FLAG,
                                                                             P_ERR_TBL,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                        DBG('Failed in call 1 to icpks_fcj_icdredmn_cluster.fn_main');
                      ELSE
                        IF L_TB_CLUSTER_DATA.EXISTS('Pkg_Rate_Chart') THEN
                          PKG_RATE_CHART := L_TB_CLUSTER_DATA('Pkg_Rate_Chart');
                        END IF;
                      END IF;
                    END IF;
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  
                    SELECT NVL(SUM(DECODE(IS_TAX,
                                          'Y',
                                          DECODE(DRCR_IND, 'D', AMT))),
                               0)
                      INTO P_ICDREDMN.TAX_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE;
                    P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.REDEMPTION_AMT +
                                                NVL(P_ICDREDMN.INTEREST_AMOUNT,
                                                    0) - NVL(P_ICDREDMN.TAX_AMOUNT,
                                                             0);
                    DBG('Tax Amount ' || P_ICDREDMN.TAX_AMOUNT);
                    DBG('Interest Amount ' || P_ICDREDMN.INTEREST_AMOUNT);
                    DBG('Payout Amount ' || P_ICDREDMN.PAYOUT_AMOUNT);
                  
                  END IF;
                
                  IF L_INT_START_DATE < GLOBAL.APPLICATION_DATE THEN
                    SELECT NVL(SUM(DECODE(DRCR,
                                          'C',
                                          ACQUIRED_AMT,
                                          -ACQUIRED_AMT)),
                               0)
                      INTO L_IACQUIRED
                      FROM ICTBS_ENTRIES
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE;
                  END IF;
                  DBG('l_iacquired' || L_IACQUIRED);
                
                  IF L_CAPITALIZATION THEN
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD7 := L_AVG_BAL +
                                                                                     L_IACQUIRED;
                    DBG('capitalization TD net payable amount----->' ||
                        ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD7);
                  ELSE
                    IF NOT
                        STPKS_TD_REDEMPTION.FN_FIND_LIQD_AMT(P_ICDREDMN.BRN_CODE,
                                                             P_ICDREDMN.AC_NO,
                                                             L_PRODUCT_CODE,
                                                             L_LIQD_AMT,
                                                             L_TAX_AMT,
                                                             P_ERR_CODE) THEN
                      DBG('For non capitalization TD accounts');
                    END IF;
                  
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD7 := L_AVG_BAL +
                                                                                     L_CALC_PEN_INT_TAX -
                                                                                     FN_AMT_TAX_LIQ_TILLDATE(L_TAX_AMT) +
                                                                                     L_IACQUIRED;
                    DBG('Non Capitalization TD net payable amount----->' ||
                        TO_CHAR(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD7 -
                                FN_AMT_TAX_LIQ_TILLDATE(L_TAX_AMT)));
                    DBG('Check for non capitalization' ||
                        ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD7);
                  
                  END IF;
                
                  DBG('Before posting adj entries  for the broken TD1..');
                  DELETE FROM ICTW_MEMO_BOOKING A
                   WHERE A.BRN = P_ICDREDMN.BRN_CODE
                     AND A.ACC = P_ICDREDMN.AC_NO
                     AND A.PROD = L_PRODUCT_CODE;
                
                  DBG('Flushing Memo accrulas:' || SQL%ROWCOUNT);
                  DBG('Coming out of the loop');
                END LOOP;
              
                DBG('P_ICDREDMN.WAIVE_INTEREST:' ||
                    P_ICDREDMN.WAIVE_INTEREST);
                DBG('P_ICDREDMN.wave_penalty:' || P_ICDREDMN.WAVE_PENALTY);
                DBG('l_avg_bal:' || L_AVG_BAL);
              
                P_ICDREDMN.MATURITY_AMOUNT := L_AVG_BAL;
                DBG('Maturity Amount  :' || P_ICDREDMN.MATURITY_AMOUNT);
              
              END IF;
            END IF;
          
          ELSE
          
            DBG('Partial Redemption Starts--->');
            BEGIN
              SELECT COUNT(*), ACC
                INTO L_PAYOUT_COUNT, L_BOOK_ACC
                FROM ICTM_TDPAYOUT_DETAILS
               WHERE BRN = P_ICDREDMN.BRN_CODE
                 AND ACC = P_ICDREDMN.AC_NO
                 AND PAYOUT_COMPONENT = 'I'
               GROUP BY ACC;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('No Payout For Interest');
                L_PAYOUT_COUNT := 0;
                L_BOOK_ACC     := P_ICDREDMN.AC_NO;
            END;
          
            IF L_ICTM_ACC.BOOK_ACC = P_ICDREDMN.AC_NO AND
               L_PAYOUT_COUNT = 0 THEN
            
              BEGIN
                SELECT NVL(SUM(DECODE(DRCR, 'C', AMT, -AMT)), 0)
                  INTO L_INT_AMT
                  FROM ICTB_ENTRIES_HISTORY
                 WHERE ACC = P_ICDREDMN.AC_NO
                   AND BRN = P_ICDREDMN.BRN_CODE
                   AND LIQN = 'Y';
              
              EXCEPTION
                WHEN OTHERS THEN
                  ICPKSS_UTIL.DBG('Error in Selection l_credit_amt from ICTB_ENTRIES_HISTORY');
                  L_INT_AMT := 0;
              END;
              DBG('L_INT_AMT-->' || L_INT_AMT);
              DBG('L_REMAIN_AMT--->' || L_REMAIN_AMT);
            
              L_RED_BAL      := P_ICDREDMN.REDEMPTION_AMT;
              L_REDEM_AMOUNT := P_ICDREDMN.REDEMPTION_AMT;
            
              L_RED_BAL1         := L_REMAIN_AMT;
              L_REMAIN_TD_AMOUNT := L_REMAIN_AMT;
            
              DBG('l_remain_td_amount--->' || L_REMAIN_TD_AMOUNT);
            
              L_TEMP_ORGTNR := L_ORIGINALTENOR;
              FOR J IN 1 .. 2 LOOP
              
                SELECT DECODE(J,
                              1,
                              'REDEM AMOUNT',
                              2,
                              'REMAINING AMOUNT',
                              3,
                              'REDEM AMOUNT',
                              4,
                              'REMAINING AMOUNT')
                  INTO L_PROCESS
                  FROM DUAL;
              
                DBG('Processing j----->' || J);
                DBG('Processing------->' || L_PROCESS);
              
                SELECT DECODE(J,
                              1,
                              L_REDEM_AMOUNT,
                              2,
                              L_REMAIN_TD_AMOUNT,
                              3,
                              L_REDEM_AMOUNT,
                              4,
                              L_REMAIN_TD_AMOUNT)
                  INTO G_BROKEN_AMOUNT
                  FROM DUAL;
              
                DBG('amount---->' || G_BROKEN_AMOUNT);
              
                SELECT DECODE(J,
                              1,
                              L_NEWTENOR,
                              2,
                              L_TEMP_ORGTNR,
                              3,
                              L_NEWTENOR,
                              4,
                              L_TEMP_ORGTNR)
                  INTO G_TENOR
                  FROM DUAL;
              
                DBG('tenor----->' || G_TENOR);
              
                IF J = 1 THEN
                  DBG('Its a Redemption amount, so setting redemption flag as true');
                  ICPKS_FCJ_ICDREDMN.G_REDM_FLAG := TRUE;
                ELSE
                  DBG('Its a Remaining amount, so setting redemption flag as false');
                  ICPKS_FCJ_ICDREDMN.G_REDM_FLAG := FALSE;
                END IF;
              
                IF J IN (1, 2) THEN
                  G_CALC_FROM := L_AC_OPEN_DATE;
                
                  BEGIN
                    SELECT MAX(ENT_DT)
                      INTO G_CALC_TO
                      FROM ICTBS_ENTRIES_HISTORY A
                     WHERE A.ACC = P_ICDREDMN.AC_NO
                       AND A.BRN = P_ICDREDMN.BRN_CODE
                       AND A.LIQN = 'Y'
                       AND A.ENTRY_PASSED = 'Y';
                  
                    IF J = 1 THEN
                      IF G_CALC_TO IS NULL THEN
                        DBG('Liqn has not happened');
                        ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
                        ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
                      ELSE
                        DBG('Liqn has  happened');
                        ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := TRUE;
                        ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
                      END IF;
                    END IF;
                  
                    IF G_CALC_TO IS NULL THEN
                      G_CALC_TO := L_AC_OPEN_DATE - 1;
                    END IF;
                    DBG('g_calc_to when j=1 is : ' || G_CALC_TO);
                  
                  END;
                
                  IF ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE IS NOT NULL THEN
                    DBG('from ICDRDSIM,there is a Redemption execution date');
                    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                       NVL(L_LIQ_DAYS, 0) = 0 THEN
                      IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
                        L_LAST_DT := G_CALC_FROM;
                      ELSE
                        L_LAST_DT := G_CALC_TO;
                      END IF;
                    ELSE
                    
                      L_LAST_DT := ADD_MONTHS(G_CALC_TO,
                                              12 * L_LIQ_YEARS +
                                              L_LIQ_MONTHS) + L_LIQ_DAYS;
                      DBG('l_last_dt' || L_LAST_DT);
                      DBG('icpks_fcj_icdredmn.g_redm_exec_date' ||
                          ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE);
                    END IF;
                    WHILE (L_LAST_DT <= ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE) LOOP
                      DBG('inside future dated simulation CALCULATIONS');
                      DBG('From Date111--->' || G_CALC_TO);
                      DBG('To Date111----->' || L_LAST_DT);
                      DBG('l_last_dt----->' || L_LAST_DT);
                    
                      IF L_LAST_DT = ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE AND
                         ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE =
                         GLOBAL.APPLICATION_DATE - 1 THEN
                        DBG('this is for redemption on very first day of after liquidation');
                        PKG_PENALTY_APPLY := 1;
                      END IF;
                      G_CALC_TO  := L_LAST_DT + 1;
                      L_LAST_DT1 := L_LAST_DT;
                    
                      L_LAST_DT := ADD_MONTHS(L_LAST_DT,
                                              12 * L_LIQ_YEARS +
                                              L_LIQ_MONTHS) + L_LIQ_DAYS;
                      DBG('l_last_dt1111----->' || L_LAST_DT);
                      IF NVL(L_LIQ_YEARS, 0) = 0 AND
                         NVL(L_LIQ_MONTHS, 0) = 0 AND
                         NVL(L_LIQ_DAYS, 0) = 0 THEN
                        EXIT;
                      END IF;
                    
                    END LOOP;
                  END IF;
                
                  DBG('g_calc_to111---->' || G_CALC_TO);
                  PKG_PENALTY_APPLY := 0;
                
                END IF;
              
                DBG('From Date--->' || G_CALC_FROM);
                DBG('To Date----->' || G_CALC_TO);
              
                IF J = 2 THEN
                
                  STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := TRUE;
                ELSE
                  STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;
                END IF;
              
                IF NOT STPKS_TD_REDEMPTION.FN_APPLY_RATE(P_ICDREDMN.BRN_CODE,
                                                         P_ICDREDMN.AC_NO,
                                                         L_AC_CLASS_TYPE,
                                                         L_ACCOUNT_CLASS,
                                                         L_PRODUCT_CODE,
                                                         L_CCY,
                                                         G_BROKEN_AMOUNT,
                                                         G_TENOR,
                                                         L_ORIGINALTENOR,
                                                         L_AC_OPEN_DATE,
                                                         'P') THEN
                  P_ERR_CODE := 'IC-MU0008';
                  DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                      SQLERRM);
                  RETURN FALSE;
                
                END IF;
              
                DBG('goin for resolution ');
                IF NOT
                    ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_ICDREDMN.BRN_CODE,
                                                        P_ICDREDMN.AC_NO,
                                                        P_ERROR_CODES,
                                                        P_ERROR_PARAMS) THEN
                  DBG('maint Resolution for acc gave error ' ||
                      P_ERROR_CODES || '~' || P_ERROR_PARAMS);
                  P_ERR_CODE := 'IC-MU0008';
                  DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                      SQLERRM);
                  RETURN FALSE;
                END IF;
              
                SAVEPOINT SAV_MAT1;
                IF NOT
                    STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                P_ICDREDMN.BRN_CODE) THEN
                  BEGIN
                    DELETE FROM ICTBS_INT_LIQ_DETAILS
                     WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
                       AND ACCOUNT_NUMBER = P_ICDREDMN.AC_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('FAiled in Deleting ');
                  END;
                END IF;
              
                DBG('pkg_rate_chart--->' || PKG_RATE_CHART);
                IF J = 1 THEN
                  STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT      := L_REDEM_AMOUNT;
                  STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := L_REDEM_AMOUNT;
                  PKG_PENALTY_APPLY                        := 1;
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 2;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
                    IF NOT
                        ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                           P_MODULE,
                                                           P_ACTION_CODE,
                                                           P_MULTI_TRIP_ID,
                                                           P_ICDREDMN,
                                                           P_TY_PAYOUTDETS,
                                                           P_BCPAYOUTDETS_REC,
                                                           P_PCPAYOUTDETS_REC,
                                                           P_TY_STDCUSAC,
                                                           P_TBL_NODE,
                                                           P_TBL_CHGDETS,
                                                           P_UPL_MIS_DET,
                                                           P_UPL_UDF_DET,
                                                           P_OVERRIDE_FLAG,
                                                           P_ERR_TBL,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA) THEN
                      DBG('Failed in call 2 to icpks_fcj_icdredmn_cluster.fn_main');
                    ELSE
                      IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
                        PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
                      END IF;
                    END IF;
                  END IF;
                
                  IF PKG_RATE_CHART = 'Y' THEN
                    DBG('Inside J=1 and pkg_rate_chart=Y');
                  
                    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                       NVL(L_LIQ_DAYS, 0) = 0 THEN
                      IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
                        L_LAST_DT := G_CALC_FROM;
                      ELSE
                        L_LAST_DT := G_CALC_TO;
                      END IF;
                    ELSE
                    
                      L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                              12 * L_LIQ_YEARS +
                                              L_LIQ_MONTHS) + L_LIQ_DAYS - 1;
                    
                      SELECT LEAST(NVL(MIN(ENT_DT), L_LAST_DT), L_LAST_DT)
                        INTO L_LAST_DT
                        FROM ICTBS_ENTRIES_HISTORY A
                      
                       WHERE A.ACC = P_ICDREDMN.AC_NO
                         AND A.BRN = P_ICDREDMN.BRN_CODE
                            
                         AND A.LIQN = 'Y'
                         AND A.PROD = L_PRODUCT_CODE
                         AND A.ENT_DT >= L_AC_OPEN_DATE
                         AND A.ENTRY_PASSED = 'Y';
                    
                      IF L_LAST_DT > G_CALC_TO THEN
                        L_LAST_DT := G_CALC_TO;
                        DBG('l_last_dt in if' || L_LAST_DT);
                      END IF;
                    
                    END IF;
                    DBG('g_calc_from111--->' || G_CALC_FROM);
                    DBG('g_calc_to000--->' || G_CALC_TO);
                    DBG('l_last_dt--->' || L_LAST_DT);
                    IF L_LAST_DT <= G_CALC_TO THEN
                      WHILE L_LAST_DT <= G_CALC_TO LOOP
                      
                        IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                  P_ICDREDMN.AC_NO,
                                                  G_CALC_FROM,
                                                  L_LAST_DT,
                                                  L_RULE,
                                                  L_PRODUCT_CODE,
                                                  P_ERROR_CODES,
                                                  P_ERROR_PARAMS) THEN
                          DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                          P_ERR_CODE := 'IC-MU0008';
                          DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                              SQLERRM);
                          RETURN FALSE;
                        END IF;
                        SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                          INTO L_ADJ_AMOUNT
                          FROM ICTW_MEMO_BOOKING
                         WHERE BRN = P_ICDREDMN.BRN_CODE
                           AND ACC = P_ICDREDMN.AC_NO
                           AND PROD = L_PRODUCT_CODE;
                      
                        DBG('l_adj_amount999----->' || L_ADJ_AMOUNT);
                      
                        L_ADJ_AMOUNT1 := L_ADJ_AMOUNT1 + L_ADJ_AMOUNT;
                        DBG('l_adj_amount1----->' || L_ADJ_AMOUNT1);
                        L_RED_BAL := L_RED_BAL + L_ADJ_AMOUNT;
                        DBG('l_red_bal----->' || L_RED_BAL);
                        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_RED_BAL;
                        IF NOT
                            STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                        P_ICDREDMN.BRN_CODE) THEN
                          BEGIN
                            INSERT INTO ICTBS_INT_LIQ_DETAILS
                              (ACCOUNT_NUMBER,
                               BRANCH_CODE,
                               FROM_DATE,
                               TO_DATE,
                               LIQ_AMT)
                            VALUES
                              (P_ICDREDMN.AC_NO,
                               P_ICDREDMN.BRN_CODE,
                               G_CALC_FROM,
                               L_LAST_DT,
                               L_RED_BAL);
                          EXCEPTION
                            WHEN OTHERS THEN
                              DBG('Failed ---->' || SQLERRM);
                          END;
                        END IF;
                        G_CALC_FROM := L_LAST_DT + 1;
                        L_LAST_DT1  := L_LAST_DT;
                        L_LAST_DT   := ADD_MONTHS(L_LAST_DT,
                                                  12 * L_LIQ_YEARS +
                                                  L_LIQ_MONTHS) +
                                       L_LIQ_DAYS;
                        DBG('l_last_dt1111----->' || L_LAST_DT);
                        DBG('Deleting ictw_memo_booking');
                        DELETE FROM ICTW_MEMO_BOOKING A
                         WHERE A.BRN = P_ICDREDMN.BRN_CODE
                           AND A.ACC = P_ICDREDMN.AC_NO
                           AND A.PROD = L_PRODUCT_CODE;
                      
                        IF NVL(L_LIQ_YEARS, 0) = 0 AND
                           NVL(L_LIQ_MONTHS, 0) = 0 AND
                           NVL(L_LIQ_DAYS, 0) = 0 THEN
                          EXIT;
                        END IF;
                      
                      END LOOP;
                    ELSE
                    
                      DBG('Inside Else');
                      DBG('g_calc_from In Else--->' || G_CALC_FROM);
                      DBG('g_calc_to in Else--->' || G_CALC_TO);
                      DBG('global.application_date--->' ||
                          GLOBAL.APPLICATION_DATE);
                    
                      IF (G_CALC_TO >= G_CALC_FROM AND
                         G_CALC_TO =
                         NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                              GLOBAL.APPLICATION_DATE) - 1) THEN
                        DBG('Inside Liq and redem same date');
                        IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                  P_ICDREDMN.AC_NO,
                                                  G_CALC_FROM,
                                                  
                                                  NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                                      GLOBAL.APPLICATION_DATE) - 1,
                                                  L_RULE,
                                                  L_PRODUCT_CODE,
                                                  P_ERROR_CODES,
                                                  P_ERROR_PARAMS) THEN
                          DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                          P_ERR_CODE := 'IC-MU0008';
                          DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                              SQLERRM);
                          RETURN FALSE;
                        END IF;
                        SELECT SUM(-AMT)
                          INTO L_ADJ_AMOUNT
                          FROM ICTW_MEMO_BOOKING
                         WHERE BRN = P_ICDREDMN.BRN_CODE
                           AND ACC = P_ICDREDMN.AC_NO
                           AND PROD = L_PRODUCT_CODE
                           AND IS_TAX = 'N'
                           AND DRCR_IND = 'D';
                      
                      ELSE
                        DBG('After Liq Some Accrual');
                        L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                                12 * L_LIQ_YEARS +
                                                L_LIQ_MONTHS) + L_LIQ_DAYS - 1;
                        WHILE L_LAST_DT <= G_CALC_TO LOOP
                          IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                    P_ICDREDMN.AC_NO,
                                                    G_CALC_FROM,
                                                    L_LAST_DT,
                                                    L_RULE,
                                                    L_PRODUCT_CODE,
                                                    P_ERROR_CODES,
                                                    P_ERROR_PARAMS) THEN
                            DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                            P_ERR_CODE := 'IC-MU0008';
                            DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                                SQLERRM);
                            RETURN FALSE;
                          END IF;
                          SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)),
                                     0)
                            INTO L_ADJ_AMOUNT
                            FROM ICTW_MEMO_BOOKING
                           WHERE BRN = P_ICDREDMN.BRN_CODE
                             AND ACC = P_ICDREDMN.AC_NO
                             AND PROD = L_PRODUCT_CODE;
                          L_RED_BAL := L_RED_BAL + L_ADJ_AMOUNT;
                          IF NOT
                              STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                          P_ICDREDMN.BRN_CODE) THEN
                            BEGIN
                              INSERT INTO ICTBS_INT_LIQ_DETAILS
                                (ACCOUNT_NUMBER,
                                 BRANCH_CODE,
                                 FROM_DATE,
                                 TO_DATE,
                                 LIQ_AMT)
                              VALUES
                                (P_ICDREDMN.AC_NO,
                                 P_ICDREDMN.BRN_CODE,
                                 G_CALC_FROM,
                                 L_LAST_DT,
                                 L_RED_BAL);
                            EXCEPTION
                              WHEN OTHERS THEN
                                DBG('Failed ---->' || SQLERRM);
                            END;
                          END IF;
                          G_CALC_FROM := L_LAST_DT + 1;
                          L_LAST_DT   := ADD_MONTHS(L_LAST_DT,
                                                    12 * L_LIQ_YEARS +
                                                    L_LIQ_MONTHS) +
                                         L_LIQ_DAYS;
                          DBG('l_last_dt1111----->' || L_LAST_DT);
                          DBG('Deleting ictw_memo_booking');
                          DELETE FROM ICTW_MEMO_BOOKING A
                           WHERE A.BRN = P_ICDREDMN.BRN_CODE
                             AND A.ACC = P_ICDREDMN.AC_NO
                             AND A.PROD = L_PRODUCT_CODE;
                          IF L_LAST_DT > G_CALC_TO THEN
                            IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                      P_ICDREDMN.AC_NO,
                                                      G_CALC_TO,
                                                      
                                                      NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                                          GLOBAL.APPLICATION_DATE) - 1,
                                                      L_RULE,
                                                      L_PRODUCT_CODE,
                                                      P_ERROR_CODES,
                                                      P_ERROR_PARAMS) THEN
                              DBG('failed in FN_DO_MEMO_ACCRUAL ' ||
                                  SQLERRM);
                              P_ERR_CODE := 'IC-MU0008';
                              DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                                  SQLERRM);
                              RETURN FALSE;
                            END IF;
                            SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)),
                                       0)
                              INTO L_ADJ_AMOUNT
                              FROM ICTW_MEMO_BOOKING
                             WHERE BRN = P_ICDREDMN.BRN_CODE
                               AND ACC = P_ICDREDMN.AC_NO
                               AND PROD = L_PRODUCT_CODE;
                          END IF;
                        
                          L_LAST_DT := NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                           GLOBAL.APPLICATION_DATE) - 1;
                          EXIT;
                        END LOOP;
                      
                      END IF;
                      DBG('l_adj_amount999----->' || L_ADJ_AMOUNT);
                      L_ADJ_AMOUNT2 := L_ADJ_AMOUNT2 + L_ADJ_AMOUNT;
                      IF NOT
                          STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                      P_ICDREDMN.BRN_CODE) THEN
                        BEGIN
                          INSERT INTO ICTBS_INT_LIQ_DETAILS
                            (ACCOUNT_NUMBER,
                             BRANCH_CODE,
                             FROM_DATE,
                             TO_DATE,
                             LIQ_AMT)
                          VALUES
                            (P_ICDREDMN.AC_NO,
                             P_ICDREDMN.BRN_CODE,
                             G_CALC_FROM,
                             L_LAST_DT,
                             L_REMAIN_TD_AMOUNT + L_ADJ_AMOUNT);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DBG('Failed ---->' || SQLERRM);
                        END;
                      END IF;
                    
                    END IF;
                  
                    BEGIN
                      SELECT NVL(SUM(DECODE(DRCR, 'C', AMT, -AMT)), 0)
                        INTO L_INT_AMT
                        FROM ICTB_ENTRIES_HISTORY
                       WHERE ACC = P_ICDREDMN.AC_NO
                         AND BRN = P_ICDREDMN.BRN_CODE
                         AND LIQN = 'Y';
                    EXCEPTION
                      WHEN OTHERS THEN
                        ICPKSS_UTIL.DBG('Error in Selection l_credit_amt from ICTB_ENTRIES_HISTORY');
                        L_INT_AMT := 0;
                    END;
                    ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD9 := L_REMAIN_TD_AMOUNT +
                                                                                     L_ADJ_AMOUNT;
                  
                  ELSE
                  
                    DBG('inside Else g_calc_to --->' || G_CALC_TO);
                    DBG('inside Else g_calc_from--->' || G_CALC_FROM);
                    DBG('inside Else global.application_date--->' ||
                        GLOBAL.APPLICATION_DATE);
                  
                    IF (G_CALC_TO >= G_CALC_FROM AND
                       G_CALC_TO <
                       NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                            GLOBAL.APPLICATION_DATE) - 1) THEN
                      DBG('Inside upto this no Liq');
                      IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                G_CALC_TO + 1,
                                                
                                                NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                                    GLOBAL.APPLICATION_DATE) - 1,
                                                L_RULE,
                                                L_PRODUCT_CODE,
                                                P_ERROR_CODES,
                                                P_ERROR_PARAMS) THEN
                        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                            SQLERRM);
                        RETURN FALSE;
                      END IF;
                      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                        INTO L_ADJ_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE;
                    ELSIF G_CALC_TO < G_CALC_FROM THEN
                      DBG('Some Liq');
                      IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                G_CALC_FROM,
                                                
                                                NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                                    GLOBAL.APPLICATION_DATE) - 1,
                                                L_RULE,
                                                L_PRODUCT_CODE,
                                                P_ERROR_CODES,
                                                P_ERROR_PARAMS) THEN
                        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                            SQLERRM);
                        RETURN FALSE;
                      END IF;
                      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                        INTO L_ADJ_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE;
                    
                      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                        INTO P_ICDREDMN.INTEREST_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE
                         AND IS_TAX = 'N';
                    
                      SELECT NVL(SUM(DECODE(IS_TAX,
                                            'Y',
                                            DECODE(DRCR_IND, 'D', AMT))),
                                 0)
                        INTO P_ICDREDMN.TAX_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE;
                      P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.REDEMPTION_AMT +
                                                  NVL(P_ICDREDMN.INTEREST_AMOUNT,
                                                      0) - NVL(P_ICDREDMN.TAX_AMOUNT,
                                                               0);
                      DBG('Tax Amount ' || P_ICDREDMN.TAX_AMOUNT);
                      DBG('Interest Amount ' || P_ICDREDMN.INTEREST_AMOUNT);
                      DBG('Payout Amount ' || P_ICDREDMN.PAYOUT_AMOUNT);
                    
                    ELSIF (G_CALC_TO >= G_CALC_FROM AND
                          G_CALC_TO =
                          NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                               GLOBAL.APPLICATION_DATE) - 1) THEN
                      DBG('Inside Liq and redem same date');
                      IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                G_CALC_FROM,
                                                
                                                NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                                                    GLOBAL.APPLICATION_DATE) - 1,
                                                L_RULE,
                                                L_PRODUCT_CODE,
                                                P_ERROR_CODES,
                                                P_ERROR_PARAMS) THEN
                        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                            SQLERRM);
                        RETURN FALSE;
                      END IF;
                      SELECT SUM(-AMT)
                        INTO L_ADJ_AMOUNT
                        FROM ICTW_MEMO_BOOKING
                       WHERE BRN = P_ICDREDMN.BRN_CODE
                         AND ACC = P_ICDREDMN.AC_NO
                         AND PROD = L_PRODUCT_CODE
                         AND IS_TAX = 'N'
                         AND DRCR_IND = 'D';
                    
                    END IF;
                  
                    DBG('calling fn_is_Redm_Int_payout' || G_CALC_TO);
                    IF NOT FN_IS_REDM_INT_PAYOUT(P_ICDREDMN.BRN_CODE,
                                                 P_ICDREDMN.AC_NO,
                                                 L_OFFSET_ACC) THEN
                      L_ADJ_AMOUNT1 := L_REMAIN_TD_AMOUNT + L_ADJ_AMOUNT;
                    ELSE
                      L_ADJ_AMOUNT1 := L_REMAIN_TD_AMOUNT;
                    END IF;
                  
                    IF NOT
                        STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                    P_ICDREDMN.BRN_CODE) THEN
                      BEGIN
                        DBG('Amount fianlly in J=1-->' || L_ADJ_AMOUNT1);
                        ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD9 := L_ADJ_AMOUNT1;
                        INSERT INTO ICTBS_INT_LIQ_DETAILS
                          (ACCOUNT_NUMBER,
                           BRANCH_CODE,
                           FROM_DATE,
                           TO_DATE,
                           LIQ_AMT)
                        VALUES
                          (P_ICDREDMN.AC_NO,
                           P_ICDREDMN.BRN_CODE,
                           G_CALC_FROM,
                           GLOBAL.APPLICATION_DATE - 1,
                           L_ADJ_AMOUNT1);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('Failed ---->' || SQLERRM);
                      END;
                    END IF;
                  
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CUSTOM,
                        CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                      L_FN_CALL_ID := 6;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('l_adj_amount1') := L_ADJ_AMOUNT1;
                      L_TB_CLUSTER_DATA('l_remain_td_amount') := L_REMAIN_TD_AMOUNT;
                      IF NOT
                          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                             P_MODULE,
                                                                             P_ACTION_CODE,
                                                                             P_MULTI_TRIP_ID,
                                                                             P_ICDREDMN,
                                                                             P_TY_PAYOUTDETS,
                                                                             P_BCPAYOUTDETS_REC,
                                                                             P_PCPAYOUTDETS_REC,
                                                                             P_TY_STDCUSAC,
                                                                             P_TBL_NODE,
                                                                             P_TBL_CHGDETS,
                                                                             P_UPL_MIS_DET,
                                                                             P_UPL_UDF_DET,
                                                                             P_OVERRIDE_FLAG,
                                                                             P_ERR_TBL,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                        DBG('Failed in call 6 to icpks_fcj_icdredmn_cluster.fn_maturity_amount_calc');
                        RETURN FALSE;
                      END IF;
                      IF L_TB_CLUSTER_DATA.EXISTS('l_adj_amount1') THEN
                        L_ADJ_AMOUNT1 := L_TB_CLUSTER_DATA('l_adj_amount1');
                      END IF;
                      IF L_TB_CLUSTER_DATA.EXISTS('l_remain_td_amount') THEN
                        L_REMAIN_TD_AMOUNT := L_TB_CLUSTER_DATA('l_remain_td_amount');
                      END IF;
                    END IF;
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  
                  END IF;
                
                END IF;
              
                IF J IN (2) AND L_PAYOUT_COUNT = 0 THEN
                
                  G_CALC_FROM := G_CALC_TO + 1;
                
                  DBG('g_calc_from in J=2' || G_CALC_FROM);
                  DBG('Acc and Bran' || P_ICDREDMN.AC_NO || '~' ||
                      P_ICDREDMN.BRN_CODE);
                  SELECT MATURITY_DATE
                    INTO L_MATURITY_DATE
                    FROM ICTMS_ACC
                   WHERE ACC = P_ICDREDMN.AC_NO
                     AND BRN = P_ICDREDMN.BRN_CODE;
                  G_CALC_TO := L_MATURITY_DATE;
                  DBG('g_calc_to in J=2' || G_CALC_TO);
                
                  DBG('calling fn_is_Redm_Int_payout' || G_CALC_TO);
                  IF FN_IS_REDM_INT_PAYOUT(P_ICDREDMN.BRN_CODE,
                                           P_ICDREDMN.AC_NO,
                                           L_OFFSET_ACC) THEN
                    DBG('REDEM INT PAYOUT OPTED.INTEREST CALCULATED FOR REDEMPTION AMOUNT SHOULD NOT BE CONSIDERED');
                    L_ADJ_AMOUNT := 0;
                  END IF;
                
                  STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_REMAIN_TD_AMOUNT +
                                                         NVL(L_ADJ_AMOUNT,
                                                             0);
                
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 7;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('l_remain_td_amount') := L_REMAIN_TD_AMOUNT;
                    L_TB_CLUSTER_DATA('L_INT_AMT') := L_INT_AMT;
                    IF NOT
                        ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                           P_MODULE,
                                                                           P_ACTION_CODE,
                                                                           P_MULTI_TRIP_ID,
                                                                           P_ICDREDMN,
                                                                           P_TY_PAYOUTDETS,
                                                                           P_BCPAYOUTDETS_REC,
                                                                           P_PCPAYOUTDETS_REC,
                                                                           P_TY_STDCUSAC,
                                                                           P_TBL_NODE,
                                                                           P_TBL_CHGDETS,
                                                                           P_UPL_MIS_DET,
                                                                           P_UPL_UDF_DET,
                                                                           P_OVERRIDE_FLAG,
                                                                           P_ERR_TBL,
                                                                           L_FN_CALL_ID,
                                                                           L_TB_CLUSTER_DATA) THEN
                      DBG('Failed in call 7 to icpks_fcj_icdredmn_cluster.fn_maturity_amount_calc');
                      RETURN FALSE;
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_remain_td_amount') THEN
                      L_REMAIN_TD_AMOUNT := L_TB_CLUSTER_DATA('l_remain_td_amount');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('L_INT_AMT') THEN
                      L_INT_AMT := L_TB_CLUSTER_DATA('L_INT_AMT');
                    END IF;
                  END IF;
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                
                  STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := L_REMAIN_TD_AMOUNT;
                  L_RED_BAL1                               := L_REMAIN_TD_AMOUNT +
                                                              NVL(L_ADJ_AMOUNT,
                                                                  0);
                
                  IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                     NVL(L_LIQ_DAYS, 0) = 0 THEN
                    IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
                      L_LAST_DT := G_CALC_FROM;
                    ELSE
                      L_LAST_DT := G_CALC_TO;
                    END IF;
                  ELSE
                  
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CUSTOM,
                        CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                      L_FN_CALL_ID := 11;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('l_next_liq_dt') := L_NEXT_LIQ_DT;
                      IF NOT
                          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                                                             P_MODULE,
                                                                             P_ACTION_CODE,
                                                                             P_MULTI_TRIP_ID,
                                                                             P_ICDREDMN,
                                                                             P_TY_PAYOUTDETS,
                                                                             P_BCPAYOUTDETS_REC,
                                                                             P_PCPAYOUTDETS_REC,
                                                                             P_TY_STDCUSAC,
                                                                             P_TBL_NODE,
                                                                             P_TBL_CHGDETS,
                                                                             P_UPL_MIS_DET,
                                                                             P_UPL_UDF_DET,
                                                                             P_OVERRIDE_FLAG,
                                                                             P_ERR_TBL,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                        DBG('Failed in call 11 to icpks_fcj_icdredmn_cluster.fn_maturity_amount_calc');
                        RETURN FALSE;
                      END IF;
                      IF L_TB_CLUSTER_DATA.EXISTS('l_next_liq_dt') THEN
                        L_NEXT_LIQ_DT := L_TB_CLUSTER_DATA('l_next_liq_dt');
                      END IF;
                    END IF;
                    IF NOT GLOBAL.G_SKIP_KERNEL THEN
                    
                      BEGIN
                        SELECT NEXT_LIQ_DT
                          INTO L_NEXT_LIQ_DT
                          FROM ICTBS_ACC_PR
                         WHERE BRN = P_ICDREDMN.BRN_CODE
                           AND ACC = P_ICDREDMN.AC_NO;
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                          DBG('Failed in selecting Product Code from ictb_redem_acc_pr.................');
                      END;
                    
                    ELSE
                      GLOBAL.PR_RESET_SKIP_KERNEL;
                    END IF;
                  
                    L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                            12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                                 L_LIQ_DAYS - 1;
                  END IF;
                  DBG('l_last_dt' || L_LAST_DT);
                  DBG('g_calc_to' || G_CALC_TO);
                  DBG('l_flag-->' || L_FLAG);
                  IF L_LAST_DT >= G_CALC_TO THEN
                    L_LAST_DT := G_CALC_TO - 1;
                    DBG('l_last_dt in if' || L_LAST_DT);
                    L_FLAG := L_FLAG + 1;
                  END IF;
                
                  WHILE L_LAST_DT <= G_CALC_TO AND L_FLAG != 2 LOOP
                    DBG('Inside While');
                  
                    IF NOT FN_DO_MEMO_ACCRUAL(P_ICDREDMN.BRN_CODE,
                                              P_ICDREDMN.AC_NO,
                                              G_CALC_FROM,
                                              L_LAST_DT,
                                              L_RULE,
                                              L_PRODUCT_CODE,
                                              P_ERROR_CODES,
                                              P_ERROR_PARAMS) THEN
                      DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                          SQLERRM);
                      RETURN FALSE;
                    END IF;
                    SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                      INTO L_ADJ_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE;
                  
                    SELECT SUM(AMT)
                      INTO L_INV_INT_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE
                       AND DRCR_IND = 'C';
                  
                    DBG('l_inv_int_amount  ' || L_INV_INT_AMOUNT);
                    L_TOT_INT_AMOUNT := L_TOT_INT_AMOUNT + L_INV_INT_AMOUNT;
                  
                    SELECT SUM(AMT)
                      INTO L_INV_TAX_AMOUNT
                      FROM ICTW_MEMO_BOOKING
                     WHERE BRN = P_ICDREDMN.BRN_CODE
                       AND ACC = P_ICDREDMN.AC_NO
                       AND PROD = L_PRODUCT_CODE
                       AND IS_TAX = 'Y'
                       AND DRCR_IND = 'D';
                    DBG('l_inv_tax_amount  ' || L_INV_TAX_AMOUNT);
                    L_TOT_TAX_AMOUNT := L_TOT_TAX_AMOUNT + L_INV_TAX_AMOUNT;
                  
                    DBG('l_adj_amount999----->' || L_ADJ_AMOUNT);
                    L_ADJ_AMOUNT2 := L_ADJ_AMOUNT2 + L_ADJ_AMOUNT;
                    DBG('l_adj_amount2----->' || L_ADJ_AMOUNT2);
                    L_RED_BAL1 := L_RED_BAL1 + L_ADJ_AMOUNT;
                    DBG('l_red_bal1----->' || L_RED_BAL1);
                    STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_RED_BAL1;
                    IF NOT
                        STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                                    P_ICDREDMN.BRN_CODE) THEN
                      BEGIN
                        INSERT INTO ICTBS_INT_LIQ_DETAILS
                          (ACCOUNT_NUMBER,
                           BRANCH_CODE,
                           FROM_DATE,
                           TO_DATE,
                           LIQ_AMT)
                        VALUES
                          (P_ICDREDMN.AC_NO,
                           P_ICDREDMN.BRN_CODE,
                           G_CALC_FROM,
                           L_LAST_DT,
                           L_RED_BAL1);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('Failed ---->' || SQLERRM);
                      END;
                    END IF;
                    EXIT WHEN L_LAST_DT >= G_CALC_TO;
                    G_CALC_FROM := L_LAST_DT + 1;
                    L_LAST_DT1  := L_LAST_DT;
                    L_LAST_DT   := ADD_MONTHS(L_LAST_DT,
                                              12 * L_LIQ_YEARS +
                                              L_LIQ_MONTHS) + L_LIQ_DAYS;
                    DBG('l_last_dt1111----->' || L_LAST_DT);
                  
                    IF L_LAST_DT >= G_CALC_TO THEN
                      L_LAST_DT := G_CALC_TO - 1;
                      DBG('l_last_dt in if' || L_LAST_DT);
                      L_FLAG := L_FLAG + 1;
                    END IF;
                  
                    DBG('Deleting ictw_memo_booking');
                    DELETE FROM ICTW_MEMO_BOOKING A
                     WHERE A.BRN = P_ICDREDMN.BRN_CODE
                       AND A.ACC = P_ICDREDMN.AC_NO
                       AND A.PROD = L_PRODUCT_CODE;
                  
                    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                       NVL(L_LIQ_DAYS, 0) = 0 THEN
                      EXIT;
                    END IF;
                  END LOOP;
                END IF;
                ROLLBACK TO SAV_MAT1;
              
              END LOOP;
            
              DBG('l_tot_int_amount  ' || L_TOT_INT_AMOUNT);
              DBG('l_tot_tax_amount  ' || L_TOT_TAX_AMOUNT);
              ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD13 := L_TOT_INT_AMOUNT;
              ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD14 := L_TOT_TAX_AMOUNT;
            
              DBG('L_INT_AMT(c)--->' || L_INT_AMT);
              DBG('l_adj_amount1(a)--->' || L_ADJ_AMOUNT1);
              DBG('l_adj_amount2(b)--->' || L_ADJ_AMOUNT2);
              DBG('l_remain_td_amount--->' || L_REMAIN_TD_AMOUNT);
            
              DBG('The interest amount before assignment in partial redemption is:' ||
                  P_ICDREDMN.INTEREST_AMOUNT);
              P_ICDREDMN.INTEREST_AMOUNT := L_TOT_INT_AMOUNT;
              DBG('The interest amount is:' || P_ICDREDMN.INTEREST_AMOUNT);
              STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST := P_ICDREDMN.INTEREST_AMOUNT;
              DBG('The tax amount before assignment in partial redemption is:' ||
                  P_ICDREDMN.TAX_AMOUNT);
              P_ICDREDMN.TAX_AMOUNT := L_TOT_TAX_AMOUNT;
              DBG('The tax amount is:' || P_ICDREDMN.TAX_AMOUNT);
            
              IF PKG_RATE_CHART = 'Y' THEN
                P_ICDREDMN.MATURITY_AMOUNT := L_RED_BAL1;
                DBG('P_ICDREDMN.MATURITY_AMOUNT PKG_RATE_CHART-Y' ||
                    P_ICDREDMN.MATURITY_AMOUNT);
              ELSE
                P_ICDREDMN.MATURITY_AMOUNT := L_ADJ_AMOUNT1 + L_ADJ_AMOUNT2;
                DBG('P_ICDREDMN.MATURITY_AMOUNT PKG_RATE_CHART-N' ||
                    P_ICDREDMN.MATURITY_AMOUNT);
              END IF;
            ELSE
              P_ICDREDMN.MATURITY_AMOUNT := L_REMAIN_AMT - L_INT_AMT;
              DBG('P_ICDREDMN.MATURITY_AMOUNT PAYOUT_COMP FOR I IS 0' ||
                  P_ICDREDMN.MATURITY_AMOUNT);
            END IF;
          END IF;
          DBG('P_ICDREDMN.MATURITY_AMOUNT-->' ||
              P_ICDREDMN.MATURITY_AMOUNT);
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' AND PKG_RATE_CHART = 'Y' THEN
            P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.MATURITY_AMOUNT;
          END IF;
        
          IF P_SOURCE = 'FLEXBRANCH' AND P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.REDEMPTION_AMT +
                                        NVL(P_ICDREDMN.INTEREST_AMOUNT, 0) -
                                        NVL(P_ICDREDMN.TAX_AMOUNT, 0);
            DBG('Redemption amount is:' || P_ICDREDMN.REDEMPTION_AMT);
            DBG('Tax Amount ' || P_ICDREDMN.TAX_AMOUNT);
            DBG('Interest Amount ' || P_ICDREDMN.INTEREST_AMOUNT);
            DBG('Payout Amount ' || P_ICDREDMN.PAYOUT_AMOUNT);
          END IF;
        
          ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD11 := P_ICDREDMN.MATURITY_AMOUNT;
          IF L_ICTM_ACC.MATURITY_DATE > GLOBAL.APPLICATION_DATE THEN
            P_ICDREDMN.INTEREST_RATE := STPKS_STDCUSAC_UTILS_1.FN_PROJ_INTRATE('ICDREDMN',
                                                                               P_ICDREDMN.BRN_CODE,
                                                                               P_ICDREDMN.AC_NO,
                                                                               L_PROD);
            DBG('Interest Rate-->' || P_ICDREDMN.INTEREST_RATE);
          
            ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD10 := P_ICDREDMN.INTEREST_RATE;
            DBG('icpks_icdrdsim_kernel.g_icdrdsim.v_cstb_ui_columns.num_field10' ||
                ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD10);
          
          END IF;
        
          SELECT NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0)
            INTO P_ICDREDMN.PRINCIPAL_AMOUNT
            FROM ICTM_TD_DETAILS
           WHERE BRN = P_ICDREDMN.BRN_CODE
             AND ACC = P_ICDREDMN.AC_NO;
        
          ROLLBACK TO PR_CALC;
        
        ELSIF L_PR_INT.PAYMENT_METHOD = 'D' THEN
        
          DBG('IN DISCOUNTED');
          BEGIN
            SELECT *
              INTO L_TD_DETAILS
              FROM ICTM_TD_DETAILS
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED IN FETCHING THE TD DETAILS');
          END;
        
          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            P_ICDREDMN.MATURITY_AMOUNT := (NVL(L_TD_DETAILS.TD_AMOUNT, 0) -
                                          NVL(L_TD_DETAILS.REDEM_AMT, 0));
          ELSE
            P_ICDREDMN.MATURITY_AMOUNT := NVL(L_TD_DETAILS.TD_AMOUNT, 0) -
                                          NVL(L_TD_DETAILS.REDEM_AMT, 0) -
                                          NVL(P_ICDREDMN.REDEMPTION_AMT, 0);
          END IF;
        
          P_ICDREDMN.INTEREST_RATE := STPKS_STDCUSAC_UTILS_1.FN_PROJ_INTRATE('ICDREDMN',
                                                                             P_ICDREDMN.BRN_CODE,
                                                                             P_ICDREDMN.AC_NO,
                                                                             L_PROD);
          DBG('Interest Rate-->' || P_ICDREDMN.INTEREST_RATE);
        
          ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD10 := P_ICDREDMN.INTEREST_RATE;
          DBG('icpks_icdrdsim_kernel.g_icdrdsim.v_cstb_ui_columns.num_field10' ||
              ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD10);
        
          P_ICDREDMN.PRINCIPAL_AMOUNT := NVL(L_TD_DETAILS.TD_AMOUNT, 0);
        
          IF CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDRDSIM' AND
             P_ACTION_CODE = 'TDRedemCompute' THEN
            ICPKS_MAINT.G_REDEM_AMT := P_ICDREDMN.REDEMPTION_AMT;
            IF NOT STPKS_TD_REDEMPTION.FN_BROKEN_PARTIAL_TD(P_ICDREDMN.BRN_CODE,
                                                            P_ICDREDMN.AC_NO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
              DBG('Failed in the compute of discounted deposit');
            END IF;
            DBG('Calling fn_int_adj');
            DBG('l_product_code ' || L_PRODUCT_CODE);
            IF NOT FN_INT_ADJ(P_ICDREDMN.AC_NO,
                              P_ICDREDMN.BRN_CODE,
                              P_ICDREDMN.CCY,
                              P_ICDREDMN.REDEMPTION_AMT,
                              L_PRODUCT_CODE,
                              GLOBAL.APPLICATION_DATE,
                              P_ICDREDMN.REDEMPTION_MODE,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
              ICPKSS_UTIL.DBG('Failed in fn_int_adj for discounted deposit..............');
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            ELSE
              ICPKSS_UTIL.DBG('Returning Successfully from fn_int_adj..............');
            END IF;
          END IF;
        
        END IF;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of icpks_fcj_icdredmn.fn_maturity_amount_calc ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MATURITY_AMOUNT_CALC;

  FUNCTION FN_INSERT_DATA(P_SOURCE           IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_AUTH_STATUS      IN VARCHAR2,
                          P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                          P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                          P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                          P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                          P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                          P_TY_ICDREDMN      IN OUT ICPKS_ICDREDMN_MAIN.TY_ICDREDMN,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_SERIAL_NO VARCHAR2(20);
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Start if Fn_Insert_Data');
  
    IF (NVL(P_ACTION_CODE, '#') IN ('TDRedemption', 'EnrichTDRedemption') AND
       P_SOURCE IN ('FLEXBRANCH')) THEN
    
      DBG('Success case: p_icdredmn.redem_ref_no : ' ||
          P_ICDREDMN.REDEM_REF_NO);
      IF P_ICDREDMN.REDEM_REF_NO IS NULL THEN
      
        IF NOT TRPKSS.FN_GET_PROCESS_REFNO(NVL(GWPKS_TDREDEMPTION.G_BRNCODE,
                                               GLOBAL.CURRENT_BRANCH),
                                           'ICRD',
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           P_ICDREDMN.REDEM_REF_NO,
                                           P_ERR_CODE) THEN
          IF P_ERR_CODE IS NULL THEN
            P_ERR_CODE   := 'TD-RED-16';
            P_ERR_PARAMS := 'Failed to generate TD Reference Number.';
          END IF;
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        DBG('p_icdredmn.redem_ref_no : ' || P_ICDREDMN.REDEM_REF_NO);
      END IF;
      IF NOT FN_INSERT_REDEMPTION_TBLS(P_SOURCE,
                                       P_ICDREDMN,
                                       P_TY_PAYOUTDETS,
                                       P_BCPAYOUTDETS_REC,
                                       P_PCPAYOUTDETS_REC,
                                       P_TY_STDCUSAC,
                                       P_TY_ICDREDMN,
                                       P_AUTH_STATUS,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
        DBG('Failed in fn_insert_redemption_tbls...' || SQLCODE || SQLERRM);
        RETURN FALSE;
      ELSE
        DBG('Term Deposits Redemption/Renewal saved successfully. Returning TRUE');
      END IF;
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_INSERT_DATA(P_SOURCE,
                                                      P_ACTION_CODE,
                                                      P_AUTH_STATUS,
                                                      P_ICDREDMN,
                                                      P_TY_PAYOUTDETS,
                                                      P_BCPAYOUTDETS_REC,
                                                      P_PCPAYOUTDETS_REC,
                                                      P_TY_STDCUSAC,
                                                      P_TY_ICDREDMN,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('Failed in icpks_fcj_icdredmn_cluster.FN_INSERT_DATA...' ||
              SQLCODE || SQLERRM);
        END IF;
      END IF;
    
    END IF;
    DBG('End of Fn_Insert_Data');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Faile in Fn_Inert_Data');
      DBG('Line No = ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_INSERT_DATA;

  FUNCTION FN_TENORCHANGE(P_ICDREDMN    IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                          P_ACTION_CODE IN VARCHAR2)
  
   RETURN BOOLEAN IS
    L_ICTM_ACC_REC       ICTMS_ACC%ROWTYPE;
    L_ACCOUNT_CLASS      STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_PRODUCT            ICTMS_PR_INT.PRODUCT_CODE%TYPE;
    P_ERR_CODE           VARCHAR2(1000);
    P_ERR_PARAMS         VARCHAR2(1000);
    L_NEXT_MATURITY_DATE ICTM_ACC.NEXT_MATURITY_DATE%TYPE;
  
    L_NEXT_LIQ_DATE  DATE;
    L_NEXT_SCHD_DATE DATE;
    L_REDEM_STATUS   NUMBER;
    L_NXT_LIQ_DATE   DATE;
    L_NXT_SCHD_DATE  DATE;
    L_NEXT_MAT_DT_BK DATE;
    L_CASCADE_MONTH  ICTM_ACC.CASCADE_MONTH%TYPE;
  
    L_LIQ_COUNT NUMBER := 0;
  
    L_STDCUSTD      STPKS_STDCUSTD_MAIN.TY_STDCUSTD;
    L_ACC_REC       STTM_CUST_ACCOUNT%ROWTYPE;
    L_RECORD_MASTER STTBS_RECORD_MASTER%ROWTYPE;
    L_SOURCE        COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_ERR_PARAMS    VARCHAR2(256);
  
  BEGIN
  
    DBG('Inside Fn_Tenorchange');
  
    IF P_ACTION_CODE IN ('TDRedemSave') THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_REDEM_STATUS
          FROM ICTB_TDREDEMPTION_MASTER
         WHERE ACC_NO = P_ICDREDMN.AC_NO
           AND BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND NVL(AUTH_STATUS, 'U') = 'U'
           AND NVL(CONTRACT_STATUS, 'A') = 'A';
      EXCEPTION
        WHEN OTHERS THEN
          L_REDEM_STATUS := 0;
          DBG('Redem status is null' || SQLERRM);
      END;
      DBG('l_redem_status' || L_REDEM_STATUS);
      IF (L_REDEM_STATUS > 0) THEN
        DBG('Cannot Proceed');
        OVPKSS.PR_APPENDTBL('IC-REDMN-14', '');
      END IF;
    END IF;
  
    IF P_ACTION_CODE IN ('TDRedemAuth') THEN
      BEGIN
        SELECT *
          INTO L_ICTM_ACC_REC
          FROM ICTM_ACC
         WHERE ACC = P_ICDREDMN.AC_NO
           AND BRN = P_ICDREDMN.BRN_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside of When others of ICTM_ACC' || SQLERRM);
      END;
      BEGIN
        SELECT ACCOUNT_CLASS
          INTO L_ACCOUNT_CLASS
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
           AND BRANCH_CODE = P_ICDREDMN.BRN_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Inside of When others of sttm_cust_account' || SQLERRM);
      END;
      BEGIN
        SELECT PROD
          INTO L_PRODUCT
          FROM ICTMS_ACC_PR
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of product select--> ' || SQLERRM);
          RETURN FALSE;
        
      END;
    
      DBG('Product is--> ' || L_PRODUCT);
      DELETE FROM ICTW_MEMO_BOOKING A
       WHERE A.BRN = P_ICDREDMN.BRN_CODE
         AND A.ACC = P_ICDREDMN.AC_NO
         AND A.PROD = L_PRODUCT;
    
      DBG('p_icdredmn.tenor_yy' || P_ICDREDMN.TENOR_YY);
      DBG('p_icdredmn.tenor_mm' || P_ICDREDMN.TENOR_MM);
      DBG('p_icdredmn.tenor_dd' || P_ICDREDMN.TENOR_DD);
      UPDATE ICTM_ACC
         SET ORIG_TENOR_YEARS  = P_ICDREDMN.TENOR_YY,
             ORIG_TENOR_MONTHS = P_ICDREDMN.TENOR_MM,
             ORIG_TENOR_DAYS   = P_ICDREDMN.TENOR_DD,
             MATURITY_DATE     = P_ICDREDMN.NEXT_MAT_DATE
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
      DBG('p_icdredmn.tenor_yy' || P_ICDREDMN.TENOR_YY);
      DBG('p_icdredmn.tenor_mm' || P_ICDREDMN.TENOR_MM);
      DBG('p_icdredmn.tenor_dd' || P_ICDREDMN.TENOR_DD);
    
      BEGIN
        SELECT *
          INTO L_ACC_REC
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
           AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No records fetched');
          DBG('Trace :' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;
    
      L_STDCUSTD.V_STTMS_CUST_ACCOUNT := L_ACC_REC;
      DBG('ccount number is ' ||
          L_STDCUSTD.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      IF NOT STPKS_STDCUSTD_MAIN.FN_GET_KEY_INFORMATION(L_SOURCE,
                                                        NULL,
                                                        'STDCUSTD',
                                                        'MODIFY',
                                                        L_STDCUSTD,
                                                        P_ERR_CODE,
                                                        L_ERR_PARAMS) THEN
        DBG('Failed in  stpks_stdcustd_main.Fn_Get_Key_Information with ' ||
            SQLERRM);
        DBG('Trace ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END IF;
      DBG('Going to call stpks_stdcustd_main.Fn_Populate_Record_Master');
      IF NOT STPKS_STDCUSTD_MAIN.FN_POPULATE_RECORD_MASTER(L_SOURCE,
                                                           NULL,
                                                           'STDCUSTD',
                                                           'MODIFY',
                                                           L_STDCUSTD,
                                                           L_RECORD_MASTER,
                                                           P_ERR_CODE,
                                                           L_ERR_PARAMS) THEN
      
        DBG('Failed in  stpks_stdcustd_main.Fn_Populate_Record_Master..');
        DBG('Trace ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END IF;
      DBG('Now updating the record master');
      DBG('Key Id is ' || L_RECORD_MASTER.KEY_ID);
      DBG('l_Record_Master.Char_Fld_10 ' || L_RECORD_MASTER.CHAR_FLD_10);
      BEGIN
        UPDATE STTBS_RECORD_MASTER
           SET CHAR_FLD_1  = L_RECORD_MASTER.CHAR_FLD_1,
               CHAR_FLD_2  = L_RECORD_MASTER.CHAR_FLD_2,
               CHAR_FLD_3  = L_RECORD_MASTER.CHAR_FLD_3,
               CHAR_FLD_4  = L_RECORD_MASTER.CHAR_FLD_4,
               CHAR_FLD_5  = L_RECORD_MASTER.CHAR_FLD_5,
               CHAR_FLD_6  = L_RECORD_MASTER.CHAR_FLD_6,
               CHAR_FLD_7  = L_RECORD_MASTER.CHAR_FLD_7,
               CHAR_FLD_8  = L_RECORD_MASTER.CHAR_FLD_8,
               CHAR_FLD_9  = L_RECORD_MASTER.CHAR_FLD_9,
               CHAR_FLD_10 = L_RECORD_MASTER.CHAR_FLD_10,
               CHAR_FLD_11 = L_RECORD_MASTER.CHAR_FLD_11,
               CHAR_FLD_12 = L_RECORD_MASTER.CHAR_FLD_12,
               CHAR_FLD_13 = L_RECORD_MASTER.CHAR_FLD_13,
               CHAR_FLD_14 = L_RECORD_MASTER.CHAR_FLD_14,
               CHAR_FLD_15 = L_RECORD_MASTER.CHAR_FLD_15,
               CHAR_FLD_16 = L_RECORD_MASTER.CHAR_FLD_16,
               CHAR_FLD_17 = L_RECORD_MASTER.CHAR_FLD_17,
               CHAR_FLD_18 = L_RECORD_MASTER.CHAR_FLD_18,
               CHAR_FLD_19 = L_RECORD_MASTER.CHAR_FLD_19,
               CHAR_FLD_20 = L_RECORD_MASTER.CHAR_FLD_20,
               CHAR_FLD_21 = L_RECORD_MASTER.CHAR_FLD_21,
               CHAR_FLD_22 = L_RECORD_MASTER.CHAR_FLD_22,
               CHAR_FLD_23 = L_RECORD_MASTER.CHAR_FLD_23,
               CHAR_FLD_24 = L_RECORD_MASTER.CHAR_FLD_24,
               CHAR_FLD_25 = L_RECORD_MASTER.CHAR_FLD_25,
               NUM_FLD_1   = L_RECORD_MASTER.NUM_FLD_1,
               NUM_FLD_2   = L_RECORD_MASTER.NUM_FLD_2,
               NUM_FLD_3   = L_RECORD_MASTER.NUM_FLD_3,
               NUM_FLD_4   = L_RECORD_MASTER.NUM_FLD_4,
               NUM_FLD_5   = L_RECORD_MASTER.NUM_FLD_5,
               NUM_FLD_6   = L_RECORD_MASTER.NUM_FLD_6,
               NUM_FLD_7   = L_RECORD_MASTER.NUM_FLD_7,
               NUM_FLD_8   = L_RECORD_MASTER.NUM_FLD_8,
               NUM_FLD_9   = L_RECORD_MASTER.NUM_FLD_9,
               NUM_FLD_10  = L_RECORD_MASTER.NUM_FLD_10,
               DATE_FLD_1  = L_RECORD_MASTER.DATE_FLD_1,
               DATE_FLD_2  = L_RECORD_MASTER.DATE_FLD_2,
               DATE_FLD_3  = L_RECORD_MASTER.DATE_FLD_3,
               DATE_FLD_4  = L_RECORD_MASTER.DATE_FLD_4,
               DATE_FLD_5  = L_RECORD_MASTER.DATE_FLD_5,
               DATE_FLD_6  = L_RECORD_MASTER.DATE_FLD_6,
               DATE_FLD_7  = L_RECORD_MASTER.DATE_FLD_7,
               DATE_FLD_8  = L_RECORD_MASTER.DATE_FLD_8,
               DATE_FLD_9  = L_RECORD_MASTER.DATE_FLD_9,
               DATE_FLD_10 = L_RECORD_MASTER.DATE_FLD_10
         WHERE KEY_ID = L_RECORD_MASTER.KEY_ID;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Nothing to update');
      END;
    
      ICPKS_BOD.PR_POP_NEW_RATES_DURING_ROLL(P_ICDREDMN.AC_NO,
                                             P_ICDREDMN.BRN_CODE,
                                             P_ICDREDMN.CCY,
                                             L_ACCOUNT_CLASS,
                                             L_PRODUCT
                                             
                                            ,
                                             GLOBAL.APPLICATION_DATE,
                                             'T');
      DBG('l_ictm_acc_rec.maturity_date-->' ||
          L_ICTM_ACC_REC.MATURITY_DATE);
      DBG('p_icdredmn.next_mat_date-->' || P_ICDREDMN.NEXT_MAT_DATE);
      IF L_ICTM_ACC_REC.MATURITY_DATE > P_ICDREDMN.NEXT_MAT_DATE THEN
      
        DBG('This is Tenor Reduction  Case');
        ICPKSS_TEST.PR_ICALC(P_ICDREDMN.BRN_CODE,
                             P_ICDREDMN.AC_NO,
                             L_PRODUCT,
                             L_ICTM_ACC_REC.INT_START_DATE,
                             P_ICDREDMN.NEXT_MAT_DATE - 1);
        G_REDEMREFNO := P_ICDREDMN.REDEM_REF_NO;
      
        ICPKS_MAINT.G_FULL_REDEM := NULL;
      
        IF STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                       P_ICDREDMN.BRN_CODE) THEN
          BEGIN
            G_TENOR_CHANGE := 'Y';
            DBG('Top-up flow');
            SELECT A.TD_RATECHART_ALLOW
              INTO PKG_RATE_CHART
              FROM STTM_ACCOUNT_CLASS A, STTM_CUST_ACCOUNT B
             WHERE B.BRANCH_CODE = P_ICDREDMN.BRN_CODE
               AND B.CUST_AC_NO = P_ICDREDMN.AC_NO
               AND A.ACCOUNT_CLASS = B.ACCOUNT_CLASS;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              PKG_RATE_CHART := 'N';
          END;
          IF NVL(PKG_RATE_CHART, 'N') = 'Y' THEN
            DBG('Rate chart TD');
            SELECT COUNT(*)
              INTO L_LIQ_COUNT
              FROM ICTB_ENTRIES_HISTORY
             WHERE ACC = P_ICDREDMN.AC_NO
               AND BRN = P_ICDREDMN.BRN_CODE
               AND LIQN = 'Y'
               AND ENT_DT >= L_ICTM_ACC_REC.INT_START_DATE
               AND ENT_DT <= GLOBAL.APPLICATION_DATE;
            DBG('l_liq_count' || L_LIQ_COUNT);
            IF L_LIQ_COUNT > 0 THEN
              DBG('Liquidation adjustment need to post');
              ICPKSS_MAINT.PR_SET_FULL_REDEM('Y');
              ICPKS_BOD.G_WAVE_PENALTY := 'Y';
            
              IF NOT STPKS_STDTDTOP_UTILS.FN_TOPUP_SETTLED(P_ICDREDMN.BRN_CODE,
                                                           P_ICDREDMN.AC_NO,
                                                           P_ICDREDMN.CCY,
                                                           'TENOR_CHG1',
                                                           GLOBAL.APPLICATION_DATE,
                                                           0,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
              
                DBG('failed in icpks_td_topup.fn_topup_settled');
                RETURN FALSE;
              END IF;
            
              IF NOT STPKS_STDTDTOP_UTILS.FN_REDEM_TD(P_ICDREDMN.BRN_CODE,
                                                      P_ICDREDMN.AC_NO,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
                DBG('p_err_code  ' || P_ERR_CODE);
                OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
                RETURN FALSE;
              END IF;
            
              IF NOT STPKS_STDTDTOP_UTILS.FN_TOPUP_SETTLED(P_ICDREDMN.BRN_CODE,
                                                           P_ICDREDMN.AC_NO,
                                                           P_ICDREDMN.CCY,
                                                           'TENOR_CHG2',
                                                           GLOBAL.APPLICATION_DATE,
                                                           0,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
              
                DBG('failed in icpks_td_topup.fn_topup_settled');
                RETURN FALSE;
              END IF;
            
            END IF;
            ICPKSS_MAINT.PR_SET_FULL_REDEM('');
            ICPKS_BOD.G_WAVE_PENALTY := 'N';
          END IF;
          G_TENOR_CHANGE := 'N';
        ELSE
        
          STPKS_TD_REDEMPTION.PR_BROKEN_TD(P_ICDREDMN.BRN_CODE,
                                           P_ICDREDMN.AC_NO,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS);
        END IF;
      
        BEGIN
          SELECT NEXT_LIQ_DT, NEXT_SCHD_LIQ_DT
            INTO L_NEXT_LIQ_DATE, L_NEXT_SCHD_DATE
            FROM ICTB_ACC_PR
           WHERE BRN = P_ICDREDMN.BRN_CODE
             AND ACC = P_ICDREDMN.AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in Selecting Next Liq Date');
        END;
      
        L_NXT_LIQ_DATE  := L_NEXT_LIQ_DATE;
        L_NXT_SCHD_DATE := L_NEXT_SCHD_DATE;
      
        DBG('l_Nxt_Liq_Date-->' || L_NXT_LIQ_DATE);
        DBG('l_Nxt_Schd_Date-->' || L_NXT_SCHD_DATE);
      
        IF P_ICDREDMN.NEXT_MAT_DATE > L_NEXT_LIQ_DATE THEN
          L_NEXT_LIQ_DATE  := P_ICDREDMN.NEXT_MAT_DATE - 1;
          L_NEXT_SCHD_DATE := P_ICDREDMN.NEXT_MAT_DATE - 1;
        END IF;
      
        UPDATE ICTBS_ACC_PR P
           SET P.NEXT_LIQ_DT      = L_NEXT_LIQ_DATE,
               P.NEXT_SCHD_LIQ_DT = L_NEXT_SCHD_DATE
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO;
      
      ELSIF L_ICTM_ACC_REC.MATURITY_DATE < P_ICDREDMN.NEXT_MAT_DATE THEN
      
        DBG('This is Tenor Extension  Case');
        ICPKSS_TEST.PR_ICALC(P_ICDREDMN.BRN_CODE,
                             P_ICDREDMN.AC_NO,
                             L_PRODUCT,
                             GLOBAL.APPLICATION_DATE,
                             P_ICDREDMN.NEXT_MAT_DATE - 1);
      END IF;
    
      IF L_ICTM_ACC_REC.ROLL_TENOR_PREF = 'I' THEN
      
        L_NEXT_MATURITY_DATE := ADD_MONTHS(P_ICDREDMN.NEXT_MAT_DATE,
                                           L_ICTM_ACC_REC.ROLL_TENOR_MONTHS +
                                           (L_ICTM_ACC_REC.ROLL_TENOR_YEARS * 12)) +
                                L_ICTM_ACC_REC.ROLL_TENOR_DAYS;
      
        IF NVL(L_ICTM_ACC_REC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(L_ICTM_ACC_REC.ROLL_TENOR_DAYS, 0) = 0 THEN
          L_NEXT_MAT_DT_BK := L_NEXT_MATURITY_DATE;
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_ICDREDMN.NEXT_MAT_DATE,
                                                      L_NEXT_MATURITY_DATE) THEN
            L_NEXT_MATURITY_DATE := L_NEXT_MAT_DT_BK;
          END IF;
        END IF;
      
      ELSIF L_ICTM_ACC_REC.ROLL_TENOR_PREF = 'A' THEN
      
        L_NEXT_MATURITY_DATE := ADD_MONTHS(P_ICDREDMN.NEXT_MAT_DATE,
                                           P_ICDREDMN.TENOR_MM +
                                           (P_ICDREDMN.TENOR_YY * 12)) +
                                P_ICDREDMN.TENOR_DD;
      
        IF NVL(L_ICTM_ACC_REC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_ICDREDMN.TENOR_DD, 0) = 0 THEN
          L_NEXT_MAT_DT_BK := L_NEXT_MATURITY_DATE;
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_ICDREDMN.NEXT_MAT_DATE,
                                                      L_NEXT_MATURITY_DATE) THEN
            L_NEXT_MATURITY_DATE := L_NEXT_MAT_DT_BK;
          END IF;
        END IF;
      
      ELSIF L_ICTM_ACC_REC.ROLL_TENOR_PREF = 'L' THEN
      
        L_NEXT_MATURITY_DATE := NULL;
      
      END IF;
    
      UPDATE ICTBS_ACC_PR P
         SET P.NEXT_LIQ_DT      = NVL(L_NXT_LIQ_DATE, P.NEXT_LIQ_DT),
             P.NEXT_SCHD_LIQ_DT = NVL(L_NXT_SCHD_DATE, P.NEXT_SCHD_LIQ_DT)
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
    
      UPDATE ICTM_ACC
         SET ORIG_TENOR_YEARS  = P_ICDREDMN.TENOR_YY,
             ORIG_TENOR_MONTHS = P_ICDREDMN.TENOR_MM,
             ORIG_TENOR_DAYS   = P_ICDREDMN.TENOR_DD,
             MATURITY_DATE     = P_ICDREDMN.NEXT_MAT_DATE,
             
             NEXT_MATURITY_DATE = DECODE(L_ICTM_ACC_REC.AUTO_ROLLOVER,
                                         'Y',
                                         L_NEXT_MATURITY_DATE,
                                         NEXT_MATURITY_DATE),
             ROLL_TENOR_DAYS    = DECODE(L_ICTM_ACC_REC.ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_DD,
                                         ROLL_TENOR_DAYS),
             ROLL_TENOR_MONTHS  = DECODE(L_ICTM_ACC_REC.ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_MM,
                                         ROLL_TENOR_MONTHS),
             ROLL_TENOR_YEARS   = DECODE(L_ICTM_ACC_REC.ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_YY,
                                         ROLL_TENOR_YEARS)
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
    
      L_NEXT_MATURITY_DATE := ADD_MONTHS(P_ICDREDMN.NEXT_MAT_DATE,
                                         P_ICDREDMN.TENOR_MM +
                                         (P_ICDREDMN.TENOR_YY * 12)) +
                              P_ICDREDMN.TENOR_DD;
    
      UPDATE ICTM_CHILDTDACC
         SET ORIG_TENOR_YEARS   = P_ICDREDMN.ORG_YEARS,
             ORIG_TENOR_MONTHS  = P_ICDREDMN.ORG_MONTHS,
             ORIG_TENOR_DAYS    = P_ICDREDMN.ORG_DAYS,
             INT_START_DATE     = P_ICDREDMN.NEXT_MAT_DATE,
             CHG_START_DATE     = P_ICDREDMN.NEXT_MAT_DATE,
             MATURITY_DATE      = L_NEXT_MATURITY_DATE,
             NEXT_MATURITY_DATE = DECODE(AUTO_ROLLOVER,
                                         'Y',
                                         ADD_MONTHS(L_NEXT_MATURITY_DATE,
                                                    P_ICDREDMN.TENOR_MM +
                                                    (P_ICDREDMN.TENOR_YY * 12)) +
                                         P_ICDREDMN.TENOR_DD,
                                         NEXT_MATURITY_DATE),
             ROLL_TENOR_DAYS    = DECODE(ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_DD,
                                         ROLL_TENOR_DAYS),
             ROLL_TENOR_MONTHS  = DECODE(ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_MM,
                                         ROLL_TENOR_MONTHS),
             ROLL_TENOR_YEARS   = DECODE(ROLL_TENOR_PREF,
                                         'A',
                                         P_ICDREDMN.TENOR_YY,
                                         ROLL_TENOR_YEARS)
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO
         AND MATURITY_DATE IS NOT NULL;
    
      UPDATE ICTM_CHILDTDACC_EFFDT
         SET UDE_EFF_DT = P_ICDREDMN.NEXT_MAT_DATE
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO
         AND PROD = PROD
         AND UDE_EFF_DT = UDE_EFF_DT;
    
      UPDATE ICTM_CHILDTDACC_UDEVALS
         SET UDE_EFF_DT = P_ICDREDMN.NEXT_MAT_DATE
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO
         AND PROD = PROD
         AND UDE_EFF_DT = UDE_EFF_DT;
    
      UPDATE ICTM_CHILDTD_ACCOUNT
         SET AC_OPEN_DATE = P_ICDREDMN.NEXT_MAT_DATE
       WHERE ACC = P_ICDREDMN.AC_NO
         AND BRN = P_ICDREDMN.BRN_CODE;
    
    END IF;
    DBG('Returing From fn_tenorchange');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of icpks_fcj_icdredmn.Fn_Tenorchange ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_TENORCHANGE;

  FUNCTION FN_MAIN(P_SOURCE        IN OUT VARCHAR2,
                   P_MODULE        IN VARCHAR2,
                   P_ACTION_CODE   IN OUT VARCHAR2,
                   P_MULTI_TRIP_ID IN OUT VARCHAR2,
                   P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                   P_TBL_NODE      IN TBL_NODE,
                   P_TBL_CHGDETS   IN OUT TBL_CHGDETS,
                   P_UPL_MIS_DET   IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                   P_UPL_UDF_DET   IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                   P_OVERRIDE_FLAG OUT VARCHAR2,
                   P_ERR_TBL       IN OUT OVPKS.TBL_ERROR) RETURN BOOLEAN IS
  
    L_TY_PAYOUTDETS   TY_TB_PAYOUTDETS;
    L_TY_BCPAYOUTDETS ICTM_BCPAYOUT_DETAILS%ROWTYPE;
    L_TY_PCPAYOUTDETS ICTM_PCPAYOUT_DETAILS%ROWTYPE;
    L_TY_STDCUSAC     STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
  
  BEGIN
  
    DBG('Hi coming insdide the function main........');
    FOR I IN 1 .. L_TY_PAYOUTDETS.COUNT LOOP
      DBG('l_ty_payoutdets.INSTNO::' || L_TY_PAYOUTDETS(I).INSTNO);
    END LOOP;
  
    IF NOT FN_MAIN(P_SOURCE,
                   P_MODULE,
                   P_ACTION_CODE,
                   P_MULTI_TRIP_ID,
                   P_ICDREDMN,
                   L_TY_PAYOUTDETS,
                   L_TY_BCPAYOUTDETS,
                   L_TY_PCPAYOUTDETS,
                   L_TY_STDCUSAC,
                   P_TBL_NODE,
                   P_TBL_CHGDETS,
                   P_UPL_MIS_DET,
                   P_UPL_UDF_DET,
                   P_OVERRIDE_FLAG,
                   P_ERR_TBL) THEN
      DBG('failed in actual main');
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_MAIN;

  FUNCTION FN_MAIN(P_SOURCE           IN OUT VARCHAR2,
                   P_MODULE           IN VARCHAR2,
                   P_ACTION_CODE      IN OUT VARCHAR2,
                   P_MULTI_TRIP_ID    IN OUT VARCHAR2,
                   P_ICDREDMN         IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                   P_TY_PAYOUTDETS    IN OUT TY_TB_PAYOUTDETS,
                   P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                   P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                   P_TY_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                   P_TBL_NODE         IN TBL_NODE,
                   P_TBL_CHGDETS      IN OUT TBL_CHGDETS,
                   P_UPL_MIS_DET      IN OUT MITBS_UPLOAD_CLASS_MAPPING%ROWTYPE,
                   P_UPL_UDF_DET      IN OUT UVPKSS_UDF_UPLOAD.TY_UPL_CONT_UDF,
                   P_OVERRIDE_FLAG    OUT VARCHAR2,
                   P_ERR_TBL          IN OUT OVPKS.TBL_ERROR) RETURN BOOLEAN IS
  
    E_FAILURE_EXCEPTION  EXCEPTION;
    E_OVERRIDE_EXCEPTION EXCEPTION;
    L_PK_OR_FULL           VARCHAR2(5) := 'PK';
    L_POST_UPL_STAT        VARCHAR2(1) := 'A';
    L_MODULE               SMTB_MODULES.MODULE_ID%TYPE := 'IC';
    L_FUNCTION_ID          SMTB_MENU.FUNCTION_ID%TYPE := 'ICDREDMN';
    A                      BOOLEAN;
    L_LIAB_ID              STTMS_CUSTOMER.LIABILITY_NO%TYPE;
    L_PRM_ACCOUNT_CLASS    STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_PRM_RECORD_STAT      STTMS_CUST_ACCOUNT.RECORD_STAT%TYPE;
    L_PRM_GRACE_DAYS       STTMS_ACCOUNT_CLASS.GRACE_PERIOD%TYPE;
    L_PARTIAL_LIQD         STTMS_ACCOUNT_CLASS.PARTIAL_LIQUIDATION%TYPE;
    L_PARTIAL_LIQD_AMT_BLK STTMS_ACCOUNT_CLASS.ALLOW_PART_LIQ_WITH_AMT_BLK%TYPE;
    L_ACCOUNT              STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_MATURITY_DATE        DATE;
    L_PRM_AVL_AMT          NUMBER;
    L_PRM_OFS_AMT          NUMBER;
    P_ERROR_CODES          VARCHAR2(2000);
    P_ERROR_PARAMS         VARCHAR2(2000);
    P_ERR_CODE             VARCHAR2(2000);
    P_ERR_PARAMS           VARCHAR2(2000);
    L_TEMP                 NUMBER;
    X                      VARCHAR2(200);
    L_FLD                  VARCHAR2(200);
    L_PRM_PRODUCT_CODE     ISTMS_INSTR_PROD.PROD%TYPE;
    L_RATE_CODE            CSTMS_PRODUCT.RATE_CODE_PREFERRED%TYPE;
    L_RATE_TYPE            CSTMS_PRODUCT.RATE_TYPE_PREFERRED%TYPE;
    RET                    BOOLEAN;
    L_LOV_CNT              NUMBER;
    L_FINAL_ERROR_TYPE     CHAR(1);
    L_COUNT7               NUMBER;
    SUCCESS_EXCEPTION EXCEPTION;
    L_WHAT_TO_DO  CHAR(1);
    L_AUTH_STATUS CHAR(1);
    L_PRODUCT     VARCHAR2(4);
    L_TRNREF      DETBS_RTL_TELLER.TRN_REF_NO%TYPE;
    L_BRN_AVAIL   VARCHAR2(1);
  
    L_CUST_NO     STTMS_CUST_ACCOUNT.CUST_NO%TYPE := NULL;
    L_BRN         STTMS_CUSTOMER.LOCAL_BRANCH%TYPE := NULL;
    L_RECORD_STAT LMTMS_POOL.RECORD_STAT%TYPE;
  
    AL_PRMAT_REQ VARCHAR2(1);
    TD_COUNT     NUMBER;
    L_SD_REF_NO  VARCHAR2(16);
  
    L_STAT_BLOCK VARCHAR2(1);
    CURSOR CR_LINKED_REC(P_LIAB_ID LMTMS_POOL_COLLATERAL_LINKAGES.LIAB_ID%TYPE,
                         P_BRN     LMTMS_POOL_COLLATERAL_LINKAGES.BRANCH_CODE%TYPE,
                         P_AC_NO   LMTMS_POOL_COLLATERAL_LINKAGES.COLLATERAL_CODE%TYPE) IS
      SELECT *
        FROM LMTMS_POOL_COLLATERAL_LINKAGES
       WHERE LIAB_ID = P_LIAB_ID
         AND BRANCH_CODE = P_BRN
         AND COLLATERAL_CODE = P_AC_NO;
  
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_RDFLAG        STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_ACCLASS       VARCHAR2(10);
    L_BC_PRODCODE   VARCHAR2(4);
    L_ACC_PRODCODE  VARCHAR2(4);
    L_GL_PRODCODE   VARCHAR2(4);
    L_CASH_PRODCODE VARCHAR2(4);
  
    L_PROD    VARCHAR2(4);
    L_ADV_REQ VARCHAR2(1);
  
    L_RECCOUNT NUMBER;
  
    L_SERIAL_NO CSTBS_CONTRACT.SERIAL_NO%TYPE;
  
    L_FLAG           NUMBER := 0;
    L_BOOK_ACC       ICTMS_ACC.ACC%TYPE;
    L_PAYOUT_COUNT   NUMBER;
    L_PR_INT_PAYMENT ICTM_PR_INT.PAYMENT_METHOD%TYPE;
    L_TD_DETAILS     ICTM_TD_DETAILS%ROWTYPE;
    L_ICTM_ACC       ICTM_ACC%ROWTYPE;
    L_TOTAL_AMOUNT   NUMBER := 0;
    L_NEXT_LIQ_DT    ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
  
    L_CUST_ACC_REC  STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_TOPUP_CNT     NUMBER := 0;
  
    L_TRAN_AMT NUMBER;
    L_ACTION   VARCHAR2(1);
  
    L_TY_ICDREDMN ICPKS_ICDREDMN_MAIN.TY_ICDREDMN;
    L_TOPUP_FLAG  VARCHAR2(1);
  
    L_COUNT    NUMBER := 0;
    L_ERR_TYPE ERTB_MSGS.TYPE%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_INTEREST_RATE ICTM_ACC.INTEREST_RATE%TYPE;
  
    L_ICTMS_ACC         ICTMS_ACC%ROWTYPE;
    L_INT_PAYOUT_EURACC BOOLEAN := FALSE;
    L_PAYOUT_COUNT1     NUMBER;
    L_OFFSET_ACC        ICTM_TDPAYOUT_DETAILS.OFFSET_ACC%TYPE;
    L_PAYOUT_COMPONENT  ICTM_TDPAYOUT_DETAILS.PAYOUT_COMPONENT%TYPE;
    L_ACC               ICTMS_ACC.ACC%TYPE;
  
    L_ICTM_PR_INT   ICTMS_PR_INT%ROWTYPE;
    L_TB_CALC_BRKUP STPKS_STDTDTOP_UTILS.TY_TB_RED_BRKUP;
    L_COUNT_RESOL   NUMBER := 0;
    L_ICDREDMN      TDVWS_TD_REDEMPTION%ROWTYPE;
    L_OFFSET_BRN    ICTM_TDPAYOUT_DETAILS.OFFSET_BRN%TYPE;
  BEGIN
  
    DBG('In fn_main');
  
    DBG('icpks_partition_info.g_This_Part: ' ||
        ICPKS_PARTITION_INFO.G_THIS_PART);
    BEGIN
      SELECT SEQ_NO
        INTO ICPKS_PARTITION_INFO.G_THIS_PART
        FROM CSTB_CUSTACSEQ
       WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
         AND CUST_AC_NO = P_ICDREDMN.AC_NO;
      DBG('icpks_partition_info.g_This_Part: ' ||
          ICPKS_PARTITION_INFO.G_THIS_PART);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('icpks_partition_info.g_This_Part will not be set.' || SQLERRM);
    END;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                P_MODULE,
                                                P_ACTION_CODE,
                                                P_MULTI_TRIP_ID,
                                                P_ICDREDMN,
                                                P_TY_PAYOUTDETS,
                                                P_BCPAYOUTDETS_REC,
                                                P_PCPAYOUTDETS_REC,
                                                P_TY_STDCUSAC,
                                                P_TBL_NODE,
                                                P_TBL_CHGDETS,
                                                P_UPL_MIS_DET,
                                                P_UPL_UDF_DET,
                                                P_OVERRIDE_FLAG,
                                                P_ERR_TBL,
                                                L_FN_CALL_ID,
                                                L_TB_CLUSTER_DATA) THEN
        DBG('Failed in call 3 to icpks_fcj_icdredmn_cluster.fn_main');
        RETURN FALSE;
      END IF;
    END IF;
  
    ICPKS_FCJ_ICDREDMN.G_FROMREDM := TRUE;
  
    L_TY_ICDREDMN := ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN;
  
    IF NOT ICPKS_CACHE.FN_CLEARCACHE THEN
      DBG('Failed in clearing the cache for cust_Account');
    END IF;
  
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.BRN_CODE,
                                     P_ICDREDMN.AC_NO,
                                     L_CUST_ACC_REC) THEN
      DBG('Failed in select from sttm_cust_account');
    END IF;
  
    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_CUST_ACC_REC.ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  P_ERR_CODE);
  
    IF (NVL(P_ACTION_CODE, '#') IN ('TDRedemption', 'EnrichTDRedemption') AND
       P_SOURCE IN ('FLEXBRANCH')) THEN
      IF NOT FN_DEFAULT_PAYOUTDETAILS(P_ICDREDMN,
                                      P_TY_PAYOUTDETS,
                                      P_BCPAYOUTDETS_REC,
                                      P_PCPAYOUTDETS_REC,
                                      P_TY_STDCUSAC) THEN
        DBG('Failed in  fn_mandatory_redemption::: ');
        RETURN FALSE;
      END IF;
    
      IF NOT FN_INSERT_DATA(P_SOURCE,
                            P_ACTION_CODE,
                            'A',
                            P_ICDREDMN,
                            P_TY_PAYOUTDETS,
                            P_BCPAYOUTDETS_REC,
                            P_PCPAYOUTDETS_REC,
                            P_TY_STDCUSAC,
                            L_TY_ICDREDMN,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Faile in Fn_Insert_Data@@@');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ICDREDMN.AC_NO,
                                                   P_ICDREDMN.BRN_CODE) THEN
      L_TOPUP_FLAG := 'Y';
    ELSE
      L_TOPUP_FLAG := 'N';
    END IF;
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                P_ICDREDMN.AC_NO,
                                                'Y',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
  
    P_ICDREDMN.ACC_AMT := NVL(G_BALREC.ACY_WITHDRAWABLE_BAL, 0);
  
    P_ICDREDMN.CUST_ID := L_CUST_ACC_REC.CUST_NO;
    PKG_RATE_CHART     := NVL(L_ACC_CLASS_REC.TD_RATECHART_ALLOW, 'N');
  
    DBG('Auto Auth is    : ' || NVL(GLOBAL.FN_GET_AUTO_AUTH_STATUS, 'X'));
    DBG('Original Func ID: ' ||
        NVL(GWPKS_TDREDEMPTION.G_ORIGINAL_OPERATIONCODE, '#'));
    DBG('Source          : ' || P_SOURCE);
    DBG('Action Code     : ' || P_ACTION_CODE);
  
    PKG_SOURCE := P_SOURCE;
    PKG_MODULE := P_MODULE;
  
    IF P_ACTION_CODE IN ('TDRedemSave') OR
       P_ACTION_CODE IN ('TDRedemption', 'EnrichTDRedemption') OR
       (NVL(GWPKS_TDREDEMPTION.G_ORIGINAL_OPERATIONCODE, '#') =
       'TDRedemSave' AND NVL(GLOBAL.FN_GET_AUTO_AUTH_STATUS, 'X') = 'Y' AND
       P_SOURCE = 'FLEXCUBE') OR
       (NVL(GWPKS_TDREDEMPTION.G_ORIGINAL_OPERATIONCODE, '#') =
       'TDRedemSave' AND P_SOURCE NOT IN ('FLEXCUBE', 'FLEXBRANCH'))
      
       OR (P_ACTION_CODE IN ('TDRedemption', 'EnrichTDRedemption') AND
       P_SOURCE IN ('FLEXBRANCH'))
    
     THEN
      DBG('Existing Redem Ref Number is : ' || P_ICDREDMN.REDEM_REF_NO);
      DBG('global.current_branch--> ' || GLOBAL.CURRENT_BRANCH || '~' ||
          'gwpks_tdredemption.g_brncode--> ' ||
          GWPKS_TDREDEMPTION.G_BRNCODE);
      IF P_ICDREDMN.REDEM_REF_NO IS NULL THEN
      
        IF NOT TRPKSS.FN_GET_PROCESS_REFNO(NVL(GWPKS_TDREDEMPTION.G_BRNCODE,
                                               GLOBAL.CURRENT_BRANCH),
                                           'ICRD',
                                           GLOBAL.APPLICATION_DATE,
                                           L_SERIAL_NO,
                                           P_ICDREDMN.REDEM_REF_NO,
                                           P_ERR_CODE) THEN
          IF P_ERR_CODE IS NULL THEN
            P_ERR_CODE   := 'TD-RED-16';
            P_ERR_PARAMS := 'Failed to generate TD Reference Number.';
          END IF;
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
        DBG('p_icdredmn.redem_ref_no : ' || P_ICDREDMN.REDEM_REF_NO);
      END IF;
    
      SELECT COUNT(*)
        INTO L_COUNT_RESOL
        FROM ICTB_MAINT_QUEUE
       WHERE MAINT_KEY LIKE
             P_ICDREDMN.BRN_CODE || '~' || P_ICDREDMN.AC_NO || '%'
         AND STATUS = 'U';
      IF L_COUNT_RESOL <> 0 THEN
        IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_ICDREDMN.BRN_CODE,
                                                   P_ICDREDMN.AC_NO,
                                                   P_ERROR_CODES,
                                                   P_ERROR_PARAMS) THEN
          DBG('maint Resolution for acc gave error ' || P_ERROR_CODES || '~' ||
              P_ERROR_PARAMS);
        END IF;
      END IF;
    
    END IF;
  
    DBG('p_action_code--->' || P_ACTION_CODE);
    DBG('p_icdredmn.action_flag--->' || P_ICDREDMN.ACTION_FLAG);
    IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
      DBG('calling fn_validate_redemintpayout');
      IF NOT
          FN_VALIDATE_REDEMINTPAYOUT(P_ICDREDMN, P_ERR_CODE, P_ERROR_PARAMS) THEN
        RETURN FALSE;
      END IF;
      DBG('p_icdredmn.redem_int_payout--->' || P_ICDREDMN.REDEM_INT_PAYOUT);
    END IF;
  
    DBG('COUNT HERE IS --->' || ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.COUNT);
    IF ICPKS_FCJ_ICDREDMN.G_TY_TB_ADDNAPYIN.COUNT > 0 THEN
      IF NOT FN_ADDPAYIN_DEFAULT(P_ICDREDMN, G_TY_TB_ADDNAPYIN, P_ERR_CODE) THEN
        DBG('am here');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_ACTION_CODE NOT IN ('TDRedemAuth', 'TDRedemCompute') THEN
    
      DBG('before fn_mandatory_redemption in icpks_fcj_icredmn');
    
      IF P_SOURCE <> 'FLEXCUBE' THEN
        GLOBAL.PKG_IS_TXN_VIA_GW := 'Y';
      END IF;
    
      IF NOT FN_MANDATORY_REDEMPTION(P_ICDREDMN, P_TY_PAYOUTDETS)
      
       THEN
        DBG('Failed in  fn_mandatory_redemption::: ');
        RETURN FALSE;
      END IF;
    
      IF NOT FN_VALIDATE_REDEMPTION(P_ACTION_CODE,
                                    P_ICDREDMN,
                                    L_TY_ICDREDMN,
                                    P_TY_PAYOUTDETS)
      
       THEN
        DBG('Failed in  fn_mandatory_redemption::: ');
        RETURN FALSE;
      END IF;
    
      DBG('Account Linked with SafeDeposit');
      SELECT COUNT(*)
        INTO L_RECCOUNT
        FROM DLTB_LINKAGES A, CSTB_CONTRACT B
       WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
         AND A.EVENT_SEQ_NO = B.LATEST_EVENT_SEQ_NO
         AND B.CONTRACT_STATUS <> 'S'
         AND A.LINKED_TO_REF = P_ICDREDMN.AC_NO;
      IF L_RECCOUNT > 0 THEN
        DBG('Account is Linked with SafeDeposit');
        L_FLD := NULL;
      
        OVPKSS.PR_APPENDTBL('TD-REDM25', L_FLD);
      
        RAISE E_FAILURE_EXCEPTION;
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE IN ('TDRedemAuthQry', 'TDRedemAuth') AND
       P_ICDREDMN.MAKERID = GLOBAL.USER_ID
      
       AND P_SOURCE IN ('FLEXBRANCH')
    
     THEN
      DBG('User is Same - Maker and Checker cannot be same...');
      OVPKSS.PR_APPENDTBL('LD-AU013', NULL);
    
    END IF;
    DBG('before fn_mandatory_payoutdetails in icpks_fcj_icredmn');
    DBG('p_ty_payoutdets COUNT IS :' || P_TY_PAYOUTDETS.COUNT);
    DBG('p_icdredmn.redemption_mode IS :' || P_ICDREDMN.REDEMPTION_MODE);
  
    ICPKSS_BOD.G_TRN_DT := P_ICDREDMN.TRN_DT;
    DBG('Action Flag :: ' || P_ICDREDMN.ACTION_FLAG);
    P_ICDREDMN.WAVE_PENALTY := NVL(P_ICDREDMN.WAVE_PENALTY, 'N');
  
    IF P_ICDREDMN.ACTION_FLAG = 'R' AND P_ICDREDMN.REDEMPTION_MODE = 'N' AND
       P_ICDREDMN.WAVE_PENALTY = 'Y' THEN
      ICPKS_BOD.G_WAVE_PENALTY := P_ICDREDMN.WAVE_PENALTY;
    
    ELSIF P_ICDREDMN.ACTION_FLAG = 'R' AND P_ICDREDMN.REDEMPTION_MODE = 'N' AND
          P_ICDREDMN.WAVE_PENALTY = 'N' THEN
      ICPKS_BOD.G_WAVE_PENALTY := 'N';
    
    ELSIF P_ICDREDMN.ACTION_FLAG = 'R' AND P_ICDREDMN.REDEMPTION_MODE = 'Y' AND
          P_ICDREDMN.WAVE_PENALTY = 'N' THEN
      ICPKS_BOD.G_WAVE_PENALTY := 'N';
    
    END IF;
  
    DBG('Action Flag :' || P_ICDREDMN.ACTION_FLAG);
    IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
      DBG('Setting redemption flag');
      G_REDM_FLAG := FALSE;
      DBG('Its a Redemption process');
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
        DBG('Its a Full Redemption Case');
        G_REDM_FLAG := TRUE;
      END IF;
    END IF;
  
    DBG('ACTION CODE :' || P_ACTION_CODE);
    IF P_ACTION_CODE IN ('TDRedemSave', 'TDRedemAuth') AND
       (NOT GWPKS_UTIL.G_FROM_BEAN) THEN
      DBG('before fn_limits_validate');
      DBG('ACTION_FLAG :' || P_ICDREDMN.ACTION_FLAG);
      DBG('REDEMTION MODE :' || P_ICDREDMN.REDEMPTION_MODE);
      DBG('ACC AMT :' || P_ICDREDMN.ACC_AMT);
      DBG('REDEMTION AMT :' || P_ICDREDMN.REDEMPTION_AMT);
      IF (NVL(P_ICDREDMN.ACTION_FLAG, '$') = 'R' AND
         NVL(P_ICDREDMN.REDEMPTION_MODE, '$') = 'N') OR
         NVL(P_ICDREDMN.ACTION_FLAG, '$') = 'E' THEN
        L_TRAN_AMT := P_ICDREDMN.ACC_AMT;
      ELSIF (NVL(P_ICDREDMN.ACTION_FLAG, '$') = 'R' AND
            NVL(P_ICDREDMN.REDEMPTION_MODE, '$') = 'Y') THEN
        L_TRAN_AMT := P_ICDREDMN.REDEMPTION_AMT;
      END IF;
      DBG('TRAN AMT :' || L_TRAN_AMT);
      IF P_ACTION_CODE = 'TDRedemSave' THEN
        L_ACTION := 'I';
      ELSIF P_ACTION_CODE = 'TDRedemAuth' THEN
        L_ACTION := 'A';
      END IF;
      DBG('ACTION :' || L_ACTION);
      DBG('before fn_limits_validate__input');
      IF NOT SMPKSS.FN_LIMITS_VALIDATE(L_ACTION,
                                       NVL(P_ICDREDMN.CCY, '#'),
                                       NVL(L_TRAN_AMT, 0),
                                       GLOBAL.USER_ID,
                                       GLOBAL.CURRENT_BRANCH,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
        DBG('failed during the conversion');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        L_ERR_TYPE := OVPKSS.FN_GETTYPE(P_ERR_CODE);
        IF L_ERR_TYPE = 'E' THEN
          RETURN FALSE;
        END IF;
      
      END IF;
    END IF;
  
    IF P_ICDREDMN.ACTION_FLAG = 'R' THEN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                  P_MODULE,
                                                  P_ACTION_CODE,
                                                  P_MULTI_TRIP_ID,
                                                  P_ICDREDMN,
                                                  P_TY_PAYOUTDETS,
                                                  P_BCPAYOUTDETS_REC,
                                                  P_PCPAYOUTDETS_REC,
                                                  P_TY_STDCUSAC,
                                                  P_TBL_NODE,
                                                  P_TBL_CHGDETS,
                                                  P_UPL_MIS_DET,
                                                  P_UPL_UDF_DET,
                                                  P_OVERRIDE_FLAG,
                                                  P_ERR_TBL,
                                                  L_FN_CALL_ID,
                                                  L_TB_CLUSTER_DATA) THEN
          DBG('Failed in call 3 to icpks_fcj_icdredmn_cluster.fn_main');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('p_action_code vb' || P_ACTION_CODE);
      IF ((GWPKS_UTIL.G_FROM_BEAN AND P_ACTION_CODE = 'EnrichTDRedemption') OR
         (P_ACTION_CODE NOT IN
         ('TDRedemCreateRef',
            'TDRedemSave',
            'TDRedemDelete',
            'TDRedemAuthQry',
            'EnrichTDRedemption'))) THEN
        PR_SET_REDM_INT_PARAMS(P_ICDREDMN, P_TY_PAYOUTDETS);
        IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
        
          BEGIN
            SELECT COUNT(1)
              INTO L_PAYOUT_COUNT1
              FROM ICTM_TDPAYOUT_DETAILS
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO
               AND PAYOUT_COMPONENT = 'I'
               AND PAYOUTTYPE IN ('S', 'G');
          EXCEPTION
            WHEN OTHERS THEN
              DBG('No Payout For Interest');
              L_PAYOUT_COUNT1 := 0;
          END;
        
          DBG('Interst Payout Maintained vb' || L_PAYOUT_COUNT1);
          IF L_PAYOUT_COUNT1 = 1 THEN
          
            BEGIN
              SELECT *
                INTO L_ICTMS_ACC
                FROM ICTMS_ACC
               WHERE BRN = P_ICDREDMN.BRN_CODE
                 AND ACC = P_ICDREDMN.AC_NO;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('No Payout For this account maintained');
            END;
          
            IF L_ICTMS_ACC.BOOK_ACC = L_ICTMS_ACC.ACC THEN
              SELECT OFFSET_ACC, OFFSET_BRN
                INTO L_OFFSET_ACC, L_OFFSET_BRN
                FROM ICTM_TDPAYOUT_DETAILS
               WHERE BRN = P_ICDREDMN.BRN_CODE
                 AND ACC = P_ICDREDMN.AC_NO
                 AND PAYOUT_COMPONENT = 'I'
                 AND PAYOUTTYPE IN ('S', 'G');
            
              L_INT_PAYOUT_EURACC := TRUE;
            
              UPDATE ICTM_ACC
                 SET BOOK_ACC = L_OFFSET_ACC, BOOK_BRN = L_OFFSET_BRN
               WHERE BRN = P_ICDREDMN.BRN_CODE
                 AND ACC = P_ICDREDMN.AC_NO;
            END IF;
          END IF;
        END IF;
      END IF;
    
      DBG('account class is -> ' || L_ACC_CLASS_REC.ACCOUNT_CLASS);
      DBG('allow topup is ->' || L_ACC_CLASS_REC.ALLOW_TOPUP);
    
      IF NOT STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
        DBG('# In stpks_aclass_transfer.g_aclass_transfer TRUE');
        DBG('# l_acc_class_rec.account_class...' ||
            L_ACC_CLASS_REC.ACCOUNT_CLASS);
        DBG('# global.user_id...' || GLOBAL.USER_ID);
        SELECT COUNT(*)
          INTO L_COUNT
          FROM SMVW_USER_ACCCLASS
         WHERE ACCOUNT_CLASS = L_ACC_CLASS_REC.ACCOUNT_CLASS
           AND USER_ID = GLOBAL.USER_ID;
        DBG('# l_count...' || L_COUNT);
        IF L_COUNT = 0 THEN
          DBG('# Account class not allowed for the current user');
          P_ERR_CODE   := 'ST-ACC-155';
          P_ERR_PARAMS := NULL;
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;
    
      IF L_TOPUP_FLAG = 'Y' THEN
      
        IF NOT STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP(P_SOURCE,
                                                   P_ACTION_CODE,
                                                   P_ICDREDMN,
                                                   L_TB_CALC_BRKUP,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
          DBG('topup allowed TDs fn_matamt_comp acc gave error ' ||
              P_ERROR_CODES || '~' || P_ERROR_PARAMS);
        
          RETURN FALSE;
        END IF;
      
        P_ICDREDMN.INTEREST_AMOUNT := STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST;
        P_ICDREDMN.TAX_AMOUNT      := STPKS_STDTDTOP_UTILS.G_TOTAL_TAX;
      
        IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
          P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.MATURITY_AMOUNT;
        ELSIF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
          P_ICDREDMN.PAYOUT_AMOUNT := P_ICDREDMN.REDEMPTION_AMT;
        END IF;
      
        IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
          P_ICDREDMN.INTEREST_AMOUNT := NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_INT,
                                            0);
          P_ICDREDMN.TAX_AMOUNT      := NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_TAX,
                                            0);
        END IF;
      
      ELSE
      
        IF NOT FN_MATURITY_AMOUNT_CALC(P_SOURCE,
                                       P_MODULE,
                                       P_ACTION_CODE,
                                       P_MULTI_TRIP_ID,
                                       P_ICDREDMN,
                                       P_TY_PAYOUTDETS,
                                       P_BCPAYOUTDETS_REC,
                                       P_PCPAYOUTDETS_REC,
                                       P_TY_STDCUSAC,
                                       P_TBL_NODE,
                                       P_TBL_CHGDETS,
                                       P_UPL_MIS_DET,
                                       P_UPL_UDF_DET,
                                       P_OVERRIDE_FLAG,
                                       P_ERR_TBL) THEN
          DBG('Failed in fn_maturity_amount_calc');
          RETURN FALSE;
        END IF;
      
      END IF;
    
      IF L_TB_CALC_BRKUP.COUNT > 0 THEN
        IF NOT STPKS_STDTDTOP_UTILS.FN_DMP_BRKUP_CALC(L_TB_CALC_BRKUP) THEN
          DBG('Failed in call to stpks_stdtdtop_utils.fn_dmp_brkup_calc to insert tdtb_tdtb_redm_calc_brkup tables');
        END IF;
      END IF;
    
      IF ((GWPKS_UTIL.G_FROM_BEAN AND
         P_ACTION_CODE NOT IN ('TDRedemCompute')) OR
         (P_ACTION_CODE NOT IN
         ('TDRedemAuth', 'TDRedemCompute', 'EnrichTDRedemption'))) THEN
      
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('Call from BRANCH');
        END IF;
      
        DBG('looping for mandatory ');
        DBG('p_bcpayoutdets_rec.bankcode::' || P_BCPAYOUTDETS_REC.BANKCODE);
        IF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
                'N') = 'N') THEN
          IF NOT FN_MANDATORY_PAYOUTDETAILS(P_ICDREDMN,
                                            P_TY_PAYOUTDETS,
                                            P_BCPAYOUTDETS_REC,
                                            P_PCPAYOUTDETS_REC,
                                            P_TY_STDCUSAC) THEN
            DBG('Failed in  fn_mandatory_redemption::: ');
            RETURN FALSE;
          END IF;
        END IF;
      
        IF (NVL(P_ACTION_CODE, '#') IN
           ('TDRedemption', 'EnrichTDRedemption') AND
           P_SOURCE IN ('FLEXBRANCH')) THEN
          FOR M IN 1 .. P_TY_PAYOUTDETS.LAST LOOP
            DBG(' Redemption Payout Component =' || P_TY_PAYOUTDETS(M)
                .REDM_PAYOUT_COMP);
            IF P_TY_PAYOUTDETS(M).REDM_PAYOUT_COMP = 'I' THEN
              DBG('interest component  index =' || M);
              DBG('To default the interest amount');
            
              P_TY_PAYOUTDETS(M).REDMAMT := NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_INT,
                                                0) - NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_TAX,
                                                         0) -
                                            NVL(STPKS_STDTDTOP_UTILS.G_CURR_REDEM_PENALTY,
                                                0);
              DBG('redemption amoutn for interest ---->' || P_TY_PAYOUTDETS(M)
                  .REDMAMT);
            END IF;
          END LOOP;
        END IF;
      
        IF NOT GWPKS_UTIL.G_FROM_BEAN AND P_SOURCE <> 'FLEXBRANCH' THEN
        
          DBG('before fn_default_payoutdetails for default ');
          DBG('calling');
          IF NOT FN_DEFAULT_PAYOUTDETAILS(P_ICDREDMN,
                                          P_TY_PAYOUTDETS,
                                          P_BCPAYOUTDETS_REC,
                                          P_PCPAYOUTDETS_REC,
                                          P_TY_STDCUSAC) THEN
            DBG('Failed in  fn_mandatory_redemption::: ');
            RETURN FALSE;
          END IF;
        
        END IF;
      END IF;
      DBG('before fn_validate_payoutdetails in icpks_fcj_icredmn');
      IF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
              'N') = 'N') THEN
        IF NOT FN_VALIDATE_PAYOUTDETAILS(P_ACTION_CODE,
                                         P_ICDREDMN,
                                         P_TY_PAYOUTDETS,
                                         P_BCPAYOUTDETS_REC,
                                         P_PCPAYOUTDETS_REC,
                                         P_TY_STDCUSAC,
                                         L_BC_PRODCODE,
                                         L_ACC_PRODCODE,
                                         L_GL_PRODCODE,
                                         L_CASH_PRODCODE) THEN
          DBG('Failed in  fn_validate_payoutdetails::: ');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('p_action_code : ' || P_ACTION_CODE);
    
      IF ((GWPKS_UTIL.G_FROM_BEAN AND P_ACTION_CODE = 'EnrichTDRedemption') OR
         (P_ACTION_CODE NOT IN
         ('TDRedemCreateRef',
            'TDRedemSave',
            'TDRedemDelete',
            'TDRedemAuthQry',
            'TDRedemCompute',
            'EnrichTDRedemption'))) THEN
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('Call from BRANCH b4 calling fn_upload_payoutdets');
        END IF;
      
        DBG('before fn_upload_payoutdets in icpks_fcj_icredmn');
        IF (NVL(ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.CHAR_FIELD84,
                'N') = 'N') THEN
          GWPKS_UTIL.G_MAKERID := P_ICDREDMN.MAKERID;
          IF NOT FN_UPLOAD_PAYOUTDETS(P_SOURCE,
                                      P_ICDREDMN,
                                      P_TY_PAYOUTDETS,
                                      P_BCPAYOUTDETS_REC,
                                      P_PCPAYOUTDETS_REC,
                                      P_TY_STDCUSAC,
                                      L_BC_PRODCODE,
                                      L_ACC_PRODCODE,
                                      L_GL_PRODCODE,
                                      L_CASH_PRODCODE) THEN
            DBG('Failed in  fn_upload_payoutdets::: ');
            RETURN FALSE;
          END IF;
        
          DBG('Before calling Fn_Insert_Data....... Update Denom Cert stat!!!... ');
          IF NOT FN_PROCESS_DENOM_CERT(P_SOURCE,
                                       P_ACTION_CODE,
                                       P_ICDREDMN,
                                       L_TY_ICDREDMN,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
            DBG('Failed in Fn_Process_Denom_Cert');
            RETURN FALSE;
          END IF;
        
          IF (NVL(P_ACTION_CODE, '#') IN
             ('TDRedemption', 'EnrichTDRedemption') AND
             P_SOURCE IN ('FLEXBRANCH')) THEN
          
            IF NOT FN_UPDATE_REDEMPTION_TBLS(P_SOURCE,
                                             P_ICDREDMN,
                                             P_TY_PAYOUTDETS,
                                             P_BCPAYOUTDETS_REC,
                                             P_PCPAYOUTDETS_REC,
                                             P_TY_STDCUSAC,
                                             L_TY_ICDREDMN,
                                             'A',
                                             P_ERR_CODE,
                                             P_ERR_PARAMS) THEN
              DBG('Faile in Fn_Insert_Data');
              RETURN FALSE;
            END IF;
          
          END IF;
        
        END IF;
      
        DBG('PROJECTED_INT_TILL_MAT in ictm_td_details will be updated as ' ||
            STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST);
        UPDATE ICTMS_TD_DETAILS
           SET PROJECTED_INT_TILL_MAT = STPKS_STDTDTOP_UTILS.G_TOTAL_INTEREST
         WHERE ACC = P_ICDREDMN.AC_NO
           AND BRN = P_ICDREDMN.BRN_CODE;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID      := 5;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                    P_MODULE,
                                                    P_ACTION_CODE,
                                                    P_MULTI_TRIP_ID,
                                                    P_ICDREDMN,
                                                    P_TY_PAYOUTDETS,
                                                    P_BCPAYOUTDETS_REC,
                                                    P_PCPAYOUTDETS_REC,
                                                    P_TY_STDCUSAC,
                                                    P_TBL_NODE,
                                                    P_TBL_CHGDETS,
                                                    P_UPL_MIS_DET,
                                                    P_UPL_UDF_DET,
                                                    P_OVERRIDE_FLAG,
                                                    P_ERR_TBL,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA) THEN
            DBG('Failed in call 3 to icpks_fcj_icdredmn_cluster.fn_main');
            RETURN FALSE;
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('l_prod') THEN
            L_PROD := L_TB_CLUSTER_DATA('l_prod');
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          BEGIN
            SELECT PROD
              INTO L_PROD
              FROM ICTBS_ACC_PR
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO
               AND PROD_TYPE = 'I';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed in selecting Product Code from ictb_redem_acc_pr.................');
          END;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        DBG('Product is ::: ' || L_PROD);
      
        L_ICTM_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PROD);
      
        DBG('Redem adv details are ::: ' ||
            P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE || '~' ||
            L_ICTM_PR_INT.REDEM_ADV_REQD);
      
        IF NVL(P_ICDREDMN.SUPPRESS_REDEMPTION_ADVICE, 'N') = 'N' AND
           NVL(L_ICTM_PR_INT.REDEM_ADV_REQD, 'N') = 'Y'
        
         THEN
        
          IF P_ICDREDMN.REDEMPTION_MODE = 'Y' THEN
            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := P_ICDREDMN.REDEMPTION_AMT;
            ICPKSS_UTIL.DBG('Redmn Amt is :' ||
                            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
          
            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := P_ICDREDMN.REDEMPTION_AMT;
            ICPKSS_UTIL.DBG('Redmn Amt is :' ||
                            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT);
          
          END IF;
        
          DBG('Calling icpks_tdeposit_certificate for adv gen');
          IF NOT
              ICPKSS_TDEPOSIT_CERTIFICATE.FN_TD_REDEM_ADV(P_ICDREDMN.AC_NO,
                                                          P_ICDREDMN.BRN_CODE,
                                                          P_ICDREDMN.REDEM_REF_NO) THEN
            DBG('Failed in Redemption Advice Generation.................');
            RETURN FALSE;
          ELSE
            DBG('Redemption Advice has been successfully Generated......');
          END IF;
        END IF;
      
      END IF;
    ELSIF P_ICDREDMN.ACTION_FLAG = 'E' THEN
      DBG('p_action_code : ' || P_ACTION_CODE);
      IF P_ACTION_CODE NOT IN ('TDRedemCreateRef',
                               'TDRedemSave',
                               'TDRedemDelete',
                               'TDRedemAuthQry',
                               'TDRedemCompute') THEN
        DBG('Action Flag is Renew.. So calling fn_rollover');
        GWPKS_UTIL.G_MAKERID := P_ICDREDMN.MAKERID;
        RET                  := FN_ROLLOVER(P_ICDREDMN);
        IF RET THEN
        
          DBG('ovpkss.gl_tblerror-->COUNT' || OVPKSS.GL_TBLERROR.COUNT);
          IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
            FOR L_INDEX IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
              DBG('Error Code :' || OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE);
              DBG('Error param :' || OVPKSS.GL_TBLERROR(L_INDEX).PARAMS);
              IF NVL(OVPKSS.FN_GETTYPE(OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE),
                     'X') = 'E' THEN
                RETURN FALSE;
              END IF;
            END LOOP;
          END IF;
        ELSE
          DBG('Failed in fn_rollover');
          RETURN FALSE;
        
          DBG('Returning true from fn_rollover ');
        END IF;
      
      END IF;
    
    ELSIF P_ICDREDMN.ACTION_FLAG = 'T' THEN
      GWPKS_UTIL.G_MAKERID := P_ICDREDMN.MAKERID;
      RET                  := FN_TENORCHANGE(P_ICDREDMN, P_ACTION_CODE);
    
      IF P_ACTION_CODE = 'TDRedemAuth' THEN
        DBG('Inside Maturity');
        IF L_TOPUP_FLAG = 'Y' THEN
        
          L_ICDREDMN          := NULL;
          L_ICDREDMN.BRN_CODE := P_ICDREDMN.BRN_CODE;
          L_ICDREDMN.AC_NO    := P_ICDREDMN.AC_NO;
        
          L_ICDREDMN.WAVE_PENALTY   := 'Y';
          L_ICDREDMN.REDEMPTION_AMT := 0;
          L_ICDREDMN.CCY            := P_ICDREDMN.CCY;
          IF NOT ICPKS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_ICDREDMN.BRN_CODE,
                                                    P_ICDREDMN.AC_NO,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN
            DBG('err in resolution maintenance :' || P_ERR_CODE || '~' ||
                P_ERR_PARAMS);
          END IF;
          ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_ICDREDMN.BRN_CODE,
                                              P_ICDREDMN.AC_NO);
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');
        
          IF NOT STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP(P_SOURCE,
                                                     P_ACTION_CODE,
                                                     
                                                     L_ICDREDMN,
                                                     
                                                     L_TB_CALC_BRKUP,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
            DBG('Topup allowed TDs fn_matamt_comp acc gave error ' ||
                P_ERROR_CODES || '~' || P_ERROR_PARAMS);
            RETURN FALSE;
          END IF;
          P_ICDREDMN.MATURITY_AMOUNT := L_ICDREDMN.MATURITY_AMOUNT;
          P_ICDREDMN.INTEREST_RATE   := L_ICDREDMN.INTEREST_RATE;
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');
        
          IF L_TB_CALC_BRKUP.COUNT > 0 THEN
            IF NOT STPKS_STDTDTOP_UTILS.FN_DMP_BRKUP_CALC(L_TB_CALC_BRKUP) THEN
              DBG('Failed in call to stpks_stdtdtop_utils.fn_dmp_brkup_calc to insert tdtb_tdtb_redm_calc_brkup tables');
            END IF;
            L_TB_CALC_BRKUP.DELETE;
          END IF;
        
          L_TOTAL_AMOUNT  := P_ICDREDMN.MATURITY_AMOUNT;
          L_INTEREST_RATE := P_ICDREDMN.INTEREST_RATE;
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');
        ELSE
        
          BEGIN
            SELECT PROD
              INTO L_PRODUCT
              FROM ICTMS_ACC_PR
             WHERE BRN = P_ICDREDMN.BRN_CODE
               AND ACC = P_ICDREDMN.AC_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('In WOT of product select--> ' || SQLERRM);
              RETURN FALSE;
          END;
          DBG('L_PRODUCT--->' || L_PRODUCT);
        
          STPKS_STDCUSAC_UTILS_1.PR_CALC_MATURITY(P_ICDREDMN.BRN_CODE,
                                                  P_ICDREDMN.AC_NO,
                                                  L_PRODUCT,
                                                  L_TOTAL_AMOUNT);
          DBG('Total Amount--->' || L_TOTAL_AMOUNT);
          L_INTEREST_RATE := STPKS_STDCUSAC_UTILS_1.FN_PROJ_INTRATE('STDCUSAC',
                                                                    P_ICDREDMN.BRN_CODE,
                                                                    P_ICDREDMN.AC_NO,
                                                                    L_PRODUCT);
        END IF;
        DBG('l_interest_rate--->' || L_INTEREST_RATE);
        UPDATE ICTM_ACC
           SET INTEREST_RATE   = L_INTEREST_RATE,
               MATURITY_AMOUNT = L_TOTAL_AMOUNT
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO;
      END IF;
    
      IF RET THEN
        DBG('ovpkss.gl_tblerror-->COUNT' || OVPKSS.GL_TBLERROR.COUNT);
        IF OVPKSS.GL_TBLERROR.COUNT > 0 THEN
          FOR L_INDEX IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
            DBG('Error Code :' || OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE);
            DBG('Error param :' || OVPKSS.GL_TBLERROR(L_INDEX).PARAMS);
            IF NVL(OVPKSS.FN_GETTYPE(OVPKSS.GL_TBLERROR(L_INDEX).ERR_CODE),
                   'X') = 'E' THEN
              RETURN FALSE;
            END IF;
          END LOOP;
        END IF;
      ELSE
        DBG('Failed in fn_tenorchange');
        RETURN FALSE;
        DBG('Returning true from fn_rollover ');
      END IF;
    
    END IF;
  
    IF P_ICDREDMN.ACTION_FLAG <> 'T' THEN
    
      IF (P_ACTION_CODE IN ('TDRedemAuth') AND L_TOPUP_FLAG = 'Y' AND
         P_ICDREDMN.ACTION_FLAG = 'R') OR
         (NVL(GWPKS_UTIL.PKG_ACTTYPE, '*') = 'SAVEAUTOAUTH' AND
         L_TOPUP_FLAG = 'Y' AND P_ICDREDMN.ACTION_FLAG = 'R') THEN
        IF NOT STPKS_STDTDTOP_UTILS.FN_TOPUP_SETTLED(P_ICDREDMN.BRN_CODE,
                                                     P_ICDREDMN.AC_NO,
                                                     P_ICDREDMN.CCY,
                                                     'REDEM',
                                                     GLOBAL.APPLICATION_DATE,
                                                     0,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
        
          DBG('failed in icpks_td_topup.fn_topup_settled');
          RETURN FALSE;
        END IF;
      END IF;
    
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 6;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_MAIN(P_SOURCE,
                                                P_MODULE,
                                                P_ACTION_CODE,
                                                P_MULTI_TRIP_ID,
                                                P_ICDREDMN,
                                                P_TY_PAYOUTDETS,
                                                P_BCPAYOUTDETS_REC,
                                                P_PCPAYOUTDETS_REC,
                                                P_TY_STDCUSAC,
                                                P_TBL_NODE,
                                                P_TBL_CHGDETS,
                                                P_UPL_MIS_DET,
                                                P_UPL_UDF_DET,
                                                P_OVERRIDE_FLAG,
                                                P_ERR_TBL,
                                                L_FN_CALL_ID,
                                                L_TB_CLUSTER_DATA) THEN
        DBG('Failed in call 5 to icpks_fcj_icdredmn_cluster.fn_main');
        RETURN FALSE;
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    DBG('redemption_by flag is :' || P_ICDREDMN.REDEMPTION_BY);
    IF P_TY_PAYOUTDETS.COUNT > 0 THEN
      IF NVL(P_ICDREDMN.REDEMPTION_BY, 'M') <> 'M' OR
         NVL(P_TY_PAYOUTDETS(1).PAYOUTTYPE, '#') = 'C' THEN
        DEPKSS_RTL_TELLER.PR_CHG_PICKUP_REQD(TRUE);
        IF P_TBL_NODE.EXISTS('Charge-Details') THEN
          DBG('Uploading CHARGE-Details');
          IF NOT FN_DEFAULT_CHGDETS(P_TBL_CHGDETS) THEN
            DBG('Falied in FN_DEFAULT_CHGDETS');
            RETURN FALSE;
          END IF;
        END IF;
      
        DBG('depks_rtl_teller.pkg_rtl_teller_rec.TRN_REF_NO' ||
            DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO);
      
        IF DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO IS NOT NULL AND
           P_ACTION_CODE NOT IN ('TDRedemCreateRef',
                                 'TDRedemSave',
                                 'TDRedemDelete',
                                 'TDRedemAuthQry',
                                 'TDRedemCompute') THEN
        
          BEGIN
            SELECT PRODUCT_CODE
              INTO L_PRODUCT
              FROM DETB_RTL_TELLER
             WHERE TRN_REF_NO =
                   DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Exception in SELECTING TRN_REF_NO ' || SQLERRM);
              OVPKSS.PR_APPENDTBL('ST-OTHR-001', NULL);
              RETURN FALSE;
          END;
        
          P_ICDREDMN.FCCREF := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
        
          DBG('THE VALUE OF p_icdredmn.FCCREF ' || P_ICDREDMN.FCCREF);
          DBG('THE VALUE OF PRODUCT CODE ' || L_PRODUCT);
        
          DBG('before fn_validate_subsystems in icpks_fcj_icredmn');
          IF NOT FN_VALIDATE_SUBSYSTEMS(P_ICDREDMN,
                                        P_TBL_NODE,
                                        P_TBL_CHGDETS,
                                        P_UPL_MIS_DET,
                                        P_UPL_UDF_DET,
                                        L_PRODUCT)
          
           THEN
            DBG('Failed in   fn_validate_subsystems::: ');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
          
            RETURN FALSE;
          END IF;
        
          DBG('before goin in fn_upload_subsystems in icpks_fcj_icredmn');
        
          IF NOT FN_UPLOAD_SUBSYSTEMS(P_ICDREDMN,
                                      P_TBL_CHGDETS,
                                      P_UPL_MIS_DET,
                                      P_UPL_UDF_DET,
                                      P_TBL_NODE,
                                      L_PRODUCT)
          
           THEN
            DBG('Failed in   fn_validate_subsystems::: ');
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;
  
    DBG('after fn_upload_subsystems in icpks_fcj_icredmn');
    DBG('Going to check if there are errors available in the p_error_params');
  
    DBG('p_source' || P_SOURCE);
    DBG('p_module::' || P_MODULE);
    CSPKS_UPLOAD.PR_INIT(P_SOURCE, 'ICDREDMN');
    IF NOT CSPKSS_UPLOAD.FN_WHAT_TO_DO(P_SOURCE,
                                       NVL(P_MODULE, 'RT'),
                                       L_WHAT_TO_DO,
                                       L_AUTH_STATUS,
                                       P_ERR_CODE,
                                       P_ERR_PARAMS) THEN
      DBG('cspkss_upload.fn_what_to_do returned FALSE');
      RETURN FALSE;
    END IF;
  
    DBG('l_what_to_do' || L_WHAT_TO_DO);
    DBG('l_auth_status' || L_AUTH_STATUS);
  
    IF L_WHAT_TO_DO <> 'R' THEN
    
      IF P_ACTION_CODE IN ('TDRedemSave') OR
         P_ACTION_CODE IN ('TDRedemption', 'EnrichTDRedemption') OR
         (NVL(GWPKS_TDREDEMPTION.G_ORIGINAL_OPERATIONCODE, '#') =
         'TDRedemSave' AND NVL(GLOBAL.FN_GET_AUTO_AUTH_STATUS, 'X') = 'Y' AND
         P_SOURCE = 'FLEXCUBE') OR
         (NVL(GWPKS_TDREDEMPTION.G_ORIGINAL_OPERATIONCODE, '#') =
         'TDRedemSave' AND P_SOURCE NOT IN ('FLEXCUBE', 'FLEXBRANCH')) THEN
      
        DBG('Success case: p_icdredmn.redem_ref_no : ' ||
            P_ICDREDMN.REDEM_REF_NO);
        IF P_ICDREDMN.REDEM_REF_NO IS NULL THEN
        
          IF NOT TRPKSS.FN_GET_PROCESS_REFNO(NVL(GWPKS_TDREDEMPTION.G_BRNCODE,
                                                 GLOBAL.CURRENT_BRANCH),
                                             'ICRD',
                                             GLOBAL.APPLICATION_DATE,
                                             L_SERIAL_NO,
                                             P_ICDREDMN.REDEM_REF_NO,
                                             P_ERR_CODE) THEN
            IF P_ERR_CODE IS NULL THEN
              P_ERR_CODE   := 'TD-RED-16';
              P_ERR_PARAMS := 'Failed to generate TD Reference Number.';
            END IF;
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;
          DBG('p_icdredmn.redem_ref_no : ' || P_ICDREDMN.REDEM_REF_NO);
        END IF;
      
        IF NVL(GWPKS_UTIL.PKG_FUNC, '*') = '1317' THEN
          IF GWPKS_UTIL.G_FROM_BEAN AND
             P_ACTION_CODE NOT IN ('TDRedemAuth', 'TDRedemCompute') THEN
            IF P_TY_PAYOUTDETS.COUNT > 0 THEN
              FOR I IN 1 .. P_TY_PAYOUTDETS.COUNT LOOP
              
                IF P_TY_PAYOUTDETS(I).REF_NO IS NOT NULL THEN
                  DBG('>> insert in payout chg table STTM_ACCLSR_PAYOUT_DTL fore refno: ' || P_TY_PAYOUTDETS(I)
                      .REF_NO);
                  IF P_TY_PAYOUTDETS(I)
                   .PAYOUTTYPE IN ('S', 'G', 'L', 'C', 'B', 'D') THEN
                    INSERT INTO STTM_ACCLSR_PAYOUT_DTL
                      (BRN,
                       ACC,
                       CCY,
                       PAYOUT_TYPE,
                       OFFSET_BRN,
                       OFFSET_ACC,
                       OFFSET_CCY,
                       REDAMT,
                       TRN_REF_NO,
                       EXT_REF_NO,
                       REDEM_REF_NO)
                    VALUES
                      (P_TY_PAYOUTDETS(I).BRN,
                       P_TY_PAYOUTDETS(I).ACC,
                       P_TY_PAYOUTDETS(I).CCY,
                       P_TY_PAYOUTDETS(I).PAYOUTTYPE,
                       P_TY_PAYOUTDETS(I).OFFSET_BRN,
                       P_TY_PAYOUTDETS(I).OFFSET_ACC,
                       P_TY_PAYOUTDETS(I).OFFSET_CCY,
                       P_TY_PAYOUTDETS(I).REDMAMT,
                       
                       P_TY_PAYOUTDETS(I).REF_NO,
                       P_ICDREDMN.XREF,
                       '');
                  
                  END IF;
                END IF;
              END LOOP;
            END IF;
          END IF;
        END IF;
      
      END IF;
    
    END IF;
  
    IF L_INT_PAYOUT_EURACC THEN
      UPDATE ICTM_ACC
         SET BOOK_ACC = P_ICDREDMN.AC_NO, BOOK_BRN = P_ICDREDMN.BRN_CODE
       WHERE BRN = P_ICDREDMN.BRN_CODE
         AND ACC = P_ICDREDMN.AC_NO;
    END IF;
    L_INT_PAYOUT_EURACC := FALSE;
  
    IF L_WHAT_TO_DO = 'M' THEN
      DBG('From E_Override_Exception of Fn_Main');
      P_OVERRIDE_FLAG := 'Y';
      RETURN TRUE;
    
    ELSIF L_WHAT_TO_DO = 'P' THEN
      DBG('SUCCESS');
    
      DBG('Going to insert into  iftw_td_detail');
    
      IF P_ACTION_CODE NOT IN ('TDRedemCreateRef',
                               'TDRedemSave',
                               'TDRedemDelete',
                               'TDRedemAuthQry',
                               'TDRedemCompute') THEN
        INSERT INTO IFTW_TD_DETAIL
          (BRN, ACC, AMT, CCY)
        VALUES
          (P_ICDREDMN.BRN_CODE,
           P_ICDREDMN.AC_NO,
           P_ICDREDMN.REDEMPTION_AMT,
           P_ICDREDMN.CCY);
        DBG('Insert done in iftw_td_detail..!');
      
        DBG('Going to update redem master wd next mat date for ref no -->' ||
            P_ICDREDMN.NEXT_MAT_DATE || '~' || P_ICDREDMN.REDEM_REF_NO);
        UPDATE ICTB_TDREDEMPTION_MASTER
           SET NEXT_MAT_DATE = P_ICDREDMN.NEXT_MAT_DATE
         WHERE REDEM_REF_NO = P_ICDREDMN.REDEM_REF_NO;
        DBG('Updated!');
      
      END IF;
    
      RETURN TRUE;
    
    ELSIF L_WHAT_TO_DO = 'R' THEN
      DBG('From E_Failure_Exception of Fn_Main');
    
      RETURN FALSE;
    
    END IF;
  
    DBG('p_Action_Code hereee:: ' || P_ACTION_CODE);
    DBG('p_Icdredmn.Xref :: ' || P_ICDREDMN.XREF);
    IF P_ACTION_CODE IN ('EnrichTDRedemption', 'TDRedemption') THEN
      IF NOT FN_RECALC(P_ICDREDMN,
                       P_ICDREDMN.XREF,
                       P_TY_PAYOUTDETS,
                       P_ERR_CODE,
                       P_ERR_PARAMS) THEN
        DBG('Failed in fn_recalc...' || SQLCODE || SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    ICPKS_FCJ_ICDREDMN.G_FROMREDM := FALSE;
    RETURN TRUE;
  EXCEPTION
  
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of icpks_fcj_icdredmn.Fn_Main ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MAIN;

  FUNCTION FN_SCAN_ERROR_LIST(P_FINAL_ERROR_TYPE OUT CHAR,
                              P_ERROR_CODE       IN OUT VARCHAR2,
                              P_ERROR_PARAMETER  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_HALT_ON_EXCEPTION EXCEPTION;
  
    L_ERROR_CODE      VARCHAR2(1000) := NULL;
    L_ERROR_PARAMETER VARCHAR2(1000) := NULL;
    L_ERROR_CODE_TYPE ERTBS_MSGS.TYPE%TYPE;
  
  BEGIN
  
    P_FINAL_ERROR_TYPE := NULL;
  
    IF (OVPKSS.GL_TBLERROR.COUNT = 0) THEN
      RETURN TRUE;
    END IF;
  
    FOR OVERRIDE_COUNT IN OVPKSS.GL_TBLERROR.FIRST .. OVPKSS.GL_TBLERROR.LAST LOOP
      L_ERROR_CODE      := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).ERR_CODE;
      L_ERROR_PARAMETER := OVPKSS.GL_TBLERROR(OVERRIDE_COUNT).PARAMS;
      L_ERROR_CODE_TYPE := OVPKSS.FN_GETTYPE(L_ERROR_CODE);
      DBG('l_error_code -> ' || L_ERROR_CODE);
      DBG('l_error_parameter -> ' || L_ERROR_PARAMETER);
      DBG('error code type -> ' || L_ERROR_CODE_TYPE);
    
      IF (L_ERROR_CODE_TYPE = 'X') THEN
        RETURN FALSE;
      END IF;
    
      IF (L_ERROR_CODE_TYPE IN ('O', 'A', 'D')) THEN
      
        P_FINAL_ERROR_TYPE := 'O';
      
      ELSIF (L_ERROR_CODE_TYPE = 'E') THEN
      
        RAISE L_HALT_ON_EXCEPTION;
      
      END IF;
    
    END LOOP;
  
    RETURN TRUE;
  
  EXCEPTION
  
    WHEN L_HALT_ON_EXCEPTION THEN
      P_FINAL_ERROR_TYPE := 'E';
    
      RETURN TRUE;
    
    WHEN OTHERS THEN
      P_ERROR_CODE := 'CS-UP0207';
      DEBUG.PR_DEBUG('IC', SQLCODE || SQLERRM);
      RETURN FALSE;
    
  END FN_SCAN_ERROR_LIST;

  FUNCTION FN_REDBY_TD(P_SOURCE        IN VARCHAR2,
                       P_WRK_ICDREDMN  IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_TY_STDCUSAC   IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                       P_REDM_MODE     IN VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE  VARCHAR2(100);
    L_ERR_PARAM VARCHAR2(100);
    L_REF_NO    DETB_RTL_TELLER.TRN_REF_NO%TYPE;
  
    L_OFFSET_DETAILS   VARCHAR2(10000);
    L_MCK_TSLIST       VARCHAR2(32767);
    P_ERR_CODE         VARCHAR2(500);
    P_ERR_PARAMS       VARCHAR2(500);
    L_PRM_PRODUCT_CODE ISTMS_INSTR_PROD.PROD%TYPE;
  
    L_TY_STDCUSTD STPKS_STDCUSTD_MAIN.TY_STDCUSTD;
  BEGIN
    DBG('Defaulting the payin details of Child TD from the parent');
    ICPKS_BOD.G_CHILDTD := TRUE;
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).BRN := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).CCY := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).SEQNO := 1;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).MULTIMODE_PAYOPT := 'S';
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).MULTIMODE_TDAMOUNT := TO_NUMBER(P_TY_PAYOUTDETS.REDMAMT);
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).MULTIMODE_OFFSET_BRN := P_WRK_ICDREDMN.BRN_CODE;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).MULTIMODE_TDOFFSET_ACC := P_WRK_ICDREDMN.AC_NO;
  
    P_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(1).MULTIMODE_TDOFFSET_CCY := P_WRK_ICDREDMN.CCY;
  
    P_TY_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT := TO_NUMBER(P_TY_PAYOUTDETS.REDMAMT);
  
    IF P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NULL OR
       P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO = P_WRK_ICDREDMN.AC_NO THEN
      IF NOT FN_TDACCGEN('STDCUSAC', P_TY_STDCUSAC) THEN
        DBG('Failed in generating Account number;');
        RETURN FALSE;
      ELSE
        DBG('Generated New TD Account number is ===> ' ||
            P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        DBG('Account number Exist in Type Variable > ' ||
            P_TY_STDCUSAC.V_ICTMS_ACC.ACC);
      
        P_TY_STDCUSAC.V_ICTMS_ACC.ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      
        DBG('p_ty_stdcusac.v_ictms_acc.rollover_type ' ||
            P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
        P_TY_STDCUSAC.V_ICTMS_ACC.CALC_ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_TY_STDCUSAC.V_ICTMS_ACC.BOOK_ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        IF P_TY_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'I' THEN
          P_TY_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        END IF;
      
        IF P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
          FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
            DBG('Old Account number in Acc Pr : ' || I || ': ' || P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC);
            P_TY_STDCUSAC.V_ICTMS_ACC_PR(I).ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END LOOP;
        END IF;
      
        IF P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
          FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
            DBG('Old Account number in Acc EffDt : ' || I || ': ' || P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC);
            P_TY_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END LOOP;
        END IF;
      
        IF P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
          FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT LOOP
            DBG('Old Account number in Acc Udevals : ' || I || ': ' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC);
            P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END LOOP;
        END IF;
      
        IF P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
          FOR I IN 1 .. P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT LOOP
            DBG('Old Account number in CHILD TD PAYOUT DETAILS : ' || I || ': ' || P_TY_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).ACC);
            P_TY_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END LOOP;
        END IF;
      
        DBG('Old Child PC payout Acc : ' ||
            P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC);
        P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        DBG('Old Child BC payout Acc : ' ||
            P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC);
        P_TY_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        DBG('Successfully assigned all the Acc with TD New Account number...');
      END IF;
    END IF;
  
    P_TY_STDCUSAC.V_ICTMS_TD_DETAILS.ACC := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_TY_STDCUSAC.V_ICTMS_TD_DETAILS.BRN := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_TY_STDCUSAC.V_ICTMS_TD_DETAILS.CCY := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
  
    IF P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC IS NULL THEN
    
      P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC := 'TD Payout for ' ||
                                                    P_WRK_ICDREDMN.AC_NO;
    
    END IF;
    DBG('Account Description  ' ||
        P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);
  
    IF NOT STPKS_STDCUSAC_UTILS_0.FN_DEFAULT_CUSTACC('ICDREDMN',
                                                     P_TY_STDCUSAC,
                                                     P_SOURCE,
                                                     GLOBAL.USER_ID) THEN
      DBG('stpks_stdcusac_utils_0.fn_unpicked_subsys has returned false');
    
      RETURN FALSE;
    END IF;
  
    DBG('calling fn_upload_td ');
    IF NOT GWPKS_TDACCCREATE.FN_UPLOAD_TD(P_SOURCE,
                                          P_TY_STDCUSAC,
                                          L_TY_STDCUSTD,
                                          L_ERR_CODE,
                                          L_ERR_PARAM) THEN
      DBG('fn_upload_td  failed');
      OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
      RETURN FALSE;
    END IF;
  
    IF P_REDM_MODE = 'N' THEN
      DBG('Full redemption so going to close the TD');
      BEGIN
        SELECT LINKED_RT_PRODUCT
          INTO L_PRM_PRODUCT_CODE
          FROM STTMS_CUSTAC_CLOSE_MODE
         WHERE CLOSE_MODE = 'FT'
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A'
              
           AND DRCR_IND = 'D';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        
          OVPKSS.PR_APPENDTBL('ST-ACC-357', '');
          RETURN FALSE;
      END;
    
      L_OFFSET_DETAILS := P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' ||
                          P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                          P_WRK_ICDREDMN.CCY || '~' ||
                          P_TY_PAYOUTDETS.REDMAMT || '~' ||
                          P_TY_PAYOUTDETS.XRATE || '~';
    
      DBG('l_offset_details' || L_OFFSET_DETAILS);
      L_MCK_TSLIST := NULL;
    
      DBG('Going to call icpkss_bod.fn_close_td');
      IF NOT ICPKSS_BOD.FN_CLOSE_TD(P_WRK_ICDREDMN.XREF,
                                    P_WRK_ICDREDMN.CCY,
                                    P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                    P_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                    P_TY_PAYOUTDETS.OFFSET_CCY
                                    
                                   ,
                                    P_TY_PAYOUTDETS.REDMAMT,
                                    P_TY_PAYOUTDETS.XRATE,
                                    L_PRM_PRODUCT_CODE,
                                    P_WRK_ICDREDMN.BRN_CODE,
                                    P_WRK_ICDREDMN.AC_NO,
                                    P_WRK_ICDREDMN.WAVE_PENALTY,
                                    P_WRK_ICDREDMN.WAIVE_INTEREST,
                                    L_OFFSET_DETAILS,
                                    L_MCK_TSLIST,
                                    'FT',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Failed to Close the Term Deposit while processing Savings Details');
        DBG('p_err_code :: ' || P_ERR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-07', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    BEGIN
      SELECT REFERENCE_NO
        INTO L_REF_NO
        FROM ICTM_TDPAYIN_DETAILS
       WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
         AND ACC = P_WRK_ICDREDMN.AC_NO
         AND CCY = P_WRK_ICDREDMN.CCY;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No trn_ref_no generated');
      WHEN OTHERS THEN
        DBG('Real exception..');
    END;
    DBG('trn_ref_no generated for TD :' || L_REF_NO);
  
    UPDATE ICTM_TDREDMPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND SEQNO = P_TY_PAYOUTDETS.SEQNO
       AND REDEM_REF_NO = P_WRK_ICDREDMN.REDEM_REF_NO;
  
    DBG('Rows updated for payout for TD :' || SQL%ROWCOUNT);
    ICPKS_BOD.G_CHILDTD := FALSE;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_REDBY_TD;

  FUNCTION FN_REDBY_PC(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_PCPAYOUTDETS_REC IN OUT ICTM_PCPAYOUT_DETAILS%ROWTYPE,
                       P_REDM_MODE        IN VARCHAR2)
  
   RETURN BOOLEAN IS
  
    L_KEY      VARCHAR2(4000);
    L_ERR_CODE VARCHAR2(1000);
    L_ERR_MSG  VARCHAR2(1000);
  
    L_IC_FLAG VARCHAR2(255);
    L_STATUS  VARCHAR2(16);
    L_FLAG    VARCHAR2(5);
  
    L_EXCEPTION_QUEUE PCTB_CONTRACT_MASTER.EXCEPTION_QUEUE%TYPE;
    L_REDM_AMT        ICTM_TDREDMPAYOUT_DETAILS.REDMAMT%TYPE;
  BEGIN
  
    DBG('Inside fn_redby_pc ...');
  
    L_KEY := 'CLEARING_BRN~TXN_CCY~CUST_BANK~CATEGORY~SOURCE~STATION~THEIR_REF_NO~BRANCH_OF_INPUT~CUST_BRANCH~';
    L_KEY := L_KEY ||
             'CUST_AC~CPTY_BANK~CPTY_AC~CPTY_AC_PREFIX~CPTY_NAME~AMOUNT~SOURCE_REF~';
    L_KEY := L_KEY || 'CUST_AC_CCY~CUST_NO~';
    L_KEY := L_KEY ||
             'INTERFACE_REF~INIT_DT~ACTIVATION_DT~CUST_AC_LCF~DISP_FILE_NAME~CONSOL~AGREEMENT_ID~';
    L_KEY := L_KEY ||
             'CUST__ENTRY_DT~CUST_ENTRY_VAL_DT~CPTY_ENTRY_DT~CPTY_ENTRY_VAL_DT~';
    L_KEY := L_KEY ||
             'UDF1~UDF2~UDF3~UDF4~UDF5~UDF6~UDF7~UDF8~UDF9~UDF10~UDF11~UDF12~UDF13~UDF14~UDF15~';
    L_KEY := L_KEY ||
             'UDF16~UDF17~UDF18~UDF19~UDF20~UDF21~UDF22~UDF23~UDF24~UDF25~UDF26~UDF27~UDF28~UDF29~UDF30~';
  
    DBG('l_key is  ' || L_KEY);
  
    IF P_REDM_MODE = 'N' THEN
      ACPKS.G_CONVENTIONAL_ACCNTG := TRUE;
    END IF;
  
    IF P_REDM_MODE = 'N' AND PKG_RATE_CHART = 'Y' THEN
      DBG('goin for pc full redemption adjustment entries ');
      STPKS_TD_REDEMPTION.PR_BROKEN_TD(P_WRK_ICDREDMN.BRN_CODE,
                                       P_WRK_ICDREDMN.AC_NO,
                                       L_ERR_CODE,
                                       L_ERR_MSG);
      DBG(' l_err_code ' || L_ERR_CODE);
      DBG(' l_err_msg ' || L_ERR_MSG);
    END IF;
  
    DBG('pkg_rate_chart' || PKG_RATE_CHART);
    IF P_REDM_MODE = 'N' AND PKG_RATE_CHART = 'N' THEN
    
      ICPKS_ONLIQ_NEW.PR_CALL_ICONLIQ(P_WRK_ICDREDMN.BRN_CODE,
                                      'S',
                                      P_WRK_ICDREDMN.AC_NO,
                                      'ALL',
                                      GLOBAL.APPLICATION_DATE - 1);
      DBG('After calling icpks_onliq_new.pr_call_iconliq');
      DBG('After IC online liq');
    END IF;
    DBG('TXN AMOUNT FOR PC SAVE: ' || P_TY_PAYOUTDETS.REDMAMT);
  
    IF P_REDM_MODE = 'N' THEN
      DBG('GET BALANCE FOR ACCOUNT ' || P_WRK_ICDREDMN.BRN_CODE || ' AND ' ||
          P_WRK_ICDREDMN.AC_NO);
    
      IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_WRK_ICDREDMN.BRN_CODE,
                                                  P_WRK_ICDREDMN.AC_NO,
                                                  'Y',
                                                  G_BALREC) THEN
        DEBUG.PR_DEBUG('AC',
                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                       SQLERRM);
      END IF;
      L_REDM_AMT := NVL(G_BALREC.ACY_CURR_ACC_BAL, 0);
    
    ELSE
      L_REDM_AMT := P_TY_PAYOUTDETS.REDMAMT;
    END IF;
    DBG('l_redm_amt::: ' || L_REDM_AMT);
  
    IF NOT ICPKS_BOD.FN_PAYMENT_TXN(P_WRK_ICDREDMN.XREF,
                                    P_WRK_ICDREDMN.BRN_CODE,
                                    P_WRK_ICDREDMN.AC_NO,
                                    P_WRK_ICDREDMN.CCY,
                                    P_WRK_ICDREDMN.TRN_DT,
                                    
                                    L_REDM_AMT,
                                    L_KEY,
                                    P_PCPAYOUTDETS_REC,
                                    L_ERR_CODE,
                                    L_ERR_MSG) THEN
    
      DBG('Failed while  PC txn in fn_payment_txn');
      OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_MSG);
      RETURN FALSE;
    END IF;
  
    IF P_REDM_MODE = 'N' THEN
      ACPKS.G_CONVENTIONAL_ACCNTG := FALSE;
    END IF;
  
    BEGIN
      SELECT EXCEPTION_QUEUE
        INTO L_EXCEPTION_QUEUE
        FROM PCTB_CONTRACT_MASTER
       WHERE SOURCE_REF = P_PCPAYOUTDETS_REC.REFNO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Inside WOT, while selecting the exception_queue for the PC contract.');
        L_EXCEPTION_QUEUE := '**';
    END;
    DBG('Redemption mode is coming as ' || P_REDM_MODE);
    DBG('exception_queue is coming as ' || L_EXCEPTION_QUEUE);
  
    IF P_REDM_MODE = 'N' THEN
      DBG('Full redemption, so closing the TD ');
      IF NOT FN_PC_CLOSE_TD(P_WRK_ICDREDMN.BRN_CODE,
                            P_WRK_ICDREDMN.AC_NO,
                            L_ERR_CODE,
                            L_ERR_MSG) THEN
        DBG('Failed to Close to the Term Deposit while processing Bank Details');
        DBG('l_err_code :: ' || L_ERR_CODE);
        OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_MSG);
        OVPKSS.PR_APPENDTBL('TD-RED-32', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_redby_pc ..');
      DBG(SQLERRM);
      L_ERR_CODE := 'ST-OTHR-001';
      RETURN FALSE;
  END FN_REDBY_PC;

  FUNCTION FN_REDBY_BC(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       P_BCPAYOUTDETS_REC IN OUT ICTM_BCPAYOUT_DETAILS%ROWTYPE,
                       L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                       P_REDM_MODE        IN VARCHAR2)
  
   RETURN BOOLEAN IS
    PRECTYPE         VARCHAR2(500);
    PTS              VARCHAR2(32767);
    PDTF             VARCHAR2(50);
    PPROC            VARCHAR2(1);
    PIDENTIFIER      VARCHAR2(32767);
    PFLAG            NUMBER;
    PERR             VARCHAR2(10000);
    PPRMS            VARCHAR2(32767);
    P_DATE           DATE;
    P_FLAG           NUMBER;
    L_OFFSET_DETAILS VARCHAR2(10000);
    L_MCK_TSLIST     VARCHAR2(32767);
    P_ERR_CODE       VARCHAR2(500);
    P_ERR_PARAMS     VARCHAR2(500);
    L_REF_NO         ISTMS_INSTR_TXN.CONTRACT_REF_NO%TYPE;
    L_PRM_CUST_NO    STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_SERIAL_NO      VARCHAR2(16);
    L_PRM_INST_NO    VARCHAR2(500);
    P_SOURCE         COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_SOURCE         COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_INSTR_PROD     VARCHAR2(3);
    L_WAIVE_CHG      VARCHAR2(1);
    L_INST_NO        ISTMS_INSTR_TXN.INSTR_NO%TYPE;
  
    L_ALW_INV_TRACK VARCHAR2(1);
    L_STOCK_CODE    VARCHAR2(10);
    L_INSTR_TYPE    ISTM_INSTR_TXN.INSTR_TYPE%TYPE;
  
  BEGIN
  
    DBG('>> DD/BC refno: ' || P_TY_PAYOUTDETS.REF_NO);
    IF GWPKS_UTIL.G_FROM_BEAN AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH', 'ENRICH') THEN
      IF P_TY_PAYOUTDETS.REF_NO IS NOT NULL THEN
        DEPKS_RTL_TELLER.G_TRN_REF_NO := P_TY_PAYOUTDETS.REF_NO;
      
        DBG('>>> now the real pic starts...charging multimode trns now for DD n BC...');
        DEPKSS_RTL_TELLER.PR_CHG_PICKUP_REQD(TRUE);
        DBG('Uploading payout multimode chg-details');
        IF NOT FN_DEFAULT_PAYOUT_CHGDETS(GWPKS_TDREDEMPTION.G_PAYOUT_CHGDTLS,
                                         P_TY_PAYOUTDETS.REF_NO) THEN
          DBG('Falied in Fn_Default_Payout_Chgdets');
          RETURN FALSE;
        END IF;
      
      END IF;
    END IF;
  
    DBG('Going to call pr_gen_inst_no');
  
    IF GWPKS_UTIL.G_FROM_BEAN THEN
      L_SOURCE := 'FCRH';
    ELSE
      L_SOURCE := 'TDRE';
    END IF;
  
    IF P_TY_PAYOUTDETS.PAYOUTTYPE = 'B' THEN
      L_INSTR_PROD := 'BCA';
    ELSE
      L_INSTR_PROD := 'DDA';
    END IF;
  
    DBG('p_ty_payoutdets.INSTNO::' || P_TY_PAYOUTDETS.INSTNO);
    DBG('p_ty_payoutdets.WAIVE_ISSUE_CHG::' ||
        P_TY_PAYOUTDETS.WAIVE_ISSUE_CHG);
    L_PRM_INST_NO := P_TY_PAYOUTDETS.INSTNO;
    L_WAIVE_CHG   := P_TY_PAYOUTDETS.WAIVE_ISSUE_CHG;
    DBG('l_prm_inst_no::' || L_PRM_INST_NO);
    DBG('l_waive_chg::' || L_WAIVE_CHG);
  
    DBG('After calling pr_gen_inst_no' || P_BCPAYOUTDETS_REC.BANKCODE);
  
    P_DATE := NVL(P_WRK_ICDREDMN.TRN_DT, GLOBAL.APPLICATION_DATE);
  
    DBG('Going to select from cust no from sttms_cust_account');
    SELECT CUST_NO
      INTO L_PRM_CUST_NO
      FROM STTMS_CUST_ACCOUNT
     WHERE BRANCH_CODE = P_WRK_ICDREDMN.BRN_CODE
       AND CUST_AC_NO = P_WRK_ICDREDMN.AC_NO;
  
    IF P_REDM_MODE = 'N' THEN
    
      DBG('Redemption mode is full redemption');
      P_FLAG           := 0;
      L_OFFSET_DETAILS := NULL || '~' || NULL || '~' ||
                          P_BCPAYOUTDETS_REC.CHQ_CCY || '~' ||
                          P_BCPAYOUTDETS_REC.CHQ_AMT || '~' ||
                          P_BCPAYOUTDETS_REC.XRATE || '~';
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
        DBG('in if ');
      
        L_MCK_TSLIST := L_SOURCE || '~' || P_WRK_ICDREDMN.XREF || '~' ||
                        GLOBAL.CURRENT_BRANCH;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_INSTR_PROD || '~INIT~~~~' ||
                        TO_CHAR(P_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.BRN_CODE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.CCY;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.AC_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~D~' ||
                        TO_CHAR(P_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_PRM_INST_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BANKCODE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_CCY;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~~~~' ||
                        TO_CHAR(P_BCPAYOUTDETS_REC.CHQ_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_PRM_CUST_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~' ||
                        P_BCPAYOUTDETS_REC.NARRATIVE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~' || GLOBAL.CURRENT_BRANCH;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_WAIVE_CHG;
        L_MCK_TSLIST := L_MCK_TSLIST || '~>~' || P_BCPAYOUTDETS_REC.PAYBRN;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.MICR_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~INIT~~' ||
                        P_BCPAYOUTDETS_REC.BENFNAME;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD1;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD2;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD3;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || '~~~~~~~~~~~~~~~';
      
        DBG('l_waive_chg::' || L_WAIVE_CHG);
        DBG('l_mck_tslist::' || L_MCK_TSLIST);
      
      ELSE
        DBG('in Elseee');
        L_MCK_TSLIST := L_SOURCE || '~~' || GLOBAL.CURRENT_BRANCH;
      
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_INSTR_PROD || '~INIT~~~~' ||
                       
                        TO_CHAR(P_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.BRN_CODE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.CCY;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_WRK_ICDREDMN.AC_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~D~' ||
                        TO_CHAR(P_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_PRM_INST_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BANKCODE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_CCY;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~~~~' ||
                        TO_CHAR(P_WRK_ICDREDMN.CHQ_DATE, 'RRRRMMDD');
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_PRM_CUST_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~' ||
                        P_BCPAYOUTDETS_REC.NARRATIVE;
        L_MCK_TSLIST := L_MCK_TSLIST || '~~' || GLOBAL.CURRENT_BRANCH;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || L_WAIVE_CHG;
        L_MCK_TSLIST := L_MCK_TSLIST || '~>~' || P_BCPAYOUTDETS_REC.PAYBRN;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.MICR_NO;
        L_MCK_TSLIST := L_MCK_TSLIST || '~INIT~~' ||
                        P_BCPAYOUTDETS_REC.BENFNAME;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD1;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD2;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || P_BCPAYOUTDETS_REC.BENFADD3;
        L_MCK_TSLIST := L_MCK_TSLIST || '~' || '~~~~~~~~~~~~~~~';
      
      END IF;
    
      DBG('Assigned to l_mck_tslist::' || L_MCK_TSLIST);
    
      DBG('Going to call icpkss_bod.fn_close_td');
      IF NOT ICPKSS_BOD.FN_CLOSE_TD(P_WRK_ICDREDMN.XREF,
                                    P_WRK_ICDREDMN.CCY,
                                    NULL,
                                    NULL,
                                    P_BCPAYOUTDETS_REC.CHQ_CCY,
                                    P_BCPAYOUTDETS_REC.CHQ_AMT,
                                    P_BCPAYOUTDETS_REC.XRATE,
                                    L_PRM_PRODUCT_CODE,
                                    P_WRK_ICDREDMN.BRN_CODE,
                                    P_WRK_ICDREDMN.AC_NO,
                                    P_WRK_ICDREDMN.WAVE_PENALTY,
                                    P_WRK_ICDREDMN.WAIVE_INTEREST,
                                    L_OFFSET_DETAILS,
                                    L_MCK_TSLIST,
                                    
                                    L_INSTR_PROD
                                    
                                   ,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Failed to Close to the Term Deposit while processing Bank Details');
        DBG('p_err_code :: ' || P_ERR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-04', NULL);
        RETURN FALSE;
      END IF;
    
      L_REF_NO := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
      DBG('l_ref_no:' || L_REF_NO);
    
      DBG('p_redm_mode::' || P_REDM_MODE);
    ELSIF P_REDM_MODE = 'Y' THEN
    
      PRECTYPE := 'UPLOAD_INSTRTXN>MCKDETS';
    
      PTS := L_SOURCE || '~' || P_WRK_ICDREDMN.XREF || '~' ||
             GLOBAL.CURRENT_BRANCH;
    
      PTS := PTS || '~' || L_INSTR_PROD || '~INIT~~~~' ||
            
             TO_CHAR(P_DATE, 'RRRRMMDD');
      PTS := PTS || '~' || P_WRK_ICDREDMN.BRN_CODE;
      PTS := PTS || '~' || P_WRK_ICDREDMN.CCY;
    
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
      PTS := PTS || '~' || P_WRK_ICDREDMN.AC_NO;
      PTS := PTS || '~D~' || TO_CHAR(P_DATE, 'RRRRMMDD');
      PTS := PTS || '~' || L_PRM_INST_NO;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.BANKCODE;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.CHQ_CCY;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.CHQ_AMT;
      PTS := PTS || '~~~~~' ||
             TO_CHAR(P_BCPAYOUTDETS_REC.CHQ_DATE, 'RRRRMMDD');
      PTS := PTS || '~' || L_PRM_CUST_NO;
      PTS := PTS || '~~' || P_BCPAYOUTDETS_REC.NARRATIVE;
      PTS := PTS || '~~' || GLOBAL.CURRENT_BRANCH;
      PTS := PTS || '~' || L_WAIVE_CHG;
    
      PTS := PTS || '~>~' || P_BCPAYOUTDETS_REC.PAYBRN;
    
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.MICR_NO;
      PTS := PTS || '~INIT~~' || P_BCPAYOUTDETS_REC.BENFNAME;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.BENFADD1;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.BENFADD2;
      PTS := PTS || '~' || P_BCPAYOUTDETS_REC.BENFADD3;
      PTS := PTS || '~' || '~~~~~~~~~~~~~~~';
    
      DBG('l_waive_chg::' || L_WAIVE_CHG);
      DBG('pts::' || PTS);
    
      PDTF  := 'RRRRMMDD';
      PPROC := 'Y';
      CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('Y');
      DBG('Going to call icpkss_bod.fn_instr_txn');
      IF NOT ICPKSS_BOD.FN_INSTR_TXN(PRECTYPE,
                                     PTS,
                                     PDTF,
                                     PPROC,
                                     PIDENTIFIER,
                                     PFLAG,
                                     PERR,
                                     PPRMS) THEN
        DBG('Failed to process Instruments while processing Bank Details');
        OVPKSS.PR_APPENDTBL('TD-RED-02', NULL);
        RETURN FALSE;
      END IF;
    
      L_REF_NO := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
    
      DBG('p_wrk_icdredmn.xref :' || P_WRK_ICDREDMN.XREF);
      IF P_WRK_ICDREDMN.XREF IS NULL THEN
        P_WRK_ICDREDMN.XREF := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
      END IF;
      P_WRK_ICDREDMN.FCCREF := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
    
      DBG('Going to Select contract reference number from istms_instr_txn');
    
      DBG('l_ref_no fetched :: ' || L_REF_NO);
    
      DBG('Going to call ispkss_instruments.fn_save');
      IF NOT
          ISPKSS_INSTRUMENTS.FN_SAVE('A', L_REF_NO, 1, 'INIT', PERR, PPRMS) THEN
        DBG('Failed to save Instruments while processing Bank Details');
        OVPKSS.PR_APPENDTBL('TD-RED-03', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    BEGIN
      SELECT INSTR_NO
        INTO L_INST_NO
        FROM ISTMS_INSTR_TXN
       WHERE CONTRACT_REF_NO = L_REF_NO;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in updating inst number');
    END;
  
    DBG('instrument number' || L_INST_NO);
    DBG('contract reference' || L_REF_NO);
  
    DBG('Calling Fn_Get_Bank_Rec_Wrp...');
    IF GLOBALS_FRC.FN_GET_BANK_REC_WRP(PERR, PPRMS) THEN
      L_ALW_INV_TRACK := NVL(GLOBALS_FRC.G_TBL_STTM_BANK_REC.ALW_INV_TRACK,
                             'N');
      DBG('In Fn_Get_Bank_Rec_Wrp...' || L_ALW_INV_TRACK);
    ELSE
      DBG('no bank exists!!!');
      L_ALW_INV_TRACK := 'N';
      PERR            := NULL;
      PPRMS           := NULL;
    END IF;
    DBG('l_alw_inv_track-->' || L_ALW_INV_TRACK);
    IF L_ALW_INV_TRACK = 'Y' THEN
    
      DBG('l_instr_prod-->' || L_INSTR_PROD);
      L_INSTR_TYPE := CGPKS_UPLOAD_UTILS.FN_GET_UNIFIED_INSTR_TYPE(L_INSTR_PROD);
      DBG('l_instr_type-->' || L_INSTR_TYPE);
      IF NOT IVPKS_UTILS.FN_UPDATE_INSTRUMENT_STATUS(L_STOCK_CODE,
                                                     'ZERO',
                                                     L_INSTR_TYPE,
                                                     NULL,
                                                     P_BCPAYOUTDETS_REC.BANKCODE,
                                                     GLOBAL.CURRENT_BRANCH,
                                                     NULL,
                                                     NULL,
                                                     L_INST_NO,
                                                     L_INST_NO,
                                                     'I',
                                                     PERR,
                                                     PPRMS) THEN
        DBG('failed while updating the instrument status in iv tables');
        DBG(' l_err_code : ' || PERR || ' aft returning frm iv pack');
        OVPKS.PR_APPENDTBL(PERR, PPRMS);
        RETURN FALSE;
      END IF;
    END IF;
  
    UPDATE ICTM_BCPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND CCY = P_WRK_ICDREDMN.CCY;
  
    DBG('Rows updated for BC :' || SQL%ROWCOUNT);
  
    UPDATE ICTM_TDREDMPAYOUT_DETAILS
       SET REF_NO = L_REF_NO, INSTNO = L_INST_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND SEQNO = P_TY_PAYOUTDETS.SEQNO
       AND REDEM_REF_NO = P_WRK_ICDREDMN.REDEM_REF_NO;
    DBG('Rows updated for Payout Details :' || SQL%ROWCOUNT);
  
    IF P_WRK_ICDREDMN.FCCREF IS NULL THEN
      DBG('>> assigin refno to payout master: ' || L_REF_NO);
      P_WRK_ICDREDMN.FCCREF := NVL(L_REF_NO, DEPKS_RTL_TELLER.G_TRN_REF_NO);
    END IF;
    IF P_TY_PAYOUTDETS.REF_NO IS NULL THEN
      DBG('>> assigin refno to payout dtl: ' || L_REF_NO);
      P_TY_PAYOUTDETS.REF_NO := NVL(L_REF_NO, DEPKS_RTL_TELLER.G_TRN_REF_NO);
    END IF;
  
    IF P_TY_PAYOUTDETS.INSTNO IS NULL THEN
      DBG('>> assigin instno to payout dtl: ' || L_INST_NO);
      P_TY_PAYOUTDETS.INSTNO := L_INST_NO;
    END IF;
  
    DBG('Returning true from fn_redby_bc');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_redby_bc ..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_REDBY_BC;

  FUNCTION FN_REDBY_GL(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                       P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                       L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                       P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN
  
   IS
    L_OFFSET_DETAILS VARCHAR2(10000);
    L_MCK_TSLIST     VARCHAR2(32767);
    L_AMT_DRAWN      NUMBER;
    P_FLAG           NUMBER;
    P_ERR_CODE       VARCHAR2(500);
    P_ERR_PARAMS     VARCHAR2(500);
    P_SOURCE         COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_REF_NO         DETB_RTL_TELLER.TRN_REF_NO%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG('>> GL refno: ' || P_TY_PAYOUTDETS.REF_NO);
    IF GWPKS_UTIL.G_FROM_BEAN AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH', 'ENRICH') THEN
      IF P_TY_PAYOUTDETS.REF_NO IS NOT NULL THEN
        DEPKS_RTL_TELLER.G_TRN_REF_NO := P_TY_PAYOUTDETS.REF_NO;
      
        DBG('>>> now the real pic starts...charing multimode trns now for GL...');
        DEPKSS_RTL_TELLER.PR_CHG_PICKUP_REQD(TRUE);
        DBG('Uploading payout multimode chg-details');
        IF NOT FN_DEFAULT_PAYOUT_CHGDETS(GWPKS_TDREDEMPTION.G_PAYOUT_CHGDTLS,
                                         P_TY_PAYOUTDETS.REF_NO) THEN
          DBG('Falied in Fn_Default_Payout_Chgdets');
          RETURN FALSE;
        END IF;
      
      END IF;
    END IF;
  
    IF P_REDM_MODE = 'N' THEN
    
      DBG('If Rdemption mode is full');
      P_FLAG := 0;
    
      L_OFFSET_DETAILS := P_TY_PAYOUTDETS.OFFSET_ACC || '~' ||
                          P_TY_PAYOUTDETS.OFFSET_BRN || '~' ||
                          P_WRK_ICDREDMN.CCY || '~' ||
                          P_TY_PAYOUTDETS.REDMAMT || '~' ||
                          P_TY_PAYOUTDETS.XRATE || '~';
      L_MCK_TSLIST     := NULL;
    
      DBG('Going to call icpkss_bod.fn_close_td');
      DBG('TRN_DATE IS' || ICPKS_BOD.G_TRN_DT);
      DBG('pkg_close_mode: ' || PKG_CLOSE_MODE);
      IF NOT ICPKSS_BOD.FN_CLOSE_TD(P_WRK_ICDREDMN.XREF,
                                    P_WRK_ICDREDMN.CCY,
                                    P_TY_PAYOUTDETS.OFFSET_BRN,
                                    P_TY_PAYOUTDETS.OFFSET_ACC,
                                    P_WRK_ICDREDMN.CCY,
                                    P_TY_PAYOUTDETS.REDMAMT,
                                    P_TY_PAYOUTDETS.XRATE,
                                    L_PRM_PRODUCT_CODE,
                                    P_WRK_ICDREDMN.BRN_CODE,
                                    P_WRK_ICDREDMN.AC_NO,
                                    P_WRK_ICDREDMN.WAVE_PENALTY,
                                    P_WRK_ICDREDMN.WAIVE_INTEREST,
                                    L_OFFSET_DETAILS,
                                    L_MCK_TSLIST,
                                    
                                    NVL(PKG_CLOSE_MODE, 'FT')
                                    
                                   ,
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Failed to Close the Term Deposit while processing General Ledger Details');
        DBG('p_err_code :: ' || P_ERR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-05', NULL);
        RETURN FALSE;
      END IF;
    ELSIF P_REDM_MODE = 'Y' THEN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 1;
        DBG('Calling icpks_fcj_icdredmn_cluster.fn_redby_gl');
        IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_GL(P_WRK_ICDREDMN,
                                                      P_TY_PAYOUTDETS,
                                                      L_PRM_PRODUCT_CODE,
                                                      P_REDM_MODE,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('Failure has happened in icpks_fcj_icdredmn_cluster.fn_redby_gl');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('the redemption Mode is partial');
    
      DBG('Going to call icpkss_bod.fn_teller_txn ');
      IF NOT ICPKSS_BOD.FN_TELLER_TXN(P_WRK_ICDREDMN.BRN_CODE,
                                      L_PRM_PRODUCT_CODE,
                                      P_WRK_ICDREDMN.XREF,
                                      P_WRK_ICDREDMN.AC_NO,
                                      P_WRK_ICDREDMN.CCY,
                                      
                                      P_TY_PAYOUTDETS.REDMAMT,
                                      P_TY_PAYOUTDETS.OFFSET_BRN,
                                      P_TY_PAYOUTDETS.OFFSET_ACC,
                                      P_WRK_ICDREDMN.CCY,
                                      P_TY_PAYOUTDETS.REDMAMT,
                                      NULL,
                                      P_TY_PAYOUTDETS.XRATE,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DBG('Failed to do Partial Redemption while processing General Ledger Details');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-06', NULL);
        RETURN FALSE;
      END IF;
    END IF;
    L_REF_NO := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
  
    UPDATE ICTM_BCPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND CCY = P_WRK_ICDREDMN.CCY;
  
    DBG('Rows updated for GL :' || SQL%ROWCOUNT);
  
    UPDATE ICTM_TDREDMPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND SEQNO = P_TY_PAYOUTDETS.SEQNO
       AND REDEM_REF_NO = P_WRK_ICDREDMN.REDEM_REF_NO;
    DBG('Rows updated for Payout Details :' || SQL%ROWCOUNT);
  
    IF P_WRK_ICDREDMN.FCCREF IS NULL THEN
      DBG('>> assigin refno to payout master: ' || L_REF_NO);
      P_WRK_ICDREDMN.FCCREF := L_REF_NO;
    END IF;
    IF P_TY_PAYOUTDETS.REF_NO IS NULL THEN
      DBG('>> assigin refno to payout dtl: ' || L_REF_NO);
      P_TY_PAYOUTDETS.REF_NO := L_REF_NO;
    END IF;
  
    DBG('Returning true from fn_redby_gl');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_redby_gl ..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_REDBY_GL;

  FUNCTION FN_REDBY_CASH(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                         P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                         L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                         P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN
  
   IS
    L_OFFSET_DETAILS VARCHAR2(10000);
    L_MCK_TSLIST     VARCHAR2(32767);
    L_AMT_DRAWN      NUMBER;
    P_FLAG           NUMBER;
    P_ERR_CODE       VARCHAR2(500);
    P_ERR_PARAMS     VARCHAR2(500);
    L_SOURCE         COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_REF_NO         DETB_RTL_TELLER.TRN_REF_NO%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_OFFSET_CCY VARCHAR2(10000);
    L_OUT_AMT    NUMBER;
  
  BEGIN
  
    DBG('>> cash refno: ' || P_TY_PAYOUTDETS.REF_NO);
    IF GWPKS_UTIL.G_FROM_BEAN AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH', 'ENRICH') THEN
      IF P_TY_PAYOUTDETS.REF_NO IS NOT NULL THEN
      
        DEPKS_RTL_TELLER.G_TRN_REF_NO := P_TY_PAYOUTDETS.REF_NO;
      
        DBG('>>> now the real pic starts...charing multimode trns now for Cash...');
        DEPKSS_RTL_TELLER.PR_CHG_PICKUP_REQD(TRUE);
        DBG('Uploading payout multimode chg-details');
        IF NOT FN_DEFAULT_PAYOUT_CHGDETS(GWPKS_TDREDEMPTION.G_PAYOUT_CHGDTLS,
                                         P_TY_PAYOUTDETS.REF_NO) THEN
          DBG('Falied in Fn_Default_Payout_Chgdets');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    IF P_REDM_MODE = 'N' THEN
    
      DBG('If Rdemption mode is full');
      P_FLAG := 0;
    
      L_OFFSET_DETAILS := P_TY_PAYOUTDETS.OFFSET_ACC || '~' ||
                          P_TY_PAYOUTDETS.OFFSET_BRN || '~' ||
                          P_WRK_ICDREDMN.CCY || '~' ||
                          P_TY_PAYOUTDETS.REDMAMT || '~' ||
                          P_TY_PAYOUTDETS.XRATE || '~';
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID := 2;
        L_TB_CLUSTER_DATA('l_offset_details') := L_OFFSET_DETAILS;
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_CASH(P_WRK_ICDREDMN,
                                                     P_TY_PAYOUTDETS,
                                                     L_PRM_PRODUCT_CODE,
                                                     P_REDM_MODE,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA) THEN
          DBG('Failed while calling fn_redby_CASH in cluster package' ||
              SQLERRM);
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          RETURN FALSE;
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_offset_details') THEN
          L_OFFSET_DETAILS := L_TB_CLUSTER_DATA('l_offset_details');
        END IF;
      END IF;
    
      L_MCK_TSLIST := NULL;
      DBG('Going to call cspks_acc_service.pr_close_out_withdrawal');
      CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('Y');
    
      IF GWPKS_UTIL.G_FROM_BEAN THEN
        L_SOURCE := 'FCRH';
      ELSE
        L_SOURCE := 'TDRE';
      END IF;
      CSPKS_ACC_SERVICE.PR_CLOSE_OUT_WITHDRAWAL(L_SOURCE,
                                                P_WRK_ICDREDMN.XREF,
                                                L_PRM_PRODUCT_CODE,
                                                P_WRK_ICDREDMN.BRN_CODE,
                                                P_WRK_ICDREDMN.AC_NO,
                                                'CASH',
                                                GLOBAL.APPLICATION_DATE,
                                                L_OFFSET_DETAILS,
                                                L_MCK_TSLIST,
                                                P_FLAG,
                                                P_ERR_CODE,
                                                P_ERR_PARAMS,
                                                TRUE,
                                                L_AMT_DRAWN);
    
      IF P_FLAG <> 0 THEN
        DBG('cspkss_acc_service.pr_close_out_withdrawal returned false in fn_close_td with-' ||
            P_ERR_CODE);
        ICPKS_BOD.G_FROM_TD := FALSE;
      
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    
    ELSIF P_REDM_MODE = 'Y' THEN
    
      DBG('the redemption Mode is partial');
    
      DBG('Going to call icpkss_bod.fn_teller_txn ');
      DBG('TRN_DATE IS' || ICPKS_BOD.G_TRN_DT);
    
      L_OFFSET_CCY := P_WRK_ICDREDMN.CCY;
      L_OUT_AMT    := P_TY_PAYOUTDETS.REDMAMT;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID      := 3;
      
        L_TB_CLUSTER_DATA('l_offset_ccy') := L_OFFSET_CCY;
        L_TB_CLUSTER_DATA('l_out_amt') := L_OUT_AMT;
      
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_CASH(P_WRK_ICDREDMN,
                                                     P_TY_PAYOUTDETS,
                                                     L_PRM_PRODUCT_CODE,
                                                     P_REDM_MODE,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA) THEN
          DBG('Failed while calling fn_redby_CASH in cluster package' ||
              SQLERRM);
          RETURN FALSE;
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_offset_ccy') THEN
          L_OFFSET_CCY := L_TB_CLUSTER_DATA('l_offset_ccy');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_out_amt') THEN
          L_OUT_AMT := L_TB_CLUSTER_DATA('l_out_amt');
        END IF;
      
      END IF;
    
      IF NOT ICPKSS_BOD.FN_TELLER_TXN(P_WRK_ICDREDMN.BRN_CODE,
                                      L_PRM_PRODUCT_CODE,
                                      P_WRK_ICDREDMN.XREF,
                                      P_WRK_ICDREDMN.AC_NO,
                                      P_WRK_ICDREDMN.CCY,
                                      
                                      P_TY_PAYOUTDETS.REDMAMT,
                                      P_TY_PAYOUTDETS.OFFSET_BRN,
                                      P_TY_PAYOUTDETS.OFFSET_ACC,
                                      L_OFFSET_CCY,
                                      L_OUT_AMT,
                                      NULL,
                                      P_TY_PAYOUTDETS.XRATE,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DBG('Failed to do Partial Redemption while processing General Ledger Details');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-11', NULL);
        RETURN FALSE;
      END IF;
    END IF;
    L_REF_NO := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
    UPDATE ICTM_TDREDMPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND SEQNO = P_TY_PAYOUTDETS.SEQNO
       AND REDEM_REF_NO = P_WRK_ICDREDMN.REDEM_REF_NO;
    DBG('Rows updated for Payout Details :' || SQL%ROWCOUNT);
  
    IF P_WRK_ICDREDMN.FCCREF IS NULL THEN
      DBG('>> assigin refno to payout master: ' || L_REF_NO);
      P_WRK_ICDREDMN.FCCREF := L_REF_NO;
    END IF;
    IF P_TY_PAYOUTDETS.REF_NO IS NULL THEN
      DBG('>> assigin refno to payout dtl: ' || L_REF_NO);
      P_TY_PAYOUTDETS.REF_NO := L_REF_NO;
    END IF;
  
    IF NOT MIPKSS_REFERRAL.FN_GET_CON_DEFAULT(DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.BRANCH_CODE,
                                              L_REF_NO,
                                              NULL,
                                              NULL) THEN
      OVPKSS.PR_APPENDTBL('MI-DEF02', NULL);
      RETURN FALSE;
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_CASH(P_WRK_ICDREDMN,
                                                      P_TY_PAYOUTDETS,
                                                      L_PRM_PRODUCT_CODE,
                                                      P_REDM_MODE,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
        DBG('Failed while calling fn_redby_cash in cluster package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    DBG('Returning true from fn_redby_cash');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_redby_cash ..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_REDBY_CASH;

  FUNCTION FN_REDBY_SAVINGS(P_WRK_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                            P_TY_PAYOUTDETS    IN OUT ICTM_TDREDMPAYOUT_DETAILS%ROWTYPE,
                            L_PRM_PRODUCT_CODE IN OUT ISTMS_INSTR_PROD.PROD%TYPE,
                            P_REDM_MODE        IN VARCHAR2) RETURN BOOLEAN IS
    L_OFFSET_DETAILS VARCHAR2(10000);
    L_MCK_TSLIST     VARCHAR2(32767);
    L_AMT_DRAWN      NUMBER;
    P_FLAG           NUMBER;
    P_ERR_CODE       VARCHAR2(500);
    P_ERR_PARAMS     VARCHAR2(500);
    P_SOURCE         COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_REF_NO         DETB_RTL_TELLER.TRN_REF_NO%TYPE;
    L_OUT_AMT        NUMBER(22, 3);
    L_RATE           NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG('>> savings refno: ' || P_TY_PAYOUTDETS.REF_NO);
    IF GWPKS_UTIL.G_FROM_BEAN AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH', 'ENRICH') THEN
      IF P_TY_PAYOUTDETS.REF_NO IS NOT NULL THEN
        DEPKS_RTL_TELLER.G_TRN_REF_NO := P_TY_PAYOUTDETS.REF_NO;
      
        DBG('>>> now the real pic starts...charing multimode trns now for Savings...');
        DEPKSS_RTL_TELLER.PR_CHG_PICKUP_REQD(TRUE);
        DBG('Uploading payout multimode chg-details');
        IF NOT FN_DEFAULT_PAYOUT_CHGDETS(GWPKS_TDREDEMPTION.G_PAYOUT_CHGDTLS,
                                         P_TY_PAYOUTDETS.REF_NO) THEN
          DBG('Falied in Fn_Default_Payout_Chgdets');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('p_Ty_Payoutdets.ref_no ' || P_TY_PAYOUTDETS.REF_NO);
    DBG('gwpks_util.pkg_acttype ' || GWPKS_UTIL.PKG_ACTTYPE);
  
    IF GWPKS_UTIL.PKG_ACTTYPE IN ('ENRICH') AND
       P_TY_PAYOUTDETS.REF_NO IS NULL THEN
      DEPKS_RTL_TELLER.G_TRN_REF_NO := '';
    END IF;
    DBG('>> depks_rtl_teller.g_trn_ref_no after reset: ' ||
        DEPKS_RTL_TELLER.G_TRN_REF_NO);
  
    IF P_WRK_ICDREDMN.CCY IS NULL THEN
    
      SELECT CCY
        INTO P_WRK_ICDREDMN.CCY
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_WRK_ICDREDMN.BRN_CODE
         AND CUST_AC_NO = P_WRK_ICDREDMN.AC_NO;
    
    END IF;
  
    IF P_TY_PAYOUTDETS.OFFSET_CCY IS NULL THEN
      SELECT CCY
        INTO P_TY_PAYOUTDETS.OFFSET_CCY
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_TY_PAYOUTDETS.OFFSET_BRN
         AND CUST_AC_NO = P_TY_PAYOUTDETS.OFFSET_ACC;
    END IF;
  
    IF P_REDM_MODE = 'N' THEN
    
      DBG('Redemption Mode is full redemption');
      P_FLAG := 0;
    
      L_OFFSET_DETAILS := P_TY_PAYOUTDETS.OFFSET_ACC || '~' ||
                          P_TY_PAYOUTDETS.OFFSET_BRN || '~' ||
                          P_TY_PAYOUTDETS.OFFSET_CCY || '~' ||
                         
                          P_TY_PAYOUTDETS.REDMAMT || '~' ||
                          P_TY_PAYOUTDETS.XRATE || '~';
      L_MCK_TSLIST     := NULL;
    
      DBG('Going to call icpkss_bod.fn_close_td');
      IF NOT ICPKSS_BOD.FN_CLOSE_TD(P_WRK_ICDREDMN.XREF,
                                    P_WRK_ICDREDMN.CCY,
                                    P_TY_PAYOUTDETS.OFFSET_BRN,
                                    P_TY_PAYOUTDETS.OFFSET_ACC,
                                    P_TY_PAYOUTDETS.OFFSET_CCY
                                    
                                   ,
                                    P_TY_PAYOUTDETS.REDMAMT,
                                    P_TY_PAYOUTDETS.XRATE,
                                    L_PRM_PRODUCT_CODE,
                                    P_WRK_ICDREDMN.BRN_CODE,
                                    P_WRK_ICDREDMN.AC_NO,
                                    P_WRK_ICDREDMN.WAVE_PENALTY,
                                    P_WRK_ICDREDMN.WAIVE_INTEREST,
                                    L_OFFSET_DETAILS,
                                    L_MCK_TSLIST,
                                    'FT',
                                    P_ERR_CODE,
                                    P_ERR_PARAMS) THEN
        DBG('Failed to Close the Term Deposit while processing Savings Details');
        DBG('p_err_code :: ' || P_ERR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-07', NULL);
        RETURN FALSE;
      END IF;
    ELSIF P_REDM_MODE = 'Y' THEN
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_SAVINGS(P_WRK_ICDREDMN,
                                                        P_TY_PAYOUTDETS,
                                                        L_PRM_PRODUCT_CODE,
                                                        P_REDM_MODE,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA) THEN
          DBG('Failed while calling fn_redby_savings in cluster package' ||
              SQLERRM);
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('Redemption mode is partial');
      DBG('Going to call icpkss_bod.fn_teller_txn');
      DBG('TRN_DATE IS' || ICPKS_BOD.G_TRN_DT);
    
      DBG('p_wrk_icdredmn.ccy ' || P_WRK_ICDREDMN.CCY);
      DBG('p_ty_payoutdets.offset_ccy ' || P_TY_PAYOUTDETS.OFFSET_CCY);
      DBG('p_ty_payoutdets.redmamt ' || P_TY_PAYOUTDETS.REDMAMT);
      IF P_WRK_ICDREDMN.CCY <> P_TY_PAYOUTDETS.OFFSET_CCY THEN
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID := 2;
          L_TB_CLUSTER_DATA('l_exch_rate') := NULL;
          IF NOT
              ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_SAVINGS(P_WRK_ICDREDMN,
                                                          P_TY_PAYOUTDETS,
                                                          L_PRM_PRODUCT_CODE,
                                                          P_REDM_MODE,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA) THEN
            DBG('Failed while calling fn_redby_savings in cluster package' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
          L_RATE := L_TB_CLUSTER_DATA('l_exch_rate');
          DBG('Tarun Singhal the xrate is ' || L_RATE);
        END IF;
      
        IF NOT CYPKS.FN_AMT1_TO_AMT2(P_WRK_ICDREDMN.BRN_CODE,
                                     P_WRK_ICDREDMN.CCY,
                                     P_TY_PAYOUTDETS.OFFSET_CCY,
                                     'STANDARD',
                                     'M',
                                     P_TY_PAYOUTDETS.REDMAMT,
                                     'Y',
                                     L_OUT_AMT,
                                     L_RATE,
                                     P_ERR_CODE) THEN
          DBG('Failed to get rates or rates not maintained for the currency');
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
        ELSE
          DBG('Chg Acy amount got successfully for the chg amount-> ' ||
              L_OUT_AMT);
          DBG('Exch Rate Got successfully -> ' || L_RATE);
          P_TY_PAYOUTDETS.XRATE := L_RATE;
        END IF;
      END IF;
    
      IF NOT ICPKSS_BOD.FN_TELLER_TXN(P_WRK_ICDREDMN.BRN_CODE,
                                      L_PRM_PRODUCT_CODE,
                                      P_WRK_ICDREDMN.XREF,
                                      P_WRK_ICDREDMN.AC_NO,
                                      P_WRK_ICDREDMN.CCY,
                                      
                                      P_TY_PAYOUTDETS.REDMAMT,
                                      P_TY_PAYOUTDETS.OFFSET_BRN,
                                      P_TY_PAYOUTDETS.OFFSET_ACC,
                                      P_TY_PAYOUTDETS.OFFSET_CCY,
                                      
                                      L_OUT_AMT,
                                      
                                      NULL,
                                      P_TY_PAYOUTDETS.XRATE,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
        DBG('Failed to do Partial Redemption while processing Savings Details');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
      
        OVPKSS.PR_APPENDTBL('TD-RED-08', NULL);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_WRK_ICDREDMN.XREF IS NULL THEN
      P_WRK_ICDREDMN.XREF := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
    END IF;
  
    L_REF_NO := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA('l_ref_no') := L_REF_NO;
      IF NOT
          ICPKS_FCJ_ICDREDMN_CLUSTER.FN_REDBY_SAVINGS(P_WRK_ICDREDMN,
                                                      P_TY_PAYOUTDETS,
                                                      L_PRM_PRODUCT_CODE,
                                                      P_REDM_MODE,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
        DBG('Failed while calling fn_redby_savings in cluster package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    UPDATE ICTM_TDREDMPAYOUT_DETAILS
       SET REF_NO = L_REF_NO
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO
       AND SEQNO = P_TY_PAYOUTDETS.SEQNO
       AND REDEM_REF_NO = P_WRK_ICDREDMN.REDEM_REF_NO;
    DBG('Rows updated for Payout Details :' || SQL%ROWCOUNT);
  
    IF P_WRK_ICDREDMN.FCCREF IS NULL THEN
      DBG('>> assigin refno to payout master: ' || L_REF_NO);
      P_WRK_ICDREDMN.FCCREF := L_REF_NO;
    END IF;
    IF P_TY_PAYOUTDETS.REF_NO IS NULL THEN
      DBG('>> assigin refno to payout dtl: ' || L_REF_NO);
      P_TY_PAYOUTDETS.REF_NO := L_REF_NO;
    END IF;
  
    DBG('Returning true from fn_redby_savings');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_redby_savings ..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_REDBY_SAVINGS;

  FUNCTION FN_ROLLOVER(P_WRK_ICDREDMN IN OUT TDVWS_TD_REDEMPTION%ROWTYPE)
    RETURN BOOLEAN IS
    P_ERR_CODE   VARCHAR2(1000);
    P_ERR_PARAMS VARCHAR2(1000);
    P_SOURCE     COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_RES        VARCHAR2(30);
  
    L_STDCUSTD      STPKS_STDCUSTD_MAIN.TY_STDCUSTD;
    L_ACC_REC       STTM_CUST_ACCOUNT%ROWTYPE;
    L_RECORD_MASTER STTBS_RECORD_MASTER%ROWTYPE;
    L_SOURCE        COTMS_SOURCE.SOURCE_CODE%TYPE;
    L_ERR_PARAMS    VARCHAR2(256);
  
  BEGIN
    DBG('Inside fn_rollover');
  
    DBG('Int rate based on cum amt--->' ||
        P_WRK_ICDREDMN.INTRATE_CUMAMT_REQD);
    DBG('updating ictm_acc');
    UPDATE ICTM_ACC
       SET INTRATE_CUMAMT_REQD = P_WRK_ICDREDMN.INTRATE_CUMAMT_REQD,
           
           ORIG_TENOR_YEARS  = P_WRK_ICDREDMN.TENOR_YY,
           ORIG_TENOR_MONTHS = P_WRK_ICDREDMN.TENOR_MM,
           ORIG_TENOR_DAYS   = P_WRK_ICDREDMN.TENOR_DD
    
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO;
    DBG('updated successfully');
  
    UPDATE ICTMS_ACC_PR
       SET CONT_VAR_ROLL = NVL(P_WRK_ICDREDMN.CONT_VAR_ROLL, 'N')
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO;
  
    G_ADDNL_FLAG := FALSE;
    DBG('add funds-->' || NVL(P_WRK_ICDREDMN.ADD_FUNDS, 'N'));
    DBG('addnl amt-->' || NVL(P_WRK_ICDREDMN.ADDITIONAL_AMT, 0));
  
    IF NVL(P_WRK_ICDREDMN.ADD_FUNDS, 'N') = 'Y' AND
       NVL(P_WRK_ICDREDMN.ADDITIONAL_AMT, 0) <> 0 THEN
      G_ADDNL_FLAG     := TRUE;
      G_REDEM_REF_NO   := P_WRK_ICDREDMN.REDEM_REF_NO;
      G_ADDITIONAL_AMT := NVL(P_WRK_ICDREDMN.ADDITIONAL_AMT, 0);
      DBG('setting g_addnl_flag to true');
    END IF;
  
    DBG('Going to call icpkss_bod.fn_reinstate_deposit');
    IF NOT ICPKSS_BOD.FN_REINSTATE_DEPOSIT(P_WRK_ICDREDMN.BRN_CODE,
                                           P_WRK_ICDREDMN.AC_NO,
                                           P_WRK_ICDREDMN.NEXT_MAT_DATE,
                                           P_ERR_CODE,
                                           P_ERR_PARAMS) THEN
      DBG('Failed in Renewing the Term Deposit');
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, NULL);
      OVPKSS.PR_APPENDTBL('TD-RED-09', NULL);
      RETURN FALSE;
    END IF;
    G_ADDNL_FLAG := FALSE;
  
    UPDATE ICTM_ACC
       SET MATURITY_DATE = P_WRK_ICDREDMN.NEXT_MAT_DATE
    
     WHERE BRN = P_WRK_ICDREDMN.BRN_CODE
       AND ACC = P_WRK_ICDREDMN.AC_NO;
  
    BEGIN
      SELECT *
        INTO L_ACC_REC
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_WRK_ICDREDMN.BRN_CODE
         AND CUST_AC_NO = P_WRK_ICDREDMN.AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('No records fetched');
        DBG('Trace :' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END;
  
    L_STDCUSTD.V_STTMS_CUST_ACCOUNT := L_ACC_REC;
    DBG('Account number is ' || L_STDCUSTD.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF NOT STPKS_STDCUSTD_MAIN.FN_GET_KEY_INFORMATION(L_SOURCE,
                                                      NULL,
                                                      'STDCUSTD',
                                                      'MODIFY',
                                                      L_STDCUSTD,
                                                      P_ERR_CODE,
                                                      L_ERR_PARAMS) THEN
      DBG('Failed in  stpks_stdcustd_main.Fn_Get_Key_Information with ' ||
          SQLERRM);
      DBG('Trace ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END IF;
    DBG('Going to call stpks_stdcustd_main.Fn_Populate_Record_Master');
    IF NOT STPKS_STDCUSTD_MAIN.FN_POPULATE_RECORD_MASTER(L_SOURCE,
                                                         NULL,
                                                         'STDCUSTD',
                                                         'MODIFY',
                                                         L_STDCUSTD,
                                                         L_RECORD_MASTER,
                                                         P_ERR_CODE,
                                                         L_ERR_PARAMS) THEN
    
      DBG('Failed in  stpks_stdcustd_main.Fn_Populate_Record_Master..');
      DBG('Trace ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    END IF;
    DBG('Now updating the record master');
    DBG('Key Id is ' || L_RECORD_MASTER.KEY_ID);
    DBG('l_Record_Master.Char_Fld_10 ' || L_RECORD_MASTER.CHAR_FLD_10);
    BEGIN
      UPDATE STTBS_RECORD_MASTER
         SET CHAR_FLD_1  = L_RECORD_MASTER.CHAR_FLD_1,
             CHAR_FLD_2  = L_RECORD_MASTER.CHAR_FLD_2,
             CHAR_FLD_3  = L_RECORD_MASTER.CHAR_FLD_3,
             CHAR_FLD_4  = L_RECORD_MASTER.CHAR_FLD_4,
             CHAR_FLD_5  = L_RECORD_MASTER.CHAR_FLD_5,
             CHAR_FLD_6  = L_RECORD_MASTER.CHAR_FLD_6,
             CHAR_FLD_7  = L_RECORD_MASTER.CHAR_FLD_7,
             CHAR_FLD_8  = L_RECORD_MASTER.CHAR_FLD_8,
             CHAR_FLD_9  = L_RECORD_MASTER.CHAR_FLD_9,
             CHAR_FLD_10 = L_RECORD_MASTER.CHAR_FLD_10,
             CHAR_FLD_11 = L_RECORD_MASTER.CHAR_FLD_11,
             CHAR_FLD_12 = L_RECORD_MASTER.CHAR_FLD_12,
             CHAR_FLD_13 = L_RECORD_MASTER.CHAR_FLD_13,
             CHAR_FLD_14 = L_RECORD_MASTER.CHAR_FLD_14,
             CHAR_FLD_15 = L_RECORD_MASTER.CHAR_FLD_15,
             CHAR_FLD_16 = L_RECORD_MASTER.CHAR_FLD_16,
             CHAR_FLD_17 = L_RECORD_MASTER.CHAR_FLD_17,
             CHAR_FLD_18 = L_RECORD_MASTER.CHAR_FLD_18,
             CHAR_FLD_19 = L_RECORD_MASTER.CHAR_FLD_19,
             CHAR_FLD_20 = L_RECORD_MASTER.CHAR_FLD_20,
             CHAR_FLD_21 = L_RECORD_MASTER.CHAR_FLD_21,
             CHAR_FLD_22 = L_RECORD_MASTER.CHAR_FLD_22,
             CHAR_FLD_23 = L_RECORD_MASTER.CHAR_FLD_23,
             CHAR_FLD_24 = L_RECORD_MASTER.CHAR_FLD_24,
             CHAR_FLD_25 = L_RECORD_MASTER.CHAR_FLD_25,
             NUM_FLD_1   = L_RECORD_MASTER.NUM_FLD_1,
             NUM_FLD_2   = L_RECORD_MASTER.NUM_FLD_2,
             NUM_FLD_3   = L_RECORD_MASTER.NUM_FLD_3,
             NUM_FLD_4   = L_RECORD_MASTER.NUM_FLD_4,
             NUM_FLD_5   = L_RECORD_MASTER.NUM_FLD_5,
             NUM_FLD_6   = L_RECORD_MASTER.NUM_FLD_6,
             NUM_FLD_7   = L_RECORD_MASTER.NUM_FLD_7,
             NUM_FLD_8   = L_RECORD_MASTER.NUM_FLD_8,
             NUM_FLD_9   = L_RECORD_MASTER.NUM_FLD_9,
             NUM_FLD_10  = L_RECORD_MASTER.NUM_FLD_10,
             DATE_FLD_1  = L_RECORD_MASTER.DATE_FLD_1,
             DATE_FLD_2  = L_RECORD_MASTER.DATE_FLD_2,
             DATE_FLD_3  = L_RECORD_MASTER.DATE_FLD_3,
             DATE_FLD_4  = L_RECORD_MASTER.DATE_FLD_4,
             DATE_FLD_5  = L_RECORD_MASTER.DATE_FLD_5,
             DATE_FLD_6  = L_RECORD_MASTER.DATE_FLD_6,
             DATE_FLD_7  = L_RECORD_MASTER.DATE_FLD_7,
             DATE_FLD_8  = L_RECORD_MASTER.DATE_FLD_8,
             DATE_FLD_9  = L_RECORD_MASTER.DATE_FLD_9,
             DATE_FLD_10 = L_RECORD_MASTER.DATE_FLD_10
       WHERE KEY_ID = L_RECORD_MASTER.KEY_ID;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Nothing to update');
    END;
  
    DBG('returning true from fn_rollover');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_rollover ..');
      DBG(SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_ROLLOVER;

  FUNCTION FN_INT_ADJ(P_TDACC             IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                      P_TDBRN             IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                      P_TDCCY             IN STTM_CUST_ACCOUNT.CCY%TYPE,
                      P_RED_AMT           IN ICTM_TD_DETAILS.REDEM_AMT%TYPE,
                      P_PRODUCT           IN ICTM_ACC_PR.PROD%TYPE,
                      P_BR_DATE           IN DATE,
                      P_MODE              IN VARCHAR2,
                      P_ERR_CODE          OUT ERTBS_MSGS.ERR_CODE%TYPE,
                      P_ERR_PARAM         OUT ERTBS_MSGS.MESSAGE%TYPE,
                      P_PROCESS_ADHOC_HOL IN BOOLEAN DEFAULT FALSE)
    RETURN BOOLEAN IS
  
    L_RELATED_CUSTOMER      STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_TOTALTDAMOUNT         ICTM_TD_DETAILS.TD_AMOUNT%TYPE;
    L_MATURITY_DATE         ICTMS_ACC.MATURITY_DATE%TYPE;
    L_INT_START_DATE        ICTMS_ACC.MATURITY_DATE%TYPE;
    L_PRODUCT               ICTBS_ACC_PR.PROD%TYPE;
    L_TOTAL_INTEREST_AMOUNT ICTW_MEMO_BOOKING.AMT%TYPE;
    L_RULE                  ICTMS_PR_INT.RULE%TYPE;
    L_INT_METH              ICTMS_RULE_FRM.FRM_INT_METH%TYPE;
    L_SERIAL_NO             VARCHAR2(15);
    L_TXN_REF_NO            VARCHAR2(16);
    L_TENOR                 NUMBER;
    L_INT_RATE              NUMBER;
    L_NEW_TENOR             NUMBER;
    DAYS                    NUMBER;
    MONTH                   NUMBER;
    YEAR                    NUMBER;
    L_ADJ_INT_AMNT          NUMBER;
     --sampath starts
    L_TOTAL_TAX_AMOUNT NUMBER;
    --sampath ends
    L_AMOUNT                NUMBER;
    L_PART_INT_AMNT         NUMBER;
    L_REM_TD_AMNT           NUMBER;
    TB_ACCHANDOFF           ACPKSS.TBL_ACHOFF;
    L_TB_LOOKUP             ACPKSS.TBL_LOOKUP;
    L_AC_CCY                STTBS_ACCOUNT.AC_GL_CCY%TYPE;
    L_RATE                  CYTMS_RATES.MID_RATE%TYPE;
    L_RATE_FLAG             NUMBER;
    L_AMT_BLK_NO            CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO%TYPE;
    L_NEW_AMT_BLK_NO        CATMS_AMOUNT_BLOCKS.AMOUNT_BLOCK_NO%TYPE;
    LOOKUP_CNT              NUMBER;
    I                       NUMBER;
    L_BOOK_ACC              ICTMS_ACC.BOOK_ACC%TYPE;
    L_BOOK_BRN              ICTMS_ACC.BOOK_BRN%TYPE;
    L_ACHF_CNT              NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_PR_INT ICTMS_PR_INT%ROWTYPE;
  
    L_BOOK_CCY   ICTMS_ACC.BOOK_CCY%TYPE;
    L_LCY_AMOUNT NUMBER;
  
    FUNCTION FN_PASS_ACCT(P_TDACC       VARCHAR2,
                          P_TDBRN       VARCHAR2,
                          P_BOOK_BRN    VARCHAR2,
                          P_BOOK_ACC    VARCHAR2,
                          P_BOOK_CCY    VARCHAR2,
                          P_ADJ_INT_AMT NUMBER,
                          P_BR_DATE     DATE,
                          P_PRODUCT     VARCHAR2,
                          P_ERR_CODE    OUT VARCHAR2,
                          P_ERR_PARAM   OUT ERTBS_MSGS.MESSAGE%TYPE)
      RETURN BOOLEAN IS
      L_SERIAL_NO        VARCHAR2(15);
      L_TXN_REF_NO       VARCHAR2(16);
      TB_ACCHANDOFF      ACPKSS.TBL_ACHOFF;
      L_TB_LOOKUP        ACPKSS.TBL_LOOKUP;
      L_AC_CCY           STTBS_ACCOUNT.AC_GL_CCY%TYPE;
      L_RATE             CYTMS_RATES.MID_RATE%TYPE;
      L_BOOK_ACC         ICTMS_ACC.BOOK_ACC%TYPE;
      L_BOOK_BRN         ICTMS_ACC.BOOK_BRN%TYPE;
      L_BOOK_CCY         ICTMS_ACC.BOOK_CCY%TYPE;
      L_RELATED_CUSTOMER STTM_CUST_ACCOUNT.CUST_NO%TYPE;
      L_LCY_AMOUNT       NUMBER;
      L_ACHF_CNT         NUMBER;
    BEGIN
      DBG('Start of fn_pass_Acct ...Before generating Transanction ref No....');
    
      L_BOOK_ACC := P_BOOK_ACC;
      L_BOOK_CCY := P_BOOK_CCY;
      L_BOOK_BRN := P_BOOK_BRN;
    
      BEGIN
        SELECT CUST_NO
          INTO L_RELATED_CUSTOMER
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_TDACC
           AND BRANCH_CODE = P_TDBRN;
      EXCEPTION
        WHEN OTHERS THEN
          ICPKSS_UTIL.DBG('Error while selecting related customer :' ||
                          SQLERRM);
          RETURN FALSE;
      END;
      DBG('Related customer is :' || L_RELATED_CUSTOMER);
    
      IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_TDBRN,
                                         'ILIQ',
                                         P_BR_DATE,
                                         L_SERIAL_NO,
                                         L_TXN_REF_NO,
                                         P_ERR_CODE) THEN
        DBG('trpkss.fn_get_process_refno failed ' || P_ERR_CODE);
        RETURN FALSE;
      END IF;
      DBG('Generated Transanction ref No and serial no is-->' ||
          L_TXN_REF_NO || '~' || L_SERIAL_NO);
      DBG('Now call acfn_lookup to build the entries');
    
      L_TB_LOOKUP.DELETE;
      IF NOT ACPKSS.ACFN_LOOKUP(P_PRODUCT, 'ILIQ', L_TB_LOOKUP, P_ERR_CODE) THEN
        ICPKSS_UTIL.DBG('Error in fn lookup :' || P_ERR_CODE || '~' ||
                        SQLERRM);
        RETURN FALSE;
      END IF;
    
      IF L_TB_LOOKUP.COUNT <> 0 AND L_ADJ_INT_AMNT <> 0 THEN
      
        FOR LOOKUP_CNT IN L_TB_LOOKUP.FIRST .. L_TB_LOOKUP.LAST LOOP
        
          IF L_TB_LOOKUP(LOOKUP_CNT).AMTTAG = 'ILIQ_ADJ' THEN
            L_ACHF_CNT := TB_ACCHANDOFF.COUNT + 1;
            TB_ACCHANDOFF(L_ACHF_CNT) := NULL;
            IF L_TB_LOOKUP(LOOKUP_CNT).DRCRIND = 'C' AND L_TB_LOOKUP(LOOKUP_CNT)
               .AMTTAG = 'ILIQ_ADJ' THEN
              DBG('Now in the Credit Leg.................' || L_ACHF_CNT);
              SELECT NVL(AC_GL_CCY, P_TDCCY)
                INTO L_AC_CCY
                FROM STTBS_ACCOUNT
               WHERE NVL(BRANCH_CODE, P_TDBRN) = P_TDBRN
                 AND AC_GL_NO = L_TB_LOOKUP(LOOKUP_CNT).ACCOUNT
                 AND AC_GL_REC_STATUS = 'O'
                 AND AUTH_STAT = 'A';
              TB_ACCHANDOFF(L_ACHF_CNT).AC_BRANCH := P_TDBRN;
              TB_ACCHANDOFF(L_ACHF_CNT).AC_NO := L_TB_LOOKUP(LOOKUP_CNT)
                                                 .ACCOUNT;
              TB_ACCHANDOFF(L_ACHF_CNT).AC_CCY := L_AC_CCY;
              DBG('Cr tb_acchandoff(l_achf_cnt).ac_branch.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_BRANCH);
              DBG('Cr tb_acchandoff(l_achf_cnt).ac_no.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_NO);
              DBG('Cr tb_acchandoff(l_achf_cnt).ac_ccy.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_CCY);
            
              IF TB_ACCHANDOFF(L_ACHF_CNT).AC_CCY <> GLOBAL.LCY THEN
              
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TDBRN,
                                                   TB_ACCHANDOFF (L_ACHF_CNT)
                                                   .AC_CCY,
                                                   GLOBAL.LCY,
                                                   L_ADJ_INT_AMNT,
                                                   'Y',
                                                   TB_ACCHANDOFF (L_ACHF_CNT)
                                                   .LCY_AMOUNT,
                                                   TB_ACCHANDOFF (L_ACHF_CNT)
                                                   .EXCH_RATE,
                                                   P_ERR_CODE) THEN
                  DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                  RETURN FALSE;
                END IF;
              
                IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := P_BR_DATE;
                ELSE
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
                END IF;
                TB_ACCHANDOFF(L_ACHF_CNT).FCY_AMOUNT := L_ADJ_INT_AMNT;
              ELSE
                TB_ACCHANDOFF(L_ACHF_CNT).AC_CCY := GLOBAL.LCY;
                TB_ACCHANDOFF(L_ACHF_CNT).EXCH_RATE := 1;
                TB_ACCHANDOFF(L_ACHF_CNT).LCY_AMOUNT := L_ADJ_INT_AMNT;
                IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := P_BR_DATE;
                ELSE
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
                END IF;
                TB_ACCHANDOFF(L_ACHF_CNT).FCY_AMOUNT := NULL;
              END IF;
            END IF;
            IF L_TB_LOOKUP(LOOKUP_CNT).DRCRIND = 'D' AND L_TB_LOOKUP(LOOKUP_CNT)
               .AMTTAG = 'ILIQ_ADJ' THEN
            
              DBG('Now in the Debit Leg.................' || L_ACHF_CNT);
              TB_ACCHANDOFF(L_ACHF_CNT).AC_BRANCH := L_BOOK_BRN;
              TB_ACCHANDOFF(L_ACHF_CNT).AC_NO := L_BOOK_ACC;
              TB_ACCHANDOFF(L_ACHF_CNT).AC_CCY := L_BOOK_CCY;
            
              DBG('Dr tb_acchandoff(l_achf_cnt).ac_branch.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_BRANCH);
              DBG('Dr tb_acchandoff(l_achf_cnt).ac_no.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_NO);
              DBG('Dr tb_acchandoff(l_achf_cnt).ac_ccy.................' || '~' || TB_ACCHANDOFF(L_ACHF_CNT)
                  .AC_CCY);
            
              IF P_TDCCY <> GLOBAL.LCY THEN
              
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TDBRN,
                                                   P_TDCCY,
                                                   GLOBAL.LCY,
                                                   L_ADJ_INT_AMNT,
                                                   'Y',
                                                   L_LCY_AMOUNT,
                                                   L_RATE,
                                                   P_ERR_CODE) THEN
                  DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                  RETURN FALSE;
                END IF;
              ELSE
                L_LCY_AMOUNT := L_ADJ_INT_AMNT;
              END IF;
              IF L_BOOK_CCY <> GLOBAL.LCY THEN
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TDBRN,
                                                   GLOBAL.LCY,
                                                   L_BOOK_CCY,
                                                   L_LCY_AMOUNT,
                                                   'Y',
                                                   TB_ACCHANDOFF(L_ACHF_CNT)
                                                   .FCY_AMOUNT,
                                                   TB_ACCHANDOFF(L_ACHF_CNT)
                                                   .EXCH_RATE,
                                                   P_ERR_CODE) THEN
                  DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                  RETURN FALSE;
                END IF;
                
                --SAMPATH FOR KHR AND KHR STARTS AS FCY AMOUNT IS WRONG
                IF L_BOOK_CCY = 'KHR' AND P_TDCCY = 'KHR' AND TB_ACCHANDOFF(L_ACHF_CNT).AC_CCY = 'KHR'
                  AND L_AC_CCY = 'KHR' THEN
                  TB_ACCHANDOFF(L_ACHF_CNT).FCY_AMOUNT := L_ADJ_INT_AMNT;
                END IF;
                --SAMPATH FOR KHR AND KHR ENDS AS FCY AMOUNT IS WRONG
                
                TB_ACCHANDOFF(L_ACHF_CNT).LCY_AMOUNT := L_LCY_AMOUNT;
                IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := P_BR_DATE;
                ELSE
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
                END IF;
              ELSE
                TB_ACCHANDOFF(L_ACHF_CNT).LCY_AMOUNT := L_LCY_AMOUNT;
                TB_ACCHANDOFF(L_ACHF_CNT).EXCH_RATE := 1;
                IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := P_BR_DATE;
                ELSE
                  TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
                END IF;
                TB_ACCHANDOFF(L_ACHF_CNT).FCY_AMOUNT := NULL;
              
              END IF;
            
            END IF;
            ICPKSS_UTIL.DBG('Populating other fields for .................' || L_TB_LOOKUP(LOOKUP_CNT)
                            .DRCRIND);
            TB_ACCHANDOFF(L_ACHF_CNT).USER_ID := GLOBAL.USER_ID;
            TB_ACCHANDOFF(L_ACHF_CNT).MODULE := 'IC';
            TB_ACCHANDOFF(L_ACHF_CNT).AMOUNT_TAG := L_TB_LOOKUP(LOOKUP_CNT)
                                                    .AMTTAG;
            TB_ACCHANDOFF(L_ACHF_CNT).EVENT := 'ILIQ';
            TB_ACCHANDOFF(L_ACHF_CNT).EVENT_SR_NO := 1;
            TB_ACCHANDOFF(L_ACHF_CNT).TRN_CODE := L_TB_LOOKUP(LOOKUP_CNT)
                                                  .TRNCODE;
            TB_ACCHANDOFF(L_ACHF_CNT).TRN_REF_NO := L_TXN_REF_NO;
            TB_ACCHANDOFF(L_ACHF_CNT).INSTRUMENT_CODE := '';
            IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
              TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := P_BR_DATE;
              TB_ACCHANDOFF(L_ACHF_CNT).TXN_INIT_DATE := P_BR_DATE;
              TB_ACCHANDOFF(L_ACHF_CNT).TRN_DT := P_BR_DATE;
            ELSE
              TB_ACCHANDOFF(L_ACHF_CNT).VALUE_DT := GLOBAL.APPLICATION_DATE;
              TB_ACCHANDOFF(L_ACHF_CNT).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
              TB_ACCHANDOFF(L_ACHF_CNT).TRN_DT := GLOBAL.APPLICATION_DATE;
            END IF;
            TB_ACCHANDOFF(L_ACHF_CNT).RELATED_ACCOUNT := P_TDACC;
            TB_ACCHANDOFF(L_ACHF_CNT).RELATED_CUSTOMER := L_RELATED_CUSTOMER;
            TB_ACCHANDOFF(L_ACHF_CNT).EXTERNAL_REF_NO := L_TXN_REF_NO;
            TB_ACCHANDOFF(L_ACHF_CNT).NETTING_IND := L_TB_LOOKUP(LOOKUP_CNT)
                                                     .NETIND;
            TB_ACCHANDOFF(L_ACHF_CNT).DRCR_IND := L_TB_LOOKUP(LOOKUP_CNT)
                                                  .DRCRIND;
          END IF;
        END LOOP;
      END IF;
    
      L_TB_LOOKUP.DELETE;
    
      DBG('Call to set acchandoff :' || TB_ACCHANDOFF.COUNT);
    
      IF TB_ACCHANDOFF.COUNT > 0 THEN
      
        FOR I IN TB_ACCHANDOFF.FIRST .. TB_ACCHANDOFF.LAST LOOP
          ICPKSS_UTIL.DBG('ac no :' || TB_ACCHANDOFF(I).AC_NO || '~' || TB_ACCHANDOFF(I)
                          .EVENT);
        END LOOP;
      
        IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                   1,
                                   P_BR_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'Y',
                                   'Y',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || P_ERR_CODE);
          RETURN FALSE;
        END IF;
      END IF;
    
      BEGIN
        UPDATE ICTM_TD_DETAILS
           SET REFERENCE_NO = L_TXN_REF_NO
         WHERE BRN = P_TDBRN
           AND ACC = P_TDACC
           AND CCY = P_TDCCY;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error in updating ictm_td_details :' || SQLERRM);
          RETURN FALSE;
      END;
      TB_ACCHANDOFF.DELETE;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO Exception in fn_pass_Acct' || SQLERRM);
        RETURN FALSE;
    END FN_PASS_ACCT;
  
  BEGIN
    ICPKSS_UTIL.DBG('Inside call to fn_int_adj');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_INT_ADJ(P_TDACC,
                                                   P_TDBRN,
                                                   P_TDCCY,
                                                   P_RED_AMT,
                                                   P_PRODUCT,
                                                   P_BR_DATE,
                                                   P_MODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM,
                                                   P_PROCESS_ADHOC_HOL,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA) THEN
        DBG('Failed in icpks_fcj_icdredmn_cluster.fn_int_adj');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      ICPKSS_UTIL.DBG('Parameters values acc-brn-ccy:' || P_TDACC || '~' ||
                      P_TDBRN || '~' || P_TDCCY);
      ICPKSS_UTIL.DBG('Parameters values prod-brndate-mode:' || P_PRODUCT || '~' ||
                      P_BR_DATE || '~' || P_MODE);
    
      BEGIN
        SELECT TD_AMOUNT
          INTO L_TOTALTDAMOUNT
          FROM ICTM_TD_DETAILS
         WHERE BRN = P_TDBRN
           AND ACC = P_TDACC
           AND CCY = P_TDCCY;
      EXCEPTION
        WHEN OTHERS THEN
          ICPKSS_UTIL.DBG('Error in ictm_td_details on select offset details :' ||
                          SQLERRM);
          P_ERR_CODE := 'ST-CUS98';
          P_ERR_CODE := 'TD Details Not Maintained properly for A/C :' ||
                        P_TDACC;
          RETURN FALSE;
      END;
      ICPKSS_UTIL.DBG('TD Amount is :' || L_TOTALTDAMOUNT);
    
      BEGIN
        SELECT MATURITY_DATE, INT_START_DATE, BOOK_ACC, BOOK_BRN, BOOK_CCY
          INTO L_MATURITY_DATE,
               L_INT_START_DATE,
               L_BOOK_ACC,
               L_BOOK_BRN,
               L_BOOK_CCY
          FROM ICTMS_ACC
         WHERE ACC = P_TDACC
           AND BRN = P_TDBRN;
      EXCEPTION
        WHEN OTHERS THEN
          ICPKSS_UTIL.DBG('When others of select ictms_acc...>' || SQLERRM);
          RETURN FALSE;
      END;
      ICPKSS_UTIL.DBG('Maturity Date and Int Start Date is :' ||
                      L_MATURITY_DATE || '~' || L_INT_START_DATE);
      ICPKSS_UTIL.DBG('Book Acc and Book Brn is :' || L_BOOK_ACC || '~' ||
                      L_BOOK_BRN);
    
      L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(P_PRODUCT);
    
      BEGIN
      
        SELECT FRM_INT_METH
          INTO L_INT_METH
          FROM ICTMS_RULE_FRM
         WHERE RULE_ID = L_PR_INT.RULE
           AND FRM_NO = 1;
      
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC',
                         'Could not get the interest method:' || SQLERRM);
          RETURN FALSE;
      END;
      ICPKSS_UTIL.DBG('Int Method is :' || L_INT_METH);
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_tenor') := L_TENOR;
        L_TB_CLUSTER_DATA('l_maturity_date') := L_MATURITY_DATE;
        L_TB_CLUSTER_DATA('l_int_start_date') := L_INT_START_DATE;
        IF NOT ICPKS_FCJ_ICDREDMN_CLUSTER.FN_INT_ADJ(P_TDACC,
                                                     P_TDBRN,
                                                     P_TDCCY,
                                                     P_RED_AMT,
                                                     P_PRODUCT,
                                                     P_BR_DATE,
                                                     P_MODE,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM,
                                                     P_PROCESS_ADHOC_HOL,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA) THEN
          DBG('Failed in icpks_fcj_icdredmn_cluster.fn_int_adj');
          RETURN FALSE;
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_tenor') THEN
          L_TENOR := L_TB_CLUSTER_DATA('l_tenor');
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        L_TENOR := L_MATURITY_DATE - L_INT_START_DATE;
      
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      ICPKSS_UTIL.DBG('l_tenor is................' || L_TENOR || '~' || YEAR);
    
      IF P_MODE = 'Y' THEN
        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := P_RED_AMT;
        ICPKSS_UTIL.DBG('Redmn Amt is :' ||
                        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
      
        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := P_RED_AMT;
        ICPKSS_UTIL.DBG('Redmn Amt is :' ||
                        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT);
      
      END IF;
    
      DELETE FROM ICTW_MEMO_BOOKING
       WHERE BRN = P_TDBRN
         AND ACC = P_TDACC;
      ICPKSS_UTIL.DBG('Calling pr_icalc........');
      ICPKSS_TEST.PR_ICALC(P_TDBRN,
                           P_TDACC,
                           P_PRODUCT,
                           NVL(L_INT_START_DATE, P_BR_DATE),
                           L_MATURITY_DATE - 1);
    
      BEGIN
        SELECT NVL(SUM(AMT), 0)
          INTO L_TOTAL_INTEREST_AMOUNT
          FROM ICTW_MEMO_BOOKING
         WHERE BRN = P_TDBRN
           AND ACC = P_TDACC
           AND PROD = P_PRODUCT
           AND DRCR_IND = 'C'
           AND IS_TAX != 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          ICPKSS_UTIL.DBG('Error in selecting interest amount :' ||
                          SQLERRM);
          RETURN FALSE;
      END;
      ICPKSS_UTIL.DBG('Int Amount after select from memo :' ||
                      L_TOTAL_INTEREST_AMOUNT);
    
      ICPKSS_UTIL.PR_GET_DAYS(L_INT_START_DATE,
                              L_MATURITY_DATE,
                              L_INT_METH,
                              DAYS,
                              MONTH,
                              YEAR);
    
      L_INT_RATE := ((YEAR * 100 * L_TOTAL_INTEREST_AMOUNT) /
                    (L_TOTALTDAMOUNT * L_TENOR));
    
      ICPKSS_UTIL.DBG('l_int_rate is................' || L_INT_RATE);
    
      L_NEW_TENOR := L_MATURITY_DATE - P_BR_DATE;
      ICPKSS_UTIL.DBG('l_new_tenor is................' || L_NEW_TENOR);
    
      L_ADJ_INT_AMNT := ((L_TOTALTDAMOUNT * L_NEW_TENOR * L_INT_RATE) /
                        (100 * YEAR));
      IF NOT CYPKSS.FN_AMT_ROUND(L_BOOK_CCY, L_ADJ_INT_AMNT, L_ADJ_INT_AMNT) THEN
        DBG('failed in amt rounding: ' || SQLERRM);
        RETURN FALSE;
      END IF;
    
      ICPKSS_UTIL.DBG('l_adj_int_amnt is................' ||
                      L_ADJ_INT_AMNT);
    
      IF P_MODE = 'N' THEN
      
        IF CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') <> 'ICDRDSIM' OR
           (CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDRDSIM' AND
            NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                '**') <> 'SIMULATION') THEN
        
          IF NOT FN_PASS_ACCT(P_TDACC,
                              P_TDBRN,
                              L_BOOK_BRN,
                              L_BOOK_ACC,
                              L_BOOK_CCY,
                              L_ADJ_INT_AMNT,
                              P_BR_DATE,
                              P_PRODUCT,
                              P_ERR_CODE,
                              P_ERR_PARAM) THEN
            DBG('failed in passing accounting entries');
            RETURN FALSE;
          END IF;
          
          --sampath starts        
          IF NVL(L_ADJ_INT_AMNT, 0) > 0 THEN
            IF NOT FN_POST_TAX_REVERSAL_TDUPFRONT(P_TDACC, P_TDBRN, P_TDCCY) THEN
              DBG('failed in passing accounting entries');
              RETURN FALSE;
            END IF;
          END IF;
          --sampath ends
        
          IF NVL(P_PROCESS_ADHOC_HOL, FALSE) = FALSE THEN
            ICPKSS_UTIL.DBG('Full redemption so close the amount blocks');
          
            BEGIN
              SELECT AMOUNT_BLOCK_NO
                INTO L_AMT_BLK_NO
                FROM CATMS_AMOUNT_BLOCKS
               WHERE BRANCH = P_TDBRN
                 AND ACCOUNT = P_TDACC
                 AND AMOUNT_BLOCK_TYPE = 'D'
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                ICPKSS_UTIL.DBG('No Amount block so no need of further processing');
                RETURN TRUE;
              WHEN OTHERS THEN
                ICPKSS_UTIL.DBG('In WOT of amount block select' || SQLERRM);
                RETURN TRUE;
            END;
            ICPKSS_UTIL.DBG('Amount Block no is' || L_AMT_BLK_NO);
            IF NOT CASAPKSS.FN_AMOUNT_BLOCK_SWITCH(P_BR_DATE,
                                                   P_TDBRN,
                                                   L_AMT_BLK_NO,
                                                   P_TDACC,
                                                   'C',
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM) THEN
              ICPKSS_UTIL.DBG('Failed to Close amount block in function call fn_amount_block_switch:' ||
                              SQLERRM);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      
      ELSIF P_MODE = 'Y' THEN
      
        IF CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') <> 'ICDRDSIM' OR
           (CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDRDSIM' AND
            NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                '**') <> 'SIMULATION') THEN
        
          IF NOT FN_PASS_ACCT(P_TDACC,
                              P_TDBRN,
                              L_BOOK_BRN,
                              L_BOOK_ACC,
                              L_BOOK_CCY,
                              L_ADJ_INT_AMNT,
                              P_BR_DATE,
                              P_PRODUCT,
                              P_ERR_CODE,
                              P_ERR_PARAM) THEN
            DBG('failed in passing accounting entries');
            RETURN FALSE;
          END IF;
          
          --sampath starts        
          IF NVL(L_ADJ_INT_AMNT, 0) > 0 THEN
            IF NOT FN_POST_TAX_REVERSAL_TDUPFRONT(P_TDACC, P_TDBRN, P_TDCCY) THEN
              DBG('failed in passing accounting entries');
              RETURN FALSE;
            END IF;
          END IF;
          --sampath ends
        
          ICPKSS_UTIL.DBG('New Amount Block Creation for Partial redemption..............');
        
          BEGIN
            SELECT AMOUNT_BLOCK_NO
              INTO L_AMT_BLK_NO
              FROM CATMS_AMOUNT_BLOCKS
             WHERE BRANCH = P_TDBRN
               AND ACCOUNT = P_TDACC
               AND AMOUNT_BLOCK_TYPE = 'D'
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
          EXCEPTION
            WHEN OTHERS THEN
              L_AMT_BLK_NO := NULL;
              ICPKSS_UTIL.DBG('Error in amount block select:' || SQLERRM);
          END;
          IF L_AMT_BLK_NO IS NOT NULL THEN
            IF NOT CASAPKSS.FN_AMOUNT_BLOCK_SWITCH(P_BR_DATE,
                                                   P_TDBRN,
                                                   L_AMT_BLK_NO,
                                                   P_TDACC,
                                                   'C',
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM) THEN
              ICPKSS_UTIL.DBG('Failed to Close amount block in function call fn_amount_block_switch:' ||
                              SQLERRM);
              RETURN FALSE;
            END IF;
          END IF;
          ICPKSS_UTIL.DBG('Call to create a new Amount Block.............');
        
          BEGIN
            SELECT (NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0))
              INTO L_REM_TD_AMNT
              FROM ICTMS_TD_DETAILS
             WHERE BRN = P_TDBRN
               AND ACC = P_TDACC;
          EXCEPTION
            WHEN OTHERS THEN
              L_REM_TD_AMNT := 0;
              ICPKSS_UTIL.DBG('Error in ictm_td_details on select offset details :' ||
                              SQLERRM);
          END;
          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_REM_TD_AMNT;
          ICPKSS_UTIL.DBG('Rem Amt is :' ||
                          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
        
          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := L_REM_TD_AMNT;
          ICPKSS_UTIL.DBG('Rem Amt is :' ||
                          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT);
        
          DELETE FROM ICTW_MEMO_BOOKING
           WHERE BRN = P_TDBRN
             AND ACC = P_TDACC;
          ICPKSS_UTIL.DBG('Calling pr_icalc ....................');
          ICPKSS_TEST.PR_ICALC(P_TDBRN,
                               P_TDACC,
                               P_PRODUCT,
                               P_BR_DATE,
                               L_MATURITY_DATE - 1);
        
          BEGIN
            SELECT NVL(SUM(AMT), 0)
              INTO L_PART_INT_AMNT
              FROM ICTW_MEMO_BOOKING
             WHERE BRN = P_TDBRN
               AND ACC = P_TDACC
               AND PROD = P_PRODUCT
               AND DRCR_IND = 'C'
               AND IS_TAX != 'Y';
          EXCEPTION
            WHEN OTHERS THEN
              ICPKSS_UTIL.DBG('Error in selecting interest amount :' ||
                              SQLERRM);
              RETURN FALSE;
          END;
          ICPKSS_UTIL.DBG('Int Amount after select from memo :' ||
                          L_PART_INT_AMNT);
        
          IF NOT CASAPKSS.FN_CREATE_AMOUNT_BLOCK(GLOBAL.APPLICATION_DATE,
                                                 P_TDBRN,
                                                 P_TDACC,
                                                 L_PART_INT_AMNT,
                                                 P_BR_DATE,
                                                 L_MATURITY_DATE,
                                                 NULL,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM,
                                                 L_NEW_AMT_BLK_NO) THEN
            ICPKSS_UTIL.DBG('Failed to create amount block in function cal:' ||
                            SQLERRM);
            RETURN FALSE;
          ELSE
            ICPKSS_UTIL.DBG('The New Amount Block has been created:' ||
                            L_NEW_AMT_BLK_NO);
            DBG('Hold code enters here ');
            UPDATE CATMS_AMOUNT_BLOCKS
               SET AMOUNT_BLOCK_TYPE = 'D',
                   HOLD_CODE        =
                   (SELECT HOLD_CODE
                      FROM STTMS_HOLD_MASTER
                     WHERE HOLD_TYPE = 'D'
                       AND AUTH_STAT = 'A'
                       AND RECORD_STAT = 'O')
             WHERE AMOUNT_BLOCK_NO = L_NEW_AMT_BLK_NO
               AND BRANCH = P_TDBRN
               AND ACCOUNT = P_TDACC;
          END IF;
        END IF;
      
      END IF;
      STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT      := NULL;
      STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := NULL;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    RETURN TRUE;
  END FN_INT_ADJ;

  PROCEDURE PR_RESET_PENALTY IS
  BEGIN
    DBG('Inside pr_Reset_Penalty ');
    ICPKSS_CALC.G_PENALTY := 1;
  
    IF ICPKSS_BOD.G_WAVE_PENALTY = 'Y' THEN
    
      DBG('Setting Penaly to 0 - cause waived');
      ICPKSS_CALC.G_PENALTY := 0;
    END IF;
  END PR_RESET_PENALTY;
  PROCEDURE PR_WAIVE_PENALTY IS
  BEGIN
    DBG('Inside Pr_Waive_Penalty ');
    ICPKSS_CALC.G_PENALTY := 0;
  END PR_WAIVE_PENALTY;
  FUNCTION FN_DO_MEMO_ACCRUAL(P_BRN        IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              P_ACC        IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_START_DATE IN DATE,
                              P_END_DATE   IN DATE,
                              P_RULE       IN ICTM_PR_INT.RULE%TYPE,
                              P_PROD       IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                              P_ERR_CODE   IN OUT VARCHAR2,
                              P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    SSQL              VARCHAR2(255);
    C                 INTEGER;
    I                 INTEGER;
    CNT               INTEGER := 0;
    L_REDEM_FLAG      VARCHAR2(1);
    L_REDEMPTION_TYPE VARCHAR2(1);
    L_REDEM_AMT       STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_UDE_CCY         ICTMS_PR_INT.UDE_CCY%TYPE;
    L_PR_INT          ICTMS_PR_INT%ROWTYPE;
    CURSOR CR_ICTB(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
      SELECT *
        FROM ICTBS_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND PROD = P_PROD;
  
    FUNCTION Q(S VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
      RETURN CSPKES_MISC.FN_GETCHR(39) || S || CSPKES_MISC.FN_GETCHR(39);
    END Q;
  
  BEGIN
  
    DBG('Entered fn_do_memo_accrual');
    DBG('p_brn----->' || P_BRN);
    DBG('p_acc----->' || P_ACC);
    DBG('p_start_date--->' || P_START_DATE);
    DBG('p_end_date---->' || P_END_DATE);
    DBG('p_rule----->' || P_RULE);
    DBG('p_prod----->' || P_PROD);
  
    BEGIN
    
      DELETE FROM ICTW_MEMO_BOOKING A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = P_PROD;
    
      DBG('No of rows got del:' || SQL%ROWCOUNT);
    
      ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FLAG);
    
      DBG('l_redem_flag' || L_REDEM_FLAG);
    
      IF L_REDEM_FLAG = 'Y' THEN
        L_REDEMPTION_TYPE := 'F';
      ELSIF L_REDEM_FLAG = 'N' THEN
        L_REDEMPTION_TYPE := 'P';
      ELSE
        L_REDEMPTION_TYPE := 'M';
      END IF;
    
      IF L_REDEMPTION_TYPE = 'F' THEN
        BEGIN
          SELECT (TD_AMOUNT - NVL(REDEM_AMT, 0))
            INTO L_REDEM_AMT
            FROM ICTM_TD_DETAILS
           WHERE BRN = P_BRN
             AND ACC = P_ACC;
        
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_CODE := 'IC-MU0008';
            DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                SQLERRM);
            RETURN FALSE;
          
        END;
      
        IF PKG_RATE_CHART = 'Y' THEN
          ICPKS_BOD.G_PENALTY := L_REDEM_AMT;
        ELSE
          ICPKS_BOD.G_PENALTY := ICPKS_MAINT.G_REDEM_AMT;
        END IF;
      
      ELSE
      
        IF STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT THEN
          ICPKS_BOD.G_PENALTY := 0;
        ELSE
        
          ICPKSS_MAINT.PR_GET_REDEM_AMT(L_REDEM_AMT);
          ICPKS_BOD.G_PENALTY := L_REDEM_AMT;
        
          DBG('l_Redem_Amt:' || L_REDEM_AMT);
        END IF;
      
      END IF;
    
      DBG('g_penalty:' || ICPKS_BOD.G_PENALTY);
    
      FOR X IN CR_ICTB(P_BRN, P_ACC, P_PROD) LOOP
        ICPKSS_UTIL.DBG('Inside loop for ictb acc pr ssss');
      
        L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(P_PROD);
        DBG('l_ude_ccy-->' || L_PR_INT.UDE_CCY);
        ICPKSS_CALC.G_PROD_REC.UDE_CCY := L_PR_INT.UDE_CCY;
      
        DBG('icpkss_calc.g_prod_rec.ude_ccy-->' ||
            ICPKSS_CALC.G_PROD_REC.UDE_CCY);
      
        CNT                                 := CNT + 1;
        ICPKSS_CALC.G_ICTB_ACC_PR.BRN       := X.BRN;
        ICPKSS_CALC.G_ICTB_ACC_PR.ACC       := X.ACC;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD      := X.PROD;
        ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT := P_START_DATE;
        DBG('here for full' || ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT);
        ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT         := X.GC_MAP_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT      := X.LAST_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT       := X.LAST_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT       := X.NEXT_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT      := X.LAST_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := X.NEXT_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT  := X.LAST_SCHD_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH           := X.INC_MTH;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT  := X.NEXT_SCHD_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT     := X.FIRST_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := X.NEXT_SCHD_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE         := X.PROD_TYPE;
        ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR          := X.HAS_ACCR;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT      := X.NEXT_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR         := X.PROD_ACCR;
        ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT      := X.DEFER_LIQ_DT;
        ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS        := X.ACLASS;
        ICPKSS_CALC.G_CUST_ACC.CCY                  := X.CCY;
      
        ICPKS_TEST.TB_ACC(1) := ICPKSS_CALC.G_ICTB_ACC_PR.ACC;
        ICPKS_TEST.TB_BRN(1) := ICPKSS_CALC.G_ICTB_ACC_PR.BRN;
        ICPKS_TEST.TB_PROD(1) := ICPKSS_CALC.G_ICTB_ACC_PR.PROD;
        ICPKS_TEST.TB_SC_MAP_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT;
        ICPKS_TEST.TB_GC_MAP_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT;
        ICPKS_TEST.TB_LAST_CALC_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT;
        ICPKS_TEST.TB_LAST_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT;
        ICPKS_TEST.TB_NEXT_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT;
        ICPKS_TEST.TB_LAST_ACCR_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT;
        ICPKS_TEST.TB_NEXT_ACCR_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT;
        ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT;
        ICPKS_TEST.TB_INC_MTH(1) := ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH;
        ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT;
        ICPKS_TEST.TB_FIRST_CALC_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT;
        ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT;
        ICPKS_TEST.TB_PROD_TYPE(1) := ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE;
        ICPKS_TEST.TB_HAS_ACCR(1) := ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR;
        ICPKS_TEST.TB_NEXT_CALC_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT;
        ICPKS_TEST.TB_PROD_ACCR(1) := ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR;
        ICPKS_TEST.TB_DEFER_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT;
      
      END LOOP;
    
      ICPKS_SDE.PR_PREPARE_SDE(ICPKSS_CALC.G_ICTB_ACC_PR.BRN,
                               ICPKSS_CALC.G_ICTB_ACC_PR.ACC,
                               ICPKSS_CALC.G_CUST_ACC.CCY,
                               1,
                               1);
    
      ICPKS_UDE.PR_PREPARE_GC(ICPKSS_CALC.G_ICTB_ACC_PR.BRN,
                              ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS,
                              ICPKSS_CALC.G_CUST_ACC.CCY,
                              ICPKSS_CALC.G_ICTB_ACC_PR.PROD,
                              ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT,
                              GLOBAL.APPLICATION_DATE,
                              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT);
    
      ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);
      ICPKS_TEST.PR_CACHE_PROD(P_PROD, NULL);
    
      ICPKSS_CALC.SET_ACC_DETAILS(P_BRN, P_ACC);
    
      DBG('pkg_penalty_apply:' || PKG_PENALTY_APPLY);
      IF PKG_PENALTY_APPLY = 0 THEN
        PR_WAIVE_PENALTY;
      ELSE
        DBG('icpkss_calc.g_penalty:' || ICPKSS_CALC.G_PENALTY);
        PR_RESET_PENALTY;
      END IF;
    
      C := DBMS_SQL.OPEN_CURSOR;
    
      SSQL := 'DECLARE l_tb_icent icpkss_test.rec_icent; BEGIN ' ||
              DBMS_ASSERT.SIMPLE_SQL_NAME('C3GF#_IIPR1_' || P_RULE) ||
              '(:p_brn,:p_acc,:p_prod,TO_DATE(:p_start_date,' ||
              Q('YYYYMMDD') || '),TO_DATE(:p_end_date,' || Q('YYYYMMDD') ||
              '),l_tb_icent); END;';
    
      DBG('About To Parse for TD broken calc ' || SSQL);
    
      DBMS_SQL.PARSE(C, SSQL, DBMS_SQL.NATIVE);
    
      DBMS_SQL.BIND_VARIABLE(C, 'p_brn', P_BRN);
      DBMS_SQL.BIND_VARIABLE(C, 'p_acc', P_ACC);
      DBMS_SQL.BIND_VARIABLE(C, 'p_prod', P_PROD);
      DBMS_SQL.BIND_VARIABLE(C,
                             'p_start_date',
                             TO_CHAR(P_START_DATE, 'YYYYMMDD'));
      DBMS_SQL.BIND_VARIABLE(C,
                             'p_end_date',
                             TO_CHAR(P_END_DATE, 'YYYYMMDD'));
    
      DBG('About To Execute for TD broken calc ' || SSQL);
    
      I := DBMS_SQL.EXECUTE(C);
    
      DBMS_SQL.CLOSE_CURSOR(C);
    
    EXCEPTION
      WHEN OTHERS THEN
        IF DBMS_SQL.IS_OPEN(C) THEN
          DBMS_SQL.CLOSE_CURSOR(C);
        END IF;
        P_ERR_CODE  := 'IC-MU0007';
        P_ERR_PARAM := '';
        DBG('failed in C3GF#_IIPR1_ ' || SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('coming out of fn_do_memo_accrual');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in STPKS_TD_REDEMPTION.FN_DO_MEMO_ACCRUAL --->' ||
          SQLERRM);
      P_ERR_CODE  := 'IC-MU0007';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_DO_MEMO_ACCRUAL;

  FUNCTION FN_PC_CLOSE_TD(P_BRANCH      IN ICTMS_TD_DETAILS.BRN%TYPE,
                          P_ACC         IN ICTMS_TD_DETAILS.ACC%TYPE,
                          P_ERROR_CODE  IN OUT VARCHAR2,
                          P_ERROR_PARAM IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
    L_LCY_BAL STTM_CUST_ACCOUNT.LCY_CURR_BALANCE%TYPE;
    L_CCY     VARCHAR2(3);
  BEGIN
    DBG('Inside function icpks_fcj_icdredmn.fn_pc_close_td');
    DBG('Brn:' || P_BRANCH);
    DBG('p_acc:' || P_ACC);
    SAVEPOINT START_CLOSE_TD;
  
    DBG('before the select statement of checking LCY balance');
  
    SELECT LCY_CURR_BALANCE, CCY
      INTO L_LCY_BAL, L_CCY
      FROM STTMS_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ACC
       AND BRANCH_CODE = NVL(P_BRANCH, GLOBAL.CURRENT_BRANCH);
  
    DBG('l_lcy_bal-->' || L_LCY_BAL);
    DBG('l_ccy-->' || L_CCY);
  
    IF L_LCY_BAL <> 0 AND L_CCY <> GLOBAL.LCY THEN
      DBG('Before calling acpks_reval.fn_doReval');
    
      IF NOT ACPKS_REVAL.FN_DOREVAL(GLOBAL.CURRENT_BRANCH,
                                    GLOBAL.APPLICATION_DATE,
                                    '',
                                    GLOBAL.LCY,
                                    'N',
                                    'S',
                                    'ACC',
                                    P_ACC,
                                    GLOBAL.USER_ID,
                                    P_ERROR_CODE,
                                    P_ERROR_PARAM) THEN
      
        DBG('Revaluation failed for the account:' || P_ACC);
        DBG('Error details:' || P_ERROR_CODE || '~' || P_ERROR_PARAM);
        RETURN FALSE;
      
      END IF;
    END IF;
  
    DBG('Update the status for sttms_cust_account');
    IF L_LCY_BAL = 0 THEN
      UPDATE STTMS_CUST_ACCOUNT A
         SET A.RECORD_STAT      = 'C',
             A.MOD_NO           = NVL(A.MOD_NO, 0) + 1,
             A.AUTH_STAT        = 'A',
             A.MAKER_ID         = GLOBAL.USER_ID,
             A.MAKER_DT_STAMP   = FN_MNTSTAMP,
             A.CHECKER_ID       = GLOBAL.USER_ID,
             A.CHECKER_DT_STAMP = FN_MNTSTAMP
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRANCH
            
         AND EXISTS (SELECT 1
                FROM STTM_ACCOUNT_BALANCE Y
               WHERE Y.CUST_AC_NO = A.CUST_AC_NO
                 AND Y.CUST_AC_BRN = A.BRANCH_CODE
                 AND NVL(Y.ACY_WITHDRAWABLE_BAL, 0) = 0);
    
      IF SQL%ROWCOUNT > 0 THEN
        DBG('Update sttb_account as well');
        UPDATE STTBS_ACCOUNT
           SET AC_GL_REC_STATUS = 'C'
         WHERE BRANCH_CODE = P_BRANCH
           AND AC_GL_NO = P_ACC;
        DBG('Going to update ictb_acc_pr, Since TD got closed');
        UPDATE ICTBS_ACC_PR
           SET NEXT_CALC_DT      = NULL,
               NEXT_ACCR_DT      = NULL,
               NEXT_SCHD_LIQ_DT  = NULL,
               NEXT_SCHD_ACCR_DT = NULL,
               NEXT_LIQ_DT       = NULL
         WHERE ACC = P_ACC
           AND BRN = P_BRANCH;
      END IF;
    
      DBG('No of rows updated:' || SQL%ROWCOUNT);
      DBG('Before calling Cspks_Req_Utils.Fn_Maint_Log');
    
    END IF;
    DBG('End fn_close_td');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK TO START_CLOSE_TD;
      P_ERROR_CODE := 'TD-RED-32';
      DBG('In When Others of fn_close_td for::' || SQLERRM);
      RETURN FALSE;
  END FN_PC_CLOSE_TD;

  FUNCTION FN_VALIDATE_REDEMINTPAYOUT(P_ICDREDMN     IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                                      P_ERR_CODE     IN OUT VARCHAR2,
                                      P_ERROR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_REDM_INT_PAYOUT ICTM_ACC.REDM_INT_PAYOUT%TYPE;
    L_ACC_CLASS_REC   STTM_ACCOUNT_CLASS%ROWTYPE;
    L_PROD            ICTM_ACC_PR.PROD%TYPE;
    L_PAYMENT_METHOD  ICTMS_PR_INT.PAYMENT_METHOD%TYPE;
    L_CUST_ACC_REC    STTM_CUST_ACCOUNT%ROWTYPE;
  BEGIN
    DBG('Inside fn_validate_redemintpayout');
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.BRN_CODE,
                                     P_ICDREDMN.AC_NO,
                                     L_CUST_ACC_REC) THEN
      DBG('Failed in select from sttm_cust_account');
    END IF;
    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_CUST_ACC_REC.ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  P_ERR_CODE);
    BEGIN
      SELECT REDM_INT_PAYOUT
        INTO L_REDM_INT_PAYOUT
        FROM ICTM_ACC
       WHERE ACC = P_ICDREDMN.AC_NO
         AND BRN = P_ICDREDMN.BRN_CODE;
      DBG('l_redm_int_payout' || L_REDM_INT_PAYOUT);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in getting the data' || SQLERRM);
    END;
  
    BEGIN
      SELECT PROD
        INTO L_PROD
        FROM ICTMS_ACC_PR
       WHERE ACC = P_ICDREDMN.AC_NO
         AND BRN = P_ICDREDMN.BRN_CODE;
      DBG('l_prod--->' || L_PROD);
    EXCEPTION
      WHEN OTHERS THEN
        L_PROD := NULL;
    END;
  
    BEGIN
      SELECT PAYMENT_METHOD
        INTO L_PAYMENT_METHOD
        FROM ICTMS_PR_INT
       WHERE PRODUCT_CODE = L_PROD;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('In no data found of select for Payment method');
        L_PAYMENT_METHOD := 'N';
      WHEN OTHERS THEN
        DBG('In WOT of select for Payment method');
        L_PAYMENT_METHOD := 'N';
    END;
    DBG('l_payment_method--->' || L_PAYMENT_METHOD);
    DBG(' p_icdredmn.redem_int_payout -->' || P_ICDREDMN.REDEM_INT_PAYOUT);
    DBG('l_acc_class_rec.rd_flag-->' || L_ACC_CLASS_REC.RD_FLAG);
    DBG('l_acc_class_rec.mudarabah_acc_class--->' ||
        L_ACC_CLASS_REC.MUDARABAH_ACC_CLASS);
    IF (L_REDM_INT_PAYOUT <> P_ICDREDMN.REDEM_INT_PAYOUT) AND
       (L_ACC_CLASS_REC.RD_FLAG = 'Y' OR
       NVL(L_ACC_CLASS_REC.MUDARABAH_ACC_CLASS, 'N') = 'Y' OR
       L_PAYMENT_METHOD = 'D' OR P_ICDREDMN.REDEMPTION_MODE = 'Y') THEN
      DBG('Redemption Interest payout cannot be modified for Partial Redemption or Islamic TDs or RDs or Discounted TDs');
      P_ICDREDMN.REDEM_INT_PAYOUT := L_REDM_INT_PAYOUT;
    
      P_ERR_CODE     := 'IC-REDMN-25';
      P_ERROR_PARAMS := NULL;
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERROR_PARAMS);
      RETURN FALSE;
    
    END IF;
    DBG('Returning success from fn_validate_redemintpayout');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in exception');
      RETURN FALSE;
  END;

  FUNCTION FN_ADDPAYIN_DEFAULT(P_ICDREDMN      IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                               P_ADDNLPAYINREC IN OUT TY_TB_ADDNLPAYINDETAILS,
                               P_ERR_CODE      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_GL_CODE       STTMS_PAYIN_MODE.GL_CODE%TYPE;
    L_SAVACC_CNT    NUMBER := 0;
    L_CCY_RES       VARCHAR2(1);
    L_CCY_S         VARCHAR2(3);
    L_LOCAL_CCY     VARCHAR2(3);
    L_COUNT         NUMBER := 0;
    L_CNT           NUMBER := 0;
    L_ROW_AMT       NUMBER(22, 3) := 0;
    L_TOTAL         NUMBER(22, 3) := 0;
    L_BC_CNT        NUMBER := 0;
    L_PC_CNT        NUMBER := 0;
    L_TD_CNT        NUMBER := 0;
    L_GL_CNT        NUMBER := 0;
    L_CASH_CNT      NUMBER := 0;
    L_INSEQNO       NUMBER := 1;
    L_OUTSEQNO      NUMBER := 1;
    L_BC_INT_CNT    NUMBER := 0;
    L_PC_INT_CNT    NUMBER := 0;
    L_GL_INT_CNT    NUMBER := 0;
    L_CASH_INT_CNT  NUMBER := 0;
    L_CASH_GL       DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_WF_ROW        STTMS_BRANCH_WF_DEF_MASTER%ROWTYPE;
    L_ONCE_AUTH     STTM_CUST_ACCOUNT.ONCE_AUTH%TYPE;
    L_TD_AMOUNT     ICTM_TD_DETAILS.TD_AMOUNT%TYPE;
    L_MAT_DATE      ICTM_ACC.MATURITY_DATE%TYPE;
    L_SECTORCODE    DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT       DATE;
    L_DRVALDT       DATE;
    L_LATE_CLEARING VARCHAR2(10);
    L_RESULT1       VARCHAR2(1);
    L_ERR_CODE      ERTB_MSGS.ERR_CODE%TYPE;
    P_ERR_FLAG      VARCHAR2(1);
    P_ERR_PARAM     VARCHAR2(1000);
    L_CCY           VARCHAR2(3);
    L_CUSTOMER      STTM_CUST_ACCOUNT.CUST_NO%TYPE;
  
    L_PROD     ICTB_ACC_PR.PROD%TYPE;
    L_TRN_CODE CSTM_PRODUCT_EVENT_ACCT_ENTRY.TRANSACTION_CODE%TYPE;
    TRNCODEREC STTM_TRN_CODE%ROWTYPE;
  
    L_AC_OR_GL STTB_ACCOUNT.AC_OR_GL%TYPE;
  BEGIN
    DBG('Start of fn_addpayin_default');
    DBG('First checking for addnl payin count :' || P_ADDNLPAYINREC.COUNT);
    IF P_ADDNLPAYINREC.COUNT > 0 THEN
      DBG('looping for payin details');
      FOR I IN P_ADDNLPAYINREC.FIRST .. P_ADDNLPAYINREC.LAST LOOP
        DBG('payin loop count :' || I);
        DBG('payin Seq cnt :' || L_INSEQNO);
        P_ADDNLPAYINREC(I).BRN := P_ICDREDMN.BRN_CODE;
        P_ADDNLPAYINREC(I).ACC := P_ICDREDMN.AC_NO;
        P_ADDNLPAYINREC(I).CCY := P_ICDREDMN.CCY;
        P_ADDNLPAYINREC(I).SEQNO := I;
        P_ADDNLPAYINREC(I).REDEM_REF_NO := P_ICDREDMN.REDEM_REF_NO;
        DBG('multimode_tdamount :' || P_ADDNLPAYINREC(I)
            .MULTIMODE_TDAMOUNT);
      
        IF P_ADDNLPAYINREC(I).MULTIMODE_PAYOPT = 'S' THEN
          BEGIN
            SELECT AC_OR_GL
              INTO L_AC_OR_GL
              FROM STTB_ACCOUNT
             WHERE AC_GL_NO = P_ADDNLPAYINREC(I).MULTIMODE_TDOFFSET_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Record not found in sttb_account');
          END;
          DBG('l_ac_or_gl-->' || L_AC_OR_GL);
          IF L_AC_OR_GL = 'G' THEN
            P_ERR_CODE := 'TD-VALS-004';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;
      
        IF P_ADDNLPAYINREC(I).MULTIMODE_TDAMOUNT IS NULL THEN
          DBG('multimode_percentage :' || P_ADDNLPAYINREC(I)
              .MULTIMODE_PERCENTAGE);
        
          IF P_ADDNLPAYINREC(I).MULTIMODE_PERCENTAGE IS NOT NULL THEN
          
            IF P_ADDNLPAYINREC(I).MULTIMODE_PERCENTAGE = 0 THEN
              DBG('Additional payin multimode percentage cannot be 0');
              P_ERR_CODE := 'TD-DDEP-32';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            END IF;
          
            IF I = P_ADDNLPAYINREC.COUNT THEN
              P_ADDNLPAYINREC(I).MULTIMODE_TDAMOUNT := P_ICDREDMN.ADDITIONAL_AMT -
                                                       L_TOTAL;
            ELSE
              L_ROW_AMT := (P_ADDNLPAYINREC(I)
                           .MULTIMODE_PERCENTAGE * P_ICDREDMN.ADDITIONAL_AMT) /
                           100.00;
            
              DBG('p_addnlpayinrec(i).MULTIMODE_PAYOPT ' || P_ADDNLPAYINREC(I)
                  .MULTIMODE_PAYOPT);
              DBG('p_addnlpayinrec(i).MULTIMODE_TDOFFSET_CCY ' || P_ADDNLPAYINREC(I)
                  .MULTIMODE_TDOFFSET_CCY);
              DBG('l_row_amt--->' || L_ROW_AMT);
              IF P_ADDNLPAYINREC(I).MULTIMODE_PAYOPT = 'S' THEN
                SELECT CCY
                  INTO L_CCY
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_ADDNLPAYINREC(I)
                      .MULTIMODE_TDOFFSET_ACC
                   AND BRANCH_CODE = P_ADDNLPAYINREC(I)
                      .MULTIMODE_OFFSET_BRN;
              ELSE
                L_CCY := P_ICDREDMN.CCY;
              END IF;
              DBG('l_ccy ' || L_CCY);
              IF NOT CYPKSS.FN_AMT_ROUND(L_CCY, L_ROW_AMT, L_ROW_AMT) THEN
                DBG('Failed in doing Round OFF of amount to offset currency');
              END IF;
              DBG('After Round OFF l_tdpayout_rec.redmamt  ' || L_ROW_AMT);
            
              L_TOTAL := L_TOTAL + L_ROW_AMT;
              P_ADDNLPAYINREC(I).MULTIMODE_TDAMOUNT := L_ROW_AMT;
            END IF;
          
          ELSE
            DBG('Both Percentage or Payin Amount cannot be null');
            P_ERR_CODE := 'ST-ACC-210';
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          
          END IF;
        END IF;
        DBG('l_total :' || L_TOTAL);
        DBG('multimode_tdamount for ' || I || 'row is  :' || P_ADDNLPAYINREC(I)
            .MULTIMODE_TDAMOUNT);
      
        IF P_ADDNLPAYINREC(I).MULTIMODE_PAYOPT <> 'S' THEN
          DBG('Payin Option: ' || P_ADDNLPAYINREC(I).MULTIMODE_PAYOPT);
          IF P_ADDNLPAYINREC(I).MULTIMODE_PAYOPT = 'Q' THEN
            DBG('payin option is by cheque');
          
            CSPKSS_CLG_SERV.PR_BREAK_ROUTING_NO(P_ADDNLPAYINREC(I)
                                                .ROUTING_NO,
                                                L_SECTORCODE,
                                                P_ADDNLPAYINREC(I)
                                                .CLG_BANK_CODE,
                                                P_ADDNLPAYINREC(I)
                                                .CLG_BRANCH_CODE);
          
            BEGIN
              SELECT CUST_NO
                INTO L_CUSTOMER
                FROM STTMS_CUST_ACCOUNT
               WHERE BRANCH_CODE = P_ICDREDMN.BRN_CODE
                 AND CUST_AC_NO = P_ICDREDMN.AC_NO;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
            IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(P_ADDNLPAYINREC        (I)
                                                          .CLG_BANK_CODE,
                                                          P_ADDNLPAYINREC        (I)
                                                          .CLG_BRANCH_CODE,
                                                          L_CUSTOMER,
                                                          P_ICDREDMN.BRN_CODE,
                                                          P_ADDNLPAYINREC        (I)
                                                          .CLG_PRODUCT_CODE,
                                                          P_ICDREDMN.CCY,
                                                          NULL,
                                                          L_SECTORCODE,
                                                          L_CRVALDT,
                                                          L_DRVALDT,
                                                          L_LATE_CLEARING,
                                                          L_ERR_CODE,
                                                          GLOBAL.APPLICATION_DATE,
                                                          'N',
                                                          'N')
            
             THEN
              DBG('failed to get the Value date');
              P_ERR_CODE := 'ST-ACC-243';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
            
            ELSE
              IF CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                          P_ICDREDMN.BRN_CODE,
                                          L_CRVALDT,
                                          L_RESULT1) = TRUE THEN
                DBG('Cheque clearing date is holiday ' || L_RESULT1);
                IF NVL(L_RESULT1, '*') = 'H' THEN
                  L_CRVALDT := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                            P_ICDREDMN.BRN_CODE,
                                                            L_CRVALDT,
                                                            'N');
                  DBG('Working date --> ' || L_CRVALDT);
                END IF;
              END IF;
              DBG('value date is the account opening date' || L_CRVALDT);
              P_ADDNLPAYINREC(I).CHQ_AVL_DATE := L_CRVALDT;
            
            END IF;
          END IF;
        END IF;
      
      END LOOP;
    ELSE
      DBG('No payin details entered');
      P_ERR_FLAG := -1;
      P_ERR_CODE := 'ST-ACC-197';
      OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
    
    END IF;
    DBG('End of fn_addpayin_default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in exception');
      RETURN FALSE;
  END FN_ADDPAYIN_DEFAULT;

END ICPKS_FCJ_ICDREDMN;
