CREATE OR REPLACE

PACKAGE BODY Stpks_Stdcusac_Utils_2 IS

  L_ACCOUNT_OPENING_CHARGES STTMS_ACCLS_CCY_BALANCES.ACCOUNT_OPENING_CHARGES%TYPE;
  L_SOURCE                  VARCHAR2(20);
  G_BALREC                  STTM_ACCOUNT_BALANCE%ROWTYPE;

  G_SKIP_KERNEL  BOOLEAN := FALSE;
  G_SKIP_CLUSTER BOOLEAN := FALSE;
  G_SKIP_CUSTOM  BOOLEAN := FALSE;

  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;

  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;

  PROCEDURE PR_SET_SKIP_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := TRUE;
  END PR_SET_SKIP_CLUSTER;

  PROCEDURE PR_SET_ACTIVATE_CLUSTER IS
  BEGIN
    G_SKIP_CLUSTER := FALSE;
  END PR_SET_ACTIVATE_CLUSTER;

  FUNCTION FN_SKIP_CUSTOM RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_KERNEL, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CUSTOM THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CUSTOM;
    END IF;
  END FN_SKIP_CUSTOM;

  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;

  FUNCTION FN_SKIP_CLUSTER RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN TRUE;
    ELSIF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_CLUSTER THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_CLUSTER;
    END IF;
  END FN_SKIP_CLUSTER;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcusac_utils_2 ==>' || P_MSG;
    DEBUG.PR_DEBUG('ST', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_PICKUP_LOCATION(P_ACC      IN VARCHAR2,
                              P_BRN      IN VARCHAR2,
                              P_CUST     IN VARCHAR,
                              P_MSG_TYPE IN VARCHAR2,
                              P_MODULE   IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION FN_OD_ACCOUNT_REINS_PROCESS(P_ACCOUNT_UTILIZN_TYPE IN OUT ELPKS.TY_ACCCOUNT_UTIL_MASTER,
                                       P_UTILIZN_TYPE         IN OUT ELPKS.TY_UTILS,
                                       P_ERROR                IN OUT VARCHAR2,
                                       P_ERROR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    TYPE TB_TY_LINKAGES IS TABLE OF STTM_CUST_ACCOUNT_LINKAGES%ROWTYPE INDEX BY BINARY_INTEGER;
    TY_ACCCOUNT_LINKAGE   TB_TY_LINKAGES;
    TY_ACCCOUNT_UTIL      ELPKS_MULTI_UTIL_SERVICE.TY_TB_GETB_UTILS;
    TY_ACCCOUNT_UTIL_COPY ELPKS_MULTI_UTIL_SERVICE.TY_TB_GETB_UTILS;
    L_UTILIZN_TYPE        ELPKS.TY_UTILS;
    L_LIAB_ID             NUMBER;
    L_LIMIT_ID            NUMBER;
    L_TOT_AMOUNT          NUMBER := 0;
    L_JV_TOT_AMOUNT       NUMBER := 0;
    L_FOUND               BOOLEAN;
    K                     NUMBER := 1;
    L_JOINT_VENTURE       VARCHAR2(1);
  BEGIN
  
    SELECT *
      BULK COLLECT
      INTO TY_ACCCOUNT_LINKAGE
      FROM STTM_CUST_ACCOUNT_LINKAGES
     WHERE CUST_AC_NO = P_ACCOUNT_UTILIZN_TYPE.REF_NO;
  
    IF ELPKS.ELCM_SETUP_MODE = 'E' THEN
    
      SELECT *
        BULK COLLECT
        INTO TY_ACCCOUNT_UTIL
        FROM GETB_UTILS
       WHERE USER_REFNO = P_ACCOUNT_UTILIZN_TYPE.REF_NO
         AND UTIL_STAT = 'A'
         AND LIMIT_TYPE <> 'L'
         AND UTIL_AMT <> 0
         AND AMT_TAG <> 'ACCRD. INT';
    
    ELSE
    
      P_UTILIZN_TYPE.UTILS_MASTER.REF_NO := P_ACCOUNT_UTILIZN_TYPE.REF_NO;
      P_UTILIZN_TYPE.UTILS_DETAILS(1).ACTION := 'Q';
    
      IF NOT ELPKS_MULTI_UTIL_SERVICE.FN_UTILS_QUERY(P_UTILIZN_TYPE,
                                                     TY_ACCCOUNT_UTIL) THEN
        DBG('Failed in Fn_Utils_Query...');
        RETURN FALSE;
      END IF;
    END IF;
  
    FOR J IN 1 .. TY_ACCCOUNT_UTIL.COUNT LOOP
    
      BEGIN
        SELECT NVL(JOINT_VENTURE, 'N')
          INTO L_JOINT_VENTURE
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO = TY_ACCCOUNT_UTIL(J).CUSTOMER_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No record for JV Customers ');
          L_TOT_AMOUNT := 0;
      END;
    
      IF L_JOINT_VENTURE = 'N' THEN
        L_TOT_AMOUNT := L_TOT_AMOUNT + TY_ACCCOUNT_UTIL(J).UTIL_AMT;
      ELSE
        L_JV_TOT_AMOUNT := L_JV_TOT_AMOUNT + TY_ACCCOUNT_UTIL(J).UTIL_AMT;
      END IF;
    
    END LOOP;
  
    DBG('Final Total Amount : ' || L_TOT_AMOUNT);
  
    IF L_TOT_AMOUNT = 0 THEN
      L_TOT_AMOUNT := L_JV_TOT_AMOUNT;
    END IF;
  
    IF NVL(L_TOT_AMOUNT, 0) = 0 AND L_JV_TOT_AMOUNT = 0 THEN
      DBG('Since the Amount is zero in ELCM.So No need to reinsiate');
      RETURN TRUE;
    END IF;
  
    DBG('Total JV Amount : ' || L_JV_TOT_AMOUNT);
    DBG('Total Amount    : ' || L_TOT_AMOUNT);
  
    L_UTILIZN_TYPE.UTILS_MASTER.REF_NO     := P_ACCOUNT_UTILIZN_TYPE.REF_NO;
    L_UTILIZN_TYPE.UTILS_MASTER.TRANS_DATE := P_ACCOUNT_UTILIZN_TYPE.TRANS_DATE;
    L_UTILIZN_TYPE.UTILS_MASTER.TRANS_AMT  := L_TOT_AMOUNT;
    L_UTILIZN_TYPE.UTILS_MASTER.TRANS_CCY  := P_ACCOUNT_UTILIZN_TYPE.TRANS_CCY;
    L_UTILIZN_TYPE.UTILS_MASTER.TRANS_BRN  := P_ACCOUNT_UTILIZN_TYPE.TRANS_BRN;
    L_UTILIZN_TYPE.UTILS_MASTER.TRANS_PRD  := P_ACCOUNT_UTILIZN_TYPE.TRANS_PRD;
    L_UTILIZN_TYPE.UTILS_MASTER.MODULE     := P_ACCOUNT_UTILIZN_TYPE.MODULE;
  
    FOR J IN 1 .. TY_ACCCOUNT_UTIL.COUNT LOOP
      DBG('*********************Utilization Details*********************');
      DBG('User Ref No : ' || TY_ACCCOUNT_UTIL(J).USER_REFNO);
      DBG('Customer No : ' || TY_ACCCOUNT_UTIL(J).CUSTOMER_NO);
      DBG('Amt Tag     : ' || TY_ACCCOUNT_UTIL(J).AMT_TAG);
      DBG('Limit Type  : ' || TY_ACCCOUNT_UTIL(J).LIMIT_TYPE);
      DBG('Limit id    : ' || TY_ACCCOUNT_UTIL(J).LIMIT_ID);
      DBG('Utilz Amt   : ' || TY_ACCCOUNT_UTIL(J).UTIL_AMT);
      DBG('*************************************************************');
    END LOOP;
  
    FOR J IN 1 .. TY_ACCCOUNT_LINKAGE.COUNT LOOP
      DBG('*********************Utilization Details*********************');
      DBG('CUST_AC_NO      : ' || TY_ACCCOUNT_LINKAGE(J).CUST_AC_NO);
      DBG('Customer No     : ' || TY_ACCCOUNT_LINKAGE(J).CUSTOMER_NO);
      DBG('Limit Type      : ' || TY_ACCCOUNT_LINKAGE(J).LINKAGE_TYPE);
      DBG('Limit id        : ' || TY_ACCCOUNT_LINKAGE(J).LINKED_REF_NO);
      DBG('Limit Percent   : ' || TY_ACCCOUNT_LINKAGE(J)
          .LINKAGE_PERCENTAGE);
      DBG('*************************************************************');
    END LOOP;
  
    FOR I IN 1 .. TY_ACCCOUNT_LINKAGE.COUNT LOOP
    
      SELECT LIAB_ID
        INTO L_LIAB_ID
        FROM GETM_LIAB_CUST
       WHERE CUSTOMER_NO = TY_ACCCOUNT_LINKAGE(I).CUSTOMER_NO;
    
      DBG('Liab_Id in Account Linkages : ' || L_LIAB_ID);
    
      IF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'F' THEN
        BEGIN
          SELECT ID
            INTO L_LIMIT_ID
            FROM GETM_FACILITY
           WHERE LIAB_ID = L_LIAB_ID
             AND LINE_CODE || LINE_SERIAL = TY_ACCCOUNT_LINKAGE(I)
                .LINKED_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      ELSIF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'C' THEN
        BEGIN
          SELECT ID
            INTO L_LIMIT_ID
            FROM GETM_COLLAT
           WHERE LIAB_ID = L_LIAB_ID
             AND COLLATERAL_CODE = TY_ACCCOUNT_LINKAGE(I).LINKED_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      
      ELSIF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'P' THEN
        BEGIN
          SELECT ID
            INTO L_LIMIT_ID
            FROM GETM_POOL
           WHERE LIAB_ID = L_LIAB_ID
             AND POOL_CODE = TY_ACCCOUNT_LINKAGE(I).LINKED_REF_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      END IF;
      DBG('Limit Type in Account Linkages : ' || TY_ACCCOUNT_LINKAGE(I)
          .LINKAGE_TYPE);
      DBG('Limit_Id in Account Linkages   : ' || L_LIMIT_ID);
    
      FOR J IN 1 .. TY_ACCCOUNT_UTIL.COUNT LOOP
        L_FOUND := FALSE;
        DBG('Final Comp Acc : ' || TY_ACCCOUNT_LINKAGE(I).CUST_AC_NO || TY_ACCCOUNT_LINKAGE(I)
            .CUSTOMER_NO || TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE ||
            L_LIAB_ID || L_LIMIT_ID);
        DBG('Final Comp uTIL : ' || TY_ACCCOUNT_UTIL(J).USER_REFNO || TY_ACCCOUNT_UTIL(J)
            .CUSTOMER_NO || TY_ACCCOUNT_UTIL(J).LIMIT_TYPE || TY_ACCCOUNT_UTIL(J)
            .LIAB_ID || TY_ACCCOUNT_UTIL(J).LIMIT_ID);
      
        IF TY_ACCCOUNT_LINKAGE(I)
         .CUST_AC_NO = TY_ACCCOUNT_UTIL(J).USER_REFNO AND TY_ACCCOUNT_LINKAGE(I)
           .CUSTOMER_NO = TY_ACCCOUNT_UTIL(J).CUSTOMER_NO AND TY_ACCCOUNT_LINKAGE(I)
           .LINKAGE_TYPE = TY_ACCCOUNT_UTIL(J).LIMIT_TYPE AND
            L_LIAB_ID = TY_ACCCOUNT_UTIL(J).LIAB_ID AND
            L_LIMIT_ID = TY_ACCCOUNT_UTIL(J).LIMIT_ID THEN
          L_FOUND := TRUE;
          DBG('Linkage already existing.So we have to Alter');
          EXIT;
        ELSE
          L_FOUND := FALSE;
        END IF;
      END LOOP;
    
      IF L_FOUND THEN
        DBG('Alter Utils');
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . CUSTOMER_NO := TY_ACCCOUNT_LINKAGE(I)
                                                         .CUSTOMER_NO;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . LINKAGE_TYPE := TY_ACCCOUNT_LINKAGE(I)
                                                          .LINKAGE_TYPE;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . LINKAGE_REFNO := TY_ACCCOUNT_LINKAGE(I)
                                                           .LINKED_REF_NO;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . AMT_TAG := P_ACCOUNT_UTILIZN_TYPE.AMT_TAG;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . TRANS_CCY := P_ACCOUNT_UTILIZN_TYPE.TRANS_CCY;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . TRANS_PERCENTAGE := TY_ACCCOUNT_LINKAGE(I)
                                                              .LINKAGE_PERCENTAGE;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . IS_ACCOUNT := P_ACCOUNT_UTILIZN_TYPE.IS_ACCOUNT;
        L_UTILIZN_TYPE.UTILS_DETAILS(K).ACTION := 'A';
        K := K + 1;
      ELSE
        DBG('New Utils');
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . CUSTOMER_NO := TY_ACCCOUNT_LINKAGE(I)
                                                         .CUSTOMER_NO;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . LINKAGE_TYPE := TY_ACCCOUNT_LINKAGE(I)
                                                          .LINKAGE_TYPE;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . LINKAGE_REFNO := TY_ACCCOUNT_LINKAGE(I)
                                                           .LINKED_REF_NO;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . AMT_TAG := P_ACCOUNT_UTILIZN_TYPE.AMT_TAG;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . TRANS_CCY := P_ACCOUNT_UTILIZN_TYPE.TRANS_CCY;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . TRANS_PERCENTAGE := TY_ACCCOUNT_LINKAGE(I)
                                                              .LINKAGE_PERCENTAGE;
        L_UTILIZN_TYPE.UTILS_DETAILS(K) . IS_ACCOUNT := P_ACCOUNT_UTILIZN_TYPE.IS_ACCOUNT;
        L_UTILIZN_TYPE.UTILS_DETAILS(K).ACTION := 'N';
        K := K + 1;
      END IF;
    
    END LOOP;
  
    FOR J IN 1 .. TY_ACCCOUNT_UTIL.COUNT LOOP
    
      FOR I IN 1 .. TY_ACCCOUNT_LINKAGE.COUNT LOOP
        SELECT LIAB_ID
          INTO L_LIAB_ID
          FROM GETM_LIAB_CUST
         WHERE CUSTOMER_NO = TY_ACCCOUNT_LINKAGE(I).CUSTOMER_NO;
      
        DBG('Liab_Id in Utilz : ' || L_LIAB_ID);
      
        IF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'F' THEN
          BEGIN
            SELECT ID
              INTO L_LIMIT_ID
              FROM GETM_FACILITY
             WHERE LIAB_ID = L_LIAB_ID
               AND LINE_CODE || LINE_SERIAL = TY_ACCCOUNT_LINKAGE(I)
                  .LINKED_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        ELSIF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'C' THEN
          BEGIN
            SELECT ID
              INTO L_LIMIT_ID
              FROM GETM_COLLAT
             WHERE LIAB_ID = L_LIAB_ID
               AND COLLATERAL_CODE = TY_ACCCOUNT_LINKAGE(I).LINKED_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        
        ELSIF TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE = 'P' THEN
          BEGIN
            SELECT ID
              INTO L_LIMIT_ID
              FROM GETM_POOL
             WHERE LIAB_ID = L_LIAB_ID
               AND POOL_CODE = TY_ACCCOUNT_LINKAGE(I).LINKED_REF_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        END IF;
      
        DBG('Limit_Id in Utilz : ' || L_LIMIT_ID);
        DBG('Final Comp Acc : ' || TY_ACCCOUNT_LINKAGE(I).CUST_AC_NO || TY_ACCCOUNT_LINKAGE(I)
            .CUSTOMER_NO || TY_ACCCOUNT_LINKAGE(I).LINKAGE_TYPE ||
            L_LIAB_ID || L_LIMIT_ID);
        DBG('Final Comp UTIL : ' || TY_ACCCOUNT_UTIL(J).USER_REFNO || TY_ACCCOUNT_UTIL(J)
            .CUSTOMER_NO || TY_ACCCOUNT_UTIL(J).LIMIT_TYPE || TY_ACCCOUNT_UTIL(J)
            .LIAB_ID || TY_ACCCOUNT_UTIL(J).LIMIT_ID);
      
        L_FOUND := FALSE;
      
        IF TY_ACCCOUNT_LINKAGE(I)
         .CUST_AC_NO = TY_ACCCOUNT_UTIL(J).USER_REFNO AND TY_ACCCOUNT_LINKAGE(I)
           .CUSTOMER_NO = TY_ACCCOUNT_UTIL(J).CUSTOMER_NO AND TY_ACCCOUNT_LINKAGE(I)
           .LINKAGE_TYPE = TY_ACCCOUNT_UTIL(J).LIMIT_TYPE AND
            L_LIAB_ID = TY_ACCCOUNT_UTIL(J).LIAB_ID AND
            L_LIMIT_ID = TY_ACCCOUNT_UTIL(J).LIMIT_ID THEN
          L_FOUND := TRUE;
          DBG('Utilz Exist in Linkages No need to reverse...');
          EXIT;
        ELSE
          L_FOUND := FALSE;
        END IF;
      END LOOP;
    
      IF NOT L_FOUND THEN
        DBG('Inside Reverse...');
        IF TY_ACCCOUNT_UTIL(J).LIMIT_TYPE = 'F' THEN
          BEGIN
            SELECT LINE_CODE || LINE_SERIAL
              INTO L_UTILIZN_TYPE.UTILS_DETAILS(K).LINKAGE_REFNO
              FROM GETM_FACILITY
             WHERE LIAB_ID = TY_ACCCOUNT_UTIL(J).LIAB_ID
               AND ID = TY_ACCCOUNT_UTIL(J).LIMIT_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        ELSIF TY_ACCCOUNT_UTIL(J).LIMIT_TYPE = 'C' THEN
          BEGIN
            SELECT COLLATERAL_CODE
              INTO L_UTILIZN_TYPE.UTILS_DETAILS(K).LINKAGE_REFNO
              FROM GETM_COLLAT
             WHERE LIAB_ID = TY_ACCCOUNT_UTIL(J).LIAB_ID
               AND ID = TY_ACCCOUNT_UTIL(J).LIMIT_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        
        ELSIF TY_ACCCOUNT_UTIL(J).LIMIT_TYPE = 'P' THEN
          BEGIN
            SELECT POOL_CODE
              INTO L_UTILIZN_TYPE.UTILS_DETAILS(K).LINKAGE_REFNO
              FROM GETM_POOL
             WHERE LIAB_ID = TY_ACCCOUNT_UTIL(J).LIAB_ID
               AND ID = TY_ACCCOUNT_UTIL(J).LIMIT_ID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              NULL;
          END;
        END IF;
        L_UTILIZN_TYPE.UTILS_DETAILS(K).CUSTOMER_NO := TY_ACCCOUNT_UTIL(J)
                                                       .CUSTOMER_NO;
        L_UTILIZN_TYPE.UTILS_DETAILS(K).LINKAGE_TYPE := TY_ACCCOUNT_UTIL(J)
                                                        .LIMIT_TYPE;
      
        L_UTILIZN_TYPE.UTILS_DETAILS(K).AMT_TAG := P_ACCOUNT_UTILIZN_TYPE.AMT_TAG;
        L_UTILIZN_TYPE.UTILS_DETAILS(K).ACTION := 'R';
      
        L_UTILIZN_TYPE.UTILS_DETAILS(K).IS_ACCOUNT := P_ACCOUNT_UTILIZN_TYPE.IS_ACCOUNT;
        DBG('l_utilizn_type.utils_details(' || K || ').Is_Account ' || L_UTILIZN_TYPE.UTILS_DETAILS(K)
            .IS_ACCOUNT);
      
        DBG('l_Utilizn_Type.Utils_Details(k).Linkage_Type' || L_UTILIZN_TYPE.UTILS_DETAILS(K)
            .LINKAGE_TYPE);
        DBG('l_Utilizn_Type.Utils_Details(k).Linkage_Refno' || L_UTILIZN_TYPE.UTILS_DETAILS(K)
            .LINKAGE_REFNO);
      
        IF TY_ACCCOUNT_UTIL(J).LIMIT_TYPE = 'L' THEN
          L_UTILIZN_TYPE.UTILS_DETAILS(K).LINKAGE_REFNO := TY_ACCCOUNT_UTIL(J)
                                                           .LIAB_ID;
          DBG('l_Utilizn_Type.Utils_Details(k).Linkage_Type' || L_UTILIZN_TYPE.UTILS_DETAILS(K)
              .LINKAGE_TYPE);
          DBG('l_Utilizn_Type.Utils_Details(k).Linkage_Refno' || L_UTILIZN_TYPE.UTILS_DETAILS(K)
              .LINKAGE_REFNO);
        END IF;
      
        K := K + 1;
      END IF;
    END LOOP;
    P_UTILIZN_TYPE := L_UTILIZN_TYPE;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in others of Fn_Od_Account_Reins_Process...' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END FN_OD_ACCOUNT_REINS_PROCESS;

  FUNCTION FN_OD_ACCOUNT_PROCESS(P_ACCOUNT_UTILIZN_TYPE IN OUT ELPKS.TY_ACCCOUNT_UTIL_MASTER,
                                 P_ACTION               IN VARCHAR2,
                                 EVENT_CODE             IN VARCHAR2,
                                 ESN                    IN NUMBER,
                                 P_ERROR                IN OUT VARCHAR2,
                                 P_ERROR_PARAMS         IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_UTIL_TYPE           ELPKS.TY_ACCCOUNT_UTIL_MASTER;
    L_COUNT               NUMBER;
    L_MASTER_TXN_ID_MULTI VARCHAR2(100);
    REQUESTMSG            CLOB;
    RESPONSEMSG           CLOB;
    REQUESTBUILDFAILED EXCEPTION;
    L_UTILIZN_TYPE      ELPKS.TY_UTILS;
    L_PRJ_ACC           VARCHAR2(1);
    L_UTILIZN_MAIN_TYPE ELPKS_UTILIZATION_MAIN.TY_UTILS;
    SEND_TXN_ELCM       VARCHAR2(1) := 'Y';
    L_MODULE            VARCHAR2(3) := '';
  BEGIN
    DBG('In pr_process_msg of ELPKS_SPI');
  
    DBG('Action: ' || P_ACTION);
    DBG('Customer ID: ' || P_ACCOUNT_UTILIZN_TYPE.CUSTOMER_NO);
    DBG('Values recieved for ELCM Processing');
    DBG('Customer_No               : ' ||
        P_ACCOUNT_UTILIZN_TYPE.CUSTOMER_NO);
    DBG('Liability_No              : ' ||
        P_ACCOUNT_UTILIZN_TYPE.LIABILITY_NO);
    DBG('Ref_No                    : ' || P_ACCOUNT_UTILIZN_TYPE.REF_NO);
    DBG('Trans_Date                : ' ||
        P_ACCOUNT_UTILIZN_TYPE.TRANS_DATE);
    DBG('Trans_Amt                 : ' || P_ACCOUNT_UTILIZN_TYPE.TRANS_AMT);
    DBG('Trans_Ccy                 : ' || P_ACCOUNT_UTILIZN_TYPE.TRANS_CCY);
    DBG('Trans_Brn                 : ' || P_ACCOUNT_UTILIZN_TYPE.TRANS_BRN);
    DBG('Trans_Prd                 : ' || P_ACCOUNT_UTILIZN_TYPE.TRANS_PRD);
    DBG('Is_Account                : ' ||
        P_ACCOUNT_UTILIZN_TYPE.IS_ACCOUNT);
    DBG('Module                    : ' || P_ACCOUNT_UTILIZN_TYPE.MODULE);
    DBG('Maturity_Date             : ' ||
        P_ACCOUNT_UTILIZN_TYPE.MATURITY_DATE);
    DBG('Event_Code                : ' ||
        P_ACCOUNT_UTILIZN_TYPE.EVENT_CODE);
    DBG('Event_Sq_No               : ' ||
        P_ACCOUNT_UTILIZN_TYPE.EVENT_SQ_NO);
    DBG('Forceprocess              : ' ||
        P_ACCOUNT_UTILIZN_TYPE.FORCEPROCESS);
    DBG('Simulation                : ' ||
        P_ACCOUNT_UTILIZN_TYPE.SIMULATION);
  
    L_MODULE    := P_ACCOUNT_UTILIZN_TYPE.MODULE;
    L_UTIL_TYPE := P_ACCOUNT_UTILIZN_TYPE;
  
    IF L_UTIL_TYPE.REF_NO IS NULL THEN
      OVPKS.PR_APPENDTBL('EL-FCJ-001',
                         'Account No Cannot be Null for Limits');
      RETURN FALSE;
    END IF;
  
    ELPKS_MULTI_UTIL_SERVICE.PKG_IGNORE_OVD := 'Y';
  
    DBG('Inside Porject Utilization Check..');
  
    BEGIN
      SELECT NVL(PROJECT_ACCOUNT, 'N')
        INTO L_PRJ_ACC
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = L_UTIL_TYPE.REF_NO
         AND CUST_NO = L_UTIL_TYPE.CUSTOMER_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed in getting the Account' || L_UTIL_TYPE.REF_NO);
        RETURN FALSE;
    END;
  
    DBG('Project Account : ' || L_PRJ_ACC);
  
    IF L_PRJ_ACC = 'Y' THEN
      DBG('Since Account type is Project Financing not sending Txn to ELCM');
    
      RETURN TRUE;
    END IF;
  
    IF NOT FN_OD_ACCOUNT_REINS_PROCESS(P_ACCOUNT_UTILIZN_TYPE,
                                       L_UTILIZN_TYPE,
                                       P_ERROR,
                                       P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Od_Account_Reins_Process');
      RETURN FALSE;
    END IF;
  
    IF L_UTILIZN_TYPE.UTILS_DETAILS.COUNT = 0 THEN
      DBG('No data is there to process so returning true');
      RETURN TRUE;
    END IF;
  
    DBG('Inside Liability Check...');
    DBG('No of Limit Details...' || L_UTILIZN_TYPE.UTILS_DETAILS.COUNT);
  
    FOR I IN 1 .. L_UTILIZN_TYPE.UTILS_DETAILS.COUNT LOOP
      DBG('Loop Count...' || I);
      IF L_UTILIZN_TYPE.UTILS_DETAILS(I).LIABILITY_NO IS NULL THEN
        DBG('Liability ID is NOT provided so retrieving liabiliy_no for customer: ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
            .CUSTOMER_NO);
      
        IF L_UTILIZN_TYPE.UTILS_DETAILS(I).CUSTOMER_NO IS NOT NULL THEN
        
          BEGIN
            SELECT LIAB_NO
              INTO L_UTILIZN_TYPE.UTILS_DETAILS(I).LIABILITY_NO
              FROM GETM_LIAB
             WHERE ID = (SELECT LIAB_ID
                           FROM GETM_LIAB_CUST
                          WHERE CUSTOMER_NO = L_UTILIZN_TYPE.UTILS_DETAILS(I)
                               .CUSTOMER_NO);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_UTILIZN_TYPE.UTILS_DETAILS(I).LIABILITY_NO := '';
              DBG('libaility is linked to this customer -->' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
                  .CUSTOMER_NO);
              OVPKSS.PR_APPENDTBL('EL-FCJ-001',
                                  'Liability is not Linked to the Customer ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
                                  .CUSTOMER_NO);
              RETURN FALSE;
            WHEN OTHERS THEN
              DBG('Error occured while Retrieving Liability No for Customer' ||
                  SQLERRM);
          END;
        
        END IF;
      
        DBG('Retrieved l_line_utils.Liab_Id: ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
            .LIABILITY_NO);
      END IF;
    
      L_COUNT := 0;
      DBG('Going to Check Liabilility Liability_No' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .LIABILITY_NO);
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM GETM_LIAB
         WHERE LIAB_NO = L_UTILIZN_TYPE.UTILS_DETAILS(I).LIABILITY_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COUNT := 0;
          DBG('Liabilility is Not found in ELCM');
        WHEN OTHERS THEN
          DBG('Failed in others of Liability fetching');
      END;
    
      IF L_COUNT = 0 THEN
        OVPKSS.PR_APPENDTBL('EL-FCJ-001',
                            'Liabilility is Not found in ELCM');
        RETURN FALSE;
      END IF;
    
      IF L_UTILIZN_TYPE.UTILS_DETAILS(I).CUSTOMER_NO IS NOT NULL AND L_UTILIZN_TYPE.UTILS_DETAILS(I)
         .LIABILITY_NO IS NOT NULL THEN
        L_COUNT := 0;
      
        BEGIN
          SELECT COUNT(1)
            INTO L_COUNT
            FROM GETM_LIAB_CUST LC, GETM_LIAB L
           WHERE LC.CUSTOMER_NO = L_UTILIZN_TYPE.UTILS_DETAILS(I)
                .CUSTOMER_NO
             AND LC.LIAB_ID = L.ID;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_COUNT := 0;
            DBG('Customer is Not found in ELCM');
          WHEN OTHERS THEN
            DBG('Failed in others of Customer fetching');
        END;
      
        IF L_COUNT = 0 THEN
          OVPKSS.PR_APPENDTBL('EL-FCJ-001',
                              'Customer Link is Not found in ELCM');
          RETURN FALSE;
        END IF;
      
      END IF;
    
    END LOOP;
  
    DBG('Out of Liability Check');
  
    IF NOT
        ELPKS_MULTI_UTIL_SERVICE.FN_PERCENTAGE_TO_AMOUNT(L_UTILIZN_TYPE,
                                                         P_ERROR,
                                                         P_ERROR_PARAMS) THEN
      DBG('Failed in Fn_Percentage_To_Amount');
      RETURN FALSE;
    END IF;
  
    IF ELPKS.FCJ_REQ_MUTLITRIP_ID IS NOT NULL THEN
    
      DBG('FCJ request contain multitrip id. So retrieving ELCM Transaction ID.......:' ||
          ELPKS.FCJ_REQ_MUTLITRIP_ID);
    
      BEGIN
        SELECT MASTER_TXN_ID
          INTO L_MASTER_TXN_ID_MULTI
          FROM ELTB_OVERRIDE_LOG
         WHERE FCJ_MULTITRIP_ID = ELPKS.FCJ_REQ_MUTLITRIP_ID
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data for the FCJ Multitrip ID');
          L_MASTER_TXN_ID_MULTI := '';
      END;
    END IF;
  
    DBG('Function Id : ' || ELPKS.TXN_FUNCTION);
    DBG('Action      : ' || ELPKS.TXN_ACTION);
  
    DBG('Limit Master:');
    DBG(' Ref_No       : ' || L_UTILIZN_TYPE.UTILS_MASTER. REF_NO);
    DBG(' Trans_Date   : ' || L_UTILIZN_TYPE.UTILS_MASTER. TRANS_DATE);
    DBG(' Value_Date   : ' || L_UTILIZN_TYPE.UTILS_MASTER. VALUE_DATE);
    DBG(' Trans_Amt    : ' || L_UTILIZN_TYPE.UTILS_MASTER. TRANS_AMT);
    DBG(' Trans_Ccy    : ' || L_UTILIZN_TYPE.UTILS_MASTER. TRANS_CCY);
    DBG(' Trans_Brn    : ' || L_UTILIZN_TYPE.UTILS_MASTER. TRANS_BRN);
    DBG(' Trans_Prd    : ' || L_UTILIZN_TYPE.UTILS_MASTER. TRANS_PRD);
    DBG(' Tenor_Basis  : ' || L_UTILIZN_TYPE.UTILS_MASTER. TENOR_BASIS);
    DBG(' Tenor        : ' || L_UTILIZN_TYPE.UTILS_MASTER. TENOR);
    DBG(' Module       : ' || L_UTILIZN_TYPE.UTILS_MASTER. MODULE);
    DBG(' Maturity_Date: ' || L_UTILIZN_TYPE.UTILS_MASTER. MATURITY_DATE);
    DBG(' Event_Code   : ' || L_UTILIZN_TYPE.UTILS_MASTER. EVENT_CODE);
    DBG(' Event_Sq_No  : ' || L_UTILIZN_TYPE.UTILS_MASTER. EVENT_SQ_NO);
    DBG(' Forceprocess : ' || L_UTILIZN_TYPE.UTILS_MASTER. FORCEPROCESS);
    DBG(' Simulation   : ' || L_UTILIZN_TYPE.UTILS_MASTER. SIMULATION);
  
    DBG('No of Limits Attached : ' || L_UTILIZN_TYPE.UTILS_DETAILS.COUNT);
  
    FOR I IN 1 .. L_UTILIZN_TYPE.UTILS_DETAILS.COUNT LOOP
      DBG('Limit details   : ' || I);
      DBG('Customer_No     : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .CUSTOMER_NO);
      DBG('Liability_No    : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .LIABILITY_NO);
      DBG('Linkage_Type    : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .LINKAGE_TYPE);
      DBG('Linkage_Refno   : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .LINKAGE_REFNO);
      DBG('Amt_Tag         : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I).AMT_TAG);
      DBG('Trans_Amt       : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .TRANS_AMT);
      DBG('Trans_Ccy       : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .TRANS_CCY);
      DBG('Trans_Percentage: ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .TRANS_PERCENTAGE);
      DBG('Uncoll          : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I).UNCOLL);
      DBG('Matured_Amt     : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .MATURED_AMT);
      DBG('Remarks         : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I).REMARKS);
      DBG('Serial_No       : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .SERIAL_NO);
      DBG('Action          : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I).ACTION);
      DBG('Is_Account      : ' || L_UTILIZN_TYPE.UTILS_DETAILS(I)
          .IS_ACCOUNT);
    END LOOP;
  
    DBG('Generating ELCM Transaction ID.......');
    ELPKS_MULTI_UTIL_SERVICE.PR_GEN_TXN_REF_NO;
  
    DBG('ELCM_MULTITRIP_ID: ' || ELPKS.ELCM_MULTITRIP_ID);
    DBG('TXN_ID: ' || ELPKS.TXN_ID);
  
    DBG('Inserting into log FOR TXN ID....>' || ELPKS.TXN_ID);
  
    IF SEND_TXN_ELCM <> 'N' THEN
    
      ELPKS_UTILIZATION_MAIN.PR_UTIL_TYPE(L_UTILIZN_TYPE,
                                          L_UTILIZN_MAIN_TYPE);
    
      IF NOT ELPKS_UTILIZATION_MAIN.FN_PROCESS_REQUEST(L_UTILIZN_MAIN_TYPE,
                                                       'ACC_REIN',
                                                       '',
                                                       '',
                                                       P_ERROR,
                                                       P_ERROR_PARAMS) THEN
      
        DBG('ERROR IN elpks_utilization_main.Fn_Process_Request : ' ||
            P_ERROR);
        OVPKSS.PR_APPENDTBL(P_ERROR || '', P_ERROR_PARAMS || '');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN REQUESTBUILDFAILED THEN
      DBG('Request Message Building failed.' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      ELPKS.REQ_STATUS   := 'E';
      P_ERROR            := 'EL-FCJ-001';
      P_ERROR_PARAMS     := SQLERRM;
      ELPKS.ERROR_PARAMS := SQLERRM;
      ELPKS_MULTI_UTIL_SERVICE.PR_UPDATE_LOG(REQUESTMSG, RESPONSEMSG);
      RETURN FALSE;
    WHEN OTHERS THEN
      DBG('Failed in processing request for ELCM.' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      ELPKS.REQ_STATUS   := 'E';
      P_ERROR            := 'EL-FCJ-001';
      P_ERROR_PARAMS     := SQLERRM;
      ELPKS.ERROR_PARAMS := SQLERRM;
      ELPKS_MULTI_UTIL_SERVICE.PR_UPDATE_LOG(REQUESTMSG, RESPONSEMSG);
      RETURN FALSE;
  END FN_OD_ACCOUNT_PROCESS;

  FUNCTION FN_CHECK_USER_ACC_RESTR(P_FUNCTION_ID  IN VARCHAR2,
                                   P_AC_NO        IN VARCHAR2,
                                   P_BRANCH       IN VARCHAR2,
                                   P_CUST_ACC_REC OUT STTM_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
    L_CNT         NUMBER;
    L_CUSTOMER_NO VARCHAR2(9);
    L_TEMP        NUMBER;
    L_MAKER_ID    STTMS_CUST_ACCOUNT.MAKER_ID%TYPE;
    L_AUTH_STAT   STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_ONCE_AUTH   STTMS_CUST_ACCOUNT.ONCE_AUTH%TYPE;
    L_CUST_NO     STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_ROL_RES     NUMBER := 0;
  BEGIN
    DBG('Inside fn_check_user_acc_restr');
    L_CUSTOMER_NO := GLOBAL.USER_CUSTOMER_NO;
    DBG('Restr apply flag: ' || GLOBAL.USER_ACC_RESTR_APPLY);
    IF GLOBAL.USER_ACC_RESTR_APPLY = 'Y' THEN
      DBG('global.user_acc_restr_apply ---> Y');
      DBG('p_ac_no: ' || P_AC_NO || ' p_branch: ' || P_BRANCH);
      DBG('Selecting from smvw_user_restr_accounts');
      BEGIN
        SELECT COUNT(*)
          INTO L_TEMP
          FROM SMVW_USER_RESTR_ACCOUNTS
         WHERE ACCOUNT_NO = P_AC_NO
           AND BRANCH_CODE = P_BRANCH;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_TEMP := 0;
      END;
    ELSE
      L_TEMP := 0;
    END IF;
    BEGIN
      SELECT *
        INTO P_CUST_ACC_REC
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRANCH;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed:to fetch with: ' || SQLERRM || ' but returning true');
        RETURN TRUE;
    END;
  
    SELECT COUNT(1)
      INTO L_ROL_RES
      FROM SMVWS_ROLE_ACCCLASS
     WHERE ACCOUNT_CLASS = P_CUST_ACC_REC.ACCOUNT_CLASS;
  
    IF (P_CUST_ACC_REC.MAKER_ID = GLOBAL.USER_ID AND
       P_CUST_ACC_REC.AUTH_STAT = 'U' AND P_CUST_ACC_REC.ONCE_AUTH = 'N')
      
       OR (L_TEMP = 0 AND L_ROL_RES > 0)
      
       OR STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
      DBG('Through the second IF');
      RETURN TRUE;
    ELSE
      DBG('User is not allowed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-156', '');
      RETURN FALSE;
    END IF;
    DBG('User is allowed to view');
    DBG('fn_check_user_acc_restr returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_amtdt with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DBG('Returning true anyway...');
      RETURN TRUE;
  END FN_CHECK_USER_ACC_RESTR;

  FUNCTION FN_ROUND_AMOUNTS(P_FUNCTION_ID IN VARCHAR2,
                            P_AMOUNT      IN NUMBER,
                            P_CCY         IN CYTMS_CCY_DEFN.CCY_CODE%TYPE)
    RETURN NUMBER IS
    L_AMOUNT_ROUNDED NUMBER;
    L_RET            BOOLEAN;
  BEGIN
    L_RET := CYPKSS.FN_AMT_ROUND(P_CCY, P_AMOUNT, L_AMOUNT_ROUNDED);
    RETURN L_AMOUNT_ROUNDED;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END FN_ROUND_AMOUNTS;

  FUNCTION DECODEAMT(P_FUNCTION_ID IN VARCHAR2, L_AMT NUMBER) RETURN VARCHAR2 IS
    L_AMT_CRDR VARCHAR2(2);
  BEGIN
    SELECT DECODE(SIGN(L_AMT), -1, 'Dr', 1, 'Cr', '')
      INTO L_AMT_CRDR
      FROM DUAL;
    RETURN L_AMT_CRDR;
  END DECODEAMT;

  FUNCTION FN_POPULATE_AMOUNT_DATES(P_FUNCTION_ID  IN VARCHAR2,
                                    P_CUST_ACC_REC IN STTM_CUST_ACCOUNT%ROWTYPE,
                                    P_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_DATA               VARCHAR2(32000);
    L_ACY                VARCHAR2(3);
    L_ACY_AVL_BAL        NUMBER(22, 3);
    L_PROVISION_AMOUNT   NUMBER(22, 3);
    L_DIS_UNUTILIZED_AMT NUMBER(22, 3);
    L_DIS_TOT_AVL_AMOUNT NUMBER(22, 3);
    L_DC_TOT_AVL_AMOUNT  VARCHAR2(3);
    L_ERROR_CODE         VARCHAR2(100);
    L_UNUTLZD_LINE_AMT   LMTMS_LIMITS.AVAILABLE_AMOUNT%TYPE;
    L_TOT_AVL_BAL        LMTMS_LIMITS.AVAILABLE_AMOUNT%TYPE;
    L_AMT_REC            STTMS_ACCOUNT_BAL_TOV%ROWTYPE;
  
    L_COUNT          NUMBER := 0;
    L_LIMIT_PRD      STTMS_TURNOVER_PERIODS.LIMIT_PRD%TYPE;
    L_LIMIT_AMOUNT   STTMS_TURNOVER_LMT_AMT.LIMIT_AMOUNT%TYPE;
    L_TRNOVR_AMT_DET ACTBS_CRTUR_LMT_BAL.UTIL_AMOUNT%TYPE;
  
    L_MIN_DUEDT_INT   DATE;
    L_MIN_DUEDT_PRINC DATE;
    L_MIN_DUEDT_CHG   DATE;
    L_OD_AMT_INT      NUMBER;
    L_OD_AMT_PRINC    NUMBER;
    L_OD_AMT_CHG      NUMBER;
  
    L_SWEEP_AMOUNT     NUMBER;
    L_ADCNT            NUMBER;
    L_ILM_SWEEP_AMT    NUMBER;
    L_TOTAL_AMOUNT_DUE CSTBS_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
  
    L_NET_REF STTM_ACC_NETTING_MASTER.REFERENCE_NO%TYPE;
    L_NET_BRN STTM_ACC_NETTING_MASTER.BRANCH_CODE%TYPE;
  
  BEGIN
    DBG('Inside fn_populate_amount_dates');
    DBG('Brn: ' || P_CUST_ACC_REC.BRANCH_CODE || ' Acc: ' ||
        P_CUST_ACC_REC.CUST_AC_NO || '~' ||
        P_CUST_ACC_REC.NETTING_REQUIRED);
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_CUST_ACC_REC.BRANCH_CODE,
                                                P_CUST_ACC_REC.CUST_AC_NO,
                                                'N',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
  
    DBG('p_Cust_Acc_Rec.Netting_Required : ' ||
        P_CUST_ACC_REC.NETTING_REQUIRED || '~' ||
        CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'));
    IF NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'), 'N') <> 'Y' THEN
    
      IF NOT LMPKSS_MISC.FN_GET_TOTAL_AVL_BAL(P_CUST_ACC_REC.BRANCH_CODE,
                                              P_CUST_ACC_REC.CUST_NO,
                                              P_CUST_ACC_REC.CUST_AC_NO
                                              
                                             ,
                                              ''
                                              
                                             ,
                                              P_CUST_ACC_REC.CCY,
                                              L_UNUTLZD_LINE_AMT,
                                              L_TOT_AVL_BAL,
                                              L_ERROR_CODE) THEN
        DBG('Failed In Getting Line Utilization');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'LM-00231', '');
        RETURN FALSE;
      END IF;
    
      DBG('l_tot_avl_bal: ' || L_TOT_AVL_BAL);
    
      L_DIS_UNUTILIZED_AMT := NVL(L_UNUTLZD_LINE_AMT, 0);
    
    ELSIF P_CUST_ACC_REC.NETTING_REQUIRED = 'Y' THEN
      L_TOT_AVL_BAL := STPKS_ACCOUNT_NETTING.FNGETNETTEDBAL(P_CUST_ACC_REC.BRANCH_CODE,
                                                            P_CUST_ACC_REC.CUST_AC_NO,
                                                            P_CUST_ACC_REC.CUST_NO,
                                                            P_CUST_ACC_REC.CCY,
                                                            G_BALREC.ACY_WITHDRAWABLE_BAL,
                                                            'Y',
                                                            'T',
                                                            L_NET_REF,
                                                            L_NET_BRN);
    
      L_DIS_UNUTILIZED_AMT := L_TOT_AVL_BAL;
      DBG('Net 2: l_tot_avl_bal: ' || L_TOT_AVL_BAL || '~' ||
          G_BALREC.ACY_WITHDRAWABLE_BAL);
    END IF;
  
    IF L_DIS_UNUTILIZED_AMT < 0 THEN
      L_DIS_UNUTILIZED_AMT := 0;
    END IF;
  
    IF L_TOT_AVL_BAL IS NOT NULL THEN
      L_DIS_TOT_AVL_AMOUNT := L_TOT_AVL_BAL;
    END IF;
  
    BEGIN
      SELECT NVL(SUM(AMOUNT_DUE), 0) - NVL(SUM(AMOUNT_PAID), 0)
        INTO L_TOTAL_AMOUNT_DUE
        FROM CSTBS_AUTO_SETTLE_BLOCK
       WHERE ACCOUNT_NO = P_CUST_ACC_REC.CUST_AC_NO
         AND ACCOUNT_BR = P_CUST_ACC_REC.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get amount_due: ' || SQLERRM ||
            '... So, returning from here without any reply');
        L_TOTAL_AMOUNT_DUE := 0;
    END;
    DBG(' l_Total_Amount_Due ' || L_TOTAL_AMOUNT_DUE);
  
    SELECT *
      INTO L_AMT_REC
      FROM STTMS_ACCOUNT_BAL_TOV
     WHERE CUST_AC_NO = P_CUST_ACC_REC.CUST_AC_NO
       AND BRANCH_CODE = P_CUST_ACC_REC.BRANCH_CODE;
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_CUST_ACC_REC.BRANCH_CODE,
                                                P_CUST_ACC_REC.CUST_AC_NO,
                                                'Y',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
  
    DBG('Assigment about to take place');
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_OPENING_BAL      := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.ACY_OPENING_BAL),
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD27              := DECODEAMT(P_FUNCTION_ID,
                                                                         L_AMT_REC.ACY_OPENING_BAL);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TODAY_TOVER_DR   := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                L_AMT_REC.ACY_TODAY_TOVER_DR,
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TODAY_TOVER_CR   := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                L_AMT_REC.ACY_TODAY_TOVER_CR,
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_OPENING_BAL      := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_OPENING_BAL),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD29              := DECODEAMT(P_FUNCTION_ID,
                                                                         L_AMT_REC.LCY_OPENING_BAL);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TODAY_TOVER_DR   := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_TODAY_TOVER_DR),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TODAY_TOVER_CR   := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_TODAY_TOVER_CR),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_DR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.ACY_TANK_DR),
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_CR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.ACY_TANK_CR),
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_UNCOLLECTED := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.ACY_TANK_UNCOLLECTED),
                                                                                P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD30              := DECODEAMT(P_FUNCTION_ID,
                                                                         L_AMT_REC.ACY_TANK_UNCOLLECTED);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TANK_DR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_TANK_DR),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TANK_CR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_TANK_CR),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_CURR_BALANCE     := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                ABS(L_AMT_REC.LCY_CURR_BALANCE),
                                                                                GLOBAL.LCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD38              := DECODEAMT(P_FUNCTION_ID,
                                                                         L_AMT_REC.LCY_CURR_BALANCE);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_CURR_BALANCE := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(G_BALREC.ACY_CURR_ACC_BAL),
                                                                            P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD31 := DECODEAMT(P_FUNCTION_ID,
                                                            G_BALREC.ACY_CURR_ACC_BAL);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNCOLLECTED := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                           ABS(G_BALREC.ACY_UNCOLLECTED),
                                                                           P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD33 := DECODEAMT(P_FUNCTION_ID,
                                                            G_BALREC.ACY_UNCOLLECTED);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.WITHDRAWABLE_UNCOLLED_FUND := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                      ABS(G_BALREC.WITHDRAWABLE_UNCOLLED_FUND),
                                                                                      P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD32 := DECODEAMT(P_FUNCTION_ID,
                                                            G_BALREC.WITHDRAWABLE_UNCOLLED_FUND);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_BLOCKED_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                              ABS(NVL(G_BALREC.ACY_BLOCKED_AMT,
                                                                                      0) +
                                                                                  NVL(G_BALREC.ACY_ECA_BLOCKED_AMT,
                                                                                      0)),
                                                                              P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.RECEIVABLE_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                             ABS(G_BALREC.RECEIVABLE_AMOUNT),
                                                                             P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_AVL_BAL := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                       ABS(G_BALREC.ACY_WITHDRAWABLE_BAL),
                                                                       P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD34 := DECODEAMT(P_FUNCTION_ID,
                                                            G_BALREC.ACY_WITHDRAWABLE_BAL);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_ACCRUED_DR_IC := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                             L_AMT_REC.ACY_ACCRUED_DR_IC,
                                                                             P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_ACCRUED_CR_IC           := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       L_AMT_REC.ACY_ACCRUED_CR_IC,
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DR_INT_DUE                  := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.DR_INT_DUE),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.CHG_DUE                     := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.CHG_DUE),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_DR               := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_DR),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_CR               := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_CR),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_UNCOLLECTED      := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_UNCOLLECTED),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_DR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_TANK_DR),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_CR          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_TANK_CR),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_UNCOLLECTED := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                                       ABS(L_AMT_REC.ACY_UNAUTH_TANK_UNCOLLECTED),
                                                                                       P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD42                     := DECODEAMT(P_FUNCTION_ID,
                                                                                L_AMT_REC.ACY_UNAUTH_TANK_UNCOLLECTED);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.AUTO_DEPOSITS_BAL := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                             ABS(L_AMT_REC.AUTO_DEPOSITS_BAL),
                                                                             P_CUST_ACC_REC.CCY);
  
    DBG('l_amt_rec.date_last_dr: ' || L_AMT_REC.DATE_LAST_DR);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_DR          := TO_DATE(L_AMT_REC.DATE_LAST_DR,
                                                                        'DD-MM-RRRR');
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_CR          := TO_DATE(L_AMT_REC.DATE_LAST_CR,
                                                                        'DD-MM-RRRR');
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_DR_ACTIVITY := TO_DATE(L_AMT_REC.DATE_LAST_DR_ACTIVITY,
                                                                        'DD-MM-RRRR');
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_CR_ACTIVITY := TO_DATE(L_AMT_REC.DATE_LAST_CR_ACTIVITY,
                                                                        'DD-MM-RRRR');
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_MTD_TOVER_DR := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_AMT_REC.ACY_MTD_TOVER_DR),
                                                                            P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_MTD_TOVER_CR := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_AMT_REC.ACY_MTD_TOVER_CR),
                                                                            P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_MTD_TOVER_DR := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_AMT_REC.LCY_MTD_TOVER_DR),
                                                                            GLOBAL.LCY);
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_MTD_TOVER_CR := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_AMT_REC.LCY_MTD_TOVER_CR),
                                                                            GLOBAL.LCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD28          := GLOBAL.LCY;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD26          := P_CUST_ACC_REC.CCY;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD41          := GLOBAL.LCY;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD40          := P_CUST_ACC_REC.CCY;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD39          := P_CUST_ACC_REC.CCY;
    P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.PROVISION_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(P_CUST_ACC_REC.PROVISION_AMOUNT),
                                                                            P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD35          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_DIS_UNUTILIZED_AMT),
                                                                            P_CUST_ACC_REC.CCY);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD14           := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREV_RUNBAL_PRINTED_IN_PBK;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23          := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_TOTAL_AMOUNT_DUE),
                                                                            P_CUST_ACC_REC.CCY);
    DBG('p_stdcusac.v_cstbs_ui_columns.char_field23--> ' ||
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23);
  
    SELECT COUNT(*)
      INTO L_ADCNT
      FROM STTMS_SWEEP_DETAILS
     WHERE BRANCH_CODE = P_CUST_ACC_REC.BRANCH_CODE
       AND CUST_ACCOUNT = P_CUST_ACC_REC.CUST_AC_NO
       AND SWEEP_TYPE = 'SA';
    DBG('l_adcnt-->' || L_ADCNT);
    IF L_ADCNT = 0 THEN
      DBG('Auto deposit Bal' ||
          P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.AUTO_DEPOSITS_BAL);
      L_DIS_TOT_AVL_AMOUNT := NVL(L_DIS_TOT_AVL_AMOUNT, 0) +
                              NVL(P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.AUTO_DEPOSITS_BAL,
                                  0);
    END IF;
    DBG('Total Available Bal-->' ||
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD36);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD36 := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                   ABS(L_DIS_TOT_AVL_AMOUNT),
                                                                   P_CUST_ACC_REC.CCY);
  
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD37 := DECODEAMT(P_FUNCTION_ID,
                                                            L_DIS_TOT_AVL_AMOUNT);
  
    IF P_FUNCTION_ID = 'STDCUSAC' THEN
    
      SELECT MIN(DECODE(COMPONENT_TYPE, 'P', SODD.DUE_DT, NULL)),
             NVL(SUM(DECODE(COMPONENT_TYPE, 'P', SODD.AMT_NOT_SETTLED, 0)),
                 0),
             MIN(DECODE(COMPONENT_TYPE, 'C', SODD.DUE_DT, NULL)),
             NVL(SUM(DECODE(COMPONENT_TYPE, 'C', SODD.AMT_NOT_SETTLED, 0)),
                 0),
             MIN(DECODE(COMPONENT_TYPE, 'I', SODD.DUE_DT, NULL)),
             NVL(SUM(DECODE(COMPONENT_TYPE, 'I', SODD.AMT_NOT_SETTLED, 0)),
                 0)
        INTO L_MIN_DUEDT_PRINC,
             L_OD_AMT_PRINC,
             L_MIN_DUEDT_CHG,
             L_OD_AMT_CHG,
             L_MIN_DUEDT_INT,
             L_OD_AMT_INT
        FROM STTB_OD_DUE_DETAILS SODD
       WHERE SODD.BRANCH_CODE = P_CUST_ACC_REC.BRANCH_CODE
         AND SODD.CUST_AC_NO = P_CUST_ACC_REC.CUST_AC_NO
         AND SODD.AMT_NOT_SETTLED > 0;
    
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD45 := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                     ABS(L_OD_AMT_PRINC),
                                                                     P_CUST_ACC_REC.CCY);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD2  := TO_DATE(L_MIN_DUEDT_PRINC,
                                                            'DD-MM-RRRR');
    
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD46 := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                     ABS(L_OD_AMT_INT),
                                                                     P_CUST_ACC_REC.CCY);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD3  := TO_DATE(L_MIN_DUEDT_INT,
                                                            'DD-MM-RRRR');
    
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD47 := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                     ABS(L_OD_AMT_CHG),
                                                                     P_CUST_ACC_REC.CCY);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD4  := TO_DATE(L_MIN_DUEDT_CHG,
                                                            'DD-MM-RRRR');
    
    END IF;
  
    DBG('populating Turnover Limit Details');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE IS NOT NULL THEN
      BEGIN
        SELECT LIMIT_PRD
          INTO L_LIMIT_PRD
          FROM STTMS_TURNOVER_PERIODS
         WHERE LIMIT_CODE =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
           AND TO_DATE(GLOBAL.APPLICATION_DATE) BETWEEN LIMIT_START_DATE AND
               LIMIT_END_DATE;
        P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_PRD := L_LIMIT_PRD;
        DBG('LIMIT_PRD-->' || L_LIMIT_PRD);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Inside no_data_found l_limit_amount');
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_PRD    := NULL;
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.ACC_CCY      := NULL;
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(0),
                                                                            P_CUST_ACC_REC.CCY);
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT  := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(0),
                                                                            P_CUST_ACC_REC.CCY);
        WHEN OTHERS THEN
          DBG('Oracle Error :' || SQLERRM);
          RETURN FALSE;
      END;
      IF L_LIMIT_PRD IS NOT NULL THEN
        BEGIN
          SELECT LIMIT_AMOUNT
            INTO L_LIMIT_AMOUNT
            FROM STTMS_TURNOVER_LMT_AMT
           WHERE LIMIT_PRD = L_LIMIT_PRD
             AND LIMIT_CODE =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
             AND LIMIT_CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                            ABS(L_LIMIT_AMOUNT),
                                                                            P_CUST_ACC_REC.CCY);
          P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.ACC_CCY      := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Inside no_data_found l_limit_ccy');
            P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.ACC_CCY      := NULL;
            P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                              ABS(0),
                                                                              P_CUST_ACC_REC.CCY);
            P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT  := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                              ABS(0),
                                                                              P_CUST_ACC_REC.CCY);
          WHEN OTHERS THEN
            DBG('Oracle Error :' || SQLERRM);
            RETURN FALSE;
        END;
        IF L_LIMIT_AMOUNT <> 0 THEN
          BEGIN
            SELECT UTIL_AMOUNT
              INTO L_TRNOVR_AMT_DET
              FROM ACTBS_CRTUR_LMT_BAL
             WHERE ACC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
               AND ACC_BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ACC_CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
               AND LIMIT_CODE =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
               AND LIMIT_PRD = L_LIMIT_PRD;
            P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                             ABS(L_TRNOVR_AMT_DET),
                                                                             P_CUST_ACC_REC.CCY);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                               ABS(0),
                                                                               P_CUST_ACC_REC.CCY);
            WHEN OTHERS THEN
              DBG('Oracle Error :' || SQLERRM);
              RETURN FALSE;
          END;
        END IF;
      END IF;
    ELSE
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_PRD    := NULL;
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.ACC_CCY      := NULL;
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_AMOUNT := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                        ABS(0),
                                                                        P_CUST_ACC_REC.CCY);
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT  := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                        ABS(0),
                                                                        P_CUST_ACC_REC.CCY);
    END IF;
    DBG('fn_populate_amount_dates returning true');
  
    DBG('p_cust_acc_rec.acy_sweep_ineligible' ||
        P_CUST_ACC_REC.ACY_SWEEP_INELIGIBLE);
  
    IF P_FUNCTION_ID IN ('STDCUSAC', 'IADCUSAC')
    
     THEN
    
      L_ILM_SWEEP_AMT := (NVL(G_BALREC.ACY_CURR_ACC_BAL, 0) -
                         NVL(P_CUST_ACC_REC.ACY_SWEEP_INELIGIBLE, 0));
    
      DBG('l_ilm_sweep_amt-->' || L_ILM_SWEEP_AMT);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1   := FN_ROUND_AMOUNTS(P_FUNCTION_ID,
                                                                     ABS(L_ILM_SWEEP_AMT),
                                                                     P_CUST_ACC_REC.CCY);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD92 := DECODEAMT(P_FUNCTION_ID,
                                                              L_ILM_SWEEP_AMT);
      DBG('p_stdcusac.v_cstbs_ui_columns.num_field1-->' ||
          P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1);
      DBG('p_Stdcusac.v_Cstbs_Ui_Columns.Char_Field92-->' ||
          P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD92);
    
    END IF;
  
    L_SWEEP_AMOUNT := STPKS_PROCESS_ONLINE_SWEEP.FN_GET_SWEEP_ELIGIBLE_BAL(P_CUST_ACC_REC.BRANCH_CODE,
                                                                           P_CUST_ACC_REC.CUST_AC_NO);
    DBG('CASA/TD SWEEP eligible balance-->' || L_SWEEP_AMOUNT);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD2 := L_SWEEP_AMOUNT;
  
    DBG('fn_populate_amount_dates returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_amount_dates with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POPULATE_AMOUNT_DATES;

  FUNCTION FN_POPULATE_AMTDT(P_FUNCTION_ID IN VARCHAR2,
                             P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CUST_ACC_REC STTMS_CUST_ACCOUNT%ROWTYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside fn_populate_amtdt');
  
    DBG('ONCE_AUTH inside populate amtdt-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'Y' THEN
    
      DBG('Verifying account nos');
      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                         CSPKS_REQ_GLOBAL.P_QUERY,
                                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
        DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
        RETURN FALSE;
      END IF;
      DBG('Checking User restrictions');
      IF NOT FN_CHECK_USER_ACC_RESTR(P_FUNCTION_ID,
                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                     L_CUST_ACC_REC) THEN
        DBG('fn_check_user_acc_restr has returned false');
        RETURN FALSE;
      END IF;
      DBG('Beginning the actual population');
      IF NOT
          FN_POPULATE_AMOUNT_DATES(P_FUNCTION_ID, L_CUST_ACC_REC, P_STDCUSAC) THEN
        DBG('fn_populate_amount_dates has returned false');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_AMTDT(P_FUNCTION_ID,
                                                         P_STDCUSAC,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_cluster.Fn_Populate_Amtdt');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('fn_populate_amtdt returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_amtdt with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POPULATE_AMTDT;

  FUNCTION FN_VALIDATE_SPLICCOND(P_FUNCTION_ID IN VARCHAR2,
                                 P_BRN         IN VARCHAR2,
                                 P_ACC         IN VARCHAR2) RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN
    DBG('Inside fn_validate_spliccond');
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM ICTB_UDE_UTIL_LOG_DETAIL
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND NVL(AUTH_STAT, 'U') = 'U';
      DBG('l_count is........' || L_COUNT);
      IF L_COUNT <> 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ICUTIL-04', '');
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in geetin count from ictb_ude_util_log_detail' ||
            SQLERRM);
        RETURN FALSE;
    END;
    DBG('fn_validate_spliccond returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_spliccond with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_SPLICCOND;

  FUNCTION FN_BASIC_DEFAULT(P_FUNCTION_ID IN VARCHAR2,
                            P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CUST     STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CCY      STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_LOCATION STTMS_CUST_ACCOUNT.LOCATION%TYPE;
    L_MEDIA    STTMS_CUST_ACCOUNT.MEDIA%TYPE;
    L_CR_GL    STTMS_CUST_ACCOUNT.CR_GL%TYPE;
    L_DR_GL    STTMS_CUST_ACCOUNT.DR_GL%TYPE;
  BEGIN
    DBG('Inside fn_basic_default');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY IS NULL OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION IS NULL OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL IS NULL OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL IS NULL THEN
      BEGIN
        SELECT CUST_NO, CCY, LOCATION, MEDIA, CR_GL, DR_GL
          INTO L_CUST, L_CCY, L_LOCATION, L_MEDIA, L_CR_GL, L_DR_GL
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
              
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('NO data here.. ' || SQLERRM);
      END;
    END IF;
    DBG('The customer >> ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO := L_CUST;
    END IF;
    DBG('The ccy >> ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY := L_CCY;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION := L_LOCATION;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA := L_MEDIA;
    END IF;
  
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL := L_CR_GL;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL IS NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL := L_DR_GL;
    END IF;
  
    DBG('fn_basic_default returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_basic_default with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BASIC_DEFAULT;

  FUNCTION FN_DEFAULT_ACCSTATLINE(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_NORM_CNT   NUMBER := 0;
    L_STAT_COUNT NUMBER;
  BEGIN
    DBG('Inside fn_default_accstatline');
    IF P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT > 0 THEN
    
      DBG('Loop through and find out if NORM status is present');
      FOR I IN 1 .. P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT LOOP
        DBG('In loop: ' || I);
        IF P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).STATUS = 'NORM' THEN
          L_NORM_CNT := L_NORM_CNT + 1;
        END IF;
      END LOOP;
    ELSIF P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT = 0 THEN
    
      DBG('NORM is not present');
    END IF;
    DBG('l_norm_cnt: ' || L_NORM_CNT);
    IF L_NORM_CNT = 0 THEN
      DBG('Defaulting Account Status line from the account - NORM status');
      L_STAT_COUNT := NVL(P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT, 0) + 1;
      DBG('l_stat_count: ' || L_STAT_COUNT);
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).STATUS := 'NORM';
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).DR_HO_LINE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).CR_HO_LINE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).CR_CB_LINE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).DR_CB_LINE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).DR_GL := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL;
      P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_STAT_COUNT).CR_GL := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL;
    
    END IF;
    DBG('Count: ' || P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT);
    DBG('fn_default_accstatline returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_default_accstatline with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_DEFAULT_ACCSTATLINE;

  FUNCTION FN_MODIFY_ACC(P_FUNCTION_ID   IN VARCHAR2,
                         P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_ACTION_CODE   IN VARCHAR2,
                         P_SOURCE        IN VARCHAR2,
                         P_ERR_CODE      IN OUT VARCHAR2,
                         P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_COUNT NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside fn_modify_acc');
    DBG('Verifying Acc nos');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
      RETURN FALSE;
    END IF;
  
    DBG('Source ' || P_SOURCE || ' ~p_action_code ' || P_ACTION_CODE);
    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'MODIFY' AND
       P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT IS NULL THEN
      DBG('amount ' || P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);
      P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT := P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT;
    END IF;
  
    DBG('Verifying account opening date');
    DBG('Prev date: ' || P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('Curr date: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    IF P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
      DBG('Acc open date has changed');
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM ICTBS_ACC_ACTION A
         WHERE A.BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND A.ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND A.TBL_NAME = 'STTMS_CUST_ACCOUNT'
           AND A.ACTION = 'R'
           AND A.AUTH_STAT = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed:select count(*) into n from ictbs_acc_action' ||
              SQLERRM);
          L_COUNT := 0;
      END;
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'Y' AND L_COUNT = 0 THEN
        DBG('Account Opening Date cannot be Modified..');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-184', '');
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      IF NOT STPKS_STDCUSAC_UTILS_CLUSTER.FN_MODIFY_ACC(P_FUNCTION_ID,
                                                        P_PREV_STDCUSAC,
                                                        P_STDCUSAC,
                                                        P_ACTION_CODE,
                                                        P_SOURCE,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcusac_utils_cluster.Fn_Modify_Acc');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('validation to verify the existance of unauth ic special condition maintainence');
    IF NOT
        FN_VALIDATE_SPLICCOND(P_FUNCTION_ID,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
      DBG('fn_validate_spliccond has returned false');
      RETURN FALSE;
    END IF;
    DBG('Defaulting the Acc status for norm');
    IF NOT FN_DEFAULT_ACCSTATLINE(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_default_accstatline has returned false');
      RETURN FALSE;
    END IF;
    DBG('Validating all the records');
    IF NOT STPKS_STDCUSAC_UTILS_1.FN_VALIDATE_RECORDS(P_SOURCE,
                                                      P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      P_ACTION_CODE,
                                                      P_ERR_CODE,
                                                      P_ERR_PARAMS) THEN
      DBG('stpks_stdcusac_utils_1.Fn_Validate_Records has returned false');
      RETURN FALSE;
    END IF;
    DBG('Populating the records');
    IF NOT STPKS_STDCUSAC_UTILS_1.FN_POPULATE_RECORDS(P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      P_ACTION_CODE,
                                                      P_SOURCE) THEN
      DBG('stpks_stdcusac_utils_1.Fn_Populate_Records has returned false');
      RETURN FALSE;
    END IF;
    DBG('fn_modify_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_modify_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_MODIFY_ACC;

  FUNCTION FN_COLLATERAL_POOL_LINKAGES(P_FUNCTION_ID IN VARCHAR2,
                                       P_AUTH_FLG    IN VARCHAR2,
                                       P_REC_CUSTACC IN OUT STTMS_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE VARCHAR2(4000);
  
    L_ERR_PARAM    VARCHAR2(4000);
    L_GEDAPOOL     ELPKS_COLLATERAL_SERVICE.TY_GEDAPOOL;
    L_MULTITRIP_ID VARCHAR2(20) := NULL;
    L_STATUS       VARCHAR2(1000);
    L_LIAB_ID      GETM_LIAB.LIAB_NO%TYPE;
    L_LIAB_BRN     GETM_LIAB.LIAB_BRANCH%TYPE;
    TYPE TY_L_REC_OD_COLL IS TABLE OF STTM_OD_COLL_LINKAGES%ROWTYPE INDEX BY BINARY_INTEGER;
    TYPE TY_L_REC_POOL_LINKAGES IS TABLE OF GETM_POOL_COLL_LINKAGES%ROWTYPE INDEX BY BINARY_INTEGER;
    L_REC_OD_COLL        TY_L_REC_OD_COLL;
    L_REC_POOL_LINKAGES  TY_L_REC_POOL_LINKAGES;
    L_ICTM_ACC           ICTM_ACC%ROWTYPE;
    L_CNT                NUMBER(3) := 0;
    L_ROLLOVER_TYPE      ICTM_ACC.ROLLOVER_TYPE%TYPE;
    L_AC_OPEN_DATE       STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_DEPOSIT_TENOR      NUMBER;
    L_NEXT_MATURITY_DATE ICTM_ACC.NEXT_MATURITY_DATE%TYPE;
    L_EXPY_DT            ICTM_ACC.MATURITY_DATE%TYPE;
    L_RES                VARCHAR2(100);
    L_COLL_IDX           VARCHAR2(20) := '0';
    L_COLL_IDX1          VARCHAR2(20) := '0';
    L_NEW_COLL           VARCHAR2(20) := '0';
    L_EXPIRY_DT          ICTM_ACC.MATURITY_DATE%TYPE;
    TYPE TY_REC_POOL_LINKAGES IS RECORD(
      COLLATERAL_CODE         ELVW_POOL_COLL_LINKAGES_ODINT.COLLATERAL_CODE%TYPE,
      BRANCH_CODE             ELVW_POOL_COLL_LINKAGES_ODINT.BRANCH_CODE%TYPE,
      LINKED_AMOUNT           ELVW_POOL_COLL_LINKAGES_ODINT.LINKED_AMOUNT%TYPE,
      RATE_OF_INTEREST        ELVW_POOL_COLL_LINKAGES_ODINT.RATE_OF_INTEREST%TYPE,
      POOL_CODE               ELVW_POOL_COLL_LINKAGES_ODINT.POOL_CODE%TYPE,
      AVAILABLE_INTEREST_RATE ELVW_POOL_COLL_LINKAGES_ODINT.AVAILABLE_INTEREST_RATE%TYPE);
    TYPE TY_REC_POOL_LINKAGES1 IS TABLE OF TY_REC_POOL_LINKAGES;
    L_POOL_LINKAGES   TY_REC_POOL_LINKAGES1;
    L_ACTION          VARCHAR2(10) := 'NEW';
    L_MODIFIED        BOOLEAN := FALSE;
    L_COUNT           NUMBER;
    L_IDX             NUMBER := 0;
    L_CATEGORY_NAME   VARCHAR2(50);
    L_HAIRCUT_PERCENT NUMBER(20);
    L_POOL_MODIFY     BOOLEAN := FALSE;
    L_POOL_CNT        NUMBER;
    L_POOL_INDEX      NUMBER := 0;
    L_NW_COLL_IDX     NUMBER := 0;
    P_GEDCOLLAT       ELPKS_COLLATERAL_SERVICE.TY_GEDCOLLAT;
    P_GEDCPOOL        ELPKS_COLLATERAL_SERVICE.TY_GEDCPOOL;
  
    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
    L_DFLT_DAYS          STTM_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS%TYPE;
    L_DFLT_MONTHS        STTM_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS%TYPE;
    L_DFLT_YEARS         STTM_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS%TYPE;
  
    L_INDEX NUMBER;
  BEGIN
    DBG('inside  fn_collateral_pool_linkages');
  
    SELECT COUNT(*)
      INTO L_POOL_CNT
      FROM STTMS_CUST_ACCOUNT_LINKAGES
     WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
       AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE
       AND LINKED_REF_NO LIKE P_REC_CUSTACC.CUST_NO || 'P%';
  
    DBG('l_pool_cnt-->' || L_POOL_CNT);
    DBG('p_Rec_Custacc.account_type' || P_REC_CUSTACC.ACCOUNT_TYPE);
    IF P_REC_CUSTACC.AUTO_CREATE_POOL = 'Y' OR L_POOL_CNT > 0 THEN
    
      BEGIN
        SELECT *
          BULK COLLECT
          INTO L_REC_OD_COLL
          FROM STTM_OD_COLL_LINKAGES
         WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
           AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed:SELECT * bulk collect from sttm_od_coll_linkages' ||
              SQLERRM);
      END;
    
      BEGIN
        SELECT LIAB_NO, LIAB_BRANCH
          INTO L_LIAB_ID, L_LIAB_BRN
          FROM GETM_LIAB
         WHERE ID IN (SELECT LIAB_ID
                        FROM GETM_LIAB_CUST
                       WHERE CUSTOMER_NO = P_REC_CUSTACC.CUST_NO);
      
        DBG('l_liab_id -->' || L_LIAB_ID);
        DBG('l_liab_brn -->' || L_LIAB_BRN);
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to get liab id' || SQLERRM);
      END;
      DBG('p_Auth_Flg -->>' || P_AUTH_FLG);
      IF P_AUTH_FLG = 'N' OR (L_POOL_CNT = 0 AND P_AUTH_FLG = 'Y') THEN
        DBG('inside if auth = N or  l_pool_cnt = 0 and p_auth_flg = y -->>');
      
        FOR L_OD_INDEX IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
        
          DBG('l_Rec_od_coll.ac_od_linkages loop :::' || L_OD_INDEX);
          DBG('collateral_type:::' || L_REC_OD_COLL(L_OD_INDEX)
              .COLLATERAL_TYPE);
        
          IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE IN ('T', 'U') THEN
          
            L_COLL_IDX := L_COLL_IDX + 1;
          
            DBG('entering the call for collateral creation');
          
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.ACTION := 'NEW';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.LIABILITY := L_LIAB_ID;
          
            LOOP
              L_NW_COLL_IDX := L_NW_COLL_IDX + 1;
              SELECT COUNT(*)
                INTO L_COUNT
                FROM GETM_COLLAT
               WHERE COLLATERAL_CODE =
                     P_REC_CUSTACC.CUST_NO || L_NW_COLL_IDX;
              IF L_COUNT = 0 THEN
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERALCODE := P_REC_CUSTACC.CUST_NO ||
                                                                               L_NW_COLL_IDX;
                EXIT;
              END IF;
            END LOOP;
            DBG(' l_Gedapool.a_collateral(l_coll_idx).a_collat.collateralcode' || L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX)
                .A_COLLAT.COLLATERALCODE);
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERALDESCRIPTION := NVL(P_REC_CUSTACC.AC_DESC,
                                                                                      P_REC_CUSTACC.CUST_AC_NO);
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERALCATEGORY := L_REC_OD_COLL(L_OD_INDEX)
                                                                               .CATEGORY_NAME;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERALVALUE := L_REC_OD_COLL(L_OD_INDEX)
                                                                            .LINKED_AMOUNT;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.LENDABLEMARGIN := '100';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.LIMIT_CONTRIBUTION := L_REC_OD_COLL(L_OD_INDEX)
                                                                               .LINKED_AMOUNT;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.START_DATE := GLOBAL.APPLICATION_DATE;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.END_DATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.REVIEW_DATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.SECURITY_NAME := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.NUMBER_OF_UNITS := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.CAP_AMOUNT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.PRICE_CODE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.LAST_REVAL_PRICE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.CHARGE_TYPE := 'M';
          
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.LIAB_BRANCH := L_LIAB_BRN;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.REVAL_DATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.REVAL_COLLAT := 'N';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.USER_REFNO := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.ISSUER_NAME := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.ISSUER_REF_NO := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.GUARANTOR_ID := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.RATING := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.REVOKEABLE := 'N';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.REVOKEDATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COLLATERAL_TYPE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.GRACE_DAYS := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.SECURED := 'S';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.NEXT_REVAL_DATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.HAIRCUT := L_REC_OD_COLL(L_OD_INDEX)
                                                                    .HAIRCUT;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.AVAILABLE := 'Y';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.SHARING_REQ := 'N';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.AUTO_POOL_CREATE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.CONTRACT_SOURCE_REF_NO := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.MORTGAGE_INITIATED := 'N';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.INTEREST_RATE := L_REC_OD_COLL(L_OD_INDEX)
                                                                          .COLL_INT_RATE;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.UTIL_AMT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.AVAILABLE_AMOUNT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COMMITMENT_PRODUCT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COMMITMENT_REFNO := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COMMITMENT_SETTLBRN := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COMMITMENT_SETTLACC := 'N';
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.COMMITMENT_BRANCH := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.SOURCE := NULL;
          
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.EXTRESTTYPE := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.MODNO := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.AUTHSTAT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.RECSTAT := NULL;
            L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLLAT.ONCEAUTH := NULL;
          
            IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE = 'T' THEN
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).COLL_ID := L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX)
                                                                                    .A_COLLAT.COLLATERALCODE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).CONTRACT_REF_NO := L_REC_OD_COLL(L_OD_INDEX)
                                                                                            .COLLATERAL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).CONTRACT_CONTRIBUTION := L_REC_OD_COLL(L_OD_INDEX)
                                                                                                  .LINKED_AMOUNT;
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).CONTRACT_BRANCH := L_REC_OD_COLL(L_OD_INDEX)
                                                                                            .COLLATERAL_BRANCH;
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).ACCOUNT_TYPE := 'TD';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX).A_COLL_CONT_CONTRIB(1).ACCOUNT_BALANCE := L_REC_OD_COLL(L_OD_INDEX)
                                                                                            .AVAILABLE_AMOUNT;
            
              DBG('Before calling elpks_collateral_service.fn_collateral_process');
            
              BEGIN
                SELECT MATURITY_DATE
                  INTO L_EXPIRY_DT
                  FROM ICTM_ACC
                 WHERE ACC = L_REC_OD_COLL(L_OD_INDEX).COLLATERAL
                   AND
                      
                       BRN = L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_BRANCH;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed IN SELECT FOR EXPIRY DATE' || SQLERRM);
              END;
            END IF;
          
            L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_CODE := L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX)
                                                         .A_COLLAT.COLLATERALCODE;
          ELSE
            DBG('in else part of collateral creation.. ');
            L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_CODE := L_REC_OD_COLL(L_OD_INDEX)
                                                         .COLLATERAL;
          END IF;
        
          DBG('l_expiry_dt--->' || L_EXPIRY_DT);
        
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERAL_CODE := L_REC_OD_COLL(L_OD_INDEX)
                                                                          .COLLATERAL_CODE;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERAL_DESC := NVL(P_REC_CUSTACC.AC_DESC,
                                                                              P_REC_CUSTACC.CUST_AC_NO);
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERALAMOUNT := L_REC_OD_COLL(L_OD_INDEX)
                                                                           .LINKED_AMOUNT;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).ORDER_NO := NULL;
        
          IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE IN ('C', 'U') THEN
            DBG('This is of collateral type 11');
          
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKEDAMOUNT := L_REC_OD_COLL(L_OD_INDEX)
                                                                         .LINKED_AMOUNT;
          
          ELSE
            DBG('This is of TD type 11');
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKEDAMOUNT := NULL;
          END IF;
        
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKED_AMOUNT_POOL_CCY := NULL;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).UTILIZATION := NULL;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).POOL_TYPE := NULL;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).AVAILABLE_INT_RATE := L_REC_OD_COLL(L_OD_INDEX)
                                                                             .COLL_INT_RATE;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).INTERESTSPREAD := L_REC_OD_COLL(L_OD_INDEX)
                                                                         .INT_SPREAD;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).RATE_OF_INTEREST := L_REC_OD_COLL(L_OD_INDEX)
                                                                           .OD_INT_RATE;
          L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).EXPIRYDATE := L_EXPIRY_DT;
          DBG('Updating sttm_od_coll_linkages table for populating the created collateral');
        
        END LOOP;
      
        L_GEDAPOOL.AUTO_COLLPOOL.LIAB_NO := L_LIAB_ID;
      
        LOOP
          BEGIN
            L_POOL_INDEX := L_POOL_INDEX + 1;
            SELECT COUNT(*)
              INTO L_COUNT
              FROM GETM_POOL
             WHERE POOL_CODE = P_REC_CUSTACC.CUST_NO || 'P' || L_POOL_INDEX;
            IF L_COUNT = 0 THEN
              L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE := P_REC_CUSTACC.CUST_NO || 'P' ||
                                                    L_POOL_INDEX;
              EXIT;
            END IF;
          END;
        END LOOP;
      
        L_GEDAPOOL.AUTO_COLLPOOL.POOL_DESCRIPTION     := NVL(P_REC_CUSTACC.AC_DESC,
                                                             P_REC_CUSTACC.CUST_AC_NO);
        L_GEDAPOOL.AUTO_COLLPOOL.POOL_CCY             := P_REC_CUSTACC.CCY;
        L_GEDAPOOL.AUTO_COLLPOOL.POOL_AMOUNT          := '';
        L_GEDAPOOL.AUTO_COLLPOOL.POOL_UTIL            := '';
        L_GEDAPOOL.AUTO_COLLPOOL.AUTO_FACILITY_CREATE := 'N';
        L_GEDAPOOL.AUTO_COLLPOOL.MORTGAGE_INITIATED   := 'N';
        L_GEDAPOOL.AUTO_COLLPOOL.AVAILABLE_AMOUNT     := NULL;
        L_GEDAPOOL.AUTO_COLLPOOL.MAKER_ID             := GLOBAL.USER_ID;
        L_GEDAPOOL.AUTO_COLLPOOL.MAKER_DT_STAMP       := GLOBAL.APPLICATION_DATE;
        L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_ID           := GLOBAL.USER_ID;
        L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_DT_STAMP     := GLOBAL.APPLICATION_DATE;
        L_GEDAPOOL.AUTO_COLLPOOL.MOD_NO               := NULL;
        L_GEDAPOOL.AUTO_COLLPOOL.AUTH_STAT            := 'A';
        L_GEDAPOOL.AUTO_COLLPOOL.RECORD_STAT          := 'O';
        L_GEDAPOOL.AUTO_COLLPOOL.ONCE_AUTH            := 'Y';
      
        IF NOT FN_AUTOCREATE_COLL_POOL(L_GEDAPOOL,
                                       P_REC_CUSTACC,
                                       P_GEDCOLLAT,
                                       P_GEDCPOOL,
                                       'NEW',
                                       L_ERR_CODE,
                                       L_ERR_PARAM) THEN
          DBG('failed in Fn_autocreate_coll_pool');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
          RETURN FALSE;
        END IF;
      
        BEGIN
        
          DBG('insert into STTM_CUST_ACCOUNT_LINKAGES');
          INSERT INTO STTM_CUST_ACCOUNT_LINKAGES
            (BRANCH_CODE,
             CUST_AC_NO,
             CUSTOMER_NO,
             LINKAGE_TYPE,
             LINKED_REF_NO,
             LINKAGE_PERCENTAGE,
             LINKAGE_SEQ_NO,
             LINKAGE_BRANCH,
             LINKED_CCY)
          VALUES
            (P_REC_CUSTACC.BRANCH_CODE,
             P_REC_CUSTACC.CUST_AC_NO,
             P_REC_CUSTACC.CUST_NO,
             'P',
             L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE,
             '100',
             '1',
             P_REC_CUSTACC.BRANCH_CODE,
             P_REC_CUSTACC.CCY);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed while inserting into STTM_CUST_ACCOUNT_LINKAGES after pool creation' ||
                SQLERRM);
        END;
      
        FOR I IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
        
          UPDATE STTM_OD_COLL_LINKAGES
             SET COLLATERAL_CODE = L_REC_OD_COLL(I).COLLATERAL_CODE,
                 COLLATERAL_POOL = L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE
           WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
             AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE
             AND COLLATERAL_TYPE = L_REC_OD_COLL(I).COLLATERAL_TYPE
             AND COLLATERAL = L_REC_OD_COLL(I).COLLATERAL;
        
          IF L_REC_OD_COLL(I).COLLATERAL_TYPE = 'T' THEN
            BEGIN
              SELECT *
                INTO L_ICTM_ACC
                FROM ICTM_ACC
               WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                 AND
                    
                     BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed while selecting the data from ictm_acc' ||
                    SQLERRM);
            END;
            IF L_ICTM_ACC.CLOSE_ON_MATURITY = 'Y' OR
               (L_ICTM_ACC.AUTO_ROLLOVER = 'Y' AND
               L_ICTM_ACC.ROLLOVER_TYPE IN ('S', 'T')) THEN
              BEGIN
                SELECT AC_OPEN_DATE
                  INTO L_AC_OPEN_DATE
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = L_REC_OD_COLL(I).COLLATERAL
                   AND
                      
                       BRANCH_CODE = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed while selecting the ac_open_date from sttm_cust_account' ||
                      SQLERRM);
              END;
            
              SELECT COUNT(*)
                INTO L_CNT
                FROM ICTM_TDPAYOUT_DETAILS
               WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                 AND
                    
                     BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH
                 AND PAYOUT_COMPONENT = 'I';
            
              IF (L_CNT > 0 OR (L_CNT = 0 AND L_REC_OD_COLL(I)
                 .COLLATERAL <> L_ICTM_ACC.BOOK_ACC)) THEN
                L_ROLLOVER_TYPE := 'P';
              ELSIF (L_CNT = 0 AND L_REC_OD_COLL(I)
                    .COLLATERAL = L_ICTM_ACC.BOOK_ACC) THEN
                L_ROLLOVER_TYPE := 'I';
              END IF;
            
              BEGIN
              
                SELECT NVL(RECOMPUTE_MAT_DATE, 'N'),
                       NVL(DEFAULT_TENOR_DAYS, 0),
                       NVL(DEFAULT_TENOR_MONTHS, 0),
                       NVL(DEFAULT_TENOR_YEARS, 0)
                  INTO L_RECOMPUTE_MAT_DATE,
                       L_DFLT_DAYS,
                       L_DFLT_MONTHS,
                       L_DFLT_YEARS
                  FROM STTM_ACCOUNT_CLASS
                 WHERE ACCOUNT_CLASS IN
                       (SELECT ACCOUNT_CLASS
                          FROM STTM_CUST_ACCOUNT
                         WHERE CUST_AC_NO = L_ICTM_ACC.ACC);
              
                DBG('Recompute maturity date on rollover' ||
                    L_RECOMPUTE_MAT_DATE);
                DBG('Default tenor days' || L_DFLT_DAYS);
                DBG('Default tenor months' || L_DFLT_MONTHS);
                DBG('Default tenor years' || L_DFLT_YEARS);
                DBG('Original tenor in years' ||
                    L_ICTM_ACC.ORIG_TENOR_YEARS);
                DBG('Original tenor in months' ||
                    L_ICTM_ACC.ORIG_TENOR_MONTHS);
                DBG('Original tenor in days' || L_ICTM_ACC.ORIG_TENOR_DAYS);
              
                IF L_RECOMPUTE_MAT_DATE = 'Y' THEN
                  DBG('Recompute maturity date on rollover is set Y at account class level');
                  L_NEXT_MATURITY_DATE       := ADD_MONTHS(L_ICTM_ACC.MATURITY_DATE,
                                                           L_DFLT_MONTHS +
                                                           L_DFLT_YEARS * 12) +
                                                L_DFLT_DAYS;
                  L_ICTM_ACC.ROLL_TENOR_PREF := 'L';
                  DBG('Next maturity date on force rollover' ||
                      L_NEXT_MATURITY_DATE);
                ELSE
                  DBG('Recompute maturity date on rollover is set N at account class level');
                  L_NEXT_MATURITY_DATE       := ADD_MONTHS(L_ICTM_ACC.MATURITY_DATE,
                                                           L_ICTM_ACC.ORIG_TENOR_MONTHS +
                                                           L_ICTM_ACC.ORIG_TENOR_YEARS * 12) +
                                                L_ICTM_ACC.ORIG_TENOR_DAYS;
                  L_ICTM_ACC.ROLL_TENOR_PREF := 'A';
                  DBG('Next maturity date on force rollover' ||
                      L_NEXT_MATURITY_DATE);
                END IF;
              
                UPDATE ICTM_ACC
                   SET AUTO_ROLLOVER      = 'Y',
                       CLOSE_ON_MATURITY  = 'N',
                       NEXT_MATURITY_DATE = L_NEXT_MATURITY_DATE,
                       ROLLOVER_TYPE      = L_ROLLOVER_TYPE,
                       
                       ROLL_TENOR_PREF = L_ICTM_ACC.ROLL_TENOR_PREF,
                       
                       ROLL_TENOR_YEARS  = NVL(L_ICTM_ACC.ORIG_TENOR_YEARS,
                                               0),
                       ROLL_TENOR_MONTHS = NVL(L_ICTM_ACC.ORIG_TENOR_MONTHS,
                                               0),
                       ROLL_TENOR_DAYS   = NVL(L_ICTM_ACC.ORIG_TENOR_DAYS, 0)
                
                 WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                   AND
                      
                       BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
              
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed during updating tenor and next maturity date on force rollover' ||
                      SQLERRM);
              END;
            
            END IF;
          END IF;
        END LOOP;
      
      END IF;
    
      IF P_AUTH_FLG = 'Y' AND L_POOL_CNT > 0 THEN
        DBG('case 2 modify');
        DBG('inside modify');
      
        BEGIN
          SELECT COLLATERAL_CODE,
                 BRANCH_CODE,
                 LINKED_AMOUNT,
                 RATE_OF_INTEREST,
                 POOL_CODE,
                 AVAILABLE_INTEREST_RATE
            BULK COLLECT
            INTO L_POOL_LINKAGES
            FROM ELVW_POOL_COLL_LINKAGES_ODINT L
           WHERE L.LIAB_ID = L_LIAB_ID
             AND EXISTS
           (SELECT 1
                    FROM STTMS_CUST_ACCOUNT_LINKAGES C
                   WHERE C.CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
                     AND C.BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE
                     AND C.LINKED_REF_NO LIKE P_REC_CUSTACC.CUST_NO || 'P%'
                     AND C.LINKED_REF_NO = L.POOL_CODE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed while selecting the elvw_pool_coll_linkages_odint' ||
                SQLERRM);
        END;
      
        DBG('HERE1');
        IF L_REC_OD_COLL.COUNT > 0 THEN
          FOR L_OD_INDEX IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
            L_ACTION   := 'NEW';
            L_MODIFIED := FALSE;
            DBG('outer loop');
            IF L_POOL_LINKAGES.COUNT > 0 THEN
              FOR L_POOL IN L_POOL_LINKAGES.FIRST .. L_POOL_LINKAGES.LAST
              
               LOOP
              
                IF L_POOL_LINKAGES(L_POOL).COLLATERAL_CODE = L_REC_OD_COLL(L_OD_INDEX)
                   .COLLATERAL_CODE THEN
                  L_ACTION := 'MODIFY';
                
                  SELECT A.CATEGORY_NAME, B.HAIRCUT
                    INTO L_CATEGORY_NAME, L_HAIRCUT_PERCENT
                    FROM GETMS_COLL_CATEGORY A, GETMS_COLLAT B
                   WHERE A.ID = B.CATEGORY_ID
                     AND B.COLLATERAL_CODE = L_POOL_LINKAGES(L_POOL)
                        .COLLATERAL_CODE;
                  DBG('l_category_name>>' || L_CATEGORY_NAME);
                  DBG('l_haircut_percent>>' || L_HAIRCUT_PERCENT);
                  DBG('l_Rec_od_coll(l_od_index).category_name>>' || L_REC_OD_COLL(L_OD_INDEX)
                      .CATEGORY_NAME);
                  DBG('l_Rec_od_coll(l_od_index).haircut>>' || L_REC_OD_COLL(L_OD_INDEX)
                      .HAIRCUT);
                
                  IF (L_POOL_LINKAGES(L_POOL).BRANCH_CODE <> L_REC_OD_COLL(L_OD_INDEX)
                     .COLLATERAL_BRANCH) OR
                     (L_POOL_LINKAGES(L_POOL).LINKED_AMOUNT <> L_REC_OD_COLL(L_OD_INDEX)
                     .LINKED_AMOUNT) OR (L_CATEGORY_NAME <> L_REC_OD_COLL(L_OD_INDEX)
                     .CATEGORY_NAME) OR (L_HAIRCUT_PERCENT <> L_REC_OD_COLL(L_OD_INDEX)
                     .HAIRCUT) OR (L_POOL_LINKAGES(L_POOL).AVAILABLE_INTEREST_RATE <> L_REC_OD_COLL(L_OD_INDEX)
                     .COLL_INT_RATE)
                  
                   THEN
                    L_MODIFIED    := TRUE;
                    L_POOL_MODIFY := TRUE;
                  END IF;
                  IF (L_POOL_LINKAGES(L_POOL).RATE_OF_INTEREST <> L_REC_OD_COLL(L_OD_INDEX)
                     .OD_INT_RATE) THEN
                    L_POOL_MODIFY := TRUE;
                  
                  END IF;
                  EXIT;
                END IF;
                DBG('l_action ::' || L_ACTION);
              
              END LOOP;
            END IF;
            DBG('l_action1---> ::' || L_ACTION);
          
            IF ((L_ACTION = 'MODIFY' AND L_MODIFIED = TRUE) OR
               L_ACTION = 'NEW') AND L_REC_OD_COLL(L_OD_INDEX)
              .COLLATERAL_TYPE <> 'C' THEN
              DBG('inside IF modify collateral_type <> C');
            
              L_COLL_IDX1 := L_COLL_IDX1 + 1;
            
              DBG('entering the call for collateral creation');
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ACTION := L_ACTION;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIABILITY := L_LIAB_ID;
            
              IF L_ACTION = 'MODIFY' THEN
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCODE := L_REC_OD_COLL(L_OD_INDEX)
                                                                                .COLLATERAL_CODE;
              ELSE
                LOOP
                  BEGIN
                    L_IDX := L_IDX + 1;
                    SELECT COUNT(*)
                      INTO L_COUNT
                      FROM GETM_COLLAT
                     WHERE COLLATERAL_CODE = P_REC_CUSTACC.CUST_NO || L_IDX;
                    IF L_COUNT = 0 THEN
                      L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCODE := P_REC_CUSTACC.CUST_NO ||
                                                                                      L_IDX;
                      EXIT;
                    END IF;
                  END;
                END LOOP;
              END IF;
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALDESCRIPTION := NVL(P_REC_CUSTACC.AC_DESC,
                                                                                         P_REC_CUSTACC.CUST_AC_NO);
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCATEGORY := L_REC_OD_COLL(L_OD_INDEX)
                                                                                  .CATEGORY_NAME;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALVALUE := L_REC_OD_COLL(L_OD_INDEX)
                                                                               .LINKED_AMOUNT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LENDABLEMARGIN := '100';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIMIT_CONTRIBUTION := L_REC_OD_COLL(L_OD_INDEX)
                                                                                  .LINKED_AMOUNT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.START_DATE := GLOBAL.APPLICATION_DATE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.END_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVIEW_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SECURITY_NAME := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.NUMBER_OF_UNITS := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CAP_AMOUNT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.PRICE_CODE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LAST_REVAL_PRICE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CHARGE_TYPE := 'M';
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIAB_BRANCH := L_LIAB_BRN;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVAL_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVAL_COLLAT := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.USER_REFNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ISSUER_NAME := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ISSUER_REF_NO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.GUARANTOR_ID := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.RATING := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVOKEABLE := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVOKEDATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERAL_TYPE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.GRACE_DAYS := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SECURED := 'S';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.NEXT_REVAL_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.HAIRCUT := L_REC_OD_COLL(L_OD_INDEX)
                                                                       .HAIRCUT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AVAILABLE := 'Y';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SHARING_REQ := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AUTO_POOL_CREATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CONTRACT_SOURCE_REF_NO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.MORTGAGE_INITIATED := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.INTEREST_RATE := L_REC_OD_COLL(L_OD_INDEX)
                                                                             .COLL_INT_RATE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.UTIL_AMT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AVAILABLE_AMOUNT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_PRODUCT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_REFNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_SETTLBRN := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_SETTLACC := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_BRANCH := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SOURCE := NULL;
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.EXTRESTTYPE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.MODNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AUTHSTAT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.RECSTAT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ONCEAUTH := NULL;
            
              IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE = 'T' THEN
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1).COLL_ID := L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1)
                                                                                       .A_COLLAT.COLLATERALCODE;
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1).CONTRACT_REF_NO := L_REC_OD_COLL(L_OD_INDEX)
                                                                                               .COLLATERAL;
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1).CONTRACT_CONTRIBUTION := L_REC_OD_COLL(L_OD_INDEX)
                                                                                                     .LINKED_AMOUNT;
              
                L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1).CONTRACT_BRANCH := L_REC_OD_COLL(L_OD_INDEX)
                                                                                               .COLLATERAL_BRANCH;
                DBG('Before assigning values for collateralpool linkages');
              
              END IF;
              L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_CODE := L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1)
                                                           .A_COLLAT.COLLATERALCODE;
            ELSIF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE = 'C' THEN
              L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_CODE := L_REC_OD_COLL(L_OD_INDEX)
                                                           .COLLATERAL;
              DBG('1 collateral modify');
            END IF;
          END LOOP;
        END IF;
      
        DBG('here2');
        IF L_POOL_LINKAGES.COUNT > 0 THEN
          FOR L_POOL IN L_POOL_LINKAGES.FIRST .. L_POOL_LINKAGES.LAST LOOP
            DBG('INSIDE THE LOOP FOR COLLATERAL CLOSE');
            L_ACTION   := 'CLOSE';
            L_MODIFIED := TRUE;
            DBG('outer loop');
            IF L_REC_OD_COLL.COUNT > 0 THEN
              FOR L_OD_INDEX IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
                DBG('1 l_Rec_od_coll(l_od_index).collateral_code' || L_REC_OD_COLL(L_OD_INDEX)
                    .COLLATERAL_CODE);
                IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_CODE = L_POOL_LINKAGES(L_POOL)
                   .COLLATERAL_CODE THEN
                  L_MODIFIED := FALSE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF (L_ACTION = 'CLOSE' AND L_MODIFIED = TRUE AND L_POOL_LINKAGES(L_POOL)
               .COLLATERAL_CODE LIKE P_REC_CUSTACC.CUST_NO || '%') THEN
            
              L_COLL_IDX1 := L_COLL_IDX1 + 1;
              SELECT CATEGORY_NAME, HAIRCUT_PERCENT
                INTO L_CATEGORY_NAME, L_HAIRCUT_PERCENT
                FROM GETMS_COLL_CATEGORY A, GETMS_CATEGORY_HAIRCUT B
               WHERE A.ID = B.COLL_CATEGORY_ID
                 AND EXISTS (SELECT 1
                        FROM GETMS_COLLAT COLL
                       WHERE COLL.CATEGORY_ID = A.ID
                         AND COLL.COLLATERAL_CODE = L_POOL_LINKAGES(L_POOL)
                            .COLLATERAL_CODE);
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ACTION := L_ACTION;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIABILITY := L_LIAB_ID;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCODE := L_POOL_LINKAGES(L_POOL)
                                                                              .COLLATERAL_CODE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALDESCRIPTION := NVL(P_REC_CUSTACC.AC_DESC,
                                                                                         P_REC_CUSTACC.CUST_AC_NO);
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCATEGORY := L_CATEGORY_NAME;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERALVALUE := L_POOL_LINKAGES(L_POOL)
                                                                               .LINKED_AMOUNT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LENDABLEMARGIN := '100';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIMIT_CONTRIBUTION := L_POOL_LINKAGES(L_POOL)
                                                                                  .LINKED_AMOUNT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.START_DATE := GLOBAL.APPLICATION_DATE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.END_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVIEW_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SECURITY_NAME := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.NUMBER_OF_UNITS := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CAP_AMOUNT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.PRICE_CODE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LAST_REVAL_PRICE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CHARGE_TYPE := 'M';
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.LIAB_BRANCH := L_LIAB_BRN;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVAL_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVAL_COLLAT := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.USER_REFNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ISSUER_NAME := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ISSUER_REF_NO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.GUARANTOR_ID := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.RATING := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVOKEABLE := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.REVOKEDATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COLLATERAL_TYPE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.GRACE_DAYS := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SECURED := 'S';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.NEXT_REVAL_DATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.HAIRCUT := L_HAIRCUT_PERCENT;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AVAILABLE := 'Y';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SHARING_REQ := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AUTO_POOL_CREATE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.CONTRACT_SOURCE_REF_NO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.MORTGAGE_INITIATED := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.INTEREST_RATE := L_POOL_LINKAGES(L_POOL)
                                                                             .AVAILABLE_INTEREST_RATE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.UTIL_AMT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AVAILABLE_AMOUNT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_PRODUCT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_REFNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_SETTLBRN := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_SETTLACC := 'N';
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.COMMITMENT_BRANCH := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.SOURCE := NULL;
            
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.EXTRESTTYPE := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.MODNO := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.AUTHSTAT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.RECSTAT := NULL;
              L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLLAT.ONCEAUTH := NULL;
            
              BEGIN
                SELECT A.COLL_ID,
                       A.CONTRACT_REF_NO,
                       A.CONTRACT_CONTRIBUTION,
                       A.CONTRACT_BRANCH
                  INTO L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1)
                       .COLL_ID,
                       L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1)
                       .CONTRACT_REF_NO,
                       L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1)
                       .CONTRACT_CONTRIBUTION,
                       L_GEDAPOOL.A_COLLATERAL(L_COLL_IDX1).A_COLL_CONT_CONTRIB(1)
                       .CONTRACT_BRANCH
                
                  FROM GETM_COLLAT_CONT_CONTRIB A, GETMS_COLLAT B
                 WHERE A.ID = B.CATEGORY_ID
                   AND B.COLLATERAL_CODE = L_POOL_LINKAGES(L_POOL)
                      .COLLATERAL_CODE;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('Its not linked to a TD');
              END;
              L_POOL_MODIFY := TRUE;
            
            ELSIF (L_ACTION = 'CLOSE' AND L_MODIFIED = TRUE) THEN
              L_POOL_MODIFY := TRUE;
            END IF;
          
          END LOOP;
        END IF;
      
        IF (L_GEDAPOOL.A_COLLATERAL.COUNT > 0 OR L_POOL_MODIFY = TRUE) AND
           L_REC_OD_COLL.COUNT > 0 THEN
          DBG('Case 2.1 where pools still exist on modification');
          DBG('call for pool linkages');
          FOR L_OD_INDEX IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
            IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE = 'T' THEN
              BEGIN
              
                SELECT MATURITY_DATE
                  INTO L_EXPIRY_DT
                  FROM ICTM_ACC
                 WHERE ACC = L_REC_OD_COLL(L_OD_INDEX).COLLATERAL
                   AND
                      
                       BRN = L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_BRANCH;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed IN SELECT FOR EXPIRY DATE' || SQLERRM);
              END;
            END IF;
          
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERAL_CODE := L_REC_OD_COLL(L_OD_INDEX)
                                                                            .COLLATERAL_CODE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERAL_DESC := NVL(P_REC_CUSTACC.AC_DESC,
                                                                                P_REC_CUSTACC.CUST_AC_NO);
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).COLLATERALAMOUNT := L_REC_OD_COLL(L_OD_INDEX)
                                                                             .LINKED_AMOUNT;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).ORDER_NO := NULL;
          
            IF L_REC_OD_COLL(L_OD_INDEX).COLLATERAL_TYPE IN ('C', 'U') THEN
              DBG('This is of collateral type');
            
              L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKEDAMOUNT := L_REC_OD_COLL(L_OD_INDEX)
                                                                           .LINKED_AMOUNT;
            
            ELSE
              DBG('This is of TD type');
              L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKEDAMOUNT := NULL;
            END IF;
          
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).LINKED_AMOUNT_POOL_CCY := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).UTILIZATION := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).POOL_TYPE := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).AVAILABLE_INT_RATE := L_REC_OD_COLL(L_OD_INDEX)
                                                                               .COLL_INT_RATE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).INTERESTSPREAD := L_REC_OD_COLL(L_OD_INDEX)
                                                                           .INT_SPREAD;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).RATE_OF_INTEREST := L_REC_OD_COLL(L_OD_INDEX)
                                                                             .OD_INT_RATE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_OD_INDEX).EXPIRYDATE := L_EXPIRY_DT;
          
          END LOOP;
        
          DBG('call for pool1');
        
          L_GEDAPOOL.AUTO_COLLPOOL.LIAB_NO              := L_LIAB_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE            := L_REC_OD_COLL(1)
                                                           .COLLATERAL_POOL;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_DESCRIPTION     := NVL(P_REC_CUSTACC.AC_DESC,
                                                               P_REC_CUSTACC.CUST_AC_NO);
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_CCY             := P_REC_CUSTACC.CCY;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_AMOUNT          := '';
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_UTIL            := '';
          L_GEDAPOOL.AUTO_COLLPOOL.AUTO_FACILITY_CREATE := 'N';
          L_GEDAPOOL.AUTO_COLLPOOL.MORTGAGE_INITIATED   := 'N';
          L_GEDAPOOL.AUTO_COLLPOOL.AVAILABLE_AMOUNT     := NULL;
          L_GEDAPOOL.AUTO_COLLPOOL.MAKER_ID             := GLOBAL.USER_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.MAKER_DT_STAMP       := GLOBAL.APPLICATION_DATE;
          L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_ID           := GLOBAL.USER_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_DT_STAMP     := GLOBAL.APPLICATION_DATE;
          L_GEDAPOOL.AUTO_COLLPOOL.MOD_NO               := NULL;
          L_GEDAPOOL.AUTO_COLLPOOL.AUTH_STAT            := 'A';
          L_GEDAPOOL.AUTO_COLLPOOL.RECORD_STAT          := 'O';
          L_GEDAPOOL.AUTO_COLLPOOL.ONCE_AUTH            := 'Y';
          DBG(' l_Gedapool.auto_CollPool.pool_code ' || L_REC_OD_COLL(1)
              .COLLATERAL_POOL);
        
          IF NOT FN_AUTOCREATE_COLL_POOL(L_GEDAPOOL,
                                         P_REC_CUSTACC,
                                         P_GEDCOLLAT,
                                         P_GEDCPOOL,
                                         'MODIFY',
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
            DBG('failed in Fn_autocreate_coll_pool');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         L_ERR_CODE,
                         L_ERR_PARAM);
            RETURN FALSE;
          END IF;
        
          FOR I IN L_REC_OD_COLL.FIRST .. L_REC_OD_COLL.LAST LOOP
            IF L_REC_OD_COLL(I).COLLATERAL_CODE IS NULL THEN
              UPDATE STTM_OD_COLL_LINKAGES
                 SET COLLATERAL_CODE = L_REC_OD_COLL(I).COLLATERAL_CODE,
                     COLLATERAL_POOL = L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE
               WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
                 AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE
                 AND COLLATERAL_TYPE = L_REC_OD_COLL(I).COLLATERAL_TYPE
                 AND COLLATERAL = L_REC_OD_COLL(I).COLLATERAL;
            
              IF L_REC_OD_COLL(I).COLLATERAL_TYPE = 'T' THEN
                BEGIN
                  SELECT *
                    INTO L_ICTM_ACC
                    FROM ICTM_ACC
                   WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                     AND
                        
                         BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('Failed while selecting the data from ictm_acc' ||
                        SQLERRM);
                END;
                IF L_ICTM_ACC.CLOSE_ON_MATURITY = 'Y' OR
                   (L_ICTM_ACC.AUTO_ROLLOVER = 'Y' AND
                   L_ICTM_ACC.ROLLOVER_TYPE IN ('S', 'T')) THEN
                  BEGIN
                    SELECT AC_OPEN_DATE
                      INTO L_AC_OPEN_DATE
                      FROM STTM_CUST_ACCOUNT
                     WHERE CUST_AC_NO = L_REC_OD_COLL(I).COLLATERAL
                       AND
                          
                           BRANCH_CODE = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('Failed while selecting the ac_open_date from sttm_cust_account' ||
                          SQLERRM);
                  END;
                
                  SELECT COUNT(*)
                    INTO L_CNT
                    FROM ICTM_TDPAYOUT_DETAILS
                   WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                     AND
                        
                         BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH
                     AND PAYOUT_COMPONENT = 'I';
                
                  IF (L_CNT > 0 OR (L_CNT = 0 AND L_REC_OD_COLL(I)
                     .COLLATERAL <> L_ICTM_ACC.BOOK_ACC)) THEN
                    L_ROLLOVER_TYPE := 'P';
                  ELSIF (L_CNT = 0 AND L_REC_OD_COLL(I)
                        .COLLATERAL = L_ICTM_ACC.BOOK_ACC) THEN
                    L_ROLLOVER_TYPE := 'I';
                  END IF;
                
                  BEGIN
                    SELECT NVL(RECOMPUTE_MAT_DATE, 'N'),
                           NVL(DEFAULT_TENOR_DAYS, 0),
                           NVL(DEFAULT_TENOR_MONTHS, 0),
                           NVL(DEFAULT_TENOR_YEARS, 0)
                      INTO L_RECOMPUTE_MAT_DATE,
                           L_DFLT_DAYS,
                           L_DFLT_MONTHS,
                           L_DFLT_YEARS
                      FROM STTM_ACCOUNT_CLASS
                     WHERE ACCOUNT_CLASS IN
                           (SELECT ACCOUNT_CLASS
                              FROM STTM_CUST_ACCOUNT
                             WHERE CUST_AC_NO = L_ICTM_ACC.ACC);
                  
                    DBG('Recompute maturity date on rollover' ||
                        L_RECOMPUTE_MAT_DATE);
                    DBG('Default tenor days' || L_DFLT_DAYS);
                    DBG('Default tenor months' || L_DFLT_MONTHS);
                    DBG('Default tenor years' || L_DFLT_YEARS);
                    DBG('Original tenor in years' ||
                        L_ICTM_ACC.ORIG_TENOR_YEARS);
                    DBG('Original tenor in months' ||
                        L_ICTM_ACC.ORIG_TENOR_MONTHS);
                    DBG('Original tenor in days' ||
                        L_ICTM_ACC.ORIG_TENOR_DAYS);
                  
                    IF L_RECOMPUTE_MAT_DATE = 'Y' THEN
                      DBG('Recompute maturity date on rollover is set Y at account class level');
                      L_NEXT_MATURITY_DATE       := ADD_MONTHS(L_ICTM_ACC.MATURITY_DATE,
                                                               L_DFLT_MONTHS +
                                                               L_DFLT_YEARS * 12) +
                                                    L_DFLT_DAYS;
                      L_ICTM_ACC.ROLL_TENOR_PREF := 'L';
                      DBG('Next maturity date on force rollover' ||
                          L_NEXT_MATURITY_DATE);
                    ELSE
                      DBG('Recompute maturity date on rollover is set N at account class level');
                      L_NEXT_MATURITY_DATE       := ADD_MONTHS(L_ICTM_ACC.MATURITY_DATE,
                                                               L_ICTM_ACC.ORIG_TENOR_MONTHS +
                                                               L_ICTM_ACC.ORIG_TENOR_YEARS * 12) +
                                                    L_ICTM_ACC.ORIG_TENOR_DAYS;
                      L_ICTM_ACC.ROLL_TENOR_PREF := 'A';
                      DBG('Next maturity date on force rollover' ||
                          L_NEXT_MATURITY_DATE);
                    END IF;
                  
                    UPDATE ICTM_ACC
                       SET AUTO_ROLLOVER      = 'Y',
                           CLOSE_ON_MATURITY  = 'N',
                           NEXT_MATURITY_DATE = L_NEXT_MATURITY_DATE,
                           ROLLOVER_TYPE      = L_ROLLOVER_TYPE,
                           
                           ROLL_TENOR_PREF   = L_ICTM_ACC.ROLL_TENOR_PREF,
                           ROLL_TENOR_YEARS  = NVL(L_ICTM_ACC.ORIG_TENOR_YEARS,
                                                   0),
                           ROLL_TENOR_MONTHS = NVL(L_ICTM_ACC.ORIG_TENOR_MONTHS,
                                                   0),
                           ROLL_TENOR_DAYS   = NVL(L_ICTM_ACC.ORIG_TENOR_DAYS,
                                                   0)
                    
                     WHERE ACC = L_REC_OD_COLL(I).COLLATERAL
                       AND
                          
                           BRN = L_REC_OD_COLL(I).COLLATERAL_BRANCH;
                  
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('Failed during updating tenor and next maturity date on force rollover' ||
                          SQLERRM);
                  END;
                
                END IF;
              END IF;
            END IF;
          END LOOP;
        
        ELSIF (L_GEDAPOOL.A_COLLATERAL.COUNT > 0 OR L_POOL_MODIFY = TRUE) AND
              L_REC_OD_COLL.COUNT = 0 THEN
          DBG('entered into the total close...!');
        
          DBG('building close for the pool close.');
        
          L_GEDAPOOL.AUTO_COLLPOOL.LIAB_NO              := L_LIAB_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE            := L_POOL_LINKAGES(1)
                                                           .POOL_CODE;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_DESCRIPTION     := NVL(P_REC_CUSTACC.AC_DESC,
                                                               P_REC_CUSTACC.CUST_AC_NO);
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_CCY             := P_REC_CUSTACC.CCY;
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_AMOUNT          := '';
          L_GEDAPOOL.AUTO_COLLPOOL.POOL_UTIL            := '';
          L_GEDAPOOL.AUTO_COLLPOOL.AUTO_FACILITY_CREATE := 'N';
          L_GEDAPOOL.AUTO_COLLPOOL.MORTGAGE_INITIATED   := 'N';
          L_GEDAPOOL.AUTO_COLLPOOL.AVAILABLE_AMOUNT     := NULL;
          L_GEDAPOOL.AUTO_COLLPOOL.MAKER_ID             := GLOBAL.USER_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.MAKER_DT_STAMP       := GLOBAL.APPLICATION_DATE;
          L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_ID           := GLOBAL.USER_ID;
          L_GEDAPOOL.AUTO_COLLPOOL.CHECKER_DT_STAMP     := GLOBAL.APPLICATION_DATE;
          L_GEDAPOOL.AUTO_COLLPOOL.MOD_NO               := NULL;
          L_GEDAPOOL.AUTO_COLLPOOL.AUTH_STAT            := 'A';
          L_GEDAPOOL.AUTO_COLLPOOL.RECORD_STAT          := 'O';
          L_GEDAPOOL.AUTO_COLLPOOL.ONCE_AUTH            := 'Y';
          DBG(' l_Gedapool.auto_CollPool.pool_code in close ' || L_POOL_LINKAGES(1)
              .POOL_CODE);
        
          L_INDEX := 0;
          FOR R_POOL_LINK IN (SELECT Y.COLLATERAL_CODE,
                                     X.LINKED_AMOUNT,
                                     X.AVAILABLE_INTEREST_RATE AS COLL_INT_RATE,
                                     X.INTEREST_SPREAD         AS INT_SPREAD,
                                     X.RATE_OF_INTEREST        AS OD_INT_RATE,
                                     X.EXPIRY_DATE
                                FROM GETM_POOL_COLL_LINKAGES X,
                                     GETM_COLLAT             Y,
                                     GETM_POOL               P
                               WHERE X.COLLATERAL_ID = Y.ID
                                 AND X.POOL_ID = P.ID
                                 AND P.POOL_CODE = L_POOL_LINKAGES(1)
                                    .POOL_CODE) LOOP
            DBG('Inside r_pool_link Loop..');
            L_INDEX := L_INDEX + 1;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).COLLATERAL_CODE := R_POOL_LINK.COLLATERAL_CODE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).COLLATERAL_DESC := NVL(P_REC_CUSTACC.AC_DESC,
                                                                             P_REC_CUSTACC.CUST_AC_NO);
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).COLLATERALCURRENCY := P_REC_CUSTACC.CCY;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).COLLATERALAMOUNT := R_POOL_LINK.LINKED_AMOUNT;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).ORDER_NO := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).LINKEDAMOUNT := R_POOL_LINK.LINKED_AMOUNT;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).LINKED_AMOUNT_POOL_CCY := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).UTILIZATION := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).POOL_TYPE := NULL;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).AVAILABLE_INT_RATE := R_POOL_LINK.COLL_INT_RATE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).INTERESTSPREAD := R_POOL_LINK.INT_SPREAD;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).RATE_OF_INTEREST := R_POOL_LINK.OD_INT_RATE;
            L_GEDAPOOL.AUTO_COLLPOOLLINKAGES(L_INDEX).EXPIRYDATE := R_POOL_LINK.EXPIRY_DATE;
          END LOOP;
        
          IF NOT FN_AUTOCREATE_COLL_POOL(L_GEDAPOOL,
                                         P_REC_CUSTACC,
                                         P_GEDCOLLAT,
                                         P_GEDCPOOL,
                                         'CLOSE',
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
            DBG('failed in Fn_autocreate_coll_pool');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         L_ERR_CODE,
                         L_ERR_PARAM);
            RETURN FALSE;
          END IF;
        
          DELETE FROM STTM_CUST_ACCOUNT_LINKAGES
           WHERE BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE
             AND CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
             AND CUSTOMER_NO = P_REC_CUSTACC.CUST_NO
             AND LINKAGE_TYPE = 'P'
             AND LINKED_REF_NO LIKE P_REC_CUSTACC.CUST_NO || 'P' || '%';
        
        END IF;
      END IF;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('It is in when others-fn_collateral_pool_linkages');
      DBG('In WOT of fn_collateral_pool_linkages with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_COLLATERAL_POOL_LINKAGES;

  FUNCTION FN_AUTOCREATE_COLL_POOL(P_GEDAPOOL    IN ELPKS_COLLATERAL_SERVICE.TY_GEDAPOOL,
                                   P_REC_CUSTACC IN STTMS_CUST_ACCOUNT%ROWTYPE,
                                   P_GEDCOLLAT   OUT ELPKS_COLLATERAL_SERVICE.TY_GEDCOLLAT,
                                   P_GEDCPOOL    OUT ELPKS_COLLATERAL_SERVICE.TY_GEDCPOOL,
                                   P_ACTION_CODE IN VARCHAR2,
                                   P_ERR_CODE    IN OUT VARCHAR2,
                                   P_ERR_PARAM   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_STATUS       VARCHAR2(1000);
    L_MULTITRIP_ID VARCHAR2(20) := NULL;
    L_USER_ID      SMTB_USER.USER_ID%TYPE;
    L_LIAB_BRN     GETM_LIAB.LIAB_BRANCH%TYPE;
  BEGIN
    DBG('Inside Fn_autopooltype_convert for converting type of auto pool to collateral and pool type. ');
    DBG('collateral type ');
    DBG('p_Gedapool.auto_CollPoolLinkages.COUNT --->>>' ||
        P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.COUNT);
    L_USER_ID := GLOBAL.USER_ID;
  
    BEGIN
      SELECT LIAB_BRANCH
        INTO L_LIAB_BRN
        FROM GETM_LIAB
       WHERE LIAB_NO = P_GEDAPOOL.AUTO_COLLPOOL.LIAB_NO;
      DBG('l_liab_brn -->' || L_LIAB_BRN);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get liab_branch' || SQLERRM);
    END;
  
    IF P_GEDAPOOL.A_COLLATERAL.COUNT > 0 THEN
      FOR APOOLCNT IN P_GEDAPOOL.A_COLLATERAL.FIRST .. P_GEDAPOOL.A_COLLATERAL.LAST LOOP
        IF P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLLAT.ACTION <> 'CLOSE' THEN
          P_GEDCOLLAT.COLLATERAL         := TY_COLLAT_MASTER(NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL
                                                             
                                                             );
          P_GEDCOLLAT.COLL_COVENANT      := TY_COLL_COVENANTS();
          P_GEDCOLLAT.COLL_INSURANCE     := TY_COLL_INSURANCES();
          P_GEDCOLLAT.COLL_CONT_CONTRIB  := TY_COLLAT_CONT_CONTRIBS();
          P_GEDCOLLAT.COLL_SHARING       := TY_SHARING_DETAILSS();
          P_GEDCOLLAT.COLL_UDE_VALUESS   := TY_COLLAT_UDE_VALUESS();
          P_GEDCOLLAT.COLL_EXT_SYS_RESTS := TY_COLLAT_EXT_SYS_RESTS();
          P_GEDCOLLAT.COLL_HAIRCUTS      := TY_COLL_HAIRCUTS();
        
          P_GEDCOLLAT.COLLATERAL.LIAB_NO                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.LIABILITY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_CODE        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCODE;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_DESCRIPTION := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALDESCRIPTION;
          P_GEDCOLLAT.COLLATERAL.CATEGORY_NAME          := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCATEGORY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_CURRENCY    := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCURRENCY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_VALUE       := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALVALUE;
          P_GEDCOLLAT.COLLATERAL.HAIRCUT                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.HAIRCUT;
          P_GEDCOLLAT.COLLATERAL.START_DATE             := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.START_DATE;
          P_GEDCOLLAT.COLLATERAL.CHARGE_TYPE            := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.CHARGE_TYPE;
          P_GEDCOLLAT.COLLATERAL.REVAL_COLLAT           := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.REVAL_COLLAT;
          P_GEDCOLLAT.COLLATERAL.SECURED                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.SECURED;
        
          P_GEDCOLLAT.COLLATERAL.LIAB_BRANCH        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.LIAB_BRANCH;
          P_GEDCOLLAT.COLLATERAL.SHARING_REQ        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.SHARING_REQ;
          P_GEDCOLLAT.COLLATERAL.AUTO_POOL_CREATE   := 'N';
          P_GEDCOLLAT.COLLATERAL.BRANCH_CODE        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.BRANCH_CODE;
          P_GEDCOLLAT.COLLATERAL.AVAILABLE          := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.AVAILABLE;
          P_GEDCOLLAT.COLLATERAL.MORTGAGE_INITIATED := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.MORTGAGE_INITIATED;
          P_GEDCOLLAT.COLLATERAL.INTEREST_RATE      := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.INTEREST_RATE;
          P_GEDCOLLAT.COLLATERAL.CUSTOMER_NO        := P_REC_CUSTACC.CUST_NO;
        
          DBG('collateral contribution type ');
        
          IF P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB.COUNT > 0 THEN
            P_GEDCOLLAT.COLL_CONT_CONTRIB.EXTEND;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1) := TY_COLLAT_CONT_CONTRIB(NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL
                                                                       
                                                                      ,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL
                                                                       
                                                                       );
          
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_REF_NO := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                .CONTRACT_REF_NO;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_CONTRIBUTION := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                      .CONTRACT_CONTRIBUTION;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_BRANCH := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                .CONTRACT_BRANCH;
          
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).ACCOUNT_TYPE := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                             .ACCOUNT_TYPE;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).ACCOUNT_BALANCE := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                .ACCOUNT_BALANCE;
          
            DBG('p_gedcollat.coll_cont_contrib(1).CONTRACT_REF_NO' || P_GEDCOLLAT.COLL_CONT_CONTRIB(1)
                .CONTRACT_REF_NO);
          
          ELSE
            DBG(' p_Gedapool.a_collateral(apoolcnt).a_coll_cont_contrib.delete');
          
          END IF;
          DBG('CALL FOR COLLATERAL CREATION NEW');
          IF NOT
              ELPKS_COLLATERAL_SERVICE.FN_COLLATERAL_PROCESS('FLEXCUBE',
                                                             P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                             .A_COLLAT.ACTION,
                                                             P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                             .A_COLLAT.ACTION,
                                                             L_MULTITRIP_ID,
                                                             P_GEDCOLLAT,
                                                             'N',
                                                             L_STATUS,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
            DBG('failed in fn_collateral_process');
            PR_LOG_ERROR('', 'FLEXCUBE', P_ERR_CODE, 'p_Err_Param');
            RETURN FALSE;
          ELSE
            DBG('SUCCESS FROM fn_collateral_process');
          END IF;
        END IF;
      END LOOP;
    END IF;
  
    DBG('p_Gedapool.auto_CollPoolLinkages.COUNT --->>>' ||
        P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.COUNT);
    IF P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.COUNT > 0 THEN
      DBG('initialising for pool linkages');
      P_GEDCPOOL.COLL_POOL := TY_POOL_MASTER(NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL
                                             
                                            ,
                                             NULL,
                                             NULL
                                             
                                             );
    
      P_GEDCPOOL.COLL_POOL_LINK := TY_POOL_COLL_LINKS();
    
      FOR APOOLLINK IN P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.FIRST .. P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.LAST LOOP
        DBG('BUILDING TYPE FOR POOL LINKAGES');
        DBG('apoollink' || APOOLLINK);
        P_GEDCPOOL.COLL_POOL_LINK.EXTEND;
      
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK) := TY_POOL_COLL_LINK(NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL,
                                                                  NULL);
      
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).COLLATERAL_CODE := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                .COLLATERAL_CODE;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).COLLATERAL_DESC := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                .COLLATERAL_DESC;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).COLLATERAL_CURRENCY := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                    .COLLATERALCURRENCY;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).COLLATERAL_AMOUNT := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                  .COLLATERALAMOUNT;
      
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).BRANCH_CODE := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                            .BRANCH_CODE;
      
        IF P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
         .LINKEDAMOUNT IS NOT NULL THEN
          DBG('This is of type collateral or unsecure');
        
          P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).LINKED_AMOUNT := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                .LINKEDAMOUNT;
        
        ELSE
          DBG('This is of type TD');
          P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).LINKED_PERCENT_NUMBER := '100';
        END IF;
      
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).AVAILABLE_INTEREST_RATE := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                        .AVAILABLE_INT_RATE;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).INTEREST_SPREAD := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                .INTERESTSPREAD;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).RATE_OF_INTEREST := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                                 .RATE_OF_INTEREST;
        P_GEDCPOOL.COLL_POOL_LINK(APOOLLINK).EXPIRY_DATE := P_GEDAPOOL.AUTO_COLLPOOLLINKAGES(APOOLLINK)
                                                            .EXPIRYDATE;
      END LOOP;
    
    ELSIF P_GEDAPOOL.AUTO_COLLPOOLLINKAGES.COUNT = 0 THEN
      DBG('initialising for pool linkages if AUTO_COLLPOOLLINKAGES has no data');
      P_GEDCPOOL.COLL_POOL := TY_POOL_MASTER(NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL);
      DBG('done with p_Gedcpool.coll_pool');
      P_GEDCPOOL.COLL_POOL_LINK := TY_POOL_COLL_LINKS();
      DBG('P_GEDCPOOL.COLL_POOL_LINK.count is :' ||
          P_GEDCPOOL.COLL_POOL_LINK.COUNT);
    END IF;
  
    DBG('type conversion for pool');
    P_GEDCPOOL.COLL_POOL.LIAB_NO          := P_GEDAPOOL.AUTO_COLLPOOL.LIAB_NO;
    P_GEDCPOOL.COLL_POOL.POOL_CODE        := P_GEDAPOOL.AUTO_COLLPOOL.POOL_CODE;
    P_GEDCPOOL.COLL_POOL.POOL_DESCRIPTION := P_GEDAPOOL.AUTO_COLLPOOL.POOL_DESCRIPTION;
    P_GEDCPOOL.COLL_POOL.POOL_CCY         := P_GEDAPOOL.AUTO_COLLPOOL.POOL_CCY;
    P_GEDCPOOL.COLL_POOL.POOL_AMOUNT      := P_GEDAPOOL.AUTO_COLLPOOL.POOL_AMOUNT;
    P_GEDCPOOL.COLL_POOL.POOL_UTIL        := P_GEDAPOOL.AUTO_COLLPOOL.POOL_UTIL;
  
    P_GEDCPOOL.COLL_POOL.LIAB_BRANCH          := L_LIAB_BRN;
    P_GEDCPOOL.COLL_POOL.RECORD_STAT          := P_GEDAPOOL.AUTO_COLLPOOL.RECORD_STAT;
    P_GEDCPOOL.COLL_POOL.AUTH_STAT            := P_GEDAPOOL.AUTO_COLLPOOL.AUTH_STAT;
    P_GEDCPOOL.COLL_POOL.MOD_NO               := P_GEDAPOOL.AUTO_COLLPOOL.MOD_NO;
    P_GEDCPOOL.COLL_POOL.MAKER_ID             := P_GEDAPOOL.AUTO_COLLPOOL.MAKER_ID;
    P_GEDCPOOL.COLL_POOL.MAKER_DT_STAMP       := P_GEDAPOOL.AUTO_COLLPOOL.MAKER_DT_STAMP;
    P_GEDCPOOL.COLL_POOL.CHECKER_ID           := P_GEDAPOOL.AUTO_COLLPOOL.CHECKER_ID;
    P_GEDCPOOL.COLL_POOL.CHECKER_DT_STAMP     := P_GEDAPOOL.AUTO_COLLPOOL.CHECKER_DT_STAMP;
    P_GEDCPOOL.COLL_POOL.ONCE_AUTH            := P_GEDAPOOL.AUTO_COLLPOOL.ONCE_AUTH;
    P_GEDCPOOL.COLL_POOL.MORTGAGE_INITIATED   := P_GEDAPOOL.AUTO_COLLPOOL.MORTGAGE_INITIATED;
    P_GEDCPOOL.COLL_POOL.AUTO_FACILITY_CREATE := P_GEDAPOOL.AUTO_COLLPOOL.AUTO_FACILITY_CREATE;
    P_GEDCPOOL.COLL_POOL.AVAILABLE_AMOUNT     := P_GEDAPOOL.AUTO_COLLPOOL.AVAILABLE_AMOUNT;
    DBG('CALL FOR POOL CREATION NEW');
    IF NOT
        ELPKS_COLLATERAL_SERVICE.FN_COLLATERAL_POOL_PROCESS('FLEXCUBE',
                                                            P_ACTION_CODE,
                                                            P_ACTION_CODE,
                                                            L_MULTITRIP_ID,
                                                            P_GEDCPOOL,
                                                            'N',
                                                            L_STATUS,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN
      DBG('failed in fn_collateral_process');
      PR_LOG_ERROR('', 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAM);
      RETURN FALSE;
    END IF;
  
    IF P_GEDAPOOL.A_COLLATERAL.COUNT > 0 THEN
      FOR APOOLCNT IN P_GEDAPOOL.A_COLLATERAL.FIRST .. P_GEDAPOOL.A_COLLATERAL.LAST LOOP
        IF P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLLAT.ACTION = 'CLOSE' THEN
          P_GEDCOLLAT.COLLATERAL         := TY_COLLAT_MASTER(NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL
                                                             
                                                             );
          P_GEDCOLLAT.COLL_COVENANT      := TY_COLL_COVENANTS();
          P_GEDCOLLAT.COLL_INSURANCE     := TY_COLL_INSURANCES();
          P_GEDCOLLAT.COLL_CONT_CONTRIB  := TY_COLLAT_CONT_CONTRIBS();
          P_GEDCOLLAT.COLL_SHARING       := TY_SHARING_DETAILSS();
          P_GEDCOLLAT.COLL_UDE_VALUESS   := TY_COLLAT_UDE_VALUESS();
          P_GEDCOLLAT.COLL_EXT_SYS_RESTS := TY_COLLAT_EXT_SYS_RESTS();
          P_GEDCOLLAT.COLL_HAIRCUTS      := TY_COLL_HAIRCUTS();
        
          P_GEDCOLLAT.COLLATERAL.LIAB_NO                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.LIABILITY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_CODE        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCODE;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_DESCRIPTION := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALDESCRIPTION;
          P_GEDCOLLAT.COLLATERAL.CATEGORY_NAME          := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCATEGORY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_CURRENCY    := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALCURRENCY;
          P_GEDCOLLAT.COLLATERAL.COLLATERAL_VALUE       := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.COLLATERALVALUE;
          P_GEDCOLLAT.COLLATERAL.HAIRCUT                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.HAIRCUT;
          P_GEDCOLLAT.COLLATERAL.START_DATE             := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.START_DATE;
          P_GEDCOLLAT.COLLATERAL.CHARGE_TYPE            := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.CHARGE_TYPE;
          P_GEDCOLLAT.COLLATERAL.REVAL_COLLAT           := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.REVAL_COLLAT;
          P_GEDCOLLAT.COLLATERAL.SECURED                := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                           .A_COLLAT.SECURED;
        
          P_GEDCOLLAT.COLLATERAL.LIAB_BRANCH        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.LIAB_BRANCH;
          P_GEDCOLLAT.COLLATERAL.SHARING_REQ        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.SHARING_REQ;
          P_GEDCOLLAT.COLLATERAL.AUTO_POOL_CREATE   := 'N';
          P_GEDCOLLAT.COLLATERAL.BRANCH_CODE        := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.BRANCH_CODE;
          P_GEDCOLLAT.COLLATERAL.AVAILABLE          := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.AVAILABLE;
          P_GEDCOLLAT.COLLATERAL.MORTGAGE_INITIATED := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.MORTGAGE_INITIATED;
          P_GEDCOLLAT.COLLATERAL.INTEREST_RATE      := P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                       .A_COLLAT.INTEREST_RATE;
          DBG('collateral contribution type ');
          IF P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB.COUNT > 0 THEN
            P_GEDCOLLAT.COLL_CONT_CONTRIB.EXTEND;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1) := TY_COLLAT_CONT_CONTRIB(NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL
                                                                       
                                                                      ,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL,
                                                                       NULL
                                                                       
                                                                       );
          
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_REF_NO := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                .CONTRACT_REF_NO;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_CONTRIBUTION := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                      .CONTRACT_CONTRIBUTION;
            P_GEDCOLLAT.COLL_CONT_CONTRIB(1).CONTRACT_BRANCH := P_GEDAPOOL.A_COLLATERAL(APOOLCNT).A_COLL_CONT_CONTRIB(1)
                                                                .CONTRACT_BRANCH;
            DBG('p_gedcollat.coll_cont_contrib(1).CONTRACT_REF_NO' || P_GEDCOLLAT.COLL_CONT_CONTRIB(1)
                .CONTRACT_REF_NO);
          ELSE
            DBG(' p_Gedapool.a_collateral(apoolcnt).a_coll_cont_contrib.delete');
          
          END IF;
          DBG('CALL FOR COLLATERAL CREATION NEW');
          IF NOT
              ELPKS_COLLATERAL_SERVICE.FN_COLLATERAL_PROCESS('FLEXCUBE',
                                                             P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                             .A_COLLAT.ACTION,
                                                             P_GEDAPOOL.A_COLLATERAL(APOOLCNT)
                                                             .A_COLLAT.ACTION,
                                                             L_MULTITRIP_ID,
                                                             P_GEDCOLLAT,
                                                             'N',
                                                             L_STATUS,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAM) THEN
            DBG('failed in fn_collateral_process');
            PR_LOG_ERROR('', 'FLEXCUBE', P_ERR_CODE, 'p_Err_Param');
            RETURN FALSE;
          ELSE
            DBG('SUCCESS FROM fn_collateral_process');
          END IF;
        END IF;
      END LOOP;
    END IF;
  
    GLOBAL.PR_INIT(GLOBAL.CURRENT_BRANCH, L_USER_ID);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_autopooltype_convert with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR('', 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_AUTOCREATE_COLL_POOL;

  FUNCTION FN_AUTHORIZE_CUSTACC(P_FUNCTION_ID IN VARCHAR2,
                                P_REC_CUSTACC IN OUT STTMS_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_IGNORE           VARCHAR2(10);
    R_COUNT            NUMBER;
    L_AC_CLASS_TYPE    STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    ALERT_RETURN       VARCHAR2(11);
    L_DATE_TIME        DATE;
    V_COUNT1           NUMBER;
    MAX_SL_NO          NUMBER(10);
    V_INTERPAY         STTMS_ACCOUNT_CLASS.INTERPAY%TYPE;
    V_COUNT2           NUMBER;
    V_COUNT3           NUMBER;
    L_AUTH_FLG         VARCHAR2(1);
    L_KEY_ID           VARCHAR2(200);
    L_CUST_AC_NO       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRANCH_CODE      STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_MOD_NO           NUMBER;
    L_CCY              STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_RDFLAG           STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_CHECKER_ID       STTMS_CUST_ACCOUNT.CHECKER_ID%TYPE;
    L_CHECKER_DT_STAMP STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP%TYPE;
    L_AUTH_STAT        STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_CUSTOMER_NAME1   STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_LANGUAGE         STTMS_CUSTOMER.LANGUAGE%TYPE;
    L_COUNTRY          STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNT            NUMBER := 0;
    L_DATE_STAMP       STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                              'DD-MON-YYYY') ||
                                                                     TO_CHAR(FN_SYSDATE,
                                                                              'HH24:MI:SS')),
                                                                     'DD-MON-YYYY HH24:MI:SS');
    L_TD_AMOUNT        NUMBER;
    L_TD_OFFSET_ACC    VARCHAR(20);
    L_OFFSET_BRN       VARCHAR2(3);
    L_PAYIN_OPTION     CHAR;
    L_MESSAGE          ERTB_MSGS.MESSAGE%TYPE;
    L_POOL_CNT         NUMBER;
  
    L_CUM_FLAG  BOOLEAN := FALSE;
    L_AMT       NUMBER(22, 3);
    L_ERR_PARAM ERTBS_MSGS.MESSAGE%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    --sampath starts
    L_TD_UPFRONT_BOOK_FLAG CHAR(1) := 'N';
    --sampath ends
  
  BEGIN
    DBG('Inside fn_authorize_custacc with acc no: ' ||
        P_REC_CUSTACC.CUST_AC_NO);
    L_AUTH_FLG    := P_REC_CUSTACC.ONCE_AUTH;
    L_CUST_AC_NO  := P_REC_CUSTACC.CUST_AC_NO;
    L_BRANCH_CODE := P_REC_CUSTACC.BRANCH_CODE;
    L_MOD_NO      := P_REC_CUSTACC.MOD_NO;
    L_CCY         := P_REC_CUSTACC.CCY;
    DBG('Brn: ' || L_BRANCH_CODE || ' Acc :' || L_CUST_AC_NO || ' Ccy: ' ||
        L_CCY);
  
    DBG('Updating cust account table');
    UPDATE STTMS_CUST_ACCOUNT
       SET AUTH_STAT        = 'A',
           ONCE_AUTH        = 'Y',
           CHECKER_ID       = NVL(GWPKS_UTIL.G_CHECKERID, GLOBAL.USER_ID),
           CHECKER_DT_STAMP = L_DATE_STAMP
     WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
       AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE;
  
    L_CUM_FLAG := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_FLAG(P_REC_CUSTACC.BRANCH_CODE,
                                                         P_REC_CUSTACC.CUST_AC_NO);
    IF L_CUM_FLAG THEN
      L_AMT := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(P_REC_CUSTACC, 'Y');
      DBG('l_amt is --> ' || L_AMT);
    END IF;
  
    DBG('Calling cepkss.Fn_Post_Update_account for AUTH');
    IF NOT CEPKSS.FN_POST_UPDATE_ACCOUNT(P_REC_CUSTACC.CUST_AC_NO,
                                         P_REC_CUSTACC.BRANCH_CODE,
                                         'AUTH',
                                         L_ERR_CODE) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
      RETURN FALSE;
    END IF;
    P_REC_CUSTACC.ONCE_AUTH := 'Y';
    DBG('Beginning TD Booking');
    SAVEPOINT TD_BOOK;
    BEGIN
      SELECT AC_CLASS_TYPE, RD_FLAG
        INTO P_REC_CUSTACC.ACCOUNT_TYPE, L_RDFLAG
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = NVL(P_REC_CUSTACC.ACCOUNT_CLASS, '~~~')
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('It is in when others-assiging N to rdflag and proceeding');
        L_RDFLAG := 'N';
    END;
    DBG('Acc Type: ' || P_REC_CUSTACC.ACCOUNT_TYPE);
    DBG('l_auth_flg: ' || L_AUTH_FLG);
    DBG('l_rdflag: ' || L_RDFLAG);
    IF P_REC_CUSTACC.ACCOUNT_TYPE = 'Y' AND L_AUTH_FLG = 'N' AND
       NVL(L_RDFLAG, 'N') = 'N' THEN
      DBG('before call to fn td book inside if cond');
      BEGIN
        SELECT TD_AMOUNT, TD_OFFSET_ACC, OFFSET_BRN, PAYIN_OPTION
          INTO L_TD_AMOUNT, L_TD_OFFSET_ACC, L_OFFSET_BRN, L_PAYIN_OPTION
          FROM ICTM_TD_DETAILS
         WHERE BRN = P_REC_CUSTACC.BRANCH_CODE
           AND ACC = P_REC_CUSTACC.CUST_AC_NO
           AND CCY = P_REC_CUSTACC.CCY;
        DBG('l_td_amount =>' || L_TD_AMOUNT);
        DBG('l_td_offset_acc =>' || L_TD_OFFSET_ACC);
        DBG('l_offset_brn =>' || L_OFFSET_BRN);
        DBG('l_payin_option =>' || L_PAYIN_OPTION);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed:SELECT td_amount,' || SQLERRM);
      END;
      DBG('Calling icpkss_bod.fn_td_book');
    
      --sampath starts
    
      L_TD_UPFRONT_BOOK_FLAG := 'Y';
      G_TD_UPFRONT_BOOK_FLAG := L_TD_UPFRONT_BOOK_FLAG;
    
      --sampath ends
    
      IF NOT ICPKSS_BOD.FN_TD_BOOK(L_CUST_AC_NO,
                                   L_BRANCH_CODE,
                                   L_CCY,
                                   L_ERR_CODE,
                                   L_ERR_PARAM) THEN
        DBG('bomb in fn td book  with:' || L_ERR_CODE || '~' ||
            L_ERR_PARAM);
        IF L_ERR_CODE IS NULL THEN
          L_ERR_CODE := 'ST-CUS99';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS99', '');
          RETURN FALSE;
        ELSE
        
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        
          RETURN FALSE;
        END IF;
        DBG('Error in book td');
        ROLLBACK TO TD_BOOK;
        DBG('Rooled back to td_book');
        DBG('Deleting: Calling stpks_maint_bakup.fn_complete_del_acc');
        IF NOT STPKS_MAINT_BAKUP.FN_COMPLETE_DEL_ACC(L_BRANCH_CODE,
                                                     L_CUST_AC_NO) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FNR12', '');
        END IF;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_Auth_Flg') := L_AUTH_FLG;
        IF NOT
            STPKSS_STDCUSAC_UTILS_CLUSTER.FN_AUTHORIZE_CUSTACC(P_FUNCTION_ID,
                                                               P_REC_CUSTACC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
          DBG('error in  Stpkss_Stdcusac_Utils_Custom.Fn_Authorize_Custacc-');
          RETURN FALSE;
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_Auth_Flg') THEN
          L_AUTH_FLG := L_TB_CLUSTER_DATA('l_Auth_Flg');
        END IF;
      
      END IF;
    
    END IF;
  
    DBG('l_err_code: ' || L_ERR_CODE);
  
    DBG('Auth stat: ' || P_REC_CUSTACC.AUTH_STAT);
    IF P_REC_CUSTACC.AUTH_STAT = 'A' THEN
      SELECT COUNT(*)
        INTO R_COUNT
        FROM SVTMS_ACC_SIG_MASTER
       WHERE BRANCH = P_REC_CUSTACC.BRANCH_CODE
         AND ACC_NO = P_REC_CUSTACC.CUST_AC_NO;
      IF (R_COUNT > 0) THEN
        DBG('Starting Replicating signatures');
        BEGIN
          SVPKSS.PR_REPLICATE_ACC_SIG(P_REC_CUSTACC.BRANCH_CODE,
                                      P_REC_CUSTACC.CUST_AC_NO);
          DBG('Signatures Successfully Replicated !!!');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Signatures Not Successfully Replicated ???');
            DBG('Now Fire a job to Replicate');
            SVPKSS.PR_FIRE_JOB('svpkss.pr_replicate_acc_sig(' || '''' ||
                               P_REC_CUSTACC.BRANCH_CODE || '''' || ',' || '''' ||
                               P_REC_CUSTACC.CUST_AC_NO || '''' ||
                               ',job);');
        END;
      END IF;
    END IF;
  
    DBG('p_Rec_Custacc.Record_Stat' || P_REC_CUSTACC.RECORD_STAT);
    DBG('p_Rec_Custacc.Auth_Stat' || P_REC_CUSTACC.AUTH_STAT);
    DBG('p_Rec_Custacc.Acc_Stmt_Type1' || P_REC_CUSTACC.AC_STMT_TYPE);
    DBG('p_Rec_Custacc.Acc_Stmt_Type2' || P_REC_CUSTACC.ACC_STMT_TYPE2);
    DBG('p_Rec_Custacc.Acc_Stmt_Type3' || P_REC_CUSTACC.ACC_STMT_TYPE3);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('P_REC_CUSTACC.AUTH_STAT') := P_REC_CUSTACC.AUTH_STAT;
      IF NOT
          STPKSS_STDCUSAC_UTILS_CLUSTER.FN_AUTHORIZE_CUSTACC(P_FUNCTION_ID,
                                                             P_REC_CUSTACC,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DBG('error in  Stpkss_Stdcusac_Utils_Custom.Fn_Authorize_Custacc-');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF P_REC_CUSTACC.RECORD_STAT = 'C' THEN
        IF P_REC_CUSTACC.AC_STMT_TYPE <> 'N' THEN
          IF NOT ACPKS_STMT.FN_HANDOFF_AN_ACST(P_REC_CUSTACC.PREVIOUS_STATEMENT_DATE,
                                               GLOBAL.APPLICATION_DATE,
                                               P_REC_CUSTACC.CUST_AC_NO,
                                               P_REC_CUSTACC.BRANCH_CODE,
                                               P_REC_CUSTACC.CCY) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS20', '');
            RETURN FALSE;
          END IF;
        END IF;
      
        IF P_REC_CUSTACC.ACC_STMT_TYPE2 <> 'N' THEN
          IF NOT ACPKS_STMT.FN_HANDOFF_AN_ACST(P_REC_CUSTACC.PREVIOUS_STATEMENT_DATE2,
                                               GLOBAL.APPLICATION_DATE,
                                               P_REC_CUSTACC.CUST_AC_NO,
                                               P_REC_CUSTACC.BRANCH_CODE,
                                               P_REC_CUSTACC.CCY) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS20', '');
            RETURN FALSE;
          END IF;
        END IF;
        IF P_REC_CUSTACC.ACC_STMT_TYPE3 <> 'N' THEN
          IF NOT ACPKS_STMT.FN_HANDOFF_AN_ACST(P_REC_CUSTACC.PREVIOUS_STATEMENT_DATE3,
                                               GLOBAL.APPLICATION_DATE,
                                               P_REC_CUSTACC.CUST_AC_NO,
                                               P_REC_CUSTACC.BRANCH_CODE,
                                               P_REC_CUSTACC.CCY) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS20', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    IF P_REC_CUSTACC.ACCOUNT_TYPE <> 'Y' THEN
      DBG('p_Rec_Custacc.Auto_Create_Pool --->' ||
          P_REC_CUSTACC.AUTO_CREATE_POOL);
      IF NOT FN_COLLATERAL_POOL_LINKAGES(P_FUNCTION_ID,
                                         L_AUTH_FLG,
                                         P_REC_CUSTACC) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS120', '');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('fn_authorize_custacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_authorize_custacc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_AUTHORIZE_CUSTACC;

  FUNCTION FN_CUSTACC_ENTRIES(P_FUNCTION_ID  IN VARCHAR2,
                              P_WRK_STDCUSAC IN OUT STTMS_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM          VARCHAR2(100);
    L_SERIAL_NO          VARCHAR2(15);
    L_TXN_REF_NO         VARCHAR2(16);
    L_TXN_CODE           VARCHAR2(16);
    L_ACC_HAND           ACPKSS.TBL_ACHOFF;
    C_ACC_HAND           ACPKSS.TBL_ACHOFF;
    L_NETTING_INDICATOR  CSTMS_EVENT_ACCT_ENTRY_CLASS.NETTING_INDICATOR%TYPE := 'n';
    L_EVENT_CLASS_CODE   STTMS_ACCOUNT_CLASS.TURNOVER_EVENT_CLASS_CODE%TYPE;
    L_TURNOVER_RTOH_CODE STTMS_ACCOUNT_CLASS.TURNOVER_RTOH_CODE%TYPE;
  
    L_COUNT          NUMBER := 0;
    TDLCY_AMOUNT     NUMBER;
    TDFCY_AMOUNT     NUMBER;
    TDLCY_AMOUNT_AMT NUMBER;
    TD_XRATE         ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_ACC_CCY        STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_RES_CCY        GLTMS_GLMASTER.RES_CCY%TYPE;
    L_BRANCH_LCY     STTMS_BRANCH.BRANCH_LCY%TYPE;
    L_FLAG           NUMBER := 0;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('pay in option-->' || P_WRK_STDCUSAC.INF_ACC_OPENING_AMT);
    IF P_WRK_STDCUSAC.INF_ACC_OPENING_AMT > 0 THEN
      BEGIN
        SELECT TURNOVER_EVENT_CLASS_CODE
          INTO L_EVENT_CLASS_CODE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS = P_WRK_STDCUSAC.ACCOUNT_CLASS;
        DBG('L_EVENT_CLASS_CODE-->' || L_EVENT_CLASS_CODE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in no data for event class');
          L_EVENT_CLASS_CODE := '';
      END;
      BEGIN
        SELECT TURNOVER_RTOH_CODE
          INTO L_TURNOVER_RTOH_CODE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS = P_WRK_STDCUSAC.ACCOUNT_CLASS;
        DBG('L_TURNOVER_RTOH_CODE-->' || L_TURNOVER_RTOH_CODE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in no data for eventL_TURNOVER_RTOH_CODE');
          L_TURNOVER_RTOH_CODE := '';
      END;
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM CSTM_EVENT_CLASS
         WHERE CLASS_CODE = L_EVENT_CLASS_CODE
           AND EVENT_CODE = 'INIT';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('in others of event class' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('INSIDE fn_validate_lov_EventClass_code lcount AFTER-->' ||
          L_COUNT);
    
      IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_WRK_STDCUSAC.BRANCH_CODE,
                                         'ZXRD',
                                         GLOBAL.APPLICATION_DATE,
                                         L_SERIAL_NO,
                                         L_TXN_REF_NO,
                                         L_ERR_CODE) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
        DBG('bomb in fn_get_process_refno in reference number-:' ||
            L_ERR_CODE || '~' || L_ERR_PARAM);
        RETURN FALSE;
      END IF;
      DBG('l_serial_no-->' || L_SERIAL_NO);
      DBG('l_txn_ref_no-->' || L_TXN_REF_NO);
      IF P_WRK_STDCUSAC.INF_PAY_IN_OPTION = 'A' THEN
        BEGIN
          SELECT CCY
            INTO L_ACC_CCY
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_WRK_STDCUSAC.INF_OFFSET_ACCOUNT
             AND BRANCH_CODE = P_WRK_STDCUSAC.INF_OFFSET_BRANCH;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('in no data for L_ACC_CCY' || SQLERRM);
            L_ACC_CCY := '';
            RETURN FALSE;
        END;
      ELSE
        L_ACC_CCY := P_WRK_STDCUSAC.CCY;
      END IF;
      BEGIN
        SELECT ACCOUNT_OPENING_CHARGES
          INTO L_ACCOUNT_OPENING_CHARGES
          FROM STTMS_ACCLS_CCY_BALANCES
         WHERE ACCOUNT_CLASS = P_WRK_STDCUSAC.ACCOUNT_CLASS
           AND CCY_CODE = P_WRK_STDCUSAC.CCY;
        DBG('L_EVENT_CLASS_CODE-->' || L_ACCOUNT_OPENING_CHARGES);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in no data for event class');
          L_ACCOUNT_OPENING_CHARGES := '';
      END;
      DBG('ACC OPEN DATE--> ' || TO_DATE(P_WRK_STDCUSAC.AC_OPEN_DATE));
      BEGIN
        SELECT BRANCH_LCY
          INTO L_BRANCH_LCY
          FROM STTM_BRANCH
         WHERE BRANCH_CODE = P_WRK_STDCUSAC.INF_OFFSET_BRANCH;
        DBG('L_BRANCH_LCY-->' || L_BRANCH_LCY);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in no data for event class');
          L_BRANCH_LCY := '';
      END;
    
      DBG('GLOBAL.LCY-->' || GLOBAL.LCY);
      DBG('maker id is -->' || P_WRK_STDCUSAC.MAKER_ID);
    
      BEGIN
        C_ACC_HAND(1).TRN_REF_NO := L_TXN_REF_NO;
        C_ACC_HAND(1).EVENT_SR_NO := 1;
        C_ACC_HAND(1).EVENT := 'INIT';
        C_ACC_HAND(1).DRCR_IND := 'D';
        C_ACC_HAND(1).TXN_INIT_DATE := TO_DATE(GLOBAL.APPLICATION_DATE);
        C_ACC_HAND(1).TRN_DT := TO_DATE(GLOBAL.APPLICATION_DATE);
        C_ACC_HAND(1).VALUE_DT := TO_DATE(P_WRK_STDCUSAC.AC_OPEN_DATE);
      
        C_ACC_HAND(1).USER_ID := NVL(P_WRK_STDCUSAC.MAKER_ID,
                                     GLOBAL.USER_ID);
      
        C_ACC_HAND(1).MODULE := 'DE';
        L_ACC_HAND(1).TRN_REF_NO := L_TXN_REF_NO;
        L_ACC_HAND(1).EVENT_SR_NO := 1;
        L_ACC_HAND(1).EVENT := 'INIT';
        L_ACC_HAND(1).AC_CCY := P_WRK_STDCUSAC.CCY;
        L_ACC_HAND(1).DRCR_IND := 'C';
        L_ACC_HAND(1).TXN_INIT_DATE := TO_DATE(GLOBAL.APPLICATION_DATE);
        L_ACC_HAND(1).TRN_DT := TO_DATE(GLOBAL.APPLICATION_DATE);
        L_ACC_HAND(1).VALUE_DT := TO_DATE(P_WRK_STDCUSAC.AC_OPEN_DATE);
      
        L_ACC_HAND(1).USER_ID := NVL(P_WRK_STDCUSAC.MAKER_ID,
                                     GLOBAL.USER_ID);
      
        L_ACC_HAND(1).MODULE := 'DE';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('in others of period-->' || SQLERRM);
      END;
      IF P_WRK_STDCUSAC.INF_ACC_OPENING_AMT IS NOT NULL THEN
        DBG('p_wrk_stdcusac.ACCOUNT_CLASS-->' ||
            P_WRK_STDCUSAC.ACCOUNT_CLASS);
      
        IF L_EVENT_CLASS_CODE IS NULL THEN
          DBG('Event class code is null.');
          L_ERR_CODE  := 'ST-ACST08';
          L_ERR_PARAM := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        END IF;
      
        IF L_EVENT_CLASS_CODE IS NOT NULL THEN
          IF L_COUNT <> 0 THEN
          
            BEGIN
              L_ACC_HAND(1).AC_BRANCH := P_WRK_STDCUSAC.BRANCH_CODE;
              L_ACC_HAND(1).AC_NO := P_WRK_STDCUSAC.CUST_AC_NO;
              BEGIN
                SELECT NETTING_INDICATOR, TRANSACTION_CODE
                  INTO L_NETTING_INDICATOR, L_TXN_CODE
                  FROM CSTM_EVENT_ACCT_ENTRY_CLASS
                 WHERE CLASS_CODE = L_EVENT_CLASS_CODE
                   AND MODULE = 'DE'
                   AND ACCOUNT_ROLE_CODE = 'OFS_ACC_USER'
                   AND AMT_TAG = 'TXN_AMT'
                   AND DR_CR_INDICATOR = 'C';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('in no data for event class ACCOUNTING ENTRIES');
                
                  L_ERR_CODE  := 'AC-DEF09';
                  L_ERR_PARAM := L_EVENT_CLASS_CODE || '~' || 'DE' || '~' ||
                                 'OFS_ACC_USER' || '~' || 'TXN_AMT' || '~' || 'C';
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               L_ERR_PARAM);
                  RETURN FALSE;
                
              END;
              DBG('l_txn_code here for TXN-AMT tag is-->' || L_TXN_CODE);
              DBG('L_NETTING_INDICATOR-->' || L_NETTING_INDICATOR);
            
              IF L_TXN_CODE IS NULL THEN
                DBG('Transaction code is null');
                L_ERR_CODE  := 'AC-DEF07';
                L_ERR_PARAM := L_EVENT_CLASS_CODE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              L_ACC_HAND(1).TRN_CODE := L_TXN_CODE;
              L_ACC_HAND(1).AMOUNT_TAG := 'TXN_AMT';
              IF P_WRK_STDCUSAC.INF_WAIVE_ACC_OPEN_CHARGE = 'Y' THEN
                L_ACC_HAND(1).LCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT;
              ELSE
                IF L_NETTING_INDICATOR = 'Y' THEN
                  IF L_ACCOUNT_OPENING_CHARGES IS NOT NULL THEN
                    L_ACC_HAND(1).LCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT -
                                                L_ACCOUNT_OPENING_CHARGES;
                    L_FLAG := 1;
                  
                  ELSE
                    L_ACC_HAND(1).LCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT;
                    L_FLAG := 1;
                  
                  END IF;
                ELSE
                  L_ACC_HAND(1).LCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT;
                END IF;
              END IF;
              BEGIN
                DBG('p_wrk_stdcusac.CCY-->' || P_WRK_STDCUSAC.CCY);
                TDLCY_AMOUNT := '';
                TD_XRATE     := '';
                TDFCY_AMOUNT := '';
                IF P_WRK_STDCUSAC.CCY <> GLOBAL.LCY THEN
                
                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.BRANCH_CODE,
                                                     P_WRK_STDCUSAC.CCY,
                                                     GLOBAL.LCY,
                                                     L_ACC_HAND(1).LCY_AMOUNT,
                                                     'Y',
                                                     TDLCY_AMOUNT,
                                                     TD_XRATE,
                                                     L_ERR_CODE) THEN
                    ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                    DBG('Error code :' || L_ERR_CODE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 L_ERR_CODE,
                                 L_ERR_PARAM);
                    RETURN FALSE;
                  END IF;
                  TDFCY_AMOUNT     := L_ACC_HAND(1).LCY_AMOUNT;
                  TDLCY_AMOUNT_AMT := TDLCY_AMOUNT;
                ELSE
                  TDLCY_AMOUNT     := L_ACC_HAND(1).LCY_AMOUNT;
                  TDLCY_AMOUNT_AMT := L_ACC_HAND(1).LCY_AMOUNT;
                  TD_XRATE         := NULL;
                  TDFCY_AMOUNT     := NULL;
                END IF;
                IF L_FLAG = 1 THEN
                  TD_XRATE := '';
                
                  TDLCY_AMOUNT_AMT := '';
                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.BRANCH_CODE,
                                                     P_WRK_STDCUSAC.CCY,
                                                     GLOBAL.LCY,
                                                     P_WRK_STDCUSAC.INF_ACC_OPENING_AMT,
                                                     'Y',
                                                     TDLCY_AMOUNT_AMT,
                                                     TD_XRATE,
                                                     L_ERR_CODE) THEN
                    ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                    DBG('Error code :' || L_ERR_CODE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 L_ERR_CODE,
                                 L_ERR_PARAM);
                    RETURN FALSE;
                  END IF;
                END IF;
                DBG('tdlcy_amount-->' || TDLCY_AMOUNT);
                DBG('td_xrate-->' || TD_XRATE);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('IN NO DATA OF OFFSET CURRENCY');
                  RETURN FALSE;
              END;
              L_ACC_HAND(1).NETTING_IND := L_NETTING_INDICATOR;
              L_ACC_HAND(1).FINANCIAL_CYCLE := NULL;
              L_ACC_HAND(1).PERIOD_CODE := NULL;
              L_ACC_HAND(1).LCY_AMOUNT := TDLCY_AMOUNT;
              L_ACC_HAND(1).FCY_AMOUNT := TDFCY_AMOUNT;
              L_ACC_HAND(1).EXCH_RATE := TD_XRATE;
              IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                         1,
                                         TO_DATE(GLOBAL.APPLICATION_DATE),
                                         L_ACC_HAND,
                                         'B',
                                         'N',
                                         'N',
                                         GLOBAL.USER_ID,
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
                DBG('bomb in fn_get_process_refno in achandoff SECOND TIME -:' ||
                    L_ERR_CODE || '~' || L_ERR_PARAM);
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('IN OTHERS OF ACCOUNTING ENTRIES-->' || SQLERRM);
                RETURN FALSE;
            END;
          
            IF P_WRK_STDCUSAC.INF_PAY_IN_OPTION = 'A' THEN
              BEGIN
                IF L_BRANCH_LCY <> GLOBAL.LCY THEN
                
                  BEGIN
                    TDLCY_AMOUNT := '';
                    TD_XRATE     := '';
                    TDFCY_AMOUNT := '';
                    DBG('here inside 2nd conversion');
                    IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.BRANCH_CODE,
                                                       GLOBAL.LCY,
                                                       L_BRANCH_LCY,
                                                       TDLCY_AMOUNT_AMT,
                                                       'Y',
                                                       TDLCY_AMOUNT,
                                                       TD_XRATE,
                                                       L_ERR_CODE) THEN
                      ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                      DBG('Error code :' || L_ERR_CODE);
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   'FLEXCUBE',
                                   L_ERR_CODE,
                                   L_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                    TDFCY_AMOUNT     := TDLCY_AMOUNT_AMT;
                    TDLCY_AMOUNT_AMT := TDLCY_AMOUNT;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('in others of icpkss-->' || SQLERRM);
                      RETURN FALSE;
                  END;
                ELSE
                  TDFCY_AMOUNT := NULL;
                  TD_XRATE     := NULL;
                END IF;
                DBG('L_ACC_CCY-->' || L_ACC_CCY);
                IF L_BRANCH_LCY <> L_ACC_CCY THEN
                
                  BEGIN
                    TDLCY_AMOUNT := TDLCY_AMOUNT_AMT;
                    TD_XRATE     := '';
                    TDFCY_AMOUNT := '';
                    DBG('here inside 2nd conversion');
                    IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.INF_OFFSET_BRANCH,
                                                       L_BRANCH_LCY,
                                                       L_ACC_CCY,
                                                       TDLCY_AMOUNT,
                                                       'Y',
                                                       TDFCY_AMOUNT,
                                                       TD_XRATE,
                                                       L_ERR_CODE) THEN
                      ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                      DBG('Error code :' || L_ERR_CODE);
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   'FLEXCUBE',
                                   L_ERR_CODE,
                                   L_ERR_PARAM);
                      RETURN FALSE;
                    END IF;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('in others of icpkss-->' || SQLERRM);
                      RETURN FALSE;
                  END;
                END IF;
                DBG('tdlcy_amount-->' || TDLCY_AMOUNT);
                DBG('td_xrate-->' || TD_XRATE);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('IN NO DATA OF OFFSET CURRENCY');
                  RETURN FALSE;
              END;
            
            ELSIF P_WRK_STDCUSAC.INF_PAY_IN_OPTION = 'G' THEN
              IF P_WRK_STDCUSAC.CCY <> GLOBAL.LCY THEN
                TDLCY_AMOUNT := TDLCY_AMOUNT_AMT;
                TDFCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT;
              ELSE
                TDLCY_AMOUNT := P_WRK_STDCUSAC.INF_ACC_OPENING_AMT;
                TDFCY_AMOUNT := NULL;
                TD_XRATE     := NULL;
              END IF;
            
            END IF;
            BEGIN
              C_ACC_HAND(1).AC_BRANCH := P_WRK_STDCUSAC.INF_OFFSET_BRANCH;
              C_ACC_HAND(1).AC_NO := P_WRK_STDCUSAC.INF_OFFSET_ACCOUNT;
              C_ACC_HAND(1).AC_CCY := L_ACC_CCY;
              BEGIN
                SELECT NETTING_INDICATOR, TRANSACTION_CODE
                  INTO L_NETTING_INDICATOR, L_TXN_CODE
                  FROM CSTM_EVENT_ACCT_ENTRY_CLASS
                 WHERE CLASS_CODE = L_EVENT_CLASS_CODE
                   AND MODULE = 'DE'
                   AND ACCOUNT_ROLE_CODE = 'OFS_ACC'
                   AND AMT_TAG = 'TXN_AMT'
                   AND DR_CR_INDICATOR = 'D';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('in no data for event class ACCOUNTING ENTRIES');
                
                  L_ERR_CODE  := 'AC-DEF09';
                  L_ERR_PARAM := L_EVENT_CLASS_CODE || '~' || 'DE' || '~' ||
                                 'OFS_ACC' || '~' || 'TXN_AMT' || '~' || 'D';
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               L_ERR_PARAM);
                  RETURN FALSE;
                
              END;
              DBG('l_txn_code 2 here for TXN-AMT tag is-->' || L_TXN_CODE);
            
              IF L_TXN_CODE IS NULL THEN
                DBG('Transaction code is null');
                L_ERR_CODE  := 'AC-DEF07';
                L_ERR_PARAM := L_EVENT_CLASS_CODE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              DBG('L_NETTING_INDICATOR-->' || L_NETTING_INDICATOR);
              C_ACC_HAND(1).TRN_CODE := L_TXN_CODE;
              C_ACC_HAND(1).AMOUNT_TAG := 'TXN_AMT';
              C_ACC_HAND(1).LCY_AMOUNT := TDLCY_AMOUNT;
              C_ACC_HAND(1).NETTING_IND := L_NETTING_INDICATOR;
              C_ACC_HAND(1).FINANCIAL_CYCLE := NULL;
              C_ACC_HAND(1).PERIOD_CODE := NULL;
              C_ACC_HAND(1).FCY_AMOUNT := TDFCY_AMOUNT;
              C_ACC_HAND(1).EXCH_RATE := TD_XRATE;
              IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                         1,
                                         TO_DATE(GLOBAL.APPLICATION_DATE),
                                         C_ACC_HAND,
                                         'B',
                                         'N',
                                         'N',
                                         GLOBAL.USER_ID,
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
                DBG('bomb in fn_get_process_refno in achandoff FIRST TIME -:' ||
                    L_ERR_CODE || '~' || L_ERR_PARAM);
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('IN OTHERS OF ACCOUNTING ENTRIES-->' || SQLERRM);
                RETURN FALSE;
            END;
          END IF;
        END IF;
      END IF;
    
      IF L_EVENT_CLASS_CODE IS NULL AND
         P_WRK_STDCUSAC.INF_ACC_OPENING_AMT IS NOT NULL THEN
        DBG('Event class code is null.');
        L_ERR_CODE  := 'ST-ACST08';
        L_ERR_PARAM := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    
      IF P_WRK_STDCUSAC.INF_WAIVE_ACC_OPEN_CHARGE = 'N' THEN
        IF L_NETTING_INDICATOR <> 'Y' THEN
          IF L_ACCOUNT_OPENING_CHARGES IS NOT NULL THEN
            BEGIN
              C_ACC_HAND(1).AC_CCY := P_WRK_STDCUSAC.CCY;
              C_ACC_HAND(1).AC_BRANCH := P_WRK_STDCUSAC.BRANCH_CODE;
              C_ACC_HAND(1).AC_NO := P_WRK_STDCUSAC.CUST_AC_NO;
            
              IF L_EVENT_CLASS_CODE IS NULL THEN
                DBG('Event class code is null.');
                L_ERR_CODE  := 'ST-ACST08';
                L_ERR_PARAM := NULL;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              BEGIN
                SELECT NETTING_INDICATOR, TRANSACTION_CODE
                  INTO L_NETTING_INDICATOR, L_TXN_CODE
                  FROM CSTM_EVENT_ACCT_ENTRY_CLASS
                 WHERE CLASS_CODE = L_EVENT_CLASS_CODE
                   AND MODULE = 'DE'
                   AND ACCOUNT_ROLE_CODE = 'OFS_ACC_USER'
                   AND AMT_TAG = 'CHG-AMT'
                   AND DR_CR_INDICATOR = 'D';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('in no data for event class ACCOUNTING ENTRIES');
                
                  L_ERR_CODE  := 'AC-DEF09';
                  L_ERR_PARAM := L_EVENT_CLASS_CODE || '~' || 'DE' || '~' ||
                                 'OFS_ACC_USER' || '~' || 'CHG-AMT' || '~' || 'D';
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               L_ERR_PARAM);
                  RETURN FALSE;
                
              END;
              DBG('l_txn_code for CHG-AMT tag is-->' || L_TXN_CODE);
              DBG('L_NETTING_INDICATOR-->' || L_NETTING_INDICATOR);
            
              IF L_TXN_CODE IS NULL THEN
                DBG('Transaction code is null');
                L_ERR_CODE  := 'AC-DEF07';
                L_ERR_PARAM := L_EVENT_CLASS_CODE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              BEGIN
                DBG('p_wrk_stdcusac.CCY-->' || P_WRK_STDCUSAC.CCY);
                TDLCY_AMOUNT := '';
                TD_XRATE     := '';
                TDFCY_AMOUNT := '';
                IF P_WRK_STDCUSAC.CCY <> GLOBAL.LCY THEN
                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.BRANCH_CODE,
                                                     P_WRK_STDCUSAC.CCY,
                                                     GLOBAL.LCY,
                                                     L_ACCOUNT_OPENING_CHARGES,
                                                     'Y',
                                                     TDLCY_AMOUNT,
                                                     TD_XRATE,
                                                     L_ERR_CODE) THEN
                    ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                    DBG('Error code :' || L_ERR_CODE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 L_ERR_CODE,
                                 L_ERR_PARAM);
                    RETURN FALSE;
                  END IF;
                  TDFCY_AMOUNT := L_ACCOUNT_OPENING_CHARGES;
                ELSE
                  TDLCY_AMOUNT := L_ACCOUNT_OPENING_CHARGES;
                  TD_XRATE     := NULL;
                  TDFCY_AMOUNT := NULL;
                END IF;
                DBG('tdlcy_amount-->' || TDLCY_AMOUNT);
                DBG('td_xrate-->' || TD_XRATE);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('IN NO DATA OF OFFSET CURRENCY');
                  RETURN FALSE;
              END;
            
              C_ACC_HAND(1).TRN_CODE := L_TXN_CODE;
              C_ACC_HAND(1).AMOUNT_TAG := 'CHG-AMT';
              C_ACC_HAND(1).LCY_AMOUNT := TDLCY_AMOUNT;
              C_ACC_HAND(1).NETTING_IND := L_NETTING_INDICATOR;
              C_ACC_HAND(1).FINANCIAL_CYCLE := NULL;
              C_ACC_HAND(1).PERIOD_CODE := NULL;
              C_ACC_HAND(1).FCY_AMOUNT := TDFCY_AMOUNT;
              C_ACC_HAND(1).EXCH_RATE := TD_XRATE;
              IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                         1,
                                         TO_DATE(GLOBAL.APPLICATION_DATE),
                                         C_ACC_HAND,
                                         'B',
                                         'N',
                                         'N',
                                         GLOBAL.USER_ID,
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
                DBG('bomb in fn_get_process_refno in achandoff THIORD TIME -:' ||
                    L_ERR_CODE || '~' || L_ERR_PARAM);
              
                IF L_ERR_CODE IS NULL THEN
                  L_ERR_CODE := 'ST-ACSTC15';
                END IF;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
              
                RETURN FALSE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('IN OTHERS OF ACCOUNTING ENTRIES-->' || SQLERRM);
                RETURN FALSE;
            END;
          END IF;
        END IF;
      
        IF L_ACCOUNT_OPENING_CHARGES IS NOT NULL THEN
          BEGIN
            L_NETTING_INDICATOR := '';
            TDLCY_AMOUNT        := '';
            TD_XRATE            := '';
            TDFCY_AMOUNT        := '';
            BEGIN
              SELECT ACCOUNT_HEAD
                INTO L_ACC_HAND(1).AC_NO
                FROM CSTMS_ROLE_TO_HEAD_CLASS
               WHERE CLASS_CODE = L_TURNOVER_RTOH_CODE
                 AND ACCOUNTING_ROLE = 'CHARGEINC';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('in no data for event class ACCOUNT_HEAD');
                L_ACC_HAND(1).AC_NO := '';
            END;
            DBG('l_acc_hand(1).ac_no---->' || L_ACC_HAND(1).AC_NO);
            IF L_ACC_HAND(1).AC_NO IS NOT NULL THEN
              L_ACC_HAND(1).AC_BRANCH := P_WRK_STDCUSAC.BRANCH_CODE;
            
              IF L_EVENT_CLASS_CODE IS NULL THEN
                DBG('Event class code is null.');
                L_ERR_CODE  := 'ST-ACST08';
                L_ERR_PARAM := NULL;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              BEGIN
                SELECT NETTING_INDICATOR, TRANSACTION_CODE
                  INTO L_NETTING_INDICATOR, L_TXN_CODE
                  FROM CSTM_EVENT_ACCT_ENTRY_CLASS
                 WHERE CLASS_CODE = L_EVENT_CLASS_CODE
                   AND MODULE = 'DE'
                   AND ACCOUNT_ROLE_CODE = 'CHARGEINC'
                   AND AMT_TAG = 'CHG-AMT'
                   AND DR_CR_INDICATOR = 'C';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('in no data for event class ACCOUNTING ENTRIES');
                
                  L_ERR_CODE  := 'AC-DEF09';
                  L_ERR_PARAM := L_EVENT_CLASS_CODE || '~' || 'DE' || '~' ||
                                 'CHARGEINC' || '~' || 'CHG-AMT' || '~' || 'c';
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               L_ERR_PARAM);
                  RETURN FALSE;
                
              END;
              BEGIN
                SELECT RES_CCY
                  INTO L_RES_CCY
                  FROM GLTMS_GLMASTER
                 WHERE GL_CODE = L_ACC_HAND(1).AC_NO;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('in no data for event class ACCOUNTING ENTRIES');
              END;
              DBG('in no data for event class ACCOUNTING ENTRIES--->' ||
                  L_RES_CCY);
              IF P_WRK_STDCUSAC.CCY <> NVL(L_RES_CCY, GLOBAL.LCY) THEN
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_WRK_STDCUSAC.BRANCH_CODE,
                                                   P_WRK_STDCUSAC.CCY,
                                                   NVL(L_RES_CCY, GLOBAL.LCY),
                                                   
                                                   L_ACCOUNT_OPENING_CHARGES,
                                                   'Y',
                                                   TDLCY_AMOUNT,
                                                   TD_XRATE,
                                                   L_ERR_CODE) THEN
                  ICPKSS_UTIL.DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                  DBG('Error code :' || L_ERR_CODE);
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               L_ERR_PARAM);
                  RETURN FALSE;
                END IF;
                TDFCY_AMOUNT := L_ACCOUNT_OPENING_CHARGES;
              ELSE
                TDLCY_AMOUNT := L_ACCOUNT_OPENING_CHARGES;
                TD_XRATE     := NULL;
                TDFCY_AMOUNT := NULL;
              END IF;
              DBG('l_txn_code 2 for CHG-AMT tag is-->' || L_TXN_CODE);
            
              IF L_TXN_CODE IS NULL THEN
                DBG('Transaction code is null');
                L_ERR_CODE  := 'AC-DEF07';
                L_ERR_PARAM := L_EVENT_CLASS_CODE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            
              DBG('L_NETTING_INDICATOR-->' || L_NETTING_INDICATOR);
              L_ACC_HAND(1).AC_CCY := NVL(L_RES_CCY, GLOBAL.LCY);
              L_ACC_HAND(1).TRN_CODE := L_TXN_CODE;
              L_ACC_HAND(1).AMOUNT_TAG := 'CHG-AMT';
              L_ACC_HAND(1).LCY_AMOUNT := TDLCY_AMOUNT;
              L_ACC_HAND(1).NETTING_IND := L_NETTING_INDICATOR;
              L_ACC_HAND(1).FINANCIAL_CYCLE := NULL;
              L_ACC_HAND(1).PERIOD_CODE := NULL;
              L_ACC_HAND(1).FCY_AMOUNT := TDFCY_AMOUNT;
              L_ACC_HAND(1).EXCH_RATE := TD_XRATE;
              IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                         1,
                                         TO_DATE(GLOBAL.APPLICATION_DATE),
                                         L_ACC_HAND,
                                         'B',
                                         'N',
                                         'N',
                                         GLOBAL.USER_ID,
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN
                DBG('bomb in fn_get_process_refno in achandoff FOURTH TIME -:' ||
                    L_ERR_CODE || '~' || L_ERR_PARAM);
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             L_ERR_CODE,
                             L_ERR_PARAM);
                RETURN FALSE;
              END IF;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('IN OTHERS OF ACCOUNTING ENTRIES-->' || SQLERRM);
              RETURN FALSE;
          END;
        END IF;
      ELSE
        L_ACCOUNT_OPENING_CHARGES := 0;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('TRN_REF_NO') := L_TXN_REF_NO;
        IF NOT
            STPKS_STDCUSAC_UTILS_CLUSTER.FN_CUSTACC_ENTIRES(P_FUNCTION_ID,
                                                            P_WRK_STDCUSAC,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA) THEN
          DBG('Failed in stpks_stdcusac_utils_cluster.Fn_Custacc_Entries');
          RETURN FALSE;
        END IF;
      END IF;
    
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_preupld_calls with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_CUSTACC_ENTRIES;

  FUNCTION FN_CUSTADVICE_ENTIRES(P_FUNCTION_ID  IN VARCHAR2,
                                 P_WRK_STDCUSAC IN OUT STTMS_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
    L_RECEIVER           STTBS_ACCOUNT.CUST_NO%TYPE;
    L_PRODUCT_MSG        MSTMS_MSG_FORMAT.PRODUCT%TYPE;
    L_RET_DCN            MSTBS_DLY_MSG_OUT.DCN%TYPE;
    L_CUST_NO_ADV        STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CCY_ADV            STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_AC_NO_ADV          STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_OPENING_AMT_ADV    STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT%TYPE;
    L_PAY_OPTION_ADV     VARCHAR2(50);
    L_ACCOUNT_TYPE_ADV   STTMS_CUST_ACCOUNT.ACCOUNT_TYPE%TYPE;
    L_CUSTOMER_NAME_ADV  STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_ADDRESS_LINE1_ADV  STTMS_CUSTOMER.ADDRESS_LINE1%TYPE;
    L_ADDRESS_LINE2_ADV  STTMS_CUSTOMER.ADDRESS_LINE2%TYPE;
    L_ADDRESS_LINE3_ADV  STTMS_CUSTOMER.ADDRESS_LINE3%TYPE;
    L_ADDRESS_LINE4_ADV  STTMS_CUSTOMER.ADDRESS_LINE4%TYPE;
    L_BANK_NAME_ADV      STTMS_BANK.BANK_NAME%TYPE;
    L_OFFSET_BRANCH_ADV  STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH%TYPE;
    L_OFFSET_ACCOUNT_ADV STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT%TYPE;
    L_PAY_ACC_ADV        VARCHAR2(50);
    L_PAY_GL_ADV         VARCHAR2(50);
    P_MSG_HANDOFF        MSTBS_MSG_HANDOFF%ROWTYPE;
    PM_BAD_DCNS          VARCHAR2(200);
    L_COUNT              NUMBER := 0;
    L_MEDIA              MSTM_MSG_ACC_ADDRESS.MEDIA%TYPE;
    L_LOCATION           MSTM_MSG_ACC_ADDRESS.LOCATION%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_CUSTADVICE_ENTIRES(P_FUNCTION_ID,
                                                             P_WRK_STDCUSAC,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_cluster.Fn_Custadvice_Entires');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      BEGIN
        SELECT CUST_NO
          INTO L_RECEIVER
          FROM STTBS_ACCOUNT
         WHERE NVL(BRANCH_CODE, P_WRK_STDCUSAC.BRANCH_CODE) =
               P_WRK_STDCUSAC.BRANCH_CODE
           AND AC_GL_NO = P_WRK_STDCUSAC.CUST_AC_NO
           AND AC_OR_GL = 'A';
        DBG('HERE INSIDE');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('inside no data of cust');
          SELECT WALKIN_CUSTOMER
            INTO L_RECEIVER
            FROM STTMS_BRANCH
           WHERE BRANCH_CODE = P_WRK_STDCUSAC.BRANCH_CODE;
      END;
      BEGIN
        L_MEDIA    := NVL(FN_PICKUP_MEDIA(P_WRK_STDCUSAC.CUST_AC_NO,
                                          P_WRK_STDCUSAC.BRANCH_CODE,
                                          P_WRK_STDCUSAC.CUST_NO,
                                          'ACC_OPADV',
                                          'DE'),
                          'MAIL');
        L_LOCATION := NVL(FN_PICKUP_LOCATION(P_WRK_STDCUSAC.CUST_AC_NO,
                                             P_WRK_STDCUSAC.BRANCH_CODE,
                                             P_WRK_STDCUSAC.CUST_NO,
                                             'ACC_OPADV',
                                             'DE'),
                          'CIF');
      
        SELECT MSG.PRODUCT
          INTO L_PRODUCT_MSG
          FROM MSTMS_MSG_FORMAT MSG, MSTM_ADV_FORMAT ADV
         WHERE MSG.MSG_TYPE = 'ACC_OPADV'
           AND MSG.FORMAT = ADV.FORMAT
           AND MSG.MODULE = 'DE'
           AND MSG.MEDIA = L_MEDIA
           AND MSG.BRANCH IN (P_WRK_STDCUSAC.BRANCH_CODE, 'ALL')
           AND MSG.CCY IN (P_WRK_STDCUSAC.CCY, 'ALL')
           AND ADV.RECORD_STAT = 'O'
           AND ADV.ONCE_AUTH = 'Y'
           AND ADV.LANGUAGE = GLOBAL.LANG;
      
        DBG('l_product_msg-->' || L_PRODUCT_MSG);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('HERE inside no data--' || SQLERRM);
        WHEN OTHERS THEN
          DBG('HERE inside others-->' || SQLERRM);
          RETURN FALSE;
      END;
      BEGIN
        DELETE FROM MSTBS_MSG_HANDOFF
         WHERE MSG_TYPE = 'ACC_OPADV'
           AND REFERENCE_NO = P_WRK_STDCUSAC.CUST_AC_NO;
        DBG('DELETE from mstbs_msg_handoff-->' || SQL%ROWCOUNT);
        DELETE FROM MSTBS_DLY_MSG_OUT
         WHERE MSG_TYPE = 'ACC_OPADV'
           AND REFERENCE_NO = P_WRK_STDCUSAC.CUST_AC_NO;
        DBG('DELETE from mstbs_dly_msg_out-->' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of DELETE: ' || SQLERRM);
      END;
      INSERT INTO MSTBS_MSG_HANDOFF
        (BRANCH,
         REFERENCE_NO,
         ESN,
         MSG_TYPE,
         RECEIVER,
         SERIAL_NO,
         CCY,
         PRIORITY,
         DIRECTIVE_STATUS,
         PROCESSED_FLAG,
         SUPPRESS_FLAG,
         HOLD_STATUS,
         MSG_STATUS,
         PRODUCT,
         MODULE,
         MEDIA,
         GENERATE_STATUS,
         MAKER_ID,
         MAKER_DT_STAMP,
         CHECKER_ID,
         CHECKER_DT_STAMP,
         ONCE_AUTH,
         AUTH_STAT,
         LOCATION,
         CUST_AC_NO)
      VALUES
        (P_WRK_STDCUSAC.BRANCH_CODE,
         P_WRK_STDCUSAC.CUST_AC_NO,
         1,
         'ACC_OPADV',
         L_RECEIVER,
         1,
         P_WRK_STDCUSAC.CCY,
         1,
         'I',
         'Y',
         'N',
         'N',
         'G',
         L_PRODUCT_MSG,
         'DE',
         L_MEDIA,
         'G',
         GLOBAL.USER_ID,
         GLOBAL.APPLICATION_DATE,
         GLOBAL.USER_ID,
         GLOBAL.APPLICATION_DATE,
         'Y',
         'A'
         
        ,
         L_LOCATION,
         P_WRK_STDCUSAC.CUST_AC_NO)
      RETURNING DCN INTO L_RET_DCN;
      DBG('INSERT into mstbs_msg_handoff-->' || SQL%ROWCOUNT);
      DBG('l_ret_dcn-->' || L_RET_DCN);
      BEGIN
        SELECT *
          INTO P_MSG_HANDOFF
          FROM MSTBS_MSG_HANDOFF
         WHERE DCN = L_RET_DCN;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('in others of p_msg_handoff -->' || SQLERRM);
      END;
      BEGIN
        SELECT CUST_NO,
               CCY,
               CUST_AC_NO,
               INF_ACC_OPENING_AMT,
               INF_PAY_IN_OPTION,
               ACCOUNT_TYPE,
               INF_OFFSET_BRANCH,
               INF_OFFSET_ACCOUNT
          INTO L_CUST_NO_ADV,
               L_CCY_ADV,
               L_AC_NO_ADV,
               L_OPENING_AMT_ADV,
               L_PAY_OPTION_ADV,
               L_ACCOUNT_TYPE_ADV,
               L_OFFSET_BRANCH_ADV,
               L_OFFSET_ACCOUNT_ADV
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.CUST_AC_NO
              
           AND BRANCH_CODE = P_WRK_STDCUSAC.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('HERE I AM IN NODATA');
      END;
      IF L_PAY_OPTION_ADV = 'A' THEN
        L_PAY_OPTION_ADV := 'By Account';
        L_PAY_ACC_ADV    := 'Yes';
        L_PAY_GL_ADV     := 'No';
      ELSE
        L_PAY_OPTION_ADV := 'By GL';
        L_PAY_ACC_ADV    := 'No';
        L_PAY_GL_ADV     := 'Yes';
      END IF;
      BEGIN
        SELECT CUSTOMER_NAME1,
               ADDRESS_LINE1,
               ADDRESS_LINE2,
               ADDRESS_LINE3,
               ADDRESS_LINE4
          INTO L_CUSTOMER_NAME_ADV,
               L_ADDRESS_LINE1_ADV,
               L_ADDRESS_LINE2_ADV,
               L_ADDRESS_LINE3_ADV,
               L_ADDRESS_LINE4_ADV
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO = L_CUST_NO_ADV;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('HERE I AM IN NODATA FOR CUST INFO');
      END;
      BEGIN
        SELECT BANK_NAME INTO L_BANK_NAME_ADV FROM STTMS_BANK;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('HERE I AM IN NODATA FOR CUST sttm_bank');
      END;
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_TDATE_', 1, GLOBAL.APPLICATION_DATE);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_BANK-NAME_', 1, L_BANK_NAME_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_BRANCH-ADDR_', 1, '');
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUST-NAME1_', 1, L_CUSTOMER_NAME_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUSTOMER_', 1, L_CUST_NO_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUST-ADRESS1_', 1, L_ADDRESS_LINE1_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUST-ADRESS2_', 1, L_ADDRESS_LINE2_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUST-ADRESS3_', 1, L_ADDRESS_LINE3_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_CUST-ADRESS4_', 1, L_ADDRESS_LINE4_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_ACCOUNT-TYPE_', 1, L_ACCOUNT_TYPE_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_ACCOUNT-NO_', 1, L_AC_NO_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_ACCOUNT-CCY_', 1, L_CCY_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_INI-FUNDING-AMT_', 1, L_OPENING_AMT_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_PAYIN-MODE_', 1, L_PAY_OPTION_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_ACC-OPEN-CHG-AMT_', 1, L_ACCOUNT_OPENING_CHARGES);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_PAYIN-BY-ACC-YN_', 1, L_PAY_ACC_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_PAYIN-BY-GL-YN_', 1, L_PAY_GL_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_PAYIN-BY-ACCOUNT_', 1, L_OFFSET_ACCOUNT_ADV);
      INSERT INTO MSTBS_ADV_INPUT
        (DCN, FIELD_TAG, LOOP_NO, VALUE)
      VALUES
        (L_RET_DCN, '_PAYIN-BY-ACC-BRN_', 1, L_OFFSET_BRANCH_ADV);
      DBG('BEFORE CALLING MSPKS');
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM MSTMS_MSG_ADDRESS A
         WHERE A.MSG_TYPE IN ('ALL', 'ACC_OPADV')
           AND A.MODULE IN ('DE', 'AL')
           AND A.BRANCH IN (P_WRK_STDCUSAC.BRANCH_CODE, 'ALL')
              
           AND A.MEDIA LIKE NVL(L_MEDIA, '%')
           AND A.CUSTOMER_NO = L_CUST_NO_ADV
              
           AND A.CUST_AC_NO = P_WRK_STDCUSAC.CUST_AC_NO;
      
        DBG('l_count->' || L_COUNT);
        IF L_COUNT = 0 THEN
          INSERT INTO MSTMS_MSG_ADDRESS
            (MSG_TYPE,
             MODULE,
             BRANCH,
             LOCATION,
             MEDIA,
             CUSTOMER_NO,
             CUST_AC_NO)
          VALUES
            ('ACC_OPADV',
             'DE',
             P_WRK_STDCUSAC.BRANCH_CODE
             
            ,
             L_LOCATION,
             L_MEDIA,
             L_CUST_NO_ADV,
             P_WRK_STDCUSAC.CUST_AC_NO);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('IN others of mstms_msg_address--' || SQLERRM);
          RETURN FALSE;
      END;
      IF NOT MSPKS.FN_GENERATE_MSG_OUT(P_MSG_HANDOFF, 'N', PM_BAD_DCNS) THEN
        DBG('FALIED IN FNGENERATE MSG OUT' || SQLERRM);
      
      END IF;
    
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of insertion into mstbs_msg_handoff: ' || SQLERRM);
      DBG('In WOT of insertion into mstbs_msg_handoff: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END;

  FUNCTION FN_AUTH(P_FUNCTION_ID  IN VARCHAR2,
                   P_AC_NO        VARCHAR2,
                   P_BRANCH       VARCHAR2,
                   P_MOD_NO       IN STTMS_CUST_ACCOUNT.MOD_NO%TYPE,
                   P_IS_AUTO_AUTH CHAR) RETURN BOOLEAN IS
    L_POPULATE_CHANGES_LOG VARCHAR2(1);
    L_REC_CUSTACC          STTMS_CUST_ACCOUNT%ROWTYPE;
    L_COUNT                NUMBER;
    L_AUTH_COUNT           NUMBER;
    RECMOD                 NUMBER;
    L_CUST_NO              VARCHAR2(20);
    L_KEY_ID               STTBS_RECORD_LOG.KEY_ID%TYPE := '~STTM_CUST_ACCOUNT~' ||
                                                           P_BRANCH || '~' ||
                                                           P_AC_NO || '~';
    L_DATE_STAMP           STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                                  'DD-MON-YYYY') ||
                                                                         TO_CHAR(FN_SYSDATE,
                                                                                  'HH24:MI:SS')),
                                                                         'DD-MON-YYYY HH24:MI:SS');
    L_ONCE_AUTH            CHAR(1);
  
    L_ACC_GRANDFATHERED VARCHAR2(1);
    L_ACC_BENEFICIARY   STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_ALLOW_GF          VARCHAR2(1);
    L_REPORTABLE        VARCHAR2(1);
    L_OPERATION         VARCHAR2(1);
    L_FATCA_END_DATE    DATE;
    L_FATCA_BAL         NUMBER;
    L_US_INDICIA        STTMS_CUST_FATCA.US_INDICIA%TYPE;
    L_MATCH_CRITERIA    STTMS_CUST_FATCA_LOG.MATCH_CRITERIA%TYPE;
    L_INCLUDE_BAL       VARCHAR2(1);
    L_US_SOURCED        VARCHAR2(1);
    L_RECALCITRANT      VARCHAR2(1);
  
  BEGIN
    DBG('Inside fn_auth');
    BEGIN
      SELECT CUST_NO
        INTO L_CUST_NO
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRANCH;
      SELECT NVL(B.POPULATE_CHANGES_LOG, 'N')
        INTO L_POPULATE_CHANGES_LOG
        FROM STTMS_CUSTOMER A, STTMS_CUSTOMER_CAT B
       WHERE A.CUSTOMER_CATEGORY = B.CUST_CAT
         AND A.CUSTOMER_NO = L_CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed l_populate_changes_log fetching' || SQLERRM);
        L_POPULATE_CHANGES_LOG := 'N';
    END;
    DBG('l_populate_changes_log' || L_POPULATE_CHANGES_LOG);
    IF L_POPULATE_CHANGES_LOG = 'Y' THEN
      DBG('Calling fn_update_cust_change_log');
    
    END IF;
    DBG('Taking record from sttms_cust_account');
    SELECT *
      INTO L_REC_CUSTACC
      FROM STTMS_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_AC_NO
       AND BRANCH_CODE = P_BRANCH;
  
    BEGIN
      L_ONCE_AUTH := L_REC_CUSTACC.ONCE_AUTH;
      DBG('l_ONCE_AUTH -->' || L_ONCE_AUTH);
    
    EXCEPTION
    
      WHEN OTHERS THEN
        DBG('Failed in fetching the auth stat value' || SQLERRM);
    END;
  
    BEGIN
      DBG('going to call icpks_cache.fn_get_fatca_beneficiary');
      L_ACC_BENEFICIARY := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(P_BRANCH,
                                                                P_AC_NO);
      DBG('FATCA beneficiary received as : ' || L_ACC_BENEFICIARY);
      DBG('going to call stpks_FATCA_US_indicia.fn_chk_US_indica_at_custacc with country code as : ' ||
          L_REC_CUSTACC.COUNTRY_CODE);
      IF NOT
          STPKS_FATCA_US_INDICIA.FN_CHK_US_INDICA_AT_CUSTACC(L_ACC_BENEFICIARY,
                                                             P_BRANCH,
                                                             P_AC_NO,
                                                             P_FUNCTION_ID,
                                                             L_REC_CUSTACC.COUNTRY_CODE,
                                                             L_MATCH_CRITERIA,
                                                             L_US_INDICIA) THEN
        DBG('Failed while updating account level us indicia flag');
      END IF;
      IF NOT
          STPKS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_PROD_MAINT_SETUP('IC',
                                                                L_REC_CUSTACC.ACCOUNT_CLASS,
                                                                'A',
                                                                L_ALLOW_GF,
                                                                L_INCLUDE_BAL) THEN
        DBG('failed to fetch the allow grandfathering flag');
        L_ALLOW_GF := 'N';
      END IF;
      IF NOT
          STPKS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_CUSTOMER_PARAMS(L_ACC_BENEFICIARY,
                                                               L_US_INDICIA,
                                                               L_REPORTABLE,
                                                               L_RECALCITRANT,
                                                               L_US_SOURCED) THEN
      
        DBG('failed to fetch the reportable classification');
        L_REPORTABLE := 'N';
      END IF;
      DBG('going to call fn_get_grandfathered_status');
      IF NVL(L_ALLOW_GF, 'N') = 'Y' AND NVL(L_REPORTABLE, 'N') = 'Y' THEN
        IF STPKS_FATCA_GRANDFATHER_CHK.FN_GET_GRANDFATHER_CHK_CASA(P_BRANCH,
                                                                   P_AC_NO) THEN
          L_ACC_GRANDFATHERED := 'Y';
        ELSE
          L_ACC_GRANDFATHERED := 'N';
        END IF;
        DBG('The returned grandfathered status is : ' ||
            L_ACC_GRANDFATHERED);
      ELSE
        L_ACC_GRANDFATHERED := 'N';
      END IF;
      IF NVL(L_REPORTABLE, 'N') = 'Y' THEN
        DBG('mod no : ' || L_REC_CUSTACC.MOD_NO || ' ~ record stat : ' ||
            L_REC_CUSTACC.RECORD_STAT);
        IF L_REC_CUSTACC.MOD_NO > 1 AND L_REC_CUSTACC.RECORD_STAT <> 'C' THEN
          L_OPERATION := 'U';
        ELSIF L_REC_CUSTACC.RECORD_STAT = 'C' THEN
          L_OPERATION := 'D';
        ELSE
          L_OPERATION := 'I';
        END IF;
        DBG('oblig entry operation is : ' || L_OPERATION);
      
        IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_BRANCH,
                                                    P_AC_NO,
                                                    'Y',
                                                    G_BALREC) THEN
          DEBUG.PR_DEBUG('AC',
                         'Failed in Get_Sttm_Account_Balance .. : ' ||
                         SQLERRM);
        END IF;
      
        IF L_REC_CUSTACC.ACCOUNT_TYPE = 'Y' THEN
          SELECT DECODE(NVL(CLOSE_ON_MATURITY, 'N'),
                        'Y',
                        MATURITY_DATE,
                        NULL),
                 TD_AMOUNT
            INTO L_FATCA_END_DATE, L_FATCA_BAL
            FROM ICTMS_ACC A, ICTMS_TD_DETAILS B
           WHERE A.ACC = B.ACC
             AND A.BRN = B.BRN
             AND A.ACC = P_AC_NO
             AND A.BRN = P_BRANCH;
        ELSE
          DBG('this is a CASA account');
          L_FATCA_END_DATE := NULL;
          IF L_REC_CUSTACC.MOD_NO = 1 THEN
            L_FATCA_BAL := L_REC_CUSTACC.INF_ACC_OPENING_AMT;
          ELSE
          
            L_FATCA_BAL := G_BALREC.ACY_CURR_ACC_BAL;
          
          END IF;
        END IF;
        DBG('end date : ' || L_FATCA_END_DATE);
        DBG('balance : ' || L_FATCA_BAL);
        IF NOT
            STPKSS_FATCA_OBLIG_ENTRY.FN_POPULATE_OBLIG(P_BRANCH || P_AC_NO,
                                                       'A',
                                                       'FLEXCUBE',
                                                       'IC',
                                                       L_REC_CUSTACC.ACCOUNT_CLASS,
                                                       L_ACC_BENEFICIARY,
                                                       L_REC_CUSTACC.AC_OPEN_DATE,
                                                       L_FATCA_END_DATE,
                                                       L_REC_CUSTACC.CCY,
                                                       L_FATCA_BAL,
                                                       L_ACC_GRANDFATHERED,
                                                       L_OPERATION) THEN
          DBG('failed : ' || SQLERRM);
          RETURN FALSE;
        END IF;
      
      END IF;
      DBG('fatca is done');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('failed while processing for fatca, err is - ' || SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('Calling fn_authorize_custacc');
    IF NOT FN_AUTHORIZE_CUSTACC(P_FUNCTION_ID, L_REC_CUSTACC) THEN
      DBG('Failed in fn_authorize_custacc');
      RETURN FALSE;
    END IF;
  
    DBG('l_ONCE_AUTH second-->' || L_ONCE_AUTH);
  
    DBG('fn_auth returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_auth with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_AUTH;

  FUNCTION FN_CREATECLRING_CONTRACT(P_FUNCTION_ID IN VARCHAR2,
                                    P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                    P_BRN         IN STTM_BRANCH.BRANCH_CODE%TYPE,
                                    P_CCY         IN STTM_CUST_ACCOUNT.CCY%TYPE,
                                    P_TDPAYIN     IN ICTMS_TDPAYIN_DETAILS%ROWTYPE,
                                    P_ERR_CODE    IN OUT ERTBS_MSGS.ERR_CODE%TYPE)
    RETURN BOOLEAN IS
  
    L_SERIAL_NO     VARCHAR2(15);
    L_XREF          VARCHAR2(16);
    L_OVERRIDE_FLAG VARCHAR2(2);
  
    L_AUTH_STAT  VARCHAR2(1);
    L_ERR_TBL    OVPKS.TBL_ERROR;
    L_TY_CLG_REC CGPKSS_UPLOAD_CG_CREATE.TY_CLG_UPLD_REC;
    L_BRANCH_DET STTM_BRANCH%ROWTYPE;
    L_ROUTINGNO  VARCHAR2(27);
  
    L_REF_NO CSTB_CLEARING_MASTER.REFERENCE_NO%TYPE;
  
    L_USER        SMTBS_USER.USER_ID%TYPE;
    L_BRN         STTMS_BRANCH.BRANCH_CODE%TYPE;
    L_LOG_CHANGED BOOLEAN := FALSE;
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAMS VARCHAR2(1000);
  
    L_BANK_CODE   DETMS_CLG_BRN_CODE.BANK_CODE%TYPE;
    L_BRN_CODE    DETMS_CLG_BRN_CODE.BRANCH_CODE%TYPE;
    L_SECTOR_CODE DETMS_CLG_BRN_CODE.SECTOR_CODE%TYPE;
  
    L_AVL_DATE ACTB_FUNCOL.AVAILABLEDATE%TYPE;
  
  BEGIN
  
    DBG('inside function fn_createclring_contract');
  
    IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                       'OCLR',
                                       GLOBAL.APPLICATION_DATE,
                                       L_SERIAL_NO,
                                       L_XREF,
                                       P_ERR_CODE) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, '');
      DBG('bomb in fn_get_process_refno in reference number-:' ||
          P_ERR_CODE);
      RETURN FALSE;
    END IF;
    DBG('l_serial_no-->' || L_SERIAL_NO);
    DBG('l_txn_ref_no-->' || L_XREF);
  
    DBG('Ref no ' || L_XREF);
  
    BEGIN
      DBG('branch is -->' || P_BRN);
      SELECT *
        INTO L_BRANCH_DET
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('failed  in others of fn_createclring_contract' || SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('p_tdpayin.clg_bank_code-->' || P_TDPAYIN.CLG_BANK_CODE);
    DBG('p_tdpayin.clg_branch_code-->' || P_TDPAYIN.CLG_BRANCH_CODE);
  
    DBG('Product_code-->' || P_TDPAYIN.CLG_PRODUCT_CODE);
  
    L_TY_CLG_REC.TY_CLG_UPLD(1).XREF := L_XREF;
  
    L_TY_CLG_REC.TY_CLG_UPLD(1).PROD := P_TDPAYIN.CLG_PRODUCT_CODE;
  
    L_TY_CLG_REC.TY_CLG_UPLD(1).TXN_BRN := L_BRANCH_DET.BRANCH_CODE;
    L_TY_CLG_REC.TY_CLG_UPLD(1).REMACCOUNT := P_TDPAYIN.DRAWEE_AC_NO;
    L_TY_CLG_REC.TY_CLG_UPLD(1).REMBANK := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).REMBRANCH := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).BENACCOUNT := P_ACC_NO;
    L_TY_CLG_REC.TY_CLG_UPLD(1).BENBANK := L_BRANCH_DET.BANK_CODE;
    L_TY_CLG_REC.TY_CLG_UPLD(1).BENBRANCH := L_BRANCH_DET.BRANCH_CODE;
    L_TY_CLG_REC.TY_CLG_UPLD(1).INSTRNO := P_TDPAYIN.CHQ_INSTUMENTNO;
    L_TY_CLG_REC.TY_CLG_UPLD(1).INSTRCCY := P_CCY;
    L_TY_CLG_REC.TY_CLG_UPLD(1).INSTRAMT := P_TDPAYIN.MULTIMODE_TDAMOUNT;
    L_TY_CLG_REC.TY_CLG_UPLD(1).INSTRDATE := P_TDPAYIN.CHQ_INSTRUMENT_DATE;
    L_TY_CLG_REC.TY_CLG_UPLD(1).TXNDATE := GLOBAL.APPLICATION_DATE;
    L_TY_CLG_REC.TY_CLG_UPLD(1).VALDATEBNK := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).VALDATECUST := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).LATECLG := '';
  
    L_TY_CLG_REC.TY_CLG_UPLD(1).ROUTINGNO := P_TDPAYIN.ROUTING_NO;
  
    L_TY_CLG_REC.TY_CLG_UPLD(1).ENDPOINT := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).SERIALNO := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).FCCREF := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).ENTRY_NO := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).BENE_CCY := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).REMARKS := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).FORCE_POSTING := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).EXCH_RATE := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).CONSIDER_FOR_REG_CC := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).SPL_CHQ_FLG := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).CONSOLIDATED := '';
    L_TY_CLG_REC.TY_CLG_UPLD(1).INSTR_TYPE := 'CHQ';
    L_TY_CLG_REC.TY_CLG_UPLD(1).DIRECTION := 'O';
    L_TY_CLG_REC.TY_CLG_UPLD(1).MODULE_CODE := 'TD';
    L_TY_CLG_REC.TY_CLG_UPLD(1).CHEQUEISSUEDATE := L_TY_CLG_REC.TY_CLG_UPLD(1)
                                                   .INSTRDATE;
    DBG('going to call cgpks_upload_cg_create.fn_upload');
    DBG('ben acc-->' || P_ACC_NO);
  
    IF NOT CGPKS_UPLOAD_CG_CREATE.FN_UPLOAD(L_SOURCE,
                                            L_TY_CLG_REC,
                                            L_OVERRIDE_FLAG,
                                            L_AUTH_STAT,
                                            L_ERR_TBL) THEN
    
      DBG('failed in  cgpks_upload_cg_create.fn_upload');
      DBG('?error-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FMS-121', '');
      RETURN FALSE;
    
    ELSE
    
      DBG('successfully created cg contract');
      DBG('going to insert into TDCG_LINK_DETAILS');
      DBG('CUST_AC_NO-->' || P_ACC_NO);
      DBG('FCCREF-->' || L_TY_CLG_REC.TY_CLG_UPLD(1).FCCREF);
      L_REF_NO := L_TY_CLG_REC.TY_CLG_UPLD(1).FCCREF;
    
      BEGIN
        SELECT FCCREF
          INTO L_TY_CLG_REC.TY_CLG_UPLD(1).FCCREF
          FROM IFTB_CLEARING_UPLOAD
         WHERE XREF = L_TY_CLG_REC.TY_CLG_UPLD(1).XREF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN OTHERS' || SQLERRM);
      END;
    
      BEGIN
        SELECT AUTH_STAT
        
          INTO L_AUTH_STAT
        
          FROM CSTB_CLEARING_MASTER
         WHERE REFERENCE_NO = L_REF_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in checking the auth status of the contract...');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FMS-121', '');
          RETURN FALSE;
        
      END;
      L_USER := GLOBAL.USER_ID;
      L_BRN  := GLOBAL.CURRENT_BRANCH;
      IF NVL(L_AUTH_STAT, 'U') <> 'A' THEN
        DBG('Calling authorize for clearing transaction..');
        DBG('Shifting to log SYSTEM ');
        GLOBAL.PR_INIT(L_BRN, 'SYSTEM');
        L_LOG_CHANGED := TRUE;
      
        IF NOT CGPKSS_UPLOAD_CG_CREATE.FN_AUTHORIZE(L_REF_NO,
                                                    L_ERR_CODE,
                                                    L_ERR_PARAMS) THEN
          DBG('failed in  cgpks_upload_cg_create.fn_authorize');
          DBG('?error-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FMS-121', '');
          RETURN FALSE;
        
        ELSE
          DBG('Updating status to SUCS in iftbs_clearing_upload since cgpkss_upload_cg_create.fn_authorize is through');
        
          UPDATE IFTBS_CLEARING_UPLOAD
             SET STATUS = 'SUCS', ERROR_CODES = NULL, ERROR_PARAMS = NULL
           WHERE XREF = L_XREF
             AND SCODE = 'FCRH';
          DBG('Updated status to SUCS in iftbs_clearing_upload since cgpkss_upload_cg_create.fn_authorize is through');
        
        END IF;
      END IF;
    
      IF L_LOG_CHANGED THEN
        DBG('Shifting to log ' || L_USER);
        GLOBAL.PR_INIT(L_BRN, L_USER);
      END IF;
    
      INSERT INTO CGTB_TD_LINKAGES
        (TD_REF_NO, CLEARING_REF_NO, TD_BRANCH, TD_CCY)
      VALUES
        (P_ACC_NO, L_TY_CLG_REC.TY_CLG_UPLD(1).FCCREF, P_BRN, P_CCY);
    
      DBG('INSERTED');
    
      L_AVL_DATE := ICPKS_BOD.GET_CHQ_AVL_DATE(P_BRN,
                                               P_ACC_NO,
                                               L_TY_CLG_REC.TY_CLG_UPLD(1)
                                               .FCCREF);
      DBG('l_avl_date--->' || L_AVL_DATE);
      IF L_AVL_DATE IS NOT NULL THEN
        DBG('updating tanked status');
        BEGIN
          UPDATE STTM_CUST_ACCOUNT
             SET ACC_TANKED_STAT = 'Y'
           WHERE BRANCH_CODE = P_BRN
             AND CUST_AC_NO = P_ACC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('in exception');
            NULL;
        END;
      END IF;
    
    END IF;
  
    RETURN TRUE;
  END FN_CREATECLRING_CONTRACT;

  FUNCTION FN_AUTH_CUSTACC(P_FUNCTION_ID IN VARCHAR2,
                           P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_ACTION_CODE IN VARCHAR2,
                           P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS
    L_MOD_NO               STTMS_CUST_ACCOUNT.MOD_NO%TYPE;
    L_STATUS               VARCHAR2(1);
    L_ACCOUNT_UTILIZN_TYPE ELPKS.TY_ACCCOUNT_UTIL_MASTER;
    L_DATE                 DATE;
    L_PROD                 VARCHAR2(6);
    L_LIABLITY_NO          VARCHAR2(9);
    EVENT_CODE             CSTBS_CONTRACT.CURR_EVENT_CODE%TYPE;
    EVENT_SQ_NO            CSTBS_CONTRACT.LATEST_EVENT_SEQ_NO%TYPE;
    P_ERROR                ERTB_MSGS.ERR_CODE%TYPE;
    P_ERROR_PARAMS         ERTB_MSGS.MESSAGE%TYPE;
    ACTION_CODE            VARCHAR2(20) := 'MODIFY';
    L_COUNT                NUMBER;
  
    L_TDPAYINDETAILS ICTMS_TDPAYIN_DETAILS%ROWTYPE;
    L_SECTORCODE     DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT        DATE;
    L_DRVALDT        DATE;
    L_LATE_CLEARING  VARCHAR2(10);
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_RESULT               VARCHAR2(1000);
    L_TDPAYINDETAILS_COUNT NUMBER;
  
  BEGIN
    DBG('Inside fn_auth_custacc');
    DBG('Verifying account nos');
  
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
      RETURN FALSE;
    END IF;
    IF P_SOURCE NOT IN ('FLEXCUBE') THEN
    
      DBG('Source is not flexcube..so taking gthe mod_no to authorize from sttm_cust_account');
      SELECT MOD_NO
        INTO L_MOD_NO
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      IF L_MOD_NO IS NULL THEN
        DBG('Failed:Mod No  is NULL');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-MAN01',
                     'Modification Number~');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Modification Number to Authorize..' || L_MOD_NO);
    DBG('p_stdcusac.v_ictms_tdpayin_details.COUNT-->' ||
        P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
  
    DBG('getting details for cheque');
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN
      L_TDPAYINDETAILS_COUNT := 0;
      BEGIN
        SELECT *
          INTO L_TDPAYINDETAILS
          FROM ICTMS_TDPAYIN_DETAILS
         WHERE ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
           AND MULTIMODE_PAYOPT = 'Q';
      
        L_TDPAYINDETAILS_COUNT := 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('no data found');
          L_TDPAYINDETAILS_COUNT := 0;
        WHEN OTHERS THEN
          DBG('in others');
          L_TDPAYINDETAILS_COUNT := 0;
      END;
    
      DBG('l_tdpayindetails_count is ' || L_TDPAYINDETAILS_COUNT);
    
      IF (L_TDPAYINDETAILS_COUNT = 1) THEN
      
        DBG('payin option is cheque');
      
        DBG('get value date');
        DBG('bank code-->' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23);
        DBG('branch code -->' ||
            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25);
      
        DBG('l_tdpayindetails.clg_bank_code-->' ||
            L_TDPAYINDETAILS.CLG_BANK_CODE);
        DBG('l_tdpayindetails.clg_branch_code-->' ||
            L_TDPAYINDETAILS.CLG_BRANCH_CODE);
      
        CSPKSS_CLG_SERV.PR_BREAK_ROUTING_NO(NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD71,
                                                L_TDPAYINDETAILS.ROUTING_NO),
                                            L_SECTORCODE,
                                            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23,
                                            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25);
        DBG('l_sectorcode-->' || L_SECTORCODE);
        DBG('Product Code' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD48);
        DBG('l_tdpayindetails.clg_product_code-->' ||
            L_TDPAYINDETAILS.CLG_PRODUCT_CODE);
      
        IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23,
                                                          L_TDPAYINDETAILS.CLG_BANK_CODE),
                                                      NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25,
                                                          L_TDPAYINDETAILS.CLG_BRANCH_CODE),
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD48,
                                                          L_TDPAYINDETAILS.CLG_PRODUCT_CODE),
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      NULL,
                                                      L_SECTORCODE,
                                                      L_CRVALDT,
                                                      L_DRVALDT,
                                                      L_LATE_CLEARING,
                                                      L_ERR_CODE,
                                                      GLOBAL.APPLICATION_DATE,
                                                      'N',
                                                      'N') THEN
        
          DBG('failed to get the Value date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
          RETURN FALSE;
        ELSE
        
          DBG('value date -->' || L_CRVALDT);
          DBG('account open date-->' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
        
          IF CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                      L_CRVALDT,
                                      L_RESULT) = TRUE THEN
            DBG('Cheque clearing date is holiday ' || L_RESULT);
            IF NVL(L_RESULT, '*') = 'H' THEN
              L_CRVALDT := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        L_CRVALDT,
                                                        'N');
              DBG('Working date --> ' || L_CRVALDT);
            END IF;
          END IF;
        
          IF L_CRVALDT <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
            DBG('acount open date is different from the value date of t he product');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-242',
                         L_CRVALDT);
            RETURN FALSE;
          END IF;
        END IF;
      
      END IF;
    END IF;
  
    L_SOURCE := P_SOURCE;
  
    IF P_SOURCE <> 'FLEXBRANCH' THEN
      DBG('Calling fn_auth');
      IF NOT FN_AUTH(P_FUNCTION_ID,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                     L_MOD_NO,
                     'N') THEN
        DBG('fn_auth has returned false');
        RETURN FALSE;
      END IF;
    ELSIF GWPKS_UTIL.PKG_ACTTYPE = 'SAVEAUTOAUTH' THEN
      DBG('Calling fn_auth for flexbranch action :: ' ||
          GWPKS_UTIL.PKG_ACTTYPE);
    
      DBG('GWPKS_UTIL.pkg_func is ' || GWPKS_UTIL.PKG_FUNC ||
          ' and p_Function_Id is ' || P_FUNCTION_ID);
      IF NVL(NVL(GWPKS_UTIL.PKG_FUNC, P_FUNCTION_ID), '****') = '1317' THEN
      
        ICPKS_BOD.G_CHILDTD := TRUE;
      END IF;
      IF NOT FN_AUTH(P_FUNCTION_ID,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                     L_MOD_NO,
                     'N') THEN
        DBG('fn_auth has returned false');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROJECT_ACCOUNT, 'N') = 'N' THEN
    
      DBG('Chaecking Status from sttb_acc_limits_reinit');
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTB_ACC_LIMITS_REINIT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND STATUS IN ('U', 'E');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed while getting the status' || SQLERRM);
          L_STATUS := '';
      END;
      IF L_COUNT > 0 THEN
        DBG('Reinitiating the account process');
      
        BEGIN
          SELECT REINIT_DATE
            INTO L_DATE
            FROM STTB_ACC_LIMITS_REINIT
           WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found for the account: ' || SQLERRM);
          WHEN OTHERS THEN
            DBG('In WOT of caching with: ' || SQLERRM);
        END;
      
        BEGIN
          SELECT LIABILITY_NO
            INTO L_LIABLITY_NO
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Failed while getting the Liability No for customer' ||
                SQLERRM);
        END;
        DBG('populating the l_Account_Utilizn_Type types');
        L_ACCOUNT_UTILIZN_TYPE.REF_NO       := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        L_ACCOUNT_UTILIZN_TYPE.CUSTOMER_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        L_ACCOUNT_UTILIZN_TYPE.LIABILITY_NO := L_LIABLITY_NO;
        L_ACCOUNT_UTILIZN_TYPE.TRANS_BRN    := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        L_ACCOUNT_UTILIZN_TYPE.TRANS_CCY    := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        L_ACCOUNT_UTILIZN_TYPE.TRANS_PRD    := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        L_ACCOUNT_UTILIZN_TYPE.MODULE       := 'ST';
        L_ACCOUNT_UTILIZN_TYPE.IS_ACCOUNT   := 'Y';
        L_ACCOUNT_UTILIZN_TYPE.TRANS_DATE   := L_DATE;
        L_ACCOUNT_UTILIZN_TYPE.AMT_TAG      := 'BALANCE';
        DBG('going to call Fn_Od_Account_Process fot reinititation');
      
        IF NOT FN_OD_ACCOUNT_PROCESS(L_ACCOUNT_UTILIZN_TYPE,
                                     ACTION_CODE,
                                     EVENT_CODE,
                                     EVENT_SQ_NO,
                                     P_ERROR,
                                     P_ERROR_PARAMS) THEN
        
          DBG('Fn_Od_Account_Process for reinitiation returning false');
        
          DBG('Updating the sttb_acc_limits_reinit');
          DBG('Cust ac no' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
          DBG('branch code' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
          IF NOT FN_SET_REINIT_ACC(P_FUNCTION_ID,
                                   'E',
                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                   P_ERROR,
                                   P_ERROR_PARAMS) THEN
            DBG('Failed while updating sttb_acc_limits_reinit for status ');
            RETURN FALSE;
          END IF;
        
          RETURN FALSE;
        ELSE
          DBG('Updating the status for Success');
        
          UPDATE STTB_ACC_LIMITS_REINIT
             SET STATUS = 'P'
           WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        
        END IF;
      END IF;
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      DBG('Calling the custom function Stpks_Stdcusac_Utils_2_custom.Fn_Auth_Custacc');
      IF NOT STPKS_STDCUSAC_UTILS_CLUSTER.FN_AUTH_CUSTACC(P_FUNCTION_ID,
                                                          P_STDCUSAC,
                                                          P_ACTION_CODE,
                                                          P_SOURCE) THEN
        DBG('Failed in Stpks_Stdcusac_Utils_cluster.Fn_Auth_Custacc');
        RETURN FALSE;
      END IF;
      DBG('After  function Stpks_Stdcusac_Utils_cluster.Fn_Auth_Custacc');
    
    END IF;
  
    DBG('fn_auth_custacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_auth_custacc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_AUTH_CUSTACC;

  FUNCTION FN_COPY_INIT(P_FUNCTION_ID IN VARCHAR2,
                        P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_AUTO_GEN_FLAG CHAR;
    L_CUST_ACC_MASK VARCHAR2(20);
    L_AC_MASK_BRN   VARCHAR2(3);
    L_ACNO_LEN      NUMBER;
    L_BANK_CODE     PCTMS_BANK_PARAM.BANK_CODE%TYPE;
    L_PREV_AC_NO    STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_AC_NO         STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside fn_copy_init');
    DBG('Building the initial subsysstat');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_BUILD_INITSTAT(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('stpks_stdcusac_utils_0.fn_build_initstat has returned false');
      RETURN FALSE;
    END IF;
    DBG('Account number generation');
    L_PREV_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    BEGIN
      SELECT NVL(AC_AUTOGEN_FLAG, 'N'), CUSTOMER_ACC_MASK
        INTO L_AUTO_GEN_FLAG, L_CUST_ACC_MASK
        FROM STTMS_ACC_PARAM
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT NVL(AC_AUTOGEN_FLAG, 'N'), CUSTOMER_ACC_MASK
          INTO L_AUTO_GEN_FLAG, L_CUST_ACC_MASK
          FROM STTMS_ACC_PARAM
         WHERE BRANCH_CODE = '***';
      WHEN OTHERS THEN
        DBG('Failed while fetching mask details ' || SQLERRM);
        RETURN FALSE;
    END;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD6    := L_AUTO_GEN_FLAG;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD3    := L_CUST_ACC_MASK;
    L_ACNO_LEN                                   := LENGTH(L_CUST_ACC_MASK);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
  
    DBG('RETRO_12_3_25821251: p_Stdcusac.v_Sttms_Cust_Account.ACCOUNT_DERIVED_STATUS ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_DERIVED_STATUS);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_DERIVED_STATUS IS NOT NULL THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_DERIVED_STATUS := 'NORM';
    END IF;
  
    IF NVL(L_AUTO_GEN_FLAG, 'N') = 'Y' AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPL_AC_GEN, 'N') = 'N' THEN
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            STPKS_STDCUSAC_UTILS_CLUSTER.FN_COPY_INIT(P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('Failed in stpks_stdcusac_utils_cluster.Fn_Copy_Init...');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF NOT STPKS_STDCUSAC_UTILS_0.FN_ACC_AUTOGEN(P_FUNCTION_ID,
                                                     L_ACNO_LEN,
                                                     P_STDCUSAC) THEN
          DBG('Unable to generate account');
          RETURN FALSE;
        END IF;
      
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      DBG('Assigning the value of calc_acc,book_acc and charge book acc as cust ac no while copy');
      P_STDCUSAC.V_ICTMS_ACC.CALC_ACC        := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC        := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    
      DBG('p_Stdcusac.v_Sttms_Cust_Account.Cust_Ac_No :: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    
      DBG('charge_book_acc--->' || P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC);
      DBG('calc_acc---->' || P_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
      DBG('book_acc--->' || P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
    
    ELSE
    
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC := 'DUMMY';
      P_STDCUSAC.V_ICTMS_ACC.CALC_ACC        := 'DUMMY';
      P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC        := 'DUMMY';
      DBG('charge_book_acc--->' || P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC);
      DBG('calc_acc---->' || P_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
      DBG('book_acc--->' || P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
    
    END IF;
  
    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := NULL;
    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE  := NULL;
    P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE := NULL;
  
    DBG('fn_copy_init returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_copy_init with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_COPY_INIT;

  FUNCTION FN_COPY_ACC(P_FUNCTION_ID IN VARCHAR2,
                       P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CAT_TYPE              VARCHAR2(1) := NULL;
    L_CNT                   NUMBER := 0;
    L_EMPTY_LINKED_ENTITIES STPKSS_ACCOUNT_UPLOAD_TYPE.TY_TB_LINKED_ENTY;
    L_EMPTY_JOINT_HOLDERS   STPKSS_ACCOUNT_UPLOAD_TYPE.TY_TB_ACC_JOINT;
  
    L_AUTO_GEN_FLAG CHAR;
    L_SOURCE        COTM_SOURCE.SOURCE_CODE%TYPE;
  
    L_ERR_CODE  VARCHAR2(100);
    L_ERR_PARAM VARCHAR2(100);
  BEGIN
    DBG('Inside fn_copy_acc');
    DBG('Beginning the rest of the defaults');
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Customer: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    BEGIN
      SELECT DECODE(CUSTOMER_TYPE, 'B', 'C', CUSTOMER_TYPE)
        INTO L_CAT_TYPE
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY    := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RISK_FREE_EXP_AMOUNT := NULL;
    END;
    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_EXP_TYPE_MASTER
       WHERE CATEGORY_TYPE = L_CAT_TYPE
         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';
      IF L_CNT <> 0 THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RISK_FREE_EXP_AMOUNT := NULL;
      END IF;
    END;
    DBG('---------------1------------------');
  
    DBG('AUTO DEPOSITS BAL BEFORE: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL := NULL;
    DBG('AUTO DEPOSITS BAL BEFORE: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL);
  
    DBG('p_Stdcusac.v_Sttms_Cust_Account.Clearing_Ac_No :' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO);
    DBG('p_Stdcusac.v_Sttms_Cust_Account.MULTI_CCY_AC_NO :' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO := NULL;
    IF NOT STPKS_STDMCYAC_KERNEL.G_MULTI_CURRENCY_1 THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO := NULL;
    END IF;
  
    DBG('p_Stdcusac.v_Sttms_Cust_Account.Clearing_Ac_No :' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO);
    DBG('p_Stdcusac.v_Sttms_Cust_Account.MULTI_CCY_AC_NO :' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES := 'N';
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS              := 'NORM';
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE            := GLOBAL.APPLICATION_DATE;
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC, 'N') <> 'Y' THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING         := 'N';
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT := NULL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH  := NULL;
    END IF;
    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'N') THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED := 'N';
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL    := NULL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES   := NULL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1            := NULL;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2            := NULL;
    END IF;
  
    DBG('Nullifying Subsystems: ');
    DBG('Interest');
  
    DBG('Brn: ' || P_STDCUSAC.V_ICTMS_ACC.BRN);
  
    DBG('deposit');
  
    P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.DELETE;
    DBG('Payouts');
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS       := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS  := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT  := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC       := NULL;
  
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDPCPAYOUT := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDBCPAYOUT := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_PR.DELETE;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_EFFDT.DELETE;
    P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_UDEVALS.DELETE;
    P_STDCUSAC.TY_ICCTDFPO.V_UI_COLUMNS__MULT_INTRT.DELETE;
    P_STDCUSAC.TY_ICCTDFPO.V_CHILDTDPAYOUT_DETAILS.DELETE;
  
    P_STDCUSAC.TY_ICCINTPO.V_STTMS_CUST_ACCOUNT     := NULL;
    P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS := NULL;
    P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS := NULL;
    P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS       := NULL;
  
    DBG('Charges');
    P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT := NULL;
    P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.DELETE;
    P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB.DELETE;
    P_STDCUSAC.TY_ICCHSPCN.V_CSTBS_UI_COLUMNS := NULL;
    DBG('Misdetails');
    P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT := NULL;
  
    P_STDCUSAC.TY_MICACCTM.V_MITB_ACCOUNT_CHANGE_LOG.DELETE;
    P_STDCUSAC.TY_MICACCTM.V_MITB_BAL_TRANSFER_LOG.DELETE;
  
    P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32 := NULL;
    P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD33 := NULL;
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_NUMBER := NULL;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21      := NULL;
  
    DBG('UDFDetails');
  
    DBG('Consolidated charges');
    P_STDCUSAC.TY_ICCCSPCN.V_STTMS_CUST_ACCOUNT := NULL;
    P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.DELETE;
    P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL.DELETE;
    P_STDCUSAC.TY_ICCCSPCN.V_CSTBS_UI_COLUMNS.DELETE;
    DBG('Autodeposit details');
    P_STDCUSAC.TY_ICCINSTR.V_STTMS_CUST_ACCOUNT        := NULL;
    P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION := NULL;
    DBG('Linked entities');
    P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.DELETE;
    P_STDCUSAC.TY_CSCCUSLN.V_STTM_CUST_ACCOUNT := NULL;
  
    DBG('Diary details');
    P_STDCUSAC.TY_SICDIARY.V_SITMS_DIARY_MASTER.DELETE;
  
    DBG('Doc checklist');
    IF P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
    
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT LOOP
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED := NULL;
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).EXPIRY_DATE := NULL;
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).EXPECTED_DATE_SUBMISSION := NULL;
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).ACTUAL_SUBMISSION_DATE := NULL;
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).DOCREFNO := NULL;
      END LOOP;
    END IF;
  
    BEGIN
      SELECT NVL(AC_AUTOGEN_FLAG, 'N')
        INTO L_AUTO_GEN_FLAG
        FROM STTMS_ACC_PARAM
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT NVL(AC_AUTOGEN_FLAG, 'N')
          INTO L_AUTO_GEN_FLAG
          FROM STTMS_ACC_PARAM
         WHERE BRANCH_CODE = '***';
      WHEN OTHERS THEN
        DBG('Failed while fetching mask details ' || SQLERRM);
        RETURN FALSE;
    END;
    L_SOURCE                                                     := CSPKS_REQ_GLOBAL.G_HEADER('SOURCE');
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY                  := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE                := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE                 := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT        := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES      := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2               := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2                := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2               := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2       := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3               := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3                := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3               := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3       := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXCL_SAMEDAY_RVRTRNS_FM_STMT := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT            := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE      := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE   := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO        := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2     := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE2  := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO2       := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3     := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE3  := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO3       := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_AUTO_CLOSED          := 'N';
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT := 'N';
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO         := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED      := NULL;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE      := NULL;
    IF L_AUTO_GEN_FLAG = 'Y' THEN
      DBG('Calling stpks_stdcusac_utils_0.fn_default_custacc when autogen flag Y');
      IF NOT STPKS_STDCUSAC_UTILS_0.FN_DEFAULT_CUSTACC(P_FUNCTION_ID,
                                                       P_STDCUSAC,
                                                       L_SOURCE,
                                                       GLOBAL.USER_ID) THEN
        RETURN FALSE;
      END IF;
    END IF;
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DR_OVD := 'N';
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_CR_OVD := 'N';
  
    P_STDCUSAC.TY_STCCHNLM.V_STTMS_ACCOUNT_CHANNEL.DELETE;
    DBG('Calling fn_default_channels');
    IF NOT STPKSS_STDCUSAC_UTILS_0.FN_DEFAULT_CHANNELS(L_SOURCE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                       P_STDCUSAC.TY_STCCHNLM.V_STTMS_ACCOUNT_CHANNEL,
                                                       L_ERR_CODE,
                                                       L_ERR_PARAM) THEN
      DBG('fn_default_channels has returned false');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
      RETURN FALSE;
    END IF;
  
    DBG('fn_copy_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_copy_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_COPY_ACC;

  FUNCTION FN_DELACC(P_FUNCTION_ID IN VARCHAR2,
                     P_AC_NO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                     P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
    L_MODNO STTMS_CUST_ACCOUNT.MOD_NO%TYPE;
    L_SURE  BOOLEAN;
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM VARCHAR2(400);
  BEGIN
    DBG('Inside fn_delacc');
    BEGIN
      SELECT MOD_NO
        INTO L_MODNO
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('failed while fetching mod_no');
    END;
    DBG('Calling gipks_check.fn_clear_gi_data');
    IF NOT GIPKS_CHECK.FN_CLEAR_GI_DATA(P_AC_NO, L_MODNO, L_MODNO) THEN
      DBG('Fn_Clear_GI_Data.....Delete failed');
    END IF;
    DBG('Calling cepkss.fn_post_update_account');
    IF NOT
        CEPKSS.FN_POST_UPDATE_ACCOUNT(P_AC_NO, P_BRN, 'DELETE', L_ERR_CODE) THEN
      DBG('failed in cepkss.Fn_Post_Update_account');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
      RETURN FALSE;
    END IF;
    DBG('Updating svtms_acc_sig_master');
  
    DBG('Updating svtms_acc_sig_det');
    UPDATE SVTMS_ACC_SIG_DET
       SET RECORD_STAT = 'D'
     WHERE BRANCH = P_BRN
          
       AND ACC_NO = P_AC_NO;
    BEGIN
      DBG('Deleting from cstb_custacseq');
      DELETE FROM CSTB_CUSTACSEQ
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_AC_NO;
      DBG('Successfully deleted from cstb_custacseq');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Deleting from cstb_custacseq failed ' || SQLERRM);
        RETURN FALSE;
    END;
    BEGIN
      DBG('Deleting from  sttms_account_bal_tov');
      DELETE FROM STTMS_ACCOUNT_BAL_TOV
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_AC_NO;
      DBG('Successfully deleted from sttms_account_bal_tov');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Deleting from sttms_account_bal_tov failed ' || SQLERRM);
    END;
  
    BEGIN
      DBG('Deleting from  sttm_acc_notice_pref');
      DELETE FROM STTM_ACC_NOTICE_PREF
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_AC_NO;
      DBG('Successfully deleted from sttm_acc_notice_pref');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Deleting from sttm_acc_notice_pref failed' || SQLERRM);
    END;
  
    BEGIN
      DBG('Deleting from ictb_maint_queue for accounts created from excel upload');
      DELETE FROM ICTBS_MAINT_QUEUE
       WHERE MAINT_KEY LIKE '%' || P_AC_NO || '%'
         AND BRN = P_BRN;
      DBG('Successfully deleted from ictb_maint_queue');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Deleting from ictb_maint_queue failed' || SQLERRM);
    END;
  
    DBG('fn_delacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_delacc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_DELACC;

  FUNCTION FN_DELETE_ACC(P_FUNCTION_ID IN VARCHAR2,
                         P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM      VARCHAR2(400);
    L_STMT_ACC_EXIST NUMBER;
    L_CUST_COUNT     NUMBER;
  BEGIN
    DBG('Inside fn_delete_acc');
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('#3 Mis brn: ' ||
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('#3 Mis acc: ' ||
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                       CSPKS_REQ_GLOBAL.P_DELETE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
      RETURN FALSE;
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CUST_COUNT
        FROM SFTMS_CUST_SUBSCRIPTION
       WHERE SUB_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND SUB_BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      IF L_CUST_COUNT > 0 THEN
        L_ERR_CODE  := 'SF-CUSB24';
        L_ERR_PARAM := 'SD Term Deposit Account cannot be Deleted';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED IN SUBSCRIPTION VALIDATION....');
    END;
    DBG('Starting the deletion');
    IF NOT FN_DELACC(P_FUNCTION_ID,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('fn_delacc has returned false');
      RETURN FALSE;
    END IF;
    DBG('fn_delete_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_delete_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_DELETE_ACC;

  FUNCTION FN_REOPEN_INSTRUCTION(P_FUNCTION_ID IN VARCHAR2,
                                 P_AC_NO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
    L_MOD_NO     STTMS_ACCOUNT_MAINT_INSTR.MOD_NO%TYPE;
    L_DATE_STAMP STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                        'DD-MON-YYYY') ||
                                                               TO_CHAR(FN_SYSDATE,
                                                                        'HH24:MI:SS')),
                                                               'DD-MON-YYYY HH24:MI:SS');
    CURSOR CUR_INST IS
      SELECT BRANCH_CODE, ACCOUNT_NO, SEQ_NO, MOD_NO
        FROM ICTBS_DEPOSIT_INSTRUCTION
       WHERE BRANCH_CODE = P_BRN
         AND ACCOUNT_NO = P_AC_NO;
  BEGIN
    DBG('Inside fn_reopen_instruction');
    DBG('Updating ictbs_deposit_instruction initially');
    UPDATE ICTBS_DEPOSIT_INSTRUCTION
       SET RECORD_STAT      = 'O',
           AUTH_STAT        = 'U',
           MAKER_ID         = GLOBAL.USER_ID,
           MAKER_DT_STAMP   = L_DATE_STAMP,
           CHECKER_ID       = NULL,
           CHECKER_DT_STAMP = NULL
     WHERE ACCOUNT_NO = P_AC_NO
       AND BRANCH_CODE = P_BRN;
    FOR EACH_ROW IN CUR_INST LOOP
    
      UPDATE ICTBS_DEPOSIT_INSTRUCTION
         SET MOD_NO = NVL(EACH_ROW.MOD_NO, 0) + 1
       WHERE BRANCH_CODE = EACH_ROW.BRANCH_CODE
         AND ACCOUNT_NO = EACH_ROW.ACCOUNT_NO
         AND SEQ_NO = EACH_ROW.SEQ_NO;
    END LOOP;
    DBG('Done with ictbs_deposit_instruction');
    BEGIN
      SELECT MOD_NO
        INTO L_MOD_NO
        FROM STTMS_ACCOUNT_MAINT_INSTR
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
      DBG('l_mod_no: ' || L_MOD_NO);
      L_MOD_NO := L_MOD_NO + 1;
      DBG('Updating sttms_account_maint_instr with mod no: ' || L_MOD_NO);
      UPDATE STTMS_ACCOUNT_MAINT_INSTR
         SET RECORD_STAT      = 'O',
             AUTH_STAT        = 'U',
             MAKER_ID         = GLOBAL.USER_ID,
             MAKER_DT_STAMP   = L_DATE_STAMP,
             CHECKER_ID       = NULL,
             CHECKER_DT_STAMP = NULL,
             MOD_NO           = L_MOD_NO
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('in When no data found in Sttms_Account_Maint_Instr..');
    END;
  
    DBG('fn_reopen_instruction returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_reopen_instruction with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_REOPEN_INSTRUCTION;

  FUNCTION FN_REOPEN_POSTUPLD(P_FUNCTION_ID IN VARCHAR2,
                              P_AC_NO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
  BEGIN
    DBG('Inside fn_reopen_postupld');
    DBG('Calling cepkss.Fn_Post_Update_account for AUTH');
    IF NOT
        CEPKSS.FN_POST_UPDATE_ACCOUNT(P_AC_NO, P_BRN, 'REOPEN', L_ERR_CODE) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
      RETURN FALSE;
    END IF;
    DBG('Calling fn_reopen_instruction');
    IF NOT FN_REOPEN_INSTRUCTION(P_FUNCTION_ID, P_AC_NO, P_BRN) THEN
      DBG('fn_reopen_instruction has returned false');
      RETURN FALSE;
    END IF;
    DBG('fn_reopen_postupld returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_reopen_postupld with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_REOPEN_POSTUPLD;

  FUNCTION FN_REOPEN_CUSTACC(P_FUNCTION_ID IN VARCHAR2,
                             P_AC_NO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                             P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM VARCHAR2(400);
    L_COUNT     NUMBER;
    L_AC_TYPE   STTMS_CUST_ACCOUNT.ACCOUNT_TYPE%TYPE;
    L_CUST_NO   STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_REC_STAT  STTM_CUSTOMER.RECORD_STAT%TYPE;
    L_DECEASED  STTM_CUSTOMER.DECEASED%TYPE;
  BEGIN
    DBG('Inside fn_reopen_custacc');
    DBG('Checking for presence of TD account');
    SELECT ACCOUNT_TYPE
      INTO L_AC_TYPE
      FROM STTMS_CUST_ACCOUNT
     WHERE BRANCH_CODE = P_BRN
       AND CUST_AC_NO = P_AC_NO;
    IF L_AC_TYPE = 'Y' THEN
      DBG('Closed TD A/c can not be reopened');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSTD01', '');
      RETURN FALSE;
    END IF;
    BEGIN
      SELECT CUST_NO
        INTO L_CUST_NO
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
      DBG('Customer number is ' || P_AC_NO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('customer fetching failed..');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-LM0018', '');
        RETURN FALSE;
    END;
  
    DBG('Checking for customer DECEASED/CLOSED STATUS: ' || L_CUST_NO);
    BEGIN
      SELECT NVL(RECORD_STAT, '*'), NVL(DECEASED, 'N')
        INTO L_REC_STAT, L_DECEASED
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = L_CUST_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('no data found');
    END;
    DBG('l_rec_stat--> ' || L_REC_STAT);
    DBG('l_deceased--> ' || L_DECEASED);
  
    IF L_REC_STAT = 'C' THEN
      DBG('Customer is closed ');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-188', '');
      RETURN FALSE;
    END IF;
    IF L_DECEASED = 'Y' THEN
      DBG('Customer is DECEASED ');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-801', '');
      RETURN FALSE;
    END IF;
  
    DBG('Update interest start date for IC account');
    UPDATE ICTMS_ACC A
    
       SET A.INT_START_DATE = GLOBAL.APPLICATION_DATE,
           A.CHG_START_DATE = GLOBAL.APPLICATION_DATE
     WHERE A.BRN = P_BRN
       AND A.ACC = P_AC_NO;
    DBG('fn_reopen_custacc returning true');
    RETURN TRUE;
  END FN_REOPEN_CUSTACC;

  FUNCTION FN_REOPEN_ACC(P_FUNCTION_ID IN VARCHAR2,
                         P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_POST_UPLD   IN BOOLEAN DEFAULT FALSE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
  BEGIN
    DBG('Inside fn_reopen_acc');
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF P_POST_UPLD THEN
      DBG('Inside fn_reopen_acc for post upld');
      DBG('Calling fn_reopen_postupld');
      IF NOT
          FN_REOPEN_POSTUPLD(P_FUNCTION_ID,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
        DBG('fn_reopen_postupld has returned false');
        RETURN FALSE;
      END IF;
      DBG('fn_reopen_acc for post upld returning true');
      RETURN TRUE;
    END IF;
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                       CSPKS_REQ_GLOBAL.P_REOPEN,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
      RETURN FALSE;
    END IF;
    DBG('Reopening');
    IF NOT FN_REOPEN_CUSTACC(P_FUNCTION_ID,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('fn_reopen_custacc has returned false');
      RETURN FALSE;
    END IF;
    DBG('fn_reopen_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_reopen_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_REOPEN_ACC;

  FUNCTION FN_GET_ACC_CLOSURE_DET(P_FUNCTION_ID IN VARCHAR2,
                                  P_STCACLOS    IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                  P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_CLOSE_REQD  OUT CHAR) RETURN BOOLEAN IS
    L_BRN      STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_AC_NO    STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_SEQ_NO   NUMBER;
    L_INTEREST NUMBER := 0;
    L_TAX      NUMBER := 0;
    AL_RET     VARCHAR2(12);
    L_CALC_DT  DATE;
    L_SUCCESS  VARCHAR2(1);
  
    IC_MAPPED  NUMBER := 0;
    REQ_LIQ_DT DATE;
    IC_DT      DATE;
  
    L_CHG_AMT  NUMBER := 0;
    L_CHG_AMT1 NUMBER := 0;
    L_XRATE    NUMBER;
  
    L_ERR_PARAM VARCHAR2(2000);
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_KEY_ID VARCHAR2(1000);
  
    L_RULE          ICTMS_RULE.RULE_ID%TYPE;
    L_INT_ACC_CLOSE ICTMS_RULE.INT_ACC_CLOSE%TYPE;
  
    L_ACQUIRED_AMT NUMBER := 0;
  
  BEGIN
    DBG('Inside fn_get_acc_closure_det');
    L_BRN                                           := P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE;
    L_AC_NO                                         := P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO;
    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_DATE := GLOBAL.APPLICATION_DATE;
  
    BEGIN
      DBG('B4 select from AC CLOSURE table...');
      SELECT NVL(MAX(CLOSING_SEQ_NO), 0)
        INTO L_SEQ_NO
        FROM STTBS_CUST_AC_CLOSURE
       WHERE BRANCH_CODE = L_BRN
         AND AC_NO = L_AC_NO;
      P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_SEQ_NO := L_SEQ_NO + 1;
      DBG('After select ...seq no is...' || L_SEQ_NO);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_SEQ_NO := 1;
      WHEN OTHERS THEN
        DBG('Failed in when others while select for seq no....' || SQLERRM);
        DBG('Closure of Account Failed.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS24', '');
        RETURN FALSE;
    END;
    DBG('Closing seq no is...' ||
        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_SEQ_NO);
    BEGIN
      DBG('B4 select of product type..');
      L_SUCCESS := 'N';
      FOR I IN (SELECT B.PRODUCT_CODE,
                       B.PRODUCT_TYPE,
                       A.LAST_LIQ_DT,
                       C.INT_START_DATE
                  FROM ICTB_ACC_PR A, ICTM_PRODUCT_DEFINITION B, ICTMS_ACC C
                 WHERE A.PROD = B.PRODUCT_CODE
                   AND A.ACC = C.ACC
                   AND A.BRN = C.BRN
                   AND A.ACC = L_AC_NO
                   AND A.LAST_LIQ_DT <
                       (P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_DATE - 1)
                      
                   AND A.BRN = L_BRN
                      
                   AND NVL(A.STOP_IC, 'N') = 'N'
                      
                   AND EXISTS
                 (SELECT 1
                          FROM ICTMS_PR_INT
                         WHERE PRODUCT_CODE = A.PROD
                           AND NVL(ZAKAT_PRODUCT, 'N') = 'N'))
      
       LOOP
      
        IF I.LAST_LIQ_DT IS NOT NULL THEN
          L_CALC_DT := I.LAST_LIQ_DT + 1;
        ELSE
          L_CALC_DT := I.INT_START_DATE;
        END IF;
        DBG('Calc FROM ' || L_CALC_DT || ' TO ' ||
            (P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_DATE - 1));
        DBG('Product type is...' || I.PRODUCT_TYPE);
        IF I.PRODUCT_TYPE NOT IN ('C', 'S') THEN
        
          BEGIN
            SELECT A.RULE
              INTO L_RULE
              FROM ICTMS_PR_INT A
             WHERE A.PRODUCT_CODE = I.PRODUCT_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed to get rule id ' || SQLERRM);
          END;
          DBG('RULE ID is ---' || L_RULE);
          BEGIN
            SELECT B.INT_ACC_CLOSE
              INTO L_INT_ACC_CLOSE
              FROM ICTM_RULE B
             WHERE B.RULE_ID = L_RULE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed to get int acc close flag ' || SQLERRM);
          END;
          DBG('l_int_acc_close is ---' || L_INT_ACC_CLOSE);
          IF NVL(L_INT_ACC_CLOSE, 'N') = 'Y' THEN
          
            DBG('Calling icpkss_calc.pr_icalc now ...' || L_BRN || '~' ||
                L_AC_NO || '~' || L_CALC_DT || '~' ||
                P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_DATE);
            DELETE FROM ICTW_MEMO_BOOKING
             WHERE BRN = L_BRN
               AND ACC = L_AC_NO
               AND PROD = I.PRODUCT_CODE;
          
            DBG('before call to icpks_test.pr_icalc');
          
            ICPKSS_TEST.PR_ICALC(L_BRN,
                                 L_AC_NO,
                                 I.PRODUCT_CODE,
                                 L_CALC_DT,
                                 (P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_DATE - 1));
          
            DBG('After call to pr_icalc....B4 interest calculation');
            L_SUCCESS := 'Y';
          END IF;
        END IF;
      END LOOP;
      DBG('l_success is ...' || L_SUCCESS);
      IF L_SUCCESS = 'Y' THEN
        L_INTEREST := ICPKS_BOD.FN_INT_ONLIQ(L_AC_NO, L_BRN);
        DBG('Interest calculated is ...' || L_INTEREST);
        L_TAX := ICPKS_BOD.FN_TAX_ONLIQ(L_AC_NO, L_BRN);
        DBG('Tax calculated is ...' || L_TAX);
      END IF;
      DBG('The interest is ...' || L_INTEREST || '------' ||
          'l_tax is ...' || L_TAX);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('failed in wo while calc of interest/tax...' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS18', '');
        DBG('Failed to calculate Interest for the account');
        RETURN FALSE;
    END;
    DBG('Done with calculation of interest and tax');
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE,
                                                P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO,
                                                'Y',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE := NVL(G_BALREC.ACY_CURR_ACC_BAL,
                                                              0);
  
    DBG('Closing Bal: ' ||
        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE);
    IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE IS NULL THEN
      DBG('Balnave is NULL');
      P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE := 0;
    END IF;
    P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 := NVL(P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43,
                                                      0);
    P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 := L_INTEREST - L_TAX;
  
    DBG('p_Stcaclos.v_Cstbs_Ui_Columns.Char_Field43 IS ::' ||
        P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43);
    SELECT NVL(SUM(DECODE(DRCR, 'D', -1, 'C', 1) * NVL(ACQUIRED_AMT, 0)), 0)
      INTO L_ACQUIRED_AMT
      FROM ICTB_ENTRIES
     WHERE ACC = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO
       AND BRN = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE;
    DBG('l_acquired_amt IS :' || L_ACQUIRED_AMT);
    P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 := P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 +
                                                  L_ACQUIRED_AMT;
  
    DBG('remaining interest applicable is ...' ||
        P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 || 'and balance is ...' ||
        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE);
  
    IF P_FUNCTION_ID = 'STDCUSAC' THEN
      IF P_STCACLOS.V_RETAIL_CHARGE_DETAILS.COUNT = 0 THEN
        L_KEY_ID := '~' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE || '~' ||
                    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO || '~' ||
                    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_SEQ_NO || '~';
        DBG('key_id for service charge-->' || L_KEY_ID);
      
        DBG('Calling fn_service_charge_pickup!!!!');
        IF NOT
            STPKS_STCACLOS_KERNEL.FN_SERVICE_CHARGE_PICKUP(P_SOURCE,
                                                           CSPKS_REQ_WRAPPER.G_SOURCE_OPERATION,
                                                           'STDCUSAC',
                                                           'CHGPKUP',
                                                           'A',
                                                           L_KEY_ID,
                                                           P_STCACLOS,
                                                           L_ERR_CODE,
                                                           L_ERR_PARAM) THEN
          DBG('fn_service_charge_pickup has returned false inside main calls');
          RETURN FALSE;
        END IF;
      END IF;
      IF P_STCACLOS.V_RETAIL_CHARGE_DETAILS.COUNT > 0 THEN
        FOR I IN P_STCACLOS.V_RETAIL_CHARGE_DETAILS.FIRST .. P_STCACLOS.V_RETAIL_CHARGE_DETAILS.LAST LOOP
          DBG('inside loop to get charge amount ' || P_STCACLOS.V_RETAIL_CHARGE_DETAILS(I)
              .AMOUNT);
          IF NVL(P_STCACLOS.V_RETAIL_CHARGE_DETAILS(I).WAIVER, 'N') = 'N' THEN
          
            L_CHG_AMT1 := 0;
            L_XRATE    := NULL;
            L_ERR_CODE := NULL;
            IF P_STCACLOS.V_RETAIL_CHARGE_DETAILS(I)
             .CURRENCY != P_STCACLOS.V_STTMS_CUST_ACCOUNT.CCY THEN
              DBG('Conversion from ' || P_STCACLOS.V_RETAIL_CHARGE_DETAILS(I)
                  .CURRENCY || ' to  ' ||
                  P_STCACLOS.V_STTMS_CUST_ACCOUNT.CCY);
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 P_STCACLOS.V_RETAIL_CHARGE_DETAILS         (I)
                                                 .CURRENCY,
                                                 P_STCACLOS.V_STTMS_CUST_ACCOUNT.CCY,
                                                 P_STCACLOS.V_RETAIL_CHARGE_DETAILS         (I)
                                                 .AMOUNT,
                                                 'Y',
                                                 L_CHG_AMT1,
                                                 L_XRATE,
                                                 L_ERR_CODE) THEN
                DBG(' Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in Fn_Get_Acc_Closure_Det');
                RETURN FALSE;
              END IF;
              L_CHG_AMT := L_CHG_AMT + NVL(L_CHG_AMT1, 0);
              DBG('l_chg_amt in if-->' || L_CHG_AMT);
            ELSE
              L_CHG_AMT := NVL(L_CHG_AMT, 0) +
                           NVL(P_STCACLOS.V_RETAIL_CHARGE_DETAILS(I).AMOUNT,
                               0);
              DBG('l_chg_amt in else-->' || L_CHG_AMT);
            END IF;
            DBG('total charge amount in account ccy-->' || L_CHG_AMT);
          
          END IF;
        END LOOP;
      
        IF L_CHG_AMT > 0 AND
           (P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE +
           P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43) < L_CHG_AMT THEN
          DBG('Available balance is less than the charge amount.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS30', '');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
  
    DBG('#23723961 p_Stcaclos.v_Sttbs_Cust_Ac_Closure.Closing_Balance' ||
        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE);
    DBG('#23723961 p_Stcaclos.v_Cstbs_Ui_Columns.Char_Field43 ' ||
        P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43);
    DBG('#23723961 l_chg_amt  ' || L_CHG_AMT);
  
    IF (P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE +
       P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43) - L_CHG_AMT = 0 THEN
    
      DBG('Close Mode is not required since available balance is 0');
      P_CLOSE_REQD := 'N';
      IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS12', '');
      END IF;
    
    ELSE
      DBG('p_close_reqd=Y..so close mode is required');
      P_CLOSE_REQD := 'Y';
    END IF;
    DBG('fn_get_acc_closure_det returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_get_acc_closure_det with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_GET_ACC_CLOSURE_DET;

  FUNCTION FN_PRECLOSE_ACC(P_FUNCTION_ID IN VARCHAR2,
                           P_STCACLOS    IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                           P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                           P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
    L_CLOSE_REQD CHAR;
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM VARCHAR2(3000);
    L_COUNT     NUMBER(4) := 0;
  
    LCOUNT1 NUMBER;
  BEGIN
    DBG('Inside fn_preclose_acc');
    DBG('Brn: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Ccy: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.CCY);
    DBG('Getting the closure details');
  
    SELECT COUNT(*)
      INTO LCOUNT1
      FROM STTM_CUST_ACCOUNT
     WHERE CONSOL_CHG_BRN = P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
       AND CONSOL_CHG_ACC = P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF LCOUNT1 > 0 THEN
      DBG('RECORD CANT BE CLOSED');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-VALS-220', '');
      RETURN FALSE;
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO LCOUNT1
        FROM CATM_ACC_STRUCTURE_DETAIL A, CATM_ACCOUNT_STRUCTURE B
       WHERE B.STRUCTURE_GROUP = A.STRUCTURE_GROUP
         AND B.RECORD_STAT = 'O'
         AND A.COVER_ACCOUNT = P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND A.COVER_BRANCH = P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      DBG('lcount1 ' || LCOUNT1);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get COUNT OF Accoutn structure');
    END;
    IF LCOUNT1 > 0 THEN
      DBG('RECORD CANT BE CLOSED');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-301', '');
      RETURN FALSE;
    END IF;
  
    SELECT COUNT(*)
      INTO L_COUNT
      FROM CATMS_AMOUNT_BLOCKS
     WHERE AMOUNT_BLOCK_TYPE = 'C'
       AND RECORD_STAT = 'O'
       AND ACCOUNT = P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
       AND BRANCH = P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    DBG('coming here');
  
    DBG('l_count is ' || L_COUNT);
    IF L_COUNT > 0 THEN
      DBG('Cover Account Cannot be Closed as it has Amount Block');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-227', '');
      RETURN FALSE;
    END IF;
  
    DBG('To disallow the closure of an account if this a/c linked as an guarator and trk receivable exists');
    IF INSTR(CSPKS_OS_PARAM.GET_PARAM_VAL('MODULE_INSTALLED'), 'CL') > 0 THEN
      IF CLPKSS_UTIL.FN_RECVTRK_EXISTS(NULL,
                                       NULL,
                                       P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                       P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                       L_ERR_CODE,
                                       L_ERR_PARAM) THEN
        DBG('Receivable tracking exists for this a/c acting as guarantor...so cannot close this a/c');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS66', '');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_GET_ACC_CLOSURE_DET(P_FUNCTION_ID,
                                  P_STCACLOS,
                                  P_SOURCE,
                                  L_CLOSE_REQD) THEN
      DBG('fn_get_acc_closure_det has returned false');
    END IF;
    DBG('fn_preclose_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_preclose_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_PRECLOSE_ACC;

  FUNCTION FN_ALLOW_CLOSE(P_FUNCTION_ID IN VARCHAR2,
                          P_AC_NO       IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                          P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
    L_UNAUTHDR             NUMBER;
    L_UNAUTHCR             NUMBER;
    L_TANK_UNAUTHDR        NUMBER;
    L_TANK_UNAUTHCR        NUMBER;
    L_ACY_TANK_CR          NUMBER;
    L_ACY_TANK_DR          NUMBER;
    L_LCY_TANK_CR          NUMBER;
    L_LCY_TANK_DR          NUMBER;
    L_ACY_TANK_UNCOLLECTED NUMBER;
    L_ACY_CURR_BALANCE     NUMBER;
    L_LCY_CURR_BALANCE     NUMBER;
    L_ACY_UNCOLLECTED      NUMBER;
    AL_RETURN              VARCHAR2(10);
    L_TOT                  NUMBER;
    L_BAL_COUNT            NUMBER(10);
    L_BALREC               STTMS_ACCOUNT_BAL_TOV%ROWTYPE;
    IC_DT                  DATE;
    REQ_LIQ_DT             DATE;
  
    NUM_SLAVES       INTEGER;
    SI_COUNT         NUMBER(10);
    AL_RET           VARCHAR2(10);
    L_BILL_PROD_CODE VARCHAR2(4);
    L_SLAVE_CNT      NUMBER;
    L_FLAG           NUMBER;
    L_LINE_ACC_COUNT NUMBER;
    L_STAT           STTMS_CUST_ACCOUNT.ACC_STATUS%TYPE;
    MSG_COUNT        NUMBER(3);
    L_CNT            NUMBER;
    L_COUNT          NUMBER;
    L_AUTH_STAT      STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_DR_INT_DUE     NUMBER;
    L_CHG_DUE        NUMBER;
    L_NET            NUMBER;
    L_NON_PPC_CNT    NUMBER := 0;
    L_BRANCH_CODE    VARCHAR2(10);
    L_RECORD_STAT    CHAR(1);
    L_PC_COUNT       NUMBER;
  
    L_RECCOUNT NUMBER;
  
    L_AUTO_CREATE_POOL STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL%TYPE;
  
    L_ERR_CODE  ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM ERTBS_MSGS.MESSAGE%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_CNT_UNAUTH       NUMBER := 0;
    L_CUST_CHANGE      NUMBER := 0;
    L_UP_COUNT         NUMBER := 0;
    L_TOTAL_AMOUNT_DUE CSTBS_AUTO_SETTLE_BLOCK.AMOUNT_DUE%TYPE;
    L_CIF_FROZEN       STTMS_CUSTOMER.FROZEN%TYPE;
    L_LINK_CNT         NUMBER := 0;
    L_UNAUTH_UP_COUNT  NUMBER := 0;
    EXP_COUNT          NUMBER(10);
    L_RD_PAYMENT_BRN   ICTMS_ACC.RD_PAYMENT_BRN%TYPE;
    L_RD_PAYMENT_ACC   ICTMS_ACC.RD_PAYMENT_ACC%TYPE;
    L_YETOBECLEARED    NUMBER := 0;
    L_LINE_ACC_COUNT_1 NUMBER;
  
    TYPE TY_RD_DETAILS IS TABLE OF ICTMS_ACC%ROWTYPE;
    L_TY_RD_DETAILS TY_RD_DETAILS;
    CURSOR RD_DETAILS(P_AC_NO IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                      P_BRN   IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE) IS
      SELECT *
        FROM ICTMS_ACC A
       WHERE A.RD_PAYMENT_BRN = P_BRN
         AND A.RD_PAYMENT_ACC = P_AC_NO;
  
  BEGIN
    DBG('Inside fn_allow_close');
  
    SELECT COUNT(1)
      INTO L_UP_COUNT
      FROM UPTM_BILL_INSTRUCTION T
     WHERE T.DEBIT_BRN = P_BRN
       AND T.DEBIT_ACC = P_AC_NO
       AND T.RECORD_STAT = 'O'
       AND T.ONCE_AUTH = 'Y';
    IF L_UP_COUNT <> 0 THEN
      DBG('Utility Payments are pending for the account and hence cannot be closed');
      OVPKS.PR_APPENDTBL('ST-ACC-555', NULL);
      RETURN FALSE;
    END IF;
  
    DBG('l_up_count is :' || L_UP_COUNT);
    SELECT COUNT(1)
      INTO L_UNAUTH_UP_COUNT
      FROM UPTM_BILL_INSTRUCTION T
     WHERE T.DEBIT_BRN = P_BRN
       AND T.DEBIT_ACC = P_AC_NO
       AND T.AUTH_STAT = 'U';
    DBG('l_unauth_up_count is :' || L_UNAUTH_UP_COUNT);
    IF L_UNAUTH_UP_COUNT > 0 THEN
      DBG('Utility Payments are unauthorised');
      OVPKS.PR_APPENDTBL('ST-ACC-556', NULL);
      RETURN FALSE;
    END IF;
  
    DBG('Selecting count from sttms_cust_account');
    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_CUST_ACCOUNT
     WHERE BRANCH_CODE = P_BRN
       AND STATEMENT_ACCOUNT = P_AC_NO;
    DBG('l_cnt: ' || L_CNT);
    IF L_CNT > 0 THEN
      DBG('De Link all the linked accounts before closing the parent account.');
      DBG('Other Accts are linked to this acct for stmt Generation.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS64', '');
      RETURN FALSE;
    END IF;
    BEGIN
      SELECT AUTH_STAT, AUTO_CREATE_POOL
        INTO L_AUTH_STAT, L_AUTO_CREATE_POOL
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Faield get the auth_stat');
    END;
  
    IF L_AUTO_CREATE_POOL = 'Y' THEN
      DBG('Delink all accounts in LIMITS and uncheck auto_create_pool flag before closing');
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS150', '');
      RETURN FALSE;
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_LINK_CNT
        FROM STTMS_CUST_ACCOUNT_LINKAGES
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get the cnt of linkages');
        L_LINK_CNT := 0;
    END;
  
    IF L_LINK_CNT > 0 THEN
      DBG('Limit linkages are available.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS151', '');
    END IF;
  
    IF G_AC_DORMANCY_CLOSURE = 'N' THEN
    
      IF L_AUTH_STAT = 'U' THEN
        DBG('Unauthorized record cannot be closed, it can be deleted before first auth');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SDV05', '');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Account Linked with SafeDeposit');
    SELECT COUNT(*)
      INTO L_RECCOUNT
      FROM DLTB_LINKAGES A, CSTB_CONTRACT B
     WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
       AND B.CONTRACT_STATUS <> 'S'
       AND A.LINKED_TO_REF = P_AC_NO;
    IF L_RECCOUNT > 0 THEN
      DBG('Account is Linked with SafeDeposit');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAND-010', '');
      RETURN FALSE;
    END IF;
  
    SELECT COUNT(*)
      INTO L_COUNT
      FROM STTMS_CUST_ACCOUNT X, ICTM_TDPAYOUT_DETAILS Y
     WHERE X.CUST_AC_NO = Y.ACC
       AND X.BRANCH_CODE = Y.BRN
       AND Y.OFFSET_ACC = P_AC_NO
       AND Y.OFFSET_BRN = P_BRN
       AND X.RECORD_STAT = 'O'
       AND Y.PAYOUTTYPE = 'S';
    IF L_COUNT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-561', '');
      RETURN FALSE;
    END IF;
  
    DBG('Checking for amount due');
    BEGIN
      SELECT SUM(NVL(AMOUNT_DUE, 0)) - SUM(NVL(AMOUNT_PAID, 0))
        INTO L_TOTAL_AMOUNT_DUE
        FROM CSTBS_AUTO_SETTLE_BLOCK
       WHERE ACCOUNT_NO = P_AC_NO
         AND ACCOUNT_BR = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get amount_due: ' || SQLERRM ||
            '... So, returning from here without any reply');
        L_TOTAL_AMOUNT_DUE := 0;
    END;
    DBG(' l_Total_Amount_Due ' || L_TOTAL_AMOUNT_DUE);
    IF L_TOTAL_AMOUNT_DUE > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACL-001', '');
      RETURN FALSE;
    END IF;
  
    DBG('Checking if the customer is frozen');
    BEGIN
      SELECT FROZEN
        INTO L_CIF_FROZEN
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = (SELECT CUST_NO
                              FROM STTM_CUST_ACCOUNT
                             WHERE CUST_AC_NO = P_AC_NO
                               AND BRANCH_CODE = P_BRN);
      DBG('l_cif_frozen ' || L_CIF_FROZEN);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get l_cif_frozen');
    END;
    IF NVL(L_CIF_FROZEN, 'N') = 'Y' THEN
      DBG('Customer is frozen');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACL-002', '');
    END IF;
  
    DBG('Calling pcpks_pcdtronl_utils.Fn_check_pc_mandate ');
    IF NOT PCPKS_PCDTRONL_UTILS.FN_CHECK_PC_MANDATE(P_AC_NO,
                                                    P_BRN,
                                                    L_ERR_CODE,
                                                    L_ERR_PARAM,
                                                    P_FUNCTION_ID) THEN
      DBG('account has active mandates in PC.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, P_AC_NO);
      RETURN FALSE;
    END IF;
  
    SELECT COUNT(*)
      INTO L_CNT
      FROM CATM_CHECK_BOOK
    
     WHERE NVL(REQUEST_STATUS, 'Delivered') = 'Delivered'
       AND BRANCH = P_BRN
       AND ACCOUNT = P_AC_NO
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    IF L_CNT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CHQBOOK', '');
    
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CNT_UNAUTH
        FROM CATMS_CHECK_BOOK
       WHERE BRANCH = P_BRN
         AND ACCOUNT = P_AC_NO
         AND AUTH_STAT = 'U';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('No unauthorized record');
    END;
    DBG('l_Cnt_unauth-->' || L_CNT_UNAUTH);
    IF L_CNT_UNAUTH > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CHQBOOK1', '');
    
    END IF;
  
    DBG('Check whether the Any interest is due to be Debited from the Cust Account.');
    BEGIN
      SELECT DR_INT_DUE, CHG_DUE
        INTO L_DR_INT_DUE, L_CHG_DUE
        FROM STTMS_ACCOUNT_BAL_TOV
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Faield to get the DR_INT_DUE,CHG_DUE');
    END;
  
    IF NVL(L_CHG_DUE, 0) <> 0 THEN
      DBG('Account Has Charge Due Which Should Be Liquidated Before Account Closure');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS36', '');
      RETURN FALSE;
    END IF;
    BEGIN
      SELECT *
        INTO L_BALREC
        FROM STTMS_ACCOUNT_BAL_TOV
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'DV-ONL-063', '');
        RETURN FALSE;
    END;
  
    IF L_BALREC.NETTING_REQUIRED = 'Y' AND
       NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'), 'N') = 'Y' THEN
      SELECT COUNT(1)
        INTO L_CNT
        FROM STTM_ACC_NETTING_MASTER NM, STTM_ACC_NETTING_DETAIL ND
       WHERE NM.RECORD_STAT = 'O'
         AND NM.ONCE_AUTH = 'Y'
         AND NM.REFERENCE_NO = ND.REFERENCE_NO
         AND ND.CUST_AC_NO = P_AC_NO
         AND ND.BRANCH_CODE = P_BRN;
    
      IF L_CNT > 0 THEN
        DBG('Account is part of a netting structure Which Should Be Delinked or Closed Before Account Closure..');
        OVPKS.PR_APPENDTBL('ST-LMT-025', '');
      END IF;
    END IF;
  
    IF NOT
        CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_BRN, P_AC_NO, 'Y', G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
    L_BALREC.ACY_BLOCKED_AMOUNT := NVL(G_BALREC.ACY_BLOCKED_AMT, 0) +
                                   NVL(G_BALREC.ACY_ECA_BLOCKED_AMT, 0);
    L_BALREC.ACY_UNCOLLECTED    := NVL(G_BALREC.ACY_UNCOLLECTED, 0);
  
    DBG('l_Dr_Int_Due' || L_DR_INT_DUE);
    IF NVL(L_DR_INT_DUE, 0) <> 0 AND
       G_BALREC.ACY_WITHDRAWABLE_BAL < L_DR_INT_DUE THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS35', '');
      RETURN FALSE;
    END IF;
  
    IF L_BALREC.ACY_TANK_CR <> 0 OR L_BALREC.LCY_TANK_CR <> 0 OR
       L_BALREC.ACY_TANK_DR <> 0 OR L_BALREC.LCY_TANK_DR <> 0 OR
       L_BALREC.ACY_TANK_UNCOLLECTED <> 0 OR L_BALREC.ACY_UNCOLLECTED <> 0 OR
       L_BALREC.ACY_UNAUTH_CR <> 0 OR L_BALREC.ACY_UNAUTH_DR <> 0 OR
       L_BALREC.ACY_UNAUTH_TANK_CR <> 0 OR
      
       L_BALREC.ACY_UNAUTH_TANK_DR <> 0 OR L_BALREC.ACY_BLOCKED_AMOUNT <> 0 THEN
      DBG('Cannot close. Either uncollected funds or nonzero balance exist for this account');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS11', '');
      RETURN FALSE;
    END IF;
    DBG('All Balances are Zero...');
    DBG('checking  for slave accounts');
    BEGIN
      SELECT COUNT(*)
        INTO L_SLAVE_CNT
        FROM STTMS_CUST_ACCOUNT
       WHERE MASTER_ACCOUNT_NO = P_AC_NO
         AND BRANCH_CODE = P_BRN
         AND RECORD_STAT = 'O';
      DBG('After select for open slave a/c of this a/c...' || L_SLAVE_CNT);
      IF L_SLAVE_CNT > 0 THEN
        DBG('Account cannot be closed since Slave accounts are not closed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'AC-CLOSE011', '');
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
      WHEN OTHERS THEN
        DBG('Failed in WOT of Slave account check with: ' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'DV-ONL-063', '');
        RETURN FALSE;
    END;
    REQ_LIQ_DT := GLOBAL.APPLICATION_DATE - 1;
    DBG('I want Liquidations till ' || TO_CHAR(REQ_LIQ_DT));
    DBG('Checking if any active accounts are combined with this a/c for calculation');
    DBG('Checking if Slave (Calc) A/Cs');
    SELECT COUNT(*)
      INTO NUM_SLAVES
      FROM ICTMS_ACC A, STTMS_CUST_ACCOUNT C
     WHERE A.BRN = P_BRN
       AND A.CALC_ACC = P_AC_NO
       AND C.BRANCH_CODE = A.BRN
       AND C.CUST_AC_NO = A.ACC
       AND A.ACC != A.CALC_ACC
       AND C.RECORD_STAT = 'O';
    IF NUM_SLAVES != 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS14', '');
      RETURN FALSE;
    END IF;
    DBG('No Slave (Calc) A/Cs');
    DBG('Checking if Slave (Book) A/Cs');
    DBG('checking if other accounts have this account as their booking a/c');
    SELECT COUNT(*)
      INTO NUM_SLAVES
      FROM ICTMS_ACC A, STTMS_CUST_ACCOUNT C
    
     WHERE A.BOOK_BRN = P_BRN
       AND A.BOOK_ACC = P_AC_NO
       AND C.BRANCH_CODE = A.BRN
       AND C.CUST_AC_NO = A.ACC
       AND C.RECORD_STAT = 'O'
       AND A.ACC != A.BOOK_ACC;
    IF NUM_SLAVES != 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS15', '');
      RETURN FALSE;
    END IF;
    DBG('Check for accounts with charge_book_acc as master account');
    DBG('Checking if Slave (Charge Book) A/Cs');
    SELECT COUNT(*)
      INTO NUM_SLAVES
      FROM ICTMS_ACC A, STTMS_CUST_ACCOUNT C
    
     WHERE A.CHARGE_BOOK_BRN = P_BRN
       AND A.CHARGE_BOOK_ACC = P_AC_NO
       AND C.BRANCH_CODE = A.BRN
       AND C.CUST_AC_NO = A.ACC
       AND C.RECORD_STAT = 'O'
       AND A.ACC != A.CHARGE_BOOK_ACC;
    IF NUM_SLAVES != 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS60', '');
      RETURN FALSE;
    END IF;
    DBG('No Slave(Charge Book) A/Cs');
  
    DBG('Checking RD Auto Payment Take down account');
  
    OPEN RD_DETAILS(P_AC_NO, P_BRN);
    FETCH RD_DETAILS BULK COLLECT
      INTO L_TY_RD_DETAILS;
    CLOSE RD_DETAILS;
    DBG('RD account count: ' || L_TY_RD_DETAILS.COUNT);
    IF L_TY_RD_DETAILS.COUNT > 0 THEN
      FOR I IN L_TY_RD_DETAILS.FIRST .. L_TY_RD_DETAILS.LAST LOOP
        SELECT NVL(RECORD_STAT, 'X')
          INTO L_RECORD_STAT
          FROM STTMS_CUST_ACCOUNT C
         WHERE C.BRANCH_CODE = L_TY_RD_DETAILS(I).BRN
           AND C.CUST_AC_NO = L_TY_RD_DETAILS(I).ACC;
      
        IF L_RECORD_STAT = 'O' THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-562', '');
          RETURN FALSE;
        END IF;
      END LOOP;
    END IF;
  
    L_COUNT := 0;
    DBG('No RD Auto Payment Take down account avl');
  
    DBG('To disallow the closure of an account if this a/c linked as an guarator and trk receivable exists');
    IF INSTR(CSPKS_OS_PARAM.GET_PARAM_VAL('MODULE_INSTALLED'), 'CL') > 0 THEN
      IF CLPKSS_UTIL.FN_RECVTRK_EXISTS(NULL,
                                       NULL,
                                       P_AC_NO,
                                       P_BRN,
                                       L_ERR_CODE,
                                       L_ERR_PARAM) THEN
        DBG('Receivable tracking exists for this a/c acting as guarantor...so cannot close this a/c');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS66', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Not a guarantor for a loan a/c');
  
    DBG('To disallow the closure of an account if its linked to an active limit (in LMDLIMIT.FMB)');
    BEGIN
      IF ELPKSS.LIMITS_MODULE = 'LM' THEN
      
        SELECT COUNT(*)
          INTO L_LINE_ACC_COUNT
          FROM LMTMS_LIMITS
         WHERE INTEREST_CALC_ACC = P_AC_NO
           AND LIAB_BR = P_BRN
           AND RECORD_STAT = 'O'
           AND AVAILABILITY_FLAG = 'Y';
      
      ELSE
        IF NOT
            ELPKS_FACILITY_SERVICE.FN_GETTING_LINE_ACC_COUNT(P_AC_NO,
                                                             P_BRN,
                                                             L_LINE_ACC_COUNT) THEN
          DBG('Failed in elpks_facility_service.Fn_getting_line_acc_count ');
        END IF;
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Error in selecting from lmtms_limits ' || SQLERRM);
        RETURN FALSE;
    END;
  
    SELECT COUNT(8)
    
      INTO L_LINE_ACC_COUNT_1
      FROM GETMS_FACILITY
     WHERE INTEREST_CALC_ACC = P_AC_NO
       AND RECORD_STAT = 'O';
    DBG('l_Line_Acc_Count limit:' || L_LINE_ACC_COUNT);
  
    IF L_LINE_ACC_COUNT >= 1 AND L_LINE_ACC_COUNT_1 >= 1 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS37', '');
      RETURN FALSE;
    END IF;
    DBG('Billing Changes Start');
  
    DBG('Ensuring Billing invoice generation and liquidation is done before account is closed.');
    BEGIN
      SELECT COUNT(*)
        INTO NUM_SLAVES
        FROM ICTB_ACC_PR
       WHERE BILLING_PROD = 'Y'
         AND ACC = P_AC_NO
         AND BRN = P_BRN
         AND BILL_PRODUCT_CODE IS NOT NULL
         AND LAST_LIQ_DT < GLOBAL.APPLICATION_DATE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;
    DBG('#1 num_slaves: ' || NUM_SLAVES);
    IF (NUM_SLAVES > 0) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS100', '');
      RETURN FALSE;
    END IF;
    SELECT COUNT(*)
      INTO NUM_SLAVES
      FROM ICTB_DR_INT_DUE A, STTM_CUST_ACCOUNT B
     WHERE A.ACC = B.CUST_AC_NO
       AND A.PROD_TYPE = 'B'
       AND BRN = P_BRN
       AND (NVL(A.AMT_DUE, 0) - NVL(A.AMT_SETTLD, 0)) <> 0
       AND A.ACC = P_AC_NO;
    DBG('#2 num_slaves: ' || NUM_SLAVES);
    IF NUM_SLAVES > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS100', '');
      RETURN FALSE;
    END IF;
  
    DBG('Checking if any standing instructions are attached to the account');
  
    SELECT COUNT(*)
      INTO EXP_COUNT
      FROM SITB_INSTRUCTION I, SITB_CONTRACT_MASTER M
     WHERE M.INSTRUCTION_NO = I.INSTRUCTION_NO
       AND I.INST_VERSION_NO =
           (SELECT NVL(MAX(LATEST_VERSION_NO), 0)
              FROM SITBS_INSTRUCTION
             WHERE INSTRUCTION_NO = M.INSTRUCTION_NO)
       AND M.VERSION_NO = I.LATEST_VERSION_NO
       AND I.INST_STATUS <> 'S'
       AND NVL(M.SI_EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
           GLOBAL.APPLICATION_DATE
       AND ((M.DR_ACCOUNT = P_AC_NO AND M.DR_ACC_BR = P_BRN) OR
           (M.CR_ACCOUNT = P_AC_NO AND M.CR_ACC_BR = P_BRN));
  
    DBG('No of exp_inst' || EXP_COUNT);
  
    IF EXP_COUNT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS21', '');
      RETURN FALSE;
    ELSE
      DBG('Instructions are expired so account can be closed');
    END IF;
  
    SELECT COUNT(*)
      INTO SI_COUNT
      FROM SITM_DIARY_MASTER
     WHERE UNIT_TYPE = 'ACCOUNT'
       AND UNIT_VALUE = P_AC_NO
       AND BRANCH_CODE = P_BRN
       AND ((RECORD_STAT = 'O') OR (RECORD_STAT = 'C' AND AUTH_STAT = 'U'))
       AND NVL(EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
           GLOBAL.APPLICATION_DATE;
    DBG('No of SI attached ' || SI_COUNT);
    IF SI_COUNT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS21', '');
      RETURN FALSE;
    END IF;
    DBG('checking any active siinstruction avaialble');
  
    BEGIN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM ILTM_ACCOUNT
       WHERE ACCOUNT = P_AC_NO
            
         AND BRANCH_CODE = P_BRN
         AND RECORD_STAT = 'O';
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('failed to Select The record from table Iltm_Account...');
    END;
  
    IF L_COUNT > 0 THEN
    
      DBG('Customer Account Can Not Be Closed as this is linked to an active ILM account structure');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS22', '');
      RETURN FALSE;
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_ALLOW_CLOSE(P_FUNCTION_ID,
                                                      P_AC_NO,
                                                      P_BRN,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_cluster. Fn_Allow_Close');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Additional checks before closing account have been retroed');
    DBG('Checking if settlement instr is still open for this account');
    SELECT COUNT(*)
      INTO L_TOT
      FROM ISTMS_INSTR
    
     WHERE ((PAY_ACCOUNT = P_AC_NO AND PAY_AC_BRANCH = P_BRN) OR
           (RECV_ACCOUNT = P_AC_NO AND RECV_AC_BRANCH = P_BRN))
       AND (RECORD_STAT = 'O' OR (RECORD_STAT = 'C' AND AUTH_STAT = 'U'))
          
       AND (BRANCH = P_BRN OR BRANCH = 'ALL');
  
    IF L_TOT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSCL01', '');
      RETURN FALSE;
    END IF;
    DBG('Checking if any uninitiated contracts are linked');
    SELECT COUNT(*)
      INTO L_TOT
      FROM CSTBS_CONTRACT A, LDTBS_CONTRACT_MASTER B
     WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
       AND B.VERSION_NO = A.LATEST_VERSION_NO
       AND ((B.DFLT_SETTLE_AC = P_AC_NO AND DFLT_SETTLE_AC_BRANCH = P_BRN) OR
           (B.DR_SETL_AC = P_AC_NO AND DR_SETL_AC_BR = P_BRN))
       AND (A.CONTRACT_STATUS IN ('Y', 'A'));
  
    IF L_TOT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS54', '');
      RETURN FALSE;
    END IF;
    DBG('Checking if any active contracts are linked');
    SELECT COUNT(*)
      INTO L_TOT
      FROM CSTBS_CONTRACT A, ISTBS_CONTRACTIS B
     WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
       AND A.CONTRACT_STATUS = 'A'
       AND A.CURR_EVENT_CODE <> 'RETN'
       AND B.AMOUNT_TAG IN ('PRINCIPAL_LIQD',
                            'BILL_LIQ_AMT',
                            'BILL_LIQ_AMTEQ',
                            'SETBOTAMT',
                            'SETSOLDAMT',
                            'MAIN_INT_LIQD')
       AND B.ACCOUNT = P_AC_NO
       AND B.EVENT_SEQ_NO =
           (SELECT MAX(EVENT_SEQ_NO)
              FROM ISTBS_CONTRACTIS T
             WHERE CONTRACT_REF_NO = B.CONTRACT_REF_NO)
          
       AND B.ACC_BRANCH = P_BRN;
    IF L_TOT > 0 THEN
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACLOS01', '');
      RETURN FALSE;
    END IF;
  
    SELECT COUNT(1)
      INTO L_TOT
      FROM DLTBS_CONTRACT_MASTER A, CSTBS_CONTRACT B
     WHERE A.CONTRACT_REF_NO = B.CONTRACT_REF_NO
       AND B.CONTRACT_STATUS <> 'S'
       AND A.SETTLEMENT_ACCOUNT = P_AC_NO
       AND A.SETTLEMENT_BRANCH = P_BRN;
  
    IF L_TOT > 0 THEN
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS109', '');
      RETURN FALSE;
    END IF;
  
    DBG('Checking if this account is used as settlement account for any active CL accounts');
  
    SELECT COUNT(*)
      INTO L_TOT
      FROM CLTBS_ACCOUNT_COMPONENTS A, CLTBS_ACCOUNT_MASTER B
     WHERE ((A.DR_PROD_AC = P_AC_NO AND A.DR_ACC_BRN = P_BRN) OR
           (A.CR_PROD_AC = P_AC_NO AND A.CR_ACC_BRN = P_BRN))
       AND B.ACCOUNT_STATUS IN ('A', 'Y', 'H', 'E')
       AND A.ACCOUNT_NUMBER = B.ACCOUNT_NUMBER
       AND A.BRANCH_CODE = B.BRANCH_CODE;
  
    DBG('l_tot CL:' || L_TOT);
  
    IF L_TOT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS106', '');
      RETURN FALSE;
    END IF;
  
    BEGIN
      SELECT ACC_STATUS
        INTO L_STAT
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to fetch ACC STAUS');
        RETURN FALSE;
    END;
    IF L_STAT <> 'NORM' THEN
      DBG('Account can be closed only if status is NORM');
    
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-EXP3', '');
    
    END IF;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_NET
        FROM ACTB_NETTING_TRANSACTION
       WHERE AC_BRANCH = P_BRN
         AND AC_NO = P_AC_NO
         AND NETTING_STATUS = 'U';
    EXCEPTION
      WHEN OTHERS THEN
        L_NET := 0;
        DBG('No Netting Entries Found');
    END;
    DBG('No of Netting Entries Found' || L_NET);
    IF L_NET > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NET-008', '');
      RETURN FALSE;
    END IF;
  
    DBG('checking if any PC still active');
    SELECT COUNT(1)
      INTO L_PC_COUNT
      FROM PCTB_CONTRACT_MASTER
     WHERE CONTRACT_STATUS = 'A'
       AND CUST_AC_NO = P_AC_NO
       AND CUST_AC_BRN = P_BRN;
    IF L_PC_COUNT > 0 THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLP11', '');
    END IF;
  
    DBG('Checking if there is any ppc is still open associated with the account no');
    SELECT COUNT(1)
      INTO L_COUNT
      FROM STTM_PROJECT A, STTM_PPC B
     WHERE A.PROJECT_ID = B.PROJECT_ID
       AND A.PROJECT_AC_BRANCH = P_BRN
       AND A.PROJECT_AC_NO = P_AC_NO
       AND B.RECORD_STAT = 'O'
       AND B.ONCE_AUTH = 'Y';
    IF L_COUNT <> 0 THEN
      DBG('Cannot close account ' || P_AC_NO ||
          ' as some PPCs are still open.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-354', '');
      RETURN FALSE;
    END IF;
  
    FOR EACHREC IN (SELECT B.*
                      FROM STTM_PROJECT A, STTM_PROJECT_NON_PPC_LINES B
                     WHERE A.PROJECT_ID = B.PROJECT_ID
                       AND A.PROJECT_AC_BRANCH = P_BRN
                       AND A.PROJECT_AC_NO = P_AC_NO
                       AND A.RECORD_STAT = 'O') LOOP
      DBG('Inside the Loop checking for Non ppc line which are still open');
      L_COUNT       := ELPKS_FACILITY_SERVICE.FN_GET_FACILITY_COUNT(EACHREC.CUSTOMER_NO,
                                                                    TRIM(EACHREC.LINE_ID) ||
                                                                    TRIM(EACHREC.LINE_SERIAL));
      L_NON_PPC_CNT := L_NON_PPC_CNT + L_COUNT;
    END LOOP;
  
    IF L_NON_PPC_CNT <> 0 THEN
      DBG('Cannot close account ' || P_AC_NO ||
          ' as some Non PPC Lines  are still open.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-356', '');
      RETURN FALSE;
    END IF;
  
    DBG('Checking if the account has primary party change in progress');
    BEGIN
      SELECT COUNT(1)
        INTO L_CUST_CHANGE
        FROM STTMS_CUST_CHANGE
       WHERE BRANCH_CODE = P_BRN
         AND ACCOUNT_NO = P_AC_NO
         AND AUTH_STAT = 'U';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_CUST_CHANGE := 0;
      WHEN OTHERS THEN
        L_CUST_CHANGE := 0;
    END;
    IF L_CUST_CHANGE > 0 THEN
      DBG('There is a primary party change in progress, should not allow any transaction until complete.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-AC-566', '');
      RETURN FALSE;
    END IF;
  
    IF NOT ACPKS_UTILS.FN_VALIDATEANDRETRYFORACC(P_AC_NO,
                                                 P_BRN,
                                                 L_ERR_CODE,
                                                 L_ERR_PARAM) THEN
      DBG('Failed in acpks_utils.fn_ValidateAndRetryForAcc : ' || SQLERRM || '~' ||
          L_ERR_CODE);
      IF L_ERR_CODE IS NULL THEN
        L_ERR_CODE  := 'ST-CUS24';
        L_ERR_PARAM := NULL;
      END IF;
      OVPKSS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
      RETURN FALSE;
    END IF;
  
    DBG('Now going to validate Cheques pending for outward clearing ');
    BEGIN
      SELECT COUNT(*)
        INTO L_YETOBECLEARED
        FROM CSTB_CLEARING_MASTER
       WHERE BEN_ACCOUNT = P_AC_NO
         AND ACC_BRANCH = P_BRN
         AND DISPATCH_STATUS <> 'L'
         AND PRODUCT_CODE IN
             (SELECT PRODUCT_CODE
                FROM CGTMS_PRODUCT_REFERRAL
               WHERE DEFER_LIQUIDATION = 'Y');
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in picking records from CSTB_CLEARING_MASTER and error is ' ||
            SQLERRM);
    END;
    IF L_YETOBECLEARED > 0 THEN
      DBG('Cheques pending for outward clearing ');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLGOC', '');
      RETURN FALSE;
    END IF;
  
    DBG('fn_allow_close returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_allow_close with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_ALLOW_CLOSE;

  FUNCTION FN_VALIDATE_CLOSURE_DET(P_FUNCTION_ID    IN VARCHAR2,
                                   P_CLOSE_REQD     IN VARCHAR2,
                                   P_STCACLOS       IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                   P_SOURCE         IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                   P_INSTR_DETAILS  OUT VARCHAR2,
                                   P_OFFSET_DETAILS OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_OFS_CNT         NUMBER;
    AL_RET            VARCHAR2(12);
    L_CLOSE_MODE_TYPE CHAR;
    L_INTR_TYPE       VARCHAR2(2000);
    L_LINKED_PRD      STTM_CUSTAC_CLOSE_MODE.LINKED_RT_PRODUCT%TYPE;
  
    L_TBL_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID             NUMBER;
    L_TBL_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Inside fn_validate_closure_det');
    DBG('p_source :' || P_SOURCE);
    DBG('p_close_reqd ===>' || P_CLOSE_REQD);
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling Stpks_Stdcusac_Utils_cluster.Fn_Validate_Closure_Det');
      L_FN_CALL_ID       := 1;
      L_TBL_CLUSTER_DATA := L_TBL_CLUSTER_DATA_EMPTY;
    
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_CLOSURE_DET(P_FUNCTION_ID,
                                                               P_CLOSE_REQD,
                                                               P_STCACLOS,
                                                               P_SOURCE,
                                                               P_INSTR_DETAILS,
                                                               P_OFFSET_DETAILS,
                                                               L_FN_CALL_ID,
                                                               L_TBL_CLUSTER_DATA) THEN
      
        DEBUG.PR_DEBUG('AC',
                       'Failed in Stpks_Stdcusac_Utils_Cluster.Fn_Validate_Closure_Det');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('Global.g_Skip_Kernel is FALSE');
    
      IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE IS NULL AND
         P_CLOSE_REQD <> 'N' THEN
        DBG('Close Mode cannot be Null');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS13', '');
        RETURN FALSE;
      END IF;
      IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE IS NOT NULL AND
         P_CLOSE_REQD = 'N' THEN
        DBG('Close Mode Should be NULL');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-ACC-153',
                     'Close Mode Details~');
        RETURN FALSE;
      END IF;
      BEGIN
        DBG('Close Mode :' ||
            P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE);
        IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE +
           P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 < 0 THEN
          DBG('Balance is < 0');
          DBG('p_stcaclos.v_STTBS_CUST_AC_CLOSURE.close_mode :' ||
              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE);
        
          IF CASAPKS_BATCH.PKG_AUTO_CLOSE THEN
            DBG('Failed in Dormancy Account Closure');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS31', '');
            RETURN FALSE;
          END IF;
        
          SELECT CLOSE_MODE_TYPE
            INTO L_CLOSE_MODE_TYPE
            FROM (SELECT DISTINCT CLOSE_MODE, 'F' CLOSE_MODE_TYPE
                    FROM STTM_CUSTAC_CLOSE_MODE
                   WHERE DRCR_IND IN ('C')
                     AND CLOSE_MODE =
                         P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE
                        
                     AND RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y');
        
          BEGIN
            SELECT LINKED_RT_PRODUCT
              INTO L_LINKED_PRD
              FROM STTMS_CUSTAC_CLOSE_MODE
             WHERE DRCR_IND = 'C'
               AND CLOSE_MODE =
                   P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE
                  
               AND RECORD_STAT = 'O'
               AND ONCE_AUTH = 'Y';
          
            IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.LINKED_PRODUCT IS NOT NULL AND
               L_LINKED_PRD IS NOT NULL THEN
              IF L_LINKED_PRD <>
                 P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.LINKED_PRODUCT THEN
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-704', '');
              END IF;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
              DBG('Came in Exception of Balance is < 0 PRD case. Proceed further');
          END;
        
        ELSE
          DBG('Balnce is > 0');
          IF P_SOURCE = 'FLEXBRANCH' THEN
          
            DBG('INSIDE FLEXBRANCH');
            SELECT CLOSE_MODE
              INTO L_INTR_TYPE
              FROM STTM_CUSTAC_CLOSE_MODE
             WHERE DRCR_IND = 'D'
               AND CLOSE_MODE =
                   P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE
                  
               AND RECORD_STAT = 'O'
               AND ONCE_AUTH = 'Y';
          
            IF L_INTR_TYPE = 'BCA' THEN
              L_CLOSE_MODE_TYPE := 'I';
            ELSE
              L_CLOSE_MODE_TYPE := 'F';
            END IF;
          ELSE
          
            DBG('Close mode type: ' ||
                P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD45);
            IF P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD45 IS NULL THEN
              SELECT DISTINCT CLOSE_MODE_TYPE
                INTO L_CLOSE_MODE_TYPE
                FROM (SELECT DISTINCT CLOSE_MODE, 'F' CLOSE_MODE_TYPE
                        FROM STTM_CUSTAC_CLOSE_MODE
                       WHERE DRCR_IND = 'D'
                         AND CLOSE_MODE =
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE
                            
                         AND RECORD_STAT = 'O'
                         AND ONCE_AUTH = 'Y'
                      
                      UNION
                      SELECT DISTINCT INSTR_TYPE, 'I' CLOSE_MODE_TYPE
                        FROM ISTM_INSTR_PROD
                       WHERE INSTR_TYPE =
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE);
            ELSE
              L_CLOSE_MODE_TYPE := P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD45;
            END IF;
          
            BEGIN
              SELECT LINKED_RT_PRODUCT
                INTO L_LINKED_PRD
                FROM STTMS_CUSTAC_CLOSE_MODE
               WHERE DRCR_IND = 'D'
                 AND CLOSE_MODE =
                     P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE
                    
                 AND RECORD_STAT = 'O'
                 AND ONCE_AUTH = 'Y';
            
              IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.LINKED_PRODUCT IS NOT NULL AND
                 L_LINKED_PRD IS NOT NULL THEN
                IF L_LINKED_PRD <>
                   P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.LINKED_PRODUCT THEN
                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-703', '');
                END IF;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
                DBG('Came in Exception of Balance is > 0 PRD case. Proceed further');
            END;
          
          END IF;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Failed in close mode validation' || SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-115',
                       'Close Mode~' ||
                       P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE || '~');
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('Failed in When others :' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('l_close_mode_type: ' || L_CLOSE_MODE_TYPE);
    
      DBG('#23723961 p_Stcaclos.v_Sttbs_Cust_Ac_Closure.Offset_Branch ' ||
          P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH);
      DBG('#23723961 p_Stcaclos.v_Sttbs_Cust_Ac_Closure.Offset_Ac_No ' ||
          P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO);
      DBG('##23723961 p_Close_Reqd  ' || P_CLOSE_REQD);
    
      IF CASAPKS_BATCH.PKG_AUTO_CLOSE THEN
        DBG('This is auto account closure from casapks_batch, assighning l_Close_Mode_Type to I');
        L_CLOSE_MODE_TYPE := 'I';
      END IF;
    
      IF L_CLOSE_MODE_TYPE = 'F' AND
         P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE <> 'CASH' THEN
      
        DBG('Check for mand fields of FT');
        IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH IS NULL OR
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO IS NULL AND
           P_CLOSE_REQD = 'Y' THEN
          DBG('Offset details are Null');
          DBG('Failed in Offset details validation');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS14', '');
          RETURN FALSE;
        END IF;
        IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_PAYABLE_BRANCH IS NOT NULL OR
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_EXPIRY_DATE IS NOT NULL OR
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_NO IS NOT NULL OR
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_BENEF_NAME IS NOT NULL OR
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ISSUE_BANK IS NOT NULL THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-153',
                       'Instrument Details~');
          RETURN FALSE;
        END IF;
        BEGIN
          SELECT COUNT(*)
            INTO L_OFS_CNT
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO =
                 P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO
             AND BRANCH_CODE =
                 P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH;
          IF L_OFS_CNT < 1 THEN
            DBG('Failed because Invalid Offset Account for the selected Offset branch');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS15', '');
            RETURN FALSE;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in when others while validating offset details..' ||
                SQLERRM);
            RETURN FALSE;
        END;
      
        IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH =
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE AND
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO =
           P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO THEN
          DBG('Offset account cannot be the same as the Main account During Account Closure');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS23', '');
          RETURN FALSE;
        END IF;
      
        P_OFFSET_DETAILS := P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO || '~' ||
                            P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH || '~' ||
                            P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_CCY ||
                            '~~~';
        DBG('Offset details....' || P_OFFSET_DETAILS);
      ELSIF L_CLOSE_MODE_TYPE = 'I' THEN
      
        DBG('before chking value of casapks_batch.pkg_auto_close');
        IF CASAPKS_BATCH.PKG_AUTO_CLOSE THEN
          DBG('bulk closure offset branch value' ||
              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH);
          DBG('bulk closure offset account_no value' ||
              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO);
          DBG('bulk closure offset branch and account chk');
          IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH IS NULL OR
             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO IS NULL THEN
            DBG('bulk closure Offset details are Null');
            DBG('bulk closure Failed in Offset details validation');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS14', '');
            RETURN FALSE;
          END IF;
          P_OFFSET_DETAILS := P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO || '~' ||
                              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH || '~' ||
                              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_CCY ||
                              '~~~';
          DBG('bulk closure Offset details building structure....' ||
              P_OFFSET_DETAILS);
        ELSE
        
          DBG('check for mand fields of instruments');
          IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH IS NOT NULL OR
             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO IS NOT NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-CLS21',
                         'Offset Details~');
            RETURN FALSE;
          END IF;
          IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_EXPIRY_DATE <=
             GLOBAL.APPLICATION_DATE THEN
            DBG('Expiry Date cannot be less than or equal to current date');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CLS17', '');
            RETURN FALSE;
          END IF;
          P_INSTR_DETAILS := P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_PRINTED_STATIONARY || '~' ||
                             NVL(P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_PAYABLE_BRANCH,
                                 P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE) || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_NO || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_STATUS || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_EXPIRY_DATE || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_BENEF_NAME || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ULT_BENEF1 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ULT_BENEF2 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ULT_BENEF3 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ULT_BENEF4 || '~' || '' || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_ISSUE_BANK || '~' ||
                            
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS1 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE1 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS2 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE2 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS3 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE3 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS4 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE4 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS5 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE5 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS6 || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_OTHER_DETAILS_TYPE6 || '~'
                            
                             || '~' ||
                             P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.INSTR_NO || '~' || '~';
        
          DBG('Mck details are....' || P_INSTR_DETAILS);
        END IF;
      END IF;
    
    ELSE
      DBG('Before reset skip kernel');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DBG('fn_validate_closure_det returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_closure_det with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_CLOSURE_DET;

  FUNCTION FN_CLOSE_CUSTACC_BRN(P_FUNCTION_ID    IN VARCHAR2,
                                P_CLOSE_REQD     CHAR,
                                P_STCACLOS       IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                                P_OFFSET_DETAILS VARCHAR2,
                                P_INSTR_DETAILS  VARCHAR2) RETURN BOOLEAN IS
    L_FLAG NUMBER := -1;
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAM   VARCHAR2(255);
    AL_RET        VARCHAR2(12);
    L_AMT_DRAWN   NUMBER;
    L_IGNORE      VARCHAR2(12);
    L_LCY_BAL     NUMBER;
    L_SOURCE_CODE VARCHAR2(12);
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Inside fn_close_custacc_brn');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_PRE_CLOSE_CUSTACC_BRN(P_FUNCTION_ID,
                                                                P_CLOSE_REQD,
                                                                P_STCACLOS,
                                                                P_OFFSET_DETAILS,
                                                                P_INSTR_DETAILS,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
        DBG('stpks_stdcusac_utils_cluster.FN_PRE_CLOSE_CUSTACC_BRN..' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      DBG('Brn: ' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE);
      DBG('Ac no: ' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO);
      DBG('p_close_reqd: ' || P_CLOSE_REQD);
      IF P_CLOSE_REQD = 'Y' THEN
        DBG('B4 call to pr_close_out_withdrawal...' ||
            P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.XREF || '~' ||
            P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE);
        DBG('Application date: ' || GLOBAL.APPLICATION_DATE);
        CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('Y');
      
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          L_SOURCE_CODE := 'FCRH';
        END IF;
        IF G_AC_CLOSURE THEN
        
          L_SOURCE_CODE := NULL;
        END IF;
        DBG('l_source_code :' || L_SOURCE_CODE);
      
        BEGIN
          SELECT SEQ_NO
            INTO ICPKS_PARTITION_INFO.G_THIS_PART
            FROM CSTB_CUSTACSEQ
           WHERE BRANCH_CODE =
                 P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE
             AND CUST_AC_NO = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO;
          DBG('Intraday: icpks_partition_info.g_This_Part: ' ||
              ICPKS_PARTITION_INFO.G_THIS_PART);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Intraday: icpks_partition_info.g_This_Part will not be set.' ||
                SQLERRM);
        END;
        IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH',
                                      P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE) THEN
        
          DBG('Intraday: Calling icpks_deferred_entries.pr_post_entries  ' ||
              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE || ' Acc: ' ||
              P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO || ' Seq No: ' ||
              ICPKS_PARTITION_INFO.G_THIS_PART);
          IF NOT TDPKS_UTILS.FN_POST_INTRADAY_ACCR(P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE,
                                                   P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO,
                                                   L_ERR_CODE,
                                                   L_ERR_PARAM) THEN
            DBG('Failed in posting the intraday accrual entries');
            RETURN FALSE;
          END IF;
        END IF;
      
        CSPKS_ACC_SERVICE.PR_CLOSE_OUT_WITHDRAWAL(L_SOURCE_CODE,
                                                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.XREF,
                                                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.LINKED_PRODUCT,
                                                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE,
                                                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO,
                                                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE,
                                                  NVL(GLOBAL.APPLICATION_DATE,
                                                      P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD44),
                                                  P_OFFSET_DETAILS,
                                                  P_INSTR_DETAILS,
                                                  L_FLAG,
                                                  L_ERR_CODE,
                                                  L_ERR_PARAM,
                                                  NULL,
                                                  L_AMT_DRAWN);
        DBG('After pr_close_out_withdrawal with flag...' || L_FLAG);
        DBG('After pr_close_out_withdrawal with ...l_err_code' ||
            L_ERR_CODE);
        DBG('After pr_close_out_withdrawal with ...l_err_param' ||
            L_ERR_PARAM);
        IF L_FLAG = -1 THEN
          DBG('Failed in close out withdrawl with....' || L_ERR_CODE);
          IF L_ERR_CODE IS NOT NULL THEN
          
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         L_ERR_CODE,
                         L_ERR_PARAM);
          END IF;
          DBG('Closure of Account Failed.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS24', '');
          CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('N');
          RETURN FALSE;
        END IF;
      
        IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH',
                                      P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE) THEN
          DBG('Clearing the accrual tables for the ent_dt >= application date');
          DELETE FROM ICTBS_ENTRIES_HISTORY_ACCR
           WHERE BRN = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE
             AND ACC = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO
             AND ENT_DT >= GLOBAL.APPLICATION_DATE;
          DBG('Records deleted from ictbs_entries_history_accr - ' ||
              SQL%ROWCOUNT);
          DELETE FROM ICTBS_ENTRIES_HIST_ZEROACCR
           WHERE BRN = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE
             AND ACC = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO
             AND ENT_DT >= GLOBAL.APPLICATION_DATE;
          DBG('Records deleted from ictbs_entries_hist_zeroaccr - ' ||
              SQL%ROWCOUNT);
        END IF;
      
      END IF;
    
      IF P_CLOSE_REQD = 'N' THEN
      
        DBG('This means IC online liq is reqd');
        ICPKS_ONLIQ_NEW.PR_CALL_ICONLIQ(P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE,
                                        'S',
                                        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO,
                                        'ALL'
                                        
                                       ,
                                        GLOBAL.APPLICATION_DATE - 1);
      
        SELECT LCY_CURR_BALANCE
          INTO L_LCY_BAL
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO
           AND BRANCH_CODE = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE;
        IF L_LCY_BAL <> 0 THEN
          IF NOT ACPKS_REVAL.FN_DOREVAL(GLOBAL.CURRENT_BRANCH,
                                        GLOBAL.APPLICATION_DATE,
                                        '',
                                        GLOBAL.LCY,
                                        'N',
                                        'S',
                                        'ACC',
                                        P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO,
                                        GLOBAL.USER_ID,
                                        L_ERR_CODE,
                                        L_ERR_PARAM) THEN
            DBG('Closure of Account Failed.');
            IF L_ERR_CODE IS NOT NULL THEN
            
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           L_ERR_CODE,
                           L_ERR_PARAM);
            END IF;
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS24', '');
            CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('N');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    
      GLOBAL.PR_INIT(GLOBAL.CURRENT_BRANCH, NVL(G_CR_USER, 'SYSTEM'));
    
      CSPKS_ACC_SERVICE.PR_SET_CLOSURE_FLAG('N');
      DBG('Closure successful....');
      DBG('fn_close_custacc_brn returning true');
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_POST_CLOSE_CUSTACC_BRN(P_FUNCTION_ID,
                                                                 P_CLOSE_REQD,
                                                                 P_STCACLOS,
                                                                 P_OFFSET_DETAILS,
                                                                 P_INSTR_DETAILS,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
        DBG('stpks_stdcusac_utils_cluster.FN_POST_CLOSE_CUSTACC_BRN..' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_close_custacc_brn with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_CLOSE_CUSTACC_BRN;

  FUNCTION FN_CLOSE_INSTRUCTION(P_FUNCTION_ID IN VARCHAR2,
                                P_STCACLOS    IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS)
    RETURN BOOLEAN IS
    L_TRN_REF_NO DETB_RTL_TELLER.TRN_REF_NO%TYPE;
    L_PRODUCT    CSTM_PRODUCT.PRODUCT_CODE%TYPE;
  BEGIN
    DBG('Inside fn_close_instruction');
    L_TRN_REF_NO                                      := DEPKS_RTL_TELLER.PKG_RTL_TELLER_REC.TRN_REF_NO;
    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.RELATED_REF_NO := L_TRN_REF_NO;
    BEGIN
      INSERT INTO STTBS_CUST_AC_CLOSURE
      VALUES P_STCACLOS.V_STTBS_CUST_AC_CLOSURE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to insert into STTBS_CUST_AC_CLOSURE with: ' ||
            SQLERRM);
        RETURN FALSE;
    END;
  
    DBG('fn_close_instruction returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_close_instruction with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_CLOSE_INSTRUCTION;

  FUNCTION FN_CLOSE_CUSTACC(P_FUNCTION_ID IN VARCHAR2,
                            P_STCACLOS    IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                            P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE)
    RETURN BOOLEAN IS
    MSG_COUNT        NUMBER(3);
    L_CNT            NUMBER;
    L_MOD_NO         NUMBER;
    L_COUNT          NUMBER;
    L_AUTH_STAT      STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_DR_INT_DUE     NUMBER;
    L_CHG_DUE        NUMBER;
    L_BRN            VARCHAR2(3);
    L_AC_NO          STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_CLOSE_REQD     CHAR;
    L_STAT           CHAR;
    L_AUTH_STATUS    CHAR(1);
    L_DATE_STAMP     STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                            'DD-MON-YYYY') ||
                                                                   TO_CHAR(FN_SYSDATE,
                                                                            'HH24:MI:SS')),
                                                                   'DD-MON-YYYY HH24:MI:SS');
    L_TRN_REF_NO     DETB_RTL_TELLER.TRN_REF_NO%TYPE;
    L_PRODUCT        CSTM_PRODUCT.PRODUCT_CODE%TYPE;
    L_OFFSET_DETAILS VARCHAR2(2000);
    L_INSTR_DETAILS  VARCHAR2(2000);
  
    L_KEY_ID VARCHAR2(1000);
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
    L_ERR_PARAMS VARCHAR2(10);
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DBG('Inside fn_close_custacc');
    L_BRN                                          := P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    L_AC_NO                                        := P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE := P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO       := P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    DBG('Checking if a/c closure for this a/c is allowed ');
    IF NOT FN_ALLOW_CLOSE(P_FUNCTION_ID, L_AC_NO, L_BRN) THEN
      DBG('Closure is not allowed for this account');
      RETURN FALSE;
    END IF;
    DBG('Getting closure details');
    IF NOT FN_GET_ACC_CLOSURE_DET(P_FUNCTION_ID,
                                  P_STCACLOS,
                                  P_SOURCE,
                                  L_CLOSE_REQD) THEN
      DBG('fn_get_acc_closure_det has returned false');
      RETURN FALSE;
    END IF;
  
    DBG('l_close_reqd: ' || L_CLOSE_REQD);
  
    IF P_FUNCTION_ID = 'STDCUSAC' THEN
      L_KEY_ID := '~' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE || '~' ||
                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO || '~' ||
                  P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_SEQ_NO || '~';
      DBG('key_id for service charge in utils 2-->' || L_KEY_ID);
      DEPKSS_RTL_TELLER.G_CLOSURE_CHARGE := 'Y';
      DBG('Calling fn_service_charge_pickup inside utils 2!!!!');
      IF NOT STPKS_STCACLOS_KERNEL.FN_SERVICE_CHARGE_PICKUP(P_SOURCE,
                                                            CSPKS_REQ_WRAPPER.G_SOURCE_OPERATION,
                                                            'STDCUSAC',
                                                            'CLOSE',
                                                            'A',
                                                            L_KEY_ID,
                                                            P_STCACLOS,
                                                            L_ERR_CODE,
                                                            L_ERR_PARAMS) THEN
        DBG('fn_service_charge_pickup has returned false inside main calls');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF L_CLOSE_REQD = 'Y' THEN
      IF NOT FN_VALIDATE_CLOSURE_DET(P_FUNCTION_ID,
                                     L_CLOSE_REQD,
                                     P_STCACLOS,
                                     P_SOURCE,
                                     L_INSTR_DETAILS,
                                     L_OFFSET_DETAILS) THEN
        DBG('Failed in fn_validate_closure_det');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT FN_CLOSE_CUSTACC_BRN(P_FUNCTION_ID,
                                L_CLOSE_REQD,
                                P_STCACLOS,
                                L_OFFSET_DETAILS,
                                L_INSTR_DETAILS) THEN
      DBG('fn_close_custacc_brn has returned false');
      RETURN FALSE;
    END IF;
  
    IF NOT FN_CLOSE_INSTRUCTION(P_FUNCTION_ID, P_STCACLOS) THEN
      DBG('Closure is not allowed for this account');
      RETURN FALSE;
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKSS_STDCUSAC_UTILS_CLUSTER.FN_CLOSE_CUSTACC(P_FUNCTION_ID,
                                                         P_STCACLOS,
                                                         P_SOURCE,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DBG('error in  stpkss_stdcusac_utils_custom.Fn_Close_Custacc');
        RETURN FALSE;
      END IF;
    END IF;
  
    UPDATE STTB_ACCOUNT
       SET AC_GL_REC_STATUS = 'C'
     WHERE AC_GL_NO = L_AC_NO
       AND BRANCH_CODE = L_BRN;
    DBG('STTB ACCOUNT UPDATED:' || SQLERRM);
  
    DBG('fn_close_custacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_close_custacc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_CLOSE_CUSTACC;

  FUNCTION FN_POST_CLOSE_ACC(P_FUNCTION_ID IN VARCHAR2,
                             P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                             P_ACC         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE)
    RETURN BOOLEAN IS
  
    L_ERR_CODE ERTB_MSGS.ERR_CODE%TYPE;
  
  BEGIN
    DBG('Inside fn_post_close_acc');
    DBG('Calling cepkss.Fn_Post_Update_account');
    DBG('p_brn:' || P_BRN);
    DBG('p_acc:' || P_ACC);
    DBG('Calling cepkss.Fn_Post_Update_account');
    IF NOT CEPKSS.FN_POST_UPDATE_ACCOUNT(P_ACC, P_BRN, 'CLOSE', L_ERR_CODE) THEN
      DBG('fn_post_update_account failed ...');
      RETURN FALSE;
    END IF;
  
    DBG('before updating sttm_cust_account.account_auto_closed');
    IF CASAPKSS_BATCH.PKG_AUTO_CLOSE THEN
      UPDATE STTM_CUST_ACCOUNT
         SET ACCOUNT_AUTO_CLOSED = 'Y'
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    END IF;
    DBG('after updating sttm_cust_account.account_auto_closed');
  
    DBG('fn_post_close_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_post_close_acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POST_CLOSE_ACC;

  FUNCTION FN_CLOSE_ACC(P_FUNCTION_ID IN VARCHAR2,
                        P_STCACLOS    IN OUT STPKS_STCACLOS_MAIN.TY_STCACLOS,
                        P_SOURCE      IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                        P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
    L_CUSTACC_REC STTMS_CUST_ACCOUNT%ROWTYPE;
    L_DEFER_FLAG  VARCHAR2(1);
    L_ERR_TBL     OVPKS.TBL_ERROR;
    L_CHGACC_CNT  NUMBER := 0;
    CURSOR CU_CARD_ACCOUNT(P_CUSTOMER IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_BRANCH   IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE) IS
      SELECT *
        FROM STTMS_CARD_ACCOUNT
       WHERE CUST_AC_NO = P_CUSTOMER
         AND BRANCH_CODE = P_BRANCH;
    TYPE TY_CARD_ACCOUNT IS TABLE OF STTM_CARD_ACCOUNT%ROWTYPE;
    L_TY_CARD_ACCOUNT TY_CARD_ACCOUNT;
  
    CURSOR CU_CARD_DETAILS(P_CUSTOMER IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_BRANCH   IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE) IS
      SELECT *
        FROM SWTMS_CARD_DETAILS
       WHERE FCC_ACC_NO = P_CUSTOMER
         AND FCC_ACC_BRN = P_BRANCH;
    TYPE TY_CARD_DETAILS IS TABLE OF SWTM_CARD_DETAILS%ROWTYPE;
    L_TY_CARD_DETAILS TY_CARD_DETAILS;
  
    L_COUNT NUMBER;
  BEGIN
    DBG('Inside fn_close_acc');
    DBG('Source: ' || P_SOURCE);
    DBG('Brn: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Ccy: ' || P_STCACLOS.V_STTMS_CUST_ACCOUNT.CCY);
    DBG('Offs brn: ' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_BRANCH);
    DBG('Offs acc: ' || P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO);
    DBG('Taking the account cache');
  
    IF P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSING_BALANCE = 0 AND
       P_STCACLOS.V_CSTBS_UI_COLUMNS.CHAR_FIELD43 = 0 THEN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM ICTB_CHG_VAL
       WHERE ACC = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO
         AND BRN = P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE
         AND ITM_DT <= GLOBAL.APPLICATION_DATE;
    
      IF L_COUNT > 0 THEN
        DBG('Please run online liquidation before closing the account,Since charge liquidation is pending for the account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS04', '');
      END IF;
    END IF;
  
    IF P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO =
       P_STCACLOS.V_STTBS_CUST_AC_CLOSURE.OFFSET_AC_NO THEN
      DBG('Customer account number and offset account are the same');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'DE-JRN55', '');
      RETURN FALSE;
    END IF;
  
    BEGIN
      SELECT *
        INTO L_CUSTACC_REC
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data found for the account: ' ||
            P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        RETURN FALSE;
      WHEN OTHERS THEN
        DBG('In WOT of caching with: ' || SQLERRM);
        RETURN FALSE;
    END;
  
    BEGIN
      SELECT COUNT(*)
        INTO L_CHGACC_CNT
        FROM STTMS_COMB_STMT_MAINT
       WHERE CHARGE_ACC = P_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND CHARGE_ACC_BRN = P_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      DBG('l_chgacc_cnt ' || L_CHGACC_CNT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get COUNT OF Charge accounts');
        L_CHGACC_CNT := 0;
    END;
    IF L_CHGACC_CNT > 0 THEN
      DBG('RECORD CANT BE CLOSED as mapped account used as charge account for combined statement');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-303', '');
      RETURN FALSE;
    END IF;
  
    DBG('Done taking the cache');
    DBG('Cached brn: ' || L_CUSTACC_REC.BRANCH_CODE);
    DBG('Cached acc: ' || L_CUSTACC_REC.CUST_AC_NO);
    DBG('Opening cursor cu_card_account');
    OPEN CU_CARD_ACCOUNT(L_CUSTACC_REC.CUST_AC_NO,
                         L_CUSTACC_REC.BRANCH_CODE);
    FETCH CU_CARD_ACCOUNT BULK COLLECT
      INTO L_TY_CARD_ACCOUNT;
    CLOSE CU_CARD_ACCOUNT;
    DBG('Card account count: ' || L_TY_CARD_ACCOUNT.COUNT);
    IF L_TY_CARD_ACCOUNT.COUNT > 0 THEN
      IF L_TY_CARD_ACCOUNT(1).RECORD_STAT != 'C' THEN
        DBG('Please close all the card accounts before closing customer account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-CLO-DB', '');
        RETURN FALSE;
      END IF;
    
      IF L_TY_CARD_ACCOUNT(1).AUTH_STAT != 'A' THEN
        DBG('Please authorise all the unauthorised card account details before closing customer account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-CLO-DB1', '');
        RETURN FALSE;
      END IF;
    
    END IF;
  
    DBG('Opening cursor Cu_Card_Details');
    OPEN CU_CARD_DETAILS(L_CUSTACC_REC.CUST_AC_NO,
                         L_CUSTACC_REC.BRANCH_CODE);
    FETCH CU_CARD_DETAILS BULK COLLECT
      INTO L_TY_CARD_DETAILS;
    CLOSE CU_CARD_DETAILS;
    DBG('Card account count: ' || L_TY_CARD_DETAILS.COUNT);
    IF L_TY_CARD_DETAILS.COUNT > 0 THEN
      FOR I IN L_TY_CARD_DETAILS.FIRST .. L_TY_CARD_DETAILS.LAST LOOP
        IF L_TY_CARD_DETAILS(I).RECORD_STAT != 'C' THEN
          DBG('Please close all the card accounts before closing customer account');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-CLO-DB', '');
          RETURN FALSE;
        END IF;
      END LOOP;
    END IF;
  
    SELECT COUNT(1)
      INTO L_COUNT
      FROM STTMS_DEBIT_CARD_MASTER
     WHERE CUST_AC_NO = L_CUSTACC_REC.CUST_AC_NO
       AND BRANCH_CODE = L_CUSTACC_REC.BRANCH_CODE
       AND (RECORD_STAT = 'O' OR AUTH_STAT = 'U');
    DBG('l_count is ::' || L_COUNT);
    IF L_COUNT = 1 THEN
      DBG('Active or unauthorised cards exist for the account');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-CLO-DB2', '');
    END IF;
  
    DBG('Verifying the Account nos');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VERIFY_N_GET_REF_NOS(P_FUNCTION_ID,
                                                       P_ACTION_CODE,
                                                       L_CUSTACC_REC.CUST_AC_NO,
                                                       L_CUSTACC_REC.ALT_AC_NO,
                                                       L_CUSTACC_REC.BRANCH_CODE) THEN
    
      DBG('stpks_stdcusac_utils_0.fn_verify_n_get_ref_nos has returned false');
      RETURN FALSE;
    END IF;
    IF P_SOURCE <> 'FLEXCUBE' THEN
      DBG('Source is: ' || P_SOURCE);
    
    ELSE
      DBG('Source is FLEXCUBE');
      L_DEFER_FLAG := 'N';
    END IF;
    DBG('l_defer_flag: ' || L_DEFER_FLAG);
    IF L_DEFER_FLAG = 'Y' THEN
      DBG('Source: ' || P_SOURCE || ' - Processing');
    
    ELSE
      DBG('FLEXCUBE Processing');
      DBG('Calling fn_close_custacc');
      IF NOT FN_CLOSE_CUSTACC(P_FUNCTION_ID, P_STCACLOS, P_SOURCE) THEN
        DBG('fn_close_custacc has returned false');
        RETURN FALSE;
      END IF;
    END IF;
  
    DBG('Check if any unused cheque leaves exist for the account.. ');
    BEGIN
    
      SELECT COUNT(*)
        INTO L_COUNT
        FROM CATM_CHECK_DETAILS A
       WHERE A.BRANCH = L_CUSTACC_REC.BRANCH_CODE
         AND A.ACCOUNT = L_CUSTACC_REC.CUST_AC_NO
         AND A.RECORD_STAT = 'O'
         AND A.STATUS IN ('N', 'R')
         AND MOD_NO = (SELECT MAX(MOD_NO)
                         FROM CATM_CHECK_DETAILS B
                        WHERE B.BRANCH = A.BRANCH
                          AND B.ACCOUNT = A.ACCOUNT
                          AND A.CHECK_NO = B.CHECK_NO)
         AND NOT EXISTS (SELECT NULL
                FROM CATM_CHECK_BOOK C
               WHERE C.BRANCH = A.BRANCH
                 AND C.ACCOUNT = A.ACCOUNT
                 AND C.FIRST_CHECK_NO = A.CHECK_BOOK_NO
                 AND C.REQUEST_STATUS = 'Destroyed');
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in picking records from Catm_Check_Details and error is ' ||
            SQLERRM);
        RETURN FALSE;
    END;
    DBG('Unused cheque count is ->' || L_COUNT);
    IF L_COUNT > 0 THEN
      DBG('Unused check leaves exists for this Customer Account');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACC-025', NULL);
    END IF;
  
    IF L_CUSTACC_REC.AC_STAT_FROZEN = 'Y' THEN
      DBG('Account is in frozen state.');
      OVPKSS.PR_APPENDTBL('AC-VAC04', L_CUSTACC_REC.CUST_AC_NO);
    END IF;
  
    DBG('fn_close_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_close_acc with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_CLOSE_ACC;

  FUNCTION FN_POPULATE_ACC_TYPE(P_FUNCTION_ID   IN VARCHAR2,
                                P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    N NUMBER;
  BEGIN
    DBG('Inside fn_populate_acc_type');
    DBG('Brn: ' || P_STDCUSAC.V_ICTMS_ACC.BRN);
    DBG('Cust acc: ' || P_STDCUSAC.V_ICTMS_ACC.ACC);
    DBG('Curr calc acc: ' || P_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
    DBG('Prev calc acc: ' || P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
    DBG('Prev acctype: ' || P_PREV_STDCUSAC.V_ICTMS_ACC.ACC_TYPE);
  
    P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE := NVL(P_PREV_STDCUSAC.V_ICTMS_ACC.ACC_TYPE,
                                           'N');
  
    IF P_STDCUSAC.V_ICTMS_ACC.ACC <> P_STDCUSAC.V_ICTMS_ACC.CALC_ACC THEN
      DBG('Cust acc is unequal to Curr calc acc');
      P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE := 'C';
      DBG('Updating ictm_acc for the curr calc acc record');
      UPDATE ICTM_ACC
         SET ACC_TYPE = 'M'
       WHERE BRN = P_STDCUSAC.V_ICTMS_ACC.BRN
         AND ACC = P_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
      DBG('#1 Executing icpkss_calc.pr_recalc_cons_bal');
      ICPKSS_CALC.PR_RECALC_CONS_BAL(P_STDCUSAC.V_ICTMS_ACC.BRN,
                                     P_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
    ELSIF P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC IS NOT NULL THEN
      IF P_STDCUSAC.V_ICTMS_ACC.ACC <> P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC THEN
        DBG('Cust acc is unequal to Prev calc acc');
        P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE := 'N';
        DELETE FROM ICTBS_CONSOL_VD_BAL B
         WHERE B.BRN = P_STDCUSAC.V_ICTMS_ACC.BRN
           AND B.ACC = P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
        DBG('Reset bD BAL for old Master');
        DELETE FROM ICTBS_CONSOL_BD_BAL B
         WHERE B.BRN = P_STDCUSAC.V_ICTMS_ACC.BRN
           AND B.ACC = P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
        SELECT COUNT(*)
          INTO N
          FROM ICTMS_ACC A
         WHERE A.BRN = P_STDCUSAC.V_ICTMS_ACC.BRN
           AND A.CALC_ACC = P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC
           AND A.ACC <> P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
        IF N > 0 THEN
        
          DBG('Still master. Slaves = ' || TO_CHAR(N));
          ICPKSS_CALC.PR_RECALC_CONS_BAL(P_STDCUSAC.V_ICTMS_ACC.BRN,
                                         P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
        ELSE
        
          DBG(P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC || ' chgd to normal');
          UPDATE ICTMS_ACC A
             SET A.ACC_TYPE = 'N'
           WHERE A.BRN = P_STDCUSAC.V_ICTMS_ACC.BRN
             AND A.ACC = P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC;
        END IF;
      END IF;
    ELSE
      DBG('Beats all other conditions');
      P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE := 'N';
    END IF;
    DBG('p_stdcusac.v_ictms_acc.acc_type: ' ||
        P_STDCUSAC.V_ICTMS_ACC.ACC_TYPE);
    DBG('fn_populate_acc_type returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_acc_type with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POPULATE_ACC_TYPE;

  FUNCTION FN_BLOCK(P_FUNCTION_ID IN VARCHAR2,
                    P_CUST_NO     IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_block with customer: ' || P_CUST_NO);
    DBG('Updating the frozen stat in customer table');
    BEGIN
      UPDATE STTMS_CUSTOMER SET FROZEN = 'Y' WHERE CUSTOMER_NO = P_CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT... Failed to block the customer');
        NULL;
    END;
    DBG('fn_block returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_block with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BLOCK;

  FUNCTION FN_POPULATE_REINIT_ACC(P_FUNCTION_ID   IN VARCHAR2,
                                  P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                  P_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                  ERR_CODE        IN OUT VARCHAR2,
                                  ERR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_STAT      VARCHAR2(1) := 'U';
    L_ERR_CODE  ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM ERTB_MSGS.MESSAGE%TYPE;
  
  BEGIN
    DBG('Inside fn_populate_reinit_type : ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
  
    UPDATE STTB_ACC_LIMITS_REINIT
       SET REINIT_DATE = TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                          'DD-MON-YYYY') ||
                                 TO_CHAR(FN_SYSDATE, 'HH24:MI:SS')),
                                 'DD-MON-YYYY HH24:MI:SS'),
           STATUS      = L_STAT
     WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
       AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
  
    IF SQL%NOTFOUND THEN
      INSERT INTO STTB_ACC_LIMITS_REINIT
        (BRANCH_CODE,
         CUST_AC_NO,
         REINIT_DATE,
         STATUS,
         ERROR_CODE,
         ERROR_PARAMS)
      VALUES
        (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
         TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE, 'DD-MON-YYYY') ||
                 TO_CHAR(FN_SYSDATE, 'HH24:MI:SS')),
                 'DD-MON-YYYY HH24:MI:SS'),
         L_STAT,
         L_ERR_CODE,
         L_ERR_PARAM);
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_block with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    
  END FN_POPULATE_REINIT_ACC;

  FUNCTION FN_SET_REINIT_ACC(P_FUNCTION_ID IN VARCHAR2,
                             P_STATUS      IN VARCHAR2,
                             P_AC_NO       IN VARCHAR2,
                             P_BRANCH      IN VARCHAR2,
                             P_ERROR       IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
    E_UPDATE_EXCEPTION EXCEPTION;
  
  BEGIN
    DBG('Inside fn_set_reinit_acc for updating status');
    SAVEPOINT RE_INIT;
  
    DBG('Updating the sttb_acc_limits_reinit');
    DBG('Cust ac no' || P_AC_NO);
    DBG('branch code' || P_BRANCH);
  
    BEGIN
      UPDATE STTB_ACC_LIMITS_REINIT
         SET STATUS       = P_STATUS,
             ERROR_CODE   = P_ERROR,
             ERROR_PARAMS = P_ERR_PARAMS
       WHERE CUST_AC_NO = P_AC_NO
         AND BRANCH_CODE = P_BRANCH;
    
    EXCEPTION
      WHEN OTHERS THEN
        RAISE E_UPDATE_EXCEPTION;
    END;
  
    COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In WHEN OTHERS OF fn_set_reinit_acc..' || SQLERRM);
      DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      ROLLBACK TO RE_INIT;
      RETURN FALSE;
    
  END FN_SET_REINIT_ACC;

  FUNCTION FN_ASSIGN(P_FUNCTION_ID IN VARCHAR2,
                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CUST_ACC_REC  STTM_CUST_ACCOUNT%ROWTYPE;
    L_ICTMS_ACC_REC ICTMS_ACC%ROWTYPE;
  
    CURSOR C_PROV IS
      SELECT *
        FROM STTMS_ACCOUNT_PROV_PERCENT
       WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
  
  BEGIN
    DBG('Inside fn_assign');
    BEGIN
      SELECT *
        INTO L_CUST_ACC_REC
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('NO data here.. ' || SQLERRM);
    END;
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                'N',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
  
    BEGIN
      SELECT *
        INTO L_ICTMS_ACC_REC
        FROM ICTMS_ACC
       WHERE ACC = P_STDCUSAC.V_ICTMS_ACC.ACC
         AND BRN = P_STDCUSAC.V_ICTMS_ACC.BRN;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('NO data here.. ' || SQLERRM);
    END;
  
    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                'N',
                                                G_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
  
    DBG('p_Stdcusac.v_Sttms_Cust_Account. Checkbook_Name_1' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT. CHECKBOOK_NAME_1);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           ACCOUNT_TYPE,
                                                           L_CUST_ACC_REC.
                                                           ACCOUNT_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           ACC_STMT_DAY2,
                                                           L_CUST_ACC_REC.
                                                           ACC_STMT_DAY2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           ACC_STMT_DAY3,
                                                           L_CUST_ACC_REC.
                                                           ACC_STMT_DAY3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           ACC_STMT_TYPE2,
                                                           L_CUST_ACC_REC.
                                                           ACC_STMT_TYPE2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           ACC_STMT_TYPE3,
                                                           L_CUST_ACC_REC.
                                                           ACC_STMT_TYPE3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           AC_DESC,
                                                           L_CUST_ACC_REC.
                                                           AC_DESC);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           AC_OPEN_DATE,
                                                           L_CUST_ACC_REC.
                                                           AC_OPEN_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DE_POST := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                           AC_STAT_DE_POST,
                                                           L_CUST_ACC_REC.
                                                           AC_STAT_DE_POST);
  
    P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT := NVL(G_BALREC.AC_STAT_DORMANT,
                                                              L_CUST_ACC_REC.AC_STAT_DORMANT);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_FROZEN          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STAT_FROZEN,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STAT_FROZEN);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STAT_NO_CR,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STAT_NO_CR);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STAT_NO_DR,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STAT_NO_DR);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_STOP_PAY        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STAT_STOP_PAY,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STAT_STOP_PAY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STMT_CYCLE,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STMT_CYCLE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STMT_CYCLE2,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STMT_CYCLE2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STMT_CYCLE3,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STMT_CYCLE3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STMT_DAY,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STMT_DAY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AC_STMT_TYPE,
                                                                   L_CUST_ACC_REC.
                                                                   AC_STMT_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ADDRESS1,
                                                                   L_CUST_ACC_REC.
                                                                   ADDRESS1);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ADDRESS2,
                                                                   L_CUST_ACC_REC.
                                                                   ADDRESS2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ADDRESS3,
                                                                   L_CUST_ACC_REC.
                                                                   ADDRESS3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ADDRESS4,
                                                                   L_CUST_ACC_REC.
                                                                   ADDRESS4);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALLOW_BACK_PERIOD_ENTRY := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ALLOW_BACK_PERIOD_ENTRY,
                                                                   L_CUST_ACC_REC.
                                                                   ALLOW_BACK_PERIOD_ENTRY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ALT_AC_NO,
                                                                   L_CUST_ACC_REC.
                                                                   ALT_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ATM_CUST_AC_NO,
                                                                   L_CUST_ACC_REC.
                                                                   ATM_CUST_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_AMT_LIMIT       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ATM_DLY_AMT_LIMIT,
                                                                   L_CUST_ACC_REC.
                                                                   ATM_DLY_AMT_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_COUNT_LIMIT     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ATM_DLY_COUNT_LIMIT,
                                                                   L_CUST_ACC_REC.
                                                                   ATM_DLY_COUNT_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   ATM_FACILITY,
                                                                   L_CUST_ACC_REC.
                                                                   ATM_FACILITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AUTO_DEPOSITS_BAL,
                                                                   L_CUST_ACC_REC.
                                                                   AUTO_DEPOSITS_BAL);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                   AUTO_PROV_REQD,
                                                                   L_CUST_ACC_REC.
                                                                   AUTO_PROV_REQD);
  
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD = 'Y' AND
       L_CUST_ACC_REC.
     AUTO_PROV_REQD = 'Y' AND P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT = 0 THEN
      OPEN C_PROV;
      LOOP
        FETCH C_PROV BULK COLLECT
          INTO P_STDCUSAC.V_ACCOUNT_PROV_PERCENT;
        EXIT WHEN C_PROV%NOTFOUND;
      END LOOP;
      CLOSE C_PROV;
    END IF;
  
    DBG('p_Stdcusac.v_account_prov_percent.count is...' ||
        P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        AUTO_REORDER_CHECK_LEAVES,
                                                                        L_CUST_ACC_REC.
                                                                        AUTO_REORDER_CHECK_LEAVES);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        AUTO_REORDER_CHECK_LEVEL,
                                                                        L_CUST_ACC_REC.
                                                                        AUTO_REORDER_CHECK_LEVEL);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        AUTO_REORDER_CHECK_REQUIRED,
                                                                        L_CUST_ACC_REC.
                                                                        AUTO_REORDER_CHECK_REQUIRED);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_SINCE         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        BALANCE_REPORT_SINCE,
                                                                        L_CUST_ACC_REC.
                                                                        BALANCE_REPORT_SINCE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_TYPE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        BALANCE_REPORT_TYPE,
                                                                        L_CUST_ACC_REC.
                                                                        BALANCE_REPORT_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CHECKBOOK_NAME_1,
                                                                        L_CUST_ACC_REC.
                                                                        CHECKBOOK_NAME_1);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CHECKBOOK_NAME_2,
                                                                        L_CUST_ACC_REC.
                                                                        CHECKBOOK_NAME_2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CHEQUE_BOOK_FACILITY,
                                                                        L_CUST_ACC_REC.
                                                                        CHEQUE_BOOK_FACILITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CLEARING_AC_NO,
                                                                        L_CUST_ACC_REC.
                                                                        CLEARING_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_BANK_CODE           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CLEARING_BANK_CODE,
                                                                        L_CUST_ACC_REC.
                                                                        CLEARING_BANK_CODE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOLIDATION_REQD           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CONSOLIDATION_REQD,
                                                                        L_CUST_ACC_REC.
                                                                        CONSOLIDATION_REQD);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE                 := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        COUNTRY_CODE,
                                                                        L_CUST_ACC_REC.
                                                                        COUNTRY_CODE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CREDIT_TXN_LIMIT             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CREDIT_TXN_LIMIT,
                                                                        L_CUST_ACC_REC.
                                                                        CREDIT_TXN_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_REV_DATE               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CR_LM_REV_DATE,
                                                                        L_CUST_ACC_REC.
                                                                        CR_LM_REV_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_START_DATE             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        CR_LM_START_DATE,
                                                                        L_CUST_ACC_REC.
                                                                        CR_LM_START_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        DAYLIGHT_LIMIT_AMOUNT,
                                                                        L_CUST_ACC_REC.
                                                                        DAYLIGHT_LIMIT_AMOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON                  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        DEFER_RECON,
                                                                        L_CUST_ACC_REC.
                                                                        DEFER_RECON);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES      := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        DISPLAY_IBAN_IN_ADVICES,
                                                                        L_CUST_ACC_REC.
                                                                        DISPLAY_IBAN_IN_ADVICES);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANT_PARAM                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        DORMANT_PARAM,
                                                                        L_CUST_ACC_REC.
                                                                        DORMANT_PARAM);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_AC_NO                 := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        ESCROW_AC_NO,
                                                                        L_CUST_ACC_REC.
                                                                        ESCROW_AC_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_BRANCH_CODE           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        ESCROW_BRANCH_CODE,
                                                                        L_CUST_ACC_REC.
                                                                        ESCROW_BRANCH_CODE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_PERCENTAGE            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        ESCROW_PERCENTAGE,
                                                                        L_CUST_ACC_REC.
                                                                        ESCROW_PERCENTAGE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_TRANSFER              := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        ESCROW_TRANSFER,
                                                                        L_CUST_ACC_REC.
                                                                        ESCROW_TRANSFER);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXCL_SAMEDAY_RVRTRNS_FM_STMT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        EXCL_SAMEDAY_RVRTRNS_FM_STMT,
                                                                        L_CUST_ACC_REC.
                                                                        EXCL_SAMEDAY_RVRTRNS_FM_STMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        EXPOSURE_CATEGORY,
                                                                        L_CUST_ACC_REC.
                                                                        EXPOSURE_CATEGORY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING                      := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        FUNDING,
                                                                        L_CUST_ACC_REC.
                                                                        FUNDING);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT              := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        FUNDING_ACCOUNT,
                                                                        L_CUST_ACC_REC.
                                                                        FUNDING_ACCOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        FUNDING_BRANCH,
                                                                        L_CUST_ACC_REC.
                                                                        FUNDING_BRANCH);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_BALANCE_REPORT           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_BALANCE_REPORT,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_BALANCE_REPORT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_INTERIM_STMT,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_INTERIM_STMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT_ON_MVMT     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_INTERIM_STMT_ON_MVMT,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_INTERIM_STMT_ON_MVMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_STMT_ONLY_ON_MVMT,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_STMT_ONLY_ON_MVMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_STMT_ONLY_ON_MVMT2,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_STMT_ONLY_ON_MVMT2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                        GEN_STMT_ONLY_ON_MVMT3,
                                                                        L_CUST_ACC_REC.
                                                                        GEN_STMT_ONLY_ON_MVMT3);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INF_ACC_OPENING_AMT,
                                                                       L_CUST_ACC_REC.
                                                                       INF_ACC_OPENING_AMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INF_OFFSET_ACCOUNT,
                                                                       L_CUST_ACC_REC.
                                                                       INF_OFFSET_ACCOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INF_OFFSET_BRANCH,
                                                                       L_CUST_ACC_REC.
                                                                       INF_OFFSET_BRANCH);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INF_PAY_IN_OPTION,
                                                                       L_CUST_ACC_REC.
                                                                       INF_PAY_IN_OPTION);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INF_WAIVE_ACC_OPEN_CHARGE,
                                                                       L_CUST_ACC_REC.
                                                                       INF_WAIVE_ACC_OPEN_CHARGE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INHERIT_REPORTING           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INHERIT_REPORTING,
                                                                       L_CUST_ACC_REC.
                                                                       INHERIT_REPORTING);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_CREDIT_AMT          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INTERIM_CREDIT_AMT,
                                                                       L_CUST_ACC_REC.
                                                                       INTERIM_CREDIT_AMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_DEBIT_AMT           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INTERIM_DEBIT_AMT,
                                                                       L_CUST_ACC_REC.
                                                                       INTERIM_DEBIT_AMT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_SINCE        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INTERIM_REPORT_SINCE,
                                                                       L_CUST_ACC_REC.
                                                                       INTERIM_REPORT_SINCE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_TYPE         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       INTERIM_REPORT_TYPE,
                                                                       L_CUST_ACC_REC.
                                                                       INTERIM_REPORT_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       JOINT_AC_INDICATOR,
                                                                       L_CUST_ACC_REC.
                                                                       JOINT_AC_INDICATOR);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY                   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       LIMIT_CCY,
                                                                       L_CUST_ACC_REC.
                                                                       LIMIT_CCY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LINE_ID                     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       LINE_ID,
                                                                       L_CUST_ACC_REC.
                                                                       LINE_ID);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION                    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       LOCATION,
                                                                       L_CUST_ACC_REC.
                                                                       LOCATION);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LODGEMENT_BOOK_FACILITY     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       LODGEMENT_BOOK_FACILITY,
                                                                       L_CUST_ACC_REC.
                                                                       LODGEMENT_BOOK_FACILITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MASTER_ACCOUNT_NO           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       MASTER_ACCOUNT_NO,
                                                                       L_CUST_ACC_REC.
                                                                       MASTER_ACCOUNT_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA                       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       MEDIA,
                                                                       L_CUST_ACC_REC.
                                                                       MEDIA);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MIN_REQD_BAL                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       MIN_REQD_BAL,
                                                                       L_CUST_ACC_REC.
                                                                       MIN_REQD_BAL);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD9_VALIDATION_REQD        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       MOD9_VALIDATION_REQD,
                                                                       L_CUST_ACC_REC.
                                                                       MOD9_VALIDATION_REQD);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       NETTING_REQUIRED,
                                                                       L_CUST_ACC_REC.
                                                                       NETTING_REQUIRED);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE1                    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       NOMINEE1,
                                                                       L_CUST_ACC_REC.
                                                                       NOMINEE1);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE2                    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       NOMINEE2,
                                                                       L_CUST_ACC_REC.
                                                                       NOMINEE2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.OFFLINE_LIMIT               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       OFFLINE_LIMIT,
                                                                       L_CUST_ACC_REC.
                                                                       OFFLINE_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PASSBOOK_FACILITY,
                                                                       L_CUST_ACC_REC.
                                                                       PASSBOOK_FACILITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DIRECT_BANKING              := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       DIRECT_BANKING,
                                                                       L_CUST_ACC_REC.
                                                                       DIRECT_BANKING);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       POSITIVE_PAY_AC,
                                                                       L_CUST_ACC_REC.
                                                                       POSITIVE_PAY_AC);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_BALANCE,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_BALANCE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE2 := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_BALANCE2,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_BALANCE2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE3 := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_BALANCE3,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_BALANCE3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_DATE,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_DATE2,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_DATE2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_DATE3,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_DATE3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_NO,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_NO);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO2      := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_NO2,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_NO2);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO3      := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PREVIOUS_STATEMENT_NO3,
                                                                       L_CUST_ACC_REC.
                                                                       PREVIOUS_STATEMENT_NO3);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PRODUCT_LIST                := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PRODUCT_LIST,
                                                                       L_CUST_ACC_REC.
                                                                       PRODUCT_LIST);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROV_CCY_TYPE               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       PROV_CCY_TYPE,
                                                                       L_CUST_ACC_REC.
                                                                       PROV_CCY_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REFERRAL_REQUIRED           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REFERRAL_REQUIRED,
                                                                       L_CUST_ACC_REC.
                                                                       REFERRAL_REQUIRED);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_END_DATE               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REGD_END_DATE,
                                                                       L_CUST_ACC_REC.
                                                                       REGD_END_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REGD_PERIODICITY,
                                                                       L_CUST_ACC_REC.
                                                                       REGD_PERIODICITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_START_DATE             := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REGD_START_DATE,
                                                                       L_CUST_ACC_REC.
                                                                       REGD_START_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_CC_AVAILABILITY         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REG_CC_AVAILABILITY,
                                                                       L_CUST_ACC_REC.
                                                                       REG_CC_AVAILABILITY);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REG_D_APPLICABLE,
                                                                       L_CUST_ACC_REC.
                                                                       REG_D_APPLICABLE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       REPL_CUST_SIG,
                                                                       L_CUST_ACC_REC.
                                                                       REPL_CUST_SIG);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RISK_FREE_EXP_AMOUNT        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       RISK_FREE_EXP_AMOUNT,
                                                                       L_CUST_ACC_REC.
                                                                       RISK_FREE_EXP_AMOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SALARY_ACCOUNT              := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SALARY_ACCOUNT,
                                                                       L_CUST_ACC_REC.
                                                                       SALARY_ACCOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SOD_NOTIFICATION_PERCENT    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SOD_NOTIFICATION_PERCENT,
                                                                       L_CUST_ACC_REC.
                                                                       SOD_NOTIFICATION_PERCENT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_PRODUCT   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SPECIAL_CONDITION_PRODUCT,
                                                                       L_CUST_ACC_REC.
                                                                       SPECIAL_CONDITION_PRODUCT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_TXNCODE   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SPECIAL_CONDITION_TXNCODE,
                                                                       L_CUST_ACC_REC.
                                                                       SPECIAL_CONDITION_TXNCODE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS                  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       STALE_DAYS,
                                                                       L_CUST_ACC_REC.
                                                                       STALE_DAYS);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       STATEMENT_ACCOUNT,
                                                                       L_CUST_ACC_REC.
                                                                       STATEMENT_ACCOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_CHANGE_AUTOMATIC     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       STATUS_CHANGE_AUTOMATIC,
                                                                       L_CUST_ACC_REC.
                                                                       STATUS_CHANGE_AUTOMATIC);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT                    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SUBLIMIT,
                                                                       L_CUST_ACC_REC.
                                                                       SUBLIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_TYPE                  := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       SWEEP_TYPE,
                                                                       L_CUST_ACC_REC.
                                                                       SWEEP_TYPE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT                   := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TOD_LIMIT,
                                                                       L_CUST_ACC_REC.
                                                                       TOD_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TOD_LIMIT_END_DATE,
                                                                       L_CUST_ACC_REC.
                                                                       TOD_LIMIT_END_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TOD_LIMIT_START_DATE,
                                                                       L_CUST_ACC_REC.
                                                                       TOD_LIMIT_START_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TRACK_RECEIVABLE,
                                                                       L_CUST_ACC_REC.
                                                                       TRACK_RECEIVABLE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TXN_CODE_LIST               := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TXN_CODE_LIST,
                                                                       L_CUST_ACC_REC.
                                                                       TXN_CODE_LIST);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ                 := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       TYPE_OF_CHQ,
                                                                       L_CUST_ACC_REC.
                                                                       TYPE_OF_CHQ);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       UNCOLL_FUNDS_LIMIT,
                                                                       L_CUST_ACC_REC.
                                                                       UNCOLL_FUNDS_LIMIT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.VALIDATION_DIGIT            := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.
                                                                       VALIDATION_DIGIT,
                                                                       L_CUST_ACC_REC.
                                                                       VALIDATION_DIGIT);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE,
                                                               L_CUST_ACC_REC.DR_HO_LINE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE,
                                                               L_CUST_ACC_REC.CR_HO_LINE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE,
                                                               L_CUST_ACC_REC.CR_CB_LINE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE,
                                                               L_CUST_ACC_REC.DR_CB_LINE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAS_ACCOUNT         := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAS_ACCOUNT,
                                                               L_CUST_ACC_REC.CAS_ACCOUNT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE,
                                                               L_CUST_ACC_REC.DORMANCY_DATE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DAYS       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DAYS,
                                                               L_CUST_ACC_REC.DORMANCY_DAYS);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT210_REQD          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT210_REQD,
                                                               L_CUST_ACC_REC.MT210_REQD);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS          := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS,
                                                               L_CUST_ACC_REC.ACC_STATUS);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE        := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE,
                                                               L_CUST_ACC_REC.STATUS_SINCE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_AUTO_CLOSED := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_AUTO_CLOSED,
                                                               L_CUST_ACC_REC.ACCOUNT_AUTO_CLOSED);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_BRN      := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_BRN,
                                                               L_CUST_ACC_REC.CONSOL_CHG_BRN);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT     := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT,
                                                               L_CUST_ACC_REC.ACC_TANKED_STAT);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH           := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH,
                                                               L_CUST_ACC_REC.ONCE_AUTH);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACY_CURR_BALANCE := NVL(P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_CURR_ACC_BAL,
                                                            G_BALREC.ACY_CURR_ACC_BAL);
  
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID       := GLOBAL.USER_ID;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP := FN_MNTSTAMP;
  
    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := NVL(P_STDCUSAC.V_ICTMS_ACC.
                                                 INT_START_DATE,
                                                 L_ICTMS_ACC_REC.
                                                 INT_START_DATE);
    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE  := NVL(P_STDCUSAC.V_ICTMS_ACC.
                                                 MATURITY_DATE,
                                                 L_ICTMS_ACC_REC.
                                                 MATURITY_DATE);
    P_STDCUSAC.V_ICTMS_TD_DETAILS.CCY     := NVL(P_STDCUSAC.V_ICTMS_TD_DETAILS. CCY,
                                                 L_CUST_ACC_REC. CCY);
    DBG('fn_assign returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_assign with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_ASSIGN;

  FUNCTION FN_MAINT_CUSTAC_LOG(P_SOURCE        IN VARCHAR2,
                               P_ACTION_CODE   IN VARCHAR2,
                               P_POST_UPL_STAT IN VARCHAR2,
                               P_STDCUSAC      IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_WRK_STDCUSAC  IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ERR_CODE      IN OUT VARCHAR2,
                               P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_CALLING_FUNCTION VARCHAR2(50) := 'STDCUSAC';
    L_MODULE           SMTB_MODULES.MODULE_ID%TYPE := 'ST';
    L_AUTH_STAT        VARCHAR2(32767) := NULL;
    L_FUNCTION_ID      SMTB_MENU.FUNCTION_ID%TYPE := 'STDCUSAC';
    L_KEY_ID           VARCHAR2(32767);
    L_MOD_NO           NUMBER := 1;
    L_BLK              VARCHAR2(32767) := NULL;
    L_FLD              VARCHAR2(32767) := NULL;
    L_DBT              VARCHAR2(32767) := NULL;
    L_DBC              VARCHAR2(32767) := NULL;
    L_REC_ACTION       VARCHAR2(32767) := 'M';
    L_DTL_KEY          VARCHAR2(32767) := NULL;
    L_PREV_COUNT       NUMBER := 0;
    L_WRK_COUNT        NUMBER := 0;
    L_COUNT            NUMBER := 0;
    L_LOG_COUNT        NUMBER := 0;
    L_FLD_COUNT        NUMBER := 0;
    L_MATCHED_REC      NUMBER := 0;
    L_REC_FOUND        BOOLEAN := FALSE;
    L_PREV_FOUND       BOOLEAN := FALSE;
    L_WRK_FOUND        BOOLEAN := FALSE;
    L_REC_MODIFIED     BOOLEAN := FALSE;
    L_RECORD_LOG       STTBS_RECORD_LOG%ROWTYPE;
    L_FIELD_LOG        STTBS_FIELD_LOG%ROWTYPE;
    L_TB_FIELD_LOG     CSPKS_REQ_GLOBAL.TY_TB_FLD_LOG;
  
    L_CSCCUSLN     CSPKS_CSCCUSLN_MAIN.TY_CSCCUSLN;
    L_DMY_CSCCUSLN CSPKS_CSCCUSLN_MAIN.TY_CSCCUSLN;
    L_ICCCSPCN     ICPKS_ICCCSPCN_MAIN.TY_ICCCSPCN;
    L_DMY_ICCCSPCN ICPKS_ICCCSPCN_MAIN.TY_ICCCSPCN;
    L_ICCHSPCN     ICPKS_ICCHSPCN_MAIN.TY_ICCHSPCN;
    L_DMY_ICCHSPCN ICPKS_ICCHSPCN_MAIN.TY_ICCHSPCN;
    L_ICCINSTR     ICPKS_ICCINSTR_MAIN.TY_ICCINSTR;
    L_DMY_ICCINSTR ICPKS_ICCINSTR_MAIN.TY_ICCINSTR;
    L_MICACCTM     MIPKS_MICACCTM_MAIN.TY_MICACCTM;
    L_DMY_MICACCTM MIPKS_MICACCTM_MAIN.TY_MICACCTM;
  
    L_SICDIARY         SIPKS_SICDIARY_MAIN.TY_SICDIARY;
    L_DMY_SICDIARY     SIPKS_SICDIARY_MAIN.TY_SICDIARY;
    L_STCACLOS         STPKS_STCACLOS_MAIN.TY_STCACLOS;
    L_DMY_STCACLOS     STPKS_STCACLOS_MAIN.TY_STCACLOS;
    L_STCCUSBL         STPKS_STCCUSBL_MAIN.TY_STCCUSBL;
    L_DMY_STCCUSBL     STPKS_STCCUSBL_MAIN.TY_STCCUSBL;
    L_SVCACSIG         SVPKS_SVCACSIG_MAIN.TY_SVCACSIG;
    L_DMY_SVCACSIG     SVPKS_SVCACSIG_MAIN.TY_SVCACSIG;
    L_SOURCE_OPERATION VARCHAR2(50) := NULL;
    L_MULTITRIP_ID     VARCHAR2(20) := NULL;
    L_REQUEST_NO       VARCHAR2(20) := NULL;
    L_TANKING_STATUS   VARCHAR2(10) := NULL;
    L_RECORD_MASTER    STTBS_RECORD_MASTER%ROWTYPE := NULL;
  
    PROCEDURE DBG(P_MSG VARCHAR2) IS
      L_MSG VARCHAR2(32767);
    BEGIN
      L_MSG := 'Fn_Maint_custac_Log ==>' || P_MSG;
      DEBUG.PR_DEBUG('ST', L_MSG);
    END DBG;
  
    PROCEDURE PR_LOG_CHANGE(P_DBC     IN VARCHAR2,
                            P_ACTION  IN VARCHAR2,
                            P_OLD_VAL IN VARCHAR2,
                            P_NEW_VAL IN VARCHAR2) IS
    BEGIN
      IF NVL(P_OLD_VAL, '@') <> NVL(P_NEW_VAL, '@') THEN
        L_LOG_COUNT := L_LOG_COUNT + 1;
        L_FLD_COUNT := L_FLD_COUNT + 1;
        L_FIELD_LOG.DETAIL_KEY := L_DTL_KEY;
        L_FIELD_LOG.BLOCK_NAME := L_BLK;
        L_FIELD_LOG.FIELD_NAME := P_DBC;
        L_FIELD_LOG.TABLE_NAME := L_DBT;
        L_FIELD_LOG.ITEM_NO := L_FLD_COUNT;
        L_FIELD_LOG.RECORD_STAT := P_ACTION;
        L_FIELD_LOG.OLD_VALUE := P_OLD_VAL;
        L_FIELD_LOG.NEW_VALUE := P_NEW_VAL;
        L_TB_FIELD_LOG(L_LOG_COUNT) := L_FIELD_LOG;
      END IF;
    END PR_LOG_CHANGE;
  
  BEGIN
  
    DBG('In Fn_Maint_Log');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN,
                         CSPKS_REQ_GLOBAL.P_AUTH,
                         CSPKS_REQ_GLOBAL.P_DELETE) THEN
      DBG('Doing Maintenance Log ..');
      L_KEY_ID := '~STTM_CUST_ACCOUNT~' ||
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
      IF L_KEY_ID IS NOT NULL THEN
        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO IS NOT NULL THEN
            L_MOD_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO;
          ELSE
            L_MOD_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO;
          END IF;
        ELSE
          L_MOD_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO;
        END IF;
        L_AUTH_STAT := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT,
                           'U');
      
        IF NOT CSPKS_REQ_UTILS.FN_MAINT_LOG(P_SOURCE,
                                            L_SOURCE_OPERATION,
                                            L_FUNCTION_ID,
                                            P_ACTION_CODE,
                                            L_MULTITRIP_ID,
                                            L_REQUEST_NO,
                                            'STTMS_CUST_ACCOUNT',
                                            L_KEY_ID,
                                            L_MOD_NO,
                                            P_POST_UPL_STAT,
                                            L_TANKING_STATUS,
                                            L_RECORD_MASTER,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
          DBG('Failed in Cspks_Req_Utils.Fn_Maint_Log..');
          RETURN FALSE;
        END IF;
        IF CSPKS_REQ_UTILS.FN_FIELD_LOG_REQD(P_ACTION_CODE, L_FUNCTION_ID) THEN
          L_FIELD_LOG.KEY_ID      := L_KEY_ID;
          L_FIELD_LOG.MOD_NO      := L_MOD_NO;
          L_FIELD_LOG.FUNCTION_ID := L_FUNCTION_ID;
        
          L_DBT := 'STTM_CUST_ACCOUNT';
        
          L_BLK          := 'STTMS_CUST_ACCOUNT';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL AND
             P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL AND
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~STTM_CUST_ACCOUNT~' ||
                         P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                         P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~STTM_CUST_ACCOUNT~' ||
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('BRANCH_CODE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            PR_LOG_CHANGE('CUST_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            PR_LOG_CHANGE('CUST_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
            PR_LOG_CHANGE('ACCOUNT_CLASS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
            PR_LOG_CHANGE('CCY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
            PR_LOG_CHANGE('ACCOUNT_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE);
            PR_LOG_CHANGE('AC_DESC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);
            PR_LOG_CHANGE('AC_STAT_NO_DR',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR);
            PR_LOG_CHANGE('AC_STAT_NO_CR',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR);
            PR_LOG_CHANGE('AC_STAT_STOP_PAY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_STOP_PAY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_STOP_PAY);
            PR_LOG_CHANGE('AC_STAT_DORMANT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT);
            PR_LOG_CHANGE('JOINT_AC_INDICATOR',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);
            PR_LOG_CHANGE('AC_OPEN_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
            PR_LOG_CHANGE('ALT_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO);
            PR_LOG_CHANGE('AC_STAT_FROZEN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_FROZEN,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_FROZEN);
            PR_LOG_CHANGE('NOMINEE1',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE1,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE1);
            PR_LOG_CHANGE('NOMINEE2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.NOMINEE2);
            PR_LOG_CHANGE('ADDRESS1',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1);
            PR_LOG_CHANGE('ADDRESS2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2);
            PR_LOG_CHANGE('ADDRESS3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3);
            PR_LOG_CHANGE('ADDRESS4',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4);
            PR_LOG_CHANGE('AC_STAT_DE_POST',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DE_POST,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DE_POST);
            PR_LOG_CHANGE('CLEARING_BANK_CODE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_BANK_CODE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_BANK_CODE);
            PR_LOG_CHANGE('CLEARING_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO);
            PR_LOG_CHANGE('IBAN_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
            PR_LOG_CHANGE('TRACK_RECEIVABLE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE);
            PR_LOG_CHANGE('REFERRAL_REQUIRED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REFERRAL_REQUIRED,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REFERRAL_REQUIRED);
            PR_LOG_CHANGE('ACC_STATUS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS);
            PR_LOG_CHANGE('STATUS_SINCE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE);
            PR_LOG_CHANGE('INHERIT_REPORTING',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INHERIT_REPORTING,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INHERIT_REPORTING);
            PR_LOG_CHANGE('STATUS_CHANGE_AUTOMATIC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_CHANGE_AUTOMATIC,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_CHANGE_AUTOMATIC);
            PR_LOG_CHANGE('DORMANT_PARAM',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANT_PARAM,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANT_PARAM);
            PR_LOG_CHANGE('ACCOUNT_DERIVED_STATUS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_DERIVED_STATUS,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_DERIVED_STATUS);
            PR_LOG_CHANGE('LOCATION',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION);
            PR_LOG_CHANGE('MEDIA',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA);
            PR_LOG_CHANGE('CHEQUE_BOOK_FACILITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY);
            PR_LOG_CHANGE('PASSBOOK_FACILITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY);
          
            PR_LOG_CHANGE('DIRECT_BANKING',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DIRECT_BANKING,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DIRECT_BANKING);
          
            PR_LOG_CHANGE('CAS_ACCOUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAS_ACCOUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAS_ACCOUNT);
            PR_LOG_CHANGE('TYPE_OF_CHQ',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ);
            PR_LOG_CHANGE('ATM_CUST_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);
            PR_LOG_CHANGE('ATM_DLY_AMT_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_AMT_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_AMT_LIMIT);
            PR_LOG_CHANGE('ATM_DLY_COUNT_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_COUNT_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_COUNT_LIMIT);
            PR_LOG_CHANGE('MT210_REQD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT210_REQD,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT210_REQD);
            PR_LOG_CHANGE('POSITIVE_PAY_AC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC);
            PR_LOG_CHANGE('STALE_DAYS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS);
            PR_LOG_CHANGE('CHECKBOOK_NAME_1',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1);
            PR_LOG_CHANGE('CHECKBOOK_NAME_2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2);
            PR_LOG_CHANGE('AUTO_REORDER_CHECK_REQUIRED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED);
            PR_LOG_CHANGE('AUTO_REORDER_CHECK_LEVEL',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL);
            PR_LOG_CHANGE('AUTO_REORDER_CHECK_LEAVES',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES);
            PR_LOG_CHANGE('LODGEMENT_BOOK_FACILITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.LODGEMENT_BOOK_FACILITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LODGEMENT_BOOK_FACILITY);
            PR_LOG_CHANGE('ALLOW_BACK_PERIOD_ENTRY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALLOW_BACK_PERIOD_ENTRY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALLOW_BACK_PERIOD_ENTRY);
            PR_LOG_CHANGE('AUTO_PROV_REQD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD);
            PR_LOG_CHANGE('EXPOSURE_CATEGORY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY);
            PR_LOG_CHANGE('RISK_FREE_EXP_AMOUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.RISK_FREE_EXP_AMOUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RISK_FREE_EXP_AMOUNT);
            PR_LOG_CHANGE('PROV_CCY_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROV_CCY_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROV_CCY_TYPE);
            PR_LOG_CHANGE('DEFER_RECON',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON);
            PR_LOG_CHANGE('CONSOLIDATION_REQD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOLIDATION_REQD,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOLIDATION_REQD);
            PR_LOG_CHANGE('FUNDING',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING);
            PR_LOG_CHANGE('FUNDING_BRANCH',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH);
            PR_LOG_CHANGE('FUNDING_ACCOUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT);
            PR_LOG_CHANGE('MOD9_VALIDATION_REQD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD9_VALIDATION_REQD,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD9_VALIDATION_REQD);
            PR_LOG_CHANGE('VALIDATION_DIGIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.VALIDATION_DIGIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.VALIDATION_DIGIT);
            PR_LOG_CHANGE('SUBLIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT);
            PR_LOG_CHANGE('UNCOLL_FUNDS_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT);
            PR_LOG_CHANGE('TOD_LIMIT_START_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE);
            PR_LOG_CHANGE('TOD_LIMIT_END_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE);
            PR_LOG_CHANGE('TOD_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT);
            PR_LOG_CHANGE('LIMIT_CCY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY);
            PR_LOG_CHANGE('LINE_ID',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.LINE_ID,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LINE_ID);
            PR_LOG_CHANGE('OFFLINE_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.OFFLINE_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.OFFLINE_LIMIT);
            PR_LOG_CHANGE('NETTING_REQUIRED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED);
            PR_LOG_CHANGE('CREDIT_TXN_LIMIT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CREDIT_TXN_LIMIT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CREDIT_TXN_LIMIT);
            PR_LOG_CHANGE('CR_LM_START_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_START_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_START_DATE);
            PR_LOG_CHANGE('CR_LM_REV_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_REV_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_LM_REV_DATE);
            PR_LOG_CHANGE('AC_STMT_DAY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY);
            PR_LOG_CHANGE('AC_STMT_CYCLE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE);
            PR_LOG_CHANGE('ATM_FACILITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY);
            PR_LOG_CHANGE('AC_STMT_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE);
            PR_LOG_CHANGE('GEN_STMT_ONLY_ON_MVMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT);
            PR_LOG_CHANGE('DISPLAY_IBAN_IN_ADVICES',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES);
            PR_LOG_CHANGE('ACC_STMT_TYPE2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2);
            PR_LOG_CHANGE('ACC_STMT_DAY2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2);
            PR_LOG_CHANGE('AC_STMT_CYCLE2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2);
            PR_LOG_CHANGE('GEN_STMT_ONLY_ON_MVMT2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2);
            PR_LOG_CHANGE('ACC_STMT_TYPE3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3);
            PR_LOG_CHANGE('ACC_STMT_DAY3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3);
            PR_LOG_CHANGE('AC_STMT_CYCLE3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3);
            PR_LOG_CHANGE('GEN_STMT_ONLY_ON_MVMT3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3);
            PR_LOG_CHANGE('EXCL_SAMEDAY_RVRTRNS_FM_STMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXCL_SAMEDAY_RVRTRNS_FM_STMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXCL_SAMEDAY_RVRTRNS_FM_STMT);
            PR_LOG_CHANGE('STATEMENT_ACCOUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_BALANCE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_DATE2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_BALANCE2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE2);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_NO2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO2,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO2);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_DATE3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_BALANCE3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE3);
            PR_LOG_CHANGE('PREVIOUS_STATEMENT_NO3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO3,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO3);
            PR_LOG_CHANGE('SWEEP_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_TYPE);
            PR_LOG_CHANGE('MASTER_ACCOUNT_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MASTER_ACCOUNT_NO,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MASTER_ACCOUNT_NO);
            PR_LOG_CHANGE('AUTO_DEPOSITS_BAL',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DEPOSITS_BAL);
            PR_LOG_CHANGE('MIN_REQD_BAL',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MIN_REQD_BAL,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MIN_REQD_BAL);
            PR_LOG_CHANGE('REG_CC_AVAILABILITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_CC_AVAILABILITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_CC_AVAILABILITY);
            PR_LOG_CHANGE('REG_D_APPLICABLE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE);
            PR_LOG_CHANGE('REGD_PERIODICITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY);
            PR_LOG_CHANGE('REGD_START_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_START_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_START_DATE);
            PR_LOG_CHANGE('REGD_END_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_END_DATE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_END_DATE);
            PR_LOG_CHANGE('PRODUCT_LIST',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PRODUCT_LIST,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PRODUCT_LIST);
            PR_LOG_CHANGE('TXN_CODE_LIST',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TXN_CODE_LIST,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TXN_CODE_LIST);
            PR_LOG_CHANGE('SPECIAL_CONDITION_PRODUCT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_PRODUCT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_PRODUCT);
            PR_LOG_CHANGE('SPECIAL_CONDITION_TXNCODE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_TXNCODE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_TXNCODE);
            PR_LOG_CHANGE('MODE_OF_OPERATION',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION);
            PR_LOG_CHANGE('DR_HO_LINE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE);
            PR_LOG_CHANGE('CR_HO_LINE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE);
            PR_LOG_CHANGE('CR_CB_LINE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE);
            PR_LOG_CHANGE('DR_CB_LINE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE);
            PR_LOG_CHANGE('DR_GL',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL);
            PR_LOG_CHANGE('CR_GL',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL);
            PR_LOG_CHANGE('AC_STAT_BLOCK',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_BLOCK,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_BLOCK);
            PR_LOG_CHANGE('ACC_TANKED_STAT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT);
            PR_LOG_CHANGE('BALANCE_REPORT_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_TYPE);
            PR_LOG_CHANGE('INTERIM_DEBIT_AMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_DEBIT_AMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_DEBIT_AMT);
            PR_LOG_CHANGE('INTERIM_CREDIT_AMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_CREDIT_AMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_CREDIT_AMT);
            PR_LOG_CHANGE('INTERIM_STMT_DAY_COUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_STMT_DAY_COUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_STMT_DAY_COUNT);
            PR_LOG_CHANGE('INTERIM_STMT_YTD_COUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_STMT_YTD_COUNT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_STMT_YTD_COUNT);
            PR_LOG_CHANGE('GEN_INTERIM_STMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT);
            PR_LOG_CHANGE('GEN_INTERIM_STMT_ON_MVMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT_ON_MVMT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT_ON_MVMT);
            PR_LOG_CHANGE('GEN_BALANCE_REPORT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_BALANCE_REPORT,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_BALANCE_REPORT);
            PR_LOG_CHANGE('INTERIM_REPORT_SINCE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_SINCE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_SINCE);
            PR_LOG_CHANGE('INTERIM_REPORT_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_TYPE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_REPORT_TYPE);
            PR_LOG_CHANGE('BALANCE_REPORT_SINCE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_SINCE,
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BALANCE_REPORT_SINCE);
          END IF;
        
          DBG('Calling Cspks_CSCCUSLN_Main.Fn_Maint_Log..');
          IF NOT CSPKS_CSCCUSLN_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'CSCCUSLN',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_CSCCUSLN,
                                                  P_WRK_STDCUSAC.TY_CSCCUSLN,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Cspks_CSCCUSLN_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Icpks_ICCCSPCN_Main.Fn_Maint_Log..');
          IF NOT ICPKS_ICCCSPCN_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'ICCCSPCN',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_ICCCSPCN,
                                                  P_WRK_STDCUSAC.TY_ICCCSPCN,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Icpks_ICCCSPCN_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Icpks_ICCHSPCN_Main.Fn_Maint_Log..');
          IF NOT ICPKS_ICCHSPCN_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'ICCHSPCN',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_ICCHSPCN,
                                                  P_WRK_STDCUSAC.TY_ICCHSPCN,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Icpks_ICCHSPCN_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Icpks_ICCINSTR_Main.Fn_Maint_Log..');
          IF NOT ICPKS_ICCINSTR_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'ICCINSTR',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_ICCINSTR,
                                                  P_WRK_STDCUSAC.TY_ICCINSTR,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Icpks_ICCINSTR_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Mipks_MICACCTM_Main.Fn_Maint_Log..');
          IF NOT MIPKS_MICACCTM_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'MICACCTM',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_MICACCTM,
                                                  P_WRK_STDCUSAC.TY_MICACCTM,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Mipks_MICACCTM_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Sipks_SICDIARY_Main.Fn_Maint_Log..');
          IF NOT SIPKS_SICDIARY_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'SICDIARY',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_SICDIARY,
                                                  P_WRK_STDCUSAC.TY_SICDIARY,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Sipks_SICDIARY_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Stpks_STCCUSBL_Main.Fn_Maint_Log..');
          IF NOT STPKS_STCCUSBL_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'STCCUSBL',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_STCCUSBL,
                                                  P_WRK_STDCUSAC.TY_STCCUSBL,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Stpks_STCCUSBL_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Stpks_STCACLOS_Main.Fn_Maint_Log..');
          IF NOT STPKS_STCACLOS_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'STCACLOS',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_STCACLOS,
                                                  P_WRK_STDCUSAC.TY_STCACLOS,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Stpks_STCACLOS_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
          DBG('Calling Svpks_SVCACSIG_Main.Fn_Maint_Log..');
          IF NOT SVPKS_SVCACSIG_MAIN.FN_MAINT_LOG(P_SOURCE,
                                                  L_SOURCE_OPERATION,
                                                  'SVCACSIG',
                                                  P_ACTION_CODE,
                                                  L_CALLING_FUNCTION,
                                                  L_KEY_ID,
                                                  L_MOD_NO,
                                                  P_PREV_STDCUSAC.TY_SVCACSIG,
                                                  P_WRK_STDCUSAC.TY_SVCACSIG,
                                                  L_TB_FIELD_LOG,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
            DBG('Failed in Svpks_SVCACSIG_Main.Fn_Build_Fc_Type..');
            RETURN FALSE;
          END IF;
        
          L_DBT        := 'STTM_ACCOUNT_PROV_PERCENT';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_ACCOUNT_PROV_PERCENT~' || P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                               .STATUS || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                          .STATUS,
                          '@') = NVL(P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                      .STATUS,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('STATUS',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                  .STATUS,
                                  P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT (L_INDEX)
                                  .STATUS);
                    PR_LOG_CHANGE('PROV_PERCENT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                  .PROV_PERCENT,
                                  P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT (L_INDEX)
                                  .PROV_PERCENT);
                    PR_LOG_CHANGE('DISCOUNT_PERCENT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                  .DISCOUNT_PERCENT,
                                  P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT (L_INDEX)
                                  .DISCOUNT_PERCENT);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT (L_INDEX)
                                  .BRANCH_CODE);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('STATUS',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .STATUS);
                PR_LOG_CHANGE('PROV_PERCENT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .PROV_PERCENT);
                PR_LOG_CHANGE('DISCOUNT_PERCENT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .DISCOUNT_PERCENT);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .BRANCH_CODE);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                          .STATUS,
                          '@') = NVL(P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX1)
                                      .STATUS,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_ACCOUNT_PROV_PERCENT~' || P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                            .STATUS || '~';
                PR_LOG_CHANGE('STATUS',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .STATUS,
                              NULL);
                PR_LOG_CHANGE('PROV_PERCENT',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .PROV_PERCENT,
                              NULL);
                PR_LOG_CHANGE('DISCOUNT_PERCENT',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .DISCOUNT_PERCENT,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_PROV_PERCENT(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_BIC_CODE';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_BIC_CODE.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_BIC_CODE.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_BIC_CODE~' || P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                               .AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                               .BIC_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                               .GL_CUST || '~' || P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                               .BRANCH_CODE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX).BIC_CODE,
                          '@') = NVL(P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1)
                                      .BIC_CODE,
                                      '@')) AND
                     (NVL(P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX).GL_CUST,
                          '@') =
                     NVL(P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1).GL_CUST,
                          '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1)
                                  .AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_BIC_CODE (L_INDEX)
                                  .AC_NO);
                    PR_LOG_CHANGE('BIC_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1)
                                  .BIC_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_BIC_CODE (L_INDEX)
                                  .BIC_CODE);
                    PR_LOG_CHANGE('DESCRIPTION',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1)
                                  .DESCRIPTION,
                                  P_WRK_STDCUSAC.V_STTMS_BIC_CODE (L_INDEX)
                                  .DESCRIPTION);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_BIC_CODE (L_INDEX)
                                  .BRANCH_CODE);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX).AC_NO);
                PR_LOG_CHANGE('BIC_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .BIC_CODE);
                PR_LOG_CHANGE('DESCRIPTION',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .DESCRIPTION);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .BRANCH_CODE);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_BIC_CODE.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_BIC_CODE.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX).BIC_CODE,
                          '@') =
                     NVL(P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1).BIC_CODE,
                          '@')) AND
                     (NVL(P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX).GL_CUST,
                          '@') =
                     NVL(P_WRK_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX1).GL_CUST,
                          '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_BIC_CODE~' || P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                            .AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                            .BIC_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                            .GL_CUST || '~' || P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                            .BRANCH_CODE || '~';
                PR_LOG_CHANGE('AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .AC_NO,
                              NULL);
                PR_LOG_CHANGE('BIC_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .BIC_CODE,
                              NULL);
                PR_LOG_CHANGE('DESCRIPTION',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .DESCRIPTION,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_BIC_CODE(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_ACCSTAT_REPLINES_DETAIL';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_ACCSTAT_REPLINES_DETAIL~' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                               .STATUS || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                          .STATUS,
                          '@') = NVL(P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                      .STATUS,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('STATUS',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .STATUS,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .STATUS);
                    PR_LOG_CHANGE('DR_HO_LINE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .DR_HO_LINE,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .DR_HO_LINE);
                    PR_LOG_CHANGE('CR_HO_LINE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .CR_HO_LINE,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .CR_HO_LINE);
                    PR_LOG_CHANGE('CR_CB_LINE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .CR_CB_LINE,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .CR_CB_LINE);
                    PR_LOG_CHANGE('DR_CB_LINE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .DR_CB_LINE,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .DR_CB_LINE);
                    PR_LOG_CHANGE('DR_GL',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .DR_GL,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .DR_GL);
                    PR_LOG_CHANGE('CR_GL',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                  .CR_GL,
                                  P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL (L_INDEX)
                                  .CR_GL);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('STATUS',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .STATUS);
                PR_LOG_CHANGE('DR_HO_LINE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_HO_LINE);
                PR_LOG_CHANGE('CR_HO_LINE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_HO_LINE);
                PR_LOG_CHANGE('CR_CB_LINE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_CB_LINE);
                PR_LOG_CHANGE('DR_CB_LINE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_CB_LINE);
                PR_LOG_CHANGE('DR_GL',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_GL);
                PR_LOG_CHANGE('CR_GL',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_GL);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                          .STATUS,
                          '@') = NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX1)
                                      .STATUS,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_ACCSTAT_REPLINES_DETAIL~' || P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                            .STATUS || '~';
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('STATUS',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .STATUS,
                              NULL);
                PR_LOG_CHANGE('DR_HO_LINE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_HO_LINE,
                              NULL);
                PR_LOG_CHANGE('CR_HO_LINE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_HO_LINE,
                              NULL);
                PR_LOG_CHANGE('CR_CB_LINE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_CB_LINE,
                              NULL);
                PR_LOG_CHANGE('DR_CB_LINE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_CB_LINE,
                              NULL);
                PR_LOG_CHANGE('DR_GL',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .DR_GL,
                              NULL);
                PR_LOG_CHANGE('CR_GL',
                              'D',
                              P_PREV_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(L_INDEX)
                              .CR_GL,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_AC_LINKED_ENTITIES';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_AC_LINKED_ENTITIES~' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                               .JOINT_HOLDER_CODE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                          .JOINT_HOLDER_CODE,
                          '@') = NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                      .JOINT_HOLDER_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('JOINT_HOLDER_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                  .JOINT_HOLDER_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES (L_INDEX)
                                  .JOINT_HOLDER_CODE);
                    PR_LOG_CHANGE('JOINT_HOLDER_DESCRIPTION',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                  .JOINT_HOLDER_DESCRIPTION,
                                  P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES (L_INDEX)
                                  .JOINT_HOLDER_DESCRIPTION);
                    PR_LOG_CHANGE('JOINT_HOLDER',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                  .JOINT_HOLDER,
                                  P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES (L_INDEX)
                                  .JOINT_HOLDER);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('JOINT_HOLDER_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER_CODE);
                PR_LOG_CHANGE('JOINT_HOLDER_DESCRIPTION',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER_DESCRIPTION);
                PR_LOG_CHANGE('JOINT_HOLDER',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                          .JOINT_HOLDER_CODE,
                          '@') = NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX1)
                                      .JOINT_HOLDER_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_AC_LINKED_ENTITIES~' || P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                            .JOINT_HOLDER_CODE || '~';
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('JOINT_HOLDER_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER_CODE,
                              NULL);
                PR_LOG_CHANGE('JOINT_HOLDER_DESCRIPTION',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER_DESCRIPTION,
                              NULL);
                PR_LOG_CHANGE('JOINT_HOLDER',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(L_INDEX)
                              .JOINT_HOLDER,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT := 'STTM_ACCOUNT_MAINT_INSTR';
        
          L_BLK          := 'STTMS_ACCOUNT_MAINT_INSTR';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE IS NOT NULL AND
             P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE IS NOT NULL AND
             P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~STTM_ACCOUNT_MAINT_INSTR~' ||
                         P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE || '~' ||
                         P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~STTM_ACCOUNT_MAINT_INSTR~' ||
                         P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('BRANCH_CODE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE);
            PR_LOG_CHANGE('CUST_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO);
            PR_LOG_CHANGE('DATE_OF_LAST_MAINT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.DATE_OF_LAST_MAINT,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.DATE_OF_LAST_MAINT);
            PR_LOG_CHANGE('INSTR1_WHEN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR1_WHEN,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR1_WHEN);
            PR_LOG_CHANGE('INSTR2_WHEN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR2_WHEN,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR2_WHEN);
            PR_LOG_CHANGE('INSTR3_WHEN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR3_WHEN,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR3_WHEN);
            PR_LOG_CHANGE('INSTR4_WHEN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR4_WHEN,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR4_WHEN);
            PR_LOG_CHANGE('MAINT_INSTR_1',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_1,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_1);
            PR_LOG_CHANGE('MAINT_INSTR_2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_2,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_2);
            PR_LOG_CHANGE('MAINT_INSTR_3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_3,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_3);
            PR_LOG_CHANGE('MAINT_INSTR_4',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_4,
                          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_4);
          END IF;
        
          L_DBT        := 'STTM_CUSTAC_PRODUCTS';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_CUSTAC_PRODUCTS~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                               .PRODUCT_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                               .BRANCH_CODE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                          .PRODUCT_CODE,
                          '@') = NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                      .PRODUCT_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('DEBIT_TXN',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                  .DEBIT_TXN,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS (L_INDEX)
                                  .DEBIT_TXN);
                    PR_LOG_CHANGE('CREDIT_TXN',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                  .CREDIT_TXN,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS (L_INDEX)
                                  .CREDIT_TXN);
                    PR_LOG_CHANGE('PRODUCT_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                  .PRODUCT_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS (L_INDEX)
                                  .PRODUCT_CODE);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('DEBIT_TXN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .DEBIT_TXN);
                PR_LOG_CHANGE('CREDIT_TXN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .CREDIT_TXN);
                PR_LOG_CHANGE('PRODUCT_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .PRODUCT_CODE);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                          .PRODUCT_CODE,
                          '@') = NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX1)
                                      .PRODUCT_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_CUSTAC_PRODUCTS~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                            .PRODUCT_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                            .BRANCH_CODE || '~';
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('DEBIT_TXN',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .DEBIT_TXN,
                              NULL);
                PR_LOG_CHANGE('CREDIT_TXN',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .CREDIT_TXN,
                              NULL);
                PR_LOG_CHANGE('PRODUCT_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(L_INDEX)
                              .PRODUCT_CODE,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_CUSTAC_TXNCODE';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_CUSTAC_TXNCODE~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                               .TXN_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                               .BRANCH_CODE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                          .TXN_CODE,
                          '@') = NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                      .TXN_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('TXN_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                  .TXN_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE (L_INDEX)
                                  .TXN_CODE);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('DEBIT_TXN',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                  .DEBIT_TXN,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE (L_INDEX)
                                  .DEBIT_TXN);
                    PR_LOG_CHANGE('CREDIT_TXN',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                  .CREDIT_TXN,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE (L_INDEX)
                                  .CREDIT_TXN);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('TXN_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .TXN_CODE);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('DEBIT_TXN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .DEBIT_TXN);
                PR_LOG_CHANGE('CREDIT_TXN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .CREDIT_TXN);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                          .TXN_CODE,
                          '@') = NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX1)
                                      .TXN_CODE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_CUSTAC_TXNCODE~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                            .TXN_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                            .BRANCH_CODE || '~';
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('TXN_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .TXN_CODE,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('DEBIT_TXN',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .DEBIT_TXN,
                              NULL);
                PR_LOG_CHANGE('CREDIT_TXN',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(L_INDEX)
                              .CREDIT_TXN,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_CUSTAC_CRDR_LMTS';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_CUSTAC_CRDR_LMTS~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                               .CR_DR_CCY || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                          .CR_DR_CCY,
                          '@') = NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                      .CR_DR_CCY,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('CR_DR_CCY',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                  .CR_DR_CCY,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS (L_INDEX)
                                  .CR_DR_CCY);
                    PR_LOG_CHANGE('CR_LMT_AMT',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                  .CR_LMT_AMT,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS (L_INDEX)
                                  .CR_LMT_AMT);
                    PR_LOG_CHANGE('DR_LMT_AMT',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                  .DR_LMT_AMT,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS (L_INDEX)
                                  .DR_LMT_AMT);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS (L_INDEX)
                                  .BRANCH_CODE);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('CR_DR_CCY',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CR_DR_CCY);
                PR_LOG_CHANGE('CR_LMT_AMT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CR_LMT_AMT);
                PR_LOG_CHANGE('DR_LMT_AMT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .DR_LMT_AMT);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .BRANCH_CODE);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                          .CR_DR_CCY,
                          '@') = NVL(P_WRK_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX1)
                                      .CR_DR_CCY,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_CUSTAC_CRDR_LMTS~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                            .CR_DR_CCY || '~';
                PR_LOG_CHANGE('CR_DR_CCY',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CR_DR_CCY,
                              NULL);
                PR_LOG_CHANGE('CR_LMT_AMT',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CR_LMT_AMT,
                              NULL);
                PR_LOG_CHANGE('DR_LMT_AMT',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .DR_LMT_AMT,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'ICTM_ACC_PR';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_PR.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~ICTM_ACC_PR~' || P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).BRN || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).ACC || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD, '@') =
                     NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).PROD,
                          '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRN',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).BRN,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX).BRN);
                    PR_LOG_CHANGE('ACC',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).ACC,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX).ACC);
                    PR_LOG_CHANGE('WAIVE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1)
                                  .WAIVE,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX)
                                  .WAIVE);
                    PR_LOG_CHANGE('GEN_UCA',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1)
                                  .GEN_UCA,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX)
                                  .GEN_UCA);
                    PR_LOG_CHANGE('RECORD_STAT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1)
                                  .RECORD_STAT,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX)
                                  .RECORD_STAT);
                    PR_LOG_CHANGE('PROD',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).PROD,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_PR (L_INDEX).PROD);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).BRN);
                PR_LOG_CHANGE('ACC',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).ACC);
                PR_LOG_CHANGE('WAIVE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).WAIVE);
                PR_LOG_CHANGE('GEN_UCA',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).GEN_UCA);
                PR_LOG_CHANGE('RECORD_STAT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX)
                              .RECORD_STAT);
                PR_LOG_CHANGE('PROD',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_PR.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD, '@') =
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).PROD, '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~ICTM_ACC_PR~' || P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).BRN || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).ACC || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD || '~';
                PR_LOG_CHANGE('BRN',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).BRN,
                              NULL);
                PR_LOG_CHANGE('ACC',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).ACC,
                              NULL);
                PR_LOG_CHANGE('WAIVE',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).WAIVE,
                              NULL);
                PR_LOG_CHANGE('GEN_UCA',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX)
                              .GEN_UCA,
                              NULL);
                PR_LOG_CHANGE('RECORD_STAT',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX)
                              .RECORD_STAT,
                              NULL);
                PR_LOG_CHANGE('PROD',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT := 'ICTM_ACC';
        
          L_BLK          := 'ICTMS_ACC';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_ICTMS_ACC.BRN IS NOT NULL AND
             P_PREV_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_ICTMS_ACC.BRN IS NOT NULL AND
             P_WRK_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~ICTM_ACC~' || P_PREV_STDCUSAC.V_ICTMS_ACC.BRN || '~' ||
                         P_PREV_STDCUSAC.V_ICTMS_ACC.ACC || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~ICTM_ACC~' || P_WRK_STDCUSAC.V_ICTMS_ACC.BRN || '~' ||
                         P_WRK_STDCUSAC.V_ICTMS_ACC.ACC || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('CALC_ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.CALC_ACC,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
            PR_LOG_CHANGE('BOOK_ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
            PR_LOG_CHANGE('HAS_IS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.HAS_IS,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.HAS_IS);
            PR_LOG_CHANGE('INT_START_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
            PR_LOG_CHANGE('BOOK_BRN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_BRN);
            PR_LOG_CHANGE('HAS_DRCR_ADV',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV);
            PR_LOG_CHANGE('CHARGE_BOOK_BRN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN);
            PR_LOG_CHANGE('CHARGE_BOOK_ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC);
            PR_LOG_CHANGE('CHG_START_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE);
            PR_LOG_CHANGE('PRINC_LIQ_AC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC);
            PR_LOG_CHANGE('PRINC_LIQ_BRANCH',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH);
            PR_LOG_CHANGE('AUTO_ROLLOVER',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER);
            PR_LOG_CHANGE('CLOSE_ON_MATURITY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY);
            PR_LOG_CHANGE('MOVE_INT_TO_UNCLAIMED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED);
            PR_LOG_CHANGE('MATURITY_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            PR_LOG_CHANGE('ROLLOVER_TYPE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
            PR_LOG_CHANGE('ROLLOVER_AMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT);
            PR_LOG_CHANGE('NEXT_MATURITY_DATE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
            PR_LOG_CHANGE('RD_TAKEDOWN_DAYS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS);
            PR_LOG_CHANGE('RD_TAKEDOWN_MONTHS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS);
            PR_LOG_CHANGE('RD_TAKEDOWN_YEARS',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS);
            PR_LOG_CHANGE('RD_PAYMENT_ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC);
            PR_LOG_CHANGE('RD_PAYMENT_BRN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN);
            PR_LOG_CHANGE('RD_PAYMENT_CCY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY);
            PR_LOG_CHANGE('RD_INSTALLMENT_AMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT);
            PR_LOG_CHANGE('RD_PAY_SCHDT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT);
            PR_LOG_CHANGE('RD_FLAG',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_FLAG,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_FLAG);
            PR_LOG_CHANGE('RD_AUTO_PMNT_TAKEDOWN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN);
            PR_LOG_CHANGE('RD_MOVE_MAT_TO_UNCLAIMED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED);
            PR_LOG_CHANGE('RD_MOVE_FUNDS_ON_OVD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD);
            PR_LOG_CHANGE('MOVE_PRIC_TO_UNCLAIMED',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED);
          
          END IF;
        
          L_DBT        := 'ICTM_ACC_EFFDT';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~ICTM_ACC_EFFDT~' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).BRN || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).ACC || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD || '~' ||
                                TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                                        .UDE_EFF_DT,
                                        CSPKS_REQ_GLOBAL.G_DATE_FORMAT) || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD,
                          '@') = NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).PROD,
                                      '@')) AND
                     (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE) =
                     NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRN',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).BRN,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT (L_INDEX).BRN);
                    PR_LOG_CHANGE('ACC',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).ACC,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT (L_INDEX).ACC);
                    PR_LOG_CHANGE('PROD',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).PROD,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT (L_INDEX).PROD);
                    PR_LOG_CHANGE('UDE_EFF_DT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                                  .UDE_EFF_DT,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT (L_INDEX)
                                  .UDE_EFF_DT);
                    PR_LOG_CHANGE('RECORD_STAT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                                  .RECORD_STAT,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT (L_INDEX)
                                  .RECORD_STAT);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).BRN);
                PR_LOG_CHANGE('ACC',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).ACC);
                PR_LOG_CHANGE('PROD',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD);
                PR_LOG_CHANGE('UDE_EFF_DT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                              .UDE_EFF_DT);
                PR_LOG_CHANGE('RECORD_STAT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                              .RECORD_STAT);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD,
                          '@') = NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).PROD,
                                      '@')) AND
                     (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE) =
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~ICTM_ACC_EFFDT~' || P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).BRN || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).ACC || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD || '~' ||
                             TO_CHAR(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                                     .UDE_EFF_DT,
                                     CSPKS_REQ_GLOBAL.G_DATE_FORMAT) || '~';
                PR_LOG_CHANGE('BRN',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).BRN,
                              NULL);
                PR_LOG_CHANGE('ACC',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).ACC,
                              NULL);
                PR_LOG_CHANGE('PROD',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD,
                              NULL);
                PR_LOG_CHANGE('UDE_EFF_DT',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                              .UDE_EFF_DT,
                              NULL);
                PR_LOG_CHANGE('RECORD_STAT',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                              .RECORD_STAT,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'ICTM_ACC_UDEVALS';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~ICTM_ACC_UDEVALS~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).BRN || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).ACC || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' ||
                                TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                        .UDE_EFF_DT,
                                        CSPKS_REQ_GLOBAL.G_DATE_FORMAT) || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                               .UDE_ID || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD,
                          '@') = NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).PROD,
                                      '@')) AND
                     (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE) =
                     NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE)) AND
                     (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_ID,
                          '@') = NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                      .UDE_ID,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRN',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).BRN,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX).BRN);
                    PR_LOG_CHANGE('ACC',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).ACC,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX).ACC);
                    PR_LOG_CHANGE('PROD',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).PROD,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX).PROD);
                    PR_LOG_CHANGE('UDE_EFF_DT',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                  .UDE_EFF_DT,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX)
                                  .UDE_EFF_DT);
                    PR_LOG_CHANGE('UDE_ID',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                  .UDE_ID,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX)
                                  .UDE_ID);
                    PR_LOG_CHANGE('UDE_VALUE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                  .UDE_VALUE,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX)
                                  .UDE_VALUE);
                    PR_LOG_CHANGE('RATE_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                  .RATE_CODE,
                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS (L_INDEX)
                                  .RATE_CODE);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRN',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).BRN);
                PR_LOG_CHANGE('ACC',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).ACC);
                PR_LOG_CHANGE('PROD',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD);
                PR_LOG_CHANGE('UDE_EFF_DT',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_EFF_DT);
                PR_LOG_CHANGE('UDE_ID',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_ID);
                PR_LOG_CHANGE('UDE_VALUE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_VALUE);
                PR_LOG_CHANGE('RATE_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .RATE_CODE);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD,
                          '@') = NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).PROD,
                                      '@')) AND
                     (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE) =
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                          .UDE_EFF_DT,
                          GLOBAL.MIN_DATE)) AND
                     (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                          .UDE_ID,
                          '@') = NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                      .UDE_ID,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~ICTM_ACC_UDEVALS~' || P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).BRN || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).ACC || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' ||
                             TO_CHAR(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                     .UDE_EFF_DT,
                                     CSPKS_REQ_GLOBAL.G_DATE_FORMAT) || '~' || P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                            .UDE_ID || '~';
                PR_LOG_CHANGE('BRN',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).BRN,
                              NULL);
                PR_LOG_CHANGE('ACC',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).ACC,
                              NULL);
                PR_LOG_CHANGE('PROD',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD,
                              NULL);
                PR_LOG_CHANGE('UDE_EFF_DT',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_EFF_DT,
                              NULL);
                PR_LOG_CHANGE('UDE_ID',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_ID,
                              NULL);
                PR_LOG_CHANGE('UDE_VALUE',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_VALUE,
                              NULL);
                PR_LOG_CHANGE('RATE_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .RATE_CODE,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_ACCOUNT_REPORT_GEN_TIME';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_ACCOUNT_REPORT_GEN_TIME~' || P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                               .MESSAGE_TYPE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                          .MESSAGE_TYPE,
                          '@') = NVL(P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                      .MESSAGE_TYPE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('MESSAGE_TYPE',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                  .MESSAGE_TYPE,
                                  P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME (L_INDEX)
                                  .MESSAGE_TYPE);
                    PR_LOG_CHANGE('GEN_TIME',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                  .GEN_TIME,
                                  P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME (L_INDEX)
                                  .GEN_TIME);
                    PR_LOG_CHANGE('SERIAL_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                  .SERIAL_NO,
                                  P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME (L_INDEX)
                                  .SERIAL_NO);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('MESSAGE_TYPE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .MESSAGE_TYPE);
                PR_LOG_CHANGE('GEN_TIME',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .GEN_TIME);
                PR_LOG_CHANGE('SERIAL_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .SERIAL_NO);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                          .MESSAGE_TYPE,
                          '@') = NVL(P_WRK_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX1)
                                      .MESSAGE_TYPE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_ACCOUNT_REPORT_GEN_TIME~' || P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                            .MESSAGE_TYPE || '~';
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('MESSAGE_TYPE',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .MESSAGE_TYPE,
                              NULL);
                PR_LOG_CHANGE('GEN_TIME',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .GEN_TIME,
                              NULL);
                PR_LOG_CHANGE('SERIAL_NO',
                              'D',
                              P_PREV_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(L_INDEX)
                              .SERIAL_NO,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT        := 'STTM_ACCOUNT_REPORT_GEN_TIME';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_ACCOUNT_REPORT_GEN_TIME~' || P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                               .MESSAGE_TYPE || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                          .MESSAGE_TYPE,
                          '@') = NVL(P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                      .MESSAGE_TYPE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1 (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1 (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('MESSAGE_TYPE',
                                  'M',
                                  P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                  .MESSAGE_TYPE,
                                  P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1 (L_INDEX)
                                  .MESSAGE_TYPE);
                    PR_LOG_CHANGE('GEN_TIME',
                                  'M',
                                  P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                  .GEN_TIME,
                                  P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1 (L_INDEX)
                                  .GEN_TIME);
                    PR_LOG_CHANGE('SERIAL_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                  .SERIAL_NO,
                                  P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1 (L_INDEX)
                                  .SERIAL_NO);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('MESSAGE_TYPE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .MESSAGE_TYPE);
                PR_LOG_CHANGE('GEN_TIME',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .GEN_TIME);
                PR_LOG_CHANGE('SERIAL_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .SERIAL_NO);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                          .MESSAGE_TYPE,
                          '@') = NVL(P_WRK_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX1)
                                      .MESSAGE_TYPE,
                                      '@')) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_ACCOUNT_REPORT_GEN_TIME~' || P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                            .MESSAGE_TYPE || '~';
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('MESSAGE_TYPE',
                              'D',
                              P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .MESSAGE_TYPE,
                              NULL);
                PR_LOG_CHANGE('GEN_TIME',
                              'D',
                              P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .GEN_TIME,
                              NULL);
                PR_LOG_CHANGE('SERIAL_NO',
                              'D',
                              P_PREV_STDCUSAC.V_REPORT_GEN_TIME__GEN1(L_INDEX)
                              .SERIAL_NO,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT := 'ICTM_TD_DETAILS';
        
          L_BLK          := 'ICTMS_TD_DETAILS';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.BRN IS NOT NULL AND
             P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.ACC IS NOT NULL AND
             P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.CCY IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.BRN IS NOT NULL AND
             P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.ACC IS NOT NULL AND
             P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.CCY IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~ICTM_TD_DETAILS~' ||
                         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' ||
                         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.ACC || '~' ||
                         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.CCY || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~ICTM_TD_DETAILS~' ||
                         P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' ||
                         P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.ACC || '~' ||
                         P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.CCY || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('BRN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.BRN,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.BRN);
            PR_LOG_CHANGE('ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.ACC,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.ACC);
            PR_LOG_CHANGE('CCY',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.CCY,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.CCY);
            PR_LOG_CHANGE('PAYIN_OPTION',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.PAYIN_OPTION,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.PAYIN_OPTION);
            PR_LOG_CHANGE('TD_AMOUNT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);
            PR_LOG_CHANGE('OFFSET_BRN',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN);
            PR_LOG_CHANGE('TD_OFFSET_ACC',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC,
                          P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC);
          END IF;
        
          L_DBT := 'STTM_ACC_NOTICE_PREF';
        
          L_BLK          := 'STTMS_ACC_NOTICE_PREF';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE IS NOT NULL AND
             P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE IS NOT NULL AND
             P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~STTM_ACC_NOTICE_PREF~' ||
                         P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE || '~' ||
                         P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~STTM_ACC_NOTICE_PREF~' ||
                         P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('BRANCH_CODE',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.BRANCH_CODE);
            PR_LOG_CHANGE('CUST_AC_NO',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.CUST_AC_NO);
            PR_LOG_CHANGE('ADV_INTEREST_REQD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.ADV_INTEREST_REQD,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.ADV_INTEREST_REQD);
            PR_LOG_CHANGE('MONTHLY_FREE_AMT',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT);
            PR_LOG_CHANGE('NOTICE_PERIOD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD);
            PR_LOG_CHANGE('VALIDITY_PERIOD',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD,
                          P_WRK_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD);
          END IF;
        
          L_DBT        := 'STTM_ACCOUNT_NOMINEES';
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~STTM_ACCOUNT_NOMINEES~' || P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                               .BRANCH_CODE || '~' || P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                               .CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                               .NOMINEE_ID || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                          .NOMINEE_ID,
                          -1) = NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                     .NOMINEE_ID,
                                     -1)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('ADDRESS1',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .ADDRESS1,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .ADDRESS1);
                    PR_LOG_CHANGE('ADDRESS2',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .ADDRESS2,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .ADDRESS2);
                    PR_LOG_CHANGE('ADDRESS3',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .ADDRESS3,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .ADDRESS3);
                    PR_LOG_CHANGE('ADDRESS4',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .ADDRESS4,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .ADDRESS4);
                    PR_LOG_CHANGE('NOMINEE_ID',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .NOMINEE_ID,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .NOMINEE_ID);
                    PR_LOG_CHANGE('CUST_AC_NO',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .CUST_AC_NO,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .CUST_AC_NO);
                    PR_LOG_CHANGE('BRANCH_CODE',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .BRANCH_CODE,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .BRANCH_CODE);
                    PR_LOG_CHANGE('IS_MINOR',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .IS_MINOR,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .IS_MINOR);
                    PR_LOG_CHANGE('GUARDIAN_NAME',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARDIAN_NAME,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARDIAN_NAME);
                    PR_LOG_CHANGE('GUARDIAN_RELATION',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARDIAN_RELATION,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARDIAN_RELATION);
                    PR_LOG_CHANGE('GUARD_ADDR1',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARD_ADDR1,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARD_ADDR1);
                    PR_LOG_CHANGE('GUARD_ADDR2',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARD_ADDR2,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARD_ADDR2);
                    PR_LOG_CHANGE('GUARD_ADDR3',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARD_ADDR3,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARD_ADDR3);
                    PR_LOG_CHANGE('GUARD_ADDR4',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .GUARD_ADDR4,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .GUARD_ADDR4);
                    PR_LOG_CHANGE('NOMINEE_NAME',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .NOMINEE_NAME,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .NOMINEE_NAME);
                    PR_LOG_CHANGE('NOMINEE_DOB',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .NOMINEE_DOB,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .NOMINEE_DOB);
                    PR_LOG_CHANGE('RELATIONSHIP',
                                  'M',
                                  P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                  .RELATIONSHIP,
                                  P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES (L_INDEX)
                                  .RELATIONSHIP);
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('ADDRESS1',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS1);
                PR_LOG_CHANGE('ADDRESS2',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS2);
                PR_LOG_CHANGE('ADDRESS3',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS3);
                PR_LOG_CHANGE('ADDRESS4',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS4);
                PR_LOG_CHANGE('NOMINEE_ID',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_ID);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .CUST_AC_NO);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .BRANCH_CODE);
                PR_LOG_CHANGE('IS_MINOR',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .IS_MINOR);
                PR_LOG_CHANGE('GUARDIAN_NAME',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARDIAN_NAME);
                PR_LOG_CHANGE('GUARDIAN_RELATION',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARDIAN_RELATION);
                PR_LOG_CHANGE('GUARD_ADDR1',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR1);
                PR_LOG_CHANGE('GUARD_ADDR2',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR2);
                PR_LOG_CHANGE('GUARD_ADDR3',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR3);
                PR_LOG_CHANGE('GUARD_ADDR4',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR4);
                PR_LOG_CHANGE('NOMINEE_NAME',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_NAME);
                PR_LOG_CHANGE('NOMINEE_DOB',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_DOB);
                PR_LOG_CHANGE('RELATIONSHIP',
                              'N',
                              NULL,
                              P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .RELATIONSHIP);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT;
          L_WRK_COUNT  := P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                          .NOMINEE_ID,
                          -1) = NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX1)
                                     .NOMINEE_ID,
                                     -1)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;
                  
                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~STTM_ACCOUNT_NOMINEES~' || P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                            .BRANCH_CODE || '~' || P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                            .CUST_AC_NO || '~' || P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                            .NOMINEE_ID || '~';
                PR_LOG_CHANGE('ADDRESS1',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS1,
                              NULL);
                PR_LOG_CHANGE('ADDRESS2',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS2,
                              NULL);
                PR_LOG_CHANGE('ADDRESS3',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS3,
                              NULL);
                PR_LOG_CHANGE('ADDRESS4',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .ADDRESS4,
                              NULL);
                PR_LOG_CHANGE('NOMINEE_ID',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_ID,
                              NULL);
                PR_LOG_CHANGE('CUST_AC_NO',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .CUST_AC_NO,
                              NULL);
                PR_LOG_CHANGE('BRANCH_CODE',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .BRANCH_CODE,
                              NULL);
                PR_LOG_CHANGE('IS_MINOR',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .IS_MINOR,
                              NULL);
                PR_LOG_CHANGE('GUARDIAN_NAME',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARDIAN_NAME,
                              NULL);
                PR_LOG_CHANGE('GUARDIAN_RELATION',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARDIAN_RELATION,
                              NULL);
                PR_LOG_CHANGE('GUARD_ADDR1',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR1,
                              NULL);
                PR_LOG_CHANGE('GUARD_ADDR2',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR2,
                              NULL);
                PR_LOG_CHANGE('GUARD_ADDR3',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR3,
                              NULL);
                PR_LOG_CHANGE('GUARD_ADDR4',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .GUARD_ADDR4,
                              NULL);
                PR_LOG_CHANGE('NOMINEE_NAME',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_NAME,
                              NULL);
                PR_LOG_CHANGE('NOMINEE_DOB',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .NOMINEE_DOB,
                              NULL);
                PR_LOG_CHANGE('RELATIONSHIP',
                              'D',
                              P_PREV_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(L_INDEX)
                              .RELATIONSHIP,
                              NULL);
              END IF;
            END LOOP;
          END IF;
        
          L_DBT := 'CSTB_UI_COLUMNS';
        
          L_BLK          := 'CSTBS_UI_COLUMNS__BRNST';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;
        
          IF P_PREV_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1 IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1 IS NOT NULL THEN
            DBG('Record has been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~CSTB_UI_COLUMNS~' ||
                         P_PREV_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1 || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~CSTB_UI_COLUMNS~' ||
                         P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1 || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('CHAR_FIELD1',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1,
                          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD1);
            PR_LOG_CHANGE('CHAR_FIELD2',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD2,
                          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD2);
            PR_LOG_CHANGE('CHAR_FIELD3',
                          L_REC_ACTION,
                          P_PREV_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD3,
                          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD3);
          END IF;
        
          IF NOT CSPKS_REQ_UTILS.FN_LOG_FUNC_UDF_CHANGES(P_SOURCE,
                                                         NULL,
                                                         L_FUNCTION_ID,
                                                         P_ACTION_CODE,
                                                         L_KEY_ID,
                                                         L_MOD_NO,
                                                         P_PREV_STDCUSAC.UDF_DETAILS,
                                                         P_WRK_STDCUSAC.UDF_DETAILS,
                                                         L_TB_FIELD_LOG,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
            DBG('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
            RETURN FALSE;
          END IF;
        
          L_COUNT := L_TB_FIELD_LOG.COUNT;
          IF L_COUNT > 0 THEN
            DBG('Inserting into Field Log..');
            BEGIN
              FORALL L_INDEX IN 1 .. L_COUNT
                INSERT INTO STTBS_FIELD_LOG
                VALUES L_TB_FIELD_LOG
                  (L_INDEX);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Insert into Field Log..');
                DBG(SQLERRM);
                P_ERR_CODE   := 'ST-UPLD-001';
                P_ERR_PARAMS := '@STTBS_FIELD_LOG';
            END;
          END IF;
        
        END IF;
      END IF;
    END IF;
  
    DBG('Returning Success From Fn_Maint_Log..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Maint_Log ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MAINT_CUSTAC_LOG;

  FUNCTION FN_ADD_JOINT_ACC(P_SOURCE       IN VARCHAR2,
                            P_FUNCTION_ID  IN VARCHAR2,
                            P_WRK_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_ACC_JOINT_HOLDER         STPKS_STDJHMNT_MAIN.TY_TB_V_STTMS_ACC_JOINT_HOLDER;
    L_LINKED_ACCOUNT           STTM_ACC_JOINT_MASTER%ROWTYPE;
    L_MOD_NO                   STTM_ACC_JOINT_MASTER.MOD_NO%TYPE;
    L_COUNT                    NUMBER;
    L_AC_LINKED_ENTITIES_COUNT NUMBER;
    L_STDJHMNT                 STPKS_STDJHMNT_MAIN.TY_STDJHMNT;
    L_RECORD_MASTER            STTBS_RECORD_MASTER%ROWTYPE;
    L_RECORD_LOG               STTBS_RECORD_LOG%ROWTYPE;
  
    L_RECORD_KEY    VARCHAR2(32767);
    L_FUNCTION_TYPE VARCHAR2(32767);
    L_KEY_ID        VARCHAR2(32767);
  
    L_PRV_STDJHMNT STPKS_STDJHMNT_MAIN.TY_STDJHMNT;
    L_MODIFY       BOOLEAN := FALSE;
  
    L_RECORD_STAT STTM_CUST_ACCOUNT.RECORD_STAT%TYPE;
    L_ONCE_AUTH   STTM_CUST_ACCOUNT.ONCE_AUTH%TYPE;
  
  BEGIN
  
    DBG('Inside Fn_Add_Joint_Acc');
    L_LINKED_ACCOUNT.BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    L_LINKED_ACCOUNT.CUST_AC_NO  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    L_LINKED_ACCOUNT.CUST_NO     := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.auth_stat' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT);
    L_LINKED_ACCOUNT.JOINT_AC_INDICATOR := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR;
    L_LINKED_ACCOUNT.MODE_OF_OPERATION  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION;
    L_LINKED_ACCOUNT.MAKER_ID           := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID;
    L_LINKED_ACCOUNT.MAKER_DT_STAMP     := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP;
    L_LINKED_ACCOUNT.CHECKER_ID         := GLOBAL.USER_ID;
    L_LINKED_ACCOUNT.CHECKER_DT_STAMP   := FN_MNTSTAMP;
    L_LINKED_ACCOUNT.RECORD_STAT        := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT;
    L_LINKED_ACCOUNT.AUTH_STAT          := 'A';
    L_LINKED_ACCOUNT.ONCE_AUTH          := 'Y';
    L_LINKED_ACCOUNT.MOD_NO             := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO;
    L_AC_LINKED_ENTITIES_COUNT          := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
    DBG('count: ' || L_AC_LINKED_ENTITIES_COUNT);
  
    IF L_AC_LINKED_ENTITIES_COUNT > 0 AND
       L_LINKED_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
      FOR I IN 1 .. L_AC_LINKED_ENTITIES_COUNT LOOP
        L_ACC_JOINT_HOLDER(I).BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                             .BRANCH_CODE;
        L_ACC_JOINT_HOLDER(I).CUST_AC_NO := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                            .CUST_AC_NO;
        L_ACC_JOINT_HOLDER(I).JOINT_HOLDER_CODE := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                   .JOINT_HOLDER_CODE;
        L_ACC_JOINT_HOLDER(I).JOINT_HOLDER_DESCRIPTION := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                          .JOINT_HOLDER_DESCRIPTION;
        L_ACC_JOINT_HOLDER(I).JOINT_HOLDER := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                              .JOINT_HOLDER;
        L_ACC_JOINT_HOLDER(I).START_DATE := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                            .START_DATE;
        L_ACC_JOINT_HOLDER(I).END_DATE := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                          .END_DATE;
      END LOOP;
    END IF;
    DBG('Going to populate  l_stdjhmnt..');
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.AUTH_STAT          := 'A';
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.RECORD_STAT        := 'O';
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.BRANCH_CODE        := L_LINKED_ACCOUNT.BRANCH_CODE;
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.CUST_AC_NO         := L_LINKED_ACCOUNT.CUST_AC_NO;
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.CUST_NO            := L_LINKED_ACCOUNT.CUST_NO;
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.JOINT_AC_INDICATOR := L_LINKED_ACCOUNT.JOINT_AC_INDICATOR;
    L_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.MODE_OF_OPERATION  := L_LINKED_ACCOUNT.MODE_OF_OPERATION;
    BEGIN
      DBG('Before Select Statement to check the action');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTM_ACC_JOINT_MASTER
       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
    
      WHEN OTHERS THEN
        DBG('Error while getting the Count from sttm_acc_joint_master  ' ||
            SQLERRM);
      
    END;
  
    BEGIN
      SELECT RECORD_STAT, ONCE_AUTH
        INTO L_RECORD_STAT, L_ONCE_AUTH
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      DBG('record stat is ' || L_RECORD_STAT || ' once auth is  ' ||
          L_ONCE_AUTH);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_RECORD_STAT := 'O';
        L_ONCE_AUTH   := 'N';
        DBG('in when no data found');
    END;
    DBG('ONCE AUTH is ' || L_ONCE_AUTH || ' and count is ' || L_COUNT);
  
    IF (L_COUNT > 0) AND NVL(L_ONCE_AUTH, 'N') = 'Y' THEN
    
      DBG(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO ||
          'Already exists, so modify action');
    
      BEGIN
        SELECT *
          INTO L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_MASTER
          FROM STTM_ACC_JOINT_MASTER
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Nothing...');
        WHEN OTHERS THEN
          DBG('Error while getting prev values' || SQLERRM);
      END;
      BEGIN
        SELECT *
          BULK COLLECT
          INTO L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER
          FROM STTM_ACC_JOINT_HOLDER
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Nothing...');
        WHEN OTHERS THEN
          DBG('Error while getting prev values' || SQLERRM);
      END;
    
      IF L_ACC_JOINT_HOLDER.COUNT <>
         L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER.COUNT THEN
        L_MODIFY := TRUE;
        DBG('Change in count');
      
      ELSIF NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.MODE_OF_OPERATION,
                '*') <>
            NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION, '*') THEN
        L_MODIFY := TRUE;
        DBG('Change in mode_of_operation');
      
      ELSE
        FOR I IN 1 .. L_ACC_JOINT_HOLDER.COUNT LOOP
          IF NVL(L_ACC_JOINT_HOLDER(I).BRANCH_CODE, '*') <>
             NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I).BRANCH_CODE,
                 '*') THEN
            L_MODIFY := TRUE;
            DBG('Change in branch_code ');
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).CUST_AC_NO, '*') <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I).CUST_AC_NO,
                    '*') THEN
            L_MODIFY := TRUE;
            DBG('Change in cust_ac_no ');
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).JOINT_HOLDER_CODE, '*') <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I)
                    .JOINT_HOLDER_CODE,
                    '*') THEN
            L_MODIFY := TRUE;
            DBG('Change in joint_holder_code ');
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).JOINT_HOLDER_DESCRIPTION, '*') <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I)
                    .JOINT_HOLDER_DESCRIPTION,
                    '*') THEN
            L_MODIFY := TRUE;
            DBG('Change in joint_holder_description ');
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).JOINT_HOLDER, '*') <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I).JOINT_HOLDER,
                    '*') THEN
            L_MODIFY := TRUE;
            DBG('Change in joint_holder ');
          
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).START_DATE, SYSDATE + 1000) <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I).START_DATE,
                    SYSDATE + 1000) THEN
          
            L_MODIFY := TRUE;
            DBG('Change in start_date ');
          
          ELSIF NVL(L_ACC_JOINT_HOLDER(I).END_DATE, SYSDATE + 1000) <>
                NVL(L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_HOLDER(I).END_DATE,
                    SYSDATE + 1000) THEN
          
            L_MODIFY := TRUE;
            DBG('Change in end_date ');
          END IF;
        END LOOP;
      END IF;
      IF L_MODIFY OR L_RECORD_STAT <>
         L_PRV_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.RECORD_STAT THEN
      
        BEGIN
          SELECT MOD_NO
            INTO L_MOD_NO
            FROM STTM_ACC_JOINT_MASTER
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          UPDATE STTM_ACC_JOINT_MASTER
             SET JOINT_AC_INDICATOR = L_LINKED_ACCOUNT.JOINT_AC_INDICATOR,
                 MODE_OF_OPERATION  = L_LINKED_ACCOUNT.MODE_OF_OPERATION
                 
                ,
                 MAKER_ID       = NVL(L_LINKED_ACCOUNT.MAKER_ID,
                                      GLOBAL.USER_ID),
                 MAKER_DT_STAMP = NVL(L_LINKED_ACCOUNT.MAKER_DT_STAMP,
                                      FN_MNTSTAMP),
                 RECORD_STAT    = L_RECORD_STAT
                 
                ,
                 CHECKER_ID       = GLOBAL.USER_ID,
                 CHECKER_DT_STAMP = FN_MNTSTAMP,
                 MOD_NO           = L_MOD_NO + 1
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = L_LINKED_ACCOUNT.BRANCH_CODE;
        
          DELETE FROM STTM_ACC_JOINT_HOLDER
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = L_LINKED_ACCOUNT.BRANCH_CODE;
        
          DBG('MODIFY: ' || L_ACC_JOINT_HOLDER.COUNT);
        
          IF L_ACC_JOINT_HOLDER.COUNT > 0 AND
             L_LINKED_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
            FORALL I IN 1 .. L_ACC_JOINT_HOLDER.LAST
            
              INSERT INTO STTM_ACC_JOINT_HOLDER
              VALUES L_ACC_JOINT_HOLDER
                (I);
          END IF;
          DBG('Going to call stpks_stdjhmnt_main.Fn_Get_Key_Information');
        
          L_RECORD_KEY    := CSPKS_REQ_GLOBAL.FN_GET_REQ_KEY;
          L_FUNCTION_TYPE := CSPKS_REQ_GLOBAL.FN_GET_FUNC_TYPE;
          L_KEY_ID        := CSPKS_REQ_GLOBAL.FN_GET_KEY_ID;
        
          IF NOT STPKS_STDJHMNT_MAIN.FN_GET_KEY_INFORMATION(P_SOURCE,
                                                            NULL,
                                                            'STDJHMNT',
                                                            'MODIFY',
                                                            L_STDJHMNT,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
            DBG('Failed in  stpks_stdjhmnt_main.Fn_Get_Key_Information..');
            RETURN FALSE;
          END IF;
          DBG('Going to call stpks_stdjhmnt_main.Fn_Populate_Record_Master');
          IF NOT
              STPKS_STDJHMNT_MAIN.FN_POPULATE_RECORD_MASTER(P_SOURCE,
                                                            '',
                                                            'STDJHMNT',
                                                            'MODIFY',
                                                            L_STDJHMNT,
                                                            L_RECORD_MASTER,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          
            DBG('Failed in  stpks_stdjhmnt_main.Fn_Populate_Record_Master..');
          
            RETURN FALSE;
          END IF;
        
          DBG('Populating other values for l_Record_Master');
          L_RECORD_MASTER.BRANCH_CODE := L_LINKED_ACCOUNT.BRANCH_CODE;
          L_RECORD_MASTER.FUNCTION_ID := 'STDJHMNT';
          L_RECORD_MASTER.TABLE_NAME  := 'STTM_ACC_JOINT_MASTER';
        
          L_RECORD_MASTER.CURR_MOD_NO        := L_MOD_NO + 1;
          L_RECORD_MASTER.LATEST_AUTH_MOD_NO := L_MOD_NO + 1;
          L_RECORD_MASTER.FIRST_AUTH_STAT    := 'A';
          L_RECORD_MASTER.RECORD_STAT        := L_RECORD_STAT;
          L_RECORD_MASTER.KEY_DEF            := '~STTM_ACC_JOINT_MASTER~BRANCH_CODE~CUST_AC_NO~';
        
          L_RECORD_MASTER.CURR_MAKER_ID       := NVL(L_LINKED_ACCOUNT.MAKER_ID,
                                                     GLOBAL.USER_ID);
          L_RECORD_MASTER.CURR_MAKER_DT_STAMP := NVL(L_LINKED_ACCOUNT.MAKER_DT_STAMP,
                                                     FN_MNTSTAMP);
        
          L_RECORD_MASTER.FIRST_CHECKER_ID       := GLOBAL.USER_ID;
          L_RECORD_MASTER.FIRST_CHECKER_DT_STAMP := FN_MNTSTAMP;
          L_RECORD_MASTER.CHECKER_ID             := GLOBAL.USER_ID;
        
          L_RECORD_MASTER.CHECKER_DT_STAMP := FN_MNTSTAMP;
        
          DBG('Populating other values for STTB_RECORD_LOG');
        
          L_RECORD_LOG.KEY_ID := L_RECORD_MASTER.KEY_ID;
        
          L_RECORD_LOG.MOD_NO := L_RECORD_MASTER.CURR_MOD_NO;
        
          L_RECORD_LOG.ACTION_CODE := 'MODIFY';
        
          L_RECORD_LOG.BRANCH_CODE := L_RECORD_MASTER.BRANCH_CODE;
        
          L_RECORD_LOG.FUNCTION_ID := L_RECORD_MASTER.FUNCTION_ID;
        
          L_RECORD_LOG.TABLE_NAME := L_RECORD_MASTER.TABLE_NAME;
        
          L_RECORD_LOG.REC_DATA := CSPKS_REQ_GLOBAL.G_RES;
        
          L_RECORD_LOG.RECORD_STAT      := L_RECORD_MASTER.RECORD_STAT;
          L_RECORD_LOG.CHECKER_ID       := L_RECORD_MASTER.CHECKER_ID;
          L_RECORD_LOG.CHECKER_DT_STAMP := L_RECORD_MASTER.CHECKER_DT_STAMP;
        
          L_RECORD_LOG.MAKER_ID := L_LINKED_ACCOUNT.MAKER_ID;
        
          L_RECORD_LOG.MAKER_DT_STAMP := L_LINKED_ACCOUNT.MAKER_DT_STAMP;
        
          L_RECORD_LOG.AUTH_STAT := 'A';
        
          L_RECORD_LOG.FIRST_AUTH_STAT := 'A';
        
          L_RECORD_LOG.FIRST_CHECKER_ID := GLOBAL.USER_ID;
        
          L_RECORD_LOG.FIRST_CHECKER_DT_STAMP := FN_MNTSTAMP;
        
          L_RECORD_LOG.TANKING_STATUS := 'N';
          L_RECORD_LOG.CHAR_FLD_1     := L_RECORD_MASTER.CHAR_FLD_1;
        
          L_RECORD_LOG.CHAR_FLD_2 := L_RECORD_MASTER.CHAR_FLD_2;
          L_RECORD_LOG.CHAR_FLD_3 := L_RECORD_MASTER.CHAR_FLD_3;
        
          L_RECORD_LOG.CHAR_FLD_4 := L_RECORD_MASTER.CHAR_FLD_4;
          L_RECORD_LOG.CHAR_FLD_5 := L_RECORD_MASTER.CHAR_FLD_5;
          L_RECORD_LOG.CHAR_FLD_6 := L_RECORD_MASTER.CHAR_FLD_6;
        
          L_RECORD_LOG.CHAR_FLD_7 := L_RECORD_MASTER.CHAR_FLD_7;
          L_RECORD_LOG.CHAR_FLD_8 := L_RECORD_MASTER.CHAR_FLD_8;
        
          L_RECORD_LOG.CHAR_FLD_9 := L_RECORD_MASTER.CHAR_FLD_9;
        
          L_RECORD_LOG.CHAR_FLD_10 := L_RECORD_MASTER.CHAR_FLD_10;
        
          L_RECORD_LOG.CHAR_FLD_11 := L_RECORD_MASTER.CHAR_FLD_11;
        
          L_RECORD_LOG.CHAR_FLD_12 := L_RECORD_MASTER.CHAR_FLD_12;
        
          L_RECORD_LOG.CHAR_FLD_13 := L_RECORD_MASTER.CHAR_FLD_13;
        
          L_RECORD_LOG.CHAR_FLD_14 := L_RECORD_MASTER.CHAR_FLD_14;
        
          L_RECORD_LOG.CHAR_FLD_15 := L_RECORD_MASTER.CHAR_FLD_15;
        
          L_RECORD_LOG.CHAR_FLD_16 := L_RECORD_MASTER.CHAR_FLD_16;
        
          L_RECORD_LOG.CHAR_FLD_17 := L_RECORD_MASTER.CHAR_FLD_17;
        
          L_RECORD_LOG.CHAR_FLD_18 := L_RECORD_MASTER.CHAR_FLD_18;
        
          L_RECORD_LOG.CHAR_FLD_19 := L_RECORD_MASTER.CHAR_FLD_19;
        
          L_RECORD_LOG.CHAR_FLD_20 := L_RECORD_MASTER.CHAR_FLD_20;
        
          L_RECORD_LOG.CHAR_FLD_21 := L_RECORD_MASTER.CHAR_FLD_21;
        
          L_RECORD_LOG.CHAR_FLD_22 := L_RECORD_MASTER.CHAR_FLD_22;
        
          L_RECORD_LOG.CHAR_FLD_23 := L_RECORD_MASTER.CHAR_FLD_23;
        
          L_RECORD_LOG.CHAR_FLD_24 := L_RECORD_MASTER.CHAR_FLD_24;
        
          L_RECORD_LOG.CHAR_FLD_25 := L_RECORD_MASTER.CHAR_FLD_25;
        
          L_RECORD_LOG.NUM_FLD_1 := L_RECORD_MASTER.NUM_FLD_1;
        
          L_RECORD_LOG.NUM_FLD_2 := L_RECORD_MASTER.NUM_FLD_2;
        
          L_RECORD_LOG.NUM_FLD_3 := L_RECORD_MASTER.NUM_FLD_3;
        
          L_RECORD_LOG.NUM_FLD_4 := L_RECORD_MASTER.NUM_FLD_4;
        
          L_RECORD_LOG.NUM_FLD_5 := L_RECORD_MASTER.NUM_FLD_5;
        
          L_RECORD_LOG.NUM_FLD_6 := L_RECORD_MASTER.NUM_FLD_6;
        
          L_RECORD_LOG.NUM_FLD_7 := L_RECORD_MASTER.NUM_FLD_7;
        
          L_RECORD_LOG.NUM_FLD_8 := L_RECORD_MASTER.NUM_FLD_8;
        
          L_RECORD_LOG.NUM_FLD_9 := L_RECORD_MASTER.NUM_FLD_9;
        
          L_RECORD_LOG.NUM_FLD_10 := L_RECORD_MASTER.NUM_FLD_10;
        
          L_RECORD_LOG.DATE_FLD_1 := L_RECORD_MASTER.DATE_FLD_1;
        
          L_RECORD_LOG.DATE_FLD_2 := L_RECORD_MASTER.DATE_FLD_2;
        
          L_RECORD_LOG.DATE_FLD_3 := L_RECORD_MASTER.DATE_FLD_3;
        
          L_RECORD_LOG.DATE_FLD_4 := L_RECORD_MASTER.DATE_FLD_4;
        
          L_RECORD_LOG.DATE_FLD_5 := L_RECORD_MASTER.DATE_FLD_5;
        
          L_RECORD_LOG.DATE_FLD_6 := L_RECORD_MASTER.DATE_FLD_6;
        
          L_RECORD_LOG.DATE_FLD_7 := L_RECORD_MASTER.DATE_FLD_7;
        
          L_RECORD_LOG.DATE_FLD_8 := L_RECORD_MASTER.DATE_FLD_8;
        
          L_RECORD_LOG.DATE_FLD_9 := L_RECORD_MASTER.DATE_FLD_9;
        
          L_RECORD_LOG.DATE_FLD_10 := L_RECORD_MASTER.DATE_FLD_10;
        
          UPDATE STTBS_RECORD_MASTER
             SET CURR_MOD_NO     = L_RECORD_MASTER.CURR_MOD_NO,
                 AUTH_STAT       = L_RECORD_MASTER.AUTH_STAT,
                 RECORD_STAT     = L_RECORD_MASTER.RECORD_STAT,
                 FIRST_AUTH_STAT = L_RECORD_MASTER.FIRST_AUTH_STAT
                 
                ,
                 LATEST_AUTH_MOD_NO = L_RECORD_MASTER.LATEST_AUTH_MOD_NO,
                 CHAR_FLD_1         = L_RECORD_MASTER.CHAR_FLD_1,
                 CHAR_FLD_2         = L_RECORD_MASTER.CHAR_FLD_2
                 
                ,
                 CHAR_FLD_3 = L_RECORD_MASTER.CHAR_FLD_3
                 
                ,
                 CHAR_FLD_4 = L_RECORD_MASTER.CHAR_FLD_4
                 
                ,
                 CHAR_FLD_5 = L_RECORD_MASTER.CHAR_FLD_5
                 
                ,
                 CHAR_FLD_6 = L_RECORD_MASTER.CHAR_FLD_6
                 
                ,
                 CHAR_FLD_7 = L_RECORD_MASTER.CHAR_FLD_7
                 
                ,
                 CHAR_FLD_8 = L_RECORD_MASTER.CHAR_FLD_8
                 
                ,
                 CHAR_FLD_9 = L_RECORD_MASTER.CHAR_FLD_9
                 
                ,
                 CHAR_FLD_10 = L_RECORD_MASTER.CHAR_FLD_10
                 
                ,
                 CHAR_FLD_11 = L_RECORD_MASTER.CHAR_FLD_11
                 
                ,
                 CHAR_FLD_12 = L_RECORD_MASTER.CHAR_FLD_12
                 
                ,
                 CHAR_FLD_13 = L_RECORD_MASTER.CHAR_FLD_13
                 
                ,
                 CHAR_FLD_14 = L_RECORD_MASTER.CHAR_FLD_14
                 
                ,
                 CHAR_FLD_15 = L_RECORD_MASTER.CHAR_FLD_15
                 
                ,
                 CHAR_FLD_16 = L_RECORD_MASTER.CHAR_FLD_16
                 
                ,
                 CHAR_FLD_17 = L_RECORD_MASTER.CHAR_FLD_17,
                 CHAR_FLD_18 = L_RECORD_MASTER.CHAR_FLD_18
                 
                ,
                 CHAR_FLD_19 = L_RECORD_MASTER.CHAR_FLD_19
                 
                ,
                 CHAR_FLD_20 = L_RECORD_MASTER.CHAR_FLD_20
                 
                ,
                 CHAR_FLD_21 = L_RECORD_MASTER.CHAR_FLD_21
                 
                ,
                 CHAR_FLD_22 = L_RECORD_MASTER.CHAR_FLD_22
                 
                ,
                 CHAR_FLD_23 = L_RECORD_MASTER.CHAR_FLD_23
                 
                ,
                 CHAR_FLD_24 = L_RECORD_MASTER.CHAR_FLD_24
                 
                ,
                 CHAR_FLD_25 = L_RECORD_MASTER.CHAR_FLD_25
                 
                ,
                 NUM_FLD_1 = L_RECORD_MASTER.NUM_FLD_1
                 
                ,
                 NUM_FLD_2 = L_RECORD_MASTER.NUM_FLD_2
                 
                ,
                 NUM_FLD_3 = L_RECORD_MASTER.NUM_FLD_3
                 
                ,
                 NUM_FLD_4 = L_RECORD_MASTER.NUM_FLD_4
                 
                ,
                 NUM_FLD_5 = L_RECORD_MASTER.NUM_FLD_5
                 
                ,
                 NUM_FLD_6 = L_RECORD_MASTER.NUM_FLD_6
                 
                ,
                 NUM_FLD_7 = L_RECORD_MASTER.NUM_FLD_7
                 
                ,
                 NUM_FLD_8 = L_RECORD_MASTER.NUM_FLD_8
                 
                ,
                 NUM_FLD_9 = L_RECORD_MASTER.NUM_FLD_9
                 
                ,
                 NUM_FLD_10 = L_RECORD_MASTER.NUM_FLD_10
                 
                ,
                 DATE_FLD_1 = L_RECORD_MASTER.DATE_FLD_1
                 
                ,
                 DATE_FLD_2 = L_RECORD_MASTER.DATE_FLD_2
                 
                ,
                 DATE_FLD_3 = L_RECORD_MASTER.DATE_FLD_3
                 
                ,
                 DATE_FLD_4 = L_RECORD_MASTER.DATE_FLD_4
                 
                ,
                 DATE_FLD_5 = L_RECORD_MASTER.DATE_FLD_5
                 
                ,
                 DATE_FLD_6 = L_RECORD_MASTER.DATE_FLD_6
                 
                ,
                 DATE_FLD_7 = L_RECORD_MASTER.DATE_FLD_7
                 
                ,
                 DATE_FLD_8 = L_RECORD_MASTER.DATE_FLD_8
                 
                ,
                 DATE_FLD_9 = L_RECORD_MASTER.DATE_FLD_9
                 
                ,
                 DATE_FLD_10 = L_RECORD_MASTER.DATE_FLD_10
                 
                ,
                 CURR_MAKER_ID = L_RECORD_MASTER.CURR_MAKER_ID
                 
                ,
                 CURR_MAKER_DT_STAMP = L_RECORD_MASTER.CURR_MAKER_DT_STAMP
                 
                ,
                 FIRST_CHECKER_ID = L_RECORD_MASTER.FIRST_CHECKER_ID
                 
                ,
                 FIRST_CHECKER_DT_STAMP = L_RECORD_MASTER.FIRST_CHECKER_DT_STAMP
                 
                ,
                 CHECKER_ID = L_RECORD_MASTER.CHECKER_ID
                 
                ,
                 CHECKER_DT_STAMP = L_RECORD_MASTER.CHECKER_DT_STAMP
          
           WHERE KEY_ID = L_RECORD_MASTER.KEY_ID;
        
          DBG('Before Inserting  into STTB_RECORD_LOG');
        
          BEGIN
          
            INSERT INTO STTB_RECORD_LOG
            
            VALUES L_RECORD_LOG;
          
          EXCEPTION
          
            WHEN OTHERS THEN
            
              DBG('Exception Raised While Populating Record Log ::' ||
                  SQLERRM);
            
              RETURN FALSE;
            
          END;
        
          DBG('After Inserting  into STTB_RECORD_LOG');
        
          CSPKS_REQ_GLOBAL.PR_SET_REQ_KEY(L_RECORD_KEY);
          CSPKS_REQ_GLOBAL.PR_SET_FUNC_TYPE(L_FUNCTION_TYPE);
          CSPKS_REQ_GLOBAL.PR_SET_KEY_ID(L_KEY_ID);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error While Modifying the Joint holder Details');
        END;
      END IF;
    
    ELSE
      DBG('New Operation');
      INSERT INTO STTM_ACC_JOINT_MASTER VALUES L_LINKED_ACCOUNT;
    
      IF L_ACC_JOINT_HOLDER.COUNT > 0 AND
         L_LINKED_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
        FORALL I IN L_ACC_JOINT_HOLDER.FIRST .. L_ACC_JOINT_HOLDER.LAST
          INSERT INTO STTM_ACC_JOINT_HOLDER VALUES L_ACC_JOINT_HOLDER (I);
      END IF;
      DBG('Inserted Into sttm_acc_joint_master');
    
      L_RECORD_KEY    := CSPKS_REQ_GLOBAL.FN_GET_REQ_KEY;
      L_FUNCTION_TYPE := CSPKS_REQ_GLOBAL.FN_GET_FUNC_TYPE;
      L_KEY_ID        := CSPKS_REQ_GLOBAL.FN_GET_KEY_ID;
    
      DBG('Going to call stpks_stdjhmnt_main.Fn_Get_Key_Information');
      IF NOT STPKS_STDJHMNT_MAIN.FN_GET_KEY_INFORMATION(P_SOURCE,
                                                        NULL,
                                                        'STDJHMNT',
                                                        'NEW',
                                                        L_STDJHMNT,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
        DBG('Failed in  stpks_stdjhmnt_main.Fn_Get_Key_Information..');
        RETURN FALSE;
      END IF;
      DBG('Going to call stpks_stdjhmnt_main.Fn_Populate_Record_Master');
      IF NOT STPKS_STDJHMNT_MAIN.FN_POPULATE_RECORD_MASTER(P_SOURCE,
                                                           '',
                                                           'STDJHMNT',
                                                           'NEW',
                                                           L_STDJHMNT,
                                                           L_RECORD_MASTER,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
        DBG('Failed in  stpks_stdjhmnt_main.Fn_Populate_Record_Master..');
        RETURN FALSE;
      END IF;
      DBG('Populating other values for l_Record_Master');
      L_RECORD_MASTER.BRANCH_CODE            := L_LINKED_ACCOUNT.BRANCH_CODE;
      L_RECORD_MASTER.FUNCTION_ID            := 'STDJHMNT';
      L_RECORD_MASTER.TABLE_NAME             := 'STTM_ACC_JOINT_MASTER';
      L_RECORD_MASTER.CURR_MOD_NO            := 1;
      L_RECORD_MASTER.LATEST_AUTH_MOD_NO     := 1;
      L_RECORD_MASTER.FIRST_AUTH_STAT        := 'A';
      L_RECORD_MASTER.KEY_DEF                := '~STTM_ACC_JOINT_MASTER~BRANCH_CODE~CUST_AC_NO~';
      L_RECORD_MASTER.CURR_MAKER_ID          := L_LINKED_ACCOUNT.MAKER_ID;
      L_RECORD_MASTER.CURR_MAKER_DT_STAMP    := L_LINKED_ACCOUNT.MAKER_DT_STAMP;
      L_RECORD_MASTER.FIRST_CHECKER_ID       := GLOBAL.USER_ID;
      L_RECORD_MASTER.FIRST_CHECKER_DT_STAMP := FN_MNTSTAMP;
      L_RECORD_MASTER.CHECKER_ID             := GLOBAL.USER_ID;
      L_RECORD_MASTER.CHECKER_DT_STAMP       := FN_MNTSTAMP;
      DBG('Populating other values for STTB_RECORD_LOG');
      L_RECORD_LOG.KEY_ID                 := L_RECORD_MASTER.KEY_ID;
      L_RECORD_LOG.MOD_NO                 := 1;
      L_RECORD_LOG.ACTION_CODE            := 'NEW';
      L_RECORD_LOG.BRANCH_CODE            := L_RECORD_MASTER.BRANCH_CODE;
      L_RECORD_LOG.FUNCTION_ID            := 'STDJHMNT';
      L_RECORD_LOG.TABLE_NAME             := 'STTM_ACC_JOINT_MASTER';
      L_RECORD_LOG.REC_DATA               := CSPKS_REQ_GLOBAL.G_RES;
      L_RECORD_LOG.RECORD_STAT            := 'O';
      L_RECORD_LOG.MAKER_ID               := L_LINKED_ACCOUNT.MAKER_ID;
      L_RECORD_LOG.MAKER_DT_STAMP         := L_LINKED_ACCOUNT.MAKER_DT_STAMP;
      L_RECORD_LOG.AUTH_STAT              := 'A';
      L_RECORD_LOG.FIRST_AUTH_STAT        := 'A';
      L_RECORD_LOG.FIRST_CHECKER_ID       := GLOBAL.USER_ID;
      L_RECORD_LOG.FIRST_CHECKER_DT_STAMP := FN_MNTSTAMP;
      L_RECORD_LOG.TANKING_STATUS         := 'N';
      L_RECORD_LOG.CHAR_FLD_1             := L_RECORD_MASTER.CHAR_FLD_1;
      L_RECORD_LOG.CHAR_FLD_2             := L_RECORD_MASTER.CHAR_FLD_2;
      L_RECORD_LOG.CHAR_FLD_3             := L_RECORD_MASTER.CHAR_FLD_3;
      L_RECORD_LOG.CHAR_FLD_4             := L_RECORD_MASTER.CHAR_FLD_4;
      L_RECORD_LOG.CHAR_FLD_5             := L_RECORD_MASTER.CHAR_FLD_5;
      L_RECORD_LOG.CHAR_FLD_6             := L_RECORD_MASTER.CHAR_FLD_6;
      L_RECORD_LOG.CHAR_FLD_7             := L_RECORD_MASTER.CHAR_FLD_7;
      L_RECORD_LOG.CHAR_FLD_8             := L_RECORD_MASTER.CHAR_FLD_8;
      L_RECORD_LOG.CHAR_FLD_9             := L_RECORD_MASTER.CHAR_FLD_9;
      L_RECORD_LOG.CHAR_FLD_10            := L_RECORD_MASTER.CHAR_FLD_10;
      L_RECORD_LOG.CHAR_FLD_11            := L_RECORD_MASTER.CHAR_FLD_11;
      L_RECORD_LOG.CHAR_FLD_12            := L_RECORD_MASTER.CHAR_FLD_12;
      L_RECORD_LOG.CHAR_FLD_13            := L_RECORD_MASTER.CHAR_FLD_13;
      L_RECORD_LOG.CHAR_FLD_14            := L_RECORD_MASTER.CHAR_FLD_14;
      L_RECORD_LOG.CHAR_FLD_15            := L_RECORD_MASTER.CHAR_FLD_15;
      L_RECORD_LOG.CHAR_FLD_16            := L_RECORD_MASTER.CHAR_FLD_16;
      L_RECORD_LOG.CHAR_FLD_17            := L_RECORD_MASTER.CHAR_FLD_17;
      L_RECORD_LOG.CHAR_FLD_18            := L_RECORD_MASTER.CHAR_FLD_18;
      L_RECORD_LOG.CHAR_FLD_19            := L_RECORD_MASTER.CHAR_FLD_19;
      L_RECORD_LOG.CHAR_FLD_20            := L_RECORD_MASTER.CHAR_FLD_20;
      L_RECORD_LOG.CHAR_FLD_21            := L_RECORD_MASTER.CHAR_FLD_21;
      L_RECORD_LOG.CHAR_FLD_22            := L_RECORD_MASTER.CHAR_FLD_22;
      L_RECORD_LOG.CHAR_FLD_23            := L_RECORD_MASTER.CHAR_FLD_23;
      L_RECORD_LOG.CHAR_FLD_24            := L_RECORD_MASTER.CHAR_FLD_24;
      L_RECORD_LOG.CHAR_FLD_25            := L_RECORD_MASTER.CHAR_FLD_25;
      L_RECORD_LOG.NUM_FLD_1              := L_RECORD_MASTER.NUM_FLD_1;
      L_RECORD_LOG.NUM_FLD_2              := L_RECORD_MASTER.NUM_FLD_2;
      L_RECORD_LOG.NUM_FLD_3              := L_RECORD_MASTER.NUM_FLD_3;
      L_RECORD_LOG.NUM_FLD_4              := L_RECORD_MASTER.NUM_FLD_4;
      L_RECORD_LOG.NUM_FLD_5              := L_RECORD_MASTER.NUM_FLD_5;
      L_RECORD_LOG.NUM_FLD_6              := L_RECORD_MASTER.NUM_FLD_6;
      L_RECORD_LOG.NUM_FLD_7              := L_RECORD_MASTER.NUM_FLD_7;
      L_RECORD_LOG.NUM_FLD_8              := L_RECORD_MASTER.NUM_FLD_8;
      L_RECORD_LOG.NUM_FLD_9              := L_RECORD_MASTER.NUM_FLD_9;
      L_RECORD_LOG.NUM_FLD_10             := L_RECORD_MASTER.NUM_FLD_10;
      L_RECORD_LOG.DATE_FLD_1             := L_RECORD_MASTER.DATE_FLD_1;
      L_RECORD_LOG.DATE_FLD_2             := L_RECORD_MASTER.DATE_FLD_2;
      L_RECORD_LOG.DATE_FLD_3             := L_RECORD_MASTER.DATE_FLD_3;
      L_RECORD_LOG.DATE_FLD_4             := L_RECORD_MASTER.DATE_FLD_4;
      L_RECORD_LOG.DATE_FLD_5             := L_RECORD_MASTER.DATE_FLD_5;
      L_RECORD_LOG.DATE_FLD_6             := L_RECORD_MASTER.DATE_FLD_6;
      L_RECORD_LOG.DATE_FLD_7             := L_RECORD_MASTER.DATE_FLD_7;
      L_RECORD_LOG.DATE_FLD_8             := L_RECORD_MASTER.DATE_FLD_8;
      L_RECORD_LOG.DATE_FLD_9             := L_RECORD_MASTER.DATE_FLD_9;
      L_RECORD_LOG.DATE_FLD_10            := L_RECORD_MASTER.DATE_FLD_10;
    
      L_RECORD_LOG.CHECKER_ID       := L_RECORD_MASTER.CHECKER_ID;
      L_RECORD_LOG.CHECKER_DT_STAMP := L_RECORD_MASTER.CHECKER_DT_STAMP;
    
      DBG('Going to Insert into STTB_RECORD_MASTER');
      BEGIN
        INSERT INTO STTB_RECORD_MASTER VALUES L_RECORD_MASTER;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert into STTB_RECORD_MASTER..' || SQLERRM);
      END;
      DBG('After Inserting  into STTB_RECORD_MASTER');
      DBG('Before Inserting  into STTB_RECORD_LOG');
      BEGIN
        INSERT INTO STTB_RECORD_LOG VALUES L_RECORD_LOG;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Exception Raised While Populating Record Log ::' || SQLERRM);
      END;
      DBG('After Inserting  into STTB_RECORD_LOG');
    
      CSPKS_REQ_GLOBAL.PR_SET_REQ_KEY(L_RECORD_KEY);
      CSPKS_REQ_GLOBAL.PR_SET_FUNC_TYPE(L_FUNCTION_TYPE);
      CSPKS_REQ_GLOBAL.PR_SET_KEY_ID(L_KEY_ID);
    
    END IF;
    DBG('Returning Sucessful Fn_Add_Joint_Acc');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('In when others Exception of Fn_Add_Joint_Acc');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
    
  END FN_ADD_JOINT_ACC;

  FUNCTION FN_JOINT_HOLDER_CONVERSION(P_SOURCE      IN VARCHAR2,
                                      P_FUNCTION_ID IN VARCHAR2,
                                      P_ERR_CODE    IN OUT VARCHAR2,
                                      P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_WRK_STDCUSAC STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
  
    TYPE TY_TB_STTMS_AC_LINKED_ENTITIES IS TABLE OF STTM_AC_LINKED_ENTITIES%ROWTYPE INDEX BY BINARY_INTEGER;
    L_LINKED_ENTITIES TY_TB_STTMS_AC_LINKED_ENTITIES;
    L_CUST_ACCOUNT    STTM_CUST_ACCOUNT%ROWTYPE;
  
    CURSOR C_CUST_ACCOUNT IS
      SELECT *
        FROM STTM_CUST_ACCOUNT SCA
       WHERE NOT EXISTS (SELECT 1
                FROM STTM_ACC_JOINT_MASTER ACJM
               WHERE ACJM.CUST_AC_NO = SCA.CUST_AC_NO
                 AND ACJM.BRANCH_CODE = SCA.BRANCH_CODE)
         AND AUTH_STAT = 'A';
  
  BEGIN
    DBG('Inside Fn_Joint_Holder_Conversion');
    OPEN C_CUST_ACCOUNT;
    LOOP
      FETCH C_CUST_ACCOUNT
        INTO L_CUST_ACCOUNT;
      IF C_CUST_ACCOUNT%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('Checking for Acc :' || L_CUST_ACCOUNT.CUST_AC_NO || '~' ||
          L_CUST_ACCOUNT.BRANCH_CODE);
      BEGIN
        L_LINKED_ENTITIES.DELETE;
        DBG('Count : ' || L_LINKED_ENTITIES.COUNT);
      
        SELECT *
          BULK COLLECT
          INTO L_LINKED_ENTITIES
          FROM STTM_AC_LINKED_ENTITIES
         WHERE CUST_AC_NO = L_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = L_CUST_ACCOUNT.BRANCH_CODE;
      END;
    
      L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT := L_CUST_ACCOUNT;
      L_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.DELETE;
      IF L_LINKED_ENTITIES.COUNT > 0 THEN
        FOR I IN 1 .. L_LINKED_ENTITIES.COUNT LOOP
          L_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I) := L_LINKED_ENTITIES(I);
        END LOOP;
      END IF;
      SAVEPOINT SP_JOINT_HOLDERS;
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_ADD_JOINT_ACC(P_SOURCE,
                                                     P_FUNCTION_ID,
                                                     L_WRK_STDCUSAC,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcusac_utils_2.Fn_Add_Joint_Acc ' ||
            P_ERR_CODE || '~' || P_ERR_PARAMS);
        ROLLBACK TO SP_JOINT_HOLDERS;
      ELSE
        DBG('Successfully uploaded Joint holder details');
      END IF;
    END LOOP;
  
    DBG('Returning successfully from Fn_Joint_Holder_Conversion...');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in WOE of Fn_Joint_Holder_Conversion');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_JOINT_HOLDER_CONVERSION;

  FUNCTION FN_PICKUP_MEDIA(P_ACC      IN VARCHAR2,
                           P_BRN      IN VARCHAR2,
                           P_CUST     IN VARCHAR,
                           P_MSG_TYPE IN VARCHAR2,
                           P_MODULE   IN VARCHAR2) RETURN VARCHAR2 IS
    L_MEDIA STTM_CUSTOMER.DEFAULT_MEDIA%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('ST', 'In fn_pickup_media');
    BEGIN
      SELECT B.MEDIA
        INTO L_MEDIA
        FROM MSTMS_CUST_ACC_ADDRESS A,
             MSTM_MSG_ACC_ADDRESS   B,
             STTM_CUST_ACCOUNT      C
       WHERE A.CUST_AC_NO = B.CUST_AC_NO
         AND A.CUST_AC_BRN = B.BRANCH
         AND A.CUST_AC_NO = C.CUST_AC_NO
         AND A.CUST_AC_BRN = C.BRANCH_CODE
         AND A.MEDIA = B.MEDIA
         AND A.LOCATION = B.LOCATION
         AND B.MODULE IN (P_MODULE, 'AL')
         AND A.CUST_AC_NO = P_ACC
         AND A.CUST_AC_BRN = P_BRN
         AND A.MEDIA = C.MEDIA
         AND B.MSG_TYPE = P_MSG_TYPE
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A'
         AND ROWNUM = 1;
      DEBUG.PR_DEBUG('ST', 'media coming in 1 is ' || L_MEDIA);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('ST',
                       'In when no data found for acc ' || P_ACC ||
                       ' and brn ' || P_BRN || ' and msg type ' ||
                       P_MSG_TYPE);
        BEGIN
          SELECT B.MEDIA
            INTO L_MEDIA
            FROM MSTM_CUST_ADDRESS A, MSTM_MSG_ADDRESS B, STTM_CUSTOMER C
           WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
             AND A.CUSTOMER_NO = C.CUSTOMER_NO
             AND A.MEDIA = B.MEDIA
             AND A.LOCATION = B.LOCATION
             AND B.MODULE IN (P_MODULE, 'AL')
             AND B.BRANCH IN (P_BRN, 'ALL')
             AND B.MEDIA = C.DEFAULT_MEDIA
             AND A.CUSTOMER_NO = P_CUST
             AND B.MSG_TYPE = P_MSG_TYPE
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND ROWNUM = 1;
          DEBUG.PR_DEBUG('ST', 'media coming in 2 is ' || L_MEDIA);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('ST',
                           'In when no data found for cust ' || P_CUST ||
                           ' and msg type ' || P_MSG_TYPE);
            BEGIN
              SELECT B.MEDIA
                INTO L_MEDIA
                FROM MSTMS_CUST_ACC_ADDRESS A,
                     MSTM_MSG_ACC_ADDRESS   B,
                     STTM_CUST_ACCOUNT      C
               WHERE A.CUST_AC_NO = B.CUST_AC_NO
                 AND A.CUST_AC_BRN = B.BRANCH
                 AND A.CUST_AC_NO = C.CUST_AC_NO
                 AND A.CUST_AC_BRN = C.BRANCH_CODE
                 AND B.MEDIA = A.MEDIA
                 AND A.LOCATION = B.LOCATION
                 AND B.MODULE IN (P_MODULE, 'AL')
                 AND A.CUST_AC_NO = P_ACC
                 AND A.CUST_AC_BRN = P_BRN
                 AND B.MSG_TYPE = 'ANY MSG TYPE'
                 AND B.MEDIA = C.MEDIA
                 AND A.RECORD_STAT = 'O'
                 AND A.AUTH_STAT = 'A'
                 AND ROWNUM = 1;
              DEBUG.PR_DEBUG('ST', 'media coming in 3 is ' || L_MEDIA);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('ST',
                               'In when no data found for acc ' || P_ACC ||
                               ' and brn ' || P_BRN ||
                               ' and msg type ANY MSG TYPE');
                BEGIN
                  SELECT B.MEDIA
                    INTO L_MEDIA
                    FROM MSTM_CUST_ADDRESS A,
                         MSTM_MSG_ADDRESS  B,
                         STTM_CUSTOMER     C
                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                     AND A.CUSTOMER_NO = C.CUSTOMER_NO
                     AND A.MEDIA = B.MEDIA
                     AND A.LOCATION = B.LOCATION
                     AND B.MODULE IN (P_MODULE, 'AL')
                     AND B.BRANCH IN (P_BRN, 'ALL')
                     AND A.CUSTOMER_NO = P_CUST
                     AND B.MSG_TYPE = 'ANY MSG TYPE'
                     AND B.MEDIA = C.DEFAULT_MEDIA
                     AND A.RECORD_STAT = 'O'
                     AND A.AUTH_STAT = 'A'
                     AND ROWNUM = 1;
                  DEBUG.PR_DEBUG('ST', 'media coming in 4 is ' || L_MEDIA);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DEBUG.PR_DEBUG('ST',
                                   'In when no data found for cust ' ||
                                   P_CUST || ' and  ANY MSG TYPE');
                    L_MEDIA := NULL;
                END;
            END;
        END;
    END;
    DEBUG.PR_DEBUG('ST', 'final media coming is ' || L_MEDIA);
    DEBUG.PR_DEBUG('ST', 'Returning successfully from fn_pickup_media');
    RETURN L_MEDIA;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'In when others exception' || SQLERRM);
      DEBUG.PR_DEBUG('ST',
                     'error in ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_MEDIA := NULL;
      RETURN L_MEDIA;
  END FN_PICKUP_MEDIA;

  FUNCTION FN_PICKUP_LOCATION(P_ACC      IN VARCHAR2,
                              P_BRN      IN VARCHAR2,
                              P_CUST     IN VARCHAR,
                              P_MSG_TYPE IN VARCHAR2,
                              P_MODULE   IN VARCHAR2) RETURN VARCHAR2 IS
    L_LOCATION STTM_CUSTOMER.LOC_CODE%TYPE;
  BEGIN
    DEBUG.PR_DEBUG('ST', 'In fn_pickup_media');
    BEGIN
      SELECT B.LOCATION
        INTO L_LOCATION
        FROM MSTMS_CUST_ACC_ADDRESS A,
             MSTM_MSG_ACC_ADDRESS   B,
             STTM_CUST_ACCOUNT      C
       WHERE A.CUST_AC_NO = B.CUST_AC_NO
         AND A.CUST_AC_BRN = B.BRANCH
         AND A.CUST_AC_NO = C.CUST_AC_NO
         AND A.CUST_AC_BRN = C.BRANCH_CODE
         AND A.MEDIA = B.MEDIA
         AND A.LOCATION = B.LOCATION
         AND B.MODULE IN (P_MODULE, 'AL')
         AND A.CUST_AC_NO = P_ACC
         AND A.CUST_AC_BRN = P_BRN
         AND A.MEDIA = C.MEDIA
         AND B.MSG_TYPE = P_MSG_TYPE
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A'
         AND ROWNUM = 1;
      DEBUG.PR_DEBUG('ST', 'location coming in 1 is ' || L_LOCATION);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DEBUG.PR_DEBUG('ST',
                       'In when no data found for acc ' || P_ACC ||
                       ' and brn ' || P_BRN || ' and msg type ' ||
                       P_MSG_TYPE);
        BEGIN
          SELECT B.LOCATION
            INTO L_LOCATION
            FROM MSTM_CUST_ADDRESS A, MSTM_MSG_ADDRESS B, STTM_CUSTOMER C
           WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
             AND A.CUSTOMER_NO = C.CUSTOMER_NO
             AND A.MEDIA = B.MEDIA
             AND A.LOCATION = B.LOCATION
             AND B.MODULE IN (P_MODULE, 'AL')
             AND B.BRANCH IN (P_BRN, 'ALL')
             AND B.MEDIA = C.DEFAULT_MEDIA
             AND A.CUSTOMER_NO = P_CUST
             AND B.MSG_TYPE = P_MSG_TYPE
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND ROWNUM = 1;
          DEBUG.PR_DEBUG('ST', 'location coming in 2 is ' || L_LOCATION);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DEBUG.PR_DEBUG('ST',
                           'In when no data found for cust ' || P_CUST ||
                           ' and msg type ' || P_MSG_TYPE);
            BEGIN
              SELECT B.LOCATION
                INTO L_LOCATION
                FROM MSTMS_CUST_ACC_ADDRESS A,
                     MSTM_MSG_ACC_ADDRESS   B,
                     STTM_CUST_ACCOUNT      C
               WHERE A.CUST_AC_NO = B.CUST_AC_NO
                 AND A.CUST_AC_BRN = B.BRANCH
                 AND A.CUST_AC_NO = C.CUST_AC_NO
                 AND A.CUST_AC_BRN = C.BRANCH_CODE
                 AND B.MEDIA = A.MEDIA
                 AND A.LOCATION = B.LOCATION
                 AND B.MODULE IN (P_MODULE, 'AL')
                 AND A.CUST_AC_NO = P_ACC
                 AND A.CUST_AC_BRN = P_BRN
                 AND B.MSG_TYPE = 'ANY MSG TYPE'
                 AND B.MEDIA = C.MEDIA
                 AND A.RECORD_STAT = 'O'
                 AND A.AUTH_STAT = 'A'
                 AND ROWNUM = 1;
              DEBUG.PR_DEBUG('ST',
                             'location coming in 3 is ' || L_LOCATION);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DEBUG.PR_DEBUG('ST',
                               'In when no data found for acc ' || P_ACC ||
                               ' and brn ' || P_BRN ||
                               ' and msg type ANY MSG TYPE');
                BEGIN
                  SELECT B.LOCATION
                    INTO L_LOCATION
                    FROM MSTM_CUST_ADDRESS A,
                         MSTM_MSG_ADDRESS  B,
                         STTM_CUSTOMER     C
                   WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                     AND A.CUSTOMER_NO = C.CUSTOMER_NO
                     AND A.MEDIA = B.MEDIA
                     AND A.LOCATION = B.LOCATION
                     AND B.MODULE IN (P_MODULE, 'AL')
                     AND B.BRANCH IN (P_BRN, 'ALL')
                     AND A.CUSTOMER_NO = P_CUST
                     AND B.MSG_TYPE = 'ANY MSG TYPE'
                     AND B.MEDIA = C.DEFAULT_MEDIA
                     AND A.RECORD_STAT = 'O'
                     AND A.AUTH_STAT = 'A'
                     AND ROWNUM = 1;
                  DEBUG.PR_DEBUG('ST',
                                 'location coming in 4 is ' || L_LOCATION);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DEBUG.PR_DEBUG('ST',
                                   'In when no data found for cust ' ||
                                   P_CUST || ' and  ANY MSG TYPE');
                    L_LOCATION := NULL;
                END;
            END;
        END;
    END;
    DEBUG.PR_DEBUG('ST', 'final location coming is ' || L_LOCATION);
    DEBUG.PR_DEBUG('ST', 'Returning successfully from fn_pickup_location');
    RETURN L_LOCATION;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('ST', 'In when others exception' || SQLERRM);
      DEBUG.PR_DEBUG('ST',
                     'error in ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      L_LOCATION := NULL;
      RETURN L_LOCATION;
  END FN_PICKUP_LOCATION;

  FUNCTION FN_UPDATELIMITUTIL(P_ACC IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_BRN IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              
                              P_FLAG IN CHAR,
                              
                              P_ERRCODE  OUT VARCHAR2,
                              P_ERRPARAM OUT VARCHAR2) RETURN BOOLEAN IS
    L_RET    VARCHAR2(30);
    L_AVLBAL ACTBS_HANDOFF.LCY_AMOUNT%TYPE := 0;
    L_AVLAMT ACTBS_HANDOFF.LCY_AMOUNT%TYPE := 0;
  
    L_UNCOL_BASIS       CHAR(1);
    L_UNCOL_FUNDS       NUMBER := 0;
    L_LINKED_AMOUNT     NUMBER;
    L_LMSTRUCT          LMTBS_LINE_UTILS%ROWTYPE;
    L_ACTION            CHAR(1);
    L_FUNC_ID           VARCHAR2(20);
    L_TODLIMIT          STTM_CUST_ACCOUNT.TOD_LIMIT%TYPE;
    L_ACCOUNT_CLASS_REC STTMS_ACCOUNT_CLASS%ROWTYPE;
    L_TRINPUT_STAGE     STTM_BRANCH.END_OF_INPUT%TYPE;
    L_ACCREC            STTMS_CUST_ACCOUNT%ROWTYPE;
  
    L_STTM_ACC_BALANCE STTM_ACCOUNT_BALANCE%ROWTYPE;
  
  BEGIN
    DBG('Inside Fn_updatelimitutil');
  
    IF NOT STPKS_STDCUSAC_UTILS_2.FN_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_CUSTOM.FN_PRE_UPDATELIMITUTIL(P_ACC,
                                                             P_BRN,
                                                             P_FLAG,
                                                             P_ERRCODE,
                                                             P_ERRPARAM) THEN
        DBG('failed in stpks_stdcusac_utils_custom.Fn_Pre_updatelimitutil');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCUSAC_UTILS_2.FN_SKIP_CLUSTER THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_PRE_UPDATELIMITUTIL(P_ACC,
                                                              P_BRN,
                                                              P_FLAG,
                                                              P_ERRCODE,
                                                              P_ERRPARAM) THEN
        DBG('failed in stpks_stdcusac_utils_cluster.Fn_Pre_updatelimitutil');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT STPKS_STDCUSAC_UTILS_2.FN_SKIP_KERNEL THEN
    
      DBG('Inside Fn_updatelimitutil p_acc-->' || P_ACC);
      DBG('Inside Fn_updatelimitutil p_brn-->' || P_BRN);
    
      IF P_ACC IS NOT NULL AND P_BRN IS NOT NULL
      
       THEN
      
        IF NOT CVPKS_UTILS.GET_STTM_CUST_ACC(P_BRN, P_ACC, L_ACCREC) THEN
          DBG('Failed in Getting account details..');
          P_ERRCODE := 'DE-JRN76';
          RETURN FALSE;
        END IF;
      
        IF NOT
            ACPKS_CUSTBAL_PROCESS.FN_GET_STTM_ACCOUNT_BAL(P_BRN,
                                                          P_ACC,
                                                          L_STTM_ACC_BALANCE) THEN
        
          DBG('Failed in Getting account details..');
          P_ERRCODE := 'DE-JRN76';
          RETURN FALSE;
        END IF;
      
        DBG('l_Accrec.Acy_Avl_Bal-->' || L_ACCREC.ACY_AVL_BAL);
      
        IF L_STTM_ACC_BALANCE.ACY_WITHDRAWABLE_BAL < 0 OR
           NVL(P_FLAG, 'N') IN ('Y', 'R') THEN
        
          CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACCREC.ACCOUNT_CLASS,
                                        L_ACCOUNT_CLASS_REC,
                                        P_ERRCODE);
          IF (P_FLAG <> 'R') THEN
            DBG('Getting Available Balance..');
          
            L_AVLBAL := L_STTM_ACC_BALANCE.ACY_WITHDRAWABLE_BAL;
          
            SELECT NVL(UNCOLLECTED_FUNDS_BASIS, 'U'), END_OF_INPUT
              INTO L_UNCOL_BASIS, L_TRINPUT_STAGE
              FROM STTM_BRANCH
             WHERE BRANCH_CODE = P_BRN;
          
            DBG('Getting l_uncol_basis  ' || L_UNCOL_BASIS);
            DBG('Getting l_Accrec.ccy        ' || L_ACCREC.CCY);
          
            IF L_UNCOL_BASIS = 'A' THEN
            
              L_UNCOL_FUNDS := NVL(L_STTM_ACC_BALANCE.WITHDRAWABLE_UNCOLLED_FUND,
                                   0);
            
            ELSE
            
              L_UNCOL_FUNDS := LEAST(NVL(L_ACCREC.UNCOLL_FUNDS_LIMIT, 0),
                                     NVL(L_STTM_ACC_BALANCE.ACY_UNCOLLECTED,
                                         0));
            
            END IF;
            DBG('Getting l_uncol_funds  ' || L_UNCOL_FUNDS);
          
            DBG('avl Bal is - ' || TO_CHAR(L_AVLBAL));
          
            IF (GLOBAL.APPLICATION_DATE BETWEEN L_ACCREC.TOD_START_DATE AND
               NVL(L_ACCREC.TOD_END_DATE, GLOBAL.APPLICATION_DATE + 1)) THEN
              L_TODLIMIT := NVL(L_ACCREC.TOD_LIMIT, 0);
            END IF;
          
            SELECT SUM(B.AVAILABLE_AMOUNT)
              INTO L_LINKED_AMOUNT
              FROM STTM_CUST_ACCOUNT A, STTM_SWEEP_DETAILS B
             WHERE A.BRANCH_CODE = P_BRN
               AND A.CUST_AC_NO = P_ACC
               AND A.CUST_AC_NO = B.CUST_ACCOUNT
               AND A.BRANCH_CODE = B.BRANCH_CODE
               AND NVL(A.MUDARABAH_ACCOUNTS, 'N') = 'Y';
            DBG('l_linked_amounte ' || L_LINKED_AMOUNT);
          
            L_AVLAMT := L_AVLBAL + NVL(L_UNCOL_FUNDS, 0) +
                        NVL(L_TODLIMIT, 0) +
                        NVL(L_ACCREC.REG_CC_AVAILABLE_FUNDS, 0) +
                        NVL(L_LINKED_AMOUNT, 0);
          
            DBG('l_Avlamt ' || L_AVLAMT);
          
            DBG('l_trinput_stage ' || L_TRINPUT_STAGE);
          
            IF NVL(L_TRINPUT_STAGE, 'N') = 'N' THEN
              L_AVLAMT := L_AVLAMT + NVL(L_ACCREC.DAYLIGHT_LIMIT_AMOUNT, 0);
            END IF;
          
            DBG('Giving out the components of avl amt ');
            DBG('1. Avl Bal ' || L_AVLBAL);
            DBG('2. blocked ' || NVL(L_ACCREC.ACY_BLOCKED_AMOUNT, 0));
            DBG('3. Least of uncoll funds limit / acy uncoll - acy unauth uncol ' ||
                LEAST(NVL(L_ACCREC.UNCOLL_FUNDS_LIMIT, 0),
                      
                      NVL((L_STTM_ACC_BALANCE.ACY_UNCOLLECTED -
                          L_ACCREC.ACY_UNAUTH_UNCOLLECTED),
                          
                          0)));
            DBG('4. tank uncol ' || NVL(L_ACCREC.ACY_TANK_UNCOLLECTED, 0));
            DBG('5. unauth tank uncol ' ||
                NVL(L_ACCREC.ACY_UNAUTH_TANK_UNCOLLECTED, 0));
            DBG('6. Sublimit ' || NVL(L_ACCREC.SUBLIMIT, 0));
            DBG('7. Tod Limit ' || L_TODLIMIT);
          
            DBG('Avl Amt is -  ' || TO_CHAR(L_AVLAMT));
          
            DBG('7. Tod Limit ' || L_TODLIMIT);
          
            DBG('Avl Amt is -  ' || TO_CHAR(L_AVLAMT));
          END IF;
          L_LMSTRUCT.IS_ACCOUNT := 'Y';
          L_LMSTRUCT.REF_NO     := P_ACC;
          L_LMSTRUCT.AMT_TAG    := 'BALANCE';
          L_LMSTRUCT.CUST_ID    := L_ACCREC.CUST_NO;
          L_LMSTRUCT.CCY        := L_ACCREC.CCY;
          L_LMSTRUCT.AMT        := L_AVLAMT;
        
          L_LMSTRUCT.UNCOLL := L_UNCOL_FUNDS;
        
          DBG('XXX uncoll         ' || L_UNCOL_FUNDS);
          DBG('XXX tanked uncoll  ' || L_ACCREC.ACY_TANK_UNCOLLECTED);
          DBG('XXX sending uncoll ' || L_LMSTRUCT.UNCOLL);
        
          L_LMSTRUCT.BRANCH         := P_BRN;
          L_LMSTRUCT.PRODUCT        := L_ACCREC.ACCOUNT_CLASS;
          L_LMSTRUCT.LIAB_ID        := NULL;
          L_LMSTRUCT.TENOR_BASIS    := 'N';
          L_LMSTRUCT.TENOR          := 0;
          L_LMSTRUCT.MATURITY_DATE  := NULL;
          L_LMSTRUCT.CTRY_EXPOSURE  := NULL;
          L_LMSTRUCT.MOD_CODE       := 'AC';
          L_LMSTRUCT.TIMESTAMP      := SYSDATE;
          L_LMSTRUCT.TRACK_CUST_EXP := 'Y';
          L_LMSTRUCT.TRACK_PROD_EXP := 'Y';
          L_LMSTRUCT.TRACK_CTRY_EXP := 'Y';
          L_LMSTRUCT.MATURED        := NULL;
          L_LMSTRUCT.MATURED_AMT    := NULL;
          L_ACTION                  := 'N';
        
          DBG('Getting Into Limits');
        
          DBG('l_account_class_rec.ac_class_type :: ' ||
              L_ACCOUNT_CLASS_REC.AC_CLASS_TYPE);
        
          DBG('Limit_Check_Reqd :' ||
              NVL(L_ACCOUNT_CLASS_REC.LIMIT_CHECK_REQUIRED, 'N'));
          IF NVL(L_ACCOUNT_CLASS_REC.AC_CLASS_TYPE, '*') <> 'Y' THEN
          
            IF NVL(L_ACCOUNT_CLASS_REC.LIMIT_CHECK_REQUIRED, 'N') = 'Y' THEN
            
              DBG('Getting Into Limits actually');
            
              IF NVL(L_ACCREC.PROJECT_ACCOUNT, 'N') = 'N' THEN
                DBG('l_Lmstruct.Amt : ' || L_LMSTRUCT.AMT);
                IF L_LMSTRUCT.AMT >= 0 THEN
                  L_LMSTRUCT.AMT := 0;
                END IF;
                DBG('p_flag --> ' || P_FLAG);
              
                IF NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'),
                       'N') = 'Y' THEN
                  IF NOT
                      STPKS_ACCOUNT_NETTING.FN_SET_UTIL_FORNETTEDAC(P_BRN,
                                                                    P_ACC,
                                                                    NULL,
                                                                    L_LMSTRUCT,
                                                                    L_ACCOUNT_CLASS_REC.OVERDRAFT_FACILITY,
                                                                    P_ERRCODE,
                                                                    P_ERRPARAM) THEN
                    DBG('Limits Processing Failed...');
                    P_ERRCODE := 'AC-LIMIT';
                    RETURN FALSE;
                  END IF;
                END IF;
              
                IF NVL(P_FLAG, 'N') IN ('N', 'R') THEN
                  IF NOT LMPKSS.FN_PROCESS_SET_UTIL_BAL(L_LMSTRUCT,
                                                        'ALTER_UTIL',
                                                        L_ACTION,
                                                        P_BRN,
                                                        P_ACC,
                                                        NULL,
                                                        NULL,
                                                        L_ACCREC.NETTING_REQUIRED,
                                                        P_ERRCODE,
                                                        P_ERRPARAM) THEN
                    DBG('Limits Processing Failed...');
                    P_ERRCODE := 'AC-LIMIT';
                    RETURN FALSE;
                  END IF;
                
                ELSIF P_FLAG = 'Y' THEN
                  IF NOT LMPKSS.FN_PROCESS_SET_UTIL_BAL(L_LMSTRUCT,
                                                        'ALTER_UTIL',
                                                        L_ACTION,
                                                        P_BRN,
                                                        P_ACC,
                                                        NULL,
                                                        NULL,
                                                        L_ACCREC.NETTING_REQUIRED,
                                                        P_ERRCODE,
                                                        P_ERRPARAM,
                                                        P_FLAG) THEN
                  
                    DBG('Limits Processing Failed...');
                    OVPKS.PR_APPENDTBL(P_ERRCODE, P_ERRPARAM);
                  END IF;
                END IF;
                DBG('Limits Processing done.');
              END IF;
            END IF;
          END IF;
          DBG('Out of balance update with ...: ' || L_RET);
        END IF;
      END IF;
    
    END IF;
    STPKS_STDCUSAC_UTILS_2.PR_SET_ACTIVATE_KERNEL;
  
    DBG('Returned successfully from Fn_updatelimitutil');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others exception of Fn_updatelimitutil' || SQLERRM);
      DBG('error in ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_UPDATELIMITUTIL;

END STPKS_STDCUSAC_UTILS_2;
