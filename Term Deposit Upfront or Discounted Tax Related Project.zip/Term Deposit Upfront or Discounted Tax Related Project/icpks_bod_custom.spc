CREATE OR REPLACE PACKAGE icpks_bod_custom AS
/*------------------------------------------------------------------------------------------
** This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
** Copyright © 2013 - 2013  Oracle and/or its affiliates.  All rights reserved.
**
** No part of this work may be reproduced, stored in a retrieval system,
** adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
** translated in any language or computer language,
** without the prior written permission of Oracle and/or its affiliates.
**
**
** Oracle Financial Services Software Limited.
** Oracle Park, Off Western Express Highway,
** Goregaon (East),
** Mumbai - 400 063, India.
------------------------------------------------------------------------------------------
*/
/*
-------------------------------------------------------------------------------------
CHANGE HISTORY

New package
Created BY : Vibilash A

   Changed By                : Nalandhan G
   Changed On                : 02-Sep-2013
   Change Description        : Extensibility Hook Changes
   Search string             : 9NT1606_12.0.2_RETRO_17397208

  Changed by                : Naveen A
  Changed On                 : 03-Feb-2014
  Change Description        : Hook changes required
  Search string             : 9NT1606_12.0.2_INATAHK_18158594
                                : 9NT1606_12.0.2_INATAHK_18158809
**
** Modified By             : Shayam Sundar Ragunathan
** Modified On             : 21-May-2014
** Modified Reason         : Hook Changes for fn_payment_txn
** Search String           : 9NT1606_12.0.3_INATAHK_RETRO_18804511

** Modified By             : KaviyarasuV
** Modified On             : 20-Jun-2014
** Modified Reason         : Hooks changes provided as per request.
** Search String           : 9NT1606_INTERNAL_12.0.3_SFR#19028569
** Retro String            : 9NT1606_INATAHK_12.0.2_SFR#18718323

  Changed by          : Jumrose M
  Changed On          : 24-June-2014
  Change Description  : Hook changes required
  Search string       : 9NT1606_12.0.3_RETRO_19051954

   Modified By           : Gowthami R
   Modified On           : 25-Jun-2014
   Modified Reason       : Hook retro changes
   Search String         : 9NT1606_12.0.3_RETRO_SFR#19061668

   Modified By           : Gowthami R
   Modified On           : 26-Jun-2014
   Modified Reason       : Hook retro changes
   Search String         : 9NT1606_12.0.3_RETRO_SFR#19069981

** Modified By         : Chaatravi
** Modified On         : 14-Sept-2016
** Modified Reason     : Hook provided as requested. (Retro : 22922586)
** Search string       : 12.2_EXTN_23658544

** Changed By           : Nidhi Verma
** Changed On	        : 30-Mar-2017
** Change Description   : Hooks Given.
** Search String        : Bug#25561985

Modified By         :Nidhi Verma
Modified On         : 12-Apr-2017
Modified Reason     : Provided Extensible hooks.
Search String       : Bug#25821355

Modified By        : Saisudha Rathinavelu
Modified On        : 26-July-2017
Modified Reason    : Retro for hook change bug id 26484731.
Search String      : 12.4_RETRO_Bug#26525040

Modified By         : Dekyi
Modified On         : 29-Oct-2018
Modified Reason     : EHD Ref: BMOCH_12.4_18_OCT_2018_01_0000.
Search String       : 12.4_EXTN_28846544
--------------------------------------------------------------------------------------------------------
*/

--sampath starts
  G_TD_UPFRONT_ROLLOVER_AMT_FLAG CHAR(1);
--sampath ends
  
FUNCTION icfn_bod(p_brn     VARCHAR2,
                    p_dt      DATE,
                    p_process NUMBER, -- DAB Tuning Changes are Retroed for UBSW    -- Kernel10.0 IC Parallel
                    p_fn_Call_id IN  NUMBER,
          p_tb_custom_Data IN OUT Global.ty_Tb_custom_Data) RETURN NUMBER;

    --9NT1606_12.0.2_RETRO_17397208 changes starts
  PROCEDURE  pr_rollover_deposit(p_Fn_Call_ID  Number,
                     p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
  PROCEDURE  Pr_Auto_Extension_Deposit(p_Fn_Call_ID  Number,
                           p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
  PROCEDURE  pr_maturity_deposit(p_Fn_Call_ID  NUMBER,
                     p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data);
  --9NT1606_12.0.2_RETRO_17397208 Changes Ends
  --9NT1606_12.0.2_INATAHK_18158594 changes starts
  FUNCTION fn_superscribe_ic(p_brn         IN OUT VARCHAR2,
                             p_account     IN OUT VARCHAR2,
                             p_ty_stdcusac IN OUT stpks_stdcusac_main.ty_stdcusac,
                             p_ty_icctdfpo IN OUT icpks_icctdfpo_main.ty_icctdfpo,
                             p_source      IN VARCHAR2,
               p_Fn_Call_ID  Number,
               p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data) RETURN BOOLEAN;
  PROCEDURE pr_liqdby_td(p_Fn_Call_ID  Number,
             p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
  PROCEDURE Pr_Pop_New_Rates_During_Roll(p_acc IN ictms_Acc.acc%TYPE,
                     p_brn IN ictms_acc.brn%TYPE,
                     p_ccy IN sttms_cust_account.ccy%TYPE,
                     p_aclass IN  sttms_cust_account.account_class%TYPE,
                     p_prod   IN ictbs_acc_pr.prod%TYPE,
                     p_process_dt IN DATE,
                     p_Fn_Call_ID  Number,
                     p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
  --9NT1606_12.0.2_INATAHK_18158594 changes ends
  --9NT1606_12.0.2_INATAHK_18158809 CHANGES STARTS
  FUNCTION fn_td_book(tdacc     IN sttm_cust_account.cust_ac_no%TYPE,
                      tdbrn     IN sttm_cust_account.branch_code%TYPE,
                      tdccy     IN sttm_cust_account.ccy%TYPE,
                      err_code  OUT ertbs_msgs.err_code%TYPE,
                      err_param OUT ertbs_msgs.message%TYPE,
            p_Fn_Call_ID  Number,
            p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data)
            RETURN BOOLEAN;
  --9NT1606_12.0.2_INATAHK_18158809 CHANGES ENDS
    --9NT1606_12.0.3_RETRO_SFR#19061668 Starts
  FUNCTION fn_reinstate_deposit(p_branch          ictms_acc.brn%TYPE,
                                  p_acc             ictms_acc.acc%TYPE,
                                  p_nxt_maturity_dt ictms_acc.maturity_date%TYPE,
                                  p_err_code        IN OUT ertbs_msgs.err_code%TYPE,
                                  p_err_msg         IN OUT ertbs_msgs.message%TYPE,
                                  p_Fn_Call_ID      Number,
                                  p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data)
  RETURN BOOLEAN;
  --9NT1606_12.0.3_RETRO_SFR#19061668 Ends

--9NT1606_12.0.3_INATAHK_RETRO_18804511 starts
FUNCTION fn_payment_txn(p_xref             IN VARCHAR2,
                        p_branch_code      IN sttms_cust_account.branch_code%TYPE,
                        p_acc_no           IN sttms_cust_account.cust_ac_no%TYPE,
                        p_ccy              IN VARCHAR2,
                        p_trndt            IN DATE,
                        p_redmamt          IN NUMBER,
                        p_key              IN VARCHAR2,
                        p_pcpayoutdets_rec IN OUT ictm_pcpayout_details%ROWTYPE,
                        p_err_code         IN OUT VARCHAR2,
                        p_err_msg          IN OUT VARCHAR2,
                        p_Fn_Call_ID       IN OUT NUMBER,
                        p_Tb_Custom_Data   IN OUT Global.Ty_Tb_Custom_Data)
RETURN BOOLEAN;
--9NT1606_12.0.3_INATAHK_RETRO_18804511 ends
--9NT1606_INTERNAL_12.0.3_SFR#19028569 Starts
PROCEDURE pr_liquidate_interest(p_Fn_Call_ID  Number,
                                p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
--9NT1606_INTERNAL_12.0.3_SFR#19028569 Ends
  --9NT1606_12.0.3_RETRO_19051954 changes starts
  PROCEDURE pr_set_tbhandoff(p_amt_tag      IN VARCHAR2,
                             p_tag_ccy      IN VARCHAR2,
                             p_tag_amt      IN sttms_cust_account.acy_avl_bal%TYPE,
                             p_brn          IN VARCHAR2,
                             p_acc          IN VARCHAR2,
                             p_ccy          IN VARCHAR2,
                             pkg_lookup_row IN BINARY_INTEGER,
                             p_tag_amt_lcy  IN OUT sttms_cust_account.acy_avl_bal%TYPE,
                             p_xrate        IN OUT actbs_handoff.exch_rate%TYPE,
               p_Fn_Call_ID       Number,
                             p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data);
  PROCEDURE pr_set_tbhandoff_dcd(p_td_acc       IN VARCHAR2,
                                 p_amt_tag      IN VARCHAR2,
                                 p_tag_ccy      IN VARCHAR2,
                                 p_tag_amt      IN sttms_cust_account.acy_avl_bal%TYPE,
                                 p_brn          IN VARCHAR2,
                                 p_acc          IN VARCHAR2,
                                 p_ccy          IN VARCHAR2,
                                 pkg_lookup_row IN BINARY_INTEGER,
                                 p_tag_amt_lcy  IN OUT sttms_cust_account.acy_avl_bal%TYPE,
                                 p_xrate        IN OUT actbs_handoff.exch_rate%TYPE,
                 p_Fn_Call_ID       Number,
                 p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data);

    PROCEDURE pr_liquidate_princ(pkg_lookup_row IN BINARY_INTEGER,
                  p_Fn_Call_ID       Number,
               p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data);
  --9NT1606_12.0.3_RETRO_19051954 changes ends
  --9NT1606_12.0.3_RETRO_SFR#19069981    starts

FUNCTION fn_populate_tdrollover (p_acc IN sttm_cust_account.cust_ac_no%TYPE,
                                  p_brn IN sttm_cust_account.branch_code%TYPE,
                  p_product IN ictbs_acc_pr.prod%TYPE,
                  p_acy_avl_bal IN sttm_cust_account.acy_avl_bal%TYPE,
                                  p_ictm_acc IN icpks_bod.cr_ictm_acc%ROWTYPE,
                                  p_rollover_amt IN ictms_acc.rollover_amt%TYPE,
                                  p_errcode OUT VARCHAR2,
                                  p_errmsg OUT VARCHAR2,
                                  p_Fn_Call_ID  Number,
                                  p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
RETURN BOOLEAN;

 ---9NT1606_12.0.3_RETRO_SFR#19069981    Ends

 --12.2_EXTN_23658544 Changes starts
 PROCEDURE pr_liqdby_pc(p_Fn_Call_ID  Number,
                        p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
 --12.2_EXTN_23658544 Changes ends
   --Bug#25561985 starts
 FUNCTION fn_manualrollover_addlamt(p_redem_ref_no IN VARCHAR2,
                                   p_brn IN VARCHAR2,
                                   p_acc IN VARCHAR2,
                                   p_ccy IN VARCHAR2,
                                   p_cust IN VARCHAR2,
                                   p_err_code OUT VARCHAR2,
                                   p_err_params OUT varchar2,
                                   p_Fn_Call_ID  Number,
                                   p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
RETURN BOOLEAN;
 --Bug#25561985 ends
 --Bug#25821355 Changes starts here
FUNCTION FN_LIQUIDATE_DEBIT_INT(P_BRANCH         IN VARCHAR2,
                                  P_BOOK_ACC       IN ICTBS_DR_INT_DUE.BOOK_ACC%TYPE,
                                  P_VALUE_DT       IN ICTBS_DR_INT_DUE.DUE_DT%TYPE,
                                  P_MODE           IN VARCHAR2,
                                  P_PROD_TYPE      IN VARCHAR2,
                                  P_ERR_CODE       OUT VARCHAR2,
                                  P_ERR_MSG        OUT VARCHAR2,
                                  P_FN_CALL_ID     NUMBER,
                                  P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN;
--Bug#25821355 Changes ends here
--12.4_RETRO_Bug#26525040 Changes starts here
PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2);

FUNCTION fn_pre_payment_txn_1405(p_detb_rtl_teller_rec IN detbs_rtl_teller%ROWTYPE,
                        p_trndt            IN DATE,
                        p_txnamt           IN NUMBER,
                        p_key              IN VARCHAR2,
                        p_pcpayoutdets_rec IN OUT detbs_pctrn%ROWTYPE,
                        p_err_code         IN OUT VARCHAR2,
                        p_err_msg          IN OUT VARCHAR2)
RETURN BOOLEAN;
--12.4_RETRO_Bug#26525040 Changes ends here
--12.4_EXTN_28846544 starts
PROCEDURE  pr_rollover_deposit (p_pr_int_aclass IN OUT ictms_pr_int_aclass%ROWTYPE,
                                p_Fn_Call_ID  NUMBER,
                                p_Tb_Custom_Data  IN OUT Global.Ty_Tb_Custom_Data);
--12.4_EXTN_28846544 ends
END icpks_bod_custom;
