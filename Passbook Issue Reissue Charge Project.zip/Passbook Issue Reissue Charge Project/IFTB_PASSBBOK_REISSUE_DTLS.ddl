-- Create table
create table IFTB_PASSBBOK_REISSUE_DTLS
(
  xrefid      VARCHAR2(16) PRIMARY KEY,
  reissue_val CHAR(1)
)