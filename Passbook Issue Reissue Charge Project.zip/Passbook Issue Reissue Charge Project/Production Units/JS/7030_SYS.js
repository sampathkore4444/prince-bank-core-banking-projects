/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2020, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : 7030_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = '';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_CATMS_PASSBOOK_DETAILS":"BRN~ACC~PASSBOOKNO~STATUS~REMARKS~PASSBOOKTYPE~PREVPASSBOOKNO~XREF~REFERENCE_NO~ADD1~ADD2~ADD3~ADD4~AC_DESC~CUSTNO~CCY~CHGACCOUNT~CHGACCDESC~CHGACCBRN~CHGCUSTID~CHGPKPDN~CHAR_FIELD20"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_CATMS_PASSBOOK_DETAILS">BRN~ACC~PASSBOOKNO~STATUS~REMARKS~PASSBOOKTYPE~PREVPASSBOOKNO~XREF~REFERENCE_NO~ADD1~ADD2~ADD3~ADD4~AC_DESC~CUSTNO~CCY~CHGACCOUNT~CHGACCDESC~CHGACCBRN~CHGCUSTID~CHGPKPDN~CHAR_FIELD20</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_CATMS_PASSBOOK_DETAILS" : ""}; 

 var dataSrcLocationArray = new Array("BLK_CATMS_PASSBOOK_DETAILS"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside 7030.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside 7030.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_CATMS_PASSBOOK_DETAILS__BRN";
pkFields[0] = "BLK_CATMS_PASSBOOK_DETAILS__BRN";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_CATMS_PASSBOOK_DETAILS__BRN__LOV_BRANCH":["BLK_CATMS_PASSBOOK_DETAILS__BRN~~","","",""],"BLK_CATMS_PASSBOOK_DETAILS__ACC__LOV_ACC_PB_Y":["BLK_CATMS_PASSBOOK_DETAILS__ACC~BLK_CATMS_PASSBOOK_DETAILS__AC_DESC~BLK_CATMS_PASSBOOK_DETAILS__CUSTNO~BLK_CATMS_PASSBOOK_DETAILS__CCY~BLK_CATMS_PASSBOOK_DETAILS__PASSBOOKNO~BLK_CATMS_PASSBOOK_DETAILS__STATUS~BLK_CATMS_PASSBOOK_DETAILS__PREV_PASSBOOK_STATUS~","BLK_CATMS_PASSBOOK_DETAILS__BRN!","N~N~N~N~N~N~N",""],"BLK_CATMS_PASSBOOK_DETAILS__PASSBOOKTYPE__LOV_STOCKCD":["BLK_CATMS_PASSBOOK_DETAILS__PASSBOOKTYPE~~","BLK_CATMS_PASSBOOK_DETAILS__CCY!","N~N",""],"BLK_CATMS_PASSBOOK_DETAILS__CHGACCOUNT__LOV_CUSAC_CHG":["BLK_CATMS_PASSBOOK_DETAILS__CHGACCOUNT~BLK_CATMS_PASSBOOK_DETAILS__CHGCUSTID~BLK_CATMS_PASSBOOK_DETAILS__CHGACCDESC~BLK_CATMS_PASSBOOK_DETAILS__CHGACCBRN~","","N~N~N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CHCD~BLK_CATMS_PASSBOOK_DETAILS","STCPBHIS~BLK_CATMS_PASSBOOK_DETAILS"); 

 var CallFormRelat=new Array("CATMS_PASSBOOK_DETAILS.XREF=CSTBS_WBCHARGE_DETAILS.XREF","CATMS_PASSBOOK_DETAILS.CUST_AC_NO = CATMS_PASSBOOK_LOG__A.ACCOUNT AND CATMS_PASSBOOK_DETAILS.BRANCH_CODE = CATMS_PASSBOOK_LOG__A.BRANCH AND CATMS_PASSBOOK_DETAILS.PASSBOOK_NUMBER = CATMS_PASSBOOK_LOG__A.PASSBOOK_NUMBER"); 

 var CallRelatType= new Array("N","1"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["7030"]="KERNEL";
ArrPrntFunc["7030"]="";
ArrPrntOrigin["7030"]="";
ArrRoutingType["7030"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["7030"]="N";
ArrCustomModified["7030"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CHCD":"","STCPBHIS":""};
var scrArgSource = {"CHCD":"","STCPBHIS":""};
var scrArgVals = {"CHCD":"","STCPBHIS":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CHCD":"","STCPBHIS":""};
var dpndntOnSrvs = {"CHCD":"","STCPBHIS":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
callformTabArray["CVS_MAIN__TAB_MAIN"] = "STCPBHIS";
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {"QUERY":"2","NEW":"2","MODIFY":"2","AUTHORIZE":"1","DELETE":"1","CLOSE":"1","REOPEN":"1","REVERSE":"1","ROLLOVER":"1","CONFIRM":"1","LIQUIDATE":"1","SUMMARYQUERY":"1"};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------