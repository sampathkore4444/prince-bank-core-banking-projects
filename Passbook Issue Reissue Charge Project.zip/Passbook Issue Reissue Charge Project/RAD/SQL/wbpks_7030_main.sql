CREATE OR REPLACE PACKAGE BODY wbpks_7030_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : wbpks_7030_main.sql
     **
     ** Module     : FLEXCUBE Web Branch
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2020 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Ui_Name            VARCHAR2(50) := '7030';
   g_7030         wbpks_7030_Main.ty_7030;
   g_Req_Key                 VARCHAR2(32767);
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Kernel    BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      IF debug.pkg_debug_on <> 2 THEN
         l_Msg := 'wbpks_7030_Main ==>'||p_Msg;
         Debug.Pr_Debug('WB' ,l_Msg);
      END IF;
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := '7030';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      wbpks_7030_Kernel.Pr_Skip_Handler (P_Stage);
      wbpks_7030_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Kernel IS
   BEGIN
      g_Skip_Kernel := TRUE;
   END Pr_Set_Skip_Kernel;
   PROCEDURE Pr_Set_Activate_Kernel IS
   BEGIN
      g_Skip_Kernel := FALSE;
   END Pr_Set_Activate_Kernel;
   FUNCTION  Fn_Skip_Kernel RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type = Cspks_Req_Global.p_Kernel THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Kernel;
      END IF;
   END  Fn_Skip_Kernel;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Build_Fc_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_7030       IN   OUT wbpks_7030_Main.ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;

   BEGIN

      dbg('In Fn_Sys_Build_Fc_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node = 'BLK_CATMS_PASSBOOK_DETAILS' THEN
            p_7030.v_catms_passbook_details.BRANCH := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.ACCOUNT := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.PASSBOOK_NUMBER := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.STATUS := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.REMARKS := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.PASSBOOKTYPE := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.OLD_PASS_BOOK_NO := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.XREF := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_catms_passbook_details.REFERENCE_NO := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.ADDRESS1 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.ADDRESS2 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.ADDRESS3 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.ADDRESS4 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.AC_DESC := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.CUST_NO := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.CCY := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD1 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD2 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD3 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD4 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD5 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_cstbs_ui_columns.CHAR_FIELD20 := Cspks_Req_Global.Fn_GetVal;
            p_7030.v_sttms_cust_account.branch_code :=p_7030.v_catms_passbook_details.branch;
            p_7030.v_sttms_cust_account.cust_ac_no :=p_7030.v_catms_passbook_details.account;
            p_7030.v_cstbs_ui_columns.char_field1 :=p_7030.v_catms_passbook_details.account;
         ELSIF  l_Node = '' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            p_7030.Ty_chcd := NULL;
            l_key_vals :='XREF'||'>'||p_7030.v_catms_passbook_details.XREF;
            Dbg('Calling Chpks_Chcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Chpks_Chcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_7030.Ty_chcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Chpks_Chcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node = 'BLK_MAIN' THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='STCPBHIS_'||p_Action_Code;
            END IF;
            p_7030.Ty_stcpbhis := NULL;
            l_key_vals :='ACCOUNT~BRANCH~PASSBOOK_NUMBER'||'>'||p_7030.v_catms_passbook_details.CUST_AC_NO||'~'||p_7030.v_catms_passbook_details.BRANCH_CODE||'~'||p_7030.v_catms_passbook_details.PASSBOOK_NUMBER;
            Dbg('Calling Stpks_Stcpbhis_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Stpks_Stcpbhis_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'STCPBHIS',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_7030.Ty_stcpbhis,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_7030.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Type;
   FUNCTION Fn_Sys_Build_Ws_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_7030       IN   OUT wbpks_7030_Main.ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Pk_counter        NUMBER :=1;
      l_Count             NUMBER;
      l_Parent_Rec        NUMBER :=0;
      l_Key               VARCHAR2(255);
      l_Pkey              VARCHAR2(32767);
      l_PVal              VARCHAR2(32767);
      l_Val               VARCHAR2(32767);
      l_Tag               VARCHAR2(100);
      l_Node              VARCHAR2(100);
      l_Key_Vals          VARCHAR2(32767);
      l_Key_Tags          VARCHAR2(32767);
      l_Source_Operation  VARCHAR2(100) := p_Source_Operation;
      Invalid_Date        EXCEPTION;

   BEGIN

      dbg('In Fn_Sys_Build_Ws_Type..');

      l_Node := Cspks_Req_Global.Fn_GetNode;
      WHILE (l_Node <> 'EOPL')
      LOOP
         --Dbg('Node Name  :'||l_Node);
         IF  l_Node IN ( 'BLK_CATMS_PASSBOOK_DETAILS','Catms-Passbook-Details-Full','Catms-Passbook-Details-IO') THEN
            l_Key       := Cspks_Req_Global.Fn_GetTag;
            l_Val       := Cspks_Req_Global.Fn_GetVal;
            WHILE (l_Key <> 'EOPL')
            LOOP
               --dbg('Key/Value   :'||l_Key ||':'||l_Val);
               IF l_Key = 'BRN' THEN
                  p_7030.v_catms_passbook_details.BRANCH := l_Val;
               ELSIF l_Key = 'ACC' THEN
                  p_7030.v_catms_passbook_details.ACCOUNT := l_Val;
               ELSIF l_Key = 'PASSBOOKNO' THEN
                  p_7030.v_catms_passbook_details.PASSBOOK_NUMBER := l_Val;
               ELSIF l_Key = 'STATUS' THEN
                  p_7030.v_catms_passbook_details.STATUS := l_Val;
               ELSIF l_Key = 'REMARKS' THEN
                  p_7030.v_catms_passbook_details.REMARKS := l_Val;
               ELSIF l_Key = 'PASSBOOKTYPE' THEN
                  p_7030.v_catms_passbook_details.PASSBOOKTYPE := l_Val;
               ELSIF l_Key IN( 'PREV_PASSBOOK_NO','PREVPASSBOOKNO')  THEN
                  p_7030.v_catms_passbook_details.OLD_PASS_BOOK_NO := l_Val;
               ELSIF l_Key IN( 'EXTERNAL_REFERENCE_NUMEBR','XREF')  THEN
                  p_7030.v_catms_passbook_details.XREF := l_Val;
               ELSIF l_Key = 'REFERENCE_NO' THEN
                  p_7030.v_catms_passbook_details.REFERENCE_NO := l_Val;
               ELSIF l_Key = 'ADD1' THEN
                  p_7030.v_sttms_cust_account.ADDRESS1 := l_Val;
               ELSIF l_Key = 'ADD2' THEN
                  p_7030.v_sttms_cust_account.ADDRESS2 := l_Val;
               ELSIF l_Key = 'ADD3' THEN
                  p_7030.v_sttms_cust_account.ADDRESS3 := l_Val;
               ELSIF l_Key = 'ADD4' THEN
                  p_7030.v_sttms_cust_account.ADDRESS4 := l_Val;
               ELSIF l_Key = 'AC_DESC' THEN
                  p_7030.v_sttms_cust_account.AC_DESC := l_Val;
               ELSIF l_Key = 'CUSTNO' THEN
                  p_7030.v_sttms_cust_account.CUST_NO := l_Val;
               ELSIF l_Key = 'CCY' THEN
                  p_7030.v_sttms_cust_account.CCY := l_Val;
               ELSIF l_Key IN( 'CHGACC','CHGACCOUNT')  THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD1 := l_Val;
               ELSIF l_Key = 'CHGACCDESC' THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD2 := l_Val;
               ELSIF l_Key = 'CHGACCBRN' THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD3 := l_Val;
               ELSIF l_Key = 'CHGCUSTID' THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD4 := l_Val;
               ELSIF l_Key = 'CHGPKPDN' THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD5 := l_Val;
               ELSIF l_Key = 'CHAR_FIELD20' THEN
                  p_7030.v_cstbs_ui_columns.CHAR_FIELD20 := l_Val;
               END IF;
               l_Key       := Cspks_Req_Global.Fn_GetTag;
               l_Val       := Cspks_Req_Global.Fn_GetVal;
            END LOOP;
            p_7030.v_sttms_cust_account.branch_code :=p_7030.v_catms_passbook_details.branch;
            p_7030.v_sttms_cust_account.cust_ac_no :=p_7030.v_catms_passbook_details.account;
            p_7030.v_cstbs_ui_columns.char_field1 :=p_7030.v_catms_passbook_details.account;
         ELSIF  l_Node IN ( '','') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            p_7030.Ty_chcd := NULL;
            l_key_vals :='XREF'||'>'||p_7030.v_catms_passbook_details.XREF;
            Dbg('Calling Chpks_Chcd_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Chpks_Chcd_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_7030.Ty_chcd,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Chpks_Chcd_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         ELSIF  l_Node IN ( 'BLK_MAIN','Main') THEN
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='STCPBHIS_'||p_Action_Code;
            END IF;
            p_7030.Ty_stcpbhis := NULL;
            l_key_vals :='ACCOUNT~BRANCH~PASSBOOK_NUMBER'||'>'||p_7030.v_catms_passbook_details.CUST_AC_NO||'~'||p_7030.v_catms_passbook_details.BRANCH_CODE||'~'||p_7030.v_catms_passbook_details.PASSBOOK_NUMBER;
            Dbg('Calling Stpks_Stcpbhis_Main.Fn_Build_Type..');
            Cspks_Req_Global.Pr_Rewind_By_One;
            IF NOT Stpks_Stcpbhis_Main.Fn_Build_Type(p_Source,
               l_Source_Operation,
               'STCPBHIS',
               p_Action_Code,
               p_Function_Id,
               l_Key_Vals,
               p_Addl_Info ,
               p_7030.Ty_stcpbhis,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Build_Type..');
               RETURN FALSE;
            END IF;
            Cspks_Req_Global.Pr_Rewind_By_One;

         END IF;
         l_Node := Cspks_Req_Global.Fn_GetNode;
      END LOOP;

      p_7030.Addl_Info := p_Addl_Info;
      Dbg('Returning Success From Fn_Sys_Build_Fc_Type.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN Invalid_Date THEN
         Pr_Log_Error(p_Source,'ST-OTHR-003',l_Key||'~'||Cspks_Req_Global.g_Date_Format) ;
         RETURN FALSE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Sys_Build_Fc_Type ');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Type;
   FUNCTION Fn_Sys_Build_Fc_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_7030          IN wbpks_7030_Main.ty_7030,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Fc_Ts..');

      --Dbg('Building Childs Of :..');
      l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
      l_Level_Format      := l_0_Lvl_Counter;
      Cspks_Req_Global.Pr_Write('P','BLK_CATMS_PASSBOOK_DETAILS',l_Level_Format);
      Cspks_Req_Global.Pr_Write('V','BRN',p_7030.v_catms_passbook_details.branch);
      Cspks_Req_Global.Pr_Write('V','ACC',p_7030.v_catms_passbook_details.account);
      Cspks_Req_Global.Pr_Write('V','PASSBOOKNO',p_7030.v_catms_passbook_details.passbook_number);
      Cspks_Req_Global.Pr_Write('V','STATUS',p_7030.v_catms_passbook_details.status);
      Cspks_Req_Global.Pr_Write('V','REMARKS',p_7030.v_catms_passbook_details.remarks);
      Cspks_Req_Global.Pr_Write('V','PASSBOOKTYPE',p_7030.v_catms_passbook_details.passbooktype);
      Cspks_Req_Global.Pr_Write('V','PREVPASSBOOKNO',p_7030.v_catms_passbook_details.old_pass_book_no);
      Cspks_Req_Global.Pr_Write('V','XREF',p_7030.v_catms_passbook_details.xref);
      Cspks_Req_Global.Pr_Write('V','REFERENCE_NO',p_7030.v_catms_passbook_details.reference_no);
      Cspks_Req_Global.Pr_Write('V','ADD1',p_7030.v_sttms_cust_account.address1);
      Cspks_Req_Global.Pr_Write('V','ADD2',p_7030.v_sttms_cust_account.address2);
      Cspks_Req_Global.Pr_Write('V','ADD3',p_7030.v_sttms_cust_account.address3);
      Cspks_Req_Global.Pr_Write('V','ADD4',p_7030.v_sttms_cust_account.address4);
      Cspks_Req_Global.Pr_Write('V','AC_DESC',p_7030.v_sttms_cust_account.ac_desc);
      Cspks_Req_Global.Pr_Write('V','CUSTNO',p_7030.v_sttms_cust_account.cust_no);
      Cspks_Req_Global.Pr_Write('V','CCY',p_7030.v_sttms_cust_account.ccy);
      Cspks_Req_Global.Pr_Write('V','CHGACCOUNT',p_7030.v_cstbs_ui_columns.char_field1);
      Cspks_Req_Global.Pr_Write('V','CHGACCDESC',p_7030.v_cstbs_ui_columns.char_field2);
      Cspks_Req_Global.Pr_Write('V','CHGACCBRN',p_7030.v_cstbs_ui_columns.char_field3);
      Cspks_Req_Global.Pr_Write('V','CHGCUSTID',p_7030.v_cstbs_ui_columns.char_field4);
      Cspks_Req_Global.Pr_Write('V','CHGPKPDN',p_7030.v_cstbs_ui_columns.char_field5);
      Cspks_Req_Global.Pr_Write('V','CHAR_FIELD20',p_7030.v_cstbs_ui_columns.char_field20);
      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      IF NOT Chpks_Chcd_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         p_7030.ty_chcd,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      l_Level_Format      := l_0_Lvl_Counter;
      l_Cntr_Before := l_Master_Childs;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='STCPBHIS_'||p_Action_Code;
      END IF;
      IF NOT Stpks_Stcpbhis_Main.Fn_Build_Ts_List(p_source,
         l_Source_Operation,
         'STCPBHIS',
         p_Action_Code,
         p_Function_Id,
         p_7030.ty_stcpbhis,
         l_Level_Format,
         l_1_Lvl_Counter,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         RETURN FALSE;
      END IF;
      l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

      Dbg('Returning Success From Fn_Sys_Build_Fc_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Fc_Ts;
   FUNCTION Fn_Sys_Build_Ws_Ts (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Exchange_Pattern IN       VARCHAR2,
      p_7030          IN wbpks_7030_Main.ty_7030,
      p_Err_Code        IN OUT VARCHAR2,
      p_Err_Params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Level_Format  VARCHAR2(32767);
      l_Parent_Format VARCHAR2(32767);
      l_Date_Val      VARCHAR2(32767);
      l_Master_Childs NUMBER := 0;
      l_Desc_Vc          VARCHAR2(32767);
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Key_Cols          VARCHAR2(32767);
      l_Key_Vals          VARCHAR2(32767);
      l_0_Lvl_Counter NUMBER := 0;
      l_1_Lvl_Counter NUMBER := 0;
      l_Cntr_Before   NUMBER := 0;
      l_Master_Where  VARCHAR2(32767);
      l_Count         NUMBER := 0;

   BEGIN
      Dbg('In Fn_Sys_Build_Ws_Ts..');
      IF SUBSTR(p_Exchange_Pattern,3,4) = 'FS' THEN
         Dbg('Building Full Screen Reply..');

         --Dbg('Building Childs Of :..');
         IF ( (  p_7030.v_catms_passbook_details.branch IS NOT NULL 
         AND  p_7030.v_catms_passbook_details. account IS NOT NULL 
         AND  p_7030.v_catms_passbook_details. passbook_number IS NOT NULL 
         AND  p_7030.v_catms_passbook_details. reference_no IS NOT NULL 
          ) OR(  p_7030.v_sttms_cust_account.branch_code IS NOT NULL 
         AND  p_7030.v_sttms_cust_account.cust_ac_no IS NOT NULL 
          ) OR(  p_7030.v_cstbs_ui_columns.char_field1 IS NOT NULL 
          ) )
          THEN
            l_0_Lvl_Counter   := l_0_Lvl_Counter +1;
            l_Level_Format      := l_0_Lvl_Counter;
            Cspks_Req_Global.Pr_Write('P','Catms-Passbook-Details-Full',l_Level_Format);
            Cspks_Req_Global.Pr_Write('V','BRN',p_7030.v_catms_passbook_details.branch);
            Cspks_Req_Global.Pr_Write('V','ACC',p_7030.v_catms_passbook_details.account);
            Cspks_Req_Global.Pr_Write('V','PASSBOOKNO',p_7030.v_catms_passbook_details.passbook_number);
            Cspks_Req_Global.Pr_Write('V','STATUS',p_7030.v_catms_passbook_details.status);
            Cspks_Req_Global.Pr_Write('V','REMARKS',p_7030.v_catms_passbook_details.remarks);
            Cspks_Req_Global.Pr_Write('V','PASSBOOKTYPE',p_7030.v_catms_passbook_details.passbooktype);
            Cspks_Req_Global.Pr_Write('V','EXTERNAL_REFERENCE_NUMEBR',p_7030.v_catms_passbook_details.xref);
            Cspks_Req_Global.Pr_Write('V','AC_DESC',p_7030.v_sttms_cust_account.ac_desc);
            Cspks_Req_Global.Pr_Write('V','CUSTNO',p_7030.v_sttms_cust_account.cust_no);
            Cspks_Req_Global.Pr_Write('V','CHGACC',p_7030.v_cstbs_ui_columns.char_field1);
            Cspks_Req_Global.Pr_Write('V','CHGACCDESC',p_7030.v_cstbs_ui_columns.char_field2);
            Cspks_Req_Global.Pr_Write('V','CHGACCBRN',p_7030.v_cstbs_ui_columns.char_field3);
            Cspks_Req_Global.Pr_Write('V','CHGCUSTID',p_7030.v_cstbs_ui_columns.char_field4);
            Cspks_Req_Global.Pr_Write('V','CHAR_FIELD20',p_7030.v_cstbs_ui_columns.char_field20);
            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='CHCD_'||p_Action_Code;
            END IF;
            IF NOT Chpks_Chcd_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'CHCD',
               p_Action_Code,
               p_Function_Id,
               p_7030.ty_chcd,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

            l_Level_Format      := l_0_Lvl_Counter;
            l_Cntr_Before := l_Master_Childs;
            IF p_Source = 'FLEXCUBE'  THEN
               l_Source_Operation :='STCPBHIS_'||p_Action_Code;
            END IF;
            IF NOT Stpks_Stcpbhis_Main.Fn_Build_Ts_List(p_source,
               l_Source_Operation,
               'STCPBHIS',
               p_Action_Code,
               p_Function_Id,
               p_7030.ty_stcpbhis,
               l_Level_Format,
               l_1_Lvl_Counter,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in Fn_Build_Ts_List');
               RETURN FALSE;
            END IF;
            l_Master_Childs  :=  l_Master_Childs + (l_0_Lvl_Counter -  l_Cntr_Before);

         END IF;
      ELSE
         Dbg('Building Primary Key Reply..');
      END IF;
      Dbg('Returning Success From Fn_Sys_Build_Ws_Ts..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Build_Fc_Ts..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Ws_Ts;
   FUNCTION Fn_Sys_Check_Mandatory (p_Source    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_7030 IN  wbpks_7030_Main.Ty_7030,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000);
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
      l_Rec_Sent       BOOLEAN := TRUE;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';

   BEGIN

      Dbg('In Fn_Sys_Check_Mandatory..');

      l_Fld := 'CATMS_PASSBOOK_DETAILS.BRANCH';
      IF p_7030.v_catms_passbook_details.branch IS Null THEN
         Dbg('Field branch is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'CATMS_PASSBOOK_DETAILS. ACCOUNT';
      IF p_7030.v_catms_passbook_details. account IS Null THEN
         Dbg('Field  account is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'CATMS_PASSBOOK_DETAILS. PASSBOOK_NUMBER';
      IF p_7030.v_catms_passbook_details. passbook_number IS Null THEN
         Dbg('Field  passbook_number is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;
      l_Fld := 'CATMS_PASSBOOK_DETAILS. REFERENCE_NO';
      IF p_7030.v_catms_passbook_details. reference_no IS Null THEN
         Dbg('Field  reference_no is Null..');
         p_Err_Code    := 'ST-MAND-001';
         p_Err_Params := '@'||l_Fld;
         RETURN FALSE;
      END IF;

      IF p_Pk_Or_Full = 'FULL'  THEN
         Dbg('Full Mandatory Checks..');

         l_Blk := 'CATMS_PASSBOOK_DETAILS';
         l_Fld := 'CATMS_PASSBOOK_DETAILS.ACCOUNT';
         IF p_7030.v_catms_passbook_details.account IS Null THEN
            Dbg('Mandatory Key Column account Cannot Be Null');
            Pr_Log_Error(p_Source,'ST-MAND-004','@'||l_Fld );
         END IF;

         l_Blk := 'STTMS_CUST_ACCOUNT';
         l_Rec_Sent  := FALSE;
         l_Fld := 'STTMS_CUST_ACCOUNT.BRANCH_CODE';
         IF p_7030.v_sttms_cust_account.branch_code IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column branch_code Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;
         l_Fld := 'STTMS_CUST_ACCOUNT.CUST_AC_NO';
         IF p_7030.v_sttms_cust_account.cust_ac_no IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column cust_ac_no Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;

         l_Blk := 'CSTBS_UI_COLUMNS';
         l_Rec_Sent  := FALSE;
         l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD1';
         IF p_7030.v_cstbs_ui_columns.char_field1 IS Null THEN
            IF l_Rec_Sent  THEN
               Dbg('Primary key Column char_field1 Cannot Be Null');
               Pr_Log_Error(p_Source,'ST-MAND-002','@'||l_Fld||'~@'||l_Blk) ;
            END IF;
         ELSE
            l_Rec_Sent  := TRUE;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Check_Mandatory ..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_debug('**','In When Others of Fn_Sys_Check_Mandatory ..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory;
   FUNCTION Fn_Sys_Basic_Vals        (p_Source            IN VARCHAR2,
      p_7030     IN  wbpks_7030_Main.ty_7030,
      p_Err_code          IN OUT VARCHAR2,
      p_Err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
   BEGIN

      Dbg('In Fn_Sys_Basic_Vals..');
      IF p_7030.v_cstbs_ui_columns.CHAR_FIELD20 IS NOT NULL THEN
         IF p_7030.v_cstbs_ui_columns.CHAR_FIELD20 NOT IN ('R','D','F') THEN
            dbg('Invalid Value For The Field  :CHAR_FIELD20:'||p_7030.v_cstbs_ui_columns.CHAR_FIELD20);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_7030.v_cstbs_ui_columns.CHAR_FIELD20||'~@CSTBS_UI_COLUMNS.CHAR_FIELD20~@CSTBS_UI_COLUMNS') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Basic_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Basic_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Basic_Vals;

   FUNCTION Fn_Sys_Default_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_7030     IN  OUT wbpks_7030_Main.ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
   BEGIN

      Dbg('In Fn_Sys_Default_Vals..');
      Dbg('Returning Success From Fn_Sys_Default_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Default_Vals..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_Vals;

   FUNCTION Fn_Sys_Merge_Amendables        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Prev_7030 IN wbpks_7030_Main.Ty_7030,
      p_Wrk_7030 IN OUT wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Wrk_Count      NUMBER := 0 ;
      l_Deleted_Recs   NUMBER := 0;
      l_Modified_Flds  VARCHAR2(32000):= NULL;
      l_Key            VARCHAR2(5000):= NULL;
      l_Mod_Fld        VARCHAR2(100):= NULL;
      i                NUMBER := 1;
      l_Rec_Found      BOOLEAN := FALSE;
      l_Rec_Modified   BOOLEAN := FALSE;
      l_Rec_Sent       BOOLEAN := FALSE;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Pk_Or_Full     VARCHAR2(5) :='FULL';
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Mod_No         NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Amendable_Nodes Cspks_Req_Global.Ty_Amend_Nodes;
      l_Amendable_Fields Cspks_Req_Global.Ty_Amend_Fields;

      FUNCTION Fn_Amendable(p_Item IN VARCHAR2) RETURN BOOLEAN IS
      BEGIN
         IF l_Amendable_Fields.EXISTS(p_Item) THEN
            RETURN TRUE;
         ELSE
            RETURN FALSE;
         END IF;
      END Fn_Amendable;
   BEGIN

      Dbg('In Fn_Sys_Merge_Amendables');

      Dbg('Calling Cspks_Req_Utils.Fn_Get_Amendable_Details..');
      IF NOT Cspks_Req_Utils.Fn_Get_Amendable_Details(p_source ,
         p_Source_Operation,
         l_Amendable_Nodes,
         l_Amendable_Fields,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Cspks_Req_Utils.Fn_Get_Amendable_Details..');
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      END IF;

      l_Blk := 'CATMS_PASSBOOK_DETAILS';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_fld := 'CATMS_PASSBOOK_DETAILS.ACCOUNT';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.ACCOUNT') THEN
         p_Wrk_7030.v_catms_passbook_details.account := p_7030.v_catms_passbook_details.account;
      ELSE
         IF p_7030.v_catms_passbook_details.account IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.account,'@') <>
               NVL(p_7030.v_catms_passbook_details.account,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.PASSBOOK_NUMBER';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.PASSBOOK_NUMBER') THEN
         p_Wrk_7030.v_catms_passbook_details.passbook_number := p_7030.v_catms_passbook_details.passbook_number;
      ELSE
         IF p_7030.v_catms_passbook_details.passbook_number IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.passbook_number,-1) <>
               NVL(p_7030.v_catms_passbook_details.passbook_number,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.STATUS';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.STATUS') THEN
         p_Wrk_7030.v_catms_passbook_details.status := p_7030.v_catms_passbook_details.status;
      ELSE
         IF p_7030.v_catms_passbook_details.status IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.status,'@') <>
               NVL(p_7030.v_catms_passbook_details.status,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.REMARKS';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.REMARKS') THEN
         p_Wrk_7030.v_catms_passbook_details.remarks := p_7030.v_catms_passbook_details.remarks;
      ELSE
         IF p_7030.v_catms_passbook_details.remarks IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.remarks,'@') <>
               NVL(p_7030.v_catms_passbook_details.remarks,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.PASSBOOKTYPE';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.PASSBOOKTYPE') THEN
         p_Wrk_7030.v_catms_passbook_details.passbooktype := p_7030.v_catms_passbook_details.passbooktype;
      ELSE
         IF p_7030.v_catms_passbook_details.passbooktype IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.passbooktype,'@') <>
               NVL(p_7030.v_catms_passbook_details.passbooktype,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.ISSUE_DATE';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.ISSUE_DATE') THEN
         p_Wrk_7030.v_catms_passbook_details.issue_date := p_7030.v_catms_passbook_details.issue_date;
      ELSE
         IF p_7030.v_catms_passbook_details.issue_date IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.issue_date,global.min_date) <>
               NVL(p_7030.v_catms_passbook_details.issue_date,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.OLD_PASS_BOOK_NO';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.OLD_PASS_BOOK_NO') THEN
         p_Wrk_7030.v_catms_passbook_details.old_pass_book_no := p_7030.v_catms_passbook_details.old_pass_book_no;
      ELSE
         IF p_7030.v_catms_passbook_details.old_pass_book_no IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.old_pass_book_no,-1) <>
               NVL(p_7030.v_catms_passbook_details.old_pass_book_no,-1)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.MAKER_ID';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.MAKER_ID') THEN
         p_Wrk_7030.v_catms_passbook_details.maker_id := p_7030.v_catms_passbook_details.maker_id;
      ELSE
         IF p_7030.v_catms_passbook_details.maker_id IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.maker_id,'@') <>
               NVL(p_7030.v_catms_passbook_details.maker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.MAKER_DT_STAMP';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.MAKER_DT_STAMP') THEN
         p_Wrk_7030.v_catms_passbook_details.maker_dt_stamp := p_7030.v_catms_passbook_details.maker_dt_stamp;
      ELSE
         IF p_7030.v_catms_passbook_details.maker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.maker_dt_stamp,global.min_date) <>
               NVL(p_7030.v_catms_passbook_details.maker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.CHECKER_ID';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.CHECKER_ID') THEN
         p_Wrk_7030.v_catms_passbook_details.checker_id := p_7030.v_catms_passbook_details.checker_id;
      ELSE
         IF p_7030.v_catms_passbook_details.checker_id IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.checker_id,'@') <>
               NVL(p_7030.v_catms_passbook_details.checker_id,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.CHECKER_DT_STAMP';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.CHECKER_DT_STAMP') THEN
         p_Wrk_7030.v_catms_passbook_details.checker_dt_stamp := p_7030.v_catms_passbook_details.checker_dt_stamp;
      ELSE
         IF p_7030.v_catms_passbook_details.checker_dt_stamp IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.checker_dt_stamp,global.min_date) <>
               NVL(p_7030.v_catms_passbook_details.checker_dt_stamp,global.min_date)  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.ONCE_AUTH';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.ONCE_AUTH') THEN
         p_Wrk_7030.v_catms_passbook_details.once_auth := p_7030.v_catms_passbook_details.once_auth;
      ELSE
         IF p_7030.v_catms_passbook_details.once_auth IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.once_auth,'@') <>
               NVL(p_7030.v_catms_passbook_details.once_auth,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.AUTH_STAT';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.AUTH_STAT') THEN
         p_Wrk_7030.v_catms_passbook_details.auth_stat := p_7030.v_catms_passbook_details.auth_stat;
      ELSE
         IF p_7030.v_catms_passbook_details.auth_stat IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.auth_stat,'@') <>
               NVL(p_7030.v_catms_passbook_details.auth_stat,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.RECORD_STAT';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.RECORD_STAT') THEN
         p_Wrk_7030.v_catms_passbook_details.record_stat := p_7030.v_catms_passbook_details.record_stat;
      ELSE
         IF p_7030.v_catms_passbook_details.record_stat IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.record_stat,'@') <>
               NVL(p_7030.v_catms_passbook_details.record_stat,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.XREF';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.XREF') THEN
         p_Wrk_7030.v_catms_passbook_details.xref := p_7030.v_catms_passbook_details.xref;
      ELSE
         IF p_7030.v_catms_passbook_details.xref IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.xref,'@') <>
               NVL(p_7030.v_catms_passbook_details.xref,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;
      l_fld := 'CATMS_PASSBOOK_DETAILS.REFERENCE_NO';
      IF Fn_Amendable('CATMS_PASSBOOK_DETAILS.REFERENCE_NO') THEN
         p_Wrk_7030.v_catms_passbook_details.reference_no := p_7030.v_catms_passbook_details.reference_no;
      ELSE
         IF p_7030.v_catms_passbook_details.reference_no IS NOT NULL THEN
            IF NVL(p_Wrk_7030.v_catms_passbook_details.reference_no,'@') <>
               NVL(p_7030.v_catms_passbook_details.reference_no,'@')  THEN
               l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
               l_Rec_Modified := TRUE;
            END IF;
         END IF;
      END IF;

      l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
      IF  l_Rec_Modified THEN
         IF l_Modified_Flds IS NOT NULL THEN
            i :=  1;
            l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
            WHILE l_Mod_Fld <> 'EOPL' LOOP
               Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
               i := i +1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
            END LOOP;
         END IF;
      END IF;

      l_Blk := 'STTMS_CUST_ACCOUNT';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_Rec_Sent := FALSE;
      IF p_7030.v_sttms_cust_account.branch_code IS NOT NULL AND p_7030.v_sttms_cust_account.cust_ac_no IS NOT NULL THEN
         dbg('Record Has Been Sent..');
         p_Wrk_7030.v_sttms_cust_account.branch_code := p_7030.v_sttms_cust_account.branch_code;
         p_Wrk_7030.v_sttms_cust_account.cust_ac_no := p_7030.v_sttms_cust_account.cust_ac_no;
         l_Rec_Sent := TRUE;
      END IF;
      IF l_Rec_Sent THEN
         l_fld := 'STTMS_CUST_ACCOUNT.ADDRESS1';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.ADDRESS1') THEN
            p_Wrk_7030.v_sttms_cust_account.address1 := p_7030.v_sttms_cust_account.address1;
         ELSE
            IF p_7030.v_sttms_cust_account.address1 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.address1,'@') <>
                  NVL(p_7030.v_sttms_cust_account.address1,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.ADDRESS2';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.ADDRESS2') THEN
            p_Wrk_7030.v_sttms_cust_account.address2 := p_7030.v_sttms_cust_account.address2;
         ELSE
            IF p_7030.v_sttms_cust_account.address2 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.address2,'@') <>
                  NVL(p_7030.v_sttms_cust_account.address2,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.ADDRESS3';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.ADDRESS3') THEN
            p_Wrk_7030.v_sttms_cust_account.address3 := p_7030.v_sttms_cust_account.address3;
         ELSE
            IF p_7030.v_sttms_cust_account.address3 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.address3,'@') <>
                  NVL(p_7030.v_sttms_cust_account.address3,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.ADDRESS4';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.ADDRESS4') THEN
            p_Wrk_7030.v_sttms_cust_account.address4 := p_7030.v_sttms_cust_account.address4;
         ELSE
            IF p_7030.v_sttms_cust_account.address4 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.address4,'@') <>
                  NVL(p_7030.v_sttms_cust_account.address4,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.AC_DESC';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.AC_DESC') THEN
            p_Wrk_7030.v_sttms_cust_account.ac_desc := p_7030.v_sttms_cust_account.ac_desc;
         ELSE
            IF p_7030.v_sttms_cust_account.ac_desc IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.ac_desc,'@') <>
                  NVL(p_7030.v_sttms_cust_account.ac_desc,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.CUST_NO';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.CUST_NO') THEN
            p_Wrk_7030.v_sttms_cust_account.cust_no := p_7030.v_sttms_cust_account.cust_no;
         ELSE
            IF p_7030.v_sttms_cust_account.cust_no IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.cust_no,'@') <>
                  NVL(p_7030.v_sttms_cust_account.cust_no,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'STTMS_CUST_ACCOUNT.CCY';
         IF Fn_Amendable('STTMS_CUST_ACCOUNT.CCY') THEN
            p_Wrk_7030.v_sttms_cust_account.ccy := p_7030.v_sttms_cust_account.ccy;
         ELSE
            IF p_7030.v_sttms_cust_account.ccy IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_sttms_cust_account.ccy,'@') <>
                  NVL(p_7030.v_sttms_cust_account.ccy,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;

         l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
         IF  l_Rec_Modified THEN
            IF l_Modified_Flds IS NOT NULL THEN
               i :=  1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
               WHILE l_Mod_Fld <> 'EOPL' LOOP
                  Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
                  i := i +1;
                  l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
               END LOOP;
            END IF;
         END IF;
      ELSE

         IF l_Amendable_Nodes.EXISTS('STTMS_CUST_ACCOUNT') THEN
            IF l_Amendable_Nodes('STTMS_CUST_ACCOUNT').All_Records = 'Y' THEN
               p_Wrk_7030.v_sttms_cust_account :=NULL;
            END IF;
         END IF;
      END IF;

      l_Blk := 'CSTBS_UI_COLUMNS';
      l_Rec_Modified := FALSE;
      l_Modified_Flds  := NULL;

      l_Rec_Sent := FALSE;
      IF p_7030.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
         dbg('Record Has Been Sent..');
         p_Wrk_7030.v_cstbs_ui_columns.char_field1 := p_7030.v_cstbs_ui_columns.char_field1;
         l_Rec_Sent := TRUE;
      END IF;
      IF l_Rec_Sent THEN
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD2';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD2') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field2 := p_7030.v_cstbs_ui_columns.char_field2;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field2 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field2,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field2,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD3';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD3') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field3 := p_7030.v_cstbs_ui_columns.char_field3;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field3 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field3,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field3,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD4';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD4') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field4 := p_7030.v_cstbs_ui_columns.char_field4;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field4 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field4,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field4,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD5';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD5') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field5 := p_7030.v_cstbs_ui_columns.char_field5;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field5 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field5,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field5,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD6';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD6') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field6 := p_7030.v_cstbs_ui_columns.char_field6;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field6 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field6,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field6,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD7';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD7') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field7 := p_7030.v_cstbs_ui_columns.char_field7;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field7 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field7,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field7,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD8';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD8') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field8 := p_7030.v_cstbs_ui_columns.char_field8;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field8 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field8,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field8,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD9';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD9') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field9 := p_7030.v_cstbs_ui_columns.char_field9;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field9 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field9,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field9,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD10';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD10') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field10 := p_7030.v_cstbs_ui_columns.char_field10;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field10 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field10,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field10,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;
         l_fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD20';
         IF Fn_Amendable('CSTBS_UI_COLUMNS.CHAR_FIELD20') THEN
            p_Wrk_7030.v_cstbs_ui_columns.char_field20 := p_7030.v_cstbs_ui_columns.char_field20;
         ELSE
            IF p_7030.v_cstbs_ui_columns.char_field20 IS NOT NULL THEN
               IF NVL(p_Wrk_7030.v_cstbs_ui_columns.char_field20,'@') <>
                  NVL(p_7030.v_cstbs_ui_columns.char_field20,'@')  THEN
                  l_Modified_Flds := l_Modified_Flds ||'~'||l_Fld;
                  l_Rec_Modified := TRUE;
               END IF;
            END IF;
         END IF;

         l_Modified_Flds := LTRIM(l_Modified_Flds,'~');
         IF  l_Rec_Modified THEN
            IF l_Modified_Flds IS NOT NULL THEN
               i :=  1;
               l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_modified_flds,i,'~');
               WHILE l_Mod_Fld <> 'EOPL' LOOP
                  Pr_Log_Error(p_Source,'ST-AMND-002','@'||l_Mod_Fld||'~@'||l_Blk) ;
                  i := i +1;
                  l_Mod_Fld := Cspkes_Misc.fn_GetParam(l_Modified_Flds,i,'~');
               END LOOP;
            END IF;
         END IF;
      ELSE

         IF l_Amendable_Nodes.EXISTS('CSTBS_UI_COLUMNS') THEN
            IF l_Amendable_Nodes('CSTBS_UI_COLUMNS').All_Records = 'Y' THEN
               p_Wrk_7030.v_cstbs_ui_columns :=NULL;
            END IF;
         END IF;
      END IF;

      Dbg('Returning Success From Fn_Sys_Merge_Amendables..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Merge_Amendables..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Merge_Amendables;

   FUNCTION Fn_Sys_Check_Mandatory_Nodes  (p_Source            IN VARCHAR2,
      p_Wrk_7030 IN  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Blk            VARCHAR2(100);
      l_Fld            VARCHAR2(100);
   BEGIN

      dbg('In Fn_Gen_Sys_Node_Mand_Checks..');
      Dbg('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Check_Mandatory_Nodes..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Check_Mandatory_Nodes;

   FUNCTION Fn_Sys_Lov_Vals        (p_Source            IN VARCHAR2,
      p_Wrk_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Count          NUMBER:= 0;
      l_Key            VARCHAR2(5000):= NULL;
      i                NUMBER := 1;
      l_Lov_Count      NUMBER := 0;
      l_Blk            VARCHAR2(100):= 0;
      l_Fld            VARCHAR2(100):= 0;
      l_Inv_Chr        VARCHAR2(5) :=NULL;
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER  := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER  := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER  := 0;
   BEGIN

      Dbg('In Fn_Sys_Lov_Vals');
      l_Blk := 'CATMS_PASSBOOK_DETAILS';
      l_Fld := 'CATMS_PASSBOOK_DETAILS.BRANCH';
      IF p_wrk_7030.v_catms_passbook_details.BRANCH IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (select branch_code,branch_name from sttm_core_branch where once_auth='Y' and record_stat='O') WHERE BRANCH_CODE = P_wrk_7030.v_catms_passbook_details.BRANCH;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :BRANCH:'||p_Wrk_7030.v_catms_passbook_details.BRANCH);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_7030.v_catms_passbook_details.BRANCH||'~@CATMS_PASSBOOK_DETAILS.BRANCH~@CATMS_PASSBOOK_DETAILS') ;
         END IF;
      END IF;
      l_Fld := 'CATMS_PASSBOOK_DETAILS.ACCOUNT';
      IF p_wrk_7030.v_catms_passbook_details.ACCOUNT IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT a.cust_ac_no,a.ac_desc,a.cust_no,a.ccy,b.passbook_number,b.status status,decode(b.status, NULL, 'Active', 'Re-Issue & Active') old_status FROM sttm_cust_account a, catm_passbook_details b WHERE a.cust_ac_no = b.account(+) AND a.branch_code = b.branch(+) AND a.account_type <> 'Y' AND a.passbook_facility = 'Y' AND a.record_stat = 'O' AND a.once_auth = 'Y' AND a.auth_stat = 'A' AND NVL(upper(b.status), '***') NOT IN ('ACTIVE', 'RE-ISSUE & ACTIVE') AND a.Branch_Code = P_wrk_7030.v_catms_passbook_details.BRANCH) WHERE CUST_AC_NO = P_wrk_7030.v_catms_passbook_details.ACCOUNT;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :ACCOUNT:'||p_Wrk_7030.v_catms_passbook_details.ACCOUNT);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_7030.v_catms_passbook_details.ACCOUNT||'~@CATMS_PASSBOOK_DETAILS.ACCOUNT~@CATMS_PASSBOOK_DETAILS') ;
         END IF;
      END IF;
      l_Fld := 'CATMS_PASSBOOK_DETAILS.PASSBOOKTYPE';
      IF p_wrk_7030.v_catms_passbook_details.PASSBOOKTYPE IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT STOCK_CODE, STOCK_DESC FROM IVTMS_STOCK_MASTER WHERE INSTRUMENT_TYPE='PB' AND STOCK_TYPE='B' AND (STOCK_CCY = P_wrk_7030.v_sttms_cust_account.CCY OR STOCK_CCY IS NULL) AND ONCE_AUTH='Y' AND RECORD_STAT ='O' AND AUTH_STAT = 'A') WHERE STOCK_CODE = P_wrk_7030.v_catms_passbook_details.PASSBOOKTYPE;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :PASSBOOKTYPE:'||p_Wrk_7030.v_catms_passbook_details.PASSBOOKTYPE);
            Pr_Log_Error(p_Source,'ST-VALS-011',p_Wrk_7030.v_catms_passbook_details.PASSBOOKTYPE||'~@CATMS_PASSBOOK_DETAILS.PASSBOOKTYPE~@CATMS_PASSBOOK_DETAILS') ;
         END IF;
      END IF;
      l_Blk := 'CSTBS_UI_COLUMNS';
      l_Fld := 'CSTBS_UI_COLUMNS.CHAR_FIELD1';
      IF p_wrk_7030.v_cstbs_ui_columns.CHAR_FIELD1 IS NOT NULL THEN
         SELECT COUNT(*) INTO l_LOV_COUNT  FROM  (SELECT AC_GL_NO, CUST_NO, AC_GL_DESC, BRANCH_CODE FROM STTBS_ACCOUNT WHERE AC_GL_REC_STATUS = 'O' AND AC_OR_GL = 'A' AND AUTH_STAT = 'A' AND AC_CLASS IN (SELECT ACCOUNT_CLASS FROM STTM_ACCOUNT_CLASS WHERE AC_CLASS_TYPE <> 'Y')) WHERE AC_GL_NO = P_wrk_7030.v_cstbs_ui_columns.CHAR_FIELD1;
         IF l_lov_count = 0  THEN
            Dbg('Invalid Value For The Field  :CHAR_FIELD1:'||p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD1);
            Pr_Log_Error(p_Source,'ST-VALS-012',p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD1||'~@CSTBS_UI_COLUMNS.CHAR_FIELD1~@CSTBS_UI_COLUMNS') ;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Sys_Lov_Vals..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Lov_Vals..');
         Debug.Pr_debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Lov_Vals;

   FUNCTION Fn_Sys_Default_And_Validate        (p_Source            IN VARCHAR2,
      p_Source_Operation  IN     VARCHAR2,
      p_Function_id       IN     VARCHAR2,
      p_Action_Code       IN     VARCHAR2,
      p_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Prev_7030 IN OUT  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030 IN OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Base_Data_From_Fc  VARCHAR2(1):= 'Y';
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);


   BEGIN

      Dbg('In Fn_Sys_Default_and_Validate..');

      IF p_Source <> 'FLEXCUBE'  THEN
         BEGIN
            SELECT Base_Data_From_Fc
            INTO   l_Base_Data_From_Fc
            FROM   Cotms_Source
            WHERE  Source_Code = p_Source;
         EXCEPTION
            WHEN NO_DATA_FOUND THEN
               Dbg('Failed in Selecting Source '||p_Source);
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-VALS-002';
               p_Err_Params  := p_Source;
               RETURN FALSE;
         END;
      END IF;
      l_key := Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CATMS_PASSBOOK_DETAILS.BRANCH')||'-'||
      p_7030.v_catms_passbook_details.branch||':'||
      Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CATMS_PASSBOOK_DETAILS. ACCOUNT')||'-'||
      p_7030.v_catms_passbook_details. account||':'||
      Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CATMS_PASSBOOK_DETAILS. PASSBOOK_NUMBER')||'-'||
      p_7030.v_catms_passbook_details. passbook_number||':'||
      Cspks_Req_Utils.Fn_Get_Item_Desc(p_source,g_ui_name,'CATMS_PASSBOOK_DETAILS. REFERENCE_NO')||'-'||
      p_7030.v_catms_passbook_details. reference_no;
      IF p_Action_Code = Cspks_Req_Global.p_New THEN
         IF p_Prev_7030.v_catms_passbook_details.branch IS NOT NULL THEN
            Dbg('Record Already Exists..');
            Pr_Log_Error(p_Source,'ST-VALS-001',l_Key) ;
         END IF;
      ELSIF p_Action_Code IN (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify,Cspks_Req_Global.p_Auth,Cspks_Req_Global.p_Close,Cspks_Req_Global.p_Reopen,Cspks_Req_Global.p_Query,Cspks_Req_Global.p_Delete) THEN
         IF p_Prev_7030.v_catms_passbook_details.branch IS NULL THEN
            Dbg('Record Does not Exist..');
            pr_log_error(p_source,'ST-VALS-002',l_key) ;
         END IF;
      END IF;
      p_Wrk_7030 := p_7030;
      IF p_Action_Code in  (Cspks_Req_Global.p_New,Cspks_Req_Global.p_Modify) THEN
         Dbg('Calling .Fn_Sys_Basic_Vals..');
         IF NOT Fn_Sys_Basic_Vals(p_Source,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Basic_Vals..');
            RETURN FALSE;
         END IF;

         IF p_Action_Code = Cspks_Req_Global.p_New  THEN
            Dbg('Calling .Fn_Sys_Default_Vals..');
            IF NOT Fn_Sys_Default_Vals(p_Source,
               p_Wrk_7030,
               p_Err_Code,
               p_Err_Params)  THEN
               Dbg('Failed in .Fn_Sys_Default_Vals..');
               RETURN FALSE;
            END IF;

         END IF;
         Dbg('Calling .Fn_Sys_Check_Mandatory_Nodes..');
         IF NOT Fn_Sys_Check_Mandatory_Nodes(p_source,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Check_Mandatory_Nodes..');
            RETURN FALSE;
         END IF;

         Dbg('Calling  .Fn_Sys_Lov_Vals..');
         IF NOT Fn_Sys_Lov_Vals(p_source,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in .Fn_Sys_Lov_Vals..');
            RETURN FALSE;
         END IF;

      END IF;
      Dbg('Returning Success  From Fn_Sys_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Sys_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Default_And_Validate;
   FUNCTION Fn_Sys_Query_Desc_Fields  ( p_Source    IN  VARCHAR2,
                              p_Source_operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Wrk_7030  IN   OUT wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists     BOOLEAN := TRUE;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query_Desc_Fields..');
      Dbg('Returning Success From Fn_Sys_Query_Desc_Fields..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query_Desc_Fields ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query_Desc_Fields;
   FUNCTION Fn_Sys_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_7030         IN  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030  IN   OUT wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS
      l_Key            VARCHAR2(5000):= NULL;
      l_Count          NUMBER := 0;
      l_Wrk_Count          NUMBER := 0;
      l_Key_Tags       VARCHAR2(32767);
      l_Key_Vals       VARCHAR2(32767);
      l_Rec_Exists        BOOLEAN := TRUE;
      RECORD_LOCKED    EXCEPTION;
      PRAGMA EXCEPTION_INIT( RECORD_LOCKED, -54 );
      l_Dsn_Rec_Cnt_1 NUMBER := 0;
      l_Bnd_Cntr_1    NUMBER := 0;
      l_Dsn_Rec_Cnt_2 NUMBER := 0;
      l_Bnd_Cntr_2    NUMBER := 0;
      l_Dsn_Rec_Cnt_3 NUMBER := 0;
      l_Bnd_Cntr_3    NUMBER := 0;
   BEGIN
      Dbg('In Fn_Sys_Query..');
      IF p_QryData_Reqd = 'Q' THEN
         Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
         IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
            RETURN FALSE;
         END IF;
      ELSE
         l_key := ;
         Dbg('Get The Master Record...');
         IF NVL(p_With_Lock,'N') = 'Y' THEN
            BEGIN
               SELECT *
               INTO   p_wrk_7030.v_catms_passbook_details
               FROM  CATM_PASSBOOK_DETAILS
               WHERE FOR UPDATE NOWAIT;
            EXCEPTION
               WHEN RECORD_LOCKED THEN
                  Dbg('Failed to Obtain the Lock..');
                  Pr_Log_Error(p_Source,'ST-LOCK-001',NULL);
                  RETURN FALSE;
               WHEN No_Data_Found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  l_Rec_Exists := FALSE;
            END;

         ELSE
            BEGIN
               SELECT *
               INTO   p_Wrk_7030.v_catms_passbook_details
               FROM  CATM_PASSBOOK_DETAILS
               WHERE;
            EXCEPTION
               WHEN no_data_found THEN
                  Dbg('Failed in Selecting The Master Recotrd..');
                  Dbg('Record Does not Exist..');
                  p_Err_Code    := 'ST-VALS-002';
                  p_Err_Params  := l_Key;
                  RETURN FALSE;
            END;

         END IF;
         IF p_Full_Data = 'Y' AND l_Rec_Exists THEN
            Dbg('Get the Record For :CATMS_PASSBOOK_DETAILS');
            BEGIN
               SELECT *
               INTO p_Wrk_7030.v_catms_passbook_details
               FROM   CATM_PASSBOOK_DETAILS
               WHERE;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :CATMS_PASSBOOK_DETAILS');
            END;
            Dbg('Get the Record For :STTMS_CUST_ACCOUNT');
            BEGIN
               SELECT *
               INTO p_Wrk_7030.v_sttms_cust_account
               FROM   STTM_CUST_ACCOUNT
               WHERE branch_code = p_Wrk_7030.v_catms_passbook_details.branch
                AND cust_ac_no = p_Wrk_7030.v_catms_passbook_details.account
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :STTMS_CUST_ACCOUNT');
            END;
            Dbg('Get the Record For :CSTBS_UI_COLUMNS');
            BEGIN
               SELECT *
               INTO p_Wrk_7030.v_cstbs_ui_columns
               FROM   CSTB_UI_COLUMNS
               WHERE char_field1 = p_Wrk_7030.v_catms_passbook_details.account
               ;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg(SQLERRM);
                  Dbg('Failed in Selecting The Record For :CSTBS_UI_COLUMNS');
            END;

         END IF;
         IF p_QryData_Reqd = 'Y' THEN
            Dbg('Calling  Fn_Sys_Query_Desc_Fields..');
            IF NOT Fn_Sys_Query_Desc_Fields (p_Source,
               p_Source_Operation,
               p_Function_Id,
               p_Action_Code,
               p_Wrk_7030,
               p_Err_Code  ,
               p_Err_Params ) THEN
               Dbg('Failed in Fn_Sys_Query_Desc_Fields..');
               RETURN FALSE;
            END IF;
         END IF;

      END IF;
      Dbg('Returning Success From Fn_Sys_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Query;
   FUNCTION Fn_Sys_Upload_Db         (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Prev_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030      IN OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Count             NUMBER:= 0;
      l_Ins_Count         NUMBER:= 0;
      l_Upd_Count         NUMBER:= 0;
      l_Del_Count         NUMBER:= 0;
      l_Wrk_Count         NUMBER:= 0;
      l_Prev_Count        NUMBER:= 0;
      l_Rec_Found         BOOLEAN:= FALSE;
      l_Row_Id            ROWID;
      l_Key               VARCHAR2(5000):= NULL;
      l_Auth_Stat         VARCHAR2(1) := 'A';
      l_Base_Data_From_Fc VARCHAR2(1):= 'Y';
   BEGIN
      Dbg('In Fn_Sys_Upload_Db..');
      IF p_Action_Code = Cspks_Req_Global.p_new THEN

         Dbg('Inserting Into CATMS_PASSBOOK_DETAILS..');
         BEGIN
            IF  p_wrk_7030.v_catms_passbook_details.branch IS NOT NULL AND  p_wrk_7030.v_catms_passbook_details. account IS NOT NULL AND  p_wrk_7030.v_catms_passbook_details. passbook_number IS NOT NULL AND  p_wrk_7030.v_catms_passbook_details. reference_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  CATM_PASSBOOK_DETAILS
               VALUES p_wrk_7030.v_catms_passbook_details;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoCATMS_PASSBOOK_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CATMS_PASSBOOK_DETAILS';
               RETURN FALSE;
         END;

         Dbg('Inserting Into STTMS_CUST_ACCOUNT..');
         BEGIN
            IF  p_wrk_7030.v_sttms_cust_account.branch_code IS NOT NULL AND  p_wrk_7030.v_sttms_cust_account.cust_ac_no IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  STTM_CUST_ACCOUNT
               VALUES p_wrk_7030.v_sttms_cust_account;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoSTTMS_CUST_ACCOUNT..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@STTMS_CUST_ACCOUNT';
               RETURN FALSE;
         END;

         Dbg('Inserting Into CSTBS_UI_COLUMNS..');
         BEGIN
            IF  p_wrk_7030.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
               Dbg('Record Sent..');
               INSERT INTO  CSTB_UI_COLUMNS
               VALUES p_wrk_7030.v_cstbs_ui_columns;
            END IF;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed In Insert intoCSTBS_UI_COLUMNS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CSTBS_UI_COLUMNS';
               RETURN FALSE;
         END;
      ELSIF p_Action_Code = Cspks_Req_Global.p_modify THEN

         Dbg('Updating Single Record Node :  CATMS_PASSBOOK_DETAILS..');
         BEGIN
            UPDATE CATM_PASSBOOK_DETAILS
            SET
            ACCOUNT = p_Wrk_7030.v_catms_passbook_details.ACCOUNT,
            PASSBOOK_NUMBER = p_Wrk_7030.v_catms_passbook_details.PASSBOOK_NUMBER,
            STATUS = p_Wrk_7030.v_catms_passbook_details.STATUS,
            REMARKS = p_Wrk_7030.v_catms_passbook_details.REMARKS,
            PASSBOOKTYPE = p_Wrk_7030.v_catms_passbook_details.PASSBOOKTYPE,
            ISSUE_DATE = p_Wrk_7030.v_catms_passbook_details.ISSUE_DATE,
            OLD_PASS_BOOK_NO = p_Wrk_7030.v_catms_passbook_details.OLD_PASS_BOOK_NO,
            MAKER_ID = p_Wrk_7030.v_catms_passbook_details.MAKER_ID,
            MAKER_DT_STAMP = p_Wrk_7030.v_catms_passbook_details.MAKER_DT_STAMP,
            CHECKER_ID = p_Wrk_7030.v_catms_passbook_details.CHECKER_ID,
            CHECKER_DT_STAMP = p_Wrk_7030.v_catms_passbook_details.CHECKER_DT_STAMP,
            ONCE_AUTH = p_Wrk_7030.v_catms_passbook_details.ONCE_AUTH,
            AUTH_STAT = p_Wrk_7030.v_catms_passbook_details.AUTH_STAT,
            RECORD_STAT = p_Wrk_7030.v_catms_passbook_details.RECORD_STAT,
            XREF = p_Wrk_7030.v_catms_passbook_details.XREF,
            REFERENCE_NO = p_Wrk_7030.v_catms_passbook_details.REFERENCE_NO
WHERE;
         EXCEPTION
            WHEN OTHERS THEN
               Dbg('Failed in Insert Into CATMS_PASSBOOK_DETAILS..');
               Dbg(SQLERRM);
               p_Err_Code    := 'ST-UPLD-001';
               p_Err_Params  := '@CATMS_PASSBOOK_DETAILS';
               RETURN FALSE;
         END;

         IF  p_Wrk_7030.v_sttms_cust_account.branch_code IS NOT NULL AND  p_Wrk_7030.v_sttms_cust_account.cust_ac_no IS NOT NULL THEN
            Dbg('Record Sent..');
            Dbg('Updating Single Record Node :  STTMS_CUST_ACCOUNT..');
            BEGIN
               UPDATE STTM_CUST_ACCOUNT
               SET
               ADDRESS1 = p_Wrk_7030.v_sttms_cust_account.ADDRESS1,
               ADDRESS2 = p_Wrk_7030.v_sttms_cust_account.ADDRESS2,
               ADDRESS3 = p_Wrk_7030.v_sttms_cust_account.ADDRESS3,
               ADDRESS4 = p_Wrk_7030.v_sttms_cust_account.ADDRESS4,
               AC_DESC = p_Wrk_7030.v_sttms_cust_account.AC_DESC,
               CUST_NO = p_Wrk_7030.v_sttms_cust_account.CUST_NO,
               CCY = p_Wrk_7030.v_sttms_cust_account.CCY
WHERE branch_code = p_Wrk_7030.v_sttms_cust_account.branch_code
 AND cust_ac_no = p_Wrk_7030.v_sttms_cust_account.cust_ac_no
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into STTMS_CUST_ACCOUNT..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@STTMS_CUST_ACCOUNT';
                  RETURN FALSE;
            END;
            IF SQL%ROWCOUNT = 0 THEN
               BEGIN
                  INSERT INTO  STTM_CUST_ACCOUNT
                  VALUES p_Wrk_7030.v_sttms_cust_account;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Insert Into STTMS_CUST_ACCOUNT..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@STTMS_CUST_ACCOUNT';
                     RETURN FALSE;
               END;
            END IF;
         ELSE
            dbg('Check If The Record Is Already Present for  STTMS_CUST_ACCOUNT. .');
            IF  p_prev_7030.v_sttms_cust_account.branch_code IS NOT NULL OR  p_prev_7030.v_sttms_cust_account.cust_ac_no IS NOT NULL THEN
               Dbg('Prev Data Exists And Not Sent For  STTMS_CUST_ACCOUNT. Delete the Existing Record.');
               DELETE STTM_CUST_ACCOUNT
               WHERE branch_code = p_Prev_7030.v_sttms_cust_account.branch_code
                AND cust_ac_no = p_Prev_7030.v_sttms_cust_account.cust_ac_no
               ;
            END IF;
         END IF;

         IF  p_Wrk_7030.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
            Dbg('Record Sent..');
            Dbg('Updating Single Record Node :  CSTBS_UI_COLUMNS..');
            BEGIN
               UPDATE CSTB_UI_COLUMNS
               SET
               CHAR_FIELD2 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD2,
               CHAR_FIELD3 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD3,
               CHAR_FIELD4 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD4,
               CHAR_FIELD5 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD5,
               CHAR_FIELD6 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD6,
               CHAR_FIELD7 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD7,
               CHAR_FIELD8 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD8,
               CHAR_FIELD9 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD9,
               CHAR_FIELD10 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD10,
               CHAR_FIELD20 = p_Wrk_7030.v_cstbs_ui_columns.CHAR_FIELD20
WHERE char_field1 = p_Wrk_7030.v_cstbs_ui_columns.char_field1
;
            EXCEPTION
               WHEN OTHERS THEN
                  Dbg('Failed in Insert Into CSTBS_UI_COLUMNS..');
                  Dbg(SQLERRM);
                  p_Err_Code    := 'ST-UPLD-001';
                  p_Err_Params  := '@CSTBS_UI_COLUMNS';
                  RETURN FALSE;
            END;
            IF SQL%ROWCOUNT = 0 THEN
               BEGIN
                  INSERT INTO  CSTB_UI_COLUMNS
                  VALUES p_Wrk_7030.v_cstbs_ui_columns;
               EXCEPTION
                  WHEN OTHERS THEN
                     Dbg('Failed in Insert Into CSTBS_UI_COLUMNS..');
                     Dbg(SQLERRM);
                     p_Err_Code    := 'ST-UPLD-001';
                     p_Err_Params  := '@CSTBS_UI_COLUMNS';
                     RETURN FALSE;
               END;
            END IF;
         ELSE
            dbg('Check If The Record Is Already Present for  CSTBS_UI_COLUMNS. .');
            IF  p_prev_7030.v_cstbs_ui_columns.char_field1 IS NOT NULL THEN
               Dbg('Prev Data Exists And Not Sent For  CSTBS_UI_COLUMNS. Delete the Existing Record.');
               DELETE CSTB_UI_COLUMNS
               WHERE char_field1 = p_Prev_7030.v_cstbs_ui_columns.char_field1
               ;
            END IF;
         END IF;
      ELSIF p_Action_Code = Cspks_Req_Global.p_delete THEN
         Dbg('Action Code '||p_Action_Code);
         Dbg('Deleting The Data..');

         
         DELETE CSTB_UI_COLUMNS
         WHERE char_field1 = p_Wrk_7030.v_catms_passbook_details.account
         ;

         
         DELETE STTM_CUST_ACCOUNT
         WHERE branch_code = p_Wrk_7030.v_catms_passbook_details.branch
          AND cust_ac_no = p_Wrk_7030.v_catms_passbook_details.account
         ;

         DELETE CATM_PASSBOOK_DETAILS WHERE;



      END IF;

      Dbg('Returning Success From Fn_Sys_Upload_Db');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Sys_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Upload_Db;
   FUNCTION Fn_Build_Type (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_7030       IN   OUT wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Child_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;

   BEGIN

      Dbg('In Fn_Build_Ws_Type..');

      IF Cspks_Req_Utils.Fn_Is_Req_Fc_Format(p_Source,p_Function_Id) THEN
         IF NOT Fn_Sys_Build_Fc_Type(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Fc_Type..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT Fn_Sys_Build_Ws_Type(p_source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Addl_Info ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Build_Ws_Type..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTTYPE');
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Post_Build_Type_Structure(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Child_Function,
            p_Addl_Info ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Post_Build_Type_Structure..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Build_Type..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Build_Type ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Type;
   FUNCTION Fn_Build_Ts_List (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_exchange_pattern   IN  VARCHAR2,
      p_7030          IN wbpks_7030_Main.ty_7030,
      p_err_code        IN OUT VARCHAR2,
      p_err_params      IN OUT VARCHAR2)
   RETURN BOOLEAN   IS

      l_Main_Function smtb_menu.function_id%TYPE := p_Function_id;

   BEGIN

      dbg('In Fn_Build_Ts_List..');

      IF Cspks_Req_Utils.Fn_Is_Res_Fc_Format(p_source,p_Function_id) THEN
         IF NOT  Fn_Sys_Build_Fc_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_7030,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Fc_Ts');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Sys_Build_Ws_Ts(p_Source,
            p_source_operation,
            p_Function_id,
            p_action_code,
            p_exchange_pattern,
            p_7030,
            p_err_code,
            p_err_params)  THEN
            dbg('Failed in Fn_Sys_Build_Ws_Ts');
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning from Fn_Build_Ts_List');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of wbpks_7030_Main.Fn_Build_Ts_List ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Build_Ts_List;
   FUNCTION Fn_Get_Key_Information (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_7030       IN  OUT wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Key_Cols        VARCHAR2(32767);
      l_Key_Vals        VARCHAR2(32767);
      l_Func_Type       VARCHAR2(32767);
   BEGIN

      Dbg('In Fn_Get_Key_Information..');
      l_Key_Cols := ;
      l_Key_Vals := ;
      Dbg('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
      IF NOT Cspks_Req_Utils.Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code ,
         'MAINTENANCE',
         'CATMS_PASSBOOK_DETAILS',
         'BLK_CATMS_PASSBOOK_DETAILS',
         'Catms-Passbook-Details',
         l_Key_Cols,
         l_Key_Vals,
         p_7030.Addl_Info,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
         RETURN FALSE;
      END IF;
      IF p_7030.Addl_Info.EXISTS('RECORD_KEY') THEN
         G_Req_Key :=  p_7030.Addl_Info('RECORD_KEY');
      END IF;
      Dbg('Returning Succsess From Fn_Get_Key_Information..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Get_Key_Information..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Key_Information;
   FUNCTION Fn_Check_Mandatory (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_7030 IN OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
     RETURN BOOLEAN IS

      l_Pk_Or_Full      VARCHAR2(10) :=  'FULL';
      l_Blk      VARCHAR2(100) ;
      l_Fld      VARCHAR2(100) ;
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation      VARCHAR2(100) := p_Source_Operation;
      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;

   BEGIN

      Dbg('In Fn_Check_Mandatory..');

      IF p_Pk_Or_Full = 'FULL' OR p_Action_Code = Cspks_Req_Global.p_New THEN
         l_Pk_Or_Full := 'FULL';
      ELSE
         l_Pk_Or_Full := p_Pk_Or_Full;
      END IF;
      Pr_Skip_Handler('PREMAND');
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  wbpks_7030_Custom.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Pre_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  wbpks_7030_Kernel.Fn_Pre_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      IF NOT wbpks_7030_Main.Fn_Skip_Sys THEN
         Dbg('Calling   Fn_Sys_Check_Mandatory..');
         IF NOT Fn_Sys_Check_Mandatory(p_Source,
            l_Pk_Or_Full,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Sys_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      l_chcd := p_7030.ty_chcd;
      Dbg('Calling Chpks_Chcd_Main.Fn_Check_Mandatory..');
      IF NOT Chpks_Chcd_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_chcd,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='STCPBHIS_'||p_Action_Code;
      END IF;
      l_stcpbhis := p_7030.ty_stcpbhis;
      Dbg('Calling Stpks_Stcpbhis_Main.Fn_Check_Mandatory..');
      IF NOT Stpks_Stcpbhis_Main.Fn_Check_Mandatory(p_Source,
         l_Source_Operation,
         'STCPBHIS',
         p_Action_Code,
         p_Function_Id,
         l_Pk_Or_Full,
         l_stcpbhis,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RETURN FALSE;
      END IF;

      Pr_Skip_Handler('POSTMAND');
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            l_Pk_Or_Full,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  wbpks_7030_Kernel.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Post_Check_Mandatory (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            l_Pk_Or_Full,
            p_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in  wbpks_7030_Custom.Fn_Post_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Check_Mandatory..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Check_Mandatory;
   FUNCTION Fn_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd       IN  VARCHAR2,
      p_7030         IN  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030  IN   OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Wrk_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Key_Vals VARCHAR2(32767);
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;

   BEGIN

      Dbg('In Fn_Query..');

      Pr_Skip_Handler('PREQRY');
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Pre_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Pre_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Pre_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Full_Data = 'Y' THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_7030.Ty_chcd;
         l_Key_Vals :='XREF'||'>'||p_wrk_7030.v_catms_passbook_details.XREF;
         Dbg('Calling Chpks_Chcd_Main. Fn_Query..');
         IF NOT Chpks_Chcd_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_chcd,
            l_Wrk_chcd,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Chpks_Chcd_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_7030.Ty_chcd := l_Wrk_chcd;

         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='STCPBHIS_'||p_Action_Code;
         END IF;
         l_stcpbhis := p_7030.Ty_stcpbhis;
         l_Key_Vals :='ACCOUNT~BRANCH~PASSBOOK_NUMBER'||'>'||p_wrk_7030.v_catms_passbook_details.CUST_AC_NO||'~'||p_wrk_7030.v_catms_passbook_details.BRANCH_CODE||'~'||p_wrk_7030.v_catms_passbook_details.PASSBOOK_NUMBER;
         Dbg('Calling Stpks_Stcpbhis_Main. Fn_Query..');
         IF NOT Stpks_Stcpbhis_Main.Fn_Query (p_Source,
            l_Source_Operation,
            'STCPBHIS',
            p_Action_Code,
            p_Function_Id,
            l_Key_Vals,
            p_QryData_Reqd,
            l_stcpbhis,
            l_Wrk_stcpbhis,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Stpks_Stcpbhis_Main. Fn_Query..');
            RETURN FALSE;
         END IF;

          p_Wrk_7030.Ty_stcpbhis := l_Wrk_stcpbhis;

      END IF;
      Pr_Skip_Handler('POSTQRY');
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Post_Query (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_Full_Data  ,
            p_With_Lock,
            p_QryData_Reqd,
            p_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Post_Query..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Query..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Query;
   FUNCTION Fn_Default_And_Validate        (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Prev_7030 IN OUT  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030 IN OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_Id;
      l_Check_Amendables  VARCHAR2(1) := 'N';
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Full_data    VARCHAR2(1) := 'N';
      l_With_Lock    VARCHAR2(1) := 'Y';
      l_Qrydata_Reqd    VARCHAR2(1) := 'N';
      l_Pk_Or_Full      VARCHAR2(10) := 'FULL';

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Prev_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Prev_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Wrk_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;

   BEGIN

      Dbg('In Fn_Default_And_Validate..');

      l_Full_data   := 'Y';
      Dbg('Calling  Fn_Query..');
      IF NOT Fn_Query(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Full_data,
         l_With_Lock,
         l_Qrydata_Reqd,
         p_7030,
         p_Prev_7030,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Fn_Query..');
         RETURN FALSE;
      END IF;
      Pr_Skip_Handler('PREDFLT');
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Pre_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Pre_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_Sys THEN
         Dbg('Calling in Fn_Sys_Default_and_Validate..');
         IF NOT Fn_Sys_Default_and_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code  ,
            p_Err_Params ) THEN
            Dbg('Failed in Fn_Sys_Default_and_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='CHCD_'||p_Action_Code;
      END IF;
      l_chcd := p_7030.ty_chcd;
      l_prev_chcd := p_Prev_7030.ty_chcd;
      l_wrk_chcd := p_Wrk_7030.ty_chcd;
      Dbg('Calling  Chpks_Chcd_Main.Fn_Default_And_Validate..');
      IF NOT Chpks_Chcd_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'CHCD',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_chcd,
         l_Prev_chcd,
         l_Wrk_chcd,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_7030.ty_chcd:= l_prev_chcd;
      p_Wrk_7030.ty_chcd:= l_wrk_chcd;


      IF p_Source = 'FLEXCUBE'  THEN
         l_Source_Operation :='STCPBHIS_'||p_Action_Code;
      END IF;
      l_stcpbhis := p_7030.ty_stcpbhis;
      l_prev_stcpbhis := p_Prev_7030.ty_stcpbhis;
      l_wrk_stcpbhis := p_Wrk_7030.ty_stcpbhis;
      Dbg('Calling  Stpks_Stcpbhis_Main.Fn_Default_And_Validate..');
      IF NOT Stpks_Stcpbhis_Main.Fn_Default_And_Validate (p_Source,
         l_Source_Operation,
         'STCPBHIS',
         p_Action_Code,
         p_Function_Id,
         l_Check_Amendables,
         l_stcpbhis,
         l_Prev_stcpbhis,
         l_Wrk_stcpbhis,
         p_Err_Code,
         p_Err_Params) THEN
         Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Default_And_Validate..');
         RETURN FALSE;
      END IF;
      p_Prev_7030.ty_stcpbhis:= l_prev_stcpbhis;
      p_Wrk_7030.ty_stcpbhis:= l_wrk_stcpbhis;


      Pr_Skip_Handler('POSTDFLT');
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Post_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_function_Id  ,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Post_Default_And_Validate..');
            RETURN FALSE;
         END IF;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_Modify THEN
         Dbg('Calling  Fn_Check_Mandatory..');
         IF NOT Fn_Check_Mandatory(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            l_Pk_Or_Full,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Check_Mandatory..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success From Fn_Default_And_Validate..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Default_And_Validate;
   FUNCTION Fn_Upload_Db  (p_Source            IN VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Post_Upl_Stat    IN     VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Prev_7030     IN  wbpks_7030_Main.Ty_7030,
      p_Wrk_7030      IN OUT  wbpks_7030_Main.Ty_7030,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Main_Function Smtb_Menu.Function_Id%TYPE := p_Function_id;
      l_Source_Operation       VARCHAR2(100) := p_Source_Operation;
      l_Row_Id            ROWID;
      l_Key  VARCHAR2(32767);
      l_Fld  VARCHAR2(32767);

      l_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Prev_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_Wrk_chcd    Chpks_Chcd_Main.Ty_chcd;
      l_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Prev_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;
      l_Wrk_stcpbhis    Stpks_Stcpbhis_Main.Ty_stcpbhis;

   BEGIN

      Dbg('In Fn_Upload_Db..');

      IF p_Action_Code = Cspks_Req_Global.p_delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_7030.ty_chcd;
         l_prev_chcd := p_Prev_7030.ty_chcd;
         l_wrk_chcd := p_Wrk_7030.ty_chcd;
         Dbg('Calling Chpks_Chcd_Main.Fn_Upload_Db');
         IF NOT Chpks_Chcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_chcd,
            l_Prev_chcd,
            l_Wrk_chcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Chpks_Chcd_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_7030.Ty_chcd:= l_Wrk_chcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='STCPBHIS_'||p_Action_Code;
         END IF;
         l_stcpbhis := p_7030.ty_stcpbhis;
         l_prev_stcpbhis := p_Prev_7030.ty_stcpbhis;
         l_wrk_stcpbhis := p_Wrk_7030.ty_stcpbhis;
         Dbg('Calling Stpks_Stcpbhis_Main.Fn_Upload_Db');
         IF NOT Stpks_Stcpbhis_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'STCPBHIS',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_stcpbhis,
            l_Prev_stcpbhis,
            l_Wrk_stcpbhis,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Upload_Db');
            RETURN FALSE;
         END IF;
         p_Wrk_7030.Ty_stcpbhis:= l_Wrk_stcpbhis;


      END IF;
      Pr_Skip_Handler('PREUPLD');
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Pre_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Pre_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_Sys THEN
         IF NOT Fn_Sys_Upload_Db (p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Pre_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;

      IF p_Action_Code <> Cspks_Req_Global.p_delete THEN
         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='CHCD_'||p_Action_Code;
         END IF;
         l_chcd := p_7030.ty_chcd;
         l_prev_chcd := p_Prev_7030.ty_chcd;
         l_wrk_chcd := p_Wrk_7030.ty_chcd;
         Dbg('Calling Chpks_Chcd_Main.Fn_Upload_Db..');
         IF NOT Chpks_Chcd_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'CHCD',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_chcd,
            l_Prev_chcd,
            l_Wrk_chcd,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Chpks_Chcd_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_7030.Ty_chcd:= l_Wrk_chcd;


         IF p_Source = 'FLEXCUBE'  THEN
            l_Source_Operation :='STCPBHIS_'||p_Action_Code;
         END IF;
         l_stcpbhis := p_7030.ty_stcpbhis;
         l_prev_stcpbhis := p_Prev_7030.ty_stcpbhis;
         l_wrk_stcpbhis := p_Wrk_7030.ty_stcpbhis;
         Dbg('Calling Stpks_Stcpbhis_Main.Fn_Upload_Db..');
         IF NOT Stpks_Stcpbhis_Main.Fn_Upload_Db (p_Source,
            l_Source_Operation,
            'STCPBHIS',
            p_Action_Code,
            p_Function_Id,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            l_stcpbhis,
            l_Prev_stcpbhis,
            l_Wrk_stcpbhis,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Upload_Db..');
            RETURN FALSE;
         END IF;
         p_Wrk_7030.Ty_stcpbhis:= l_Wrk_stcpbhis;


      END IF;
      Pr_Skip_Handler('POSTUPLD');
      IF NOT wbpks_7030_Main.Fn_Skip_kernel  THEN
         IF NOT wbpks_7030_Kernel.Fn_Post_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Kernel.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT wbpks_7030_Main.Fn_Skip_custom  THEN
         IF NOT wbpks_7030_Custom.Fn_Post_Upload_Db (p_Source,
            p_Source_operation,
            p_Function_id,
            p_Action_Code,
            p_function_Id  ,
            p_Post_Upl_Stat,
            p_Multi_Trip_Id,
            p_7030,
            p_Prev_7030,
            p_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in wbpks_7030_Custom.Fn_Post_Upload_Db..');
            RETURN FALSE;
         END IF;
      END IF;
      Dbg('Returning Success  From Fn_Upload_Db..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of wbpks_7030_Main.Fn_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Upload_Db;
   FUNCTION Fn_Extract_Custom_Data (p_Source   IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      l_7030     wbpks_7030_Main.Ty_7030;

   BEGIN

      Dbg('In Fn_Extract_Custom_Data.. ');
      IF NOT  Fn_Build_Type(p_source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Addl_Info,
         l_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_Status      := 'F';
         RAISE e_Failure_Exception;
      END IF;
      Dbg('Calling  Fn_Get_Key_Information..');
      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      p_Addl_Info := l_7030.Addl_Info;
      Dbg('Returning from Fn_Extract_Custom_Data..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Extract_Custom_Data..');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Extract_Custom_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Extract_Custom_Data;

   FUNCTION Fn_Rebuild_Ts_List (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;

   BEGIN

      Dbg('In Fn_Rebuild_Ts_List ');
      IF NOT  Fn_Build_Ts_List(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         p_Exchange_Pattern,
         g_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Ts_List');
         p_Status      := 'F';
         RETURN FALSE;
      END IF;
      Dbg('Returning Success From Fn_Rebuild_Ts_List..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Rebuild_Ts_List');
         p_Status        := 'F';
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Rebuild_Ts_List..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Rebuild_Ts_List;

   FUNCTION Fn_Get_Node_Data (
      p_Node_Data         IN OUT Cspks_Req_Global.Ty_Tb_Chr_Node_Data,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN   IS
      l_Cntr NUMBER := 0;
   BEGIN

      Dbg('In Fn_Get_Node_Data..');
      l_Cntr  := Nvl(p_Node_Data.Count,0) + 1;
      p_Node_Data(l_Cntr).Node_Name := 'BLK_CATMS_PASSBOOK_DETAILS';
      p_Node_Data(l_Cntr).Xsd_Node := 'Catms-Passbook-Details';
      p_Node_Data(l_Cntr).Node_Parent := '';
      p_Node_Data(l_Cntr).Node_Relation_Type := '1';
      p_Node_Data(l_Cntr).Query_Node := '0';
      p_Node_Data(l_Cntr).Node_Fields := 'BRN~ACC~PASSBOOKNO~STATUS~REMARKS~PASSBOOKTYPE~PREVPASSBOOKNO~XREF~REFERENCE_NO~ADD1~ADD2~ADD3~ADD4~AC_DESC~CUSTNO~CCY~CHGACCOUNT~CHGACCDESC~CHGACCBRN~CHGCUSTID~CHGPKPDN~CHAR_FIELD20~';
      p_Node_Data(l_Cntr).Node_Tags := 'BRN~ACC~PASSBOOKNO~STATUS~REMARKS~PASSBOOKTYPE~PREV_PASSBOOK_NO~EXTERNAL_REFERENCE_NUMEBR~REFERENCE_NO~ADD1~ADD2~ADD3~ADD4~AC_DESC~CUSTNO~CCY~CHGACC~CHGACCDESC~CHGACCBRN~CHGCUSTID~CHGPKPDN~CHAR_FIELD2';
      p_Node_Data(l_Cntr).Node_Tags := p_Node_Data(l_Cntr).Node_Tags||'0~';

      IF NOT Chpks_Chcd_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Chpks_Chcd_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      IF NOT Stpks_Stcpbhis_Main.Fn_Get_Node_Data(
         p_Node_Data,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Stpks_Stcpbhis_Main.Fn_Get_Node_Data..');
         RETURN FALSE;
      END IF;
      Dbg('Returning From Fn_Get_Node_Data.. ');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of wbpks_7030_Main.Fn_Get_Node_Data..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Get_Node_Data;
   FUNCTION Fn_Int_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_7030          IN OUT wbpks_7030_Main.ty_7030,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;
      l_Resultant_Error_Type  VARCHAR2(32767):= 'I';
      l_Post_Upl_Stat         VARCHAR2(1) :='A';
      l_Prev_Auth_Stat        VARCHAR2(1) :='U';
      l_Wrk_7030    wbpks_7030_Main.Ty_7030;
      l_Prev_7030    wbpks_7030_Main.Ty_7030;
      l_Dmy_7030    wbpks_7030_Main.Ty_7030;
      l_Pk_Or_Full    VARCHAR2(5) :='PK';
      l_Full_Data    VARCHAR2(1) := 'Y';
      l_With_Lock    VARCHAR2(1) := 'N';
      l_Qrydata_Reqd    VARCHAR2(1) := 'Y';
      l_Count         NUMBER;
      l_Action_Code       VARCHAR2(100):= p_Action_Code;

   BEGIN

      Dbg('In Fn_Int_Main..');

      SAVEPOINT Sp_Int_Main_7030;
      p_Status := 'S';
      g_7030 := p_7030;
      l_Wrk_7030 := p_7030;

      Dbg('Calling  Fn_Check_Mandatory..');
      IF NOT Fn_Check_Mandatory(p_Source,
         p_Source_Operation,
         p_Function_Id,
         p_Action_Code,
         l_Pk_Or_Full,
         p_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Check_Mandatory..');
         Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
         RAISE E_Failure_Exception;
      END IF;

      IF NOT  Fn_Get_Key_Information(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Get_Key_Information..');
         RAISE e_Failure_Exception;
      END IF;
      IF p_Action_Code = Cspks_Req_Global.p_query THEN
         Dbg('Calling in Fn_Query..');
         IF NOT Fn_Query(p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            l_Full_data,
            l_with_lock,
            l_Qrydata_Reqd,
            p_7030,
            l_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Query..');
            Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;
      ELSE
         Dbg('Calling  Fn_Default_And_Validate..');
         IF NOT Fn_Default_And_Validate (p_Source,
            p_Source_Operation,
            p_Function_Id,
            l_Action_Code,
            p_7030,
            l_Prev_7030,
            l_Wrk_7030,
            p_Err_Code,
            p_Err_Params) THEN
            Dbg('Failed in Fn_Default_And_Validate..');
            pr_log_error(p_Source,p_Err_Code, p_Err_Params);
            RAISE E_Failure_Exception;
         END IF;

         -- Get Resultant Error Type
         l_Resultant_Error_Type := Cspks_Req_Utils.Fn_Get_Resultant_Error_Type;
         IF l_Resultant_Error_Type <> 'E' THEN
            Dbg('Calling  Fn_Upload_Db..');
            IF NOT Fn_Upload_Db (p_Source,
               p_Source_Operation,
               p_Function_Id,
               l_Action_Code,
               l_Post_Upl_Stat,
               p_Multi_Trip_Id,
               p_7030,
               l_Prev_7030,
               l_Wrk_7030,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Fn_Upload_Db..');
               pr_log_error(p_Source,p_Err_Code, p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;
            IF  l_Action_Code <> Cspks_Req_Global.p_Auth THEN
               l_Prev_Auth_Stat := 'A';
               --Get Upload Status
               Dbg('Calling Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
               IF NOT Cspks_Req_Utils.Fn_Get_Auto_Auth_Status (p_Source,
                  p_Source_Operation,
                  p_Function_Id,
                  l_Action_Code,
                  l_Prev_Auth_Stat,
                  p_Multi_Trip_Id,
                  P_Request_No,
                  l_Post_Upl_Stat,
                  p_Err_Code,
                  p_Err_Params) THEN
                  Dbg('Failed in Cspks_Req_Utils.Fn_Get_Auto_Auth_Status..');
                  Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
                  RAISE E_Failure_Exception;
               END IF;

               IF l_Post_Upl_Stat NOT IN ('A','U','O') THEN
                  Dbg('Cannot Proceed Further..');
                  RAISE E_Failure_Exception;
               ELSE
                  IF l_post_upl_stat = 'A'THEN
                     Dbg('Calling  Fn_Upload_Db..');
                     IF NOT Fn_Upload_Db (p_Source,
                        p_Source_Operation,
                        p_Function_Id,
                        Cspks_Req_Global.p_auth,
                        l_Post_Upl_Stat,
                        p_Multi_Trip_Id,
                        p_7030,
                        l_Prev_7030,
                        l_Wrk_7030,
                        p_Err_Code,
                        p_Err_Params) THEN
                        Dbg('Failed in Fn_Upload_Db..');
                        Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                        RAISE E_Failure_Exception;
                     END IF;
                  END IF;
               END IF;
            END IF;
            --Get Upload Status
            Dbg('Calling  Cspks_Req_Utils.Fn_Get_Upload_Status..');
            IF NOT Cspks_Req_Utils.Fn_Get_Upload_Status (p_Source,
               p_source_operation,
               p_Function_Id,
               l_Action_Code,
               p_Multi_Trip_Id,
               P_Request_No,
               l_Post_Upl_Stat,
               p_Err_Code,
               p_Err_Params) THEN
               Dbg('Failed in Cspks_Req_Utils.Fn_Get_Upload_Status..');
               Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
               RAISE E_Failure_Exception;
            END IF;

            IF l_Post_Upl_Stat IN ('A','U') THEN
               Dbg('Success Case...');
               IF l_Action_Code <> Cspks_Req_Global.p_Delete THEN
                  IF NOT Fn_Query(p_Source,
                     p_Source_Operation,
                     p_Function_Id,
                     l_Action_Code,
                     l_Full_Data,
                     l_With_Lock,
                     l_Qrydata_Reqd,
                     l_Wrk_7030,
                     l_Wrk_7030,
                     p_Err_Code,
                     p_Err_Params) THEN
                     Dbg('Failed in Fn_Query..');
                     Pr_Log_Error(p_Source,p_Err_Code, p_Err_Params);
                     RAISE E_Failure_Exception;
                  END IF;
               END IF;
            ELSIF l_Post_Upl_Stat ='O' THEN
               Dbg('Raising Override Exception..');
               RAISE E_Override_Exception;
            ELSE
               Dbg('Not Feasible to Proceed..');
               RAISE E_Failure_Exception;
            END IF;
         ELSE
            Dbg('Encountered Errros..');
            RAISE E_Failure_Exception;
         END IF;
      END IF; -- Action Code

      Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
      Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
      g_7030 := l_wrk_7030;
      IF l_Action_Code = Cspks_Req_Global.p_Delete AND p_Source = 'FLEXCUBE'  THEN
         l_Wrk_7030 := l_Dmy_7030;
      END IF;
      p_7030 := l_wrk_7030;
      Dbg('Errors     :'||p_Err_Code);
      Dbg('Parameters :'||p_Err_Params);

      Dbg('Returning Success From Fn_Int_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Int_Main..');
         ROLLBACK TO Sp_Int_Main_7030;
         p_Status        := 'F';
         l_Post_Upl_Stat := 'F';
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Int_Main');
         p_Status        := 'O';
         l_post_upl_stat := 'O';
         IF NOT Cspks_Req_Utils.Fn_Log_Overrides(p_Multi_Trip_Id, p_Request_No, p_Err_Code, p_Err_Params) THEN
            Dbg('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
            p_Err_Code    := 'ST-OTHR-001';
            p_Err_Params  := Null;
            RETURN FALSE;
         END IF;
         Cspks_Req_Utils.Pr_Get_Final_Err_Code(p_Function_Id,l_Action_Code,l_Post_Upl_Stat,p_Err_Code,p_Err_Params);
         Pr_Log_Error(p_Source,p_Err_Code,p_Err_Params);
         Dbg('Errors     :'||p_Err_Code);
         Dbg('Parameters :'||p_Err_Params);
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Int_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         ROLLBACK TO Sp_Int_Main_7030;
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Int_Main;

   FUNCTION Fn_Main   (p_Source            IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_7030          IN OUT wbpks_7030_Main.ty_7030,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      E_Failure_Exception     EXCEPTION;
      E_Override_Exception    EXCEPTION;

   BEGIN

      Dbg('In Fn_Main..');
      SAVEPOINT Sp_Main_7030;
      Dbg('Calling  Fn_Int_Main..');
      IF NOT  Fn_Int_Main(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Multi_Trip_Id,
         p_Request_No,
         p_7030,
         p_Status,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Int_Main..');
         RAISE E_Failure_Exception;
      END IF;
      IF p_Status = 'F' THEN
         RAISE E_Failure_Exception;
      ELSIF p_Status = 'O' THEN
         RAISE E_Override_Exception;
      END IF;
      Dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         Dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main_7030;
         p_Status      := 'F';
         RETURN TRUE;

      WHEN E_Override_Exception THEN
         Dbg('From E_Override_Exception of Fn_Main..');
         p_Status      := 'O';
         RETURN TRUE;

      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Main ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         ROLLBACK TO Sp_Main_7030;
         RETURN FALSE;
   END Fn_Main;

   FUNCTION Fn_Process_Request (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
                              p_Exchange_Pattern  IN     VARCHAR2,
                              p_Multi_Trip_Id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_Addl_Info         IN OUT Cspks_Req_Global.Ty_Addl_Info,
                              p_Status            IN OUT VARCHAR2 ,
                              p_Err_Code          IN OUT VARCHAR2,
                              p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN IS

      l_7030     wbpks_7030_Main.ty_7030;

   BEGIN

      Dbg('In Fn_Process_Request ');
      IF NOT  Fn_Build_Type(p_Source,
         p_Source_Operation,
         p_Function_id,
         p_Action_Code,
         p_Addl_Info,
         l_7030,
         p_Err_Code,
         p_Err_Params)  THEN
         Dbg('Failed in Fn_Build_Type..');
         p_status      := 'F';
         RETURN FALSE;
      END IF;
      IF Cspks_Req_Global.Fn_UnTanking THEN
         IF NOT  Fn_Int_Main(p_Source,
            p_Source_Operation,
            p_Function_Id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_7030,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      ELSE
         IF NOT  Fn_Main(p_source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Multi_Trip_Id,
            p_Request_No,
            l_7030,
            p_Status,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_main..');
            RETURN FALSE;
         END IF;
      END IF;

      p_addl_info := l_7030.Addl_Info;
      IF Cspks_Req_Global.Fn_Build_Resp THEN
         Cspks_Req_Global.Pr_Reset;
         IF NOT  Fn_Build_Ts_List(p_Source,
            p_Source_Operation,
            p_Function_id,
            p_Action_Code,
            p_Exchange_Pattern,
            l_7030,
            p_Err_Code,
            p_Err_Params)  THEN
            Dbg('Failed in Fn_Build_Ts_List..');
            p_Status      := 'F';
            RETURN FALSE;
         END IF;
         Cspks_Req_Global.Pr_Close_Ts;
      END IF;
      Dbg('Returning Success From Fn_Process_Request..');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of Fn_Process_Request..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Status      := 'F';
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Process_Request;

END wbpks_7030_main;
/