CREATE OR REPLACE PACKAGE BODY GWPKS_NEWPASSBOOK_CUSTOM AS
  /*
  -------------------------------------------------------------------------------------------------------
   CHANGE HISTORY
   **    Change Tag        : PRF_CUSTOM_05_03072018
   **    Changes By        : Aniket
   **    Changes on        : 03-JUL-2018
   **    Description       : Changes related to Passbook printing specific to Prince Finance
    -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE DBG(P_DBG IN VARCHAR2) IS
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      DEBUG.PR_DEBUG('IF',
                     '[DEBUG] ' || 'gwpks_newpassbook_custom :' || P_DBG);
    END IF;
  END DBG;

  --passbook reissue charge starts
  PROCEDURE PR_INSERT_PBK_REISSUE_DTLS(P_XREFID     IN VARCHAR2,
                                       P_REISSUEVAL IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO IFTB_PASSBBOK_REISSUE_DTLS VALUES (P_XREFID, P_REISSUEVAL);
    COMMIT;
  
  EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
      UPDATE IFTB_PASSBBOK_REISSUE_DTLS
         SET XREFID = P_XREFID, REISSUE_VAL = P_REISSUEVAL
       WHERE XREFID = P_XREFID;
      COMMIT;
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_PBK_REISSUE_DTLS');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    
  END PR_INSERT_PBK_REISSUE_DTLS;
  --passbook reissue charge ends

  FUNCTION FN_BUILD_PBDETAILS(P_PARENT_RES                  IN VARCHAR2,
                              P_TY_REC_CATM_PASSBOOK_DETAIL IN GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                              P_PARENT                      IN OUT NOCOPY VARCHAR2,
                              P_TAG                         IN OUT NOCOPY VARCHAR2,
                              P_DATA                        IN OUT NOCOPY VARCHAR2,
                              P_FORMAT                      IN OUT NOCOPY VARCHAR2,
                              P_ERR_CODE                    IN OUT NOCOPY VARCHAR2,
                              P_ERR_PARAM                   IN OUT NOCOPY VARCHAR2,
                              P_FN_CALL_ID                  IN OUT NOCOPY NUMBER,
                              P_TB_CUSTOM_DATA              IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
  
   RETURN BOOLEAN IS
    L_CURR_TAG VARCHAR2(255);
  
    /* --passbook reissue charge starts
    L_CATM_PASSBOOK_DETAILS CATMS_PASSBOOK_DETAILS%ROWTYPE;
    L_REISSUE_VAL CHAR(1);
    --passbook reissue charge ends*/
  
  BEGIN
    DBG('Inside gwpks_newpassbook_custom.fn_build_pbdetails ...=' ||
        P_FN_CALL_ID);
  
    --passbook reissue charge starts
    DBG('CHAR_FIELD20=' ||
        P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20);
  
    DBG('P_TAG=' || P_TAG);
  
    DBG('P_DATA=' || P_DATA);
  
    P_TAG  := 'CHAR_FIELD20' || '~' || P_TAG;
    P_DATA := P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20 || '~' ||
              P_DATA;
    --passbook reissue charge ends
  
    /*--sampath starts
    IF P_FN_CALL_ID = 1 AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('BRNQUERY', 'SAVEAUTOAUTH') THEN
    
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH);
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT);
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER);
      
      BEGIN
      
        SELECT *
          INTO L_CATM_PASSBOOK_DETAILS
          FROM CATMS_PASSBOOK_DETAILS
         WHERE BRANCH = P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH
           AND ACCOUNT =
               P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT
           AND STATUS = 'CLOSED';
        --AND PASSBOOK_NUMBER =
        --  P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CATM_PASSBOOK_DETAILS := NULL;
      END;
    
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER=' ||
          L_CATM_PASSBOOK_DETAILS.PASSBOOK_NUMBER);
    
      DBG('L_CATM_PASSBOOK_DETAILS.STATUS=' ||
          L_CATM_PASSBOOK_DETAILS.STATUS);
    
      IF L_CATM_PASSBOOK_DETAILS.STATUS = 'CLOSED' THEN
        
      SELECT REISSUE_VAL INTO L_REISSUE_VAL FROM IFTB_PASSBBOK_REISSUE_DTLS
      WHERE XREFID = P_TY_REC_CATM_PASSBOOK_DETAIL.g_rec_pb_dtls.XREF;
      
      P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20 := L_REISSUE_VAL;
      
        --Check for Reissue reason
        IF P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20 IS NULL THEN
        
          DBG('Passbook Reissue Reason should not be null');
          -- P_ERR_CODE := 'GW-PRIN-001';
          -- RETURN FALSE;
          --OVPKSS.PR_APPENDTBL('GW-PRIN-001', null);
          -- RETURN FALSE;
        
        END IF;
      
        IF P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.COUNT > 0 THEN
        
          FOR I IN P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.FIRST .. P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.LAST LOOP
          
            DBG('Inside teller rec assignment for i count ::' || I);
          
          --P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS(I).WAIVER := 'Y';
          
          END LOOP;
        END IF;
      
      END IF;
    
    END IF;
    
    --sampath ends*/
  
    DBG('Returning Successfully from gwpks_newpassbook_custom.fn_build_pbdetails..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of gwpks_newpassbook_custom.fn_build_pbdetails ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BUILD_PBDETAILS;

  FUNCTION FN_TS_TO_TYPE(PRECTYPE                      IN VARCHAR2,
                         PKEY                          IN VARCHAR2,
                         PDATA                         IN VARCHAR2,
                         P_TY_REC_CATM_PASSBOOK_DETAIL IN OUT NOCOPY GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                         P_ERR_CODE                    IN OUT NOCOPY VARCHAR2,
                         P_ERR_PARAM                   IN OUT NOCOPY VARCHAR2,
                         P_FN_CALL_ID                  IN OUT NOCOPY NUMBER,
                         P_TB_CUSTOM_DATA              IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA)
  
   RETURN BOOLEAN IS
  
    --passbook reissue charge starts
    L_CATM_PASSBOOK_DETAILS CATMS_PASSBOOK_DETAILS%ROWTYPE;
    L_REISSUE_VAL           CHAR(1);
    L_XREFID                VARCHAR2(100);
    --passbook reissue charge ends
  
  BEGIN
  
    DBG('Inside gwpks_newpassbook_custom.fn_ts_to_type ...=' ||
        P_FN_CALL_ID);
  
    DBG('PKEY=' || PKEY);
    DBG('PDATA=' || PDATA);
  
    --passbook reissue charge starts
    --L_XREFID      := 'FJB2001400297733';
    --L_REISSUE_VAL := 'R';
  
    IF P_FN_CALL_ID = 1 AND
       GWPKS_UTIL.PKG_ACTTYPE IN ('BRNQUERY', 'SAVEAUTOAUTH') THEN
    
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH);
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT);
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER);
    
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.g_rec_pb_dtls.xref=' ||
          P_TY_REC_CATM_PASSBOOK_DETAIL.g_rec_pb_dtls.xref);
    
      L_XREFID      := P_TY_REC_CATM_PASSBOOK_DETAIL.g_rec_pb_dtls.xref;
      L_REISSUE_VAL := SUBSTR(PDATA, INSTR(PDATA, '>') - 2, 1); --P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20;
    
      DBG('L_XREFID=' || L_XREFID);
      DBG('L_REISSUE_VAL=' || L_REISSUE_VAL);
    
      BEGIN
      
        SELECT *
          INTO L_CATM_PASSBOOK_DETAILS
          FROM CATMS_PASSBOOK_DETAILS
         WHERE BRANCH = P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.BRANCH
           AND ACCOUNT =
               P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT
           AND STATUS = 'CLOSED';
        --AND PASSBOOK_NUMBER =
        --  P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CATM_PASSBOOK_DETAILS := NULL;
      END;
      DBG('P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.PASSBOOK_NUMBER=' ||
          L_CATM_PASSBOOK_DETAILS.PASSBOOK_NUMBER);
    
      DBG('L_CATM_PASSBOOK_DETAILS.STATUS=' ||
          L_CATM_PASSBOOK_DETAILS.STATUS);
    
      IF L_CATM_PASSBOOK_DETAILS.STATUS = 'CLOSED' THEN
      
        IF L_REISSUE_VAL NOT IN ('R', 'D', 'F') THEN
          DBG('Passbook Reissue Reason should not be null');
          P_ERR_CODE := 'GW-PRIN-001';
          RETURN FALSE;
        END IF;
      
        PR_INSERT_PBK_REISSUE_DTLS(L_XREFID, L_REISSUE_VAL);
      
        SELECT REISSUE_VAL
          INTO L_REISSUE_VAL
          FROM IFTB_PASSBBOK_REISSUE_DTLS
         WHERE XREFID = P_TY_REC_CATM_PASSBOOK_DETAIL.g_rec_pb_dtls.XREF;
      
        DBG('L_REISSUE_VAL=' || L_REISSUE_VAL);
      
        P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20 := L_REISSUE_VAL;
      
        --Check for Reissue reason
        IF P_TY_REC_CATM_PASSBOOK_DETAIL.g_tb_ui_columns.char_field20 IS NULL THEN
        
          DBG('Passbook Reissue Reason should not be null');
          P_ERR_CODE := 'GW-PRIN-001';
          RETURN FALSE;
          --OVPKSS.PR_APPENDTBL('GW-PRIN-001', null);
          -- RETURN FALSE;
        
        END IF;
      
        IF P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.COUNT > 0 THEN
        
          FOR I IN P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.FIRST .. P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.LAST LOOP
          
            DBG('Inside teller rec assignment for i count ::' || I);
            DBG('L_REISSUE_VAL=' || L_REISSUE_VAL);
          
            IF L_REISSUE_VAL NOT IN ('D') THEN
            
              P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS(I).WAIVER := 'Y';
            
            END IF;
          
            IF I = 1 AND L_REISSUE_VAL IN ('D') THEN
            
              P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS(I).WAIVER := 'Y';
            
            END IF;
          
          --CHG_AMT1
          
          END LOOP;
        END IF;
      
      ELSE
        IF P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.COUNT > 0 THEN
        
          FOR I IN P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.FIRST .. P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS.LAST LOOP
          
            DBG('Inside teller rec assignment for i count ::' || I);
          
            P_TY_REC_CATM_PASSBOOK_DETAIL.G_TB_PB_CHG_DTLS(I).WAIVER := 'Y';
          
          --CHG_AMT1
          
          END LOOP;
        
        END IF;
      
      END IF;
    
    END IF;
  
    --passbook reissue charge starts ends
  
    DBG('Returning Successfully from gwpks_newpassbook_custom.fn_ts_to_type..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In When Others of gwpks_newpassbook_custom.fn_ts_to_type ..' ||
          SQLERRM);
      RETURN FALSE;
  END FN_TS_TO_TYPE;

  PROCEDURE PR_PROCESS_MSG(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                           P_REC_MSG_HEADER  IN GWPKS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                           P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                           P_INSTR_REC       IN OUT NOCOPY GWPKS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                           P_FLAG            IN OUT NUMBER,
                           P_FN_CALL_ID      IN OUT NUMBER,
                           P_TB_CUSTOM_DATA  IN OUT NOCOPY GLOBAL.TY_TB_CUSTOM_DATA,
                           P_ERR_CODE        IN OUT VARCHAR2,
                           P_ERR_PARAM       IN OUT VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('DE', 'pr_process_msg');
    RETURN;
  END PR_PROCESS_MSG;

  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    RETURN;
  END PR_SKIP_HANDLER;

  FUNCTION FN_TS_TO_TYPE_PRE(PRECTYPE                      IN VARCHAR2,
                             PKEY                          IN VARCHAR2,
                             PDATA                         IN VARCHAR2,
                             P_TY_REC_CATM_PASSBOOK_DETAIL IN OUT GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                             P_ERR_CODE                    IN OUT VARCHAR2,
                             P_ERR_PARAM                   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_ts_to_type');
  
    DBG('Returning success from fn_ts_to_type');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_newpassbook_custom.fn_ts_to_type ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE  := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_TS_TO_TYPE_PRE;

  FUNCTION FN_TS_TO_TYPE_POST(PRECTYPE                      IN VARCHAR2,
                              PKEY                          IN VARCHAR2,
                              PDATA                         IN VARCHAR2,
                              P_TY_REC_CATM_PASSBOOK_DETAIL IN OUT GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                              P_ERR_CODE                    IN OUT VARCHAR2,
                              P_ERR_PARAM                   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_ts_to_type');
  
    DBG('Returning success from fn_ts_to_type');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_newpassbook_custom.fn_ts_to_type ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
    
      RETURN FALSE;
  END FN_TS_TO_TYPE_POST;

  FUNCTION FN_BUILD_PBDETAILS_PRE(P_PARENT_RES                  IN VARCHAR2,
                                  P_TY_REC_CATM_PASSBOOK_DETAIL IN GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                                  P_PARENT                      IN OUT VARCHAR2,
                                  P_TAG                         IN OUT VARCHAR2,
                                  P_DATA                        IN OUT VARCHAR2,
                                  P_FORMAT                      IN OUT VARCHAR2,
                                  P_ERR_CODE                    IN OUT VARCHAR2,
                                  P_ERR_PARAM                   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_build_pbdetails_Pre');
  
    DBG('P_TAG=' || P_TAG);
    DBG('P_DATA=' || P_DATA);
  
    DBG('Returning success from fn_build_pbdetails_Pre');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_newpassbook_custom.fn_build_pbdetails_Pre ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE  := 'ST-OTHR-001';
      P_ERR_PARAM := NULL;
      RETURN FALSE;
  END FN_BUILD_PBDETAILS_PRE;

  FUNCTION FN_BUILD_PBDETAILS_POST(P_PARENT_RES                  IN VARCHAR2,
                                   P_TY_REC_CATM_PASSBOOK_DETAIL IN GWPKS_NEWPASSBOOK.TY_REC_CATM_PASSBOOK_DETAIL,
                                   P_PARENT                      IN OUT VARCHAR2,
                                   P_TAG                         IN OUT VARCHAR2,
                                   P_DATA                        IN OUT VARCHAR2,
                                   P_FORMAT                      IN OUT VARCHAR2,
                                   P_ERR_CODE                    IN OUT VARCHAR2,
                                   P_ERR_PARAM                   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    --PRF_CUSTOM_05_03072018 changes starts
    L_TB_EMPTY_TBL     GWPKS_CREATERETAILTLR.TY_RECS_TBL;
    L_TB_NAME_VAL_PAIR GWPKS_CREATERETAILTLR.TY_RECS_TBL;
    L_TS_TAG_VALUES    VARCHAR2(32767);
    L_TS_TAG_NAMES     VARCHAR2(32767);
    L_NODE_NAME        VARCHAR2(50);
    L_CURR_TAG         VARCHAR2(255);
    L_P_CNT            INTEGER;
    L_TAG              VARCHAR2(32767);
    L_DATA             VARCHAR2(32767);
    L_STR              VARCHAR2(32767);
    --PRF_CUSTOM_05_03072018 changes ends
  BEGIN
    DBG('Inside fn_build_pbdetails_Post');
  
    --PRF_CUSTOM_05_03072018 changes starts
    DBG('ANIKET IS ABOUT TO ADD SOME MORE DATA REQUIRED FOR THE PASSBOOK');
    DBG('BEFORE PARENT :' || P_PARENT);
    DBG('BEFORE FORMAT :' || P_FORMAT);
    DBG('BEFORE TAG :' || P_TAG);
    DBG('BEFORE DATA :' || P_DATA);
  
    L_TAG  := '';
    L_DATA := '';
  
    L_P_CNT     := 1;
    L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT,
                                               NULL,
                                               'N',
                                               L_P_CNT,
                                               '>'),
                       '??');
  
    WHILE L_NODE_NAME <> 'EOPL' LOOP
      DBG('Processing the node: ' || L_NODE_NAME);
      L_TB_NAME_VAL_PAIR := L_TB_EMPTY_TBL;
      L_TS_TAG_NAMES     := NVL(CSPKES_MISC.FN_GETPARAM(P_TAG,
                                                        P_TAG,
                                                        'N',
                                                        L_P_CNT,
                                                        '>'),
                                '??');
    
      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || L_TS_TAG_NAMES;
      END IF;
    
      L_TS_TAG_VALUES := NVL(CSPKES_MISC.FN_GETPARAM(P_DATA,
                                                     P_DATA,
                                                     'N',
                                                     L_P_CNT,
                                                     '>'),
                             '??');
    
      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || L_TS_TAG_VALUES;
      END IF;
    
      DBG('L_NODE_NAME :' || L_NODE_NAME);
    
      IF L_NODE_NAME = 'Blk-Catms-Passbook-Details' THEN
        DBG('ABOUT TO ADD SOME DATA SPECIFIC TO PRINCE');
      
        FOR X IN (SELECT *
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         (SELECT BRANCH_CODE
                            FROM STTMS_CUST_ACCOUNT
                           WHERE CUST_AC_NO =
                                 P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT)) LOOP
          L_TAG  := L_TAG || '~ACC_BRN~';
          L_DATA := L_DATA || X.BRANCH_CODE || '~';
        
          L_TAG  := L_TAG || 'ACC_BRN_NAME~';
          L_DATA := L_DATA || X.BRANCH_NAME || '~';
        
          L_TAG  := L_TAG || 'ACC_BRN_DET~';
          L_DATA := L_DATA || X.BRANCH_CODE || ' - ' || X.BRANCH_NAME || '~';
        END LOOP;
      
        FOR X IN (SELECT *
                    FROM STTM_CUSTOMER
                   WHERE CUSTOMER_NO =
                         (SELECT CUST_NO
                            FROM STTMS_CUST_ACCOUNT
                           WHERE CUST_AC_NO =
                                 P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT)) LOOP
          L_TAG  := L_TAG || 'UID_NAME~';
          L_DATA := L_DATA || X.UNIQUE_ID_NAME || '~';
        
          L_TAG  := L_TAG || 'UID_VALUE~';
          L_DATA := L_DATA || X.UNIQUE_ID_VALUE || '~';
        
          SELECT TYPE_NAME
            INTO L_STR
            FROM STTM_STATIC_TYPE
           WHERE TYPE = 'CIF_ID_TYPE'
             AND TYPE_VALUE = X.UNIQUE_ID_NAME;
        
          L_TAG  := L_TAG || 'ID_DETAILS~';
          L_DATA := L_DATA || L_STR || ' - ' || X.UNIQUE_ID_VALUE || '~';
        
          L_STR := X.FULL_NAME;
        END LOOP;
      
        FOR X IN (SELECT *
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO =
                         P_TY_REC_CATM_PASSBOOK_DETAIL.G_REC_PB_DTLS.ACCOUNT) LOOP
        
          --VANNROATH ADD NEW CURRENCY AND ACCOUNT CLASS FIELD
          L_TAG  := L_TAG || 'ACC_CCY~';
          L_DATA := L_DATA || NVL(TRIM(X.CCY), TRIM(L_STR)) || '~';
          L_TAG  := L_TAG || 'ACC_CLASS~';
          L_DATA := L_DATA || NVL(TRIM(X.ACCOUNT_CLASS), TRIM(L_STR)) || '~';
          L_TAG  := L_TAG || 'ACC_DETAILS2~';
          L_DATA := L_DATA || X.CCY || ' - ' || X.ACCOUNT_CLASS || ' - ' || '~';
          -- FINISHED CHANGED
        
          L_TAG  := L_TAG || 'ACC_NAME~';
          L_DATA := L_DATA || NVL(TRIM(X.AC_DESC), TRIM(L_STR)) || '~';
        
        END LOOP;
      
        L_TAG  := L_TAG || 'ISS_DATE~';
        L_DATA := L_DATA || TO_CHAR(GLOBAL.APPLICATION_DATE, 'DD-MON-RRRR') || '~';
      END IF;
    
      IF L_TS_TAG_NAMES <> '??' THEN
        L_TAG := L_TAG || '>';
      END IF;
    
      IF L_TS_TAG_VALUES <> '??' THEN
        L_DATA := L_DATA || '>';
      END IF;
    
      L_P_CNT     := L_P_CNT + 1;
      L_NODE_NAME := NVL(CSPKES_MISC.FN_GETPARAM(P_PARENT, L_P_CNT, '>'),
                         '??');
    END LOOP;
    P_TAG  := L_TAG;
    P_DATA := L_DATA;
    DBG('AFTER PARENT :' || P_PARENT);
    DBG('AFTER FORMAT :' || P_FORMAT);
    DBG('AFTER TAG :' || P_TAG);
    DBG('AFTER DATA :' || P_DATA);
    --PRF_CUSTOM_05_03072018 changes ends    
  
    DBG('Returning success from fn_build_pbdetails_Post');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_newpassbook_custom.fn_build_pbdetails_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
    
      RETURN FALSE;
  END FN_BUILD_PBDETAILS_POST;

  PROCEDURE PR_PROCESS_MSG_PRE(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                               P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                               P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                               P_INSTR_REC       IN OUT NOCOPY GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                               P_FLAG            IN OUT NUMBER,
                               P_ERR_CODE        IN OUT VARCHAR2,
                               P_ERR_PARAM       IN OUT VARCHAR2) IS
  BEGIN
    DBG('Inside pr_process_msg_Pre');
  
    DBG('Returning success from pr_process_msg_Pre');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'In When Others of gwpks_newpassbook_cluster.pr_process_msg_Pre..');
      DEBUG.PR_DEBUG('IF', SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN;
  END PR_PROCESS_MSG_PRE;

  PROCEDURE PR_PROCESS_MSG_POST(P_IS_IN_MSG_CLOB  IN VARCHAR2,
                                P_REC_MSG_HEADER  IN GWPKSS_SERVICE_ROUTER.TY_BIZ_PROCESS_HEADER,
                                P_IS_OUT_MSG_CLOB IN OUT VARCHAR2,
                                P_INSTR_REC       IN OUT NOCOPY GWPKSS_SERVICE_ROUTER.TY_PROCESSING_INSTRUCTIONS,
                                P_FLAG            IN OUT NUMBER,
                                P_ERR_CODE        IN OUT VARCHAR2,
                                P_ERR_PARAM       IN OUT VARCHAR2) IS
  BEGIN
    DBG('Inside pr_process_msg_Post');
  
    DBG('Returning success from pr_process_msg_Post');
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of gwpks_newpassbook_cluster.pr_process_msg_Post ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE := SQLERRM;
      RETURN;
  END PR_PROCESS_MSG_POST;

END GWPKS_NEWPASSBOOK_CUSTOM;
