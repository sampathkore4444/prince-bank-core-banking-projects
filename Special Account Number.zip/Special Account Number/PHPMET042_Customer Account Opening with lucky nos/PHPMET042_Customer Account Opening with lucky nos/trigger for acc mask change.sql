




CREATE or REPLACE TRIGGER ACC_MASK_CHANG_TRG
  AFTER UPDATE OF CUSTOMER_ACC_MASK ON STTMS_ACC_PARAM
  FOR EACH ROW
DECLARE

  l_count number;

BEGIN
  SELECT count(1)
    INTO l_count
    FROM sttm_new_Acc_mask
   WHERE branch_code = :NEW.branch_code;

  if l_count = 0 then
    insert into sttm_new_Acc_mask
    values
      (:new.CUSTOMER_ACC_MASK, :new.BRANCH_CODE);
  else
    UPDATE sttm_new_Acc_mask
       SET new_cust_acc_mask = :new.CUSTOMER_ACC_MASK
     WHERE branch_code = :NEW.branch_code;
  end if;

EXCEPTION

  WHEN others THEN
    debug.pr_debug('AC','error code='||SQLCODE);
END;
    
