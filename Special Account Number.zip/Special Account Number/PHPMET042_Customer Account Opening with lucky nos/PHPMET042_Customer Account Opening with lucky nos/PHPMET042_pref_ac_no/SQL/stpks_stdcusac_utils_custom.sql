create or replace package body stpks_stdcusac_utils_custom as
  ------------------------------------------------------------------------------------------
   This source is part of the Oracle FLEXCUBE Universal Banking Software Product.
   Copyright � 2007 - 2012  Oracle andor its affiliates.  All rights reserved.
  
   No part of this work may be reproduced, stored in a retrieval system,
   adopted or transmitted in any form or by any means, electronic, mechanical, photographic, graphic, optic recording or otherwise,
   translated in any language or computer language,
   without the prior written permission of Oracle andor its affiliates.
  
  
   Oracle Financial Services Software Limited.
   Oracle Park, Off Western Express Highway,
   Goregaon (East),
   Mumbai - 400 063, India.
  ------------------------------------------------------------------------------------------
  
  
  ---------------------------------------------------------------------------------------------------
    -- Author   MuraliDharan.R
    -- Created  30-Oct-2012
    -- Purpose  Extensible hooks for stpks_stdcusac_utils% packages. 9NT1525_12.0_CITI120_14807649
  
      Changed By                 Mythili P.
      Changed On                 08-Jan-2013
      Change Description         Extensibility Hook Changes
      Search string              9NT1525_12.0.1_CITI120_16082567
  
    Modified By                    Viba R
    Modified On                    12-Aug-2013
    Fix Description                Hook changes for Account Number generation
    Search String                  9NT1525_12.0.2_Internal_Retro_17297454 changes
  
  
      Changed By                 Ravikumar G
      Changed On                 08-Jul-2013
      Change Description         Extensibility Hooks provided for IBAN Account No generation.
      Retro Source             9NT1525_12.0.1_IXOFBRM_17055754
      Search String              9NT1525_12.0.2_RETRO_17448540
  
         Modified by         Hemalatha N
  
         Modified On         15-Oct-2013
  
         Modified reason     Hook changes retro done
  
         Search String       9NT1606_12.0.2_RETRO_SFR#17579906
  
    Changed By                   Anuja V.S
    Changed On                   16-Oct-2013
    Change Description           Providing Hook for having Different TD masking(Extensibility changes).
    Search String                9NT1606_12.0.2_RETRO_17611542
    Retro String                 9NT1606_12.0.1_RETRO_15963301
  
    Modified By            Naveen A
      Modified On            14-Nov-2013
      Modified Reason        Hook changes Required
      Search string          9NT1606_12.0.2_ISGBINTL_EXTN_17801280
  
    Changed By                   Shayam Sundar Ragunathan
    Changed On                   07-May-2014
    Change Description           Extensibility Hook Changes
    Search string                9NT1606_12.0.3_GBPFBN_RETRO_18731482
  
    Modified by                  Shayam Sundar Ragunathan
    Modified On                  15-May-2014
    Modified reason              Hook changes provided as requested
    Search string                9NT1606_12.0.3_INATAHK_RETRO_18768977
  
    Modified by                  Shayam Sundar Ragunathan
    Modified On                  15-May-2014
    Modified Reason              Hook Requested for fn_validate_joint_account
    Search String                9NT1606_12.0.3_IUSDABA_RETRO_18768994
  
    Modified by                  Shayam Sundar Ragunathan
    Modified On                  15-May-2014
    Modified reason              Hook changes retro done
    Search String                9NT1606_12.0.3_INTERNAL_RETRO_18769002
  
    Modified by                  Shayam Sundar Ragunathan
    Modified On                  15-May-2014
    Modified Reason              Hook Requested for fn_validate_customer
    Search String                9NT1606_12.0.3_INATAHK_RETRO_18769019
  
     Changed By                    Jumrose M
     Changed On                    23-June-2014
     Change Description            Hooks changes provided
     Search string                 9NT1606_12.0.3_RETRO_19045792
  
      Changed By                 Jumrose M
      Changed On                 26-June-2014
      Change Description         Hooks changes provided
      Search string              9NT1606_12.0.3_RETRO_19060483
  
     Modified By            Gowthami R
     Modified On            26-Jun-2014
     Modified Reason        Hook retro changes
     Search String          9NT1606_12.0.3_RETRO_SFR#19055389
  
    Changed By                 MuraliDharan R  Viba R
    Changed On                 26-June-2014
    Change Description         Hooks changes
    Search string              9NT1606_12.0.3_TIEN PHONG BANK_EXTN_19052955
  
  
     Modified By            Gowthami R
     Modified On            27-Jun-2014
     Modified Reason        Hook retro changes
     Search String          9NT1606_12.0.3_RETRO_SFR#19069981
  
    Modfied By            Poornima Ramasami
      Modified On           30-June-2014
      Modified Reason       Hooks Retro Changes
      Retro String           9NT1606_12.0.2_RETRO_19128012
      Search String         9NT1606_12.0.3_RETRO_19128351
  
    Modfied By            Suresh Babu B
      Modified On           08-July-2014
      Modified Reason       Hooks Retro Changes
      Search String         9NT1606_12.0.3_RETRO_19170694
  
      Modified By            Anuja.V.S
      Modified On            10-Nov-2014
      Modified Reason        Hook provided for CASA-TD Advices
      Search String          9NT1606_12_0_3_RETRO_19996521
      Retro String           9NT1606_12_0_2_EXTN_19956267
      
      Modified By            Srikanth Bandi
      Modified On            19-APR-2015
      Modified Reason        To validate the preferred ac no
      Search String         PHPMET042_Customer Account Opening with preferred ac no
      
      
     -------------------------------------------------------------------------------------------------------
     
  PROCEDURE Dbg(p_Msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    l_Msg = 'stpks_stdcusac_utils_custom =='  p_Msg;
    Debug.Pr_Debug('AE', l_Msg);
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  --9NT1606_12.0.2_RETRO_17611542 Begins
  FUNCTION fn_Update_Accno(p_function_id    IN VARCHAR2,
                           p_acc            IN sttms_cust_account.cust_ac_no%TYPE,
                           p_brn            IN sttms_cust_account.branch_code%TYPE,
                           p_fn_call_id     IN OUT NUMBER,
                           p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_Update_Accno');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_Update_Accno');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_Update_Accno' 
          sqlerrm);
      RETURN FALSE;
  END fn_Update_Accno;

  FUNCTION fn_Acc_Autogen(p_function_id    IN VARCHAR2,
                          p_ac_no_length   IN NUMBER,
                          p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                          p_fn_call_id     IN OUT NUMBER,
                          p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_Acc_Autogen');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_Acc_Autogen');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_Acc_Autogen' 
          sqlerrm);
      RETURN FALSE;
  END fn_Acc_Autogen;

  FUNCTION fn_Other_Defaults(p_function_id    IN VARCHAR2,
                             p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                             p_source         IN VARCHAR2,
                             p_skip_cust      IN BOOLEAN DEFAULT FALSE,
                             p_fn_call_id     IN OUT NUMBER,
                             p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_Other_Defaults');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_Other_Defaults');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_Other_Defaults' 
          sqlerrm);
      RETURN FALSE;
  END fn_Other_Defaults;
  --9NT1606_12.0.3_RETRO_19128351 starts
  FUNCTION fn_auth_custacc(p_Function_Id IN VARCHAR2,
                           p_stdcusac    IN OUT stpks_stdcusac_main.ty_stdcusac,
                           p_action_code IN VARCHAR2,
                           p_source      IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST', 'Start of fn_auth_custacc');
  
    debug.pr_debug('ST', 'Returning true from  fn_auth_custacc');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'Start of fn_auth_custacc');
      RETURN FALSE;
  END fn_auth_custacc;
  --9NT1606_12.0.3_RETRO_19128351 ends
  --9NT1606_12_0_3_RETRO_19996521 starts
  FUNCTION Fn_Custadvice_Entires(p_Function_Id    IN VARCHAR2,
                                 p_stdcusac       IN OUT Sttms_Cust_Account%ROWTYPE,
                                 p_fn_call_id     IN OUT NUMBER,
                                 p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST', 'Start of Fn_Custadvice_Entires');
  
    debug.pr_debug('ST', 'Returning true from  Fn_Custadvice_Entires');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'Start of Fn_Custadvice_Entires');
      RETURN FALSE;
  END Fn_Custadvice_Entires;

  FUNCTION Fn_Custacc_Entires(p_Function_Id    IN VARCHAR2,
                              p_stdcusac       IN OUT Sttms_Cust_Account%ROWTYPE,
                              p_fn_call_id     IN OUT NUMBER,
                              p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST', 'Start of Fn_Custacc_Entires');
  
    debug.pr_debug('ST', 'Returning true from  Fn_Custacc_Entires');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'Start of Fn_Custacc_Entires');
      RETURN FALSE;
  END Fn_Custacc_Entires;
  --9NT1606_12_0_3_RETRO_19996521 ends

  FUNCTION fn_validate_Cust_Acc(p_function_id    IN VARCHAR2,
                                p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                p_acc_param_rec  IN sttms_acc_param%ROWTYPE,
                                p_mask_branch    OUT sttms_acc_param.branch_code%TYPE,
                                p_fn_call_id     IN OUT NUMBER,
                                p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_validate_Cust_Acc');
  
    --PHPMET042_Customer Account Opening with preferred ac no starts
    BEGIN
    
      dbg('inside stpks_stdcusac_utils_custom.fn_validate_Cust_Acc');
      IF p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50 is not null then
        p_stdcusac.v_sttms_cust_account.cust_ac_no = p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50;
        Dbg('p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50=' 
            p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50);
        Dbg('p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD49=' 
            p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD49);
      
      END IF;
    
    EXCEPTION
      WHEN OTHERS THEN
        dbg('#$ wot. gone');
    END;
  
    --PHPMET042_Customer Account Opening with preferred ac no ends 
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_validate_Cust_Acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('Exception in stpks_stdcusac_utils_custom.fn_validate_Cust_Acc' 
          sqlerrm);
      RETURN FALSE;
  END fn_validate_Cust_Acc;

  --9NT1606_12.0.2_RETRO_17611542 Ends

  FUNCTION fn_default_custacc(p_function_id    IN VARCHAR2,
                              p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                              p_source         IN VARCHAR2,
                              p_user_id        IN smtbs_user.user_id%TYPE,
                              p_fn_call_id     IN OUT NUMBER,
                              p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_default_custacc');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_default_custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_default_custacc' 
          sqlerrm);
      RETURN FALSE;
  END fn_default_custacc;

  FUNCTION fn_chqbook_upld(p_wrk_Stdcusac     IN stpks_stdcusac_main.ty_stdcusac,
                           p_Source_Operation IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_fn_call_id       IN OUT NUMBER,
                           p_Tb_custom_Data   IN OUT Global.Ty_Tb_custom_Data,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2)
  
   RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.fn_chqbook_upld');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_chqbook_upld');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_chqbook_upld' 
          sqlerrm);
      RETURN FALSE;
  END fn_chqbook_upld;

  FUNCTION Fn_Modify_Acc(p_Function_Id    IN VARCHAR2,
                         p_Prev_Stdcusac  IN Stpks_Stdcusac_Main.Ty_Stdcusac,
                         p_Stdcusac       IN OUT Stpks_Stdcusac_Main.Ty_Stdcusac,
                         p_Action_Code    IN VARCHAR2,
                         p_Source         IN varchar2,
                         p_fn_call_id     IN OUT NUMBER,
                         p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data,
                         p_Err_Code       IN OUT varchar2,
                         p_Err_Params     IN OUT varchar2) RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.Fn_Modify_Acc');
  
    dbg('End  of stpks_stdcusac_utils_custom..Fn_Modify_Acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.Fn_Modify_Acc' 
          sqlerrm);
      RETURN FALSE;
  END Fn_Modify_Acc;

  --9NT1525_12.0.1_CITI120_16082567 changes starts
  FUNCTION Fn_Allow_Close(p_Function_Id    IN VARCHAR2,
                          p_Ac_No          IN Sttms_Cust_Account.Cust_Ac_No%TYPE,
                          p_Brn            IN Sttms_Cust_Account.Branch_Code%TYPE,
                          p_fn_call_id     IN NUMBER,
                          p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
    --PHOMET282 CHANGES 
    CURSOR cursor_check_status IS
      SELECT request_status,
             FIRST_CHECK_NO,
             EXTERNAL_REF_NO,
             ONCE_AUTH,
             BRANCH,
             CHEQUE_BOOK_TYPE,
             CHECK_LEAVES,
             ACCOUNT,
             SEQ_NO
        FROM catms_check_book
       WHERE ACCOUNT = p_Ac_No
         AND BRANCH = P_Brn
         AND (LOWER(REQUEST_STATUS) = 'requested' OR
             LOWER(REQUEST_STATUS) = 'generated');
  
    CURSOR cursor_atm_card IS
      SELECT ATM_ACC_NO, FCC_ACC_NO, ATM_CARD_NO
        FROM SWTM_CARD_DETAILS
       WHERE FCC_ACC_NO = p_Ac_No
         AND FCC_ACC_BRN = p_Brn;
  
    p_swdcdmnt         swpks_swdcdmnt_Main.ty_swdcdmnt;
    p_cadchboo         capks_cadchboo_main.ty_cadchboo;
    check_status_rec   p_cadchboo.v_catms_check_book%ROWTYPE;
    atm_card_details   p_swdcdmnt.v_swtm_card_details%ROWTYPE;
    p_source           varchar2(16);
    p_Source_Operation varchar2(16);
    --l_Multi_Trip_Id    varchar2(50);
    l_Request_No  varchar2(16);
    p_request_no  varchar2(16);
    p_Status      varchar2(16);
    p_Err_Code    varchar2(16);
    p_Err_Params  varchar2(16);
    no_atm_card   NUMBER(2);
    L_MULTITRIPID VARCHAR2(50);
    ACTION        VARCHAR2(10);
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.Fn_Allow_Close');
       
    for atm_card_details in cursor_atm_card LOOP
      p_swdcdmnt.v_swtm_card_details.ATM_ACC_NO  = atm_card_details.Atm_Acc_No;
      p_swdcdmnt.v_swtm_card_details.FCC_ACC_NO  = atm_card_details.fcc_acc_no;
      p_swdcdmnt.v_swtm_card_details.ATM_CARD_NO = atm_card_details.atm_card_no;
      IF NOT swpks_swdcdmnt_main.Fn_main(p_Source,
                                         p_Source_Operation,
                                         p_Function_Id,
                                         cspks_req_global.p_Close,
                                         L_MULTITRIPID,
                                         '1',
                                         p_swdcdmnt,
                                         p_Status,
                                         p_Err_Code,
                                         p_err_params) THEN
        debug.pr_debug('ST',
                       'mspkss.fn_gen_msg_out failed for account ;' 
                       p_Ac_No);
      END IF;
    END LOOP;
    
    for check_status_rec in cursor_check_status LOOP
     --L_MULTITRIPID = '653456789';
     L_MULTITRIPID =  Cspks_Req_Wrapper.g_Multi_Trip_Id;
      p_cadchboo.v_catms_check_book.FIRST_CHECK_NO   = check_status_rec.FIRST_CHECK_NO;
      p_cadchboo.v_catms_check_book.External_ref_no  = check_status_rec.External_ref_no;
      p_cadchboo.v_catms_check_book.Once_auth        = check_status_rec.Once_auth;
      p_cadchboo.v_catms_check_book.Branch           = check_status_rec.Branch;
      p_cadchboo.v_catms_check_book.CHEQUE_BOOK_TYPE = check_status_rec.CHEQUE_BOOK_TYPE;
      p_cadchboo.v_catms_check_book.CHECK_LEAVES     = check_status_rec.CHECK_LEAVES;
      p_cadchboo.v_catms_check_book.ACCOUNT          = check_status_rec.ACCOUNT;
      p_cadchboo.v_catms_check_book.SEQ_NO           = check_status_rec.SEQ_NO;
      Dbg('SEQ NO IS  'p_cadchboo.v_catms_check_book.SEQ_NO);
    
      IF NOT capks_cadchboo_main.Fn_main(p_source,
                                         p_Source_Operation,
                                         p_Function_Id,
                                         cspks_req_global.p_Close,
                                         L_MULTITRIPID ,
                                         '1',
                                         p_cadchboo,
                                         p_Status,
                                         p_Err_Code,
                                         p_Err_Params) THEN
        debug.pr_debug('ST',
                       'closure of cadchboo failed for account ;' 
                       p_Ac_No);
      END IF;
    
    END LOOP;
  
    dbg('End  of stpks_stdcusac_utils_custom..Fn_Allow_Close');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.Fn_Allow_Close' 
          sqlerrm);
      RETURN FALSE;
  END Fn_Allow_Close;
  --9NT1525_12.0.1_CITI120_16082567 changes ends

  --9NT1525_12.0.2_Internal_Retro_17297454 changes Starts
  FUNCTION Fn_Accgen(p_Function_Id    IN VARCHAR2,
                     p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                     p_fn_call_id     IN NUMBER,
                     p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start  of stpks_stdcusac_utils_custom.Fn_Accgen');
  
    dbg('End  of stpks_stdcusac_utils_custom..Fn_Accgen');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.Fn_Accgen' 
          sqlerrm);
      RETURN FALSE;
  END Fn_Accgen;
  --9NT1525_12.0.2_Internal_Retro_17297454 changes Ends

  -- 9NT1525_12.0.2_RETRO_17448540 Starts
  ---------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION fn_validate_iban(p_function_id    IN VARCHAR2,
                            p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                            p_action_code    IN VARCHAR2,
                            p_fn_call_id     IN OUT NUMBER,
                            p_tb_custom_data IN OUT global.ty_tb_custom_data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Inside fn_validate_IBAN - Custom');
    dbg('Set Skip Kernel to True to Skip IBAN account Gen');
    --Global.Pr_Set_Skip_Kernel;
    dbg('fn_validate_IBAN returning true - Cluster');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT of fn_validate_IBAN Custom with '  SQLERRM 
          ' and trace '  dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END fn_validate_iban;
  -- 9NT1525_12.0.2_RETRO_17448540 Ends

  --9NT1606_12.0.2_RETRO_SFR#17579906  Changes starts
  FUNCTION Fn_Copy_Init(p_function_id    IN VARCHAR2,
                        p_stdcusac       IN OUT Stpks_Stdcusac_Main.Ty_Stdcusac,
                        p_Fn_Call_ID     NUMBER,
                        p_Tb_Custom_data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Copy_Init ');
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'WOT exception of Fn_Copy_Init'  SQLERRM);
      RETURN FALSE;
  END Fn_Copy_Init;
  --9NT1606_12.0.2_RETRO_SFR#17579906   Changes ends
  --9NT1606_12.0.2_ISGBINTL_EXTN_17801280 changes starts
  FUNCTION fn_validate_iban_acc(p_function_id    IN VARCHAR2,
                                p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                p_action_code    IN VARCHAR2,
                                p_fn_call_id     NUMBER,
                                p_tb_custom_data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_validate_iban_acc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST',
                     'WOT exception of fn_validate_iban_acc'  SQLERRM);
      RETURN FALSE;
  END fn_validate_iban_acc;
  --9NT1606_12.0.2_ISGBINTL_EXTN_17801280 changes ends
  --9NT1606_12.0.3_RETRO_SFR#19055389 starts
  FUNCTION Fn_Authorize_Custacc(p_Function_Id    IN VARCHAR2,
                                p_Rec_Custacc    IN OUT Sttms_Cust_Account%ROWTYPE,
                                p_fn_call_id     NUMBER,
                                p_tb_custom_data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Authorize_Custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST',
                     'WOT exception of Fn_Authorize_Custacc'  SQLERRM);
      RETURN FALSE;
  END Fn_Authorize_Custacc;
  --9NT1606_12.0.3_RETRO_SFR#19055389 ends
  --9NT1606_12.0.3_RETRO_19060483 changes starts
  FUNCTION fn_deposit_def_validate(p_function_id    IN VARCHAR2,
                                   p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                   p_action_code    IN VARCHAR2,
                                   p_source         IN VARCHAR2,
                                   p_fn_call_id     NUMBER,
                                   p_tb_custom_data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_deposit_def_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST',
                     'WOT exception of fn_deposit_def_validate'  SQLERRM);
      RETURN FALSE;
  END fn_deposit_def_validate;
  --9NT1606_12.0.3_RETRO_19060483 changes ends
  --9NT1606_12.0.3_INTERNAL_RETRO_18769002- starts
  FUNCTION Fn_Validate_Closure_Det(p_Function_Id     IN VARCHAR2,
                                   p_Close_Reqd      IN VARCHAR2,
                                   p_Stcaclos        IN OUT Stpks_Stcaclos_Main.Ty_Stcaclos,
                                   p_Source          IN Cotms_Source.Source_Code%TYPE,
                                   p_Instr_Details   OUT VARCHAR2,
                                   p_Offset_Details  OUT VARCHAR2,
                                   p_Fn_Call_Id      IN OUT NUMBER,
                                   p_Tb_Cluster_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    Dbg('Inside stpks_stdcusac_utils_custom.Fn_Validate_Closure_Det');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Dbg('Failed in WOE of stpks_stdcusac_utils_custom.Fn_Validate_Closure_Det  ' 
          sqlcode  sqlerrm);
      RETURN FALSE;
  END Fn_Validate_Closure_Det;
  --9NT1606_12.0.3_INTERNAL_RETRO_18769002- ends
  --9NT1606_12.0.3_RETRO_SFR#19069981 starts
  FUNCTION fn_populate_ic_details(p_function_id    IN VARCHAR2,
                                  p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                  p_Fn_Call_ID     Number,
                                  p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_populate_ic_details');
    dbg('End  of stpks_stdcusac_utils_custom.fn_populate_ic_details');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_populate_ic_details' 
          sqlerrm);
      RETURN FALSE;
  END fn_populate_ic_details;

  FUNCTION fn_upload(p_function_id    IN VARCHAR2,
                     p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                     p_action_code    IN VARCHAR2,
                     p_source         IN VARCHAR2,
                     p_Err_Code       IN OUT VARCHAR2,
                     p_Err_Params     IN OUT VARCHAR2,
                     p_Fn_Call_ID     Number,
                     p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_upload');
    dbg('End  of stpks_stdcusac_utils_custom.fn_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_upload' 
          sqlerrm);
      RETURN FALSE;
  END fn_upload;
  --9NT1606_12.0.3_RETRO_SFR#19069981 ends
  --9NT1606_12.0.3_IUSDABA_RETRO_18768994 Starts
  FUNCTION fn_validate_joint_account(p_function_id    IN VARCHAR2,
                                     p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                     p_action_code    IN VARCHAR2,
                                     p_Fn_Call_ID     Number,
                                     p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_validate_joint_account');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_validate_joint_account');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_validate_joint_account' 
          sqlerrm);
      RETURN FALSE;
  END fn_validate_joint_account;
  --9NT1606_12.0.3_IUSDABA_RETRO_18768994 Ends
  --9NT1606_12.0.3_INATAHK_RETRO_18769019 Starts
  FUNCTION fn_validate_customer(p_Function_Id    IN VARCHAR2,
                                p_cust           sttms_cust_account.cust_no%TYPE,
                                p_acccls         sttms_cust_account.account_class%TYPE,
                                p_Fn_Call_ID     NUMBER,
                                p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_validate_customer');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_validate_customer');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_validate_customer' 
          sqlerrm);
      RETURN FALSE;
  END fn_validate_customer;
  --9NT1606_12.0.3_INATAHK_RETRO_18769019 Ends
  --9NT1606_12.0.3_INATAHK_RETRO_18768977 changes starts
  FUNCTION fn_acccls_pickup(p_function_id    IN VARCHAR2,
                            p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                            p_source         IN VARCHAR2,
                            p_skip_cust      IN BOOLEAN DEFAULT FALSE,
                            p_Fn_Call_ID     Number,
                            p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_acccls_pickup');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_acccls_pickup');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_acccls_pickup' 
          sqlerrm);
      RETURN FALSE;
  END fn_acccls_pickup;

  FUNCTION fn_validate_items(p_Source         IN VARCHAR2,
                             p_function_id    IN VARCHAR2,
                             p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                             p_action_code    IN VARCHAR2,
                             p_Err_Code       IN OUT VARCHAR2,
                             p_Err_Params     IN OUT VARCHAR2,
                             p_Fn_Call_ID     Number,
                             p_Tb_Custom_Data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_validate_items');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_validate_items');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_validate_items' 
          sqlerrm);
      RETURN FALSE;
  END fn_validate_items;
  --9NT1606_12.0.3_INATAHK_RETRO_18768977 changes ends
  --9NT1606_12.0.3_GBPFBN_RETRO_18731482 Begins
  FUNCTION fn_pickup_mis(p_function_id    IN VARCHAR2,
                         p_micacctm       IN OUT mipks_micacctm_main.ty_micacctm,
                         p_pkp_flag       IN BOOLEAN DEFAULT FALSE,
                         p_del_flag       IN BOOLEAN DEFAULT FALSE,
                         P_Fn_Call_Id     IN OUT NUMBER,
                         p_tb_custom_data IN OUT global.ty_tb_custom_data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST', 'Start of fn_pickup_mis');
    debug.pr_debug('ST', 'Returning true from  fn_pickup_mis');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'Failed in fn_pickup_mis'  SQLCODE  SQLERRM);
      RETURN FALSE;
  END fn_pickup_mis;
  --9NT1606_12.0.3_GBPFBN_RETRO_18731482 Ends
  --9NT1606_12.0.3_RETRO_19045792 changes starts
  FUNCTION Fn_Close_Custacc(p_Function_Id    IN VARCHAR2,
                            p_Stcaclos       IN OUT Stpks_Stcaclos_Main.Ty_Stcaclos,
                            p_Source         IN Cotms_Source.Source_Code%TYPE,
                            p_fn_call_id     NUMBER,
                            p_tb_custom_data IN OUT Global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.Fn_Close_Custacc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('ST', 'WOT exception of Fn_Close_Custacc'  SQLERRM);
      RETURN FALSE;
  END Fn_Close_Custacc;
  --9NT1606_12.0.3_RETRO_19045792 changes ends
  --9NT1606_12.0.3_TIEN PHONG BANK_EXTN_19052955 Begins
  FUNCTION fn_payinout_validate(p_function_id    IN VARCHAR2,
                                p_action_code    IN VARCHAR2,
                                p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                                p_err_flag       IN OUT NUMBER,
                                P_Fn_Call_Id     IN OUT NUMBER,
                                p_Tb_Custom_Data IN OUT global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_payinout_validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WOT exception of fn_payinout_validate'  SQLERRM);
      RETURN FALSE;
  END fn_payinout_validate;

  FUNCTION fn_payinout_default(p_function_id    IN VARCHAR2,
                               p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                               p_action_code    IN VARCHAR2,
                               p_Source         IN VARCHAR2,
                               p_err_flag       IN OUT NUMBER,
                               P_Fn_Call_Id     IN OUT NUMBER,
                               p_Tb_Custom_Data IN OUT global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN IS
  BEGIN
    debug.pr_debug('ST',
                   'Inside stpks_stdcusac_utils_custom.fn_payinout_default');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WOT exception of fn_payinout_default'  SQLERRM);
      RETURN FALSE;
  END fn_payinout_default;
  --9NT1606_12.0.3_TIEN PHONG BANK_EXTN_19052955 Ends
  --9NT1606_12.0.3_RETRO_19170694 starts
  FUNCTION fn_populate_amtdt(p_Function_Id    IN VARCHAR2,
                             p_stdcusac       IN OUT stpks_stdcusac_main.ty_stdcusac,
                             p_fn_call_id     IN OUT NUMBER,
                             p_Tb_Custom_Data IN OUT global.Ty_Tb_Custom_Data)
    RETURN BOOLEAN is
  BEGIN
    dbg('Start of stpks_stdcusac_utils_custom.fn_populate_amtdt');
  
    dbg('End  of stpks_stdcusac_utils_custom.fn_populate_amtdt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('WO Exception in stpks_stdcusac_utils_custom.fn_populate_amtdt' 
          sqlerrm);
      RETURN FALSE;
  END fn_populate_amtdt;
  --9NT1606_12.0.3_RETRO_19170694 ends
end stpks_stdcusac_utils_custom;
