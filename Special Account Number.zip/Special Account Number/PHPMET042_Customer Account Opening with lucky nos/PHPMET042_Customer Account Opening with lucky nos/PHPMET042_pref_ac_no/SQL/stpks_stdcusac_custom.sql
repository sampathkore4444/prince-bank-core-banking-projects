CREATE OR REPLACE PACKAGE BODY stpks_stdcusac_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcusac_custom.sql
  **
  ** Module     : Static Maintenance  
  ** 
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright � 2008,2015 , Oracle and/or its affiliates.  All rights reserved
  ** 
  ** 
  ** No part of this work may be reproduced, stored in a retrieval system, adopted 
  ** or transmitted in any form or by any means, electronic, mechanical, 
  ** photographic, graphic, optic recording or otherwise, translated in any 
  ** language or computer language, without the prior written permission of 
  ** Oracle and/or its affiliates. 
  ** 
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East), 
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :  
  Changed By         :  
  Change Description :  
  
  Modified By           : Madhumati Vyakaranam
  Modified On           : 06-Apr-2014
  Modified Reason       : Added address change advice generation code.
  Search String         : Metro Bank PHPMETCASA25APR13_012
  
  
  Modified By         : Srikanth Bandi
  Modified On         : 03-MAR-2015
  Change Description  : Validation for Joint account restriction
  Search String       : PHPMET046_Restriction of Joint Accounts 
  
  
   Modified By         : Srikanth Bandi
  Modified On         : 10-APR-2015
  Change Description  : To escape, Account mask popup  on providing pref_cust_ac_no
  Search String       : PHPMET042_Customer Account Opening with preferred ac nos
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    l_Msg := 'stpks_stdcusac_Custom ==>' || p_Msg;
    Debug.Pr_Debug('ST', l_Msg);
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcusac         IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcusac_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcusac         IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    if p_Action_Code = Cspks_Req_Global.p_Close THEN
      Dbg('in close function pre check');
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                       p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    no_check_status NUMBER(3);
    no_atm_card     NUMBER(3);
  
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    IF p_Action_Code = cspks_req_global.p_Close THEN
      --count the number of unused check leaves
      SELECT COUNT(*)
        INTO no_check_status
        FROM catms_check_book
       WHERE ACCOUNT = p_stdcusac.v_sttms_cust_account.cust_ac_no
         AND BRANCH = GLOBAL.current_branch
         AND (LOWER(REQUEST_STATUS) = 'requested' OR
             LOWER(REQUEST_STATUS) = 'generated');
    
      --count the number of cards associated
    
      SELECT COUNT(*)
        INTO no_atm_card
        FROM SWTM_CARD_DETAILS
       WHERE FCC_ACC_NO = p_stdcusac.v_sttms_cust_account.cust_ac_no
         AND FCC_ACC_BRN = GLOBAL.current_branch;
    
      IF no_check_status > 0 THEN
        Dbg('hello in check status ' ||
            p_stdcusac.v_sttms_cust_account.cust_ac_no);
        pr_log_error(p_source, 'STDCUSAC', 'IF-CHECK-01', '');
        -- RETURN FALSE;
      END IF;
    
      -- IF no_card_details > 0 OR 
      IF no_atm_card > 0 THEN
        Dbg('hello');
        --p_err_code   := 'IF-ATM-001';
        -- p_err_params := '';
        -- pr_log_error(p_source, 'STDCUSAC', 'IF-ATM-001', '');
        -- ovpkss.pr_appendTbl(p_err_code, p_err_params);
        --RETURN FALSE;
      END IF;
    END IF;
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    CURSOR c1 IS
      SELECT A.DOCUMENT_TYPE,
             A.VALID_TILL,
             A.EXP_SUB_DATE,
             A.ACTUAL_SUB_DATE,
             A.DOCUMENT_REF_NO,
             A.CHECKED,
             B.MANDATORY
        FROM STTMS_CUST_DOC_CHECKLIST A, STTMS_CUST_DOC_CUSTOM B
       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
         AND A.DOCUMENT_TYPE = B.DOCUMENT_TYPE
         AND A.CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    CURSOR C2 IS
      SELECT *
        FROM STTM_ACLASS_DOCTYPE
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    r1 c1%rowtype;
    r2 c2%rowtype;
  
    i       PLS_INTEGER := 0;
    counter PLS_INTEGER := 1;
  
    l_stdaccls sttms_account_class_custom.joint_ac_restriction%TYPE; --PHPMET046_Restriction of Joint Accounts Changes
  
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
    Dbg('rahul coll');
  
    --PHPMET046_Restriction of Joint Accounts Changes start   
  
    IF p_Function_Id = 'STDCUSAC' and P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      Begin
        select joint_ac_restriction
          into l_stdaccls
          from sttms_account_class_custom
         where account_class =
               p_stdcusac.v_sttms_cust_account.account_class;
      Exception
        when others then
          l_stdaccls := NULL;
      End;
      Dbg(' Joint ac restriction checked :' || l_stdaccls);
      Dbg('Account type validation starts' || p_action_code);
    
      IF l_stdaccls = 'Y'
      -- and  p_wrk_stdcusac.v_sttms_cust_account.Account_type = 'J' 
       Then
        Dbg('Joint account is restricted');
        Pr_Log_Error(p_Function_Id, p_Source, 'ST-ACC-361', '');
      END IF;
    End if;
  
    --PHPMET046_Restriction of Joint Accounts changes end
  
    ---- 7159_PHPMET029 begins
    Dbg('rahul coll');
    Dbg('rahulraj');
  
    --- The record  r1 will fetch customer documents
    IF p_Action_Code = 'DEFAULT' THEN
      FOR r1 IN c1 LOOP
        i := i + counter;
      
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).document_type := r1.DOCUMENT_TYPE;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).MANDATORY := r1.MANDATORY;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).EXPIRY_DATE := r1.VALID_TILL;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).EXPECTED_DATE_SUBMISSION := r1.EXP_SUB_DATE;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).ACTUAL_SUBMISSION_DATE := r1.ACTUAL_SUB_DATE;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).CHECKED := r1.CHECKED;
      
      END LOOP;
    END IF;
  
    --- The record r2 will fetch account class  documents
    IF p_Action_Code = 'DEFAULT' THEN
      FOR r2 IN c2 LOOP
        i := i + counter;
      
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).document_type := r2.DOCUMENT_TYPE;
        p_Wrk_stdcusac.v_sttms_doctype_check_list(i).MANDATORY := r2.MANDATORY;
      END LOOP;
    END IF;
    ---- 7159_PHPMET029 ends
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    pdcn                    VARCHAR2(2000);
    p_msg_handoff           mstbs_msg_handoff%ROWTYPE;
    l_serno                 VARCHAR2(50);
    l_dcn                   mstbs_msg_handoff.dcn%TYPE;
    cust_acc_rec            sttms_cust_account%rowtype;
    l_format                mstbs_msg_handoff.msg_type%TYPE;
    l_sttms_branch          sttms_branch%rowtype;
    l_sttms_customer        sttms_customer%rowtype;
    l_sttms_customer_custom sttms_customer_custom%rowtype;
    l_sttms_bank            sttms_bank%rowtype;
  
    CURSOR cursor_check_status IS
      SELECT request_status,
             FIRST_CHECK_NO,
             EXTERNAL_REF_NO,
             ONCE_AUTH,
             BRANCH,
             CHEQUE_BOOK_TYPE,
             CHECK_LEAVES,
             ACCOUNT,
             SEQ_NO
        FROM catms_check_book
       WHERE ACCOUNT = p_stdcusac.v_sttms_cust_account.cust_ac_no
         AND BRANCH = p_stdcusac.v_sttms_cust_account.branch_code
         AND (LOWER(REQUEST_STATUS) = 'requested' OR
             LOWER(REQUEST_STATUS) = 'generated');
  
    CURSOR cursor_atm_card IS
      SELECT ATM_ACC_NO, FCC_ACC_NO, ATM_CARD_NO
        FROM SWTM_CARD_DETAILS
       WHERE FCC_ACC_NO = p_stdcusac.v_sttms_cust_account.cust_ac_no
         AND FCC_ACC_BRN = p_stdcusac.v_sttms_cust_account.branch_code;
  
    p_swdcdmnt       swpks_swdcdmnt_Main.ty_swdcdmnt;
    p_cadchboo       capks_cadchboo_main.ty_cadchboo;
    check_status_rec p_cadchboo.v_catms_check_book%ROWTYPE;
    atm_card_details p_swdcdmnt.v_swtm_card_details%ROWTYPE;
    p_request_no     varchar2(16);
    p_Status         varchar2(16);
    no_atm_card      NUMBER(2);
    Procedure pr_putits(pdcn     mstbs_adv_input.dcn%type,
                        in_loop  mstbs_adv_input.LOOP_NO%Type,
                        in_field varchar2,
                        in_value varchar2) IS
    begin
      icpkss_util.dbg('b4 INSERT INTO MSTBS_AVD_INPUT');
      insert into mstbs_adv_input
        (dcn, loop_no, field_tag, value, justify)
      values
        (pdcn, in_loop, in_field, in_value, 'L');
      icpkss_util.dbg('Inserted string is ' || pdcn || '~' || in_field || '~' ||
                      to_char(in_loop) || '~' || in_value || '~L');
    end;
  
  BEGIN
    --Metro Bank PHPMETCASA25APR13_012 changes start
    Dbg('In Fn_Post_Upload_Db..');
  
    /*   IF (p_Action_Code = cspks_req_global.p_Close)
          THEN
    for atm_card_details in cursor_atm_card LOOP
      p_swdcdmnt.v_swtm_card_details.ATM_ACC_NO  := atm_card_details.Atm_Acc_No;
      p_swdcdmnt.v_swtm_card_details.FCC_ACC_NO  := atm_card_details.fcc_acc_no;
      p_swdcdmnt.v_swtm_card_details.ATM_CARD_NO := atm_card_details.atm_card_no;
      IF NOT swpks_swdcdmnt_main.Fn_main(p_Source,
                                         p_Source_Operation,
                                         p_Function_Id,
                                         cspks_req_global.p_Close,
                                         p_Multi_Trip_Id,
                                         '1',
                                         p_swdcdmnt,
                                         p_Status,
                                         p_Err_Code,
                                         p_err_params) THEN
        debug.pr_debug('ST',
                       'mspkss.fn_gen_msg_out failed for account ;' ||
                       p_stdcusac.v_sttms_cust_account.cust_ac_no);
      END IF;
    END LOOP;
    
    for check_status_rec in cursor_check_status LOOP
    
      p_cadchboo.v_catms_check_book.FIRST_CHECK_NO   := check_status_rec.FIRST_CHECK_NO;
      p_cadchboo.v_catms_check_book.External_ref_no  := check_status_rec.External_ref_no;
      p_cadchboo.v_catms_check_book.Once_auth        := check_status_rec.Once_auth;
      p_cadchboo.v_catms_check_book.Branch           := check_status_rec.Branch;
      p_cadchboo.v_catms_check_book.CHEQUE_BOOK_TYPE := check_status_rec.CHEQUE_BOOK_TYPE;
      p_cadchboo.v_catms_check_book.CHECK_LEAVES     := check_status_rec.CHECK_LEAVES;
      p_cadchboo.v_catms_check_book.ACCOUNT          := check_status_rec.ACCOUNT;
      p_cadchboo.v_catms_check_book.SEQ_NO           := check_status_rec.SEQ_NO;
      Dbg('SEQ NO IS  '||p_cadchboo.v_catms_check_book.SEQ_NO);
    
      IF NOT capks_cadchboo_main.Fn_main(p_source,
                                         p_Source_Operation,
                                         p_Function_Id,
                                         cspks_req_global.p_Close,
                                         p_Multi_Trip_Id ,
                                         '1',
                                         p_cadchboo,
                                         p_Status,
                                         p_Err_Code,
                                         p_Err_Params) THEN
        debug.pr_debug('ST',
                       'closure of cadchboo failed for account ;' ||
                       p_stdcusac.v_sttms_cust_account.cust_ac_no);
      END IF;
    
    END LOOP;
    END IF;*/
  
    BEGIN
      SELECT *
        INTO l_sttms_customer
        FROM sttms_customer
       WHERE customer_no = p_stdcusac.v_sttms_cust_account.CUST_NO;
    EXCEPTION
    
      WHEN OTHERS THEN
        debug.pr_debug('ST',
                       'When others of select sttm_customer...>' || sqlerrm);
    END;
  
    BEGIN
      SELECT *
        INTO l_sttms_customer_custom
        FROM sttms_customer_custom
       WHERE customer_no = p_stdcusac.v_sttms_cust_account.CUST_NO;
    EXCEPTION
    
      WHEN OTHERS THEN
        debug.pr_debug('ST',
                       'When others of select sttm_customer...>' || sqlerrm);
    END;
  
    IF p_Action_Code = Cspks_Req_Global.p_Modify --Cspks_Req_Global.p_Auth
     THEN
      IF cspks_feature.fn_installed('ADRCHGADV') THEN
        IF ((lower(p_prev_stdcusac.v_sttms_cust_account.ADDRESS1) <>
           lower(p_wrk_stdcusac.v_sttms_cust_account.ADDRESS1)) OR
           (lower(p_prev_stdcusac.v_sttms_cust_account.ADDRESS2) <>
           lower(p_wrk_stdcusac.v_sttms_cust_account.ADDRESS2)) OR
           (lower(p_prev_stdcusac.v_sttms_cust_account.ADDRESS3) <>
           lower(p_wrk_stdcusac.v_sttms_cust_account.ADDRESS3)) OR
           (lower(p_prev_stdcusac.v_sttms_cust_account.ADDRESS4) <>
           lower(p_wrk_stdcusac.v_sttms_cust_account.ADDRESS4)) OR
           (p_prev_stdcusac.v_sttms_cust_account.ADDRESS1 IS NULL AND
           p_wrk_stdcusac.v_sttms_cust_account.ADDRESS1 IS NOT NULL) OR
           (p_prev_stdcusac.v_sttms_cust_account.ADDRESS2 IS NULL AND
           p_wrk_stdcusac.v_sttms_cust_account.ADDRESS2 IS NOT NULL) OR
           (p_prev_stdcusac.v_sttms_cust_account.ADDRESS3 IS NULL AND
           p_wrk_stdcusac.v_sttms_cust_account.ADDRESS3 IS NOT NULL) OR
           (p_prev_stdcusac.v_sttms_cust_account.ADDRESS4 IS NULL AND
           p_wrk_stdcusac.v_sttms_cust_account.ADDRESS4 IS NOT NULL)) AND
           l_sttms_customer_custom.intimate_adr_change = 'Y'
        
         THEN
          Dbg('address are not equal');
        
          select * into l_sttms_bank from sttms_bank;
        
          BEGIN
            SELECT *
              INTO l_sttms_branch
              FROM sttms_branch
             WHERE branch_code = GLOBAL.CURRENT_BRANCH;
          EXCEPTION
            WHEN OTHERS THEN
              debug.pr_debug('MS',
                             'Failed to select branch_name cos ' || SQLERRM);
              NULL;
          END;
        
          IF NOT trpkss.fn_get_process_refno(global.current_branch,
                                             'MSOG',
                                             global.application_date,
                                             l_serno,
                                             l_dcn,
                                             p_err_code) THEN
            RETURN FALSE;
          END IF;
        
          INSERT INTO mstbs_msg_handoff
            (branch,
             dcn,
             NAME,
             address1,
             address2,
             address3,
             address4,
             reference_no,
             esn,
             module,
             msg_type,
             product,
             ccy,
             from_date,
             receiver,
             media,
             msg_status,
             generate_status,
             hold_status,
             auth_stat,
             directive_status,
             cust_ac_no,
             maker_id,
             maker_dt_stamp,
             checker_id,
             checker_dt_stamp,
             mod_no)
          VALUES
            (GLOBAL.current_branch,
             l_dcn,
             l_sttms_customer.customer_name1,
             l_sttms_customer.address_line1,
             l_sttms_customer.address_line2,
             l_sttms_customer.address_line3,
             l_sttms_customer.address_line4,
             p_stdcusac.v_sttms_cust_account.CUST_AC_NO,
             '1',
             'ST',
             'ADR_CHANGE_ADV',
             'ALL',
             p_stdcusac.v_sttms_cust_account.CCY,
             global.application_date,
             l_sttms_customer.customer_no,
             nvl(l_sttms_customer.default_media, 'MAIL'),
             'N',
             'N',
             'N',
             'A',
             'B',
             p_stdcusac.v_sttms_cust_account.CUST_AC_NO,
             global.user_id,
             global.application_date,
             global.user_id,
             global.application_date,
             '1');
        
          debug.pr_debug('ST', 'Calling the mspkss.fn_gen_msg_out');
        
          BEGIN
            SELECT *
              INTO p_msg_handoff
              FROM mstbs_msg_handoff
             WHERE dcn = l_dcn;
          EXCEPTION
            WHEN OTHERS THEN
              debug.pr_debug('ST',
                             'Others while selecting from mstbs_msg_handoff');
          END;
        
          pr_putits(l_dcn, 1, 'BRANCH-DATE', global.application_date);
          pr_putits(l_dcn,
                    1,
                    'CUST-NAME1',
                    l_sttms_customer.customer_name1);
          pr_putits(l_dcn,
                    1,
                    'NEW-CUST-ADRESS1',
                    p_stdcusac.v_sttms_cust_account.ADDRESS1);
          pr_putits(l_dcn,
                    1,
                    'NEW-CUST-ADRESS2',
                    p_stdcusac.v_sttms_cust_account.ADDRESS2);
          pr_putits(l_dcn,
                    1,
                    'NEW-CUST-ADRESS3',
                    p_stdcusac.v_sttms_cust_account.ADDRESS3);
          pr_putits(l_dcn,
                    1,
                    'NEW-CUST-ADRESS4',
                    p_stdcusac.v_sttms_cust_account.ADDRESS4);
          pr_putits(l_dcn,
                    1,
                    'OLD-CUST-ADRESS1',
                    p_prev_stdcusac.v_sttms_cust_account.ADDRESS1);
          pr_putits(l_dcn,
                    1,
                    'OLD-CUST-ADRESS2',
                    p_prev_stdcusac.v_sttms_cust_account.ADDRESS2);
        
          pr_putits(l_dcn,
                    1,
                    'OLD-CUST-ADRESS3',
                    p_prev_stdcusac.v_sttms_cust_account.ADDRESS3);
        
          pr_putits(l_dcn,
                    1,
                    'OLD-CUST-ADRESS4',
                    p_prev_stdcusac.v_sttms_cust_account.ADDRESS4);
        
          pr_putits(l_dcn, 1, 'BANK-NAME', l_sttms_bank.bank_name);
          pr_putits(l_dcn, 1, 'BRANCH-ADDR1', l_sttms_branch.branch_addr1);
          pr_putits(l_dcn, 1, 'BRANCH-ADDR2', l_sttms_branch.branch_addr2);
          pr_putits(l_dcn, 1, 'BRANCH-ADDR3', l_sttms_branch.branch_addr3);
          pr_putits(l_dcn, 1, 'CUSTOMER', l_sttms_customer.customer_no);
        
          debug.pr_debug('ST', 'B4 call mspkss.fn_gen_msg_out');
        
          IF NOT mspkss.fn_generate_msg_out(p_msg_handoff, 'N', pdcn) THEN
            debug.pr_debug('ST',
                           'mspkss.fn_gen_msg_out failed for account ;' ||
                           p_stdcusac.v_sttms_cust_account.CUST_AC_NO);
          END IF;
        END IF;
      END IF;
    END IF;
    --Metro Bank PHPMETCASA25APR13_012 changes end
  
    --PHPMET042_Customer Account Opening with preferred ac nos starts 
  
    Dbg('p_Action_Code p_Action_Code p_Action_Code=' || p_Action_Code);
    IF p_Action_Code IN ('DEFAULT') THEN
      dbg('inside validation');
    
      -- To escape, Account mask popup  on providing pref_cust_ac_no
    
      if p_wrk_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50 is not null then
        p_wrk_stdcusac.v_cstbs_ui_columns.CHAR_FIELD6 := 'Y';
      end if;
    
    END IF;
  
    IF p_Action_Code = cspks_req_global.p_auth THEN
      update sttms_pref_acc_no
         set status = 'Y'
       where cust_ac_no = p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50;
    
      UPDATE cstbs_ui_columns
         SET CHAR_FIELD50 = p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD50,
             CHAR_FIELD49 = p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD49
       where char_field1 = p_stdcusac.v_cstbs_ui_columns.CHAR_FIELD1;
    
      Dbg('Row Count Modified=' || SQL%ROWCOUNT);
    END IF;
  
    --PHPMET042_Customer Account Opening with preferred ac nos ends
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                         p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcusac_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcusac_custom;
