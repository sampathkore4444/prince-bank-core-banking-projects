CREATE OR REPLACE PACKAGE BODY stpks_stdpreac_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdpreac_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright © 2008,2015 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    l_Msg := 'stpks_stdpreac_Custom ==>' || p_Msg;
    Debug.Pr_Debug('ST', l_Msg);
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdpreac         IN OUT stpks_stdpreac_Main.ty_stdpreac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdpreac_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdpreac         IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdpreac         IN stpks_stdpreac_Main.ty_stdpreac,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdpreac         IN stpks_stdpreac_Main.ty_stdpreac,
                                       p_Prev_stdpreac    IN OUT stpks_stdpreac_Main.ty_stdpreac,
                                       p_Wrk_stdpreac     IN OUT stpks_stdpreac_Main.ty_stdpreac,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdpreac         IN stpks_stdpreac_Main.Ty_stdpreac,
                                        p_Prev_stdpreac    IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                                        p_Wrk_stdpreac     IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdpreac         IN stpks_stdpreac_Main.Ty_stdpreac,
                            p_Prev_stdpreac    IN stpks_stdpreac_Main.Ty_stdpreac,
                            p_Wrk_stdpreac     IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdpreac         IN stpks_stdpreac_Main.Ty_stdpreac,
                             p_prev_stdpreac    IN stpks_stdpreac_Main.Ty_stdpreac,
                             p_wrk_stdpreac     IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_acc_mask    varchar2(20);
    l_len1        number;
    l_len2        number;
    l_branch      varchar2(3);
    l_ac_no_mask  varchar2(3);
    l_count       number;
    l_start_ac_no varchar2(20);
    l_end_ac_no   varchar2(20);
    j             number;
    l_cnt         number;
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    ---Srikanth Changes Start
  
    select customer_acc_mask
      into l_acc_mask
      from sttms_acc_param
     where branch_code = p_stdpreac.v_sttms_pref_ac_brn.branch_code;
  
    select branch_code
      into l_branch
      from sttms_pref_ac_brn
     where branch_code = p_stdpreac.v_sttms_pref_ac_brn.branch_code;
  
    select substr(cust_ac_no, 1, 3)
      into l_ac_no_mask
      from sttms_pref_acc_no
     where cust_ac_no = p_stdpreac.v_sttms_pref_acc_no(1).cust_ac_no;
  
    /* SELECT count(1)
     into l_count
     from Sttm_Cust_Account a, sttm_pref_acc_no b
    where a.cust_ac_no = b.cust_ac_no;*/
  
    select start_ac_no
      into l_start_ac_no
      from sttms_acc_param
     where branch_code = p_stdpreac.v_sttms_pref_ac_brn.branch_code;
    select end_ac_no
      into l_end_ac_no
      from sttms_acc_param
     where branch_code = p_stdpreac.v_sttms_pref_ac_brn.branch_code;
  
    IF p_Action_Code in (Cspks_Req_Global.p_new, Cspks_Req_Global.p_modify) THEN
      dbg('branch:::' || l_branch || ':::::' || 'ac_no_mask::' ||
          l_ac_no_mask);
      -----chnages starts
      for j in 1 .. p_stdpreac.v_sttms_pref_acc_no.count loop
      
        ------Duplication record exist check----
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTM_PREF_ACC_NO
         WHERE CUST_AC_NO IN (p_stdpreac.v_sttms_pref_acc_no(j).cust_ac_no);
      
        SELECT COUNT(1)
          INTO L_CNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO IN (p_stdpreac.v_sttms_pref_acc_no(j).cust_ac_no);
      
        dbg('l_count::' || l_count || '------' || 'l_cnt::' || l_cnt);
        -----------Duplication code chck ends    
      
        dbg('leng of acc no::' ||
            length(p_stdpreac.v_sttms_pref_acc_no(j).cust_ac_no));
        dbg('len og mask::' || length(l_acc_mask));
        If l_branch <> l_ac_no_mask then
          Dbg('Account Number doesnt follow AC mask');
          p_Err_Code   := 'ST-ACM-03';
          p_Err_Params := 'Account Number doesnt follow AC mask';
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
          return false;
        
        ELSIF length(p_stdpreac.v_sttms_pref_acc_no(j).cust_ac_no) <>
              length(l_acc_mask) THEN
          Dbg('length is not equal');
          p_Err_Code   := 'ST-ACM-01';
          p_Err_Params := 'Customer Account Number doesnt match with Customer Account Mask';
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
          return false;
        
        ELSE
          if l_cnt <> 0 or l_count > 1
          
           then
            Dbg('Account Number is already used');
            p_Err_Code   := 'ST-ACM-04';
            p_Err_Params := 'Account Number is already used';
            Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
            --return false;
          
            /*  ELSIF p_stdpreac.v_sttms_pref_acc_no(j)
            .cust_ac_no not between l_start_ac_no and l_end_ac_no then
             dbg('In Range');
             p_Err_Code   := 'ST-ACM-06';
             p_Err_Params := 'Account Number not in range';
             Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);*/
            -- END IF;
            -- END IF;
            -- END IF;
            return false;
          end if;
        END IF;
      end loop;
    END IF;
    -- END IF;
  
    /* IF p_Action_Code in (Cspks_Req_Global.p_modify) then
    
      IF l_acc_mask not in sttms_acc_param where
       branch_code = p_stdpreac.v_sttms_pref_ac_brn.branch_code then
        p_Err_Code   := 'ST-ACM-05';
        p_Err_Params := 'OLD AND CURRENT ACCOUNT GEN MASK IS NOT SAME';
        Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
        RETURN FALSE;
      
      END IF;
    END IF;*/
  
    /* 
     IF p_Action_Code in (Cspks_Req_Global.p_Modify) THEN
        IF length(p_stdpreac.v_sttms_pref_acc_no(1).cust_ac_no) <>
           length(l_acc_mask) THEN
          Dbg('ACCOUNT MASK IS CHANGED');
          p_Err_Code   := 'ST-ACM-02';
          p_Err_Params := 'OLD AND CURRENT ACCOUNT GEN MASK IS NOT SAME';
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
          RETURN FALSE;
        
        END IF;
      END IF;
    */
    --Srikanth Changes end
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdpreac         IN stpks_stdpreac_Main.Ty_stdpreac,
                        p_Wrk_stdpreac     IN OUT stpks_stdpreac_Main.Ty_stdpreac,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdpreac_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdpreac         IN stpks_stdpreac_Main.ty_stdpreac,
                         p_wrk_stdpreac     IN OUT stpks_stdpreac_Main.ty_stdpreac,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdpreac_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdpreac_custom;
