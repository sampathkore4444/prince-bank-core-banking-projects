/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Financial Services Software Limited.
**  10-11, SDF I, SEEPZ, Andheri (East),
**  Mumbai - 400 096.
**  India.
**  
**  Copyright (c) 2014 by Oracle Financial Services Software Limited. All rights reserved.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : STDCUSAC_CUSTOM.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
**

**  Modified By     :   Srikanth Bandi
**  Modified On     :   09-Apr-2015
**  Modified Reason :   Preferred account number LOV should be enabled only when Preferred account number check box is checked.
**  Search String   :  

****************************************************************************************************************************/
/*
function fn_launchscreen()
{
  var winParams = new Object();
  alert("SRI");
        var fun_id = 'STDCUSAC';
		winParams.mainWin = parent.window;
		
		parentWinParams = new Object();	
		var parentWin = fnGetParentWin();
		parentWinParams.PARENT_FUNC_ID= 'STDCUSAC';
		parentWinParams.FUNCTION_ID=fun_id;
       	mainWin.dispHref1(fun_id,seqNo);
 return true;
}
*/



function fnPostNew_CUSTOM() {


fnEnableElement(document.getElementById("BLK_CUST_ACCOUNT__SPECIALACNOREQ"));
return true;
}




function fnonchangespecialacno() {

	if (document.getElementById("BLK_CUST_ACCOUNT__SPECIALACNOREQ").checked) {
		fnEnableElement(document.getElementById("BLK_CUST_ACCOUNT__PREFERREDACCNO"));
	} else {

		fnDisableElement(document.getElementById("BLK_CUST_ACCOUNT__PREFERREDACCNO"));
		document.getElementById("BLK_CUST_ACCOUNT__PREFERREDACCNO").value = "";
	}

}

	
		
	// Acheiving Custom hook, using function overrding.
	/*dont change */
var fnPostAccPickup_KERNEL = fnPostAccPickup;

var fnPostAccPickup = function(){
   fnPostAccPickup_KERNEL();
   fnPostAccPickup_CUSTOM();
}
/* dont change */


function fnPostAccPickup_CUSTOM(){

 //bandi changes
try{


       fnonchangespecialacno();

      fnDisableElement(document.getElementById("BLK_CUST_ACCOUNT__PREFERREDACCNO")) ;
     

     if (document.getElementById("BLK_CUST_ACCOUNT__SPECIALACNOREQ").checked == true ){
	 
	    /* fix/adjustment */
		
		// defuault/populate  Accmask alert/subscreen depedent fields as dummy fields, to skip errors.
		
		fnAddElement_CUSTOM("INPUT", {type: 'hidden',name: 'ACCMSK',value: 'nnnnnnnn'});
	    fnAddElement_CUSTOM("INPUT", {type: 'hidden',name: 'MSKACC',value: 'nnnnnnnn'});

		for (var i=1;i<=20 ;i++)
		   fnAddElement_CUSTOM("INPUT", {type: 'hidden',name: 'T'+i ,value: '0'});
		
        /* fix/adjustment ends */
		
        fnPreSave_CVS_ACNO_KERNEL();
		
     }
 }catch(e){
    prompt("Error:" + e ,'');
 }
 //bandi changes ends
 
}

function fnAddElement_CUSTOM(tag,props){

	var e = document.createElement(tag);
	for( prop in props )
		e.setAttribute(prop,props[prop]);
	document.body.appendChild(e);
}




