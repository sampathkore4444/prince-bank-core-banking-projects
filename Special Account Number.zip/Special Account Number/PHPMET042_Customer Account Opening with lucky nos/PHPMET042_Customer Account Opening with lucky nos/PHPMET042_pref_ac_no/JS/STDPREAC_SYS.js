/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2015, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : STDPREAC_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_PREF_BRN">BRANCH_CODE~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_PREF_BRN" RELATION_TYPE="N" TYPE="BLK_PREF_ACC_NO">CUST_AC_NO~STATUS~BRANCH_CODE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var txnBranchFld = "" ;
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_PREF_BRN">AUTHSTAT~TXNSTAT~BRANCH_CODE</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "STDPREAC";
var defaultWhereClause = "";
var defaultOrderByClause ="";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_PREF_BRN";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
var relationArray = new Array(); 			// {Table Name} is the array index, {Parent Table Name}~{Relation} is the array value 
relationArray['BLK_PREF_BRN'] = ""; 
relationArray['BLK_PREF_ACC_NO'] = "BLK_PREF_BRN~N"; 

var dataSrcLocationArray = new Array(); 	// Array of all Data Sources used in the screen 
dataSrcLocationArray[0] = "BLK_PREF_BRN"; 
dataSrcLocationArray[1] = "BLK_PREF_ACC_NO"; 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside STDPREAC.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside STDPREAC.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_PREF_BRN__BRANCH_CODE";
pkFields[0] = "BLK_PREF_BRN__BRANCH_CODE";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
var modifyAmendArr = new Array(); 
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
var subsysArr    = new Array(); 

//***** Fields Amendable while Modification *****
modifyAmendArr[0] = "BLK_PREF_ACC_NO__CUST_AC_NO";
modifyAmendArr[1] = "BLK_PREF_ACC_NO__STATUS";
modifyAmendArr[2] = "BLK_PREF_ACC_NO__BRANCH_CODE";
//***** Fields Amendable while Query *****
queryAmendArr[0] = "BLK_PREF_ACC_NO__CUST_AC_NO";
queryAmendArr[1] = "BLK_PREF_ACC_NO__STATUS";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var retflds = new Array();
var bndFlds = new Array();
var lovVal = new Array();

var offlineRetflds = new Array();
var offlineBndFlds = new Array();


/***** Lov Infomation for Field BLK_PREF_BRN__BRANCH_CODE  *****/
retflds["BLK_PREF_BRN__BRANCH_CODE__LOV_BRN"]="BLK_PREF_BRN__BRANCH_CODE~";
bndFlds["BLK_PREF_BRN__BRANCH_CODE__LOV_BRN"]="";

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//--------------------------------------------
multipleEntryIDs[0] = 'BLK_PREF_ACC_NO';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array();

 var CallFormRelat=new Array();

 var CallRelatType= new Array();


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["STDPREAC"]="CUSTOM";
ArrPrntFunc["STDPREAC"]="";
ArrPrntOrigin["STDPREAC"]="";
ArrRoutingType["STDPREAC"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["STDPREAC"]="N";
ArrCustomModified["STDPREAC"]="Y";

 // Code for Loading Cluster/Custom js File ends

//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = new Array(); 
var scrArgSource = new Array(); 
var scrArgDest = new Array(); 
var scrArgVals = new Array(); 
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = new Array(); 
var dpndntOnSrvs = new Array(); 
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = new Array(); 
actStageArry['QUERY'] = "2";
actStageArry['NEW'] = "2";
actStageArry['MODIFY'] = "2";
actStageArry['AUTHORIZE'] = "2";
actStageArry['DELETE'] = "2";
actStageArry['CLOSE'] = "2";
actStageArry['REOPEN'] = "2";
actStageArry['REVERSE'] = "2";
actStageArry['ROLLOVER'] = "2";
actStageArry['CONFIRM'] = "2";
actStageArry['LIQUIDATE'] = "2";
actStageArry['SUMMARYQUERY'] = "2";