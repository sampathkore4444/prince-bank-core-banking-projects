function fnPostNew_CUSTOM() {
document.getElementById("BLK_REFERRAL__SALE_CHANNEL").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL__RELATIONSHIP_OFFICER").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL__REFERRAL_PERSON").nextSibling.nextSibling.style.visibility="hidden";

return true;

}

