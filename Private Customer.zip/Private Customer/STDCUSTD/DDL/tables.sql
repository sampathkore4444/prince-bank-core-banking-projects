-- Create table
create table STTM_CUST_TD_REFERRAL_CUSTOM
(
  brn                  VARCHAR2(3) not null,
  acc                  VARCHAR2(20) not null,
  ccy                  VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_TD_REFERRAL_CUSTOM add primary key (BRN, ACC, CCY)
/
-- Create table
create table STTM_CUST_TD_REFERRAL_TEMP_CUSTOM
(
  brn                  VARCHAR2(3) not null,
  acc                  VARCHAR2(20) not null,
  ccy                  VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_TD_REFERRAL_TEMP_CUSTOM add primary key (BRN, ACC, CCY)
/