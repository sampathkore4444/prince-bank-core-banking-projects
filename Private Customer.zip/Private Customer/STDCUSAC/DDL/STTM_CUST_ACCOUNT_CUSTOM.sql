-- Create table
create table STTM_CUST_ACCOUNT_CUSTOM
(
  branch_code          VARCHAR2(3) not null,
  cust_ac_no           VARCHAR2(20) not null,
  ccy                  VARCHAR2(3),
  cust_no              VARCHAR2(9),
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table STTM_CUST_ACCOUNT_CUSTOM add primary key (BRANCH_CODE, CUST_AC_NO)
/