CREATE OR REPLACE PACKAGE BODY clpks_cldaccvm_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'clpks_cldaccvm_Custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('CL', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');
  END PR_SKIP_HANDLER;
  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Build_Type_Structure..');
  
    DBG('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Build_Type_Structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  --referral changes sampath starts
  FUNCTION FN_GET_CUST_NAME(P_PERSON_TYPE IN VARCHAR2,
                            P_CUST_NO     IN VARCHAR2)
    RETURN STTM_CUSTOMER.CUSTOMER_NAME1%TYPE AS
  
    L_CUST_NAME STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;
  
    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
  
  BEGIN
  
    IF P_PERSON_TYPE = 'RP' THEN
    
      DBG('P_CUST_NO=' || P_CUST_NO);
    
      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = P_CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;
    
    END IF;
  
    IF P_PERSON_TYPE = 'RO' THEN
    
      DBG('P_CUST_NO=' || P_CUST_NO);
    
      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = P_CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;
    
    END IF;
  
    DBG('L_CUST_NAME=' || L_CUST_NAME);
  
    RETURN L_CUST_NAME;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE CUSTOMER NAME');
    
      L_CUST_NAME := NULL;
      RETURN L_CUST_NAME;
    
  END FN_GET_CUST_NAME;

  FUNCTION FN_CHECK_CUSTOMER(P_CUST_NO IN STTM_CUSTOMER.CUSTOMER_NO%TYPE)
    RETURN NUMBER AS
    L_COUNT NUMBER := 0;
  BEGIN
    SELECT COUNT(1)
      INTO L_COUNT
      FROM STTM_CUSTOMER A
     WHERE A.CUSTOMER_NO = P_CUST_NO;
  
    RETURN L_COUNT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('NO CUSTOMER IS AVAILABLE');
      RETURN L_COUNT;
  END FN_CHECK_CUSTOMER;

  --referral changes sampath ends

  --sampath starts
  FUNCTION FN_GET_MID_RATE RETURN CYTM_RATES.MID_RATE%TYPE AS
    L_MID_RATE CYTM_RATES.MID_RATE%TYPE;
  BEGIN
    SELECT MID_RATE
      INTO L_MID_RATE
      FROM CYTM_RATES
     WHERE BRANCH_CODE = GLOBAL.current_branch
       AND CCY1 = 'USD'
       AND CCY2 = 'KHR'
       AND RATE_TYPE = 'STANDARD';
  
    RETURN L_MID_RATE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING MID RATE');
      DBG('ERROR CODE IN FN_GET_MID_RATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MID_RATE=' || SQLERRM);
      RETURN L_MID_RATE;
  END FN_GET_MID_RATE;

  --sampath ends

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                  P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    --sampath starts
    L_COUNT                       NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    L_OUTSTANDING                 NUMBER;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
  
    L_HIST_COUNT                NUMBER := 0;
    L_CLTB_LOAN_RISK_SCORE_HIST CLTB_LOAN_RISK_SCORE_HIST%ROWTYPE;
  
    --sampath ends
  
    --main and sub sector changes starts
    L_SECTOR_COUNT                      NUMBER := 0;
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST%ROWTYPE;
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM      CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    L_SEC_HIST_COUNT                    NUMBER := 0;
    --main and sub sector changes ends
  
    --referral changes sampath starts
    L_REFERRAL_COUNT                    NUMBER := 0;
    L_REFERRAL_HIST_COUNT               NUMBER := 0;
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM      CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST%ROWTYPE;
    L_CUST_REF_COUNT                    NUMBER := 0;
    L_CUST_REL_OFF_COUNT                NUMBER := 0;
  
    --referral changes sampath ends
  
  BEGIN
  
    DBG('In Fn_Pre_Check_Mandatory..=' || P_ACTION_CODE);
  
    --referral changes sampth starts
    IF CSPKS_REQ_GLOBAL.G_HEADER('ACTION') IN ('MODIFY') THEN
    
      IF p_cldaccvm.v_account_referral_custom.SALE_CHANNEL IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-013', '');
      
        RETURN FALSE;
      
      END IF;
    
      /*  IF p_cldaccvm.v_account_referral_custom.REFERRAL_PERSON IS NULL THEN
      
      PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-014', '');
      
      RETURN FALSE;
      
      END IF;*/
    
      IF p_cldaccvm.v_account_referral_custom.RELATIONSHIP_OFFICER IS NULL THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-015', '');
      
        RETURN FALSE;
      
      END IF;
    
    END IF;
    --referral changes ends
  
    --sampath starts
    IF P_ACTION_CODE IN ('MODIFY', 'MatDateEnrich') OR
       P_ACTION_CODE LIKE 'DefaultUde%' THEN
    
      DBG('P_CLDACCVM.v_loan_risk_score_custom.exposure_type=' ||
          P_CLDACCVM.v_loan_risk_score_custom.exposure_type);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type=' ||
          P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.term_conditions=' ||
          P_CLDACCVM.v_loan_risk_score_custom.term_conditions);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv=' ||
          P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.purchased_prop=' ||
          P_CLDACCVM.v_loan_risk_score_custom.purchased_prop);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.rating_agency=' ||
          P_CLDACCVM.v_loan_risk_score_custom.rating_agency);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.rating_approach=' ||
          P_CLDACCVM.v_loan_risk_score_custom.rating_approach);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.risk_class=' ||
          P_CLDACCVM.v_loan_risk_score_custom.risk_class);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.risk_weight=' ||
          P_CLDACCVM.v_loan_risk_score_custom.risk_weight);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia=' ||
          P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.remark=' ||
          P_CLDACCVM.v_loan_risk_score_custom.remark);
    
      --Get Principal Outstanding
      IF P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        L_OUTSTANDING := NVL(L_OUTSTANDING, 0); --fix
      
      END IF;
    
      IF P_CLDACCVM.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        P_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                  0);
      
      ELSE
      
        P_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                  0);
      
      END IF;
    
      --Sub Exposure Type Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
            
         AND SUB_EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-003', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Term & Conditions Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
            
         AND term_conditions =
             P_CLDACCVM.v_loan_risk_score_custom.term_conditions;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-004', '');
      
        RETURN FALSE;
      
      END IF;
    
      --% LTV Validation pls check
      IF P_CLDACCVM.v_loan_risk_score_custom.exposure_type =
         '11_Exposures to Real Estate' THEN
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE EXPOSURE_TYPE =
               P_CLDACCVM.v_loan_risk_score_custom.exposure_type
           AND percentage_ltv =
               P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-005', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      --Purchased Property Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
         AND purchased_prop =
             P_CLDACCVM.v_loan_risk_score_custom.purchased_prop;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-006', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Purchased Property(USD) Field Validation
      IF P_CLDACCVM.v_loan_risk_score_custom.exposure_type =
         '11_Exposures to Real Estate' THEN
      
        IF P_CLDACCVM.v_loan_risk_score_custom.PURCHASED_PROP_USD IS NULL OR
           P_CLDACCVM.v_loan_risk_score_custom.PURCHASED_PROP_USD <= 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-009', '');
        
          RETURN FALSE;
        
        END IF;
      
        --P_CLDACCVM.v_loan_risk_score_custom.PURCHASED_PROP_USD := 0;
      
      ELSE
      
        IF P_CLDACCVM.v_loan_risk_score_custom.PURCHASED_PROP_USD <> 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-010', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      --Get Colltaeral Pool Amount
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      P_CLDACCVM.v_columns__tot_collat_pool.NUM_FIELD24 := NVL(L_POOL_AMOUNT,
                                                               0);
    
      --Rating Agency Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
         AND rating_agency =
             P_CLDACCVM.v_loan_risk_score_custom.rating_agency;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-007', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Rating Approach Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
         AND rating_approach =
             P_CLDACCVM.v_loan_risk_score_custom.rating_approach;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-008', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Risk Class Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_RISK_SCORE_CUSTOM
       WHERE EXPOSURE_TYPE =
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type
         AND rating_approach =
             P_CLDACCVM.v_loan_risk_score_custom.rating_approach
            
         AND risk_class = P_CLDACCVM.v_loan_risk_score_custom.risk_class;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-001', '');
      
        RETURN FALSE;
      
      END IF;
    
      --Risk Weight Validation
      IF P_CLDACCVM.v_loan_risk_score_custom.exposure_type =
         '5_Exposures to Non-Deposit Taking Institutions' THEN
      
        IF P_CLDACCVM.v_loan_risk_score_custom.TERM_CONDITIONS =
           'Short term (Up to 3month)' THEN
        
          IF P_CLDACCVM.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
            --('40%', '75%', '100%', '150%') THEN
             ('20%', '50%', '100%', '150%') THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        ELSIF P_CLDACCVM.v_loan_risk_score_custom.TERM_CONDITIONS =
              'Longer than 3 months' THEN
        
          IF P_CLDACCVM.v_loan_risk_score_custom.RISK_WEIGHT NOT IN
            --('20%', '50%', '100%', '150%') THEN
             ('40%', '75%', '100%', '150%') THEN
          
            PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
          
            RETURN FALSE;
          
          END IF;
        
        END IF;
      
      ELSE
      
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTB_LOAN_RISK_SCORE_CUSTOM
         WHERE ((EXPOSURE_TYPE NOT IN
               (select value
                    from lmtm_type_values
                   where type = 'RISK_SCORE') AND
               EXPOSURE_TYPE =
               P_CLDACCVM.v_loan_risk_score_custom.exposure_type) OR
               (EXPOSURE_TYPE IN
               (select value
                    from lmtm_type_values
                   where type = 'RISK_SCORE') AND
               TERM_CONDITIONS =
               P_CLDACCVM.v_loan_risk_score_custom.TERM_CONDITIONS))
           AND RISK_WEIGHT =
               P_CLDACCVM.v_loan_risk_score_custom.RISK_WEIGHT;
      
        IF L_COUNT = 0 THEN
        
          PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-002', '');
        
          RETURN FALSE;
        
        END IF;
      
      END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      IF L_COUNT > 0 OR
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.exposure_type, '*')
        
         AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.SUB_EXPOSURE_TYPE, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.TERM_CONDITIONS, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.percentage_ltv, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.purchased_prop, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.purchased_prop_usd, 0) <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd, 0) AND
        --NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.total_collat_pool, 0) <>
        --NVL(P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool, 0) AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_agency, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.rating_agency, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.rating_approach, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.rating_approach, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_class, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.risk_class, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.risk_weight, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.risk_weight, '*') AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.out_in_cambodia, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia, '*') AND
        --NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding, 0) <>
        --NVL(P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding, 0) AND
         NVL(L_CLTB_LOAN_RISK_SCORE_CUSTOM.remark, '*') <>
         NVL(P_CLDACCVM.v_loan_risk_score_custom.remark, '*') THEN
      
        DBG('INSERTING INTO HISTORY TABLE');
      
        --Get Max ESN Number from vami table
      
        DBG('UNIQUE_SEQ_NO=' || CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID'));
        BEGIN
          SELECT COUNT(1)
            INTO L_HIST_COUNT
            FROM CLTB_LOAN_RISK_SCORE_HIST
          
           WHERE loan_account_number =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             and branch_code =
                 P_CLDACCVM.v_cltbs_account_master.branch_code
             and UNIQUE_SEQ_NO = CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID');
        EXCEPTION
        
          WHEN OTHERS THEN
            L_HIST_COUNT := 0;
        END;
      
        DBG('L_HIST_COUNT=' || L_HIST_COUNT);
      
        IF L_HIST_COUNT = 0 THEN
          INSERT INTO CLTB_LOAN_RISK_SCORE_HIST
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             remark,
             unique_seq_no)
            SELECT A.*, CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID')
              FROM CLTB_LOAN_RISK_SCORE_CUSTOM A
             WHERE LOAN_ACCOUNT_NUMBER =
                   P_CLDACCVM.v_cltbs_account_master.account_number
               AND BRANCH_CODE =
                   P_CLDACCVM.v_cltbs_account_master.branch_code
               AND ROWID =
                   (SELECT MAX(ROWID)
                      FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                     WHERE LOAN_ACCOUNT_NUMBER =
                           P_CLDACCVM.v_cltbs_account_master.account_number
                       AND BRANCH_CODE =
                           P_CLDACCVM.v_cltbs_account_master.branch_code);
        
        END IF;
      
        /*  DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM
        WHERE LOAN_ACCOUNT_NUMBER =
              P_CLDACCVM.v_cltbs_account_master.account_number
          AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;*/
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = P_CLDACCVM.v_loan_risk_score_custom.exposure_type,
               sub_exposure_type  = P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type,
               term_conditions    = P_CLDACCVM.v_loan_risk_score_custom.term_conditions,
               percentage_ltv     = P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv,
               purchased_prop     = P_CLDACCVM.v_loan_risk_score_custom.purchased_prop,
               purchased_prop_usd = P_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd,
               --total_collat_pool  = P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool,
               rating_agency   = P_CLDACCVM.v_loan_risk_score_custom.rating_agency,
               rating_approach = P_CLDACCVM.v_loan_risk_score_custom.rating_approach,
               risk_class      = P_CLDACCVM.v_loan_risk_score_custom.risk_class,
               risk_weight     = P_CLDACCVM.v_loan_risk_score_custom.risk_weight,
               out_in_cambodia = P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia,
               --lcy_outstanding    = P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding,
               remark = P_CLDACCVM.v_loan_risk_score_custom.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_RISK_SCORE_CUSTOM
            (loan_account_number,
             branch_code,
             exposure_type,
             sub_exposure_type,
             term_conditions,
             percentage_ltv,
             purchased_prop,
             purchased_prop_usd,
             --total_collat_pool,
             rating_agency,
             rating_approach,
             risk_class,
             risk_weight,
             out_in_cambodia,
             --LCY_OUTSTANDING,
             REMARK)
          values
            (P_CLDACCVM.v_cltbs_account_master.account_number,
             P_CLDACCVM.v_cltbs_account_master.branch_code,
             P_CLDACCVM.v_loan_risk_score_custom.exposure_type,
             P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type,
             P_CLDACCVM.v_loan_risk_score_custom.term_conditions,
             P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv,
             P_CLDACCVM.v_loan_risk_score_custom.purchased_prop,
             P_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd,
             --P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool,
             P_CLDACCVM.v_loan_risk_score_custom.rating_agency,
             P_CLDACCVM.v_loan_risk_score_custom.rating_approach,
             P_CLDACCVM.v_loan_risk_score_custom.risk_class,
             P_CLDACCVM.v_loan_risk_score_custom.risk_weight,
             P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia,
             --P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding,
             P_CLDACCVM.v_loan_risk_score_custom.remark);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
        END;
      END IF;
    
      --main and sub sector changes starts
      --Sub Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccvm.v_loan_sector_dtls_custom.main_sector
            
         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccvm.v_loan_sector_dtls_custom.SUB_SECTOR;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
      
        RETURN FALSE;
      
      END IF;
    
      --of-which Sector Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTB_LOAN_SECTOR_DETAILS
       WHERE MAIN_SECTOR_CODE || ' ' || MAIN_SECTOR_DESC =
             p_cldaccvm.v_loan_sector_dtls_custom.main_sector
            
         AND SUB_SECTOR_CODE || ' ' || SUB_SECTOR_DESC =
             p_cldaccvm.v_loan_sector_dtls_custom.SUB_SECTOR
         AND DECODE(OF_WHICH_SECTOR_CODE,
                    NULL,
                    OF_WHICH_SECTOR_DESC,
                    OF_WHICH_SECTOR_CODE || ' ' || OF_WHICH_SECTOR_DESC) =
             p_cldaccvm.v_loan_sector_dtls_custom.OF_WHICH_SECTOR;
    
      IF L_COUNT = 0 THEN
      
        PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');
      
        RETURN FALSE;
      
      END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_SECTOR_COUNT
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccvm.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccvm.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_SECTOR_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      DBG('L_SECTOR_COUNT=' || L_SECTOR_COUNT);
    
      IF L_SECTOR_COUNT > 0 OR
         NVL(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.MAIN_SECTOR, '*') <>
         NVL(P_CLDACCVM.v_loan_sector_dtls_custom.MAIN_SECTOR, '*')
        
         AND NVL(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.SUB_SECTOR, '*') <>
         NVL(P_CLDACCVM.v_loan_sector_dtls_custom.SUB_SECTOR, '*') AND
        
         NVL(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.OF_WHICH_SECTOR, '*') <>
         NVL(P_CLDACCVM.v_loan_sector_dtls_custom.OF_WHICH_SECTOR, '*') THEN
      
        DBG('INSERTING INTO HISTORY TABLE');
      
        --Get Max ESN Number from vami table
      
        DBG('UNIQUE_SEQ_NO=' || CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID'));
        BEGIN
          SELECT COUNT(1)
            INTO L_SEC_HIST_COUNT
            FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
          
           WHERE loan_account_number =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             and branch_code =
                 P_CLDACCVM.v_cltbs_account_master.branch_code
             and UNIQUE_SEQ_NO = CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID');
        EXCEPTION
        
          WHEN OTHERS THEN
            L_SEC_HIST_COUNT := 0;
        END;
      
        DBG('L_HIST_COUNT=' || L_HIST_COUNT);
      
        IF L_SEC_HIST_COUNT = 0 THEN
          INSERT INTO CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_sector,
             unique_seq_no)
            SELECT A.*, CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID')
              FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM A
             WHERE LOAN_ACCOUNT_NUMBER =
                   P_CLDACCVM.v_cltbs_account_master.account_number
               AND BRANCH_CODE =
                   P_CLDACCVM.v_cltbs_account_master.branch_code
               AND ROWID =
                   (SELECT MAX(ROWID)
                      FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                     WHERE LOAN_ACCOUNT_NUMBER =
                           P_CLDACCVM.v_cltbs_account_master.account_number
                       AND BRANCH_CODE =
                           P_CLDACCVM.v_cltbs_account_master.branch_code);
        
        END IF;
      
        /*  DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM
        WHERE LOAN_ACCOUNT_NUMBER =
              P_CLDACCVM.v_cltbs_account_master.account_number
          AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;*/
      
        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
               sub_sector      = P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
               of_which_sector = P_CLDACCVM.v_loan_sector_dtls_custom.of_which_sector
        
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          insert into CLTB_LOAN_SECTOR_DTLS_CUSTOM
            (loan_account_number,
             branch_code,
             main_sector,
             sub_sector,
             of_which_sector)
          values
            (P_CLDACCVM.v_cltbs_account_master.account_number,
             P_CLDACCVM.v_cltbs_account_master.branch_code,
             P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
             P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
             P_CLDACCVM.v_loan_sector_dtls_custom.of_which_sector);
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED WHILE INSERTING');
        END;
      
        /*P_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
                                                                        1,
        
         
                      
                                                                        instr(P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
                                                                              ' ') - 1);
                 
          P_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC := SUBSTR(P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
            
                                                                      instr(P_CLDACCVM.v_loan_sector_dtls_custom.main_sector,
                                                                            ' ') + 1);
        
          P_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
                                                                        1,
                                                                        instr(P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
                                                                              ' ') - 1);
          P_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC := SUBSTR(P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
                                                                      instr(P_CLDACCVM.v_loan_sector_dtls_custom.sub_sector,
                                                                            ' ') + 1);
        */
      END IF;
      --main and sub sector changes ends
    
      --referral changes sampath starts
      --referral Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO =
             p_cldaccvm.v_account_referral_custom.referral_person;
    
      --IF L_COUNT = 0 THEN
    
      --   PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-011', '');
    
      --  RETURN FALSE;
    
      -- END IF;
    
      --relationship_officer Validation
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO =
             p_cldaccvm.v_account_referral_custom.relationship_officer;
    
      --IF L_COUNT = 0 THEN
    
      --  PR_LOG_ERROR('CLDACCNT', 'FLEXCUBE', 'CL-PRIN-012', '');
    
      -- RETURN FALSE;
    
      -- END IF;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_REFERRAL_COUNT
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               p_cldaccvm.v_cltbs_account_master.account_number
           AND BRANCH_CODE = p_cldaccvm.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_COUNT := 0;
      END;
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      DBG('L_REFERRAL_COUNT=' || L_REFERRAL_COUNT);
    
      IF L_REFERRAL_COUNT > 0 OR
         NVL(L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON, '*') <>
         NVL(P_CLDACCVM.v_account_referral_custom.REFERRAL_PERSON, '*')
        
         AND
         NVL(L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER, '*') <>
         NVL(P_CLDACCVM.v_account_referral_custom.RELATIONSHIP_OFFICER, '*') AND
        
         NVL(L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL, '*') <>
         NVL(P_CLDACCVM.v_account_referral_custom.SALE_CHANNEL, '*') THEN
      
        DBG('INSERTING INTO HISTORY TABLE 1');
      
        --Get Max ESN Number from vami table
      
        DBG('UNIQUE_SEQ_NO=' || CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID'));
        BEGIN
          SELECT COUNT(1)
            INTO L_REFERRAL_HIST_COUNT
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
          
           WHERE loan_account_number =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             and branch_code =
                 P_CLDACCVM.v_cltbs_account_master.branch_code
             and UNIQUE_SEQ_NO = CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID');
        EXCEPTION
        
          WHEN OTHERS THEN
            L_REFERRAL_HIST_COUNT := 0;
        END;
      
        DBG('L_REFERRAL_HIST_COUNT=' || L_REFERRAL_HIST_COUNT);
      
        IF L_REFERRAL_HIST_COUNT = 0 THEN
        
          BEGIN
            insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
              (loan_account_number,
               branch_code,
               referral_person,
               relationship_officer,
               sale_channel)
            values
              (P_CLDACCVM.v_cltbs_account_master.account_number,
               P_CLDACCVM.v_cltbs_account_master.branch_code,
               P_CLDACCVM.v_account_referral_custom.referral_person,
               P_CLDACCVM.v_account_referral_custom.relationship_officer,
               P_CLDACCVM.v_account_referral_custom.sale_channel);
          
          EXCEPTION
          
            WHEN OTHERS THEN
              DBG('FAILED WHILE INSERTING');
          END;
        
          INSERT INTO CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
            (loan_account_number,
             branch_code,
             referral_person,
             relationship_officer,
             sale_channel,
             unique_seq_no)
            SELECT A.*, CSPKS_REQ_GLOBAL.G_HEADER('MULTITRIPID')
              FROM CLTB_ACCOUNT_REFERRAL_CUSTOM A
             WHERE LOAN_ACCOUNT_NUMBER =
                   P_CLDACCVM.v_cltbs_account_master.account_number
               AND BRANCH_CODE =
                   P_CLDACCVM.v_cltbs_account_master.branch_code
               AND ROWID =
                   (SELECT MAX(ROWID)
                      FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                     WHERE LOAN_ACCOUNT_NUMBER =
                           P_CLDACCVM.v_cltbs_account_master.account_number
                       AND BRANCH_CODE =
                           P_CLDACCVM.v_cltbs_account_master.branch_code);
        
        END IF;
      
        /*  DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM
        WHERE LOAN_ACCOUNT_NUMBER =
              P_CLDACCVM.v_cltbs_account_master.account_number
          AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;*/
      
        G_REFERRAL_PERSON      := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.Referral_Person;
        G_RELATIONSHIP_OFFICER := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER;
      
        IF FN_CHECK_CUSTOMER(G_REFERRAL_PERSON) = 1 AND
           FN_CHECK_CUSTOMER(G_RELATIONSHIP_OFFICER) = 1 AND
           FN_CHECK_CUSTOMER(P_CLDACCVM.v_account_referral_custom.referral_person) = 0 AND
           FN_CHECK_CUSTOMER(P_CLDACCVM.v_account_referral_custom.relationship_officer) = 0 THEN
        
          UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM
             SET referral_person      = G_REFERRAL_PERSON,
                 relationship_officer = G_RELATIONSHIP_OFFICER,
                 sale_channel         = P_CLDACCVM.v_account_referral_custom.sale_channel
          
           WHERE LOAN_ACCOUNT_NUMBER =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 P_CLDACCVM.v_cltbs_account_master.branch_code;
        
        ELSE
        
          UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM
             SET referral_person = P_CLDACCVM.v_account_referral_custom.referral_person
                 
                ,
                 
                 relationship_officer = P_CLDACCVM.v_account_referral_custom.relationship_officer,
                 sale_channel         = P_CLDACCVM.v_account_referral_custom.sale_channel
          
           WHERE LOAN_ACCOUNT_NUMBER =
                 P_CLDACCVM.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 P_CLDACCVM.v_cltbs_account_master.branch_code;
        
        END IF;
      
      ELSE
      
        DBG('INSIDE ELSE CONDITION');
      
        BEGIN
          SELECT *
            INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
           WHERE LOAN_ACCOUNT_NUMBER =
                 p_cldaccvm.v_cltbs_account_master.account_number
             AND BRANCH_CODE =
                 p_cldaccvm.v_cltbs_account_master.branch_code;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
        END;
      
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER);
        DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL=' ||
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL);
        DBG('G_REFERRAL_PERSON=' || G_REFERRAL_PERSON);
        DBG('G_RELATIONSHIP_OFFICER=' || G_RELATIONSHIP_OFFICER);
      
        SELECT COUNT(1)
          INTO L_CUST_REF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccvm.v_account_referral_custom.referral_person;
      
        DBG('L_CUST_REF_COUNT=' || L_CUST_REF_COUNT);
      
        SELECT COUNT(1)
          INTO L_CUST_REL_OFF_COUNT
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO =
               p_cldaccvm.v_account_referral_custom.relationship_officer;
      
        DBG('L_CUST_REL_OFF_COUNT=' || L_CUST_REL_OFF_COUNT);
      
        IF L_CUST_REF_COUNT = 0 AND L_CUST_REL_OFF_COUNT = 0 THEN
        
          BEGIN
            insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
              (loan_account_number,
               branch_code,
               referral_person,
               relationship_officer,
               sale_channel)
            values
              (p_cldaccvm.v_cltbs_account_master.account_number,
               p_cldaccvm.v_cltbs_account_master.branch_code,
               L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person,
               L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer,
               p_cldaccvm.v_account_referral_custom.sale_channel);
          
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED WHILE INSERTING');
            
          END;
        
        ELSE
          --apple apple referral changes
        
          BEGIN
            insert into CLTB_ACCOUNT_REFERRAL_CUSTOM
              (loan_account_number,
               branch_code,
               referral_person,
               relationship_officer,
               sale_channel)
            values
              (P_CLDACCVM.v_cltbs_account_master.account_number,
               P_CLDACCVM.v_cltbs_account_master.branch_code,
               P_CLDACCVM.v_account_referral_custom.referral_person,
               P_CLDACCVM.v_account_referral_custom.relationship_officer,
               P_CLDACCVM.v_account_referral_custom.sale_channel);
          
          EXCEPTION
          
            WHEN OTHERS THEN
              DBG('FAILED WHILE INSERTING');
          END;
        
        END IF; --apple apple referral changes
      
      END IF;
      --referral changes sampath ends
    
    END IF;
  
    IF P_ACTION_CODE = 'DELETE' THEN
    
      /*DELETE FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
       where a.LOAN_ACCOUNT_NUMBER =
             P_CLDACCVM.v_cltbs_account_master.account_number
         and a.branch_code = P_CLDACCVM.v_cltbs_account_master.branch_code
         and rowid in
             (SELECT MAX(ROWID)
                FROM CLTB_LOAN_RISK_SCORE_CUSTOM
               WHERE LOAN_ACCOUNT_NUMBER =
                     P_CLDACCVM.v_cltbs_account_master.account_number
                 AND BRANCH_CODE =
                     P_CLDACCVM.v_cltbs_account_master.branch_code);
      --and a.event_seq_no = p_cldpymnt.v_cltbs_liq.event_seq_no;*/
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_HIST
          FROM CLTB_LOAN_RISK_SCORE_HIST
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code
           AND ROWID =
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_HIST
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_HIST := NULL;
      END;
    
      DBG('L_CLTB_LOAN_RISK_SCORE_HIST.EXPOSURE_TYPE=' ||
          L_CLTB_LOAN_RISK_SCORE_HIST.EXPOSURE_TYPE);
      DBG('P_CLDACCVM.v_loan_risk_score_custom.exposure_type=' ||
          P_CLDACCVM.v_loan_risk_score_custom.exposure_type);
    
      BEGIN
      
        DBG('UPDATING BACK');
      
        UPDATE CLTB_LOAN_RISK_SCORE_CUSTOM
           SET exposure_type      = L_CLTB_LOAN_RISK_SCORE_HIST.exposure_type,
               sub_exposure_type  = L_CLTB_LOAN_RISK_SCORE_HIST.sub_exposure_type,
               term_conditions    = L_CLTB_LOAN_RISK_SCORE_HIST.term_conditions,
               percentage_ltv     = L_CLTB_LOAN_RISK_SCORE_HIST.percentage_ltv,
               purchased_prop     = L_CLTB_LOAN_RISK_SCORE_HIST.purchased_prop,
               purchased_prop_usd = L_CLTB_LOAN_RISK_SCORE_HIST.purchased_prop_usd,
               --total_collat_pool  = P_CLDACCVM.v_loan_risk_score_custom.total_collat_pool,
               rating_agency   = L_CLTB_LOAN_RISK_SCORE_HIST.rating_agency,
               rating_approach = L_CLTB_LOAN_RISK_SCORE_HIST.rating_approach,
               risk_class      = L_CLTB_LOAN_RISK_SCORE_HIST.risk_class,
               risk_weight     = L_CLTB_LOAN_RISK_SCORE_HIST.risk_weight,
               out_in_cambodia = L_CLTB_LOAN_RISK_SCORE_HIST.out_in_cambodia,
               --lcy_outstanding    = P_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding,
               remark = L_CLTB_LOAN_RISK_SCORE_HIST.remark
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED WHILE INSERTING INTO CLTB_LOAN_RISK_SCORE_CUSTOM');
      END;
    
      --main and sub sector changes starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code
           AND ROWID =
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST := NULL;
      END;
    
      DBG('L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST.main_Sector=' ||
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST.main_Sector);
      DBG('P_CLDACCVM.exposure_type=' ||
          P_CLDACCVM.v_loan_sector_dtls_custom.main_Sector);
    
      BEGIN
      
        DBG('UPDATING BACK');
      
        UPDATE CLTB_LOAN_SECTOR_DTLS_CUSTOM
           SET main_sector     = L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST.main_sector,
               sub_sector      = L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST.sub_sector,
               of_which_sector = L_CLTB_LOAN_SECTOR_DTLS_CUSTOM_HIST.of_which_sector
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED WHILE INSERTING INTO CLTB_LOAN_RISK_SCORE_CUSTOM');
      END;
      --main and sub sector changes ends
    
      --referral changes sampath starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code
           AND ROWID =
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST := NULL;
      END;
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST.REFERRAL_PERSON=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST.REFERRAL_PERSON);
      DBG('P_CLDACCVM.REFERRAL_PERSON=' ||
          P_CLDACCVM.v_account_referral_custom.REFERRAL_PERSON);
    
      BEGIN
      
        DBG('UPDATING BACK');
      
        UPDATE CLTB_ACCOUNT_REFERRAL_CUSTOM A
           SET A.REFERRAL_PERSON      = L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST.REFERRAL_PERSON,
               A.RELATIONSHIP_OFFICER = L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST.RELATIONSHIP_OFFICER,
               A.SALE_CHANNEL         = L_CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST.SALE_CHANNEL
         WHERE LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.branch_code;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED WHILE INSERTING INTO CLTB_ACCOUNT_REFERRAL_CUSTOM');
      END;
    
      --referral changes sampath ends
    
    END IF;
  
    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
    
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
          L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
    
      P_CLDACCVM.v_loan_risk_score_custom.exposure_type     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
      P_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
      P_CLDACCVM.v_loan_risk_score_custom.term_conditions   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
      P_CLDACCVM.v_loan_risk_score_custom.percentage_ltv    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
      P_CLDACCVM.v_loan_risk_score_custom.purchased_prop    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
      P_CLDACCVM.v_loan_risk_score_custom.rating_agency     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
      P_CLDACCVM.v_loan_risk_score_custom.rating_approach   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
      P_CLDACCVM.v_loan_risk_score_custom.risk_class        := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
      P_CLDACCVM.v_loan_risk_score_custom.risk_weight       := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
      P_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
      P_CLDACCVM.v_loan_risk_score_custom.remark            := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
    
    END IF;*/
  
    --sampath ends
  
    DBG('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    DBG('In Fn_Post_Check_Mandatory..');
  
    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
					 
  BEGIN
  
    DBG('In Fn_Pre_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Default_And_Validate..');
  
    DBG('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                      P_SOURCE_OPERATION IN VARCHAR2,
                                      P_FUNCTION_ID      IN VARCHAR2,
                                      P_ACTION_CODE      IN VARCHAR2,
                                      P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                      P_ERR_CODE         IN OUT VARCHAR2,
                                      P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Pre_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_RESOLVE_REF_NUMBERS;
  FUNCTION FN_POST_RESOLVE_REF_NUMBERS(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CLDACCVM         IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Post_Resolve_Ref_Numbers..');
  
    DBG('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of clpks_cldaccvm_Main.Fn_Post_Resolve_Ref_Numbers ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_RESOLVE_REF_NUMBERS;
  FUNCTION FN_PRE_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Product_Default..');
  
    DBG('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PRODUCT_DEFAULT;

  FUNCTION FN_POST_PRODUCT_DEFAULT(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Product_Default..');
  
    DBG('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Product_Default ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PRODUCT_DEFAULT;

  FUNCTION FN_PRE_UNLOCK(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN OUT VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Unlock..');
  
    DBG('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UNLOCK;

  FUNCTION FN_POST_UNLOCK(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN OUT VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Unlock');
  
    DBG('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Unlock ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UNLOCK;

  FUNCTION FN_PRE_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_SUBSYS_PICKUP;

  FUNCTION FN_POST_SUBSYS_PICKUP(P_SOURCE           IN VARCHAR2,
                                 P_SOURCE_OPERATION IN VARCHAR2,
                                 P_FUNCTION_ID      IN VARCHAR2,
                                 P_ACTION_CODE      IN VARCHAR2,
                                 P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                                 P_ERR_CODE         IN OUT VARCHAR2,
                                 P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Subsys_Pickup..');
  
    DBG('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Subsys_Pickup ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_SUBSYS_PICKUP;

  FUNCTION FN_PRE_ENRICH(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Enrich..');
  
    DBG('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_ENRICH;

  FUNCTION FN_POST_ENRICH(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_PREV_CLDACCVM    IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Enrich..');
  
    DBG('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Enrich ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_ENRICH;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    DBG('In Fn_Pre_Upload_Db..=' || P_ACTION_CODE);
  
    --main and sub sector changes starts
    /*IF P_ACTION_CODE IN ('MODIFY', 'MatDateEnrich') OR
       P_ACTION_CODE LIKE 'DefaultUde%' THEN
    
      UPDATE cltbs_account_master A
         SET A.FIELD_CHAR_4 = SUBSTR(p_cldaccvm.v_loan_sector_dtls_custom.sub_sector,
                                     1,
                                     instr(p_cldaccvm.v_loan_sector_dtls_custom.sub_sector,
                                           ' ') - 1),
             A.FIELD_CHAR_8 = SUBSTR(p_cldaccvm.v_loan_sector_dtls_custom.Main_Sector,
                                     1,
                                     instr(p_cldaccvm.v_loan_sector_dtls_custom.Main_Sector,
                                           ' ') - 1)
       WHERE A.ACCOUNT_NUMBER =
             P_CLDACCVM.v_cltbs_account_master.account_number;
    
    END IF;*/
    --main and sub sector changes ends
  
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Upload_Db..');
  
    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_PROCESS(P_SOURCE           IN VARCHAR2,
                          P_SOURCE_OPERATION IN VARCHAR2,
                          P_FUNCTION_ID      IN VARCHAR2,
                          P_ACTION_CODE      IN VARCHAR2,
                          P_CHILD_FUNCTION   IN VARCHAR2,
                          P_MULTI_TRIP_ID    IN VARCHAR2,
                          P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                          P_ERR_CODE         IN OUT VARCHAR2,
                          P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Pre_Process..');
  
    DBG('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_PROCESS;

  FUNCTION FN_POST_PROCESS(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_MULTI_TRIP_ID    IN VARCHAR2,
                           P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_PREV_CLDACCVM    IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    DBG('In Fn_Post_Process..');
  
    DBG('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Process ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_PROCESS;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                        P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    --sampath ends
  
    --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
  
    --referral changes sampath starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    --referral changes sampath ends
  
  BEGIN
  
    DBG('In Fn_Pre_Query.. P_ACTION_CODE=' || P_ACTION_CODE);
  
    --sampath starts
    /*IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
      BEGIN
        SELECT *
          INTO            P_WRK_CLDACCVM.v_cltb_restructure_custom
          FROM CLTB_RESTRUCTURE_CUSTOM
         WHERE ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN FN_PRE_QUERY');
          DBG('ERROR CODE IN FN_PRE_QUERY=' || SQLCODE);
          DBG('ERROR MESSAGE IN FN_PRE_QUERY=' || SQLERRM);
      END;
    
      BEGIN
        SELECT *
          BULK COLLECT
          INTO P_WRK_CLDACCVM.v_restructure_link_custom
          FROM CLTB_RESTRUCTURE_LINK_CUSTOM
         WHERE ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.ACCOUNT_NUMBER
           AND BRANCH_CODE = P_CLDACCVM.v_cltbs_account_master.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN FN_PRE_QUERY');
          DBG('ERROR CODE IN FN_PRE_QUERY=' || SQLCODE);
          DBG('ERROR MESSAGE IN FN_PRE_QUERY=' || SQLERRM);
      END;
    END IF;*/
  
    IF P_ACTION_CODE IN ('NEW', 'EXECUTEQUERY', 'MODIFY', 'MatDateEnrich') OR
       P_ACTION_CODE LIKE 'DefaultUde%' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      --Get Colltaeral Pool Amount
      DBG('P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID=' ||
          P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID);
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      P_WRK_CLDACCVM.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      --LCY Outstanding
      IF P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        L_OUTSTANDING := NVL(L_OUTSTANDING, 0); --fix
      
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                                      0);
      END IF;
    
      IF P_WRK_CLDACCVM.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('P_CLDACCVM.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(P_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD23, 0));
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      --main and sub sector changes starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      --main and sub sector changes ends
    
      --referral changes sampath starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
    
      --referral changes sampath ends
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.exposure_type     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.term_conditions   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.percentage_ltv    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.purchased_prop    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --P_WRK_CLDACCVM.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --P_WRK_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      
        --main and sub sector changes starts
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.main_sector;
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector;
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.of_which_sector;
      
        /*P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                          1,
                                                                          instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                                ' ') - 1);
        P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                        instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                              ' ') + 1);
        
        P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                          1,
                                                                          instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                                ' ') - 1);
        P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                        instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                              ' ') + 1);*/
      
        --main and sub sector changes ends
      
        --referral changes starts
        P_WRK_CLDACCVM.v_account_referral_custom.referral_person := FN_GET_CUST_NAME('RP',
                                                                                     L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
      
        P_WRK_CLDACCVM.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
      
        P_WRK_CLDACCVM.v_account_referral_custom.sale_channel := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
        --referral changes ends
      
      END IF;
    
    END IF;
  
    --sampath ends
    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_CLDACCVM         IN CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_WRK_CLDACCVM     IN OUT CLPKS_CLDACCVM_MAIN.TY_CLDACCVM,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    --sampath starts
    L_CLTB_LOAN_RISK_SCORE_CUSTOM CLTB_LOAN_RISK_SCORE_CUSTOM%ROWTYPE;
    L_POOL_AMOUNT                 NUMBER := 0; --GETM_POOL.POOL_AMOUNT%TYPE;
    L_OUTSTANDING                 NUMBER;
    L_LCY_OUTSTANDING             CSTB_UI_COLUMNS.NUM_FIELD25%TYPE;
    --sampath ends
  
    --main and sub sector changes starts
    L_CLTB_LOAN_SECTOR_DTLS_CUSTOM CLTB_LOAN_SECTOR_DTLS_CUSTOM%ROWTYPE;
    --main and sub sector changes ends
  
    --referral changes sampath starts
    L_CLTB_ACCOUNT_REFERRAL_CUSTOM CLTB_ACCOUNT_REFERRAL_CUSTOM%ROWTYPE;
    --referral changes sampath ends
  
  BEGIN
  
    DBG('In Fn_Post_Query P_ACTION_CODE=' || P_ACTION_CODE);
  
    --sampath starts
  
    IF P_ACTION_CODE IN ('SUBSYSPKP_MODIFY', 'MatDateEnrich') OR
       P_ACTION_CODE LIKE 'DefaultUde%' THEN
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_RISK_SCORE_CUSTOM
          FROM CLTB_LOAN_RISK_SCORE_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_RISK_SCORE_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_RISK_SCORE_CUSTOM := NULL;
      END;
    
      --Get Colltaeral Pool Amount
      DBG('P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID=' ||
          P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID);
    
      BEGIN
        FOR G IN (SELECT *
                  
                    FROM GETM_POOL A
                   WHERE A.LIAB_ID IN
                         (SELECT ID
                            FROM GETM_LIAB
                           WHERE LIAB_NO =
                                 P_CLDACCVM.v_cltbs_account_master.CUSTOMER_ID)
                     AND A.RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y') LOOP
        
          IF G.POOL_CCY = 'KHR' THEN
          
            L_POOL_AMOUNT := L_POOL_AMOUNT +
                             G.POOL_AMOUNT / FN_GET_MID_RATE;
          
          ELSE
          
            L_POOL_AMOUNT := L_POOL_AMOUNT + G.POOL_AMOUNT;
          
          END IF;
        
        END LOOP;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_POOL_AMOUNT := 0;
        
      END;
    
      DBG('COLLATERAL POOL AMOUNT BEFORE FORMAT=' || L_POOL_AMOUNT);
    
      IF NOT cypks.fn_amt_round('USD', L_POOL_AMOUNT, L_POOL_AMOUNT) THEN
        RETURN FALSE;
      END IF;
    
      DBG('COLLATERAL POOL AMOUNT AFTER FORMAT=' || L_POOL_AMOUNT);
    
      P_WRK_CLDACCVM.v_columns__tot_collat_pool.NUM_FIELD24 := L_POOL_AMOUNT;
    
      --LCY Outstanding
      IF P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER IS NOT NULL AND
         P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE IS NOT NULL THEN
        DBG('Going to call clpks_util.Fn_Principal_Outstanding_Calc..');
        IF NOT CLPKS_UTIL.FN_PRINCIPAL_OUTSTANDING_CALC(P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.ACCOUNT_NUMBER,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.BRANCH_CODE,
                                                        P_CLDACCVM.V_CLTBS_ACCOUNT_MASTER.PRODUCT_CODE,
                                                        L_OUTSTANDING) THEN
          DBG('Failed in clpks_util.Fn_Principal_Outstanding_Calc');
          L_OUTSTANDING := 0;
        END IF;
        DBG('l_outstanding-- ' || L_OUTSTANDING);
      
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD23 := NVL(L_OUTSTANDING,
                                                                      0);
      END IF;
    
      IF P_WRK_CLDACCVM.v_cltbs_account_master.currency = 'KHR' THEN
      
        L_LCY_OUTSTANDING := L_OUTSTANDING / FN_GET_MID_RATE;
      
        DBG('L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        IF NOT
            cypks.fn_amt_round('USD', L_LCY_OUTSTANDING, L_LCY_OUTSTANDING) THEN
          RETURN FALSE;
        END IF;
      
        DBG('AFTER FORMAT L_LCY_OUTSTANDING=' || L_LCY_OUTSTANDING);
      
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_LCY_OUTSTANDING,
                                                                      0);
      
      ELSE
        DBG('P_CLDACCVM.v_cltbs_account_master.AMOUNT_FINANCED=' ||
            NVL(P_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD23, 0));
        P_WRK_CLDACCVM.v_columns__tot_prin_out_lcy.NUM_FIELD25 := NVL(L_OUTSTANDING,
                                                                      0);
      
      END IF;
    
      --main and sub sector changes starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_LOAN_SECTOR_DTLS_CUSTOM
          FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_LOAN_SECTOR_DTLS_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_LOAN_SECTOR_DTLS_CUSTOM := NULL;
      END;
    
      --main and sub sector changes ends
    
      --referral changes sampath starts
    
      BEGIN
        SELECT *
          INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
          FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
         where a.LOAN_ACCOUNT_NUMBER =
               P_CLDACCVM.v_cltbs_account_master.account_number
           and a.branch_code =
               P_CLDACCVM.v_cltbs_account_master.branch_code
           and rowid in
               (SELECT MAX(ROWID)
                  FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                 WHERE LOAN_ACCOUNT_NUMBER =
                       P_CLDACCVM.v_cltbs_account_master.account_number
                   AND BRANCH_CODE =
                       P_CLDACCVM.v_cltbs_account_master.branch_code);
      
      EXCEPTION
        WHEN OTHERS THEN
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
      END;
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.LOAN_ACCOUNT_NUMBER);
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.BRANCH_CODE);
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.REFERRAL_PERSON);
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.RELATIONSHIP_OFFICER);
    
      DBG('L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL=' ||
          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.SALE_CHANNEL);
    
      --referral changes sampath ends
    
      IF L_CLTB_LOAN_RISK_SCORE_CUSTOM.LOAN_ACCOUNT_NUMBER IS NOT NULL AND
         L_CLTB_LOAN_RISK_SCORE_CUSTOM.BRANCH_CODE IS NOT NULL THEN
        DBG('L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE=' ||
            L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE);
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.exposure_type     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.sub_exposure_type := L_CLTB_LOAN_RISK_SCORE_CUSTOM.SUB_EXPOSURE_TYPE;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.term_conditions   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TERM_CONDITIONS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.percentage_ltv    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PERCENTAGE_LTV;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.purchased_prop    := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP;
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.purchased_prop_usd := L_CLTB_LOAN_RISK_SCORE_CUSTOM.PURCHASED_PROP_USD;
        --P_WRK_CLDACCVM.v_loan_risk_score_custom.total_collat_pool  := L_CLTB_LOAN_RISK_SCORE_CUSTOM.TOTAL_COLLAT_POOL;
      
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_agency   := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_AGENCY;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.rating_approach := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RATING_APPROACH;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_class      := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_CLASS;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.risk_weight     := L_CLTB_LOAN_RISK_SCORE_CUSTOM.RISK_WEIGHT;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.out_in_cambodia := L_CLTB_LOAN_RISK_SCORE_CUSTOM.OUT_IN_CAMBODIA;
        --P_WRK_CLDACCVM.v_loan_risk_score_custom.lcy_outstanding := L_CLTB_LOAN_RISK_SCORE_CUSTOM.lcy_outstanding;
        P_WRK_CLDACCVM.v_loan_risk_score_custom.remark := L_CLTB_LOAN_RISK_SCORE_CUSTOM.REMARK;
      
        --main and sub sector changes starts
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.main_sector     := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.main_sector;
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.sub_sector      := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector;
        P_WRK_CLDACCVM.v_loan_sector_dtls_custom.of_which_sector := L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.of_which_sector;
      
        /*P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                            1,
        
                        
        
                                                                            instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                                  ' ') - 1);
                               
          P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(8).FIELD_DESC := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                   
                                                                          instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.Main_Sector,
                                                                                ' ') + 1);
        
          P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_CHAR_1 := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                            1,
                                                                            instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                                  ' ') - 1);
          P_WRK_CLDACCVM.V_CLVWS_ACCOUNT_UDF_CHAR(4).FIELD_DESC := SUBSTR(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                          instr(L_CLTB_LOAN_SECTOR_DTLS_CUSTOM.sub_sector,
                                                                                ' ') + 1);
        */
        --main and sub sector changes ends
      
        --referral changes sampath starts
        IF P_ACTION_CODE NOT IN ('SUBSYSPKP_MODIFY') THEN
        
          P_WRK_CLDACCVM.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
          P_WRK_CLDACCVM.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                            L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
          P_WRK_CLDACCVM.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
        
        ELSE
        
          P_WRK_CLDACCVM.v_account_referral_custom.referral_person      := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person;
          P_WRK_CLDACCVM.v_account_referral_custom.relationship_officer := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer;
          P_WRK_CLDACCVM.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
        
        END IF;
        --referral changes sampath ends
      
      END IF;
    
      --referral changes sampath starts
      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      
        BEGIN
          SELECT *
            INTO L_CLTB_ACCOUNT_REFERRAL_CUSTOM
            FROM CLTB_ACCOUNT_REFERRAL_CUSTOM a
           where a.LOAN_ACCOUNT_NUMBER =
                 p_cldaccvm.v_cltbs_account_master.account_number
             and a.branch_code =
                 p_cldaccvm.v_cltbs_account_master.branch_code
             and rowid in
                 (SELECT MAX(ROWID)
                    FROM CLTB_ACCOUNT_REFERRAL_CUSTOM
                   WHERE LOAN_ACCOUNT_NUMBER =
                         p_cldaccvm.v_cltbs_account_master.account_number
                     AND BRANCH_CODE =
                         p_cldaccvm.v_cltbs_account_master.branch_code);
        
        EXCEPTION
          WHEN OTHERS THEN
            L_CLTB_ACCOUNT_REFERRAL_CUSTOM := NULL;
        END;
      
        P_WRK_CLDACCVM.v_account_referral_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.referral_person);
        P_WRK_CLDACCVM.v_account_referral_custom.relationship_officer := FN_GET_CUST_NAME('RO',
                                                                                          L_CLTB_ACCOUNT_REFERRAL_CUSTOM.relationship_officer);
        P_WRK_CLDACCVM.v_account_referral_custom.sale_channel         := L_CLTB_ACCOUNT_REFERRAL_CUSTOM.sale_channel;
      
      END IF;
      --referral changes sampath ends
    
    END IF;
  
    --sampath ends
  
    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of clpks_cldaccvm_Custom.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

END CLPKS_CLDACCVM_CUSTOM;
