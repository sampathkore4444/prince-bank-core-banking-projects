/*function fnPopulatePurchaseProp(){

if (document.getElementById("BLK_CREDIT_RISK__EXPOSURE_TYPE").value == "11_Exposures to Real Estate"){

document.getElementById("BLK_CREDIT_RISK__PURCHASED_PROP_USDI").value = 0;

fnDisableElement(document.getElementById("BLK_CREDIT_RISK__PURCHASED_PROP_USDI"));

}

}*/

function fnInTab_TAB_CREDIT_RISK_CUSTOM(){


document.getElementById("BLK_CREDIT_RISK__MAIN_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

document.getElementById("BLK_CREDIT_RISK__SUB_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

document.getElementById("BLK_CREDIT_RISK__OF_WHICH_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

return true;


}

function fnInTab_TAB_UDF_CUSTOM(){

var length = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;


for(var j=0;j<length;j++){


if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[3].getElementsByTagName('INPUT')[0].value == "INDUSTRY"){

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[8].getElementsByTagName('INPUT')[0].disabled = true;

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_DESCRC7').disabled = true;

}

if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[3].getElementsByTagName('INPUT')[0].value == "SECTOR"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[8].getElementsByTagName('INPUT')[0].disabled = true;

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_DESCRC7').disabled = true;

}

if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[3].getElementsByTagName('INPUT')[0].value == "REFERAL STAFF"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.style.visibility = "hidden";
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[8].getElementsByTagName('INPUT')[0].disabled = true;

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_DESCRC7').disabled = true;

}
  
    if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[3].getElementsByTagName('INPUT')[0].value == "OFFICER IN CHARGE"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.style.visibility = "hidden";
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[7].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[8].getElementsByTagName('INPUT')[0].disabled = true;

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__FIELD_DESCRC7').disabled = true;

}


}

return true;


}

function fnPostUnlock_CUSTOM() {
document.getElementById("BLK_REFERRAL_DTLS__SALE_CHANNEL").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL_DTLS__RELATIONSHIP_OFFICER").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL_DTLS__REFERRAL_PERSON").nextSibling.nextSibling.style.visibility="hidden";

return true;

}


