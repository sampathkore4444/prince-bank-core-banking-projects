-- Create table
create table CLTB_ACCOUNT_REFERRAL_CUSTOM
(
  loan_account_number  VARCHAR2(35) not null,
  branch_code          VARCHAR2(3) not null,
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255)
)
/
alter table CLTB_ACCOUNT_REFERRAL_CUSTOM add primary key (LOAN_ACCOUNT_NUMBER, BRANCH_CODE)
/
-- Create table
create table CLTB_ACCOUNT_REFERRAL_CUSTOM_HIST
(
  loan_account_number  VARCHAR2(35),
  branch_code          VARCHAR2(3),
  referral_person      VARCHAR2(255),
  relationship_officer VARCHAR2(255),
  sale_channel         VARCHAR2(255),
  unique_seq_no        VARCHAR2(25)
)
/
