/*function fnPopulatePurchaseProp(){



if (document.getElementById("BLK_RISK_SCORE__EXPOSURE_TYPE").value == "11_Exposures to Real Estate"){


document.getElementById("BLK_RISK_SCORE__PURCHASED_PROP_USDI").value = 0;

fnDisableElement(document.getElementById("BLK_RISK_SCORE__PURCHASED_PROP_USDI"));

}

}*/

function fnInTab_TAB_CREDIT_SCORE_CUSTOM(){

document.getElementById("BLK_RISK_SCORE__MAIN_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

document.getElementById("BLK_RISK_SCORE__SUB_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

document.getElementById("BLK_RISK_SCORE__OF_WHICH_SECTOR").nextSibling.nextSibling.style.visibility="hidden";

return true;

}

function fnInTab_TAB_UDF_CUSTOM(){


var length = document.getElementById("BLK_CLVWS_ACCOUNT_UDF_CHAR").tBodies[0].rows.length;


for(var j=0;j<length;j++){

console.log("Field Name="+ document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value);

if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value == "INDUSTRY"){

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__DESCRIPTIONRC7').disabled = true;

}

if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value == "SECTOR"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__DESCRIPTIONRC3').disabled = true;

}


if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value == "REFERAL STAFF"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.style.visibility = "hidden";
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__DESCRIPTIONRC3').disabled = true;

}

if(document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[1].getElementsByTagName('INPUT')[0].value == "OFFICER IN CHARGE"){


document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].disabled = true;
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.style.visibility = "hidden";
document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR').tBodies[0].rows[j].cells[2].getElementsByTagName('INPUT')[0].nextSibling.nextSibling.style.visibility = "hidden";

document.getElementById('BLK_CLVWS_ACCOUNT_UDF_CHAR__DESCRIPTIONRC3').disabled = true;

}


}

return true;

}

function fnPostNew_CUSTOM() {
document.getElementById("BLK_REFERRAL_DTLS__SALE_CHANNEL").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL_DTLS__RELATIONSHIP_OFFICER").nextSibling.nextSibling.style.visibility="hidden";
document.getElementById("BLK_REFERRAL_DTLS__REFERRAL_PERSON").nextSibling.nextSibling.style.visibility="hidden";

return true;

}