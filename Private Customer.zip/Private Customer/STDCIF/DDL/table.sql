-- Create table
create table STTM_CUSTOMER_CUSTOM_REFERRAL_TEMP
(
  customer_no          VARCHAR2(9) not null,
  sale_channel         VARCHAR2(105),
  referral_person      VARCHAR2(105),
  relationship_officer VARCHAR2(105)
)
/
alter table STTM_CUSTOMER_CUSTOM_REFERRAL_TEMP add primary key (CUSTOMER_NO)
/