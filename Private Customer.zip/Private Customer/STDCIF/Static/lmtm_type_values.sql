
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'CEO', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'CEO Private', 'I');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'CEO Relatives', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Chairman', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Chairman Private', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Chairman Relatives', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Other Corporate Private', 'C');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Other Private', 'I');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Prince Group Partner', 'C');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Shareholders', 'I');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Shareholders Private', 'I');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Shareholders Relatives', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Sister Company', 'C');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Sister Company SM', 'I');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Vice Chairman', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Vice Chairman Private', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRIVATE_STATUS', 'Vice Chairman Relatives', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'BFS (Business Financial Service)', 'BFS');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Branches', 'BRN');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Direct Sales', 'DS');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'MB (Mobile Banking)', 'MB');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'Merchant Team', 'MT');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'PCP (Private Client Portfolio)', 'PCP');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('SALE_CHANNEL', 'PFS (Priority Financial Service)', 'PFS');

COMMIT;
