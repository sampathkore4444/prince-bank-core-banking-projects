insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('ST-PRIN-024', 'ENG', 'Relationship Officer should not be null', 'E', 'N', 'STDCIF', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('ST-PRIN-025', 'ENG', 'Sale Channel should not be null', 'E', 'N', 'STDCIF', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('ST-PRIN-026', 'ENG', 'Private Customer Status should be Null for Non-Private Customers', 'E', 'N', 'STDCIF', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('ST-PRIN-027', 'ENG', 'Private Customer Status should not be Null for Private Customers', 'E', 'N', 'STDCIF', 1, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
