insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_NAME_REFERRER', 'MASSIVE_DISTRIBUTIONS', 'Business Supply Service', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_NAME_REFERRER_TD', 'MASSIVE_DISTRIBUTIONS', 'Business Supply Service', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Rachhann Leang', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Pho Visak', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Ouk Mnut', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Som Devid', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Tim Seyha', 'Business Development Supervisor', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Tha Panha', 'Business Development Supervisor', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Sou Phoeurn', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Chiem Sopanha', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Deng Chhunly', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Chab Chamnan', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Chhut Sokha', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Eam Tarong', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Mek Meta', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Nat Ron', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Heng Sambo', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER', 'Meach Makara', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Rachhann Leang', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Pho Visak', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Ouk Mnut', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Som Devid', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Tim Seyha', 'Business Development Supervisor', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Tha Panha', 'Business Development Supervisor', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Sou Phoeurn', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Chiem Sopanha', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Deng Chhunly', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Chab Chamnan', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Chhut Sokha', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Eam Tarong', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Mek Meta', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Nat Ron', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Heng Sambo', 'Business Development Executive', 'N');

insert into udtm_lov (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'Meach Makara', 'Business Development Executive', 'N');

COMMIT;
