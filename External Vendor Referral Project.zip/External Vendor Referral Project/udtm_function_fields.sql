insert into udtm_function_fields (FIELD_NAME, FUNCTION_ID)
values ('VENDOR_NAME_REFERRER', 'STDCUSAC');

insert into udtm_function_fields (FIELD_NAME, FUNCTION_ID)
values ('VENDOR_NAME_REFERRER_TD', 'STDCUSTD');

insert into udtm_function_fields (FIELD_NAME, FUNCTION_ID)
values ('VENDOR_STAFF_NAME_REFERRER', 'STDCUSAC');

insert into udtm_function_fields (FIELD_NAME, FUNCTION_ID)
values ('VENDOR_STAFF_NAME_REFERRER_TD', 'STDCUSTD');

COMMIT;
