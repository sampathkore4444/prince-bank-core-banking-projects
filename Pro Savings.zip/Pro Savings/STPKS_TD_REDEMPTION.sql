CREATE OR REPLACE PACKAGE BODY STPKS_TD_REDEMPTION AS

  TB_G_MEMO_REC      TY_MEMO_REC;
  PKG_TEMP_MEMO_REC  TY_MEMO_REC;
  PKG_TEMP_MEMO_REC1 TY_MEMO_REC;
  PKG_TEMP_MEMO_REC2 TY_MEMO_REC;
  PKG_LOOKUP         ACPKS.TBL_LOOKUP;

  G_CCY VARCHAR2(3);

  PKG_RATE_CHART     STTM_ACCOUNT_CLASS.TD_RATECHART_ALLOW%TYPE;
  G_INT_START_DATE   ICTM_ACC.INT_START_DATE%TYPE;
  G_TAX_PAY_CCY_FLAG ICTMS_RULE_FRM.TAX_CALC_CCY%TYPE;

  PROCEDURE DBG(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IC', 'STPKS_TD_REDEMPTION--->' || X);
  END DBG;

  PROCEDURE PR_RESET_PENALTY IS
  BEGIN
    DBG('Inside pr_Reset_Penalty ');
    ICPKSS_CALC.G_PENALTY := 1;
    IF ICPKSS_BOD.G_WAVE_PENALTY = 'Y' THEN
      DBG('Setting Penaly to 0 - cause waived');
      ICPKSS_CALC.G_PENALTY := 0;
    END IF;
  END PR_RESET_PENALTY;
  PROCEDURE PR_WAIVE_PENALTY IS
  BEGIN
    DBG('Inside Pr_Waive_Penalty ');
    ICPKSS_CALC.G_PENALTY := 0;
  END PR_WAIVE_PENALTY;

  PROCEDURE PR_PRINT_INT(P_TB_INT DBMS_SQL.NUMBER_TABLE) IS
    L_INDEX PLS_INTEGER;
  BEGIN
    IF P_TB_INT.COUNT > 0 THEN
      L_INDEX := P_TB_INT.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        DBG('Printing table:' || L_INDEX || '~' || P_TB_INT(L_INDEX));
        L_INDEX := P_TB_INT.NEXT(L_INDEX);
      END LOOP;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO exception in pr_print_int' || SQLERRM);
  END PR_PRINT_INT;

  FUNCTION FN_INSERT_TD_BROKEN(P_BRN        IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                               P_ACC        IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                               P_OLD_AMT    IN ICTB_ENTRIES_HISTORY.AMT%TYPE,
                               P_NEW_AMT    IN ICTB_ENTRIES_HISTORY.AMT%TYPE,
                               P_CCY        IN VARCHAR2,
                               P_DIFF_AMT   IN ICTB_ENTRIES_HISTORY.AMT%TYPE,
                               P_LIQD       IN VARCHAR2,
                               P_ACCR       IN VARCHAR2,
                               P_IS_TAX     IN VARCHAR2,
                               P_IS_PNL     IN VARCHAR2,
                               P_ERROR_CODE IN OUT VARCHAR2,
                               P_FRM_NO     IN NUMBER) RETURN BOOLEAN IS
    L_DRCR   VARCHAR2(1);
    L_SEQ_NO NUMBER := 0;
  BEGIN
  
    DBG('Inside fn_insert_td_broken');
    DBG('icpks_fcj_icdredmn.g_redemrefno' ||
        ICPKS_FCJ_ICDREDMN.G_REDEMREFNO);
    SELECT DECODE(SIGN(P_DIFF_AMT), 1, 'C', 'D') INTO L_DRCR FROM DUAL;
  
    BEGIN
      SELECT COUNT(1)
        INTO L_SEQ_NO
        FROM ICTB_TD_BROKEN
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND CCY = P_CCY;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO in select from ictb_td_broken' || SQLERRM);
        L_SEQ_NO := 0;
    END;
    L_SEQ_NO := L_SEQ_NO + 1;
  
    DBG('l_Seq_no=' || L_SEQ_NO);
  
    INSERT INTO ICTB_TD_BROKEN
      (BRN,
       ACC,
       BROKEN_DATE,
       LIQD_AMT_TILLDATE,
       NEW_LIQD_AMT,
       CCY,
       DRCR,
       DIFF_AMT,
       LIQD,
       ACCR,
       IS_TAX,
       IS_PENALTY,
       SEQ_NO,
       REDEM_REF_NO,
       FRM_NO)
    VALUES
      (P_BRN,
       P_ACC,
       GLOBAL.APPLICATION_DATE,
       P_OLD_AMT,
       P_NEW_AMT,
       P_CCY,
       L_DRCR,
       P_DIFF_AMT,
       NVL(P_LIQD, 'N'),
       NVL(P_ACCR, 'N'),
       NVL(P_IS_TAX, 'N'),
       NVL(P_IS_PNL, 'N'),
       L_SEQ_NO,
       ICPKS_FCJ_ICDREDMN.G_REDEMREFNO,
       P_FRM_NO);
    DBG('inserted into ictb_td_broken for:' || P_ACC);
    DBG('Insertion ocunt:' || SQL%ROWCOUNT);
  
    DBG('Successfully coming out of fn_insert_td_broken');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in wot of fn_insert_td_broken-->' || SQLERRM);
      DBG(' Tracer-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERROR_CODE := 'IC-MU0008';
      RETURN FALSE;
    
  END FN_INSERT_TD_BROKEN;

  FUNCTION FN_FIND_LIQD_AMT(P_BRN  IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                            P_ACC  IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                            P_PROD IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                            
                            P_LIQD_AMT OUT DBMS_SQL.NUMBER_TABLE,
                            P_TAX_AMT  OUT DBMS_SQL.NUMBER_TABLE,
                            
                            P_ERROR_CODE IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_START_DT DATE;
    L_TO_DATE  DATE;
    L_FLAG     NUMBER := 0;
  
    L_AMT_LIQD_TILLDATE DBMS_SQL.NUMBER_TABLE;
    L_AMT_TAX_TILLDATE  DBMS_SQL.NUMBER_TABLE;
  
    L_REC_ICTM_ACC ICTM_ACC%ROWTYPE;
  
    L_BROKEN_DATE ICTB_TD_BROKEN.BROKEN_DATE%TYPE;
    L_SEQ_NO      ICTB_TD_BROKEN.SEQ_NO%TYPE;
  
    L_PREV_LIQN_DATE DATE;
    L_RULE           ICTM_PR_INT.RULE%TYPE;
    L_PROD_REC       ICTM_PR_INT%ROWTYPE;
  
  BEGIN
    DBG('Inside FN_FIND_LIQD_AMT');
  
    L_TO_DATE := GLOBAL.APPLICATION_DATE;
  
    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
  
    DBG('Before Computing liquidation amount');
  
    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(P_PROD);
    L_RULE     := L_PROD_REC.RULE;
  
    FOR EACH_REC IN (SELECT HIS.*
                       FROM ICTB_ENTRIES_HISTORY HIS, ICTM_RULE_FRM B
                      WHERE B.FRM_NO = HIS.FRM_NO
                        AND HIS.BRN = P_BRN
                        AND HIS.ACC = P_ACC
                        AND HIS.PROD = P_PROD
                        AND B.RULE_ID = L_RULE
                        AND HIS.LIQN = 'Y'
                        AND HIS.ENTRY_PASSED = 'Y'
                        AND HIS.ENT_DT >= L_REC_ICTM_ACC.INT_START_DATE
                        AND B.BOOK_FLAG = 'B'
                      ORDER BY ENT_DT DESC) LOOP
    
      BEGIN
      
        L_BROKEN_DATE := NULL;
        BEGIN
          SELECT MAX(BROKEN_DATE)
            INTO L_BROKEN_DATE
            FROM ICTB_TD_BROKEN
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND LIQD = 'Y'
             AND NVL(IS_TAX, 'N') = 'N'
             AND NVL(IS_PENALTY, 'N') = 'N'
             AND NVL(ACCR, 'N') = 'N'
             AND FRM_NO = EACH_REC.FRM_NO
             AND BROKEN_DATE > EACH_REC.ENT_DT
             AND BROKEN_DATE <= L_TO_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_BROKEN_DATE := NULL;
            DBG(SQLERRM);
        END;
      
        DBG('l_broken_date~l_prev_liqn_date~each_rec.ent_dt~each_rec.frm_no' ||
            L_BROKEN_DATE || '~' || L_PREV_LIQN_DATE || '~' ||
            EACH_REC.ENT_DT || '~' || EACH_REC.FRM_NO);
        IF L_PREV_LIQN_DATE IS NOT NULL THEN
          DBG('Redemption entry identified in broken td already for date' ||
              L_PREV_LIQN_DATE ||
              'should not refer entries history anymore');
          IF EACH_REC.ENT_DT != L_PREV_LIQN_DATE THEN
            DBG('Interest  liqn date for different date ..exit the loop');
            EXIT;
          END IF;
        END IF;
      
        IF L_BROKEN_DATE IS NOT NULL THEN
          L_SEQ_NO := 0;
          BEGIN
            SELECT NVL(MAX(SEQ_NO), 0)
              INTO L_SEQ_NO
              FROM ICTB_TD_BROKEN
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND LIQD = 'Y'
               AND NVL(IS_TAX, 'N') = 'N'
               AND NVL(IS_PENALTY, 'N') = 'N'
               AND NVL(ACCR, 'N') = 'N'
               AND FRM_NO = EACH_REC.FRM_NO
               AND BROKEN_DATE = L_BROKEN_DATE;
          EXCEPTION
            WHEN OTHERS THEN
              L_SEQ_NO := 0;
              DBG(SQLERRM);
          END;
        
          FOR EACH_BR_TD IN (SELECT *
                               FROM ICTB_TD_BROKEN
                              WHERE BRN = EACH_REC.BRN
                                AND ACC = EACH_REC.ACC
                                AND LIQD = 'Y'
                                AND NVL(IS_TAX, 'N') = 'N'
                                AND NVL(IS_PENALTY, 'N') = 'N'
                                AND NVL(ACCR, 'N') = 'N'
                                AND FRM_NO = EACH_REC.FRM_NO
                                   
                                AND BROKEN_DATE = L_BROKEN_DATE
                                AND NVL(SEQ_NO, 0) = L_SEQ_NO) LOOP
          
            L_PREV_LIQN_DATE := EACH_REC.ENT_DT;
            IF L_AMT_LIQD_TILLDATE.EXISTS(EACH_BR_TD.FRM_NO) THEN
            
              L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) := L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) +
                                                        EACH_BR_TD.NEW_LIQD_AMT;
            
            ELSE
            
              L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) := EACH_BR_TD.NEW_LIQD_AMT;
            
            END IF;
            DBG('each_br_td.frm_no .. ' || EACH_BR_TD.FRM_NO);
            DBG('each_br_td.new_liqd_amt  .. ' || EACH_BR_TD.NEW_LIQD_AMT);
            DBG('l_amt_liqd_tilldate(each_br_td.frm_no) .. ' ||
                L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO));
          
            L_FLAG := 1;
            EXIT;
          END LOOP;
        END IF;
      
        IF L_FLAG <> 1 THEN
        
          IF L_AMT_LIQD_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN
          
            L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) +
                                                    EACH_REC.AMT;
          
          ELSE
          
            L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := EACH_REC.AMT;
          
          END IF;
          DBG('each_rec.frm_no .. ' || EACH_REC.FRM_NO);
        
          DBG('each_rec.amt  .. ' || EACH_REC.AMT);
          DBG('l_amt_liqd_tilldate(each_rec.frm_no) .. ' ||
              L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO));
        
        END IF;
      
        L_TO_DATE := EACH_REC.ENT_DT;
        L_FLAG    := 0;
      END;
    
      IF NOT L_AMT_LIQD_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN
        DBG('l_amt_liqd_tilldate not exists');
        L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := 0;
      END IF;
    
    END LOOP;
    P_LIQD_AMT := L_AMT_LIQD_TILLDATE;
  
    DBG('printing p_liqd_amt');
    PR_PRINT_INT(P_TB_INT => P_LIQD_AMT);
  
    DBG('Before Computing tax amount');
    L_FLAG := 0;
  
    L_TO_DATE        := GLOBAL.APPLICATION_DATE;
    L_PREV_LIQN_DATE := NULL;
  
    FOR EACH_REC IN (SELECT HIS.*
                       FROM ICTB_ENTRIES_HISTORY HIS, ICTM_RULE_FRM B
                      WHERE B.RULE_ID = L_RULE
                        AND B.FRM_NO = HIS.FRM_NO
                        AND HIS.BRN = P_BRN
                        AND HIS.ACC = P_ACC
                        AND HIS.PROD = P_PROD
                        AND HIS.DRCR = 'D'
                        AND HIS.LIQN = 'Y'
                        AND HIS.ENTRY_PASSED = 'Y'
                        AND HIS.ENT_DT >= L_REC_ICTM_ACC.INT_START_DATE
                        AND B.BOOK_FLAG = 'T'
                      ORDER BY ENT_DT DESC) LOOP
    
      BEGIN
      
        L_BROKEN_DATE := NULL;
        BEGIN
          SELECT MAX(BROKEN_DATE)
            INTO L_BROKEN_DATE
            FROM ICTB_TD_BROKEN
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND LIQD = 'Y'
             AND NVL(IS_TAX, 'N') = 'Y'
             AND NVL(IS_PENALTY, 'N') = 'N'
             AND NVL(ACCR, 'N') = 'N'
             AND FRM_NO = EACH_REC.FRM_NO
             AND BROKEN_DATE > EACH_REC.ENT_DT
             AND BROKEN_DATE <= L_TO_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_BROKEN_DATE := NULL;
        END;
      
        DBG('l_broken_date~l_prev_liqn_date~each_rec.ent_dt~each_rec.frm_no' ||
            L_BROKEN_DATE || '~' || L_PREV_LIQN_DATE || '~' ||
            EACH_REC.ENT_DT || '~' || EACH_REC.FRM_NO);
        IF L_PREV_LIQN_DATE IS NOT NULL THEN
          DBG('Redemption entry identified in broken td already for date' ||
              L_PREV_LIQN_DATE ||
              'should not refer entries history anymore');
          IF EACH_REC.ENT_DT != L_PREV_LIQN_DATE THEN
            DBG('Tax liqn date for different date ..exit the loop');
            EXIT;
          END IF;
        END IF;
      
        IF L_BROKEN_DATE IS NOT NULL THEN
          L_SEQ_NO := 0;
          BEGIN
            SELECT NVL(MAX(SEQ_NO), 0)
              INTO L_SEQ_NO
              FROM ICTB_TD_BROKEN
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND LIQD = 'Y'
               AND FRM_NO = EACH_REC.FRM_NO
               AND NVL(IS_TAX, 'N') = 'Y'
               AND NVL(IS_PENALTY, 'N') = 'N'
               AND NVL(ACCR, 'N') = 'N'
               AND BROKEN_DATE = L_BROKEN_DATE;
          EXCEPTION
            WHEN OTHERS THEN
              L_SEQ_NO := 0;
              DBG(SQLERRM);
          END;
        
          FOR EACH_BR_TD IN (SELECT *
                               FROM ICTB_TD_BROKEN
                              WHERE BRN = EACH_REC.BRN
                                AND ACC = EACH_REC.ACC
                                AND LIQD = 'Y'
                                AND NVL(IS_TAX, 'N') = 'Y'
                                AND NVL(IS_PENALTY, 'N') = 'N'
                                AND NVL(ACCR, 'N') = 'N'
                                AND FRM_NO = EACH_REC.FRM_NO
                                AND BROKEN_DATE = L_BROKEN_DATE
                                AND NVL(SEQ_NO, 0) = L_SEQ_NO)
          
           LOOP
          
            L_PREV_LIQN_DATE := EACH_REC.ENT_DT;
            IF L_AMT_TAX_TILLDATE.EXISTS(EACH_BR_TD.FRM_NO) THEN
              L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) := L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) +
                                                       EACH_BR_TD.NEW_LIQD_AMT;
            ELSE
              L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) := EACH_BR_TD.NEW_LIQD_AMT;
            END IF;
            DBG('each_br_td.frm_no .. ' || EACH_BR_TD.FRM_NO);
            DBG('each_br_td.new_liqd_amt  .. ' || EACH_BR_TD.NEW_LIQD_AMT);
            DBG('l_amt_tax_tilldate(each_br_td.frm_no) .. ' ||
                L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO));
          
            L_FLAG := 1;
            EXIT;
          END LOOP;
        END IF;
        IF L_FLAG <> 1 THEN
        
          IF L_AMT_TAX_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN
            L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) +
                                                   EACH_REC.AMT;
          ELSE
            L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := EACH_REC.AMT;
          END IF;
        
          DBG('each_rec.frm_no .. ' || EACH_REC.FRM_NO);
          DBG('each_rec.amt  .. ' || EACH_REC.AMT);
          DBG('l_amt_tax_tilldate(each_rec.frm_no) .. ' ||
              L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO));
        
        END IF;
      
        L_TO_DATE := EACH_REC.ENT_DT;
        L_FLAG    := 0;
      END;
    
      IF NOT L_AMT_TAX_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN
        DBG('l_amt_tax_tilldate not exists');
        L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := 0;
      END IF;
    
    END LOOP;
    P_TAX_AMT := L_AMT_TAX_TILLDATE;
  
    DBG('Successfully coming out of fn_find_liqd_amt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in wot of fn_find_liqd_amt-->' || SQLERRM);
      DBG(' Tracer-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERROR_CODE := 'IC-MU0008';
      RETURN FALSE;
  END FN_FIND_LIQD_AMT;

  FUNCTION FN_ACCR_ADJ(P_TXN_REF_NO   IN VARCHAR2,
                       P_BRN          IN VARCHAR2,
                       P_PRODUCT_CODE IN VARCHAR2,
                       P_CCY          IN VARCHAR2,
                       P_ACC          IN VARCHAR2,
                       TB_G_MEMO_REC  IN TY_MEMO_REC,
                       P_ERR_CODE     IN OUT VARCHAR2,
                       P_ERR_PARAM    IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_EXPENSE_GL     CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_PAYABLE_GL     CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_ACCRUED_AMT    NUMBER(22, 7);
    L_ADJ_AMOUNT     NUMBER(22, 7);
    L_REC_ICTM_ACC   ICTM_ACC%ROWTYPE;
    L_LAST_LIQN_DATE DATE;
    L_TRN_CODE       CSTM_PRODUCT_EVENT_ACCT_ENTRY.TRANSACTION_CODE%TYPE;
    L_FRM_NO         NUMBER;
  
    L_DRCR_IND VARCHAR2(1) := 'C';
    L_TMP_GL   CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
  
    L_REC_CUST_ACC STTMS_CUST_ACCOUNT%ROWTYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    DBG('Inside fn_accr_adj ');
  
    IF CSPKS_ACC_SERVICE.G_ACCR_ADJ_DONE THEN
      DBG('Already accrual adjustment done..return true');
      RETURN TRUE;
    END IF;
  
    L_FRM_NO   := TB_G_MEMO_REC(1).FRM_NO;
    L_DRCR_IND := TB_G_MEMO_REC(1).DRCR_IND;
  
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, L_REC_CUST_ACC) THEN
      DBG('Failed in select from sttm_cust_Account');
    END IF;
    DBG('l_Rec_cust_Acc.acc_Status = ' || L_REC_CUST_ACC.ACC_STATUS);
  
    IF NOT PKG_LOOKUP.EXISTS(1) THEN
      PKG_LOOKUP(1).NETIND := 'N';
      PKG_LOOKUP(1).MIS_HEAD := '';
    END IF;
  
    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
  
    BEGIN
      SELECT TRANSACTION_CODE
        INTO L_TRN_CODE
        FROM CSTM_PRODUCT_EVENT_ACCT_ENTRY
       WHERE PRODUCT_CODE = P_PRODUCT_CODE
         AND EVENT_CODE = 'IACR'
         AND AMT_TAG = 'IACR'
            
         AND DR_CR_INDICATOR = L_DRCR_IND
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        L_TRN_CODE := 'DPA';
    END;
  
    --sampath starts
    IF P_PRODUCT_CODE IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
      
    DBG('L_FRM_NO='||L_FRM_NO);
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND L_FRM_NO = 2 THEN
      
        L_TRN_CODE := 'CLX';
      
      END IF;
    
    END IF;
    --sampath ends
    
    --Pro Savings Sampath Starts
    IF P_PRODUCT_CODE IN ('PS01', 'PS02', 'PS03', 'PS04') THEN
      
    DBG('L_FRM_NO='||L_FRM_NO);
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND L_FRM_NO = 2 THEN
      
        L_TRN_CODE := 'CLX';
      
      END IF;
    
    END IF;
    --Pro Savings Sampath Ends
  
    SELECT ACCOUNT_HEAD
      INTO L_EXPENSE_GL
      FROM (SELECT A.ACCOUNT_HEAD
              FROM CSTM_BRANCH_PRODRTH_DETAIL A, CSTB_ACCROLE B
             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
               AND A.ACCOUNTING_ROLE LIKE '%PNL-' || L_FRM_NO
               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-' || L_FRM_NO
               AND A.STATUS = NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND A.PRODUCT_CODE IN
                   (SELECT PRODUCT_CODE
                      FROM CSTM_BRANCH_PRODRTH_MASTER
                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND RECORD_STAT = 'O'
                       AND AUTH_STAT = 'A')
            UNION
            SELECT A.ACCOUNT_HEAD
              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
               AND A.ACCOUNTING_ROLE LIKE '%PNL-' || L_FRM_NO
               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-' || L_FRM_NO
               AND A.STATUS = NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                      FROM CSTM_BRANCH_PRODRTH_DETAIL A, CSTB_ACCROLE B
                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                       AND A.ACCOUNTING_ROLE LIKE '%PNL-' || L_FRM_NO
                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-' || L_FRM_NO
                       AND A.STATUS =
                           NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
                       AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND A.PRODUCT_CODE IN
                           (SELECT PRODUCT_CODE
                              FROM CSTM_BRANCH_PRODRTH_MASTER
                             WHERE PRODUCT_CODE = P_PRODUCT_CODE
                               AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND RECORD_STAT = 'O'
                               AND AUTH_STAT = 'A')))
     WHERE ROWNUM = 1;
  
    DBG('l_expense_gl:' || L_EXPENSE_GL);
  
    SELECT ACCOUNT_HEAD
      INTO L_PAYABLE_GL
      FROM (SELECT A.ACCOUNT_HEAD
              FROM CSTM_BRANCH_PRODRTH_DETAIL A, CSTB_ACCROLE B
             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
               AND A.ACCOUNTING_ROLE LIKE '%-ACCR-' || L_FRM_NO
               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-%' || L_FRM_NO
               AND A.STATUS = NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
               AND A.PRODUCT_CODE IN
                   (SELECT PRODUCT_CODE
                      FROM CSTM_BRANCH_PRODRTH_MASTER
                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                       AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND RECORD_STAT = 'O'
                       AND AUTH_STAT = 'A')
            UNION
            SELECT A.ACCOUNT_HEAD
              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
               AND A.ACCOUNTING_ROLE LIKE '%-ACCR-' || L_FRM_NO
               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-%' || L_FRM_NO
               AND A.STATUS = NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                      FROM CSTM_BRANCH_PRODRTH_DETAIL A, CSTB_ACCROLE B
                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                       AND A.ACCOUNTING_ROLE LIKE '%-ACCR-' || L_FRM_NO
                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ-%' || L_FRM_NO
                       AND A.STATUS =
                           NVL(L_REC_CUST_ACC.ACC_STATUS, A.STATUS)
                       AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND A.PRODUCT_CODE IN
                           (SELECT PRODUCT_CODE
                              FROM CSTM_BRANCH_PRODRTH_MASTER
                             WHERE PRODUCT_CODE = P_PRODUCT_CODE
                               AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND RECORD_STAT = 'O'
                               AND AUTH_STAT = 'A')))
     WHERE ROWNUM = 1;
  
    DBG('l_payable_gl:' || L_PAYABLE_GL);
  
    IF L_DRCR_IND = 'D' THEN
    
      L_TMP_GL     := L_EXPENSE_GL;
      L_EXPENSE_GL := L_PAYABLE_GL;
      L_PAYABLE_GL := L_TMP_GL;
      L_TMP_GL     := NULL;
    END IF;
  
    IF TDPKS_UTILS.G_ACCR_ADJ_STDT IS NOT NULL THEN
      DBG('Reversing intraday accrual - tdpks_utils.g_accr_adj_stdt=' ||
          TDPKS_UTILS.G_ACCR_ADJ_STDT);
      BEGIN
        SELECT SUM(CUR_RUN_ACCR)
          INTO L_ACCRUED_AMT
          FROM ICTBS_ENTRIES_HISTORY_ACCR A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND A.ENTRY_PASSED = 'Y'
           AND A.PROD = P_PRODUCT_CODE
           AND A.FRM_NO = NVL(L_FRM_NO, A.FRM_NO)
           AND A.ENT_DT =
               (SELECT MAX(ENT_DT)
                  FROM ICTBS_ENTRIES_HISTORY_ACCR A
                 WHERE A.ACC = P_ACC
                   AND A.BRN = P_BRN
                   AND A.PROD = P_PRODUCT_CODE
                   AND A.ENTRY_PASSED = 'Y'
                   AND A.FRM_NO = NVL(L_FRM_NO, A.FRM_NO)
                      
                   AND A.ENT_DT = TDPKS_UTILS.G_ACCR_ADJ_STDT);
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Not even single accrual happend');
          L_ACCRUED_AMT := 0;
      END;
    
    ELSE
    
      BEGIN
        SELECT NVL(MAX(ENT_DT + 1), L_REC_ICTM_ACC.INT_START_DATE)
          INTO L_LAST_LIQN_DATE
          FROM ICTBS_ENTRIES_HISTORY A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND A.LIQN = 'Y'
           AND A.ENTRY_PASSED = 'Y'
              
           AND A.ENT_DT >= L_REC_ICTM_ACC.INT_START_DATE;
      EXCEPTION
        WHEN OTHERS THEN
          L_LAST_LIQN_DATE := L_REC_ICTM_ACC.INT_START_DATE;
      END;
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        DBG('status change cluster....');
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_accrued_amt') := L_ACCRUED_AMT;
        IF NOT STPKS_TD_REDEMPTION_CLUSTER.FN_ACCR_ADJ(P_TXN_REF_NO,
                                                       P_BRN,
                                                       P_PRODUCT_CODE,
                                                       P_CCY,
                                                       P_ACC,
                                                       TB_G_MEMO_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
          DBG('Failed in call to stpks_td_redemption_cluster.fn_accr_adj');
          RETURN FALSE;
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_accrued_amt') THEN
          L_ACCRUED_AMT := L_TB_CLUSTER_DATA('l_accrued_amt');
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        BEGIN
          SELECT SUM(ACCRUED_AMT)
            INTO L_ACCRUED_AMT
          
            FROM ICTBS_ENTRIES_HISTORY_ACCR A
          
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
                
             AND A.ENTRY_PASSED = 'Y'
             AND A.FRM_NO = NVL(L_FRM_NO, A.FRM_NO)
             AND A.ENT_DT =
                 (SELECT MAX(ENT_DT)
                  
                    FROM ICTBS_ENTRIES_HISTORY_ACCR A
                  
                   WHERE A.ACC = P_ACC
                     AND A.BRN = P_BRN
                        
                     AND A.ENTRY_PASSED = 'Y'
                     AND A.FRM_NO = NVL(L_FRM_NO, A.FRM_NO)
                        
                     AND A.ENT_DT >= L_LAST_LIQN_DATE);
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Not even single accrual happend');
            L_ACCRUED_AMT := 0;
        END;
      END IF;
      DBG('l_accrued_amt=' || L_ACCRUED_AMT);
      DBG('tb_g_memo_rec(1).amt=' || TB_G_MEMO_REC(1).AMT);
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    L_ADJ_AMOUNT := TB_G_MEMO_REC(1).AMT - NVL(L_ACCRUED_AMT, 0);
    DBG('l_adj_amount=' || L_ADJ_AMOUNT);
  
    IF NVL(L_ADJ_AMOUNT, 0) <> 0 THEN
      IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
             '**') <> 'SIMULATION' THEN
      
        IF NOT FN_DO_ACCOUNTING(L_TRN_CODE,
                                P_TXN_REF_NO,
                                'IACR',
                                L_ADJ_AMOUNT,
                                'IACR',
                                
                                L_PAYABLE_GL,
                                L_EXPENSE_GL,
                                P_BRN,
                                P_ACC,
                                P_CCY,
                                P_PRODUCT_CODE,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
          DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
          P_ERR_CODE := 'IC-MU0008';
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('Adjustment Accounting Done..');
    END IF;
    TDPKS_UTILS.G_ACCR_ADJ_STDT := NULL;
    DBG('Successfully coming out of fn_accr_adj');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in wot of fn_accr_adj-->' || SQLERRM);
      DBG('fn_accr_adj Tracer-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    
  END FN_ACCR_ADJ;

  FUNCTION FN_ACLOOKUP(P_TXN_REF_NO   IN VARCHAR2,
                       P_BRN          IN VARCHAR2,
                       P_PRODUCT_CODE IN VARCHAR2,
                       P_CCY          IN VARCHAR2,
                       P_ACC          IN VARCHAR2,
                       P_BOOK_ACCOUNT IN VARCHAR2,
                       
                       P_AMT_LIQD_TILLDATE IN OUT DBMS_SQL.NUMBER_TABLE,
                       TB_G_MEMO_REC       IN TY_MEMO_REC,
                       P_ERR_CODE          IN OUT VARCHAR2,
                       P_ERR_PARAM         IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_LOOKUP     ACPKS.TBL_LOOKUP;
    L_FRM_NO     NUMBER(5);
    L_FORMULA_NO NUMBER(5);
    L_DIFF_AMT   NUMBER(22, 7);
    L_TAX_AMT    NUMBER(22, 7);
  
    L_TAX_AMT_TILLDATE DBMS_SQL.NUMBER_TABLE;
  
    L_DRCR           VARCHAR2(1);
    L_DR_CR_ACCOUNT1 STTB_ACCOUNT.AC_GL_NO%TYPE;
    L_DR_CR_ACCOUNT2 STTB_ACCOUNT.AC_GL_NO%TYPE;
    L_EXPENSE_GL     CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_PAYABLE_GL     CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_MEMO_REC       TY_MEMO_REC;
    L_ACCQUIRED_AMT  NUMBER(22, 7);
    L_LIQ_COUNT      NUMBER := 0;
  
    L_ISTOPUP_ACCT   NUMBER := 0;
    L_ADJ_START_DATE DATE;
    L_REC_ICTM_ACC   ICTM_ACC%ROWTYPE;
    L_LIQ_INT        NUMBER := 0;
    L_BROKEN_AMT     NUMBER := 0;
  
    L_PENALTY_AMT NUMBER(22, 3);
  
    L_FATCA_EXT_CUSTOMER_SDE NUMBER := NULL;
    L_FATCA_TAX_AMT          NUMBER;
    L_REFERRAL_TABLE         TATBS_FATCA_REFERRAL%ROWTYPE;
    L_REFERRAL_NEEDED        BOOLEAN := FALSE;
  
    L_FATCA_AUDIT_LOG      TATBS_FATCA_AUDIT_LOG%ROWTYPE;
    L_ACCOUNT_CLASS        STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_FATCA_AUDIT_LOG_REQD BOOLEAN := FALSE;
  
    L_RULE_ID     ICTM_PR_INT.RULE%TYPE;
    L_ICTM_PR_INT ICTMS_PR_INT%ROWTYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_BOOK_FLAG ICTMS_RULE_FRM.BOOK_FLAG%TYPE;
  
    L_ACCR_FLAG ICTMS_RULE_FRM.ACCR_FLAG%TYPE;
  BEGIN
    DBG('In fn_aclookup');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT STPKS_TD_REDEMPTION_CLUSTER.FN_ACLOOKUP(P_TXN_REF_NO,
                                                     P_BRN,
                                                     P_PRODUCT_CODE,
                                                     P_CCY,
                                                     P_ACC,
                                                     P_BOOK_ACCOUNT,
                                                     P_AMT_LIQD_TILLDATE,
                                                     TB_G_MEMO_REC,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAM,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_td_redemption_cluster.FN_ACLOOKUP' || SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      DBG('p_txn_ref_no:' || P_TXN_REF_NO);
      DBG('p_brn:' || P_BRN);
      DBG('p_product_code:' || P_PRODUCT_CODE);
      DBG('p_ccy:' || P_CCY);
      DBG('p_book_account:' || P_BOOK_ACCOUNT);
    
      DBG('*******************************printing the tb_g_memo_rec table now ************************************* ');
      DECLARE
        L_TMP_IDX PLS_INTEGER;
      BEGIN
        IF TB_G_MEMO_REC.COUNT > 0 THEN
          L_TMP_IDX := TB_G_MEMO_REC.FIRST;
          WHILE L_TMP_IDX IS NOT NULL LOOP
            DBG('brn~acc~prod~frm_no~is_tax~drcr_ind~amt' || TB_G_MEMO_REC(L_TMP_IDX).BRN || '~' || TB_G_MEMO_REC(L_TMP_IDX).ACC || '~' || TB_G_MEMO_REC(L_TMP_IDX).PROD || '~' || TB_G_MEMO_REC(L_TMP_IDX)
                .FRM_NO || '~' || TB_G_MEMO_REC(L_TMP_IDX).IS_TAX || '~' || TB_G_MEMO_REC(L_TMP_IDX)
                .DRCR_IND || '~' || TB_G_MEMO_REC(L_TMP_IDX).AMT);
            L_TMP_IDX := TB_G_MEMO_REC.NEXT(L_TMP_IDX);
          END LOOP;
        END IF;
      END;
      DBG(' ************************done with printing the tb_g_memo_rec table now *******************************');
    
      DBG('Just before acfn_lookup');
      DBG('Product code is ' || P_PRODUCT_CODE);
      IF NOT
          ACPKSS.ACFN_LOOKUP(P_PRODUCT_CODE, 'ILIQ', L_LOOKUP, P_ERR_CODE) THEN
      
        DBG('p_err_code:' || P_ERR_CODE);
        DBG('Returning false with:' || SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('after acfn_lookup. lookup count:' || L_LOOKUP.COUNT);
      IF (L_LOOKUP.COUNT = 0) THEN
        RETURN FALSE;
      END IF;
      FOR I IN 1 .. L_LOOKUP.COUNT LOOP
        DBG('TAG IS: ' || L_LOOKUP(I).AMTTAG);
      END LOOP;
    
      IF TB_G_MEMO_REC.COUNT > 0 THEN
      
        DECLARE
          I PLS_INTEGER;
        BEGIN
          I := TB_G_MEMO_REC.FIRST;
          WHILE I IS NOT NULL
          
           LOOP
          
            DBG('first step i' || I);
            L_FORMULA_NO := TB_G_MEMO_REC(I).FRM_NO;
            IF NOT P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
              P_AMT_LIQD_TILLDATE(L_FORMULA_NO) := 0;
            END IF;
          
            IF NOT PKG_TAX_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
              PKG_TAX_LIQD_TILLDATE(L_FORMULA_NO) := 0;
            END IF;
            DBG('Inside the main loop memo rec formula no' || L_FORMULA_NO);
          
            BEGIN
              DBG('Fetching Book Flag');
            
              DBG('P_PRODUCT_CODE' || P_PRODUCT_CODE);
              L_ICTM_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(P_PRODUCT_CODE);
            
              SELECT BOOK_FLAG, ACCR_FLAG
                INTO L_BOOK_FLAG, L_ACCR_FLAG
              
                FROM ICTMS_RULE_FRM
               WHERE RULE_ID = L_ICTM_PR_INT.RULE
                 AND FRM_NO = TB_G_MEMO_REC(I).FRM_NO;
            
              DBG('Book flag' || L_BOOK_FLAG || 'Accr Flag' || L_ACCR_FLAG);
            
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed while ACCR FLAG for Rule : ' || SQLERRM);
            END;
          
            IF TB_G_MEMO_REC(I).DRCR_IND = 'C' AND
               
                NVL(TB_G_MEMO_REC(I).IS_TAX, 'N') = 'N' THEN
              DBG('Step1 ILIQ');
            
              DBG('Printing p_amt_liqd_tilldate');
              PR_PRINT_INT(P_AMT_LIQD_TILLDATE);
              DBG('Printing Pkg_redem_amt_accr');
              PR_PRINT_INT(PKG_REDEM_AMT_ACCR);
            
              DBG('Tb_g_memo_rec(i).amt:' || TB_G_MEMO_REC(I).AMT);
              DBG('pkg_j=' || PKG_J);
            
              IF PKG_FROM_BROKEN_TD THEN
              
                IF PKG_IS_BROKEN_TD AND PKG_J = 1 THEN
                  DBG('broken td True');
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
                    DBG('p_amt_liqd_tilldate(l_Formula_No)=' ||
                        P_AMT_LIQD_TILLDATE(L_FORMULA_NO));
                    DBG('Tb_g_memo_rec(i).amt=' || TB_G_MEMO_REC(I).AMT);
                  
                    L_DIFF_AMT := P_AMT_LIQD_TILLDATE(L_FORMULA_NO) - TB_G_MEMO_REC(I).AMT;
                  
                  END IF;
                
                  DBG('l_diff_amt :' || L_DIFF_AMT);
                  IF L_DIFF_AMT > 0 THEN
                    DBG('difference amount is debited from already liquidated amount' ||
                        L_DIFF_AMT);
                    P_ERR_CODE := 'IC-REDMN-17';
                    OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                  
                  END IF;
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
                  
                    DBG('Will be inserting old_amt~new_amt~diff_amt ' ||
                        P_AMT_LIQD_TILLDATE(L_FORMULA_NO) || '~' || TB_G_MEMO_REC(I).AMT || '~' ||
                        L_DIFF_AMT || 'in the broken TD');
                  
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                               TB_G_MEMO_REC(I).AMT,
                                               P_CCY,
                                               L_DIFF_AMT,
                                               'Y',
                                               'N',
                                               'N',
                                               'N',
                                               P_ERR_CODE,
                                               L_FORMULA_NO) THEN
                    
                      DBG('Failed in fn_insert_td_broken');
                      RETURN FALSE;
                    END IF;
                  END IF;
                
                ELSE
                  DBG('broken td false');
                  L_DIFF_AMT := TB_G_MEMO_REC(I).AMT;
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
                    DBG('Inserting the l_diff_amt as such here..' ||
                        L_DIFF_AMT);
                  
                    DBG('old_amt~new_amt~diff_amt ' ||
                        P_AMT_LIQD_TILLDATE(L_FORMULA_NO) || '~' || TB_G_MEMO_REC(I).AMT || '~' ||
                        L_DIFF_AMT || 'in the broken TD');
                  
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                               TB_G_MEMO_REC(I).AMT,
                                               P_CCY,
                                               L_DIFF_AMT,
                                               'N',
                                               'Y',
                                               'N',
                                               'N',
                                               P_ERR_CODE,
                                               L_FORMULA_NO) THEN
                      DBG('Failed in fn_insert_td_broken');
                      RETURN FALSE;
                    END IF;
                  END IF;
                
                  IF TB_G_MEMO_REC(I).DRCR_IND = 'C' AND L_ACCR_FLAG = 'Y' THEN
                  
                    L_MEMO_REC(1) := TB_G_MEMO_REC(I);
                    PKG_LOOKUP(1).NETIND := 'N';
                    PKG_LOOKUP(1).MIS_HEAD := '';
                    DBG('calling fn_accr_adj');
                    IF NOT FN_ACCR_ADJ(P_TXN_REF_NO,
                                       P_BRN,
                                       P_PRODUCT_CODE,
                                       P_CCY,
                                       P_ACC,
                                       L_MEMO_REC,
                                       P_ERR_CODE,
                                       P_ERR_PARAM) THEN
                      DBG('failed in fn_accr_adj ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      RETURN FALSE;
                    END IF;
                  END IF;
                END IF;
              
              ELSE
              
                DBG('partial redemption');
                IF PKG_PROCESSING_REM_AMT THEN
                  DBG('Remaining Amount');
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) AND
                     PKG_REDEM_AMT_ACCR.EXISTS(L_FORMULA_NO) THEN
                    L_DIFF_AMT := P_AMT_LIQD_TILLDATE(L_FORMULA_NO) -
                                  (PKG_REDEM_AMT_ACCR(L_FORMULA_NO) + TB_G_MEMO_REC(I).AMT);
                  END IF;
                
                  DBG('l_diff_amt--->' || L_DIFF_AMT);
                
                  IF L_DIFF_AMT > 0 THEN
                    DBG('difference amount is debited from already liquidated amount' ||
                        L_DIFF_AMT);
                    P_ERR_CODE := 'IC-REDMN-17';
                    OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                  
                  END IF;
                
                  UPDATE ICTMS_TD_DETAILS A
                     SET LIQ_AMT = TB_G_MEMO_REC(I).AMT
                   WHERE A.BRN = P_BRN
                     AND A.ACC = P_ACC;
                
                  DBG('No of rows updated for ictms_td_details:' ||
                      SQL%ROWCOUNT);
                
                  DBG('SDL- Before Entry');
                  IF STPKS_STDTDTOP_UTILS.G_INT_LIQD.EXISTS(L_FORMULA_NO) THEN
                    DBG('Step 1');
                    DBG('Tb_g_memo_rec(i).amt' || TB_G_MEMO_REC(I).AMT);
                    DBG('stpks_stdtdtop_utils.g_int_liqd(l_Formula_No)' ||
                        STPKS_STDTDTOP_UTILS.G_INT_LIQD(L_FORMULA_NO));
                  
                    L_BROKEN_AMT := TB_G_MEMO_REC(I)
                                    .AMT +
                                     STPKS_STDTDTOP_UTILS.G_INT_LIQD(L_FORMULA_NO);
                  ELSE
                    DBG('Step 2');
                    DBG('Tb_g_memo_rec(i).amt' || TB_G_MEMO_REC(I).AMT);
                    L_BROKEN_AMT := TB_G_MEMO_REC(I).AMT;
                  
                  END IF;
                  DBG('l_broken_amt' || L_BROKEN_AMT || L_FORMULA_NO);
                
                  DBG('l_broken_amt=' || L_BROKEN_AMT);
                
                  IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                             P_ACC,
                                             P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                             
                                             L_BROKEN_AMT,
                                             
                                             P_CCY,
                                             L_DIFF_AMT,
                                             'Y',
                                             'N',
                                             'N',
                                             'N',
                                             P_ERR_CODE,
                                             L_FORMULA_NO) THEN
                  
                    DBG('Failed in fn_insert_td_broken');
                  
                    RETURN FALSE;
                  
                  END IF;
                
                ELSE
                  DBG('Redemption Amount');
                  L_DIFF_AMT := TB_G_MEMO_REC(I).AMT;
                
                  IF TB_G_MEMO_REC(I).DRCR_IND = 'C' THEN
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                               TB_G_MEMO_REC(I).AMT,
                                               P_CCY,
                                               L_DIFF_AMT,
                                               'N',
                                               'Y',
                                               'N',
                                               'N',
                                               P_ERR_CODE,
                                               L_FORMULA_NO) THEN
                    
                      DBG('Failed in fn_insert_td_broken');
                    
                      RETURN FALSE;
                    
                    END IF;
                  END IF;
                
                END IF;
              END IF;
            
              SELECT DECODE(SIGN(L_DIFF_AMT), 1, 'C', 'D')
                INTO L_DRCR
                FROM DUAL;
            
              DBG('l_drcr ' || L_DRCR);
              DBG('Accrual difference amt:' || L_DIFF_AMT);
            
              FOR J IN 1 .. L_LOOKUP.COUNT LOOP
              
                L_FRM_NO := TO_NUMBER(SUBSTR(L_LOOKUP(J).ACCROLE,
                                             INSTR(L_LOOKUP(J).ACCROLE,
                                                   '-',
                                                   -1) + 1));
              
                IF (SUBSTR(L_LOOKUP(J).ACCROLE,
                           INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                           4)) <> 'BOOK' AND
                   L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                  .AMTTAG = ('ILIQ') THEN
                
                  DBG('l_frm_no:' || L_FRM_NO);
                  DBG('Do accounting2');
                
                  PKG_LOOKUP(1) := L_LOOKUP(J);
                
                  IF PKG_FROM_BROKEN_TD AND (NOT PKG_IS_BROKEN_TD) THEN
                  
                    L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                    L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = TRUE AND
                        PKG_IS_BROKEN_TD = TRUE) THEN
                  
                    IF PKG_J = 2 THEN
                      L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                      L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                    
                    ELSE
                    
                      IF PKG_J = 1 THEN
                      
                        SELECT ACCOUNT_HEAD
                          INTO L_EXPENSE_GL
                          FROM (SELECT A.ACCOUNT_HEAD
                                  FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                       CSTB_ACCROLE               B
                                 WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                   AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                   AND A.ACCOUNTING_ROLE LIKE
                                       '%PNL-' || L_FRM_NO
                                   AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                   AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                                   AND A.PRODUCT_CODE IN
                                       (SELECT PRODUCT_CODE
                                          FROM CSTM_BRANCH_PRODRTH_MASTER
                                         WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                           AND BRANCH_CODE =
                                               GLOBAL.CURRENT_BRANCH
                                           AND RECORD_STAT = 'O'
                                           AND AUTH_STAT = 'A')
                                UNION
                                SELECT A.ACCOUNT_HEAD
                                  FROM CSTMS_PRODUCT_ACCROLE A,
                                       CSTB_ACCROLE          B
                                 WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                   AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                   AND A.ACCOUNTING_ROLE LIKE
                                       '%PNL-' || L_FRM_NO
                                   AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                   AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                       (SELECT A.ACCOUNTING_ROLE,
                                               A.PRODUCT_CODE
                                          FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                               CSTB_ACCROLE               B
                                         WHERE A.PRODUCT_CODE =
                                               P_PRODUCT_CODE
                                           AND A.ACCOUNTING_ROLE =
                                               B.ROLE_CODE
                                           AND A.ACCOUNTING_ROLE LIKE
                                               '%PNL-' || L_FRM_NO
                                           AND A.ACCOUNTING_ROLE NOT LIKE
                                               '%ADJ%'
                                           AND A.BRANCH_CODE =
                                               GLOBAL.CURRENT_BRANCH
                                           AND A.PRODUCT_CODE IN
                                               (SELECT PRODUCT_CODE
                                                  FROM CSTM_BRANCH_PRODRTH_MASTER
                                                 WHERE PRODUCT_CODE =
                                                       P_PRODUCT_CODE
                                                   AND BRANCH_CODE =
                                                       GLOBAL.CURRENT_BRANCH
                                                   AND RECORD_STAT = 'O'
                                                   AND AUTH_STAT = 'A')))
                         WHERE ROWNUM = 1;
                      
                        DBG('l_expense_gl:' || L_EXPENSE_GL);
                      
                        L_DR_CR_ACCOUNT1 := L_EXPENSE_GL;
                        L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                      
                      END IF;
                    END IF;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = FALSE) AND
                        (PKG_PROCESSING_REM_AMT = TRUE) THEN
                  
                    SELECT ACCOUNT_HEAD
                      INTO L_EXPENSE_GL
                      FROM (SELECT A.ACCOUNT_HEAD
                              FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                   CSTB_ACCROLE               B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND A.PRODUCT_CODE IN
                                   (SELECT PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_MASTER
                                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                       AND BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND RECORD_STAT = 'O'
                                       AND AUTH_STAT = 'A')
                            UNION
                            SELECT A.ACCOUNT_HEAD
                              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                           CSTB_ACCROLE               B
                                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                       AND A.ACCOUNTING_ROLE LIKE
                                           '%PNL-' || L_FRM_NO
                                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                       AND A.BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND A.PRODUCT_CODE IN
                                           (SELECT PRODUCT_CODE
                                              FROM CSTM_BRANCH_PRODRTH_MASTER
                                             WHERE PRODUCT_CODE =
                                                   P_PRODUCT_CODE
                                               AND BRANCH_CODE =
                                                   GLOBAL.CURRENT_BRANCH
                                               AND RECORD_STAT = 'O'
                                               AND AUTH_STAT = 'A')))
                     WHERE ROWNUM = 1;
                  
                    DBG('l_expense_gl:' || L_EXPENSE_GL);
                  
                    L_DR_CR_ACCOUNT1 := L_EXPENSE_GL;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = FALSE) AND
                        (PKG_PROCESSING_REM_AMT = FALSE) THEN
                  
                    SELECT ACCOUNT_HEAD
                      INTO L_EXPENSE_GL
                      FROM (SELECT A.ACCOUNT_HEAD
                              FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                   CSTB_ACCROLE               B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND A.PRODUCT_CODE IN
                                   (SELECT PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_MASTER
                                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                       AND BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND RECORD_STAT = 'O'
                                       AND AUTH_STAT = 'A')
                            UNION
                            SELECT A.ACCOUNT_HEAD
                              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                           CSTB_ACCROLE               B
                                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                       AND A.ACCOUNTING_ROLE LIKE
                                           '%PNL-' || L_FRM_NO
                                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                       AND A.BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND A.PRODUCT_CODE IN
                                           (SELECT PRODUCT_CODE
                                              FROM CSTM_BRANCH_PRODRTH_MASTER
                                             WHERE PRODUCT_CODE =
                                                   P_PRODUCT_CODE
                                               AND BRANCH_CODE =
                                                   GLOBAL.CURRENT_BRANCH
                                               AND RECORD_STAT = 'O'
                                               AND AUTH_STAT = 'A')))
                     WHERE ROWNUM = 1;
                  
                    DBG('l_expense_gl::::' || L_EXPENSE_GL);
                  
                    L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                    L_DR_CR_ACCOUNT2 := L_EXPENSE_GL;
                  
                  ELSE
                  
                    L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                  
                  END IF;
                  DBG('l_dr_cr_account1:' || L_DR_CR_ACCOUNT1);
                  DBG('l_dr_cr_account2:' || L_DR_CR_ACCOUNT2);
                
                  IF L_LOOKUP(J)
                   .AMTTAG = 'ILIQ' AND L_LOOKUP(J).DRCRIND = 'C' AND
                      NVL(L_FATCA_AUDIT_LOG.BASIS_AMOUNT, 0) = 0 AND
                      NVL(L_DIFF_AMT, 0) <> 0 THEN
                    L_FATCA_AUDIT_LOG.TRANSACTION_CODE := L_LOOKUP(J)
                                                          .TRNCODE;
                    DBG('trnCode : ' || L_FATCA_AUDIT_LOG.TRANSACTION_CODE);
                  
                    L_REFERRAL_TABLE.AMOUNT_TAG         := L_LOOKUP(J)
                                                           .AMTTAG;
                    L_REFERRAL_TABLE.TRANSACTION_CODE   := L_LOOKUP(J)
                                                           .TRNCODE;
                    L_REFERRAL_TABLE.TRANSACTION_AMOUNT := L_DIFF_AMT;
                    DBG('BASIS trnCode~amtTag : ' ||
                        L_REFERRAL_TABLE.TRANSACTION_CODE || '~' ||
                        L_REFERRAL_TABLE.AMOUNT_TAG);
                  
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT := L_DIFF_AMT;
                    DBG('Set fatca tax basis amount as : ' ||
                        L_FATCA_AUDIT_LOG.BASIS_AMOUNT);
                  END IF;
                
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 1;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('TXN_CODE') := L_LOOKUP(J).TRNCODE;
                    L_TB_CLUSTER_DATA('ACC_ROLE') := L_LOOKUP(J).ACCROLE;
                    L_TB_CLUSTER_DATA('AMT_TAG') := L_LOOKUP(J).AMTTAG;
                    L_TB_CLUSTER_DATA('DIFF_AMT') := L_DIFF_AMT;
                    L_TB_CLUSTER_DATA('ACCOUNT2') := L_DR_CR_ACCOUNT2;
                    L_TB_CLUSTER_DATA('ACCOUNT1') := L_DR_CR_ACCOUNT1;
                    L_TB_CLUSTER_DATA('PKG_J') := PKG_J;
                    L_TB_CLUSTER_DATA('event') := 'ILIQ';
                    IF NOT
                        STPKS_TD_REDEMPTION_CLUSTER.FN_ACLOOKUP(P_TXN_REF_NO,
                                                                P_BRN,
                                                                P_PRODUCT_CODE,
                                                                P_CCY,
                                                                P_ACC,
                                                                P_BOOK_ACCOUNT,
                                                                P_AMT_LIQD_TILLDATE,
                                                                TB_G_MEMO_REC,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAM,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
                      DBG('stpks_td_redemption_cluster.FN_ACLOOKUP ' ||
                          SQLERRM);
                      RETURN FALSE;
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('ACCOUNT1') THEN
                      L_DR_CR_ACCOUNT1 := L_TB_CLUSTER_DATA('ACCOUNT1');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('ACCOUNT2') THEN
                      L_DR_CR_ACCOUNT2 := L_TB_CLUSTER_DATA('ACCOUNT2');
                    END IF;
                  
                  END IF;
                
                  IF NOT GLOBAL.G_SKIP_KERNEL THEN
                  
                    IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                           '**') <> 'SIMULATION' THEN
                    
                      IF NOT FN_DO_ACCOUNTING(L_LOOKUP        (J).TRNCODE,
                                              P_TXN_REF_NO,
                                              L_LOOKUP        (J).AMTTAG,
                                              L_DIFF_AMT,
                                              'ILIQ',
                                              L_DR_CR_ACCOUNT1,
                                              L_DR_CR_ACCOUNT2,
                                              P_BRN,
                                              P_ACC,
                                              P_CCY,
                                              P_PRODUCT_CODE,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
                        DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        RETURN FALSE;
                      END IF;
                    END IF;
                  
                  END IF;
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                
                ELSIF (SUBSTR(L_LOOKUP(J).ACCROLE,
                              INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                              4)) <> 'BOOK' AND
                      L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                     .AMTTAG = ('IACQUIRED') AND PKG_FROM_BROKEN_TD
                     
                      AND ((PKG_J = 1) OR
                      (PKG_J = 2 AND
                      STPKS_STDTDTOP_UTILS.G_TOPUP_ADHOC_TD_REDMN)) THEN
                
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 8;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('L_accquired_AMT') := L_ACCQUIRED_AMT;
                    IF NOT
                        STPKS_TD_REDEMPTION_CLUSTER.FN_ACLOOKUP(P_TXN_REF_NO,
                                                                P_BRN,
                                                                P_PRODUCT_CODE,
                                                                P_CCY,
                                                                P_ACC,
                                                                P_BOOK_ACCOUNT,
                                                                P_AMT_LIQD_TILLDATE,
                                                                TB_G_MEMO_REC,
                                                                P_ERR_CODE,
                                                                P_ERR_PARAM,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
                      DBG(' Failed in  stpks_td_redemption_cluster.fn_aclookup');
                      RETURN FALSE;
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('L_accquired_AMT ') THEN
                      L_ACCQUIRED_AMT := L_TB_CLUSTER_DATA('L_accquired_AMT');
                    END IF;
                  END IF;
                  IF NOT GLOBAL.G_SKIP_KERNEL THEN
                  
                    BEGIN
                      SELECT ACQUIRED_AMT
                        INTO L_ACCQUIRED_AMT
                        FROM ICTBS_ENTRIES
                       WHERE BRN = TB_G_MEMO_REC(I).BRN
                         AND ACC = TB_G_MEMO_REC(I).ACC
                         AND PROD = TB_G_MEMO_REC(I).PROD
                         AND FRM_NO = TB_G_MEMO_REC(I).FRM_NO;
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_ACCQUIRED_AMT := 0;
                    END;
                  
                  END IF;
                  GLOBAL.PR_RESET_SKIP_KERNEL;
                
                  BEGIN
                    SELECT COUNT(1)
                      INTO L_LIQ_COUNT
                      FROM ICTBS_ENTRIES_HISTORY A
                     WHERE BRN = TB_G_MEMO_REC(I).BRN
                       AND ACC = TB_G_MEMO_REC(I).ACC
                       AND PROD = TB_G_MEMO_REC(I).PROD
                       AND A.LIQN = 'Y';
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_ACCQUIRED_AMT := 0;
                  END;
                  DBG('L_accquired_AMT::' || L_ACCQUIRED_AMT);
                  IF L_ACCQUIRED_AMT <> 0 AND L_LIQ_COUNT = 0 THEN
                    IF L_ACCQUIRED_AMT > 0 THEN
                      L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                      L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                    ELSE
                      L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                      L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                    END IF;
                    L_ACCQUIRED_AMT := ABS(L_ACCQUIRED_AMT);
                    DBG('L_accquired_AMT222::' || L_ACCQUIRED_AMT);
                  
                    IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                           '**') <> 'SIMULATION' THEN
                    
                      IF NOT FN_DO_ACCOUNTING(L_LOOKUP        (J).TRNCODE,
                                              P_TXN_REF_NO,
                                              L_LOOKUP        (J).AMTTAG,
                                              L_ACCQUIRED_AMT,
                                              'ILIQ',
                                              L_DR_CR_ACCOUNT1,
                                              L_DR_CR_ACCOUNT2,
                                              P_BRN,
                                              P_ACC,
                                              P_CCY,
                                              P_PRODUCT_CODE,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
                        DBG('FAILED IN FN_DO_ACCOUNTING ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        RETURN FALSE;
                      END IF;
                    END IF;
                  END IF;
                  DBG('ACCOUNTING DONE..');
                
                  DBG('Accounting Done..');
                END IF;
              
              END LOOP;
            ELSIF TB_G_MEMO_REC(I)
             .DRCR_IND = 'D' AND
                   NVL(TB_G_MEMO_REC(I).IS_TAX, 'N') = 'Y' THEN
            
              DBG('Step2 TAX');
            
              FOR J IN 1 .. L_LOOKUP.COUNT LOOP
                L_FRM_NO := TO_NUMBER(SUBSTR(L_LOOKUP(J).ACCROLE,
                                             INSTR(L_LOOKUP(J).ACCROLE,
                                                   '-',
                                                   -1) + 1));
              
                IF (SUBSTR(L_LOOKUP(J).ACCROLE,
                           INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                           4)) = 'TPBL' AND
                   L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                  .AMTTAG = ('TAX') THEN
                
                  DBG('l_ictm_pr_int.rule' || L_ICTM_PR_INT.RULE);
                
                  BEGIN
                  
                    SELECT TAX_PAY_CCY_FLAG
                      INTO G_TAX_PAY_CCY_FLAG
                      FROM ICTMS_RULE_FRM
                     WHERE RULE_ID = L_ICTM_PR_INT.RULE
                       AND FRM_NO = L_FRM_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('Failed in picking the tax_pay_ccy_flagy');
                  END;
                  DBG('g_tax_pay_ccy_flag :' || G_TAX_PAY_CCY_FLAG);
                
                  DBG('l_frm_no:' || L_FRM_NO);
                  DBG('Do accounting2');
                
                  PKG_LOOKUP(1) := L_LOOKUP(J);
                
                  IF ((PKG_FROM_BROKEN_TD = TRUE) AND
                     (PKG_IS_BROKEN_TD = TRUE) AND (PKG_J = 1)) OR
                    
                     ((PKG_FROM_BROKEN_TD = FALSE) AND
                     (PKG_PROCESSING_REM_AMT = TRUE)) THEN
                  
                    L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                    L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                  
                    IF PKG_PROCESSING_REM_AMT THEN
                    
                      IF PKG_TAX_LIQD_TILLDATE.EXISTS(L_FRM_NO) AND
                         PKG_TAX_ON_REDEM_AMT.EXISTS(L_FRM_NO) THEN
                      
                        DBG(' PROCESSING REMAMT pkg_tax_liqd_tilldate=' ||
                            PKG_TAX_LIQD_TILLDATE(L_FRM_NO));
                      
                        DBG('Tb_g_memo_rec(i).amt=' || TB_G_MEMO_REC(I).AMT);
                      
                        DBG('Pkg_tax_on_redem_amt=' ||
                            PKG_TAX_ON_REDEM_AMT(L_FRM_NO));
                      
                        L_TAX_AMT := (PKG_TAX_LIQD_TILLDATE(L_FRM_NO) -
                                     (TB_G_MEMO_REC(I)
                                     .AMT + PKG_TAX_ON_REDEM_AMT(L_FRM_NO)));
                      END IF;
                      DBG('l_tax_amt=' || L_TAX_AMT);
                    
                      L_BROKEN_AMT := 0;
                      L_LIQ_INT    := 0;
                    
                      IF STPKS_STDTDTOP_UTILS.G_TAX_LIQD.EXISTS(L_FRM_NO) THEN
                        L_BROKEN_AMT := TB_G_MEMO_REC(I)
                                        .AMT +
                                         STPKS_STDTDTOP_UTILS.G_TAX_LIQD(L_FRM_NO);
                      ELSE
                        L_BROKEN_AMT := TB_G_MEMO_REC(I).AMT;
                      END IF;
                    
                      DBG('l_tax_amt=' || L_TAX_AMT);
                      IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                                 P_ACC,
                                                 PKG_TAX_LIQD_TILLDATE(L_FRM_NO),
                                                 
                                                 L_BROKEN_AMT,
                                                 
                                                 P_CCY,
                                                 L_TAX_AMT,
                                                 'Y',
                                                 'N',
                                                 'Y',
                                                 'N',
                                                 P_ERR_CODE,
                                                 L_FRM_NO) THEN
                      
                        DBG('Failed in fn_insert_td_broken');
                      
                        RETURN FALSE;
                      
                      END IF;
                    
                    ELSE
                    
                      IF PKG_TAX_LIQD_TILLDATE.EXISTS(L_FRM_NO) THEN
                        DBG('ELSE...pkg_tax_liqd_tilldate=' ||
                            PKG_TAX_LIQD_TILLDATE(L_FRM_NO));
                      
                        DBG('Tb_g_memo_rec(i).amt=' || TB_G_MEMO_REC(I).AMT);
                        L_TAX_AMT := (PKG_TAX_LIQD_TILLDATE(L_FRM_NO) - TB_G_MEMO_REC(I).AMT);
                      
                        IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                                   P_ACC,
                                                   PKG_TAX_LIQD_TILLDATE(L_FRM_NO),
                                                   TB_G_MEMO_REC(I).AMT,
                                                   P_CCY,
                                                   L_TAX_AMT,
                                                   'Y',
                                                   'N',
                                                   'Y',
                                                   'N',
                                                   P_ERR_CODE,
                                                   L_FRM_NO) THEN
                        
                          DBG('Failed in fn_insert_td_broken');
                        
                          RETURN FALSE;
                        
                        END IF;
                      END IF;
                    
                    END IF;
                  
                  ELSE
                  
                    L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                    L_TAX_AMT        := TB_G_MEMO_REC(I).AMT;
                    PR_PRINT_INT(P_TB_INT => PKG_TAX_LIQD_TILLDATE);
                  
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               PKG_TAX_LIQD_TILLDATE(L_FRM_NO),
                                               TB_G_MEMO_REC(I).AMT,
                                               P_CCY,
                                               L_TAX_AMT,
                                               'N',
                                               'Y',
                                               'Y',
                                               'N',
                                               P_ERR_CODE,
                                               L_FRM_NO) THEN
                    
                      DBG('Failed in fn_insert_td_broken');
                    
                      RETURN FALSE;
                    
                    END IF;
                  
                  END IF;
                
                  DBG('l_dr_cr_account1:' || L_DR_CR_ACCOUNT1);
                  DBG('l_dr_cr_account2:' || L_DR_CR_ACCOUNT2);
                
                  DBG('Do accounting for TAX');
                  DBG('tAX amt:' || TB_G_MEMO_REC(I).AMT);
                  ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD5 := L_TAX_AMT;
                  IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                         '**') <> 'SIMULATION' THEN
                  
                    IF NOT FN_DO_ACCOUNTING(L_LOOKUP        (J).TRNCODE,
                                            P_TXN_REF_NO,
                                            L_LOOKUP        (J).AMTTAG,
                                            L_TAX_AMT,
                                            'ILIQ',
                                            L_DR_CR_ACCOUNT1,
                                            L_DR_CR_ACCOUNT2,
                                            P_BRN,
                                            P_ACC,
                                            P_CCY,
                                            P_PRODUCT_CODE,
                                            P_ERR_CODE,
                                            P_ERR_PARAM) THEN
                      DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      RETURN FALSE;
                    END IF;
                  END IF;
                  DBG('Accounting Done for tax');
                  EXIT;
                
                ELSIF (SUBSTR(L_LOOKUP(J).ACCROLE,
                              INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                              (INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 2) -
                              INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) - 1))) IN
                      ('TPBL', 'FATCA_ESCROW') AND
                      L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                     .AMTTAG IN ('FATCA_TAX', 'FATCA_REFERRAL') THEN
                  DBG('STEP2.1 FATCA TAX');
                  DBG('l_Lookup(j).accrole : ' || L_LOOKUP(J).ACCROLE);
                  DBG('l_Lookup(j).amttag : ' || L_LOOKUP(J).AMTTAG);
                  IF PKG_FROM_BROKEN_TD THEN
                    DBG('pkg_From_broken_td is true');
                  END IF;
                  IF PKG_IS_BROKEN_TD THEN
                    DBG('pkg_Is_broken_td is true ');
                  END IF;
                  IF PKG_PROCESSING_REM_AMT THEN
                    DBG('pkg_processing_rem_amt : ');
                  END IF;
                  L_FATCA_EXT_CUSTOMER_SDE := ICPKS_CACHE.FN_GET_FATCA_EXT_CUST(P_BRN,
                                                                                P_ACC);
                  DBG('External customer sde value is : ' ||
                      L_FATCA_EXT_CUSTOMER_SDE);
                  IF (L_FATCA_EXT_CUSTOMER_SDE = 1 AND L_LOOKUP(J)
                     .AMTTAG = 'FATCA_TAX') OR (L_FATCA_EXT_CUSTOMER_SDE = 0 AND L_LOOKUP(J)
                     .AMTTAG = 'FATCA_REFERRAL') THEN
                    DBG('---this value should not be selected zero this--- >>->');
                    L_FATCA_TAX_AMT := 0;
                  ELSE
                    L_FATCA_TAX_AMT := TB_G_MEMO_REC(I).AMT;
                  END IF;
                  DBG('credit : ' || L_LOOKUP(J).ACCOUNT || ' debit : ' ||
                      P_BOOK_ACCOUNT);
                  IF NOT FN_DO_ACCOUNTING(L_LOOKUP       (J).TRNCODE,
                                          P_TXN_REF_NO,
                                          L_LOOKUP       (J).AMTTAG,
                                          L_FATCA_TAX_AMT,
                                          'ILIQ',
                                          L_LOOKUP       (J).ACCOUNT,
                                          P_BOOK_ACCOUNT,
                                          P_BRN,
                                          P_ACC,
                                          P_CCY,
                                          P_PRODUCT_CODE,
                                          P_ERR_CODE,
                                          P_ERR_PARAM) THEN
                    DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
                    P_ERR_CODE := 'IC-MU0008';
                    RETURN FALSE;
                  END IF;
                
                  IF L_FATCA_EXT_CUSTOMER_SDE = 0 AND L_LOOKUP(J)
                    .AMTTAG = 'FATCA_TAX' THEN
                    DBG('fatca audit log is required as the fatca decision is taken');
                    L_FATCA_AUDIT_LOG_REQD              := TRUE;
                    L_FATCA_AUDIT_LOG.CUSTOMER_ID       := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(P_BRN,
                                                                                                P_ACC);
                    L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER := P_BRN || P_ACC;
                    BEGIN
                      SELECT A.CUSTOMER_NAME1,
                             A.CUSTOMER_TYPE,
                             B.FATCA_CLASFCN
                        INTO L_FATCA_AUDIT_LOG.BENIFICIARY_NAME,
                             L_FATCA_AUDIT_LOG.CUSTOMER_TYPE,
                             L_FATCA_AUDIT_LOG.FATCA_CLASSIFICATION
                        FROM STTMS_CUSTOMER A, STTMS_CUST_FATCA B
                       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                         AND A.CUSTOMER_NO = L_FATCA_AUDIT_LOG.CUSTOMER_ID;
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('Failed while fetching customer name and customer type with : ' ||
                            SQLERRM);
                    END;
                    L_FATCA_AUDIT_LOG.OBLIGATION_TYPE := 'A';
                    BEGIN
                      SELECT ACCOUNT_CLASS
                        INTO L_ACCOUNT_CLASS
                        FROM STTMS_CUST_ACCOUNT
                       WHERE CUST_AC_NO = P_ACC
                         AND BRANCH_CODE = P_BRN;
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('failed while trying to get the account class : ' ||
                            SQLERRM);
                    END;
                    DBG('account class : ' || L_ACCOUNT_CLASS);
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_US_SOURCED(L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER,
                                                                         L_ACCOUNT_CLASS,
                                                                         L_FATCA_AUDIT_LOG.US_SOURCED_STATUS) THEN
                      DBG('Failed while fetching us sourced flag');
                    END IF;
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_GRANDFATHERED(L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER,
                                                                            L_ACCOUNT_CLASS,
                                                                            L_FATCA_AUDIT_LOG.GRANDFATHERED_STATUS) THEN
                      DBG('Failed while fetching fatca grandfathered flag');
                    END IF;
                    L_FATCA_AUDIT_LOG.WITHHOLDING_DATE := GLOBAL.APPLICATION_DATE;
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_RECALCITRANT(L_FATCA_AUDIT_LOG.CUSTOMER_ID,
                                                                           L_FATCA_AUDIT_LOG.RECALCITRANT) THEN
                      DBG('Failed while fetching fatca recalcitrant flag');
                    END IF;
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_BALANCE(L_FATCA_AUDIT_LOG.CUSTOMER_ID,
                                                                      L_FATCA_AUDIT_LOG.FATCA_BALANCE) THEN
                      DBG('failed while fetching fatca balance inside API');
                    END IF;
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT_TAG := 'ILIQ';
                  
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT_CURRENCY := P_CCY;
                    L_FATCA_AUDIT_LOG.TAX_CURRENCY          := P_CCY;
                    L_FATCA_AUDIT_LOG.TAX_AMOUNT            := NVL(L_FATCA_TAX_AMT,
                                                                   0);
                    L_FATCA_AUDIT_LOG.WITHHOLDING_USER_ID   := 'SYSTEM';
                    IF L_FATCA_AUDIT_LOG.TAX_AMOUNT = 0 THEN
                      L_FATCA_AUDIT_LOG.DECISION := 'N';
                    ELSE
                      L_FATCA_AUDIT_LOG.DECISION := 'Y';
                    END IF;
                    L_FATCA_AUDIT_LOG.OBLIGATION_BRANCH := P_BRN;
                    L_FATCA_AUDIT_LOG.TAX_AMOUNT_TAG    := 'FATCA_TAX';
                  END IF;
                
                  IF L_LOOKUP(J).AMTTAG = 'FATCA_TAX' THEN
                    L_REFERRAL_TABLE.TAX_GL         := L_LOOKUP(J).ACCOUNT;
                    L_REFERRAL_TABLE.TAX_AMOUNT_TAG := L_LOOKUP(J).AMTTAG;
                  ELSIF L_LOOKUP(J).AMTTAG = 'FATCA_REFERRAL' AND
                         L_FATCA_EXT_CUSTOMER_SDE = 1 THEN
                    L_REFERRAL_NEEDED                    := TRUE;
                    L_REFERRAL_TABLE.CUSTOMER_ID         := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(P_BRN,
                                                                                                 P_ACC);
                    L_REFERRAL_TABLE.ACCOUNT_BRANCH      := P_BRN;
                    L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT := P_BOOK_ACCOUNT;
                    L_REFERRAL_TABLE.ESCROW_GL           := L_LOOKUP(J)
                                                            .ACCOUNT;
                    L_REFERRAL_TABLE.MODULE_CODE         := 'IC';
                    L_REFERRAL_TABLE.OBLIGATION_NUMBER   := P_BRN || P_ACC;
                    L_REFERRAL_TABLE.EVENT_CODE          := 'ILIQ';
                    L_REFERRAL_TABLE.EVENT_SEQ_NO        := 1;
                  
                    L_REFERRAL_TABLE.TRANSACTION_CURRENCY := P_CCY;
                    L_REFERRAL_TABLE.TAX_CURRENCY         := P_CCY;
                  
                    L_REFERRAL_TABLE.TAX_AMOUNT := NVL(L_FATCA_TAX_AMT, 0);
                  END IF;
                
                END IF;
              END LOOP;
            
              IF L_REFERRAL_NEEDED AND
                 L_REFERRAL_TABLE.TRANSACTION_AMOUNT <> 0 THEN
                DBG('writing to FATCA referral table');
                IF NOT
                    TAPKSS_NEW.FN_INSERT_FATCA_REFERRAL(L_REFERRAL_TABLE.CUSTOMER_ID,
                                                        L_REFERRAL_TABLE.ACCOUNT_BRANCH,
                                                        L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT,
                                                        L_REFERRAL_TABLE.ESCROW_GL,
                                                        L_REFERRAL_TABLE.TAX_GL,
                                                        L_REFERRAL_TABLE.OBLIGATION_NUMBER,
                                                        L_REFERRAL_TABLE.EVENT_CODE,
                                                        L_REFERRAL_TABLE.EVENT_SEQ_NO,
                                                        L_REFERRAL_TABLE.AMOUNT_TAG,
                                                        L_REFERRAL_TABLE.TRANSACTION_CODE,
                                                        L_REFERRAL_TABLE.TAX_AMOUNT_TAG,
                                                        L_REFERRAL_TABLE.TRANSACTION_CURRENCY,
                                                        L_REFERRAL_TABLE.TRANSACTION_AMOUNT,
                                                        L_REFERRAL_TABLE.TAX_CURRENCY,
                                                        L_REFERRAL_TABLE.TAX_AMOUNT,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAM,
                                                        L_REFERRAL_TABLE.MODULE_CODE) THEN
                  DBG('failed while trying to insert into referral with : ' ||
                      P_ERR_CODE);
                  RETURN FALSE;
                END IF;
              
              ELSIF L_FATCA_AUDIT_LOG_REQD THEN
                BEGIN
                  INSERT INTO TATBS_FATCA_AUDIT_LOG
                  VALUES L_FATCA_AUDIT_LOG;
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('Record already present for the day, so updating the values on the same date');
                    UPDATE TATBS_FATCA_AUDIT_LOG
                       SET TAX_AMOUNT   = TAX_AMOUNT +
                                          L_FATCA_AUDIT_LOG.TAX_AMOUNT,
                           BASIS_AMOUNT = BASIS_AMOUNT +
                                          L_FATCA_AUDIT_LOG.BASIS_AMOUNT
                     WHERE CUSTOMER_ID = L_FATCA_AUDIT_LOG.CUSTOMER_ID
                       AND OBLIGATION_NUMBER =
                           L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER
                       AND TAX_AMOUNT_TAG =
                           L_FATCA_AUDIT_LOG.TAX_AMOUNT_TAG
                       AND WITHHOLDING_DATE =
                           L_FATCA_AUDIT_LOG.WITHHOLDING_DATE;
                  WHEN OTHERS THEN
                    DBG('failed while trying to insert into referral with : ' ||
                        P_ERR_CODE);
                    RETURN FALSE;
                END;
              
              END IF;
            
            ELSIF TB_G_MEMO_REC(I).DRCR_IND = 'D' AND
                   NVL(TB_G_MEMO_REC(I).IS_TAX, 'N') = 'N' AND
                   L_BOOK_FLAG = 'P' THEN
            
              DBG('l_book_flag' || L_BOOK_FLAG);
              DBG('Step3 penalty');
            
              FOR J IN 1 .. L_LOOKUP.COUNT LOOP
              
                L_FRM_NO := TO_NUMBER(SUBSTR(L_LOOKUP(J).ACCROLE,
                                             INSTR(L_LOOKUP(J).ACCROLE,
                                                   '-',
                                                   -1) + 1));
              
                IF (SUBSTR(L_LOOKUP(J).ACCROLE,
                           INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                           4)) <> 'BOOK' AND
                   L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                  .AMTTAG = ('ILIQ') THEN
                
                  DBG('l_frm_no:' || L_FRM_NO);
                  DBG('Do accounting3');
                
                  IF (L_LOOKUP(J).ACCROLE LIKE '%PNL%') AND
                     (L_LOOKUP(J).ACCROLE NOT LIKE '%ADJ%') THEN
                  
                    PKG_LOOKUP(1) := L_LOOKUP(J);
                  
                    L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                  
                    DBG('l_dr_cr_account1-3:' || L_DR_CR_ACCOUNT1);
                    DBG('l_dr_cr_account2-3:' || L_DR_CR_ACCOUNT2);
                  
                    L_PENALTY_AMT := TB_G_MEMO_REC(I).AMT;
                    IF ((PKG_FROM_BROKEN_TD = FALSE) AND
                       (PKG_PROCESSING_REM_AMT = TRUE)) THEN
                      IF PKG_TEMP_MEMO_REC.EXISTS(1) THEN
                        L_PENALTY_AMT := PKG_TEMP_MEMO_REC(1).AMT;
                      END IF;
                    END IF;
                  
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               0,
                                               0,
                                               P_CCY,
                                               
                                               L_PENALTY_AMT,
                                               'Y',
                                               'N',
                                               'N',
                                               'Y',
                                               P_ERR_CODE,
                                               L_FRM_NO) THEN
                    
                      DBG('Failed in fn_insert_td_broken');
                    
                      RETURN FALSE;
                    
                    END IF;
                  
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CUSTOM,
                        CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                      L_FN_CALL_ID := 2;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('TXN_CODE') := L_LOOKUP(J).TRNCODE;
                      L_TB_CLUSTER_DATA('ACC_ROLE') := L_LOOKUP(J).ACCROLE;
                      L_TB_CLUSTER_DATA('AMT_TAG') := L_LOOKUP(J).AMTTAG;
                      L_TB_CLUSTER_DATA('DIFF_AMT') := L_DIFF_AMT;
                      L_TB_CLUSTER_DATA('ACCOUNT2') := L_DR_CR_ACCOUNT2;
                      L_TB_CLUSTER_DATA('ACCOUNT1') := L_DR_CR_ACCOUNT1;
                      L_TB_CLUSTER_DATA('PKG_J') := PKG_J;
                      L_TB_CLUSTER_DATA('MEMO_REC_AMT') := TB_G_MEMO_REC(I).AMT;
                      IF NOT
                          STPKS_TD_REDEMPTION_CLUSTER.FN_ACLOOKUP(P_TXN_REF_NO,
                                                                  P_BRN,
                                                                  P_PRODUCT_CODE,
                                                                  P_CCY,
                                                                  P_ACC,
                                                                  P_BOOK_ACCOUNT,
                                                                  P_AMT_LIQD_TILLDATE,
                                                                  TB_G_MEMO_REC,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAM,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
                        DBG('stpks_td_redemption_cluster.FN_ACLOOKUP ' ||
                            SQLERRM);
                        RETURN FALSE;
                      END IF;
                    END IF;
                    IF NOT GLOBAL.G_SKIP_KERNEL THEN
                    
                      ICPKS_ICDRDSIM_KERNEL.G_ICDRDSIM.V_CSTB_UI_COLUMNS.NUM_FIELD4 := TB_G_MEMO_REC(I).AMT;
                      IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                             '**') <> 'SIMULATION' THEN
                        IF NOT FN_DO_ACCOUNTING(L_LOOKUP    (J).TRNCODE,
                                                P_TXN_REF_NO,
                                                L_LOOKUP    (J).AMTTAG,
                                                
                                                L_PENALTY_AMT,
                                                'ILIQ',
                                                L_DR_CR_ACCOUNT1,
                                                L_DR_CR_ACCOUNT2,
                                                P_BRN,
                                                P_ACC,
                                                P_CCY,
                                                P_PRODUCT_CODE,
                                                P_ERR_CODE,
                                                P_ERR_PARAM) THEN
                          DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
                          P_ERR_CODE := 'IC-MU0008';
                          RETURN FALSE;
                        END IF;
                        DBG('Accounting Done..');
                        EXIT;
                      END IF;
                    
                    END IF;
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  
                  END IF;
                END IF;
              END LOOP;
            
            ELSIF TB_G_MEMO_REC(I).DRCR_IND = 'D' AND
                   NVL(TB_G_MEMO_REC(I).IS_TAX, 'N') = 'N' AND
                   L_BOOK_FLAG != 'P' THEN
              DBG('Inside interest Debit formula - Not penalty');
            
              DBG('Tb_g_memo_rec(i).amt:' || TB_G_MEMO_REC(I).AMT);
              DBG('pkg_j=' || PKG_J);
              IF PKG_FROM_BROKEN_TD THEN
              
                IF PKG_IS_BROKEN_TD AND PKG_J = 1 THEN
                  DBG('broken td True');
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) THEN
                    DBG('p_amt_liqd_tilldate(l_Formula_No)=' ||
                        P_AMT_LIQD_TILLDATE(L_FORMULA_NO));
                    DBG('Tb_g_memo_rec(i).amt=' || TB_G_MEMO_REC(I).AMT);
                    L_DIFF_AMT := P_AMT_LIQD_TILLDATE(L_FORMULA_NO) - TB_G_MEMO_REC(I).AMT;
                  END IF;
                
                  DBG('l_diff_amt :' || L_DIFF_AMT);
                  IF L_DIFF_AMT > 0 THEN
                    DBG('difference amount is debited from already liquidated amount' ||
                        L_DIFF_AMT);
                    P_ERR_CODE := 'IC-REDMN-17';
                    OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                  END IF;
                
                  DBG('Will be inserting old_amt~new_amt~diff_amt ' ||
                      P_AMT_LIQD_TILLDATE(L_FORMULA_NO) || '~' || TB_G_MEMO_REC(I).AMT || '~' ||
                      L_DIFF_AMT || 'in the broken TD');
                
                  IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                             P_ACC,
                                             P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                             TB_G_MEMO_REC(I).AMT,
                                             P_CCY,
                                             L_DIFF_AMT,
                                             'Y',
                                             'N',
                                             'N',
                                             'N',
                                             P_ERR_CODE,
                                             L_FORMULA_NO) THEN
                  
                    DBG('Failed in fn_insert_td_broken');
                    RETURN FALSE;
                  END IF;
                
                ELSE
                  DBG('broken td false');
                  L_DIFF_AMT := TB_G_MEMO_REC(I).AMT;
                  DBG('Inserting the l_diff_amt as such here..' ||
                      L_DIFF_AMT);
                  DBG('old_amt~new_amt~diff_amt ' ||
                      P_AMT_LIQD_TILLDATE(L_FORMULA_NO) || '~' || TB_G_MEMO_REC(I).AMT || '~' ||
                      L_DIFF_AMT || 'in the broken TD');
                
                  IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                             P_ACC,
                                             P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                             TB_G_MEMO_REC(I).AMT,
                                             P_CCY,
                                             L_DIFF_AMT,
                                             'N',
                                             'Y',
                                             'N',
                                             'N',
                                             P_ERR_CODE,
                                             L_FORMULA_NO) THEN
                    DBG('Failed in fn_insert_td_broken');
                    RETURN FALSE;
                  END IF;
                
                  IF TB_G_MEMO_REC(I).DRCR_IND = 'D' AND L_ACCR_FLAG = 'Y' THEN
                  
                    L_MEMO_REC(1) := TB_G_MEMO_REC(I);
                    PKG_LOOKUP(1).NETIND := 'N';
                    PKG_LOOKUP(1).MIS_HEAD := '';
                    DBG('calling fn_accr_adj');
                    IF NOT FN_ACCR_ADJ(P_TXN_REF_NO,
                                       P_BRN,
                                       P_PRODUCT_CODE,
                                       P_CCY,
                                       P_ACC,
                                       L_MEMO_REC,
                                       P_ERR_CODE,
                                       P_ERR_PARAM) THEN
                      DBG('failed in fn_accr_adj ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      RETURN FALSE;
                    END IF;
                  END IF;
                END IF;
              
              ELSE
              
                DBG('partial redemption');
                IF PKG_PROCESSING_REM_AMT THEN
                  DBG('Remaining Amount');
                
                  IF P_AMT_LIQD_TILLDATE.EXISTS(L_FORMULA_NO) AND
                     PKG_REDEM_AMT_ACCR.EXISTS(L_FORMULA_NO) THEN
                    L_DIFF_AMT := P_AMT_LIQD_TILLDATE(L_FORMULA_NO) -
                                  (PKG_REDEM_AMT_ACCR(L_FORMULA_NO) + TB_G_MEMO_REC(I).AMT);
                  END IF;
                
                  DBG('l_diff_amt--->' || L_DIFF_AMT);
                
                  IF L_DIFF_AMT > 0 THEN
                    DBG('difference amount is debited from already liquidated amount' ||
                        L_DIFF_AMT);
                    P_ERR_CODE := 'IC-REDMN-17';
                    OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
                  
                  END IF;
                
                  UPDATE ICTMS_TD_DETAILS A
                     SET LIQ_AMT = TB_G_MEMO_REC(I).AMT
                   WHERE A.BRN = P_BRN
                     AND A.ACC = P_ACC;
                
                  DBG('No of rows updated for ictms_td_details:' ||
                      SQL%ROWCOUNT);
                
                  DBG('SDL- Before Entry2');
                  DBG('Tb_g_memo_rec(i).amt' || TB_G_MEMO_REC(I).AMT);
                
                  IF STPKS_STDTDTOP_UTILS.G_INT_LIQD.EXISTS(L_FORMULA_NO) THEN
                    DBG('Step 1');
                    DBG('Tb_g_memo_rec(i).amt' || TB_G_MEMO_REC(I).AMT);
                    DBG('stpks_stdtdtop_utils.g_int_liqd(l_Formula_No)' ||
                        STPKS_STDTDTOP_UTILS.G_INT_LIQD(L_FORMULA_NO));
                  
                    L_BROKEN_AMT := TB_G_MEMO_REC(I)
                                    .AMT +
                                     STPKS_STDTDTOP_UTILS.G_INT_LIQD(L_FORMULA_NO);
                  ELSE
                    DBG('Step 2');
                    DBG('Tb_g_memo_rec(i).amt' || TB_G_MEMO_REC(I).AMT);
                    L_BROKEN_AMT := TB_G_MEMO_REC(I).AMT;
                  
                  END IF;
                
                  DBG('l_broken_amt=' || L_BROKEN_AMT);
                
                  IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                             P_ACC,
                                             P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                             
                                             L_BROKEN_AMT,
                                             
                                             P_CCY,
                                             L_DIFF_AMT,
                                             'Y',
                                             'N',
                                             'N',
                                             'N',
                                             P_ERR_CODE,
                                             L_FORMULA_NO) THEN
                  
                    DBG('Failed in fn_insert_td_broken');
                  
                    RETURN FALSE;
                  
                  END IF;
                
                ELSE
                  DBG('Redemption Amount');
                  L_DIFF_AMT := TB_G_MEMO_REC(I).AMT;
                
                  IF TB_G_MEMO_REC(I).DRCR_IND = 'D' THEN
                    IF NOT FN_INSERT_TD_BROKEN(P_BRN,
                                               P_ACC,
                                               P_AMT_LIQD_TILLDATE(L_FORMULA_NO),
                                               TB_G_MEMO_REC(I).AMT,
                                               P_CCY,
                                               L_DIFF_AMT,
                                               'N',
                                               'Y',
                                               'N',
                                               'N',
                                               P_ERR_CODE,
                                               L_FORMULA_NO) THEN
                    
                      DBG('Failed in fn_insert_td_broken');
                    
                      RETURN FALSE;
                    
                    END IF;
                  END IF;
                
                END IF;
              END IF;
            
              SELECT DECODE(SIGN(L_DIFF_AMT), 1, 'C', 'D')
                INTO L_DRCR
                FROM DUAL;
            
              DBG('l_drcr ' || L_DRCR);
              DBG('Accrual difference amt:' || L_DIFF_AMT);
            
              FOR J IN 1 .. L_LOOKUP.COUNT LOOP
              
                L_FRM_NO := TO_NUMBER(SUBSTR(L_LOOKUP(J).ACCROLE,
                                             INSTR(L_LOOKUP(J).ACCROLE,
                                                   '-',
                                                   -1) + 1));
              
                IF (SUBSTR(L_LOOKUP(J).ACCROLE,
                           INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                           4)) <> 'BOOK' AND
                   L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                  .AMTTAG = ('ILIQ') THEN
                
                  DBG('l_frm_no:' || L_FRM_NO);
                  DBG('Do accounting2');
                
                  PKG_LOOKUP(1) := L_LOOKUP(J);
                
                  IF PKG_FROM_BROKEN_TD AND (NOT PKG_IS_BROKEN_TD) THEN
                  
                    L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                    L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = TRUE AND
                        PKG_IS_BROKEN_TD = TRUE) THEN
                  
                    IF PKG_J = 2 THEN
                      L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                      L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                    
                    ELSE
                    
                      IF PKG_J = 1 THEN
                      
                        SELECT ACCOUNT_HEAD
                          INTO L_EXPENSE_GL
                          FROM (SELECT A.ACCOUNT_HEAD
                                  FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                       CSTB_ACCROLE               B
                                 WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                   AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                   AND A.ACCOUNTING_ROLE LIKE
                                       '%PNL-' || L_FRM_NO
                                   AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                   AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                                   AND A.PRODUCT_CODE IN
                                       (SELECT PRODUCT_CODE
                                          FROM CSTM_BRANCH_PRODRTH_MASTER
                                         WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                           AND BRANCH_CODE =
                                               GLOBAL.CURRENT_BRANCH
                                           AND RECORD_STAT = 'O'
                                           AND AUTH_STAT = 'A')
                                UNION
                                SELECT A.ACCOUNT_HEAD
                                  FROM CSTMS_PRODUCT_ACCROLE A,
                                       CSTB_ACCROLE          B
                                 WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                   AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                   AND A.ACCOUNTING_ROLE LIKE
                                       '%PNL-' || L_FRM_NO
                                   AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                   AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                       (SELECT A.ACCOUNTING_ROLE,
                                               A.PRODUCT_CODE
                                          FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                               CSTB_ACCROLE               B
                                         WHERE A.PRODUCT_CODE =
                                               P_PRODUCT_CODE
                                           AND A.ACCOUNTING_ROLE =
                                               B.ROLE_CODE
                                           AND A.ACCOUNTING_ROLE LIKE
                                               '%PNL-' || L_FRM_NO
                                           AND A.ACCOUNTING_ROLE NOT LIKE
                                               '%ADJ%'
                                           AND A.BRANCH_CODE =
                                               GLOBAL.CURRENT_BRANCH
                                           AND A.PRODUCT_CODE IN
                                               (SELECT PRODUCT_CODE
                                                  FROM CSTM_BRANCH_PRODRTH_MASTER
                                                 WHERE PRODUCT_CODE =
                                                       P_PRODUCT_CODE
                                                   AND BRANCH_CODE =
                                                       GLOBAL.CURRENT_BRANCH
                                                   AND RECORD_STAT = 'O'
                                                   AND AUTH_STAT = 'A')))
                         WHERE ROWNUM = 1;
                      
                        DBG('l_expense_gl:' || L_EXPENSE_GL);
                      
                        L_DR_CR_ACCOUNT1 := L_EXPENSE_GL;
                        L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                      
                      END IF;
                    END IF;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = FALSE) AND
                        (PKG_PROCESSING_REM_AMT = TRUE) THEN
                  
                    SELECT ACCOUNT_HEAD
                      INTO L_EXPENSE_GL
                      FROM (SELECT A.ACCOUNT_HEAD
                              FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                   CSTB_ACCROLE               B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND A.PRODUCT_CODE IN
                                   (SELECT PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_MASTER
                                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                       AND BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND RECORD_STAT = 'O'
                                       AND AUTH_STAT = 'A')
                            UNION
                            SELECT A.ACCOUNT_HEAD
                              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                           CSTB_ACCROLE               B
                                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                       AND A.ACCOUNTING_ROLE LIKE
                                           '%PNL-' || L_FRM_NO
                                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                       AND A.BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND A.PRODUCT_CODE IN
                                           (SELECT PRODUCT_CODE
                                              FROM CSTM_BRANCH_PRODRTH_MASTER
                                             WHERE PRODUCT_CODE =
                                                   P_PRODUCT_CODE
                                               AND BRANCH_CODE =
                                                   GLOBAL.CURRENT_BRANCH
                                               AND RECORD_STAT = 'O'
                                               AND AUTH_STAT = 'A')))
                     WHERE ROWNUM = 1;
                  
                    DBG('l_expense_gl:' || L_EXPENSE_GL);
                  
                    L_DR_CR_ACCOUNT1 := L_EXPENSE_GL;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                  
                  ELSIF (PKG_FROM_BROKEN_TD = FALSE) AND
                        (PKG_PROCESSING_REM_AMT = FALSE) THEN
                  
                    SELECT ACCOUNT_HEAD
                      INTO L_EXPENSE_GL
                      FROM (SELECT A.ACCOUNT_HEAD
                              FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                   CSTB_ACCROLE               B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND A.PRODUCT_CODE IN
                                   (SELECT PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_MASTER
                                     WHERE PRODUCT_CODE = P_PRODUCT_CODE
                                       AND BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND RECORD_STAT = 'O'
                                       AND AUTH_STAT = 'A')
                            UNION
                            SELECT A.ACCOUNT_HEAD
                              FROM CSTMS_PRODUCT_ACCROLE A, CSTB_ACCROLE B
                             WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                               AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                               AND A.ACCOUNTING_ROLE LIKE
                                   '%PNL-' || L_FRM_NO
                               AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                               AND (ACCOUNTING_ROLE, PRODUCT_CODE) NOT IN
                                   (SELECT A.ACCOUNTING_ROLE, A.PRODUCT_CODE
                                      FROM CSTM_BRANCH_PRODRTH_DETAIL A,
                                           CSTB_ACCROLE               B
                                     WHERE A.PRODUCT_CODE = P_PRODUCT_CODE
                                       AND A.ACCOUNTING_ROLE = B.ROLE_CODE
                                       AND A.ACCOUNTING_ROLE LIKE
                                           '%PNL-' || L_FRM_NO
                                       AND A.ACCOUNTING_ROLE NOT LIKE '%ADJ%'
                                       AND A.BRANCH_CODE =
                                           GLOBAL.CURRENT_BRANCH
                                       AND A.PRODUCT_CODE IN
                                           (SELECT PRODUCT_CODE
                                              FROM CSTM_BRANCH_PRODRTH_MASTER
                                             WHERE PRODUCT_CODE =
                                                   P_PRODUCT_CODE
                                               AND BRANCH_CODE =
                                                   GLOBAL.CURRENT_BRANCH
                                               AND RECORD_STAT = 'O'
                                               AND AUTH_STAT = 'A')))
                     WHERE ROWNUM = 1;
                  
                    DBG('l_expense_gl::::' || L_EXPENSE_GL);
                  
                    L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                    L_DR_CR_ACCOUNT2 := L_EXPENSE_GL;
                  
                  ELSE
                  
                    L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                    L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                  
                  END IF;
                  DBG('l_dr_cr_account1:' || L_DR_CR_ACCOUNT1);
                  DBG('l_dr_cr_account2:' || L_DR_CR_ACCOUNT2);
                
                  IF L_LOOKUP(J)
                   .AMTTAG = 'ILIQ' AND L_LOOKUP(J).DRCRIND = 'D' AND
                      NVL(L_FATCA_AUDIT_LOG.BASIS_AMOUNT, 0) = 0 AND
                      NVL(L_DIFF_AMT, 0) <> 0 THEN
                    L_FATCA_AUDIT_LOG.TRANSACTION_CODE := L_LOOKUP(J)
                                                          .TRNCODE;
                    DBG('trnCode : ' || L_FATCA_AUDIT_LOG.TRANSACTION_CODE);
                  
                    L_REFERRAL_TABLE.AMOUNT_TAG         := L_LOOKUP(J)
                                                           .AMTTAG;
                    L_REFERRAL_TABLE.TRANSACTION_CODE   := L_LOOKUP(J)
                                                           .TRNCODE;
                    L_REFERRAL_TABLE.TRANSACTION_AMOUNT := L_DIFF_AMT;
                    DBG('BASIS trnCode~amtTag : ' ||
                        L_REFERRAL_TABLE.TRANSACTION_CODE || '~' ||
                        L_REFERRAL_TABLE.AMOUNT_TAG);
                  
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT := L_DIFF_AMT;
                    DBG('Set fatca tax basis amount as : ' ||
                        L_FATCA_AUDIT_LOG.BASIS_AMOUNT);
                  END IF;
                
                  IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                         '**') <> 'SIMULATION' THEN
                  
                    IF NOT FN_DO_ACCOUNTING(L_LOOKUP    (J).TRNCODE,
                                            P_TXN_REF_NO,
                                            L_LOOKUP    (J).AMTTAG,
                                            L_DIFF_AMT,
                                            'ILIQ',
                                            
                                            L_DR_CR_ACCOUNT2,
                                            L_DR_CR_ACCOUNT1,
                                            
                                            P_BRN,
                                            P_ACC,
                                            P_CCY,
                                            P_PRODUCT_CODE,
                                            P_ERR_CODE,
                                            P_ERR_PARAM) THEN
                      DBG('failed in FN_DO_ACCOUNTING ' || SQLERRM);
                      P_ERR_CODE := 'IC-MU0008';
                      RETURN FALSE;
                    END IF;
                  END IF;
                
                ELSIF (SUBSTR(L_LOOKUP(J).ACCROLE,
                              INSTR(L_LOOKUP(J).ACCROLE, '-', 1, 1) + 1,
                              4)) <> 'BOOK' AND
                      L_FRM_NO = TB_G_MEMO_REC(I).FRM_NO AND L_LOOKUP(J)
                     .AMTTAG = ('IACQUIRED') AND PKG_FROM_BROKEN_TD AND
                      PKG_J = 1 THEN
                  BEGIN
                    SELECT ACQUIRED_AMT
                      INTO L_ACCQUIRED_AMT
                      FROM ICTBS_ENTRIES
                     WHERE BRN = TB_G_MEMO_REC(I).BRN
                       AND ACC = TB_G_MEMO_REC(I).ACC
                       AND PROD = TB_G_MEMO_REC(I).PROD
                       AND FRM_NO = TB_G_MEMO_REC(I).FRM_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_ACCQUIRED_AMT := 0;
                  END;
                  BEGIN
                    SELECT COUNT(1)
                      INTO L_LIQ_COUNT
                      FROM ICTBS_ENTRIES_HISTORY A
                     WHERE BRN = TB_G_MEMO_REC(I).BRN
                       AND ACC = TB_G_MEMO_REC(I).ACC
                       AND PROD = TB_G_MEMO_REC(I).PROD
                       AND A.LIQN = 'Y';
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_ACCQUIRED_AMT := 0;
                  END;
                  DBG('L_accquired_AMT::' || L_ACCQUIRED_AMT);
                  IF L_ACCQUIRED_AMT <> 0 AND L_LIQ_COUNT = 0 THEN
                    IF L_ACCQUIRED_AMT > 0 THEN
                      L_DR_CR_ACCOUNT1 := P_BOOK_ACCOUNT;
                      L_DR_CR_ACCOUNT2 := L_LOOKUP(J).ACCOUNT;
                    ELSE
                      L_DR_CR_ACCOUNT1 := L_LOOKUP(J).ACCOUNT;
                      L_DR_CR_ACCOUNT2 := P_BOOK_ACCOUNT;
                    END IF;
                    L_ACCQUIRED_AMT := ABS(L_ACCQUIRED_AMT);
                    DBG('L_accquired_AMT222::' || L_ACCQUIRED_AMT);
                  
                    IF NVL(ICPKS_FCJ_ICDREDMN.G_TY_ICDREDMN.V_CSTB_UI_COLUMNS.CHAR_FIELD77,
                           '**') <> 'SIMULATION' THEN
                    
                      IF NOT FN_DO_ACCOUNTING(L_LOOKUP       (J).TRNCODE,
                                              P_TXN_REF_NO,
                                              L_LOOKUP       (J).AMTTAG,
                                              L_ACCQUIRED_AMT,
                                              'ILIQ',
                                              
                                              L_DR_CR_ACCOUNT2,
                                              L_DR_CR_ACCOUNT1,
                                              
                                              P_BRN,
                                              P_ACC,
                                              P_CCY,
                                              P_PRODUCT_CODE,
                                              P_ERR_CODE,
                                              P_ERR_PARAM) THEN
                        DBG('FAILED IN FN_DO_ACCOUNTING ' || SQLERRM);
                        P_ERR_CODE := 'IC-MU0008';
                        RETURN FALSE;
                      END IF;
                    END IF;
                  END IF;
                  DBG('ACCOUNTING DONE..');
                
                  DBG('Accounting Done..');
                END IF;
              
              END LOOP;
            
            END IF;
            I := TB_G_MEMO_REC.NEXT(I);
          END LOOP;
        END;
      END IF;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DBG('Successfully coming out of FN_ACLOOKUP');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('Failed in wot of fn_aclookup-->' || SQLERRM);
      DBG('Tracer-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
    
  END FN_ACLOOKUP;

  PROCEDURE PR_BROKEN_TD(P_BRN       IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                         P_ACC       IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                         P_ERR_CODE  IN OUT VARCHAR2,
                         P_ERR_PARAM IN OUT VARCHAR2)
  
   IS
    I INTEGER;
  
    L_CCY           STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ACCOUNT_CLASS STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
  
    L_PRE_REDEMPTION STTMS_ACCOUNT_CLASS.PRE_REDEMPTION%TYPE;
    L_PRODUCT_CODE   ICTM_PR_INT.PRODUCT_CODE%TYPE;
    L_LIQ_DAYS       ICTM_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS     ICTM_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YEARS      ICTM_PR_INT.LIQN_YEARS%TYPE;
    L_RULE           ICTM_PR_INT.RULE%TYPE;
    L_NEWTENOR       NUMBER;
    L_ORIGINALTENOR  NUMBER;
    L_AC_OPEN_DATE   DATE;
    L_AVG_BAL        NUMBER;
    L_PPO            ICTB_REDEMPTION_DETAIL.PPO%TYPE;
  
    SSQL VARCHAR2(255);
  
    L_AMT_LIQD_TILLDATE DBMS_SQL.NUMBER_TABLE;
    L_INDEX             PLS_INTEGER;
    L_TMP_FRM_NO        NUMBER;
    L_BROKEN_ACCR       NUMBER;
    L_DIFF_AMT          NUMBER;
    L_DRCR              VARCHAR2(1);
  
    L_ERR_CODE       VARCHAR2(255);
    L_ERR_PARAM      VARCHAR2(255);
    L_DAYS           INTEGER;
    L_MONTHS         INTEGER;
    L_YEARS          INTEGER;
    L_EOM            ICTM_PR_INT.LIQN_EOM%TYPE;
    L_FIRST_LIQ_DT   DATE;
    L_UDE_EFFDATE    DATE;
    L_PCENDDATE      DATE;
    L_LIQ_YN         BOOLEAN;
    L_INT_START_DATE DATE;
    EXCEPTION_RATE EXCEPTION;
  
    L_SERIAL_NO    VARCHAR2(15);
    P_TXN_REF_NO   VARCHAR2(16);
    L_BOOK_ACCOUNT ICTMS_ACC.BOOK_ACC%TYPE;
    G_CALC_FROM    DATE;
    G_CALC_TO      DATE;
  
    L_TOT_AMOUNT1 NUMBER := 0;
    L_LAST_DT     DATE;
    L_INT_AMOUNT  NUMBER := 0;
    L_LAST_DT1    DATE;
    L_ADJ_AMOUNT  NUMBER := 0;
    L_AMT1        NUMBER := 0;
    L_AMT2        NUMBER := 0;
    L_AMT3        NUMBER := 0;
  
    L_PAYOUT_COUNT NUMBER := 0;
    L_REC_ICTM_ACC ICTMS_ACC%ROWTYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_LIQN_START_ACCOUNT ICTM_PR_INT.LIQN_START_ACCOUNT%TYPE;
  
    L_OFFSET_ACC       ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;
    L_REDM_INT_PAYOUT  ICTM_ACC.REDM_INT_PAYOUT%TYPE;
    L_REDM_PAYOUT_COMP ICTM_TDREDMPAYOUT_DETAILS.REDM_PAYOUT_COMP%TYPE;
  
    L_INT_PAY_TYPE VARCHAR2(1);
    FUNCTION Q(S VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
      RETURN CSPKES_MISC.FN_GETCHR(39) || S || CSPKES_MISC.FN_GETCHR(39);
    END Q;
  
  BEGIN
  
    DBG('Entered PR_BROKEN_TD for account ' || P_ACC);
    STPKS_TD_REDEMPTION.PKG_FROM_BROKEN_TD := TRUE;
    ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR        := FALSE;
    ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ         := FALSE;
  
    SELECT B.CCY,
           C.AC_CLASS_TYPE,
           C.ACCOUNT_CLASS,
           
           D.PRODUCT_CODE,
           D.LIQN_DAYS,
           D.LIQN_MONTHS,
           D.LIQN_YEARS,
           D.RULE,
           TRUNC(NVL((GLOBAL.APPLICATION_DATE - E.INT_START_DATE), 1)) "NEWTENOR",
           TRUNC(NVL((E.MATURITY_DATE - E.INT_START_DATE), 1)) "ORGINALTENOR",
           B.AC_OPEN_DATE,
           E.INT_START_DATE,
           D.LIQN_START_ACCOUNT
      INTO L_CCY,
           L_AC_CLASS_TYPE,
           L_ACCOUNT_CLASS,
           
           L_PRODUCT_CODE,
           L_LIQ_DAYS,
           L_LIQ_MONTHS,
           L_LIQ_YEARS,
           L_RULE,
           L_NEWTENOR,
           L_ORIGINALTENOR,
           L_AC_OPEN_DATE,
           L_INT_START_DATE,
           L_LIQN_START_ACCOUNT
      FROM STTMS_CUST_ACCOUNT  B,
           STTMS_ACCOUNT_CLASS C,
           ICTM_PR_INT         D,
           ICTMS_ACC           E,
           ICTM_PR_INT_ACLASS  F,
           ICTBS_ACC_PR        G
     WHERE B.ACCOUNT_CLASS = C.ACCOUNT_CLASS
       AND B.BRANCH_CODE = E.BRN
       AND C.AC_CLASS_TYPE IN ('Y', 'S')
       AND B.CUST_AC_NO = E.ACC
       AND B.RECORD_STAT = 'O'
       AND B.AUTH_STAT = 'A'
       AND C.ACCOUNT_CLASS = F.ACLASS
          
       AND G.ACC = E.ACC
       AND G.BRN = E.BRN
       AND G.PROD = D.PRODUCT_CODE
       AND G.DEPOSIT = 'Y'
          
       AND F.PRODUCT_CODE = D.PRODUCT_CODE
       AND F.RECORD_STAT = 'N'
       AND B.CCY = F.CCY
       AND (EXISTS (SELECT X.ACC
                      FROM ICTM_ACC_PR X
                     WHERE ACC = B.CUST_AC_NO
                       AND BRN = B.BRANCH_CODE
                       AND X.WAIVE = 'N') OR NOT EXISTS
            (SELECT X.ACC
               FROM ICTM_ACC_PR X
              WHERE ACC = B.CUST_AC_NO
                AND BRN = B.BRANCH_CODE))
       AND B.CUST_AC_NO = P_ACC
       AND B.BRANCH_CODE = P_BRN;
  
    SELECT NVL(TD_AMOUNT, 0) - NVL(REDEM_AMT, 0)
      INTO L_AVG_BAL
      FROM ICTMS_TD_DETAILS
     WHERE BRN = P_BRN
       AND ACC = P_ACC;
    L_TOT_AMOUNT1 := L_AVG_BAL;
    DBG('l_avg_bal---->' || L_AVG_BAL);
  
    L_PPO := L_LIQ_DAYS || 'D' || L_LIQ_MONTHS || 'M' || L_LIQ_YEARS || 'Y';
  
    DBG('...l_ppo is' || L_PPO);
  
    G_CCY := L_CCY;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 9;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_int_start_date') := L_INT_START_DATE;
      STPKS_TD_REDEMPTION_CLUSTER.PR_BROKEN_TD(P_BRN,
                                               P_ACC,
                                               P_ERR_CODE,
                                               P_ERR_PARAM,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
      IF L_TB_CLUSTER_DATA.EXISTS('l_int_start_date') THEN
        L_INT_START_DATE := L_TB_CLUSTER_DATA('l_int_start_date');
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    L_AC_OPEN_DATE := L_INT_START_DATE;
    IF NOT FN_APPLY_RATE(P_BRN,
                         P_ACC,
                         L_AC_CLASS_TYPE,
                         L_ACCOUNT_CLASS,
                         L_PRODUCT_CODE,
                         L_CCY,
                         L_AVG_BAL,
                         L_NEWTENOR,
                         L_ORIGINALTENOR,
                         L_AC_OPEN_DATE,
                         'F'
                         
                         ) THEN
      P_ERR_CODE := 'IC-MU0008';
      DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
          SQLERRM);
      RAISE EXCEPTION_RATE;
    END IF;
  
    SELECT MAX(ENT_DT)
      INTO L_PCENDDATE
      FROM ICTBS_ENTRIES_HISTORY A
     WHERE A.ACC = P_ACC
       AND A.BRN = P_BRN
       AND A.LIQN = 'Y'
       AND A.ENTRY_PASSED = 'Y'
       AND A.ENT_DT >= L_INT_START_DATE;
    PKG_IS_BROKEN_TD := TRUE;
    DBG('l_pcenddate:' || L_PCENDDATE);
  
    DBG('PCENDDATE:' || L_PCENDDATE);
    IF L_PCENDDATE IS NULL THEN
    
      DBG('So far no liquidation');
      SELECT MAX(ENT_DT)
        INTO L_PCENDDATE
      
        FROM ICVWS_ACCR_ENTRIES_HISTORY A
      
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
            
         AND A.ENTRY_PASSED = 'Y'
         AND A.ENT_DT >= L_INT_START_DATE;
      DBG('l_pcenddate1:' || L_PCENDDATE);
      PKG_IS_BROKEN_TD := FALSE;
    ELSE
      PKG_IS_BROKEN_TD := TRUE;
    END IF;
  
    IF L_PCENDDATE IS NULL AND L_INT_START_DATE >= GLOBAL.APPLICATION_DATE THEN
      L_LIQ_YN         := FALSE;
      L_PCENDDATE      := L_INT_START_DATE;
      PKG_IS_BROKEN_TD := FALSE;
    ELSE
    
      L_PCENDDATE := GREATEST(GLOBAL.APPLICATION_DATE - 1,
                              NVL(L_PCENDDATE, L_INT_START_DATE));
    
      L_LIQ_YN := TRUE;
    END IF;
  
    IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH', P_BRN) THEN
      DBG('l_pcenddate will be changed here: Intraday accrual posted entries for today,enddate should not include today');
      DBG('l_pcenddate~global.application_date' || L_PCENDDATE || '~' ||
          GLOBAL.APPLICATION_DATE);
      IF L_PCENDDATE >= GLOBAL.APPLICATION_DATE THEN
        L_PCENDDATE := GLOBAL.APPLICATION_DATE - 1;
      END IF;
    END IF;
  
    DBG('L_PCENDDATE ****' || L_PCENDDATE);
    DBG('l_ac_open_date ****' || L_AC_OPEN_DATE);
    L_AC_OPEN_DATE := L_INT_START_DATE;
    DBG('l_int_start_date ****' || L_INT_START_DATE);
    G_INT_START_DATE := L_INT_START_DATE;
  
    IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_BRN,
                                               P_ACC,
                                               L_ERR_CODE,
                                               L_ERR_PARAM) THEN
      DBG('maint Resolution for acc gave error ' || L_ERR_CODE || '~' ||
          L_ERR_PARAM);
    END IF;
  
    DBG('after  icpks_ude.pr_make_ude_row ');
  
    IF NOT FN_FIND_LIQD_AMT(P_BRN,
                            P_ACC,
                            L_PRODUCT_CODE,
                            L_AMT_LIQD_TILLDATE,
                            PKG_TAX_LIQD_TILLDATE,
                            P_ERR_CODE) THEN
    
      DBG('failed in liqd amount and tax calculation -->' || P_ERR_CODE);
    
      RETURN;
    
    END IF;
  
    DBG('Printing l_amt_liqd_tilldated');
    PR_PRINT_INT(L_AMT_LIQD_TILLDATE);
    DBG('Printing pkg_tax_liqd_tilldate');
    PR_PRINT_INT(PKG_TAX_LIQD_TILLDATE);
  
    IF L_LIQ_YN = TRUE THEN
      DBG('Start accounting');
    
      IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_BRN,
                                         'ZIRD',
                                         GLOBAL.APPLICATION_DATE,
                                         L_SERIAL_NO,
                                         P_TXN_REF_NO,
                                         L_ERR_CODE) THEN
        DBG('pr_get_ictm_param failed ' || L_ERR_CODE);
        P_ERR_CODE := L_ERR_CODE;
        RAISE EXCEPTION_RATE;
      END IF;
      DBG('Transaction Reference No IS ' || P_TXN_REF_NO);
      DBG('p_txn_ref_no ' || P_TXN_REF_NO);
    
      L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
    
      ICPKS_FCJ_ICDREDMN.PR_GET_REDM_INT_PARAMS(L_INT_PAY_TYPE,
                                                L_OFFSET_ACC);
    
      DBG('l_offset_acc-->' || L_OFFSET_ACC);
      IF L_OFFSET_ACC IS NOT NULL THEN
        L_BOOK_ACCOUNT := L_OFFSET_ACC;
      ELSE
      
        L_BOOK_ACCOUNT := L_REC_ICTM_ACC.BOOK_ACC;
      END IF;
      DBG('l_book_account-->' || L_BOOK_ACCOUNT);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_book_account') := L_BOOK_ACCOUNT;
        L_TB_CLUSTER_DATA('l_ac_open_date') := L_AC_OPEN_DATE;
        STPKS_TD_REDEMPTION_CLUSTER.PR_BROKEN_TD(P_BRN,
                                                 P_ACC,
                                                 P_ERR_CODE,
                                                 P_ERR_PARAM,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
        IF L_TB_CLUSTER_DATA.EXISTS('booking_account') THEN
          L_BOOK_ACCOUNT := L_TB_CLUSTER_DATA('booking_account');
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_ac_open_date') THEN
          L_AC_OPEN_DATE := L_TB_CLUSTER_DATA('l_ac_open_date');
          DBG('inside assumed hook' || L_AC_OPEN_DATE);
        END IF;
      
      END IF;
    
      DBG('l_book_account' || L_BOOK_ACCOUNT);
      IF L_BOOK_ACCOUNT IS NULL THEN
        DBG('failed in select of gls in partial td brokrn' || SQLERRM);
        P_ERR_CODE := 'IC-MU0008';
        RETURN;
      END IF;
    
      BEGIN
        DBG('...l_ac_open_date is' || L_AC_OPEN_DATE);
        DBG('...l_pcenddate is' || L_PCENDDATE);
      
        IF L_LIQ_YN = TRUE AND (NOT PKG_IS_BROKEN_TD) THEN
        
          IF L_PCENDDATE >= L_INT_START_DATE THEN
            ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
            ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
            DBG('Before calling memo acruals..');
            IF NOT FN_DO_MEMO_ACCRUAL(P_BRN,
                                      P_ACC,
                                      L_AC_OPEN_DATE,
                                      L_PCENDDATE,
                                      L_RULE,
                                      L_PRODUCT_CODE,
                                      
                                      TB_G_MEMO_REC,
                                      L_ERR_CODE,
                                      L_ERR_PARAM) THEN
              P_ERR_CODE := 'IC-MU0005';
              DBG('Error in STPKS_TD_REDEMPTION.pr_broken_td (FN_DO_MEMO_ACCRUAL) failed with ' ||
                  SQLERRM);
              RAISE EXCEPTION_RATE;
            END IF;
          
            DBG('Before posting adj entries  for the broken TD');
            IF NOT FN_ACLOOKUP(P_TXN_REF_NO,
                               P_BRN,
                               L_PRODUCT_CODE,
                               L_CCY,
                               P_ACC,
                               L_BOOK_ACCOUNT,
                               L_AMT_LIQD_TILLDATE,
                               TB_G_MEMO_REC,
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
              DBG('Failed in Fn_aclookup for broken td:' || P_ERR_CODE);
              RAISE EXCEPTION_RATE;
            
            END IF;
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 2;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            
              L_TB_CLUSTER_DATA('l_product_code') := L_PRODUCT_CODE;
              L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
              IF PKG_PROCESSING_REM_AMT THEN
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '1';
              ELSE
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '0';
              END IF;
              L_ERR_CODE := NULL;
            
              STPKS_TD_REDEMPTION_CLUSTER.PR_BROKEN_TD(P_BRN,
                                                       P_ACC
                                                       
                                                      ,
                                                       L_ERR_CODE
                                                       
                                                      ,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA);
            
              IF L_ERR_CODE IS NOT NULL THEN
                P_ERR_CODE := L_ERR_CODE;
              
                RAISE EXCEPTION_RATE;
              END IF;
            
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_processing_rem_amt') THEN
                IF L_TB_CLUSTER_DATA('pkg_processing_rem_amt') = '1' THEN
                  PKG_PROCESSING_REM_AMT := TRUE;
                ELSE
                  PKG_PROCESSING_REM_AMT := FALSE;
                END IF;
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
                PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
              END IF;
            
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
          END IF;
        
        ELSE
        
          DBG('Redemption after first liuidation');
          FOR J IN 1 .. 2 LOOP
            IF J = 1 THEN
              G_CALC_FROM := L_AC_OPEN_DATE;
              SELECT MAX(ENT_DT)
                INTO G_CALC_TO
                FROM ICTBS_ENTRIES_HISTORY A
               WHERE A.ACC = P_ACC
                 AND A.BRN = P_BRN
                 AND A.LIQN = 'Y'
                 AND A.ENTRY_PASSED = 'Y';
            
              DBG('g_calc_to when j=1 is : ' || G_CALC_TO);
              IF G_CALC_TO IS NULL THEN
                G_CALC_TO := L_AC_OPEN_DATE - 1;
              
                ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
                ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
              ELSE
                ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := TRUE;
                ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
              
              END IF;
            
              PKG_J             := 1;
              PKG_PENALTY_APPLY := 0;
            ELSE
              ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
              ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
              G_CALC_FROM                     := G_CALC_TO + 1;
            
              G_CALC_TO         := GLOBAL.APPLICATION_DATE - 1;
              PKG_J             := 2;
              PKG_PENALTY_APPLY := 1;
            END IF;
          
            DBG('From Date--->' || G_CALC_FROM);
            DBG('To Date----->' || G_CALC_TO);
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID := 1;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
              STPKS_TD_REDEMPTION_CLUSTER.PR_BROKEN_TD(P_BRN,
                                                       P_ACC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA);
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
                PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
              END IF;
            END IF;
          
            IF J = 1 THEN
            
              IF NOT
                  STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ACC, P_BRN) THEN
                IF L_REC_ICTM_ACC.RD_FLAG <> 'Y' THEN
                  BEGIN
                    DELETE FROM ICTBS_INT_LIQ_DETAILS
                     WHERE BRANCH_CODE = P_BRN
                       AND ACCOUNT_NUMBER = P_ACC;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('FAiled in Deleting ');
                  END;
                END IF;
              END IF;
            
              IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                 NVL(L_LIQ_DAYS, 0) = 0 THEN
                IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
                  L_LAST_DT := G_CALC_FROM;
                ELSE
                  L_LAST_DT := G_CALC_TO;
                END IF;
              ELSE
              
                L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                        12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                             L_LIQ_DAYS - 1;
              
                SELECT LEAST(NVL(MIN(ENT_DT), L_LAST_DT), L_LAST_DT)
                  INTO L_LAST_DT
                  FROM ICTBS_ENTRIES_HISTORY A
                 WHERE A.ACC = P_ACC
                   AND A.BRN = P_BRN
                   AND A.LIQN = 'Y'
                   AND A.PROD = L_PRODUCT_CODE
                   AND A.ENT_DT >= L_INT_START_DATE
                   AND A.ENTRY_PASSED = 'Y';
              
                IF L_LAST_DT > G_CALC_TO THEN
                  L_LAST_DT := G_CALC_TO;
                END IF;
              
              END IF;
              WHILE (L_LAST_DT <= G_CALC_TO) LOOP
                DBG('From Date111--->' || G_CALC_FROM);
                DBG('To Date111----->' || G_CALC_TO);
              
                IF L_LAST_DT = G_CALC_TO AND
                   G_CALC_TO = GLOBAL.APPLICATION_DATE - 1 THEN
                  DBG('this is for redemption on very first day after liquidation');
                  PKG_PENALTY_APPLY := 1;
                END IF;
              
                IF NOT FN_DO_MEMO_ACCRUAL(P_BRN,
                                          P_ACC,
                                          G_CALC_FROM,
                                          L_LAST_DT,
                                          L_RULE,
                                          L_PRODUCT_CODE,
                                          
                                          TB_G_MEMO_REC,
                                          P_ERR_CODE,
                                          P_ERR_PARAM) THEN
                  DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                  P_ERR_CODE := 'IC-MU0008';
                  DBG('ERROR IN STPKS_TD_REDEMPTION.PR_BROKEN_TD---> ' ||
                      SQLERRM);
                  RAISE EXCEPTION_RATE;
                END IF;
              
                SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                  INTO L_ADJ_AMOUNT
                  FROM ICTW_MEMO_BOOKING
                 WHERE BRN = P_BRN
                   AND ACC = P_ACC
                   AND PROD = L_PRODUCT_CODE;
              
                DBG('l_adj_amount----->' || L_ADJ_AMOUNT);
              
                BEGIN
                  SELECT COUNT(1)
                    INTO L_PAYOUT_COUNT
                    FROM ICTM_TDPAYOUT_DETAILS
                   WHERE BRN = P_BRN
                     AND ACC = P_ACC
                     AND PAYOUT_COMPONENT = 'I';
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('No Payout For Interest');
                    L_PAYOUT_COUNT := 0;
                END;
                DBG('l_rec_ictm_Acc.Book_Acc~l_payout_count=' ||
                    L_REC_ICTM_ACC.BOOK_ACC || '~' || L_PAYOUT_COUNT);
              
                IF (L_REC_ICTM_ACC.BOOK_ACC = P_ACC AND L_PAYOUT_COUNT = 0) THEN
                
                  L_TOT_AMOUNT1 := L_TOT_AMOUNT1 + L_ADJ_AMOUNT;
                  DBG('l_tot_amount11----->' || L_TOT_AMOUNT1);
                
                  IF NOT
                      STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ACC,
                                                                  P_BRN) THEN
                  
                    IF L_REC_ICTM_ACC.RD_FLAG <> 'Y' THEN
                    
                      BEGIN
                      
                        INSERT INTO ICTBS_INT_LIQ_DETAILS
                          (ACCOUNT_NUMBER,
                           BRANCH_CODE,
                           FROM_DATE,
                           TO_DATE,
                           LIQ_AMT)
                        VALUES
                          (P_ACC,
                           P_BRN,
                           G_CALC_FROM,
                           L_LAST_DT,
                           L_TOT_AMOUNT1);
                      EXCEPTION
                        WHEN OTHERS THEN
                          DBG('Failed ---->' || SQLERRM);
                      END;
                    END IF;
                  END IF;
                END IF;
              
                IF TB_G_MEMO_REC.COUNT > 0 THEN
                  DBG('Moving into Temp');
                  FOR REC IN TB_G_MEMO_REC.FIRST .. TB_G_MEMO_REC.LAST LOOP
                    PKG_TEMP_MEMO_REC1(PKG_TEMP_MEMO_REC1.COUNT + 1) := TB_G_MEMO_REC(REC);
                  END LOOP;
                END IF;
              
                DBG('Deleting ictw_memo_booking');
                DELETE FROM ICTW_MEMO_BOOKING A
                 WHERE A.BRN = P_BRN
                   AND A.ACC = P_ACC
                   AND A.PROD = L_PRODUCT_CODE;
                TB_G_MEMO_REC.DELETE;
              
                IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
                   NVL(L_LIQ_DAYS, 0) = 0 THEN
                  EXIT;
                END IF;
              
                EXIT WHEN L_LAST_DT >= G_CALC_TO;
                G_CALC_FROM := L_LAST_DT + 1;
                L_LAST_DT1  := L_LAST_DT;
              
                IF L_LIQN_START_ACCOUNT = 'Y' AND
                   L_INT_START_DATE = LAST_DAY(L_INT_START_DATE) THEN
                  L_LAST_DT := ADD_MONTHS(L_LAST_DT + 1,
                                          12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                               L_LIQ_DAYS - 1;
                ELSE
                
                  L_LAST_DT := ADD_MONTHS(L_LAST_DT,
                                          12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                               L_LIQ_DAYS;
                END IF;
                DBG('l_last_dt---->' || L_LAST_DT);
              
                IF L_LAST_DT >= G_CALC_TO THEN
                  L_LAST_DT := G_CALC_TO;
                  DBG('l_last_dt in if2' || L_LAST_DT);
                END IF;
              
              END LOOP;
              IF PKG_TEMP_MEMO_REC1.COUNT > 0 THEN
                FOR REC IN PKG_TEMP_MEMO_REC1.FIRST .. PKG_TEMP_MEMO_REC1.LAST LOOP
                  DBG('pkg_temp_memo_rec1(rec).brn--->' || PKG_TEMP_MEMO_REC1(REC).BRN);
                  DBG('pkg_temp_memo_rec1(rec).acc--->' || PKG_TEMP_MEMO_REC1(REC).ACC);
                  DBG('pkg_temp_memo_rec1(rec).frm_no--->' || PKG_TEMP_MEMO_REC1(REC)
                      .FRM_NO);
                  DBG('pkg_temp_memo_rec1(rec).is_tax--->' || PKG_TEMP_MEMO_REC1(REC)
                      .IS_TAX);
                  DBG('pkg_temp_memo_rec1(rec).drcr_ind--->' || PKG_TEMP_MEMO_REC1(REC)
                      .DRCR_IND);
                  DBG('pkg_temp_memo_rec1(rec).amt--->' || PKG_TEMP_MEMO_REC1(REC).AMT);
                END LOOP;
              END IF;
              IF PKG_TEMP_MEMO_REC1.COUNT > 0 THEN
                DBG('Making as 4');
                TB_G_MEMO_REC.DELETE;
              
                FOR REC IN PKG_TEMP_MEMO_REC1.FIRST .. PKG_TEMP_MEMO_REC1.LAST LOOP
                  L_TMP_FRM_NO := PKG_TEMP_MEMO_REC1(REC).FRM_NO;
                  IF NOT TB_G_MEMO_REC.EXISTS(L_TMP_FRM_NO) THEN
                    TB_G_MEMO_REC(L_TMP_FRM_NO) := PKG_TEMP_MEMO_REC1(REC);
                  ELSE
                    TB_G_MEMO_REC(L_TMP_FRM_NO).AMT := TB_G_MEMO_REC(L_TMP_FRM_NO)
                                                       .AMT + PKG_TEMP_MEMO_REC1(REC).AMT;
                  
                  END IF;
                END LOOP;
              
              END IF;
            
            ELSE
            
              DBG('Here j is 2');
              DELETE FROM ICTW_MEMO_BOOKING A
               WHERE A.BRN = P_BRN
                 AND A.ACC = P_ACC
                 AND A.PROD = L_PRODUCT_CODE;
            
              IF NOT FN_DO_MEMO_ACCRUAL(P_BRN,
                                        P_ACC,
                                        G_CALC_FROM,
                                        G_CALC_TO,
                                        L_RULE,
                                        L_PRODUCT_CODE,
                                        
                                        TB_G_MEMO_REC,
                                        P_ERR_CODE,
                                        P_ERR_PARAM) THEN
                DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
                P_ERR_CODE := 'IC-MU0008';
                DBG('ERROR IN STPKS_TD_REDEMPTION.PR_BROKEN_TD---> ' ||
                    SQLERRM);
                RAISE EXCEPTION_RATE;
              END IF;
              SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
                INTO L_ADJ_AMOUNT
                FROM ICTW_MEMO_BOOKING
               WHERE BRN = P_BRN
                 AND ACC = P_ACC
                 AND PROD = L_PRODUCT_CODE;
            
              DBG('l_adj_amount22----->' || L_ADJ_AMOUNT);
              L_TOT_AMOUNT1 := L_TOT_AMOUNT1 - L_ADJ_AMOUNT;
              DBG('l_tot_amount55----->' || L_TOT_AMOUNT1);
            
            END IF;
          
            DBG('Before posting adj entries  for the broken TD1..');
            IF NOT FN_ACLOOKUP(P_TXN_REF_NO,
                               P_BRN,
                               L_PRODUCT_CODE,
                               L_CCY,
                               P_ACC,
                               L_BOOK_ACCOUNT,
                               L_AMT_LIQD_TILLDATE,
                               TB_G_MEMO_REC,
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
              DBG('Failed in Fn_aclookup for broken td:' || P_ERR_CODE);
              RAISE EXCEPTION_RATE;
            
            END IF;
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 4;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            
              L_TB_CLUSTER_DATA('l_product_code') := L_PRODUCT_CODE;
              L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
              L_TB_CLUSTER_DATA('j') := J;
              IF PKG_PROCESSING_REM_AMT THEN
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '1';
              ELSE
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '0';
              END IF;
              L_ERR_CODE := NULL;
              STPKS_TD_REDEMPTION_CLUSTER.PR_BROKEN_TD(P_BRN,
                                                       P_ACC
                                                       
                                                      ,
                                                       L_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA);
            
              IF L_ERR_CODE IS NOT NULL THEN
                P_ERR_CODE := L_ERR_CODE;
                RAISE EXCEPTION_RATE;
              END IF;
            
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_processing_rem_amt') THEN
                IF L_TB_CLUSTER_DATA('pkg_processing_rem_amt') = '1' THEN
                  PKG_PROCESSING_REM_AMT := TRUE;
                ELSE
                  PKG_PROCESSING_REM_AMT := FALSE;
                END IF;
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
                PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
              END IF;
            
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            DELETE FROM ICTW_MEMO_BOOKING A
             WHERE A.BRN = P_BRN
               AND A.ACC = P_ACC
               AND A.PROD = L_PRODUCT_CODE;
            DBG('Flushing Memo accrulas:' || SQL%ROWCOUNT);
            DBG('Coming out of the loop');
          END LOOP;
        
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
        
          ICPKSS_UTIL.DBG(SQLERRM);
          RAISE;
      END;
    
    END IF;
  
    UPDATE ICTB_ACC_PR A
       SET NEXT_EVENT_DT = GLOBAL.APPLICATION_DATE
     WHERE BRN = P_BRN
       AND ACC = P_ACC;
  
    G_BROKEN_AMOUNT := L_AVG_BAL;
    G_TENOR         := L_NEWTENOR;
    DBG('g_broken_amount b4 fn_insert_td_details' || G_BROKEN_AMOUNT);
    DBG('g_tenor b4 fn_insert_td_details' || G_TENOR);
  
    G_BROKEN_AMOUNT_INIT := L_AVG_BAL;
    DBG('g_broken_amount b4 fn_insert_td_details' || G_BROKEN_AMOUNT_INIT);
  
    IF NOT FN_INSERT_TD_DETAILS(P_BRN, P_ACC, L_CCY, L_ACCOUNT_CLASS) THEN
      DBG('Failed in stpks_profit_pool.pr_broken_td - FN_INSERT_TD_DETAILS error' ||
          SQLERRM);
      P_ERR_CODE := 'IC-MU0005';
    END IF;
  
    DBG('Updating accrued_dr/cr to 0');
  
    UPDATE STTMS_CUST_ACCOUNT
       SET ACY_ACCRUED_DR_IC = 0, ACY_ACCRUED_CR_IC = 0
     WHERE CUST_AC_NO = P_ACC
       AND BRANCH_CODE = P_BRN;
  
    DELETE FROM ICTW_MEMO_BOOKING A
     WHERE A.BRN = P_BRN
       AND A.ACC = P_ACC
       AND A.PROD = L_PRODUCT_CODE;
    DBG('Flushing Memo accrulas:' || SQL%ROWCOUNT);
  
    DBG('Setting all amounts to zero in ictb_entries');
    UPDATE ICTBS_ENTRIES
       SET AMT           = 0,
           ACCRUED_AMT   = 0,
           AMT_TO_ACCRUE = 0,
           CUR_RUN_ACCR  = 0,
           DAILY_AMT     = 0,
           ACQUIRED_AMT  = 0,
           ACQUIRED_ADJ  = 0
     WHERE BRN = P_BRN
       AND ACC = P_ACC
       AND PROD = L_PRODUCT_CODE;
  
    DBG('Coming out of stpks_td_redemption.pr_broken_td..');
  EXCEPTION
    WHEN EXCEPTION_RATE THEN
      DBG('failed in pr_broken_td for rate' || SQLERRM);
      RETURN;
    WHEN OTHERS THEN
      DBG('failed in pr_broken_td ' || SQLERRM);
      RETURN;
  END PR_BROKEN_TD;

  FUNCTION FN_BROKEN_PARTIAL_TD(P_BRN       IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_ACC       IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                P_ERR_CODE  IN OUT VARCHAR2,
                                P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_CCY           STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ACCOUNT_CLASS STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_POOL_CODE     STTMS_ACCOUNT_CLASS.POOL_CODE%TYPE;
  
    L_PROFIT_SHARING STTMS_ACCOUNT_CLASS.PROFIT_SHARING%TYPE;
    L_PRE_REDEMPTION STTMS_ACCOUNT_CLASS.PRE_REDEMPTION%TYPE;
    L_PRODUCT_CODE   ICTM_PR_INT.PRODUCT_CODE%TYPE;
    L_LIQ_DAYS       ICTM_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS     ICTM_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YEARS      ICTM_PR_INT.LIQN_YEARS%TYPE;
    L_RULE           ICTM_PR_INT.RULE%TYPE;
    L_NEWTENOR       NUMBER;
    L_ORIGINALTENOR  NUMBER;
    L_AC_OPEN_DATE   DATE;
    L_AVG_BAL        NUMBER;
    L_PPO            ICTB_PROFIT_DISTRIBUTION.PPO%TYPE;
  
    L_BROKEN_ACCR      NUMBER;
    L_ERR_CODE         VARCHAR2(255);
    L_ERR_PARAM        VARCHAR2(255);
    L_PCSTARTDATE      DATE;
    L_PCENDDATE        DATE;
    L_TD_AMOUNT        NUMBER;
    L_SERIAL_NO        VARCHAR2(15);
    P_TXN_REF_NO       VARCHAR2(16);
    TB_ACCHANDOFF      ACPKSS.TBL_ACHOFF;
    L_REDEM_AMOUNT     ICTMS_TD_DETAILS.REDEM_AMT%TYPE;
    L_REMAIN_TD_AMOUNT ICTMS_TD_DETAILS.TD_AMOUNT%TYPE := 0;
    L_CALC_END_DATE    DATE;
    L_TXN_CODE         VARCHAR2(3) := NULL;
    L_PROCESS          VARCHAR2(20);
    G_CALC_FROM        DATE;
    G_CALC_TO          DATE;
    L_EXPENSE_GL       CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_PAYABLE_GL       CSTMS_PRODUCT_ACCROLE.ACCOUNT_HEAD%TYPE;
    L_BOOK_ACCOUNT     ICTMS_ACC.BOOK_ACC%TYPE;
    L_DIFF_AMT         NUMBER(22, 7);
    L_ACCR_AMOUNT      ICTW_MEMO_BOOKING.AMT%TYPE;
  
    L_TEMP_ORGTNR          NUMBER;
    L_AMT_LIQD_TILLDATE    DBMS_SQL.NUMBER_TABLE;
    L_DIFF_ACCR_AMT        NUMBER(22, 7);
    L_ACC_FOR_REDEM_AMOUNT ICTB_REDEMPTION_DETAIL.ACCR_FOR_REDEM_AMT%TYPE;
  
    L_LOOKUP ACPKS.TBL_LOOKUP;
    L_FRM_NO NUMBER;
  
    L_CALC_TO DATE;
  
    L_TOT_AMOUNT1 NUMBER := 0;
    L_TOT_AMOUNT2 NUMBER := 0;
    L_TOT_AMOUNT3 NUMBER := 0;
    L_ADJ_AMOUNT  NUMBER := 0;
    L_LAST_DT     DATE;
    L_LAST_DT1    DATE;
    L_AMT1        NUMBER := 0;
    L_AMT2        NUMBER := 0;
    L_AMT3        NUMBER := 0;
    L_RED_BAL     ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_RED_BAL1    ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_RED_BAL2    ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_RED_BAL3    ICTMS_TD_DETAILS.REDEM_AMT%TYPE := 0;
    L_INT_RATE    ICTM_ACC.INTEREST_RATE%TYPE;
    L_MAT_AMT     ICTM_ACC.MATURITY_AMOUNT%TYPE;
  
    L_PAYMENT_METHOD ICTMS_PR_INT.PAYMENT_METHOD%TYPE;
  
    REC                       BINARY_INTEGER;
    L_INT_RATE_OPTION_REDAMT  STTM_ACCOUNT_CLASS.INT_RATE_OPTION_REDAMT%TYPE;
    L_INT_RATE_OPTION_REMAMT  STTM_ACCOUNT_CLASS.INT_RATE_OPTION_REMAMT%TYPE;
    L_NONRATECHRT_REDEM_LIQDT BOOLEAN := FALSE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_LIQN_START_ACC ICTM_PR_INT.LIQN_START_ACCOUNT%TYPE;
  
    L_OFFSET_ACC       ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;
    L_REDM_INT_PAYOUT  ICTM_ACC.REDM_INT_PAYOUT%TYPE;
    L_REDM_PAYOUT_COMP ICTM_TDREDMPAYOUT_DETAILS.REDM_PAYOUT_COMP%TYPE;
  
    L_REC_ICTM_ACC ICTM_ACC%ROWTYPE;
    L_PAYOUT_COUNT NUMBER := 0;
  
  BEGIN
  
    DBG('Entered PR_BROKEN_PARTIAL_TD FOR ACCOUNT*** ' || P_ACC);
  
    SELECT B.CCY,
           C.AC_CLASS_TYPE,
           C.ACCOUNT_CLASS,
           D.PRODUCT_CODE,
           D.LIQN_DAYS,
           D.LIQN_MONTHS,
           D.LIQN_YEARS,
           D.RULE,
           TRUNC(NVL((GLOBAL.APPLICATION_DATE - E.INT_START_DATE), 1)) "NEWTENOR",
           TRUNC(NVL((E.MATURITY_DATE - E.INT_START_DATE), 1)) "ORGINALTENOR",
           
           E.INT_START_DATE,
           
           PAYMENT_METHOD,
           D.LIQN_START_ACCOUNT
      INTO L_CCY,
           L_AC_CLASS_TYPE,
           L_ACCOUNT_CLASS,
           L_PRODUCT_CODE,
           L_LIQ_DAYS,
           L_LIQ_MONTHS,
           L_LIQ_YEARS,
           L_RULE,
           L_NEWTENOR,
           L_ORIGINALTENOR,
           L_AC_OPEN_DATE,
           L_PAYMENT_METHOD,
           L_LIQN_START_ACC
      FROM STTMS_CUST_ACCOUNT  B,
           STTMS_ACCOUNT_CLASS C,
           ICTM_PR_INT         D,
           ICTMS_ACC           E,
           ICTM_PR_INT_ACLASS  F,
           ICTBS_ACC_PR        G
     WHERE B.ACCOUNT_CLASS = C.ACCOUNT_CLASS
       AND B.BRANCH_CODE = E.BRN
       AND C.AC_CLASS_TYPE IN ('Y')
       AND B.CUST_AC_NO = E.ACC
       AND B.RECORD_STAT = 'O'
       AND B.AUTH_STAT = 'A'
       AND C.ACCOUNT_CLASS = F.ACLASS
          
       AND G.ACC = E.ACC
       AND G.BRN = E.BRN
       AND G.PROD = D.PRODUCT_CODE
       AND G.DEPOSIT = 'Y'
          
       AND F.PRODUCT_CODE = D.PRODUCT_CODE
       AND F.RECORD_STAT = 'N'
       AND B.CCY = F.CCY
       AND (EXISTS (SELECT X.ACC
                      FROM ICTM_ACC_PR X
                     WHERE ACC = B.CUST_AC_NO
                       AND BRN = B.BRANCH_CODE
                       AND X.WAIVE = 'N') OR NOT EXISTS
            (SELECT X.ACC
               FROM ICTM_ACC_PR X
              WHERE ACC = B.CUST_AC_NO
                AND BRN = B.BRANCH_CODE))
       AND B.CUST_AC_NO = P_ACC
       AND B.BRANCH_CODE = P_BRN;
  
    L_PPO := L_LIQ_DAYS || 'D' || L_LIQ_MONTHS || 'M' || L_LIQ_YEARS || 'Y';
  
    DBG('...l_ppo is' || L_PPO);
  
    BEGIN
      SELECT A.TD_RATECHART_ALLOW
        INTO PKG_RATE_CHART
        FROM STTM_ACCOUNT_CLASS A, STTM_CUST_ACCOUNT B
       WHERE A.ACCOUNT_CLASS = B.ACCOUNT_CLASS
         AND B.BRANCH_CODE = P_BRN
         AND B.CUST_AC_NO = P_ACC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        PKG_RATE_CHART := 'N';
    END;
    DBG('pkg_rate_chart flag :' || PKG_RATE_CHART);
  
    BEGIN
      SELECT (TD_AMOUNT - NVL(REDEM_AMT, 0))
        INTO L_TD_AMOUNT
        FROM ICTM_TD_DETAILS
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND CCY = L_CCY;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_CODE := 'IC-MU0008';
        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
            SQLERRM);
        RETURN FALSE;
      
    END;
    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
    DBG('l_td_amount---> ' || L_TD_AMOUNT);
    G_CCY := L_CCY;
    ICPKSS_MAINT.PR_GET_REDEM_AMT(L_REDEM_AMOUNT);
  
    DBG('l_redemeed_amount---> ' || L_REDEM_AMOUNT);
  
    L_REMAIN_TD_AMOUNT := L_TD_AMOUNT - L_REDEM_AMOUNT;
  
    DBG('l_remain_td_amount ' || L_REMAIN_TD_AMOUNT);
    L_RED_BAL1 := L_REDEM_AMOUNT;
    L_RED_BAL2 := L_REMAIN_TD_AMOUNT;
    L_RED_BAL3 := L_REDEM_AMOUNT;
  
    L_TEMP_ORGTNR := L_ORIGINALTENOR;
  
    FOR J IN 1 .. 4 LOOP
    
      SELECT DECODE(J,
                    1,
                    'REDEM AMOUNT',
                    2,
                    'REMAINING AMOUNT',
                    3,
                    'REDEM AMOUNT',
                    4,
                    'REMAINING AMOUNT')
        INTO L_PROCESS
        FROM DUAL;
    
      DBG('Processing j----->' || J);
      DBG('Processing------->' || L_PROCESS);
    
      SELECT DECODE(J,
                    1,
                    L_REDEM_AMOUNT,
                    2,
                    L_REMAIN_TD_AMOUNT,
                    3,
                    L_REDEM_AMOUNT,
                    4,
                    L_REMAIN_TD_AMOUNT)
        INTO G_BROKEN_AMOUNT
        FROM DUAL;
    
      IF J IN (1, 3) THEN
        DBG('Its a Redemption amount, so setting redemption flag as true');
        ICPKS_FCJ_ICDREDMN.G_REDM_FLAG := TRUE;
        IF J = 1 THEN
          ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := TRUE;
          ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
        ELSIF J = 3 THEN
          ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
          ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
        END IF;
      ELSE
        DBG('Its a Remaining amount, so setting redemption flag as false');
        ICPKS_FCJ_ICDREDMN.G_REDM_FLAG  := FALSE;
        ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
        ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
      END IF;
    
      DBG('amount---->' || G_BROKEN_AMOUNT);
    
      G_BROKEN_AMOUNT_INIT := G_BROKEN_AMOUNT;
      DBG('DEP_AMT_INIT ---->' || G_BROKEN_AMOUNT_INIT);
    
      SELECT DECODE(J,
                    1,
                    L_NEWTENOR,
                    2,
                    L_TEMP_ORGTNR,
                    3,
                    L_NEWTENOR,
                    4,
                    L_TEMP_ORGTNR)
        INTO G_TENOR
        FROM DUAL;
    
      DBG('tenor----->' || G_TENOR);
    
      IF J IN (1, 2) THEN
        G_CALC_FROM := L_AC_OPEN_DATE;
        L_LAST_DT   := G_CALC_FROM;
      
        BEGIN
          SELECT MAX(ENT_DT)
            INTO G_CALC_TO
            FROM ICTBS_ENTRIES_HISTORY A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.LIQN = 'Y'
             AND A.ENTRY_PASSED = 'Y';
        END;
      
        IF G_CALC_TO IS NULL THEN
          G_CALC_TO := L_AC_OPEN_DATE - 1;
        END IF;
      
        PKG_PENALTY_APPLY := 0;
      
        L_CALC_TO := G_CALC_TO;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('j') := J;
          L_TB_CLUSTER_DATA('pkg_rate_chart') := PKG_RATE_CHART;
          IF NOT
              STPKS_TD_REDEMPTION_CLUSTER.FN_BROKEN_PARTIAL_TD(P_BRN,
                                                               P_ACC,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
            P_ERR_CODE := 'IC-MU0008';
            DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
        
          IF L_TB_CLUSTER_DATA.EXISTS('pkg_rate_chart') THEN
            PKG_RATE_CHART := L_TB_CLUSTER_DATA('pkg_rate_chart');
          END IF;
        
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF PKG_RATE_CHART = 'N' THEN
            G_CALC_TO := L_AC_OPEN_DATE - 1;
            CONTINUE;
          END IF;
        
        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;
      
      ELSE
      
        G_CALC_FROM := L_CALC_TO + 1;
      
        G_CALC_TO         := GLOBAL.APPLICATION_DATE - 1;
        PKG_PENALTY_APPLY := 1;
      
        IF PKG_RATE_CHART = 'N' AND L_CALC_TO = G_CALC_TO THEN
          DBG('this is for redemption on very first day after liquidation for non rate chart TDs : Issue penalty not getting calculated');
          L_NONRATECHRT_REDEM_LIQDT := TRUE;
          G_CALC_FROM               := L_CALC_TO;
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID := 1;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
          L_TB_CLUSTER_DATA('j') := J;
          IF NOT
              STPKS_TD_REDEMPTION_CLUSTER.FN_BROKEN_PARTIAL_TD(P_BRN,
                                                               P_ACC,
                                                               P_ERR_CODE,
                                                               P_ERR_PARAM,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
            P_ERR_CODE := 'IC-MU0008';
            DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                SQLERRM);
            RETURN FALSE;
          ELSE
            IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
              PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
            END IF;
          END IF;
        END IF;
      END IF;
    
      DBG('From Date--->' || G_CALC_FROM);
      DBG('To Date----->' || G_CALC_TO);
    
      IF J IN (2, 4) THEN
        PKG_PROCESSING_REM_AMT := TRUE;
      ELSE
        PKG_PROCESSING_REM_AMT := FALSE;
      END IF;
    
      IF NOT FN_APPLY_RATE(P_BRN,
                           P_ACC,
                           L_AC_CLASS_TYPE,
                           L_ACCOUNT_CLASS,
                           L_PRODUCT_CODE,
                           L_CCY,
                           G_BROKEN_AMOUNT,
                           G_TENOR,
                           L_ORIGINALTENOR,
                           L_AC_OPEN_DATE,
                           'P'
                           
                           ) THEN
        P_ERR_CODE := 'IC-MU0008';
        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
            SQLERRM);
        RETURN FALSE;
      
      END IF;
    
      DBG('goin for resolution ');
      IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_BRN,
                                                 P_ACC,
                                                 L_ERR_CODE,
                                                 L_ERR_PARAM) THEN
        DBG('maint Resolution for acc gave error ' || L_ERR_CODE || '~' ||
            L_ERR_PARAM);
        P_ERR_CODE := 'IC-MU0008';
        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    
      IF J IN (1, 2, 3) THEN
        SAVEPOINT MAT_CL1;
        IF NOT STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ACC, P_BRN) THEN
          BEGIN
            DELETE FROM ICTBS_INT_LIQ_DETAILS
             WHERE BRANCH_CODE = P_BRN
               AND ACCOUNT_NUMBER = P_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAiled in Deleting ');
          END;
        END IF;
        DBG('Cong here11');
      
        IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
           NVL(L_LIQ_DAYS, 0) = 0 THEN
          IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
            L_LAST_DT := G_CALC_FROM;
          ELSE
            L_LAST_DT := G_CALC_TO;
          END IF;
        ELSE
          L_LAST_DT := ADD_MONTHS(G_CALC_FROM,
                                  12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                       L_LIQ_DAYS - 1;
        
          IF J IN (1, 2) THEN
            SELECT LEAST(NVL(MIN(ENT_DT), L_LAST_DT), L_LAST_DT)
              INTO L_LAST_DT
              FROM ICTBS_ENTRIES_HISTORY A
             WHERE A.ACC = P_ACC
               AND A.BRN = P_BRN
               AND A.LIQN = 'Y'
               AND A.PROD = L_PRODUCT_CODE
               AND A.ENT_DT >= L_AC_OPEN_DATE
               AND A.ENTRY_PASSED = 'Y';
          END IF;
        
        END IF;
        DBG('b4 while  l_last_dt-->' || L_LAST_DT);
        DBG('b4 while  g_calc_to-->' || G_CALC_TO);
        IF L_LAST_DT > G_CALC_TO THEN
          L_LAST_DT := G_CALC_TO;
          DBG('l_last_dt in if' || L_LAST_DT);
        END IF;
        WHILE (L_LAST_DT <= G_CALC_TO) LOOP
        
          IF L_LAST_DT = G_CALC_TO AND
             G_CALC_TO = GLOBAL.APPLICATION_DATE - 1 AND J = 1 THEN
            DBG('this is for redemption on very first day after liquidation');
            PKG_PENALTY_APPLY := 1;
          END IF;
        
          IF NOT FN_DO_MEMO_ACCRUAL(P_BRN,
                                    P_ACC,
                                    G_CALC_FROM,
                                    L_LAST_DT,
                                    L_RULE,
                                    L_PRODUCT_CODE,
                                    
                                    TB_G_MEMO_REC,
                                    P_ERR_CODE,
                                    P_ERR_PARAM) THEN
            DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
            P_ERR_CODE := 'IC-MU0008';
            DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                SQLERRM);
            RETURN FALSE;
          END IF;
          DBG('Cong here22');
          SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
            INTO L_ADJ_AMOUNT
            FROM ICTW_MEMO_BOOKING
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND PROD = L_PRODUCT_CODE;
        
          BEGIN
            SELECT COUNT(1)
              INTO L_PAYOUT_COUNT
              FROM ICTM_TDPAYOUT_DETAILS
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND PAYOUT_COMPONENT = 'I';
          EXCEPTION
            WHEN OTHERS THEN
              DBG('No Payout For Interest');
              L_PAYOUT_COUNT := 0;
          END;
          DBG('l_rec_ictm_Acc.Book_Acc~l_payout_count=' ||
              L_REC_ICTM_ACC.BOOK_ACC || '~' || L_PAYOUT_COUNT);
        
          IF (L_REC_ICTM_ACC.BOOK_ACC = P_ACC AND L_PAYOUT_COUNT = 0) THEN
          
            IF J = 1 THEN
              DBG('l_adj_amount1----->' || L_ADJ_AMOUNT);
              L_TOT_AMOUNT1 := L_TOT_AMOUNT1 + L_ADJ_AMOUNT;
              DBG('l_tot_amount11----->' || L_TOT_AMOUNT1);
              L_RED_BAL1 := NVL(L_RED_BAL1, 0) + L_ADJ_AMOUNT;
              DBG('l_red_bal1----->' || L_RED_BAL1);
              L_RED_BAL := L_RED_BAL1;
            ELSIF J = 2 THEN
              DBG('l_adj_amount2----->' || L_ADJ_AMOUNT);
              L_TOT_AMOUNT2 := L_TOT_AMOUNT2 + L_ADJ_AMOUNT;
              DBG('l_tot_amount2----->' || L_TOT_AMOUNT2);
              L_RED_BAL2 := NVL(L_RED_BAL2, 0) + L_ADJ_AMOUNT;
              DBG('l_red_bal2----->' || L_RED_BAL2);
              L_RED_BAL := L_RED_BAL2;
            ELSE
              DBG('l_adj_amount3----->' || L_ADJ_AMOUNT);
              L_TOT_AMOUNT3 := L_TOT_AMOUNT3 + L_ADJ_AMOUNT;
              DBG('l_tot_amount3----->' || L_TOT_AMOUNT3);
              L_RED_BAL3 := NVL(L_RED_BAL3, 0) + L_ADJ_AMOUNT;
              DBG('l_red_bal3----->' || L_RED_BAL3);
              L_RED_BAL := L_RED_BAL3;
            END IF;
            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_RED_BAL;
            IF NOT STPKS_STDTDTOP_UTILS.FN_IS_TOPUP_APPLICABLE(P_ACC, P_BRN) THEN
              BEGIN
                DBG('Inserting into ICTBS_INT_LIQ_DETAILS');
                INSERT INTO ICTBS_INT_LIQ_DETAILS
                  (ACCOUNT_NUMBER,
                   BRANCH_CODE,
                   FROM_DATE,
                   TO_DATE,
                   LIQ_AMT)
                VALUES
                  (P_ACC, P_BRN, G_CALC_FROM, L_LAST_DT, L_RED_BAL);
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed ---->' || SQLERRM);
              END;
            END IF;
          END IF;
        
          IF TB_G_MEMO_REC.COUNT > 0 THEN
            DBG('Moving into Temp');
            FOR REC IN TB_G_MEMO_REC.FIRST .. TB_G_MEMO_REC.LAST LOOP
              DBG('tb_g_memo_rec(rec).amt--->' || TB_G_MEMO_REC(REC).AMT);
              DBG('tb_g_memo_rec(rec).drcr_ind--->' || TB_G_MEMO_REC(REC)
                  .DRCR_IND);
              DBG('tb_g_memo_rec(rec).istax--->' || TB_G_MEMO_REC(REC)
                  .IS_TAX);
              IF NOT L_NONRATECHRT_REDEM_LIQDT THEN
                PKG_TEMP_MEMO_REC1(PKG_TEMP_MEMO_REC1.COUNT + 1) := TB_G_MEMO_REC(REC);
              
              ELSE
                IF L_NONRATECHRT_REDEM_LIQDT AND
                   (TB_G_MEMO_REC(REC)
                   .DRCR_IND = 'D' AND TB_G_MEMO_REC(REC).IS_TAX = 'N') THEN
                  PKG_TEMP_MEMO_REC1(PKG_TEMP_MEMO_REC1.COUNT + 1) := TB_G_MEMO_REC(REC);
                END IF;
              END IF;
            
            END LOOP;
          END IF;
        
          DBG('Deleting ictw_memo_booking');
          DELETE FROM ICTW_MEMO_BOOKING A
           WHERE A.BRN = P_BRN
             AND A.ACC = P_ACC
             AND A.PROD = L_PRODUCT_CODE;
          TB_G_MEMO_REC.DELETE;
        
          IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
             NVL(L_LIQ_DAYS, 0) = 0 THEN
            EXIT;
          END IF;
        
          EXIT WHEN L_LAST_DT >= G_CALC_TO;
          G_CALC_FROM := L_LAST_DT + 1;
          L_LAST_DT1  := L_LAST_DT;
        
          IF L_LIQN_START_ACC = 'Y' AND
             L_AC_OPEN_DATE = LAST_DAY(L_AC_OPEN_DATE) THEN
            L_LAST_DT := ADD_MONTHS(L_LAST_DT + 1,
                                    12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                         L_LIQ_DAYS - 1;
          ELSE
          
            L_LAST_DT := ADD_MONTHS(L_LAST_DT,
                                    12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                         L_LIQ_DAYS;
          END IF;
          DBG('l_last_dt---->' || L_LAST_DT);
        
          IF L_LAST_DT >= G_CALC_TO THEN
            L_LAST_DT := G_CALC_TO;
            DBG('l_last_dt in if2' || L_LAST_DT);
          END IF;
        
        END LOOP;
      
        IF PKG_TEMP_MEMO_REC1.COUNT > 0 THEN
          DBG('Making as 4 OR 6');
          TB_G_MEMO_REC.DELETE;
          FOR REC IN PKG_TEMP_MEMO_REC1.FIRST .. PKG_TEMP_MEMO_REC1.LAST LOOP
          
            IF NOT TB_G_MEMO_REC.EXISTS(PKG_TEMP_MEMO_REC1(REC).FRM_NO) THEN
              TB_G_MEMO_REC(PKG_TEMP_MEMO_REC1(REC).FRM_NO) := PKG_TEMP_MEMO_REC1(REC);
            ELSE
              TB_G_MEMO_REC(PKG_TEMP_MEMO_REC1(REC).FRM_NO).AMT := NVL(TB_G_MEMO_REC(PKG_TEMP_MEMO_REC1(REC).FRM_NO).AMT,
                                                                       0) + PKG_TEMP_MEMO_REC1(REC).AMT;
            END IF;
          
          END LOOP;
        
          REC := TB_G_MEMO_REC.FIRST;
          WHILE TB_G_MEMO_REC.EXISTS(REC)
          
           LOOP
            DBG('Final tb_g_memo_rec(rec).amt--->' || TB_G_MEMO_REC(REC).AMT);
            DBG('Final tb_g_memo_rec(rec).drcr_ind--->' || TB_G_MEMO_REC(REC)
                .DRCR_IND);
            PKG_TEMP_MEMO_REC2(PKG_TEMP_MEMO_REC2.COUNT + 1) := TB_G_MEMO_REC(REC);
            REC := TB_G_MEMO_REC.NEXT(REC);
          END LOOP;
        
        END IF;
        ROLLBACK TO MAT_CL1;
      
        IF J = 1 THEN
          DBG('J=1');
          DBG('pkg_temp_memp_recs count ' || PKG_TEMP_MEMO_REC2.COUNT);
          IF PKG_TEMP_MEMO_REC2.COUNT > 0 THEN
          
            DBG('COUNT > 0');
            FOR X IN 1 .. PKG_TEMP_MEMO_REC2.COUNT LOOP
            
              IF PKG_TEMP_MEMO_REC2(X)
               .DRCR_IND = 'C' AND
                  NVL(PKG_TEMP_MEMO_REC2(X).IS_TAX, 'N') = 'N' THEN
              
                IF PKG_REDEM_AMT_ACCR.EXISTS(PKG_TEMP_MEMO_REC2(X).FRM_NO) THEN
                  DBG('inside the credit interest j=1');
                  PKG_REDEM_AMT_ACCR(PKG_TEMP_MEMO_REC2(X).FRM_NO) := NVL(PKG_REDEM_AMT_ACCR(PKG_TEMP_MEMO_REC2(X)
                                                                                             .FRM_NO),
                                                                          0) + PKG_TEMP_MEMO_REC2(X).AMT;
                  DBG('Pkg_redem_amt_accr(pkg_temp_memo_rec2(x).frm_no)' ||
                      PKG_REDEM_AMT_ACCR(PKG_TEMP_MEMO_REC2(X).FRM_NO));
                  DBG('pkg_temp_memo_rec2(x).amt' || PKG_TEMP_MEMO_REC2(X).AMT);
                ELSE
                  DBG('inside else of  credit interest j=1');
                  PKG_REDEM_AMT_ACCR(PKG_TEMP_MEMO_REC2(X).FRM_NO) := PKG_TEMP_MEMO_REC2(X).AMT;
                END IF;
              
              ELSE
                IF NVL(PKG_TEMP_MEMO_REC2(X).IS_TAX, 'N') = 'Y' THEN
                
                  IF PKG_TAX_ON_REDEM_AMT.EXISTS(PKG_TEMP_MEMO_REC2(X)
                                                 .FRM_NO) THEN
                    PKG_TAX_ON_REDEM_AMT(PKG_TEMP_MEMO_REC2(X).FRM_NO) := NVL(PKG_TAX_ON_REDEM_AMT(PKG_TEMP_MEMO_REC2(X)
                                                                                                   .FRM_NO),
                                                                              0) + PKG_TEMP_MEMO_REC2(X).AMT;
                  ELSE
                    PKG_TAX_ON_REDEM_AMT(PKG_TEMP_MEMO_REC2(X).FRM_NO) := PKG_TEMP_MEMO_REC2(X).AMT;
                  END IF;
                
                ELSIF PKG_TEMP_MEMO_REC2(X)
                 .DRCR_IND = 'D' AND
                       NVL(PKG_TEMP_MEMO_REC2(X).IS_TAX, 'N') = 'N' THEN
                  DBG('For Penalty posting..');
                  PKG_TEMP_MEMO_REC(1) := PKG_TEMP_MEMO_REC2(X);
                
                END IF;
              
              END IF;
            END LOOP;
          END IF;
        
        END IF;
      
        DBG('Printing Pkg_redem_amt_accr');
        PR_PRINT_INT(PKG_REDEM_AMT_ACCR);
        DBG('Printing Pkg_tax_on_redem_amt');
        PR_PRINT_INT(PKG_TAX_ON_REDEM_AMT);
      
        IF J IN (2, 3) THEN
        
          IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_BRN,
                                             'ZIRD',
                                             GLOBAL.APPLICATION_DATE,
                                             L_SERIAL_NO,
                                             P_TXN_REF_NO,
                                             L_ERR_CODE) THEN
            DBG('pr_get_ictm_param failed ' || L_ERR_CODE);
            P_ERR_CODE := L_ERR_CODE;
          END IF;
          DBG('Transaction Reference No ' || P_TXN_REF_NO);
          DBG('p_txn_ref_no ' || P_TXN_REF_NO);
        
          IF ICPKS_FCJ_ICDREDMN.FN_IS_REDM_INT_PAYOUT(P_BRN,
                                                      P_ACC,
                                                      L_OFFSET_ACC) THEN
            DBG('Redemption Interest Payout account-->' || L_OFFSET_ACC);
          ELSE
            L_OFFSET_ACC := NULL;
          END IF;
        
          DBG('l_offset_acc-->' || L_OFFSET_ACC);
          IF L_OFFSET_ACC IS NOT NULL THEN
            L_BOOK_ACCOUNT := L_OFFSET_ACC;
          ELSE
          
            BEGIN
              SELECT BOOK_ACC
                INTO L_BOOK_ACCOUNT
                FROM ICTMS_ACC
               WHERE BRN = P_BRN
                 AND ACC = P_ACC;
            
              DBG('l_book_account' || L_BOOK_ACCOUNT);
            
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('failed in select of gls in partial td brokrn' ||
                    SQLERRM);
                RETURN FALSE;
                P_ERR_CODE := 'IC-MU0008';
            END;
          END IF;
          IF J = 2 THEN
          
            DBG('Inside j=2 for accounting');
          
            IF NOT FN_FIND_LIQD_AMT(P_BRN,
                                    P_ACC,
                                    L_PRODUCT_CODE,
                                    L_AMT_LIQD_TILLDATE,
                                    PKG_TAX_LIQD_TILLDATE,
                                    P_ERR_CODE) THEN
            
              DBG('failed in liqd amount and tax calculation -->' ||
                  P_ERR_CODE);
            
              RETURN FALSE;
            
            END IF;
          
            DBG('Printing l_amt_liqd_tilldate');
            PR_PRINT_INT(L_AMT_LIQD_TILLDATE);
            DBG('Printing pkg_tax_liqd_tilldate');
            PR_PRINT_INT(PKG_TAX_LIQD_TILLDATE);
          
            DBG('Before posting adj rntries  for the remiaining amount ');
            IF NOT FN_ACLOOKUP(P_TXN_REF_NO,
                               P_BRN,
                               L_PRODUCT_CODE,
                               L_CCY,
                               P_ACC,
                               L_BOOK_ACCOUNT,
                               L_AMT_LIQD_TILLDATE,
                               PKG_TEMP_MEMO_REC2,
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
              DBG('Failed in Fn_aclookup:' || P_ERR_CODE);
            
              RETURN FALSE;
            END IF;
          
            DELETE FROM ICTW_MEMO_BOOKING A
             WHERE A.BRN = P_BRN
               AND A.ACC = P_ACC
               AND A.PROD = L_PRODUCT_CODE;
          
            DBG(SQL%ROWCOUNT || 'ROWS DELETED');
          END IF;
        
          IF J = 3 THEN
          
            DBG('Inside j=3 for accounting');
            DBG('pkg_temp_memo_rec2.count:' || PKG_TEMP_MEMO_REC2.COUNT);
            IF NVL(PKG_TEMP_MEMO_REC2.COUNT, 0) = 0 THEN
            
              IF PKG_TEMP_MEMO_REC.COUNT > 0 THEN
                FOR REC IN PKG_TEMP_MEMO_REC.FIRST .. PKG_TEMP_MEMO_REC.LAST LOOP
                  PKG_TEMP_MEMO_REC2(PKG_TEMP_MEMO_REC2.COUNT + 1) := PKG_TEMP_MEMO_REC(REC);
                END LOOP;
              END IF;
            
            END IF;
            DBG('Before posting adj rntries  for the Redemeed Amount');
            PR_PRINT_INT(L_AMT_LIQD_TILLDATE);
            IF NOT FN_ACLOOKUP(P_TXN_REF_NO,
                               P_BRN,
                               L_PRODUCT_CODE,
                               L_CCY,
                               P_ACC,
                               L_BOOK_ACCOUNT,
                               L_AMT_LIQD_TILLDATE,
                               PKG_TEMP_MEMO_REC2,
                               P_ERR_CODE,
                               P_ERR_PARAM) THEN
              DBG('Failed in Fn_aclookup:' || P_ERR_CODE);
            
              RETURN FALSE;
            END IF;
          
            SELECT NVL(SUM(AMT), 0)
              INTO PKG_ACRR_REDEM_AMT
              FROM ICTW_MEMO_BOOKING
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND PROD = L_PRODUCT_CODE
               AND DRCR_IND = 'C';
          
            DBG('l_acc_for_redem_amount  ' ||
                STPKS_TD_REDEMPTION.PKG_ACRR_REDEM_AMT);
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 2;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            
              DBG('l_redem_amount:' || L_REDEM_AMOUNT);
              L_TB_CLUSTER_DATA('p_cr_gl') := L_BOOK_ACCOUNT;
              L_TB_CLUSTER_DATA('l_redem_amount') := L_REDEM_AMOUNT;
              L_TB_CLUSTER_DATA('l_ccy') := L_CCY;
              L_TB_CLUSTER_DATA('p_txn_ref_no') := P_TXN_REF_NO;
            
              L_TB_CLUSTER_DATA('l_product_code') := L_PRODUCT_CODE;
              L_TB_CLUSTER_DATA('pkg_penalty_apply') := PKG_PENALTY_APPLY;
              IF PKG_PROCESSING_REM_AMT THEN
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '1';
              ELSE
                L_TB_CLUSTER_DATA('pkg_processing_rem_amt') := '0';
              END IF;
              L_TB_CLUSTER_DATA('j') := J;
              L_TB_CLUSTER_DATA('pkg_rate_chart') := PKG_RATE_CHART;
            
              IF NOT
                  STPKS_TD_REDEMPTION_CLUSTER.FN_BROKEN_PARTIAL_TD(P_BRN,
                                                                   P_ACC,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAM,
                                                                   L_FN_CALL_ID,
                                                                   L_TB_CLUSTER_DATA) THEN
                DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;
            
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_processing_rem_amt') THEN
                IF L_TB_CLUSTER_DATA('pkg_processing_rem_amt') = '1' THEN
                  PKG_PROCESSING_REM_AMT := TRUE;
                ELSE
                  PKG_PROCESSING_REM_AMT := FALSE;
                END IF;
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_penalty_apply') THEN
                PKG_PENALTY_APPLY := L_TB_CLUSTER_DATA('pkg_penalty_apply');
              END IF;
            
              IF L_TB_CLUSTER_DATA.EXISTS('pkg_rate_chart') THEN
                PKG_RATE_CHART := L_TB_CLUSTER_DATA('pkg_rate_chart');
              END IF;
            
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            DELETE FROM ICTW_MEMO_BOOKING A
             WHERE A.BRN = P_BRN
               AND A.ACC = P_ACC
               AND A.PROD = L_PRODUCT_CODE;
          
            DBG('ROWS DELETED' || SQL%ROWCOUNT);
          
          END IF;
        
        END IF;
      END IF;
      TB_G_MEMO_REC.DELETE;
      PKG_TEMP_MEMO_REC1.DELETE;
      PKG_TEMP_MEMO_REC2.DELETE;
      L_AMT1                    := 0;
      L_AMT2                    := 0;
      L_AMT3                    := 0;
      L_NONRATECHRT_REDEM_LIQDT := FALSE;
    END LOOP;
  
    G_BROKEN_AMOUNT := L_REDEM_AMOUNT;
    G_TENOR         := L_NEWTENOR;
  
    DBG('g_broken_amount--->' || G_BROKEN_AMOUNT);
    DBG('g_tenor--->' || G_TENOR);
  
    G_BROKEN_AMOUNT_INIT := L_REDEM_AMOUNT;
    DBG('g_broken_amount b4 fn_insert_td_details' || G_BROKEN_AMOUNT_INIT);
  
    DBG('calling fn_insert_td_details');
  
    IF NOT FN_INSERT_TD_DETAILS(P_BRN, P_ACC, L_CCY, L_ACCOUNT_CLASS) THEN
      DBG('FAILED IN PR_BROKEN_PARTIAL_TD ' || SQLERRM);
      DBG('FAILED IN PR_BROKEN_PARTIAL_TD ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE := 'IC-TDR011';
    END IF;
  
    UPDATE ICTMS_TD_DETAILS
       SET REDEM_AMT = NVL(REDEM_AMT, 0) + L_REDEM_AMOUNT
     WHERE BRN = P_BRN
       AND ACC = P_ACC;
  
    DBG('Avail Amount in Account--->' || L_REMAIN_TD_AMOUNT);
  
    G_CALC_FROM := L_AC_OPEN_DATE;
    BEGIN
      SELECT MAX(ENT_DT)
        INTO G_CALC_TO
        FROM ICTBS_ENTRIES_HISTORY A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
         AND A.LIQN = 'Y'
         AND A.ENTRY_PASSED = 'Y';
    
      IF G_CALC_TO IS NULL THEN
        G_CALC_TO := L_AC_OPEN_DATE - 1;
      END IF;
      DBG('g_calc_to when j=1 is : ' || G_CALC_TO);
    
    END;
  
    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
       NVL(L_LIQ_DAYS, 0) = 0 THEN
      IF G_CALC_TO = L_AC_OPEN_DATE - 1 THEN
        L_LAST_DT := G_CALC_FROM;
      ELSE
        L_LAST_DT := G_CALC_TO;
      END IF;
    ELSE
    
      L_LAST_DT := ADD_MONTHS(G_CALC_FROM, 12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                   L_LIQ_DAYS - 1;
    END IF;
    DBG('g_calc_from111--->' || G_CALC_FROM);
    DBG('g_calc_to000--->' || G_CALC_TO);
    DBG('l_last_dt--->' || L_LAST_DT);
  
    ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);
  
    WHILE L_LAST_DT <= G_CALC_TO LOOP
    
      IF NOT FN_DO_MEMO_ACCRUAL(P_BRN,
                                P_ACC,
                                G_CALC_FROM,
                                L_LAST_DT,
                                L_RULE,
                                L_PRODUCT_CODE,
                                TB_G_MEMO_REC,
                                P_ERR_CODE,
                                P_ERR_PARAM) THEN
        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
        P_ERR_CODE := 'IC-MU0008';
        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
        INTO L_ADJ_AMOUNT
        FROM ICTW_MEMO_BOOKING
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD = L_PRODUCT_CODE;
    
      G_CALC_FROM := L_LAST_DT + 1;
    
      IF L_LIQN_START_ACC = 'Y' AND
         L_AC_OPEN_DATE = LAST_DAY(L_AC_OPEN_DATE) THEN
        L_LAST_DT := ADD_MONTHS(L_LAST_DT + 1,
                                12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                     L_LIQ_DAYS - 1;
      ELSE
      
        L_LAST_DT := ADD_MONTHS(L_LAST_DT, 12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                     L_LIQ_DAYS;
      END IF;
      DBG('l_last_dt1111----->' || L_LAST_DT);
      DBG('Deleting ictw_memo_booking');
      DELETE FROM ICTW_MEMO_BOOKING A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = L_PRODUCT_CODE;
    
      IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
         NVL(L_LIQ_DAYS, 0) = 0 THEN
        EXIT;
      END IF;
    
    END LOOP;
  
    DBG('l_adj_amount' || L_ADJ_AMOUNT);
  
    BEGIN
      SELECT INTEREST_RATE, MATURITY_AMOUNT
        INTO L_INT_RATE, L_MAT_AMT
        FROM ICTBS_TDREDEMPTION_MASTER
       WHERE ACC_NO = P_ACC
         AND BRANCH_CODE = P_BRN
         AND AUTH_STATUS = 'U';
    EXCEPTION
      WHEN OTHERS THEN
        L_INT_RATE := 0;
        L_MAT_AMT  := 0;
    END;
    DBG('44444444');
  
    UPDATE ICTM_ACC
       SET INTEREST_RATE = L_INT_RATE, MATURITY_AMOUNT = L_MAT_AMT
     WHERE ACC = P_ACC
       AND BRN = P_BRN;
  
    DBG('555555');
    DELETE FROM ICTW_MEMO_BOOKING A
     WHERE A.BRN = P_BRN
       AND A.ACC = P_ACC
       AND A.PROD = L_PRODUCT_CODE;
    DBG(SQL%ROWCOUNT || 'ROWS UPDATED');
  
    STPKS_TD_REDEMPTION.PKG_ACRR_REDEM_AMT := 0;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_TD_REDEMPTION_CLUSTER.FN_BROKEN_PARTIAL_TD(P_BRN,
                                                           P_ACC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA) THEN
        DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_BROKEN_PARTIAL_TD ' || SQLERRM);
      P_ERR_CODE := 'IC-MU0008';
      RETURN FALSE;
  END FN_BROKEN_PARTIAL_TD;

  FUNCTION FN_INSERT_TD_DETAILS(P_BRN       IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_ACC       IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                P_CCY       IN VARCHAR2,
                                P_ACC_CLASS IN VARCHAR2) RETURN BOOLEAN IS
  
    L_END_DATE            DATE;
    L_PCSTARTDATE         DATE;
    L_PCENDDATE           DATE;
    L_UDE_VALUE           ICTM_ACC_UDEVALS.UDE_VALUE%TYPE;
    L_REDEMPTION_TYPE     ICTB_REDEMPTION_DETAIL.REDEMPTION_TYPE%TYPE;
    L_REDEM_FLAG          VARCHAR2(1);
    L_LIQ_DAYS            ICTM_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS          ICTM_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YEARS           ICTM_PR_INT.LIQN_YEARS%TYPE;
    L_PPO                 VARCHAR2(10);
    L_ACC_OPEN_DT         DATE;
    L_CUR_PERIOD_START_DT STTMS_PERIOD_CODES.PC_START_DATE%TYPE;
    L_AC_CLASS_TYPE       STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
  
    L_AVG_BAL         NUMBER(22, 7);
    L_START_DATE      DATE;
    L_COUNT           NUMBER;
    L_REDEMPTION_DATE DATE;
    L_MATURITY_DATE   DATE;
  
  BEGIN
  
    DBG('Entered FN_INSERT_TD_DETAILS...');
  
    DBG('P_BRN...' || P_BRN || ' P_ACC ..' || P_ACC);
    DBG('p_pool_code...' || ' p_ccy ..' || P_CCY);
    DBG('p_acc_class...' || P_ACC_CLASS);
  
    SELECT COUNT(1)
      INTO L_COUNT
      FROM ICTBS_REDEMPTION_DETAIL
     WHERE BRN = P_BRN
       AND ACC = P_ACC
       AND REDEMPTION_TYPE IN ('M', 'F');
  
    IF L_COUNT = 0 THEN
    
      SELECT NVL(LIQN_DAYS, 0), NVL(LIQN_MONTHS, 0), NVL(LIQN_YEARS, 0)
        INTO L_LIQ_DAYS, L_LIQ_MONTHS, L_LIQ_YEARS
        FROM ICTMS_PR_INT
       WHERE PRODUCT_CODE = (SELECT PROD
                               FROM ICTBS_ACC_PR
                              WHERE ACC = P_ACC
                                AND BRN = P_BRN);
    
      L_PPO := L_LIQ_DAYS || 'D' || L_LIQ_MONTHS || 'M' || L_LIQ_YEARS || 'Y';
      DBG('Processing l_ppo---> ' || L_PPO);
    
      ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FLAG);
    
      DBG('l_redem_flag' || L_REDEM_FLAG);
    
      IF L_REDEM_FLAG = 'Y' THEN
        L_REDEMPTION_TYPE := 'F';
      ELSIF L_REDEM_FLAG = 'N' THEN
        L_REDEMPTION_TYPE := 'P';
      ELSE
        L_REDEMPTION_TYPE := 'M';
      END IF;
    
      IF L_REDEMPTION_TYPE = 'M' AND L_AC_CLASS_TYPE <> 'S' THEN
      
        SELECT E.MATURITY_DATE
          INTO L_MATURITY_DATE
          FROM ICTMS_ACC E
         WHERE BRN = P_BRN
           AND ACC = P_ACC;
      
        L_END_DATE := L_MATURITY_DATE - 1;
      
      END IF;
    
      L_REDEMPTION_DATE := GLOBAL.APPLICATION_DATE;
      DBG('l_end_date---> ' || L_END_DATE);
      DBG('l_redemption_date---> ' || L_REDEMPTION_DATE);
      IF L_REDEMPTION_TYPE = 'P' THEN
        L_UDE_VALUE := PKG_REDEM_RATE;
        DBG('l_ude_value***' || L_UDE_VALUE);
      ELSE
      
        BEGIN
        
          SELECT UDE_VALUE
            INTO L_UDE_VALUE
            FROM ICTMS_ACC_UDEVALS
           WHERE UDE_EFF_DT =
                 (SELECT MAX(UDE_EFF_DT)
                    FROM ICTMS_ACC_UDEVALS
                   WHERE UDE_EFF_DT <= L_END_DATE
                     AND BRN = P_BRN
                     AND ACC = P_ACC
                     AND TD_RATE_CODE IS NOT NULL)
             AND BRN = P_BRN
             AND ACC = P_ACC
             AND TD_RATE_CODE IS NOT NULL;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('In When No Data Found So assignging ude value as zero');
            L_UDE_VALUE := 0;
        END;
      END IF;
    
      DBG('ude value----->' || L_UDE_VALUE);
      DBG('g_applicable_slab' || G_APPLICABLE_SLAB);
      DBG('g_applicable_TENOR' || G_APPLICABLE_TENOR);
    
      DBG(' g_applicable_tenor------------>' || G_APPLICABLE_TENOR);
      DBG('Processing l_redemption_type---> ' || L_REDEMPTION_TYPE);
    
      BEGIN
        INSERT INTO ICTBS_REDEMPTION_DETAIL
          (BRN,
           ACC,
           CCY,
           REDEM_DATE,
           REDEM_AMOUNT,
           ACCR_FROM_DATE,
           ACCR_TO_DATE,
           TENOR,
           AMOUNT_SLAB,
           INT_RATE,
           REDEMPTION_TYPE,
           ACCR_FOR_REDEM_AMT,
           TRANSACTION_DATE,
           ADJ_FOR_REDEM_ACCR,
           PPO)
        VALUES
          (P_BRN,
           P_ACC,
           P_CCY,
           L_REDEMPTION_DATE,
           G_BROKEN_AMOUNT,
           NULL,
           NULL,
           G_TENOR,
           G_APPLICABLE_SLAB,
           L_UDE_VALUE,
           L_REDEMPTION_TYPE,
           PKG_ACRR_REDEM_AMT,
           GLOBAL.APPLICATION_DATE,
           'N',
           L_PPO);
      
        PKG_ACRR_REDEM_AMT := 0;
      EXCEPTION
        WHEN OTHERS THEN
          ICPKSS_UTIL.DBG('insert failed in fn_insert_td_details with -->' ||
                          SQLERRM);
          RETURN FALSE;
      END;
    
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('IN EXCEPTION OF FN_INSERT_TD_DETAILS ' || SQLERRM);
      RETURN FALSE;
  END FN_INSERT_TD_DETAILS;

  FUNCTION FN_APPLY_RATE(P_BRN           IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                         P_ACC           IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                         P_AC_CLASS_TYPE IN STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE,
                         P_ACCOUNT_CLASS IN STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE,
                         P_PRODUCT_CODE  IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                         P_CCY           IN STTMS_CUST_ACCOUNT.CCY%TYPE,
                         P_AVG_BAL       IN NUMBER,
                         P_NEWTENOR      IN NUMBER,
                         P_ORIGINALTENOR IN NUMBER,
                         P_AC_OPEN_DATE  IN DATE,
                         P_PPO           IN VARCHAR2
                         
                         )
  
   RETURN BOOLEAN IS
  
    L_FIRST        BOOLEAN := TRUE;
    L_RATE         NUMBER;
    P_TY_RATE      LDPKS_SCHEDULES.TY_RATE;
    L_TD_RATECODE  ICTM_ACC_UDEVALS.TD_RATE_CODE%TYPE;
    L_UDE_EFF_DT   ICTM_ACC_UDEVALS.UDE_EFF_DT%TYPE;
    L_UDEID        ICTM_ACC_UDEVALS.UDE_ID %TYPE;
    L_DATEUPDATE   BOOLEAN := FALSE;
    L_PREVRATE     ICTM_ACC_UDEVALS.UDE_VALUE%TYPE;
    L_TD_RATE_CODE ICTM_ACC_UDEVALS.TD_RATE_CODE%TYPE;
    L_RATE_CODE    ICTM_ACC_UDEVALS.RATE_CODE%TYPE;
    L_UDE_VARIANCE ICTM_ACC_UDEVALS.UDE_VARIANCE%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    DBG('Entered FN_APPLY_PREV_RATE...');
  
    DBG('p_account_class...' || P_ACCOUNT_CLASS || ' p_ccy ..' || P_CCY);
  
    DBG('p_newtenor...' || P_NEWTENOR || ' p_ppo ..' || P_PPO);
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      IF NOT STPKS_TD_REDEMPTION_CLUSTER.FN_APPLY_RATE(P_BRN,
                                                       P_ACC,
                                                       P_AC_CLASS_TYPE,
                                                       P_ACCOUNT_CLASS,
                                                       P_PRODUCT_CODE,
                                                       P_CCY,
                                                       P_AVG_BAL,
                                                       P_NEWTENOR,
                                                       P_ORIGINALTENOR,
                                                       P_AC_OPEN_DATE,
                                                       P_PPO,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_td_redemption_cluster.FN_APPLY_RATE' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      BEGIN
        DBG('upate for full redemption..');
        DBG('dummy update');
      
        UPDATE ICTM_ACC_UDEVALS
           SET UDE_EFF_DT = P_AC_OPEN_DATE
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PROD = P_PRODUCT_CODE
           AND UDE_EFF_DT = P_AC_OPEN_DATE;
        DBG('upate for full redemption..' || SQL%ROWCOUNT);
        IF SQL%ROWCOUNT = 0 THEN
          FOR X IN (SELECT DISTINCT UDE_ID
                      FROM ICTM_ACC_UDEVALS
                     WHERE BRN = P_BRN
                       AND ACC = P_ACC
                       AND PROD = P_PRODUCT_CODE) LOOP
            BEGIN
              DBG('inserting for acopen .');
              SELECT UDE_VALUE,
                     RATE_CODE,
                     TD_RATE_CODE,
                     NVL(UDE_VARIANCE, 0)
                INTO L_PREVRATE,
                     L_RATE_CODE,
                     L_TD_RATE_CODE,
                     L_UDE_VARIANCE
                FROM ICTM_ACC_UDEVALS
               WHERE ACC = P_ACC
                 AND BRN = P_BRN
                 AND UDE_ID = X.UDE_ID
                 AND UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                                     FROM ICTMS_ACC_UDEVALS
                                   
                                    WHERE UDE_EFF_DT <= P_AC_OPEN_DATE
                                         
                                      AND ACC = P_ACC
                                      AND BRN = P_BRN
                                      AND UDE_ID = X.UDE_ID);
              DBG('l_ude_variance..' || L_UDE_VARIANCE);
              INSERT INTO ICTM_ACC_UDEVALS
                (BRN,
                 ACC,
                 PROD,
                 UDE_EFF_DT,
                 UDE_ID,
                 UDE_VALUE,
                 RATE_CODE,
                 AUTH_STAT,
                 RECORD_STAT,
                 TD_RATE_CODE,
                 UDE_VARIANCE)
              VALUES
                (P_BRN,
                 P_ACC,
                 P_PRODUCT_CODE,
                 P_AC_OPEN_DATE,
                 X.UDE_ID,
                 L_PREVRATE,
                 L_RATE_CODE,
                 'A',
                 'O',
                 L_TD_RATE_CODE,
                 L_UDE_VARIANCE);
            
            EXCEPTION
              WHEN OTHERS THEN
                DBG('bombed in insert..');
                NULL;
            END;
          END LOOP;
          BEGIN
          
            INSERT INTO ICTM_ACC_EFFDT
              (BRN, ACC, PROD, UDE_EFF_DT, RECORD_STAT, ONCE_AUTH)
            VALUES
              (P_BRN, P_ACC, P_PRODUCT_CODE, P_AC_OPEN_DATE, 'O', 'Y');
          
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('no tdrate code' || SQLERRM);
          RETURN FALSE;
      END;
    
      DBG('no tdrate code111' || SQLERRM);
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('in exception of FN_APPLY_PREV_RATE ' || SQLERRM);
      RETURN FALSE;
    
  END FN_APPLY_RATE;

  FUNCTION FN_DO_ACCOUNTING(P_TXN_CODE   IN VARCHAR2,
                            P_TXN_REF_NO IN VARCHAR2,
                            P_AMT_TAG    IN VARCHAR2,
                            P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                            P_EVENT      IN VARCHAR2,
                            P_CR_GL      IN VARCHAR2,
                            P_DR_GL      IN VARCHAR2,
                            P_BRN        IN VARCHAR2,
                            P_ACC        IN VARCHAR2,
                            P_CCY        IN VARCHAR2,
                            P_PROD       IN VARCHAR2,
                            P_ERR_CODE   IN OUT VARCHAR2,
                            P_ERR_PARAM  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_PROD              VARCHAR2(4);
    L_AMOUNT_TAG        VARCHAR2(20);
    L_NETTING_INDICATOR VARCHAR2(1);
    L_MIS_HEAD          VARCHAR2(20);
    RELATED_CUSTOMER    VARCHAR2(20);
    L_INT_START_DATE    DATE;
    L_ACLASS            VARCHAR2(20);
    L_BOOK_ACCOUNT      VARCHAR2(10);
    L_ACCOUNT_HEAD      VARCHAR2(20);
    L_PER_GL            VARCHAR2(30);
    L_DRCR              VARCHAR2(1);
    L_XRATE             ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_TAG_AMT_LCY       NUMBER(22, 7);
    L_ERR_CODE          VARCHAR2(100);
    L_ERR_PARAM         VARCHAR2(200);
    L_TAG_AMOUNT        NUMBER(22, 7);
    L_TAG_AMT_FCY       NUMBER(22, 7) := NULL;
  
    L_BOOK_ACC      ICTMS_ACC.BOOK_ACC%TYPE;
    L_BOOK_BRN      ICTMS_ACC.BOOK_BRN%TYPE;
    L_DR_ACC_BRANCH STTMS_BRANCH.BRANCH_CODE%TYPE := P_BRN;
    L_CR_ACC_BRANCH STTMS_BRANCH.BRANCH_CODE%TYPE := P_BRN;
  
    L_BOOK_CCY ICTMS_ACC.BOOK_CCY%TYPE;
    L_CCY      STTM_CUST_ACCOUNT.CCY%TYPE;
  
    L_TAG_AMT_FCY_CR NUMBER(22, 7) := NULL;
    L_TAG_AMT_FCY_DR NUMBER(22, 7) := NULL;
    L_TAG_AMT_LCY_CR NUMBER(22, 7) := NULL;
    L_TAG_AMT_LCY_DR NUMBER(22, 7) := NULL;
    L_CR_CCY         ACTBS_HANDOFF.AC_CCY%TYPE := P_CCY;
    L_DR_CCY         ACTBS_HANDOFF.AC_CCY%TYPE := P_CCY;
    L_CR_XRATE       ACTBS_HANDOFF.EXCH_RATE%TYPE;
    L_DR_XRATE       ACTBS_HANDOFF.EXCH_RATE%TYPE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_VALUE_DATE DATE;
  BEGIN
  
    DBG('INSIDE PR_SET_TBHANDOFF STARTS -------->');
  
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
  
    DBG('p_amt_tag--> ' || P_AMT_TAG);
    DBG('p_tag_amt--> ' || P_TAG_AMT);
    DBG('p_brn------> ' || P_BRN);
    DBG('p_acc------> ' || P_ACC);
    DBG('p_ccy------> ' || P_CCY);
  
    L_TAG_AMOUNT := ABS(P_TAG_AMT);
  
    IF NVL(L_TAG_AMOUNT, 0) = 0 THEN
      DBG('Since amount is zero...no acc hand off');
      RETURN TRUE;
    END IF;
  
    --sampath starts
    IF P_PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'PTP' AND
         P_AMT_TAG = 'ILIQ' THEN
      
        DBG('SKIP THE ACCRUAL TO BE LIQUIDATED TO CASA FOR THE EXTRA TOPUP ON PRE-REDEMPTION');
      
        RETURN TRUE;
      
      END IF;
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'TCX' AND
         P_AMT_TAG = 'ILIQ' THEN
      
        DBG('SKIP THE ACCRUAL TO BE LIQUIDATED TO CASA FOR THE EXTRA TOPUP ON PRE-REDEMPTION');
      
        RETURN TRUE;
      
      END IF;
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'TCX' AND
         P_AMT_TAG = 'TAX' THEN
      
        DBG('SKIP THE TAX TO BE DEBITED FROM CASA FOR THE EXTR ACCRUAL FOR THE EXTRA TOPUP ON PRE-REDEMPTION');
      
        RETURN TRUE;
      
      END IF;
      
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'CLX' AND
         P_AMT_TAG = 'IACR' THEN
      
        DBG('SKIP THE TAX TO BE DEBITED FROM CASA FOR THE EXTR ACCRUAL FOR THE EXTRA TOPUP ON PRE-REDEMPTION');
      
        RETURN TRUE;
      
      END IF;
    
    END IF;
    --sampath ends
    
    --Pro Savings Sampath Starts
    IF P_PROD IN ('PS01', 'PS02', 'PS03', 'PS04') THEN
      
       DBG('INSIDE PRO SAVINGS ACCOUNT CLASSES');
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'PTP' AND
         P_AMT_TAG = 'ILIQ' THEN
      
        DBG('SKIP THE ACCRUAL TO BE LIQUIDATED TO CASA FOR THE EXTRA TOPUP ON PRE-REDEMPTION1');
      
        RETURN TRUE;
      
      END IF;
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'TCX' AND
         P_AMT_TAG = 'ILIQ' THEN
      
        DBG('SKIP THE ACCRUAL TO BE LIQUIDATED TO CASA FOR THE EXTRA TOPUP ON PRE-REDEMPTION2');
      
        RETURN TRUE;
      
      END IF;
    
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'TCX' AND
         P_AMT_TAG = 'TAX' THEN
      
        DBG('SKIP THE TAX TO BE DEBITED FROM CASA FOR THE EXTR ACCRUAL FOR THE EXTRA TOPUP ON PRE-REDEMPTION1');
      
        RETURN TRUE;
      
      END IF;
      
      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 AND P_TXN_CODE = 'CLX' AND
         P_AMT_TAG = 'IACR' THEN
      
        DBG('SKIP THE TAX TO BE DEBITED FROM CASA FOR THE EXTR ACCRUAL FOR THE EXTRA TOPUP ON PRE-REDEMPTION2');
      
        RETURN TRUE;
      
      END IF;
    
    END IF;
    --Pro Savings Sampath Ends
  
    DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
    DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
    L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                        GLOBAL.APPLICATION_DATE);
    DBG('Value date - ' || L_VALUE_DATE);
  
    L_NETTING_INDICATOR := NVL(PKG_LOOKUP(1).NETIND, 'N');
    L_MIS_HEAD          := PKG_LOOKUP(1).MIS_HEAD;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_tag_amt_lcy_cr') := L_TAG_AMT_LCY_CR;
      L_TB_CLUSTER_DATA('l_tag_amt_lcy_dr') := L_TAG_AMT_LCY_DR;
      L_TB_CLUSTER_DATA('l_tag_amt_fcy_cr') := L_TAG_AMT_FCY_CR;
      L_TB_CLUSTER_DATA('l_tag_amt_fcy_dr') := L_TAG_AMT_FCY_DR;
      L_TB_CLUSTER_DATA('l_tag_amt_lcy') := L_TAG_AMT_LCY;
      L_TB_CLUSTER_DATA('l_xrate') := L_XRATE;
      L_TB_CLUSTER_DATA('l_cr_xrate') := L_CR_XRATE;
      L_TB_CLUSTER_DATA('l_dr_xrate') := L_DR_XRATE;
      IF NOT
          STPKS_TD_REDEMPTION_CLUSTER.FN_DO_ACCOUNTING(P_TXN_CODE,
                                                       P_TXN_REF_NO,
                                                       P_AMT_TAG,
                                                       P_TAG_AMT,
                                                       P_EVENT,
                                                       P_CR_GL,
                                                       P_DR_GL,
                                                       P_BRN,
                                                       P_ACC,
                                                       P_CCY,
                                                       P_PROD,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_td_redemption_cluster.fn_do_accounting' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_tag_amt_lcy_cr') THEN
        L_TAG_AMT_LCY_CR := L_TB_CLUSTER_DATA('l_tag_amt_lcy_cr');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_tag_amt_lcy_dr') THEN
        L_TAG_AMT_LCY_DR := L_TB_CLUSTER_DATA('l_tag_amt_lcy_dr');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_tag_amt_fcy_cr') THEN
        L_TAG_AMT_FCY_CR := L_TB_CLUSTER_DATA('l_tag_amt_fcy_cr');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_tag_amt_fcy_dr') THEN
        L_TAG_AMT_FCY_DR := L_TB_CLUSTER_DATA('l_tag_amt_fcy_dr');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_tag_amt_lcy') THEN
        L_TAG_AMT_LCY := L_TB_CLUSTER_DATA('l_tag_amt_lcy');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_xrate') THEN
        L_XRATE := L_TB_CLUSTER_DATA('l_xrate');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_cr_xrate') THEN
        L_CR_XRATE := L_TB_CLUSTER_DATA('l_cr_xrate');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_dr_xrate') THEN
        L_DR_XRATE := L_TB_CLUSTER_DATA('l_dr_xrate');
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF NVL(P_CCY, '$$') <> GLOBAL.LCY THEN
      
        IF NOT CYPKS.FN_AMT1_TO_AMT2(P_BRN,
                                     P_CCY,
                                     GLOBAL.LCY,
                                     P_TAG_AMT,
                                     'Y',
                                     L_TAG_AMT_LCY,
                                     L_XRATE,
                                     L_ERR_CODE) THEN
          DBG('move funds Failed in fn_amt1_to_amt2');
          P_ERR_CODE := 'IC-TDR001';
        END IF;
      
        L_TAG_AMT_LCY_CR := L_TAG_AMT_LCY;
        L_TAG_AMT_LCY_DR := L_TAG_AMT_LCY;
        L_TAG_AMT_FCY_CR := P_TAG_AMT;
        L_TAG_AMT_FCY_DR := P_TAG_AMT;
        L_CR_XRATE       := L_XRATE;
        L_DR_XRATE       := L_XRATE;
      
      ELSE
      
        L_TAG_AMT_LCY_CR := P_TAG_AMT;
        L_TAG_AMT_LCY_DR := P_TAG_AMT;
      
      END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    DBG('l_netting_indicator--> ' || L_NETTING_INDICATOR);
    DBG('l_mis_head--> ' || L_MIS_HEAD);
  
    IF P_ACC IS NOT NULL THEN
    
      BEGIN
        SELECT CUST_NO
          INTO RELATED_CUSTOMER
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_ACC
           AND BRANCH_CODE = P_BRN;
      
        DBG('related_customer--> ' || RELATED_CUSTOMER);
      
        BEGIN
          SELECT OFFSET_BRN, OFFSET_ACC
            INTO L_BOOK_BRN, L_BOOK_ACC
            FROM ICTM_TDREDMPAYOUT_DETAILS
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND REDM_PAYOUT_COMP = 'I'
             AND PAYOUTTYPE = 'S'
             AND REDEM_REF_NO = ICPKS_FCJ_ICDREDMN.G_REDEMREFNO;
        
          SELECT CCY
            INTO L_BOOK_CCY
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = L_BOOK_BRN
             AND CUST_AC_NO = L_BOOK_ACC;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in getting the data from ictm_tdredmpayout_details, hence select from ictm_acc' ||
                SQLERRM);
          
            SELECT BOOK_ACC, BOOK_BRN, BOOK_CCY
              INTO L_BOOK_ACC, L_BOOK_BRN, L_BOOK_CCY
            
              FROM ICTMS_ACC
             WHERE BRN = P_BRN
               AND ACC = P_ACC;
            DBG('l_int_start_date--> ' || L_INT_START_DATE);
        END;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error in ictm_acc select for interest start date :' ||
              SQLERRM);
        
          L_BOOK_ACC := NULL;
        
          L_BOOK_BRN := P_BRN;
          L_BOOK_CCY := P_CCY;
        
      END;
    END IF;
  
    DBG('l_book_acc->' || L_BOOK_ACC || '~l_book_brn->' || L_BOOK_BRN ||
        '~p_cr_gl->' || P_CR_GL || '~p_Dr_gl->' || P_DR_GL || '~p_brn->' ||
        P_BRN);
  
    DBG('l_book_ccy-' || L_BOOK_CCY);
    DBG('p_ccy-' || P_CCY);
  
    IF L_BOOK_ACC IS NOT NULL AND L_BOOK_BRN IS NOT NULL THEN
    
      IF (NVL(L_BOOK_ACC, '$$') = P_CR_GL OR
         NVL(L_BOOK_ACC, '$$') = P_DR_GL) AND
         NVL(L_BOOK_CCY, '$$') <> P_CCY AND
         NVL(L_BOOK_CCY, '$$') <> GLOBAL.LCY THEN
        DBG('Book CCY and Acc CCY are diff...');
        L_TAG_AMT_FCY := NULL;
        L_XRATE       := NULL;
        IF NOT CYPKS.FN_AMT1_TO_AMT2(P_BRN,
                                     P_CCY,
                                     L_BOOK_CCY,
                                     P_TAG_AMT,
                                     'Y',
                                     L_TAG_AMT_FCY,
                                     L_XRATE,
                                     L_ERR_CODE) THEN
          DBG('move funds Failed in fn_amt1_to_amt2');
          P_ERR_CODE := 'IC-TDR001';
        END IF;
        DBG('* FCY Amt      : ' || L_TAG_AMT_FCY);
      END IF;
    
      IF L_BOOK_ACC = P_CR_GL THEN
        DBG('branch is different so going to replace the branch for cr acc');
        DBG('Cr Acc is the Booking Account...');
        L_CR_CCY := L_BOOK_CCY;
      
        L_CR_ACC_BRANCH := L_BOOK_BRN;
      
        IF NVL(L_CR_CCY, '$$') <> P_CCY AND
           NVL(L_CR_CCY, '$$') <> GLOBAL.LCY THEN
          L_TAG_AMT_FCY_CR := L_TAG_AMT_FCY;
          L_CR_XRATE       := NULL;
        ELSIF NVL(L_CR_CCY, '$$') <> P_CCY AND
              NVL(L_CR_CCY, '$$') = GLOBAL.LCY THEN
          L_TAG_AMT_FCY_CR := NULL;
          L_CR_XRATE       := NULL;
        END IF;
      
      END IF;
      IF L_BOOK_ACC = P_DR_GL
      
       THEN
        DBG('branch is different so going to replace the branch for dr acc');
        L_DR_ACC_BRANCH := L_BOOK_BRN;
      
        L_DR_CCY := L_BOOK_CCY;
        IF NVL(L_DR_CCY, '$$') <> P_CCY AND
           NVL(L_DR_CCY, '$$') <> GLOBAL.LCY THEN
          L_TAG_AMT_FCY_DR := L_TAG_AMT_FCY;
          L_DR_XRATE       := NULL;
        ELSIF NVL(L_DR_CCY, '$$') <> P_CCY AND
              NVL(L_DR_CCY, '$$') = GLOBAL.LCY THEN
          L_TAG_AMT_FCY_DR := NULL;
          L_DR_XRATE       := NULL;
        END IF;
      
      END IF;
    
    END IF;
  
    DBG('Book Account   : ' || L_BOOK_ACC || '~' || L_BOOK_BRN || '~' ||
        L_BOOK_CCY || '~');
    DBG('Credit Account : ' || P_CR_GL || '~' || L_CR_ACC_BRANCH || '~' ||
        L_CR_CCY || '~');
    DBG('Debit Account  : ' || P_DR_GL || '~' || L_DR_ACC_BRANCH || '~' ||
        L_DR_CCY || '~');
  
    IF L_CR_CCY <> P_CCY AND L_CR_CCY <> GLOBAL.LCY AND L_CR_XRATE IS NULL THEN
      DBG('3 Currency involved. So getting derived rate based on the LCY amount of TD currency..');
      IF NOT CYPKSS.FN_AMT_TO_RATE(L_CR_CCY,
                                   GLOBAL.LCY,
                                   L_TAG_AMT_FCY_CR,
                                   L_TAG_AMT_LCY_CR,
                                   L_CR_XRATE) THEN
        DBG('Failed to Derive the Exchange Rate ');
        P_ERR_CODE  := 'GW-OTHR-001';
        P_ERR_PARAM := 'Cr Derived rate from LCY amount~';
        RETURN FALSE;
      END IF;
      DBG('Derived Rate for Cr is : ' || L_CR_XRATE);
    END IF;
  
    IF L_DR_CCY <> P_CCY AND L_DR_CCY <> GLOBAL.LCY AND L_DR_XRATE IS NULL THEN
      DBG('3 Currency involved. So getting derived rate based on the LCY amount of TD currency..');
      IF NOT CYPKSS.FN_AMT_TO_RATE(L_DR_CCY,
                                   GLOBAL.LCY,
                                   L_TAG_AMT_FCY_DR,
                                   L_TAG_AMT_LCY_DR,
                                   L_DR_XRATE) THEN
        DBG('Failed to Derive the Exchange Rate ');
        P_ERR_CODE  := 'GW-OTHR-001';
        P_ERR_PARAM := 'Dr Derived rate from LCY amount~';
        RETURN FALSE;
      END IF;
      DBG('Derived Rate for Dr is : ' || L_DR_XRATE);
    END IF;
  
    DBG('Orig Amount : ' || P_TAG_AMT || '~' || P_CCY);
    DBG('Dr Amount  : ' || P_DR_GL || '~' || L_DR_ACC_BRANCH ||
        L_TAG_AMT_FCY_DR || '~' || L_TAG_AMT_LCY_DR || '~' || L_DR_XRATE || '~');
    DBG('Cr Amount  : ' || P_CR_GL || '~' || L_CR_ACC_BRANCH ||
        L_TAG_AMT_FCY_CR || '~' || L_TAG_AMT_LCY_CR || '~' || L_CR_XRATE || '~');
  
    DBG('l_cr_acc_branch ->' || L_CR_ACC_BRANCH || '~l_dr_acc_branch->' ||
        L_DR_ACC_BRANCH);
  
    IF P_AMT_TAG = ('TAX') THEN
      DBG('Inside this TPBL case');
      IF NVL(G_TAX_PAY_CCY_FLAG, 'A') = 'L' THEN
        DBG('g_tax_pay_ccy_flag is Local Currency');
        IF NVL(L_BOOK_ACC, '$$') <> P_CR_GL AND P_CCY <> GLOBAL.LCY THEN
          DBG('Inside this TPBL p_cr_gl case');
          L_CR_CCY         := GLOBAL.LCY;
          L_TAG_AMT_FCY_CR := 0;
          L_CR_XRATE       := 0;
        ELSIF NVL(L_BOOK_ACC, '$$') <> P_DR_GL AND P_CCY <> GLOBAL.LCY THEN
          DBG('Inside this TPBL p_dr_gl case');
          L_DR_CCY         := GLOBAL.LCY;
          L_TAG_AMT_FCY_DR := 0;
          L_DR_XRATE       := 0;
        END IF;
      END IF;
    END IF;
  
    SELECT DECODE(SIGN(P_TAG_AMT), 1, 'C', 'D') INTO L_DRCR FROM DUAL;
  
    TB_ACCHANDOFF(1) := NULL;
  
    TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
    TB_ACCHANDOFF(1).MODULE := 'IC';
    TB_ACCHANDOFF(1).AMOUNT_TAG := P_AMT_TAG;
    TB_ACCHANDOFF(1).EVENT := P_EVENT;
    TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
    TB_ACCHANDOFF(1).TRN_CODE := P_TXN_CODE;
    TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
    TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
    TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';
  
    TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
    TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
    TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
    TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
    TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
    TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
    TB_ACCHANDOFF(1).DRCR_IND := L_DRCR;
  
    TB_ACCHANDOFF(1).AC_BRANCH := L_CR_ACC_BRANCH;
  
    TB_ACCHANDOFF(1).AC_NO := P_CR_GL;
  
    TB_ACCHANDOFF(1).AC_CCY := L_CR_CCY;
  
    TB_ACCHANDOFF(1).FCY_AMOUNT := ABS(L_TAG_AMT_FCY_CR);
    TB_ACCHANDOFF(1).LCY_AMOUNT := ABS(L_TAG_AMT_LCY_CR);
  
    TB_ACCHANDOFF(1).EXCH_RATE := L_CR_XRATE;
  
    TB_ACCHANDOFF(1).PRODUCT := P_PROD;
  
    DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
    DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
    DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
    DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
    DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
    DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
    DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
    DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
    DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
    DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
    DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
    DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
    DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
    DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
    DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
    DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
    DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
    DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
    DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
    DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
    DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);
  
    DBG(' Finished credit leg');
  
    SELECT DECODE(SIGN(P_TAG_AMT), 1, 'D', 'C') INTO L_DRCR FROM DUAL;
  
    TB_ACCHANDOFF(2) := NULL;
  
    TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID, GLOBAL.USER_ID);
    TB_ACCHANDOFF(2).MODULE := 'IC';
    TB_ACCHANDOFF(2).AMOUNT_TAG := P_AMT_TAG;
    TB_ACCHANDOFF(2).EVENT := P_EVENT;
    TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
    TB_ACCHANDOFF(2).TRN_CODE := P_TXN_CODE;
    TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
    TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
    TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';
  
    TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
    TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
    TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
    TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
    TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
    TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
    TB_ACCHANDOFF(2).DRCR_IND := L_DRCR;
  
    TB_ACCHANDOFF(2).AC_BRANCH := L_DR_ACC_BRANCH;
  
    TB_ACCHANDOFF(2).AC_NO := P_DR_GL;
  
    TB_ACCHANDOFF(2).AC_CCY := L_DR_CCY;
  
    TB_ACCHANDOFF(2).FCY_AMOUNT := ABS(L_TAG_AMT_FCY_DR);
    TB_ACCHANDOFF(2).LCY_AMOUNT := ABS(L_TAG_AMT_LCY_DR);
  
    TB_ACCHANDOFF(2).EXCH_RATE := L_DR_XRATE;
  
    TB_ACCHANDOFF(2).PRODUCT := P_PROD;
  
    DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
    DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
    DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
    DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
    DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
    DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
    DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
    DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
    DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
    DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
    DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
    DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
    DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
    DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
    DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
    DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
    DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
    DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
    DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
    DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
    DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);
  
    DBG(' Finished debit leg');
  
    DBG('calling acpkss.fn_achandoff ');
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_TD_REDEMPTION_CLUSTER.FN_DO_ACCOUNTING(P_TXN_CODE,
                                                       P_TXN_REF_NO,
                                                       P_AMT_TAG,
                                                       P_TAG_AMT,
                                                       P_EVENT,
                                                       P_CR_GL,
                                                       P_DR_GL,
                                                       P_BRN,
                                                       P_ACC,
                                                       P_CCY,
                                                       P_PROD,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_td_redemption_cluster.fn_do_accounting' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;
  
    IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                               1,
                               GLOBAL.APPLICATION_DATE,
                               TB_ACCHANDOFF,
                               'B',
                               'N',
                               'N',
                               GLOBAL.USER_ID,
                               L_ERR_CODE,
                               L_ERR_PARAM) THEN
      ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);
    
      IF L_ERR_CODE IS NOT NULL THEN
        OVPKS.PR_APPENDTBL(L_ERR_CODE, L_ERR_PARAM);
      END IF;
    
      P_ERR_CODE := L_ERR_CODE;
    
    ELSE
      DBG('SUCCESS IN ACCOUNTING HANDOFF');
      --RETURN FALSE;
    END IF;
  
    --sampath starts
    /*IF P_PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN
    
      --Reverse Extra Liquidations
      IF NOT
          STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS(P_TXN_CODE,
                                                                         P_TXN_REF_NO,
                                                                         P_AMT_TAG,
                                                                         P_TAG_AMT,
                                                                         P_EVENT,
                                                                         P_CR_GL,
                                                                         P_DR_GL,
                                                                         P_BRN,
                                                                         P_ACC,
                                                                         P_CCY,
                                                                         P_PROD,
                                                                         P_ERR_CODE,
                                                                         P_ERR_PARAM) THEN
      
        DBG('FAILED IN REVERSING THE LIQUIDATIONS FOR THE EXTRA TOP UP BACK TO CASA');
      
        RETURN FALSE;
      
      ELSE
      
        DBG('SUCCESS IN REVERSING THE LIQUIDATIONS FOR THE EXTRA TOP UP BACK TO CASA');
      
        --Reverse Extra Tax 
        IF NOT
            STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_TAX(P_TXN_CODE,
                                                                  P_TXN_REF_NO,
                                                                  P_AMT_TAG,
                                                                  P_TAG_AMT,
                                                                  P_EVENT,
                                                                  P_CR_GL,
                                                                  P_DR_GL,
                                                                  P_BRN,
                                                                  P_ACC,
                                                                  P_CCY,
                                                                  P_PROD,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAM) THEN
        
          DBG('FAILED IN REVERSING THE TAX BACK TO CASA');
        
          RETURN FALSE;
        
        ELSE
        
          DBG('SUCCESS IN REVERSING THE TAX BACK TO CASA');
        
          --Reverse Extra Accruals
          IF NOT
              STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_ACCRUALS(P_TXN_CODE,
                                                                   P_TXN_REF_NO,
                                                                   P_AMT_TAG,
                                                                   P_TAG_AMT,
                                                                   P_EVENT,
                                                                   P_CR_GL,
                                                                   P_DR_GL,
                                                                   P_BRN,
                                                                   P_ACC,
                                                                   P_CCY,
                                                                   P_PROD,
                                                                   P_ERR_CODE,
                                                                   P_ERR_PARAM) THEN
          
            DBG('FAILED IN REVERSING THE LIQUIDATIONS FOR THE EXTRA TOP UP BACK TO CASA');
          
            RETURN FALSE;
          
          ELSE
          
            DBG('SUCCESS IN REVERSING THE LIQUIDATIONS FOR THE EXTRA TOP UP BACK TO CASA');
          
            RETURN TRUE;
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;*/
    --sampath ends
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('STPKS_TD_REDEMPTION.FN_DO_ACCOUNTING failed-->' || SQLERRM);
      P_ERR_CODE := 'IC-MU0006';
      RETURN FALSE;
  END FN_DO_ACCOUNTING;
  FUNCTION FN_DO_MEMO_ACCRUAL(P_BRN        IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              P_ACC        IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_START_DATE IN DATE,
                              P_END_DATE   IN DATE,
                              P_RULE       IN ICTM_PR_INT.RULE%TYPE,
                              P_PROD       IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                              
                              P_MEMO_REC  OUT TY_MEMO_REC,
                              P_ERR_CODE  IN OUT VARCHAR2,
                              P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    SSQL              VARCHAR2(255);
    C                 INTEGER;
    I                 INTEGER;
    L_ACCR_AMOUNT     NUMBER(22, 7);
    CNT               INTEGER := 0;
    L_REDEM_FLAG      VARCHAR2(1);
    L_REDEMPTION_TYPE VARCHAR2(1);
    L_REDEM_AMT       STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
  
    L_TOPUP_CNT  NUMBER := 0;
    L_TOPUP_FLAG VARCHAR2(1);
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_UDE_CCY     ICTMS_PR_INT.UDE_CCY%TYPE;
    L_ICTM_PR_INT ICTM_PR_INT%ROWTYPE;
    CURSOR CR_ICTB(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
      SELECT *
        FROM ICTBS_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND PROD = P_PROD;
  
    CURSOR CR_MEMO_BOOKING(PBRN VARCHAR2, PACC VARCHAR2, PPROD VARCHAR2) IS
      SELECT M.*
        FROM ICTW_MEMO_BOOKING M
       WHERE M.BRN = PBRN
         AND M.ACC = PACC
         AND M.PROD = PPROD
      
       ORDER BY M.FRM_NO;
  
    FUNCTION Q(S VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
      RETURN CSPKES_MISC.FN_GETCHR(39) || S || CSPKES_MISC.FN_GETCHR(39);
    END Q;
  
  BEGIN
  
    DBG('Entered fn_do_memo_accrual');
    DBG('p_brn----->' || P_BRN);
    DBG('p_acc----->' || P_ACC);
    DBG('p_start_date--->' || P_START_DATE);
    DBG('p_end_date---->' || P_END_DATE);
    DBG('p_rule----->' || P_RULE);
    DBG('p_prod----->' || P_PROD);
  
    BEGIN
    
      DELETE FROM ICTW_MEMO_BOOKING A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = P_PROD;
    
      DBG('No of rows got del:' || SQL%ROWCOUNT);
    
      DBG('Deleting records from ictbs_iis_val');
      DELETE FROM ICTBS_IIS_VAL I
       WHERE I.BRN = P_BRN
         AND I.ACC = P_ACC
         AND I.RULE_ID = P_RULE
         AND I.PROD = P_PROD;
      DBG('No of rows got del:' || SQL%ROWCOUNT);
    
      ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FLAG);
    
      DBG('l_redem_flag' || L_REDEM_FLAG);
    
      L_TOPUP_CNT := 0;
    
      BEGIN
        SELECT COUNT(1)
          INTO L_TOPUP_CNT
          FROM TDTB_EVENT_DETAILS
         WHERE ACC = P_ACC
           AND BRN = P_BRN;
      EXCEPTION
        WHEN OTHERS THEN
          L_TOPUP_CNT := 0;
      END;
    
      IF L_TOPUP_CNT > 0 THEN
        L_TOPUP_FLAG := 'Y';
      ELSE
        L_TOPUP_FLAG := 'N';
      END IF;
      DBG('l_topup_flag--->' || L_TOPUP_FLAG);
    
      IF L_REDEM_FLAG = 'Y' THEN
        L_REDEMPTION_TYPE := 'F';
      ELSIF L_REDEM_FLAG = 'N' THEN
        L_REDEMPTION_TYPE := 'P';
      ELSE
        L_REDEMPTION_TYPE := 'M';
      END IF;
      IF L_TOPUP_FLAG = 'N' THEN
        IF L_REDEMPTION_TYPE = 'F' THEN
          BEGIN
            SELECT (TD_AMOUNT - NVL(REDEM_AMT, 0))
              INTO L_REDEM_AMT
              FROM ICTM_TD_DETAILS
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND CCY = NVL(G_CCY, GLOBAL.LCY);
          EXCEPTION
            WHEN OTHERS THEN
              P_ERR_CODE := 'IC-MU0008';
              DBG('ERROR IN STPKS_TD_REDEMPTION.FN_PARTIAL_BROKEN_TD---> ' ||
                  SQLERRM);
              RETURN FALSE;
            
          END;
        
          ICPKS_BOD.G_PENALTY := L_REDEM_AMT;
        
        ELSE
        
          IF PKG_PROCESSING_REM_AMT THEN
            ICPKS_BOD.G_PENALTY := 0;
          ELSE
          
            ICPKSS_MAINT.PR_GET_REDEM_AMT(L_REDEM_AMT);
            ICPKS_BOD.G_PENALTY := L_REDEM_AMT;
          
            DBG('l_Redem_Amt:' || L_REDEM_AMT);
          END IF;
        
        END IF;
      END IF;
    
      DBG('g_penalty:' || ICPKS_BOD.G_PENALTY);
    
      FOR X IN CR_ICTB(P_BRN, P_ACC, P_PROD) LOOP
        ICPKSS_UTIL.DBG('Inside loop for ictb acc pr ssss');
      
        L_ICTM_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(P_PROD);
        DBG('l_ude_ccy-->' || L_ICTM_PR_INT.UDE_CCY);
      
        ICPKSS_CALC.G_PROD_REC.UDE_CCY := L_ICTM_PR_INT.UDE_CCY;
      
        DBG('icpkss_calc.g_prod_rec.ude_ccy-->' ||
            ICPKSS_CALC.G_PROD_REC.UDE_CCY);
      
        CNT                            := CNT + 1;
        ICPKSS_CALC.G_ICTB_ACC_PR.BRN  := X.BRN;
        ICPKSS_CALC.G_ICTB_ACC_PR.ACC  := X.ACC;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD := X.PROD;
      
        ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT := P_START_DATE;
        DBG('here for full' || ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT);
      
        ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT         := X.GC_MAP_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT      := X.LAST_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT       := X.LAST_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT       := X.NEXT_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT      := X.LAST_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := X.NEXT_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT  := X.LAST_SCHD_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH           := X.INC_MTH;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT  := X.NEXT_SCHD_LIQ_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT     := X.FIRST_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := X.NEXT_SCHD_ACCR_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE         := X.PROD_TYPE;
        ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR          := X.HAS_ACCR;
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT      := X.NEXT_CALC_DT;
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR         := X.PROD_ACCR;
        ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT      := X.DEFER_LIQ_DT;
        ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS        := X.ACLASS;
        ICPKSS_CALC.G_CUST_ACC.CCY                  := X.CCY;
      END LOOP;
    
      ICPKS_TEST.TB_NEXT_ACCR_DT(1) := P_END_DATE;
      ICPKS_TEST.TB_LAST_ACCR_DT(1) := P_START_DATE - 1;
      ICPKS_TEST.TB_NEXT_LIQ_DT(1) := P_END_DATE;
      ICPKS_TEST.TB_LAST_LIQ_DT(1) := P_START_DATE - 1;
      ICPKS_TEST.TB_PROD(1) := ICPKSS_CALC.G_ICTB_ACC_PR.PROD;
      ICPKS_TEST.TB_FIRST_CALC_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT;
      ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(1) := ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT;
    
      ICPKS_UDE.PR_PREPARE_GC(ICPKSS_CALC.G_ICTB_ACC_PR.BRN,
                              ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS,
                              ICPKSS_CALC.G_CUST_ACC.CCY,
                              ICPKSS_CALC.G_ICTB_ACC_PR.PROD,
                              ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT,
                              GLOBAL.APPLICATION_DATE,
                              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT);
    
      ICPKS_SDE.PR_PREPARE_SDE(P_BRN,
                               P_ACC,
                               ICPKSS_CALC.G_CUST_ACC.CCY,
                               1,
                               1);
    
      ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);
      ICPKS_TEST.PR_CACHE_PROD(P_PROD, NULL);
    
      ICPKSS_CALC.SET_ACC_DETAILS(P_BRN, P_ACC);
    
      DBG('pkg_penalty_apply:' || PKG_PENALTY_APPLY);
      IF PKG_PENALTY_APPLY = 0 THEN
        PR_WAIVE_PENALTY;
      ELSE
        DBG('icpkss_calc.g_penalty:' || ICPKSS_CALC.G_PENALTY);
        PR_RESET_PENALTY;
      END IF;
    
      C := DBMS_SQL.OPEN_CURSOR;
    
      SSQL := 'DECLARE l_tb_icent icpkss_test.rec_icent; BEGIN ' ||
             
              'C3GF#_IIPR1_' || P_RULE ||
              '(:p_brn,:p_acc,:p_prod,TO_DATE(:p_start_date,'
             
              || Q('YYYYMMDD') || '),TO_DATE(:p_end_date ,' ||
             
              Q('YYYYMMDD') || '),l_tb_icent' || '); END;';
    
      DBG('About To Parse for TD broken calc ' || SSQL);
    
      DBMS_SQL.PARSE(C, SSQL, DBMS_SQL.NATIVE);
    
      DBMS_SQL.BIND_VARIABLE(C, 'p_brn', P_BRN);
      DBMS_SQL.BIND_VARIABLE(C, 'p_acc', P_ACC);
      DBMS_SQL.BIND_VARIABLE(C, 'p_prod', P_PROD);
      DBMS_SQL.BIND_VARIABLE(C,
                             'p_start_date',
                             TO_CHAR(P_START_DATE, 'YYYYMMDD'));
      DBMS_SQL.BIND_VARIABLE(C,
                             'p_end_date',
                             TO_CHAR(P_END_DATE, 'YYYYMMDD'));
    
      DBG('About To Execute for TD broken calc ' || SSQL);
    
      I := DBMS_SQL.EXECUTE(C);
    
      DBMS_SQL.CLOSE_CURSOR(C);
    
    EXCEPTION
      WHEN OTHERS THEN
        IF DBMS_SQL.IS_OPEN(C) THEN
          DBMS_SQL.CLOSE_CURSOR(C);
        END IF;
        P_ERR_CODE  := 'IC-MU0007';
        P_ERR_PARAM := '';
        DBG('failed in C3GF#_IIPR1_ ' || SQLERRM);
        RETURN FALSE;
    END;
  
    IF CR_MEMO_BOOKING%ISOPEN THEN
      CLOSE CR_MEMO_BOOKING;
    END IF;
  
    OPEN CR_MEMO_BOOKING(P_BRN, P_ACC, P_PROD);
    FETCH CR_MEMO_BOOKING BULK COLLECT
      INTO P_MEMO_REC;
  
    CLOSE CR_MEMO_BOOKING;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKSS_TD_REDEMPTION_CLUSTER.FN_MEMO_ACCRUAL(P_BRN,
                                                       P_ACC,
                                                       P_START_DATE,
                                                       P_END_DATE,
                                                       P_RULE,
                                                       P_PROD,
                                                       P_MEMO_REC,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpkss_td_redemption_cluster...');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF P_MEMO_REC.COUNT > 0 THEN
      DBG('Printing Memo details');
      FOR I IN P_MEMO_REC.FIRST .. P_MEMO_REC.LAST LOOP
        DBG('Brn~Acc~Prod~Frm_no~Is_tax~drcr_ind~amt::' || P_MEMO_REC(I).BRN || '~' || P_MEMO_REC(I).ACC || '~' || P_MEMO_REC(I).PROD || '~' || P_MEMO_REC(I)
            .FRM_NO || '~' || P_MEMO_REC(I).IS_TAX || '~' || P_MEMO_REC(I)
            .DRCR_IND || '~' || P_MEMO_REC(I).AMT);
      END LOOP;
    END IF;
  
    DBG('coming out of fn_do_memo_accrual');
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in STPKS_TD_REDEMPTION.FN_DO_MEMO_ACCRUAL --->' ||
          SQLERRM);
      P_ERR_CODE  := 'IC-MU0007';
      P_ERR_PARAM := '';
      RETURN FALSE;
  END FN_DO_MEMO_ACCRUAL;

END STPKS_TD_REDEMPTION;
