CREATE OR REPLACE PACKAGE BODY stpks_stdcusac_utils_1 IS

  TYPE TY_EXIST_SUBSYS IS TABLE OF VARCHAR2(50) INDEX BY VARCHAR2(50);

  G_SUBSYSTEM_TY_FLDS GWPKS_UTIL.TY_SUBSYSTEM_FLDS;
  G_ERR_FLAG          INTEGER := 0;
  PKG_FIELD           VARCHAR2(1000);
  PKG_SOURCE          VARCHAR2(30);

  PKG_CASCADE_NXTMATDT VARCHAR2(1) := 'N';
  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcusac_utils_1 ==>' || P_MSG;
    DEBUG.PR_DEBUG('ST', L_MSG);
  END DBG;

  FUNCTION FN_CHECK_SWIFTFORMAT_KERNEL(P_FUNCTION_ID IN VARCHAR2,
                                       P_KEY         IN VARCHAR2,
                                       P_FIELD       IN VARCHAR2)
    RETURN BOOLEAN;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_UPLD_VALIDATIONS(P_FUNCTION_ID IN VARCHAR2,
                               P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_BANK_AUTH_STAT STTMS_BANK.AUTH_STAT%TYPE;
  BEGIN
    DBG('Inside fn_upld_validations');
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || ' Acc: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Acccls: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS ||
        ' Custno: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

    DBG('To check for the validity of the bank params maintained');
    BEGIN
      SELECT AUTH_STAT INTO L_BANK_AUTH_STAT FROM STTM_BANK;

      IF L_BANK_AUTH_STAT = 'U' THEN
        DBG('Failed: Bank Paramters not Authorized');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-10001', '');
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Failed: Bank Paramters not Maintained');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-BRN04', '');
        RETURN FALSE;
    END;

    DBG('fn_upld_validations returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upld_validations with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_UPLD_VALIDATIONS;

  FUNCTION FN_LEFTPAD(P_FUNCTION_ID    IN VARCHAR2,
                      P_TYPE           IN VARCHAR2,
                      USER_STRING      IN VARCHAR2,
                      P_BANK_CODE_MASK IN VARCHAR2,
                      P_ACC_NO_MASK    IN VARCHAR2,
                      P_PADDED_VALUE   IN OUT VARCHAR2) RETURN NUMBER IS
    SUBST           VARCHAR2(1);
    LENGTH_STR_IBAN NUMBER(30);
    LENGTH_STR      NUMBER(30);
    LPAD_STR        VARCHAR2(30);
    I               NUMBER(15);
    IS_NUMERIC      NUMBER(1);
  BEGIN
    DBG('Inside fn_leftpad');

    LPAD_STR := USER_STRING;
    DBG('BEGIN :FN_LEFTPAD');
    DBG('p_type:' || P_TYPE);
    IF P_TYPE = 'B' THEN
      IS_NUMERIC := 1;
      DBG('p_bank_code_mask: ' || P_BANK_CODE_MASK);
      LENGTH_STR := NVL(LENGTH(P_BANK_CODE_MASK), 0);
      DBG('length_str: ' || LENGTH_STR);
      LENGTH_STR_IBAN := NVL(LENGTH(USER_STRING), 0);
      DBG('length_str_iban: ' || LENGTH_STR_IBAN);
      LPAD_STR := USER_STRING;
      I        := 1;
      LOOP
        SUBST := SUBSTR(USER_STRING, I, 1);
        DBG('i= ' || I);
        IF (ASCII(SUBST) >= 48 AND ASCII(SUBST) <= 57) THEN
          IS_NUMERIC := 0;
        ELSE
          IS_NUMERIC := 1;
        END IF;
        I := I + 1;
        EXIT WHEN IS_NUMERIC = 1 OR I > LENGTH_STR_IBAN;
      END LOOP;
      IF INSTR(P_BANK_CODE_MASK, 'a', 1) = '0' THEN

        IF (IS_NUMERIC = 0 AND LENGTH_STR > LENGTH_STR_IBAN) THEN
          LPAD_STR := LPAD(USER_STRING, LENGTH_STR, '0');
          DBG('user_string:' || USER_STRING);
          DBG('lpad_str:' || LPAD_STR);
        END IF;
      END IF;
      DBG('p_type:' || P_TYPE);
    ELSIF P_TYPE = 'A' THEN

      IS_NUMERIC := 1;
      LENGTH_STR := NVL(LENGTH(P_ACC_NO_MASK), 0);
      DBG('length_str in function:' || LENGTH_STR);
      LENGTH_STR_IBAN := NVL(LENGTH(USER_STRING), 0);
      DBG('length_str_iban in function:' || LENGTH_STR_IBAN);

      I := 1;
      LOOP
        SUBST := SUBSTR(USER_STRING, I, 1);
        DBG('i= ' || I);
        IF (ASCII(SUBST) >= 48 AND ASCII(SUBST) <= 57) THEN
          IS_NUMERIC := 0;
        ELSE
          IS_NUMERIC := 1;
        END IF;
        I := I + 1;
        EXIT WHEN IS_NUMERIC = 1 OR I > LENGTH_STR_IBAN;
      END LOOP;
      DBG('is_numeric : ' || IS_NUMERIC);
      DBG('user_string : ' || USER_STRING);
      DBG('length_str : ' || LENGTH_STR);
      DBG('length_str_iban : ' || LENGTH_STR_IBAN);
      IF INSTR(P_ACC_NO_MASK, 'a', 1) = '0' THEN

        IF (IS_NUMERIC = 0 AND LENGTH_STR > LENGTH_STR_IBAN) THEN
          LPAD_STR := LPAD(USER_STRING, LENGTH_STR, '0');
          DBG('user_string:' || USER_STRING);
          DBG('lpad_str:' || LPAD_STR);
        END IF;
      END IF;
    END IF;
    P_PADDED_VALUE := LPAD_STR;
    DBG('fn_leftpad returning');
    RETURN IS_NUMERIC;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upld_validations with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN IS_NUMERIC;
  END FN_LEFTPAD;

  FUNCTION FN_PAYINOUT_VALIDATE(P_FUNCTION_ID IN VARCHAR2,
                                P_ACTION_CODE IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ERR_FLAG    IN OUT NUMBER) RETURN BOOLEAN IS
    L_GL_CODE    STTMS_PAYIN_MODE.GL_CODE%TYPE;
    L_GL_CNT     NUMBER := 0;
    L_SAVACC_CNT NUMBER := 0;
    L_CASH_CNT   NUMBER := 0;
    L_CCY_RES    VARCHAR2(1);
    L_CCY_S      VARCHAR2(3);
    L_LOCAL_CCY  VARCHAR2(3);
    L_COUNT      NUMBER := 0;
    L_CNT        NUMBER := 0;
    GL_COUNT     NUMBER := 0;
    CASHGL_COUNT NUMBER := 0;

    L_PAYIN_TOTAL           NUMBER(22, 3) := 0;
    L_PAYIN_PERCENTAGE      NUMBER(22, 3) := 0;
    L_PAYOUT_PERCENTAGE     NUMBER(22, 3) := 0;
    L_PAYOUT_INT_PERCENTAGE NUMBER(22, 3) := 0;

    L_AC_STAT_FROZEN VARCHAR2(1);
    L_AC_STAT_NO_DR  VARCHAR2(1);
    L_PAY_MTHD       VARCHAR2(1);

    CHEQUE_COUNT NUMBER := 0;
    SAV_COUNT    NUMBER := 0;

    L_ACC_BAL        STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    OFFSETFCY_AMOUNT NUMBER;
    OFFSET_XRATE     ACTBS_HANDOFF.EXCH_RATE%TYPE;

    L_SECTORCODE    DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT       DATE;
    L_DRVALDT       DATE;
    L_LATE_CLEARING VARCHAR2(10);
    L_ERROR_CODE    VARCHAR2(10);

    L_RESULT VARCHAR2(1000);

    L_ACY_AVL_BAL STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;

    L_BAL_MULTIMODE STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;

    L_LIM_BAL STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    CURSOR CUR_FACILITY_LINKAGE(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTM_CUST_ACCOUNT_LINKAGES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    TYPE TY_FACILITY_LINKAGE IS TABLE OF CUR_FACILITY_LINKAGE%ROWTYPE INDEX BY BINARY_INTEGER;
    L_FACILITY_LINKAGE TY_FACILITY_LINKAGE;
    TYPE TY_EXPIRY_DATE IS TABLE OF GETM_FACILITY.LINE_EXPIRY_DATE%TYPE INDEX BY BINARY_INTEGER;
    L_EXPIRED_DATE TY_EXPIRY_DATE;
    L_ERR_CODE     ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM    VARCHAR2(2000);
    L_EXPIRY_COUNT NUMBER := 0;
    L_EXPIRY_DATE  DATE;
    L_LIAB_NO      VARCHAR2(20);
    L_DENDEP_FLG   STTM_ACCOUNT_CLASS.DENM_DEPOSIT%TYPE;

    L_DENOM_VALID_FLAG BOOLEAN := FALSE;

    L_AC_STAT_DORMANT STTM_ACCOUNT_BALANCE.AC_STAT_DORMANT%TYPE;
    L_ACCOUNT_CLASS   STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_AVL_BAL_REQ     STTM_ACCOUNT_CLASS.AVAIL_BAL_REQD%TYPE;
    L_AC_OPEN_DATE    STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_CHQ_STL_DAYS STTM_BRANCH.CHEQUE_STALE_DAYS%TYPE;
  BEGIN
    DBG('Inside fn_payinout_validate');

    DBG('p_action_code ' || P_ACTION_CODE || 'auto_rollover' ||
        P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER || 'int unclaimed' ||
        P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED || 'princ unclaimed' ||
        P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED || 'pkg func' ||
        GWPKS_UTIL.PKG_FUNC);
    IF P_ACTION_CODE = 'NEW' AND GWPKS_UTIL.PKG_FUNC = 'TDMM' THEN
      DBG('Close on maturity-->' ||
          P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY);
      IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'N' AND
         P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'N' AND
         P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N' THEN
        P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY := 'Y';
      END IF;
      DBG('Close on maturity 2-->' ||
          P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY);
    END IF;

    DBG('First checking for v_ictms_tdpayin_details count :' ||
        P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
    IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'N' THEN
      IF P_ACTION_CODE <> 'MODIFY' OR
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

        IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
          FOR I IN P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.LAST LOOP
            DBG('p_stdcusac.v_ictms_tdpayin_details(i).multimode_payopt....' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_PAYOPT);
            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'S' THEN
              DBG('looping for payin details' || I || '  FIR ACCC ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_OFFSET_BRN);

              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_ACC IS NULL THEN
                DBG('Payin offset account cannot be null');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS400', '');
                P_ERR_FLAG := -1;
                RETURN FALSE;
              END IF;

              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_ACC IS NULL THEN
                DBG('Payin offset account cannot be null');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS400', '');
                P_ERR_FLAG := -1;
                RETURN FALSE;
              END IF;

              IF CUR_FACILITY_LINKAGE%ISOPEN THEN
                CLOSE CUR_FACILITY_LINKAGE;
              END IF;
              OPEN CUR_FACILITY_LINKAGE(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                        .MULTIMODE_OFFSET_BRN,
                                        P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                        .MULTIMODE_TDOFFSET_ACC);
              FETCH CUR_FACILITY_LINKAGE BULK COLLECT
                INTO L_FACILITY_LINKAGE;
              L_EXPIRY_COUNT := 0;
              IF L_FACILITY_LINKAGE.COUNT > 0 THEN
                FOR J IN 1 .. L_FACILITY_LINKAGE.COUNT LOOP
                  DBG('Customer no ' || L_FACILITY_LINKAGE(J).CUSTOMER_NO);
                  BEGIN
                    SELECT LIABILITY_NO
                      INTO L_LIAB_NO
                      FROM STTM_CUSTOMER
                     WHERE CUSTOMER_NO = L_FACILITY_LINKAGE(J).CUSTOMER_NO;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('In when others ' || SQLERRM);
                      L_LIAB_NO := NULL;
                  END;
                  IF L_FACILITY_LINKAGE(J).LINKAGE_TYPE = 'F' THEN
                    IF NOT
                        ELPKS_FACILITY_SERVICE.FN_GET_LINE_EXP_DT(L_FACILITY_LINKAGE(J)
                                                                  .LINKED_REF_NO,
                                                                  L_LIAB_NO,
                                                                  L_EXPIRY_DATE,
                                                                  L_ERR_CODE,
                                                                  L_ERR_PARAM) THEN
                      DBG('Failed in Elpks_Facility_Service.Fn_Get_Line_Exp_Dt' ||
                          SQLERRM);
                      RETURN FALSE;
                    ELSE
                      L_EXPIRED_DATE(J) := L_EXPIRY_DATE;
                    END IF;

                    IF (L_EXPIRED_DATE(J) < GLOBAL.APPLICATION_DATE) THEN
                      L_EXPIRY_COUNT := L_EXPIRY_COUNT + 1;
                    END IF;
                  END IF;
                  DBG('Calculated Balance Amount greater than limit balance...error message... : ' || J);
                END LOOP;
              END IF;
              DBG('i outer loop : ' || I);
              CLOSE CUR_FACILITY_LINKAGE;
              IF L_EXPIRY_COUNT > 0 THEN
                DBG('Inside expired  OD lines ');
                IF NOT ACPKS_MISC.FN_GETAVLBAL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_OFFSET_BRN,
                                               P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_TDOFFSET_ACC,
                                               L_ACC_BAL,
                                               'Y',
                                               'N',
                                               'Y') THEN
                  DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
                  RETURN FALSE;
                END IF;
              ELSE
                DBG('Inside available OD lines ');
                IF NOT ACPKS_MISC.FN_GETAVLBAL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_OFFSET_BRN,
                                               P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_TDOFFSET_ACC,
                                               L_ACC_BAL,
                                               'Y',
                                               'Y',
                                               'Y') THEN
                  DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
                  RETURN FALSE;
                END IF;
              END IF;

              DBG('Offset Branch ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_OFFSET_BRN);
              DBG('Offset Account ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDOFFSET_ACC);
              BEGIN
                SELECT B.CCY,

                       C.ACY_WITHDRAWABLE_BAL,
                       B.ACCOUNT_CLASS
                  INTO P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                       .MULTIMODE_TDOFFSET_CCY,
                       L_ACY_AVL_BAL,
                       L_ACCOUNT_CLASS
                  FROM STTMS_CUST_ACCOUNT B, STTM_ACCOUNT_BALANCE C
                 WHERE B.BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_OFFSET_BRN
                   AND B.CUST_AC_NO = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_TDOFFSET_ACC

                   AND C.CUST_AC_BRN = B.BRANCH_CODE
                   AND C.CUST_AC_NO = B.CUST_AC_NO

                ;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('Failed in selecting ccy for payin account');
                  RETURN FALSE;
              END;

              BEGIN
                SELECT AVAIL_BAL_REQD
                  INTO L_AVL_BAL_REQ
                  FROM STTM_ACCOUNT_CLASS
                 WHERE ACCOUNT_CLASS = L_ACCOUNT_CLASS;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed to get avail bal required from account class');
                  NULL;
              END;
              DBG('l_avl_bal_req ----->' || L_AVL_BAL_REQ);

              DBG('Got avl bal as --->' || L_ACC_BAL);
              DBG('tdccy ---->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
              DBG('offsetccy ----->' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDOFFSET_CCY);
              DBG('global.lcy ----->' || GLOBAL.LCY);
              IF NVL(L_AVL_BAL_REQ, 'N') = 'Y' THEN
                IF ((P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                   .MULTIMODE_TDOFFSET_CCY = GLOBAL.LCY) AND
                   (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY = GLOBAL.LCY)) OR
                   (P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                   .MULTIMODE_TDOFFSET_CCY =
                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY) THEN
                  DBG('In the case where td , offset ccy r same as local ccy....');
                  DBG('hv to compare acc avl bal with offset lcy amt.....');

                  IF (NVL(L_ACY_AVL_BAL, 0) <
                     NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                          .MULTIMODE_TDAMOUNT,
                          0)) THEN
                    DBG('TD Amount greater than available balance...calculating balance amount...');
                    IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                      L_BAL_MULTIMODE := NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                             .MULTIMODE_TDAMOUNT,
                                             0) - NVL(L_ACY_AVL_BAL, 0);
                    ELSE
                      L_BAL_MULTIMODE := NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                             .MULTIMODE_TDAMOUNT,
                                             0);
                    END IF;
                    IF (NVL(L_ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                      DBG('Total Amount greater than available balance...calculating limit balance amount...');
                      IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                        L_LIM_BAL := NVL(L_ACC_BAL, 0) -
                                     NVL(L_ACY_AVL_BAL, 0);
                      ELSE
                        L_LIM_BAL := NVL(L_ACC_BAL, 0);
                      END IF;
                    END IF;
                    IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                      DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                          L_LIM_BAL || ' balance Td amount ' ||
                          L_BAL_MULTIMODE);
                      L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                     .MULTIMODE_TDOFFSET_ACC;
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   'FLEXCUBE',
                                   'ST-ACC-010',
                                   L_ERR_PARAM);

                    ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                      IF L_EXPIRY_COUNT > 0 THEN
                        DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                            L_LIM_BAL || ' balance Td amount ' ||
                            L_BAL_MULTIMODE);
                        L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                       .MULTIMODE_TDOFFSET_ACC;
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     'FLEXCUBE',
                                     'ST-ACC-012',
                                     L_ERR_PARAM);
                      ELSE
                        DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                            L_LIM_BAL || ' balance Td amount ' ||
                            L_BAL_MULTIMODE);
                        L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                       .MULTIMODE_TDOFFSET_ACC;
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     'FLEXCUBE',
                                     'ST-ACC-011',
                                     L_ERR_PARAM);
                      END IF;
                    END IF;
                  END IF;

                ELSE
                  OFFSETFCY_AMOUNT := NULL;
                  OFFSET_XRATE     := NULL;
                  DBG('its in the else part of forign currency');

                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                    L_FN_CALL_ID := 3;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('i') := I;
                    L_TB_CLUSTER_DATA('OFFSET_XRATE') := OFFSET_XRATE;
                    DBG('Inside 11, function id is ' || P_FUNCTION_ID);
                    DBG('Inside 11, the value of I is  ' ||
                        L_TB_CLUSTER_DATA('i'));
                    IF NOT
                        STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_VALIDATE(P_FUNCTION_ID,
                                                                          P_ACTION_CODE,
                                                                          P_STDCUSAC,
                                                                          P_ERR_FLAG,
                                                                          L_FN_CALL_ID,
                                                                          L_TB_CLUSTER_DATA) THEN
                      DBG('11 Failed in stpks_stdcusac_utils_cluster.fn_payinout_validate');
                      RETURN FALSE;
                    END IF;

                    OFFSET_XRATE := L_TB_CLUSTER_DATA('OFFSET_XRATE');
                    DBG('The value of offset_xrate tarun is ' ||
                        OFFSET_XRATE);

                  END IF;

                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS (I).BRN,
                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                     P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS (I)
                                                     .MULTIMODE_TDOFFSET_CCY,
                                                     P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS (I)
                                                     .MULTIMODE_TDAMOUNT,
                                                     'Y',
                                                     OFFSETFCY_AMOUNT,
                                                     OFFSET_XRATE,
                                                     P_ERR_FLAG) THEN
                    DBG('failed');
                    DBG(SQLERRM);
                    RETURN FALSE;
                  END IF;
                  DBG('so comparing acc avl bal with offset fcy amt...as this will hv the td offset amt in ac ccy...');

                  IF (NVL(L_ACY_AVL_BAL, 0) < NVL(OFFSETFCY_AMOUNT, 0)) THEN

                    DBG('TD Amount greater than available balance...calculating balance amount...');
                    IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                      L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0) -
                                         NVL(L_ACY_AVL_BAL, 0);
                    ELSE
                      L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0);
                    END IF;
                    IF (NVL(L_ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                      DBG('Total Amount greater than available balance...calculating limit balance amount...');
                      IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                        L_LIM_BAL := NVL(L_ACC_BAL, 0) -
                                     NVL(L_ACY_AVL_BAL, 0);
                      ELSE
                        L_LIM_BAL := NVL(L_ACC_BAL, 0);
                      END IF;
                    END IF;
                    IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                      DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                          L_LIM_BAL || ' balance Td amount ' ||
                          L_BAL_MULTIMODE);
                      L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                     .MULTIMODE_TDOFFSET_ACC;
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   'FLEXCUBE',
                                   'ST-ACC-010',
                                   L_ERR_PARAM);

                    ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                      IF L_EXPIRY_COUNT > 0 THEN
                        DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                            L_LIM_BAL || ' balance Td amount ' ||
                            L_BAL_MULTIMODE);
                        L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                       .MULTIMODE_TDOFFSET_ACC;
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     'FLEXCUBE',
                                     'ST-ACC-012',
                                     L_ERR_PARAM);
                      ELSE
                        DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                            L_LIM_BAL || ' balance Td amount ' ||
                            L_BAL_MULTIMODE);
                        L_ERR_PARAM := P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                       .MULTIMODE_TDOFFSET_ACC;
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     'FLEXCUBE',
                                     'ST-ACC-011',
                                     L_ERR_PARAM);
                      END IF;
                    END IF;
                  END IF;

                END IF;
              END IF;
            END IF;
          END LOOP;
        END IF;

      END IF;

      IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN

        BEGIN
          SELECT PAYMENT_METHOD
            INTO L_PAY_MTHD
            FROM ICTM_PR_INT
           WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error while selecting payment method' || SQLERRM);
        END;
        IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' AND
           NVL(L_PAY_MTHD, 'B') = 'D' THEN
          DBG('Pay in option cannot be given as Cheque for Discounted Deposit');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-550', '');
          P_ERR_FLAG := -1;
        END IF;

        DBG('looping for payin details');
        FOR I IN P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.LAST LOOP

          DBG('Account type-->' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE);
          DBG('payin--->' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21);

          DBG('p_stdcusac.v_ictms_tdpayin_details(i).CLG_PRODUCT_CODE ;;;' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
              .CLG_PRODUCT_CODE);
          IF (GWPKS_UTIL.PKG_FUNC = 'TDMM' AND
             P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q') THEN
            BEGIN
              SELECT SECTOR_CODE
                INTO L_SECTORCODE
                FROM DETM_CLG_BRN_CODE
               WHERE BANK_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .CLG_BANK_CODE
                 AND BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .CLG_BRANCH_CODE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('Sector code not exists for the current clearing bank and branch');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-243', '');
                RETURN FALSE;
              WHEN OTHERS THEN
                DBG('failed in when others ' || SQLERRM);
                RETURN FALSE;
            END;
            DBG('l_sectorcode-->' || L_SECTORCODE);
            DBG('CLG_PRODUCT_CODE' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CLG_PRODUCT_CODE);

            IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS         (I)
                                                          .CLG_BANK_CODE,
                                                          P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS         (I)
                                                          .CLG_BRANCH_CODE,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                          P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS         (I)
                                                          .CLG_PRODUCT_CODE,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                          NULL,
                                                          L_SECTORCODE,
                                                          L_CRVALDT,
                                                          L_DRVALDT,
                                                          L_LATE_CLEARING,
                                                          L_ERR_CODE,
                                                          GLOBAL.APPLICATION_DATE,
                                                          'N',
                                                          'N') THEN

              DBG('failed to get the Value date');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR_CODE, '');
              RETURN FALSE;
            ELSE
              DBG('l_Crvaldt = ' || L_CRVALDT);
              IF CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          L_CRVALDT,
                                          L_RESULT) = TRUE THEN
                DBG('Cheque clearing date is holiday = ' || L_RESULT);
                IF NVL(L_RESULT, '*') = 'H' THEN
                  L_CRVALDT := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                            L_CRVALDT,
                                                            'N');
                  DBG('Working date --> ' || L_CRVALDT);
                END IF;
              END IF;
              DBG('value date is the account opening date' || L_CRVALDT);
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := L_CRVALDT;
            END IF;
          END IF;

          IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' AND
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' THEN
            IF (P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_PAYOPT = 'Q' AND
                (P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CHQ_INSTUMENTNO <>
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD22 OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CLG_BANK_CODE <> P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23 OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CLG_BRANCH_CODE <>
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25 OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CLG_PRODUCT_CODE <>
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD48 OR

                P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .DRAWEE_AC_NO <> P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD50 OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .ROUTING_NO <> P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD47 OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .CHQ_INSTRUMENT_DATE <>
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD2)) OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
              .MULTIMODE_PAYOPT <> 'Q' THEN
              DBG('USER CANT CHANGE THE PAYIN DETAILS');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-240', '');
              P_ERR_FLAG := -1;
              RETURN FALSE;
            END IF;

          ELSIF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'O' AND
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'Q' THEN
              DBG('while pay in option is others in main tab..so in deposit tab user cant select cheque');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-241', '');
              P_ERR_FLAG := -1;
              RETURN FALSE;
            END IF;
          END IF;

          L_PAYIN_TOTAL := L_PAYIN_TOTAL + P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                          .MULTIMODE_TDAMOUNT;

          IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
           .MULTIMODE_PERCENTAGE IS NOT NULL THEN
            L_PAYIN_PERCENTAGE := L_PAYIN_PERCENTAGE + P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                 .MULTIMODE_PERCENTAGE;
          END IF;

          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 1;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            IF NOT
                STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_VALIDATE(P_FUNCTION_ID,
                                                                  P_ACTION_CODE,
                                                                  P_STDCUSAC,
                                                                  P_ERR_FLAG,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
              DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_validate');
              RETURN FALSE;
            END IF;
          END IF;
          IF NOT GLOBAL.G_SKIP_KERNEL THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
             .MULTIMODE_PAYOPT NOT IN ('S', 'G', 'C', 'Y', 'Q') OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_PAYOPT IS NULL THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-TD-100',
                           '@ICTMS_TD_DETAILS.PAYIN_OPTION~');
              P_ERR_FLAG := -1;
            END IF;

          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;

          IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'S' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
             .MULTIMODE_OFFSET_BRN IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_ACC IS NULL THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-129', '');
              P_ERR_FLAG := -1;
            END IF;
            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_BRANCH
             WHERE BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_OFFSET_BRN
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
            IF L_COUNT = 0 THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-115',
                           '@ICTMS_TD_DETAILS.OFFSET_BRN~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                           .MULTIMODE_OFFSET_BRN || '~');
              P_ERR_FLAG := -1;
            END IF;
            DBG('p_stdcusac.v_ictms_tdpayin_details(i).multimode_tdoffset_acc: ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_TDOFFSET_ACC);
            DBG('p_stdcusac.v_ictms_tdpayin_details(i).multimode_offset_brn: ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_OFFSET_BRN);

            IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN
              IF NOT ICPKS_BOD.G_CHILDTD THEN
                BEGIN
                  SELECT NVL(AC_STAT_FROZEN, 'N'),
                         NVL(AC_STAT_NO_DR, 'N')

                        ,
                         NVL(C.AC_STAT_DORMANT, 'N'),
                         AC_OPEN_DATE
                    INTO L_AC_STAT_FROZEN,
                         L_AC_STAT_NO_DR,
                         L_AC_STAT_DORMANT,
                         L_AC_OPEN_DATE
                    FROM STTMS_CUST_ACCOUNT B, STTM_ACCOUNT_BALANCE C
                   WHERE

                   B.BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_OFFSET_BRN
                   AND B.ACCOUNT_TYPE <> 'Y'
                   AND B.AUTH_STAT = 'A'
                   AND B.RECORD_STAT = 'O'
                   AND B.CUST_AC_NO = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDOFFSET_ACC
                   AND C.CUST_AC_BRN = B.BRANCH_CODE
                   AND C.CUST_AC_NO = B.CUST_AC_NO

                  ;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-115',
                                 '@ICTMS_TD_DETAILS.OFFSET_ACC~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                 .MULTIMODE_TDOFFSET_ACC || '~');

                END;

                DBG('l_ac_open_date --> ' || L_AC_OPEN_DATE);
                DBG('p_stdcusac.v_ictms_acc.int_start_date --> ' ||
                    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
                IF L_AC_OPEN_DATE > P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
                  L_ERR_PARAM := L_AC_OPEN_DATE || '~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                .MULTIMODE_TDOFFSET_ACC || '~' ||
                                 P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~;';
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'AC-VAC11',
                               L_ERR_PARAM);
                END IF;

                IF L_AC_STAT_FROZEN = 'Y' THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'AC-VAC04',
                               '@ICTMS_TD_DETAILS.OFFSET_ACC~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                               .MULTIMODE_TDOFFSET_ACC || '~');

                END IF;

                IF L_AC_STAT_NO_DR = 'Y' THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'AC-VAC07',
                               '@' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                               .MULTIMODE_TDOFFSET_ACC || '~');

                END IF;

                IF L_AC_STAT_DORMANT = 'Y' THEN
                  DBG('Dormant account');
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'AC-VAC05',
                               P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                               .MULTIMODE_TDOFFSET_ACC);
                END IF;

              END IF;
            END IF;
            SAV_COUNT := SAV_COUNT + 1;
          ELSIF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'G' THEN
            GL_COUNT := GL_COUNT + 1;
          ELSIF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'C' THEN
            CASHGL_COUNT := CASHGL_COUNT + 1;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'Q' THEN
            DBG('INKE');
            DBG(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CHQ_INSTUMENTNO);
            DBG(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CHQ_INSTRUMENT_DATE);
            DBG(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CLG_BANK_CODE);
            DBG(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CLG_BRANCH_CODE);
            DBG(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CLG_PRODUCT_CODE);

            DBG('following check is specific for flexbranch');

            IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CHQ_INSTRUMENT_DATE > GLOBAL.APPLICATION_DATE THEN

                DBG('Cheque date cannot be greater than today');

                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-VALS-002', '');
                RETURN FALSE;
              END IF;
            END IF;

            CHEQUE_COUNT := CHEQUE_COUNT + 1;
            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
             .CHQ_INSTUMENTNO IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CLG_BANK_CODE IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CLG_BRANCH_CODE IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CLG_PRODUCT_CODE IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CHQ_INSTRUMENT_DATE IS NULL THEN
              P_ERR_FLAG := -1;
              DBG('Cheque Instrument no,Clearing Bank Code and Clearing Branch Code,Clearing Product,Cheque date is mandatory');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-250',
                           'Cheque Instrument no,Clearing Bank Code,Clearing Branch Code,Clearing Product,Cheque date');
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'Y' THEN
            DBG('validation for TD account needs to be added here');
          END IF;

          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 2;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            IF NOT
                STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_VALIDATE(P_FUNCTION_ID,
                                                                  P_ACTION_CODE,
                                                                  P_STDCUSAC,
                                                                  P_ERR_FLAG,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
              DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_validate');
              RETURN FALSE;
            END IF;
          END IF;
          IF NOT GLOBAL.G_SKIP_KERNEL THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT <> 'Q' THEN
              DBG('not cheque');
              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .CHQ_INSTUMENTNO IS NOT NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .CLG_BANK_CODE IS NOT NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .CLG_BRANCH_CODE IS NOT NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .CLG_PRODUCT_CODE IS NOT NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .CHQ_INSTRUMENT_DATE IS NOT NULL THEN
                DBG('Cheque Instrument no,Clearing Bank Code and Clearing Branch Code should be null while Payin option is not Cheque.');
                P_ERR_FLAG := -1;

                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-342', '');

              END IF;
            END IF;

          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;

        END LOOP;
      ELSE
        DBG('No payin details entered');
        P_ERR_FLAG := -1;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-197', '');
      END IF;
      IF GL_COUNT > 1 OR CASHGL_COUNT > 1 THEN
        DBG('payin for GL or Cash cannot be greater than 1');
        P_ERR_FLAG := -1;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-214', '');
      END IF;

      DBG('cheque_count-->' || CHEQUE_COUNT);
      DBG('sav_count-->' || SAV_COUNT);
      DBG('gl_count-->' || GL_COUNT);
      DBG('cashgl_count -->' || CASHGL_COUNT);

      IF CHEQUE_COUNT > 1 THEN
        DBG('Payin Option Cannot be Greater than one with Cheque');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-254', '');
        P_ERR_FLAG := -1;
        RETURN FALSE;
      END IF;

      IF CHEQUE_COUNT >= 1 AND
         (SAV_COUNT >= 1 OR GL_COUNT >= 1 OR CASHGL_COUNT >= 1) THEN
        DBG('Other Payin Options not allowed while Payin option Cheque Selected.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-255', '');
        P_ERR_FLAG := -1;
        RETURN FALSE;
      END IF;

      DBG('l_payin_total is :' || L_PAYIN_TOTAL);

      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') != 'Y' THEN
        IF L_PAYIN_TOTAL <> P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT THEN
          DBG('Payin Details is not equal to TD book amount');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-206', '');
        END IF;
      END IF;

      DBG('l_payin_percentage is :' || L_PAYIN_PERCENTAGE);

      IF NOT (L_PAYIN_PERCENTAGE = 0 OR L_PAYIN_PERCENTAGE = 100) THEN
        DBG('Total Payin Percentage is not consistent');
        P_ERR_FLAG := -1;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-207', '');
      END IF;
    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
      FOR EACH_REC IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC).PAYOUTTYPE = 'Y' THEN
          DBG('PERCENT' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
              .PERCENTAGE);
          DBG('td amount' || P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);
          DBG('rolover amount' ||
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.ROLLOVER_AMT);
          IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.ROLLOVER_AMT >
             (P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
             .PERCENTAGE * P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT / 100) THEN
            DBG('inlet and outlet sould have same amount');

            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTH-X02', '');

          END IF;
        END IF;
      END LOOP;
    END IF;

    DBG('Second checking for v_ictms_tdpayout_details count :' ||
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);

    IF (P_FUNCTION_ID = 'STDCUSTD' OR P_FUNCTION_ID = 'STDTDSIM') OR
       GWPKS_UTIL.PKG_FUNC IN ('TDMM', 'IPTDMM') THEN
      BEGIN
        SELECT DENM_DEPOSIT
          INTO L_DENDEP_FLG
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No data found for denom deposit');
      END;
      DBG('l_dendep_flg-->' || L_DENDEP_FLG);
      IF NVL(L_DENDEP_FLG, 'N') = 'Y' AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE THEN

        IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0

         THEN
          FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
            IF NVL(P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT,
                   '#') = 'I' THEN
              DBG('Denom int book acc validation skipped as atleast one payout component available for I and rollover is principal only');
              L_DENOM_VALID_FLAG := TRUE;
            END IF;
          END LOOP;
        END IF;
        IF NOT L_DENOM_VALID_FLAG THEN

          DBG('For Denominated Deposits, Interest Booking Account cannot be same as the TD account');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DNDP-22', '');
        END IF;
      END IF;
    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN

      BEGIN
        SELECT PAYMENT_METHOD
          INTO L_PAY_MTHD
          FROM ICTM_PR_INT
         WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Error while selecting payment method' || SQLERRM);
      END;

      IF NVL(L_PAY_MTHD, 'B') = 'D' AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE THEN
        DBG('For Discounted Deposits, Interest Booking Account cannot be same as the TD account');
        P_ERR_FLAG := -1;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-461', '');
      END IF;

      FOR EACH_REC IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP

        IF NVL(L_PAY_MTHD, 'B') = 'D' AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
          .PAYOUT_COMPONENT = 'I' THEN
          DBG('Payout details should not be entered for Discounted Deposits');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-460', '');
          EXIT;
        END IF;

        IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
         .PAYOUTTYPE = 'Y' AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
           .PAYOUT_COMPONENT = 'I' THEN
          DBG('Interest payout is not applicable for Payout Option Term Deposit.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-400', '');
          P_ERR_FLAG := -1;
          EXIT;
        END IF;

        IF NVL(P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER, 'N') = 'Y' AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE, 'P') IN ('T', 'I') AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
          .PAYOUT_COMPONENT = 'I' THEN
          DBG('Interest payout is not applicable for Rollover type as Interest and Principal+Interest.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-401', '');
          P_ERR_FLAG := -1;
          EXIT;
        END IF;

      END LOOP;
    END IF;

    IF (P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' OR
       P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y') THEN
      IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
        DBG('looping for v_ictms_tdpayout_details ');
        FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP

          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PERCENTAGE IS NOT NULL THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_PAYOUT_PERCENTAGE := L_PAYOUT_PERCENTAGE + P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                    .PERCENTAGE;
            ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .PAYOUT_COMPONENT = 'I' THEN
              L_PAYOUT_INT_PERCENTAGE := L_PAYOUT_INT_PERCENTAGE + P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                        .PERCENTAGE;
            END IF;

          ELSE
            DBG('Payout percentage cannot be null');
            P_ERR_FLAG := -1;
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-208', '');
          END IF;

          DBG('Validating princ liq brn');

          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'S' THEN
            IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
              IF (P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                 .OFFSET_BRN IS NULL) THEN

                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-121', '');
                P_ERR_FLAG := -1;
              END IF;
            END IF;
            DBG('----------9-----------');
            IF (P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N') THEN
              IF (P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                 .OFFSET_BRN IS NULL) THEN

                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-121', '');
                P_ERR_FLAG := -1;
              END IF;
            END IF;
          END IF;

          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'Y' THEN
            IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.AUTO_ROLLOVER = 'N' AND
               P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.CLOSE_ON_MATURITY = 'N' AND
               P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MOVE_INT_TO_UNCLAIMED = 'N' AND
               P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MOVE_PRIC_TO_UNCLAIMED = 'N' THEN
              DBG('TD Mandatory Check Failed');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-0012', '');

              P_ERR_FLAG := -1;
            END IF;
          END IF;

        END LOOP;

        IF L_PAYOUT_PERCENTAGE <> 100 AND L_PAYOUT_PERCENTAGE <> 0 THEN
          DBG('Total Payout Percentage is not equal to cent');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-209', '');
        END IF;

        IF L_PAYOUT_INT_PERCENTAGE <> 100 AND L_PAYOUT_INT_PERCENTAGE <> 0 THEN
          DBG('Total Payout Percentage for interest component is not equal to cent');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-402', '');
        END IF;

      END IF;

    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
      FOR EACH_REC IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        IF P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
          .PAYOUT_COMPONENT = 'P' THEN
          DBG('Cannot have Payout option when Move Principal to Unclaimed is Selected');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-212', '');
          EXIT;
        END IF;
      END LOOP;
      FOR EACH_REC IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        IF P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
          .PAYOUT_COMPONENT = 'I' THEN
          DBG('Cannot have Payout option when Move Interest to Unclaimed is Selected');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-260', '');
          EXIT;
        END IF;
      END LOOP;
    END IF;

    RETURN TRUE;
  END FN_PAYINOUT_VALIDATE;

  FUNCTION FN_PAYINOUT_DEFAULT(P_FUNCTION_ID IN VARCHAR2,
                               P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ACTION_CODE IN VARCHAR2,
                               P_SOURCE      IN VARCHAR2,
                               P_ERR_FLAG    IN OUT NUMBER) RETURN BOOLEAN IS
    L_GL_CODE STTMS_PAYIN_MODE.GL_CODE%TYPE;

    L_SAVACC_CNT NUMBER := 0;
    L_CCY_RES    VARCHAR2(1);
    L_CCY_S      VARCHAR2(3);
    L_LOCAL_CCY  VARCHAR2(3);
    L_COUNT      NUMBER := 0;
    L_CNT        NUMBER := 0;

    L_ROW_AMT NUMBER(22, 3) := 0;
    L_TOTAL   NUMBER(22, 3) := 0;

    L_BC_CNT   NUMBER := 0;
    L_PC_CNT   NUMBER := 0;
    L_TD_CNT   NUMBER := 0;
    L_GL_CNT   NUMBER := 0;
    L_CASH_CNT NUMBER := 0;
    L_INSEQNO  NUMBER := 1;
    L_OUTSEQNO NUMBER := 1;

    L_BC_INT_CNT   NUMBER := 0;
    L_PC_INT_CNT   NUMBER := 0;
    L_GL_INT_CNT   NUMBER := 0;
    L_CASH_INT_CNT NUMBER := 0;

    L_CASH_GL   DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_WF_ROW    STTMS_BRANCH_WF_DEF_MASTER%ROWTYPE;
    L_ONCE_AUTH STTM_CUST_ACCOUNT.ONCE_AUTH%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_BC_CNT_FLG BOOLEAN := FALSE;
    L_DD_CNT_FLG BOOLEAN := FALSE;

  BEGIN
    DBG('Inside fn_payinout_default ' ||
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
    BEGIN
      SELECT NVL(MAX(SEQNO), 1)
        INTO L_INSEQNO
        FROM ICTM_TDPAYIN_DETAILS
       WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_INSEQNO := 1;
      WHEN OTHERS THEN
        DBG('Failed to index the payin details');
        RETURN FALSE;
    END;

    DBG('Payin seq no : ' || L_INSEQNO);
    BEGIN
      SELECT NVL(MAX(SEQNO), 1)
        INTO L_OUTSEQNO
        FROM ICTM_TDPAYOUT_DETAILS
       WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_OUTSEQNO := 1;
      WHEN OTHERS THEN
        DBG('Failed to index the payin details');
        RETURN FALSE;
    END;
    DBG('payout seq no : ' || L_OUTSEQNO);

    DBG('First checking for v_ictms_tdpayin_details count :' ||
        P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
    DBG('p_stdcusac.v_ictms_acc.rd_flag :' ||
        P_STDCUSAC.V_ICTMS_ACC.RD_FLAG);
    IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG <> 'Y' THEN

      IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN

        BEGIN
          SELECT ONCE_AUTH
            INTO L_ONCE_AUTH
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ONCE_AUTH := 'N';
        END;
        DBG('l_once_auth--> ' || L_ONCE_AUTH);
        IF NOT (P_ACTION_CODE = 'MODIFY' AND L_ONCE_AUTH = 'Y') THEN

          DBG('looping for payin details');
          FOR I IN P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.LAST LOOP
            DBG('payin loop count :' || I);
            DBG('payin Seq cnt :' || L_INSEQNO);
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).SEQNO := L_INSEQNO;

            DBG('multimode_tdamount :' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_TDAMOUNT);
            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
             .MULTIMODE_TDAMOUNT IS NULL THEN
              DBG('multimode_percentage :' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PERCENTAGE);

              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_PERCENTAGE IS NOT NULL THEN
                IF I = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT THEN
                  P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT -
                                                                              L_TOTAL;
                ELSE
                  L_ROW_AMT := (P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                               .MULTIMODE_PERCENTAGE *
                                P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT) /
                               100.00;
                  L_TOTAL := L_TOTAL + L_ROW_AMT;
                  P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := L_ROW_AMT;
                END IF;
              ELSE
                DBG('Both Percentage or Payin Amount cannot be null');
                P_ERR_FLAG := -1;
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-210', '');
              END IF;
            END IF;
            DBG('l_total :' || L_TOTAL);
            DBG('multimode_tdamount for ' || I || 'row is  :' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_TDAMOUNT);

            IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
             .MULTIMODE_PAYOPT NOT IN ('S', 'Y') THEN
              DBG('Payin Option: ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PAYOPT);

              IF ((P_ACTION_CODE = 'CREATE' AND
                 NOT (GWPKS_UTIL.G_FROM_BEAN)) AND
                 (P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .MULTIMODE_OFFSET_BRN IS NOT NULL OR P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .MULTIMODE_TDOFFSET_ACC IS NOT NULL)) THEN
                DBG('Cannot Enter Offset Account and Branch');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-180', '');
                P_ERR_FLAG := -1;
                RETURN FALSE;
              END IF;

              DBG('Selecting GL code from the branch for pay in option : ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PAYOPT);
              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_PAYOPT <> 'Q' THEN

                GLOBAL.PR_RESET_SKIP_KERNEL;
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                  L_FN_CALL_ID := 2;
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                  L_TB_CLUSTER_DATA('i') := I;
                  IF NOT
                      STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_DEFAULT(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       P_ACTION_CODE,
                                                                       P_SOURCE,
                                                                       P_ERR_FLAG,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA) THEN
                    DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
                    RETURN FALSE;
                  END IF;
                  IF L_TB_CLUSTER_DATA.EXISTS('l_gl_code') THEN
                    L_GL_CODE := L_TB_CLUSTER_DATA('l_gl_code');
                  END IF;

                END IF;

                BEGIN
                  IF NOT GLOBAL.G_SKIP_KERNEL THEN

                    BEGIN
                      SELECT GL_CODE
                        INTO L_GL_CODE
                        FROM STTMS_PAYIN_MODE
                       WHERE BRANCH_CODE =
                             P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN
                         AND PAYIN_OPTION = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                            .MULTIMODE_PAYOPT
                         AND AUTH_STAT = 'A'
                         AND RECORD_STAT = 'O';

                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                         .MULTIMODE_PAYOPT = 'C' THEN
                          DBG('GL not maintained in STDPAYIN for cash');
                        ELSE
                          DBG('GL not maintained');
                          PR_LOG_ERROR(P_FUNCTION_ID,
                                       'FLEXCUBE',
                                       'ST-ACC-120',
                                       P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                       .MULTIMODE_PAYOPT || '~');
                          P_ERR_FLAG := -1;
                          RETURN FALSE;
                        END IF;
                    END;

                  ELSE
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  END IF;

                  DBG('p_Source = ' || P_SOURCE);
                  IF P_SOURCE IN ('FLEXBRANCH') THEN
                    IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                     .MULTIMODE_PAYOPT = 'C' THEN

                      DBG('Cash GL check Starts');

                      IF NOT CSPKSS_ARC.FN_GET_WF_ROW(P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN,
                                                      GWPKS_UTIL.PKG_FUNC,
                                                      L_WF_ROW) THEN
                        PR_LOG_ERROR(P_FUNCTION_ID,
                                     'FLEXCUBE',
                                     'ST-ACC-256',
                                     P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                     .MULTIMODE_PAYOPT || '~');
                        P_ERR_FLAG := -1;
                        RETURN FALSE;
                      END IF;

                      DBG('l_wf_row.cash_txn ' || L_WF_ROW.CASH_TXN);

                      GLOBAL.PR_RESET_SKIP_KERNEL;
                      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                         (CSPKS_REQ_GLOBAL.P_CLUSTER,
                          CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                        L_FN_CALL_ID := 3;
                        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                        L_TB_CLUSTER_DATA('i') := I;
                        IF NOT
                            STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_DEFAULT(P_FUNCTION_ID,
                                                                             P_STDCUSAC,
                                                                             P_ACTION_CODE,
                                                                             P_SOURCE,
                                                                             P_ERR_FLAG,
                                                                             L_FN_CALL_ID,
                                                                             L_TB_CLUSTER_DATA) THEN
                          DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
                          RETURN FALSE;
                        END IF;
                        IF L_TB_CLUSTER_DATA.EXISTS('l_gl_code') THEN
                          L_GL_CODE := L_TB_CLUSTER_DATA('l_gl_code');
                        END IF;

                      END IF;
                      IF NOT GLOBAL.G_SKIP_KERNEL THEN

                        IF (GWPKS_UTIL.G_FROM_BEAN AND
                           L_WF_ROW.CASH_TXN = 'Y') THEN
                          BEGIN
                            SELECT CASH_GL
                              INTO L_CASH_GL
                              FROM DETMS_TIL_VLT_CCY_PARAMS A,
                                   DETM_TIL_VLT_MASTER      B
                             WHERE A.BRANCH_CODE = B.BRANCH_CODE
                               AND A.TILL_ID = B.TILL_ID
                               AND A.BRANCH_CODE =
                                   P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN

                               AND A.TILL_ID = CSPKS_ARC.G_TILL_ID
                               AND A.CCY_CD =
                                   P_STDCUSAC.V_ICTMS_TD_DETAILS.CCY

                               AND AUTH_STAT = 'A'
                               AND RECORD_STAT = 'O';

                            IF L_CASH_GL IS NOT NULL THEN
                              L_GL_CODE := L_CASH_GL;
                            END IF;
                          EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                              DBG('TILL is not maintained');
                          END;
                        END IF;

                      ELSE
                        GLOBAL.PR_RESET_SKIP_KERNEL;
                      END IF;

                    END IF;

                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                       (CSPKS_REQ_GLOBAL.P_CLUSTER,
                        CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                      L_FN_CALL_ID := 1;
                      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                      L_TB_CLUSTER_DATA('i') := I;
                      IF NOT
                          STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_DEFAULT(P_FUNCTION_ID,
                                                                           P_STDCUSAC,
                                                                           P_ACTION_CODE,
                                                                           P_SOURCE,
                                                                           P_ERR_FLAG,
                                                                           L_FN_CALL_ID,
                                                                           L_TB_CLUSTER_DATA) THEN
                        DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
                        RETURN FALSE;
                      END IF;
                      IF L_TB_CLUSTER_DATA.EXISTS('l_gl_code') THEN
                        L_GL_CODE := L_TB_CLUSTER_DATA('l_gl_code');
                      END IF;

                    END IF;

                  END IF;
                  P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_OFFSET_BRN := P_STDCUSAC.V_ICTMS_ACC.BRN;
                  P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDOFFSET_ACC := L_GL_CODE;
                  DBG('Offset GL for Option: ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_TDOFFSET_ACC);
                  DBG('Offset BRN  for Option: ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_OFFSET_BRN);

                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('GL Code is not maintained');
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-120',
                                 P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                 .MULTIMODE_PAYOPT || '~');
                    P_ERR_FLAG := -1;
                    RETURN FALSE;
                  WHEN OTHERS THEN
                    DBG('GL Code is not maintained: ' || SQLERRM);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-120',
                                 P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN || '~' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                 .MULTIMODE_PAYOPT || '~');
                    P_ERR_FLAG := -1;
                    RETURN FALSE;
                END;

                BEGIN
                  DBG('Selecting the GL from gl master');
                  SELECT CCY_RES, RES_CCY
                    INTO L_CCY_RES, L_CCY_S
                    FROM GLTMS_GLMASTER
                   WHERE GL_CODE = L_GL_CODE
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A';
                  DBG('Currency Restriction :' || L_CCY_RES ||
                      'Allowed Currency:' || L_CCY_S);
                  SELECT BRANCH_LCY
                    INTO L_LOCAL_CCY
                    FROM STTMS_BRANCH
                   WHERE BRANCH_CODE =
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  DBG('The Local Currency of the Branch:' || L_LOCAL_CCY);
                  IF (NVL(L_CCY_RES, '#') = 'F' AND
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY = L_LOCAL_CCY) OR
                     (NVL(L_CCY_RES, '#') = 'S' AND
                     L_CCY_S <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY) THEN
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'AC-VGL01',
                                 L_GL_CODE || '~' ||
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY || '~');
                    P_ERR_FLAG := -1;
                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In WOT of select statement in fn_deposit_def_validate with: ' ||
                        SQLERRM || ' and trace: ' ||
                        DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-UPCA0033',
                                 '');
                    P_ERR_FLAG := -1;
                END;
              END IF;
            END IF;
            L_INSEQNO := L_INSEQNO + 1;
          END LOOP;
        END IF;
      ELSE
        DBG('No payin details entered');
        P_ERR_FLAG := -1;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-197', '');
      END IF;

    ELSIF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'Y' AND
          P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
      DBG('Payin details cannot b eadded to RD');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-297', '');

    END IF;

    IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'Y' AND
       (P_STDCUSAC.V_ICTMS_ACC.INTRATE_CUMAMT_REQD = 'Y' OR
       P_STDCUSAC.V_ICTMS_ACC.INTRATE_CUMAMT_ROLL_REQD = 'Y') THEN
      DBG('Interest rate based on cumulative amount feature is not supported for recurring deposits');

      PR_LOG_ERROR(P_FUNCTION_ID,
                   P_SOURCE,
                   'TD-DDEP-06',
                   'Interest rate based on cumulative amount feature is not supported for recurring deposits');
    END IF;

    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99  := NULL;
    P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99  := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD98  := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100 := NULL;
    P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100 := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD96  := NULL;
    P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD97  := NULL;

    IF (P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' OR
       P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y') THEN
      IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
        DBG('looping for v_ictms_tdpayout_details ');
        FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
          DBG('payout loop count :' || I);
          DBG('payout Seq cnt :' || L_OUTSEQNO);
          DBG('payout component' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
              .PAYOUT_COMPONENT);
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT := NVL(P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                         .PAYOUT_COMPONENT,
                                                                         'P');
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO := L_OUTSEQNO;

          DBG('Validating princ liq brn');
          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'S' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_BRN IS NULL THEN
              DBG('Liquidation Branch Can not be NULL.');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-MAN01',
                           '@ICTMS_ACC.PRINC_LIQ_BRANCH~');

              P_ERR_FLAG := -1;
            END IF;

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .OFFSET_ACC IS NOT NULL AND P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
               .OFFSET_BRN IS NOT NULL THEN
              DBG('Valiating Pricipal Liqn Acc');

              SELECT COUNT(*)
                INTO L_CNT
                FROM STTMS_CUST_ACCOUNT
               WHERE (BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                     .OFFSET_BRN AND ACCOUNT_TYPE <> 'Y' AND
                     AUTH_STAT = 'A' AND RECORD_STAT = 'O' AND CUST_AC_NO = P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                     .OFFSET_ACC);

              DBG('l_cnt ->' || L_CNT);

              IF L_CNT = 0 THEN
                DBG('Entered count is zero before calling cluster');
                GLOBAL.PR_RESET_SKIP_KERNEL;
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                  L_FN_CALL_ID := 4;
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                  L_TB_CLUSTER_DATA('i') := I;

                  IF NOT
                      STPKS_STDCUSAC_UTILS_CLUSTER.FN_PAYINOUT_DEFAULT(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       P_ACTION_CODE,
                                                                       P_SOURCE,
                                                                       P_ERR_FLAG,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA) THEN
                    DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
                    RETURN FALSE;
                  END IF;

                  IF L_TB_CLUSTER_DATA.EXISTS('l_cnt') THEN
                    L_CNT := L_TB_CLUSTER_DATA('l_cnt');
                  END IF;
                  DBG('entered to check');
                END IF;
                DBG('After cluster' || L_CNT);
                GLOBAL.PR_RESET_SKIP_KERNEL;
              END IF;

              IF L_CNT = 0 THEN
                DBG('Liq Account Validation Failed.');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'ST-ACC-115',
                             '@ICTMS_ACC.PRINC_LIQ_ACC~' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                             .OFFSET_ACC || '~');
                P_ERR_FLAG := -1;
              END IF;
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
           .PAYOUTTYPE IN ('B', 'D') THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'B' THEN
              DBG('payout type is BC, Hence assigning BC flg');
              L_BC_CNT_FLG := TRUE;
            ELSE
              DBG('payout type is DD, Hence assigning DD flg');
              L_DD_CNT_FLG := TRUE;
            END IF;

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_BC_CNT                                                         := L_BC_CNT + 1;
              P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99           := 'U';
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT      := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PERCENTAGE;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY              := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE         := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.PAYOUT_COMPONENT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PAYOUT_COMPONENT;
            ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .PAYOUT_COMPONENT = 'I' THEN
              L_BC_INT_CNT                                                     := L_BC_INT_CNT + 1;
              P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99           := 'U';
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_PERCENT      := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PERCENTAGE;
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.CCY              := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.CHQ_DATE         := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.PAYOUT_COMPONENT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PAYOUT_COMPONENT;
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'C' THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_CASH_CNT := L_CASH_CNT + 1;
            ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .PAYOUT_COMPONENT = 'I' THEN
              L_CASH_INT_CNT := L_CASH_INT_CNT + 1;
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'G' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC IS NULL THEN
              DBG('Liquidation GL Cannot be NULL.');
              P_ERR_FLAG := -1;
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-215', '');
            END IF;

            BEGIN
              SELECT COUNT(*)
                INTO L_CNT
                FROM GLTM_GLMASTER
               WHERE GL_CODE = P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                    .OFFSET_ACC
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';
            END;
            IF L_CNT = 0 THEN
              DBG('Liq Account Validation Failed for GL');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-115',
                           '@ICTMS_ACC.PRINC_LIQ_ACC~' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                           .OFFSET_ACC || '~');
              P_ERR_FLAG := -1;
            END IF;

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_GL_CNT := L_GL_CNT + 1;
            ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .PAYOUT_COMPONENT = 'I' THEN
              L_GL_INT_CNT := L_GL_INT_CNT + 1;
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'Y' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_TD_CNT := L_TD_CNT + 1;

              P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD98      := 'U';
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.PERCENTAGE   := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                             .PERCENTAGE;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.CCY          := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.AC_OPEN_DATE := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;

              IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.DEFTFROM = 'A' THEN
                P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.ACCOUNT_CLASS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
              END IF;
            END IF;

          ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'P' THEN

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUT_COMPONENT = 'P' THEN
              L_PC_CNT                                                         := L_PC_CNT + 1;
              P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100          := 'U';
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE     := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PERCENTAGE;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY              := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PAYOUT_COMPONENT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PAYOUT_COMPONENT;
            ELSIF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
             .PAYOUT_COMPONENT = 'I' THEN
              L_PC_INT_CNT                                                     := L_PC_INT_CNT + 1;
              P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100          := 'U';
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS.PCPERCENTAGE     := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PERCENTAGE;
              P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS.CCY              := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).CCY;
              P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.PAYOUT_COMPONENT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                                                                  .PAYOUT_COMPONENT;
            END IF;

          END IF;

          L_OUTSEQNO := L_OUTSEQNO + 1;

        END LOOP;

        IF L_DD_CNT_FLG AND L_BC_CNT_FLG THEN
          DBG('payout type is DD and BC, Hence throwing error');
          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-VALS-005', '');
          RETURN FALSE;
        END IF;

        IF L_BC_CNT > 1 OR L_CASH_CNT > 1 OR L_GL_CNT > 1 OR L_TD_CNT > 1 OR
           L_PC_CNT > 1 OR L_BC_INT_CNT > 1 OR L_CASH_INT_CNT > 1 OR
           L_GL_INT_CNT > 1 OR L_PC_INT_CNT > 1

         THEN
          DBG('Cannot have multiple Payout option except Account ');
          DBG('l_bc_cnt :' || L_BC_CNT);
          DBG('l_pc_cnt :' || L_PC_CNT);
          DBG('l_bc_int_cnt :' || L_BC_INT_CNT);
          DBG('l_pc_int_cnt :' || L_PC_INT_CNT);

          P_ERR_FLAG := -1;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-211', '');
        ELSE

          P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD22 := NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD22,
                                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);

          IF NOT
              ICPKS_ICCTDFPO_UTILS_0.FN_PAYOUT_DEF_VALIDATE(P_STDCUSAC.TY_ICCTDFPO,
                                                            P_ACTION_CODE,
                                                            P_FUNCTION_ID) THEN
            DBG('returning false from fn_validate');
            RETURN FALSE;
          END IF;

          IF NOT
              ICPKS_ICCINTPO_UTILS_0.FN_PAYOUT_DEF_VALIDATE(P_STDCUSAC.TY_ICCINTPO,
                                                            P_ACTION_CODE,
                                                            P_FUNCTION_ID) THEN
            DBG('returning false from fn_validate');
            RETURN FALSE;
          END IF;

        END IF;

      END IF;
    END IF;

    IF NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD98, 'D') <> 'U' THEN

      DBG('Nullifying all the values');
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC      := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_PR.DELETE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_EFFDT.DELETE;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_UDEVALS.DELETE;
      P_STDCUSAC.TY_ICCTDFPO.V_CHILDTDPAYOUT_DETAILS.DELETE;

    END IF;

    IF NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100, 'D') <> 'U' THEN

      DBG('Nullifying all the values for PC');
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.BRN := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.ACC := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS.CCY := NULL;

    END IF;
    IF NVL(P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD100, 'D') <> 'U' THEN

      DBG('Nullifying all the values for PC');
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS.BRN := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS.ACC := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS.CCY := NULL;

    END IF;

    IF NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99, 'D') <> 'U' THEN

      DBG('Nullifying all the values for BC');

      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.BRN := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.ACC := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS.CCY := NULL;
    END IF;
    IF NVL(P_STDCUSAC.TY_ICCINTPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD99, 'D') <> 'U' THEN

      DBG('Nullifying all the values for BC');

      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.BRN := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.ACC := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS.CCY := NULL;
    END IF;

    IF NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD96, 'D') <> 'U' THEN

      DBG('Nullifying all the values for Child BC');
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDBCPAYOUT.BRN := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDBCPAYOUT.ACC := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDBCPAYOUT.CCY := NULL;
    END IF;

    IF NVL(P_STDCUSAC.TY_ICCTDFPO.V_CSTBS_UI_COLUMNS.CHAR_FIELD97, 'D') <> 'U' THEN

      DBG('Nullifying all the values for Child BC');
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDPCPAYOUT.BRN := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDPCPAYOUT.ACC := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDPCPAYOUT.CCY := NULL;
    END IF;

    RETURN TRUE;
  END FN_PAYINOUT_DEFAULT;

  FUNCTION FN_POPULATE_OD_COLL_LINKAGES(P_FUNCTION_ID IN VARCHAR2,
                                        P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_FIELD      VARCHAR2(30);
    L_LIAB_COUNT VARCHAR2(30);
  BEGIN

    IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.COUNT > 0 THEN

      BEGIN
        SELECT COUNT(*)
          INTO L_LIAB_COUNT
          FROM GETM_LIAB_CUST
         WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        IF L_LIAB_COUNT = 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-457', '');
          RETURN FALSE;
        END IF;
      END;

      DBG('looping for all rows in STTM_OD_LINKAGES');
      FOR I IN P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.FIRST .. P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.LAST LOOP

        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT IS NULL THEN
          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE = 'T' THEN
            BEGIN
              SELECT SA.ACY_WITHDRAWABLE_BAL,
                     NVL((SELECT AMT
                           FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
                          WHERE A1.PROD = PR.PRODUCT_CODE
                            AND A1.COND_KEY =
                                ST.BRANCH_CODE || ST.CUST_AC_NO
                            AND A1.UDE_ID = PR.INT_RATE_UDE
                            AND A1.UDE_EFF_DT =
                                (SELECT MAX(A2.UDE_EFF_DT)
                                   FROM ICTB_UDEVALS A2
                                  WHERE A2.COND_KEY = A1.COND_KEY
                                    AND A2.UDE_ID = A1.UDE_ID
                                    AND A2.UDE_EFF_DT <=
                                        GLOBAL.APPLICATION_DATE

                                 )),
                         0) RATE
                INTO P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT,
                     P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE
                FROM STTM_CUST_ACCOUNT ST, STTM_ACCOUNT_BALANCE SA
               WHERE

               ST.CUST_AC_NO = P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
              .COLLATERAL
               AND ST.BRANCH_CODE = P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
              .COLLATERAL_BRANCH
               AND SA.CUST_AC_BRN = ST.BRANCH_CODE
               AND SA.CUST_AC_NO = ST.CUST_AC_NO

              ;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT := 0;
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE := 0;
              WHEN OTHERS THEN
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT := 0;
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE := 0;
            END;
          ELSIF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE = 'C' THEN
            BEGIN
              SELECT AVAILABLE_AMOUNT, INTEREST_RATE
                INTO P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT,
                     P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE
                FROM GETM_COLLAT
               WHERE COLLATERAL_CODE = P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                    .COLLATERAL
                 AND BRANCH_CODE = P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                    .COLLATERAL_BRANCH;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT := 0;
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE := 0;
              WHEN OTHERS THEN
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).AVAILABLE_AMOUNT := 0;
                P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE := 0;
            END;
          END IF;
        END IF;

        DBG('Applicable interest rate -->' || P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
            .COLL_INT_RATE);
        DBG('Interest spread -->' || P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
            .INT_SPREAD);

        P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLL_INT_RATE := NVL(P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                                                                    .COLL_INT_RATE,
                                                                    0);
        P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).INT_SPREAD := NVL(P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                                                                 .INT_SPREAD,
                                                                 0);

        P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).OD_INT_RATE := (P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                                                              .COLL_INT_RATE + P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
                                                              .INT_SPREAD);

        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE IS NULL THEN
          L_FIELD := 'Collateral_type';
          DBG(L_FIELD || ' is null in collateral Linkages block');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-454', L_FIELD);
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE <> 'U' THEN
          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL IS NULL THEN
            L_FIELD := 'Collateral';
            DBG(L_FIELD || ' is null in collateral Linkages block');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-454', L_FIELD);
            RETURN FALSE;
          END IF;

          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
           .COLLATERAL_BRANCH IS NULL THEN
            L_FIELD := 'Collateral  branch';
            DBG(L_FIELD || ' is null in collateral Linkages block');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-454', L_FIELD);
            RETURN FALSE;
          END IF;
        END IF;

        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE <> 'C' THEN
          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).CATEGORY_NAME IS NULL THEN
            L_FIELD := 'Collateral category';
            DBG(L_FIELD || ' is null in collateral Linkages block');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-454', L_FIELD);
            RETURN FALSE;
          END IF;

          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).HAIRCUT IS NULL THEN
            L_FIELD := 'Haircut';
            DBG(L_FIELD || ' is null in collateral Linkages block');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-454', L_FIELD);
            RETURN FALSE;
          END IF;
        END IF;
        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).COLLATERAL_TYPE <> 'U' THEN
          IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).LINKED_AMOUNT > P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I)
             .AVAILABLE_AMOUNT THEN
            DBG('Linked amount is greater than available amount');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-453', '');
            RETURN FALSE;
          END IF;
        END IF;
        IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).LINKED_AMOUNT <= 0 THEN
          DBG('Linked amount should be greater than zero');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-456', '');
          RETURN FALSE;
        END IF;

      END LOOP;
    END IF;
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT FN_POPULATE_OD_COLL_LINKAGES ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;

  END FN_POPULATE_OD_COLL_LINKAGES;

  FUNCTION FN_VALIDATE_BNKACC(P_FUNCTION_ID IN VARCHAR2,
                              P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CHECK_CLG  NUMBER := 0;
    L_CHECK_IBAN NUMBER := 0;
  BEGIN
    DBG('Inside fn_validate_bnkacc');
    DBG('First checking for clearing account no');
    DBG('p_stdcusac.v_sttms_cust_account.clearing_ac_no ;' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO);
    DBG('p_stdcusac.v_sttms_cust_account.cust_ac_no :' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_CHECK_CLG
        FROM STTMS_CUST_ACCOUNT
       WHERE CLEARING_AC_NO =
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO
         AND

             (CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO OR
             (BRANCH_CODE <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE AND
             CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO))
         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';
      IF L_CHECK_CLG = 0 THEN
        DBG('Not available in sttm_cust_account. Going to look in sttm_clg_an_no');

        SELECT COUNT(*)
          INTO L_CHECK_CLG
          FROM STTM_CLG_AC_NO
         WHERE CLEARING_AC_NO =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO
           AND GL_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        IF L_CHECK_CLG > 0 THEN
          DBG('Error...Found in sttm_clg_ac_no');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN16', '');
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Found in sttm_cust_account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN16', '');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Second checking for iban account no');

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN

      SELECT COUNT(*)
        INTO L_CHECK_IBAN
        FROM STTMS_CUST_ACCOUNT
       WHERE IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO
         AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      IF L_CHECK_IBAN = 0 THEN
        DBG('Not available in sttm_cust_account. Going to look in sttm_clg_an_no');
        SELECT COUNT(*)
          INTO L_CHECK_IBAN
          FROM STTM_CLG_AC_NO
         WHERE IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO
           AND GL_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        IF L_CHECK_IBAN > 0 THEN
          DBG('Found in sttm_clg_ac_no');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN15', '');
          RETURN FALSE;
        END IF;
      ELSE
        DBG('Found in sttm_cust_account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN15', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('fn_validate_bnkacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upld_validations with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_BNKACC;

  FUNCTION FN_CHECK_SWIFTFORMAT(P_FUNCTION_ID IN VARCHAR2,
                                P_KEY         IN VARCHAR2,
                                P_FIELD       IN VARCHAR2) RETURN BOOLEAN IS
    L_SKIP_KERNEL      BOOLEAN;
    L_SKIP_PRECLUSTER  BOOLEAN;
    L_SKIP_POSTCLUSTER BOOLEAN;
    L_SKIP_CUSTOM      BOOLEAN;

  BEGIN
    DBG('Inside fn_check_SWIFTFormat');
    CSPKS_REQ_UTILS.PR_RESET_SKIP_VAR(L_SKIP_KERNEL,
                                      L_SKIP_PRECLUSTER,
                                      L_SKIP_POSTCLUSTER,
                                      L_SKIP_CUSTOM);
    IF NOT L_SKIP_CUSTOM THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CUSTOM.FN_PRE_CHECK_SWIFTFORMAT(P_FUNCTION_ID,
                                                                 P_KEY,
                                                                 P_FIELD,
                                                                 L_SKIP_KERNEL,
                                                                 L_SKIP_PRECLUSTER,
                                                                 L_SKIP_POSTCLUSTER) THEN
        DBG('Failed in stpks_stdcusac_utils_1_custom.fn_pre_check_swiftformat');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT L_SKIP_PRECLUSTER THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_PRE_CHECK_SWIFTFORMAT(P_FUNCTION_ID,
                                                                  P_KEY,
                                                                  P_FIELD,
                                                                  L_SKIP_KERNEL,
                                                                  L_SKIP_PRECLUSTER,
                                                                  L_SKIP_POSTCLUSTER) THEN
        DBG('Failed in stpks_stdcusac_utils_0_cluster.fn_pre_check_swiftformat');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT L_SKIP_KERNEL THEN
      IF NOT FN_CHECK_SWIFTFORMAT_KERNEL(P_FUNCTION_ID, P_KEY, P_FIELD) THEN
        DBG('Failed in fn_check_swiftformat_KERNEL');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT L_SKIP_POSTCLUSTER THEN
      DBG('Calling the cluster  function stpks_check_swiftformat_cluster.FN_post_update_accno');
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_POST_CHECK_SWIFTFORMAT(P_FUNCTION_ID,
                                                                   P_KEY,
                                                                   P_FIELD) THEN
        DBG('Failed in stpks_stdcusac_utils_0_cluster.FN_post_check_swiftformat');
        RETURN FALSE;
      END IF;
      DBG('After  function stpks_stdcusac_utils_0_cluster.FN_post_check_swiftformat');
    END IF;

    IF NOT L_SKIP_CUSTOM THEN
      DBG('Calling the custom function stpks_stdcusac_utils_1_custom.FN_post_check_swiftformat');
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CUSTOM.FN_POST_CHECK_SWIFTFORMAT(P_FUNCTION_ID,
                                                                  P_KEY,
                                                                  P_FIELD) THEN
        DBG('Failed in stpks_stdcusac_utils_1_custom.FN_post_check_swiftformat');
        RETURN FALSE;
      END IF;
      DBG('After function stpks_stdcusac_utils_1_custom.FN_post_check_swiftformat');
    END IF;

    DBG('fn_check_SWIFTFormat returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_check_SWIFTFormat with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FMVAL010', P_FIELD);

      RETURN FALSE;
  END FN_CHECK_SWIFTFORMAT;

  FUNCTION FN_CHECK_SWIFTFORMAT_KERNEL(P_FUNCTION_ID IN VARCHAR2

                                      ,
                                       P_KEY   IN VARCHAR2,
                                       P_FIELD IN VARCHAR2) RETURN BOOLEAN IS
    L_SWIFTCHARSET VARCHAR2(255);
    L_CHARTOCHK    VARCHAR2(1);
    L_INDEX        NUMBER;
    L_ERROR_FOUND  VARCHAR2(1) := 'N';
  BEGIN
    DBG('Inside fn_check_swiftformat_kernel');

    DBG('Entered Into Function fn_check_swiftformat_kernel');
    DBG('Key Field To Check For SWIFT Format : ' || P_KEY);
    L_SWIFTCHARSET := ' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    L_SWIFTCHARSET := L_SWIFTCHARSET ||
                      '0123456789.,-()+/=*&%:?!"<>;~`@#$^_[]{}|\';
    L_SWIFTCHARSET := L_SWIFTCHARSET || '''';
    FOR L_INDEX IN 1 .. NVL(LENGTH(P_KEY), 0) LOOP
      L_CHARTOCHK := SUBSTR(P_KEY, L_INDEX, 1);
      IF INSTR(L_SWIFTCHARSET, L_CHARTOCHK) = 0 THEN
        DBG('Failed for SWIFT Format Validation');

        IF L_CHARTOCHK = CHR(10) THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SWIFT-02', P_FIELD);

        ELSE
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-SWIFT-01',
                       L_CHARTOCHK || '~' || P_FIELD);
        END IF;

        L_ERROR_FOUND := 'Y';

      END IF;
    END LOOP;

    IF L_ERROR_FOUND = 'Y' THEN
      DBG('error found so returing false');
      RETURN FALSE;
    END IF;

    DBG('fn_check_swiftformat_kernel returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_check_SWIFTFormat with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IF-FMVAL010', P_FIELD);

      RETURN FALSE;

  END FN_CHECK_SWIFTFORMAT_KERNEL;

  FUNCTION FN_VALIDATE_ALTACC(P_FUNCTION_ID IN VARCHAR2,
                              P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                              P_ACC         IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                              P_ALTACC      IN STTMS_CUST_ACCOUNT.ALT_AC_NO%TYPE,
                              P_ACTION_CODE IN VARCHAR2 DEFAULT NULL)
    RETURN BOOLEAN IS
    L_ALT_AC STTMS_CUST_ACCOUNT.ALT_AC_NO%TYPE;
    L_COUNT  NUMBER;
  BEGIN
    DBG('Inside fn_validate_altacc');
    DBG('Acc: ' || P_ACC || ' Altacc: ' || P_ALTACC);

    IF P_ALTACC IS NULL THEN
      DBG('Alternate account number cannot be blank');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'AC-STAT002',
                   'Alternate Account Number');
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE = 'NEW' THEN

      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_BRN
           AND ALT_AC_NO = P_ALTACC;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COUNT := 0;
      END;

      IF L_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ALT-03', NULL);
        RETURN FALSE;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('For MODIFY');
      IF P_ALTACC IS NOT NULL THEN
        IF P_ALTACC = P_ACC THEN
          DBG('Alt A/c is same as cust acc');
          RETURN TRUE;
        END IF;

        BEGIN
          SELECT ALT_AC_NO
            INTO L_ALT_AC
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = P_BRN
             AND CUST_AC_NO = P_ACC;
          DBG('Old Alt Ac:' || L_ALT_AC);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Alt acc' || SQLERRM);
        END;

        IF L_ALT_AC IS NOT NULL AND L_ALT_AC = P_ALTACC THEN
          DBG('Alt ac same..not chaneg..so no need to validate');
          RETURN TRUE;
        END IF;
      END IF;
    END IF;

    PKG_FIELD := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                  P_FUNCTION_ID,
                                                  'STTMS_CUST_ACCOUNT.ALT_AC_NO') || '-' ||
                 P_ALTACC;
    DBG('pkg_field here in alt acc ->' || PKG_FIELD);

    IF NOT FN_CHECK_SWIFTFORMAT(P_FUNCTION_ID, P_ALTACC, PKG_FIELD) THEN
      DBG('fn_check_SWIFTFormat has returned false');

      RETURN FALSE;
    END IF;

    DBG('fn_validate_altacc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_altacc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ALTACC;

  FUNCTION FN_VALIDATE_CLRBNKCD(P_FUNCTION_ID IN VARCHAR2,
                                P_BRN         IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_CLRBNKCD    IN OUT STTMS_CUST_ACCOUNT.CLEARING_BANK_CODE%TYPE)
    RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN
    DBG('Inside fn_validate_clrbnkcd with Clrbnkcd: ' || P_CLRBNKCD);

    IF P_CLRBNKCD IS NULL THEN
      BEGIN
        DBG('Checking in pctms_bank_param');
        SELECT BANK_CODE
          INTO P_CLRBNKCD
          FROM PCTMS_BANK_PARAM
         WHERE BRANCH_CODE = P_BRN
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A'
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found... But going on');
          NULL;
      END;
    END IF;

    DBG('Checking: ' || P_CLRBNKCD);
    IF P_CLRBNKCD IS NOT NULL THEN

      SELECT COUNT(1)
        INTO L_COUNT
        FROM PCTMS_BANK_PARAM
       WHERE BANK_CODE = P_CLRBNKCD
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      IF L_COUNT = 0 THEN
        DBG('Failed for Clearing Bank Code Validation');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-104', P_CLRBNKCD);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_validate_clrbnkcd returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_clrbnkcd with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_CLRBNKCD;

  FUNCTION FN_VALIDATE_ACC_OPEN_DATE(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC)

   RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_validate_acc_open_date with Acc open date:');

    IF NOT GWPKS_UTIL.G_FROM_BEAN THEN
      DBG('Source is not Flexbranch.... Validating the date');

      DBG('ac open date-->' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
      DBG('payin opt-->' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21);
      DBG('account type-->' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE);
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' AND
         P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' THEN
        NULL;
      ELSE

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NOT NULL AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE >
           GLOBAL.APPLICATION_DATE THEN
          DBG('Validation Failed Account Open Date');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS10', '');
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    DBG('fn_validate_acc_open_date returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_acc_open_date with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ACC_OPEN_DATE;

  FUNCTION FN_VALIDATE_OPMODE(P_FUNCTION_ID IN VARCHAR2,
                              P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CUST_TYPE STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
  BEGIN
    DBG('Inside fn_validate_opmode');
    SELECT CUSTOMER_TYPE
      INTO L_CUST_TYPE
      FROM STTMS_CUSTOMER
     WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

    DBG('l_cust_type' || L_CUST_TYPE);
    IF L_CUST_TYPE = 'C' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION IS NOT NULL THEN
      DBG('mode_of_operation' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION);
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION IN ('E', 'F') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-602', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('fn_validate_opmode returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_opmode with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_OPMODE;

  FUNCTION FN_VALIDATE_MASK(P_FUNCTION_ID IN VARCHAR2,
                            P_MASKTYPE    IN VARCHAR2,
                            P_MASK        IN VARCHAR2,
                            P_MASKVALUE   IN VARCHAR2) RETURN BOOLEAN IS
    L_MASKVALUE         VARCHAR2(30);
    LPAD_STR            VARCHAR2(30);
    L_ALERTRETVAL       VARCHAR2(10);
    SUBST               VARCHAR2(1);
    IS_NUMERIC          NUMBER(1) := 1;
    LENGTH_STR          NUMBER(30);
    LENGTH_STR_IBAN     NUMBER(30);
    I                   NUMBER(15);
    L_LENGTHOFMASK      NUMBER;
    L_LENGTHOFMASKVALUE NUMBER;
  BEGIN
    DBG('Inside Fn_validate_mask');

    L_LENGTHOFMASK := LENGTH(P_MASK);
    DBG('l_LengthOfMask: ' || L_LENGTHOFMASK);
    L_LENGTHOFMASKVALUE := LENGTH(P_MASKVALUE);
    DBG('l_LengthOfMaskValue: ' || L_LENGTHOFMASKVALUE);
    L_MASKVALUE := LOWER(P_MASKVALUE);
    DBG('l_MaskValue: ' || L_MASKVALUE);

    DBG('p_MaskType: ' || P_MASKTYPE);
    IF P_MASKTYPE = 'B' THEN
      IF L_LENGTHOFMASK <> L_LENGTHOFMASKVALUE THEN
        DBG('Mismatch in Length of Bank Code Mask and Value for Bank Code');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Fn_validate_mask returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of Fn_validate_mask with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_MASK;

  FUNCTION FN_VALIDATE_DOCUMENTS(P_FUNCTION_ID IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_DOCUMENT_TYPES     VARCHAR2(4000);
    L_DOC_TYPES          VARCHAR2(4000);
    L_EXPIRE_DOC_TYPES   VARCHAR2(4000);
    L_EXPECTED_DOC_TYPES VARCHAR2(4000);
    L_ERR_CODE           VARCHAR2(10);
    L_ERR_PARAM          VARCHAR2(4000);
    L_CNT                NUMBER;
    L_FND                BOOLEAN := FALSE;

    L_DOC_COUNT     NUMBER;
    L_CUST_TYPE     VARCHAR2(1);
    L_MANDDOC_COUNT NUMBER := 0;

    L_COUNT_2        NUMBER;
    L_MULTI_CURRENCY VARCHAR2(20);

  BEGIN
    DBG('inside fn_validate_documents');
    DBG('Total documents defaulted for the account->' ||
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);
    G_MULTI_CURRENCY := STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       L_MULTI_CURRENCY);
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF G_MULTI_CURRENCY <> TRUE THEN

        DBG('Inside new or modify');
        IF P_ACTION_CODE IN ('NEW') THEN
          BEGIN
            SELECT CUSTOMER_TYPE
              INTO L_CUST_TYPE
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Error in getting customer type');
          END;
          DBG('l_cust_type is :' || L_CUST_TYPE);
          SELECT COUNT(*)
            INTO L_DOC_COUNT
            FROM STTM_ACLASS_DOCTYPE A
           WHERE A.ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
             AND A.CUSTOMER_TYPE = L_CUST_TYPE
             AND A.MANDATORY = 'Y';
          DBG('l_doc_count is :' || L_DOC_COUNT ||
              ' p_stdcusac.v_sttms_doctype_check_list.COUNT :' ||
              P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);
          IF P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
            DBG('There are documents');
            FOR I IN 1 .. P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT LOOP
              IF NVL(P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).MANDATORY,
                     'N') = 'Y' THEN
                DBG('l_manddoc_count:' || I);
                L_MANDDOC_COUNT := L_MANDDOC_COUNT + 1;
              END IF;
            END LOOP;
            DBG('Final_manddoc_count_:' || L_MANDDOC_COUNT);
          END IF;
          IF L_DOC_COUNT > L_MANDDOC_COUNT THEN
            DBG('doc has been deleted');
            L_ERR_CODE  := 'ST-UPL-104';
            L_ERR_PARAM := '';
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         L_ERR_CODE,
                         L_ERR_PARAM);
            RETURN FALSE;
          END IF;
        END IF;

        IF P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
          L_DOCUMENT_TYPES := NULL;
          FOR I IN 1 .. P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT LOOP
            DBG('Inside document check list loop');
            DBG('Document Type->' || P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                .DOCUMENT_TYPE);
            DBG('Mandatory->' || P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                .MANDATORY);
            DBG('checked status->' || P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                .CHECKED);
            IF P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).MANDATORY = 'Y' THEN

              IF ICPKS_BOD.G_CHILDTD THEN
                DBG('defaulting checked flag of document for child TD');
                IF NVL(P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED,
                       'N') = 'N' THEN
                  P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED := 'Y';
                END IF;
              END IF;

              IF NVL(P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED, 'N') = 'N' AND P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                .EXPECTED_DATE_SUBMISSION IS NULL THEN

                IF L_DOCUMENT_TYPES IS NULL THEN
                  L_DOCUMENT_TYPES := P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                      .DOCUMENT_TYPE;
                ELSE
                  L_DOCUMENT_TYPES := L_DOCUMENT_TYPES || ',' || P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                     .DOCUMENT_TYPE;
                END IF;
              END IF;
            END IF;

            IF P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).MANDATORY = 'Y' THEN
              IF NVL(P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED, 'N') = 'N' AND P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                .EXPECTED_DATE_SUBMISSION > GLOBAL.APPLICATION_DATE THEN
                IF L_DOC_TYPES IS NULL THEN
                  L_DOC_TYPES := P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                 .DOCUMENT_TYPE;
                ELSE
                  L_DOC_TYPES := L_DOC_TYPES || ',' || P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                .DOCUMENT_TYPE;
                END IF;
              END IF;
            END IF;

          END LOOP;
          IF P_FUNCTION_ID <> 'STDCASAC' THEN
            IF L_DOCUMENT_TYPES IS NOT NULL AND
               LENGTH(L_DOCUMENT_TYPES) < 4000 THEN

              L_ERR_CODE  := 'ST-UPL-100';
              L_ERR_PARAM := L_DOCUMENT_TYPES;

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           L_ERR_CODE,
                           L_ERR_PARAM);
              RETURN FALSE;
            ELSIF L_DOCUMENT_TYPES IS NOT NULL THEN

              L_ERR_CODE  := 'ST-UPL-101';
              L_ERR_PARAM := '';

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           L_ERR_CODE,
                           L_ERR_PARAM);
              RETURN FALSE;
            END IF;

            IF L_DOC_TYPES IS NOT NULL AND LENGTH(L_DOC_TYPES) < 4000 THEN

              P_ERR_CODE   := 'ST-UPL-102';
              P_ERR_PARAMS := L_DOC_TYPES;

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            ELSIF L_DOC_TYPES IS NOT NULL THEN

              P_ERR_CODE   := 'ST-UPL-103';
              P_ERR_PARAMS := '';

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            END IF;
          END IF;
        END IF;
      END IF;

      IF G_MULTI_CURRENCY = TRUE THEN
        FOR I IN 1 .. P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT LOOP

          IF NVL(P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED, 'N') = 'N' THEN
            P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CHECKED := 'Y';
          END IF;
        END LOOP;

      END IF;

    END IF;

    DBG('fn_validate_documents returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_documents with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_DOCUMENTS;

  FUNCTION FN_VALIDATE_DOCNOTIFICATION(P_FUNCTION_ID  IN VARCHAR2,
                                       P_BRANCH       IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                       P_ACC          IN STTMS_CUSTOMER.CUSTOMER_NO%TYPE,
                                       P_DOCLIST      IN STPKS_STDCUSAC_MAIN.TY_TB_STTMS_DOCTYPE_CHECK_LIST,
                                       P_PREV_DOCLIST IN STPKS_STDCUSAC_MAIN.TY_TB_STTMS_DOCTYPE_CHECK_LIST,
                                       P_REMARKS      IN STTM_DOCTYPE_REMARKS%ROWTYPE,
                                       P_DMS          IN CSTB_UI_COLUMNS.CHAR_FIELD70%TYPE,
                                       P_ACTION_CODE  IN VARCHAR2,
                                       P_ERR_CODE     IN OUT VARCHAR2,
                                       P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_FND            BOOLEAN := FALSE;
    L_PREV_CHANGE    BOOLEAN := FALSE;
    L_IS_ADDED       BOOLEAN := FALSE;
    P_STDCUSAC       STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_MULTI_CURRENCY VARCHAR2(20);
  BEGIN
    DBG('Inside fn_validate_doc_and_notification');

    IF NOT ICPKS_BOD.G_CHILDTD AND P_FUNCTION_ID <> 'STDCASAC' THEN

      IF P_DOCLIST.COUNT > 0 THEN
        FOR I IN 1 .. P_DOCLIST.COUNT LOOP

          L_PREV_CHANGE := FALSE;
          L_IS_ADDED    := TRUE;
          IF P_PREV_DOCLIST.COUNT > 0 THEN
            FOR J IN 1 .. P_PREV_DOCLIST.COUNT LOOP
              IF (P_DOCLIST(I)
                 .DOCUMENT_TYPE = P_PREV_DOCLIST(J).DOCUMENT_TYPE) THEN
                L_IS_ADDED := FALSE;
                IF ((P_DOCLIST(I)
                   .EXPECTED_DATE_SUBMISSION <> P_PREV_DOCLIST(J)
                   .EXPECTED_DATE_SUBMISSION OR P_DOCLIST(I)
                   .EXPIRY_DATE <> P_PREV_DOCLIST(J).EXPIRY_DATE OR P_DOCLIST(I)
                   .ACTUAL_SUBMISSION_DATE <> P_PREV_DOCLIST(J)
                   .ACTUAL_SUBMISSION_DATE)) THEN
                  L_PREV_CHANGE := TRUE;
                  EXIT;
                END IF;
              END IF;
            END LOOP;
            IF L_IS_ADDED THEN
              L_PREV_CHANGE := TRUE;
            END IF;
          ELSE
            L_PREV_CHANGE := TRUE;
          END IF;

          IF P_ACTION_CODE = 'NEW' THEN

            IF P_DOCLIST(I).EXPECTED_DATE_SUBMISSION IS NOT NULL THEN
              IF P_DOCLIST(I)
               .EXPECTED_DATE_SUBMISSION <= GLOBAL.APPLICATION_DATE THEN
                P_ERR_CODE   := 'ST-DOC-007';
                P_ERR_PARAMS := 'The Expected date of submission' || P_DOCLIST(I)
                               .EXPECTED_DATE_SUBMISSION ||
                                'Should Greater than Today Date';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
            IF P_DOCLIST(I).EXPIRY_DATE IS NOT NULL THEN
              IF P_DOCLIST(I).EXPIRY_DATE <= GLOBAL.APPLICATION_DATE THEN
                P_ERR_CODE   := 'ST-DOC-006';
                P_ERR_PARAMS := 'The Expiry Date' || P_DOCLIST(I)
                               .EXPIRY_DATE ||
                                ' Should Greater than Today Date';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
              IF P_DOCLIST(I).EXPECTED_DATE_SUBMISSION IS NOT NULL THEN
                IF P_DOCLIST(I)
                 .EXPIRY_DATE <= P_DOCLIST(I).EXPECTED_DATE_SUBMISSION THEN
                  P_ERR_CODE   := 'ST-DOC-008';
                  P_ERR_PARAMS := 'The Expiry Date' || P_DOCLIST(I)
                                 .EXPIRY_DATE ||
                                  'Should Greater than Expected submission date' || P_DOCLIST(I)
                                 .EXPECTED_DATE_SUBMISSION;
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               P_ERR_CODE,
                               P_ERR_PARAMS);
                  RETURN FALSE;
                END IF;
              END IF;
            END IF;

            DBG('p_dms' || P_DMS);
            IF P_DMS = 'Y' THEN
              IF P_DOCLIST(I)
               .DOCREFNO IS NULL AND P_DOCLIST(I).CHECKED = 'Y' THEN
                P_ERR_CODE   := 'ST-DOC-005';
                P_ERR_PARAMS := 'Please upload the document for' || P_DOCLIST(I)
                               .DOCUMENT_TYPE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
          END IF;

          IF P_ACTION_CODE = 'MODIFY' THEN
            IF L_PREV_CHANGE THEN

              IF P_DOCLIST(I)
               .EXPECTED_DATE_SUBMISSION < GLOBAL.APPLICATION_DATE THEN
                P_ERR_CODE   := 'ST-DOC-007';
                P_ERR_PARAMS := 'The Expected date of submission' || P_DOCLIST(I)
                               .EXPECTED_DATE_SUBMISSION ||
                                'Should Greater than Today Date';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;

              END IF;

              IF P_DOCLIST(I).EXPIRY_DATE < GLOBAL.APPLICATION_DATE THEN
                P_ERR_CODE   := 'ST-DOC-006';
                P_ERR_PARAMS := 'The Expiry Date' || P_DOCLIST(I)
                               .EXPIRY_DATE ||
                                ' Should Greater than Today Date';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;

              IF P_DOCLIST(I)
               .EXPIRY_DATE < P_DOCLIST(I).EXPECTED_DATE_SUBMISSION THEN
                P_ERR_CODE   := 'ST-DOC-008';
                P_ERR_PARAMS := 'The Expiry Date' || P_DOCLIST(I)
                               .EXPIRY_DATE ||
                                'Should Greater than Expected submission date' || P_DOCLIST(I)
                               .EXPECTED_DATE_SUBMISSION;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;

              IF P_DOCLIST(I)
               .EXPIRY_DATE < P_DOCLIST(I).ACTUAL_SUBMISSION_DATE THEN
                P_ERR_CODE   := 'ST-DOC-10';
                P_ERR_PARAMS := 'The Expiry Date' || P_DOCLIST(I)
                               .EXPIRY_DATE ||
                                'Should Greater than Actual submission date';
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;

              END IF;
            END IF;
            IF P_DMS = 'Y' THEN
              IF P_DOCLIST(I)
               .DOCREFNO IS NULL AND P_DOCLIST(I).CHECKED = 'Y' THEN
                P_ERR_CODE   := 'ST-DOC-005';
                P_ERR_PARAMS := 'Please upload the document for' || P_DOCLIST(I)
                               .DOCUMENT_TYPE;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
            END IF;
          END IF;
        END LOOP;
      END IF;

      IF STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                        P_STDCUSAC,
                                                        L_MULTI_CURRENCY) <> TRUE THEN
        IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          DBG('p_remarks.send_notification' || P_REMARKS.SEND_NOTIFICATION);
          IF P_REMARKS.SEND_NOTIFICATION = 'Y' THEN
            DBG('p_remarks.send_notification' ||
                P_REMARKS.SEND_NOTIFICATION);
            L_FND := FALSE;
            DBG('p_doclist.COUNT' || P_DOCLIST.COUNT);
            IF P_DOCLIST.COUNT > 0 THEN
              FOR I IN P_DOCLIST.FIRST .. P_DOCLIST.LAST LOOP
                DBG('p_doclist.MANDATORY' || P_DOCLIST(I).MANDATORY);
                IF P_DOCLIST(I).MANDATORY = 'Y' THEN
                  L_FND := TRUE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF L_FND = FALSE THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-NOTF-001',
                           'No Maandatory documents in checklist for sending notification');
              RETURN FALSE;
            END IF;
            IF P_REMARKS.FREQUENCY IS NULL THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-NOTF-002',
                           'Frequency Should given for Sending notification');
            END IF;
          END IF;
        END IF;

      END IF;
    END IF;
    DBG('fn_validate_doc_and_notification returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_doc_and_notification with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_DOCNOTIFICATION;

  FUNCTION FN_BBAN_BANK_CODE(P_FUNCTION_ID    IN VARCHAR2,
                             P_STDCUSAC       IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ACTION_CODE    IN VARCHAR2,
                             L_BBAN_BANK_CODE IN STTMS_BRANCH.BBAN_BANK_CODE%TYPE,
                             L_END_POS        IN NUMBER,
                             L_START_POS      IN NUMBER,
                             L_IBAN_AC_NO     IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                             L_ACTION         IN VARCHAR2) RETURN BOOLEAN IS
    L_FLD_DESC CSTB_LABELS.LABEL_DESCRIPTION%TYPE;

  BEGIN
    DBG('Inside  fn_BBAN_BANK_CODE');

    L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                   'STDBRANC',
                                                   'STTMS_BRANCH.BBAN_BANK_CODE');
    DBG('l_fld_desc is ' || L_FLD_DESC);

    IF LENGTH(L_BBAN_BANK_CODE) > 0 THEN
      IF LENGTH(L_BBAN_BANK_CODE) <> L_END_POS - L_START_POS + 1 THEN
        DBG('Length of Bank code parameter differs!');

        PR_LOG_ERROR('STDBRANC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      ELSE
        IF L_ACTION = 'GENERATE' THEN
          L_IBAN_AC_NO := L_IBAN_AC_NO || L_BBAN_BANK_CODE;
        END IF;
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_BBAN_BANK_CODE <>
           SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                  L_START_POS,
                  LENGTH(L_BBAN_BANK_CODE)) THEN
          DBG('Content of Bank code parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    ELSE
      DBG('Value not available for Bank code parameter!');
      PR_LOG_ERROR('STDBRANC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      RETURN FALSE;
    END IF;
    DBG('fn_BBAN_BANK_CODE returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_BANK_CODE with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_BANK_CODE;

  FUNCTION FN_BBAN_BRANCH_CODE(P_FUNCTION_ID      IN VARCHAR2,
                               P_STDCUSAC         IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ACTION_CODE      IN VARCHAR2,
                               L_BBAN_BRANCH_CODE IN STTMS_BRANCH.BBAN_BRN_CODE%TYPE,
                               L_END_POS          IN NUMBER,
                               L_START_POS        IN NUMBER,
                               L_IBAN_AC_NO       IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                               L_ACTION           IN VARCHAR2) RETURN BOOLEAN IS
    L_FLD_DESC CSTB_LABELS.LABEL_DESCRIPTION%TYPE;

  BEGIN
    DBG('Inside  fn_BBAN_branch_code');

    L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                   'STDBRANC',
                                                   'STTMS_BRANCH.BBAN_BRN_CODE');
    DBG('l_fld_desc is ' || L_FLD_DESC);

    IF LENGTH(L_BBAN_BRANCH_CODE) > 0 THEN
      IF LENGTH(L_BBAN_BRANCH_CODE) <> L_END_POS - L_START_POS + 1 THEN
        DBG('Length of Branch code parameter differs!');
        PR_LOG_ERROR('STDBRANC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      ELSE
        IF L_ACTION = 'GENERATE' THEN
          L_IBAN_AC_NO := L_IBAN_AC_NO || L_BBAN_BRANCH_CODE;
        END IF;
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_BBAN_BRANCH_CODE <>
           SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                  L_START_POS,
                  LENGTH(L_BBAN_BRANCH_CODE)) THEN
          DBG('Content of Branch code parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    ELSE
      DBG('Value not available for Branch code parameter!');
      PR_LOG_ERROR('STDBRANC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      RETURN FALSE;
    END IF;
    DBG('fn_BBAN_branch_code returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_branch_code with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_BRANCH_CODE;

  FUNCTION FN_BBAN_ACCNO(P_FUNCTION_ID IN VARCHAR2,
                         P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_ACTION_CODE IN VARCHAR2,
                         L_END_POS     IN NUMBER,
                         L_START_POS   IN NUMBER,
                         L_IBAN_AC_NO  IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                         L_ACTION      IN VARCHAR2) RETURN BOOLEAN IS

    L_LEN_CUST_AC_NO NUMBER;
    L_CUST_AC_NO     STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_FLD_DESC       CSTB_LABELS.LABEL_DESCRIPTION%TYPE;
    L_HO_BRANCH      STTMS_BANK.HO_BRANCH%TYPE;
  BEGIN
    DBG('Inside  fn_BBAN_accno');
    SELECT HO_BRANCH INTO L_HO_BRANCH FROM STTMS_BANK;

    L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                   'STDCUSAC',
                                                   'STTMS_CUST_ACCOUNT.CUST_AC_NO');
    DBG('l_fld_desc is ' || L_FLD_DESC);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NULL THEN
      DBG('Account Number is not available, IBAN could not be validated!');
      PR_LOG_ERROR('STDCUSAC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      RETURN FALSE;
    ELSE

      IF CSPKSS_FEATURE.FN_INSTALLED('SPL_IBAN_MASK', L_HO_BRANCH) THEN
        L_CUST_AC_NO := REGEXP_REPLACE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                       '[-,.*/]',
                                       '');
      ELSE

        L_CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END IF;
      DBG('l_cust_ac_no-->' || L_CUST_AC_NO);
      L_LEN_CUST_AC_NO := NVL(LENGTH(L_CUST_AC_NO), 0);
      DBG('l_len_cust_ac_no-->' || L_LEN_CUST_AC_NO);
      IF L_LEN_CUST_AC_NO > L_END_POS - L_START_POS + 1 THEN
        DBG('Length of account no is > than bban account length maintained!');
        DBG('IBAN Couldn''t be validated!');
        PR_LOG_ERROR('STDCUSAC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      END IF;
      IF L_ACTION = 'GENERATE' THEN
        L_IBAN_AC_NO := L_IBAN_AC_NO ||
                        LPAD(L_CUST_AC_NO, L_END_POS - L_START_POS + 1, '0');
        DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_CUST_AC_NO <> SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                                  L_END_POS + 1 - LENGTH(L_CUST_AC_NO),
                                  LENGTH(L_CUST_AC_NO)) THEN
          DBG('Content of Account Number parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    END IF;

    DBG('fn_BBAN_accno returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_accno with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_ACCNO;

  FUNCTION FN_BBAN_ALTERNATE_ACCNO(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   P_ACTION_CODE IN VARCHAR2,
                                   L_END_POS     IN NUMBER,
                                   L_START_POS   IN NUMBER,
                                   L_IBAN_AC_NO  IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                                   L_ACTION      IN VARCHAR2) RETURN BOOLEAN IS

    L_LEN_CUST_AC_NO NUMBER;
    L_ALT_CUST_AC_NO STTMS_CUST_ACCOUNT.ALT_AC_NO%TYPE;
    L_FLD_DESC       CSTB_LABELS.LABEL_DESCRIPTION%TYPE;
    L_HO_BRANCH      STTMS_BANK.HO_BRANCH%TYPE;
  BEGIN
    DBG('Inside  fn_BBAN_accno');
    SELECT HO_BRANCH INTO L_HO_BRANCH FROM STTMS_BANK;

    L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                   'STDCUSAC',
                                                   'STTMS_CUST_ACCOUNT.ALT_AC_NO');
    DBG('l_fld_desc is ' || L_FLD_DESC);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO IS NULL THEN
      DBG('Alternate Account Number is not available, IBAN could not be validated!');
      PR_LOG_ERROR('STDCUSAC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      IF L_ACTION = 'GENERATE' THEN
        PR_LOG_ERROR('STDCUSAC', 'FLEXCUBE', 'ST-IBAN-07', NULL);
      END IF;
      RETURN FALSE;
    ELSE

      IF CSPKSS_FEATURE.FN_INSTALLED('SPL_IBAN_MASK', L_HO_BRANCH) THEN
        L_ALT_CUST_AC_NO := REGEXP_REPLACE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                                           '[-,.*/]',
                                           '');
      ELSE

        L_ALT_CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO;
      END IF;

      DBG('l_alt_cust_ac_no-->' || L_ALT_CUST_AC_NO);
      L_LEN_CUST_AC_NO := NVL(LENGTH(L_ALT_CUST_AC_NO), 0);
      DBG('l_len_cust_ac_no-->' || L_LEN_CUST_AC_NO);
      IF L_LEN_CUST_AC_NO > L_END_POS - L_START_POS + 1 THEN
        DBG('Length of alternate account no is > than bban account length maintained!');
        DBG('IBAN Couldn''t be Validated!');
        PR_LOG_ERROR('STDCUSAC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      END IF;
      IF L_ACTION = 'GENERATE' THEN
        L_IBAN_AC_NO := L_IBAN_AC_NO || LPAD(L_ALT_CUST_AC_NO,
                                             L_END_POS - L_START_POS + 1,
                                             '0');
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_ALT_CUST_AC_NO <>
           SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                  L_END_POS + 1 - LENGTH(L_ALT_CUST_AC_NO),
                  LENGTH(L_ALT_CUST_AC_NO)) THEN
          DBG('Content of Alternate Account Number parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    END IF;

    DBG('fn_BBAN_alternate_accno returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_alternate_accno with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_ALTERNATE_ACCNO;

  FUNCTION FN_BBAN_JOINTHOLDERS(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACTION_CODE IN VARCHAR2,
                                L_END_POS     IN NUMBER,
                                L_START_POS   IN NUMBER,
                                L_IBAN_AC_NO  IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                                L_ACTION      IN VARCHAR2) RETURN BOOLEAN IS

    L_JOINT_HOLDER_COUNT NUMBER;
    L_TEMP_H_MASK_VALUE  VARCHAR2(1);

  BEGIN
    DBG('Inside  fn_BBAN_jointholders');
    IF L_ACTION <> 'GENERATE' THEN
      IF L_END_POS <> L_START_POS THEN
        DBG('Length of Account Holders Paramter is > than 1!');
        DBG('IBAN Couldn''t be Valiated!');
        PR_LOG_ERROR('STDCUSAC', 'FLEXCUBE', 'ST-IBAN-09', '');

      END IF;
    END IF;
    IF L_ACTION = 'GENERATE' THEN

      IF P_FUNCTION_ID LIKE 'CL%' THEN
        L_JOINT_HOLDER_COUNT := CLPKS_CLDACCNT_UTILS.G_ACC_PARTY_COUNT;
      ELSE

        L_JOINT_HOLDER_COUNT := P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
      END IF;
      IF L_JOINT_HOLDER_COUNT < 35 THEN
        IF L_JOINT_HOLDER_COUNT < 9 THEN
          L_TEMP_H_MASK_VALUE := TO_CHAR(L_JOINT_HOLDER_COUNT + 1);
        ELSE

          L_TEMP_H_MASK_VALUE := CHR(L_JOINT_HOLDER_COUNT + 1 + 55);
        END IF;
      ELSE
        DBG('Count of Total Account Holders is > than 35!');
        DBG('IBAN Couldn''t be generated!');
        PR_LOG_ERROR('STDCUSAC',
                     'FLEXCUBE'

                    ,
                     'ST-IBAN-11',
                     NULL

                     );
      END IF;
      L_IBAN_AC_NO := L_IBAN_AC_NO || L_TEMP_H_MASK_VALUE;
      DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
    END IF;

    DBG('fn_BBAN_jointholders returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_jointholders with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_JOINTHOLDERS;

  FUNCTION FN_BBAN_CUSTOMER_TYPE(P_FUNCTION_ID IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ACTION_CODE IN VARCHAR2,
                                 L_END_POS     IN NUMBER,
                                 L_START_POS   IN NUMBER,
                                 L_IBAN_AC_NO  IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                                 L_ACTION      IN VARCHAR2) RETURN BOOLEAN IS

    L_CUSTOMER_TYPE STTMS_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_NATIONAL_ID   STTMS_CUST_PERSONAL.P_NATIONAL_ID%TYPE;
    L_FLD_DESC      CSTB_LABELS.LABEL_DESCRIPTION%TYPE;

  BEGIN
    DBG('Inside  fn_BBAN_customer_type');
    BEGIN
      SELECT NVL(CUS.CUSTOMER_TYPE, 'I')
        INTO L_CUSTOMER_TYPE
        FROM STTMS_CUSTOMER CUS
       WHERE CUS.CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      DBG('l_customer_type-->' || L_CUSTOMER_TYPE);
      IF L_CUSTOMER_TYPE = 'I' THEN

        L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                       'STDCIF',
                                                       'STTMS_CUST_PERSONAL.P_NATIONAL_ID');
        DBG('l_fld_desc is ' || L_FLD_DESC);

        BEGIN
          SELECT CPER.P_NATIONAL_ID
            INTO L_NATIONAL_ID
            FROM STTMS_CUST_PERSONAL CPER
           WHERE CPER.CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In WOT while selecting from sttms_cust_personal!');
            DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-IBAN-06'

                        ,
                         L_FLD_DESC);
            RETURN FALSE;
        END;

      ELSIF L_CUSTOMER_TYPE IN ('C', 'B') THEN

        L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                       'STDCIF',
                                                       'STTMS_CUST_PERSONAL.P_NATIONAL_ID');
        DBG('l_fld_desc is ' || L_FLD_DESC);

        BEGIN
          SELECT CCOR.C_NATIONAL_ID
            INTO L_NATIONAL_ID
            FROM STTMS_CUST_CORPORATE CCOR
           WHERE CCOR.CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In WOT while selecting from sttms_cust_corporate!');
            DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            PR_LOG_ERROR('STDCIF',
                         'FLEXCUBE',
                         'ST-IBAN-06'

                        ,
                         L_FLD_DESC);
            RETURN FALSE;
        END;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT while selecting from STTM_BRANCH!');
        DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN FALSE;
    END;
    DBG('l_national_id-->' || L_NATIONAL_ID);
    IF LENGTH(L_NATIONAL_ID) > 0 THEN
      IF LENGTH(L_NATIONAL_ID) > L_END_POS - L_START_POS + 1 THEN
        DBG('Length of National ID is > than bban National ID length maintained!');
        DBG('IBAN Couldn''t be Validated!');
        PR_LOG_ERROR('STDCUSAC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      END IF;
      IF L_ACTION = 'GENERATE' THEN
        L_IBAN_AC_NO := L_IBAN_AC_NO || LPAD(L_NATIONAL_ID,
                                             L_END_POS - L_START_POS + 1,
                                             '0');
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_NATIONAL_ID <> SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                                   L_END_POS + 1 - LENGTH(L_NATIONAL_ID),
                                   LENGTH(L_NATIONAL_ID)) THEN
          DBG('Content of National ID parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    ELSE
      DBG('Value not available for National ID parameter!');
      PR_LOG_ERROR('STDBRANC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      RETURN FALSE;
    END IF;

    DBG('fn_BBAN_customer_type returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_customer_type with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_CUSTOMER_TYPE;

  FUNCTION FN_BBAN_ACCOUNT_TYPE(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACTION_CODE IN VARCHAR2,
                                L_END_POS     IN NUMBER,
                                L_START_POS   IN NUMBER,
                                L_IBAN_AC_NO  IN OUT STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                                L_ACTION      IN VARCHAR2) RETURN BOOLEAN IS

    L_IBAN_ACC_TYPE STTMS_ACCOUNT_CLASS.IBAN_ACC_TYPE%TYPE;
    L_FLD_DESC      CSTB_LABELS.LABEL_DESCRIPTION%TYPE;
    L_PRODUCT       CLTMS_PRODUCT%ROWTYPE;

  BEGIN
    DBG('Inside  fn_BBAN_account_type');

    L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                   'STDACCLS',
                                                   'STTMS_ACCOUNT_CLASS.IBAN_ACC_TYPE');
    DBG('l_fld_desc is ' || L_FLD_DESC);

    BEGIN

      IF P_FUNCTION_ID LIKE 'CL%' THEN
        L_PRODUCT       := CLPKS_CACHE.FN_PRODUCT(CLPKS_CLDACCNT_UTILS.G_PROD_CODE);
        L_IBAN_ACC_TYPE := L_PRODUCT.IBAN_ACC_TYPE;
        DBG('l_iban_acc_type' || L_IBAN_ACC_TYPE);
      ELSE

        SELECT ACL.IBAN_ACC_TYPE
          INTO L_IBAN_ACC_TYPE
          FROM STTMS_ACCOUNT_CLASS ACL
         WHERE ACL.ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT while selecting from sttms_account_class!');
        DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN FALSE;
    END;
    DBG('l_iban_acc_type-->' || L_IBAN_ACC_TYPE);
    IF LENGTH(L_IBAN_ACC_TYPE) > 0 THEN
      IF LENGTH(L_IBAN_ACC_TYPE) <> L_END_POS - L_START_POS + 1 THEN
        DBG('Length of l_iban_acc_type parameter differs!');
        PR_LOG_ERROR('STDBRANC',
                     'FLEXCUBE',
                     'ST-IBAN-06'

                    ,
                     L_FLD_DESC);
        RETURN FALSE;
      END IF;
      IF L_ACTION = 'GENERATE' THEN
        L_IBAN_AC_NO := L_IBAN_AC_NO || L_IBAN_ACC_TYPE;
        DBG('l_iban_ac_no' || L_IBAN_AC_NO);
      END IF;
      IF L_ACTION <> 'GENERATE' THEN
        IF L_IBAN_ACC_TYPE <>
           SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                  L_START_POS,
                  LENGTH(L_IBAN_ACC_TYPE)) THEN
          DBG('Content of l_iban_acc_type parameter differs!');
          PR_LOG_ERROR('STDBRANC', 'FLEXCUBE', 'ST-IBAN-09', '');

        END IF;
      END IF;
    ELSE
      DBG('Value not available for l_iban_acc_type parameter!');
      PR_LOG_ERROR('STDBRANC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC);
      RETURN FALSE;
    END IF;

    DBG('fn_BBAN_account_type returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_BBAN_account_type with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_BBAN_ACCOUNT_TYPE;

  PROCEDURE PR_END_POS(P_START_POS IN NUMBER,
                       P_MASK_CHAR IN VARCHAR2,
                       P_MASK      IN STTMS_BRANCH.BBAN_FORMAT_MSK%TYPE,
                       P_END_POS   OUT NUMBER) IS
    L_TEMP_START_POS NUMBER := P_START_POS;
  BEGIN
    DBG('Inside pr_next_pos to find the end position of mask character-->' ||
        P_MASK_CHAR);
    DBG('start position-->' || L_TEMP_START_POS);
    FOR I IN L_TEMP_START_POS .. LENGTH(P_MASK) LOOP
      IF SUBSTR(P_MASK, I, 1) = P_MASK_CHAR THEN
        P_END_POS := I;
      ELSE
        DBG('Exiting the loop since other mask value encountered!!');
        EXIT;
      END IF;
    END LOOP;
    DBG('end_pos-->' || P_END_POS);
  END PR_END_POS;

  FUNCTION FN_BBAN_CHECK_DIGIT_GENERATION(P_FUNCTION_ID IN VARCHAR2,
                                          P_BBAN_AC_NO  IN OUT STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE,
                                          P_BRANCH      IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE)
    RETURN BOOLEAN IS
    L_STAT_FLAG               BOOLEAN := FALSE;
    L_START_POS               NUMBER;
    L_END_POS                 NUMBER;
    L_TEMP_MASK_CHAR          STTMS_BRANCH.BBAN_FORMAT_MSK%TYPE;
    L_TEMP_BBAN_AC_NO         STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_USER_CHECK_DIGIT        STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_BBAN_FORMAT_MASK        STTMS_BRANCH.BBAN_FORMAT_MSK%TYPE;
    L_CHECK_DIGIT_ALGORITHIM  STTMS_BRANCH.CHK_DIG_ALGO%TYPE;
    L_USER_DEFINED_ALGORITHIM STTMS_BRANCH.USER_DEF_ALGO%TYPE;

  BEGIN
    L_START_POS       := 1;
    L_TEMP_BBAN_AC_NO := '';
    DBG('Padded with zero for Check digit-->' || L_TEMP_BBAN_AC_NO);
    BEGIN
      SELECT BR.BBAN_FORMAT_MSK, BR.CHK_DIG_ALGO, BR.USER_DEF_ALGO
        INTO L_BBAN_FORMAT_MASK,
             L_CHECK_DIGIT_ALGORITHIM,
             L_USER_DEFINED_ALGORITHIM
        FROM STTM_BRANCH BR
       WHERE BR.BRANCH_CODE = P_BRANCH;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In WOT while selecting from STTM_BRANCH!');
        DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
        RETURN FALSE;
    END;
    LOOP
      DBG('l_start_pos-->' || L_START_POS);
      L_TEMP_MASK_CHAR := SUBSTR(L_BBAN_FORMAT_MASK, L_START_POS, 1);
      PR_END_POS(L_START_POS,
                 L_TEMP_MASK_CHAR,
                 L_BBAN_FORMAT_MASK,
                 L_END_POS);
      IF L_TEMP_MASK_CHAR = 'd' THEN
        DBG('Inside mask char ''d''!');
        DBG('l_check_digit_algorithim-->' || L_CHECK_DIGIT_ALGORITHIM);

        FOR I IN 1 .. LENGTH(P_BBAN_AC_NO) LOOP
          IF (ASCII(UPPER(SUBSTR(P_BBAN_AC_NO, I, 1)))) BETWEEN 65 AND 90 THEN
            DBG('Converting alphabets into numerics');
            L_TEMP_BBAN_AC_NO := L_TEMP_BBAN_AC_NO ||
                                 ((ASCII(UPPER(SUBSTR(P_BBAN_AC_NO, I, 1)))) - 55);
          ELSE
            L_TEMP_BBAN_AC_NO := L_TEMP_BBAN_AC_NO ||
                                 (SUBSTR(P_BBAN_AC_NO, I, 1));
          END IF;
        END LOOP;

        IF L_CHECK_DIGIT_ALGORITHIM = 'U' THEN
          DBG('Inside User-defined Alg!');
          IF L_USER_DEFINED_ALGORITHIM IS NOT NULL THEN
            L_STAT_FLAG := CSPKSS_ALG_SERVER.FN_CHK_DIGIT_GEN('PR_GEN_' ||
                                                              L_USER_DEFINED_ALGORITHIM,
                                                              P_BRANCH,
                                                              L_TEMP_BBAN_AC_NO,
                                                              L_USER_CHECK_DIGIT);
          ELSE
            RETURN FALSE;
          END IF;

        ELSIF L_CHECK_DIGIT_ALGORITHIM = 'MOD97' THEN
          DBG('Inside Mod97!');
          L_STAT_FLAG        := STPKS_STDCUSAC_UTILS_0.FN_CHKDIGIT97(P_FUNCTION_ID,
                                                                     L_TEMP_BBAN_AC_NO,
                                                                     L_USER_CHECK_DIGIT);
          L_USER_CHECK_DIGIT := 98 - L_USER_CHECK_DIGIT;
          IF L_USER_CHECK_DIGIT < 10 THEN
            L_USER_CHECK_DIGIT := '0' || L_USER_CHECK_DIGIT;
          END IF;
          DBG('l_user_check_digit' || L_USER_CHECK_DIGIT);

        ELSIF L_CHECK_DIGIT_ALGORITHIM = 'MOD11W' THEN
          DBG('Inside MOD11W!');
          L_STAT_FLAG := STPKS_STDCUSAC_UTILS_0.FN_CHKSUM11WW(P_FUNCTION_ID,
                                                              L_TEMP_BBAN_AC_NO,
                                                              L_USER_CHECK_DIGIT);

          L_USER_CHECK_DIGIT := SUBSTR(L_USER_CHECK_DIGIT, -1, 1);

        ELSIF L_CHECK_DIGIT_ALGORITHIM IN ('MOD10', 'MOD11') THEN
          DBG('Inside MOD10/MOD11!');
          L_STAT_FLAG := STPKS_STDCUSAC_UTILS_0.FN_CHKDIGIT(P_FUNCTION_ID,
                                                            'd',
                                                            L_TEMP_BBAN_AC_NO);

          L_USER_CHECK_DIGIT := SUBSTR(L_TEMP_BBAN_AC_NO, -1, 1);
          L_TEMP_BBAN_AC_NO  := SUBSTR(L_TEMP_BBAN_AC_NO,
                                       1,
                                       LENGTH(L_TEMP_BBAN_AC_NO) - 1);

        ELSE
          DBG('Inside Else of Alg!');
          RETURN FALSE;
        END IF;

        L_TEMP_BBAN_AC_NO := P_BBAN_AC_NO;
        DBG('l_temp_bban_ac_no :: ' || L_TEMP_BBAN_AC_NO);
        DBG('l_user_check_digit :: ' || L_USER_CHECK_DIGIT);

        IF L_STAT_FLAG THEN
          IF LENGTH(L_USER_CHECK_DIGIT) = L_END_POS - L_START_POS + 1 THEN
            L_TEMP_BBAN_AC_NO := SUBSTR(L_TEMP_BBAN_AC_NO,
                                        1,
                                        L_START_POS - 1) ||
                                 L_USER_CHECK_DIGIT

                                 ||
                                 SUBSTR(L_TEMP_BBAN_AC_NO, L_END_POS + 1);
            DBG('l_temp_iban_ac_no-->' || L_TEMP_BBAN_AC_NO);
          ELSE
            DBG('Length of Check Digit Maintained and Generated are different!');
            DBG('IBAN Couldn''t be generated!');

            PR_LOG_ERROR('STDCUSAC',
                         'FLEXCUBE'

                        ,
                         'ST-IBAN-12',
                         NULL

                         );

            RETURN FALSE;
          END IF;
        ELSE
          DBG('l_check_digit_algorithim returned false!');
          DBG('IBAN Couldn''t be generated!');

          PR_LOG_ERROR('STDCUSAC',
                       'FLEXCUBE'

                      ,
                       'ST-IBAN-12',
                       NULL

                       );

          RETURN FALSE;
        END IF;
      END IF;
      L_START_POS := L_END_POS + 1;
      EXIT WHEN L_START_POS > LENGTH(L_BBAN_FORMAT_MASK);
    END LOOP;

    P_BBAN_AC_NO := NVL(L_TEMP_BBAN_AC_NO, P_BBAN_AC_NO);

    RETURN TRUE;
  END FN_BBAN_CHECK_DIGIT_GENERATION;

  FUNCTION FN_FORMAT_VALIDATE_IBAN_ACC(P_FUNCTION_ID IN VARCHAR2,
                                       P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                       P_ACTION_CODE IN VARCHAR2)
    RETURN BOOLEAN IS
    L_IBAN_MASK_BANK_CODE      STTMS_BRANCH.IBAN_MASK_BANK_CODE%TYPE;
    L_IBAN_MASK_ACCOUNT_NUMBER STTMS_BRANCH.IBAN_MASK_ACCOUNT_NUMBER%TYPE;
    L_IBAN_AC_NO               STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_COUNTRY_CODE             STTMS_BRANCH.COUNTRY_CODE%TYPE;
    L_ERR_CODE                 VARCHAR2(100);
    L_ERR_PARAM                ERTBS_MSGS.MESSAGE%TYPE;
    L_TO_PAD_ACC               VARCHAR2(30);
    L_SUBSTR_BANK              VARCHAR2(30);
    L_CONCAT_BNKACC            VARCHAR2(30);
    L_SUBSTR_IBAN_CTY          VARCHAR2(20);
    L_SUBSTR_CURR_BRN          VARCHAR2(20);
    L_ACCOUNT_NUMBER           VARCHAR2(20);
    L_BANK_CODE                VARCHAR2(10);
    L_CHECKDIG                 VARCHAR2(2);

    L_LEN_FORMAT              NUMBER;
    L_LENGTH_USER_BNK         NUMBER(2);
    L_COUNT                   INTEGER := 0;
    L_STAT_FLAG               BOOLEAN := FALSE;
    L_DEF_LV_COUNT            NUMBER;
    L_START_POS               NUMBER;
    L_END_POS                 NUMBER;
    CHECKDIG                  VARCHAR2(2);
    L_LEN_CUST_AC_NO          NUMBER;
    L_TEMP_MASK_CHAR          STTMS_BRANCH.BBAN_FORMAT_MSK%TYPE;
    L_TEMP_DATA_CHAR          STTMS_BRANCH.BBAN_DATA_TYPE%TYPE;
    L_CUSTOMER_TYPE           STTMS_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_NATIONAL_ID             STTMS_CUST_PERSONAL.P_NATIONAL_ID%TYPE;
    L_IBAN_ACC_TYPE           STTMS_ACCOUNT_CLASS.IBAN_ACC_TYPE%TYPE;
    L_TEMP_BBAN_AC_NO         STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_TEMP_IBAN_CHAR          STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_CUST_AC_NO              STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ALT_CUST_AC_NO          STTMS_CUST_ACCOUNT.ALT_AC_NO%TYPE;
    L_USER_CHECK_DIGIT        STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_IBAN_COUNTRY_CODE       STTMS_BRANCH.IBAN_CNTRY_CD%TYPE;
    L_IBAN_CHK_DGT_ALGORITHM  STTMS_BRANCH.IBAN_CHK_DIG_ALGO%TYPE;
    L_BBAN_FORMAT_MASK        STTMS_BRANCH.BBAN_FORMAT_MSK%TYPE;
    L_BBAN_DATA_TYPE          STTMS_BRANCH.BBAN_DATA_TYPE%TYPE;
    L_CHECK_DIGIT_ALGORITHIM  STTMS_BRANCH.CHK_DIG_ALGO%TYPE;
    L_USER_DEFINED_ALGORITHIM STTMS_BRANCH.USER_DEF_ALGO%TYPE;
    L_BBAN_BRANCH_CODE        STTMS_BRANCH.BBAN_BRN_CODE%TYPE;
    L_BBAN_BANK_CODE          STTMS_BRANCH.BBAN_BANK_CODE%TYPE;
    L_AC_CLASS_TYPE           STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
  BEGIN
    DBG('Inside fn_format_validate_iban_acc');
    L_IBAN_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO;
    DBG('IBAN number to be validated-->' || L_IBAN_AC_NO);
    BEGIN
      DBG('Selecting count from sttms_cust_account');
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE IBAN_AC_NO = L_IBAN_AC_NO
         AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    EXCEPTION

      WHEN OTHERS THEN
        DBG('Error Occured while Getting Iban Ac Number from Sttms_cust_account :  ' ||
            SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
        RETURN FALSE;
    END;

    DBG('l_count: ' || L_COUNT);
    IF L_COUNT <> 0 THEN
      DBG('IBAN Account Number Verification Failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
      RETURN FALSE;
    END IF;
    DBG('Account BRANCH_CODE-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);

    IF NOT CSPKS_IBAN.FN_GET_AC_CLASS_TYPE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                           L_AC_CLASS_TYPE,
                                           L_ERR_CODE) THEN
      DBG('Failed in FN_GET_AC_CLASS_TYPE for iban ' || L_ERR_CODE);
      RETURN FALSE;
    END IF;
    DBG('l_ac_class_type-->' || L_AC_CLASS_TYPE);

    IF NOT CSPKS_IBAN.FN_GET_BBAN_MASKVAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          L_IBAN_COUNTRY_CODE,
                                          L_IBAN_CHK_DGT_ALGORITHM,
                                          L_BBAN_FORMAT_MASK,
                                          L_BBAN_DATA_TYPE,
                                          L_CHECK_DIGIT_ALGORITHIM,
                                          L_USER_DEFINED_ALGORITHIM,
                                          L_BBAN_BRANCH_CODE,
                                          L_BBAN_BANK_CODE,
                                          L_ERR_CODE) THEN
      DBG('Failed in FN_GET_BBAN_MASKVAL for iban ' || L_ERR_CODE);
      RETURN FALSE;
    END IF;
    L_SUBSTR_IBAN_CTY := SUBSTR(L_IBAN_AC_NO, 1, 2);
    DBG('l_substr_iban_cty  -->' || L_SUBSTR_IBAN_CTY);
    DBG('l_iban_country_code-->' || L_IBAN_COUNTRY_CODE);

    IF L_BBAN_FORMAT_MASK IS NOT NULL THEN
      IF L_AC_CLASS_TYPE = 'S' OR L_AC_CLASS_TYPE = 'U' OR
         (L_AC_CLASS_TYPE = 'N' AND L_SUBSTR_IBAN_CTY = L_IBAN_COUNTRY_CODE) THEN

        DBG('l_iban_chk_dgt_algorithm-->' || L_IBAN_CHK_DGT_ALGORITHM);
        IF L_IBAN_CHK_DGT_ALGORITHM IS NOT NULL THEN

          DBG('Calling cspk_iban.fn_iban_chk_digit_gen');
          IF NOT
              CSPK_IBAN.FN_IBAN_CHK_DIGIT_GEN(SUBSTR(L_IBAN_AC_NO, 5),
                                              CHECKDIG,
                                              L_ERR_CODE,
                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
            DBG('l_err_code-->' || L_ERR_CODE);
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN09', '');
            RETURN FALSE;
          ELSE
            DBG('Checkdig: ' || CHECKDIG);
            IF CHECKDIG <> SUBSTR(L_IBAN_AC_NO, 3, 2) THEN
              DBG('IBAN CheckDigit Does Not match with the CheckDigit Generated!');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-IBAN10',
                           L_IBAN_AC_NO);
              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('l_iban_chk_dgt_algorithim is null!');
          PR_LOG_ERROR('STDBRANC',
                       'FLEXCUBE',
                       'ST-IBAN-08'

                      ,
                       ''

                       );
          RETURN FALSE;
        END IF;

        DBG('Country Code Verification!');
        L_SUBSTR_IBAN_CTY := SUBSTR(L_IBAN_AC_NO, 1, 2);
        DBG('l_substr_iban_cty  -->' || L_SUBSTR_IBAN_CTY);
        DBG('l_iban_country_code-->' || L_IBAN_COUNTRY_CODE);
        IF L_SUBSTR_IBAN_CTY <> L_IBAN_COUNTRY_CODE THEN
          IF L_AC_CLASS_TYPE = 'S' OR L_AC_CLASS_TYPE = 'U' THEN
            DBG('Wrong Format for IBAN Account Number!');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-IBAN06',
                         L_IBAN_COUNTRY_CODE);
            RETURN FALSE;
          END IF;
        END IF;

        L_LEN_FORMAT := NVL(LENGTH(L_BBAN_FORMAT_MASK), 0);
        DBG('l_len_format-->' || L_LEN_FORMAT);
        IF LENGTH(L_IBAN_AC_NO) - 4 <> L_LEN_FORMAT THEN
          DBG('IBAN Account Number Does Not match with the BBAN Format Mask!');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN07', '');
          RETURN FALSE;
        END IF;

        DBG('l_bban_data_type-->' || L_BBAN_DATA_TYPE);
        IF L_BBAN_DATA_TYPE IS NOT NULL THEN
          L_START_POS := 1;
          LOOP
            DBG('l_start_pos-->' || L_START_POS);
            L_TEMP_DATA_CHAR := SUBSTR(L_BBAN_DATA_TYPE, L_START_POS, 1);
            L_TEMP_IBAN_CHAR := SUBSTR(SUBSTR(L_IBAN_AC_NO, 5),
                                       L_START_POS,
                                       1);
            IF L_TEMP_DATA_CHAR = 'a' THEN
              DBG('Inside data char ''a''!');
              IF ASCII(UPPER(L_TEMP_IBAN_CHAR)) NOT BETWEEN 65 AND 90 THEN
                DBG('l_bban_data_type is not alpha!');
                PR_LOG_ERROR('STDBRANC',
                             'FLEXCUBE',
                             'ST-IBAN-08'

                            ,
                             ''

                             );
                RETURN FALSE;
              END IF;
            ELSIF L_TEMP_DATA_CHAR = 'n' THEN
              DBG('Inside data char ''n''!');
              IF ASCII(UPPER(L_TEMP_IBAN_CHAR)) NOT BETWEEN 48 AND 57 THEN
                DBG('l_bban_data_type is not numeric!');
                PR_LOG_ERROR('STDBRANC',
                             'FLEXCUBE',
                             'ST-IBAN-08'

                            ,
                             ''

                             );
                RETURN FALSE;
              END IF;
            ELSIF L_TEMP_DATA_CHAR = 'c' THEN
              DBG('Inside data char ''c''!');
              IF ASCII(UPPER(L_TEMP_IBAN_CHAR)) NOT BETWEEN 65 AND 90 AND
                 ASCII(UPPER(L_TEMP_IBAN_CHAR)) NOT BETWEEN 48 AND 57 THEN
                DBG('l_bban_data_type is neither alpha nor numeric!');
                PR_LOG_ERROR('STDBRANC',
                             'FLEXCUBE',
                             'ST-IBAN-08'

                            ,
                             ''

                             );
                RETURN FALSE;
              END IF;
            ELSE
              DBG('l_bban_data_type is invalid!');
              PR_LOG_ERROR('STDBRANC',
                           'FLEXCUBE',
                           'ST-IBAN-08'

                          ,
                           ''

                           );
              RETURN FALSE;
            END IF;
            L_START_POS := L_START_POS + 1;
            EXIT WHEN L_START_POS > LENGTH(L_BBAN_DATA_TYPE);
          END LOOP;
        ELSE
          DBG('l_bban_data_type is null!');
          PR_LOG_ERROR('STDBRANC',
                       'FLEXCUBE',
                       'ST-IBAN-08'

                      ,
                       ''

                       );
          RETURN FALSE;
        END IF;

        L_START_POS       := 1;
        L_TEMP_BBAN_AC_NO := SUBSTR(L_IBAN_AC_NO, 5);
        DBG('l_temp_bban_ac_no-->' || L_TEMP_BBAN_AC_NO);
        LOOP
          DBG('l_start_pos-->' || L_START_POS);
          L_TEMP_MASK_CHAR := SUBSTR(L_BBAN_FORMAT_MASK, L_START_POS, 1);
          PR_END_POS(L_START_POS,
                     L_TEMP_MASK_CHAR,
                     L_BBAN_FORMAT_MASK,
                     L_END_POS);
          IF L_TEMP_MASK_CHAR = 'd' THEN
            DBG('Inside mask char ''d''!');
            L_TEMP_BBAN_AC_NO := RPAD(SUBSTR(L_TEMP_BBAN_AC_NO,
                                             1,
                                             L_START_POS - 1),
                                      L_END_POS,
                                      '0') ||
                                 SUBSTR(L_TEMP_BBAN_AC_NO, L_END_POS + 1);
            DBG('l_temp_bban_ac_no-->' || L_TEMP_BBAN_AC_NO);
          END IF;
          L_START_POS := L_END_POS + 1;
          EXIT WHEN L_START_POS > LENGTH(L_BBAN_FORMAT_MASK);
        END LOOP;
        DBG('Finally l_temp_bban_ac_no check digit positions replaced with zeros-->' ||
            L_TEMP_BBAN_AC_NO);
        L_START_POS := 1;
        DBG('Padded with zero for Check digit-->' || L_TEMP_BBAN_AC_NO);
        IF NOT
            FN_BBAN_CHECK_DIGIT_GENERATION(P_FUNCTION_ID,
                                           L_TEMP_BBAN_AC_NO,
                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
          DBG('Failed!');
        ELSE
          DBG('Succeeded!');
        END IF;
        DBG('l_temp_bban_ac_no-->' || L_TEMP_BBAN_AC_NO);
        IF L_TEMP_BBAN_AC_NO <> SUBSTR(L_IBAN_AC_NO, 5) THEN
          DBG('BBAN CheckDigit Does Not match with the CheckDigit Generated!');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN-08', '');

          RETURN FALSE;
        END IF;

      END IF;
    END IF;
    IF (L_AC_CLASS_TYPE = 'N' AND L_SUBSTR_IBAN_CTY <> L_IBAN_COUNTRY_CODE) THEN
      IF NOT CSPKS_IBAN.FN_VALIDATE_IBAN(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                         'Y',
                                         'N',
                                         L_ERR_CODE,
                                         L_ERR_PARAM) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
        RETURN FALSE;

      END IF;
    END IF;
    DBG('fn_format_validate_iban_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_iban_acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_FORMAT_VALIDATE_IBAN_ACC;

  FUNCTION FN_DETAIL_VALIDATE_IBAN_ACC(P_FUNCTION_ID IN VARCHAR2,
                                       P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                       P_ACTION_CODE IN VARCHAR2)
    RETURN BOOLEAN IS
    L_IBAN_MASK_BANK_CODE      STTMS_BRANCH.IBAN_MASK_BANK_CODE%TYPE;
    L_IBAN_MASK_ACCOUNT_NUMBER STTMS_BRANCH.IBAN_MASK_ACCOUNT_NUMBER%TYPE;
    L_IBAN_AC_NO               STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_COUNTRY_CODE             STTMS_BRANCH.COUNTRY_CODE%TYPE;
    L_ERR_CODE                 VARCHAR2(100);
    L_TO_PAD_ACC               VARCHAR2(30);
    L_SUBSTR_BANK              VARCHAR2(30);
    L_CONCAT_BNKACC            VARCHAR2(30);
    L_SUBSTR_IBAN_CTY          VARCHAR2(20);
    L_SUBSTR_CURR_BRN          VARCHAR2(20);
    L_ACCOUNT_NUMBER           VARCHAR2(20);
    L_BANK_CODE                VARCHAR2(10);
    L_CHECKDIG                 VARCHAR2(2);

    L_LEN_FORMAT      NUMBER;
    L_LENGTH_USER_BNK NUMBER(2);
    L_COUNT           INTEGER := 0;
    L_STAT_FLAG       BOOLEAN := FALSE;
    L_DEF_LV_COUNT    NUMBER;
    L_START_POS       NUMBER;
    L_END_POS         NUMBER;
    CHECKDIG          VARCHAR2(2);
    L_LEN_CUST_AC_NO  NUMBER;
    L_TEMP_MASK_CHAR  STTMS_BRANCH .BBAN_FORMAT_MSK %TYPE;
    L_TEMP_DATA_CHAR  STTMS_BRANCH .BBAN_DATA_TYPE %TYPE;

    L_CUSTOMER_TYPE    STTMS_CUSTOMER .CUSTOMER_TYPE %TYPE;
    L_NATIONAL_ID      STTMS_CUST_PERSONAL .P_NATIONAL_ID %TYPE;
    L_IBAN_ACC_TYPE    STTMS_ACCOUNT_CLASS .IBAN_ACC_TYPE %TYPE;
    L_TEMP_BBAN_AC_NO  STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;
    L_TEMP_IBAN_CHAR   STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;
    L_CUST_AC_NO       STTMS_CUST_ACCOUNT .CUST_AC_NO %TYPE;
    L_ALT_CUST_AC_NO   STTMS_CUST_ACCOUNT .ALT_AC_NO %TYPE;
    L_USER_CHECK_DIGIT STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;

    L_IBAN_COUNTRY_CODE       STTMS_BRANCH.IBAN_CNTRY_CD %TYPE;
    L_IBAN_CHK_DGT_ALGORITHM  STTMS_BRANCH.IBAN_CHK_DIG_ALGO %TYPE;
    L_BBAN_FORMAT_MASK        STTMS_BRANCH.BBAN_FORMAT_MSK %TYPE;
    L_BBAN_DATA_TYPE          STTMS_BRANCH.BBAN_DATA_TYPE %TYPE;
    L_CHECK_DIGIT_ALGORITHIM  STTMS_BRANCH.CHK_DIG_ALGO %TYPE;
    L_USER_DEFINED_ALGORITHIM STTMS_BRANCH.USER_DEF_ALGO %TYPE;
    L_BBAN_BANK_CODE          STTMS_BRANCH.BBAN_BANK_CODE %TYPE;
    L_BBAN_BRANCH_CODE        STTMS_BRANCH.BBAN_BRN_CODE %TYPE;
  BEGIN
    DBG('Inside fn_detail_validate_iban_acc');
    L_IBAN_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO;
    DBG('IBAN number to be validated-->' || L_IBAN_AC_NO);
    BEGIN
      DBG('Selecting count from sttms_cust_account');
      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE IBAN_AC_NO = L_IBAN_AC_NO
         AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    EXCEPTION

      WHEN OTHERS THEN
        DBG('Error Occured while Getting Iban Ac Number from Sttms_cust_account :  ' ||
            SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
        RETURN FALSE;
    END;

    DBG('l_count: ' || L_COUNT);
    IF L_COUNT <> 0 THEN
      DBG('IBAN Account Number Verification Failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
      RETURN FALSE;
    END IF;
    DBG('Account BRANCH_CODE-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);

    IF NOT CSPKS_IBAN.FN_GET_BBAN_MASKVAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          L_IBAN_COUNTRY_CODE,
                                          L_IBAN_CHK_DGT_ALGORITHM,
                                          L_BBAN_FORMAT_MASK,
                                          L_BBAN_DATA_TYPE,
                                          L_CHECK_DIGIT_ALGORITHIM,
                                          L_USER_DEFINED_ALGORITHIM,
                                          L_BBAN_BRANCH_CODE,
                                          L_BBAN_BANK_CODE,
                                          L_ERR_CODE) THEN
      DBG('Failed in FN_GET_BBAN_MASKVAL for iban ' || L_ERR_CODE);
      RETURN FALSE;
    END IF;

    DBG('l_bban_format_mask-->' || L_BBAN_FORMAT_MASK);
    DBG('l_iban_ac_no      -->' || L_IBAN_AC_NO);
    IF L_BBAN_FORMAT_MASK IS NOT NULL THEN
      L_START_POS := 1;
      LOOP
        DBG('l_start_pos-->' || L_START_POS);
        L_TEMP_MASK_CHAR := SUBSTR(L_BBAN_FORMAT_MASK, L_START_POS, 1);
        PR_END_POS(L_START_POS,
                   L_TEMP_MASK_CHAR,
                   L_BBAN_FORMAT_MASK,
                   L_END_POS);
        IF L_TEMP_MASK_CHAR = 'b' THEN
          DBG('Inside mask char ''b''!');

          DBG('l_bban_bank_code-->' || L_BBAN_BANK_CODE);
          IF NOT FN_BBAN_BANK_CODE(P_FUNCTION_ID,
                                   P_STDCUSAC,
                                   P_ACTION_CODE,
                                   L_BBAN_BANK_CODE,
                                   L_END_POS,
                                   L_START_POS,
                                   L_IBAN_AC_NO,
                                   'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 's' THEN
          DBG('Inside mask char ''s''!');
          DBG('l_bban_bank_code-->' || L_BBAN_BANK_CODE);
          IF NOT FN_BBAN_BRANCH_CODE(P_FUNCTION_ID,
                                     P_STDCUSAC,
                                     P_ACTION_CODE,
                                     L_BBAN_BRANCH_CODE,
                                     L_END_POS,
                                     L_START_POS,
                                     L_IBAN_AC_NO,
                                     'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 'z' THEN
          DBG('Inside mask char ''z''!');
          IF NOT FN_BBAN_ACCNO(P_FUNCTION_ID,
                               P_STDCUSAC,
                               P_ACTION_CODE,
                               L_END_POS,
                               L_START_POS,
                               L_IBAN_AC_NO,
                               'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 'l' THEN
          DBG('Inside mask char ''l''!');
          IF NOT FN_BBAN_ALTERNATE_ACCNO(P_FUNCTION_ID,
                                         P_STDCUSAC,
                                         P_ACTION_CODE,
                                         L_END_POS,
                                         L_START_POS,
                                         L_IBAN_AC_NO,
                                         'VALIDATE') THEN
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 'h' THEN
          DBG('Inside mask char ''h''!');
          IF NOT FN_BBAN_JOINTHOLDERS(P_FUNCTION_ID,
                                      P_STDCUSAC,
                                      P_ACTION_CODE,
                                      L_END_POS,
                                      L_START_POS,
                                      L_IBAN_AC_NO,
                                      'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 'i' THEN
          DBG('Inside mask char ''i''!');
          IF NOT FN_BBAN_CUSTOMER_TYPE(P_FUNCTION_ID,
                                       P_STDCUSAC,
                                       P_ACTION_CODE,
                                       L_END_POS,
                                       L_START_POS,
                                       L_IBAN_AC_NO,
                                       'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;

        ELSIF L_TEMP_MASK_CHAR = 't' THEN
          DBG('Inside mask char ''t''!');
          IF NOT FN_BBAN_ACCOUNT_TYPE(P_FUNCTION_ID,
                                      P_STDCUSAC,
                                      P_ACTION_CODE,
                                      L_END_POS,
                                      L_START_POS,
                                      L_IBAN_AC_NO,
                                      'VALIDATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
        ELSIF L_TEMP_MASK_CHAR = 'd' THEN
          DBG('Skipping mask char ''d''!');
        ELSE
          DBG('Mask character is other than allowed ones!');
          RETURN FALSE;
        END IF;
        L_START_POS := L_END_POS + 1;
        EXIT WHEN L_START_POS > LENGTH(L_BBAN_FORMAT_MASK);
      END LOOP;
    ELSE
      DBG('l_bban_format_mask is null!');
    END IF;

    DBG('fn_detail_validate_iban_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_iban_acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_DETAIL_VALIDATE_IBAN_ACC;

  FUNCTION FN_VALIDATE_IBAN_ACC(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
    L_IBAN_MASK_BANK_CODE      STTMS_BRANCH.IBAN_MASK_BANK_CODE%TYPE;
    L_IBAN_MASK_ACCOUNT_NUMBER STTMS_BRANCH.IBAN_MASK_ACCOUNT_NUMBER%TYPE;
    L_IBAN_AC_NO               STTM_CUST_ACCOUNT.IBAN_AC_NO%TYPE;
    L_COUNTRY_CODE             STTMS_BRANCH.COUNTRY_CODE%TYPE;
    L_ERR_CODE                 VARCHAR2(100);
    L_TO_PAD_ACC               VARCHAR2(30);
    L_SUBSTR_BANK              VARCHAR2(30);
    L_CONCAT_BNKACC            VARCHAR2(30);
    L_SUBSTR_IBAN_CTY          VARCHAR2(20);
    L_SUBSTR_CURR_BRN          VARCHAR2(20);
    L_ACCOUNT_NUMBER           VARCHAR2(20);
    L_BANK_CODE                VARCHAR2(10);
    L_CHECKDIG                 VARCHAR2(2);

    L_LEN_FORMAT      NUMBER;
    L_LENGTH_USER_BNK NUMBER(2);
    L_COUNT           INTEGER := 0;
    L_ERR_PARAM       ERTBS_MSGS.MESSAGE%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
  BEGIN
    DBG('Inside fn_validate_iban_acc');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling stpks_stdcusac_utils_1_cluster.fn_pre_validate_iban_acc ');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_PRE_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                                                  P_STDCUSAC,
                                                                  P_ACTION_CODE,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
        DBG('Called to stpks_stdcusac_utils_1_cluster.fn_pre_validate_iban_acc');
      END IF;
    END IF;

    DBG('Calling Format validate IBAN, since IBAN_AC_NO is not null!');
    IF NOT
        FN_FORMAT_VALIDATE_IBAN_ACC(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
      DBG('2: Failed in IBAN Account Number Format Validation');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN-08', '');
      RETURN FALSE;
    END IF;

    IF P_FUNCTION_ID NOT IN ('ACDTFRBT') THEN
      DBG('Calling Detail validate IBAN, since IBAN_AC_NO is not null!');
      IF NOT FN_DETAIL_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                         P_STDCUSAC,
                                         P_ACTION_CODE) THEN
        DBG('2: Failed in IBAN Account Number Detail Validation');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN-09', '');

      END IF;
    END IF;

    DBG('Calling fn_validate_bnkacc');
    IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_bnkacc has returned false');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN08', '');
      RETURN FALSE;
    END IF;
    DBG('fn_validate_iban_acc returning true');
    RETURN TRUE;

    IF P_ACTION_CODE = 'MODIFY' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
      BEGIN
        SELECT IBAN_AC_NO
          INTO L_IBAN_AC_NO
          FROM STTM_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        DBG('Old iban_ac_no:' || L_IBAN_AC_NO);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WHEN OTHERS No iban_ac_no' || SQLERRM);
      END;
      IF L_IBAN_AC_NO IS NOT NULL AND
         L_IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO THEN
        DBG('l_iban_ac_no same..not changd..so no need to validate...');
        RETURN TRUE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
      BEGIN
        DBG('Selecting count from sttms_cust_account');
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT
         WHERE IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO
           AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COUNT := 0;
        WHEN OTHERS THEN
          DBG('Error Occured while Getting Iban Ac Number from Sttms_cust_account :  ' ||
              SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
          RETURN FALSE;
      END;

      DBG('l_count: ' || L_COUNT);
      IF L_COUNT <> 0 THEN
        DBG('IBAN Account Number Verification Failed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
        RETURN FALSE;
      END IF;

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                                              P_STDCUSAC,
                                                              P_ACTION_CODE,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
          DBG('Failed in stpks_stdcusac_utils_cluster.fn_validate_iban_acc');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        DBG('Selecting iban details from sttms_branch');
        SELECT IBAN_MASK_BANK_CODE, IBAN_MASK_ACCOUNT_NUMBER, COUNTRY_CODE
          INTO L_IBAN_MASK_BANK_CODE,
               L_IBAN_MASK_ACCOUNT_NUMBER,
               L_COUNTRY_CODE
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

        L_LEN_FORMAT := 4 + NVL(LENGTH(L_IBAN_MASK_ACCOUNT_NUMBER), 0) +
                        NVL(LENGTH(L_IBAN_MASK_BANK_CODE), 0);
        DBG('l_len_format: ' || L_LEN_FORMAT);
        IF LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO) <>
           L_LEN_FORMAT THEN
          DBG('IBAN Account Number Does Not match with the Format Mask');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN07', '');
          RETURN FALSE;
        END IF;

        DBG('Country Code Verification');
        SELECT COUNTRY_CODE
          INTO L_COUNTRY_CODE
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

        L_SUBSTR_IBAN_CTY := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                    1,
                                    2);
        L_SUBSTR_CURR_BRN := SUBSTR(L_COUNTRY_CODE, 1, 2);
        L_BANK_CODE       := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                    5,
                                    LENGTH(L_IBAN_MASK_BANK_CODE));
        L_ACCOUNT_NUMBER  := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                    5 + LENGTH(L_IBAN_MASK_BANK_CODE));
        DBG('l_iban_mask_bank_code: ' || L_IBAN_MASK_BANK_CODE);
        DBG('l_iban_mask_account_number: ' || L_IBAN_MASK_ACCOUNT_NUMBER);
        DBG('l_account_number: ' || L_ACCOUNT_NUMBER);
        DBG('l_bank_code: ' || L_BANK_CODE);
        DBG('l_country_code: ' || L_COUNTRY_CODE);
        DBG('l_substr_iban_cty: ' || L_SUBSTR_IBAN_CTY);
        DBG('l_substr_curr_brn: ' || L_SUBSTR_CURR_BRN);

        IF L_SUBSTR_IBAN_CTY <> L_SUBSTR_CURR_BRN THEN
          DBG('Wrong Format for IBAN Account Number.');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-IBAN06',
                       L_SUBSTR_CURR_BRN);
          RETURN FALSE;
        END IF;

        DBG('Checking Mask(Bank Code)');
        IF NOT FN_VALIDATE_MASK(P_FUNCTION_ID,
                                'B',
                                L_IBAN_MASK_BANK_CODE,
                                L_BANK_CODE) THEN
          DBG('MisMatch Account Number with Format Mask');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-IBAN02',
                       '@STTMS_CUST_ACCOUNT.CUST_AC_NO~' ||
                       L_IBAN_MASK_ACCOUNT_NUMBER || '~');
          RETURN FALSE;
        END IF;

        DBG('Checking Mask(Account Number)');
        IF NOT FN_VALIDATE_MASK(P_FUNCTION_ID,
                                'A',
                                L_IBAN_MASK_ACCOUNT_NUMBER,
                                L_ACCOUNT_NUMBER) THEN
          DBG('MisMatch Account Number with Format Mask');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-IBAN02',
                       '@STTMS_CUST_ACCOUNT.CUST_AC_NO~' ||
                       L_IBAN_MASK_ACCOUNT_NUMBER || '~');
          RETURN FALSE;
        END IF;

        L_SUBSTR_BANK     := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                    5,
                                    NVL(LENGTH(L_IBAN_MASK_BANK_CODE), 0));
        L_LENGTH_USER_BNK := NVL(LENGTH(L_SUBSTR_BANK), 0);
        L_TO_PAD_ACC      := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                    L_LENGTH_USER_BNK + 4 + 1);
        L_CONCAT_BNKACC   := L_SUBSTR_BANK || L_TO_PAD_ACC;

        IF NOT CSPKS_IBAN.FN_VALIDATE_IBAN(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                           'Y',
                                           'N',
                                           L_ERR_CODE,
                                           L_ERR_PARAM) THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
          RETURN FALSE;

        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

      DBG('Calling fn_validate_bnkacc');
      IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_bnkacc has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling stpks_stdcusac_utils_1_cluster.fn_post_validate_iban_acc ');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_POST_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                                                   P_STDCUSAC,
                                                                   P_ACTION_CODE,
                                                                   L_FN_CALL_ID,
                                                                   L_TB_CLUSTER_DATA) THEN
        DBG('Called to stpks_stdcusac_utils_1_cluster.fn_post_validate_iban_acc');
      END IF;
    END IF;

    DBG('fn_validate_iban_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_iban_acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_IBAN_ACC;

  FUNCTION FN_GEN_IBAN_ACC(P_FUNCTION_ID IN VARCHAR2,
                           P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
    L_IBAN_MASK_BANK_CODE      STTMS_BRANCH.IBAN_MASK_BANK_CODE%TYPE;
    L_IBAN_MASK_ACCOUNT_NUMBER STTMS_BRANCH.IBAN_MASK_ACCOUNT_NUMBER%TYPE;
    L_COUNTRY_CODE             STTMS_BRANCH.COUNTRY_CODE%TYPE;
    L_PADDED_VALUE             VARCHAR2(35);
    CONCAT_BNKACC              VARCHAR2(30);
    CHECKDIG                   VARCHAR2(2);

    ERRCODE VARCHAR2(2000);

    CHECK_DIGIT NUMBER;
    LPAD_NUM    NUMBER;
    L_COUNT     NUMBER;
    B_NUM       NUMBER;
    A_NUM       NUMBER;
    MESG        NUMBER;

    L_STAT_FLAG          BOOLEAN := FALSE;
    L_DEF_LV_COUNT       NUMBER;
    L_START_POS          NUMBER;
    L_END_POS            NUMBER;
    L_LEN_CUST_AC_NO     NUMBER;
    L_JOINT_HOLDER_COUNT NUMBER;
    L_TEMP_H_MASK_VALUE  VARCHAR2(1);
    L_TEMP_MASK_CHAR     STTMS_BRANCH .BBAN_FORMAT_MSK %TYPE;
    L_CUSTOMER_TYPE      STTMS_CUSTOMER .CUSTOMER_TYPE %TYPE;
    L_NATIONAL_ID        STTMS_CUST_PERSONAL .P_NATIONAL_ID %TYPE;
    L_IBAN_ACC_TYPE      STTMS_ACCOUNT_CLASS .IBAN_ACC_TYPE %TYPE;
    L_CUST_AC_NO         STTMS_CUST_ACCOUNT .CUST_AC_NO %TYPE;
    L_ALT_CUST_AC_NO     STTM_CUST_ACCOUNT.ALT_AC_NO %TYPE;
    L_TEMP_IBAN_LEN      NUMBER;
    L_TEMP_IBAN_AC_NO    STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;
    L_IBAN_AC_NO         STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;
    L_USER_CHECK_DIGIT   STTMS_CUST_ACCOUNT .IBAN_AC_NO %TYPE;

    L_IBAN_COUNTRY_CODE       STTMS_BRANCH.IBAN_CNTRY_CD %TYPE;
    L_IBAN_CHK_DGT_ALGORITHM  STTMS_BRANCH.IBAN_CHK_DIG_ALGO %TYPE;
    L_BBAN_FORMAT_MASK        STTMS_BRANCH.BBAN_FORMAT_MSK %TYPE;
    L_BBAN_DATA_TYPE          STTMS_BRANCH.BBAN_DATA_TYPE %TYPE;
    L_CHECK_DIGIT_ALGORITHIM  STTMS_BRANCH.CHK_DIG_ALGO %TYPE;
    L_USER_DEFINED_ALGORITHIM STTMS_BRANCH.USER_DEF_ALGO %TYPE;
    L_BBAN_BANK_CODE          STTMS_BRANCH.BBAN_BANK_CODE %TYPE;
    L_BBAN_BRANCH_CODE        STTMS_BRANCH.BBAN_BRN_CODE %TYPE;

    L_FLD_DESC CSTB_LABELS.LABEL_DESCRIPTION%TYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Inside fn_gen_iban_acc');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling stpks_stdcusac_utils_1_cluster.fn_pre_gen_iban_acc ');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_PRE_GEN_IBAN_ACC(P_FUNCTION_ID,
                                                             P_STDCUSAC,
                                                             P_ACTION_CODE,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DBG('Called to stpks_stdcusac_utils_1_cluster.fn_pre_gen_iban_acc');
      END IF;
    END IF;

    DBG('Account BRANCH_CODE-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);

    IF NOT CSPKS_IBAN.FN_GET_BBAN_MASKVAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          L_IBAN_COUNTRY_CODE,
                                          L_IBAN_CHK_DGT_ALGORITHM,
                                          L_BBAN_FORMAT_MASK,
                                          L_BBAN_DATA_TYPE,
                                          L_CHECK_DIGIT_ALGORITHIM,
                                          L_USER_DEFINED_ALGORITHIM,
                                          L_BBAN_BRANCH_CODE,
                                          L_BBAN_BANK_CODE,
                                          ERRCODE) THEN
      DBG('Failed in FN_GET_BBAN_MASKVAL for iban ' || ERRCODE);
      RETURN FALSE;
    END IF;
    DBG('l_bban_format_mask-->' || L_BBAN_FORMAT_MASK);
    IF L_BBAN_FORMAT_MASK IS NOT NULL THEN
      L_IBAN_AC_NO := NULL;
      L_START_POS  := 1;
      LOOP
        DBG('l_start_pos-->' || L_START_POS);
        L_TEMP_MASK_CHAR := SUBSTR(L_BBAN_FORMAT_MASK, L_START_POS, 1);
        PR_END_POS(L_START_POS,
                   L_TEMP_MASK_CHAR,
                   L_BBAN_FORMAT_MASK,
                   L_END_POS);
        IF L_TEMP_MASK_CHAR = 'b' THEN
          DBG('Inside mask char ''b''!');
          DBG('l_bban_bank_code-->' || L_BBAN_BANK_CODE);
          IF NOT FN_BBAN_BANK_CODE(P_FUNCTION_ID,
                                   P_STDCUSAC,
                                   P_ACTION_CODE,
                                   L_BBAN_BANK_CODE,
                                   L_END_POS,
                                   L_START_POS,
                                   L_IBAN_AC_NO,
                                   'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 's' THEN
          DBG('Inside mask char ''s''!');
          DBG('l_bban_branch_code-->' || L_BBAN_BRANCH_CODE);
          IF NOT FN_BBAN_BRANCH_CODE(P_FUNCTION_ID,
                                     P_STDCUSAC,
                                     P_ACTION_CODE,
                                     L_BBAN_BRANCH_CODE,
                                     L_END_POS,
                                     L_START_POS,
                                     L_IBAN_AC_NO,
                                     'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 'z' THEN
          DBG('Inside mask char ''z''!');
          DBG('cust_ac_no-->' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
          IF NOT FN_BBAN_ACCNO(P_FUNCTION_ID,
                               P_STDCUSAC,
                               P_ACTION_CODE,
                               L_END_POS,
                               L_START_POS,
                               L_IBAN_AC_NO,
                               'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 'l' THEN
          DBG('Inside mask char ''l''!');
          DBG('alt_ac_no-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO);
          IF NOT FN_BBAN_ALTERNATE_ACCNO(P_FUNCTION_ID,
                                         P_STDCUSAC,
                                         P_ACTION_CODE,
                                         L_END_POS,
                                         L_START_POS,
                                         L_IBAN_AC_NO,
                                         'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 'h' THEN
          DBG('Inside mask char ''h''!');
          L_JOINT_HOLDER_COUNT := P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
          IF NOT FN_BBAN_JOINTHOLDERS(P_FUNCTION_ID,
                                      P_STDCUSAC,
                                      P_ACTION_CODE,
                                      L_END_POS,
                                      L_START_POS,
                                      L_IBAN_AC_NO,
                                      'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          L_IBAN_AC_NO := L_IBAN_AC_NO || L_TEMP_H_MASK_VALUE;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 'i' THEN
          DBG('Inside mask char ''i''!');
          IF NOT FN_BBAN_CUSTOMER_TYPE(P_FUNCTION_ID,
                                       P_STDCUSAC,
                                       P_ACTION_CODE,
                                       L_END_POS,
                                       L_START_POS,
                                       L_IBAN_AC_NO,
                                       'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 't' THEN
          DBG('Inside mask char ''t''!');
          IF NOT FN_BBAN_ACCOUNT_TYPE(P_FUNCTION_ID,
                                      P_STDCUSAC,
                                      P_ACTION_CODE,
                                      L_END_POS,
                                      L_START_POS,
                                      L_IBAN_AC_NO,
                                      'GENERATE') THEN
            DBG('Failed!');
            RETURN FALSE;
          ELSE
            DBG('Succeeded!');
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSIF L_TEMP_MASK_CHAR = 'd' THEN
          DBG('Inside mask char ''d''!');
          IF L_CHECK_DIGIT_ALGORITHIM IS NOT NULL THEN
            DBG('l_check_digit_algorithim-->' || L_CHECK_DIGIT_ALGORITHIM);
            L_TEMP_IBAN_AC_NO := L_IBAN_AC_NO;
            DBG('Before padding with zero for Check digit-->' ||
                L_TEMP_IBAN_AC_NO);
            L_TEMP_IBAN_LEN := LENGTH(L_TEMP_IBAN_AC_NO) + L_END_POS -
                               L_START_POS + 1;
            DBG('l_temp_iban_len-->' || L_TEMP_IBAN_LEN);
            L_TEMP_IBAN_AC_NO := RPAD(L_TEMP_IBAN_AC_NO,
                                      L_TEMP_IBAN_LEN,
                                      '0');
            DBG('After padding with zero for Check digit-->' ||
                L_TEMP_IBAN_AC_NO);
            L_IBAN_AC_NO := L_TEMP_IBAN_AC_NO;
          ELSE
            DBG('l_check_digit_algorithim is null!');

            L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                           'STDBRANC',
                                                           'STTMS_BRANCH.CHK_DIG_ALGO');
            DBG('l_fld_desc is ' || L_FLD_DESC);

            PR_LOG_ERROR('STDBRANC',
                         'FLEXCUBE',
                         'ST-IBAN-06'

                        ,
                         L_FLD_DESC

                         );
            RETURN FALSE;
          END IF;
          DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
        ELSE
          DBG('Mask character is other than allowed ones!');
          RETURN FALSE;
        END IF;
        L_START_POS := L_END_POS + 1;
        EXIT WHEN L_START_POS > LENGTH(L_BBAN_FORMAT_MASK);
      END LOOP;
    ELSE
      DBG('l_bban_format_mask is null!');
      RETURN TRUE;
    END IF;

    DBG('BBAN CheckDigit Generation!');
    L_START_POS       := 1;
    L_TEMP_IBAN_AC_NO := L_IBAN_AC_NO;
    DBG('Padded with zero for Check digit-->' || L_TEMP_IBAN_AC_NO);
    IF NOT
        FN_BBAN_CHECK_DIGIT_GENERATION(P_FUNCTION_ID,
                                       L_TEMP_IBAN_AC_NO,
                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
      DBG('Failed!');
      RETURN FALSE;
    ELSE
      DBG('Succeeded!');
    END IF;

    L_IBAN_AC_NO := L_TEMP_IBAN_AC_NO;
    DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);

    DBG('IBAN CheckDigit Generation!');
    IF L_IBAN_CHK_DGT_ALGORITHM IS NOT NULL THEN

      DBG('Calling cspk_iban.fn_iban_check_digit_gen');
      IF NOT
          CSPK_IBAN.FN_IBAN_CHK_DIGIT_GEN(L_IBAN_AC_NO,
                                          CHECKDIG,
                                          ERRCODE,
                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN14', '');
        RETURN FALSE;
      ELSE
        DBG('Checkdig: ' || CHECKDIG);
        L_IBAN_AC_NO := L_IBAN_COUNTRY_CODE || CHECKDIG || L_IBAN_AC_NO;
      END IF;

      DBG('IBAN number Genrated-->' || L_IBAN_AC_NO);
    ELSE

      L_FLD_DESC := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC('FLEXCUBE',
                                                     'STDBRANC',
                                                     'STTMS_BRANCH.CHK_DIG_ALGO');
      DBG('l_fld_desc is ' || L_FLD_DESC);

      DBG('l_iban_chk_dgt_algorithim is null!');
      PR_LOG_ERROR('STDBRANC',
                   'FLEXCUBE',
                   'ST-IBAN-06'

                  ,
                   L_FLD_DESC

                   );
      RETURN FALSE;
    END IF;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO := L_IBAN_AC_NO;
    DBG('IBAN Acc no: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT
         WHERE IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO
           AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      EXCEPTION

        WHEN OTHERS THEN
          DBG('Error Occured while Getting Iban Ac Number from Sttms_cust_account');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
          RETURN FALSE;
      END;
      IF L_COUNT <> 0 THEN
        DBG('IBAN Account Number Verification Failed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Calling fn_validate_bnkacc');
    IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('Failed in IBAN Account Number Validation');
      RETURN FALSE;
    END IF;

    DBG('Calling Format validate IBAN, since IBAN_AC_NO is not null!');
    IF NOT
        FN_FORMAT_VALIDATE_IBAN_ACC(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
      DBG('2: Failed in IBAN Account Number Format Validation');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN-08', '');
      RETURN FALSE;
    END IF;

    DBG('fn_gen_iban_acc returning true');
    RETURN TRUE;

    DBG('IBAN bank code: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13);
    DBG('IBAN account no: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);

    CONCAT_BNKACC := CONCAT(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13,
                            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12);

    BEGIN
      DBG('Selecting from sttms_branch');
      SELECT IBAN_MASK_BANK_CODE, IBAN_MASK_ACCOUNT_NUMBER, COUNTRY_CODE
        INTO L_IBAN_MASK_BANK_CODE,
             L_IBAN_MASK_ACCOUNT_NUMBER,
             L_COUNTRY_CODE
        FROM STTMS_BRANCH
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Error Occured while Getting IBAN Masks details :  ' ||
            SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-181', '');
        RETURN FALSE;
    END;
    DBG('l_iban_mask_bank_code: ' || L_IBAN_MASK_BANK_CODE);
    DBG('l_iban_mask_account_number: ' || L_IBAN_MASK_ACCOUNT_NUMBER);
    DBG('l_country_code: ' || L_COUNTRY_CODE);

    DBG('Bank code: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13);
    DBG('Acc no: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12);
    IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 IS NULL AND
       P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12 IS NULL THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN01', '');
      RETURN FALSE;
    END IF;

    DBG('Selecting from pctms_bank_param');
    SELECT COUNT(*)
      INTO L_COUNT
      FROM PCTMS_BANK_PARAM
     WHERE RECORD_STAT = 'O'
       AND AUTH_STAT = 'A'
       AND BANK_CODE = P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13;

    IF L_COUNT = 0 THEN
      DBG('Invalid IBAN Bank code..');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-ACC-115',
                   '@CSTBS_UI_COLUMNS.CHAR_FIELD13~' ||
                   P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 || '~');
      RETURN FALSE;
    END IF;

    IF LENGTH(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13) >
       LENGTH(L_IBAN_MASK_BANK_CODE) THEN
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-ACC-115',
                   '@CSTBS_UI_COLUMNS.CHAR_FIELD13~' ||
                   L_IBAN_MASK_BANK_CODE || '~');
      RETURN FALSE;
    END IF;

    L_PADDED_VALUE := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13;
    LPAD_NUM       := FN_LEFTPAD(P_FUNCTION_ID,
                                 'B',
                                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13,
                                 L_IBAN_MASK_BANK_CODE,
                                 L_IBAN_MASK_ACCOUNT_NUMBER,
                                 L_PADDED_VALUE);
    DBG('1: l_padded_value: ' || L_PADDED_VALUE);
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 := L_PADDED_VALUE;
    DBG('lpad_num:' || LPAD_NUM);
    IF LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO) >
       LENGTH(L_IBAN_MASK_ACCOUNT_NUMBER) THEN
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-IBAN02',
                   '@STTMS_CUST_ACCOUNT.IBAN_AC_NO~' ||
                   L_IBAN_MASK_ACCOUNT_NUMBER || '~');
    END IF;
    L_PADDED_VALUE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO;
    LPAD_NUM       := FN_LEFTPAD(P_FUNCTION_ID,
                                 'A',
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                 L_IBAN_MASK_BANK_CODE,
                                 L_IBAN_MASK_ACCOUNT_NUMBER,
                                 L_PADDED_VALUE);
    DBG('2: l_padded_value: ' || L_PADDED_VALUE);
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO := L_PADDED_VALUE;
    DBG('lpad_num: ' || LPAD_NUM);

    DBG('Validating the Bank mask');
    IF NOT FN_VALIDATE_MASK(P_FUNCTION_ID,
                            'B',
                            L_IBAN_MASK_BANK_CODE,
                            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13) THEN
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-IBAN02',
                   '@CSTBS_UI_COLUMNS.CHAR_FIELD13~' ||
                   L_IBAN_MASK_BANK_CODE || '~');
      RETURN FALSE;
    END IF;

    DBG('Validating the Account mask');
    IF NOT FN_VALIDATE_MASK(P_FUNCTION_ID,
                            'A',
                            L_IBAN_MASK_ACCOUNT_NUMBER,
                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO) THEN
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-IBAN02',
                   '@STTMS_CUST_ACCOUNT.IBAN_AC_NO~' ||
                   L_IBAN_MASK_ACCOUNT_NUMBER || '~');
      RETURN FALSE;
    END IF;

    DBG('Calling cspk_iban.fn_iban_check_digit_gen');
    IF NOT
        CSPK_IBAN.FN_IBAN_CHECK_DIGIT_GEN(CONCAT_BNKACC, CHECKDIG, ERRCODE) THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN14', '');
      RETURN FALSE;
    ELSE
      DBG('Checkdig: ' || CHECKDIG);
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO := CONCAT(SUBSTR(L_COUNTRY_CODE,
                                                                  1,
                                                                  2),
                                                           CONCAT(CHECKDIG,
                                                                  CONCAT_BNKACC));
      DBG('IBAN number Genrated: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    END IF;

    DBG('IBAN Acc no: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT
         WHERE IBAN_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO
           AND CUST_AC_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COUNT := 0;
        WHEN OTHERS THEN
          DBG('Error Occured while Getting Iban Ac Number from Sttms_cust_account');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
          RETURN FALSE;
      END;
      IF L_COUNT <> 0 THEN
        DBG('IBAN Account Number Verification Failed');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS30', '');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Calling fn_validate_bnkacc');
    IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('Failed in IBAN Account Number Validation');
      RETURN FALSE;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      DBG('Calling stpks_stdcusac_utils_1_cluster.fn_post_gen_iban_acc ');
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_POST_GEN_IBAN_ACC(P_FUNCTION_ID,
                                                              P_STDCUSAC,
                                                              P_ACTION_CODE,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
        DBG('Called to stpks_stdcusac_utils_1_cluster.fn_post_gen_iban_acc');
      END IF;
    END IF;

    DBG('fn_gen_iban_acc returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_iban_acc with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_GEN_IBAN_ACC;

  FUNCTION FN_VALIDATE_IBAN(P_FUNCTION_ID IN VARCHAR2,
                            P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS

    L_ERR_CODE    ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM   VARCHAR2(100);
    L_PARAM_VALUE CSTBS_PARAM.PARAM_VAL%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_IBAN_AC_NO    STTMS_CUST_ACCOUNT.IBAN_AC_NO %TYPE;

  BEGIN
    DBG('Inside fn_validate_IBAN');
    DBG('IBAN Reqd: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10);
    DBG('IBAN Bank code: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13);
    DBG('IBAN Acc no: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    DBG('IBAN Acc no from subscreen: ' ||
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12);
    DBG('IBAN Bank code: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);
    DBG('IBAN Account Number Validation');

    IF NOT CSPKS_IBAN.FN_GET_AC_CLASS_TYPE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                           L_AC_CLASS_TYPE,
                                           L_ERR_CODE) THEN
      DBG('Failed in FN_GET_AC_CLASS_TYPE for iban ' || L_ERR_CODE);
      RETURN FALSE;
    END IF;
    DBG('l_ac_class_type-->' || L_AC_CLASS_TYPE);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED = 'Y' THEN
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW OR
         P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        IF L_AC_CLASS_TYPE IN ('S', 'U') THEN
          DBG('IBAN_AC_NO before Generation/Validation-->' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NULL THEN
            DBG('Calling Generate IBAN, since IBAN_AC_NO is null!');
            IF NOT FN_GEN_IBAN_ACC(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
              DBG('1: Failed in IBAN Account Number Generation');
              G_ERR_FLAG := -1;
              DBG('assigned false to err flag');
            END IF;
          ELSE
            DBG('Calling validate IBAN, since IBAN_AC_NO is not null!');

            IF NOT FN_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                        P_STDCUSAC,
                                        P_ACTION_CODE) THEN
              DBG('2: Failed in IBAN Account Number Validation');
              G_ERR_FLAG := -1;
              DBG('assigned false to err flag');
            END IF;
          END IF;
        ELSIF L_AC_CLASS_TYPE = 'N' THEN
          DBG('IBAN_AC_NO before Generation/Validation-->' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
            DBG('Calling validate IBAN, since IBAN_AC_NO is not null!');

            DBG('Calling Format validate IBAN, since IBAN_AC_NO is not null!');
            IF NOT FN_FORMAT_VALIDATE_IBAN_ACC(P_FUNCTION_ID,
                                               P_STDCUSAC,
                                               P_ACTION_CODE) THEN
              DBG('2: Failed in IBAN Account Number Format Validation');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN-08', '');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('fn_validate_IBAN returning true');
    RETURN TRUE;

    DBG('Going into Cluster/Custom Call to Generate Site Specific IBAN, if any.');
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('Calling Stpks_Stdcusac_Utils_cluster.Fn_Validate_Iban');
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_IBAN(P_FUNCTION_ID,
                                                        P_STDCUSAC,
                                                        P_ACTION_CODE,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA) THEN
        DBG('Failed in Stpks_Stdcusac_Utils_cluster.Fn_Validate_Iban');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('Not Skipping the Kernel Code');

      IF (P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL) AND
         P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10 = 'N' THEN
        DBG('Mandatory Element IBAN A/c No should be NULL');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-182', '');
        G_ERR_FLAG := -1;
        DBG('1');
        DBG('assigned false to err flag');
      END IF;

      DBG('Further IBAN processing');
      IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10 = 'Y' THEN
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
          IF NOT
              FN_VALIDATE_IBAN_ACC(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
            DBG('1: Failed in IBAN Account Number Validation');
            G_ERR_FLAG := -1;
            DBG('2');
            DBG('assigned false to err flag');
          END IF;
        ELSE
          IF NOT FN_GEN_IBAN_ACC(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
            DBG('2: Failed in IBAN Account Number Validation');
            G_ERR_FLAG := -1;
            DBG('3');
            DBG('assigned false to err flag');
          END IF;

          BEGIN

            L_PARAM_VALUE := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('IBANPLUS_REQD'),
                                 'N');

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_PARAM_VALUE := 'N';
          END;
          IF L_PARAM_VALUE = 'Y' THEN
            IF NOT CSPK_IBAN.FN_VALIDATE_NATIONAL_ID(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO,
                                                     L_ERR_CODE,
                                                     L_ERR_PARAM) THEN
              DEBUG.PR_DEBUG('PC',
                             'Failed in fn_validate_national_id for iban ' ||
                             L_ERR_CODE);
              G_ERR_FLAG := -1;
              DBG('4');
            END IF;
          END IF;

        END IF;
      END IF;

    ELSE
      DBG('Skipping the Kernel Code');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('fn_validate_IBAN returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_IBAN with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_IBAN;

  FUNCTION FN_VALIDATE_TRNOVER_LIMIT_CODE(P_FUNCTION_ID IN VARCHAR2,
                                          P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_COUNT_LIMIT_CCY NUMBER := 0;
    L_COUNT           NUMBER := 0;
    L_COUNT_TRN       NUMBER := 0;
    L_LIMIT_PRD       STTMS_TURNOVER_PERIODS.LIMIT_PRD%TYPE;

  BEGIN
    DBG('Inside fn_validate_trnover_limit_code');

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE IS NOT NULL THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
           AND TRNOVER_LMT_CODE =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
           AND ONCE_AUTH = 'Y'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Oracle Error :' || SQLERRM);
          RETURN FALSE;
      END;

      BEGIN
        SELECT 1
          INTO L_COUNT_TRN
          FROM STTMS_TURNOVER_LIMIT
         WHERE LIMIT_CODE =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
           AND ONCE_AUTH = 'Y'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Inside no_data_found-->>l_trnover_lmt_code' || SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSTLC03', '');
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('Oracle Error :' || SQLERRM);
          RETURN FALSE;
      END;

      IF L_COUNT <> 0 THEN
        BEGIN
          SELECT LIMIT_PRD
            INTO L_LIMIT_PRD
            FROM STTMS_TURNOVER_PERIODS
           WHERE LIMIT_CODE =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
             AND TO_DATE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) BETWEEN
                 LIMIT_START_DATE AND LIMIT_END_DATE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Inside no_data_found-->>LIMIT_PRD' || SQLERRM);
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSTLC01', '');
            RETURN FALSE;
          WHEN OTHERS THEN
            DBG('Oracle Error :' || SQLERRM);
            RETURN FALSE;
        END;

        BEGIN
          SELECT COUNT(LIMIT_CCY)
            INTO L_COUNT_LIMIT_CCY
            FROM STTMS_TURNOVER_LMT_AMT
           WHERE LIMIT_PRD = L_LIMIT_PRD
             AND LIMIT_CODE =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE
             AND LIMIT_CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_COUNT_LIMIT_CCY := 0;
            DBG('Inside no_data_found-->>limit_ccy' || SQLERRM);
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-CUSTLC02',
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY || '~' ||
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE || '~');
            RETURN FALSE;
          WHEN OTHERS THEN
            DBG('Oracle Error :' || SQLERRM);
            DBG('Inside when others then limit_ccy');
            RETURN FALSE;
        END;

        IF L_COUNT_LIMIT_CCY <> 1 THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-CUSTLC02',
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY || '~' ||
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE || '~');
          RETURN FALSE;
        ELSE
          DBG('l_count_limit_ccy' || L_COUNT_LIMIT_CCY);
          RETURN TRUE;
        END IF;
      ELSE
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSTLC03', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('fn_validate_trnover_limit_code returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_trnover_limit_code with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_TRNOVER_LIMIT_CODE;

  FUNCTION FN_VALIDATE_ATM_AC_NO(P_FUNCTION_ID IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS

    L_ATM_AC_NO  VARCHAR(20);
    L_OLD_ATM_AC VARCHAR(20);
    L_ATM_BRN    VARCHAR(3);
    L_BOOLEAN    BOOLEAN := TRUE;
    L_COUNT      INTEGER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Inside fn_validate_atm_ac_no with atm no: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_VALIDATE_ATM_AC_NO(P_FUNCTION_ID,
                                                               P_STDCUSAC,
                                                               P_ACTION_CODE,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_1_cluster.fn_validate_atm_ac_no');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('Not Skipping the Kernel Code');

      BEGIN
        SELECT LPAD(COD_ATM_BRANCH, 3, '0')
          INTO L_ATM_BRN
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT of cod_atm_branch: ' || SQLERRM);
          NULL;
      END;
      DBG('l_atm_brn: ' || L_ATM_BRN);

      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY, 'N') = 'N' THEN

        DBG(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY || '-' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO || '-' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_AMT_LIMIT || '-' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_COUNT_LIMIT);
        IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO IS NOT NULL) OR
           (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_AMT_LIMIT, 0) > 0) OR
           (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_DLY_COUNT_LIMIT, 0) > 0) THEN

          DBG('ATM Account Number Should be NULL');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IFATM-030',
                       '@STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_ACTION_CODE = 'MODIFY' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO IS NOT NULL THEN
        BEGIN
          SELECT ATM_CUST_AC_NO
            INTO L_OLD_ATM_AC
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          DBG('Old l_old_atm_ac:' || L_OLD_ATM_AC);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('WHEN OTHERS No iban_ac_no' || SQLERRM);
        END;
        IF L_OLD_ATM_AC IS NOT NULL AND
           L_OLD_ATM_AC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO THEN
          DBG('atm_cust_ac_no same..not changd..so no need to validate...');
          RETURN TRUE;
        END IF;
      END IF;

      IF LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO) <= 10 THEN
        DBG('Length of ATM no is <= 10... so continue processing');
      ELSE
        DBG('Full ATM no has been entered... So, check for its validity');
        IF L_ATM_BRN IS NOT NULL THEN
          DBG('Checking whether the first 3 chars of the ATM no is the ATM branch code');
          IF SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO, 1, 3) <>
             L_ATM_BRN THEN
            DBG('The ATM no entered is invalid');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IFATM-029', '');
            RETURN FALSE;
          ELSE
            DBG('Valid no entered... Lets cut down the branch code... only to append it later');
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO := SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO,
                                                                     4);
          END IF;
        END IF;
      END IF;
      DBG('After all this circus, the ATM no is: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);

      IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO IS NOT NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL) THEN
        FOR LOOP1 IN 1 .. LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO) LOOP
          IF SUBSTR(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO,
                    LOOP1,
                    1) NOT IN
             ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0') THEN
            L_BOOLEAN := FALSE;
            EXIT;
          END IF;
        END LOOP;

        IF NOT L_BOOLEAN THEN
          DBG('ATM Account Number Should be Numeric');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-157', '');
          RETURN FALSE;
        END IF;

        IF L_BOOLEAN THEN
          L_ATM_AC_NO                                    := L_ATM_BRN ||
                                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO := L_ATM_AC_NO;
          DBG('ATM A.c No:' || L_ATM_AC_NO);
          DBG('ATM Account Account Number : ' || L_ATM_AC_NO);

          DBG('-------Checkpoint--------');
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTMS_CUST_ACCOUNT
             WHERE BRANCH_CODE =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ATM_CUST_AC_NO = L_ATM_AC_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_COUNT := 0;
          END;
          IF L_COUNT > 0 THEN
            DBG('ATM Account Number Validation Failed');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IFATM-002', '');

          END IF;
        END IF;
      ELSE
        IF PKG_SOURCE = 'FLEXCUBE' THEN
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY = 'Y' AND
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO IS NULL THEN
            DBG('ATM Account Number is NULL');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSAT02', '');

          END IF;
        END IF;
      END IF;

    ELSE
      DBG('Skipping the Kernel Code');
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('fn_validate_atm_ac_no returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_atm_ac_no with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ATM_AC_NO;

  FUNCTION FN_VALIDATE_DEFER_RECON(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_validate_defer_recon');
    DBG('Defer Recon Passed :  ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON);
    IF ((P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'N' AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON, 'N') <> 'N')) THEN
      DBG('Deferred Reconciliation Check failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0096', '');
      RETURN FALSE;
    END IF;
    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'Y' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON NOT IN ('Y', 'N')) THEN
      DBG('Deferred Reconciliation Check failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0095', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'Y' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DEFER_RECON = 'Y' AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING, 'N') <> 'N' THEN
      DBG('Funding check failed for defer recon');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-150', '');
      RETURN FALSE;
    END IF;
    DBG('fn_validate_defer_recon returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_defer_recon with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_DEFER_RECON;

  FUNCTION FN_VALIDATE_FUNDING(P_FUNCTION_ID IN VARCHAR2,
                               P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_COUNT INTEGER := 0;
  BEGIN
    DBG('Inside fn_validate_funding');
    DBG('Funding Passed :  ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'N' AND
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD9_VALIDATION_REQD = 'Y' OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING = 'Y') THEN
      DBG('Funding and Mod 9 Validation Required cannot be checked if Positive Pay is unchecked.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-175', '');
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'Y' THEN
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING, 'N') = 'Y' THEN
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH IS NULL THEN
          DBG('Funding Branch Can not be NULL.');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-MAN01',
                       '@STTMS_CUST_ACCOUNT.FUNDING_BRANCH');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT IS NULL THEN
          DBG('Funding Account Can not be NULL.');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-MAN01',
                       '@STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO =
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT THEN
          DBG('Funding account and customer account cannot be same');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-106', '');
          RETURN FALSE;
        END IF;

        DBG('Validating for valid funding branch');
        SELECT COUNT(1)
          INTO L_COUNT
          FROM STTMS_BRANCH
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH
           AND RECORD_STAT = 'O'
           AND AUTH_STAT = 'A';
        IF L_COUNT = 0 THEN
          DBG('The Funding Branch for the Customer is not Valid.');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-107',
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH || '~');
          RETURN FALSE;
        END IF;
        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O'
           AND NOT EXISTS
         (SELECT 1
                  FROM DUAL
                 WHERE CUST_AC_NO =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        IF L_COUNT = 0 THEN
          DBG('No funding account available for this customer');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-108',
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT || '~');
          RETURN FALSE;
        END IF;
      ELSE
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH IS NOT NULL THEN
          DBG('Funding Branch Should be NULL.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-110', '');
          RETURN FALSE;
        END IF;
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT IS NOT NULL THEN
          DBG('Funding Account Should be NULL.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-109', '');
          RETURN FALSE;
        END IF;
      END IF;
    ELSE
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_BRANCH IS NOT NULL THEN
        DBG('Funding Branch Should be NULL.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-110', '');
        RETURN FALSE;
      END IF;
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.FUNDING_ACCOUNT IS NOT NULL THEN
        DBG('Funding Account Should be NULL.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-109', '');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_validate_funding returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_funding with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_FUNDING;

  FUNCTION FN_VALIDATE_AUTOREORDER(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CHEQUE_BOOK_FACILITY CHAR;
    L_LODGEMENT_BOOK       CHAR;
    L_ERR_FLAG             NUMBER := 0;
  BEGIN
    DBG('Inside fn_validate_autoreorder');
    DBG('Auto reorder check required: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED);
    DBG('Cheque book facility: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY);
    DBG('Cheque book name 1: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1);

    SELECT NVL(CHEQUE_BOOK_FACILITY, 'N'), NVL(LODGEMENT_BOOK, 'N')
      INTO L_CHEQUE_BOOK_FACILITY, L_LODGEMENT_BOOK
      FROM STTMS_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    DBG('l_cheque_book_facility: ' || L_CHEQUE_BOOK_FACILITY);
    DBG('l_lodgement_book: ' || L_LODGEMENT_BOOK);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LODGEMENT_BOOK_FACILITY <>
       L_LODGEMENT_BOOK THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS63', '');
    END IF;
    DBG('PKG_SOURCE-->' || PKG_SOURCE);
    IF PKG_SOURCE = 'FLEXCUBE' THEN
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY, 'N') = 'Y' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1 IS NULL THEN
        DBG('Cheque book Name is missing');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS70', '');
        L_ERR_FLAG := -1;
      END IF;
    END IF;

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY, 'N') = 'N' AND
       (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED,
            'N') = 'Y' OR
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1 IS NOT NULL OR
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2 IS NOT NULL) THEN
      DBG('Auto Re-order check failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-111', '');
      L_ERR_FLAG := -1;
    END IF;

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED, 'N') = 'Y' THEN
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES, 0) <= 0 THEN
        DBG('The Check Level and Leaves are Wrong value. 1');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-MAN01',
                     '@STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES');
        L_ERR_FLAG := -1;
      ELSIF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL, 0) <= 0 THEN
        DBG('Auto reorder chq is Y but auto_reorder_check_level is  null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-MAN01',
                     '@STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL');
        L_ERR_FLAG := -1;
      END IF;
    END IF;
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED, 'N') = 'N' THEN
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL, 0) <> 0 THEN
        DBG('The Check Level and Leaves are Wrong value.');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-ACC-153',
                     '@STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL');
        L_ERR_FLAG := -1;
      ELSIF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES,
                0) <> 0 THEN
        DBG('Auto reorder chq is N but auto_reorder_check_leaves is not null');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-ACC-153',
                     '@STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES');
        L_ERR_FLAG := -1;
      END IF;
    END IF;

    IF L_ERR_FLAG = -1 THEN
      DBG('fn_validate_autoreorder returning false');
      RETURN FALSE;
    END IF;

    DBG('fn_validate_autoreorder returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_autoreorder with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_AUTOREORDER;

  FUNCTION FN_VALIDATE_REGD(P_FUNCTION_ID IN VARCHAR2,
                            P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_REGD_APPLICABLE CHAR(1);
  BEGIN
    DBG('Inside fn_validate_regD');

    BEGIN
      SELECT REG_D_APPLICABLE
        INTO L_REGD_APPLICABLE
        FROM STTM_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Error with: ' || SQLERRM);
        RETURN FALSE;
    END;
    DBG('l_regd_applicable ' || L_REGD_APPLICABLE);

    IF L_REGD_APPLICABLE = 'Y' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE = 'Y' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS61', '');
        RETURN FALSE;
      END IF;
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE = 'N' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY <> 'N' THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-330', '');

        RETURN FALSE;
      END IF;
    ELSIF L_REGD_APPLICABLE = 'N' AND
          (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REG_D_APPLICABLE, 'N') <> 'N' OR
          NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REGD_PERIODICITY, 'N') <> 'N') THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-190', '');
      RETURN FALSE;
    END IF;

    DBG('fn_validate_regD returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_regD with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_REGD;

  FUNCTION FN_VALIDATE_ACC_STATUS(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_COUNT INTEGER := 0;
  BEGIN
    DBG('Inside fn_validate_acc_status');
    DBG('Status count: ' || P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT);

    IF P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT LOOP
        DBG('Status: ' || P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).STATUS);
        IF P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).STATUS IS NOT NULL THEN
          DBG('LOV validation For Account Status');
          BEGIN
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTMS_CONTRACT_STATUSES
             WHERE STATUS_CODE = P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                  .STATUS
               AND STATUS_TYPE IN ('A', 'B')
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('Failed During Selection of Account Status Code with No_data_found');
              L_COUNT := 0;
            WHEN OTHERS THEN
              DBG('In WHEN OTHERS of Selection of Account Status From sttms_contract_statuses with:  ' ||
                  SQLERRM);
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-115',
                           '@STTMS_ACCSTAT_REPLINES_DETAIL.STATUS~' || P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                           .STATUS || '~');
              RETURN FALSE;
          END;
          IF L_COUNT = 0 THEN
            DBG('LOV Validation Failed For Account Status ');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-115',
                         '@STTMS_ACCSTAT_REPLINES_DETAIL.STATUS~' || P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                         .STATUS || '~');
            RETURN FALSE;
          END IF;
        END IF;
      END LOOP;
    END IF;

    DBG('fn_validate_acc_status returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_acc_status with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ACC_STATUS;

  FUNCTION FN_VALIDATE_EXPCAT(P_FUNCTION_ID IN VARCHAR2,
                              P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_PROVISION_IDX STTM_ACCOUNT_PROV_PERCENT.STATUS%TYPE;
    L_COUNT         INTEGER := 0;
  BEGIN
    DBG('Inside fn_validate_expcat');
    DBG('exposure_category Passed: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY IS NOT NULL THEN

      SELECT COUNT(1)
        INTO L_COUNT
        FROM STTMS_EXPOSURE_CATEGORY
       WHERE EXPOSURE_CATEGORY =
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
      IF L_COUNT = 0 THEN
        DBG('Exposure Category Check Failed ');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-114', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD = 'Y' THEN
      IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT LOOP
          IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I)
           .PROV_PERCENT IS NULL AND
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY IS NULL THEN
            DBG('Exposure Category Cant be Null ');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-EXP1',
                         '@STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY~');
            RETURN FALSE;
          END IF;
        END LOOP;
      ELSIF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT = 0 AND
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY IS NULL THEN
        DBG('Exposure Category Cant be Null ');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-EXP1',
                     '@STTMS_CUST_ACCOUNT.EXPOSURE_CATEGORY~');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_validate_expcat returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_expcat with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_EXPCAT;

  FUNCTION FN_VALIDATE_STATEMENT_DET(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_ACC_COUNT INTEGER := 0;
    L_COUNT     INTEGER := 0;

  BEGIN
    DBG('Inside fn_validate_statement_det');

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT IS NOT NULL THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE <> 'N' OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 <> 'N' OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 <> 'N' OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-AC003', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE = 'N' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE IS NOT NULL OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY IS NOT NULL THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-331', '');

        RETURN FALSE;
      END IF;
    END IF;

    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE <> 'D' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY IS NULL) OR
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE IS NULL) THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAN101', '');

      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 = 'N' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 IS NOT NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 IS NOT NULL THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-332', '');

        RETURN FALSE;
      END IF;
    END IF;

    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 <> 'D' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 IS NULL) OR
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 IS NULL) THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAN101', '');

      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 = 'N' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 IS NOT NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 IS NOT NULL THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-333', '');

        RETURN FALSE;
      END IF;
    END IF;

    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 <> 'D' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 IS NULL) OR
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 IS NULL) THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAN102', '');

      RETURN FALSE;
    END IF;

    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE =
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 =
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE =
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3) THEN

      DBG('#25554377 p_stdcusac.v_sttms_cust_account.ac_stmt_day ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY);
      DBG('#25554377 p_stdcusac.v_sttms_cust_account.acc_stmt_day2 ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2);
      DBG('#25554377 p_stdcusac.v_sttms_cust_account.acc_stmt_day3 ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3);
      IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY =
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAN05', '');

        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_ACC_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND STATEMENT_ACCOUNT IS NULL
         AND CUST_AC_NO NOT IN (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO)
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT;
      IF (L_ACC_COUNT = 0) THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-UPLM004',
                     '@STTMS_CUST_ACCOUNT.STATEMENT_ACCOUNT~');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_validate_statement_det returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_statement_det with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_STATEMENT_DET;

  FUNCTION FN_VALIDATE_ACC_LIMIT(P_FUNCTION_ID IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_STR              VARCHAR2(4000);
    L_LINE_ID          VARCHAR2(11);
    AL_RET             VARCHAR2(10);
    L_LIABILITY        VARCHAR2(9);
    L_UNADVISED        VARCHAR2(1);
    L_NETTING_REQUIRED CHAR;
    L_OD_TYPE          CHAR;
    L_GET_MAT          BOOLEAN := FALSE;
    L_COUNT            INTEGER := 0;
    L_LMT_CHECK        STTMS_ACCOUNT_CLASS.LIMIT_CHECK_REQUIRED%TYPE;

    L_DL_LIMIT CHAR := 'N';

    L_ERR_CODE_LIST VARCHAR2(120);
    L_ERR_COUNT     NUMBER := 0;
    L_ERR_CODE      VARCHAR2(20);

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Inside fn_validate_acc_limit');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('ERR_CODE_LIST') := L_ERR_CODE_LIST;
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_VALIDATE_ACC_LIMIT(P_FUNCTION_ID,
                                                               P_STDCUSAC,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_1_cluster.fn_validate_acc_limit..');
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        RETURN FALSE;
      END IF;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      L_LINE_ID := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LINE_ID;
      L_LINE_ID := TRIM(L_LINE_ID);
      BEGIN
        SELECT OVERDRAFT_FACILITY, DAYLIGHT_LIMIT, LIMIT_CHECK_REQUIRED
          INTO L_OD_TYPE, L_DL_LIMIT, L_LMT_CHECK
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS, '~~~');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to get OD type of Account cvlass');
          NULL;
      END;

      DBG('l_od_type: ' || L_OD_TYPE);

      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED, 'N') = 'Y' AND
         NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'),
             'N') = 'Y' THEN
        IF NOT STPKS_ACCOUNT_NETTING.FN_VALIDATE_ACC_LIMIT(P_FUNCTION_ID,
                                                           P_STDCUSAC,
                                                           P_STDCUSAC,
                                                           L_OD_TYPE) THEN
          DBG('Failed in fn_validate_acc_limit..');
        END IF;
      END IF;

      IF L_OD_TYPE = 'N' AND
         (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0) > 0 OR
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT, 0) > 0

         OR
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT, 0) > 0 OR
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT, 0) > 0

         ) THEN

        DBG('Od is not allowed..');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-177', '');
        RETURN FALSE;
      END IF;

      IF NVL(L_LMT_CHECK, 'N') = 'N' AND
         P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
        DBG('Linkage of facility not allowed');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-506', '');
      END IF;

      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT, 0) < 0 THEN
        DBG('negative dayligt limit amount is not allowed..');

        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'CA-00177',
                     '@STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT');

        RETURN FALSE;
      END IF;

      IF (NVL(L_DL_LIMIT, 'N') = 'N' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT > 0) THEN
        DBG('dayligt limit is not allowed..');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-201', '');
        RETURN FALSE;
      END IF;

      IF (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0) < 0 OR
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT, 0) < 0) THEN
        DBG('negative temp od limit amount is not allowed..');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CA-00185', '');

        RETURN FALSE;
      END IF;

      IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
        BEGIN
          SELECT LIABILITY_NO
            INTO L_LIABILITY
            FROM STTM_CUSTOMER
           WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN FETCHING THE CUSTOMER DETAILS...');
        END;
        IF NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'),
               'N') <> 'Y' THEN

          IF NOT
              ELPKSS_LIABILITY_SERVICE.FN_GET_NETTING_STATUS(L_LIABILITY,
                                                             L_NETTING_REQUIRED) THEN
            DEBUG.PR_DEBUG('AC',
                           'Error while getting liabilitit netting ' ||
                           L_NETTING_REQUIRED);
          END IF;
          IF L_NETTING_REQUIRED <> 'N' THEN
            FOR I IN 1 .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
              IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKAGE_TYPE = 'F' THEN
                IF NOT
                    ELPKSS_FACILITY_SERVICE.FN_GET_NETTING_STATUS(L_LIABILITY,
                                                                  P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                                                  .LINKED_REF_NO,
                                                                  L_NETTING_REQUIRED) THEN
                  L_NETTING_REQUIRED := 'N';
                  DBG('Error while getting liabilitit netting ' ||
                      L_NETTING_REQUIRED);
                END IF;
              END IF;
              IF L_NETTING_REQUIRED = 'N' THEN
                EXIT;
              END IF;
            END LOOP;
          END IF;

          DBG('l_netting_required' || L_NETTING_REQUIRED);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED <>
             L_NETTING_REQUIRED AND
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED = 'N' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-REF-0003', '');

          END IF;

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED <>
             L_NETTING_REQUIRED AND
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-NET-001', '');
            RETURN FALSE;
          END IF;
        END IF;

        FOR I IN 1 .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
          L_UNADVISED := 'N';
          IF NOT ELPKS_FACILITY_SERVICE.FN_GETTING_UNADVISED(L_LIABILITY,
                                                             P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                                             .LINKED_REF_NO,
                                                             L_UNADVISED) THEN
            DBG('Failed in ELPKS_FACILITY_SERVICE.fn_getting_unadvised ');
            RETURN FALSE;
          END IF;
          IF L_UNADVISED = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'LM-UNAD3',
                         P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKED_REF_NO);
          END IF;
        END LOOP;

      ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED = 'Y' AND
            NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'),
                'N') <> 'Y' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-NET-000', '');
        RETURN FALSE;
      END IF;

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE <
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'AC-LM-99997', '');
        RETURN FALSE;
      END IF;

      DBG('fn_validate_acc_limit returning true');

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_acc_limit with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ACC_LIMIT;

  FUNCTION FN_VALIDATE_AUTOEXRATE_LMT(P_FUNCTION_ID IN VARCHAR2,
                                      P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_validate_autoexrate_lmt');

    DBG('Credit Auto Exrate Limit Passed: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_AUTO_EX_RATE_LMT);
    DBG('Debit Auto Exrate Limit Passed: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_AUTO_EX_RATE_LMT);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_AUTO_EX_RATE_LMT IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_AUTO_EX_RATE_LMT < 0 THEN
      DBG('Credit Auto Exrate Limit Should be Positive.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CY-CDF13', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_AUTO_EX_RATE_LMT IS NOT NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_AUTO_EX_RATE_LMT < 0 THEN
      DBG('Debit Auto Exrate Limit Should be Positive.');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CY-CDF13', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_AUTO_EX_RATE_LMT IS NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_AUTO_EX_RATE_LMT IS NOT NULL THEN
      DBG('DebitCredit Auto Exrate Limit Failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CY-CDF14', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_AUTO_EX_RATE_LMT IS NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_AUTO_EX_RATE_LMT IS NOT NULL THEN
      DBG('DebitCredit Auto Exrate Limit Failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CY-CDF14', '');
      RETURN FALSE;
    END IF;

    DBG('fn_validate_autoexrate_lmt returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_autoexrate_lmt with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_AUTOEXRATE_LMT;

  FUNCTION FN_VALIDATE_NOTICE_PREFERENCE(P_FUNCTION_ID IN VARCHAR2,
                                         P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_NOTICE_PREFERENCE(P_FUNCTION_ID,
                                                                     P_STDCUSAC,
                                                                     L_FN_CALL_ID,
                                                                     L_TB_CLUSTER_DATA) THEN

        DBG('Failed in fn_validate_notice_preference');
        RETURN FALSE;
      END IF;
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('validating record');
      SELECT AC_CLASS_TYPE
        INTO L_AC_CLASS_TYPE
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

      IF L_AC_CLASS_TYPE <> 'S' THEN
        DBG('If account type  is not saving' || L_AC_CLASS_TYPE);
        IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD >= 0 OR
           P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD IS NOT NULL) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NT-05', '');

        END IF;

        IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD >= 0 OR
           P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD IS NOT NULL) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NT-05', '');

        END IF;
        IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT >= 0 OR
           P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT IS NOT NULL) THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NT-05', '');

        END IF;

      ELSE

        IF P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.ADV_INTEREST_REQD = 'N' THEN
          IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT IS NOT NULL OR
             P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD IS NOT NULL OR
             P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD IS NOT NULL) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACNT-01', '');
            RETURN FALSE;
          END IF;
        END IF;

        IF P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.ADV_INTEREST_REQD = 'Y' THEN
          IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD <= 0 OR
             P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.NOTICE_PERIOD IS NULL) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACNT-02', '');
            RETURN FALSE;
          END IF;

          IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD <= 0 OR
             P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.VALIDITY_PERIOD IS NULL) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACNT-03', '');
            RETURN FALSE;
          END IF;
          IF (P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT <= 0 OR
             P_STDCUSAC.V_STTMS_ACC_NOTICE_PREF.MONTHLY_FREE_AMT IS NULL) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACNT-04', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('returning true from  validate method');

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_notice_preference with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACNT-05', '');
      RETURN FALSE;
  END FN_VALIDATE_NOTICE_PREFERENCE;

  FUNCTION FN_VALIDATE_ACCOPENAMT(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS

    L_MIN_OPEN_BAL STTM_ACCLS_MIN_BAL_DET.MINIMUM_OPENING_BALANCE%TYPE;

  BEGIN
    DBG('inside fn_validate_accopenamt');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT IS NOT NULL THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION IS NULL THEN
        DBG('inside fn_validate_accopenamt FAILURE');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-195', '');
        RETURN FALSE;
      ELSE
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION = 'A' THEN
          IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT IS NULL OR
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH IS NULL) THEN
            DBG('inside fn_validate_accopenamt FAILURE');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-202', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;

    BEGIN
      L_MIN_OPEN_BAL := 0;

      SELECT MINIMUM_OPENING_BALANCE
        INTO L_MIN_OPEN_BAL
        FROM STTMS_ACCLS_MIN_BAL_DET
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
         AND CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY

         AND PASSBOOK_FACILITY =
             NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY, 'N')
         AND CHEQUE_BOOK_FACILITY =
             NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY, 'N')
         AND ATM_FACILITY =
             NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY, 'N')
         AND DIRECT_BANKING =
             NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DIRECT_BANKING, 'N');

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('No data matches.. pick the default min balance..');
        BEGIN
          SELECT A.DFLT_MIN_OPEN_BAL
            INTO L_MIN_OPEN_BAL
            FROM STTMS_ACCLS_MIN_BAL A
           WHERE A.ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
             AND A.CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No defalt balance also..');
            L_MIN_OPEN_BAL := 0;
        END;

        DBG('Inside l_min_open_bal value-->' || L_MIN_OPEN_BAL);

      WHEN OTHERS THEN
        DBG('inside fn_validate_accopenamt FAILURE' || SQLERRM);
        L_MIN_OPEN_BAL := 0;
    END;

    DBG('Inside l_min_open_bal -->' || L_MIN_OPEN_BAL);
    DBG('Inside p_stdcusac.v_sttms_cust_account.INF_ACC_OPENING_AMT -->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT);

    IF (NVL(G_MULTI_CURRENCY, FALSE) <> TRUE) THEN
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') = 'N'

       THEN

        IF NVL(L_MIN_OPEN_BAL, 0) >

           NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT, 0) THEN

          DBG('inside fn_validate_accopenamt FAILURE');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-204', '');

        END IF;
      END IF;

    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('In NO DATA of fn_validate_accopenamt with: ' || SQLERRM);
      RETURN TRUE;
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_accopenamt with: ' || SQLERRM);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ACCOPENAMT;

  FUNCTION FN_VALIDATE_INTERMEDIARY(P_FUNCTION_ID IN VARCHAR2,
                                    P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_SUM NUMBER(5, 2) := 0;
  BEGIN
    DBG('Inside fn_validate_intermediary');

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERMEDIARY_REQUIRED, 'N') = 'N' THEN
      IF P_STDCUSAC.V_STTMS_INTERMEDIARY.COUNT > 0 THEN
        DBG('Intermediary details should not be entered if intermediary required flag is not checked');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-500', '');
        G_ERR_FLAG := -1;
        DBG('5');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERMEDIARY_REQUIRED, 'N') = 'Y' THEN
      IF P_STDCUSAC.V_STTMS_INTERMEDIARY.COUNT = 0 THEN
        DBG('Intermediary details should be entered if intermediary required flag is checked');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-501', '');
        G_ERR_FLAG := -1;
        DBG('6');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERMEDIARY_REQUIRED, 'N') = 'Y' THEN
      IF P_STDCUSAC.V_STTMS_INTERMEDIARY.COUNT > 0 THEN
        FOR I IN P_STDCUSAC.V_STTMS_INTERMEDIARY.FIRST .. P_STDCUSAC.V_STTMS_INTERMEDIARY.LAST LOOP
          L_SUM := L_SUM +
                   NVL(P_STDCUSAC.V_STTMS_INTERMEDIARY(I).INTERMEDIARY_RATIO,
                       0);
        END LOOP;
      END IF;

      IF (L_SUM <> 100) THEN
        DBG('Sum of all Intermediary ratio should be 100 percentage');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-502', '');
        G_ERR_FLAG := -1;
        DBG('7');
        DBG('assigned false to err flag');
      END IF;
    END IF;
    DBG('fn_validate_intermediary returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_intermediary with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_INTERMEDIARY;

  FUNCTION FN_VALIDATE_ITEMS(P_SOURCE      IN VARCHAR2,
                             P_FUNCTION_ID IN VARCHAR2,
                             P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ACTION_CODE IN VARCHAR2,
                             P_ERR_CODE    IN OUT VARCHAR2,
                             P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CCY_TYPE      VARCHAR2(3);
    L_CHECK_COUNTRY NUMBER := 0;
    L_OD_TYPE       CHAR;
    L_PASSBOOKCNT   NUMBER;
    L_CHECK_COUNT   NUMBER;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_LMT_CHECK STTMS_ACCOUNT_CLASS.LIMIT_CHECK_REQUIRED%TYPE;

    L_PASSBOOK_FACILITY    STTMS_ACCOUNT_CLASS.PASSBOOK_FACILITY%TYPE;
    L_CHEQUE_BOOK_FACILITY STTMS_ACCOUNT_CLASS.CHEQUE_BOOK_FACILITY%TYPE;
    L_ATM_FACILITY         STTMS_ACCOUNT_CLASS.ATM_FACILITY%TYPE;
    L_DIRECT_BANKING       STTMS_ACCOUNT_CLASS.DIRECT_BANKING%TYPE;

    L_ERR_CODE  VARCHAR2(2000);
    L_ERR_PARAM VARCHAR2(2000);

    L_CUSTREC STTMS_CUSTOMER%ROWTYPE;
    L_MNR_MJR STTMS_ACCOUNT_CLASS.MINOR_MAJOR%TYPE;

    L_MULTI_CURRENCY VARCHAR2(20);

    L_STMT_CYCLE  STTMS_CUST_ACCOUNT.AC_STMT_CYCLE%TYPE;
    L_AC_STMT_DAY STTMS_CUST_ACCOUNT.AC_STMT_DAY%TYPE;

    L_STMT_CYCLE2  STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2%TYPE;
    L_AC_STMT_DAY2 STTMS_CUST_ACCOUNT.ACC_STMT_DAY2%TYPE;
    L_STMT_CYCLE3  STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3%TYPE;
    L_AC_STMT_DAY3 STTMS_CUST_ACCOUNT.ACC_STMT_DAY3%TYPE;

  BEGIN
    DBG('Inside fn_validate_items');

    DBG('Checking for Joint account holders: Count: ' ||
        P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);

    IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR IN ('S') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF91', '');
      END IF;
    END IF;

    DBG('Acc desc is -->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC IS NULL AND
       P_FUNCTION_ID NOT IN ('STDCA003', 'STDSA003', 'STDTD003') THEN
      IF OVPKSS.FN_GETTYPE('CS-00015') IN ('E', 'X') THEN
        DBG('Error type is E so logging error');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-00015', ' ');
        G_ERR_FLAG := -1;
        DBG('8');
      ELSE
        DBG('Error type is I so defaulting customer full name');
        BEGIN
          SELECT FULL_NAME
            INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in selecting from Sttms_Customer');
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC := NULL;

        END;
        DBG('Acc desc from select is-->' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);

      END IF;
    END IF;

    DBG('Calling cypkss.fn_eurtype');
    L_CCY_TYPE := CYPKSS.FN_EURTYPE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
    DBG('l_ccy_type: ' || L_CCY_TYPE);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY <> 'Y' OR
       L_CCY_TYPE NOT IN ('I', 'E') THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ = 'E' THEN
        DBG('Cannot provide Cheque book facility for the account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-VAL01', '');
        G_ERR_FLAG := -1;
        DBG('9');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    DBG('Validating Account class');
    IF P_ACTION_CODE <> 'MODIFY' THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_VALIDATE_ACCCLS(P_FUNCTION_ID,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                    P_AC_OPEN_DATE => P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN
        DBG('fn_validate_acccls has returned false');
        G_ERR_FLAG := -1;
        DBG('10');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    DBG('Validating Alt acc');
    IF NOT FN_VALIDATE_ALTACC(P_FUNCTION_ID,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO,
                              P_ACTION_CODE) THEN
      DBG('fn_validate_altacc has returned false');
      G_ERR_FLAG := -1;
      DBG('11');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Currency');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VALIDATE_ACCCCY(P_FUNCTION_ID,
                                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS) THEN
      DBG('fn_validate_accccy has returned false');
      G_ERR_FLAG := -1;
      DBG('12');
      DBG('assigned false to err flag');
    END IF;

    DBG('Calling fn_validate_bnkacc');
    IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_bnkacc has returned false');
      RETURN FALSE;
    END IF;

    DBG('Validating Clearing Bank code');
    IF NOT
        FN_VALIDATE_CLRBNKCD(P_FUNCTION_ID,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_BANK_CODE) THEN
      DBG('fn_validate_clrbn has returned false');
      G_ERR_FLAG := -1;
      DBG('13');
      DBG('assigned false to err flag');
    END IF;

    DBG('Calling fn_validate_bnkacc');
    IF NOT FN_VALIDATE_BNKACC(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_bnkacc has returned false');
      RETURN FALSE;
    END IF;

    DBG('Validating Customer');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_VALIDATE_CUSTOMER(P_FUNCTION_ID,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS) THEN
      DBG('fn_validate_customer has returned false');
      DBG('14');
      G_ERR_FLAG := -1;
      DBG('assigned false to err flag');
    END IF;

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_ITEMS(P_SOURCE,
                                                         P_FUNCTION_ID,
                                                         P_STDCUSAC,
                                                         P_ACTION_CODE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdcusac_utils_cluster.fn_validate_items');
        RETURN FALSE;
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    DBG('Validating Account Open date');
    IF NOT FN_VALIDATE_ACC_OPEN_DATE(P_FUNCTION_ID,

                                     P_STDCUSAC) THEN

      DBG('fn_validate_acc_open_date has returned false');
      G_ERR_FLAG := -1;
      DBG('15');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating IBAN details');
    IF NOT FN_VALIDATE_IBAN(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
      DBG('fn_validate_IBAN has returned false');
      G_ERR_FLAG := -1;
      DBG('16');
      DBG('assigned false to err flag');
    END IF;

    OVPKS.PR_READTBL(L_ERR_CODE, L_ERR_PARAM);

    IF L_ERR_CODE IS NOT NULL AND
       L_ERR_CODE IN ('IS-IBAN-004', 'IS-IBAN-006', 'IS-IBAN-003') THEN
      DBG('16' || L_ERR_CODE);
      OVPKS.PR_INITERRTBL;
      RETURN FALSE;
    END IF;

    DBG('Validating Turnover Limit Code');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRNOVER_LMT_CODE IS NOT NULL THEN
      IF NOT FN_VALIDATE_TRNOVER_LIMIT_CODE(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('Validation Failed For Turnover Limit Code.');
        G_ERR_FLAG := -1;
        DBG('17');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    DBG('Validating Account description');

    DBG('Validating ATM acc no');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE <> 'Y' THEN
      IF NOT FN_VALIDATE_ATM_AC_NO(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
        DBG('fn_validate_atm_ac_no has returned false');
        G_ERR_FLAG := -1;
        DBG('19');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      SELECT COUNT(*)
        INTO L_CHECK_COUNT
        FROM CATM_CHECK_DETAILS A
       WHERE BRANCH = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACCOUNT = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND RECORD_STAT = 'O'
         AND STATUS = 'N'

         AND A.MOD_NO = (SELECT MAX(B.MOD_NO)
                           FROM CATM_CHECK_DETAILS B
                          WHERE B.ACCOUNT = A.ACCOUNT
                            AND B.BRANCH = A.BRANCH
                            AND B.CHECK_BOOK_NO = A.CHECK_BOOK_NO
                            AND A.CHECK_NO = B.CHECK_NO);
      DBG('l_check_count is :' || L_CHECK_COUNT);

      IF L_CHECK_COUNT > 0 AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY <> 'Y' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-229', '');

      END IF;

    END IF;

    DBG('Validating Stale days');
    DBG('Stale Days: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS);
    IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'N' AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS, 0) <> 0) THEN
      DBG('1: Stale Days Check failed');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-ACC-153',
                   '@STTMS_CUST_ACCOUNT.STALE_DAYS');
      G_ERR_FLAG := -1;
      DBG('20');
      DBG('assigned false to err flag');
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC = 'Y' AND
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS <= 0 OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS >
       TRUNC(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STALE_DAYS)) THEN
      DBG('2: Stale Days Check failed');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS58', '');
      G_ERR_FLAG := -1;
      DBG('21');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Deferred reconcilliation');
    IF NOT FN_VALIDATE_DEFER_RECON(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_defer_recon has returned false');
      G_ERR_FLAG := -1;
      DBG('22');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating funding details');
    IF NOT FN_VALIDATE_FUNDING(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_funding has returned false');
      G_ERR_FLAG := -1;
      DBG('23');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Auto reorder options');
    IF NOT FN_VALIDATE_AUTOREORDER(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_autoreorder has returned false');
      G_ERR_FLAG := -1;
      DBG('24');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating REGD');
    IF NOT FN_VALIDATE_REGD(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_regD has returned false');
      G_ERR_FLAG := -1;
      DBG('25');
      DBG('assigned false to err flag');
    END IF;
    IF STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      L_MULTI_CURRENCY) <> TRUE THEN
      IF P_SOURCE NOT IN ('FLEXBRANCH') THEN
        DBG('Validating Location and Media');
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1 IS NOT NULL OR
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2 IS NOT NULL OR
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3 IS NOT NULL OR
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4 IS NOT NULL THEN

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION IS NULL AND
             P_SOURCE = 'FLEXCUBE'

           THEN
            DBG('Mandatory Element Location is NULL.');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-MAN01',
                         '@STTMS_CUST_ACCOUNT.LOCATION');

            DBG('assigned false to err flag');
          END IF;

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA IS NULL AND
             P_SOURCE = 'FLEXCUBE'

           THEN
            DBG('Mandatory Element Media is NULL.');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-MAN01',
                         '@STTMS_CUST_ACCOUNT.MEDIA');

            DBG('assigned false to err flag');
          END IF;
        END IF;
      END IF;
    END IF;
    DBG('Validating Account statuses');
    IF NOT FN_VALIDATE_ACC_STATUS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_acc_status has returned false');
      G_ERR_FLAG := -1;
      DBG('26');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Exposure category');
    IF NOT FN_VALIDATE_EXPCAT(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_expcat has returned false');
      G_ERR_FLAG := -1;
      DBG('27');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Statement details');

    IF NOT FN_VALIDATE_STATEMENT_DET(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_statement_det has returned false');
      G_ERR_FLAG := -1;
      DBG('28');
      DBG('assigned false to err flag');
    END IF;

    DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_cycle' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE);
    DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_cycle2' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2);
    DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_cycle3' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3);

    DBG('P_ACTION_CODE' || P_ACTION_CODE);
    IF P_ACTION_CODE = 'MODIFY' THEN

      BEGIN
        SELECT AC_STMT_CYCLE,
               AC_STMT_DAY,
               L_STMT_CYCLE2,
               ACC_STMT_DAY2,
               L_STMT_CYCLE3,
               ACC_STMT_DAY3
          INTO L_STMT_CYCLE,
               L_AC_STMT_DAY,
               L_STMT_CYCLE2,
               L_AC_STMT_DAY2,
               L_STMT_CYCLE3,
               L_AC_STMT_DAY3
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      DBG('l_stmt_cycle' || L_STMT_CYCLE);
      DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_day' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY);
      DBG('L_AC_STMT_DAY' || L_AC_STMT_DAY);
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE);
      IF L_STMT_CYCLE <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE OR
         L_AC_STMT_DAY <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE := NULL;
      END IF;
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE);

      DBG('l_stmt_cycle2' || L_STMT_CYCLE2);
      DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_type' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2);
      DBG('L_AC_STMT_DAY' || L_AC_STMT_DAY2);
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date2' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2);
      IF L_STMT_CYCLE2 <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 OR
         L_AC_STMT_DAY2 <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2 := NULL;
      END IF;
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date2' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE2);

      DBG('l_stmt_cycle3' || L_STMT_CYCLE3);
      DBG('p_stdcusac.v_sttms_cust_account.ac_stmt_day' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3);
      DBG('L_AC_STMT_DAY' || L_AC_STMT_DAY3);
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date3' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3);
      IF L_STMT_CYCLE3 <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 OR
         L_AC_STMT_DAY3 <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3 := NULL;
      END IF;
      DBG(' P_Stdcusac.V_Sttms_Cust_Account.Previous_Statement_Date3' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE3);
    END IF;

    DBG('Validating Account limits');
    IF NOT FN_VALIDATE_ACC_LIMIT(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_acc_limit has returned false');
      G_ERR_FLAG := -1;
      DBG('29');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating tod details');
    IF NOT FN_VALIDATE_TOD_DETAILS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('coming here');
      DBG('fn_validate_tod_details has returned false');
      G_ERR_FLAG := -1;
      DBG('30');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating Auto exchange rate limit');
    IF NOT FN_VALIDATE_AUTOEXRATE_LMT(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_autoexrate_lmt has returned false');
      G_ERR_FLAG := -1;
      DBG('31');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating IBAN Reqd');

    DBG('p_Function_Id-->' || P_FUNCTION_ID);
    DBG('IBAN_REQUIRED-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED = 'N' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DISPLAY_IBAN_IN_ADVICES = 'Y' THEN
      IF P_FUNCTION_ID <> 'STDCASAC' THEN
        DBG('IBAN required flag is unchecked');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN50', '');
        G_ERR_FLAG := -1;
        DBG('32');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    DBG('Validating Mod9 details');
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD9_VALIDATION_REQD = 'N' AND
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.VALIDATION_DIGIT = '0' OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.VALIDATION_DIGIT = '9') THEN
      DBG('Mod 9 Validation required flag is unchecked');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-IBAN51', '');
      G_ERR_FLAG := -1;
      DBG('33');
      DBG('assigned false to err flag');
    END IF;

    IF NOT FN_VALIDATE_NOTICE_PREFERENCE(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_items has returned false');
      G_ERR_FLAG := -1;
      DBG('34');
      DBG('assigned false to err flag');
    END IF;

    DBG('Validating fn_validate_accopenamt details-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF NOT FN_VALIDATE_ACCOPENAMT(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_accopenamt has returned false');
        G_ERR_FLAG := -1;
        DBG('35');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    BEGIN
      SELECT OVERDRAFT_FACILITY,
             LIMIT_CHECK_REQUIRED

            ,
             PASSBOOK_FACILITY,
             CHEQUE_BOOK_FACILITY,
             ATM_FACILITY,
             DIRECT_BANKING

        INTO L_OD_TYPE,
             L_LMT_CHECK

            ,
             L_PASSBOOK_FACILITY,
             L_CHEQUE_BOOK_FACILITY,
             L_ATM_FACILITY,
             L_DIRECT_BANKING

        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to get OD type of Account class');
        NULL;
    END;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'Y' THEN

      IF NVL(L_LMT_CHECK, 'N') = 'N' THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-505', '');
        G_ERR_FLAG := -1;
        DBG('36');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'N' THEN
      IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-452', '');
        G_ERR_FLAG := -1;
        DBG('37');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'Y' THEN
      IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.COUNT = 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-451', '');
        G_ERR_FLAG := -1;
        DBG('38');
        DBG('assigned false to err flag');
      END IF;
    END IF;

    IF P_ACTION_CODE = 'NEW' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'Y' THEN
        IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-458', '');
          G_ERR_FLAG := -1;
          DBG('39');
          DBG('assigned false to err flag');
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'Y' THEN
        IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
          FOR I IN P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.FIRST .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.LAST LOOP
            IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
             .LINKED_REF_NO NOT LIKE
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO || 'P' || '%' THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-458', '');
              G_ERR_FLAG := -1;
              DBG('40');
              DBG('assigned false to err flag');
              EXIT;
            END IF;
          END LOOP;
        END IF;
      END IF;
    END IF;

    IF NOT FN_VALIDATE_INTERMEDIARY(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_items has returned false');
      G_ERR_FLAG := -1;
      DBG('41');
      DBG('assigned false to err flag');
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('Going to check passbook facility..' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY);
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY, 'N') = 'N' THEN
        DBG('Going to check the count..');
        SELECT COUNT(1)
          INTO L_PASSBOOKCNT
          FROM CATM_PASSBOOK_DETAILS A, STTM_CUST_ACCOUNT B
         WHERE B.CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND B.CUST_AC_NO = A.ACCOUNT
           AND B.BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND B.BRANCH_CODE = A.BRANCH
           AND A.STATUS <> 'CLOSED';
        DBG('Passbook issued ..? - ' || L_PASSBOOKCNT);
        IF L_PASSBOOKCNT > 0 THEN
          DBG('Passbook is already associated.hence, the facility cannot be revoked.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'GW-CA-012', NULL);
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    DBG('validating whether the  mandatory documents are checked');

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF NOT FN_VALIDATE_DOCUMENTS(P_FUNCTION_ID,
                                   P_STDCUSAC,
                                   P_ACTION_CODE,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
        DBG('fn_validate_documents has returned false');
        G_ERR_FLAG := -1;
        DBG('42');
        DBG('assigned false to err flag');
      END IF;

    END IF;

    DBG('Returning with the result');
    IF G_ERR_FLAG = -1 THEN
      DBG('fn_validate_items returning false');
      G_ERR_FLAG := 1;
      DBG('42');
      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_CHECK_COUNTRY
        FROM STTM_COUNTRY
       WHERE COUNTRY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE
         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';
      IF L_CHECK_COUNTRY = 0 THEN
        DBG('COUNTRY CODE Not available in STTM_COUNTRY');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'TA-VALS-001',
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE);
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF G_MULTI_CURRENCY <> TRUE THEN

        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_FACILITY, 'N') <>
           NVL(L_PASSBOOK_FACILITY, 'N') OR
           NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY, 'N') <>
           NVL(L_CHEQUE_BOOK_FACILITY, 'N') OR
           NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY, 'N') <>
           NVL(L_ATM_FACILITY, 'N') OR
           NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DIRECT_BANKING, 'N') <>
           NVL(L_DIRECT_BANKING, 'N') THEN

          DBG('Defaulted facilites has been changed..');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-041', NULL);
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      BEGIN
        IF NOT CVPKSS_UTILS.GET_CUST_NO(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                        L_CUSTREC) THEN
          DEBUG.PR_DEBUG('AC',
                         'unable to get the customer record ' || SQLERRM);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('AC', 'Encountered some problem here' || SQLERRM);
          RETURN FALSE;
      END;
      BEGIN
        SELECT NVL(MINOR_MAJOR, 'NA')
          INTO L_MNR_MJR
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('AC',
                         'Encountered some problem here @ sttms_account_class' ||
                         SQLERRM);
          RETURN FALSE;
      END;
      IF L_CUSTREC.CUSTOMER_TYPE <> 'I' AND L_MNR_MJR IN ('MI', 'MJ', 'BT') THEN
        PR_LOG_ERROR('STDCUSAC', 'FLEXCUBE', 'ST-ACC-001', NULL);
      END IF;
    END IF;

    DBG('fn_validate_items returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_items with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_ITEMS;

  FUNCTION FN_VALIDATE_INTERIM_DTLS(P_FUNCTION_ID IN VARCHAR2,
                                    P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_GENMSG_CNT    NUMBER := 0;
    L_BALREPORT_CNT NUMBER := 0;
    L_GEN_TIME_CNT1 NUMBER := 0;
    L_GEN_TIME_CNT2 NUMBER := 0;
  BEGIN
    DBG('Inside fn_validate_interim_detls');

    DBG('Gen time count: ' || P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT);
    DBG('Gen time 1 count: ' || P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT);

    IF P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT LOOP
        DBG('Gen Msg Type: ' || P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I)
            .MESSAGE_TYPE);
        IF P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).MESSAGE_TYPE = '942' THEN
          L_GENMSG_CNT := 1;
        END IF;

        IF L_GEN_TIME_CNT1 = 0 AND
           (P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).GEN_TIME < 0 OR P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I)
           .GEN_TIME > 23)

         THEN
          L_GEN_TIME_CNT1 := 1;
        END IF;
        IF L_GENMSG_CNT > 0 AND L_GEN_TIME_CNT1 > 0 THEN
          DBG('Exiting loop 1');
          EXIT;
        END IF;
      END LOOP;
    END IF;

    IF P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT LOOP
        DBG('Gen 1 Msg Type: ' || P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I)
            .MESSAGE_TYPE);
        IF P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).MESSAGE_TYPE = '941' THEN
          L_BALREPORT_CNT := 1;
        END IF;

        IF L_GEN_TIME_CNT2 = 0 AND
           (P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).GEN_TIME < 0 OR P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I)
           .GEN_TIME > 23)

         THEN
          L_GEN_TIME_CNT2 := 1;
        END IF;
        IF L_BALREPORT_CNT > 0 AND L_GEN_TIME_CNT2 > 0 THEN
          DBG('Exiting loop 2');
          EXIT;
        END IF;
      END LOOP;
    END IF;

    DBG('p_stdcusac.v_sttms_cust_account.gen_interim_stmt is ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT || '~' ||
        L_GENMSG_CNT);
    DBG('p_stdcusac.v_sttms_cust_account.gen_balance_report ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_BALANCE_REPORT || '~' ||
        L_BALREPORT_CNT);
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_INTERIM_STMT, 'N') = 'N' AND
       L_GENMSG_CNT > 0 THEN
      DBG('Generate Message Flag is Off. Should not enter Message Genaration Time Details for Generate Message');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSAC-10', '');

    END IF;
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_BALANCE_REPORT, 'N') = 'N' AND
       L_BALREPORT_CNT > 0 THEN
      DBG('Generate Balance Report Flag is Off. Should not enter Message Genaration Time Details for Generate balance report');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSAC-11', '');

    END IF;
    IF L_GEN_TIME_CNT1 > 0 THEN
      DBG('#1 Message generation Time value should be in the range 1 and 23');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IS-CCYRS-08', '');

    END IF;
    IF L_GEN_TIME_CNT2 > 0 THEN
      DBG('#2 Message generation Time value should be in the range 1 and 23');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IS-CCYRS-08', '');

    END IF;

    DBG('fn_validate_interim_detls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_interim_detls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_INTERIM_DTLS;

  FUNCTION FN_VALIDATE_MIS(P_FUNCTION_ID IN VARCHAR2,
                           P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CALC_METHOD_DESC VARCHAR2(20);
    L_CCY              VARCHAR2(3);
    L_CALC_METHOD      CHAR;
    L_COUNT            NUMBER;
    L_MULTI_CURRENCY   VARCHAR2(20);
  BEGIN
    DBG('Inside fn_validate_mis');
    DBG('Untref: ' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO);

    G_MULTI_CURRENCY := STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       L_MULTI_CURRENCY);
    IF (NVL(G_MULTI_CURRENCY, FALSE) <> TRUE) THEN
      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO IS NULL THEN
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END IF;
      P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM GLTMS_MIS_CLASS
         WHERE UPPER(AUTH_STAT) <> 'A'
           AND MIS_TYPE <> 'C';
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      IF (L_COUNT <> 0) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT07', '');
        RETURN FALSE;
      END IF;

      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG = 'P' THEN
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE IS NULL THEN
          DBG('Pool Code cannot be NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT32', '');

        END IF;
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE IS NOT NULL THEN
          BEGIN
            SELECT CALC_METHOD
              INTO L_CALC_METHOD
              FROM MITMS_POOL_CODE
             WHERE POOL_CODE =
                   P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE;
            DBG('l_calc_method==>' || L_CALC_METHOD);
            IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CALC_METHOD <>
               L_CALC_METHOD THEN
              SELECT DECODE(L_CALC_METHOD,
                            '1',
                            '30(Euro)/360',
                            '2',
                            '30(US)/360',
                            '3',
                            'Actual/360',
                            '4',
                            '30(Euro)/365',
                            '5',
                            '30(US)/365',
                            '6',
                            'Actual/365',
                            '7',
                            '30(Euro)/Actual',
                            '8',
                            '30(US)/Actual',
                            '9',
                            'Actual/Actual',

                            '-1',
                            '30(Euro)/364',
                            '-2',
                            '30(US)/364',
                            '0',
                            'Actual/364')

                INTO L_CALC_METHOD_DESC
                FROM DUAL;

              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-168',
                           L_CALC_METHOD_DESC || '~' ||
                           P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE || '~');
              RETURN FALSE;
            END IF;
          EXCEPTION

            WHEN NO_DATA_FOUND THEN
              DBG('Failed to select calc_method into l_calc_method with ' ||
                  SQLERRM);
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'MI-NEWUP001',
                           P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE || '~');
              RETURN FALSE;

            WHEN OTHERS THEN
              DBG('Failed to select calc_method into l_calc_method with ' ||
                  SQLERRM);
              RETURN FALSE;
          END;
        ELSE
          P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CALC_METHOD := '1';
        END IF;
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_TYPE <> 'X' THEN
          DBG('Rate Type Should be Fixed if  Rate Flag is Pool Code in MIS Details');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-165', '');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG = 'R' AND
         P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE IS NOT NULL THEN
        DBG('Pool Code Should be NULL if  Rate Flag is Account Level in MIS Details');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-167', '');
        RETURN FALSE;
      END IF;
      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG = 'R' AND
         P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_TYPE = 'F' THEN
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_CODE IS NULL THEN
          DBG('Refinance Rate Code is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT23', '');
          RETURN FALSE;
        END IF;
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_SPREAD IS NULL THEN
          DBG('Refinance Spread is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT24', '');
          RETURN FALSE;
        END IF;
      END IF;
      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_TYPE = 'X' THEN
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_CODE IS NOT NULL OR
           P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_SPREAD IS NOT NULL THEN
          DBG('Rate Code and Spread  Should be NULL if Rate Type is Fixed');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-166', '');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG = 'R' AND
         P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_TYPE = 'F' THEN
        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_RATE_CODE IS NULL THEN
          DBG('Refinance Rate Code is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT23', '');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.REF_SPREAD IS NULL THEN
          DBG('Refinance Spread is NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MI-MNT24', '');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    DBG('fn_validate_mis returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_mis with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_MIS;

  FUNCTION FN_VALIDATE_JOINT_ACCOUNT(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                     P_ACTION_CODE IN VARCHAR2)
    RETURN BOOLEAN IS
    L_JOINT_INDEX    STTB_UPLOAD_LINKED_ENTITIES.JOINT_HOLDER_CODE%TYPE;
    L_JOINT_REC      STTMS_AC_LINKED_ENTITIES%ROWTYPE;
    L_CUSTOMER_NAME1 STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_SHORT_NAME     STTMS_CUSTOMER.SHORT_NAME%TYPE;
    L_MSG_TYP        ERTBS_MSGS.TYPE%TYPE;
    L_JOINT_COUNT    NUMBER;

    L_CUSTOMER_TYPE STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_HOLDERTYPE    STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_PARAM         VARCHAR2(1000) := NULL;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    L_NEW_JH  BOOLEAN := FALSE;
    L_JH_CODE STTMS_AC_LINKED_ENTITIES.JOINT_HOLDER_CODE%TYPE;
    L_BRN     STTMS_AC_LINKED_ENTITIES.BRANCH_CODE%TYPE;
    L_CUSTACC STTMS_AC_LINKED_ENTITIES.CUST_AC_NO%TYPE;

  BEGIN
    DBG('Inside fn_validate_joint_account');

    BEGIN
      SELECT CUSTOMER_TYPE
        INTO L_CUSTOMER_TYPE
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Not able to select the type with error::' || SQLERRM);
    END;

    DBG('Entities count: ' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
    IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
        IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
         .JOINT_HOLDER_CODE IS NULL THEN
          DBG('1: For Joint Account Type Joint Holder Code should not be NULL');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
          RETURN FALSE;
        END IF;
      END LOOP;
    ELSE
      DBG('2: For Joint Account Type Joint Holder Code should not be NULL');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-ACC-117',
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      RETURN FALSE;
    END IF;

    FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN

        SELECT COUNT(*)
          INTO L_JOINT_COUNT
          FROM STTMS_AC_LINKED_ENTITIES
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND JOINT_HOLDER_CODE = P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .JOINT_HOLDER_CODE;
        IF L_JOINT_COUNT <> 0 THEN
          DBG('Joint-Holder already Exists');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS17', '');
          RETURN FALSE;
        END IF;
      END IF;
      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
       .JOINT_HOLDER_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
        DBG('Primary Customer cannot be maintained as a joint holder');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-CUS18',
                     P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                     .JOINT_HOLDER_CODE || '~');
        RETURN FALSE;
      END IF;

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            STPKSS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_JOINT_ACCOUNT(P_FUNCTION_ID,
                                                                    P_STDCUSAC,
                                                                    P_ACTION_CODE,
                                                                    L_FN_CALL_ID,
                                                                    L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_validate_joint_account');
          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
         .JOINT_HOLDER NOT IN ('AUS',
                                 'CON',
                                 'CUS',
                                 'DEV',
                                 'GUA',
                                 'GUR',
                                 'JAF',
                                 'JAO',
                                 'JOF',
                                 'JOO',
                                 'NOM',
                                 'REL',
                                 'SOL',
                                 'SOW',
                                 'THR',
                                 'TRU',

                                 'VAL',
                                 'POA') THEN

          DBG('Wrong Joint Holder Type Passed');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-116',
                       P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                       .JOINT_HOLDER || '~');
          RETURN FALSE;
        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
       .JOINT_HOLDER_DESCRIPTION IS NULL THEN
        P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).JOINT_HOLDER_DESCRIPTION := L_CUSTOMER_NAME1 || ' ' ||
                                                                             L_SHORT_NAME;
      END IF;

      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE IS NULL AND P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
         .END_DATE IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-224', '');
        RETURN FALSE;
      END IF;

      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE IS NOT NULL THEN
        IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
         .START_DATE < NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                             GLOBAL.APPLICATION_DATE) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-228', '');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
       .START_DATE > P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'AC-LM-99997', '');
        RETURN FALSE;
      END IF;

      BEGIN
        SELECT JOINT_HOLDER_CODE, BRANCH_CODE, CUST_AC_NO
          INTO L_JH_CODE, L_BRN, L_CUSTACC
          FROM STTMS_AC_LINKED_ENTITIES
         WHERE JOINT_HOLDER_CODE = P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .JOINT_HOLDER_CODE
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .BRANCH_CODE
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .CUST_AC_NO;
        L_NEW_JH := FALSE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_NEW_JH := TRUE;
      END;
      IF L_NEW_JH THEN

        IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
         .END_DATE < GLOBAL.APPLICATION_DATE THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-600', '');

          RETURN FALSE;
        END IF;
      END IF;

      BEGIN
        SELECT CUSTOMER_TYPE
          INTO L_HOLDERTYPE
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .JOINT_HOLDER_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Not able to select the joint holder type with error::' ||
              SQLERRM);
      END;
      IF L_HOLDERTYPE <> L_CUSTOMER_TYPE THEN
        L_PARAM := P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                   .JOINT_HOLDER_CODE;
      END IF;
      IF L_PARAM IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-JHN-000', L_PARAM);
      END IF;
      L_PARAM := NULL;

    END LOOP;

    DBG('Validating Mode of Operation for Corporate Customer');
    DBG('Mode of Operation' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION);
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION IS NOT NULL THEN
      IF NOT FN_VALIDATE_OPMODE(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_opmode has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_validate_joint_account returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_joint_account with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_JOINT_ACCOUNT;

  FUNCTION FN_VALIDATE_JOINT_HOLDERS(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_REC_OFFSET_ACC STTMS_CUST_ACCOUNT%ROWTYPE;
    L_CUSTNO         STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_COUNT          NUMBER;

    CURSOR CUR_JOINT_DTLS(P_BRN IN VARCHAR2, P_ACC IN VARCHAR2) IS
      SELECT JOINT_HOLDER_CODE
        FROM STTMS_AC_LINKED_ENTITIES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;

    TYPE L_TB_JOINT_DTLS IS TABLE OF CUR_JOINT_DTLS%ROWTYPE INDEX BY PLS_INTEGER;
    L_TY_JOINT_DTLS L_TB_JOINT_DTLS;

    L_EXISTS BOOLEAN := FALSE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    L_CNT                   NUMBER := 0;

  BEGIN
    DBG('Start of fn_validate_joint_holders..');
    DBG('Joint_ac_indicator..' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);

    IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.LAST LOOP
        DBG('Validation For Payin' ||
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
        IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PAYOPT = 'S' THEN

          IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
           .MULTIMODE_TDOFFSET_ACC IS NULL THEN
            DBG('Payin offset account cannot be null');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS400', '');
            RETURN FALSE;
          END IF;

          IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_REC_OFFSET_ACC) THEN
            DBG('Failed in getting cust account details for offset account');
            RETURN FALSE;
          END IF;

          DBG('p_stdcusac.v_sttms_cust_account.cust_no' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
          DBG('l_rec_offset_acc.cust_no' || L_REC_OFFSET_ACC.CUST_NO);
          DBG('l_rec_offset_acc.JOINT_AC_INDICATOR' ||
              L_REC_OFFSET_ACC.JOINT_AC_INDICATOR);
          IF CUR_JOINT_DTLS%ISOPEN THEN
            CLOSE CUR_JOINT_DTLS;
          END IF;
          OPEN CUR_JOINT_DTLS(L_REC_OFFSET_ACC.BRANCH_CODE,
                              L_REC_OFFSET_ACC.CUST_AC_NO);
          FETCH CUR_JOINT_DTLS BULK COLLECT
            INTO L_TY_JOINT_DTLS;
          CLOSE CUR_JOINT_DTLS;
          DBG('payin casa account joint holder count' ||
              L_TY_JOINT_DTLS.COUNT);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' THEN
            DBG('TD JOINT ACC INDICATIOR - SINGLE');
            DBG('p_stdcusac.v_sttms_cust_account.cust_no' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
            DBG('l_rec_offset_acc.cust_no' || L_REC_OFFSET_ACC.CUST_NO);
            DBG('l_rec_offset_acc.JOINT_AC_INDICATOR' ||
                L_REC_OFFSET_ACC.JOINT_AC_INDICATOR);
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
               L_REC_OFFSET_ACC.CUST_NO THEN
              IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
                DBG('Pay in account #CASA belongs to different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-001',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
                DBG('Pay in account #CASA is a joint account of different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-002',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;
            ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                  L_REC_OFFSET_ACC.CUST_NO AND
                  L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('Pay in account #CASA account is a Joint account');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-003',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
            DBG('TD JOINT ACC INDICATIOR - JOINT');

            IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
              IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                 L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay in account #CASA is not a joint account');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-004',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                    L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay in account #CASA is a individual account of  different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-005',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;
            ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('TD JOINT HOLDERS COUNT-->' ||
                  P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
              DBG('CASA JOINT HOLDERS COUNT-->' || L_TY_JOINT_DTLS.COUNT);
              IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                 L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay in account #CASA belongs to different customers');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-007',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;

              IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
                FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
                  DBG('TD joint holder-->' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_CODE);
                  IF L_TY_JOINT_DTLS.COUNT > 0 THEN
                    L_EXISTS := FALSE;
                    FOR K IN L_TY_JOINT_DTLS.FIRST .. L_TY_JOINT_DTLS.LAST LOOP
                      DBG('CASA joint holder-->' || L_TY_JOINT_DTLS(K)
                          .JOINT_HOLDER_CODE);
                      IF NVL(L_TY_JOINT_DTLS(K).JOINT_HOLDER_CODE, '****') =
                         NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER_CODE,
                             '****') THEN
                        L_EXISTS := TRUE;
                      END IF;

                    END LOOP;
                  END IF;
                  IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                     L_REC_OFFSET_ACC.CUST_NO AND (NOT L_EXISTS) THEN
                    DBG('Pay in account #CASA joint holders are different');
                    PR_LOG_ERROR('STDCUSTD',
                                 'FLEXCUBE',
                                 'TD-CIF-006',
                                 L_REC_OFFSET_ACC.CUST_AC_NO);
                  END IF;
                END LOOP;
              END IF;

            END IF;
          END IF;
          L_REC_OFFSET_ACC := NULL;
          L_TY_JOINT_DTLS.DELETE;
        END IF;
      END LOOP;
    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        DBG('Validation For Payout' ||
            P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
        IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).PAYOUTTYPE = 'S' THEN

          IF (P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y') OR
             (P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N') THEN
            IF (P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).OFFSET_ACC IS NULL OR P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
               .OFFSET_BRN IS NULL) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-121', '');
              RETURN FALSE;
            END IF;
          END IF;
          DBG('----------9-----------');

          IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                           .OFFSET_BRN,
                                           P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                                           .OFFSET_ACC,
                                           L_REC_OFFSET_ACC) THEN
            DBG('Failed in getting cust account details for offset account');
            RETURN FALSE;

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 1;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('i') := I;

              IF NOT
                  STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_JOINT_HOLDERS(P_FUNCTION_ID,
                                                                         P_STDCUSAC,
                                                                         L_FN_CALL_ID,
                                                                         L_TB_CLUSTER_DATA) THEN
                DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
                RETURN FALSE;
              END IF;

              IF L_TB_CLUSTER_DATA.EXISTS('l_cnt') THEN
                L_CNT := L_TB_CLUSTER_DATA('l_cnt');
                IF L_CNT = 0 THEN
                  RETURN FALSE;
                END IF;
              END IF;
            END IF;
            DBG('After cluster' || L_CNT);
            GLOBAL.PR_RESET_SKIP_KERNEL;

          END IF;
          DBG('p_stdcusac.v_sttms_cust_account.cust_no' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
          DBG('l_rec_offset_acc.cust_no' || L_REC_OFFSET_ACC.CUST_NO);
          DBG('l_rec_offset_acc.JOINT_AC_INDICATOR' ||
              L_REC_OFFSET_ACC.JOINT_AC_INDICATOR);
          IF CUR_JOINT_DTLS%ISOPEN THEN
            CLOSE CUR_JOINT_DTLS;
          END IF;
          OPEN CUR_JOINT_DTLS(L_REC_OFFSET_ACC.BRANCH_CODE,
                              L_REC_OFFSET_ACC.CUST_AC_NO);
          FETCH CUR_JOINT_DTLS BULK COLLECT
            INTO L_TY_JOINT_DTLS;
          CLOSE CUR_JOINT_DTLS;

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' THEN
            DBG('TD JOINT ACC INDICATIOR - SINGLE');

            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
               L_REC_OFFSET_ACC.CUST_NO THEN
              IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
                DBG('Pay out account #CASA belongs to different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-008',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
                DBG('Pay out account #CASA is a joint account of different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-009',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;
            ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                  L_REC_OFFSET_ACC.CUST_NO AND
                  L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('Pay out account #CASA account is a Joint account)');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-010',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
            DBG('TD JOINT ACC INDICATIOR - JOINT');

            IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
              IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                 L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay out account #CASA is not a joint account');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-011',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                    L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay out account #CASA is a individual account of  different customer');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-012',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;
            ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('TD JOINT HOLDERS COUNT-->' ||
                  P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
              DBG('CASA JOINT HOLDERS COUNT-->' || L_TY_JOINT_DTLS.COUNT);
              IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                 L_REC_OFFSET_ACC.CUST_NO THEN
                DBG('Pay out account #CASA belongs to different customers');
                PR_LOG_ERROR('STDCUSTD',
                             'FLEXCUBE',
                             'TD-CIF-014',
                             L_REC_OFFSET_ACC.CUST_AC_NO);
              END IF;
              IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
                FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
                  DBG('TD joint holder-->' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_CODE);
                  IF L_TY_JOINT_DTLS.COUNT > 0 THEN
                    L_EXISTS := FALSE;
                    FOR K IN L_TY_JOINT_DTLS.FIRST .. L_TY_JOINT_DTLS.LAST LOOP
                      DBG('CASA joint holder-->' || L_TY_JOINT_DTLS(K)
                          .JOINT_HOLDER_CODE);
                      IF NVL(L_TY_JOINT_DTLS(K).JOINT_HOLDER_CODE, '****') =
                         NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER_CODE,
                             '****') THEN
                        L_EXISTS := TRUE;
                      END IF;

                    END LOOP;
                  END IF;
                  IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                     L_REC_OFFSET_ACC.CUST_NO AND (NOT L_EXISTS) THEN
                    DBG('Pay out account #CASA joint holders are different');
                    PR_LOG_ERROR('STDCUSTD',
                                 'FLEXCUBE',
                                 'TD-CIF-013',
                                 L_REC_OFFSET_ACC.CUST_AC_NO);
                  END IF;
                END LOOP;
              END IF;

            END IF;

          END IF;
          L_REC_OFFSET_ACC := NULL;
          L_TY_JOINT_DTLS.DELETE;
        END IF;
      END LOOP;
    END IF;

    IF P_FUNCTION_ID = 'STDCUSTD' THEN
      IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO THEN
        DBG('Validation For Int booking account' ||
            P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);

        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              STPKS_STDCUSAC_UTILS_CLUSTER.FN_VALIDATE_JOINT_HOLDERS(P_FUNCTION_ID,
                                                                     P_STDCUSAC,
                                                                     L_FN_CALL_ID,
                                                                     L_TB_CLUSTER_DATA) THEN
            DBG('Failed in stpks_stdcusac_utils_cluster.fn_payinout_default');
            RETURN FALSE;
          END IF;
        END IF;

        IF NOT GLOBAL.G_SKIP_KERNEL THEN

          IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
                                           P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
                                           L_REC_OFFSET_ACC) THEN

            DBG('Failed in getting cust account details for offset account');
            RETURN FALSE;

          END IF;

        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;

        DBG('p_stdcusac.v_sttms_cust_account.cust_no' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        DBG('l_rec_offset_acc.cust_no' || L_REC_OFFSET_ACC.CUST_NO);
        DBG('l_rec_offset_acc.JOINT_AC_INDICATOR' ||
            L_REC_OFFSET_ACC.JOINT_AC_INDICATOR);
        IF CUR_JOINT_DTLS%ISOPEN THEN
          CLOSE CUR_JOINT_DTLS;
        END IF;
        OPEN CUR_JOINT_DTLS(L_REC_OFFSET_ACC.BRANCH_CODE,
                            L_REC_OFFSET_ACC.CUST_AC_NO);
        FETCH CUR_JOINT_DTLS BULK COLLECT
          INTO L_TY_JOINT_DTLS;
        CLOSE CUR_JOINT_DTLS;
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' THEN
          IF L_REC_OFFSET_ACC.CUST_NO <>
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
            IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
              DBG('Interest Booking account CASA belongs to different customer');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-015',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('Interest Booking  account CASA is a joint account of different customer');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-016',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                L_REC_OFFSET_ACC.CUST_NO AND
                L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
            DBG('Interest Booking  account CASA account is a Joint account');
            PR_LOG_ERROR('STDCUSTD',
                         'FLEXCUBE',
                         'TD-CIF-017',
                         L_REC_OFFSET_ACC.CUST_AC_NO);
          END IF;

        ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN

          IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
               L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Interest Booking  account CASA is not a joint account');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-018',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                  L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Interest Booking  account #CASA is a individual account of  different customer');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-019',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
            DBG('TD JOINT HOLDERS COUNT-->' ||
                P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
            DBG('CASA JOINT HOLDERS COUNT-->' || L_TY_JOINT_DTLS.COUNT);
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
               L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Interest Booking  account #CASA belongs to different customers');
              PR_LOG_ERROR('STDCUSTD',
                           'FLEXCUBE',
                           'TD-CIF-021',
                           L_REC_OFFSET_ACC.CUST_AC_NO);

            END IF;
            IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
              FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
                DBG('TD joint holder-->' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                    .JOINT_HOLDER_CODE);
                IF L_TY_JOINT_DTLS.COUNT > 0 THEN
                  L_EXISTS := FALSE;
                  FOR K IN L_TY_JOINT_DTLS.FIRST .. L_TY_JOINT_DTLS.LAST LOOP
                    DBG('CASA joint holder-->' || L_TY_JOINT_DTLS(K)
                        .JOINT_HOLDER_CODE);
                    IF NVL(L_TY_JOINT_DTLS(K).JOINT_HOLDER_CODE, '****') =
                       NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                           .JOINT_HOLDER_CODE,
                           '****') THEN
                      L_EXISTS := TRUE;
                    END IF;

                  END LOOP;
                END IF;
                IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                   L_REC_OFFSET_ACC.CUST_NO AND (NOT L_EXISTS) THEN
                  DBG('Interest Booking  account #CASA joint holders are different');
                  PR_LOG_ERROR('STDCUSTD',
                               'FLEXCUBE',
                               'TD-CIF-020',
                               L_REC_OFFSET_ACC.CUST_AC_NO);
                END IF;
              END LOOP;
            END IF;

          END IF;
        END IF;
      END IF;
    END IF;

    IF P_FUNCTION_ID = 'IADCUSTD' THEN
      IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO THEN
        DBG('Validation For Profit booking account' ||
            P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
        IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
                                         P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
                                         L_REC_OFFSET_ACC) THEN
          DBG('Failed in getting cust account details for offset account');
          RETURN FALSE;
        END IF;
        DBG('p_stdcusac.v_sttms_cust_account.cust_no' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        DBG('l_rec_offset_acc.cust_no' || L_REC_OFFSET_ACC.CUST_NO);
        DBG('l_rec_offset_acc.JOINT_AC_INDICATOR' ||
            L_REC_OFFSET_ACC.JOINT_AC_INDICATOR);
        IF CUR_JOINT_DTLS%ISOPEN THEN
          CLOSE CUR_JOINT_DTLS;
        END IF;
        OPEN CUR_JOINT_DTLS(L_REC_OFFSET_ACC.BRANCH_CODE,
                            L_REC_OFFSET_ACC.CUST_AC_NO);
        FETCH CUR_JOINT_DTLS BULK COLLECT
          INTO L_TY_JOINT_DTLS;
        CLOSE CUR_JOINT_DTLS;
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' THEN
          IF L_REC_OFFSET_ACC.CUST_NO <>
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
            IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
              DBG('Profit Booking account CASA belongs to different customer');
              PR_LOG_ERROR('IADCUSTD',
                           'FLEXCUBE',
                           'IA-CIF-015',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
              DBG('Profit Booking  account CASA is a joint account of different customer');
              PR_LOG_ERROR('IADCUSTD',
                           'FLEXCUBE',
                           'IA-CIF-016',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                L_REC_OFFSET_ACC.CUST_NO AND
                L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
            DBG('Profit Booking  account CASA account is a Joint account');
            PR_LOG_ERROR('IADCUSTD',
                         'FLEXCUBE',
                         'IA-CIF-017',
                         L_REC_OFFSET_ACC.CUST_AC_NO);
          END IF;

        ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN

          IF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'S' THEN
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
               L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Profit Booking account CASA is not a joint account');
              PR_LOG_ERROR('IADCUSTD',
                           'FLEXCUBE',
                           'IA-CIF-018',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
                  L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Profit Booking  account #CASA is a individual account of  different customer');
              PR_LOG_ERROR('IADCUSTD',
                           'FLEXCUBE',
                           'IA-CIF-019',
                           L_REC_OFFSET_ACC.CUST_AC_NO);
            END IF;
          ELSIF L_REC_OFFSET_ACC.JOINT_AC_INDICATOR = 'J' THEN
            DBG('TD JOINT HOLDERS COUNT-->' ||
                P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
            DBG('CASA JOINT HOLDERS COUNT-->' || L_TY_JOINT_DTLS.COUNT);
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
               L_REC_OFFSET_ACC.CUST_NO THEN
              DBG('Profit Booking  account #CASA belongs to different customers');
              PR_LOG_ERROR('IADCUSTD',
                           'FLEXCUBE',
                           'IA-CIF-021',
                           L_REC_OFFSET_ACC.CUST_AC_NO);

            END IF;
            IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
              FOR I IN 1 .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP
                DBG('TD joint holder-->' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                    .JOINT_HOLDER_CODE);
                IF L_TY_JOINT_DTLS.COUNT > 0 THEN
                  L_EXISTS := FALSE;
                  FOR K IN L_TY_JOINT_DTLS.FIRST .. L_TY_JOINT_DTLS.LAST LOOP
                    DBG('CASA joint holder-->' || L_TY_JOINT_DTLS(K)
                        .JOINT_HOLDER_CODE);
                    IF NVL(L_TY_JOINT_DTLS(K).JOINT_HOLDER_CODE, '****') =
                       NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                           .JOINT_HOLDER_CODE,
                           '****') THEN
                      L_EXISTS := TRUE;
                    END IF;

                  END LOOP;
                END IF;
                IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO =
                   L_REC_OFFSET_ACC.CUST_NO AND (NOT L_EXISTS) THEN
                  DBG('Profit Booking  account #CASA joint holders are different');
                  PR_LOG_ERROR('IADCUSTD',
                               'FLEXCUBE',
                               'IA-CIF-020',
                               L_REC_OFFSET_ACC.CUST_AC_NO);
                END IF;
              END LOOP;
            END IF;

          END IF;
        END IF;
      END IF;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_validate_joint_holders..');
      RETURN FALSE;
  END FN_VALIDATE_JOINT_HOLDERS;

  FUNCTION FN_VALIDATE_RECORDS(P_SOURCE      IN VARCHAR2,
                               P_FUNCTION_ID IN VARCHAR2,
                               P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ACTION_CODE IN VARCHAR2,
                               P_ERR_CODE    IN OUT VARCHAR2,
                               P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Inside fn_validate_records');

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('Getting the subsys stats');
      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                      G_SUBSYSTEM_TY_FLDS) THEN
        DBG('fn_parse_subsysstats has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Calling fn_validate_items');
    IF NOT FN_VALIDATE_ITEMS(P_SOURCE,
                             P_FUNCTION_ID,
                             P_STDCUSAC,
                             P_ACTION_CODE,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
      DBG('fn_validate_items has returned false');
      RETURN FALSE;
    END IF;

    DBG('Validating Interim Details');
    IF NOT FN_VALIDATE_INTERIM_DTLS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_validate_interim_detls has returned false');
      RETURN FALSE;
    END IF;

    DBG('MIS Stat: ' || G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);
    IF G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT = 'U' THEN
      DBG('Validating MIS Details');
      IF NOT FN_VALIDATE_MIS(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_mis has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
      DBG('Validating Joint holders');
      IF NOT
          FN_VALIDATE_JOINT_ACCOUNT(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
        DBG('fn_validate_joint_account has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      DBG('## calling stpks_stdcusac_utils_1_cluster.fn_validate_ic_account...');
      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_VALIDATE_RECORDS(P_SOURCE,
                                                             P_FUNCTION_ID,
                                                             P_STDCUSAC,
                                                             P_ACTION_CODE,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DBG('## Failed in stpks_stdcusac_utils_1_cluster.fn_validate_records');
        RETURN FALSE;
      END IF;
      DBG('## success for stpks_stdcusac_utils_1_cluster.fn_validate_records...');
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('## kernel part');

      IF NOT FN_VALIDATE_JOINT_HOLDERS(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_joint_holders has returned false');
        RETURN FALSE;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('fn_validate_records returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_records with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_RECORDS;

  FUNCTION FN_INSERT_CUSTACSEQ(P_FUNCTION_ID IN VARCHAR2,
                               PI_BRANCH     IN VARCHAR2,
                               PI_CUST_NO    IN VARCHAR2,
                               PI_CUST_AC_NO IN VARCHAR2) RETURN BOOLEAN IS
    L_SEQNO        CSTB_CUSTACSEQ.SEQ_NO%TYPE := 1;
    L_NO_OF_STREAM PLS_INTEGER := CSPKS_PARALLEL_STREAM.FN_STREAM_COUNT('STDCUSAC',
                                                                        PI_BRANCH);
    L_ROWID        ROWID;
    L_RECSTAT      STTM_CUST_ACCOUNT.RECORD_STAT%TYPE;
  BEGIN
    DBG('pi_branch: ' || PI_BRANCH);
    DBG('pi_cust_ac_no: ' || PI_CUST_AC_NO);
    DBG('pi_cust_no: ' || PI_CUST_NO);

    DBG('Select the rowid');
    BEGIN
      SELECT B.ROWID
        INTO L_ROWID
        FROM STTMS_CUST_ACCOUNT B
       WHERE B.CUST_AC_NO = PI_CUST_AC_NO
         AND B.BRANCH_CODE = PI_BRANCH
         AND B.RECORD_STAT = 'O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Selecting without the record stat');
        SELECT B.ROWID
          INTO L_ROWID
          FROM STTMS_CUST_ACCOUNT B
         WHERE B.CUST_AC_NO = PI_CUST_AC_NO
           AND B.BRANCH_CODE = PI_BRANCH;
    END;
    DBG('Rowid: ' || L_ROWID);

    IF L_NO_OF_STREAM > 1 THEN
      BEGIN
        SELECT A.SEQ_NO
          INTO L_SEQNO
          FROM CSTB_CUSTACSEQ A, STTMS_CUST_ACCOUNT B

         WHERE A.BRANCH_CODE = PI_BRANCH
           AND A.BRANCH_CODE = B.BRANCH_CODE
           AND A.CUST_AC_NO = B.CUST_AC_NO
           AND B.RECORD_STAT = 'O'
           AND B.CUST_NO = PI_CUST_NO
           AND A.CUST_NO = B.CUST_NO
           AND ROWNUM = 1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT MOD(TRSQ_CUSTACSEQ.NEXTVAL, L_NO_OF_STREAM) + 1
              INTO L_SEQNO
              FROM DUAL;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Sequence does not exist');
              L_SEQNO := 1;
          END;
      END;
    END IF;
    DBG('l_seqno: ' || L_SEQNO);
    ICPKS_PARTITION_INFO.G_THIS_PART := L_SEQNO;
    BEGIN
      INSERT INTO CSTB_CUSTACSEQ
        (SEQ_NO, BRANCH_CODE, CUST_NO, CUST_AC_NO, R_ROWID)
      VALUES
        (L_SEQNO, PI_BRANCH, PI_CUST_NO, PI_CUST_AC_NO, L_ROWID);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_insert_custacseq with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_INSERT_CUSTACSEQ;

  FUNCTION FN_POPULATE_IC_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_REC_ICUDE         ICTMS_PR_INT_EFFDT%ROWTYPE;
    L_OLD_PROD          ICTBS_ACC_PR.PROD%TYPE;
    L_RULE_ID           ICTM_RULE_UDE.RULE_ID%TYPE;
    L_RATE_CODE         ICTMS_PR_INT_UDEVALS.RATE_CODE%TYPE;
    L_UDE_VALUE         ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_UDE_TYPE          ICTMS_RULE_UDE.UDE_TYPE%TYPE;
    L_UDE_ID            ICTMS_ACC_UDEVALS.UDE_ID%TYPE;
    L_RATE              ICTMS_RATES.RATE%TYPE;
    L_ACCOUNT_TYPE      STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ROLLOVER_TYPE     STTMS_ACCOUNT_CLASS.AUTO_ROLLOVER%TYPE;
    L_CLOSE_ON_MATURITY STTMS_ACCOUNT_CLASS.CLOSE_ON_MATURITY%TYPE;
    L_INT_UNCLAIMED     STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_PRINC_UNCLAIMED   STTMS_ACCOUNT_CLASS.MOVE_PRIC_TO_UNCLAIMED%TYPE;
    L_MAT_UNCLAIMED     STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_MOVE_FUNDS_ON_OVD STTMS_ACCOUNT_CLASS.RD_MOVE_FUNDS_ON_OVD%TYPE;
    L_DAYS              STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS%TYPE;
    L_MONTHS            STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS%TYPE;
    L_YEARS             STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS%TYPE;
    L_RD                STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_TDAYS             STTMS_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE;
    L_TMONTHS           STTMS_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE;
    L_TYEARS            STTMS_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE;
    L_FREE_BANKING_DAYS STTMS_ACCOUNT_CLASS.FREE_BANKING_DAYS%TYPE;
    L_DRCR_ADV          STTMS_ACCOUNT_CLASS.HAS_DRCR_ADV%TYPE;
    L_IC_INCLUSION      STTMS_ACCOUNT_CLASS.IC_INCLUSION%TYPE;
    L_HAS_IS            STTMS_ACCOUNT_CLASS.HAS_IS%TYPE;
    L_RES               VARCHAR2(2000);
    L_BRN               VARCHAR2(3);
    L_BRANCH            VARCHAR2(3);
    L_DATE              DATE;
    L_NEXT_DATE         DATE;
    L_CHG_START_DATE    DATE;
    L_CHG_DATE          DATE;
    L_OLD_EFFDT         DATE;
    L_DAY               NUMBER;
    L_MONTH             NUMBER;
    L_YEAR              NUMBER;
    L_CURR_DAY          NUMBER;
    L_CURR_MONTH        NUMBER;
    L_CURR_YEAR         NUMBER;
    L_CNTR              NUMBER;
    L_COUNT             NUMBER;
    L_PROD_CNT          NUMBER;
    L_CNT               INTEGER := 0;
    L_CNT1              NUMBER;
    L_TD_RATE_CODE      ICTMS_PR_INT_UDEVALS.TD_RATE_CODE%TYPE;
    L_HOLTREATREQD      ICTM_BRANCH_PARAMETERS.HOLIDAY_TRTMT_REQD%TYPE;
    L_TMP_CNT           PLS_INTEGER := 0;
    L_FOUND             BOOLEAN := FALSE;

    CURSOR CR_PRODS(P_ACC_CLASS VARCHAR2, P_CCY VARCHAR2) IS
      SELECT A.PRODUCT_CODE PROD,
             DECODE(P.UDE_CCY, 'ACY', 'A', 'L') UDE_CCY,
             A.CONT_VAR_ROLL CONT_VAR_ROLL
        FROM CSTMS_PRODUCT C, ICTM_PR_INT P, ICTM_PR_INT_ACLASS A
       WHERE C.PRODUCT_CODE = A.PRODUCT_CODE
         AND C.RECORD_STAT = 'O'
         AND C.ONCE_AUTH = 'Y'
         AND P.PRODUCT_CODE = A.PRODUCT_CODE
         AND A.ACLASS = P_ACC_CLASS
         AND A.CCY = P_CCY
         AND A.RECORD_STAT = 'N';
    R_PROD        CR_PRODS%ROWTYPE;
    L_RES_HOL_TRT DATE;
    L_CALC_DATE   DATE;

    L_MONTH_END_DEP VARCHAR2(1);
    L_RESULT        VARCHAR2(1);
    L_ERROR         VARCHAR2(1);
    L_HOL_PREF      VARCHAR2(1);
    L_WRK_DAY       DATE;
    L_MONTH_END_FLG BOOLEAN := FALSE;

    L_HOL_RES VARCHAR2(1000);
    L_HOL_MOV STTM_ACCOUNT_CLASS.HOLIDAY_MOVEMENT%TYPE;
    L_MESSAGE ERTB_MSGS.MESSAGE%TYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    L_MATURITY_DATE      DATE;
    L_NEXT_MATURITY_DATE DATE;

  BEGIN
    DBG('Inside fn_populate_ic_details');

    ICPKS_UTIL.PR_HOLIDAY_TREATMENT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                    L_HOLTREATREQD);
    DBG('holiday treatment is ' || L_HOLTREATREQD);

    DBG('Defaulting certain parameters again befor upload');

    DBG('Selecting from sttms_account_class');
    SELECT AC_CLASS_TYPE,
           AUTO_ROLLOVER,
           CLOSE_ON_MATURITY,
           MOVE_INT_TO_UNCLAIMED,
           MOVE_PRIC_TO_UNCLAIMED,
           MOVE_INT_TO_UNCLAIMED,
           RD_MOVE_FUNDS_ON_OVD,
           NVL(DEFAULT_TENOR_DAYS, 0),
           NVL(DEFAULT_TENOR_MONTHS, 0),
           NVL(DEFAULT_TENOR_YEARS, 0),
           NVL(RD_FLAG, 'N'),
           RD_SCHEDULE_DAYS,
           RD_SCHEDULE_MONTHS,
           RD_SCHEDULE_YEARS,
           FREE_BANKING_DAYS,
           HOLIDAY_CALENDAR,
           MONTH_END_DEPOSIT,
           HOLIDAY_MOVEMENT
      INTO L_ACCOUNT_TYPE,
           L_ROLLOVER_TYPE,
           L_CLOSE_ON_MATURITY,
           L_INT_UNCLAIMED,
           L_PRINC_UNCLAIMED,
           L_MAT_UNCLAIMED,
           L_MOVE_FUNDS_ON_OVD,
           L_DAYS,
           L_MONTHS,
           L_YEARS,
           L_RD,
           L_TDAYS,
           L_TMONTHS,
           L_TYEARS,
           L_FREE_BANKING_DAYS,
           L_HOL_PREF,
           L_MONTH_END_DEP,
           L_HOL_MOV
      FROM STTMS_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

    DBG('RD_FLAG: ' || L_RD);
    DBG('l_account_type ' || L_ACCOUNT_TYPE);

    IF L_ACCOUNT_TYPE <> 'Y' THEN
      IF (P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY IS NOT NULL) THEN
        DBG('Cannot enter TD Detils for Non Deposit accounts');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-334', '');

        RETURN FALSE;
      END IF;
    END IF;

    DBG('l_account_type: ' || L_ACCOUNT_TYPE);
    IF L_ACCOUNT_TYPE = 'Y' THEN
      IF L_RD <> 'Y' AND
         (P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD = 'Y' OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS IS NOT NULL OR
         P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT IS NOT NULL) THEN
        DBG('Cannot enter RD Detils for non RD accounts');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-335', '');

        RETURN FALSE;
      END IF;
      IF L_RD = 'Y' THEN
        IF (P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' OR
           P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
           P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' OR
           P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT IS NOT NULL OR
           P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT IS NOT NULL OR
           P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC IS NOT NULL OR
           P_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN IS NOT NULL) THEN
          DBG('Cannot enter RD Detils for non RD accounts');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-336', '');

          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN <> 'Y' AND
           (P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN IS NOT NULL OR
           P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC IS NOT NULL) THEN
          DBG('Cannot enter rd_payment_brn,etc...if rd_auto_pmnt_takedown is not selected');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-162', '');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    L_CHG_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE +
                        NVL(L_FREE_BANKING_DAYS, 0);
    L_CHG_DATE       := L_CHG_START_DATE;

    DBG('Calling cepkss_date.fn_isholiday');
    IF NOT CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                    L_CHG_START_DATE,
                                    L_RES) THEN
      DBG('cepkss_date.fn_isholiday has returned false... but continuing');
      NULL;
    END IF;
    IF L_RES = 'H' THEN
      DBG('#1 Calling cepkss_date.fn_getworkingday');
      L_CHG_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 L_CHG_START_DATE,
                                                 'N',
                                                 1);
    END IF;

    DBG('Calling cepkss_date.fn_splitdate for l_chg_date');
    IF NOT CEPKSS_DATE.FN_SPLITDATE(L_CHG_DATE, L_DAY, L_MONTH, L_YEAR) THEN
      DBG('cepkss_date.fn_splitdate for l_chg_date has returned false... but continuing');
    END IF;

    DBG('Calling cepkss_date.fn_splitdate for l_chg_start_date');
    IF NOT CEPKSS_DATE.FN_SPLITDATE(L_CHG_START_DATE,
                                    L_CURR_DAY,
                                    L_CURR_MONTH,
                                    L_CURR_YEAR) THEN
      DBG('cepkss_date.fn_splitdate has returned false... but continuing');
    END IF;
    IF L_MONTH != L_CURR_MONTH THEN
      DBG('#2 Calling cepkss_date.fn_getworkingday');
      L_CHG_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 L_CHG_START_DATE,
                                                 'Y',
                                                 1);
    END IF;
    L_CHG_START_DATE := L_CHG_DATE;
    DBG('l_chg_start_date: ' || L_CHG_START_DATE);

    IF L_DAYS IS NULL THEN
      L_DAYS := 0;
    ELSIF L_MONTHS IS NULL THEN
      L_MONTHS := 0;
    ELSIF L_YEARS IS NULL THEN
      L_YEARS := 0;
    END IF;
    DBG('l_days: ' || L_DAYS || ' l_months: ' || L_MONTHS || ' l_years: ' ||
        L_YEARS);

    SELECT COUNT(*)
      INTO L_COUNT
      FROM ICTMS_ACC
     WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
       AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    DBG('l_count of ictms_acc: ' || L_COUNT);

    IF L_COUNT = 0 THEN
      BEGIN
        SELECT IC_INCLUSION, NVL(HAS_IS, 'N'), NVL(HAS_DRCR_ADV, 'N')
          INTO L_IC_INCLUSION, L_HAS_IS, L_DRCR_ADV
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed while Selecting from sttms_account_class Table with: ' ||
              SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0075', '');
          RETURN FALSE;
      END;
      DBG('l_ic_inclusion: ' || L_IC_INCLUSION);

      L_DATE := NVL(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                    ADD_MONTHS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                               L_MONTHS + (L_YEARS * 12)) + L_DAYS);

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID := 6;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_date') := L_DATE;
        IF NOT
            STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                 P_STDCUSAC,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('l_date') THEN
          L_DATE := L_TB_CLUSTER_DATA('l_date');
        END IF;

      END IF;

      DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
          P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
      DBG('l_date-->' || L_DATE);
      IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
         NVL(L_DAYS, 0) = 0 THEN
        L_MATURITY_DATE := L_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                       L_DATE) THEN
          DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
          L_DATE := L_MATURITY_DATE;
        END IF;

      END IF;

      DBG('b4 holcheck l_date: ' || L_DATE);

      IF (L_IC_INCLUSION = 'Y') THEN

        P_STDCUSAC.V_ICTMS_ACC.BRN             := NVL(P_STDCUSAC.V_ICTMS_ACC.BRN,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        P_STDCUSAC.V_ICTMS_ACC.ACC             := NVL(P_STDCUSAC.V_ICTMS_ACC.ACC,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        P_STDCUSAC.V_ICTMS_ACC.CALC_ACC        := NVL(P_STDCUSAC.V_ICTMS_ACC.CALC_ACC,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        P_STDCUSAC.V_ICTMS_ACC.HAS_IS          := NVL(P_STDCUSAC.V_ICTMS_ACC.HAS_IS,
                                                      L_HAS_IS);
        P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE  := NVL(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
        P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN        := NVL(P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        P_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV    := NVL(P_STDCUSAC.V_ICTMS_ACC.HAS_DRCR_ADV,
                                                      L_DRCR_ADV);
        P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN := NVL(P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC := NVL(P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC        := NVL(P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE  := NVL(P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
                                                      L_CHG_START_DATE);

        DBG('l_account_type: ' || L_ACCOUNT_TYPE);
        IF L_ACCOUNT_TYPE = 'Y' THEN
          DBG('Deposit account');

          P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER          := NVL(P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
                                                               NVL(L_ROLLOVER_TYPE,
                                                                   'N'));
          P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY      := NVL(P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
                                                               NVL(L_CLOSE_ON_MATURITY,
                                                                   'N'));
          P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED  := NVL(P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
                                                               NVL(L_INT_UNCLAIMED,
                                                                   'N'));
          P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED := NVL(P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
                                                               NVL(L_PRINC_UNCLAIMED,
                                                                   'N'));
          P_STDCUSAC.V_ICTMS_ACC.RD_FLAG                := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_FLAG,
                                                               L_RD);
          P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN  := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN,
                                                               'N');

          P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED,
                                                                 'N');
          P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD     := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD,
                                                                 'N');

          P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

          P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE := NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
                                                      'P');

          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                      L_DATE);

          DBG('b4 holcheck maturity_date: ' ||
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

          L_RES_HOL_TRT := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;

          IF L_MONTH_END_DEP = 'Y' AND
             NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN

            DBG('Checking last working day of the account open date');
            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT('L',
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                                      L_WRK_DAY,
                                                      L_ERROR) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR, '');
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;

            IF L_WRK_DAY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE OR
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE =
               LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN
              L_MONTH_END_FLG := TRUE;
            END IF;
          END IF;
          IF L_MONTH_END_FLG THEN
            DBG('Checking for month end deposit');
            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE),
                                                      L_RES_HOL_TRT,
                                                      L_ERROR) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR, '');
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;

          ELSE

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 1;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

              IF NOT
                  STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA) THEN
                DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');

                RETURN FALSE;
              END IF;

            END IF;

            IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                      L_RES_HOL_TRT,
                                                      P_FUNCTION_ID) THEN
              DBG('icpks_holiday.fn_get_maturity_date has failed but continuing');
            END IF;

          END IF;

          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(L_RES_HOL_TRT,
                                                      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
            L_FN_CALL_ID      := 2;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            IF NOT
                STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                     P_STDCUSAC,
                                                                     L_FN_CALL_ID,
                                                                     L_TB_CLUSTER_DATA) THEN
              DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');

              RETURN FALSE;
            END IF;
          END IF;
          IF NOT GLOBAL.G_SKIP_KERNEL THEN

            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                    P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS +
                                                                    P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS * 12) +
                                                         P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS;

            DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
                P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
            DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
                P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
               NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
              L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
              DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
              IF NOT
                  STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                          P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
                DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
                P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
              END IF;

              IF L_NEXT_MATURITY_DATE <>
                 P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
                DBG('Next maturity date change during cascade');
                PKG_CASCADE_NXTMATDT := 'Y';
              END IF;

            END IF;

          END IF;
          GLOBAL.PR_RESET_SKIP_KERNEL;

          DBG('INTDETAILS Stat: ' || G_SUBSYSTEM_TY_FLDS('INTDETAILS').STAT);
          IF G_SUBSYSTEM_TY_FLDS('INTDETAILS').STAT <> 'U' THEN

            IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN

              BEGIN
                SELECT A.PRODUCT_CODE PROD,
                       DECODE(P.UDE_CCY, 'ACY', 'A', 'L') UDE_CCY,
                       A.CONT_VAR_ROLL CONT_VAR_ROLL
                  INTO R_PROD.PROD, R_PROD.UDE_CCY, R_PROD.CONT_VAR_ROLL
                  FROM CSTMS_PRODUCT C, ICTM_PR_INT P, ICTM_PR_INT_ACLASS A
                 WHERE C.PRODUCT_CODE = A.PRODUCT_CODE
                   AND C.RECORD_STAT = 'O'
                   AND C.ONCE_AUTH = 'Y'
                   AND P.PRODUCT_CODE = A.PRODUCT_CODE
                   AND A.ACLASS =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                   AND A.CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                   AND A.RECORD_STAT = 'N'
                   AND A.PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('SQLERRM' || SQLERRM);
                  DBG(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

              END;
              L_PROD_CNT := 1;
              DBG('2. ictms_acc_pr');
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).PROD := R_PROD.PROD;
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).WAIVE := 'N';
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).GEN_UCA := 'N';
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).RECORD_STAT := 'O';
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).ONCE_AUTH := 'Y';
              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).UDE_CCY := R_PROD.UDE_CCY;

              P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).CONT_VAR_ROLL := NVL(P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT)
                                                                         .CONT_VAR_ROLL,
                                                                         NVL(R_PROD.CONT_VAR_ROLL,
                                                                             'N'));
              DBG('Continue Variance on rollover here-> ' || P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT)
                  .CONT_VAR_ROLL);

              DBG('3. ictms_acc_effdt');
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).PROD := R_PROD.PROD;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).UDE_EFF_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).RECORD_STAT := 'O';
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).ONCE_AUTH := 'Y';
              SELECT RULE
                INTO L_RULE_ID
                FROM ICTMS_PR_INT
               WHERE PRODUCT_CODE = R_PROD.PROD;
              SELECT COUNT(*)
                INTO L_CNTR
                FROM ICTMS_PR_INT_EFFDT
               WHERE BRANCH_CODE =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                 AND CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                 AND PRODUCT_CODE = R_PROD.PROD
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';
              IF L_CNTR > 0 THEN
                L_BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              ELSE
                L_BRN := 'ALL';
              END IF;
              L_CNT := 0;
              FOR EACH_ROW IN (SELECT DISTINCT P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                               U.PRODUCT_CODE,
                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                               U.UDE_ID,
                                               U.UDE_VALUE,
                                               U.RATE_CODE
                                 FROM ICTMS_PR_INT_UDEVALS U,
                                      ICTM_PR_INT_EFFDT    E
                                WHERE U.BRANCH_CODE = L_BRN
                                  AND U.ACLASS =
                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                  AND U.CCY_CODE =
                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                  AND U.PRODUCT_CODE = R_PROD.PROD
                                  AND U.UDE_EFF_DT =
                                      (SELECT MAX(U1.UDE_EFF_DT)

                                         FROM ICTMS_PR_INT_EFFDT U1

                                        WHERE U1.BRANCH_CODE = U.BRANCH_CODE
                                          AND U1.ACLASS = U.ACLASS
                                          AND U1.CCY_CODE = U.CCY_CODE
                                          AND U1.PRODUCT_CODE =
                                              U.PRODUCT_CODE
                                          AND U1.RECORD_STAT = 'O'
                                          AND U1.AUTH_STAT = 'A'
                                          AND U1.UDE_EFF_DT <=
                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE)
                                  AND U.BRANCH_CODE = E.BRANCH_CODE
                                  AND U.ACLASS = E.ACLASS
                                  AND U.CCY_CODE = E.CCY_CODE
                                  AND U.PRODUCT_CODE = E.PRODUCT_CODE
                                  AND U.UDE_EFF_DT = E.UDE_EFF_DT
                                  AND E.RECORD_STAT = 'O'
                                  AND E.AUTH_STAT = 'A') LOOP
                L_CNT := L_CNT + 1;
                DBG('In UDE loop');
                SELECT UDE_TYPE
                  INTO L_UDE_TYPE
                  FROM ICTMS_RULE_UDE
                 WHERE RULE_ID = L_RULE_ID
                   AND UDE_ID = EACH_ROW.UDE_ID;
                IF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NOT NULL THEN
                  L_RATE_CODE := NULL;
                  BEGIN
                    L_BRANCH := ICPKSS_CALC.FN_GET_RATE_BRANCH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                               EACH_ROW.RATE_CODE);
                    SELECT RATE
                      INTO L_RATE
                      FROM ICTMS_RATES
                     WHERE BRANCH_CODE = L_BRANCH
                       AND RATE_CODE = EACH_ROW.RATE_CODE
                       AND CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                       AND EFF_DT =
                           (SELECT MAX(EFF_DT)
                              FROM ICTMS_RATES
                             WHERE BRANCH_CODE = L_BRANCH
                               AND RATE_CODE = EACH_ROW.RATE_CODE
                               AND CCY_CODE =
                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                               AND EFF_DT <=
                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE)
                       AND RECORD_STAT = 'O'
                       AND AUTH_STAT = 'A';
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_RATE := 0;
                  END;
                  L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0) + L_RATE;
                ELSIF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NULL THEN
                  L_RATE_CODE := NULL;
                  L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0);
                ELSE
                  L_RATE_CODE := EACH_ROW.RATE_CODE;
                  L_UDE_VALUE := EACH_ROW.UDE_VALUE;
                END IF;
                DBG('3A. ictms_acc_udevals');

                L_FOUND := FALSE;
                IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
                  L_TMP_CNT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST;
                  WHILE L_TMP_CNT IS NOT NULL LOOP
                    IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                     .UDE_ID = EACH_ROW.UDE_ID THEN
                      L_FOUND := TRUE;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).PROD := R_PROD.PROD;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_ID := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                              .UDE_ID,
                                                                              EACH_ROW.UDE_ID);
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_VALUE := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                                 .UDE_VALUE,
                                                                                 L_UDE_VALUE);
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).RATE_CODE := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                                 .RATE_CODE,
                                                                                 L_RATE_CODE);
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_EFF_DT := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                                  .UDE_EFF_DT,
                                                                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
                    END IF;
                    L_TMP_CNT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.NEXT(L_TMP_CNT);
                  END LOOP;
                END IF;
                IF NOT L_FOUND THEN
                  L_TMP_CNT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT + 1;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).PROD := R_PROD.PROD;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_ID := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                          .UDE_ID,
                                                                          EACH_ROW.UDE_ID);
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_VALUE := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                             .UDE_VALUE,
                                                                             L_UDE_VALUE);
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).RATE_CODE := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                             .RATE_CODE,
                                                                             L_RATE_CODE);
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT).UDE_EFF_DT := NVL(P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_CNT)
                                                                              .UDE_EFF_DT,
                                                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
                END IF;

              END LOOP;
              DBG('After vals loop: l_cnt: ' || L_CNT);
              IF L_CNT = 0 THEN

                L_CNT1 := 1;
                FOR I IN (SELECT U.UDE_ID
                            FROM ICTMS_RULE_UDE U, ICTMS_PR_INT P
                           WHERE P.PRODUCT_CODE = R_PROD.PROD
                             AND U.RULE_ID = P.RULE) LOOP
                  DBG('3B. ictms_acc_udevals');
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).PROD := R_PROD.PROD;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_EFF_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_ID := I.UDE_ID;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_VALUE := 0;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).RATE_CODE := NULL;

                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).AUTH_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT,
                                                                          'U');
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).RECORD_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT,
                                                                            'O');

                  L_CNT1 := L_CNT1 + 1;
                END LOOP;
              END IF;
            ELSE

              L_PROD_CNT := 0;
              DBG('Opening cr_prods');
              OPEN CR_PRODS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
              LOOP
                FETCH CR_PRODS
                  INTO R_PROD;
                EXIT WHEN CR_PRODS%NOTFOUND;
                DBG('No #' || CR_PRODS%ROWCOUNT || '#Product Obtained: ' ||
                    R_PROD.PROD);
                L_PROD_CNT := L_PROD_CNT + 1;

                DBG('2. ictms_acc_pr');
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).PROD := R_PROD.PROD;
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).WAIVE := 'N';
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).GEN_UCA := 'N';
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).RECORD_STAT := 'O';
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).ONCE_AUTH := 'Y';
                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).UDE_CCY := R_PROD.UDE_CCY;

                P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT).CONT_VAR_ROLL := NVL(P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT)
                                                                           .CONT_VAR_ROLL,
                                                                           NVL(R_PROD.CONT_VAR_ROLL,
                                                                               'N'));
                DBG('Continue variance on rollover here ->' || P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_CNT)
                    .CONT_VAR_ROLL);

                DBG('3. ictms_acc_effdt');
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).PROD := R_PROD.PROD;
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).UDE_EFF_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).RECORD_STAT := 'O';
                P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_PROD_CNT).ONCE_AUTH := 'Y';

                SELECT RULE
                  INTO L_RULE_ID
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = R_PROD.PROD;

                SELECT COUNT(*)
                  INTO L_CNTR
                  FROM ICTMS_PR_INT_EFFDT
                 WHERE BRANCH_CODE =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND ACLASS =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                   AND CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                   AND PRODUCT_CODE = R_PROD.PROD
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';
                IF L_CNTR > 0 THEN
                  L_BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                ELSE
                  L_BRN := 'ALL';
                END IF;

                L_CNT := 0;
                FOR EACH_ROW IN (SELECT DISTINCT P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                 U.PRODUCT_CODE,
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                 U.UDE_ID,
                                                 U.UDE_VALUE,
                                                 U.RATE_CODE,
                                                 U.TD_RATE_CODE
                                   FROM ICTMS_PR_INT_UDEVALS U,
                                        ICTM_PR_INT_EFFDT    E
                                  WHERE U.BRANCH_CODE = L_BRN
                                    AND U.ACLASS =
                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                    AND U.CCY_CODE =
                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                    AND U.PRODUCT_CODE = R_PROD.PROD
                                    AND U.UDE_EFF_DT =
                                        (SELECT MAX(U1.UDE_EFF_DT)

                                           FROM ICTMS_PR_INT_EFFDT U1

                                          WHERE U1.BRANCH_CODE =
                                                U.BRANCH_CODE
                                            AND U1.ACLASS = U.ACLASS
                                            AND U1.CCY_CODE = U.CCY_CODE
                                            AND U1.PRODUCT_CODE =
                                                U.PRODUCT_CODE
                                            AND U1.RECORD_STAT = 'O'
                                            AND U1.AUTH_STAT = 'A'
                                            AND U1.UDE_EFF_DT <=
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE)
                                    AND U.BRANCH_CODE = E.BRANCH_CODE
                                    AND U.ACLASS = E.ACLASS
                                    AND U.CCY_CODE = E.CCY_CODE
                                    AND U.PRODUCT_CODE = E.PRODUCT_CODE
                                    AND U.UDE_EFF_DT = E.UDE_EFF_DT
                                    AND E.RECORD_STAT = 'O'
                                    AND E.AUTH_STAT = 'A') LOOP
                  L_CNT := L_CNT + 1;
                  DBG('In UDE loop');
                  SELECT UDE_TYPE
                    INTO L_UDE_TYPE
                    FROM ICTMS_RULE_UDE
                   WHERE RULE_ID = L_RULE_ID
                     AND UDE_ID = EACH_ROW.UDE_ID;

                  IF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NOT NULL THEN
                    L_RATE_CODE := NULL;
                    BEGIN
                      L_BRANCH := ICPKSS_CALC.FN_GET_RATE_BRANCH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                                 EACH_ROW.RATE_CODE);
                      SELECT RATE
                        INTO L_RATE
                        FROM ICTMS_RATES
                       WHERE BRANCH_CODE = L_BRANCH
                         AND RATE_CODE = EACH_ROW.RATE_CODE
                         AND CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                         AND EFF_DT =
                             (SELECT MAX(EFF_DT)
                                FROM ICTMS_RATES
                               WHERE BRANCH_CODE = L_BRANCH
                                 AND RATE_CODE = EACH_ROW.RATE_CODE
                                 AND CCY_CODE =
                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                 AND EFF_DT <=
                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE)
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A';
                    EXCEPTION
                      WHEN OTHERS THEN
                        L_RATE := 0;
                    END;
                    L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0) + L_RATE;
                  ELSIF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NULL THEN
                    L_RATE_CODE := NULL;
                    L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0);
                  ELSE
                    L_RATE_CODE := EACH_ROW.RATE_CODE;
                    L_UDE_VALUE := EACH_ROW.UDE_VALUE;
                  END IF;
                  DBG('td_rate_code ::' || EACH_ROW.TD_RATE_CODE);
                  L_TD_RATE_CODE := EACH_ROW.TD_RATE_CODE;

                  DBG('l_td_rate_code ::' || L_TD_RATE_CODE);
                  DBG('3A. ictms_acc_udevals');
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).PROD := R_PROD.PROD;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).UDE_EFF_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).UDE_ID := EACH_ROW.UDE_ID;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).UDE_VALUE := L_UDE_VALUE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).RATE_CODE := L_RATE_CODE;
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT).TD_RATE_CODE := L_TD_RATE_CODE;

                  DBG('td_rate_code :: ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT)
                      .TD_RATE_CODE);

                END LOOP;
                DBG('After vals loop: l_cnt: ' || L_CNT);

                IF L_CNT = 0 THEN

                  L_CNT1 := 1;
                  FOR I IN (SELECT U.UDE_ID
                              FROM ICTMS_RULE_UDE U, ICTMS_PR_INT P
                             WHERE P.PRODUCT_CODE = R_PROD.PROD
                               AND U.RULE_ID = P.RULE) LOOP

                    DBG('3B. ictms_acc_udevals');
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).PROD := R_PROD.PROD;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_EFF_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_ID := I.UDE_ID;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).UDE_VALUE := 0;
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).RATE_CODE := NULL;

                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).AUTH_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT,
                                                                            'U');
                    P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_CNT1).RECORD_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT,
                                                                              'O');

                    L_CNT1 := L_CNT1 + 1;
                  END LOOP;
                END IF;
              END LOOP;
              CLOSE CR_PRODS;
            END IF;
          END IF;
        ELSE

          P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER          := NVL(P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER,
                                                               'N');
          P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY      := NVL(P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY,
                                                               'N');
          P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED  := NVL(P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED,
                                                               'N');
          P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED := NVL(P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED,
                                                               'N');
          P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE          := NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE,
                                                               'P');
          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE          := NVL(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                               NULL);

          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE      := NULL;
          P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC       := NULL;
          P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH   := NULL;
          P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;

        END IF;
      END IF;

    ELSE
      DBG('TD is currently getting modified');

      DBG('Cspkss_Req_Wrapper.g_action_code' ||
          CSPKSS_REQ_WRAPPER.G_ACTION_CODE);
      IF NVL(CSPKSS_REQ_WRAPPER.G_ACTION_CODE, '****') NOT IN ('MODIFY') THEN

        DBG('Going to call icpks_holiday.Fn_Get_maturity_date');
        L_RES_HOL_TRT := NULL;

        DBG('Holiday movement' || L_HOL_MOV);
        DBG('Holiday calendar' || L_HOL_PREF);
        IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL THEN
          IF NOT ICPKS_HOLIDAY.FN_ISHOLIDAY(L_HOL_PREF,
                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                            L_HOL_RES,
                                            L_MESSAGE) THEN
            DBG('icpks_holiday.fn_isholiday has returned false');
          END IF;
          DBG('Maturity date is a' || L_HOL_RES);

          IF L_HOL_PREF IN ('L', 'C', 'B') AND L_HOL_MOV = 'H' AND
             L_HOL_RES = 'H' THEN
            DBG('Maturity date is a holiday as per the holiday treatment');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'IC-MSC031',
                         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            IF GWPKS_UTIL.G_FROM_BEAN THEN
              DBG('brn ovpks for IC-MSC031');
              OVPKSS.PR_APPENDTBL('IC-MSC031',
                                  P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            END IF;
          END IF;
        END IF;

        IF L_MONTH_END_DEP = 'Y' AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN

          DBG('Checking last working day of the account open date');
          IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT('L',
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                    LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                                    L_WRK_DAY,
                                                    L_ERROR) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR, '');
            DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
          END IF;

          IF L_WRK_DAY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE OR
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE =
             LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN
            L_MONTH_END_FLG := TRUE;
          END IF;
        END IF;
        IF L_MONTH_END_FLG THEN
          DBG('Checking for month end deposit');
          IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                    LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE),
                                                    L_RES_HOL_TRT,
                                                    L_ERROR) THEN

            DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <>
             LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'IC-MSC022',
                         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                         LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~');
            IF GWPKS_UTIL.G_FROM_BEAN THEN
              DBG('brn ovpks for IC-MSC022');
              OVPKSS.PR_APPENDTBL('IC-MSC022',
                                  P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                  LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~');
            END IF;
          END IF;

          IF L_RES_HOL_TRT <>
             LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
            IF L_RES_HOL_TRT <
               LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC009',
                           LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~' ||
                           L_RES_HOL_TRT || '~');
              IF GWPKS_UTIL.G_FROM_BEAN THEN
                DBG('brn ovpks for IC-MSC009');
                OVPKSS.PR_APPENDTBL('IC-MSC009',
                                    LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~' ||
                                    L_RES_HOL_TRT || '~');
              END IF;
            END IF;

          END IF;

        ELSE

          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
            L_FN_CALL_ID      := 3;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

            IF NOT
                STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                     P_STDCUSAC,
                                                                     L_FN_CALL_ID,
                                                                     L_TB_CLUSTER_DATA) THEN
              DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');

              RETURN FALSE;
            END IF;

          END IF;

          IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                    L_RES_HOL_TRT,
                                                    P_FUNCTION_ID) THEN
            DBG('icpks_holiday.fn_get_maturity_date has failed but continuing');
          END IF;

          IF NVL(L_RES_HOL_TRT, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <>
             P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
            IF NVL(L_RES_HOL_TRT, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) >
               P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC002',
                           P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                           L_RES_HOL_TRT || '~');
              IF GWPKS_UTIL.G_FROM_BEAN THEN
                DBG('brn ovpks for IC-MSC002');
                OVPKSS.PR_APPENDTBL('IC-MSC002',
                                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                    L_RES_HOL_TRT || '~');
              END IF;
            ELSE
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC009',
                           P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                           L_RES_HOL_TRT || '~');
              IF GWPKS_UTIL.G_FROM_BEAN THEN
                DBG('brn ovpks for IC-MSC009 2');
                OVPKSS.PR_APPENDTBL('IC-MSC009',
                                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                    L_RES_HOL_TRT || '~');
              END IF;
            END IF;
          END IF;

        END IF;

        IF NVL(L_RES_HOL_TRT, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <>
           P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN

          IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE IS NOT NULL THEN
            DBG('Child TD is present, changing the dates in child td as maturity date in main TD is moved');
            DBG('Child TD int_start_date before : ' ||
                P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE);
            DBG('p_stdcusac.v_ictms_acc.maturity_date : ' ||
                P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.AC_OPEN_DATE  := L_RES_HOL_TRT;
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE +
                                                                            (L_RES_HOL_TRT -
                                                                            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.CHG_START_DATE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.CHG_START_DATE +
                                                                            (L_RES_HOL_TRT -
                                                                            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MATURITY_DATE      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MATURITY_DATE +
                                                                            (L_RES_HOL_TRT -
                                                                            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.NEXT_MATURITY_DATE := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.NEXT_MATURITY_DATE +
                                                                            (L_RES_HOL_TRT -
                                                                            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            DBG('Child TD int_start_date after : ' ||
                P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE);
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <=
             P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'IC-MSC003',
                         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                         P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
            IF GWPKS_UTIL.G_FROM_BEAN THEN
              DBG('brn ovpks for IC-MSC003');
              OVPKSS.PR_APPENDTBL('IC-MSC003',
                                  P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                  P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
            END IF;
          ELSE
            IF L_RES_HOL_TRT <= P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC026',
                           L_RES_HOL_TRT || '~' ||
                           P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
              DBG('Maturity Date cannot be less than or equal to interest start date, hence maturity date
                       movement is ignored');
              IF GWPKS_UTIL.G_FROM_BEAN THEN
                DBG('brn ovpks for IC-MSC026');
                OVPKSS.PR_APPENDTBL('IC-MSC026',
                                    L_RES_HOL_TRT || '~' ||
                                    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
              END IF;

            ELSE
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(L_RES_HOL_TRT,
                                                          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
            END IF;
          END IF;

        END IF;
        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'A' THEN
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS   := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                            0);
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                            0);
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS  := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                            0);

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 4;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              IF NOT
                  STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA) THEN
                DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');

                RETURN FALSE;
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                      P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS +
                                                                      P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS * 12) +
                                                           P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS;

              DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
                  P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
              DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
                  P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
              IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
                 NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
                L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
                DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
                IF NOT
                    STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
                  DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
                  P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
                END IF;

                IF L_NEXT_MATURITY_DATE <>
                   P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
                  DBG('Next maturity date change during cascade');
                  PKG_CASCADE_NXTMATDT := 'Y';
                END IF;

              END IF;

            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;

          ELSIF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'L' THEN
            DBG('Setting next maturity date as null as roll tenor preference is set as account class tenor');
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
          ELSE

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID      := 5;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              IF NOT
                  STPKSS_STDCUSAC_UTILS_CLUSTER.FN_POPULATE_IC_DETAILS(P_FUNCTION_ID,
                                                                       P_STDCUSAC,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA) THEN
                DBG('failed in   stpks_stdcusac_utils_cluster.fn_populate_ic_details-');

                RETURN FALSE;
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                      NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
                                                                          0) +
                                                                      NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS,
                                                                          0) * 12) +
                                                           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
                                                               0);

              DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
                  P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
              DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
                  P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
              IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
                 NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
                L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
                DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
                IF NOT
                    STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
                  DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
                  P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
                END IF;

                IF L_NEXT_MATURITY_DATE <>
                   P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
                  DBG('Next maturity date change during cascade');
                  PKG_CASCADE_NXTMATDT := 'Y';
                END IF;

              END IF;

            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;

          END IF;

        ELSE
          P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS    := NULL;
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS  := NULL;
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS   := NULL;
        END IF;
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

      END IF;
    END IF;

    DBG('fn_populate_ic_details returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_ic_details with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_POPULATE_IC_DETAILS;

  FUNCTION FN_UPLOAD_PROV_PERCENT(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_FLAG     BOOLEAN;
    L_NORM_CNT NUMBER;
  BEGIN
    DBG('Inside fn_Upload_Prov_Percent');
    DBG('Provisioning count: ' || P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD = 'N' AND
       P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT > 0 THEN
      DBG('Cannot enter Provision details if auto_prov_reqd is unchecked..');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-151', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD = 'Y' AND
       P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT = 0 THEN
      DBG('Failed:Provisioning Percentage Details NULL.');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MAN103', '');

      RETURN FALSE;
    END IF;

    L_NORM_CNT := 0;
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_PROV_REQD, 'N') = 'Y' THEN
      IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT LOOP
          L_FLAG := TRUE;
          DBG('Status: ' || P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I).STATUS);
          IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I).STATUS = 'NORM' THEN
            L_NORM_CNT := L_NORM_CNT + 1;
          END IF;

          IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I).PROV_PERCENT IS NULL THEN
            DBG('Failed :Provision Percent cannot be NULL');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'LD-PRV001',
                         '@STTMS_ACCOUNT_PROV_PERCENT.PROV_PERCENT~');
            RETURN FALSE;
          END IF;

          IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I).PROV_PERCENT > 100 THEN
            DBG('Failed :Provision Percent cannot be >100');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'LD-PRV003',
                         '@STTMS_ACCOUNT_PROV_PERCENT.PROV_PERCENT~');
            RETURN FALSE;
          END IF;

          IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT(I).DISCOUNT_PERCENT > 100 THEN
            DBG('Failed :Discount Percent cannot be >100');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'LD-PRV003',
                         '@STTMS_ACCOUNT_PROV_PERCENT.DISCOUNT_PERCENT~');
            RETURN FALSE;
          END IF;
        END LOOP;
        DBG('After loop: l_norm_cnt: ' || L_NORM_CNT);

        IF L_FLAG AND L_NORM_CNT <> 1 THEN
          DBG('The NORM status is mandatory');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-PRV1', '');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    DBG('fn_Upload_Prov_Percent returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_Upload_Prov_Percent with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_PROV_PERCENT;

  FUNCTION FN_UPLOAD_ACCMAINT_INSTR(P_FUNCTION_ID IN VARCHAR2,
                                    P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                    P_ACTION_CODE IN VARCHAR2) RETURN BOOLEAN IS
    L_TY_PREV_INTR STTMS_ACCOUNT_MAINT_INSTR%ROWTYPE;
    L_INSTR1       VARCHAR2(2000);
    L_INSTR2       VARCHAR2(2000);
    L_INSTR3       VARCHAR2(2000);
    L_INSTR4       VARCHAR2(2000);
  BEGIN
    DBG('Inside fn_upload_accmaint_instr');

    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.BRANCH_CODE        := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO         := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAKER_ID           := GLOBAL.USER_ID;
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAKER_DT_STAMP     := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP;
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CHECKER_ID         := '';
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CHECKER_DT_STAMP   := '';
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.RECORD_STAT        := 'O';
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.AUTH_STAT          := 'U';
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.DATE_OF_LAST_MAINT := GLOBAL.APPLICATION_DATE;
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.ONCE_AUTH          := 'N';
    P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MOD_NO             := 1;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('MODIFY');
      BEGIN
        SELECT *
          INTO L_TY_PREV_INTR
          FROM STTMS_ACCOUNT_MAINT_INSTR
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed:select * into l_ty_prev_intr' || SQLERRM);
      END;

      DBG('After selection');
      IF L_TY_PREV_INTR.MAINT_INSTR_1 <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_1 OR
         L_TY_PREV_INTR.MAINT_INSTR_2 <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_2 OR
         L_TY_PREV_INTR.MAINT_INSTR_3 <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_3 OR
         L_TY_PREV_INTR.MAINT_INSTR_4 <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_4 OR
         L_TY_PREV_INTR.INSTR1_WHEN <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR1_WHEN OR
         L_TY_PREV_INTR.INSTR2_WHEN <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR2_WHEN OR
         L_TY_PREV_INTR.INSTR3_WHEN <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR3_WHEN OR
         L_TY_PREV_INTR.INSTR4_WHEN <>
         P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR4_WHEN THEN
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CHECKER_ID       := '';
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CHECKER_DT_STAMP := '';
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.RECORD_STAT      := 'O';
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.AUTH_STAT        := 'U';
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.ONCE_AUTH        := 'Y';
        P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MOD_NO           := P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MOD_NO + 1;
      END IF;
    END IF;

    DBG('validating conditions ....');
    DEPKS_INSTR.PR_POPULATE_INSTR(P_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.CUST_AC_NO,
                                  GLOBAL.CURRENT_BRANCH,
                                  L_INSTR1,
                                  L_INSTR2,
                                  L_INSTR3,
                                  L_INSTR4);
    DBG('After call to procedure..depks_instr.pr_populate_instr.');
    IF L_INSTR1 = 'FAILED#$%' THEN
      DBG('Failed:Maintenance Instruction Condition 1 is not proper');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-INSTR01', '');
      RETURN FALSE;
    ELSIF L_INSTR2 = 'FAILED#$%' THEN
      DBG('Failed:Maintenance Instruction Condition 2 is not proper');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-INSTR02', '');
      RETURN FALSE;
    ELSIF L_INSTR3 = 'FAILED#$%' THEN
      DBG('Failed:Maintenance Instruction Condition 3 is not proper');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-INSTR03', '');
      RETURN FALSE;
    ELSIF L_INSTR4 = 'FAILED#$%' THEN
      DBG('Failed:Maintenance Instruction Condition 4 is not proper');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-INSTR04', '');
      RETURN FALSE;
    END IF;

    DBG('fn_upload_accmaint_instr returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_accmaint_instr with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_ACCMAINT_INSTR;

  FUNCTION FN_UPLOAD_RELATIONSHIP(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_LINKAGE_REC CSPKS_CSCCUSLN_MAIN.TY_TB_STB_RELATIONSHIP_LINKAGE;
    J             NUMBER;
  BEGIN
    DBG('Inside fn_upload_relationship');
    DBG('Count: ' ||
        P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT);

    J := 0;
    IF P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT > 0 THEN
      DBG('Removing the primary relation details');
      FOR I IN 1 .. P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT LOOP
        DBG('Relationship: ' || P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(I)
            .RELATIONSHIP);

        IF P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(I)
         .RELATIONSHIP IN ('primary', 'PRIMARY', 'Primary') THEN
          J := J + 1;
        END IF;
      END LOOP;
    END IF;
    IF J = 0 THEN

      IF NOT
          CSPKSS_UTILS.FN_DEFAULT_RELATIONSHIP(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                               'A',
                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
        DBG('Error in Inserting the Primary Holder');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUST0014', '');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('After defaulting the primary details: Count: ' ||
        L_LINKAGE_REC.COUNT);

    DBG('fn_upload_relationship returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_relationship with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_RELATIONSHIP;

  FUNCTION FN_UPLOAD_ACCMIS(P_FUNCTION_ID IN VARCHAR2,
                            P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_Upload_accmis');
    DBG('Unit ref no: ' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO);
    IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO IS NOT NULL THEN
      P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_TYPE := 'A';
      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG IS NULL THEN
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG := 'P';
      END IF;
    END IF;

    DBG('fn_Upload_accmis returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_Upload_accmis with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_ACCMIS;

  FUNCTION FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   P_ACTION_CODE IN VARCHAR2,
                                   P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS

    L_ERR_CODE               VARCHAR2(10);
    L_GL_CODE                STTMS_PAYIN_MODE.GL_CODE%TYPE;
    L_RD_FLAG                STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_RD_MIN_SCHEDULE_DAYS   STTMS_ACCOUNT_CLASS.RD_MIN_SCHEDULE_DAYS%TYPE;
    L_RD_MAX_SCHEDULE_DAYS   STTMS_ACCOUNT_CLASS.RD_MAX_SCHEDULE_DAYS%TYPE;
    L_RD_MIN_INSTALLMENT_AMT STTMS_ACCOUNT_CLASS.RD_MIN_INSTALLMENT_AMT%TYPE;
    L_ACCOUNT_TYPE           STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ROLLOVER_TYPE          STTMS_ACCOUNT_CLASS.AUTO_ROLLOVER%TYPE;
    L_CLOSE_ON_MATURITY      STTMS_ACCOUNT_CLASS.CLOSE_ON_MATURITY%TYPE;
    L_INT_UNCLAIMED          STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_PRINC_UNCLAIMED        STTMS_ACCOUNT_CLASS.MOVE_PRIC_TO_UNCLAIMED%TYPE;
    L_MAT_UNCLAIMED          STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_MOVE_FUNDS_ON_OVD      STTMS_ACCOUNT_CLASS.RD_MOVE_FUNDS_ON_OVD%TYPE;
    L_TDAYS                  STTMS_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE;
    L_TMONTHS                STTMS_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE;
    L_FREE_BANKING_DAYS      STTMS_ACCOUNT_CLASS.FREE_BANKING_DAYS%TYPE;
    L_DRCR_ADV               STTMS_ACCOUNT_CLASS.HAS_DRCR_ADV%TYPE;
    L_TYEARS                 STTMS_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE;
    L_IC_INCLUSION           STTMS_ACCOUNT_CLASS.IC_INCLUSION%TYPE;
    L_HAS_IS                 STTMS_ACCOUNT_CLASS.HAS_IS%TYPE;
    L_RD_MAT_UNCLAIMED       STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_ICTM_ACC               ICTMS_ACC%ROWTYPE;

    L_DATE      DATE;
    L_NEXT_DATE DATE;
    L_COUNT     NUMBER := 0;

    L_MIN_DAYS DATE;
    L_MAX_DAYS DATE;

    L_DFLT_TENOR NUMBER(5);
    L_CNT        NUMBER;
    L_CCY_RES    VARCHAR2(1);
    L_CCY_S      VARCHAR2(3);
    L_LOCAL_CCY  VARCHAR2(3);
    L_ERR_FLAG   NUMBER := 0;

    L_CONTRACT_VARIANCE NUMBER;

    L_PRODUCT_TYPE CSTMS_PRODUCT.PRODUCT_TYPE%TYPE;
    L_SPOT_RATE    OTTBS_CO_MASTER.SPOT_RATE%TYPE;

    L_ERROR_CODE  VARCHAR2(200);
    L_ERROR_PARAM VARCHAR2(200);

    L_AUTO_ROLLOVER         STTMS_ACCOUNT_CLASS.AUTO_ROLLOVER%TYPE;
    L_MIN_AMOUNT            STTMS_ACCOUNT_CLASS.MIN_AMOUNT%TYPE;
    L_MAX_AMOUNT            STTMS_ACCOUNT_CLASS.MAX_AMOUNT%TYPE;
    L_DAYS                  STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS%TYPE;
    L_MONTHS                STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS%TYPE;
    L_YEARS                 STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS%TYPE;
    L_MAX_TENOR_DAYS        STTMS_ACCOUNT_CLASS.MAX_TENOR_DAYS%TYPE;
    L_MIN_TENOR_DAYS        STTMS_ACCOUNT_CLASS.MIN_TENOR_DAYS%TYPE;
    L_MAX_TENOR_MONTHS      STTMS_ACCOUNT_CLASS.MAX_TENOR_MONTHS%TYPE;
    L_MIN_TENOR_MONTHS      STTMS_ACCOUNT_CLASS.MIN_TENOR_MONTHS%TYPE;
    L_MIN_TENOR_YEARS       STTMS_ACCOUNT_CLASS.MIN_TENOR_YEARS%TYPE;
    L_MAX_TENOR_YEARS       STTMS_ACCOUNT_CLASS.MAX_TENOR_YEARS%TYPE;
    L_MAXIMUM_RATE_VARIANCE CSTMS_PRODUCT.MAXIMUM_RATE_VARIANCE%TYPE;
    L_NORMAL_RATE_VARIANCE  CSTMS_PRODUCT.NORMAL_RATE_VARIANCE%TYPE;
    L_RATE_FLAG             CYTMS_RATES.MID_RATE%TYPE;
    L_FIXING_DATE           ICTMS_ACC.MATURITY_DATE%TYPE;

    L_RESULT             VARCHAR2(1000);
    L_DCD                STTMS_ACCOUNT_CLASS.DUAL_CCY_DEPOSIT%TYPE;
    L_ORGNAL_DATE        ICTMS_ACC.MATURITY_DATE%TYPE;
    L_FOUND_WORKING_DATE BOOLEAN := FALSE;
    L_WORKING_DATE       DATE;
    L_RETURN             BOOLEAN;

    L_PRINCIPAL_COUNT NUMBER := 0;
    L_INT_COUNT       NUMBER := 0;
    L_HOLTREATREQD    ICTM_BRANCH_PARAMETERS.HOLIDAY_TRTMT_REQD%TYPE;

    L_MIN_BOOK_AMT LDTM_CLUSTER_DETAILS.MIN_BOOK_AMT%TYPE;
    L_CLUSTER_SIZE LDTM_CLUSTER_DETAILS.CLUSTER_SIZE%TYPE;

    L_RES          VARCHAR2(2000);
    L_INT_PAYOUT   BOOLEAN := FALSE;
    L_PRINC_PAYOUT BOOLEAN := FALSE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    CURSOR C_V_ICTMS_TDPAYIN_DETAILS IS
      SELECT *
        FROM ICTM_TDPAYIN_DETAILS
       WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    L_ONCE_AUTH STTM_CUST_ACCOUNT.ONCE_AUTH%TYPE;

    L_NEXT_MATURITY_DATE DATE;
    L_MAT_DATE           DATE;
  BEGIN
    DBG('Inside fn_deposit_def_validate');

    IF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG <> 'Y' AND P_ACTION_CODE = 'MODIFY' THEN
        BEGIN
          SELECT ONCE_AUTH
            INTO L_ONCE_AUTH
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ONCE_AUTH := 'N';
        END;
        DBG('l_once_auth--> ' || L_ONCE_AUTH);
        IF L_ONCE_AUTH = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT = 0 THEN

            DBG('Get the Record For :ICTMS_TDPAYIN_DETAILS');
            IF C_V_ICTMS_TDPAYIN_DETAILS%ISOPEN THEN
              CLOSE C_V_ICTMS_TDPAYIN_DETAILS;
            END IF;

            OPEN C_V_ICTMS_TDPAYIN_DETAILS;
            FETCH C_V_ICTMS_TDPAYIN_DETAILS BULK COLLECT
              INTO P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS;
            CLOSE C_V_ICTMS_TDPAYIN_DETAILS;
          END IF;
          DBG('p_stdcusac.v_ictms_tdpayin_details.COUNTt--> ' ||
              P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
        END IF;
      END IF;
    END IF;

    DBG('branch_code---->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    ICPKS_UTIL.PR_HOLIDAY_TREATMENT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                    L_HOLTREATREQD);
    DBG('holiday treatment is ' || L_HOLTREATREQD);

    DBG('Princ liq brn: ' || P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH);
    DBG('Princ liq acc: ' || P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC);

    DBG('SUBSYSSTAT: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);

    DBG('--------1-----------');
    IF NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE, 'P') = 'P' THEN
      IF P_SOURCE <> 'FLEXCUBE' AND
         (P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH IS NULL OR
         P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC IS NULL) THEN
        P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC     := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_AC     := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.V_ICTMS_ACC.PRINC_LIQ_BRANCH := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      END IF;

      IF P_SOURCE <> 'FLEXCUBE' AND
         (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC IS NULL OR
         P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN IS NULL) THEN
        P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END IF;

    ELSIF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'I' THEN
      IF P_SOURCE <> 'FLEXCUBE' AND
         (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC IS NULL OR
         P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN IS NULL) THEN
        P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

      END IF;
    END IF;

    DBG('--------2-----------');
    IF P_STDCUSAC.V_ICTMS_ACC.ACC IS NULL OR
       P_STDCUSAC.V_ICTMS_ACC.BRN IS NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_STDCUSAC.V_ICTMS_ACC.BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    END IF;

    DBG('ROLLOVER_TYPE' || P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
    DBG('INTEREST BOOK_ACC' || P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 5;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      DBG('## calling stpks_stdcusac_utils_cluster.fn_deposit_def_validate...');
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                               P_STDCUSAC,
                                                               P_ACTION_CODE,
                                                               P_SOURCE,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
        DBG('failed in   stpks_stdcusac_utils_cluster.fn_deposit_def_validate-');

        RETURN FALSE;
      END IF;
      DBG('## success for stpks_stdcusac_utils_cluster.fn_deposit_def_validate...');
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN
      DBG('## kernel part');

      IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'T' AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <> P_STDCUSAC.V_ICTMS_ACC.ACC) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-112', '');
        L_ERR_FLAG := -1;
      END IF;

      IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'I' AND
         P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <> P_STDCUSAC.V_ICTMS_ACC.ACC) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-114', '');
        L_ERR_FLAG := -1;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH <> 'Y' THEN
      BEGIN
        SELECT NVL(MIN_BOOK_AMT, 0), NVL(CLUSTER_SIZE, 0)
          INTO L_MIN_BOOK_AMT, L_CLUSTER_SIZE
          FROM LDTM_CLUSTER_DETAILS
         WHERE CLUSTER_ID =
               (SELECT CLUSTER_ID
                  FROM STTM_ACCOUNT_CLASS
                 WHERE ACCOUNT_CLASS =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS)
           AND CURRENCY = P_STDCUSAC.V_ICTMS_TD_DETAILS.CCY;
      EXCEPTION
        WHEN OTHERS THEN
          L_MIN_BOOK_AMT := 0;
          L_CLUSTER_SIZE := 0;
      END;

      IF L_MIN_BOOK_AMT != 0 THEN
        IF (P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT < L_MIN_BOOK_AMT) THEN
          DBG('The deposit amount is less than the minimum booking amount.');
          L_ERROR_CODE  := 'ST-VAL-023';
          L_ERROR_PARAM := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       L_ERROR_CODE,
                       L_ERROR_PARAM);
          L_ERR_FLAG := -1;
        END IF;

        IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT < L_MIN_BOOK_AMT) THEN
          DBG('Rollover amount is less than the minimum booking amount of the cluster.');
          L_ERROR_CODE  := 'ST-VAL-321';
          L_ERROR_PARAM := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       L_ERROR_CODE,
                       L_ERROR_PARAM);
          L_ERR_FLAG := -1;
        END IF;

      END IF;

      IF L_CLUSTER_SIZE != 0 AND L_CLUSTER_SIZE IS NOT NULL THEN
        IF MOD(P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT, L_CLUSTER_SIZE) <> 0 AND
           L_CLUSTER_SIZE > 0 THEN
          L_ERROR_CODE  := 'TD-DEOP-31';
          L_ERROR_PARAM := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       L_ERROR_CODE,
                       L_ERROR_PARAM);
          L_ERR_FLAG := -1;
        END IF;

        IF MOD(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT, L_CLUSTER_SIZE) <> 0 AND
           L_CLUSTER_SIZE > 0 THEN
          L_ERROR_CODE  := 'IC-REDMN-10';
          L_ERROR_PARAM := 'Rollover Amount should be in multiples of Booking Unit';
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       L_ERROR_CODE,
                       L_ERROR_PARAM);
          L_ERR_FLAG := -1;
        END IF;

      END IF;

    END IF;

    DBG('maturity_date: ' || P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
    DBG('int_start_date: ' || P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 8;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG('## calling stpks_stdcusac_utils_1_cluster.fn_deposit_def_validate...');
      IF NOT
          STPKS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                               P_STDCUSAC,
                                                               P_ACTION_CODE,
                                                               P_SOURCE,
                                                               L_FN_CALL_ID,
                                                               L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_stdcusac_utils_1_cluster.fn_deposit_def_validate-');
        IF L_TB_CLUSTER_DATA('l_err_flag') IS NOT NULL THEN
          L_ERR_FLAG := L_TB_CLUSTER_DATA('l_err_flag');
        END IF;
        RETURN FALSE;
      END IF;
      DBG('## success for stpks_stdcusac_utils_1_cluster.fn_deposit_def_validate...');
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NULL OR
         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <
         P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-BOD009',
                     '@ICTMS_ACC.PRINC_LIQ_BRANCH~');
        L_ERR_FLAG := -1;

      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <=
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-BOD050',
                     '@ICTMS_ACC.PRINC_LIQ_BRANCH~');
        L_ERR_FLAG := -1;

      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    L_DFLT_TENOR := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;

    DBG('AUTO Rollover');

    IF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' AND
       P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN

      DBG('Original tenor days::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
      DBG('Original tenor months::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);
      DBG('Original tenor years::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);
      DBG('p_source' || P_SOURCE);
      DBG('p_stdcusac.v_ictms_acc.roll_tenor_pref' ||
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
      IF P_SOURCE <> 'FLEXCUBE' AND
         P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'A' THEN

        IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) = 0 THEN

          BEGIN
            WITH TTL_MONTHS AS
             (SELECT P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                     ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                TRUNC(MONTHS_BETWEEN(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                     P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE))) RES,
                     TRUNC(MONTHS_BETWEEN(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE)) MON
                FROM DUAL)
            SELECT CASE
                     WHEN RES >= 0 THEN
                      TRUNC(MON / 12)
                     ELSE
                      TRUNC((MON - 1) / 12)
                   END YEARS,
                   CASE
                     WHEN RES >= 0 THEN
                      MOD(MON, 12)
                     ELSE
                      MOD(MON - 1, 12)
                   END MONTHS,
                   CASE
                     WHEN RES >= 0 THEN
                      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                      ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE, MON)
                     ELSE
                      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                      ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                 MON - 1)
                   END DAYS
              INTO P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                   P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                   P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS
              FROM TTL_MONTHS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed to change tenor but continuing');
          END;
        END IF;

        IF NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS   := P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS := P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS;
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS  := P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS;
        END IF;
      END IF;
      DBG('p_stdcusac.v_ictms_acc.roll_tenor_days' ||
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS);
      DBG('p_stdcusac.v_ictms_acc.roll_tenor_years' ||
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS);
      DBG('p_stdcusac.v_ictms_acc.roll_tenor_days' ||
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS);
      DBG('Original tenor days::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
      DBG('Original tenor months::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);
      DBG('Original tenor years::' ||
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            STPKSS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                  P_STDCUSAC,
                                                                  P_ACTION_CODE,
                                                                  P_SOURCE,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_deposit_def_validate-');

          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
                                                                    0) +
                                                                (NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS,
                                                                     0) * 12)) +
                                                     NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
                                                         0);

        DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
          L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
          END IF;

          IF L_NEXT_MATURITY_DATE <>
             P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
            DBG('Next maturity date change during cascade');
            PKG_CASCADE_NXTMATDT := 'Y';
          END IF;

        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

    ELSE
      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
    END IF;

    DBG('if Move interest to unclaimed is checked move principal to unclaimed should also be checked.');
    IF P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' AND
       P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N' THEN

      DBG('p_function_id' || P_FUNCTION_ID);
      DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
      IF P_FUNCTION_ID = 'STDCUSTD' OR (GWPKS_UTIL.PKG_FUNC = 'TDMM') THEN

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-475', '');

      ELSIF P_FUNCTION_ID = 'IADCUSTD' OR (GWPKS_UTIL.PKG_FUNC = 'IPTDMM') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IP-ACC-475', '');
      END IF;

      L_ERR_FLAG := -1;
    END IF;

    DBG('Move Interest to Unclaimed');
    IF P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' AND
       P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
       P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE <> 'P' THEN
      DBG('Rollover Type Should be Principal if Auto Rollover and Move Interest to Unclaimed is Selected');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-159', '');
      L_ERR_FLAG := -1;

    END IF;

    DBG('Action Code -->' || P_ACTION_CODE);
    IF P_ACTION_CODE NOT IN ('ICPKP', 'POPDT', 'COPY') THEN
      DBG('p_stdcusac.v_ictms_acc_pr.count -->' ||
          P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
      IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        DBG('p_stdcusac.v_ictms_acc.rollover_type -->' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
        DBG('p_stdcusac.v_ictms_acc.auto_rollover -->' ||
            P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER);
        DBG('p_stdcusac.v_ictms_acc.move_int_to_unclaimed -->' ||
            P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED);
        DBG('p_stdcusac.v_ictms_acc.move_pric_to_unclaimed -->' ||
            P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED);
        DBG('p_stdcusac.v_ictms_acc.acc -->' || P_STDCUSAC.V_ICTMS_ACC.ACC);
        DBG('p_stdcusac.v_ictms_acc.book_acc -->' ||
            P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
        DBG('p_stdcusac.v_ictms_acc.brn -->' || P_STDCUSAC.V_ICTMS_ACC.BRN);
        DBG('p_stdcusac.v_ictms_acc.book_brn -->' ||
            P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN);
        IF ((P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
           P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y')) AND
           P_STDCUSAC.V_ICTMS_ACC.ACC = P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC AND
           P_STDCUSAC.V_ICTMS_ACC.BRN = P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN THEN
          DBG('Booking Account and TD account are same,Do you want to Proceed?');

          DBG('p_function_id' || P_FUNCTION_ID);
          DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
          IF P_FUNCTION_ID = 'STDCUSTD' OR (GWPKS_UTIL.PKG_FUNC = 'TDMM') THEN

            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-99', '');

          ELSIF P_FUNCTION_ID = 'IADCUSTD' OR
                (GWPKS_UTIL.PKG_FUNC = 'IPTDMM') THEN
            DBG('Profit Booking Account and TD account are same,Do you want to Proceed?');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IP-ACC-476', '');
          END IF;

        END IF;

        DBG('P_stdcusac.v_ictms_acc.auto_rollover' ||
            P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER);
        DBG('P_stdcusac.v_ictms_acc.rollover_type' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
        DBG('P_stdcusac.v_ictms_acc.move_int_to_unclaimed' ||
            P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED);
        DBG('P_stdcusac.v_ictms_acc.move_pric_to_unclaimed' ||
            P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED);
        DBG('P_stdcusac.v_ictms_tdpayout_details.count' ||
            P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
        DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
        IF GWPKS_UTIL.PKG_FUNC = 'TDMM' THEN

          IF P_ACTION_CODE = 'NEW' THEN
            DBG('Close on maturity~-->' ||
                P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY);
            IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'N' AND
               P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'N' AND
               P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N' THEN
              P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY := 'Y';
            END IF;
            DBG('Close on maturity ~2-->' ||
                P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY);
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
              FOR K IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
                DBG('PAYOUT COMPONENT' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(K)
                    .PAYOUT_COMPONENT);
                IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(K)
                 .PAYOUT_COMPONENT = 'I' THEN
                  DBG('Interest payout exists');
                  L_COUNT := 1;
                  EXIT;
                END IF;
              END LOOP;
            END IF;

            IF L_COUNT = 0 THEN
              DBG('Interest Payout Details are not provided');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-105', '');
            END IF;

          END IF;

        END IF;

        IF (P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y') AND
           P_STDCUSAC.V_ICTMS_ACC.ACC <> P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC AND
           P_STDCUSAC.V_ICTMS_ACC.BRN = P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN THEN
          DBG('Booking account should be TD account when move principle to unclaimed is checked');

          DBG('p_function_id' || P_FUNCTION_ID);
          DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
          IF P_FUNCTION_ID = 'STDCUSTD' OR (GWPKS_UTIL.PKG_FUNC = 'TDMM') THEN

            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-66', '');

          ELSIF P_FUNCTION_ID = 'IADCUSTD' OR
                (GWPKS_UTIL.PKG_FUNC = 'IPTDMM') THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IP-ACC-479', '');
          END IF;

        END IF;

        DBG('p_stdcusac.v_ictms_acc.rollover_type' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
        DBG('p_stdcusac.v_ictms_acc.auto_rollover' ||
            P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER);
        DBG('Checking payout count-->' ||
            P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);

        IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
          FOR EACH_REC IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
            DBG('payout component-->' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
                .PAYOUT_COMPONENT);
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
             .PAYOUT_COMPONENT = 'I' THEN
              DBG('For interest component setting Flag true');
              L_INT_PAYOUT := TRUE;
            END IF;

            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(EACH_REC)
             .PAYOUT_COMPONENT = 'P' AND
                P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'P' THEN
              DBG('For both interest and principle as payout component, setting Flag as FALSE');
              L_PRINC_PAYOUT := TRUE;
            END IF;
          END LOOP;
        END IF;

        IF L_PRINC_PAYOUT AND P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'P' AND
           P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          DBG('For Rollover type - Principal, Principal Payout Component should not be maintained');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-106', '');
        END IF;

        IF NOT L_INT_PAYOUT THEN

          IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'P' AND
             P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
             P_STDCUSAC.V_ICTMS_ACC.ACC = P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC AND
             P_STDCUSAC.V_ICTMS_ACC.BRN = P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN THEN
            DBG('Rollover type cannot be Principal only when the Interest Booking Account is a TD account');

            DBG('p_function_id' || P_FUNCTION_ID);
            DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
            IF P_FUNCTION_ID = 'STDCUSTD' OR (GWPKS_UTIL.PKG_FUNC = 'TDMM') THEN

              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-98', '');

            ELSIF P_FUNCTION_ID = 'IADCUSTD' OR
                  (GWPKS_UTIL.PKG_FUNC = 'IPTDMM') THEN
              DBG('For Rollover type - Principal,the Profit booking account should not be a TD account');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IP-ACC-477', '');
            END IF;

          END IF;

        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 4;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        IF NOT
            STPKSS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                  P_STDCUSAC,
                                                                  P_ACTION_CODE,
                                                                  P_SOURCE,
                                                                  L_FN_CALL_ID,
                                                                  L_TB_CLUSTER_DATA) THEN
          DBG('Error in Stpkss_Stdcusac_Utils_1_Cluster.fn_deposit_def_validate');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
          L_ERR_FLAG := -1;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        DBG('p_stdcusac.v_Ictms_Acc.Rollover_Amt is ' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT);
        DBG('p_stdcusac.v_ictms_acc.maturity_amount is ' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT);
        DBG('p_stdcusac.v_Ictms_Td_Details.Td_Amount is' ||
            P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);

        IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT >
           P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT AND
           P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT <=
           P_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT) THEN
          DBG('Special Amount is Greater than TD Amount');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-0116', '');
        END IF;

        IF P_FUNCTION_ID = 'IADCUSTD' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT >
             P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT THEN
            DBG('Rollover Amount is Greater than the TD Amount');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-0119', '');
            L_ERR_FLAG := -1;
          END IF;
        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

    END IF;

    DBG('Rollover Type');

    DBG('auto deposit check' || STPKS_STDCUSAC_KERNEL.G_AUTO_DEPOSIT);
    IF STPKS_STDCUSAC_KERNEL.G_AUTO_DEPOSIT <> 'Y' THEN

      IF NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE, 'P') <> 'S' THEN

        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID      := 1;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              STPKSS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                    P_STDCUSAC,
                                                                    P_ACTION_CODE,
                                                                    P_SOURCE,
                                                                    L_FN_CALL_ID,
                                                                    L_TB_CLUSTER_DATA) THEN
            DBG('Error in Stpkss_Stdcusac_Utils_1_Cluster.fn_deposit_def_validate');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
            L_ERR_FLAG := -1;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN

          IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT IS NOT NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD038', '');
            L_ERR_FLAG := -1;

          END IF;

        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;

      ELSE
        DBG('Rollover Amount');
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT, 0) <= 0 THEN
          DBG('Roll Over Amount Can not be Zero for Rollover Type S');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-119', '');
          L_ERR_FLAG := -1;

        END IF;
      END IF;

      DBG('Pay inout checks');
      IF NOT FN_PAYINOUT_DEFAULT(P_FUNCTION_ID,
                                 P_STDCUSAC,
                                 P_ACTION_CODE,
                                 P_SOURCE,
                                 L_ERR_FLAG) THEN
        DBG('failed in fn_payinout_default');
        L_ERR_FLAG := -1;
      END IF;

      DBG('Rd Flag');
      BEGIN
        SELECT AC_CLASS_TYPE,
               NVL(AUTO_ROLLOVER, 'N'),
               NVL(CLOSE_ON_MATURITY, 'N'),
               NVL(MOVE_INT_TO_UNCLAIMED, 'N'),
               NVL(MOVE_PRIC_TO_UNCLAIMED, 'N'),
               NVL(RD_MOVE_FUNDS_ON_OVD, 'N'),
               NVL(DEFAULT_TENOR_DAYS, 0),
               NVL(DEFAULT_TENOR_MONTHS, 0),
               NVL(DEFAULT_TENOR_YEARS, 0),
               NVL(RD_FLAG, 'N'),
               RD_SCHEDULE_DAYS,
               RD_SCHEDULE_MONTHS,
               RD_SCHEDULE_YEARS,
               FREE_BANKING_DAYS,
               IC_INCLUSION,
               NVL(HAS_IS, 'N'),
               NVL(HAS_DRCR_ADV, 'N'),
               NVL(RD_MOVE_MAT_TO_UNCLAIMED, 'N'),
               NVL(RD_MIN_INSTALLMENT_AMT, 0),
               NVL(MIN_TENOR_DAYS, 0),
               NVL(MAX_TENOR_DAYS, 0),
               NVL(MAX_TENOR_MONTHS, 0),
               NVL(MIN_TENOR_MONTHS, 0),
               NVL(MIN_TENOR_YEARS, 0),
               NVL(MAX_TENOR_YEARS, 0),
               NVL(RD_MIN_SCHEDULE_DAYS, 0),
               NVL(MIN_AMOUNT, 0),
               NVL(MAX_AMOUNT, 0),
               RD_MAX_SCHEDULE_DAYS
          INTO L_ACCOUNT_TYPE,
               L_AUTO_ROLLOVER,
               L_CLOSE_ON_MATURITY,
               L_INT_UNCLAIMED,
               L_PRINC_UNCLAIMED,
               L_MOVE_FUNDS_ON_OVD,
               L_DAYS,
               L_MONTHS,
               L_YEARS,
               L_RD_FLAG,
               L_TDAYS,
               L_TMONTHS,
               L_TYEARS,
               L_FREE_BANKING_DAYS,
               L_IC_INCLUSION,
               L_HAS_IS,
               L_DRCR_ADV,
               L_RD_MAT_UNCLAIMED,
               L_RD_MIN_INSTALLMENT_AMT,
               L_MIN_TENOR_DAYS,
               L_MAX_TENOR_DAYS,
               L_MAX_TENOR_MONTHS,
               L_MIN_TENOR_MONTHS,
               L_MIN_TENOR_YEARS,
               L_MAX_TENOR_YEARS,
               L_RD_MIN_SCHEDULE_DAYS,
               L_MIN_AMOUNT,
               L_MAX_AMOUNT,
               L_RD_MAX_SCHEDULE_DAYS
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in getting Account class ' || SQLERRM);
          L_ERROR_CODE  := 'ST-ACC-300';
          L_ERROR_PARAM := 'getting Account class Details';
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       L_ERROR_CODE,
                       L_ERROR_PARAM);
      END;

      DBG('l_rd_flag: ' || L_RD_FLAG);
      IF L_RD_FLAG = 'Y' THEN
        DBG('Inside RD FLAG Y');
        P_STDCUSAC.V_ICTMS_ACC.RD_FLAG := L_RD_FLAG;
        DBG('int_start_date: ' || P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

        DBG('rd sch date is: ' || P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT);
        P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT := NVL(P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT,
                                                   P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

        DBG('Throuh p_stdcusac.v_ictms_acc.rd_pay_schdt');
        P_STDCUSAC.V_ICTMS_TD_DETAILS.PAYIN_OPTION  := NULL;
        P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT     := NULL;
        P_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN    := NULL;
        P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC := NULL;
      ELSE
        P_STDCUSAC.V_ICTMS_ACC.RD_FLAG                  := L_RD_FLAG;
        P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN    := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_MAT_TO_UNCLAIMED := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_MOVE_FUNDS_ON_OVD     := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS         := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS       := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS        := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC           := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN           := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY           := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT       := NULL;
        P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT             := NULL;
      END IF;
      IF L_DAYS IS NULL THEN
        L_DAYS := 0;
      ELSIF L_MONTHS IS NULL THEN
        L_MONTHS := 0;
      ELSIF L_YEARS IS NULL THEN
        L_YEARS := 0;
      END IF;
      DBG('l_days: ' || L_DAYS || ' l_months: ' || L_MONTHS ||
          ' l_years: ' || L_YEARS);

      L_DATE := ADD_MONTHS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                           L_MONTHS + (L_YEARS * 12)) + L_DAYS;

      DBG('l_date' || L_DATE);
      L_NEXT_DATE := L_DATE +
                     (L_DATE - P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

      L_MIN_DAYS := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                               L_MIN_TENOR_MONTHS + L_MIN_TENOR_YEARS * 12) +
                    L_MIN_TENOR_DAYS;
      L_MAX_DAYS := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                               L_MAX_TENOR_MONTHS + L_MAX_TENOR_YEARS * 12) +
                    L_MAX_TENOR_DAYS;

      DBG('l_max_tenor_days::' || L_MAX_TENOR_DAYS);
      DBG('l_max_tenor_months::' || L_MAX_TENOR_MONTHS);
      DBG('l_max_tenor_years::' || L_MAX_TENOR_YEARS);
      IF L_MAX_TENOR_DAYS = 0 AND L_MAX_TENOR_MONTHS = 0 AND
         L_MAX_TENOR_YEARS = 0 THEN

        L_MAX_DAYS := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE + 1;

      END IF;
      DBG('l_min_days = ' || L_MIN_DAYS);
      DBG('l_max_days = ' || L_MAX_DAYS);

      DBG('--------------1---------------');
      IF P_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK IS NULL THEN
        P_STDCUSAC.V_ICTMS_ACC.OVERRIDE_AMT_BLOCK := 'N';
      END IF;
      IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
        IF P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-110', '');
          L_ERR_FLAG := -1;

        END IF;

        DBG('p_source' || P_SOURCE);
        DBG('p_stdcusac.v_ictms_acc.roll_tenor_pref' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
        IF P_SOURCE <> 'FLEXCUBE' AND
           P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF IS NULL THEN
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF := 'L';
        END IF;
        DBG('p_stdcusac.v_ictms_acc.roll_tenor_pref' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
        DBG('p_stdcusac.v_ictms_acc.next_maturity_date' ||
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        DBG('p_stdcusac.v_ictms_acc.maturity_date' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

        IF P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE IS NULL THEN
          IF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD007', '');
            L_ERR_FLAG := -1;

          END IF;
        ELSIF P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE <=
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD007', '');
          L_ERR_FLAG := -1;

        END IF;
      END IF;

      DBG('Rollover type: ' || P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
      IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'S' THEN
        IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT IS NULL OR
           P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT <= 0) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD008', '');
          L_ERR_FLAG := -1;

        END IF;
      END IF;

      DBG('------------------------2---------------------------');
      IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'Y' THEN
        IF (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS, 0) +
           NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS, 0) +
           NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS, 0)) = 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD001', '');
          L_ERR_FLAG := -1;

        END IF;
        DBG('may come here...');
        DBG('l_rd_min_schedule_days: ' || L_RD_MIN_SCHEDULE_DAYS);
        DBG('l_rd_max_schedule_days: ' || L_RD_MAX_SCHEDULE_DAYS);

        IF (TO_DATE(ADD_MONTHS(TO_DATE(GLOBAL.APPLICATION_DATE,
                                       GLOBAL.GET_NLS_DT_FORMAT),
                               (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
                                    0) + (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
                                               0) * 12))) +
                    NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS, 0),

                    GLOBAL.GET_NLS_DT_FORMAT) -

           TO_DATE(GLOBAL.APPLICATION_DATE, GLOBAL.GET_NLS_DT_FORMAT) <

           L_RD_MIN_SCHEDULE_DAYS) THEN
          DBG('Failed:min frequnecy');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD006', '');
          L_ERR_FLAG := -1;

        END IF;

        DBG('---------3---------');
        IF L_RD_MAX_SCHEDULE_DAYS IS NOT NULL THEN
          IF (TO_DATE(ADD_MONTHS(GLOBAL.APPLICATION_DATE,
                                 (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
                                      0) + (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
                                                 0) * 12))) +

                      NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS, 0),
                      GLOBAL.GET_NLS_DT_FORMAT) -
             TO_DATE(GLOBAL.APPLICATION_DATE, GLOBAL.GET_NLS_DT_FORMAT) >
             L_RD_MAX_SCHEDULE_DAYS) THEN

            DBG('Failed: Max frequncy');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD007', '');
            L_ERR_FLAG := -1;

          END IF;
        END IF;
        DBG('--------------4-------------');
        IF P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT IS NULL OR
           P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT <= 0 THEN
          DBG('Failed in rd_installment_amt validation ');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD002', '');
          L_ERR_FLAG := -1;

        END IF;
        DBG('--------------5--------------');
        IF P_STDCUSAC.V_ICTMS_ACC.RD_INSTALLMENT_AMT <
           NVL(L_RD_MIN_INSTALLMENT_AMT, 0) THEN
          DBG('Failed in rd_installment_amt validation ');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD008', '');
          L_ERR_FLAG := -1;

        END IF;
        IF P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT IS NULL OR
           P_STDCUSAC.V_ICTMS_ACC.RD_PAY_SCHDT <
           P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
          DBG('Failed in rd_pay_schdt validation');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD003', '');
          L_ERR_FLAG := -1;

        END IF;
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN, 'N') = 'Y' AND
           (P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN IS NULL OR
            P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC IS NULL) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-RD004', '');
          L_ERR_FLAG := -1;

        END IF;

        DBG('-----6-----');
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.RD_AUTO_PMNT_TAKEDOWN, 'N') = 'Y' AND
           (P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN IS NOT NULL OR
            P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC IS NOT NULL) THEN
          IF P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY IS NULL THEN
            BEGIN
              SELECT CCY
                INTO P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY
                FROM STTMS_CUST_ACCOUNT
               WHERE BRANCH_CODE = P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_BRN
                 AND CUST_AC_NO = P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_ACC;
              DBG('Rd_payment_ccy: ' ||
                  P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed to default rd_payment_ccy' || SQLERRM);
            END;
            DBG('Rd_payment_ccy: ' ||
                P_STDCUSAC.V_ICTMS_ACC.RD_PAYMENT_CCY);
          END IF;
        END IF;

        DBG('----------7---------');

        IF (P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <
           (ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE

                      ,
                       (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS, 0) +
                       (NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS, 0) * 12))) +
           NVL(P_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS, 0)) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-RD001', '');
          L_ERR_FLAG := -1;

        END IF;

      END IF;

      DBG('-------------8--------------');
      IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'N' THEN

        IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          IF NOT FN_PAYINOUT_VALIDATE(P_FUNCTION_ID,
                                      P_ACTION_CODE,
                                      P_STDCUSAC,
                                      L_ERR_FLAG) THEN
            DBG('failed in fn_payinout_validate');
            RETURN FALSE;
          END IF;
        END IF;

        DBG('Payout count :' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);

        IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-105', '');
            L_ERR_FLAG := -1;

          END IF;

          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT < 1 THEN
            DBG('payout option cannot be null ');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-205', '');
            L_ERR_FLAG := -1;

          ELSE
            L_PRINCIPAL_COUNT := 0;
            FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
               .PAYOUT_COMPONENT = 'P' THEN
                L_PRINCIPAL_COUNT := L_PRINCIPAL_COUNT + 1;
              END IF;
            END LOOP;

            IF L_PRINCIPAL_COUNT < 1 THEN

              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-525', '');

              L_ERR_FLAG := -1;
            END IF;

          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
             P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-104', '');
            L_ERR_FLAG := -1;

          END IF;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          IF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'P') THEN
            IF (P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) AND
               (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT < 1 THEN
                DBG('for rollover with P payout details cannot be null ');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-205', '');
                L_ERR_FLAG := -1;

              ELSE
                L_PRINCIPAL_COUNT := 0;
                L_INT_COUNT       := 0;
                FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
                  IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                   .PAYOUT_COMPONENT = 'P' THEN
                    L_PRINCIPAL_COUNT := L_PRINCIPAL_COUNT + 1;
                  END IF;

                  IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                   .PAYOUT_COMPONENT = 'I' THEN
                    L_INT_COUNT := L_INT_COUNT + 1;
                  END IF;
                END LOOP;

                IF L_INT_COUNT < 1 THEN
                  IF L_PRINCIPAL_COUNT < 1 THEN
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'ST-ACC-525',
                                 '');
                    L_ERR_FLAG := -1;
                  END IF;
                END IF;

              END IF;
            END IF;

            IF (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
                DBG('For rollover with P payout details should be null ');

                DBG('p_function_id' || P_FUNCTION_ID);
                DBG('gwpks_util.pkg_func' || GWPKS_UTIL.PKG_FUNC);
                IF P_FUNCTION_ID = 'STDCUSTD' OR
                   (GWPKS_UTIL.PKG_FUNC = 'TDMM') THEN

                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-0114', '');

                ELSIF P_FUNCTION_ID = 'IADCUSTD' OR
                      (GWPKS_UTIL.PKG_FUNC = 'IPTDMM') THEN
                  DBG('For Principal only auto rollover Payout details should not be entered if the Profit booking account is different from TD account');
                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IP-ACC-478', '');
                END IF;

                L_ERR_FLAG := -1;
              END IF;
            END IF;

          ELSIF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'I') THEN
            IF (P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) AND
               (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
              DBG('Rollover with principal + interest,book acc should be the TD account');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-218', '');
              L_ERR_FLAG := -1;
            ELSE
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
                DBG('for rollover with P+I payout details should be null ');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-213', '');

              END IF;
            END IF;
          ELSIF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'T') THEN
            IF (P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) AND
               (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
              DBG('Rollover with interest,book acc should be the TD account');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-218', '');
              L_ERR_FLAG := -1;
            ELSE
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT < 1 THEN
                DBG('For rollover with Interest payout details cannot be NULL ');

                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-525', '');

                L_ERR_FLAG := -1;
              END IF;
            END IF;
          ELSIF (P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'S') THEN
            IF (P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) AND
               (P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT < 1 THEN
                DBG('for rollover with Special amount payout details cannot be null ');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-205', '');
                L_ERR_FLAG := -1;

              ELSE
                L_PRINCIPAL_COUNT := 0;
                FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
                  IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
                   .PAYOUT_COMPONENT = 'P' THEN
                    L_PRINCIPAL_COUNT := L_PRINCIPAL_COUNT + 1;
                  END IF;
                END LOOP;

                IF L_PRINCIPAL_COUNT < 1 THEN

                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-525', '');

                  L_ERR_FLAG := -1;
                END IF;

              END IF;
            END IF;
          END IF;
        END IF;

        IF P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT IS NULL OR
           P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT <= 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-108', '');
          L_ERR_FLAG := -1;

        END IF;

        IF (NVL(P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE, 'x') = 'S') OR
           (P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE =
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN

          DBG('Selecting minimum and maximum amount from sttms_accls_minmax_amt_ccy');
          BEGIN
            SELECT NVL(MIN_AMOUNT, 0), NVL(MAX_AMOUNT, 0)
              INTO L_MIN_AMOUNT, L_MAX_AMOUNT
              FROM STTMS_ACCLS_MINMAX_AMT_CCY
             WHERE ACCOUNT_CLASS =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
               AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
            DBG('Selecting minimum amount : ' || L_MIN_AMOUNT);
            DBG('Selecting maximum amount : ' || L_MAX_AMOUNT);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                SELECT NVL(MIN_AMOUNT, 0), NVL(MAX_AMOUNT, 0)
                  INTO L_MIN_AMOUNT, L_MAX_AMOUNT
                  FROM STTMS_ACCLS_MINMAX_AMT_CCY
                 WHERE ACCOUNT_CLASS =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                   AND CCY = '*.*';
                DBG('Selecting minimum amount for ccy *.* : ' ||
                    L_MIN_AMOUNT);
                DBG('Selecting maximum amount for ccy *.* : ' ||
                    L_MAX_AMOUNT);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  L_MIN_AMOUNT := 0;
                  L_MAX_AMOUNT := 0;
                  DBG('Assigning Mininum and Maximum Amount has zero when it is not maintained');
              END;
            WHEN OTHERS THEN
              DBG('Min Max Amount not maintained for the account currency');
          END;

          DBG('Td_amount: ' || P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);
          DBG('l_min_amount: ' || L_MIN_AMOUNT);
          DBG('l_max_amount: ' || L_MAX_AMOUNT);
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE =
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
          IF L_MAX_AMOUNT = 0 THEN
            DBG('Max amount is not maintained..ovrride..');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-199', '');
          ELSIF P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT > L_MAX_AMOUNT THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-102', '');
            L_ERR_FLAG := -1;

          END IF;
          
          --Pro Savings Sampath Changes added AND Condition
          
          IF P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT < L_MIN_AMOUNT
            AND P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS NOT IN ('PS01','PS02','PS03','PS04') THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-101', '');
            L_ERR_FLAG := -1;
            L_ERR_CODE := 'ST-TD-101';

          END IF;
          
          
        END IF;

        DBG('Maturity_date: ' || P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        DBG('Int_start_date: ' || P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

      END IF;

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID := 7;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('L_ERR_FLAG') := L_ERR_FLAG;
        L_TB_CLUSTER_DATA('L_ERR_CODE') := L_ERR_CODE;
        DBG('i am going for number 7');
        IF NOT
            STPKS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                 P_STDCUSAC,
                                                                 P_ACTION_CODE,
                                                                 P_SOURCE,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
          DBG('error in stpks_stdcusac_utils_cluster.fn_deposit_def_validate');
          RETURN FALSE;
        END IF;

        IF L_TB_CLUSTER_DATA.EXISTS('L_ERR_FLAG') THEN
          L_ERR_FLAG := L_TB_CLUSTER_DATA('L_ERR_FLAG');
        END IF;

      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        DBG('l_date::' || L_DATE);
        DBG('p_stdcusac.v_ictms_acc.maturity_date::' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        DBG('l_min_days::' || L_MIN_DAYS);
        DBG('l_max_days::' || L_MAX_DAYS);
        DBG('Original tenor days::' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
        DBG('Original tenor months::' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);
        DBG('Original tenor years::' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);

        IF NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) = 0 THEN
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := L_DAYS;
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := L_MONTHS;
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := L_YEARS;
        END IF;

        L_MAT_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                 NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                     0) + NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                              0) * 12) +
                      NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0);

        DBG('l_mat_date::' || L_MAT_DATE);

        IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') OR
           GWPKS_UTIL.PKG_FUNC IN ('TDMM', 'IPTDMM') THEN

          IF (L_MAT_DATE < L_MIN_DAYS)

           THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-106', '');

          ELSIF (L_MAT_DATE > L_MAX_DAYS)

           THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-107', '');

          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE < L_MIN_DAYS THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-115', '');
          ELSIF (P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE > L_MAX_DAYS) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-116', '');
          END IF;

        ELSE

          IF (L_MAT_DATE < L_MIN_DAYS)

           THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC020', '');
            L_ERR_FLAG := -1;

          ELSIF (L_MAT_DATE > L_MAX_DAYS)

           THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC020', '');
            L_ERR_FLAG := -1;
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE < L_MIN_DAYS THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC033', '');
          ELSIF (P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE > L_MAX_DAYS) THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC033', '');
          END IF;

        END IF;

        L_MIN_DAYS := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                 L_MIN_TENOR_MONTHS + L_MIN_TENOR_YEARS * 12) +
                      L_MIN_TENOR_DAYS;
        L_MAX_DAYS := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                 L_MAX_TENOR_MONTHS + L_MAX_TENOR_YEARS * 12) +
                      L_MAX_TENOR_DAYS;
        DBG('l_max_tenor_days::' || L_MAX_TENOR_DAYS);
        DBG('l_max_tenor_months::' || L_MAX_TENOR_MONTHS);
        DBG('l_max_tenor_years::' || L_MAX_TENOR_YEARS);
        DBG('l_max_days::' || L_MAX_DAYS);
        DBG('l_min_days::' || L_MIN_DAYS);

        IF L_MAX_TENOR_DAYS = 0 AND L_MAX_TENOR_MONTHS = 0 AND
           L_MAX_TENOR_YEARS = 0 THEN
          L_MAX_DAYS := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE + 1;
        END IF;
        DBG('p_stdcusac.v_ictms_acc.next_maturity_date::' ||
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        DBG('pkg_cascade_nxtmatdt::' || PKG_CASCADE_NXTMATDT);
        IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') OR
           GWPKS_UTIL.PKG_FUNC IN ('TDMM', 'IPTDMM') THEN

          IF PKG_CASCADE_NXTMATDT = 'N' THEN
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                   L_MIN_DAYS + 1) < L_MIN_DAYS AND
               P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC019', '');
              L_ERR_FLAG := -1;
            ELSIF (NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                       L_MAX_DAYS - 1) > L_MAX_DAYS) AND
                  P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC019', '');
              L_ERR_FLAG := -1;
            END IF;

          ELSE
            DBG('INSIDE ELSE::');
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                   L_MIN_DAYS + 1) < L_MIN_DAYS AND
               P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              DBG('MIN DAYS VALIDATION');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC032', '');

            ELSIF (NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                       L_MAX_DAYS - 1) > L_MAX_DAYS) AND
                  P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              DBG('MAX DAYS VALIDATION');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC032', '');

            END IF;
          END IF;

        ELSE
          IF PKG_CASCADE_NXTMATDT = 'N' THEN
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                   L_MIN_DAYS + 1) < L_MIN_DAYS AND
               P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC021', '');
              L_ERR_FLAG := -1;
            ELSIF (NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                       L_MAX_DAYS - 1) > L_MAX_DAYS) AND
                  P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC021', '');
              L_ERR_FLAG := -1;
            END IF;

          ELSE
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                   L_MIN_DAYS + 1) < L_MIN_DAYS AND
               P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              DBG('MIN DAYS VALIDATION');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC034', '');

            ELSIF (NVL(P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE,
                       L_MAX_DAYS - 1) > L_MAX_DAYS) AND
                  P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
              DBG('MAX DAYS VALIDATION');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC034', '');

            END IF;
          END IF;

        END IF;

        PKG_CASCADE_NXTMATDT := 'N';

      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'Y' THEN

        IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
          IF NOT FN_PAYINOUT_VALIDATE(P_FUNCTION_ID,
                                      P_ACTION_CODE,
                                      P_STDCUSAC,
                                      L_ERR_FLAG) THEN
            DBG('failed in fn_payinout_validate');
            RETURN FALSE;
          END IF;
        END IF;

        DBG('Payout count :' || P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);

        IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT < 1 THEN
            DBG('payout option cannot be null ');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-205', '');
            L_ERR_FLAG := -1;
          ELSE
            L_PRINCIPAL_COUNT := 0;
            FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
              IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I)
               .PAYOUT_COMPONENT = 'P' THEN
                L_PRINCIPAL_COUNT := L_PRINCIPAL_COUNT + 1;
              END IF;
            END LOOP;

            IF L_PRINCIPAL_COUNT < 1 THEN

              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-525', '');

              L_ERR_FLAG := -1;
            END IF;
          END IF;
        END IF;
      END IF;

      BEGIN
        SELECT DUAL_CCY_DEPOSIT
          INTO L_DCD
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_DCD := 'N';
      END;
      IF L_DCD = 'Y' THEN

        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              STPKSS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                    P_STDCUSAC,
                                                                    P_ACTION_CODE,
                                                                    P_SOURCE,
                                                                    L_FN_CALL_ID,
                                                                    L_TB_CLUSTER_DATA) THEN
            DBG('error in    Stpkss_Stdcusac_Utils_cluster.fn_deposit_def_validate');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
            L_ERR_FLAG := -1;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN

          IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' OR
             P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
             P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' OR
             P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'N'

           THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-001', '');
            L_ERR_FLAG := -1;
          END IF;

          DBG('Payout paramaters count for DCD :' ||
              P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
          IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 1 THEN
              DBG('Payout paramaters cannot be greater than one for DCD');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-016', '');
              L_ERR_FLAG := -1;
            END IF;
            IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(1)
             .PAYOUTTYPE NOT IN ('S', 'G') THEN
              DBG('Payout paramaters can only be savings or Gl for DCD');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-017', '');
              L_ERR_FLAG := -1;
            END IF;
          END IF;

          IF P_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_SETT_ACC IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_GL IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.YLD_ENHANCEMENT IS NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.INCEPTION_FAIR_VALUE IS NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-002', '');
            L_ERR_FLAG := -1;
          END IF;

          BEGIN
            SELECT PRODUCT_TYPE
              INTO L_PRODUCT_TYPE
              FROM CSTMS_PRODUCT
             WHERE PRODUCT_CODE =
                   P_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD;
          EXCEPTION
            WHEN OTHERS THEN
              L_ERROR_CODE  := 'OT-UPL-299';
              L_ERROR_PARAM := '';
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR_CODE, '');
              RETURN FALSE;
          END;
          DBG('option product type: ' || L_PRODUCT_TYPE);

          BEGIN
            SELECT NORMAL_RATE_VARIANCE, MAXIMUM_RATE_VARIANCE
              INTO L_NORMAL_RATE_VARIANCE, L_MAXIMUM_RATE_VARIANCE
              FROM CSTMS_PRODUCT
             WHERE PRODUCT_CODE =
                   P_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;

          IF L_PRODUCT_TYPE = 'CO' THEN

            DBG('Get spot rate');

            IF NOT CYPKSS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                     P_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY,
                                     'STANDARD',
                                     'M',
                                     L_SPOT_RATE,
                                     L_RATE_FLAG,
                                     L_ERROR_CODE) THEN
              DBG('Failed in GETTING SPOT RATE');
            END IF;

            DBG('strike_price ' || P_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE);
            DBG('l_spot_rate ' || L_SPOT_RATE);

            L_CONTRACT_VARIANCE := ((P_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE -
                                   L_SPOT_RATE) / L_SPOT_RATE) * 100;
            DBG('l_contract_variance ' || L_CONTRACT_VARIANCE);
            DBG('l_maximum_rate_variance ' || L_MAXIMUM_RATE_VARIANCE);
            DBG('l_normal_rate_variance ' || L_NORMAL_RATE_VARIANCE);
            IF NOT
                OTPKSS_UPLOAD_VALIDATE.FN_VALIDATE_CONTRACT_VARIANCE(L_CONTRACT_VARIANCE,
                                                                     L_MAXIMUM_RATE_VARIANCE,
                                                                     L_NORMAL_RATE_VARIANCE,
                                                                     L_ERROR_CODE,
                                                                     L_ERROR_PARAM) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR_CODE, '');
            END IF;

            SELECT P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                   P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS
              INTO L_FIXING_DATE
              FROM DUAL;
            DBG('fixing date is ' || L_FIXING_DATE);
            DBG('deposit tenor ==> ' || L_DFLT_TENOR);
            IF P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS < 0 OR
               P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS > L_DFLT_TENOR THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-003', '');
              L_ERR_FLAG := -1;

            ELSE
              L_ORGNAL_DATE := L_FIXING_DATE;
              WHILE NOT L_FOUND_WORKING_DATE LOOP
                L_RETURN := CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                                     P_STDCUSAC.V_ICTMS_DCD_MASTER.TD_BRN,
                                                     L_FIXING_DATE,
                                                     L_RESULT);
                IF L_RESULT = 'H' THEN
                  L_WORKING_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                                 P_STDCUSAC.V_ICTMS_DCD_MASTER.TD_BRN,
                                                                 L_FIXING_DATE,
                                                                 'P',
                                                                 1);
                END IF;
                L_RETURN := CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                                     P_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY,
                                                     L_FIXING_DATE,
                                                     L_RESULT);
                IF L_RESULT = 'H' THEN
                  L_WORKING_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('CCY',
                                                                 P_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY,
                                                                 L_WORKING_DATE,
                                                                 'P',
                                                                 1);
                END IF;
                L_RETURN := CEPKSS_DATE.FN_ISHOLIDAY('CCY',
                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                     L_FIXING_DATE,
                                                     L_RESULT);
                IF L_RESULT = 'H' THEN
                  L_WORKING_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('CCY',
                                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                                 L_WORKING_DATE,
                                                                 'P',
                                                                 1);
                END IF;

                IF L_FIXING_DATE = L_WORKING_DATE OR L_WORKING_DATE IS NULL THEN
                  DBG('l_fixing_date  ' || L_FIXING_DATE || ' = ' ||
                      '  l_working_date ' || L_WORKING_DATE);
                  L_FOUND_WORKING_DATE := TRUE;
                ELSE
                  DBG('l_fixing_date  ' || L_FIXING_DATE || ' <>' ||
                      '  l_working_date ' || L_WORKING_DATE);
                  L_FIXING_DATE        := L_WORKING_DATE;
                  L_FOUND_WORKING_DATE := FALSE;

                END IF;

              END LOOP;
              IF L_ORGNAL_DATE <> L_FIXING_DATE THEN
                DBG('l_fixing_date  ' || L_FIXING_DATE || '***' ||
                    '  int_start_date ' ||
                    P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

                IF TO_DATE(L_FIXING_DATE, 'DD-MON-RRRR') <=
                   TO_DATE(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                           'DD-MON-RRRR') THEN
                  P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS := 0;
                  DBG(' FIXING_DAYS  ' ||
                      P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS);

                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-109', '');
                ELSE
                  DBG('l_fixing_date  ' || L_FIXING_DATE || '***' ||
                      '  maturity_date ' ||
                      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
                  P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                               L_FIXING_DATE;
                  DBG(' FIXING_DAYS  ' ||
                      P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS);

                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-109', '');
                END IF;
              END IF;
            END IF;
            IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO THEN
              DBG('failed:for dcd case: interest booking account must be same as TD account');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-006', '');
            END IF;
          END IF;

        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;

      ELSE

        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          IF NOT
              STPKSS_STDCUSAC_UTILS_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                    P_STDCUSAC,
                                                                    P_ACTION_CODE,
                                                                    P_SOURCE,
                                                                    L_FN_CALL_ID,
                                                                    L_TB_CLUSTER_DATA) THEN
            DBG('error in    Stpkss_Stdcusac_Utils_cluster.fn_deposit_def_validate');
            L_ERR_FLAG := -1;
          END IF;
        END IF;
        IF NOT GLOBAL.G_SKIP_KERNEL THEN

          IF P_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_SETT_ACC IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_GL IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.YLD_ENHANCEMENT IS NOT NULL OR
             P_STDCUSAC.V_ICTMS_DCD_MASTER.INCEPTION_FAIR_VALUE IS NOT NULL THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-005', '');
            L_ERR_FLAG := -1;
          END IF;

        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;

      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
        P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE := 'P';
      END IF;
      DBG(' p_stdcusac.v_ictms_acc.rollover_type ' ||
          P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);

      IF L_ERR_FLAG <> 0 THEN
        DBG('fn_validate_deposits returning false');
        RETURN FALSE;

      END IF;

    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      DBG('## calling stpks_stdcusac_utils_cluster.fn_deposit_def_validate...');

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                                                 P_STDCUSAC,
                                                                 P_ACTION_CODE,
                                                                 P_SOURCE,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_stdcusac_utils_cluster.fn_deposit_def_validate-');

        RETURN FALSE;
      END IF;
      DBG('## success for stpks_stdcusac_utils_cluster.fn_deposit_def_validate...');
    END IF;

    DBG('fn_deposit_def_validate returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_deposit_def_validate with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_DEPOSIT_DEF_VALIDATE;

  FUNCTION FN_VALIDATE_INT_START_DATE(P_FUNCTION_ID IN VARCHAR2,
                                      P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_validate_int_start_date');

    IF P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE IS NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
      DBG('Int Start Date Defaulted: ' ||
          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
    END IF;

    IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN
      P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
      DBG('Int Start Date Defaulted for Payin by Cheque: ' ||
          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
    END IF;

    IF P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE <
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
      DBG('int_start_date  is less than. ac_open_date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS102', '');
      RETURN FALSE;
    END IF;

    DBG('Int Start Date Returned: ' ||
        P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

    DBG('fn_validate_int_start_date returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_int_start_date with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_VALIDATE_INT_START_DATE;

  FUNCTION FN_VALIDATE_CHG_START_DATE(P_FUNCTION_ID IN VARCHAR2,
                                      P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS

    L_RESPONSE VARCHAR2(1000);
    L_RETURN   BOOLEAN;
  BEGIN
    DBG('Inside fn_validate_chg_start_date');

    IF P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE IS NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
      DBG('Charge start Date: ' || P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE);
    ELSE

      IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' THEN
        P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
        DBG('Int Start Date Defaulted for Payin by Cheque: ' ||
            P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE);
      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE <
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
        DBG('Charge start date  is less than. ac_open_date');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS103', '');
        RETURN FALSE;
      END IF;

      L_RETURN := CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                           P_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE,
                                           L_RESPONSE);
      IF L_RESPONSE = 'H' THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-0016', '');

      END IF;
    END IF;

    DBG('fn_validate_chg_start_date returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_chg_start_date with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_VALIDATE_CHG_START_DATE;

  FUNCTION FN_VALIDATE_PROD(P_FUNCTION_ID   IN VARCHAR2,
                            P_PRD_INDEX     IN VARCHAR2,
                            P_CUST_AC_NO    IN VARCHAR2,
                            P_ACCOUNT_CLASS IN VARCHAR2,
                            P_CCY           IN VARCHAR2,
                            P_BRANCH_CODE   IN VARCHAR2) RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN
    DBG('Inside fn_validate_prod');

    DBG('here ' || P_CUST_AC_NO || P_ACCOUNT_CLASS);
    IF STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
      DBG(' lov is validated in screen level-');
      RETURN TRUE;
    END IF;

    DBG('LOV Validation');
    SELECT COUNT(*)
      INTO L_COUNT
      FROM ICTMS_PR_INT_ACLASS      P,
           ICTMS_PRODUCT_DEFINITION D,
           CSTM_PRODUCT             C
     WHERE P.PRODUCT_CODE = P_PRD_INDEX
       AND P.ACLASS = P_ACCOUNT_CLASS
       AND P.CCY = P_CCY
       AND P.RECORD_STAT = 'N'
       AND P.PRODUCT_CODE = D.PRODUCT_CODE
       AND D.PRODUCT_TYPE IN ('I', 'P')
       AND C.PRODUCT_CODE = P.PRODUCT_CODE
       AND C.RECORD_STAT = 'O'
       AND P.PRODUCT_CODE IN
           (SELECT PRODUCT_CODE
              FROM CSVW_PRODUCT_BRANCHES
             WHERE BRANCH_CODE = P_BRANCH_CODE)
       AND C.AUTH_STAT = 'A';
    IF L_COUNT = 0 THEN
      DBG('LOV Validation Failed For Product');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'IF-TXN011',
                   '@ICTMS_ACC_PR.PROD ' || P_PRD_INDEX || '~');
      RETURN FALSE;
    END IF;

    DBG('fn_validate_prod returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_prod with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_VALIDATE_PROD;

  FUNCTION FN_VALIDATE_IC_ACCOUNT(P_FUNCTION_ID IN VARCHAR2,
                                  P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_RATE_CD     ICTMS_ACC_UDEVALS.RATE_CODE%TYPE;
    L_UDEID_INDEX ICTMS_ACC_UDEVALS.UDE_ID%TYPE;
    L_EFFDT_INDEX VARCHAR2(35);
    L_COUNT       NUMBER;

    L_TRADELIC_COUNT NUMBER;
    L_MASTER_ACC_CNT NUMBER;

    L_MASTER_ACC STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_MASTER_CCY STTMS_CUST_ACCOUNT.CCY%TYPE;

    L_COUNT1 NUMBER;

    L_ACC_CNT    NUMBER;
    L_PAY_METHOD VARCHAR2(1);
    L_ERR_PARAMS VARCHAR2(32767) := CSPKS_REQ_WRAPPER.G_ERR_PARAMS;
    L_RULE_ID    ICTM_RULE_UDE.RULE_ID%TYPE;
    L_UDE_TYPE   ICTM_RULE_UDE.UDE_TYPE%TYPE;

  BEGIN
    DBG('Inside fn_validate_ic_account');

    IF P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC IS NULL THEN
      DBG('here for defaulting');
      P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      DBG('Charge_book_acc: ' || P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC);
    END IF;

    DBG('validating Calculation A/c: ' || P_STDCUSAC.V_ICTMS_ACC.CALC_ACC);
    IF P_STDCUSAC.V_ICTMS_ACC.CALC_ACC IS NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.CALC_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    END IF;

    DBG('validating booking A/c: ' || P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC);
    IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC IS NULL THEN
      P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    END IF;
    DBG('cust_ac_no: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC IS NULL THEN
      DBG('Booking Account Not Valid.');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-MAN01',
                   '@ICTMS_ACC.BOOK_ACC~');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC IS NULL THEN
      DBG('Charge Booking Account Not Valid.');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-MAN01',
                   '@ICTMS_ACC.CHARGE_BOOK_ACC~');
      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.V_ICTMS_ACC.CALC_ACC IS NULL THEN
      DBG('Calculation Account Not Valid.');
      PR_LOG_ERROR(P_FUNCTION_ID,
                   'FLEXCUBE',
                   'ST-MAN01',
                   '@ICTMS_ACC.CALC_ACC~');
      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
       P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC IS NOT NULL THEN
      DBG('Thru...1');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC
         AND BRANCH_CODE = P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN
         AND RECORD_STAT = 'O'
         AND ACCOUNT_TYPE <> 'Y';
      DBG('l_count1: ' || L_COUNT);
      IF L_COUNT = 0 THEN

        DBG('Checking for GL accounts..');
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC
             AND AC_OR_GL = 'G'
             AND AC_GL_REC_STATUS = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Inside exception..' || SQLERRM);
            L_COUNT := 0;
        END;
        DBG('l_count2: ' || L_COUNT);
        IF L_COUNT = 0 THEN

          DBG('2: Booking Account Not Valid.');

          IF P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC = 'DUMMY' THEN
            DBG('DUMMY NO CHANGED!');
            P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          ELSE

            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CAC99', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

    END IF;

    DBG('Charge booking a/c');
    IF P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
       P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC IS NOT NULL THEN
      DBG('validating charge booking A/c: ' ||
          P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC);
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC
         AND BRANCH_CODE = P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN
         AND RECORD_STAT = 'O'
         AND ACCOUNT_TYPE <> 'Y';
      IF L_COUNT = 0 THEN

        DBG('Checking for GL accounts1..');
        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM STTBS_ACCOUNT
           WHERE AC_GL_NO = P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC
             AND AC_OR_GL = 'G'
             AND AC_GL_REC_STATUS = 'O'
             AND AUTH_STAT = 'A';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Inside exception..' || SQLERRM);
            L_COUNT := 0;
        END;
        DBG('l_count2: ' || L_COUNT);
        IF L_COUNT = 0 THEN

          IF P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC = 'DUMMY' THEN
            DBG('DUMMY NO CHANGED!');
            P_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            IF P_STDCUSAC.V_ICTMS_ACC.CALC_ACC = 'DUMMY' THEN
              P_STDCUSAC.V_ICTMS_ACC.CALC_ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            END IF;
          ELSE

            DBG('Charge Booking Account Not Valid.');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CAC99', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

    END IF;

    DBG('validating booking Branch: ' || P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN);

    IF P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE AND
       P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN IS NOT NULL THEN
      DBG('validating interest booking branch');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_ICTMS_ACC.BOOK_ACC
         AND BRANCH_CODE = P_STDCUSAC.V_ICTMS_ACC.BOOK_BRN;
      DBG('l_count1: ' || L_COUNT);
      IF L_COUNT = 0 THEN
        DBG('2: Booking Branch Not Valid.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CAB99', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC IS NOT NULL THEN

      BEGIN
        DBG('Before Selecting Count for the Customer Number ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO || 'Account Number ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC);
        DBG('Branch ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        DBG('Account Currency ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
        SELECT COUNT(1)
          INTO L_ACC_CNT
          FROM STTM_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC
           AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
           AND CONSOL_CHG_ACC IS NULL;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found ...so this is assumed as master account');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CHGAC1', '');
          RETURN FALSE;
      END;

      DBG('Account Count ' || L_ACC_CNT);

      IF L_ACC_CNT = 0 THEN
        DBG('For child accounts consolidated chg account should be same as master account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CHGAC2', '');
        RETURN FALSE;
      END IF;

    END IF;

    SELECT COUNT(*)
      INTO L_COUNT1
      FROM STTBS_TRANSFERRED_ACCOUNT S
     WHERE S.CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
       AND S.BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    DBG('l_count1 -->' || L_COUNT1);

    IF L_COUNT1 = 0 THEN
      DBG('Validating the start dates');
      DBG('Int st dt');
      IF NOT FN_VALIDATE_INT_START_DATE(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_int_start_date has returned false');
        RETURN FALSE;
      END IF;
      DBG('Chg st dt');
      IF NOT FN_VALIDATE_CHG_START_DATE(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_validate_chg_start_date has returned false');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Acc prd count: ' || P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
    IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
      DBG('Validating the products attached');
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
        DBG('Prod: ' || P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
        IF P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD IS NOT NULL

         THEN
          IF NVL(P_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT, 'N') = 'O' THEN
            IF NOT
                FN_VALIDATE_PROD(P_FUNCTION_ID,
                                 P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD,
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
              DBG('fn_validate_prod has returned false');
              RETURN FALSE;
            END IF;
          END IF;
          IF P_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT IS NULL THEN
            P_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT := 'O';
          END IF;
          P_STDCUSAC.V_ICTMS_ACC_PR(I).ONCE_AUTH := 'Y';
        ELSE
          IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT = 1 THEN
            DBG('The product is null... but the count is present... so deleting the table');
            P_STDCUSAC.V_ICTMS_ACC_PR.DELETE;
          END IF;
        END IF;
      END LOOP;
    END IF;

    DBG('Acc effdt count: ' || P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
    IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
      DBG('Defaulting Effdt details');
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP

        P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ONCE_AUTH := 'Y';
      END LOOP;
    END IF;

    DBG('UDE vals count: ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
    IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
      DBG('Defaulting UDE val details');
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT LOOP

        SELECT RULE
          INTO L_RULE_ID
          FROM ICTMS_PR_INT
         WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).PROD;

        SELECT UDE_TYPE
          INTO L_UDE_TYPE
          FROM ICTMS_RULE_UDE
         WHERE RULE_ID = L_RULE_ID
           AND UDE_ID = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID;

        IF L_UDE_TYPE = 'A' AND P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I)
          .RATE_CODE IS NOT NULL THEN
          DBG('here for ude type check');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-806',
                       P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_ID);
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VALUE = NULL THEN
          P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).UDE_VALUE := 0;
        END IF;

        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).AUTH_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT,
                                                           'U');
        P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RECORD_STAT := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT,
                                                             'O');

      END LOOP;
    END IF;

    DBG('Validation for trade license is maintained for a customer then multiple master accounts cannot exists');
    DBG('Value of Master Accc : ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC);
    DBG('Value of Customer No : ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC IS NOT NULL THEN

      SELECT COUNT(*)
        INTO L_TRADELIC_COUNT
        FROM LCTMS_CUST_EXPDATE
       WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      DBG('Trade License exist for the customer : ' || L_TRADELIC_COUNT);

      IF L_TRADELIC_COUNT <> 0 THEN
        DBG('Trade License has been maintained for the customer : ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

        BEGIN
          SELECT DISTINCT CONSOL_CHG_ACC
            INTO L_MASTER_ACC
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
             AND CONSOL_CHG_ACC IS NOT NULL;

          DBG('Master Account which is already maintained for the customer is : ' ||
              L_MASTER_ACC);
          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC <> L_MASTER_ACC THEN
            DBG('There should be maximum of one mater account can happen for the customer if it has trade license');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'CS-CIFTL-07', '');
            RETURN FALSE;
          END IF;
          DBG('Same Master account exists...So proceed');

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('This is the First Master Account. SO proceed');
            NULL;
          WHEN OTHERS THEN
            DBG('Others Exception : ' || SQLERRM);
            NULL;
        END;

      END IF;
    END IF;

    IF NVL(P_STDCUSAC.V_ICTMS_ACC_PR.COUNT, 0) > 0 THEN
      FOR J IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
        DBG('here the attached product code is ..' || P_STDCUSAC.V_ICTMS_ACC_PR(J).PROD);

        BEGIN
          SELECT PAYMENT_METHOD
            INTO L_PAY_METHOD
            FROM ICTM_PR_INT
           WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(J).PROD;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Bombed in selecting Product' || SQLERRM);
            RETURN FALSE;
        END;
        DBG('here the payment method is..' || L_PAY_METHOD);
        DBG('here the rollovertype is..' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE);
        IF L_PAY_METHOD = 'D' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE != 'P' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-01', '');
            RETURN FALSE;
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'TD-DDEP-03', '');
            RETURN FALSE;
          END IF;

        END IF;
      END LOOP;

    END IF;

    DBG('fn_validate_ic_account returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_ic_account with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_VALIDATE_IC_ACCOUNT;

  FUNCTION FN_UPLOAD_IC_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ACTION_CODE IN VARCHAR2,
                                P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS

    CURSOR CR_UDEVALS(P_PROD       IN VARCHAR2,
                      P_UDE_EFF_DT DATE,
                      P_BRANCH     VARCHAR2) IS
      SELECT DISTINCT UDE_ID
        FROM ICTMS_PR_INT_UDEVALS U, ICTM_PR_INT_EFFDT E
       WHERE U.BRANCH_CODE = P_BRANCH
         AND U.ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
         AND U.CCY_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
         AND U.PRODUCT_CODE = P_PROD
         AND U.UDE_EFF_DT =
             (SELECT MAX(U1.UDE_EFF_DT)
                FROM ICTMS_PR_INT_UDEVALS U1
               WHERE U1.BRANCH_CODE = U.BRANCH_CODE
                 AND U1.ACLASS = U.ACLASS
                 AND U1.CCY_CODE = U.CCY_CODE
                 AND U1.PRODUCT_CODE = U.PRODUCT_CODE
                 AND U1.UDE_EFF_DT <= P_UDE_EFF_DT)
         AND U.BRANCH_CODE = E.BRANCH_CODE
         AND U.ACLASS = E.ACLASS
         AND U.CCY_CODE = E.CCY_CODE
         AND U.PRODUCT_CODE = E.PRODUCT_CODE
         AND E.RECORD_STAT = 'O'
         AND E.AUTH_STAT = 'A';

    L_ACCOUNT_TYPE      STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ROLLOVER_TYPE     STTMS_ACCOUNT_CLASS.AUTO_ROLLOVER%TYPE;
    L_CLOSE_ON_MATURITY STTMS_ACCOUNT_CLASS.CLOSE_ON_MATURITY%TYPE;
    L_INT_UNCLAIMED     STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_PRINC_UNCLAIMED   STTMS_ACCOUNT_CLASS.MOVE_PRIC_TO_UNCLAIMED%TYPE;
    L_MAT_UNCLAIMED     STTMS_ACCOUNT_CLASS.MOVE_INT_TO_UNCLAIMED%TYPE;
    L_MOVE_FUNDS_ON_OVD STTMS_ACCOUNT_CLASS.RD_MOVE_FUNDS_ON_OVD%TYPE;
    L_DAYS              STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS%TYPE;
    L_MONTHS            STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS%TYPE;
    L_YEARS             STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS%TYPE;
    L_RD                STTMS_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_TDAYS             STTMS_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE;
    L_TMONTHS           STTMS_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE;
    L_TYEARS            STTMS_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE;
    L_FREE_BANKING_DAYS STTMS_ACCOUNT_CLASS.FREE_BANKING_DAYS%TYPE;
    L_DRCR_ADV          STTMS_ACCOUNT_CLASS.HAS_DRCR_ADV%TYPE;
    L_AC_CLASS_TYPE     STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_PRD_INDEX         ICTMS_ACC_PR.PROD%TYPE;
    L_UDEID_INDEX       ICTMS_ACC_UDEVALS.UDE_ID%TYPE;
    IDX                 VARCHAR2(255);
    L_EFFDT_INDEX       VARCHAR2(35);
    L_UDE_EFF_DT        VARCHAR2(15);
    L_UDE_CCY           VARCHAR2(3);
    L_BRN               VARCHAR2(3);
    L_DATE              DATE;
    L_NEXT_DATE         DATE;
    L_COUNT             NUMBER;
    L_CNTR              NUMBER;

    L_DCD        CHAR(1);
    L_LIQ_DAYS   ICTMS_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS ICTMS_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YRS    ICTMS_PR_INT.LIQN_YEARS%TYPE;

    L_PROD_START_DT CSTM_PRODUCT.PRODUCT_START_DATE%TYPE;

    TYPE TY_ICTMS_ACC_EFFDT IS TABLE OF ICTMS_ACC_EFFDT%ROWTYPE INDEX BY BINARY_INTEGER;
    L_ACC_EFFDT   TY_ICTMS_ACC_EFFDT;
    L_EFF_DT_FLAG NUMBER;
    L_CNTR1       NUMBER;
    L_PRD_INDEX1  ICTMS_ACC_PR.PROD%TYPE;
    L_EFFDT_INDEX VARCHAR2(35);
    TYPE TY_ICTM_ACC_PR IS TABLE OF ICTM_ACC_PR%ROWTYPE INDEX BY BINARY_INTEGER;
    L_PROD         TY_ICTM_ACC_PR;
    L_PRD_MOD_FLAG NUMBER;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_CUST_CATEGORY STTM_CUSTOMER.CUSTOMER_CATEGORY%TYPE;
  BEGIN
    DBG('Inside fn_upload_ic_details' ||
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
    IF P_ACTION_CODE NOT IN ('TDCompute', 'COMPUTE') THEN
      BEGIN
        SELECT AC_CLASS_TYPE
          INTO L_AC_CLASS_TYPE
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
           AND AUTH_STAT = 'A'
           AND RECORD_STAT = 'O';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed To Select Account Type from Account Class table : ' ||
              SQLERRM);
          DBG('Record may not be authorised or not open');
          RETURN FALSE;
      END;
      DBG('l_ac_class_type: ' || L_AC_CLASS_TYPE);

      L_COUNT := 0;
      IF L_AC_CLASS_TYPE = 'Y' THEN
        IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
          FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
            DBG('Prod: ' || P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
            IF P_STDCUSAC.V_ICTMS_ACC_PR(I).WAIVE = 'N' THEN
              L_COUNT := L_COUNT + 1;
            END IF;
            IF L_COUNT > 1 THEN
              DBG('no. of PRODUCT USED  :' || L_COUNT);
              DBG('Failed:More than one product is not allowed for TD account');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD099', '');
              RETURN FALSE;
            END IF;

            DBG('p_action_code :' || P_ACTION_CODE);
            IF P_ACTION_CODE IN ('NEW') THEN
              BEGIN
                SELECT PRODUCT_START_DATE
                  INTO L_PROD_START_DT
                  FROM CSTMS_PRODUCT
                 WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  L_PROD_START_DT := '';
              END;
              DBG('p_stdcusac.v_ictms_acc.int_start_date:' ||
                  P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
              DBG('l_prod_start_dt :' || L_PROD_START_DT);
              IF P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE < L_PROD_START_DT THEN
                DBG('Override: interest Start date is less that the Start date of the product');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'ST-TD-120',
                             P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
              END IF;
            END IF;

            BEGIN
              SELECT DUAL_CCY_DEPOSIT
                INTO L_DCD
                FROM STTMS_ACCOUNT_CLASS
               WHERE ACCOUNT_CLASS =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_DCD := 'N';
            END;
            IF L_DCD = 'Y' THEN
              BEGIN
                SELECT LIQN_DAYS, LIQN_MONTHS, LIQN_YEARS
                  INTO L_LIQ_DAYS, L_LIQ_MONTHS, L_LIQ_YRS
                  FROM ICTMS_PR_INT
                 WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD;
              EXCEPTION
                WHEN OTHERS THEN
                  L_LIQ_DAYS   := 0;
                  L_LIQ_MONTHS := 0;
                  L_LIQ_YRS    := 0;
              END;
              IF L_LIQ_DAYS <> 0 OR L_LIQ_MONTHS <> 0 OR L_LIQ_YRS <> 0 THEN
                DBG('Failed:cannot link ic product which has liquidation freq maintained to DCD account');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-BOD100',
                             P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
                RETURN FALSE;
              END IF;
            END IF;

          END LOOP;
        END IF;

        DBG('Account class is of Deposit....Validateing TD Detials..');
        IF NOT FN_DEPOSIT_DEF_VALIDATE(P_FUNCTION_ID,
                                       P_STDCUSAC,
                                       P_ACTION_CODE,
                                       P_SOURCE) THEN
          DBG('fn_deposit_def_validate has returned false');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' AND
           P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          DBG('Close in maturity and Auto Rollover both cannot be set to Y.Quiting');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-128', '');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
           P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y' AND
           P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE <> 'T' THEN
          DBG('When Auto Rollover is set, Move principal to unclaimed cannot be set ');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-129', '');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC.RD_FLAG = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.CALC_ACC <> P_STDCUSAC.V_ICTMS_ACC.ACC THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD017', '');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      IF P_ACTION_CODE IN ('MODIFY') THEN

        IF (NVL(CSPKS_REQ_GLOBAL.G_HEADER('SOURCE_OPERATION'), 'XX') NOT IN
           ('ModifyCustAccAclas')) THEN

          BEGIN
            SELECT CUSTOMER_CATEGORY
              INTO L_CUST_CATEGORY
              FROM STTM_CUSTOMER
             WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('No data found');
          END;

          FOR L_PROD IN (SELECT A.PROD
                           FROM ICTMS_ACC_PR A, ICTMS_PRODUCT_DEFINITION B
                          WHERE A.ACC =
                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO

                            AND B.PRODUCT_TYPE = 'I'
                            AND A.PROD = B.PRODUCT_CODE

                            AND A.BRN =
                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE

                            AND A.PROD NOT IN
                                (SELECT PRODUCT_CODE
                                   FROM CSTMS_PRODUCT
                                  WHERE CATEGORIES_LIST = 'D'
                                    AND PRODUCT_CODE IN
                                        (SELECT PRODUCT_CODE
                                           FROM CSTMS_PRD_CAT_DISALLOW
                                          WHERE CATEGORY_DISALLOW =
                                                L_CUST_CATEGORY))

                         ) LOOP

            L_PRD_MOD_FLAG := 0;

            DBG('its in product validation');
            DBG('Product is ' || L_PROD.PROD);
            IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
              FOR L_PROD_INDEX IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
                IF L_PROD.PROD = P_STDCUSAC.V_ICTMS_ACC_PR(L_PROD_INDEX).PROD THEN
                  L_PRD_MOD_FLAG := 1;
                  EXIT;
                END IF;
              END LOOP;
            END IF;
            IF L_PRD_MOD_FLAG = 0 THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-621', '');

            END IF;

          END LOOP;
          DBG('l_prd_mod_flag--' || L_PRD_MOD_FLAG);
          IF L_AC_CLASS_TYPE = 'Y' AND P_STDCUSAC.V_ICTMS_ACC_PR.COUNT = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-621', '');
          END IF;

          DBG('l_prd_index1 ' || L_PRD_INDEX1);
          DBG('p_stdcusac.v_Ictms_Acc_Pr.count' ||
              P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
          IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
            FOR L_PRD_INDEX1 IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP

              FOR L_ACC_EFFDT IN (SELECT A.*
                                    FROM ICTMS_ACC_EFFDT A
                                   WHERE A.ACC =
                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                                     AND A.BRN =
                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                                     AND A.ONCE_AUTH = 'Y'
                                     AND A.PROD = P_STDCUSAC.V_ICTMS_ACC_PR(L_PRD_INDEX1).PROD) LOOP
                L_EFF_DT_FLAG := 0;
                DBG('l_acc_effdt(l_index).acc' || L_ACC_EFFDT.ACC);
                DBG('l_acc_effdt(l_index).ude_eff_dt' ||
                    L_ACC_EFFDT.UDE_EFF_DT);

                IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
                  DBG('1');
                  DBG('p_stdcusac.v_ictms_acc_effdt.FIRST' ||
                      P_STDCUSAC.V_ICTMS_ACC_EFFDT.FIRST);
                  FOR L_EFFDT_INDEX IN P_STDCUSAC.V_ICTMS_ACC_EFFDT.FIRST .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.LAST LOOP
                    IF L_ACC_EFFDT.UDE_EFF_DT = P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_EFFDT_INDEX)
                      .UDE_EFF_DT THEN
                      L_EFF_DT_FLAG := 1;
                      DBG('true for date' || P_STDCUSAC.V_ICTMS_ACC_EFFDT(L_EFFDT_INDEX)
                          .UDE_EFF_DT);
                      EXIT;
                    END IF;
                  END LOOP;
                END IF;

                IF L_EFF_DT_FLAG = 0 THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               'ST-ACC-620',
                               L_ACC_EFFDT.UDE_EFF_DT || '~' || P_STDCUSAC.V_ICTMS_ACC_PR(L_PRD_INDEX1).PROD);

                END IF;

              END LOOP;
            END LOOP;

          END IF;
        END IF;
      END IF;

      DBG('Validating the IC account');

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

        DBG('## calling stpks_stdcusac_utils_1_cluster.fn_upload_ic_details...');
        IF NOT
            STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_UPLOAD_IC_DETAILS(P_FUNCTION_ID,
                                                                P_STDCUSAC,
                                                                P_ACTION_CODE,
                                                                P_SOURCE,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
          DBG('## Failed in stpks_stdcusac_utils_1_cluster.fn_upload_ic_details');
          RETURN FALSE;
        END IF;
        DBG('## success for stpks_stdcusac_utils_1_cluster.fn_upload_ic_details...');
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
        DBG('## kernel part');

        IF NOT FN_VALIDATE_IC_ACCOUNT(P_FUNCTION_ID, P_STDCUSAC) THEN
          DBG('fn_validate_ic_account has returned false');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 AND
           P_ACTION_CODE IN ('NEW') THEN
          DBG('Bug_27312515');
          FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
            DBG('Bug_27312515 Effdt: ' || P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                .UDE_EFF_DT);
            IF P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
             .UDE_EFF_DT < GLOBAL.APPLICATION_DATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-231',
                           P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT);
            END IF;
          END LOOP;
        END IF;

        DBG('gwpks_util.pkg_actType is>> ' || GWPKS_UTIL.PKG_ACTTYPE ||
            'and source is >> ' || P_SOURCE);

        IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 AND
           ((P_ACTION_CODE IN ('NEW', 'MODIFY') AND
           NVL(P_SOURCE, '**') <> 'FLEXBRANCH') OR
           (GWPKS_UTIL.PKG_ACTTYPE = 'SAVEAUTOAUTH'))

         THEN
          DBG('Checking Effective date with account opening date');
          DBG('Account open date is ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

          FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
            DBG('Bug_28169205 Effective date :' || P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                .UDE_EFF_DT);
            IF P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
             .UDE_EFF_DT < P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-622',
                           P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).UDE_EFF_DT);
            END IF;
          END LOOP;
        END IF;

      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;

    END IF;
    DBG('fn_upload_ic_details returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_ic_details with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_IC_DETAILS;

  FUNCTION FN_UPLOAD_AUTO_DEP_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                      P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_AC_CLASS         STTBS_ACCOUNT.AC_CLASS%TYPE;
    L_CUST_NO          STTBS_ACCOUNT.CUST_NO%TYPE;
    L_AC_GL_CCY        STTBS_ACCOUNT.AC_GL_CCY%TYPE;
    L_SEQ_NO           NUMBER;
    L_CNT              NUMBER;
    L_SWEEP_BRANCH     STTM_BRANCH.BRANCH_CODE%TYPE;
    L_DEPOSIT_CCY      CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_SWEEP_TO_ACCOUNT STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_COUNT            NUMBER(4);

    L_DATE_STAMP STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                        GLOBAL.GET_NLS_DT_FORMAT) ||
                                                               TO_CHAR(FN_SYSDATE,
                                                                        'HH24:MI:SS')),
                                                               GLOBAL.GET_NLS_DT_FORMAT ||
                                                               ' HH24:MI:SS');

    L_AUTO_DEP_AC_CLASS STTMS_ACCOUNT_CLASS.AUTO_DEP_AC_CLASS%TYPE;

    L_TENOR ICTB_DEPOSIT_INSTRUCTION.DEP_TENOR_YEARS%TYPE;

    L_ERROR_FLAG NUMBER;
  BEGIN
    DBG('Inside fn_Upload_auto_dep_details');
    DBG('Acc: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO);

    SELECT AUTO_DEP_AC_CLASS
      INTO L_AUTO_DEP_AC_CLASS
      FROM STTMS_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';

    IF L_AUTO_DEP_AC_CLASS IS NULL THEN
      DBG('No Auto Deposit Account Class has been mapped');
      DBG('Returning simply true...');
      RETURN TRUE;
    END IF;

    DBG('Deposit account class, before validating is ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACLASS);
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACLASS IS NULL THEN
      DBG('Account class is null so, skipping the validation');
      RETURN TRUE;
    END IF;

    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO IS NULL THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR01', '');
      RETURN FALSE;
    END IF;

    L_AC_CLASS  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    L_CUST_NO   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    L_AC_GL_CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    BEGIN
      SELECT NVL(MAX(SEQ_NO), 0)
        INTO L_SEQ_NO
        FROM ICTBS_DEPOSIT_INSTRUCTION
       WHERE ACCOUNT_NO =
             P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO
         AND BRANCH_CODE =
             P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.BRANCH_CODE
         AND DEPOSIT_CCY =
             P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.CCY;
      L_SEQ_NO := L_SEQ_NO + 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_SEQ_NO := 1;
    END;
    DBG('Sweep_to_acc_branch: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACC_BRANCH);
    BEGIN
      SELECT BRANCH_CODE
        INTO L_SWEEP_BRANCH
        FROM STTMS_BRANCH
       WHERE BRANCH_CODE =
             P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACC_BRANCH
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Invalid Sweep Branch Code  specified :  ' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'GW-ACUP001',
                     NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACC_BRANCH,
                         ' ') || '~');

        L_ERROR_FLAG := -1;
    END;

    IF P_FUNCTION_ID = 'IADCUSAC' THEN
      P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEPOSIT_CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    END IF;

    BEGIN
      SELECT CCY_CODE
        INTO L_DEPOSIT_CCY
        FROM CYTMS_CCY_DEFN
       WHERE CCY_CODE =
             P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEPOSIT_CCY
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Invalid Deposit Currency Code  specified :  ' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'GW-ACUP002',
                     NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEPOSIT_CCY,
                         ' ') || '~');

        L_ERROR_FLAG := -1;
    END;
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO =
       P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACCOUNT THEN
      DBG('Account No. and sweep to Account cannot be the same :  ');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR02', '');
      RETURN FALSE;
    END IF;
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACCOUNT <> NULL THEN
      BEGIN
        SELECT CUST_AC_NO
          INTO L_SWEEP_TO_ACCOUNT
          FROM STTM_CUST_ACCOUNT
         WHERE AUTH_STAT = 'A'
           AND RECORD_STAT = 'O'
           AND BRANCH_CODE =
               P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACC_BRANCH
           AND CUST_AC_NO =
               P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACCOUNT
           AND NVL(AC_DESC, 'X') <> 'AUTO DEPOSIT'
           AND CUST_AC_NO <>
               P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO
           AND ACCOUNT_CLASS IN
               (SELECT ACCOUNT_CLASS
                  FROM STTMS_ACCOUNT_CLASS
                 WHERE RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A'
                   AND AC_CLASS_TYPE <> 'Y');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Invalid Sweep to Account specified');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IC-INSTR02',
                       P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACCOUNT || '~');
          RETURN FALSE;
      END;
    END IF;
    SELECT COUNT(*)
      INTO L_COUNT
      FROM ICTBS_DEPOSIT_INSTRUCTION
     WHERE SWEEP_TO_ACCOUNT = L_SWEEP_TO_ACCOUNT
       AND ACCOUNT_NO <>
           P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO;
    IF NVL(L_COUNT, 0) <> 0 THEN
      DBG('Sweep to Account must be unique');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR03', '');

      L_ERROR_FLAG := -1;
    END IF;
    DBG('validating...start_date');
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.START_DATE IS NULL THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR07', '');

      L_ERROR_FLAG := -1;
    END IF;
    DBG('Cspkss_Req_Wrapper.g_action_code  ' ||
        CSPKSS_REQ_WRAPPER.G_ACTION_CODE);
    DBG('p_stdcusac.ty_iccinstr.v_ictbs_deposit_instruction.once_auth  ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ONCE_AUTH);

    IF CSPKSS_REQ_WRAPPER.G_ACTION_CODE = 'NEW' THEN
      IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.START_DATE <
         GLOBAL.APPLICATION_DATE THEN
        DBG('Start Date cannot be Less than Todays Date');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR06', '');

        L_ERROR_FLAG := -1;
      END IF;
    END IF;
    DBG('validating...retry_till_date');
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.RETRY_TILL_DATE <
       GLOBAL.APPLICATION_DATE THEN
      DBG('Retry Till Date cannot be less than Todays Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR05', '');

      L_ERROR_FLAG := -1;
    END IF;
    IF P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.RETRY_TILL_DATE <
       P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.START_DATE THEN
      DBG('Retry Till Date cannot be less than Start Date');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-INSTR10', '');

      L_ERROR_FLAG := -1;
    END IF;

    DBG('TENOR DAYS: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_DAYS);
    DBG('TENOR MONTHS: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_MONTHS);
    DBG('TENOR YEARS: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_YEARS);
    DBG('SWEEP_MULTIPLE_OF: ' ||
        P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_MULTIPLE_OF);
    DBG('validating...TENOR');
    L_TENOR := NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_DAYS,
                   0) + NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_MONTHS,
                            0) + NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEP_TENOR_YEARS,
                                     0);
    IF NVL(L_TENOR, 0) < 1 THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-186', '');

      L_ERROR_FLAG := -1;
    END IF;

    DBG('validating...SWEEP_MULTIPLE_OF');
    IF NVL(P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_MULTIPLE_OF,
           0) < 1 THEN

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-187', '');

      L_ERROR_FLAG := -1;
    END IF;

    DBG('fn_Upload_auto_dep_details returning true');
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

    IF NVL(L_ERROR_FLAG, 0) < 0 THEN
      RETURN FALSE;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_Upload_auto_dep_details with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_AUTO_DEP_DETAILS;

  FUNCTION FN_UPLOAD_PR_TRCODE_RES(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_PRODUCT_CODE  CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_PROD_INDEX    CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_TRNCODE_INDEX STTM_TRN_CODE.TRN_CODE%TYPE;
    L_TRN_CODE      STTM_TRN_CODE.TRN_CODE%TYPE;
    L_COUNT1        NUMBER;
    L_COUNT         NUMBER;

  BEGIN
    DBG('Inside fn_upload_pr_trcode_res');

    DBG('Restricted Products');
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_PRODUCT, 'N') <> 'Y' THEN
      DBG('SPECIAL_CONDITION_PRODUCT <> Y');
      IF P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT > 0 THEN
        DBG('Failed:Cannot give restricted products.. SPECIAL_CONDITION_PRODUCT <> Y');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-337', '');

        RETURN FALSE;
      END IF;

    ELSE
      IF P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT LOOP
          DBG('Product: ' || P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I)
              .PRODUCT_CODE);
          BEGIN
            SELECT PRODUCT_CODE
              INTO L_PRODUCT_CODE
              FROM CSTM_PRODUCT
             WHERE PRODUCT_CODE = P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I)
                  .PRODUCT_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Invalid Product Code Specified for restrction: ' ||
                  SQLERRM);
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'GW-ACUP009',
                           P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I)
                           .PRODUCT_CODE || '~');
              RETURN FALSE;
          END;
          IF P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).DEBIT_TXN IS NULL THEN
            P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).DEBIT_TXN := 'N';
          END IF;
          IF P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).CREDIT_TXN IS NULL THEN
            P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).CREDIT_TXN := 'N';
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('Restricted transcations');
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPECIAL_CONDITION_TXNCODE, 'N') <> 'Y' THEN
      IF P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT > 0 THEN
        DBG('Failed:Cannot give restricted transcations.. special_condition_txncode=Y');

        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-338', '');

        RETURN FALSE;
      END IF;

    ELSE
      IF P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT LOOP
          BEGIN
            SELECT TRN_CODE
              INTO L_TRN_CODE
              FROM STTM_TRN_CODE
             WHERE TRN_CODE = P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(I).TXN_CODE;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Invalid Transaction Code Specified' || SQLERRM);
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'GW-ACUP017',
                           L_TRNCODE_INDEX || '~');
              RETURN FALSE;
          END;
          DBG('Txn: ' || P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(I).TXN_CODE);
        END LOOP;
      END IF;
    END IF;

    DBG('fn_upload_pr_trcode_res returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_pr_trcode_res with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_PR_TRCODE_RES;

  FUNCTION FN_UPLOAD_BIC_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_BANK_NAME     VARCHAR2(50);
    L_BIC_CODE      VARCHAR2(11);
  BEGIN
    DBG('Inside fn_upload_bic_details');

    BEGIN
      SELECT AC_CLASS_TYPE
        INTO L_AC_CLASS_TYPE
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
         AND AUTH_STAT = 'A'
         AND RECORD_STAT = 'O';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed To Select Account Type from Account Class table: ' ||
            SQLERRM);
        DBG('Record may not be authorised or not open');
        RETURN FALSE;
    END;

    IF L_AC_CLASS_TYPE = 'N' AND P_STDCUSAC.V_STTMS_BIC_CODE.COUNT > 0 THEN
      DBG('BIC is not allowd for Nostro accounts');

      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-339', '');

      RETURN FALSE;
    END IF;

    DBG('fn_upload_bic_details returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_bic_details with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_BIC_DETAILS;

  FUNCTION FN_VALIDATE_DEPOSITS(P_FUNCTION_ID   IN VARCHAR2,
                                P_ACCOUNT_NO    IN VARCHAR2,
                                P_BRANCH_CODE   IN VARCHAR2,
                                P_CCY           IN VARCHAR2,
                                P_DCD           IN VARCHAR2,
                                P_AC_CLASS_TYPE IN VARCHAR2) RETURN BOOLEAN IS
    L_ICTM_ACC        ICTMS_ACC%ROWTYPE;
    L_ERR_FLAG        NUMBER := 0;
    L_ICTM_DCD_MASTER ICTMS_DCD_MASTER%ROWTYPE;
    L_DCD             CHAR(1);

    L_CNT          NUMBER := 0;
    L_TDPAYOUT_REC ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    CURSOR CUR_TDPRINC(BRANCH   VARCHAR2,
                       ACCOUNT  VARCHAR2,
                       CURRENCY VARCHAR2) IS
      SELECT *
        FROM ICTM_TDPAYOUT_DETAILS
       WHERE BRN = BRANCH
         AND ACC = ACCOUNT
         AND CCY = CURRENCY;

  BEGIN
    DBG('hi...1');
    DBG('Inside fn_validate_deposits');
    BEGIN
      SELECT *
        INTO L_ICTM_ACC
        FROM ICTMS_ACC
       WHERE ACC = P_ACCOUNT_NO
         AND BRN = P_BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to select records from ictms_acc : ' || SQLERRM);
        RETURN FALSE;
    END;

    IF P_DCD = 'Y' THEN

      BEGIN
        SELECT *
          INTO L_ICTM_DCD_MASTER
          FROM ICTMS_DCD_MASTER
         WHERE TD_ACC = P_ACCOUNT_NO
           AND TD_BRN = P_BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to select records from ictms_dcd_master : ' ||
              SQLERRM);
          RETURN FALSE;
      END;
    END IF;

    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM ICTM_TDPAYOUT_DETAILS
       WHERE BRN = P_BRANCH_CODE
         AND ACC = P_ACCOUNT_NO
         AND CCY = P_CCY;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed to select records from ictm_tdpayout_details : ' ||
            SQLERRM);
        RETURN FALSE;
    END;
    DBG('Row count for TDpayout details : ' || L_CNT);
    OPEN CUR_TDPRINC(P_BRANCH_CODE, P_ACCOUNT_NO, P_CCY);
    LOOP
      FETCH CUR_TDPRINC
        INTO L_TDPAYOUT_REC;
      EXIT WHEN CUR_TDPRINC%NOTFOUND;

      DBG('Principal Liquidation Account : ' || L_TDPAYOUT_REC.OFFSET_ACC);
      DBG('Principal Liquidation Branch : ' || L_TDPAYOUT_REC.OFFSET_BRN);
      DBG('Interest booking Account : ' || L_ICTM_ACC.BOOK_ACC);
      DBG('Interest booking Branch : ' || L_ICTM_ACC.BOOK_BRN);
      DBG('Default settl Account : ' ||
          L_ICTM_DCD_MASTER.LINKED_CCY_SETT_ACC);
      DBG('TD branch : ' || L_ICTM_DCD_MASTER.TD_BRN);
      IF NVL(L_ICTM_ACC.RD_FLAG, 'N') = 'N' THEN
        IF NVL(L_ICTM_ACC.CLOSE_ON_MATURITY, 'N') = 'Y' THEN
          IF L_TDPAYOUT_REC.OFFSET_BRN || L_TDPAYOUT_REC.OFFSET_ACC =
             P_BRANCH_CODE || P_ACCOUNT_NO THEN
            DBG('Liquidation branch and liquidation account must not be same.');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD034', '');
            L_ERR_FLAG := -1;
          END IF;

          IF L_ICTM_DCD_MASTER.LINKED_CCY_SETT_ACC = P_ACCOUNT_NO OR
             L_ICTM_DCD_MASTER.LINKED_CCY_SETT_ACC =
             L_TDPAYOUT_REC.OFFSET_ACC THEN
            DBG('Default settl acc must not be same as TD acc and princ. liq acc, in DCD option case.');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD041', '');
            L_ERR_FLAG := -1;
          END IF;

        END IF;
      END IF;
      IF P_AC_CLASS_TYPE = 'Y' THEN

        IF NVL(L_ICTM_ACC.MOVE_PRIC_TO_UNCLAIMED, 'N') = 'N' AND
           NVL(L_ICTM_ACC.CLOSE_ON_MATURITY, 'N') = 'Y' THEN
          IF L_TDPAYOUT_REC.OFFSET_ACC = L_ICTM_ACC.ACC AND
             L_TDPAYOUT_REC.OFFSET_BRN = L_ICTM_ACC.BRN THEN
            DBG('Principal Liquidation account cannot be null or same as deposit account');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD21', '');
            L_ERR_FLAG := -1;
          END IF;
        END IF;

        IF (L_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
           L_ICTM_ACC.MOVE_PRIC_TO_UNCLAIMED = 'Y') AND
           L_ICTM_ACC.AUTO_ROLLOVER = 'N' AND
           L_ICTM_ACC.ROLLOVER_TYPE <> 'P' THEN
          DBG(' Move Interest to Unclaimed cannot be Selected, when auto roLlover not checked');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-BOD052', '');
          L_ERR_FLAG := -1;
        END IF;

      END IF;
    END LOOP;
    IF L_ERR_FLAG <> 0 THEN
      DBG('fn_validate_deposits returning false');
      RETURN FALSE;

    END IF;
    DBG('fn_validate_deposits returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_deposits with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_VALIDATE_DEPOSITS;

  FUNCTION FN_UPLOAD_CHGS(P_FUNCTION_ID IN VARCHAR2,
                          P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS

    L_CHG_CCY         CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_CHARGE_BASIS    ICTMS_PR_CHG.CHARGE_BASIS%TYPE;
    L_PRODUCT_CODE    CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_PROD_INDEX      CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_SLAB_INDEX      NUMBER(4);
    L_DUP_COUNT       NUMBER(4);
    L_FLOOR_BASIS_AMT NUMBER(22, 3);
    L_FLOOR_AMT       NUMBER(22, 3);
    L_COUNT           NUMBER;
    L_CUST_CATEGORY   STTMS_CUSTOMER.CUSTOMER_CATEGORY%TYPE;

  BEGIN
    DBG('Inside fn_upload_chgs');

    DBG('Brn: ' || P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Custno: ' || P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.CUST_NO);
    DBG('Acccls: ' ||
        P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);

    DBG('Chg prod count: ' || P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.COUNT);

    IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.COUNT LOOP
        DBG('Prod: ' || P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD);

        BEGIN
          SELECT CUSTOMER_CATEGORY
            INTO L_CUST_CATEGORY
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO =
                 P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.CUST_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error while getting Customer category' || SQLERRM ||
                SQLCODE);
        END;
        IF CSPKS_UTILS.FN_PRODUCT_ALLOWED(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD

                                         ,
                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                          GLOBAL.USER_ID,
                                          P_STDCUSAC.TY_ICCHSPCN.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                          L_CUST_CATEGORY,
                                          '*') <> 'A' THEN
          DBG('Product not allowed');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-179',
                       P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD);
        END IF;

        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') = 'N' THEN
          SELECT COUNT(*)
            INTO L_COUNT
            FROM ICTMS_PR_CHG_ACLASS      A,
                 CSTMS_PRODUCT            B,
                 ICTMS_PRODUCT_DEFINITION C
           WHERE A.PRODUCT_CODE = B.PRODUCT_CODE
             AND A.ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
             AND A.CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
             AND B.AUTH_STAT = 'A'
             AND B.RECORD_STAT = 'O'
             AND A.PRODUCT_CODE = C.PRODUCT_CODE
             AND C.PRODUCT_TYPE IN ('C', 'PC')

             AND NOT EXISTS
           (SELECT 1
                    FROM ICVWS_ALL_MAPPINGS MP
                   WHERE MP.BRN =
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND MP.ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                     AND MP.PROD = A.PRODUCT_CODE)
             AND A.PRODUCT_CODE = P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD;

          IF L_COUNT = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-179',
                         P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD);
            RETURN FALSE;
          END IF;
        END IF;
        SELECT DECODE(C.CHG_CCY, 'ACY', 'A', 'L')
          INTO L_CHG_CCY
          FROM ICTMS_PR_CHG C
         WHERE C.PRODUCT_CODE = P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD;
        DBG('l_chg_ccy: ' || L_CHG_CCY);

        IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).MIN_AMT < 0 THEN

          DBG('Min amount should be > 0');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-340', '');

          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).MAX_AMT < 0 THEN

          DBG('Min amount should be > 0');

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-341', '');

          RETURN FALSE;
        END IF;

        DBG('Assignment');
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

        IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).WAIVE IS NULL THEN
          P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).WAIVE := 'N';
        END IF;
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).WAIVE := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
                                                              .WAIVE,
                                                              'N');

        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).RECORD_STAT := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
                                                                    .RECORD_STAT,
                                                                    'O');

        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).ONCE_AUTH := 'Y';
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).UDE_CCY := L_CHG_CCY;
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).MIN_AMT := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
                                                                .MIN_AMT,
                                                                0);
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).MAX_AMT := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
                                                                .MAX_AMT,
                                                                0);
        P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).FREE_TXN := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
                                                                 .FREE_TXN,
                                                                 0);
        DBG('CHG Slab');
        DBG('Slab count: ' ||
            P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB.COUNT);
        IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB.COUNT > 0 THEN

          FOR J IN 1 .. P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB.COUNT LOOP
            DBG('Slab amount: ' || P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                .SLAB_AMT);

            DBG('2: Assignment');
            P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
            P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

            IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I)
             .PROD = P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).PROD THEN
              P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).PROD := P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD;
            END IF;

            P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).FLOOR_BASIS_AMT := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                                  .FLOOR_BASIS_AMT,
                                                                                  0) +
                                                                              NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                                  .SLAB_AMT,
                                                                                  0);

            P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J).FLOOR_AMT := NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                            .FLOOR_AMT,
                                                                            0) +
                                                                        (NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                             .SLAB_AMT,
                                                                             0) *
                                                                         NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                             .CHARGE_RATE,
                                                                             0)) +
                                                                        NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                            .FLOOR_AMT,
                                                                            0) +
                                                                        NVL(P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_CHG_SLAB(J)
                                                                            .CHARGE_AMT,
                                                                            0);

          END LOOP;
          DBG('Done with charge slabs');
        END IF;

      END LOOP;
      DBG('Done with charge products');
    END IF;

    DBG('fn_upload_chgs returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_chgs with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_CHGS;

  FUNCTION FN_UPLOAD_CON_CHGS(P_FUNCTION_ID IN VARCHAR2,
                              P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_CHG_CCY         CYTMS_CCY_DEFN.CCY_CODE%TYPE;
    L_PRODUCT_CODE    CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_PROD_INDEX      CSTMS_PRODUCT.PRODUCT_CODE%TYPE;
    L_DUP_COUNT       NUMBER(4);
    L_FLOOR_BASIS_AMT NUMBER(22, 3);
    L_FLOOR_AMT       NUMBER(22, 3);
    L_MIN_AMT         NUMBER(22, 3);
    L_MAX_AMT         NUMBER(22, 3);
    L_DISCOUNT_PC     NUMBER;
    L_DISCOUNT_AMT    NUMBER;
  BEGIN
    DBG('Inside fn_upload_con_chgs');

    DBG('Con chgs count: ' || P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT);

    IF P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT LOOP
        DBG('Con chg prod: ' || P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD);

        BEGIN
          SELECT DECODE(C.CHG_CCY, 'ACY', 'A', 'L')
            INTO L_CHG_CCY
            FROM ICTMS_PR_CHG C
           WHERE C.PRODUCT_CODE = P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAiled SELECT DECODE(c.chg_ccy' || SQLERRM);
        END;
        DBG('l_chg_ccy ' || L_CHG_CCY);

        IF (NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MAX_AMT, 0) <
           NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MIN_AMT, 0)

           AND
           NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MAX_AMT, 0) != 0) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-PR008', '');
          RETURN FALSE;
        END IF;

        DBG('Selecting  min/max amounts');
        BEGIN

          SELECT NVL(C.MIN_AMT, 0),
                 NVL(C.MAX_AMT, 0),
                 NVL(C.DISCOUNT_PC, 0),
                 NVL(C.DISCOUNT_AMT, 0)
            INTO L_MIN_AMT, L_MAX_AMT, L_DISCOUNT_PC, L_DISCOUNT_AMT
            FROM ICTMS_PR_CHG_CONSOL_ACLASS C
           WHERE C.PRODUCT_CODE = L_PROD_INDEX
             AND C.ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
             AND C.CCY = L_CHG_CCY;
          DBG('Selecting  min/max amounts successs');
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Selecting  min/max amounts ' || SQLERRM);
            L_MIN_AMT      := 0;
            L_MAX_AMT      := 0;
            L_DISCOUNT_PC  := 0;
            L_DISCOUNT_AMT := 0;
        END;

        IF NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MIN_AMT, 0) > 0 THEN
          L_MIN_AMT := NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MIN_AMT,
                           0);
        END IF;

        IF NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MAX_AMT, 0) > 0 THEN
          L_MAX_AMT := NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MAX_AMT,
                           0);
        END IF;

        IF P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL.COUNT > 0 THEN

          IF NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                 .DISCOUNT_PC,
                 0) > 0 AND NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                                .DISCOUNT_AMT,
                                0) > 0 THEN
            DBG(' Both the vals for discount is there ');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-PR052', '');
            RETURN FALSE;
          END IF;
        END IF;

        DBG('Con chgs assignment');

        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).WAIVE := NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I)
                                                              .WAIVE,
                                                              'N');
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).RECORD_STAT := 'O';
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).ONCE_AUTH := 'Y';
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).UDE_CCY := L_CHG_CCY;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MIN_AMT := L_MIN_AMT;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).MAX_AMT := L_MAX_AMT;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).FREE_TXN := NULL;
        DBG('Assignment done' ||
            P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL.COUNT);
        IF P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL.COUNT > 0 THEN

          IF NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                 .DISCOUNT_PC,
                 0) > 0 THEN
            L_DISCOUNT_PC := NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                                 .DISCOUNT_PC,
                                 0);
          END IF;

          IF NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                 .DISCOUNT_AMT,
                 0) > 0 THEN
            L_DISCOUNT_AMT := NVL(P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I)
                                  .DISCOUNT_AMT,
                                  0);
          END IF;

          DBG('l_discount_pc: ' || L_DISCOUNT_PC || ' l_discount_amt: ' ||
              L_DISCOUNT_AMT);
        END IF;
        DBG('Consol chgs assignment');
        DBG('p_stdcusac.ty_icccspcn.v_ICTMS_ACC_PR(i).prod' || P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD);
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).PROD := P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).DISCOUNT_PC := L_DISCOUNT_PC;
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).DISCOUNT_AMT := L_DISCOUNT_AMT;

        DBG('Done with consol chg assignment');

      END LOOP;
    END IF;

    DBG('fn_upload_con_chgs returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_con_chgs with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_CON_CHGS;

  FUNCTION FN_UPLOAD_BILLING(P_FUNCTION_ID IN VARCHAR2,
                             P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_BRN            STTM_BILLING_PREFERENCE.BRANCH_CODE%TYPE;
    L_ACC            STTM_BILLING_PREFERENCE.CUST_AC_NO%TYPE;
    L_CON_ACC        STTM_BILLING_PREFERENCE.CONSOL_ACCOUNT%TYPE;
    L_BILL_REQD      STTM_BILLING_PREFERENCE.BILL_LIQD%TYPE;
    L_SET_ACC        STTM_BILLING_PREFERENCE.SETTLEMENT_ACCOUNT%TYPE;
    L_DIR_DEBIT      STTM_BILLING_PREFERENCE.DIRECT_DEBIT%TYPE;
    L_DD_BANK        STTM_BILLING_PREFERENCE.DD_BANK_CODE%TYPE;
    L_DD_ACC         STTM_BILLING_PREFERENCE.DD_ACCOUNT_NO%TYPE;
    L_DD_NAME        STTM_BILLING_PREFERENCE.NAME%TYPE;
    L_BILL_PROD      STTM_BILLING_PREFERENCE.BILL_PROD_CODE%TYPE;
    L_AGREEMENT_ID   STTM_BILLING_PREFERENCE.AGREEMENT_ID%TYPE;
    L_SET_BRN        STTM_BILLING_PREFERENCE.SETTLE_ACC_BRN%TYPE;
    L_SET_CCY        STTM_BILLING_PREFERENCE.SETTLE_CCY%TYPE;
    L_CON_BRN        STTM_BILLING_PREFERENCE.CONSOL_ACC_BRN%TYPE;
    L_CON_CCY        STTM_BILLING_PREFERENCE.CONSOL_CCY%TYPE;
    L_CNT            NUMBER;
    L_NUM            NUMBER;
    L_CONSOL_ACCOUNT STTMS_BILLING_PREFERENCE.CONSOL_ACCOUNT%TYPE;
    L_MATCH          BOOLEAN := FALSE;

    CURSOR BILL_PRDS IS
      SELECT PRODUCT_CODE
        FROM BLTM_PROD_ACLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
         AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
         AND NVL(OPEN, 'Y') <> 'N';
  BEGIN
    DBG('Inside fn_upload_billing');

    IF (P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT IS NULL AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN IS NULL AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_CCY IS NULL AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NULL AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO IS NULL AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME IS NULL) THEN
      DBG('Billing details not enetred...');
      RETURN TRUE;
    END IF;

    SELECT COUNT(*)
      INTO L_CNT
      FROM BLTM_PROD_ACLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
       AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
       AND NVL(OPEN, 'Y') <> 'N';

    IF L_CNT = 0 THEN
      IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME IS NOT NULL THEN
        DBG('Account class not linked to Billing Product');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL2', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
       (P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT IS NOT NULL OR
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN IS NOT NULL OR
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_CCY IS NOT NULL OR
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NOT NULL OR
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO IS NOT NULL OR
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME IS NOT NULL) THEN

      DBG('Bill Settlement details should be NULL if Consolidating A/c is not main acount');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL5', '');
      RETURN FALSE;
    END IF;

    SELECT COUNT(*)
      INTO L_CNT
      FROM STTMS_BILLING_PREFERENCE
     WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
       AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

    DBG('Count is :' || L_CNT);

    IF (L_CNT <> 0) THEN

      DBG('Getting consol account no.');

      SELECT DISTINCT CONSOL_ACCOUNT
        INTO L_CONSOL_ACCOUNT
        FROM STTMS_BILLING_PREFERENCE
       WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

      DBG('Old consol acc:' || L_CONSOL_ACCOUNT);
      DBG('New consol acc:' ||
          P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT);

      IF (L_CONSOL_ACCOUNT <>
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT) THEN

        DBG('Checking for due amt');

        SELECT COUNT(*)
          INTO L_CNT
          FROM ICTBS_DR_INT_DUE
         WHERE ACC = L_CONSOL_ACCOUNT
           AND BRN =
               P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.BRANCH_CODE
           AND PROD_TYPE = 'B'
           AND AMT_DUE <> AMT_SETTLD;

        IF (L_CNT <> 0) THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL4', '');
          RETURN FALSE;
        END IF;

      END IF;

    END IF;

    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND ((RECORD_STAT = 'O' AND AUTH_STAT = 'A' AND
             CUST_AC_NO =
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT) OR
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT =
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO)
         AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;

      IF L_CNT = 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL9', '');
        RETURN FALSE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Invalid Cons Account .' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL9', '');
        RETURN FALSE;
    END;

    DBG('Entred int o the function  fn_upload_billing_details');
    IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DIRECT_DEBIT = 'Y' THEN
      IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO IS NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME IS NULL THEN
        DBG('Failed with err code:ST-CUSBL1');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL1', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.BILL_LIQD = 'A' AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DIRECT_DEBIT = 'N' AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CUST_AC_NO =
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT AND
       P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT IS NULL THEN
      DBG('Failed with err code:ST-CUSBL3');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL3', '');
      RETURN FALSE;
    END IF;

    IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DIRECT_DEBIT = 'N' THEN
      IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO IS NOT NULL OR
         P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME IS NOT NULL THEN
        DBG('DD Details should be NULL if Direct Debit is not checked.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL7', '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE IS NOT NULL THEN

      SELECT COUNT(*)
        INTO L_CNT
        FROM PCTM_BANK_PARAM
       WHERE AUTH_STAT = 'A'
         AND RECORD_STAT = 'O'
         AND BANK_CODE =
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE;

      IF L_CNT = 0 THEN
        DBG('Invalid Direct Debit Bank Code Specified');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL6', '');
        RETURN FALSE;
      END IF;
    END IF;

    BEGIN
      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_CUST_ACCOUNT
       WHERE (CUST_AC_NO =
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT AND
             BRANCH_CODE =
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN AND
             RECORD_STAT = 'O' AND AUTH_STAT = 'A')
          OR (P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT =
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO AND
             P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN =
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      IF L_CNT = 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL8', '');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Invalid Sett Account .' || SQLERRM);
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSBL8', '');
        RETURN FALSE;
    END;

    L_BRN          := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    L_ACC          := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    L_CON_ACC      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT;
    L_BILL_REQD    := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.BILL_LIQD;
    L_SET_ACC      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT;
    L_DIR_DEBIT    := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DIRECT_DEBIT;
    L_DD_BANK      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE;
    L_DD_ACC       := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO;
    L_DD_NAME      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME;
    L_AGREEMENT_ID := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.AGREEMENT_ID;
    L_SET_BRN      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN;
    L_SET_CCY      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_CCY;
    L_CON_BRN      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACC_BRN;
    L_CON_CCY      := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_CCY;

    DBG('Bill Prod count: ' ||
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT);
    IF P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT LOOP
        DBG('Bill prod: ' || P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I)
            .BILL_PROD_CODE);
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_ACCOUNT := L_CON_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).BILL_LIQD := L_BILL_REQD;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLEMENT_ACCOUNT := L_SET_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DIRECT_DEBIT := L_DIR_DEBIT;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DD_BANK_CODE := L_DD_BANK;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DD_ACCOUNT_NO := L_DD_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).NAME := L_DD_NAME;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).AGREEMENT_ID := L_AGREEMENT_ID;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLE_ACC_BRN := L_SET_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLE_CCY := L_SET_CCY;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_ACC_BRN := L_CON_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_CCY := L_CON_CCY;
      END LOOP;
    END IF;

    DBG('Checking values from bltm_prod_aclass');
    FOR EACH_PRD IN BILL_PRDS LOOP
      IF P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT LOOP
          IF P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I)
           .BILL_PROD_CODE = EACH_PRD.PRODUCT_CODE THEN
            DBG('Match with prod: ' || EACH_PRD.PRODUCT_CODE);
            L_MATCH := TRUE;
            EXIT;
          END IF;
        END LOOP;
      END IF;
      IF NOT L_MATCH THEN
        DBG('Assigning new prod: ' || EACH_PRD.PRODUCT_CODE);
        L_NUM := P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT + 1;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).BILL_PROD_CODE := EACH_PRD.PRODUCT_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).CONSOL_ACCOUNT := L_CON_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).BILL_LIQD := L_BILL_REQD;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).SETTLEMENT_ACCOUNT := L_SET_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).DIRECT_DEBIT := L_DIR_DEBIT;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).DD_BANK_CODE := L_DD_BANK;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).DD_ACCOUNT_NO := L_DD_ACC;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).NAME := L_DD_NAME;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).AGREEMENT_ID := L_AGREEMENT_ID;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).SETTLE_ACC_BRN := L_SET_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).SETTLE_CCY := L_SET_CCY;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).CONSOL_ACC_BRN := L_CON_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(L_NUM).CONSOL_CCY := L_CON_CCY;
      END IF;
    END LOOP;

    DBG('fn_upload_billing returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_billing with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_BILLING;

  FUNCTION FN_UPLOAD_BILLING_FOR_NEW(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_upload_billing_for_new');
    DBG('Bill prod count: ' ||
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT);

    IF P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE.COUNT LOOP
        DBG('Bill prod: ' || P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I)
            .BILL_PROD_CODE);

        P_STDCUSAC.TY_STCCUSBL.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_CUST_ACCOUNT.CCY         := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;

        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_ACCOUNT := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACCOUNT;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).BILL_LIQD := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.BILL_LIQD;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLEMENT_ACCOUNT := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLEMENT_ACCOUNT;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DIRECT_DEBIT := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DIRECT_DEBIT;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DD_BANK_CODE := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_BANK_CODE;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).DD_ACCOUNT_NO := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.DD_ACCOUNT_NO;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).NAME := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.NAME;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).AGREEMENT_ID := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.AGREEMENT_ID;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLE_ACC_BRN := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_ACC_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).SETTLE_CCY := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.SETTLE_CCY;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_ACC_BRN := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_ACC_BRN;
        P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I).CONSOL_CCY := P_STDCUSAC.TY_STCCUSBL.V_PREFERENCE__BILLINGALIAS.CONSOL_CCY;
        DBG('Done with prod: ' || P_STDCUSAC.TY_STCCUSBL.V_STTMS_BILLING_PREFERENCE(I)
            .BILL_PROD_CODE);
      END LOOP;
    END IF;

    DBG('fn_upload_billing_for_new returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload_billing_for_new with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_UPLOAD_BILLING_FOR_NEW;

  FUNCTION FN_POPULATE_RECORDS(P_FUNCTION_ID IN VARCHAR2,
                               P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ACTION_CODE IN VARCHAR2,
                               P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS
    L_IC_INCLUSION          STTMS_ACCOUNT_CLASS.IC_INCLUSION%TYPE;
    L_AC_CLASS_TYPE         STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_ACCCLS_REC            STTMS_ACCOUNT_CLASS%ROWTYPE;
    L_MUDARABAH_ACC_CLASS   STTMS_ACCOUNT_CLASS.MUDARABAH_ACC_CLASS%TYPE;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  BEGIN
    DBG('Inside fn_populate_records');

    IF P_STDCUSAC.V_STTMS_BIC_CODE.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_BIC_CODE.COUNT LOOP
        P_STDCUSAC.V_STTMS_BIC_CODE(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_BIC_CODE(I).AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT LOOP
        P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.COUNT LOOP
        P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS.COUNT LOOP
        P_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_CUSTAC_CRDR_LMTS(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_STTMS_INTERMEDIARY.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_INTERMEDIARY.COUNT LOOP
        P_STDCUSAC.V_STTMS_INTERMEDIARY(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_INTERMEDIARY(I).ACCOUNT_NUMBER := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES.COUNT LOOP
        P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_STTMS_OD_COLL_LINKAGES(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT LOOP
        P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I).BRANCH := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I).ACC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT LOOP
        P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).CUST_ACCOUNT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT LOOP
        P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I).CUST_ACCOUNT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;

    IF P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT LOOP
        P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;
    IF P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT LOOP
        P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END LOOP;
    END IF;

    P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.BRANCH                     := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.CUST_AC_NO                 := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.ACCOUNT_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_MASTER.BRANCH           := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_MASTER.ACC_NO           := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NULL THEN

      IF P_ACTION_CODE = 'MODIFY' THEN
        SELECT AC_OPEN_DATE
          INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

      ELSIF P_ACTION_CODE = 'NEW' THEN

        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
      END IF;
    END IF;

    DBG('IC inclusion check');
    SELECT NVL(IC_INCLUSION, 'N'),
           AC_CLASS_TYPE,
           NVL(MUDARABAH_ACC_CLASS, 'N')
      INTO L_IC_INCLUSION, L_AC_CLASS_TYPE, L_MUDARABAH_ACC_CLASS
      FROM STTMS_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    DBG('l_ic_inclusion: ' || L_IC_INCLUSION);

    IF L_MUDARABAH_ACC_CLASS = 'Y' THEN
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS := 'Y';
    ELSE
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS := 'N';
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('Getting the subsys stats');
      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                      G_SUBSYSTEM_TY_FLDS) THEN
        DBG('fn_parse_subsysstats has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('IC details');

    IF NOT FN_POPULATE_IC_DETAILS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_populate_ic_details has returned false');
      RETURN FALSE;
    END IF;

    IF P_SOURCE <> 'FLEXCUBE' THEN
      BEGIN
        SELECT *
          INTO L_ACCCLS_REC
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Stage 1: Failed in Selection from sttms_account_class :  ' ||
              SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-102',
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS || '~');
          RETURN FALSE;
      END;
      DBG('Stage 1: Defaulting Account stmt type - 1');
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE IS NULL AND
         L_ACCCLS_REC.ACC_STMT_TYPE = 'N' THEN
        DBG('Account statement Cycle 1 passed NULL');
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE  := L_ACCCLS_REC.ACC_STMT_TYPE;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE := NULL;
      ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE IS NULL AND
            L_ACCCLS_REC.ACC_STMT_TYPE <> 'N' THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_TYPE := L_ACCCLS_REC.ACC_STMT_TYPE;
        DBG('Acc stmt cycle 1: ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE);
        DBG('l_acccls_rec.acc_stmt_cycle 1: ' ||
            L_ACCCLS_REC.ACC_STMT_CYCLE);
        IF L_ACCCLS_REC.ACC_STMT_CYCLE = 'D' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE IS NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE         := L_ACCCLS_REC.ACC_STMT_CYCLE;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT := 'Y';
        ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE = 'D' THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT := 'Y';
        ELSE
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE := L_ACCCLS_REC.ACC_STMT_CYCLE;
        END IF;

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY IS NULL AND
           L_ACCCLS_REC.STATEMENT_DAY IS NOT NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_DAY := L_ACCCLS_REC.STATEMENT_DAY;
        END IF;

      END IF;

      DBG('Stage 1: Defaulting Account stmt type - 2');
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 IS NULL AND
         L_ACCCLS_REC.ACC_STMT_TYPE2 = 'N' THEN
        DBG('Account statement Cycle 2 passed NULL');
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 := L_ACCCLS_REC.ACC_STMT_TYPE2;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 := NULL;
      ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 IS NULL AND
            L_ACCCLS_REC.ACC_STMT_TYPE2 <> 'N' THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE2 := L_ACCCLS_REC.ACC_STMT_TYPE2;
        DBG('Acc stmt cycle 2: ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE);
        DBG('l_acccls_rec.acc_stmt_cycle 2: ' ||
            L_ACCCLS_REC.ACC_STMT_CYCLE);
        IF L_ACCCLS_REC.ACC_STMT_CYCLE2 = 'D' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 IS NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2         := L_ACCCLS_REC.ACC_STMT_CYCLE2;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2 := 'Y';
        ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 = 'D' THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT2 := 'Y';
        ELSE
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE2 := L_ACCCLS_REC.ACC_STMT_CYCLE2;
        END IF;

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 IS NULL AND
           L_ACCCLS_REC.STATEMENT_DAY2 IS NOT NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY2 := L_ACCCLS_REC.STATEMENT_DAY2;
        END IF;

      END IF;

      DBG('Stage 1: Defaulting Account stmt type - 3');
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 IS NULL AND
         L_ACCCLS_REC.ACC_STMT_TYPE3 = 'N' THEN
        DBG('Account statement Cycle 3 passed NULL');
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 := L_ACCCLS_REC.ACC_STMT_TYPE3;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 := NULL;
      ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 IS NULL AND
            L_ACCCLS_REC.ACC_STMT_TYPE3 <> 'N' THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_TYPE3 := L_ACCCLS_REC.ACC_STMT_TYPE3;
        DBG('Acc stmt cycle 3: ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE);
        DBG('l_acccls_rec.acc_stmt_cycle 3: ' ||
            L_ACCCLS_REC.ACC_STMT_CYCLE);
        IF L_ACCCLS_REC.ACC_STMT_CYCLE3 = 'D' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 IS NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3         := L_ACCCLS_REC.ACC_STMT_CYCLE3;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3 := 'Y';
        ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 = 'D' THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.GEN_STMT_ONLY_ON_MVMT3 := 'Y';
        ELSE
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STMT_CYCLE3 := L_ACCCLS_REC.ACC_STMT_CYCLE3;
        END IF;

        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 IS NULL AND
           L_ACCCLS_REC.STATEMENT_DAY3 IS NOT NULL THEN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STMT_DAY3 := L_ACCCLS_REC.STATEMENT_DAY3;
        END IF;

      END IF;
    END IF;

    DBG('Provisioning percentage details');
    IF NOT FN_UPLOAD_PROV_PERCENT(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_Upload_Prov_Percent has returned false');
      RETURN FALSE;
    END IF;

    DBG('Maintenance instruction details');
    IF NOT
        FN_UPLOAD_ACCMAINT_INSTR(P_FUNCTION_ID, P_STDCUSAC, P_ACTION_CODE) THEN
      DBG('fn_upload_accmaint_instr has returned false');
      RETURN FALSE;
    END IF;

    DBG('Relationship details');
    IF NOT FN_UPLOAD_RELATIONSHIP(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_upload_relationship has returned false');
      RETURN FALSE;
    END IF;

    DBG('MIS stat: ' || G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);
    IF G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT = 'U' THEN
      DBG('MIS details');
      IF NOT FN_UPLOAD_ACCMIS(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_Upload_accmis has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF L_IC_INCLUSION = 'Y'

     THEN
      DBG('INTDETAILS');
      IF NOT FN_UPLOAD_IC_DETAILS(P_FUNCTION_ID,
                                  P_STDCUSAC,
                                  P_ACTION_CODE,
                                  P_SOURCE) THEN
        DBG('fn_upload_ic_details has returned false');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('AUTODEPDETAILS Stat: ' || G_SUBSYSTEM_TY_FLDS('AUTODEPDETAILS').STAT);

    DBG('Deposit Instructions details');
    IF NOT FN_UPLOAD_AUTO_DEP_DETAILS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_Upload_auto_dep_details has returned false');
      RETURN FALSE;
    END IF;

    DBG('Uploading Charges');

    IF NOT FN_UPLOAD_CHGS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_upload_chgs has returned false');
      RETURN FALSE;
    END IF;

    DBG('Uploading Consolidated charges');

    IF NOT FN_UPLOAD_CON_CHGS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_upload_con_chgs has returned false');
      RETURN FALSE;
    END IF;

    DBG('Restricted prd txn details');
    IF NOT FN_UPLOAD_PR_TRCODE_RES(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_upload_pr_trcode_res has returned false');
      RETURN FALSE;
    END IF;

    DBG('BIC details');
    IF NOT FN_UPLOAD_BIC_DETAILS(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_upload_bic_details has returned false');
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('MODIFY.... Billing details upload');
      IF NOT FN_UPLOAD_BILLING(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_upload_billing has returned false');
        RETURN FALSE;
      END IF;
    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      DBG('NEW... Billing');
      IF NOT FN_UPLOAD_BILLING_FOR_NEW(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_upload_billing_for_new has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT FN_POPULATE_OD_COLL_LINKAGES(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_populate_od_coll_linkages has returned false');
      RETURN FALSE;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      DBG('## calling stpks_stdcusac_utils_cluster.fn_deposit_def_validate...');

      IF NOT
          STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_POPULATE_RECORDS(P_FUNCTION_ID,
                                                             P_STDCUSAC,
                                                             P_ACTION_CODE,
                                                             P_SOURCE,
                                                             L_FN_CALL_ID,
                                                             L_TB_CLUSTER_DATA) THEN
        DBG('failed in stpks_stdcusac_utils_cluster.fn_populate_records-');

        RETURN FALSE;
      END IF;
      DBG('## success for stpks_stdcusac_utils_cluster.fn_populate_records...');
    END IF;

    DBG('fn_populate_records returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_populate_records with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POPULATE_RECORDS;

  FUNCTION FN_INSERT_ACCBAL_TOV(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_COUNT NUMBER;
  BEGIN
    DBG('Entered Into Function fn_Insert_accbal_tov');

    BEGIN

      DBG('Inserting record into sttms_account_bal_tov');
      INSERT INTO STTMS_ACCOUNT_BAL_TOV
        (CUST_AC_NO,
         BRANCH_CODE,
         ACY_OPENING_BAL,
         LCY_OPENING_BAL,
         ACY_TODAY_TOVER_DR,
         ACY_TODAY_TOVER_CR,
         LCY_TODAY_TOVER_CR,
         LCY_TODAY_TOVER_DR,
         ACY_TANK_DR,
         LCY_TANK_DR,
         ACY_TANK_CR,
         LCY_TANK_CR,
         ACY_TOVER_CR,
         LCY_TOVER_CR,
         ACY_TANK_UNCOLLECTED

        ,
         LCY_CURR_BALANCE

        ,
         ACY_UNAUTH_DR,
         ACY_UNAUTH_TANK_DR

        ,
         ACY_UNAUTH_TANK_CR,
         ACY_UNAUTH_UNCOLLECTED,
         ACY_UNAUTH_TANK_UNCOLLECTED,
         ACY_MTD_TOVER_DR,
         LCY_MTD_TOVER_DR,
         ACY_MTD_TOVER_CR,
         LCY_MTD_TOVER_CR,
         ACY_ACCRUED_DR_IC,
         ACY_ACCRUED_CR_IC,
         TOD_START_DATE,
         TOD_END_DATE,
         TOD_LIMIT,
         UNCOLL_FUNDS_LIMIT,
         SUBLIMIT

        ,
         DR_INT_DUE

         )
      VALUES
        (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0

        ,
         0

        ,
         0,
         0

        ,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT

        ,
         0

         );
      DBG('Insertion into sttms_account_bal_tov completed');

    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBG('Duplicate record Exists');
    END;

    DBG('Successfully Return From the Function fn_Insert_accbal_tov');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN WHEN OTHERS OF fn_Insert_accbal_tov:  ' || SQLERRM);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_INSERT_ACCBAL_TOV;

  FUNCTION FN_AUTH_UPLD(P_FUNCTION_ID IN VARCHAR2,
                        P_REC_CUSTACC IN OUT STTMS_CUST_ACCOUNT%ROWTYPE)
    RETURN BOOLEAN IS
    L_CHECKER_ID       STTMS_CUST_ACCOUNT.CHECKER_ID%TYPE;
    L_CHECKER_DT_STAMP STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP%TYPE;
    L_AUTH_STAT        STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_CUSTOMER_NAME1   STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_LANGUAGE         STTMS_CUSTOMER.LANGUAGE%TYPE;
    L_COUNTRY          STTMS_CUSTOMER.COUNTRY%TYPE;
    L_COUNT            NUMBER := 0;

    L_ADDR_REC_NUM NUMBER;

    L_DATE_STAMP STTMS_CUSTOMER.MAKER_DT_STAMP%TYPE := TO_DATE((TO_CHAR(GLOBAL.APPLICATION_DATE,
                                                                        GLOBAL.GET_NLS_DT_FORMAT) ||
                                                               TO_CHAR(FN_SYSDATE,
                                                                        'HH24:MI:SS')),
                                                               GLOBAL.GET_NLS_DT_FORMAT ||
                                                               ' HH24:MI:SS');

    L_COUNT_UNAUTH NUMBER;
  BEGIN
    DBG('Inside fn_auth_upld');

    DBG('Assigning from sttms_cust_account');
    L_CHECKER_ID       := P_REC_CUSTACC.CHECKER_ID;
    L_CHECKER_DT_STAMP := P_REC_CUSTACC.CHECKER_DT_STAMP;
    L_AUTH_STAT        := P_REC_CUSTACC.AUTH_STAT;

    DBG('l_auth_stat: ' || L_AUTH_STAT);
    IF L_AUTH_STAT = 'A' AND P_REC_CUSTACC.ADDRESS1 IS NOT NULL AND
       P_REC_CUSTACC.MEDIA IS NOT NULL AND
       P_REC_CUSTACC.LOCATION IS NOT NULL THEN
      SELECT CUSTOMER_NAME1, COUNTRY, LANGUAGE
        INTO L_CUSTOMER_NAME1, L_COUNTRY, L_LANGUAGE
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = P_REC_CUSTACC.CUST_NO;
      DBG('Customer Name Selected : ' || L_CUSTOMER_NAME1);
      BEGIN
        DBG('Updating mstms_cust_acc_address');

        DBG('Before assigning ADDR_REC_NUM..for modify action code');

        SELECT NVL(MAX(ADDR_REC_NUM), 0) + 1
          INTO L_ADDR_REC_NUM
          FROM MSTMS_CUST_ACC_ADDRESS
         WHERE CUST_AC_BRN = P_REC_CUSTACC.BRANCH_CODE
           AND CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO;

        UPDATE MSTMS_CUST_ACC_ADDRESS
           SET ADDRESS1        = P_REC_CUSTACC.ADDRESS1,
               ADDRESS2        = P_REC_CUSTACC.ADDRESS2,
               ADDRESS3        = P_REC_CUSTACC.ADDRESS3,
               ADDRESS4        = P_REC_CUSTACC.ADDRESS4,
               COUNTRY         = P_REC_CUSTACC.COUNTRY_CODE,
               AUTH_STAT       = 'A',
               ONCE_AUTH       = 'Y',
               DEFAULT_ADDRESS = 'Y',

               ADDR_REC_NUM = L_ADDR_REC_NUM,

               MAKER_ID         = P_REC_CUSTACC.MAKER_ID,
               MAKER_DT_STAMP   = P_REC_CUSTACC.MAKER_DT_STAMP,
               CHECKER_ID       = L_CHECKER_ID,
               CHECKER_DT_STAMP = L_CHECKER_DT_STAMP,
               RECORD_STAT      = P_REC_CUSTACC.RECORD_STAT,
               MOD_NO           = MOD_NO + 1
         WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
           AND CUST_AC_BRN = P_REC_CUSTACC.BRANCH_CODE
           AND LOCATION = P_REC_CUSTACC.LOCATION
           AND MEDIA = P_REC_CUSTACC.MEDIA;

        IF SQL%NOTFOUND THEN
          DBG('Inserting into mstms_cust_acc_address');

          DBG('Before assigning ADDR_REC_NUM..for new action code');
          SELECT NVL(MAX(ADDR_REC_NUM), 0) + 1
            INTO L_ADDR_REC_NUM
            FROM MSTMS_CUST_ACC_ADDRESS
           WHERE CUST_AC_BRN = P_REC_CUSTACC.BRANCH_CODE
             AND CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO;
          DBG('After assigning ADDR_REC_NUM..for new action code');

          INSERT INTO MSTMS_CUST_ACC_ADDRESS
            (CUST_AC_NO,
             LOCATION,
             MEDIA,
             ADDRESS1,
             ADDRESS2,
             ADDRESS3,
             ADDRESS4,
             LANGUAGE,
             TEST_KEYWORD,
             COUNTRY,
             NAME,
             ANSWERBACK,
             TEST_REQUIRED,
             CHECKER_DT_STAMP,
             MOD_NO,
             RECORD_STAT,
             AUTH_STAT,
             ONCE_AUTH,
             MAKER_DT_STAMP,
             MAKER_ID,
             CHECKER_ID,
             TOBE_EMAILED,
             DELIVERY_BY,
             HOLD_MAIL,
             CUST_AC_BRN,
             DEFAULT_ADDRESS,
             ADDR_REC_NUM)
          VALUES
            (P_REC_CUSTACC.CUST_AC_NO,
             P_REC_CUSTACC.LOCATION,
             P_REC_CUSTACC.MEDIA,
             P_REC_CUSTACC.ADDRESS1,
             P_REC_CUSTACC.ADDRESS2,
             P_REC_CUSTACC.ADDRESS3,
             P_REC_CUSTACC.ADDRESS4,
             L_LANGUAGE,
             NULL,
             P_REC_CUSTACC.COUNTRY_CODE

            ,
             L_CUSTOMER_NAME1,
             NULL,
             NULL,
             L_CHECKER_DT_STAMP,
             1,
             P_REC_CUSTACC.RECORD_STAT,
             'A',
             'Y',
             P_REC_CUSTACC.MAKER_DT_STAMP,
             P_REC_CUSTACC.MAKER_ID,
             L_CHECKER_ID

            ,
             'N',
             NULL

            ,
             'N',
             P_REC_CUSTACC.BRANCH_CODE,
             'Y',
             L_ADDR_REC_NUM);
        END IF;
      END;

      DBG('Checking Record in mstms_msg_address');
      SELECT COUNT(*)
        INTO L_COUNT
        FROM MSTMS_MSG_ACC_ADDRESS
       WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
         AND BRANCH = P_REC_CUSTACC.BRANCH_CODE
         AND LOCATION = P_REC_CUSTACC.LOCATION
         AND MEDIA = P_REC_CUSTACC.MEDIA;
      DBG('Number of Entries in Message Address : ' || L_COUNT);
      IF L_COUNT = 0 THEN
        DBG('Inserting into mstms_msg_acc_address');
        INSERT INTO MSTMS_MSG_ACC_ADDRESS
          (MSG_TYPE,
           MODULE,
           BRANCH,
           LOCATION,
           MEDIA,
           NO_OF_COPIES,
           FORMAT,
           CUST_AC_NO,
           PRIMARY_ADDRESS)
        VALUES
          ('ANY MSG TYPE',
           'AL',
           P_REC_CUSTACC.BRANCH_CODE,
           P_REC_CUSTACC.LOCATION,
           P_REC_CUSTACC.MEDIA,
           NULL,
           NULL,
           P_REC_CUSTACC.CUST_AC_NO,
           'Y');
      END IF;
    END IF;

    DBG('Date Stamp :' || L_DATE_STAMP);
    DBG('Updating tables');

    DBG('ictbs_deposit_instructio');
    UPDATE ICTBS_DEPOSIT_INSTRUCTION
       SET AUTH_STAT        = 'A',
           CHECKER_ID       = GLOBAL.USER_ID,
           CHECKER_DT_STAMP = L_DATE_STAMP

          ,
           MAKER_ID       = P_REC_CUSTACC.MAKER_ID,
           MAKER_DT_STAMP = P_REC_CUSTACC.MAKER_DT_STAMP,
           MOD_NO         = P_REC_CUSTACC.MOD_NO,
           RECORD_STAT    = NVL(P_REC_CUSTACC.RECORD_STAT, 'O'),
           ONCE_AUTH      = 'Y'

     WHERE ACCOUNT_NO = P_REC_CUSTACC.CUST_AC_NO
       AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE;

    DBG('sttms_account_maint_instr');

    BEGIN
      SELECT COUNT(*)
        INTO L_COUNT_UNAUTH
        FROM STTBS_RECORD_LOG
       WHERE KEY_ID =
             '~STTM_ACCOUNT_MAINT_INSTR~' || P_REC_CUSTACC.BRANCH_CODE || '~' ||
             P_REC_CUSTACC.CUST_AC_NO || '~'
         AND AUTH_STAT = 'U';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in selecting the count');
        L_COUNT_UNAUTH := 0;
    END;

    IF L_COUNT_UNAUTH = 0 THEN

      DBG('Updating the base table sttms_account_maint_instr since record is authorized in acc instruction maintenance screen');
      UPDATE STTMS_ACCOUNT_MAINT_INSTR
         SET AUTH_STAT        = 'A',
             CHECKER_ID       = GLOBAL.USER_ID,
             CHECKER_DT_STAMP = L_DATE_STAMP,
             ONCE_AUTH        = 'Y'
       WHERE CUST_AC_NO = P_REC_CUSTACC.CUST_AC_NO
         AND BRANCH_CODE = P_REC_CUSTACC.BRANCH_CODE;
    END IF;

    DBG('fn_auth_upld returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN WHEN OTHERS OF fn_auth_upld:  ' || SQLERRM);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END FN_AUTH_UPLD;

  FUNCTION PR_ACCOUNT_OPENING(P_FUNCTION_ID IN VARCHAR2,
                              P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                              P_BRN         VARCHAR2,
                              P_ACC         VARCHAR2) RETURN BOOLEAN IS

    CURSOR PRODCLASS(ACCLASS  STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE,
                     CURRENCY STTM_CUST_ACCOUNT.CCY%TYPE) IS

      SELECT IPC.PRODUCT_CODE
        FROM ICTMS_PR_CHG IPC, ICVWS_PR_BRN IPB
       WHERE IPC.PRODUCT_CODE IN
             (SELECT PRODUCT_CODE
                FROM ICTMS_PR_CHG_ACLASS
               WHERE ACLASS = ACCLASS
                 AND CCY = CURRENCY)
         AND IPC.CHARGE_BASIS = 'ACCOUNT-OPENING'
         AND IPC.PRODUCT_CODE = IPB.PROD
         AND IPB.BRN = P_BRN;

    L_TB_PROD      ICPKS_MAINT.TB_PROD;
    L_NEXT_LIQD_DT ICTBS_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_LAST_LIQD_DT ICTBS_ACC_PR.LAST_LIQ_DT%TYPE;
    L_BILLING_PROD ICTBS_ACC_PR.BILLING_PROD%TYPE;
    L_NO_DATA_FLG  BOOLEAN := FALSE;
    L_AC_OPEN_DT   DATE;
    L_COUNT        NUMBER := 0;

  BEGIN
    DBG('inside ACCOUNT-OPENING ');

    SELECT COUNT(*)
      INTO L_COUNT
      FROM ICTMS_PR_CHG_ACLASS
     WHERE ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
       AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;

    IF L_COUNT > 0 THEN
      BEGIN
        BEGIN
          DELETE FROM ICTBS_ACC_ACTION
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND TBL_NAME = 'ACCOUNT-OPENING'
             AND KEY_VAL = 'ACCOUNT-OPENING';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('INSIDE OTHERS OF DELETE FROM ICTBS_ACC_ACTION-->' ||
                SQLERRM);
        END;

        INSERT INTO ICTBS_ACC_ACTION
          (BRN,
           TBL_NAME,
           KEY_VAL,
           ACTION,
           NEW_VAL,
           STATUS,
           ACC,
           PROD,
           AUTH_STAT,
           BRN_DATE,
           NODE)
        VALUES
          (P_BRN,
           'ACCOUNT-OPENING',
           'ACCOUNT-OPENING',
           'A',
           1,
           'U',
           P_ACC,
           '',
           'A',
           GLOBAL.APPLICATION_DATE,
           GLOBAL.NODE);

        DBG('RECORD INSERTED-->' || SQL%ROWCOUNT);

        BEGIN
          DELETE FROM ICTBS_CHG_VAL
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND ELEM_TYPE = 'ACCOUNT-OPENING'
             AND ELEM = 'ACCOUNT-OPENING';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('INSIDE OTHERS OF DELETE FROM ICTB_CHG_VAL-->' || SQLERRM);
        END;

        FOR I IN PRODCLASS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY) LOOP
          L_AC_OPEN_DT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
          DBG('l_ac_open_dt-->' || L_AC_OPEN_DT);

          INSERT INTO ICTBS_CHG_VAL
            (BRN, ACC, ELEM_VAL, ELEM_TYPE, ITM_DT, ELEM, PROD)
          VALUES
            (P_BRN,
             P_ACC,
             1,
             'ACCOUNT-OPENING',
             L_AC_OPEN_DT,
             'ACCOUNT-OPENING',
             I.PRODUCT_CODE);

          INSERT INTO ICTBS_ACC_PR
            (BRN,
             ACC,
             CCY,
             ACLASS,
             AC_CLASS_TYPE,
             BILLING_PROD,
             HAS_PROBLEMS,
             FIRST_CALC_DT,
             GC_MAP_DT,
             NEXT_LIQ_DT,
             NEXT_SCHD_LIQ_DT,
             NEXT_CALC_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             STOP_IC,
             TAX_PRODUCT,
             PROCESS,
             PROD,
             PROD_TYPE)

          VALUES
            (P_BRN,
             P_ACC,
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
             'O',
             'N',
             'N',
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             L_AC_OPEN_DT,
             'N',
             'N',
             'N',
             1,
             I.PRODUCT_CODE,
             'C');
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('OTHERS OF pr_account_opening' || SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
          RETURN FALSE;
      END;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('OTHERS OF pr_account_opening OUTSIDE LOOP' || SQLERRM);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-UPCA0033', '');
      RETURN FALSE;
  END;

  FUNCTION FN_POSTUPLD_VALDN(P_FUNCTION_ID IN VARCHAR2,
                             P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ACTION_CODE IN VARCHAR2,
                             P_SOURCE      IN VARCHAR2) RETURN BOOLEAN IS
    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_REC_CUSTACC   STTMS_CUST_ACCOUNT%ROWTYPE;
    L_PKEY          VARCHAR2(1000);
    L_ERR_CODE      VARCHAR2(400);
    L_CURRVAL       NUMBER;

    L_DCD VARCHAR2(1);

  BEGIN
    DBG('Inside fn_postupld_valdn');
    DBG('Action: ' || P_ACTION_CODE);
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('p_stdcusac.v_cstbs_ui_columns.char_field5==>');
    DBG(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
    DBG('***********************************');

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      DBG('AUTH action');

      SELECT *
        INTO L_REC_CUSTACC
        FROM STTMS_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

      DBG('Calling upld for AUTH');
      IF NOT FN_AUTH_UPLD(P_FUNCTION_ID, L_REC_CUSTACC) THEN
        DBG('fn_auth_upld has returned false');
        RETURN FALSE;
      END IF;

      DBG('AUTH action returning true');
      RETURN TRUE;
    END IF;

    SELECT AC_CLASS_TYPE, DUAL_CCY_DEPOSIT
      INTO L_AC_CLASS_TYPE, L_DCD
      FROM STTMS_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                    G_SUBSYSTEM_TY_FLDS) THEN
      DBG('fn_parse_subsysstats has returned false');
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      DBG('Calling fn_insert_custacseq');
      IF NOT
          FN_INSERT_CUSTACSEQ(P_FUNCTION_ID,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
        DBG('fn_insert_custacseq has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('MIS Stat: ' || G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);
    IF G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT <> 'U' THEN
      DBG('Simulating mipks_referral.fn_get_acc_default');
      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32 := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD33 := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      IF NOT STPKS_STDCUSAC_UTILS_0.FN_PICKUP_MIS(P_FUNCTION_ID,
                                                  P_STDCUSAC.TY_MICACCTM,
                                                  TRUE,

                                                  FALSE)

       THEN

        DBG('fn_pickup_mis has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('MIS Stat: ' || G_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);

    IF P_ACTION_CODE = 'NEW' THEN
      DBG('Calling cepkss.fn_post_update_account for NEW');
      IF NOT CEPKSS.FN_POST_UPDATE_ACCOUNT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                           'NEW',
                                           L_ERR_CODE) THEN
        DBG('Function cepkss.Fn_Post_Update_account returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
        RETURN FALSE;
      END IF;

      SELECT ACSQ_STTB_ACCOUNT.CURRVAL INTO L_CURRVAL FROM DUAL;
      L_PKEY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE ||
                TO_CHAR(L_CURRVAL);

      UPDATE STTB_ACCOUNT
         SET AUTH_STAT = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT
       WHERE PKEY = L_PKEY;

      DBG('Inserting into bal_tov');

      P_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.CCY        := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.UTIL_AMOUNT  := 0;
      P_STDCUSAC.V_ACVWS_CRTUR_LMT_BAL.LIMIT_AMOUNT := 0;

      IF NOT FN_INSERT_ACCBAL_TOV(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('Failed while inerting into sttms_account_bal_tov');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('Calling cepkss.Fn_Post_Update_account for MODIFY');

      IF NOT CEPKSS.FN_POST_UPDATE_ACCOUNT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                           'MODIFY',
                                           L_ERR_CODE) THEN
        DBG('Function cepkss.Fn_Post_Update_account returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('l_ac_class_type: ' || L_AC_CLASS_TYPE);
    IF L_AC_CLASS_TYPE = 'Y' THEN
      DBG('Validating the deposits');
      IF NOT FN_VALIDATE_DEPOSITS(P_FUNCTION_ID,
                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                  L_DCD,
                                  L_AC_CLASS_TYPE) THEN
        DBG('fn_validate_deposits has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_postupld_valdn returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_postupld_valdn with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POSTUPLD_VALDN;

  FUNCTION FN_INSERT_REPLINES_DETAIL(P_FUNCTION_ID IN VARCHAR2,
                                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_STAT_COUNT NUMBER;
    L_SEQ_COUNT  NUMBER := 0;
  BEGIN
    DBG('Inside fn_Insert_replines_detail');

    BEGIN
      SELECT COUNT(1)
        INTO L_SEQ_COUNT
        FROM CSTBS_CUSTACSEQ
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND CUST_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        L_SEQ_COUNT := 0;
    END;
    IF L_SEQ_COUNT = 0 THEN

      DBG('Calling fn_insert_custacseq');
      IF NOT
          FN_INSERT_CUSTACSEQ(P_FUNCTION_ID,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
        DBG('fn_insert_custacseq has returned false');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('Validating the inserted lines');

    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INHERIT_REPORTING, 'N') = 'Y' OR
       STPKS_STDMCYAC_KERNEL.G_MULTI_CURRENCY_1 THEN
      DBG('INHERIT_REPORTING- is Y or g_multi_currency_1 is true');
      SELECT COUNT(*)
        INTO L_STAT_COUNT
        FROM ((SELECT STATUS,
                      DR_GL,
                      CR_GL,
                      DR_CB_LINE,
                      CR_CB_LINE,
                      DR_HO_LINE,
                      CR_HO_LINE
                 FROM STTM_ACCSTAT_REPLINES_DETAIL
                WHERE CUST_AC_NO =
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                  AND BRANCH_CODE =
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               MINUS
               SELECT STATUS,
                      DR_GL,
                      CR_GL,
                      DR_CB_LINE,
                      CR_CB_LINE,
                      DR_HO_LINE,
                      CR_HO_LINE
                 FROM STTM_ACCOUNT_CLASS_STATUS
                WHERE ACCOUNT_CLASS =
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS) MINUS
              (SELECT STATUS,
                      DR_GL,
                      CR_GL,
                      DR_CB_LINE,
                      CR_CB_LINE,
                      DR_HO_LINE,
                      CR_HO_LINE
                 FROM STTM_ACCOUNT_CLASS_STATUS
                WHERE ACCOUNT_CLASS =
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
               MINUS
               SELECT STATUS,
                      DR_GL,
                      CR_GL,
                      DR_CB_LINE,
                      CR_CB_LINE,
                      DR_HO_LINE,
                      CR_HO_LINE
                 FROM STTM_ACCSTAT_REPLINES_DETAIL
                WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                  AND BRANCH_CODE =
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE));
      DBG('l_stat_count -->' || L_STAT_COUNT);

      IF L_STAT_COUNT > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-189', '');
      END IF;

      DELETE STTM_ACCSTAT_REPLINES_DETAIL
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      DBG(' outiside   if coz dr_gl or cr_gl is NOTTT null');
      DBG('inserting the data in replines detail table and inherit reporting is YES ');
      FOR I IN (SELECT STATUS,
                       DR_GL,
                       CR_GL,
                       DR_CB_LINE,
                       CR_CB_LINE,
                       DR_HO_LINE,
                       CR_HO_LINE
                  FROM STTMS_ACCOUNT_CLASS_STATUS
                 WHERE ACCOUNT_CLASS =
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS) LOOP
        INSERT INTO STTM_ACCSTAT_REPLINES_DETAIL
          (CUST_AC_NO,
           BRANCH_CODE,
           STATUS,
           DR_GL,
           CR_GL,
           DR_CB_LINE,
           CR_CB_LINE,
           DR_HO_LINE,
           CR_HO_LINE)
        VALUES
          (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
           I.STATUS,
           I.DR_GL,
           I.CR_GL,
           I.DR_CB_LINE,
           I.CR_CB_LINE,
           I.DR_HO_LINE,
           I.CR_HO_LINE);
      END LOOP;
    END IF;

    DBG('fn_Insert_replines_detail returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_Insert_replines_detail with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_INSERT_REPLINES_DETAIL;

  FUNCTION FN_POST_UPDATE_TABLE(P_FUNCTION_ID IN VARCHAR2,
                                P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_STAT_LIST VARCHAR2(100);
    L_STAT_PROC CHAR;

  BEGIN
    DBG('Inside fn_post_update_table');

    DBG('Calling fn_Insert_replines_detail');
    IF NOT FN_INSERT_REPLINES_DETAIL(P_FUNCTION_ID, P_STDCUSAC) THEN
      DBG('fn_Insert_replines_detail has returned false');
      RETURN FALSE;
    END IF;

    SELECT STATUS_PROCESSING_BASIS
      INTO L_STAT_PROC
      FROM STTM_BRANCH
     WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    DBG('Status processing_basis is ' || L_STAT_PROC);
    IF L_STAT_PROC = 'G' THEN
      FOR REC IN (SELECT DISTINCT STATUS
                    FROM STTM_ACCOUNT_CLASS_STATUS
                   WHERE ACCOUNT_CLASS =
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                     AND STATUS NOT IN
                         (SELECT STATUS
                            FROM STTM_ACCSTAT_REPLINES_DETAIL
                           WHERE CUST_AC_NO =
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO)) LOOP
        L_STAT_LIST := L_STAT_LIST || REC.STATUS || ',';
      END LOOP;
      IF L_STAT_LIST IS NOT NULL THEN
        DBG('l_stat_list: ' || L_STAT_LIST);
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'LD-STS053',
                     SUBSTR(L_STAT_LIST, 1, LENGTH(L_STAT_LIST) - 1) || '~');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_post_update_table returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_post_update_table with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POST_UPDATE_TABLE;

  FUNCTION FN_UPLOAD(P_FUNCTION_ID IN VARCHAR2,
                     P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                     P_ACTION_CODE IN VARCHAR2,
                     P_SOURCE      IN VARCHAR2,
                     P_ERR_CODE    IN OUT VARCHAR2,
                     P_ERR_PARAMS  IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_ERR_CODE            VARCHAR2(400);
    L_ERR_PARAM           VARCHAR2(400);
    TOTAL_AMOUNT          NUMBER;
    L_INT_RATE            NUMBER;
    L_COUNT               NUMBER;
    L_RES                 VARCHAR2(400);
    L_NXT_DATE            ICTM_ACC.MATURITY_DATE%TYPE;
    PROD                  ICTM_PR_INT.PRODUCT_CODE%TYPE;
    L_PAYIN_TOTAL         ICTB_ENTRIES_HISTORY.AMT%TYPE := 0;
    P_STDCUSAC_1          STPKS_STDCUSAC_MAIN.TY_STDCUSAC := P_STDCUSAC;
    L_ACCOUNT_TYPE        STTMS_CUST_ACCOUNT.ACCOUNT_TYPE%TYPE;
    L_ACC_TANKED_STAT     STTM_CUST_ACCOUNT.ACC_TANKED_STAT%TYPE;
    L_MUDARABAH_ACC_CLASS STTM_ACCOUNT_CLASS.MUDARABAH_ACC_CLASS%TYPE;
    L_HOLTREATREQD        ICTM_BRANCH_PARAMETERS.HOLIDAY_TRTMT_REQD%TYPE;

    L_MONTH_END_DEP VARCHAR2(1);
    L_RESULT        VARCHAR2(1);
    L_ERROR         VARCHAR2(1);
    L_HOL_PREF      VARCHAR2(1);
    L_DATE          DATE;
    L_WRK_DAY       DATE;

    L_RECOMPUTE_MAT_DATE STTMS_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
    L_DEF_YEARS          STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_YEARS%TYPE;
    L_DEF_MONTHS         STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_MONTHS%TYPE;
    L_DEF_DAYS           STTMS_ACCOUNT_CLASS.DEFAULT_TENOR_DAYS%TYPE;
    L_WRY_DAY            DATE;
    L_MONTH_END_FLG      BOOLEAN := FALSE;

    L_TB_UDE_DATES DBMS_SQL.DATE_TABLE;
    L_CCY          VARCHAR2(3);

    L_HOL_MOV STTM_ACCOUNT_CLASS.HOLIDAY_MOVEMENT%TYPE;
    L_MESSAGE ERTB_MSGS.MESSAGE%TYPE;

    L_HOL_RES VARCHAR2(1000);

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    L_MATURITY_DATE      DATE;
    L_NEXT_MATURITY_DATE DATE;
    L_PREV_MAT_DT        DATE;

    L_LOV_COUNT NUMBER := 0;

    U_PRODUCT_CODE ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE;
    E_PRODUCT_CODE ICTMS_PR_INT_UDEVALS.PRODUCT_CODE%TYPE;

  BEGIN
    DBG('Inside fn_upload');
    PKG_SOURCE := P_SOURCE;

    DBG('p_stdcusac.v_sttms_cust_account.type_of_chq' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ);
    G_TYPE_OF_CHQ := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TYPE_OF_CHQ;
    DBG('g_type_of_chq after initializing  ' || G_TYPE_OF_CHQ);

    DBG('branch_code---->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    ICPKS_UTIL.PR_HOLIDAY_TREATMENT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                    L_HOLTREATREQD);
    DBG('holiday treatment is ' || L_HOLTREATREQD);

    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || ' Acc: ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

    DBG('#2 Diary count: ' ||
        P_STDCUSAC.TY_SICDIARY.V_SITMS_DIARY_MASTER.COUNT);
    IF P_STDCUSAC.TY_SICDIARY.V_SITMS_DIARY_MASTER.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_SICDIARY.V_SITMS_DIARY_MASTER.COUNT LOOP
        DBG('Instr no: ' || P_STDCUSAC.TY_SICDIARY.V_SITMS_DIARY_MASTER(I)
            .INSTRUCTION_NO);
      END LOOP;
    END IF;

    DBG('Going to call icpks_holiday.Fn_Get_maturity_date');

    BEGIN
      SELECT HOLIDAY_CALENDAR,
             MONTH_END_DEPOSIT,
             RECOMPUTE_MAT_DATE,
             NVL(DEFAULT_TENOR_YEARS, 0),
             NVL(DEFAULT_TENOR_MONTHS, 0),
             NVL(DEFAULT_TENOR_DAYS, 0),
             HOLIDAY_MOVEMENT
        INTO L_HOL_PREF,
             L_MONTH_END_DEP,
             L_RECOMPUTE_MAT_DATE,
             L_DEF_YEARS,
             L_DEF_MONTHS,
             L_DEF_DAYS,
             L_HOL_MOV
        FROM STTM_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Not a month end maturity deposit');
    END;
    IF NVL(P_STDCUSAC.V_ICTMS_ACC.DEP_TENOR_PREF, 'I') = 'L' THEN
      DBG('Recomputing maturity date again for : ' ||
          P_STDCUSAC.V_ICTMS_ACC.ACC);
      P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := L_DEF_YEARS;
      P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := L_DEF_MONTHS;
      P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := L_DEF_DAYS;
      P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE     := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                             NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                                 0) +
                                                             (NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                                  0) * 12)) +
                                                  NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                      0);

      DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
          P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
      DBG('p_stdcusac.v_ictms_acc.maturity_date-->' ||
          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
        L_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
          DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_MATURITY_DATE;
        END IF;

      END IF;

      DBG('maturity date recomputed as : ' ||
          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

    END IF;

    L_PREV_MAT_DT := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;

    IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL THEN
      DBG('Holiday movement' || L_HOL_MOV);
      DBG('Holiday calendar' || L_HOL_PREF);
      IF NOT ICPKS_HOLIDAY.FN_ISHOLIDAY(L_HOL_PREF,
                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                        L_HOL_RES,
                                        L_MESSAGE) THEN
        DBG('icpks_holiday.fn_isholiday has returned false');
      END IF;
      DBG('Maturity date is a' || L_HOL_RES);

      IF L_HOL_PREF IN ('L', 'C', 'B') AND L_HOL_MOV = 'H' AND
         L_HOL_RES = 'H' THEN
        DBG('Maturity date is a holiday as per the holiday treatment');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-MSC031',
                     P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('brn ovpks for IC-MSC031');
          OVPKSS.PR_APPENDTBL('IC-MSC031',
                              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        END IF;
      END IF;
    END IF;

    IF L_MONTH_END_DEP = 'Y' AND
       NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN

      DBG('Checking last working day of the account open date');
      IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT('L',
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                                L_WRK_DAY,
                                                L_ERROR) THEN

        DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
      END IF;

      IF L_WRK_DAY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE =
         LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN
        L_MONTH_END_FLG := TRUE;
      END IF;
    END IF;
    IF L_MONTH_END_FLG THEN
      DBG('Checking for month end deposit');
      IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE),
                                                L_NXT_DATE,
                                                L_ERROR) THEN

        DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <>
         LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-MSC022',
                     P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                     LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~');
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('brn ovpks for IC-MSC022');
          OVPKSS.PR_APPENDTBL('IC-MSC022',
                              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                              LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~');
        END IF;
      END IF;

      IF L_NXT_DATE <> LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
        IF L_NXT_DATE < LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IC-MSC009',
                       LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~' ||
                       L_NXT_DATE || '~');
          IF GWPKS_UTIL.G_FROM_BEAN THEN
            DBG('brn ovpks for IC-MSC009');
            OVPKSS.PR_APPENDTBL('IC-MSC009',
                                LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~' ||
                                L_NXT_DATE || '~');
          END IF;
        END IF;

      END IF;
    ELSE

      DBG('In Else part');

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

        IF NOT STPKSS_STDCUSAC_UTILS_CLUSTER.FN_UPLOAD(P_FUNCTION_ID,
                                                       P_STDCUSAC,
                                                       P_ACTION_CODE,
                                                       P_SOURCE,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_upload-');

          RETURN FALSE;
        END IF;

      END IF;

      IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                L_NXT_DATE,
                                                P_FUNCTION_ID) THEN
        DBG('icpks_holiday.fn_get_maturity_date has failed but continuing');
      END IF;

      DBG('The next date is:' || L_NXT_DATE || ' with maturity date:' ||
          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      IF NVL(L_NXT_DATE, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <>
         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
        IF NVL(L_NXT_DATE, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) >
           P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IC-MSC002',
                       P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                       L_NXT_DATE || '~');
          IF GWPKS_UTIL.G_FROM_BEAN THEN
            DBG('brn ovpks for IC-MSC002 2');
            OVPKSS.PR_APPENDTBL('IC-MSC002',
                                P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                L_NXT_DATE || '~');
          END IF;
        ELSE
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IC-MSC009',
                       P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                       L_NXT_DATE || '~');
          IF GWPKS_UTIL.G_FROM_BEAN THEN
            DBG('brn ovpks for IC-MSC009 3');
            OVPKSS.PR_APPENDTBL('IC-MSC009',
                                P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                                L_NXT_DATE || '~');
          END IF;
        END IF;
      END IF;
    END IF;

    IF NVL(L_NXT_DATE, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <>
       P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN

      IF P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE IS NOT NULL THEN
        DBG('Child TD is present, changing the dates in child td as maturity date in main TD is moved');
        DBG('Child TD int_start_date before : ' ||
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE);
        DBG('p_stdcusac.v_ictms_acc.maturity_date : ' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT.AC_OPEN_DATE  := L_NXT_DATE;
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE +
                                                                        (L_NXT_DATE -
                                                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.CHG_START_DATE     := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.CHG_START_DATE +
                                                                        (L_NXT_DATE -
                                                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MATURITY_DATE      := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.MATURITY_DATE +
                                                                        (L_NXT_DATE -
                                                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.NEXT_MATURITY_DATE := P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.NEXT_MATURITY_DATE +
                                                                        (L_NXT_DATE -
                                                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        DBG('Child TD int_start_date after : ' ||
            P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC.INT_START_DATE);
      END IF;
      IF NVL(L_NXT_DATE, P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) <=
         P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'IC-MSC003',
                     L_NXT_DATE || '~' ||
                     P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
        IF GWPKS_UTIL.G_FROM_BEAN THEN
          DBG('brn ovpks for IC-MSC003 4');
          OVPKSS.PR_APPENDTBL('IC-MSC003',
                              L_NXT_DATE || '~' ||
                              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE || '~');
        END IF;
      ELSE
        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(L_NXT_DATE,
                                                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      END IF;
    END IF;

    DBG('Years = ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 ||
        ', Months = ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 ||
        ', Days = ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53);
    DBG('p_Stdcusac.v_Ictms_Acc.Maturity_Date||l_prev_mat_dt--->' ||
        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' || L_PREV_MAT_DT);
    IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <> L_PREV_MAT_DT THEN

      IF NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) = 0 AND
         NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) = 0 THEN
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                      P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
      ELSE
        BEGIN
          WITH TTL_MONTHS AS
           (SELECT P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                   ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                              TRUNC(MONTHS_BETWEEN(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                   P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE))) RES,
                   TRUNC(MONTHS_BETWEEN(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                        P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE)) MON
              FROM DUAL)
          SELECT CASE
                   WHEN RES >= 0 THEN
                    TRUNC(MON / 12)
                   ELSE
                    TRUNC((MON - 1) / 12)
                 END YEARS,
                 CASE
                   WHEN RES >= 0 THEN
                    MOD(MON, 12)
                   ELSE
                    MOD(MON - 1, 12)
                 END MONTHS,
                 CASE
                   WHEN RES >= 0 THEN
                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                    ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE, MON)
                   ELSE
                    P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                    ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                               MON - 1)
                 END DAYS
            INTO P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53
            FROM TTL_MONTHS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed while changing default tenor, ' || SQLERRM);
        END;
      END IF;
    END IF;
    IF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' AND
       P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

        IF NOT STPKSS_STDCUSAC_UTILS_CLUSTER.FN_UPLOAD(P_FUNCTION_ID,
                                                       P_STDCUSAC,
                                                       P_ACTION_CODE,
                                                       P_SOURCE,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_upload-');

          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
                                                                    0) +
                                                                NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS,
                                                                    0) * 12) +
                                                     NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
                                                         0);

        DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
          L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
          END IF;

          IF L_NEXT_MATURITY_DATE <>
             P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
            DBG('Next maturity date change during cascade');
            PKG_CASCADE_NXTMATDT := 'Y';
          END IF;

        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

    ELSE
      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
    END IF;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

    DBG('Maturity_Date = ' || P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
    DBG('Next_Maturity_Date = ' ||
        P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
    DBG('Tenor = ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20);

    IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
       P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' THEN

      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

        IF NOT STPKSS_STDCUSAC_UTILS_CLUSTER.FN_UPLOAD(P_FUNCTION_ID,
                                                       P_STDCUSAC,
                                                       P_ACTION_CODE,
                                                       P_SOURCE,
                                                       P_ERR_CODE,
                                                       P_ERR_PARAMS,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA) THEN
          DBG('failed in   stpks_stdcusac_utils_cluster.fn_upload-');

          RETURN FALSE;
        END IF;
      END IF;
      IF NOT GLOBAL.G_SKIP_KERNEL THEN

        P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
                                                                    0) +
                                                                NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS,
                                                                    0) * 12) +
                                                     NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
                                                         0);

        DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('p_stdcusac.v_ictms_acc.next_maturity_date-->' ||
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
          L_NEXT_MATURITY_DATE := P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF L_NEXT_MATURITY_DATE <>
               P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE THEN
              DBG('Next maturity date change during cascade');
              PKG_CASCADE_NXTMATDT := 'Y';
            END IF;
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
          END IF;
        END IF;

      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;

    ELSE
      DBG('Setting next maturity date as null as roll tenor preference is set as account class tenor or autorollover is not selected');
      P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
      P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS    := NULL;
      P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS  := NULL;
      P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS   := NULL;
    END IF;
    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

    DBG('p_stdcusac.v_sttms_cust_account.account_class-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    SELECT AC_CLASS_TYPE, MUDARABAH_ACC_CLASS
      INTO L_ACCOUNT_TYPE, L_MUDARABAH_ACC_CLASS
      FROM STTM_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    DBG('p_action_code-->' || P_ACTION_CODE);
    DBG('Account Type' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE);
    DBG('p_Function_Id = ' || GWPKS_UTIL.PKG_FUNC);

    IF P_ACTION_CODE IN ('COMPUTE') AND L_ACCOUNT_TYPE = 'Y' AND
       NVL(L_MUDARABAH_ACC_CLASS, 'N') = 'Y' AND
       GWPKS_UTIL.PKG_FUNC IN ('IPTDMM') THEN
      IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT LOOP
          IF NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PERCENTAGE,
                 0) > 0 THEN
            DBG('Pay in Percentage--->' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_PERCENTAGE);
            P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := (P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT *
                                                                        NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                                                             .MULTIMODE_PERCENTAGE,
                                                                             0) / 100);
          END IF;
          L_PAYIN_TOTAL := L_PAYIN_TOTAL + NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_TDAMOUNT,
                                               0);
          DBG('TDAMT--->' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
              .MULTIMODE_TDAMOUNT);
        END LOOP;
      END IF;
      DBG('l_payin_total--->' || L_PAYIN_TOTAL);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1 := L_PAYIN_TOTAL;
    END IF;

    IF P_ACTION_CODE IN ('COMPUTE', 'TDCompute', 'NEW') AND
       L_ACCOUNT_TYPE = 'Y' THEN

      DBG('Entered');
      DBG('Pay in Count------>' ||
          P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
      IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT LOOP
          IF NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_PERCENTAGE,
                 0) > 0 THEN

            DBG(' p_stdcusac.v_Ictms_Tdpayin_Details.COUNT  ' ||
                P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
            DBG('i' || I);
            IF I = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT THEN
              P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT -
                                                                          L_PAYIN_TOTAL;
              DBG('amount ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDAMOUNT);
            ELSE

              DBG('Pay in Percentage--->' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PERCENTAGE);
              P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := (P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT *
                                                                          NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                                                               .MULTIMODE_PERCENTAGE,
                                                                               0) / 100);

              DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_PAYOPT ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PAYOPT);
              DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_TDOFFSET_CCY ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDOFFSET_CCY);
              IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_CCY = 'S' THEN
                SELECT CCY
                  INTO L_CCY
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_TDOFFSET_ACC
                   AND BRANCH_CODE = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_OFFSET_BRN;
              ELSE
                L_CCY := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
              END IF;
              DBG('l_ccy ' || L_CCY);
              IF NOT CYPKSS.FN_AMT_ROUND(L_CCY,
                                         P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT,
                                         P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT) THEN
                DBG('Failed in doing Round OFF of amount to offset currency');
              END IF;
              DBG('After Round OFF l_tdpayout_rec.redmamt  ' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDAMOUNT);
            END IF;

          END IF;
          L_PAYIN_TOTAL := L_PAYIN_TOTAL + NVL(P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_TDAMOUNT,
                                               0);
          DBG('TDAMT--->' || P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
              .MULTIMODE_TDAMOUNT);
        END LOOP;
      END IF;
      DBG('l_payin_total--->' || L_PAYIN_TOTAL);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1 := L_PAYIN_TOTAL;

      IF P_ACTION_CODE IN ('COMPUTE') THEN
        DBG('coming here11');
        DBG('open date--' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
        DBG('int_start_date--' || P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE <>
           P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
          P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
          IF NOT STPKS_STDCUSAC_UTILS_0.FN_POPDT(P_FUNCTION_ID, P_STDCUSAC) THEN
            DBG('failed in fn_popdt');
          END IF;
        END IF;
      END IF;

      DBG('CALLING CALC MATURITY AMOUNT');
      G_MAT_AMT_CALC := TRUE;

      IF NOT STPKS_STDCUSAC_KERNEL.FN_MATURITY_CALC(P_STDCUSAC,
                                                    L_INT_RATE,
                                                    TOTAL_AMOUNT,
                                                    L_TB_UDE_DATES,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAMS) THEN

        DBG('failed in populating maturity amount');
        RETURN FALSE;
      END IF;
      P_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE   := L_INT_RATE;
      P_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT := TOTAL_AMOUNT;

      G_MAT_AMT_CALC := FALSE;

      IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD57 = 'Y' AND
         P_SOURCE <> 'FLEXCUBE' THEN
        RETURN TRUE;
      END IF;

    END IF;

    DBG('Getting the subys stat');
    IF NOT
        STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                    P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                    G_SUBSYSTEM_TY_FLDS) THEN
      DBG('fn_parse_subsysstats has returned false');
      RETURN FALSE;
    END IF;

    DBG('Calling fn_validate_records' ||
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
    G_ERR_FLAG := 0;
    IF NOT FN_VALIDATE_RECORDS(P_SOURCE,
                               P_FUNCTION_ID,
                               P_STDCUSAC,
                               P_ACTION_CODE,
                               P_ERR_CODE,
                               P_ERR_PARAMS) THEN
      DBG('fn_validate_records has returned false');
      RETURN FALSE;
    END IF;

    DBG('Calling gipks_check.fn_call_gi_for_upload');
    IF NOT GIPKS_CHECK.FN_CALL_GI_FOR_UPLOAD(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                             1,
                                             1,
                                             'CS',
                                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                             'STACUPLD',
                                             L_ERR_CODE,
                                             L_ERR_PARAM) THEN
      DBG('gipks_check.fn_call_gi_for_upload has returned false');
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
      RETURN FALSE;
    END IF;

    DBG('Beginning the Validations for Population');
    IF NOT FN_POPULATE_RECORDS(P_FUNCTION_ID,
                               P_STDCUSAC,
                               P_ACTION_CODE,
                               P_SOURCE) THEN
      DBG('fn_populate_records has returned false');
      RETURN FALSE;
    END IF;

    DBG('p_stdcusac.v_ictms_acc_pr.count ' ||
        P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
    IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
      DBG('p_stdcusac.v_ictms_acc_effdt.count ' ||
          P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
      DBG('p_stdcusac.v_ictms_acc_udevals.count ' ||
          P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
      FOR I IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
        IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
          FOR J IN P_STDCUSAC.V_ICTMS_ACC_EFFDT.FIRST .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.LAST LOOP
            IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
              FOR K IN P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                DBG('p_stdcusac.v_ictms_acc_udevals(k).ude_id ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                    .UDE_ID);
                DBG('p_stdcusac.v_sttms_cust_account.CCY ' ||
                    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
                DBG('p_stdcusac.v_ictms_acc_udevals(k).Prod ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).PROD);
                DBG('p_stdcusac.V_ictms_acc_udevals(k).ude_eff_dt ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                    .UDE_EFF_DT);
                DBG('p_stdcusac.v_ictms_acc_udevals(k).ude_value ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                    .UDE_VALUE);
                DBG('p_stdcusac.v_ictms_acc_udevals(k).ude_variance ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                    .UDE_VARIANCE);
                DBG('p_stdcusac.V_ictms_acc_udevals(k).brn ' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).BRN);

                DBG('Goin to validate the ude ids for the effective date :' || P_STDCUSAC.V_ICTMS_ACC_EFFDT(J)
                    .UDE_EFF_DT);
                DBG('p_Stdcusac.v_ictms_acc_udevals -> ude id' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                    .UDE_ID);
                SELECT COUNT(*)
                  INTO L_LOV_COUNT
                  FROM (SELECT DISTINCT U.UDE_ID, U.UDE_VALUE, U.RATE_CODE
                          FROM ICTMS_PR_INT_UDEVALS U, ICTM_PR_INT_EFFDT E
                         WHERE U.BRANCH_CODE = (SELECT DECODE((SELECT COUNT(*)
                                                                FROM ICTMS_PR_INT_EFFDT
                                                               WHERE BRANCH_CODE =
                                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                                                                 AND ACLASS =
                                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                                                 AND CCY_CODE =
                                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                                                 AND PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                                                                 AND RECORD_STAT = 'O'
                                                                 AND AUTH_STAT = 'A'),
                                                              0,
                                                              'ALL',
                                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE)
                                                  FROM DUAL)
                           AND U.ACLASS =
                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                           AND U.CCY_CODE =
                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                           AND U.PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                           AND U.UDE_EFF_DT =
                               (SELECT MAX(U1.UDE_EFF_DT)
                                  FROM ICTMS_PR_INT_UDEVALS U1
                                 WHERE U1.BRANCH_CODE =
                                       (SELECT DECODE((SELECT COUNT(*)
                                                        FROM ICTMS_PR_INT_EFFDT
                                                       WHERE BRANCH_CODE =
                                                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                                                         AND ACLASS =
                                                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                                         AND CCY_CODE =
                                                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                                         AND PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                                                         AND RECORD_STAT = 'O'
                                                         AND AUTH_STAT = 'A'),
                                                      0,
                                                      'ALL',
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE)
                                          FROM DUAL)
                                   AND U1.ACLASS = U.ACLASS
                                   AND U1.CCY_CODE = U.CCY_CODE
                                   AND U1.PRODUCT_CODE = U.PRODUCT_CODE
                                   AND U1.UDE_EFF_DT <= P_STDCUSAC.V_ICTMS_ACC_EFFDT(J)
                                      .UDE_EFF_DT)
                           AND U.BRANCH_CODE = E.BRANCH_CODE
                           AND U.ACLASS = E.ACLASS
                           AND U.CCY_CODE = E.CCY_CODE
                           AND U.PRODUCT_CODE = E.PRODUCT_CODE
                           AND E.RECORD_STAT = 'O'
                           AND E.AUTH_STAT = 'A')
                 WHERE UDE_ID = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID;
                DBG('l_lov_count count got as :' || L_LOV_COUNT);

                FOR M IN (SELECT U_PR_CD, E_PR_CD
                            FROM (SELECT DISTINCT U.UDE_ID,
                                                  U.PRODUCT_CODE U_PR_CD,
                                                  E.PRODUCT_CODE E_PR_CD
                                    FROM ICTMS_PR_INT_UDEVALS U,
                                         ICTM_PR_INT_EFFDT    E
                                   WHERE U.BRANCH_CODE =
                                         (SELECT DECODE((SELECT COUNT(*)
                                                          FROM ICTMS_PR_INT_EFFDT
                                                         WHERE BRANCH_CODE =
                                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                                                           AND ACLASS =
                                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                                           AND CCY_CODE =
                                                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                                           AND PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                                                           AND RECORD_STAT = 'O'
                                                           AND AUTH_STAT = 'A'),
                                                        0,
                                                        'ALL',
                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE)
                                            FROM DUAL)
                                     AND U.ACLASS =
                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                     AND U.CCY_CODE =
                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                     AND U.PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                                     AND U.UDE_EFF_DT =
                                         (SELECT MAX(U1.UDE_EFF_DT)
                                            FROM ICTMS_PR_INT_UDEVALS U1
                                           WHERE U1.BRANCH_CODE =
                                                 (SELECT DECODE((SELECT COUNT(*)
                                                                  FROM ICTMS_PR_INT_EFFDT
                                                                 WHERE BRANCH_CODE =
                                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                                                                   AND ACLASS =
                                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                                                   AND CCY_CODE =
                                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                                                   AND PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
                                                                   AND RECORD_STAT = 'O'
                                                                   AND AUTH_STAT = 'A'),
                                                                0,
                                                                'ALL',
                                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE)
                                                    FROM DUAL)
                                             AND U1.ACLASS = U.ACLASS
                                             AND U1.CCY_CODE = U.CCY_CODE
                                             AND U1.PRODUCT_CODE =
                                                 U.PRODUCT_CODE
                                             AND U1.UDE_EFF_DT <= P_STDCUSAC.V_ICTMS_ACC_EFFDT(J)
                                                .UDE_EFF_DT)
                                     AND U.BRANCH_CODE = E.BRANCH_CODE
                                     AND U.ACLASS = E.ACLASS
                                     AND U.CCY_CODE = E.CCY_CODE
                                     AND E.RECORD_STAT = 'O'
                                     AND E.AUTH_STAT = 'A')
                           WHERE UDE_ID = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                .UDE_ID) LOOP
                  DBG('U_PRODUCT_CODE-' || M.U_PR_CD || '-E_PRODUCT_CODE-' ||
                      M.E_PR_CD);
                  IF M.U_PR_CD = M.E_PR_CD THEN

                    IF L_LOV_COUNT = 0 THEN
                      DBG('Invalid Value For The Field  :UDE_ID:' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                          .UDE_ID);
                      PR_LOG_ERROR(P_FUNCTION_ID,
                                   PKG_SOURCE,
                                   'ST-VALS-093',
                                   P_STDCUSAC.V_ICTMS_ACC_PR(I)
                                   .PROD || '~' || P_STDCUSAC.V_ICTMS_ACC_EFFDT(J)
                                   .UDE_EFF_DT || '~' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                   .UDE_ID || '~;');
                    END IF;

                  END IF;
                END LOOP;
                IF NOT ICPKS_UTIL.FN_VALIDATE_MIN_MAX_UDE(P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .UDE_ID,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).PROD,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .UDE_EFF_DT,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .RATE_CODE,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .TD_RATE_CODE,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .UDE_VALUE,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                          .UDE_VARIANCE,
                                                          P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).BRN,
                                                          'FLEXCUBE',
                                                          P_FUNCTION_ID,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
                  DBG('Failed in Min Max validation');
                  RETURN FALSE;
                END IF;

                IF NOT
                    ICPKS_UTIL.FN_VALIDATE_MIN_MAX_VARIANCE(P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                            .UDE_ID,
                                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                            P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).PROD,
                                                            P_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                            .UDE_VARIANCE,
                                                            'FLEXCUBE',
                                                            P_FUNCTION_ID,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                  DBG('Failed in Min Max Variance validation');
                  RETURN FALSE;
                END IF;

              END LOOP;
            END IF;
          END LOOP;
        END IF;
      END LOOP;
    END IF;

    DBG('fn_upload returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_upload with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_UPLOAD;

  FUNCTION FN_VALIDATE_OFFSETDET(P_FUNCTION_ID   IN VARCHAR2,
                                 P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_STDCUSAC      IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)

   RETURN BOOLEAN IS

  BEGIN
    DBG('Inside fn_validate_offsetdet');
    DBG('Once auth: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
    IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') = 'Y' THEN
      IF (P_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN <>
         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.OFFSET_BRN OR
         P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC <>
         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_OFFSET_ACC OR
         P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT <>
         P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT) THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TD-002', '');
        RETURN FALSE;
      END IF;
    END IF;
    DBG('fn_validate_offsetdet returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_offsetdet with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_OFFSETDET;

  FUNCTION FN_VALIDATE_TOD_DETAILS(P_FUNCTION_ID IN VARCHAR2,
                                   P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS

  BEGIN

    DBG('p_function_id' || P_FUNCTION_ID);
    DBG('coming inside');
    DBG('p_stdcusac.v_sttm_account_tod_renew.renew_flag' ||
        P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_FLAG || 'TOD_LIMIT' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT);
    DBG('p_stdcusac.v_sttm_account_tod_renew.renew_unit' ||
        P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_UNIT || 'DAYS' ||
        P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_DAYS);

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT IS NULL OR
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT = 0 THEN
      IF P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_FLAG = 'Y' OR
         P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_DAYS IS NOT NULL OR
         P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_UNIT IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-223', '');
        DBG('coming insidffffe');
      END IF;
    END IF;
    IF P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_FLAG = 'Y' THEN
      IF P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_UNIT = 'D' AND
         P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_DAYS > 366 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-220', '');
        RETURN FALSE;
      ELSIF P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_UNIT = 'M' AND
            P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_DAYS > 12 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-221', '');
        RETURN FALSE;
      ELSIF P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_UNIT IS NULL OR
            P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.RENEW_DAYS IS NULL OR
            P_STDCUSAC.V_STTM_ACCOUNT_TOD_RENEW.NEXT_RENEW_LIMIT IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-222', '');
        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_offsetdet with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_TOD_DETAILS;

  FUNCTION FN_VALIDATE_TRADE_EXPIRY(P_FUNCTION_ID IN VARCHAR2,
                                    P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    CURSOR CR_CON_CHG_ACC IS
      SELECT CONSOL_CHG_ACC
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_NO IN
             (SELECT CUST_NO
                FROM STTM_CUST_ACCOUNT
               WHERE BRANCH_CODE =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
  BEGIN
    FOR EACHREC IN CR_CON_CHG_ACC LOOP
      IF EACHREC.CONSOL_CHG_ACC !=
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CONSOL_CHG_ACC THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-222', '');
        RETURN FALSE;
      END IF;
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_offsetdet with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_TRADE_EXPIRY;

  FUNCTION FN_RDAMT(P_FROM_DATE          IN DATE,
                    P_TO_DATE            IN DATE,
                    P_RD_INSTALLMENT_AMT IN ICTM_ACC.RD_INSTALLMENT_AMT%TYPE,
                    P_RD_SCHEDULE_YEARS  IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE,
                    P_RD_SCHEDULE_MONTHS IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE,
                    P_RD_SCHEDULE_DAYS   IN STTM_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE,
                    P_ICTM_ACC           IN OUT ICTM_ACC%ROWTYPE,
                    P_TOTAL_AMOUNT       IN OUT NUMBER) RETURN BOOLEAN IS
    L_MAX_DATE NUMBER := 0;
  BEGIN

    DBG('frm_date' || P_FROM_DATE);
    DBG('to_date' || P_TO_DATE);
    DBG('p_ICTM_ACC.Rd_Pay_Schdt : ' || P_ICTM_ACC.RD_PAY_SCHDT);

    WHILE (P_ICTM_ACC.RD_PAY_SCHDT <= P_TO_DATE AND L_MAX_DATE = 0) LOOP
      P_TOTAL_AMOUNT := P_TOTAL_AMOUNT + NVL(P_RD_INSTALLMENT_AMT, 0);
      DBG('Total Amount' || P_TOTAL_AMOUNT);
      DBG('rd_installment_amt' || P_RD_INSTALLMENT_AMT);

      BEGIN
        INSERT INTO ICTBS_INT_LIQ_DETAILS
          (ACCOUNT_NUMBER, BRANCH_CODE, FROM_DATE, TO_DATE, LIQ_AMT)
        VALUES

          (P_ICTM_ACC.ACC,
           P_ICTM_ACC.BRN,
           P_ICTM_ACC.RD_PAY_SCHDT,
           P_ICTM_ACC.RD_PAY_SCHDT,
           P_TOTAL_AMOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Insert Failed For RD');
      END;

      IF (NVL(P_RD_SCHEDULE_YEARS, 0) + NVL(P_RD_SCHEDULE_MONTHS, 0) +
         NVL(P_RD_SCHEDULE_DAYS, 0)) = 0 THEN
        DBG('Not exiting here will lead to infinite loop');
        EXIT;
      END IF;

      P_ICTM_ACC.RD_PAY_SCHDT := ADD_MONTHS(NVL(P_ICTM_ACC.RD_PAY_SCHDT,
                                                P_ICTM_ACC.INT_START_DATE),
                                            12 * NVL(P_RD_SCHEDULE_YEARS, 0) +
                                            NVL(P_RD_SCHEDULE_MONTHS, 0)) +
                                 NVL(P_RD_SCHEDULE_DAYS, 0);
      DBG('Schedule date : ' || P_ICTM_ACC.RD_PAY_SCHDT);

    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_rdamt with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_RDAMT;

  PROCEDURE PR_CALC_MATURITY(P_BRN          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                             P_ACC          IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                             P_PRODUCT_CODE IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                             P_TOTAL_AMOUNT OUT NUMBER,
                             P_FUNCTION_ID  IN VARCHAR2 DEFAULT 'STDCUSAC',
                             P_FLAG         IN VARCHAR2 DEFAULT 'N',
                             P_WRK_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC DEFAULT NULL) AS

    L_RD_SCHEDULE_DAYS   STTM_ACCOUNT_CLASS.RD_SCHEDULE_DAYS%TYPE := 0;
    L_RD_SCHEDULE_MONTHS STTM_ACCOUNT_CLASS.RD_SCHEDULE_MONTHS%TYPE := 0;
    L_RD_SCHEDULE_YEARS  STTM_ACCOUNT_CLASS.RD_SCHEDULE_YEARS%TYPE := 0;

    L_TOTAL_AMOUNT NUMBER := 0;
    L_INT_AMOUNT   NUMBER;
    L_DEBT_AMOUNT  NUMBER;
    L_FROM_DATE    DATE;
    L_TO_DATE      DATE;
    L_ACC_PR       ICTBS_ACC_PR%ROWTYPE;
    L_ICTM_PR_INT  ICTM_PR_INT%ROWTYPE;
    L_ICTM_ACC     ICTM_ACC%ROWTYPE;
    L_FLAG         NUMBER := 0;
    L_PAYOUT_COUNT NUMBER := 0;
    L_RD_FLAG      NUMBER := 0;
    L_FROM_DATE1   DATE;
    L_TO_DATE1     DATE;
    L_ERR_CODE     VARCHAR2(15);
    L_ERR_PARAM    VARCHAR2(400);

    L_COUNT      NUMBER := 1;
    L_TAX_AMOUNT NUMBER;
    L_TOTAL_TAX  NUMBER := 0;
    L_TOTAL_INT  NUMBER := 0;
    L_TEMP       NUMBER;
    L_INT_RATE   NUMBER;

    L_CURRENT_AMOUNT NUMBER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_MUDARABAH_ACCOUNTS STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS%TYPE;
    L_NO_OF_STREAM       PLS_INTEGER := CSPKS_PARALLEL_STREAM.FN_STREAM_COUNT('STDCUSAC',
                                                                              P_BRN);
    L_SEQ_NO             CSTB_CUSTACSEQ.SEQ_NO%TYPE := 1;
    L_FUNC_ID            VARCHAR2(10);
  BEGIN

    BEGIN

      DEBUG.PR_DEBUG('IC',
                     'Inside PR_CALC_MATURITY' || '~' ||
                     P_WRK_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);

      IF L_NO_OF_STREAM > 1 THEN
        BEGIN
          SELECT NVL(SEQ_NO, 1)
            INTO L_SEQ_NO
            FROM CSTB_CUSTACSEQ
           WHERE BRANCH_CODE = P_BRN
             AND CUST_AC_NO = P_ACC;
        EXCEPTION
          WHEN OTHERS THEN
            L_SEQ_NO := 1;
        END;
      END IF;
      DBG('l_seqno: ' || L_SEQ_NO);
      ICPKS_PARTITION_INFO.G_THIS_PART := L_SEQ_NO;

      IF NOT ICPKS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_BRN,
                                                P_ACC,
                                                L_ERR_CODE,
                                                L_ERR_PARAM) THEN
        DBG('err in resolution maintenance :' || L_ERR_CODE || '~' ||
            L_ERR_PARAM);

      END IF;
      DBG('Going to call ICPKS_UDE.PR_MAKE_UDE_ROW');

      ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);

      SAVEPOINT MAT_AMT_CALC1;

      DBG('P_BRN' || P_BRN);
      DBG('P_ACC' || P_ACC);
      DBG('p_product_code' || P_PRODUCT_CODE);

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS IS NULL THEN
        BEGIN
          SELECT MUDARABAH_ACCOUNTS
            INTO L_MUDARABAH_ACCOUNTS
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_ACC
             AND BRANCH_CODE = P_BRN;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED IN FETCHING MUDHARABAH ACCOUNT' || SQLERRM);
        END;
      ELSE
        L_MUDARABAH_ACCOUNTS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS;
      END IF;
      DBG('l_mudarabah_accounts' || L_MUDARABAH_ACCOUNTS);

      SELECT *
        INTO L_ACC_PR
        FROM ICTBS_ACC_PR
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD = P_PRODUCT_CODE;
      DBG('selected');
    EXCEPTION

      WHEN OTHERS THEN
        DBG(SQLERRM);
        DEBUG.PR_DEBUG('IC', 'Failed in Selecing from ICTBS_ACC_PR');
    END;
    DEBUG.PR_DEBUG('IC', 'Branch' || P_BRN);
    DEBUG.PR_DEBUG('IC', 'Account' || P_ACC);
    BEGIN
      SELECT *
        INTO L_ICTM_ACC
        FROM ICTM_ACC
       WHERE BRN = P_BRN
         AND ACC = P_ACC;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('IC', 'Failed in Selecing from ICTM_ACC');
    END;
    BEGIN

      SELECT *
        INTO L_ICTM_PR_INT
        FROM ICTM_PR_INT
       WHERE PRODUCT_CODE = P_PRODUCT_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('IC', 'Failed in Selecing from ICTM_PR_INT');

    END;

    IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') THEN
      L_FUNC_ID := CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID');
    ELSE
      L_FUNC_ID := 'X';
    END IF;

    IF (NVL(L_ICTM_PR_INT.PAYMENT_METHOD, 'D') = 'B' OR
       (CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'STDTDSIM')) THEN

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in Selecing from ictm_tdpayout_details');
      END;
      L_FROM_DATE := L_ICTM_ACC.INT_START_DATE;
      L_TO_DATE   := L_ICTM_ACC.INT_START_DATE;

      IF P_FUNCTION_ID = 'ICDREDMN' AND P_FLAG = 'N' THEN
        L_ICTM_ACC.MATURITY_DATE := GLOBAL.APPLICATION_DATE;
      END IF;

      L_ICTM_PR_INT.DAYS_BF_MTHEND := NVL(L_ICTM_PR_INT.DAYS_BF_MTHEND, 0);
      IF L_ICTM_PR_INT.LIQN_START_ACCOUNT = 'Y' AND
         L_ICTM_ACC.INT_START_DATE = LAST_DAY(L_ICTM_ACC.INT_START_DATE) THEN

        L_TO_DATE := ADD_MONTHS(L_TO_DATE + 1 +
                                L_ICTM_PR_INT.DAYS_BF_MTHEND,
                                12 * L_ICTM_PR_INT.LIQN_YEARS +
                                L_ICTM_PR_INT.LIQN_MONTHS) +
                     L_ICTM_PR_INT.LIQN_DAYS - L_ICTM_PR_INT.DAYS_BF_MTHEND - 1;
      ELSE
        L_TO_DATE := ADD_MONTHS(L_TO_DATE + L_ICTM_PR_INT.DAYS_BF_MTHEND,
                                12 * L_ICTM_PR_INT.LIQN_YEARS +
                                L_ICTM_PR_INT.LIQN_MONTHS) +
                     L_ICTM_PR_INT.LIQN_DAYS - L_ICTM_PR_INT.DAYS_BF_MTHEND;

        DBG('to date : ' || L_TO_DATE);
      END IF;

      L_TO_DATE := NVL(L_ACC_PR.NEXT_LIQ_DT, L_TO_DATE);
      DBG('to date : ' || L_TO_DATE);

      IF L_TO_DATE IS NULL OR L_TO_DATE >= L_ICTM_ACC.MATURITY_DATE - 1 THEN
        L_TO_DATE := L_ICTM_ACC.MATURITY_DATE - 1;
      END IF;

      IF L_ICTM_ACC.RD_FLAG = 'Y' THEN

        L_RD_SCHEDULE_DAYS   := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_DAYS,
                                    L_ICTM_ACC.RD_TAKEDOWN_DAYS);
        L_RD_SCHEDULE_MONTHS := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_MONTHS,
                                    L_ICTM_ACC.RD_TAKEDOWN_MONTHS);
        L_RD_SCHEDULE_YEARS  := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.RD_TAKEDOWN_YEARS,
                                    L_ICTM_ACC.RD_TAKEDOWN_YEARS);

        BEGIN

          L_FROM_DATE := GREATEST(L_ICTM_ACC.INT_START_DATE,
                                  L_ACC_PR.LAST_LIQ_DT + 1);
          BEGIN

            SELECT NVL(ACY_CURR_ACC_BAL, 0)
              INTO L_CURRENT_AMOUNT
              FROM STTM_ACCOUNT_BALANCE
             WHERE CUST_AC_BRN = L_ICTM_ACC.BRN
               AND CUST_AC_NO = L_ICTM_ACC.ACC;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_CURRENT_AMOUNT := 0;
          END;
          DBG('l_current_amount :' || NVL(L_CURRENT_AMOUNT, 0));
          L_TOTAL_AMOUNT := L_TOTAL_AMOUNT + NVL(L_CURRENT_AMOUNT, 0);

          IF NOT FN_RDAMT(L_FROM_DATE,
                          L_TO_DATE,
                          L_ICTM_ACC.RD_INSTALLMENT_AMT,
                          L_RD_SCHEDULE_YEARS,
                          L_RD_SCHEDULE_MONTHS,
                          L_RD_SCHEDULE_DAYS,

                          L_ICTM_ACC,
                          L_TOTAL_AMOUNT) THEN
            DBG('failed in the function call');
          END IF;

          DBG('success');

          DBG('l_total_amount' || L_TOTAL_AMOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('failed here');
        END;

      ELSE

        IF (NVL(L_ICTM_PR_INT.PAYMENT_METHOD, 'B') = 'D' OR
           NVL(L_MUDARABAH_ACCOUNTS, 'N') = 'Y')

         THEN

          BEGIN
            SELECT LIQ_AMT
              INTO L_TOTAL_AMOUNT
              FROM ICTBS_INT_LIQ_DETAILS I
             WHERE I.BRANCH_CODE = P_BRN
               AND I.ACCOUNT_NUMBER = P_ACC
               AND TO_DATE =
                   (SELECT MAX(TO_DATE)
                      FROM ICTBS_INT_LIQ_DETAILS J
                     WHERE I.BRANCH_CODE = J.BRANCH_CODE
                       AND I.ACCOUNT_NUMBER = J.ACCOUNT_NUMBER);
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IC', 'in Exception44');
              SELECT NVL(TD_AMOUNT, 0)
                INTO L_TOTAL_AMOUNT
                FROM ICTM_TD_DETAILS
               WHERE ACC = P_ACC
                 AND BRN = P_BRN;
          END;

        END IF;
      END IF;
      DEBUG.PR_DEBUG('IC',
                     ' L_ICTM_ACC.book_acc--->' || L_ICTM_ACC.BOOK_ACC);
      DEBUG.PR_DEBUG('IC', ' L_ICTM_ACC.acc--->' || L_ICTM_ACC.ACC);
      DEBUG.PR_DEBUG('IC', ' l_payout_count--->' || L_PAYOUT_COUNT);

      IF (L_ICTM_ACC.BOOK_ACC <> L_ICTM_ACC.ACC OR L_PAYOUT_COUNT > 0) AND

         STPKSS_STDCUSTD_KERNEL.G_SIMULATION <> 'Y' THEN

        IF L_ICTM_ACC.RD_FLAG = 'Y' THEN
          BEGIN
            IF NOT FN_RDAMT(L_FROM_DATE,
                            L_ICTM_ACC.MATURITY_DATE - 1,
                            L_ICTM_ACC.RD_INSTALLMENT_AMT,
                            L_RD_SCHEDULE_YEARS,
                            L_RD_SCHEDULE_MONTHS,
                            L_RD_SCHEDULE_DAYS,

                            L_ICTM_ACC,
                            L_TOTAL_AMOUNT) THEN
              DBG('failed in the function call INSIDE ');
            END IF;
            DBG('TOTAL AMOUNT IF CASA: ' || L_TOTAL_AMOUNT);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('FAILED!!!!');
          END;
        END IF;

        P_TOTAL_AMOUNT := L_TOTAL_AMOUNT;
      ELSE
        DBG('Inside Else');

        DEBUG.PR_DEBUG('IC', ' l_total_amount--->' || L_TOTAL_AMOUNT);
        DEBUG.PR_DEBUG('IC', ' l_to_date --->' || L_TO_DATE);
        DEBUG.PR_DEBUG('IC',
                       ' MATURITY DATE --->' || L_ICTM_ACC.MATURITY_DATE);

        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID := 1;
          L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
          L_TB_CLUSTER_DATA('l_total_amount') := L_TOTAL_AMOUNT;
          STPKS_STDCUSAC_UTILS_CLUSTER.PR_CALC_MATURITY(P_BRN,
                                                        P_ACC,
                                                        P_PRODUCT_CODE,
                                                        P_TOTAL_AMOUNT,
                                                        P_FUNCTION_ID,
                                                        P_FLAG,
                                                        P_WRK_STDCUSAC,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA);
        END IF;
        GLOBAL.PR_RESET_SKIP_KERNEL;

        BEGIN
          SELECT *
            INTO ICPKSS_CALC.G_ICTB_ACC_PR
            FROM ICTBS_ACC_PR
           WHERE ACC = P_ACC
             AND BRN = P_BRN
             AND PROD = P_PRODUCT_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('in exception ictbs_acc_pr');
        END;

        WHILE ((L_TO_DATE <= L_ICTM_ACC.MATURITY_DATE - 1) OR
              (L_FLAG = 1 AND L_TO_DATE = L_ICTM_ACC.MATURITY_DATE - 1)) AND
              L_FROM_DATE <= L_TO_DATE LOOP
          DELETE ICTW_MEMO_BOOKING WHERE ACC = L_ACC_PR.ACC;
          DEBUG.PR_DEBUG('IC', ' FROM DaTE --->' || L_FROM_DATE);
          DEBUG.PR_DEBUG('IC', ' TO DATE --->' || L_TO_DATE);
          ICPKS_FCJ_ICDCALAC.G_INDICATOR := 'ICDCALAC';
          ICPKS_TEST.PR_ICALC(L_ICTM_ACC.BRN,
                              L_ICTM_ACC.ACC,
                              P_PRODUCT_CODE,
                              L_FROM_DATE,
                              L_TO_DATE);

          SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
            INTO L_INT_AMOUNT
            FROM ICTW_MEMO_BOOKING
           WHERE BRN = L_ACC_PR.BRN
             AND ACC = L_ACC_PR.ACC
             AND PROD = L_ACC_PR.PROD;
          DEBUG.PR_DEBUG('IC', ' The interest amount is ' || L_INT_AMOUNT);

          SELECT NVL(SUM(DECODE(DRCR_IND, 'D', AMT, -AMT)), 0)
            INTO L_TAX_AMOUNT

            FROM ICTW_MEMO_BOOKING
           WHERE BRN = L_ACC_PR.BRN
             AND ACC = L_ACC_PR.ACC
             AND PROD = L_ACC_PR.PROD
             AND IS_TAX = 'Y';

          L_TOTAL_INT := L_TOTAL_INT + L_INT_AMOUNT + L_TAX_AMOUNT;
          L_TOTAL_TAX := L_TOTAL_TAX + L_TAX_AMOUNT;

          IF NVL(L_ICTM_PR_INT.PAYMENT_METHOD, 'D') = 'B' THEN
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).CHAR_FIELD3 := L_INT_AMOUNT;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).CHAR_FIELD1 := L_ICTM_ACC.BRN;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).CHAR_FIELD2 := L_ICTM_ACC.ACC;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).DATE_FIELD2 := L_TO_DATE + 1;

            IF L_ICTM_ACC.ACC = L_ICTM_ACC.BOOK_ACC THEN
              STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).CHAR_FIELD4 := L_TOTAL_AMOUNT +
                                                                                                L_INT_AMOUNT;
            ELSE
              STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(L_COUNT).CHAR_FIELD4 := L_TOTAL_AMOUNT;
            END IF;

          END IF;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.CHAR_FIELD54 := L_TOTAL_TAX;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.CHAR_FIELD49 := L_TOTAL_INT;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.NUM_FIELD25  := L_COUNT;
          L_COUNT                                                          := L_COUNT + 1;

          P_TOTAL_AMOUNT := L_TOTAL_AMOUNT;
          IF L_ICTM_ACC.ACC = L_ICTM_ACC.BOOK_ACC THEN
            L_TOTAL_AMOUNT := L_TOTAL_AMOUNT + (L_INT_AMOUNT);
            P_TOTAL_AMOUNT := L_TOTAL_AMOUNT;
          END IF;

          DEBUG.PR_DEBUG('IC', 'L_ICTM_ACC.ACC ' || L_ICTM_ACC.ACC);
          DEBUG.PR_DEBUG('IC',
                         'L_ICTM_ACC.BOOK_ACC ' || L_ICTM_ACC.BOOK_ACC);

          DEBUG.PR_DEBUG('IC', ' Total Amount ' || L_TOTAL_AMOUNT);
          DEBUG.PR_DEBUG('IC', ' l_payout_count ' || L_PAYOUT_COUNT);

          L_FROM_DATE1 := L_FROM_DATE;
          L_TO_DATE1   := L_TO_DATE;

          L_FROM_DATE := L_TO_DATE + 1;

          DBG('l_from_date' || L_FROM_DATE);

          IF L_ICTM_PR_INT.LIQN_START_ACCOUNT = 'Y' AND
             L_ICTM_ACC.INT_START_DATE =
             LAST_DAY(L_ICTM_ACC.INT_START_DATE) THEN
            L_TO_DATE := ADD_MONTHS(L_TO_DATE + 1 +
                                    NVL(L_ICTM_PR_INT.DAYS_BF_MTHEND, 0),
                                    12 * L_ICTM_PR_INT.LIQN_YEARS +
                                    L_ICTM_PR_INT.LIQN_MONTHS) +
                         L_ICTM_PR_INT.LIQN_DAYS -
                         NVL(L_ICTM_PR_INT.DAYS_BF_MTHEND, 0) - 1;
          ELSE

            L_TO_DATE := ADD_MONTHS(L_TO_DATE +
                                    NVL(L_ICTM_PR_INT.DAYS_BF_MTHEND, 0),
                                    12 * L_ICTM_PR_INT.LIQN_YEARS +
                                    L_ICTM_PR_INT.LIQN_MONTHS) +
                         L_ICTM_PR_INT.LIQN_DAYS -
                         NVL(L_ICTM_PR_INT.DAYS_BF_MTHEND, 0);
            DBG('to date : ' || L_TO_DATE);
          END IF;

          IF L_TO_DATE >= L_ICTM_ACC.MATURITY_DATE - 1 AND L_FLAG = 0 THEN
            L_TO_DATE := L_ICTM_ACC.MATURITY_DATE - 1;
            L_FLAG    := 1;
          END IF;
          DBG('l_to_date--->' || L_TO_DATE);
          DBG('L_ICTM_ACC.rd_pay_schdt--->' || L_ICTM_ACC.RD_PAY_SCHDT);

          IF L_ICTM_ACC.RD_FLAG = 'Y' THEN
            BEGIN
              IF NOT FN_RDAMT(L_FROM_DATE,
                              L_TO_DATE,
                              L_ICTM_ACC.RD_INSTALLMENT_AMT,
                              L_RD_SCHEDULE_YEARS,
                              L_RD_SCHEDULE_MONTHS,
                              L_RD_SCHEDULE_DAYS,

                              L_ICTM_ACC,
                              L_TOTAL_AMOUNT) THEN
                DBG('2failed in the function call');
              END IF;

              DBG('2TOT_AMT' || L_TOTAL_AMOUNT);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('2failed here');
            END;
          END IF;

          IF (L_ICTM_ACC.BOOK_ACC = L_ICTM_ACC.ACC OR L_PAYOUT_COUNT = 0) AND
             L_ICTM_ACC.RD_FLAG <> 'Y' THEN
            DEBUG.PR_DEBUG('IC', ' GOING TO INSERT' || P_TOTAL_AMOUNT);
            DEBUG.PR_DEBUG('IC',
                           ' GOING TO INSERT--FROM_DATE' || L_FROM_DATE1);
            DEBUG.PR_DEBUG('IC', ' GOING TO INSERT--TO_DATE' || L_TO_DATE1);

            IF NVL(L_ICTM_PR_INT.PAYMENT_METHOD, 'B') = 'D' OR
               NVL(L_MUDARABAH_ACCOUNTS, 'N') = 'Y' THEN

              BEGIN
                INSERT INTO ICTBS_INT_LIQ_DETAILS
                  (ACCOUNT_NUMBER,
                   BRANCH_CODE,
                   FROM_DATE,
                   TO_DATE,
                   LIQ_AMT)
                VALUES
                  (L_ACC_PR.ACC,
                   L_ACC_PR.BRN,
                   L_FROM_DATE1,
                   L_TO_DATE1,
                   L_TOTAL_AMOUNT);

              EXCEPTION
                WHEN OTHERS THEN
                  DBG('In when others of insert into ICTBS_INT_LIQ_DETAILS ' ||
                      SQLERRM);
              END;

            END IF;

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_FN_CALL_ID := 2;
              L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
              L_TB_CLUSTER_DATA('l_to_date1') := L_TO_DATE1;
              L_TB_CLUSTER_DATA('l_total_amount') := L_TOTAL_AMOUNT;
              L_TB_CLUSTER_DATA('l_int_amount') := L_INT_AMOUNT;
              L_TB_CLUSTER_DATA('l_tax_amount') := L_TAX_AMOUNT;

              STPKS_STDCUSAC_UTILS_CLUSTER.PR_CALC_MATURITY(P_BRN,
                                                            P_ACC,
                                                            P_PRODUCT_CODE,
                                                            P_TOTAL_AMOUNT,
                                                            P_FUNCTION_ID,
                                                            P_FLAG,
                                                            P_WRK_STDCUSAC,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA);
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;

          END IF;

          DBG('next maturity date AFTER HOLIDAY Is:' || L_TO_DATE);

        END LOOP;

      END IF;
      DBG('TOTAL_AMOUNT:' || P_TOTAL_AMOUNT);

    END IF;
    IF NVL(L_ICTM_PR_INT.PAYMENT_METHOD, 'B') = 'D' THEN

      P_TOTAL_AMOUNT := P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT;

      IF P_TOTAL_AMOUNT IS NULL THEN
        DBG('this is for rollover case, since p_Wrk_Stdcusac will not be pased getting the data from account table');
        BEGIN

          SELECT NVL(ACY_WITHDRAWABLE_BAL, 0) + NVL(ACY_BLOCKED_AMT, 0) +
                 NVL(ACY_ECA_BLOCKED_AMT, 0)
            INTO P_TOTAL_AMOUNT
            FROM STTM_ACCOUNT_BALANCE
           WHERE CUST_AC_BRN = L_ICTM_ACC.BRN
             AND CUST_AC_NO = L_ICTM_ACC.ACC;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_TOTAL_AMOUNT := 0;
        END;
      END IF;

      DBG('TOTAL_AMOUNT AFTER DISCOUNTED DEPOSIT CHECK: ' ||
          P_TOTAL_AMOUNT);

      STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(1).CHAR_FIELD3 := L_TOTAL_INT -
                                                                                  L_TOTAL_TAX;
      STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(1).CHAR_FIELD1 := L_ICTM_ACC.BRN;
      STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(1).CHAR_FIELD2 := L_ICTM_ACC.ACC;
      STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(1).DATE_FIELD2 := L_ICTM_ACC.INT_START_DATE;
      STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(1).CHAR_FIELD4 := P_TOTAL_AMOUNT;

    END IF;

    ROLLBACK TO MAT_AMT_CALC1;

    G_TOTAL_INTEREST := L_TOTAL_INT;
    G_TOTAL_TAX      := L_TOTAL_TAX;

    ICPKS_FCJ_ICDCALAC.G_INDICATOR := NULL;

  EXCEPTION
    WHEN OTHERS THEN
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-TDMAT-01', NULL);
      ROLLBACK TO MAT_AMT_CALC1;

  END PR_CALC_MATURITY;

  FUNCTION FN_RATEPICK(P_ACCNO      IN VARCHAR2,
                       P_BRN        IN VARCHAR2,
                       P_INT_RATE   IN NUMBER,
                       P_RP_RATE    OUT NUMBER,
                       P_ERR_CODE   IN OUT VARCHAR2,
                       P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_CCY          STTM_CUST_ACCOUNT.CCY%TYPE;
    L_FRM_NO       ICTMS_RULE_FRM_ELEMENTS.FRM_NO%TYPE;
    L_AC_TYPE      STTM_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_INT_RATE_UDE ICTMS_PR_INT.INT_RATE_UDE%TYPE;
    L_RULE         ICTMS_PR_INT.RULE%TYPE;
    RATE_VAL       VARCHAR2(30);
    L_PROD         ICTB_ACC_PR.PROD%TYPE;
  BEGIN
    DBG('Entered into Rate pickup function');
    DBG('Account No' || P_ACCNO);
    DBG('Branch' || P_BRN);
    DBG('p_int_rate' || P_INT_RATE);

    BEGIN
      SELECT ACCOUNT_TYPE, CCY
        INTO L_AC_TYPE, L_CCY
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACCNO;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_AC_TYPE := NULL;
        L_CCY     := NULL;
        DBG('No account found' || SQLERRM);
    END;
    DBG('l_ac_type' || L_AC_TYPE);
    IF L_AC_TYPE = 'Y' THEN
      BEGIN

        SELECT PROD
          INTO L_PROD
          FROM ICTB_ACC_PR
         WHERE ACC = P_ACCNO
           AND BRN = P_BRN;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_PROD := NULL;
      END;
      DBG('l_prod' || L_PROD);
      IF L_PROD IS NOT NULL THEN
        BEGIN
          SELECT RULE, INT_RATE_UDE
            INTO L_RULE, L_INT_RATE_UDE
            FROM ICTMS_PR_INT
           WHERE PRODUCT_CODE = L_PROD;
        EXCEPTION
          WHEN OTHERS THEN

            L_RULE         := NULL;
            L_INT_RATE_UDE := NULL;
        END;
      END IF;
      DBG('l_rule' || L_RULE);
      DBG('l_int_rate_ude' || L_INT_RATE_UDE);

      IF L_INT_RATE_UDE IS NOT NULL AND L_RULE IS NOT NULL THEN

        BEGIN
          SELECT A.FRM_NO
            INTO L_FRM_NO
            FROM ICTMS_RULE_FRM_ELEMENTS A, ICTM_RULE_FRM B
           WHERE A.RULE_ID = B.RULE_ID
             AND A.FRM_NO = B.FRM_NO
             AND A.RULE_ID = L_RULE
             AND A.ELEMENT_ID = L_INT_RATE_UDE
             AND B.BOOK_FLAG = 'B';
        EXCEPTION
          WHEN OTHERS THEN
            BEGIN
              SELECT A.FRM_NO
                INTO L_FRM_NO
                FROM ICTMS_RULE_FRM_ELEMENTS A, ICTM_RULE_FRM B
               WHERE A.RULE_ID = B.RULE_ID
                 AND A.FRM_NO = B.FRM_NO
                 AND A.RULE_ID = L_RULE
                 AND A.ELEMENT_ID = L_INT_RATE_UDE
                 AND B.BOOK_FLAG = 'B'
                 AND ROWNUM = 1;
            EXCEPTION
              WHEN OTHERS THEN
                L_FRM_NO := NULL;
            END;
        END;
        DBG('l_frm_no' || L_FRM_NO);
      END IF;

      IF L_FRM_NO IS NOT NULL THEN
        RATE_VAL := L_RULE || '/' || L_INT_RATE_UDE || '/' || L_FRM_NO;
        DBG('rate_val' || RATE_VAL);
        P_RP_RATE := ICPKS_UTIL.GETRP_RATE_AMT('R',
                                               P_BRN,
                                               P_ACCNO,
                                               L_PROD,
                                               RATE_VAL,
                                               L_CCY,
                                               0);
        DBG('p_rp_rate' || P_RP_RATE);

      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in Fn rate Function' || SQLERRM);
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      RETURN FALSE;
  END FN_RATEPICK;

  FUNCTION FN_PROJ_INTRATE(P_FUNCTION_ID  IN VARCHAR2,
                           P_BRN          IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_ACC          IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_PRODUCT_CODE IN ICTM_PR_INT.PRODUCT_CODE%TYPE)

   RETURN NUMBER IS
    L_INT_RATE      ICTB_UDEVALS.RATE%TYPE;
    L_BRNCD         VARCHAR2(25);
    L_CCY           STTM_CUST_ACCOUNT.CCY%TYPE;
    L_ACLASS        STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_ACC           STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_ACC_OPEN_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_INT_START_DT  ICTM_ACC.INT_START_DATE%TYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

    L_RP_RATE    NUMBER;
    L_ERR_CODE   ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAMS ERTBS_MSGS.MESSAGE%TYPE;
    L_RP_DTLS    COPKS_RP_PROCESSING.TY_REC_RP_DETAILS;

  BEGIN

    SELECT CCY, ACCOUNT_CLASS, AC_OPEN_DATE
      INTO L_CCY, L_ACLASS, L_ACC_OPEN_DATE
      FROM STTM_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ACC
       AND BRANCH_CODE = P_BRN;
    L_BRNCD := ICPKS_UDE.FN_GET_BRANCH(P_BRN,
                                       L_ACLASS,
                                       L_CCY,
                                       P_PRODUCT_CODE);
    DBG('Inside fn_proj_Intrate' || P_BRN || '--' || L_ACLASS || '--' ||
        L_CCY || '--' || P_PRODUCT_CODE || '--' || P_ACC);
    DBG('l_brncd--->' || L_BRNCD);

    SELECT INT_START_DATE
      INTO L_INT_START_DT
      FROM ICTM_ACC
     WHERE ACC = P_ACC
       AND BRN = P_BRN;

    DBG('l_int_start_dt--->' || L_INT_START_DT);

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;

      L_TB_CLUSTER_DATA('l_ccy') := L_CCY;
      L_TB_CLUSTER_DATA('l_aclass') := L_ACLASS;
      L_TB_CLUSTER_DATA('l_acc_open_date') := L_ACC_OPEN_DATE;
      L_TB_CLUSTER_DATA('l_int_start_dt') := L_INT_START_DT;
      L_TB_CLUSTER_DATA('l_brncd') := L_BRNCD;

      L_INT_RATE := STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_PROJ_INTRATE(P_FUNCTION_ID,
                                                                   P_BRN,
                                                                   P_ACC,
                                                                   P_PRODUCT_CODE,
                                                                   L_FN_CALL_ID,
                                                                   L_TB_CLUSTER_DATA);
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      BEGIN

        SELECT NVL((NVL(A1.AMT, 0) + NVL(A1.RATE, 0) +
                   NVL(A1.UDE_VARIANCE, 0)),
                   0)
          INTO L_INT_RATE
          FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
         WHERE A1.PROD = PR.PRODUCT_CODE
           AND A1.PROD = NVL(P_PRODUCT_CODE, A1.PROD)
           AND A1.COND_TYPE = 0
           AND A1.COND_KEY = P_BRN || P_ACC
           AND A1.UDE_ID = PR.INT_RATE_UDE
           AND A1.UDE_EFF_DT =
               (SELECT MAX(A2.UDE_EFF_DT)
                  FROM ICTB_UDEVALS A2

                 WHERE A2.PROD = A1.PROD
                   AND A2.COND_TYPE = A1.COND_TYPE

                   AND A2.COND_KEY = P_BRN || P_ACC
                   AND A2.UDE_ID = A1.UDE_ID
                   AND A2.UDE_EFF_DT <=
                       GREATEST(L_INT_START_DT, GLOBAL.APPLICATION_DATE));

        DBG('l_int_rate11-->' || L_INT_RATE);

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In No Data Found');
          L_INT_RATE := NULL;
      END;
      IF L_INT_RATE IS NULL THEN

        DBG('Cominh here111-->');

        BEGIN
          SELECT NVL((NVL(A1.AMT, 0) + NVL(A1.RATE, 0) +
                     NVL(A1.UDE_VARIANCE, 0)),
                     0)
            INTO L_INT_RATE
            FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
           WHERE A1.PROD = PR.PRODUCT_CODE
             AND A1.PROD = NVL(P_PRODUCT_CODE, A1.PROD)
             AND A1.COND_TYPE = 1
             AND A1.COND_KEY = L_BRNCD || L_ACLASS || L_CCY
             AND A1.UDE_ID = PR.INT_RATE_UDE
             AND A1.UDE_EFF_DT >= L_ACC_OPEN_DATE
             AND A1.UDE_EFF_DT =

                 (SELECT MAX(A2.UDE_EFF_DT)

                    FROM ICTB_UDEVALS A2

                   WHERE A2.PROD = A1.PROD
                     AND A2.COND_TYPE = A1.COND_TYPE

                     AND A2.COND_KEY = A1.COND_KEY
                     AND A2.UDE_ID = A1.UDE_ID);

          DBG('l_int_rate22-->' || L_INT_RATE);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed --->' || SQLERRM);
            L_INT_RATE := NULL;
        END;
      END IF;

      IF L_INT_RATE IS NOT NULL THEN
        IF NOT FN_RATEPICK(P_ACC,
                           P_BRN,
                           L_INT_RATE,
                           L_RP_RATE,
                           L_ERR_CODE,
                           L_ERR_PARAMS) THEN
          DBG('Failed in FN_RATEPICK function');
        ELSE
          COPKS_RP_PROCESSING.PR_GET_RP_DETAILS(L_RP_DTLS,
                                                L_ERR_CODE,
                                                L_ERR_PARAMS);
          DBG('Rp variance-->' || L_RP_RATE || 'Actual int rate' ||
              L_INT_RATE);

          DBG('VARIANCE TYPE-->' || L_RP_DTLS.P_VAR_TYPE);
          IF L_RP_DTLS.P_VAR_TYPE IS NOT NULL THEN
            IF L_RP_DTLS.P_VAR_TYPE = 'F' THEN
              L_INT_RATE := NVL(L_RP_RATE, 0);
            ELSIF L_RP_DTLS.P_VAR_TYPE = 'P' THEN
              L_INT_RATE := L_INT_RATE +
                            (L_INT_RATE * (NVL(L_RP_RATE, 0) / 100));

            ELSIF L_RP_DTLS.P_VAR_TYPE = 'V' THEN
              L_INT_RATE := L_INT_RATE + NVL(L_RP_RATE, 0);
            END IF;

          ELSE
            L_INT_RATE := L_INT_RATE + NVL(L_RP_RATE, 0);
          END IF;
          DBG('After appying interest rate with RP variance' || L_INT_RATE);
        END IF;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 2;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_int_rate') := L_INT_RATE;

      L_INT_RATE := STPKS_STDCUSAC_UTILS_1_CLUSTER.FN_PROJ_INTRATE(P_FUNCTION_ID,
                                                                   P_BRN,
                                                                   P_ACC,
                                                                   P_PRODUCT_CODE,
                                                                   L_FN_CALL_ID,
                                                                   L_TB_CLUSTER_DATA);

      IF L_TB_CLUSTER_DATA.EXISTS('l_int_rate') THEN
        L_INT_RATE := L_TB_CLUSTER_DATA('l_int_rate');
      END IF;
    END IF;

    DBG('Final Interest Rate ' || L_INT_RATE);

    DBG('Returing from Fn_PROJ_INTRATE');
    RETURN L_INT_RATE;
  END FN_PROJ_INTRATE;

  FUNCTION FN_GET_CUM_AMT(P_ACC_REC IN STTM_CUST_ACCOUNT%ROWTYPE,
                          P_INSERT  VARCHAR2 DEFAULT 'N') RETURN NUMBER IS

    CURSOR CR_CUM_AMT(P_INT_START_DATE DATE) IS
      SELECT ITD.ACC,
             ITD.TD_AMOUNT,
             ITD.TOPUP_AMT,
             ITD.REDEM_AMT,
             'cust_ac_no|' || ITD.ACC || '~brn|' || ITD.BRN || '~bal|' ||
             (NVL(ITD.TD_AMOUNT, 0) + NVL(ITD.TOPUP_AMT, 0) -
             NVL(ITD.REDEM_AMT, 0)) || '^' CUMDET
        FROM ICTMS_TD_DETAILS ITD
        JOIN STTM_CUST_ACCOUNT SCA
          ON ITD.ACC = SCA.CUST_AC_NO
         AND ITD.BRN = SCA.BRANCH_CODE
        JOIN ICTM_ACC AC
          ON ITD.ACC = AC.ACC
         AND ITD.BRN = AC.BRN
       WHERE SCA.CCY = P_ACC_REC.CCY
         AND SCA.CUST_NO = P_ACC_REC.CUST_NO
         AND SCA.CUST_AC_NO || SCA.BRANCH_CODE !=
             P_ACC_REC.CUST_AC_NO || P_ACC_REC.BRANCH_CODE
         AND SCA.ACCOUNT_CLASS = P_ACC_REC.ACCOUNT_CLASS
         AND SCA.AC_OPEN_DATE = P_INT_START_DATE
         AND SCA.AUTH_STAT = 'A'
         AND SCA.RECORD_STAT = 'O';

    L_AMT NUMBER := 0;

    L_CUM_STR      LONG := NULL;
    L_RUN_SEQ      ICTB_CUMDET.RUN_SEQ%TYPE;
    L_INTSTARTDATE DATE;
    L_CURR_AMT     NUMBER;
    L_TOP_CUM      VARCHAR2(1);
    L_REC_ICTM_ACC ICTM_ACC%ROWTYPE;

    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;

  BEGIN
    DBG('Inside fn_get_cum_amt');

    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_AMT             := STPKS_STDCUSAC_UTILS_CLUSTER.FN_GET_CUM_AMT(P_ACC_REC,
                                                                       P_INSERT,
                                                                       L_FN_CALL_ID,
                                                                       L_TB_CLUSTER_DATA);
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('p_acc_rec.CUST_NO------> ' || P_ACC_REC.CUST_NO);
      DBG('p_acc_rec.cust_ac_no-----> ' || P_ACC_REC.CUST_AC_NO);

      IF NOT FN_GET_CUM_FLAG(P_ACC_REC.BRANCH_CODE, P_ACC_REC.CUST_AC_NO) THEN
        SELECT NVL(TD_AMOUNT, 0) + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
          INTO L_AMT
          FROM ICTM_TD_DETAILS
         WHERE BRN = P_ACC_REC.BRANCH_CODE
           AND ACC = P_ACC_REC.CUST_AC_NO;
      ELSE

        L_RUN_SEQ := TO_CHAR(SYSDATE, 'RRDDDHH24MISS');

        DBG('l_amt---->' || L_AMT);
        DBG('l_cum_Str--->' || L_CUM_STR);
        DBG('l_run_seq--->' || L_RUN_SEQ);

        BEGIN
          SELECT *
            INTO L_REC_ICTM_ACC
            FROM ICTM_ACC A
           WHERE A.ACC = P_ACC_REC.CUST_AC_NO
             AND A.BRN = P_ACC_REC.BRANCH_CODE;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in select from ictm_Acc' || SQLERRM);
            L_REC_ICTM_ACC := NULL;
        END;

        DBG('l_rec_ictm_Acc.int_start_date--->' ||
            L_REC_ICTM_ACC.INT_START_DATE);

        FOR X IN CR_CUM_AMT(L_REC_ICTM_ACC.INT_START_DATE) LOOP
          L_AMT     := L_AMT + NVL(X.TD_AMOUNT, 0) + NVL(X.TOPUP_AMT, 0) -
                       NVL(X.REDEM_AMT, 0);
          L_CUM_STR := L_CUM_STR || X.CUMDET;
        END LOOP;

        STPKS_STDTDTOP_UTILS.PR_GET_ISCUMAMT(L_TOP_CUM);
        IF NVL(L_TOP_CUM, 'N') = 'N' THEN

          SELECT NVL(TD_AMOUNT, 0) + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
            INTO L_CURR_AMT
            FROM ICTM_TD_DETAILS
           WHERE BRN = P_ACC_REC.BRANCH_CODE
             AND ACC = P_ACC_REC.CUST_AC_NO;
        ELSE
          L_CURR_AMT := STPKS_STDTDTOP_UTILS.G_RATE_BASIS_AMOUNT;
        END IF;
        L_CUM_STR  := L_CUM_STR || P_ACC_REC.CUST_AC_NO || '~BRN|' ||
                      P_ACC_REC.BRANCH_CODE || '~BAL|' || L_CURR_AMT || '^';
        L_AMT      := L_AMT + L_CURR_AMT;
        L_CURR_AMT := 0;

        DBG('amount--->' || L_AMT);
        DBG('l_cum_str ------->' || L_CUM_STR);
        IF P_INSERT = 'Y' THEN
          DBG('Going to insert into ICTB_CUMDET');
          BEGIN
            INSERT INTO ICTB_CUMDET
              (BRN,
               ACC,
               AC_OPEN_DT,
               CUM_TD_DETAILS,
               CUM_AMT,
               RUN_DT,
               RUN_SEQ)
            VALUES
              (P_ACC_REC.BRANCH_CODE,
               P_ACC_REC.CUST_AC_NO,
               P_ACC_REC.AC_OPEN_DATE,
               L_CUM_STR,
               L_AMT,
               GLOBAL.APPLICATION_DATE,
               L_RUN_SEQ);
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('dup val on index .. skp insert' || SQLERRM);
              RETURN L_AMT;
          END;
        END IF;
      END IF;

    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    RETURN L_AMT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in OTHERS of fn_get_cum_amt-->' || SQLERRM);
      L_AMT := 0;
      RETURN L_AMT;
  END FN_GET_CUM_AMT;
  FUNCTION FN_GET_CUM_FLAG(P_BRN IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_ACC IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE)

   RETURN BOOLEAN IS
    L_CUM_FLAG ICTM_ACC.INTRATE_CUMAMT_REQD%TYPE;
  BEGIN
    DBG('Inside fn_get_cum_flag...');
    BEGIN
      SELECT NVL(INTRATE_CUMAMT_REQD, 'N')
        INTO L_CUM_FLAG
        FROM ICTM_ACC
       WHERE BRN = P_BRN
         AND ACC = P_ACC;
    EXCEPTION
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('**', 'failed in WOT OF fn_get_cum_flag' || SQLERRM);
    END;
    IF L_CUM_FLAG = 'N' THEN
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END FN_GET_CUM_FLAG;

  FUNCTION FN_INSERT_ADSWEEP_DET(P_BRN        IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                 P_ACC        IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                 P_ERR_CODE   IN OUT VARCHAR2,
                                 P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS

    CURSOR C_AD_ACCOUNTS IS
      SELECT A.CUST_AC_NO,
             A.BRANCH_CODE

            ,
             C.ACY_WITHDRAWABLE_BAL,
             A.ACCOUNT_CLASS
        FROM STTM_CUST_ACCOUNT        A,
             ICTB_DEPOSIT_INSTRUCTION B,
             STTM_ACCOUNT_BALANCE     C
       WHERE A.MASTER_ACCOUNT_NO = P_ACC
         AND B.ACCOUNT_NO = A.MASTER_ACCOUNT_NO
         AND B.BRANCH_CODE = P_BRN

         AND C.CUST_AC_BRN = A.BRANCH_CODE
         AND C.CUST_AC_NO = A.CUST_AC_NO

         AND A.BRANCH_CODE = B.BRANCH_CODE
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A';

    TYPE L_TY_AD_ACC IS TABLE OF C_AD_ACCOUNTS%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_AD_ACC    L_TY_AD_ACC;
    L_SEQ_NO       NUMBER;
    L_ENABLE_SWPIN STTM_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
  BEGIN
    DBG('Fetch existing AD for the Primary account-->' || P_ACC);
    IF C_AD_ACCOUNTS%ISOPEN THEN
      CLOSE C_AD_ACCOUNTS;
    END IF;

    OPEN C_AD_ACCOUNTS;
    FETCH C_AD_ACCOUNTS BULK COLLECT
      INTO L_TB_AD_ACC;
    CLOSE C_AD_ACCOUNTS;

    IF L_TB_AD_ACC.COUNT > 0 THEN
      FOR I IN L_TB_AD_ACC.FIRST .. L_TB_AD_ACC.LAST LOOP
        BEGIN
          SELECT ENABLE_SWEEP_IN
            INTO L_ENABLE_SWPIN
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS = L_TB_AD_ACC(I).ACCOUNT_CLASS;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('NO DATA FOUNT IN ACCLS-->' || L_TB_AD_ACC(I)
                .ACCOUNT_CLASS);
            L_ENABLE_SWPIN := 'N';
        END;
        IF NVL(L_ENABLE_SWPIN, 'N') = 'Y' THEN
          BEGIN
            SELECT NVL(MAX(ORDER_OF_LINKAGE), 0) + 1
              INTO L_SEQ_NO
              FROM STTMS_SWEEP_DETAILS
             WHERE BRANCH_CODE = P_BRN
               AND CUST_ACCOUNT = P_ACC
               AND SWEEP_TYPE = 'SA';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('NO DATA FOUNT IN SWEEP FOR ACC-->' || P_ACC);
              L_SEQ_NO := 1;
          END;
          DBG('l_seq_no-->' || L_SEQ_NO);

          BEGIN
            DBG('Inserting into STTM_SWEEP_DETAILS');
            INSERT INTO STTM_SWEEP_DETAILS
              (BRANCH_CODE,
               CUST_ACCOUNT,
               ORDER_OF_LINKAGE,
               DEPOSIT_BRANCH,
               DEPOSIT_ACCOUNT,
               ORIGINAL_DEPOSIT_AMOUNT,
               LINKED_PERCENTAGE,
               LINKED_AMOUNT,
               AVAILABLE_AMOUNT,
               UTILIZED_AMOUNT,
               AMOUNT_BLOCK_NO,
               BLOCKED_AMOUNT,
               SWEEP_TYPE)
            VALUES
              (P_BRN,
               P_ACC,
               L_SEQ_NO,
               L_TB_AD_ACC(I).BRANCH_CODE,
               L_TB_AD_ACC(I).CUST_AC_NO,

               L_TB_AD_ACC(I).ACY_WITHDRAWABLE_BAL,
               100,

               L_TB_AD_ACC(I).ACY_WITHDRAWABLE_BAL,

               L_TB_AD_ACC(I).ACY_WITHDRAWABLE_BAL,
               NULL,
               NULL,
               NULL,
               'SA');
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('on duplicate value updating');
              UPDATE STTM_SWEEP_DETAILS
                 SET LINKED_PERCENTAGE = 100,

                     LINKED_AMOUNT = L_TB_AD_ACC(I).ACY_WITHDRAWABLE_BAL,

                     AVAILABLE_AMOUNT = L_TB_AD_ACC(I).ACY_WITHDRAWABLE_BAL
               WHERE BRANCH_CODE = P_BRN
                 AND CUST_ACCOUNT = P_ACC
                 AND DEPOSIT_BRANCH = L_TB_AD_ACC(I).BRANCH_CODE
                 AND DEPOSIT_ACCOUNT = L_TB_AD_ACC(I).CUST_AC_NO;
          END;
        END IF;
      END LOOP;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in  fn_insert_adsweep_det...' || SQLERRM);
      RETURN FALSE;
  END FN_INSERT_ADSWEEP_DET;

  FUNCTION FN_VALANDGETGOALACCDET(P_SOURCE          IN COTMS_SOURCE.SOURCE_CODE%TYPE,
                                  P_ACTION_CODE     IN VARCHAR2,
                                  P_GOAL_REF_NO     IN STTM_CUST_ACCOUNT.GOAL_REF_NO%TYPE,
                                  P_ACC_NO          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                  P_ACC_BRN         IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                  P_MATURITY_DT     OUT ICTM_ACC.MATURITY_DATE%TYPE,
                                  P_TOP_UP_UNITS    OUT STTMS_ACCLS_MINMAX_AMT_CCY.TOPUP_UNITS%TYPE,
                                  P_ACC_OPEN_DT     OUT STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE,
                                  P_BLK_OPEN_MONTHS OUT STTMS_ACCOUNT_CLASS. BLK_OPEN_MONTHS%TYPE,
                                  P_BLK_OPEN_DAYS   OUT STTMS_ACCOUNT_CLASS. BLK_OPEN_DAYS%TYPE,
                                  P_IS_VALID_ACC    OUT CHAR,
                                  P_ERR_CODE        IN OUT VARCHAR2,
                                  P_ERR_PARAMS      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_ACC_CLS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_ACC_CCY STTM_CUST_ACCOUNT.CCY%TYPE;
  BEGIN
    DBG('IN Fn_ValAndGetGoalAccDet');
    P_IS_VALID_ACC := 'N';
    IF P_GOAL_REF_NO IS NOT NULL THEN
      BEGIN
        SELECT SCA.ACCOUNT_CLASS,
               SCA.AC_OPEN_DATE,
               NVL(AC.BLK_OPEN_MONTHS, 0),
               NVL(AC.BLK_OPEN_DAYS, 0),
               CCY
          INTO L_ACC_CLS,
               P_ACC_OPEN_DT,
               P_BLK_OPEN_MONTHS,
               P_BLK_OPEN_DAYS,
               L_ACC_CCY
          FROM STTMS_CUST_ACCOUNT SCA, STTMS_ACCOUNT_CLASS AC
         WHERE SCA.CUST_AC_NO = P_ACC_NO
           AND SCA.BRANCH_CODE = P_ACC_BRN
           AND GOAL_REF_NO = P_GOAL_REF_NO
           AND AC.ACCOUNT_CLASS = SCA.ACCOUNT_CLASS
           AND AC.AC_CLASS_TYPE = 'Y'
           AND AC.ALLOW_TOPUP = 'Y'
           AND SCA.RECORD_STAT = 'O'
           AND SCA.ONCE_AUTH = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_IS_VALID_ACC := 'N';
        WHEN OTHERS THEN
          DBG('Inside WOE');
          P_IS_VALID_ACC := 'N';
      END;

      IF L_ACC_CLS IS NOT NULL THEN
        P_IS_VALID_ACC := 'Y';
        BEGIN
          SELECT MATURITY_DATE
            INTO P_MATURITY_DT
            FROM ICTMS_ACC
           WHERE ACC = P_ACC_NO
             AND BRN = P_ACC_BRN;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in WOE : ' || SQLERRM);
        END;

        BEGIN

          SELECT NVL(A.TOPUP_UNITS, 1)
            INTO P_TOP_UP_UNITS
            FROM STTMS_ACCLS_MINMAX_AMT_CCY A
           WHERE A.ACCOUNT_CLASS = L_ACC_CLS
             AND A.CCY = L_ACC_CCY;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN

              SELECT NVL(A.TOPUP_UNITS, 1)
                INTO P_TOP_UP_UNITS
                FROM STTMS_ACCLS_MINMAX_AMT_CCY A
               WHERE A.ACCOUNT_CLASS = L_ACC_CLS
                 AND A.CCY = '*.*';
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in WOE : ' || SQLERRM);

                P_TOP_UP_UNITS := 1;
            END;
        END;
      END IF;
    END IF;
    DBG('RETUNRING TRUE FROM fn_ValAndGetGoalAccDet..');
    RETURN TRUE;
  EXCEPTION

    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'IN WHEN OTHERS OF fn_ValAndGetGoalAccDet');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'SI-OTHR-001';
      P_ERR_PARAMS := 'STPKS_STDCUSAC_UTILS_1.FN_VALANDGETGOALACCDET~';
      RETURN FALSE;
  END FN_VALANDGETGOALACCDET;

  FUNCTION FN_CASCADE_MATDT(P_AC_OPEN_DATE IN VARCHAR2, P_DATE IN OUT DATE)
    RETURN BOOLEAN IS
    L_DAY          NUMBER;
    L_MONTH        NUMBER;
    L_YEAR         NUMBER;
    L_AC_OPEN_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_DATE         DATE;
    L_END_DAY      NUMBER;
  BEGIN
    DBG('Inside fn_cascade_matdt...');
    L_AC_OPEN_DATE := P_AC_OPEN_DATE;
    DBG('p_date-->' || P_DATE);

    DBG('Account open date is-->' || L_AC_OPEN_DATE);
    IF NOT CEPKSS_DATE.FN_SPLITDATE(P_DATE, L_DAY, L_MONTH, L_YEAR) THEN
      NULL;
    END IF;
    DBG('l_day~l_month~l_year-->' || L_DAY || '~' || L_MONTH || '~' ||
        L_YEAR);

    IF L_AC_OPEN_DATE IS NOT NULL THEN
      DBG('Account open day-->' ||
          TO_NUMBER(TO_CHAR(L_AC_OPEN_DATE, 'DD')));
      IF TO_NUMBER(TO_CHAR(L_AC_OPEN_DATE, 'DD')) <> L_DAY THEN
        L_DAY := TO_NUMBER(TO_CHAR(L_AC_OPEN_DATE, 'DD'));
        DBG('Now l_day is-->' || L_DAY);
        IF NOT CEPKSS_DATE.FN_FORMDATE(L_DAY, L_MONTH, L_YEAR, L_DATE) THEN
          DBG('Not a valid date');
          L_DATE    := NULL;
          L_END_DAY := CEPKS_DATE.FN_DAYS_IN_MONTH(L_YEAR, L_MONTH);
          DBG('End day got as-->' || L_END_DAY);
          IF NOT CEPKSS_DATE.FN_FORMDATE(L_END_DAY, L_MONTH, L_YEAR, L_DATE) THEN
            DBG('Not a valid date');
            L_DATE := NULL;
          END IF;
          DBG('l_date is-->' || L_DATE);

        END IF;
        IF L_DATE IS NOT NULL THEN
          P_DATE := L_DATE;
        END IF;
      END IF;
    END IF;
    DBG('End of fn_cascade_matdt--->' || P_DATE);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in WOT of fn_cascade_matdt' || SQLERRM);
      RETURN FALSE;
  END FN_CASCADE_MATDT;

  FUNCTION FN_INSERT_STTM_ACC_BALANCE(P_FUNCTION_ID IN VARCHAR2,
                                      P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,

                                      P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,

                                      P_ACTION_CODE IN VARCHAR2,
                                      P_ERR_CODE    IN OUT VARCHAR2,
                                      P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_STTM_ACCOUNT_BALANCE STTM_ACCOUNT_BALANCE%ROWTYPE;
    L_TXNTYPE              NUMBER := 0;
    L_TXNAMT               STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE := 0;

  BEGIN
    DBG('Inside fn_cascade_matdt...');

    IF P_ACTION_CODE IN (CSPKS_SERVICE.P_DELETE, 'DELETE') THEN
      DELETE FROM STTM_ACCOUNT_BALANCE
       WHERE CUST_AC_BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

    ELSIF P_ACTION_CODE IN (CSPKS_SERVICE.P_NEW, 'NEW') THEN

      INSERT INTO STTM_ACCOUNT_BALANCE
        (CUST_AC_BRN,
         CUST_AC_NO,
         CCY,
         ACY_WITHDRAWABLE_BAL,
         ACY_BLOCKED_AMT,
         ACY_UNCOLLECTED,

         RECEIVABLE_AMOUNT,
         WITHDRAWABLE_UNCOLLED_FUND,
         ACY_ECA_BLOCKED_AMT,
         AC_STAT_DORMANT,
         ACY_UNAUTH_CR)
      VALUES
        (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
         0,
         0,
         0,

         0,
         0,
         0,

         NVL(P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT, 'N'),

         0);
    ELSIF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY, 'MODIFY') THEN

      L_STTM_ACCOUNT_BALANCE.AC_STAT_DORMANT := NVL(P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT,
                                                    'N');
      IF NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT, 0) <>
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT, 0) THEN
        DBG('uncoll funds limit has been changed');
        L_TXNTYPE := 3;
        L_TXNAMT  := 0;
      END IF;

      IF NOT ACPKS_CUSTBAL_PROCESS.FN_UPDATE_WITHDRAW_BAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                          L_TXNAMT,
                                                          L_TXNTYPE,
                                                          L_STTM_ACCOUNT_BALANCE,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('failed in amt update');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('End of fn_insert_sttm_acc_balance--->');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in WOT of fn_insert_sttm_acc_balance' || SQLERRM);
      RETURN FALSE;
  END FN_INSERT_STTM_ACC_BALANCE;

  FUNCTION FN_POP_CASA_UDEVALS(P_WRK_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                               P_ERR_CODE     IN OUT VARCHAR2,
                               P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_BRN       STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_BRANCH    STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_RULE_ID   ICTM_RULE_UDE.RULE_ID%TYPE;
    L_RATE_CODE ICTMS_PR_INT_UDEVALS.RATE_CODE%TYPE;
    L_UDE_VALUE ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_UDE_TYPE  ICTMS_RULE_UDE.UDE_TYPE%TYPE;
    L_PROD_LOOP BOOLEAN;
    L_RATE      ICTMS_RATES.RATE%TYPE;
    L_EFFDT     VARCHAR2(10);
    L_CNTR      NUMBER := 0;
    L_UDE_FOUND BOOLEAN;
    L_UDE_CNT   NUMBER := 0;

  BEGIN
    DBG('inside Fn_Pop_casa_udevals');
    IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
      FOR PR IN P_WRK_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
        IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
          FOR EFF IN P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.LAST LOOP
            L_UDE_FOUND := FALSE;
            IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
             .PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_PR(PR).PROD THEN
              IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
                FOR UDE IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                  IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(UDE).PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(UDE)
                     .UDE_EFF_DT = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                     .UDE_EFF_DT THEN
                    L_UDE_FOUND := TRUE;
                  END IF;
                END LOOP;
              END IF;

              IF NOT L_UDE_FOUND THEN

                DBG('1: Selecting from ictms_pr_int_effdt');
                SELECT COUNT(*)
                  INTO L_CNTR
                  FROM ICTMS_PR_INT_EFFDT
                 WHERE BRANCH_CODE =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND ACLASS =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                   AND CCY_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                   AND PRODUCT_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';
                DBG('l_cntr: ' || L_CNTR);

                IF L_CNTR > 0 THEN
                  L_BRN := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                ELSE
                  L_BRN := 'ALL';
                END IF;
                DBG('l_brn: ' || L_BRN);

                FOR EACH_ROW IN (SELECT DISTINCT P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                 U.PRODUCT_CODE,
                                                 P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                                 .UDE_EFF_DT,
                                                 U.UDE_ID,
                                                 U.UDE_VALUE,
                                                 U.RATE_CODE,
                                                 U.TD_RATE_CODE
                                   FROM ICTMS_PR_INT_UDEVALS U,
                                        ICTM_PR_INT_EFFDT    E
                                  WHERE U.BRANCH_CODE = L_BRN
                                    AND U.ACLASS =
                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                                    AND U.CCY_CODE =
                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                    AND U.PRODUCT_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD
                                    AND U.UDE_EFF_DT =
                                        (SELECT MAX(U1.UDE_EFF_DT)
                                           FROM ICTMS_PR_INT_EFFDT U1
                                          WHERE U1.BRANCH_CODE =
                                                U.BRANCH_CODE
                                            AND U1.ACLASS = U.ACLASS
                                            AND U1.CCY_CODE = U.CCY_CODE
                                            AND U1.PRODUCT_CODE =
                                                U.PRODUCT_CODE
                                            AND U1.RECORD_STAT = 'O'
                                            AND U1.AUTH_STAT = 'A'
                                            AND U1.UDE_EFF_DT <= P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                               .UDE_EFF_DT)
                                    AND U.BRANCH_CODE = E.BRANCH_CODE
                                    AND U.ACLASS = E.ACLASS
                                    AND U.CCY_CODE = E.CCY_CODE
                                    AND U.PRODUCT_CODE = E.PRODUCT_CODE
                                    AND U.UDE_EFF_DT = E.UDE_EFF_DT
                                    AND E.RECORD_STAT = 'O'
                                    AND E.AUTH_STAT = 'A'
                                  ORDER BY U.UDE_ID) LOOP
                  DBG('In loop with prod: ' || EACH_ROW.PRODUCT_CODE ||
                      ' and ude id: ' || EACH_ROW.UDE_ID);
                  L_PROD_LOOP := TRUE;

                  DBG('Selecting Rule');
                  SELECT RULE
                    INTO L_RULE_ID
                    FROM ICTMS_PR_INT
                   WHERE PRODUCT_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD;
                  DBG('Rule: ' || L_RULE_ID);

                  SELECT UDE_TYPE
                    INTO L_UDE_TYPE
                    FROM ICTMS_RULE_UDE
                   WHERE RULE_ID = L_RULE_ID
                     AND UDE_ID = EACH_ROW.UDE_ID;

                  DBG('Ude type: ' || L_UDE_TYPE || ' Rate code: ' ||
                      EACH_ROW.RATE_CODE);
                  IF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NOT NULL THEN
                    L_RATE_CODE := NULL;
                    BEGIN
                      SELECT COUNT(*)
                        INTO L_CNTR
                        FROM ICTMS_RATES
                       WHERE BRANCH_CODE =
                             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                         AND RATE_CODE = EACH_ROW.RATE_CODE
                         AND CCY_CODE =
                             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A';

                      IF L_CNTR > 0 THEN
                        L_BRANCH := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                      ELSE
                        L_BRANCH := 'ALL';
                      END IF;

                      DBG('Selecting from ictms_rates');
                      SELECT RATE
                        INTO L_RATE
                        FROM ICTMS_RATES
                       WHERE BRANCH_CODE = L_BRANCH
                         AND RATE_CODE = EACH_ROW.RATE_CODE
                         AND CCY_CODE =
                             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                         AND EFF_DT = (SELECT MAX(EFF_DT)
                                         FROM ICTMS_RATES
                                        WHERE BRANCH_CODE = L_BRANCH
                                          AND RATE_CODE = EACH_ROW.RATE_CODE
                                          AND CCY_CODE =
                                              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                          AND EFF_DT <= P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                             .UDE_EFF_DT)
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A';
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        BEGIN
                          SELECT RATE
                            INTO L_RATE
                            FROM ICTMS_RATES
                           WHERE BRANCH_CODE = 'ALL'
                             AND RATE_CODE = EACH_ROW.RATE_CODE
                             AND CCY_CODE =
                                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                             AND EFF_DT =
                                 (SELECT MAX(EFF_DT)
                                    FROM ICTMS_RATES
                                   WHERE BRANCH_CODE = 'ALL'
                                     AND RATE_CODE = EACH_ROW.RATE_CODE
                                     AND CCY_CODE =
                                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
                                     AND EFF_DT <= P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                        .UDE_EFF_DT)
                             AND RECORD_STAT = 'O'
                             AND AUTH_STAT = 'A';
                        EXCEPTION
                          WHEN OTHERS THEN
                            L_RATE := 0;
                        END;
                      WHEN OTHERS THEN
                        L_RATE := 0;
                    END;
                    L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0) + L_RATE;

                  ELSIF L_UDE_TYPE = 'C' AND EACH_ROW.RATE_CODE IS NULL THEN
                    L_RATE_CODE := NULL;
                    L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0);
                  ELSE
                    L_RATE_CODE := EACH_ROW.RATE_CODE;
                    L_UDE_VALUE := NVL(EACH_ROW.UDE_VALUE, 0);
                  END IF;
                  DBG('ude_id :' || EACH_ROW.UDE_ID);
                  DBG('l_ude_type :' || L_UDE_TYPE);
                  DBG('l_rate_code :' || L_RATE_CODE);

                  DBG('Assigning UDE Values for the Effective Date' ||
                      L_EFFDT);
                  L_UDE_CNT := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT + 1;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).BRN := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).ACC := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).PROD := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_EFF_DT := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                                                              .UDE_EFF_DT;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_ID := EACH_ROW.UDE_ID;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_VALUE := L_UDE_VALUE;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).RATE_CODE := L_RATE_CODE;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).TD_RATE_CODE := EACH_ROW.TD_RATE_CODE;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).AUTH_STAT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT;
                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).RECORD_STAT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT;

                END LOOP;

                IF NOT L_PROD_LOOP THEN
                  DBG('No rates found from the above loop... So, taking just the ude id');

                  FOR EACH_ROW IN (SELECT U.UDE_ID
                                     FROM ICTMS_RULE_UDE U, ICTMS_PR_INT P
                                    WHERE P.PRODUCT_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD
                                      AND U.RULE_ID = P.RULE
                                    ORDER BY U.UDE_ID) LOOP
                    DBG('In loop with Prod: ' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD ||
                        ' Ude id: ' || EACH_ROW.UDE_ID);
                    L_UDE_CNT := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT + 1;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).BRN := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).ACC := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).PROD := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF).PROD;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_EFF_DT := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(EFF)
                                                                                .UDE_EFF_DT;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_ID := EACH_ROW.UDE_ID;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).UDE_VALUE := 0;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).RATE_CODE := NULL;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).AUTH_STAT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT;
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_UDE_CNT).RECORD_STAT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT;

                  END LOOP;
                END IF;
                DBG('UDE count: ' ||
                    P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
              END IF;
            END IF;
          END LOOP;
        END IF;
      END LOOP;
    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in WOT of Fn_Pop_casa_udevals' || SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := 'STPKS_STDCUSAC_UTILS_1.Fn_Pop_casa_udevals~';
      RETURN FALSE;
  END FN_POP_CASA_UDEVALS;

END STPKS_STDCUSAC_UTILS_1;
