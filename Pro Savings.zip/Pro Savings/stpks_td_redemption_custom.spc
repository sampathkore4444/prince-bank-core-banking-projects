CREATE OR REPLACE PACKAGE stpks_td_redemption_custom AS
  /*----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_td_redemption_custom.spc
  **
  ** Module     : TD
  **
  ** This source is part of the Oracle FLEXCUBE Software System and is copyrighted by Oracle Financial Services Software Limited.
  **
  **
  ** All rights reserved. No part of this work may be reproduced, stored in a retrieval system,
  ** adopted or transmitted in any form or by any means, electronic, mechanical, photographic,
  ** graphic, optic recording or otherwise, translated in any language or computer language,
  ** without the prior written permission of Oracle Financial Services Software Limited.
  **
  ** Oracle Financial Services Software Limited.
  ** 10-11, SDF I, SEEPZ, Andheri (East),
  ** Mumbai - 400 096.
  ** India
  ** Copyright © 2008 - 2016 Oracle Financial Services Software Limited. All rights reserved.
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  **
  **  Modified By                : Narayanan Baskar
  **  Modified On                : 6th Sep 2013
  **  Modified Reason            : Hooks Related Changes.
  **  Retro Source               : 9NT1606_12.0.1_EGPNBE_RETRO_17372556
  **  Search String              : 9NT1606_12.0.2_EGPNBE_RETRO_17388070
  **
  **  Modified By                : Narayanan Baskar
  **  Modified On                : 6th Sep 2013
  **  Modified Reason            : Added Procedure pr_broken_td and fn_broken_partial_td.
  **  Retro Source               : 9NT1606_12.0.1_EGPNBE_RETRO_17372556(2)
  **  Search String              : 9NT1606_12.0.2_EGPNBE_RETRO_17388070(1)
  
      Modified By               : Naveen A
      Modified On               : 17-June-2014
      Modified Reason           : Hook changes provided as requested
      Search String             : 9NT1606_12.0.3_RETRO_19000683
  
  ** Changed by              : Hemalatha N
  ** Changed On              : 11-Nov-2014
  ** Change Description      : RETRO OF BUG 19779191: Hook Changes provided
  ** Search string           : 9NT1606_12.0.3_RETRO_20008305
  
  **  Modified By                :  Dekyi
  **  Modified On                :  13-Sept-2016
  **  Modified Description       :  Hook changes
  **  Search Tag                 :  Bug#24482717
  
  **  Modified by                : J.Abinaya
  **  Modified on                : 23-sept-2016
  **  Modified reason            : Multiple_Tax_formula_changes
  **  Search string              : Multiple_Tax_formula_changes
  
  ** Changed by                  : Nidhi Verma
  ** Changed On                  : 05-Apr-2017
  ** Change Description          : Hook Changes provided
  ** Search string               : Bug#25748746
  ---------------------------------------------------------------------------------------------------------
  */

  --sampath starts
  --G_CUSTOM_EXECUTE_ONCE    BOOLEAN := FALSE;
  G_REV_TOPUP_BREAK_REF_NO ACTB_DAILY_LOG.TRN_REF_NO%TYPE;
  G_REV_EXTRA_TOPUP_LIQ    BOOLEAN := FALSE;
  G_REV_EXTRA_TOPUP_ACCR   BOOLEAN := FALSE;
  G_REV_EXTRA_TOPUP_TAX    BOOLEAN := FALSE;
  --sampath ends

  --9NT1606_12.0.2_EGPNBE_RETRO_17388070(1) Changes Starts
  PROCEDURE PR_BROKEN_TD(p_brn            IN sttm_cust_account.branch_code%TYPE,
                         p_acc            IN sttm_cust_account.cust_ac_no%TYPE,
                         p_err_code       IN OUT VARCHAR2,
                         p_err_param      IN OUT VARCHAR2,
                         p_Fn_Call_Id     IN OUT NUMBER,
                         p_Tb_Custom_Data IN OUT Global.Ty_Tb_custom_Data);

  FUNCTION FN_BROKEN_PARTIAL_TD(p_brn            IN sttm_cust_account.branch_code%TYPE,
                                p_acc            IN sttm_cust_account.cust_ac_no%TYPE,
                                p_err_code       IN OUT VARCHAR2,
                                p_err_param      IN OUT VARCHAR2,
                                p_Fn_Call_Id     IN OUT NUMBER,
                                p_Tb_custom_Data IN OUT Global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;
  --9NT1606_12.0.2_EGPNBE_RETRO_17388070(1) Changes Ends

  --9NT1606_12.0.2_EGPNBE_RETRO_17388070 Changes Starts
  FUNCTION Fn_Memo_Accrual(p_brn            IN sttm_cust_account.branch_code%TYPE,
                           p_acc            IN sttm_cust_account.cust_ac_no%TYPE,
                           p_start_date     IN DATE,
                           p_end_date       IN DATE,
                           p_rule           IN ictm_pr_int.rule%TYPE,
                           p_prod           IN ictm_pr_int.product_code%TYPE,
                           p_memo_rec       IN OUT stpks_td_redemption.ty_memo_rec,
                           p_err_code       IN OUT VARCHAR2,
                           p_err_param      IN OUT VARCHAR2,
                           p_Fn_Call_Id     IN OUT NUMBER,
                           p_Tb_custom_Data IN OUT Global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;

  --9NT1606_12.0.2_EGPNBE_RETRO_17388070 Changes Ends
  --9NT1606_12.0.3_RETRO_19000683 changes Starts
  FUNCTION FN_DO_ACCOUNTING(p_txn_code       IN VARCHAR2,
                            p_txn_ref_no     IN VARCHAR2,
                            p_amt_tag        IN VARCHAR2,
                            p_tag_amt        IN sttms_cust_account.acy_avl_bal%TYPE,
                            p_event          IN VARCHAR2,
                            p_cr_gl          IN VARCHAR2,
                            p_dr_gl          IN VARCHAR2,
                            p_brn            IN VARCHAR2,
                            p_acc            IN VARCHAR2,
                            p_ccy            IN VARCHAR2,
                            p_prod           IN VARCHAR2,
                            p_err_code       IN OUT VARCHAR2,
                            p_err_param      IN OUT VARCHAR2,
                            p_Fn_Call_Id     IN OUT NUMBER,
                            p_Tb_custom_Data IN OUT Global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;
  --9NT1606_12.0.3_RETRO_19000683 changes ends
  --9NT1606_12.0.3_RETRO_20008305 changes starts
  FUNCTION FN_APPLY_RATE(p_brn            IN sttm_cust_account.branch_code%type,
                         p_acc            IN sttm_cust_account.cust_ac_no%type,
                         p_ac_class_type  IN sttms_account_class.ac_class_type%TYPE,
                         p_account_class  IN sttms_account_class.account_class%TYPE,
                         p_product_code   IN ictm_pr_int.product_code%TYPE,
                         p_ccy            IN sttms_cust_account.ccy%TYPE,
                         p_avg_bal        IN NUMBER,
                         p_newtenor       IN NUMBER,
                         p_originaltenor  IN NUMBER,
                         p_ac_open_date   IN DATE,
                         p_ppo            IN varchar2,
                         p_fn_call_id     IN OUT NUMBER,
                         p_Tb_custom_Data IN OUT global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;
  --9NT1606_12.0.3_RETRO_20008305 changes ends

  --Bug#24482717 changes starts
  FUNCTION FN_ACLOOKUP(p_txn_ref_no        IN VARCHAR2,
                       p_brn               IN VARCHAR2,
                       p_product_code      IN VARCHAR2,
                       p_ccy               IN VARCHAR2,
                       p_acc               IN VARCHAR2,
                       p_book_account      IN VARCHAR2,
                       p_amt_liqd_tilldate in OUT dbms_sql.Number_Table, --sttms_cust_account.acy_avl_bal%TYPE,  -- Multiple_Tax_formula_changes
                       tb_g_memo_rec       IN stpks_td_redemption.ty_memo_rec, --856
                       p_err_code          IN OUT VARCHAR2,
                       p_err_param         IN OUT VARCHAR2,
                       p_Fn_Call_Id        IN NUMBER,
                       p_Tb_custom_Data    IN OUT Global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;
  --Bug#24482717 changes ends
  --Bug#25748746 starts
  FUNCTION fn_accr_adj(p_txn_ref_no     IN VARCHAR2,
                       p_brn            IN VARCHAR2,
                       p_product_code   IN VARCHAR2,
                       p_ccy            IN VARCHAR2,
                       p_acc            IN VARCHAR2,
                       tb_g_memo_rec    IN stpks_td_redemption.ty_memo_rec,
                       p_err_code       IN OUT VARCHAR2,
                       p_err_param      IN OUT VARCHAR2,
                       p_fn_call_id     IN OUT NUMBER,
                       p_Tb_custom_Data IN OUT global.Ty_Tb_custom_Data)
    RETURN BOOLEAN;
  --Bug#25748746 ends

  --sampath starts
  FUNCTION FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS( --P_TXN_CODE   IN VARCHAR2,
                                               P_TXN_REF_NO IN VARCHAR2,
                                               --P_AMT_TAG    IN VARCHAR2,
                                               --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                               P_EVENT IN VARCHAR2,
                                               --P_CR_GL      IN VARCHAR2,
                                               --P_DR_GL      IN VARCHAR2,
                                               P_BRN       IN VARCHAR2,
                                               P_ACC       IN VARCHAR2,
                                               P_CCY       IN VARCHAR2,
                                               P_PROD      IN VARCHAR2,
                                               P_ERR_CODE  IN OUT VARCHAR2,
                                               P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_REVERSE_EXTRA_ACCRUALS( --P_TXN_CODE   IN VARCHAR2,
                                     P_TXN_REF_NO IN VARCHAR2,
                                     --P_AMT_TAG    IN VARCHAR2,
                                     --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                     P_EVENT IN VARCHAR2,
                                     --P_CR_GL      IN VARCHAR2,
                                     --P_DR_GL      IN VARCHAR2,
                                     P_BRN                    IN VARCHAR2,
                                     P_ACC                    IN VARCHAR2,
                                     P_CCY                    IN VARCHAR2,
                                     P_PROD                   IN VARCHAR2,
                                     P_REVERSE_EXTRA_ACCRUALS IN ICTB_ENTRIES.ACCRUED_AMT%TYPE,
                                     P_ERR_CODE               IN OUT VARCHAR2,
                                     P_ERR_PARAM              IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_REVERSE_EXTRA_TOPUP_TAX( --P_TXN_CODE   IN VARCHAR2,
                                      P_TXN_REF_NO IN VARCHAR2,
                                      --P_AMT_TAG    IN VARCHAR2,
                                      --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                      P_EVENT IN VARCHAR2,
                                      --P_CR_GL      IN VARCHAR2,
                                      --P_DR_GL      IN VARCHAR2,
                                      P_BRN       IN VARCHAR2,
                                      P_ACC       IN VARCHAR2,
                                      P_CCY       IN VARCHAR2,
                                      P_PROD      IN VARCHAR2,
                                      P_ERR_CODE  IN OUT VARCHAR2,
                                      P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN;
  --sampath ends

  --Pro Savings Sampath Starts

  FUNCTION FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                                       P_TXN_REF_NO IN VARCHAR2,
                                                       --P_AMT_TAG    IN VARCHAR2,
                                                       --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                                       P_EVENT IN VARCHAR2,
                                                       --P_CR_GL      IN VARCHAR2,
                                                       --P_DR_GL      IN VARCHAR2,
                                                       P_BRN       IN VARCHAR2,
                                                       P_ACC       IN VARCHAR2,
                                                       P_CCY       IN VARCHAR2,
                                                       P_PROD      IN VARCHAR2,
                                                       P_ERR_CODE  IN OUT VARCHAR2,
                                                       P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                             P_TXN_REF_NO IN VARCHAR2,
                                             --P_AMT_TAG    IN VARCHAR2,
                                             --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                             P_EVENT IN VARCHAR2,
                                             --P_CR_GL      IN VARCHAR2,
                                             --P_DR_GL      IN VARCHAR2,
                                             P_BRN                    IN VARCHAR2,
                                             P_ACC                    IN VARCHAR2,
                                             P_CCY                    IN VARCHAR2,
                                             P_PROD                   IN VARCHAR2,
                                             P_REVERSE_EXTRA_ACCRUALS IN ICTB_ENTRIES.ACCRUED_AMT%TYPE,
                                             P_ERR_CODE               IN OUT VARCHAR2,
                                             P_ERR_PARAM              IN OUT VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                              P_TXN_REF_NO IN VARCHAR2,
                                              --P_AMT_TAG    IN VARCHAR2,
                                              --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                              P_EVENT IN VARCHAR2,
                                              --P_CR_GL      IN VARCHAR2,
                                              --P_DR_GL      IN VARCHAR2,
                                              P_BRN       IN VARCHAR2,
                                              P_ACC       IN VARCHAR2,
                                              P_CCY       IN VARCHAR2,
                                              P_PROD      IN VARCHAR2,
                                              P_ERR_CODE  IN OUT VARCHAR2,
                                              P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN;

--Pro Savings Sampath Ends
END stpks_td_redemption_custom;
