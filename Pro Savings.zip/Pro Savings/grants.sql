GRANT SELECT ON ictm_td_details_custom TO FCCNDG
/
GRANT EXECUTE ON IFPKS_PRO_SAVINGS_UTILS TO BIREP
/
grant update on iftb_pro_savings_overdue_accs to fccndg
/