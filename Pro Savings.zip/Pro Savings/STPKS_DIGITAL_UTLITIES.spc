CREATE OR REPLACE PACKAGE STPKS_DIGITAL_UTLITIES IS

  ACCOUNT_NUMBER           STVW_GET_ACC_DTLS_DIG.ACCOUNT_NUMBER%TYPE;
  ACCOUNT_TYPE             STVW_GET_ACC_DTLS_DIG.ACCOUNT_TYPE%TYPE;
  ACCOUNT_STATUS           STVW_GET_ACC_DTLS_DIG.ACCOUNT_STATUS%TYPE;
  ACCOUNT_CLASS            STVW_GET_ACC_DTLS_DIG.ACCOUNT_CLASS%TYPE;
  ACCOUNT_CURRENCY         STVW_GET_ACC_DTLS_DIG.ACCOUNT_CURRENCY%TYPE;
  ACCOUNT_BRANCH           STVW_GET_ACC_DTLS_DIG.ACCOUNT_BRANCH%TYPE;
  CUSTOMER_NO              STVW_GET_ACC_DTLS_DIG.CUSTOMER_NO%TYPE;
  ACCOUNT_DORMANT_STATUS   STVW_GET_ACC_DTLS_DIG.ACCOUNT_DORMANT_STATUS%TYPE;
  ACCOUNT_FROZEN_STATUS    STVW_GET_ACC_DTLS_DIG.ACCOUNT_FROZEN_STATUS%TYPE;
  ACCOUNT_NO_CREDIT_STATUS STVW_GET_ACC_DTLS_DIG.ACCOUNT_NO_CREDIT_STATUS%TYPE;
  ACCOUNT_NO_DEBIT_STATUS  STVW_GET_ACC_DTLS_DIG.ACCOUNT_NO_DEBIT_STATUS%TYPE;

  TRANSACTION_ID         STVW_GET_TRN_DTLS_DIG.TRANSACTION_ID%TYPE;
  ACCOUNT_BRANCH         STVW_GET_TRN_DTLS_DIG.ACCOUNT_BRANCH%TYPE;
  ACCOUNT_NUMBER         STVW_GET_TRN_DTLS_DIG.ACCOUNT_NUMBER%TYPE;
  RELATED_ACCOUNT        STVW_GET_TRN_DTLS_DIG.RELATED_ACCOUNT%TYPE;
  ACCOUNT_CURRENCY       STVW_GET_TRN_DTLS_DIG.ACCOUNT_CURRENCY%TYPE;
  DEBIT_CREDIT_INDICATOR STVW_GET_TRN_DTLS_DIG.DEBIT_CREDIT_INDICATOR%TYPE;
  TRANSACTION_CODE       STVW_GET_TRN_DTLS_DIG.TRANSACTION_CODE%TYPE;
  NARRATIVE              STVW_GET_TRN_DTLS_DIG.NARRATIVE%TYPE;
  LCY_AMOUNT             STVW_GET_TRN_DTLS_DIG.LCY_AMOUNT%TYPE;
  FCY_AMOUNT             STVW_GET_TRN_DTLS_DIG.FCY_AMOUNT%TYPE;
  EXCH_RATE              STVW_GET_TRN_DTLS_DIG.EXCH_RATE%TYPE;
  TRANSACTION_DATE       STVW_GET_TRN_DTLS_DIG.TRANSACTION_DATE%TYPE;
  VALUE_DATE             STVW_GET_TRN_DTLS_DIG.VALUE_DATE%TYPE;
  TRN_INIT_DATE          STVW_GET_TRN_DTLS_DIG.TRN_INIT_DATE%TYPE;
  MODULE                 STVW_GET_TRN_DTLS_DIG.MODULE%TYPE;
  FIN_CYCLE              STVW_GET_TRN_DTLS_DIG.FIN_CYCLE%TYPE;
  MODULE_DESC            STVW_GET_TRN_DTLS_DIG.MODULE_DESC%TYPE;
  TRN_SAVE_TIMESTAMP     STVW_GET_TRN_DTLS_DIG.TRN_SAVE_TIMESTAMP%TYPE;
  TRN_AUTH_TIMESTAMP     STVW_GET_TRN_DTLS_DIG.TRN_AUTH_TIMESTAMP%TYPE;

  FUNCTION FN_DELETE_SPL_ACC_NO(P_ACC_NO IN VARCHAR2, P_BRN_NO IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_UPDATE_SPL_ACC_NO(P_ACC_NO IN VARCHAR2, P_BRN_NO IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_GET_RFT_UNIQUE_NO_1(P_REF_NO IN VARCHAR2)
    RETURN P1FCHPRFM.cstm_contract_userdef_fields.FIELD_VAL_4%TYPE;

  FUNCTION FN_UPDATE_RFT_UNIQUE_NO_2(P_REF_NO      IN VARCHAR2,
                                     P_UNIQUE_NO_2 IN VARCHAR2) RETURN NUMBER;

  PROCEDURE PR_GET_ACCOUNT_DETAILS(P_ACC_NO      IN VARCHAR2,
                                   P_ACC_DETAILS OUT SYS_REFCURSOR);

  PROCEDURE PR_GET_TRN_DETAILS(P_ACC_NO      IN VARCHAR2,
                               P_TRN_DETAILS OUT SYS_REFCURSOR);

  FUNCTION FN_GET_INT_RATE(P_ACC IN VARCHAR2, P_BRN IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_GET_TAX_RATE(P_ACC IN VARCHAR2, P_BRN IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_CALC_INT(P_AMT      IN NUMBER,
                       P_INT_RATE IN NUMBER,
                       P_TENOR    IN NUMBER) RETURN NUMBER;

  FUNCTION FN_GET_RATE_CODE_CUSTOM(P_ACC   IN VARCHAR2,
                                   P_BRN   IN VARCHAR2,
                                   P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;

  PROCEDURE PR_RETURN_TD_DETAILS(P_ACC          IN VARCHAR2,
                                 P_INT_RATE     OUT NUMBER,
                                 P_INT_AMT      OUT NUMBER,
                                 P_TAX_AMT      OUT NUMBER,
                                 P_MATURITY_AMT OUT NUMBER);

  --Inter bank fnud transfer service
  PROCEDURE PR_GET_IBFT_BANK_BIC_CODE(P_BNAME_BIC_DTLS OUT SYS_REFCURSOR);

  PROCEDURE PR_GET_INTER_BANK_NAMES(P_BANK_DETAILS OUT SYS_REFCURSOR);

  --Fast Charge Service
  PROCEDURE PR_GET_FAST_CHARGE_DTLS(P_PROD_CODE IN VARCHAR2,
                                    P_ARC_DTLS  OUT SYS_REFCURSOR);

  --Standing Instructions Summary
  PROCEDURE PR_GET_SI_DTLS(P_SI_DTLS OUT SYS_REFCURSOR);

  --List of Standing Instructions for a customer
  PROCEDURE PR_GET_SI_DTLS(P_COUNTER_PARTY IN P1FCHPRFM.SIVW_INS_SUMMARY.COUNTERPARTY%TYPE,
                           P_SI_DTLS       OUT SYS_REFCURSOR);

  --Get Joint Details
  FUNCTION FN_GET_JOINT_DTLS(P_AC_NO  IN STVW_CUST_JOINT_DTLS_DIG.CUST_AC_NO%TYPE,
                             P_MOB_NO IN STVW_CUST_JOINT_DTLS_DIG.MOBILE_NUMBER%TYPE)
    RETURN STVW_CUST_JOINT_DTLS_DIG.CUSTOMER_NO%TYPE;

  --Get Casa details by cif no
  FUNCTION FN_GET_CASA_BY_CIF_DIG(P_CUST_NO IN STVW_GET_CASA_BY_CIF_DIG.CUST_NO%TYPE)
    RETURN STVW_GET_CASA_BY_CIF_DIG.CUST_AC_NO%TYPE;

  PROCEDURE PR_GET_CHARGE(P_AMT1    IN NUMBER,
                          P_AMT2    IN NUMBER,
                          P_CHARGE1 OUT NUMBER,
                          P_CHARGE2 OUT NUMBER);

  PROCEDURE PR_TD_INT_TAX_AMT(P_TD_DETAILS IN P1FCHPRFM.ICTM_TD_DETAILS%ROWTYPE,
                              P_INT_AMT    OUT NUMBER,
                              P_TAX_AMT    OUT NUMBER);

  PROCEDURE PR_CREATE_AIA_SI(P_POLICY_NO    IN VARCHAR2,
                             P_HOLDER_NAME  IN VARCHAR2,
                             P_HOLDER_EMAIL IN VARCHAR2,
                             P_HOLDER_PHONE IN VARCHAR2,
                             P_CUSTOMER_NO  in varchar2,
                             P_CUST_NAME    IN VARCHAR2,
                             P_CUST_AC_NO   in varchar2,
                             P_CCY          IN VARCHAR2,
                             P_AMT          IN NUMBER,
                             P_FREQ         IN VARCHAR2,
                             P_PAY_DATE     IN DATE,
                             P_EXPIRY_DATE  IN DATE,
                             P_STATUS       OUT NUMBER,
                             P_ERROR_CODE   OUT VARCHAR2,
                             P_ERROR_MSG    OUT VARCHAR2);

  /*PROCEDURE PR_MODIFY_AIA_SI(P_POLICY_NO        IN VARCHAR2,
  P_UPDATE_BILL_FREQ IN VARCHAR2,
  P_STATUS           OUT NUMBER);*/

  PROCEDURE PR_CANCEL_AIA_SI(P_POLICY_NO  IN VARCHAR2,
                             P_STATUS     OUT NUMBER,
                             P_ERROR_CODE OUT VARCHAR2,
                             P_ERROR_MSG  OUT VARCHAR2);

  PROCEDURE PR_GET_FC_CHARGE(P_PRODUCT      IN VARCHAR2,
                             P_TXN_AMT      IN NUMBER,
                             P_TXN_CCY      IN VARCHAR2,
                             P_COUNTRY_CODE IN VARCHAR2,
                             P_SENDER_ACC   IN VARCHAR2,
                             P_CHARGE       OUT NUMBER,
                             P_CHG_CCY      OUT VARCHAR2,
                             P_STATUS       OUT VARCHAR2 /*,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            P_ERROR_CODE   OUT VARCHAR2,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            P_ERROR_MSG    OUT VARCHAR2*/);
  --clever savings starts

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT(P_ACC      IN VARCHAR2,
                                   P_BRN      IN VARCHAR2,
                                   P_CCY      IN VARCHAR2,
                                   P_DUE_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  FUNCTION FN_GET_INT_TOPUP_RATE_CLEVER_SAVINGS(P_ACC   IN VARCHAR2,
                                                P_BRN   IN VARCHAR2,
                                                P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;

  FUNCTION FN_GET_RATE_CODE_CUSTOM_CLEVER_SAVINGS(P_ACC   IN VARCHAR2,
                                                  P_BRN   IN VARCHAR2,
                                                  P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;

  FUNCTION FN_GET_CLEVER_SAVINGS_PAYIN_ACC(P_ACC IN VARCHAR2,
                                           P_BRN IN VARCHAR2,
                                           P_CCY IN VARCHAR2)
    RETURN p1fchprfm.STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;

  FUNCTION FN_UPDATE_CLEVER_SAV_OVERDUE_ACCS(P_SEQ_NO  IN VARCHAR2,
                                             P_CUST_NO IN VARCHAR2,
                                             P_ACC     IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_GET_TD_INTRATE_TOPUP_AMT(P_ACC        IN VARCHAR2,
                                       P_BRN        IN VARCHAR2,
                                       P_CCY        IN VARCHAR2,
                                       P_TOPUP_DATE IN VARCHAR2)
    RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  FUNCTION fn_get_int_rate_CLEVER_SAVINGS_FOR_HIST_MB(p_acc IN VARCHAR2,
                                                      p_brn IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION fn_get_int_rate_CLEVER_SAVINGS(p_acc IN VARCHAR2,
                                          p_brn IN VARCHAR2) RETURN NUMBER;

  PROCEDURE PR_RETURN_TD_DETAILS_CLEVER_SAVINGS(P_ACC            IN VARCHAR2,
                                                P_BRN            IN VARCHAR2,
                                                P_INT_RATE       OUT NUMBER,
                                                P_INT_AMT        OUT NUMBER,
                                                P_TAX_AMT        OUT NUMBER,
                                                P_MATURITY_AMT   OUT NUMBER,
                                                P_PLAN_NAME      OUT VARCHAR2,
                                                P_MON_TOPUP_RATE OUT NUMBER,
                                                P_MON_TOPUP_AMT  OUT NUMBER);
  --clever savings ends

  --Pro Savings Sampath Starts

  FUNCTION FN_GET_TD_MIN_TOPUP_AMT_PRO_SAV(P_ACC      IN VARCHAR2,
                                           P_BRN      IN VARCHAR2,
                                           P_CCY      IN VARCHAR2,
                                           P_DUE_DATE IN VARCHAR2)
  
   RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  FUNCTION FN_GET_INT_TOPUP_RATE_PRO_SAVINGS(P_ACC   IN VARCHAR2,
                                             P_BRN   IN VARCHAR2,
                                             P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;

  FUNCTION FN_GET_RATE_CODE_CUSTOM_PRO_SAVINGS(P_ACC   IN VARCHAR2,
                                               P_BRN   IN VARCHAR2,
                                               P_TENOR IN VARCHAR2)
    RETURN P1FCHPRFM.ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;

  FUNCTION FN_GET_PRO_SAVINGS_PAYIN_ACC(P_ACC IN VARCHAR2,
                                        P_BRN IN VARCHAR2,
                                        P_CCY IN VARCHAR2)
    RETURN p1fchprfm.STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;

  FUNCTION FN_UPDATE_PRO_SAV_OVERDUE_ACCS(P_SEQ_NO  IN VARCHAR2,
                                          P_CUST_NO IN VARCHAR2,
                                          P_ACC     IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION FN_GET_TD_INTRATE_TOPUP_AMT_PRO_SAV(P_ACC        IN VARCHAR2,
                                               P_BRN        IN VARCHAR2,
                                               P_CCY        IN VARCHAR2,
                                               P_TOPUP_DATE IN VARCHAR2)
    RETURN P1FCHPRFM.ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

  FUNCTION fn_get_int_rate_PRO_SAVINGS_FOR_HIST_MB(p_acc IN VARCHAR2,
                                                   p_brn IN VARCHAR2)
    RETURN NUMBER;

  FUNCTION fn_get_int_rate_PRO_SAVINGS(p_acc IN VARCHAR2,
                                       p_brn IN VARCHAR2) RETURN NUMBER;

  PROCEDURE PR_RETURN_TD_DETAILS_PRO_SAVINGS(P_ACC            IN VARCHAR2,
                                             P_BRN            IN VARCHAR2,
                                             P_INT_RATE       OUT NUMBER,
                                             P_INT_AMT        OUT NUMBER,
                                             P_TAX_AMT        OUT NUMBER,
                                             P_MATURITY_AMT   OUT NUMBER,
                                             P_PLAN_NAME      OUT VARCHAR2,
                                             P_MON_TOPUP_RATE OUT NUMBER,
                                             P_MON_TOPUP_AMT  OUT NUMBER);
  --Pro Savings Sampath Ends
END STPKS_DIGITAL_UTLITIES;
