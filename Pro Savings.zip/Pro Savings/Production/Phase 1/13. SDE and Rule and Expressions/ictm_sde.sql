prompt Importing table ictm_Sde...
set feedback off
set define off
insert into ictm_Sde (SDE_ID, SDE_BASIS, SDE_TYPE, SDE_NTR, SDE_PRD, SDE_OP, SDE_DAYS, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, SDE_DESC, SDE_DAYS_END, EDITABLE, FIELD_NAME, AUTO_RECALC_RQD)
values ('PRO_SAVINGS_TOPUP_AMT', 'O', 'B', 'N', 'D', 'N', 1, 'O', 'A', 'Y', 1, 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'SYSTEM', to_date('10-03-2005', 'dd-mm-yyyy'), 'Top Up of all amounts done for the month', null, 'N', null, 'N');

prompt Done.
