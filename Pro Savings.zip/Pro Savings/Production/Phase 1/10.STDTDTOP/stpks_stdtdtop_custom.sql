CREATE OR REPLACE PACKAGE BODY stpks_stdtdtop_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdtdtop_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdtdtop_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdtdtop         IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdtdtop_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdtdtop         IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    --sampath starts
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    L_LIQUIDAITON_COUNT     NUMBER := 0;
    L_ICTM_TDPAYOUT_DETAILS ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PLAN_AMOUNT           ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT%TYPE;

    L_10TH_LIQUIDATION_DATE ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

    L_22ND_LIQUIDATION_DATE ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

    L_34TH_LIQUIDATION_DATE ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

    L_TOPUP_AMOUNT TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    --sampath ends
	
	--Pro Savings Sampath Starts
    L_STTM_CUST_ACCOUNT_PAYIN  STTM_CUST_ACCOUNT%ROWTYPE;
    L_PAYIN_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_PAYIN_BRN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    --Pro Savings Sampath Ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');

    --sampath starts
    IF P_ACTION_CODE = 'NEW' THEN
      --Get Account Class
      BEGIN

        SELECT *
          INTO L_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
           AND A.BRANCH_CODE = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
           AND A.RECORD_STAT = 'O'
           AND A.ONCE_AUTH = 'Y';

      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_ACCOUNT := NULL;
      END;

      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN
         ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        /* BEGIN
          SELECT COUNT(1)
            INTO L_LIQUIDAITON_COUNT
            FROM CAVW_ENTRIES A
           WHERE (A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                 A.RELATED_ACCOUNT = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC)
             AND PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
             AND EVENT = 'ILIQ'
             AND AMOUNT_TAG = 'ILIQ';
          -- AND TRN_CODE = 'PTP'; --TOP UP EXTRA RATE LIQUIDATION

        EXCEPTION

          WHEN OTHERS THEN

            L_LIQUIDAITON_COUNT := 0;

        END;*/

        --check liquidation count for the plan
        BEGIN
          SELECT count(1)
            INTO L_LIQUIDAITON_COUNT

            FROM (SELECT ROWNUM rn,
                         A.trn_dt,
                         DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                'USD',
                                NVL(SUM(A.LCY_AMOUNT), 0),
                                NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                    FROM CAVW_ENTRIES A
                   WHERE A.ac_no = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                     AND A.EVENT = 'ILIQ'
                     AND A.AMOUNT_TAG = 'ILIQ'
                     AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                     AND A.drcr_ind = 'C'
                   GROUP BY ROWNUM, A.TRN_DT
                   ORDER BY TRN_DT);
        EXCEPTION

          WHEN OTHERS THEN

            L_LIQUIDAITON_COUNT := 0;

        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN

          IF L_CUST_ACCOUNT.CCY = 'USD' THEN

            IF L_LIQUIDAITON_COUNT = 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 300;

            ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 365*/
             L_LIQUIDAITON_COUNT < 12 THEN
              --366

              L_PLAN_AMOUNT := 200;

            ELSIF L_LIQUIDAITON_COUNT = 24 THEN

              L_PLAN_AMOUNT := 350;

            ELSIF /*GLOBAL.APPLICATION_DATE - L_CUST_ACCOUNT.AC_OPEN_DATE > 365*/
            --366

            /*AND
                                                                                                                                                                                                                                                                                                                                                                                                                              GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 731*/
             L_LIQUIDAITON_COUNT > 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 300;

            ELSE

              L_PLAN_AMOUNT := 350;

            END IF;

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN

                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;

              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*200*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*200*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '200-USD');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 2

            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN

              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 22 THEN

                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '24' THEN

                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;

              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*200*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*200*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 3

            IF L_LIQUIDAITON_COUNT >= 34 AND L_LIQUIDAITON_COUNT < 37 THEN

              --Get 35th and 36th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 34 THEN

                  L_34TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_34TH_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_34TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_36TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*200*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*200*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '350-USD');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN

            IF L_LIQUIDAITON_COUNT = 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 300 * 4000;

            ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 365*/
             L_LIQUIDAITON_COUNT < 12 THEN
              --366 THEN

              L_PLAN_AMOUNT := 200 * 4000;

            ELSIF L_LIQUIDAITON_COUNT = 24 THEN

              L_PLAN_AMOUNT := 350 * 4000;

            ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE > 365 --366

                                                                                                                                                                                                                                                                                                                                                                                                                  AND
                                                                                                                                                                                                                                                                                                                                                                                                                  GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 731*/
             L_LIQUIDAITON_COUNT > 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 300 * 4000;

            ELSE

              L_PLAN_AMOUNT := 350 * 4000;

            END IF;

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*800000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*800000*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 2

            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN

              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 22 THEN

                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '24' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*800000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*800000*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 3

            IF L_LIQUIDAITON_COUNT >= 34 AND L_LIQUIDAITON_COUNT < 37 THEN

              --Get 35th and 36th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 34 THEN

                  L_34TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_34TH_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_34TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_36TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*800000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*800000*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1400000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN

          IF L_CUST_ACCOUNT.CCY = 'USD' THEN

            IF L_LIQUIDAITON_COUNT = 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 350;

            ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 365*/
             L_LIQUIDAITON_COUNT < 12 THEN
              --366

              L_PLAN_AMOUNT := 300;

            ELSE

              L_PLAN_AMOUNT := 350;

            END IF;

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*300*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*300*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 2

            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN

              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 22 THEN

                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*300*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*300*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '350-USD');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN

            IF L_LIQUIDAITON_COUNT = 12 AND L_LIQUIDAITON_COUNT < 24 THEN

              L_PLAN_AMOUNT := 350 * 4000;

            ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 365 --366*/
             L_LIQUIDAITON_COUNT < 12 THEN

              L_PLAN_AMOUNT := 300 * 4000;

            ELSE

              L_PLAN_AMOUNT := 350 * 4000;

            END IF;

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*1200000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*1200000*/ --changed from >= to >
               THEN

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 2

            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN

              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 22 THEN

                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 23rd and 24th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > L_PLAN_AMOUNT OR
                 NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT THEN --changed from >= to >

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1400000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

          IF L_CUST_ACCOUNT.CCY = 'USD' THEN

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT < 350 then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           '350-USD');

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 350 OR
                 NVL(L_TOPUP_AMOUNT, 0) > 350 THEN --changed from >= to >

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '350-USD');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN

            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT < 350 * 4000 then

              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           '1400000-KHR');

              RETURN FALSE;

            END IF;

            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN

              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *

                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP

                IF G.RN = 10 THEN

                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;

                END IF;

              END LOOP;

              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE

                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;

                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;

              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 1400000 OR
                 NVL(L_TOPUP_AMOUNT, 0) > 1400000 THEN --changed from >= to >

                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1400000-KHR');

                RETURN FALSE;

              END IF;

            END IF;

          END IF;

        END IF;

      END IF;
	  
	  --Pro Savings Sampath Starts
      IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02', 'PS03', 'PS04') THEN
        
      IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT > 0 THEN
      FOR I IN 1 .. P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.LAST LOOP
          DBG('Validation For Payin' ||
              P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);
          --IF P_STDCUSTD.V_ICTMS_TDTOPUP_PAYIN(I).PAYINTYPE = 'S' THEN
        
          L_PAYIN_ACC := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_TDOFFSET_ACC;
        
          L_PAYIN_BRN := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_OFFSET_BRN;
        
          --L_PAYIN_CCY := P_STDCUSTD.V_ICTMS_TDPAYIN_DETAILS(I)
          --.MULTIMODE_TDOFFSET_CCY;
        
          IF L_PAYIN_ACC IS NOT NULL THEN
            EXIT;
          END IF;
        
        --END IF;
        
        END LOOP;
      END IF;
      
      DBG('L_PAYIN_ACC=' || L_PAYIN_ACC);
    
      DBG('L_PAYIN_BRN=' || L_PAYIN_BRN);
    
      --DBG('L_PAYIN_CCY=' || L_PAYIN_CCY);
      
      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT_PAYIN
          FROM STTM_CUST_ACCOUNT A
         WHERE A.CUST_AC_NO = L_PAYIN_ACC
           AND A.BRANCH_CODE = L_PAYIN_BRN;
        --AND A.CCY = L_PAYIN_CCY;
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT_PAYIN := NULL;
      END;
      
      IF L_STTM_CUST_ACCOUNT_PAYIN.ACCOUNT_CLASS NOT IN
         ('CA06', 'CA07', 'CA08', 'CA09') THEN
      
        Pr_Log_Error(p_Source, p_Function_Id, 'AC-CLS-010', NULL);
      
        RETURN FALSE;
      
      END IF;   
      
      
        --Get TD Payout CASA ACCOUNT Details
        BEGIN
        
          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;
      
        --check liquidation count for the plan
        BEGIN
          SELECT count(1)
            INTO L_LIQUIDAITON_COUNT
          
            FROM (SELECT ROWNUM rn,
                         A.trn_dt,
                         DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                'USD',
                                NVL(SUM(A.LCY_AMOUNT), 0),
                                NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                    FROM CAVW_ENTRIES A
                   WHERE A.ac_no = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                     AND A.EVENT = 'ILIQ'
                     AND A.AMOUNT_TAG = 'ILIQ'
                     AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                     AND A.drcr_ind = 'C'
                   GROUP BY ROWNUM, A.TRN_DT
                   ORDER BY TRN_DT);
        EXCEPTION
        
          WHEN OTHERS THEN
          
            L_LIQUIDAITON_COUNT := 0;
          
        END;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN
        
          IF L_CUST_ACCOUNT.CCY = 'USD' THEN
          
            L_PLAN_AMOUNT := 300;
          
            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);
            
              RETURN FALSE;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 10 THEN
                
                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*300*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*300*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 22 THEN
                
                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*300*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*300*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '300-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN
          
            L_PLAN_AMOUNT := 300 * 4000;
          
            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);
            
              RETURN FALSE;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 10 THEN
                
                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*1200000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*1200000*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 22 THEN
                
                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT > 1200000 OR
                 NVL(L_TOPUP_AMOUNT, 0) > 1200000 THEN
                --changed from >= to >
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '1200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN
        
          IF L_CUST_ACCOUNT.CCY = 'USD' THEN
          
            L_PLAN_AMOUNT := 800;
          
            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);
            
              RETURN FALSE;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 10 THEN
                
                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*800*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*800*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 22 THEN
                
                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*800*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*800*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '800-USD');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
          IF L_CUST_ACCOUNT.CCY = 'KHR' THEN
          
            L_PLAN_AMOUNT := 800 * 4000;
          
            IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT <
               L_PLAN_AMOUNT then
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'AC-CLS-007',
                           L_PLAN_AMOUNT || '-' || L_CUST_ACCOUNT.CCY);
            
              RETURN FALSE;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 1  (TAKE LIQUIDAION COUNT)
            IF L_LIQUIDAITON_COUNT >= 10 AND L_LIQUIDAITON_COUNT < 13 THEN
            
              --Get 11th and 12th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 10 THEN
                
                  L_10TH_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_10TH_LIQUIDATION_DATE IS NOT NULL AND
                 L_LIQUIDAITON_COUNT <> '12' THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_10TH_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_12TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT /*3200000*/
                 OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT /*3200000*/ --changed from >= to >
               THEN
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '3200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
            --Restriction for MIN TOP UP in 11th and 12th months in tier 2
          
            IF L_LIQUIDAITON_COUNT >= 22 AND L_LIQUIDAITON_COUNT < 25 THEN
            
              --Get 23rd and 24th liquidation dates
              FOR G IN (SELECT *
                        
                          FROM (SELECT ROWNUM rn,
                                       A.trn_dt,
                                       DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                              'USD',
                                              NVL(SUM(A.LCY_AMOUNT), 0),
                                              NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                                  FROM CAVW_ENTRIES A
                                 WHERE A.ac_no =
                                       P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                                   AND A.PRODUCT =
                                       L_CUST_ACCOUNT.ACCOUNT_CLASS
                                   AND A.EVENT = 'ILIQ'
                                   AND A.AMOUNT_TAG = 'ILIQ'
                                   AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                                   AND A.drcr_ind = 'C'
                                 GROUP BY ROWNUM, A.TRN_DT
                                 ORDER BY TRN_DT)) LOOP
              
                IF G.RN = 22 THEN
                
                  L_22ND_LIQUIDATION_DATE := G.TRN_DT;
                
                END IF;
              
              END LOOP;
            
              --check if any topup done in 11th and 12th liquidations
              IF L_22ND_LIQUIDATION_DATE IS NOT NULL THEN
                BEGIN
                  SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
                    INTO L_TOPUP_AMOUNT
                    FROM ICTBS_TDTOPUP_DETAIL A
                   WHERE A.TOPUP_DATE >= L_22ND_LIQUIDATION_DATE
                        
                        --AND A.TOPUP_DATE <= L_24TH_LIQUIDATION_DATE
                     AND A.ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
                     AND A.BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
                     AND A.CCY = L_CUST_ACCOUNT.CCY;
                
                EXCEPTION
                  WHEN OTHERS THEN
                    L_TOPUP_AMOUNT := 0;
                END;
              END IF;
            
              IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT >
                 L_PLAN_AMOUNT OR NVL(L_TOPUP_AMOUNT, 0) > L_PLAN_AMOUNT THEN
                --changed from >= to >
              
                Pr_Log_Error(p_Source,
                             p_Function_Id,
                             'AC-CLS-000',
                             '3200000-KHR');
              
                RETURN FALSE;
              
              END IF;
            
            END IF;
          
          END IF;
        
        END IF;
      
      END IF;
      --pro savings ends

    END IF;
    --sampath ends

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Prev_stdtdtop    IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Prev_stdtdtop    IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Prev_stdtdtop    IN stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_prev_stdtdtop    IN stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdtdtop         IN stpks_stdtdtop_Main.Ty_stdtdtop,
                        p_Wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.Ty_stdtdtop,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdtdtop_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdtdtop         IN stpks_stdtdtop_Main.ty_stdtdtop,
                         p_wrk_stdtdtop     IN OUT stpks_stdtdtop_Main.ty_stdtdtop,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdtdtop_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdtdtop_custom;
