-- Create table
create table IFTB_TD_TOPUP_SCHEDULES_PRO_SAV
(
  acc                 VARCHAR2(20) not null,
  brn                 VARCHAR2(3) not null,
  ccy                 VARCHAR2(3) not null,
  due_date            DATE,
  due_date_with_grace DATE,
  auto_topup_amt      NUMBER,
  principal_bal       NUMBER
)
/
alter table IFTB_TD_TOPUP_SCHEDULES_PRO_SAV add primary key (ACC, BRN, CCY) disable novalidate
/