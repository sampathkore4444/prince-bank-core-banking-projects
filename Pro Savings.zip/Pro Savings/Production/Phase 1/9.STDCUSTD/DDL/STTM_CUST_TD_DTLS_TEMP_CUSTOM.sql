-- Create table
create table STTM_CUST_TD_DTLS_TEMP_CUSTOM
(
  brn            VARCHAR2(3) not null,
  acc            VARCHAR2(20) not null,
  ccy            VARCHAR2(3) not null,
  min_top_up_amt NUMBER(22,3)
)
/
alter table STTM_CUST_TD_DTLS_TEMP_CUSTOM add primary key (BRN, ACC, CCY)
/