prompt Importing table lmtm_type_of_types...
set feedback off
set define off
insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PROSAV_INS_I_KH', 'Pro Savings plan Insurance Fee in KHR for individuals', 'SAMPATH2', 'SAMPATH2', to_date('03-12-2024 11:41:05', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-12-2024 11:41:05', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PROSAV_INS_I_US', 'Pro Savings plan Insurance Fee in USD for individuals', 'SAMPATH2', 'SAMPATH2', to_date('03-12-2024 11:37:46', 'dd-mm-yyyy hh24:mi:ss'), to_date('03-12-2024 11:37:46', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_SAV_DEP_KHR', 'Pro Savings Initial Deposit in KHR', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:43:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:43:19', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_SAV_DEP_USD', 'Pro Savings Initial Deposit in USD', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 08:42:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 08:42:25', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_TOPUP_KHR_F', 'Pro Savings Minimum Top Up Amount in KHR Amount for Families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:30:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:30:32', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_TOPUP_KHR_I', 'Pro Savings Minimum Top Up Amount in KHR Amount for Individuals', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:29:25', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:29:25', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_TOPUP_USD_F', 'Pro Savings Minimum Top Up Amount in USD Amount for Families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:27:52', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:27:52', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_TOPUP_USD_I', 'Pro Savings Minimum Top Up Amount in USD Amount for Individuals', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:26:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:26:19', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

prompt Done.
