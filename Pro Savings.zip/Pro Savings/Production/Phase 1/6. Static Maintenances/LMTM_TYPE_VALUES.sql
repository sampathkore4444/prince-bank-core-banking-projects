prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_KH', '100K_PLAN', '800000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_KH', '200K_PLAN', '1400000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_KH', '300K_PLAN', '1600000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_KH', '60K_PLAN', '500000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_US', '100K_PLAN', '200');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_US', '200K_PLAN', '350');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_US', '300K_PLAN', '400');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PROSAV_INS_I_US', '60K_PLAN', '125');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KHR', '100K_PLAN', '32000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KHR', '200K_PLAN', '52000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KHR', '300K_PLAN', '60000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KHR', '60K_PLAN', '20000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_USD', '100K_PLAN', '8000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_USD', '200K_PLAN', '13000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_USD', '300K_PLAN', '15000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_USD', '60K_PLAN', '5000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_F', '1320K_PLAN', '20000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_F', '600K_PLAN', '10000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_F', '840K_PLAN', '13200000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_I', '100K_PLAN', '2400000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_I', '200K_PLAN', '3200000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_I', '300K_PLAN', '4000000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_KHR_I', '60K_PLAN', '1200000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_F', '1320K_PLAN', '5000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_F', '600K_PLAN', '2500');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_F', '840K_PLAN', '3300');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_I', '100K_PLAN', '600');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_I', '200K_PLAN', '800');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_I', '300K_PLAN', '1000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PRO_TOPUP_USD_I', '60K_PLAN', '300');

prompt Done.
