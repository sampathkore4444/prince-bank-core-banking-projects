-- Create table
create table IFTB_PRO_SAVINGS_OVERDUE_ACCS_AFTER_GRACE
(
  seq_no          VARCHAR2(25),
  customer_no     VARCHAR2(25),
  acc             VARCHAR2(25),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  due_date        DATE,
  auto_close_date DATE,
  status          CHAR(1),
  alert_sent_time DATE,
  action_code     VARCHAR2(100)
)
/
alter table IFTB_PRO_SAVINGS_OVERDUE_ACCS_AFTER_GRACE add primary key (SEQ_NO)
/