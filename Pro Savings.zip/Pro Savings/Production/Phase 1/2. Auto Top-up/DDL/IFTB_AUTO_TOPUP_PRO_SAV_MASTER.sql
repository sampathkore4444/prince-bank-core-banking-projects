-- Create table
create table IFTB_AUTO_TOPUP_PRO_SAV_MASTER
(
  seq_no          VARCHAR2(105),
  acc             VARCHAR2(105),
  brn             VARCHAR2(3),
  ccy             VARCHAR2(3),
  td_topup_ref_no VARCHAR2(20),
  pay_in_ofs_acc  VARCHAR2(105),
  pay_in_ofs_brn  VARCHAR2(3),
  top_up_date     DATE,
  top_up_amount   NUMBER,
  retry_count     NUMBER,
  status          CHAR(1)
)
/
alter table IFTB_AUTO_TOPUP_PRO_SAV_MASTER add primary key (SEQ_NO)
/