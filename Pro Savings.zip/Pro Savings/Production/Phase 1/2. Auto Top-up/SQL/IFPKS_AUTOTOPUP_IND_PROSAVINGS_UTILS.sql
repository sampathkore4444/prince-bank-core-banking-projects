CREATE OR REPLACE PACKAGE BODY IFPKS_AUTOTOPUP_IND_PROSAVINGS_UTILS AS

  PROCEDURE PR_GET_FORMATTED_XML(P_XML           IN VARCHAR2,
                                 P_FORMATTED_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_FORMATTED_XML := P_XML;
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '<S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               ' xmlns="http://fcubs.ofss.com/service/FCUBSAccService"',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML,
                               '<?xml version="1.0" encoding="UTF-8"?>',
                               NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '   </S:Body>', NULL);
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Body>', NULL);
  
    P_FORMATTED_XML := REPLACE(P_FORMATTED_XML, '</S:Envelope>', NULL);
  
  END PR_GET_FORMATTED_XML;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'PR_PROCESS_AUTO_TOPUP_IND==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(P_PLAN IN VARCHAR2,
                                           P_ACC  IN VARCHAR2,
                                           P_BRN  IN VARCHAR2,
                                           P_CCY  IN VARCHAR2)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_MIN_TOPUP_AMOUNT NUMBER;
  
    L_MIN_TOPUP_AMOUNT_STORED NUMBER;
  
  BEGIN
  
    BEGIN
    
      SELECT A.MIN_TOP_UP_AMT
        INTO L_MIN_TOPUP_AMOUNT_STORED
        FROM ICTM_TD_DETAILS_CUSTOM A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN
         AND A.CCY = P_CCY;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_MIN_TOPUP_AMOUNT_STORED := 0;
    END;
  
    DBG('L_MIN_TOPUP_AMOUNT_STORED=' || L_MIN_TOPUP_AMOUNT_STORED);
  
    BEGIN
    
      IF P_CCY = 'USD' THEN
      
        SELECT B.CODE
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_TOPUP_USD_I'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      
      ELSIF P_CCY = 'KHR' THEN
      
        SELECT B.CODE
          INTO L_MIN_TOPUP_AMOUNT
          FROM LMTM_TYPE_OF_TYPES A, LMTM_TYPE_VALUES B
         WHERE A.TYPE = B.TYPE
           AND A.TYPE = 'PRO_TOPUP_KHR_I'
           AND B.VALUE = P_PLAN
           AND A.RECORD_STAT = 'O'
           AND A.AUTH_STAT = 'A';
      
      END IF;
    
      RETURN GREATEST(L_MIN_TOPUP_AMOUNT_STORED, L_MIN_TOPUP_AMOUNT);
    
    EXCEPTION
      WHEN OTHERS THEN
      
        L_MIN_TOPUP_AMOUNT := 0;
      
        RETURN GREATEST(L_MIN_TOPUP_AMOUNT_STORED, L_MIN_TOPUP_AMOUNT);
      
    END;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV');
      DBG('ERROR CODE IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV=' || SQLERRM);
    
  END FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV;

  PROCEDURE PR_INSERT_WS_LOG(P_SEQ_NO    IN VARCHAR2,
                             P_INVOKE_TS IN TIMESTAMP,
                             P_ACC       IN VARCHAR2,
                             P_PLAN_NAME IN VARCHAR2,
                             P_REQ_TYPE  IN VARCHAR2,
                             P_REQ_MSG   IN VARCHAR2,
                             P_ADDL_INFO IN VARCHAR2) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    INSERT INTO IFTB_AUTO_TOP_UP_PRO_SAV_WS_LOG
      (REFERENCE_NO,
       INVOKE_DATE,
       CUST_AC_NO,
       PLAN_NAME,
       REQ_TYPE,
       REQ_MSG,
       ADDL_INFO)
    VALUES
      (P_SEQ_NO,
       P_INVOKE_TS,
       P_ACC,
       P_PLAN_NAME,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ADDL_INFO);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_WS_LOG');
      DBG('ERROR CODE IN PR_INSERT_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_WS_LOG=' || SQLERRM);
  END PR_INSERT_WS_LOG;

  PROCEDURE PR_UPDATE_WS_LOG(P_SEQ_NO   IN VARCHAR2,
                             P_RESPONSE IN CLOB,
                             P_STATUS   IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF IFTB_AUTO_TOP_UP_WS_LOG');
  
    UPDATE IFTB_AUTO_TOP_UP_PRO_SAV_WS_LOG
       SET RES_MSG = P_RESPONSE, STATUS = P_STATUS
     WHERE REFERENCE_NO = P_SEQ_NO;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_WS_LOG');
      DBG('ERROR CODE IN PR_UPDATE_WS_LOG=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_WS_LOG=' || SQLERRM);
  END PR_UPDATE_WS_LOG;

  PROCEDURE PR_INSERT_AUTO_TOP_UP_TEST(P_ACC  IN VARCHAR2,
                                       P_BRN  IN VARCHAR2,
                                       P_CCY  IN VARCHAR2,
                                       P_TYPE IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
    insert into iftb_auto_top_up_test
    values
      (P_ACC, P_BRN, P_CCY, P_TYPE, SYSDATE);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END PR_INSERT_AUTO_TOP_UP_TEST;

  PROCEDURE PR_INSERT_TD_OVERDUE_ACCS(P_SEQ_NO          IN VARCHAR2,
                                      P_CUST_NO         IN VARCHAR2,
                                      P_ACC             IN VARCHAR2,
                                      P_BRN             IN VARCHAR2,
                                      P_CCY             IN VARCHAR2,
                                      P_DUE_DATE        IN DATE,
                                      P_AUTO_CLOSE_DATE IN DATE,
                                      P_STATUS          IN CHAR) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_INSERT_TD_OVERDUE_ACCS');
  
    INSERT INTO IFTB_PRO_SAVINGS_OVERDUE_ACCS
      (SEQ_NO,
       CUSTOMER_NO,
       ACC,
       BRN,
       CCY,
       DUE_DATE,
       AUTO_CLOSE_DATE,
       STATUS)
    VALUES
      (P_SEQ_NO,
       P_CUST_NO,
       P_ACC,
       P_BRN,
       P_CCY,
       P_DUE_DATE,
       P_AUTO_CLOSE_DATE,
       'N');
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_TD_OVERDUE_ACCS');
      DBG('ERROR CODE IN PR_INSERT_TD_OVERDUE_ACCS=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_TD_OVERDUE_ACCS=' || SQLERRM);
  END PR_INSERT_TD_OVERDUE_ACCS;

  PROCEDURE PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE(P_SEQ_NO          IN VARCHAR2,
                                                  P_CUST_NO         IN VARCHAR2,
                                                  P_ACC             IN VARCHAR2,
                                                  P_BRN             IN VARCHAR2,
                                                  P_CCY             IN VARCHAR2,
                                                  P_DUE_DATE        IN DATE,
                                                  P_AUTO_CLOSE_DATE IN DATE,
                                                  P_STATUS          IN CHAR,
                                                  P_ACTION_CODE     IN VARCHAR2) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE');
  
    INSERT INTO IFTB_PRO_SAVINGS_OVERDUE_ACCS_AFTER_GRACE
      (SEQ_NO,
       CUSTOMER_NO,
       ACC,
       BRN,
       CCY,
       DUE_DATE,
       AUTO_CLOSE_DATE,
       STATUS,
       ACTION_CODE)
    VALUES
      (P_SEQ_NO,
       P_CUST_NO,
       P_ACC,
       P_BRN,
       P_CCY,
       P_DUE_DATE,
       P_AUTO_CLOSE_DATE,
       'N',
       P_ACTION_CODE);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE');
      DBG('ERROR CODE IN PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE=' ||
          SQLERRM);
  END PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE;

  PROCEDURE PR_INSERT_TD_AUTO_TOPUP_MASTER(P_SEQ_NO         IN VARCHAR2,
                                           P_ACC            IN VARCHAR2,
                                           P_BRN            IN VARCHAR2,
                                           P_CCY            IN VARCHAR2,
                                           P_TDTOPUP_REF_NO IN VARCHAR2,
                                           P_PAYIN_ACC      IN VARCHAR2,
                                           P_PAYIN_ACC_BRN  IN VARCHAR2,
                                           P_TOP_UP_DATE    IN DATE,
                                           P_TOP_UP_AMT     IN NUMBER,
                                           P_RETRY_COUNT    IN NUMBER,
                                           P_STATUS         IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_INSERT_TD_AUTO_TOPUP_MASTER');
  
    INSERT INTO IFTB_AUTO_TOPUP_PRO_SAV_MASTER
      (SEQ_NO,
       ACC,
       BRN,
       CCY,
       TD_TOPUP_REF_NO,
       PAY_IN_OFS_ACC,
       PAY_IN_OFS_BRN,
       TOP_UP_DATE,
       TOP_UP_AMOUNT,
       RETRY_COUNT,
       STATUS)
    VALUES
      (P_SEQ_NO,
       P_ACC,
       P_BRN,
       P_CCY,
       P_TDTOPUP_REF_NO,
       P_PAYIN_ACC,
       P_PAYIN_ACC_BRN,
       P_TOP_UP_DATE,
       P_TOP_UP_AMT,
       P_RETRY_COUNT,
       P_STATUS);
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_TD_AUTO_TOPUP_MASTER');
      DBG('ERROR CODE IN PR_INSERT_TD_AUTO_TOPUP_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_INSERT_TD_AUTO_TOPUP_MASTER=' || SQLERRM);
  END PR_INSERT_TD_AUTO_TOPUP_MASTER;

  PROCEDURE PR_UPDATE_TD_AUTO_TOPUP_MASTER(P_SEQ_NO          IN VARCHAR2,
                                           P_ACC             IN VARCHAR2,
                                           P_BRN             IN VARCHAR2,
                                           P_CCY             IN VARCHAR2,
                                           P_TD_TOPUP_REF_NO IN VARCHAR2,
                                           P_STATUS          IN CHAR) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
  
    DBG('START OF PR_UPDATE_TD_AUTO_TOPUP_MASTER');
  
    UPDATE IFTB_AUTO_TOPUP_PRO_SAV_MASTER
       SET TD_TOPUP_REF_NO = P_TD_TOPUP_REF_NO, STATUS = P_STATUS
     WHERE SEQ_NO = P_SEQ_NO
       AND ACC = P_ACC
       AND BRN = P_BRN
       AND CCY = P_CCY;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_TD_AUTO_TOPUP_MASTER');
      DBG('ERROR CODE IN PR_UPDATE_TD_AUTO_TOPUP_MASTER=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_UPDATE_TD_AUTO_TOPUP_MASTER=' || SQLERRM);
  END PR_UPDATE_TD_AUTO_TOPUP_MASTER;

  PROCEDURE PR_PROCESS_AUTO_TOPUP_IND AS
  
    L_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    --L_ICTM_TD_DETAILS_CUSTOM ICTM_TD_DETAILS_CUSTOM%ROWTYPE;
    L_TOPUP_AMOUNT                     TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_MANUAL_TOPUP_AMOUNT              TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_MANUAL_TOPUP_AMOUNT_DURING_GRACE TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_MANUAL_TOPUP_AMOUNT_AFTER_GRACE  TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_AUTO_TOPUP_AMOUNT_PREV_CYCLE     TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_AUTO_TOPUP_AMOUNT                TDTB_EVENT_DETAILS.TOPUP_AMT%TYPE;
    L_ICTB_ACC_PR                      ICTB_ACC_PR%ROWTYPE;
    L_ICTM_TDPAYIN_DETAILS             ICTM_TDPAYIN_DETAILS%ROWTYPE;
    L_TD_TOPUP_REF_NO                  ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO%TYPE;
  
    L_FORMATTED_RES_MSG CLOB;
    P_DOCUMENT_XML      XMLTYPE;
  
    L_STATUS_MSG VARCHAR2(105);
    L_ERROR_DESC VARCHAR2(255);
  
    L_RESPONSE         VARCHAR2(32767) := '';
    L_XML              VARCHAR2(32767);
    L_REF              VARCHAR2(100);
    L_SEQ              VARCHAR2(100);
    L_PLAN             VARCHAR2(25);
    L_MIN_TOPUP_AMOUNT NUMBER;
    L_SKIP_AUTO_TOPUP  BOOLEAN;
  
    CURSOR C1 IS
    
      SELECT A.*
        FROM STTM_CUST_ACCOUNT A, ICTB_ACC_PR B
       WHERE A.CUST_AC_NO = B.ACC
         AND A.BRANCH_CODE = B.BRN
         AND A.ACCOUNT_CLASS = B.PROD
         AND A.ACCOUNT_TYPE = 'Y'
         AND A.ACCOUNT_CLASS IN ('PS01', 'PS02', 'PS03', 'PS04') --pls check and include all 3 products
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y'
            --AND A.CUST_AC_NO IN ('000116163')
            --AND B.LAST_LIQ_DT >= ADD_MONTHS(B.LAST_LIQ_DT, -1)
            --AND B.NEXT_LIQ_DT < ADD_MONTHS(B.NEXT_LIQ_DT, -1)
         AND A.CUST_AC_NO NOT IN
             (SELECT A.ACC FROM IFTB_PRO_SAVINGS_TD_AUTOREDEEM_MASTER A WHERE A.STATUS <> 'Z')
            --AND SYSDATE >= B.LAST_LIQ_DT + 10
         AND (GLOBAL.application_date = B.LAST_LIQ_DT + 1 OR
             GLOBAL.application_date <= B.LAST_LIQ_DT + 1 + 14)
         --AND A.BRANCH_CODE = '033' --Add for testing branch UAT
         and a.cust_ac_no not in
             (select acc
                from ICTBS_TDTOPUP_DETAIL
               where topup_date >= B.LAST_LIQ_DT + 1
                 and topup_date <= B.LAST_LIQ_DT + 1 + 14)
            
         AND B.LAST_LIQ_DT > A.AC_OPEN_DATE
      --AND A.CUST_AC_NO = '000115723'
      /* AND 3 <= (SELECT NVL(B.RETRY_COUNT, 0)
       FROM IFTB_AUTO_TOPUP_MASTER B
      WHERE B.CUSTOMER_NO = A.CUST_NO
        AND B.CUST_AC_NO = A.CUST_AC_NO)*/
      ; --pls include retry count with date also
  
  BEGIN
  
    DBG('INSIDE PR_PROCESS_AUTO_TOPUP');
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        -- GLOBAL.PR_INIT('000', 'SYSTEM');
        --
        -- DBG('G.CUSTOMER_NO=' || G.CUSTOMER_NO);
      
        GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
        SAVEPOINT A;
      
        --DEBUG.PR_SET_ASYNC_REF('SYSTEM' || '_' || G.BRANCH_CODE || '_' ||
        --                       REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'),
        --                             ':'));
      
        DBG('G.CUST_AC_NO=' || G.CUST_AC_NO);
        DBG('G.BRANCH_CODE=' || G.BRANCH_CODE);
      
        --SEQUENCE GENERATION FOR MSGID AND REF ID
        SELECT TRSQ_AUTO_TOP_UP_SEQ.NEXTVAL INTO L_SEQ FROM DUAL;
      
        L_REF := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');
      
        --get the last liquidation
        BEGIN
          SELECT *
            INTO L_ICTB_ACC_PR
            FROM ICTB_ACC_PR A
           WHERE A.BRN = G.BRANCH_CODE
             AND A.ACC = G.CUST_AC_NO
             AND A.PROD = G.ACCOUNT_CLASS
             AND A.CCY = G.CCY
             AND A.DEPOSIT = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTB_ACC_PR := NULL;
        END;
      
        DBG('L_ICTB_ACC_PR.LAST_LIQ_DT=' || L_ICTB_ACC_PR.LAST_LIQ_DT);
      
        /*   IF ADD_MONTHS(G.AC_OPEN_DATE, 1) = L_ICTB_ACC_PR.LAST_LIQ_DT + 1 then
        
          continue;
        
        END IF;*/
      
        IF ADD_MONTHS(G.AC_OPEN_DATE, 1) = L_ICTB_ACC_PR.LAST_LIQ_DT + 1 THEN
          --Cycle 2
          --Cycle 2
          --Check If TOPUP Done or Not
          BEGIN
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_TOPUP_AMOUNT
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY;
            --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
          
            --AND A.MAKER_ID = 'SYSTEM';
          EXCEPTION
            WHEN OTHERS THEN
              L_TOPUP_AMOUNT := 0;
          END;
        
        ELSE
        
          BEGIN
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_TOPUP_AMOUNT
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY
                  --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
               AND A.TOPUP_DATE >=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
               AND A.TOPUP_DATE <=
                   ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1) + 1 + 14; --consider window/grace period 3 days
          
            --AND A.MAKER_ID = 'SYSTEM'
          
          EXCEPTION
            WHEN OTHERS THEN
              L_TOPUP_AMOUNT := 0;
          END;
        
        END IF;
      
        DBG('L_TOPUP_AMOUNT=' || L_TOPUP_AMOUNT);
      
        IF G.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN
        
          L_PLAN := '60K_PLAN';
        
          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN,
                                                                G.CUST_AC_NO,
                                                                G.BRANCH_CODE,
                                                                G.CCY);
        
          DBG('MINIMUM TOPUP AMOUNT FOR THE ACCOUNT OF TYPE IND=' ||
              L_MIN_TOPUP_AMOUNT);
        
        ELSIF G.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN
        
          L_PLAN := '200K_PLAN';
        
          L_MIN_TOPUP_AMOUNT := FN_GET_MIN_TOPUP_AMOUNT_PRO_SAV(L_PLAN, --pass the plan here
                                                                G.CUST_AC_NO,
                                                                G.BRANCH_CODE,
                                                                G.CCY);
        
          DBG('MINIMUM TOPUP AMOUNT FOR THE ACCOUNT OF TYPE IND=' ||
              L_MIN_TOPUP_AMOUNT);
        
        END IF;
      
        --Get PayIN Details
        BEGIN
        
          SELECT *
            INTO L_ICTM_TDPAYIN_DETAILS
            FROM ICTM_TDPAYIN_DETAILS A
           WHERE A.ACC = G.CUST_AC_NO
             AND A.BRN = G.BRANCH_CODE
             AND A.CCY = G.CCY;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYIN_DETAILS := NULL;
        END;
      
        DBG('PAY IN ACCOUNT NO=' ||
            L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC);
      
        DBG('PAY IN ACCOUNT BRANCH=' ||
            L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN);
      
        DBG('PAY IN ACCOUNT CURRENCY=' ||
            L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_CCY);
      
        IF L_TOPUP_AMOUNT = L_MIN_TOPUP_AMOUNT THEN
        
          IF ADD_MONTHS(G.AC_OPEN_DATE, 1) = L_ICTB_ACC_PR.LAST_LIQ_DT + 1 THEN
          
            DBG('INSIDE CYCLE 2 SO SKIPPING');
            --Cycle 2
          
            --CONTINUE;
            L_SKIP_AUTO_TOPUP := TRUE;
          
          ELSE
          
            DBG('INSIDE NOT CYCLE 2 SO DONT SKIP');
          
            L_SKIP_AUTO_TOPUP := FALSE;
          
            --If any auto topup done
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_AUTO_TOPUP_AMOUNT
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY
                  --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
               AND A.MAKER_ID = 'SYSTEM'
               AND A.CHECKER_ID = 'SYSTEM'
               AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT + 1
                  --   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                  
               AND A.TOPUP_DATE <=
                   ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1) + 1 + 14;
          
            IF L_AUTO_TOPUP_AMOUNT > L_MIN_TOPUP_AMOUNT THEN
            
              L_SKIP_AUTO_TOPUP := TRUE;
            
            END IF;
          
            --If any manual topup after skip grace period
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_MANUAL_TOPUP_AMOUNT
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY
                  --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
               AND A.MAKER_ID <> 'SYSTEM'
               AND A.TOPUP_DATE >=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                  
               AND A.TOPUP_DATE <=
                   ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1) + 1 + 14;
          
            IF L_MANUAL_TOPUP_AMOUNT >= L_MIN_TOPUP_AMOUNT THEN
            
              L_SKIP_AUTO_TOPUP := TRUE;
            
            END IF;
          
            --manual topup before 3pm
          
            --previous cycle no auto topup but manual topup then still skip
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_AUTO_TOPUP_AMOUNT_PREV_CYCLE
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY
                  --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
               AND A.MAKER_ID = 'SYSTEM'
               AND A.CHECKER_ID = 'SYSTEM'
               AND A.TOPUP_DATE >=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                  
               AND A.TOPUP_DATE <=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1 + 14;
            --ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1) + 1 + 14;
          
            IF L_AUTO_TOPUP_AMOUNT_PREV_CYCLE = 0 AND
               L_MANUAL_TOPUP_AMOUNT = L_MIN_TOPUP_AMOUNT THEN
            
              L_SKIP_AUTO_TOPUP := TRUE;
            
            END IF;
          
            --fix for (top up done manually on the due date and no-auto topup for previous cycle) and no auto topup done after grace
            --and no manual top up done after grace period starts
            --If any manual topup after skip grace period during grace
            SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
              INTO L_MANUAL_TOPUP_AMOUNT_DURING_GRACE
            --FROM TDTB_EVENT_DETAILS A
              FROM ICTBS_TDTOPUP_DETAIL A
             WHERE A.ACC = G.CUST_AC_NO
               AND A.BRN = G.BRANCH_CODE
               AND A.CCY = G.CCY
                  --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
               AND A.MAKER_ID <> 'SYSTEM'
               AND A.TOPUP_DATE >=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                  
               AND A.TOPUP_DATE <=
                   ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1 + 14;
          
            IF L_AUTO_TOPUP_AMOUNT_PREV_CYCLE = 0 AND
               L_MANUAL_TOPUP_AMOUNT_DURING_GRACE = L_MIN_TOPUP_AMOUNT THEN
            
              L_SKIP_AUTO_TOPUP := FALSE; --TRUE;
            
            END IF;
          
            --fix for (top up done manually on the due date and no-auto topup for previous cycle) and no auto topup done after grace
            --and no manual top up done after grace period ends
          
          END IF;
        
        ELSIF L_TOPUP_AMOUNT > L_MIN_TOPUP_AMOUNT AND
              L_TOPUP_AMOUNT - L_MIN_TOPUP_AMOUNT >= L_MIN_TOPUP_AMOUNT THEN
        
          --CONTINUE;
          L_SKIP_AUTO_TOPUP := TRUE;
        
        ELSIF L_TOPUP_AMOUNT > L_MIN_TOPUP_AMOUNT AND
              L_TOPUP_AMOUNT - L_MIN_TOPUP_AMOUNT < L_MIN_TOPUP_AMOUNT THEN
        
          L_SKIP_AUTO_TOPUP := FALSE;
        
          IF ADD_MONTHS(G.AC_OPEN_DATE, 1) = L_ICTB_ACC_PR.LAST_LIQ_DT + 1 THEN
          
            DBG('INSIDE CYCLE 2 SO SKIPPING');
            --Cycle 2
          
            L_SKIP_AUTO_TOPUP := TRUE;
          
          END IF;
        
          --If any manual topup after skip grace period during grace
          SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
            INTO L_MANUAL_TOPUP_AMOUNT_DURING_GRACE
          --FROM TDTB_EVENT_DETAILS A
            FROM ICTBS_TDTOPUP_DETAIL A
           WHERE A.ACC = G.CUST_AC_NO
             AND A.BRN = G.BRANCH_CODE
             AND A.CCY = G.CCY
                --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
             AND A.MAKER_ID <> 'SYSTEM'
             AND A.TOPUP_DATE >=
                 ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                
             AND A.TOPUP_DATE <=
                 ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1 + 14;
        
          --If any manual topup after skip grace period
          SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
            INTO L_MANUAL_TOPUP_AMOUNT_AFTER_GRACE
          --FROM TDTB_EVENT_DETAILS A
            FROM ICTBS_TDTOPUP_DETAIL A
           WHERE A.ACC = G.CUST_AC_NO
             AND A.BRN = G.BRANCH_CODE
             AND A.CCY = G.CCY
                --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
             AND A.MAKER_ID <> 'SYSTEM'
             AND A.TOPUP_DATE >
                 ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1 + 14
                
             AND A.TOPUP_DATE <= ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1);
        
          --previous cycle no auto topup but manual topup then still skip
          SELECT NVL(SUM(A.TOPUP_AMOUNT), 0)
            INTO L_AUTO_TOPUP_AMOUNT_PREV_CYCLE
          --FROM TDTB_EVENT_DETAILS A
            FROM ICTBS_TDTOPUP_DETAIL A
           WHERE A.ACC = G.CUST_AC_NO
             AND A.BRN = G.BRANCH_CODE
             AND A.CCY = G.CCY
                --AND A.TOPUP_DATE >= L_ICTB_ACC_PR.LAST_LIQ_DT --pls check greater than or equal to >=
             AND A.MAKER_ID = 'SYSTEM'
             AND A.CHECKER_ID = 'SYSTEM'
             AND A.TOPUP_DATE >=
                 ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1
                
             AND A.TOPUP_DATE <=
                 ADD_MONTHS(L_ICTB_ACC_PR.LAST_LIQ_DT, -1) + 1 + 14;
          --ADD_MONTHS(L_ICTB_ACC_PR.NEXT_LIQ_DT, -1) + 1 + 14;
        
          IF L_AUTO_TOPUP_AMOUNT_PREV_CYCLE = 0 AND
             L_MANUAL_TOPUP_AMOUNT_DURING_GRACE > L_MIN_TOPUP_AMOUNT THEN
          
            L_SKIP_AUTO_TOPUP := FALSE; --TRUE;
          
          END IF;
        
          IF L_AUTO_TOPUP_AMOUNT_PREV_CYCLE = 0 AND
             L_MANUAL_TOPUP_AMOUNT_AFTER_GRACE > L_MIN_TOPUP_AMOUNT THEN
          
            L_SKIP_AUTO_TOPUP := TRUE;
          
          END IF;
        
        ELSE
        
          L_SKIP_AUTO_TOPUP := FALSE;
        
        END IF;
      
        --Data to send notification from MB Starts
        IF GLOBAL.application_date = L_ICTB_ACC_PR.LAST_LIQ_DT + 1  THEN
        
          PR_INSERT_TD_OVERDUE_ACCS(L_REF,
                                    G.CUST_NO,
                                    G.CUST_AC_NO,
                                    G.BRANCH_CODE,
                                    G.CCY,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1 + 14,
                                    'N');
        
        ELSIF GLOBAL.application_date = L_ICTB_ACC_PR.LAST_LIQ_DT + 10 THEN
        
          PR_INSERT_TD_OVERDUE_ACCS(L_REF,
                                    G.CUST_NO,
                                    G.CUST_AC_NO,
                                    G.BRANCH_CODE,
                                    G.CCY,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 10,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1 + 14,
                                    'N');
        
        ELSIF GLOBAL.application_date = L_ICTB_ACC_PR.LAST_LIQ_DT + 13 THEN
           
        PR_INSERT_TD_OVERDUE_ACCS(L_REF,
                                    G.CUST_NO,
                                    G.CUST_AC_NO,
                                    G.BRANCH_CODE,
                                    G.CCY,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 13,
                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1 + 14,
                                    'N');
                                                               
        END IF;
      
        --Data to send notification from MB Ends
      
        IF /*NVL(L_TOPUP_AMOUNT, 0) <
                                                                                                                                                                                                                                  --NVL(L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT, 0) THEN
                                                                                                                                                                                                                                   L_MIN_TOPUP_AMOUNT AND */
         NOT L_SKIP_AUTO_TOPUP THEN
        
          --PR_INSERT_AUTO_TOP_UP_TEST(G.CUST_AC_NO, G.BRANCH_CODE, G.CCY, 'SILVER'); --chikki chikki
        
          --chikki chikki starts
          --insert into master table
          PR_INSERT_TD_AUTO_TOPUP_MASTER(L_REF,
                                         G.CUST_AC_NO,
                                         G.BRANCH_CODE,
                                         G.CCY,
                                         NULL,
                                         L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC,
                                         L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN,
                                         GLOBAL.APPLICATION_DATE,
                                         L_MIN_TOPUP_AMOUNT, --L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT,
                                         1, --RETRY_COUNT--pls check
                                         'N');
        
          L_XML := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fcub="http://fcubs.ofss.com/service/FCUBSAccService">
             <soapenv:Header/>
             <soapenv:Body>
                <fcub:CREATETDTOPUP_FSFS_REQ>
                   <fcub:FCUBS_HEADER>
                      <fcub:SOURCE>EXTSYS</fcub:SOURCE>
                      <fcub:UBSCOMP>FCUBS</fcub:UBSCOMP>

                      <fcub:MSGID></fcub:MSGID>

                      <fcub:CORRELID></fcub:CORRELID>
                      <fcub:USERID>SYSTEM</fcub:USERID>

                      <fcub:ENTITY></fcub:ENTITY>
                      <fcub:BRANCH>$L_BRN_CODE</fcub:BRANCH>

                      <fcub:MODULEID>ST</fcub:MODULEID>
                      <fcub:SERVICE>FCUBSAccService</fcub:SERVICE>
                      <fcub:OPERATION>CreateTDTopUp</fcub:OPERATION>

                      <fcub:SOURCE_OPERATION></fcub:SOURCE_OPERATION>

                      <fcub:SOURCE_USERID></fcub:SOURCE_USERID>

                      <fcub:DESTINATION></fcub:DESTINATION>

                      <fcub:MULTITRIPID></fcub:MULTITRIPID>

                      <fcub:FUNCTIONID></fcub:FUNCTIONID>

                      <fcub:ACTION></fcub:ACTION>

                      <fcub:MSGSTAT></fcub:MSGSTAT>

                      <fcub:SNAPSHOTID></fcub:SNAPSHOTID>

                      <fcub:PASSWORD></fcub:PASSWORD>

                      <fcub:ADDL>
                         <!--Zero or more repetitions:-->
                         <fcub:PARAM>
                            <fcub:NAME></fcub:NAME>
                            <fcub:VALUE></fcub:VALUE>
                         </fcub:PARAM>
                      </fcub:ADDL>
                   </fcub:FCUBS_HEADER>
                   <fcub:FCUBS_BODY>
                      <fcub:Tdtopup-Detail-Full>

                         <fcub:ACCOUNT_BRANCH>$L_BRN_CODE</fcub:ACCOUNT_BRANCH>
                         <fcub:AC_NO>$L_CUST_TD_AC_NO</fcub:AC_NO>

                         <fcub:CCY></fcub:CCY>

                         <fcub:TOPUP_REF_NO></fcub:TOPUP_REF_NO>

                         <fcub:TOPUP_AMT>$L_TOPUP_AMT</fcub:TOPUP_AMT>

                         <fcub:VALUEDATE></fcub:VALUEDATE>

                         <fcub:MATURITY_AMT></fcub:MATURITY_AMT>

                         <fcub:INTEREST_RATE></fcub:INTEREST_RATE>

                         <fcub:NARRATIVE></fcub:NARRATIVE>

                         <fcub:ACC_DESC></fcub:ACC_DESC>

                         <fcub:TOPUP_DATE>' ||
                   GLOBAL.application_date || '</fcub:TOPUP_DATE>

                         <fcub:TD_OPEN_DATE></fcub:TD_OPEN_DATE>

                         <fcub:DAYS></fcub:DAYS>

                         <fcub:MONTHS></fcub:MONTHS>

                         <fcub:YEARS></fcub:YEARS>

                         <fcub:MATDT></fcub:MATDT>

                         <fcub:TDAMT_BEFORE_TOPUP></fcub:TDAMT_BEFORE_TOPUP>

                         <fcub:TDAMT_AFTER_TOPUP></fcub:TDAMT_AFTER_TOPUP>

                         <fcub:MATAMT_AFTER_TOPUP></fcub:MATAMT_AFTER_TOPUP>

                         <fcub:INT_RATE_OPTION></fcub:INT_RATE_OPTION>

                         <fcub:EXT_REFERENCE></fcub:EXT_REFERENCE>

                         <fcub:CUSTOMER_NAME></fcub:CUSTOMER_NAME>

                         <fcub:CUST_NO></fcub:CUST_NO>

                         <fcub:REMITTER_NAME></fcub:REMITTER_NAME>

                         <fcub:MAKER></fcub:MAKER>

                         <fcub:MAKERSTAMP></fcub:MAKERSTAMP>

                         <fcub:CHECKER></fcub:CHECKER>

                         <fcub:CHECKERSTAMP></fcub:CHECKERSTAMP>

                         <fcub:MODNO></fcub:MODNO>

                         <fcub:TXNSTAT></fcub:TXNSTAT>

                         <fcub:AUTHSTAT></fcub:AUTHSTAT>

                         <fcub:Tdtopup-Payin>

                            <fcub:FUND_OPT></fcub:FUND_OPT>

                            <fcub:AMNT>$L_TOPUP_AMT</fcub:AMNT>

                            <fcub:OFFSET_BRN>$L_PAYIN_ACCOUNT_BRN</fcub:OFFSET_BRN>

                            <fcub:OFFSET_ACCOUNT>$L_PAYIN_ACCOUNT</fcub:OFFSET_ACCOUNT>

                            <fcub:PECENT></fcub:PECENT>
                         </fcub:Tdtopup-Payin>
                      </fcub:Tdtopup-Detail-Full>
                   </fcub:FCUBS_BODY>
                </fcub:CREATETDTOPUP_FSFS_REQ>
             </soapenv:Body>
          </soapenv:Envelope>';
        
          L_XML := REPLACE(L_XML, '$L_BRN_CODE', G.BRANCH_CODE);
          L_XML := REPLACE(L_XML, '$L_CUST_TD_AC_NO', G.CUST_AC_NO);
        
          L_XML := REPLACE(L_XML,
                           '$L_TOPUP_AMT',
                           --NVL(L_ICTM_TD_DETAILS_CUSTOM.MIN_TOP_UP_AMT, 0)); --pls check
                           NVL(L_MIN_TOPUP_AMOUNT, 0));
        
          L_XML := REPLACE(L_XML,
                           '$L_PAYIN_ACCOUNT_BRN',
                           L_ICTM_TDPAYIN_DETAILS.MULTIMODE_OFFSET_BRN); --pls check
        
          L_XML := REPLACE(L_XML,
                           '$L_PAYIN_ACCOUNT',
                           L_ICTM_TDPAYIN_DETAILS.MULTIMODE_TDOFFSET_ACC); --pls check
        
          --log ws call
        
          PR_INSERT_WS_LOG(L_REF,
                           SYSTIMESTAMP,
                           G.CUST_AC_NO,
                           L_PLAN,
                           'CreateTDTopUp',
                           L_XML,
                           'TD Auto Top-up Call');
        
          --call
          L_RESPONSE := process_http('http://10.80.80.200:8002/' ||
                                     'FCUBSAccService/FCUBSAccService',
                                     L_XML,
                                     'text/xml;charset=utf-8');
        
          DBG('L_RESPONSE=' || L_RESPONSE);
        
          PR_GET_FORMATTED_XML(L_RESPONSE, L_FORMATTED_RES_MSG);
        
          DBG('L_FORMATTED_RES_MSG=' || L_FORMATTED_RES_MSG);
        
          P_DOCUMENT_XML := XMLTYPE(L_FORMATTED_RES_MSG);
        
          --Check if returned error or success
          L_STATUS_MSG := P_DOCUMENT_XML.EXTRACT('/CREATETDTOPUP_FSFS_RES/FCUBS_HEADER/MSGSTAT/text()')
                          .GETSTRINGVAL;
        
          DBG('L_STATUS_MSG=' || L_STATUS_MSG);
        
          IF L_STATUS_MSG <> 'SUCCESS' THEN
          
            L_ERROR_DESC := P_DOCUMENT_XML.EXTRACT('/CREATETDTOPUP_FSFS_RES/FCUBS_BODY/FCUBS_ERROR_RESP/ERROR/EDESC/text()')
                            .GETSTRINGVAL;
          
            PR_UPDATE_TD_AUTO_TOPUP_MASTER(L_REF,
                                           G.CUST_AC_NO,
                                           G.BRANCH_CODE,
                                           G.CCY,
                                           L_TD_TOPUP_REF_NO,
                                           'F');
          
            PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'F');
          
            --Account Auto Redeem Condition
            IF NVL(L_TOPUP_AMOUNT, 0) <= 0 AND -- L_MIN_TOPUP_AMOUNT AND --can do more then no automatic closure/redeem
              
               GLOBAL.APPLICATION_DATE = L_ICTB_ACC_PR.LAST_LIQ_DT + 1 + 14 THEN
              --on the third day
            
              --Do the Auto-Redeem. So insert into auto-redeem table
            
              IFPKS_AUTOTDREDEEM_PRO_SAVINGS_UTILS.PR_INSERT_TD_AUTO_REDEEM_MASTER(L_REF,
                                                                                     G.CUST_AC_NO,
                                                                                     G.BRANCH_CODE,
                                                                                     G.CCY,
                                                                                     
                                                                                     NULL,
                                                                                     SYSDATE,
                                                                                     'N');
              --For notification to be sent for auto-redeem because 3 times failed after retry
              PR_INSERT_TD_OVERDUE_ACCS_AFTER_GRACE(L_REF,
                                                    G.CUST_NO,
                                                    G.CUST_AC_NO,
                                                    G.BRANCH_CODE,
                                                    G.CCY,
                                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1,
                                                    L_ICTB_ACC_PR.LAST_LIQ_DT + 1 + 14,
                                                    'N',
                                                    'PRO_SAVING_CLOSE_ACC_AFTER_3DAY');
            
            END IF;
          
            ROLLBACK TO A;
          
            CONTINUE;
          
          ELSE
          
            PR_UPDATE_TD_AUTO_TOPUP_MASTER(L_REF,
                                           G.CUST_AC_NO,
                                           G.BRANCH_CODE,
                                           G.CCY,
                                           L_TD_TOPUP_REF_NO,
                                           'S');
          
            PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'S');
          
            COMMIT;
          
          END IF;
          --chikki chikki ends
        
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED IN PR_PROCESS_AUTO_TOPUP_IND');
          DBG('ERROR LINE NUMBER PR_PROCESS_AUTO_TOPUP_IND=' ||
              DBMS_UTILITY.format_error_backtrace);
          DBG('ERROR CODE IN PR_PROCESS_AUTO_TOPUP_IND=' || SQLCODE);
          DBG('ERROR MESSAGE in PR_PROCESS_AUTO_TOPUP_IND=' || SQLERRM);
        
          PR_UPDATE_TD_AUTO_TOPUP_MASTER(L_REF,
                                         G.CUST_AC_NO,
                                         G.BRANCH_CODE,
                                         G.CCY,
                                         L_TD_TOPUP_REF_NO,
                                         'F');
        
          PR_UPDATE_WS_LOG(L_REF, L_RESPONSE, 'F');
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AUTO_TOPUP_IND');
      DBG('ERROR CODE IN PR_PROCESS_AUTO_TOPUP_IND=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_AUTO_TOPUP_IND=' || SQLERRM);
    
  END PR_PROCESS_AUTO_TOPUP_IND;

  PROCEDURE PR_PROCESS_AUTO_TOPUP_IND(P_PARAM_NAME IN VARCHAR2,
                                      PARAMVALUE   VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('000', 'SYSTEM');
  
    DBG('INSIDE PR_PROCESS_AUTO_TOPUP_IND');
  
    PR_PROCESS_AUTO_TOPUP_IND;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_AUTO_TOPUP_IND');
      DBG('ERROR CODE IN PR_PROCESS_AUTO_TOPUP_IND=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_AUTO_TOPUP_IND=' || SQLERRM);
    
  END PR_PROCESS_AUTO_TOPUP_IND;

END IFPKS_AUTOTOPUP_IND_PROSAVINGS_UTILS;
