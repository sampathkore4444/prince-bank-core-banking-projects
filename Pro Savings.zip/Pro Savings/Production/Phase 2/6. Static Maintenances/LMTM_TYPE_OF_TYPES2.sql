insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_TOPUP_KHR_F', 'Pro Savings Minimum Top Up Amount in KHR Amount for Families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 10:30:32', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 10:30:32', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '2', 'Y');

commit;
