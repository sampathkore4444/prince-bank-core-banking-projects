insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PROSAV_INS_F_KH', 'Pro Savings plan Insurance Fee in KHR for families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 16:58:50', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:58:50', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PROSAV_INS_F_US', 'Pro Savings plan Insurance Fee in USD for families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 16:57:19', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 16:57:19', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_SAV_DEP_KH_F', 'Pro Savings Initial Deposit in KHR for families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 17:18:56', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 17:18:56', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PRO_SAV_DEP_US_F', 'Pro Savings Initial Deposit in USD for families', 'SAMPATH2', 'SAMPATH2', to_date('08-02-2023 17:17:04', 'dd-mm-yyyy hh24:mi:ss'), to_date('08-02-2023 17:17:04', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

commit;
