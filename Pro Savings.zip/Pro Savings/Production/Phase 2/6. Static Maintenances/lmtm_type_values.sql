insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_KH', '720K_PLAN', '6000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_KH', '600K_PLAN', '4000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_KH', '1320K_PLAN', '8000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_US', '720K_PLAN', '1500');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_US', '600K_PLAN', '1000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PROSAV_INS_F_US', '1320K_PLAN', '2000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KH_F', '720K_PLAN', '200000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KH_F', '600K_PLAN', '160000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_KH_F', '1320K_PLAN', '320000000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_US_F', '720K_PLAN', '50000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_US_F', '600K_PLAN', '40000');

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('PRO_SAV_DEP_US_F', '1320K_PLAN', '80000');

COMMIT;
