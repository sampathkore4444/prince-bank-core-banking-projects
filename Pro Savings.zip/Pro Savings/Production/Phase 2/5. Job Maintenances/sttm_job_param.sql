insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('PRO_SAVINGS_AUTO_TOPUP_F', 'NAME', 'VARCHAR', 'OFSS');

COMMIT;
