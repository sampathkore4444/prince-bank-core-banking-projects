CREATE OR REPLACE PACKAGE BODY stpks_stdtdtop_utils IS

  G_APPLICATION_DATE DATE;
  G_USER_ID          SMTBS_USER.USER_ID%TYPE;
  G_LCY              CYTMS_CCY_DEFN.CCY_CODE%TYPE;
  G_CURRENT_BRANCH   ICTMS_ACC.BRN%TYPE;

  G_LIQD_INT_TILL_DATE NUMBER := 0;
  G_ADJ_INT_TILL_DATE  NUMBER := 0;
  G_ADJ_START_DATE     DATE;
  L_STDTPSIM_TAX       NUMBER := 0;
  PKG_DEBUG_REQD       CHAR(1) := 'Y';
  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF PKG_DEBUG_REQD = 'Y' THEN
      L_MSG := 'stpks_stdtdtop_utils :: ' || P_MSG;
      DEBUG.PR_DEBUG('IC', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_SOURCE     VARCHAR2,
                         P_ERR_CODE   VARCHAR2,
                         P_ERR_PARAMS VARCHAR2) IS
    L_FUNCTION_ID SMTB_MENU.FUNCTION_ID%TYPE := 'STDTDTOP';
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 L_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;

  FUNCTION FN_IS_TOPUP_APPLICABLE(P_ACC VARCHAR2, P_BRN VARCHAR2)
    RETURN BOOLEAN IS
    L_TOPUP_CNT INTEGER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Start of fn_is_topup_applicable for' || P_ACC || P_BRN);

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      DBG('Calling stpks_stdtdtop_utils_cluster.fn_is_topup_applicable with Fn Call Id -->' ||
          L_FN_CALL_ID);
      IF NOT
          STPKS_STDTDTOP_UTILS_CLUSTER.FN_IS_TOPUP_APPLICABLE(P_ACC,
                                                              P_BRN,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdtdtop_utils_cluster.fn_is_topup_applicable -->' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      BEGIN
        SELECT COUNT(1)
          INTO L_TOPUP_CNT
          FROM TDTB_EVENT_DETAILS
         WHERE ACC = P_ACC
           AND BRN = P_BRN;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WO Exception in select from tdtb_event_details' || SQLERRM);
          L_TOPUP_CNT := 0;
      END;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 2;
      DBG('Calling stpks_stdtdtop_utils_cluster.fn_is_topup_applicable with Fn Call Id -->' ||
          L_FN_CALL_ID);
      IF NOT
          STPKS_STDTDTOP_UTILS_CLUSTER.FN_IS_TOPUP_APPLICABLE(P_ACC,
                                                              P_BRN,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdtdtop_utils_cluster.fn_is_topup_applicable -->' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('L_TOPUP_CNT') AND
         L_TB_CLUSTER_DATA('L_TOPUP_CNT') IS NOT NULL THEN
        L_TOPUP_CNT := L_TB_CLUSTER_DATA('L_TOPUP_CNT');
      END IF;
    END IF;

    IF L_TOPUP_CNT > 0 THEN
      DBG('Topup is applicable for this account returning true');
      RETURN TRUE;
    ELSE
      DBG('Topup is not applicable for this account returning false');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_is_topup_applicable' || SQLERRM);
      RETURN FALSE;
  END FN_IS_TOPUP_APPLICABLE;

  FUNCTION FN_IS_DEP_AMT_INT_SDE(P_PROD                VARCHAR2,
                                 P_IS_DEP_AMT_INIT_SDE OUT BOOLEAN)
    RETURN BOOLEAN;

  FUNCTION FN_GET_LAST_LIQ_DT(P_AC_NO            IN VARCHAR2,
                              P_BRN_CODE         IN VARCHAR2,
                              P_DATE             DATE,
                              P_TB_TOPUP_SETTLED TY_TB_TXN_DET,
                              P_LAST_LIQ_DATE    OUT DATE) RETURN BOOLEAN IS

    L_INDEX     PLS_INTEGER;
    L_HASH_DATE PLS_INTEGER;

  BEGIN

    DBG('Start of fn_get_last_liq_dt' || P_DATE);
    IF P_DATE IS NOT NULL THEN
      L_HASH_DATE := FN_HASH_DATE(P_DATE);
      DBG('l_hash_date' || L_HASH_DATE);
    END IF;
    DBG('p_tb_topup_settled.count' || P_TB_TOPUP_SETTLED.COUNT);
    IF P_TB_TOPUP_SETTLED.COUNT > 0 THEN
      IF P_DATE IS NOT NULL THEN
        IF P_TB_TOPUP_SETTLED.EXISTS(L_HASH_DATE) THEN
          L_INDEX := L_HASH_DATE;
        ELSE
          L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_HASH_DATE);
        END IF;
      ELSE
        L_INDEX := P_TB_TOPUP_SETTLED.LAST;
      END IF;
      WHILE L_INDEX IS NOT NULL LOOP

        IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT != 0 THEN
          P_LAST_LIQ_DATE := P_TB_TOPUP_SETTLED(L_INDEX)
                             .G_EVENT_DETAIL_REC.EVENT_DATE;
          EXIT;
        END IF;
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_INDEX);
      END LOOP;

    ELSE
      DBG('Database fetch..check why p_tb_topup_settled is not populated');

      SELECT MAX(EVENT_DATE)
        INTO P_LAST_LIQ_DATE
        FROM TDTB_EVENT_DETAILS
       WHERE ACC = P_AC_NO
         AND BRN = P_BRN_CODE
         AND EVENT_DATE <= NVL(P_DATE, EVENT_DATE)
         AND LIQD_AMT > 0;
    END IF;
    DBG('Returning true ...p_last_liq_date is ' || P_LAST_LIQ_DATE);
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_get_last_liq_dt' || SQLERRM);
      RETURN FALSE;
  END FN_GET_LAST_LIQ_DT;

  FUNCTION FN_GET_BROKEN_INT(P_ACC     VARCHAR2,
                             P_BRN     VARCHAR2,
                             P_FROM_DT DATE,
                             P_TO_DT   DATE,
                             P_LIQ_INT OUT NUMBER)

   RETURN BOOLEAN IS
    L_INT_AMT NUMBER := 0;
    L_PNL_AMT NUMBER := 0;
    L_TAX_AMT NUMBER := 0;

    L_INT_AMT_CR NUMBER := 0;
    L_INT_AMT_DR NUMBER := 0;

  BEGIN
    DBG('Start of fn_get_broken_int');

    BEGIN
      SELECT COUNT(1)
        INTO L_INT_AMT
        FROM ICTB_TD_BROKEN
       WHERE BRN = P_BRN
         AND ACC = P_ACC;
    EXCEPTION
      WHEN OTHERS THEN
        L_INT_AMT := 0;
    END;

    IF L_INT_AMT > 0 THEN
      L_INT_AMT := 0;
      DBG('Record available in  ICTB_TD_BROKEN for the period ' ||
          P_FROM_DT || '~' || P_TO_DT);

      DBG('PRINTING ICTB_TD_BROKEN');
      DBG('BRN' || '~' || 'ACC' || '~' || 'BROKEN_DATE' || '~' ||
          'LIQD_AMT_TILLDATE' || '~' || 'NEW_LIQD_AMT' || '~' || 'CCY' || '~' ||
          'DRCR' || '~' || 'DIFF_AMT' || '~' || 'LIQD' || '~' || 'ACCR' || '~' ||
          'IS_TAX' || '~' || 'IS_PENALTY');
      FOR I IN (SELECT *
                  FROM ICTB_TD_BROKEN
                 WHERE ACC = P_ACC
                   AND BRN = P_BRN) LOOP
        DBG(I.BRN || '~' || I.ACC || '~' || I.BROKEN_DATE || '~' ||
            I.LIQD_AMT_TILLDATE || '~' || I.NEW_LIQD_AMT || '~' || I.CCY || '~' ||
            I.DRCR || '~' || I.DIFF_AMT || '~' || I.LIQD || '~' || I.ACCR || '~' ||
            I.IS_TAX || '~' || I.IS_PENALTY);
      END LOOP;

      BEGIN
        SELECT SUM(DECODE(LIQD,
                          'Y',
                          (-1 * NVL(DIFF_AMT, 0)),
                          NVL(DIFF_AMT, 0)))
          INTO L_INT_AMT_CR
          FROM ICTB_TD_BROKEN
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND BROKEN_DATE >= P_FROM_DT
           AND BROKEN_DATE <= P_TO_DT
           AND DRCR = 'C'
           AND IS_TAX = 'N'
           AND IS_PENALTY = 'N';
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          L_INT_AMT_CR := 0;

      END;

      BEGIN
        SELECT SUM(DECODE(LIQD,
                          'Y',
                          (-1 * NVL(DIFF_AMT, 0)),
                          NVL(DIFF_AMT, 0)))
          INTO L_INT_AMT_DR
          FROM ICTB_TD_BROKEN
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND BROKEN_DATE >= P_FROM_DT
           AND BROKEN_DATE <= P_TO_DT
           AND DRCR = 'D'
           AND IS_TAX = 'N'
           AND IS_PENALTY = 'N';
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          L_INT_AMT_DR := 0;
      END;
      L_INT_AMT_DR := L_INT_AMT_DR * -1;
      L_INT_AMT    := NVL(L_INT_AMT_CR, 0) + NVL(L_INT_AMT_DR, 0);

      DBG('l_int_amt=' || L_INT_AMT);
      BEGIN
        SELECT NVL(SUM(DIFF_AMT), 0)
          INTO L_PNL_AMT
          FROM ICTB_TD_BROKEN
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND BROKEN_DATE >= P_FROM_DT
           AND BROKEN_DATE <= P_TO_DT
           AND IS_TAX = 'N'
           AND IS_PENALTY = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          L_PNL_AMT := 0;
      END;
      L_PNL_AMT := L_PNL_AMT * -1;
      DBG('l_pnl_amt=' || L_PNL_AMT);

      BEGIN
        SELECT SUM(DECODE(LIQD,
                          'N',
                          (-1 * NVL(DIFF_AMT, 0)),
                          NVL(DIFF_AMT, 0)))
          INTO L_TAX_AMT
          FROM ICTB_TD_BROKEN
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND BROKEN_DATE >= P_FROM_DT
           AND BROKEN_DATE <= P_TO_DT
           AND IS_TAX = 'Y'
           AND IS_PENALTY = 'N';
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          L_TAX_AMT := 0;
      END;
      DBG('l_tax_amt=' || L_TAX_AMT);
      P_LIQ_INT := NVL(L_INT_AMT, 0) + NVL(L_PNL_AMT, 0) +
                   NVL(L_TAX_AMT, 0);
    ELSE
      DBG('No Record in broken Td for this period' || P_FROM_DT || '~' ||
          P_TO_DT);
      P_LIQ_INT := 0;
    END IF;
    DBG('p_liq_int=' || P_LIQ_INT);
    DBG('End of fn_get_broken_int');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_get_broken_int' || SQLERRM);
      RETURN FALSE;
  END FN_GET_BROKEN_INT;

  FUNCTION FN_GET_LIQD_INT(P_ACC     VARCHAR2,
                           P_BRN     VARCHAR2,
                           P_FROM_DT DATE,
                           P_TO_DT   DATE,
                           P_CR_DR   VARCHAR2,
                           P_LIQ_INT OUT NUMBER)

   RETURN BOOLEAN IS
    L_LIQ_INT NUMBER := 0;

  BEGIN
    DBG('start of fn_get_liqd_int' || 'p_from_dt=' || P_FROM_DT ||
        'p_to_dt' || P_TO_DT);

    IF NVL(P_CR_DR, '*') = 'C' THEN
      BEGIN
        SELECT NVL(SUM(AMT), 0)
          INTO L_LIQ_INT
          FROM ICTB_ENTRIES_HISTORY
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND DRCR = 'C'
           AND LIQN = 'Y'
           AND ENT_DT >= P_FROM_DT
           AND ENT_DT <= P_TO_DT;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in getting the liq interest so far from entries history' ||
              SQLERRM);
          L_LIQ_INT := 0;
      END;
      DBG(' Credit interest l_liq_int=' || L_LIQ_INT);
    ELSIF NVL(P_CR_DR, '*') = 'D' THEN
      BEGIN
        SELECT NVL(SUM(AMT), 0)
          INTO L_LIQ_INT
          FROM ICTB_ENTRIES_HISTORY
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND DRCR = 'D'
           AND LIQN = 'Y'
           AND ENT_DT >= P_FROM_DT
           AND ENT_DT <= P_TO_DT;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in getting the liq interest so far from entries history' ||
              SQLERRM);
          L_LIQ_INT := 0;
      END;
      DBG(' Debit interest l_liq_int=' || L_LIQ_INT);
    ELSE
      BEGIN
        SELECT NVL(SUM(DECODE(DRCR, 'C', AMT, -AMT)), 0)
          INTO L_LIQ_INT
          FROM ICTB_ENTRIES_HISTORY
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND LIQN = 'Y'
           AND ENT_DT >= P_FROM_DT
           AND ENT_DT <= P_TO_DT;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in getting the liq interest so far from entries history' ||
              SQLERRM);
          L_LIQ_INT := 0;
      END;

    END IF;
    P_LIQ_INT := L_LIQ_INT;
    DBG('Returning true from FN_GET_LIQD_INT' || P_LIQ_INT);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in FN_GET_LIQD_INT' || SQLERRM);
      RETURN FALSE;
  END FN_GET_LIQD_INT;

  FUNCTION FN_HASH_DATE(P_DT DATE) RETURN PLS_INTEGER IS
  BEGIN
    IF (P_DT IS NOT NULL) THEN
      RETURN P_DT - PKG_CONST_DATE;
    ELSE
      RETURN NULL;
    END IF;
  END;

  FUNCTION FN_POP_BRKUP_CALC(P_REDEM_REF_NO       VARCHAR2,
                             P_TB_CALC            TY_TB_REC_CALC,
                             P_TB_REDM_CALC_BRKUP IN OUT TY_TB_RED_BRKUP)
    RETURN BOOLEAN IS
    L_IDX        PLS_INTEGER;
    L_BRKUP_REQD VARCHAR2(1);
    L_COUNT      INTEGER;
  BEGIN
    L_BRKUP_REQD := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('TD_REDM_BRKUP_REQD'),
                        'N');
    IF L_BRKUP_REQD = 'Y' THEN
      IF P_TB_CALC.COUNT > 0 THEN

        DBG('start  of fn_pop_brkup_calc');
        L_COUNT := P_TB_REDM_CALC_BRKUP.COUNT + 1;
        L_IDX   := P_TB_CALC.FIRST;
        WHILE L_IDX IS NOT NULL LOOP
          P_TB_REDM_CALC_BRKUP(L_COUNT).REFERENCE_NO := P_REDEM_REF_NO;
          P_TB_REDM_CALC_BRKUP(L_COUNT).SEQNO := L_COUNT;
          P_TB_REDM_CALC_BRKUP(L_COUNT).ACC := P_TB_CALC(L_IDX).ACC;
          P_TB_REDM_CALC_BRKUP(L_COUNT).BRN := P_TB_CALC(L_IDX).BRN;
          P_TB_REDM_CALC_BRKUP(L_COUNT).PROCESSING_INDEX := P_TB_CALC(L_IDX).J;
          P_TB_REDM_CALC_BRKUP(L_COUNT).FROM_DATE := P_TB_CALC(L_IDX)
                                                     .FROM_DATE;
          P_TB_REDM_CALC_BRKUP(L_COUNT).TO_DATE := P_TB_CALC(L_IDX).TO_DATE;
          P_TB_REDM_CALC_BRKUP(L_COUNT).AMOUNT := P_TB_CALC(L_IDX).AMOUNT;
          P_TB_REDM_CALC_BRKUP(L_COUNT).TENOR := P_TB_CALC(L_IDX).TENOR;
          P_TB_REDM_CALC_BRKUP(L_COUNT).RATE := P_TB_CALC(L_IDX).RATE;
          P_TB_REDM_CALC_BRKUP(L_COUNT).INTEREST := P_TB_CALC(L_IDX)
                                                    .INTEREST;
          P_TB_REDM_CALC_BRKUP(L_COUNT).PENALTY := P_TB_CALC(L_IDX).PENALTY;
          P_TB_REDM_CALC_BRKUP(L_COUNT).TAX := P_TB_CALC(L_IDX).TAX;

          L_COUNT := L_COUNT + 1;
          L_IDX   := P_TB_CALC.NEXT(L_IDX);
        END LOOP;
        DBG('End of fn_pop_brkup_calc');
      END IF;
    ELSE
      DBG('fn_pop_brkup_calc: TD_REDM_BRKUP_REQD param not set to Y...no logging');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_pop_brkup_calc' || SQLERRM);
      RETURN FALSE;
  END FN_POP_BRKUP_CALC;

  FUNCTION FN_DMP_BRKUP_CALC(P_TB_REDM_CALC_BRKUP TY_TB_RED_BRKUP)
    RETURN BOOLEAN IS
    L_REFERENCE_NUMBER TDTB_REDM_CALC_BRKUP.REFERENCE_NO%TYPE;
    L_ACC              TDTB_REDM_CALC_BRKUP.ACC%TYPE;
    L_BRN              TDTB_REDM_CALC_BRKUP.BRN%TYPE;
    L_COUNT            INTEGER;
    L_BRKUP_REQD       VARCHAR2(1);
  BEGIN
    DBG('start  of fn_dmp_brkup_calc');
    L_BRKUP_REQD := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('TD_REDM_BRKUP_REQD'),
                        'N');
    IF L_BRKUP_REQD = 'Y' THEN
      IF P_TB_REDM_CALC_BRKUP.COUNT > 0 THEN

        L_REFERENCE_NUMBER := P_TB_REDM_CALC_BRKUP(P_TB_REDM_CALC_BRKUP.FIRST)
                              .REFERENCE_NO;
        L_ACC              := P_TB_REDM_CALC_BRKUP(P_TB_REDM_CALC_BRKUP.FIRST).ACC;
        L_BRN              := P_TB_REDM_CALC_BRKUP(P_TB_REDM_CALC_BRKUP.FIRST).BRN;

        SELECT COUNT(1)
          INTO L_COUNT
          FROM TDTB_REDM_CALC_BRKUP_HIS
         WHERE REFERENCE_NO = L_REFERENCE_NUMBER;

        IF L_COUNT > 0 THEN
          DELETE FROM TDTB_REDM_CALC_BRKUP_HIS
           WHERE REFERENCE_NO = L_REFERENCE_NUMBER;
        END IF;

        BEGIN
          INSERT INTO TDTB_REDM_CALC_BRKUP_HIS
            SELECT *
              FROM TDTB_REDM_CALC_BRKUP
             WHERE ACC = L_ACC
               AND BRN = L_BRN;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in inserting into tdtb_redm_calc_brkup_his' ||
                SQLERRM);
        END;

        DELETE FROM TDTB_REDM_CALC_BRKUP
         WHERE ACC = L_ACC
           AND BRN = L_BRN;

        BEGIN
          FORALL I IN P_TB_REDM_CALC_BRKUP.FIRST .. P_TB_REDM_CALC_BRKUP.LAST
            INSERT INTO TDTB_REDM_CALC_BRKUP
            VALUES P_TB_REDM_CALC_BRKUP
              (I);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in inserting into tdtb_redm_calc_brkup' || SQLERRM);
        END;

      END IF;
      DBG('End of fn_dmp_brkup_calc');
    ELSE
      DBG('TD_REDM_BRKUP_REQD param not set to Y...no logging');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_dmp_brkup_calc' || SQLERRM);
      RETURN FALSE;
  END FN_DMP_BRKUP_CALC;

  PROCEDURE PR_PRINT_TB_CALC(P_TB_CALC STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC) IS
    L_INDEX PLS_INTEGER;
  BEGIN
    L_INDEX := P_TB_CALC.FIRST;
    DBG('**********************************************************************************************');
    DBG('Acc~brn~j~from_date~to_Date~amount~tenor~rate~interest~penalty~tax~capital_index');

    WHILE L_INDEX IS NOT NULL LOOP

      DBG(P_TB_CALC(L_INDEX).ACC || '~' || P_TB_CALC(L_INDEX).BRN || '~' || P_TB_CALC(L_INDEX).J || '~' || P_TB_CALC(L_INDEX)
          .FROM_DATE || '~' || P_TB_CALC(L_INDEX).TO_DATE || '~' || P_TB_CALC(L_INDEX)
          .AMOUNT || '~' || P_TB_CALC(L_INDEX).TENOR || '~' || P_TB_CALC(L_INDEX).RATE || '~' || P_TB_CALC(L_INDEX)
          .INTEREST || '~' || P_TB_CALC(L_INDEX).PENALTY || '~' || P_TB_CALC(L_INDEX).TAX || '~' || P_TB_CALC(L_INDEX)
          .CAPITAL_INDEX);
      L_INDEX := P_TB_CALC.NEXT(L_INDEX);
    END LOOP;
    DBG('**********************************************************************************************');
  END PR_PRINT_TB_CALC;

  PROCEDURE PR_POP_ALL_ROWS(P_REC_CALC    TY_REC_CALC,
                            P_TB_CALC_OUT IN OUT TY_TB_REC_CALC)

   IS
    CURSOR CUR_TXN IS
      SELECT A.*, ROWID

        FROM TDTB_EVENT_DETAILS A

       WHERE BRN = P_REC_CALC.BRN
         AND ACC = P_REC_CALC.ACC
         AND EVENT_DATE >= P_REC_CALC.FROM_DATE
         AND EVENT_DATE <= P_REC_CALC.TO_DATE

       ORDER BY EVENT_DATE;

    TYPE TY_TB_TXN_DET IS TABLE OF CUR_TXN%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_TXN_DET TY_TB_TXN_DET;

    L_TMP_IDX   PLS_INTEGER;
    L_FROM_DATE DATE;
    L_TO_DATE   DATE;
    L_CNT_IDX   PLS_INTEGER := 0;
  BEGIN

    DBG('start of pr_pop_all_rows');
    DBG(' p_rec_calc.from_date=' || P_REC_CALC.FROM_DATE ||
        'p_rec_calc.to_Date=' || P_REC_CALC.TO_DATE);

    IF CUR_TXN%ISOPEN THEN
      CLOSE CUR_TXN;
    END IF;

    OPEN CUR_TXN;
    FETCH CUR_TXN BULK COLLECT
      INTO L_TB_TXN_DET;
    CLOSE CUR_TXN;
    IF L_TB_TXN_DET.COUNT > 0 THEN
      L_TMP_IDX := L_TB_TXN_DET.FIRST;
      WHILE L_TMP_IDX IS NOT NULL LOOP
        L_FROM_DATE := NVL(L_FROM_DATE, P_REC_CALC.FROM_DATE);
        IF L_TMP_IDX = L_TB_TXN_DET.LAST THEN
          L_TO_DATE := P_REC_CALC.TO_DATE - 1;
        ELSE
          L_TO_DATE := L_TB_TXN_DET(L_TB_TXN_DET.NEXT(L_TMP_IDX))
                       .EVENT_DATE - 1;
        END IF;
        L_CNT_IDX := P_TB_CALC_OUT.COUNT + 1;
        P_TB_CALC_OUT(L_CNT_IDX) := P_REC_CALC;
        P_TB_CALC_OUT(L_CNT_IDX).FROM_DATE := L_FROM_DATE;
        P_TB_CALC_OUT(L_CNT_IDX).TO_DATE := L_TO_DATE;
        L_FROM_DATE := P_TB_CALC_OUT(L_CNT_IDX).TO_DATE + 1;
        L_TMP_IDX := L_TB_TXN_DET.NEXT(L_TMP_IDX);
      END LOOP;

    END IF;

    DBG('End of pr_pop_all_rows');
  END PR_POP_ALL_ROWS;

  PROCEDURE PR_SET_GLOBALS IS
  BEGIN
    DBG('pr_set_globals Starts');
    G_APPLICATION_DATE := GLOBAL.APPLICATION_DATE;
    G_USER_ID          := GLOBAL.USER_ID;
    G_LCY              := GLOBAL.LCY;
    G_CURRENT_BRANCH   := GLOBAL.CURRENT_BRANCH;

    DBG('stpks_stdtdtop_utils.g_application_date--> ' ||
        TO_CHAR(G_APPLICATION_DATE, 'DD-MON-RRRR'));
    DBG('g_user_id--> ' || G_USER_ID);
    DBG('g_lcy--> ' || G_LCY);
    DBG('g_current_branch --> ' || G_CURRENT_BRANCH);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('pr_set_globals failed-->' || SQLERRM);
      RAISE;
  END PR_SET_GLOBALS;

  PROCEDURE PR_SET_ISTOPUP(P_TOPUP_ENABLED IN VARCHAR2) IS
  BEGIN
    DBG('pr_set_istopup  p_topup_enabled will be ' || P_TOPUP_ENABLED);
    G_TOPUP_ENABLED := P_TOPUP_ENABLED;
  END PR_SET_ISTOPUP;

  PROCEDURE PR_GET_ISTOPUP(P_TOPUP_ENABLED IN OUT VARCHAR2) IS
  BEGIN
    P_TOPUP_ENABLED := G_TOPUP_ENABLED;
    DBG('pr_get_istopup  p_topup_enabled will be ' || P_TOPUP_ENABLED);
  END PR_GET_ISTOPUP;

  PROCEDURE PR_SET_ISCUMAMT(P_CUMAMT_ENABLED IN VARCHAR2) IS
  BEGIN
    DBG('pr_set_iscumamt  p_cumamt_enabled will be ' || P_CUMAMT_ENABLED);
    G_CUMAMT_ENABLED := P_CUMAMT_ENABLED;
  END PR_SET_ISCUMAMT;

  PROCEDURE PR_GET_ISCUMAMT(P_CUMAMT_ENABLED IN OUT VARCHAR2) IS
  BEGIN
    P_CUMAMT_ENABLED := G_CUMAMT_ENABLED;
    DBG('pr_get_iscumamt  pr_get_iscumamt will be ' || P_CUMAMT_ENABLED);
  END PR_GET_ISCUMAMT;

  PROCEDURE PR_CONV_TDPAYINDET(P_TOPUP_PAYIN  ICTM_TDTOPUP_PAYIN%ROWTYPE,
                               P_TD_PAYIN_DET OUT ICTMS_TDPAYIN_DETAILS%ROWTYPE) IS
  BEGIN
    P_TD_PAYIN_DET.BRN                    := P_TOPUP_PAYIN.BRN;
    P_TD_PAYIN_DET.ACC                    := P_TOPUP_PAYIN.ACC;
    P_TD_PAYIN_DET.CCY                    := P_TOPUP_PAYIN.CCY;
    P_TD_PAYIN_DET.MULTIMODE_PAYOPT       := P_TOPUP_PAYIN.MULTIMODE_PAYOPT;
    P_TD_PAYIN_DET.MULTIMODE_TDAMOUNT     := P_TOPUP_PAYIN.MULTIMODE_TDAMOUNT;
    P_TD_PAYIN_DET.MULTIMODE_OFFSET_BRN   := P_TOPUP_PAYIN.MULTIMODE_OFFSET_BRN;
    P_TD_PAYIN_DET.MULTIMODE_TDOFFSET_ACC := P_TOPUP_PAYIN.MULTIMODE_TDOFFSET_ACC;
    P_TD_PAYIN_DET.MULTIMODE_TDOFFSET_CCY := P_TOPUP_PAYIN.MULTIMODE_TDOFFSET_CCY;
    P_TD_PAYIN_DET.REFERENCE_NO           := P_TOPUP_PAYIN.REFERENCE_NO;
    P_TD_PAYIN_DET.MULTIMODE_PERCENTAGE   := P_TOPUP_PAYIN.MULTIMODE_PERCENTAGE;
    P_TD_PAYIN_DET.MULITMODE_XRATE        := P_TOPUP_PAYIN.MULITMODE_XRATE;
    P_TD_PAYIN_DET.SEQNO                  := P_TOPUP_PAYIN.SEQNO;

  END PR_CONV_TDPAYINDET;

  FUNCTION FN_INSUPD_INT_LIQ_DET(P_ACC VARCHAR2, P_BRN VARCHAR2)
    RETURN BOOLEAN IS
    L_TO_DATE      DATE;
    L_FIRST_INSERT VARCHAR2(1);
    L_AVL_BAL      STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_BALREC       STTM_ACCOUNT_BALANCE%ROWTYPE;
  BEGIN

    IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_BRN, P_ACC, 'N', L_BALREC) THEN
      DEBUG.PR_DEBUG('AC',
                     'Failed in Get_Sttm_Account_Balance .. : ' || SQLERRM);
    END IF;
    L_AVL_BAL := NVL(L_BALREC.ACY_WITHDRAWABLE_BAL, 0) +
                 NVL(L_BALREC.ACY_BLOCKED_AMT, 0) +
                 NVL(L_BALREC.ACY_ECA_BLOCKED_AMT, 0);

    BEGIN
      SELECT LIQ1.TO_DATE
        INTO L_TO_DATE
        FROM ICTBS_INT_LIQ_DETAILS LIQ1
       WHERE LIQ1.ACCOUNT_NUMBER = P_ACC
         AND LIQ1.BRANCH_CODE = P_BRN
         AND LIQ1.TO_DATE =
             (SELECT MAX(TO_DATE)
                FROM ICTBS_INT_LIQ_DETAILS LIQ2
               WHERE LIQ2.ACCOUNT_NUMBER = P_ACC
                 AND LIQ2.BRANCH_CODE = P_BRN);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_TO_DATE      := GLOBAL.APPLICATION_DATE;
        L_FIRST_INSERT := 'Y';
    END;
    BEGIN
      IF L_TO_DATE < GLOBAL.APPLICATION_DATE OR L_FIRST_INSERT = 'Y' THEN
        INSERT INTO ICTBS_INT_LIQ_DETAILS
          (BRANCH_CODE, ACCOUNT_NUMBER, FROM_DATE, TO_DATE, LIQ_AMT)
        VALUES
          (P_BRN,
           P_ACC,
           GLOBAL.APPLICATION_DATE - 1,
           GLOBAL.APPLICATION_DATE,
           L_AVL_BAL);
        DBG('INSERTED INTO ICTBS_INT_LIQ_DETAILS');
      ELSE
        DBG('UPDATE ICTBS_INT_LIQ_DETAILS');
        UPDATE ICTBS_INT_LIQ_DETAILS
           SET LIQ_AMT = L_AVL_BAL
         WHERE BRANCH_CODE = P_BRN
           AND ACCOUNT_NUMBER = P_ACC
           AND TO_DATE = L_TO_DATE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('INSERT/UPDATE ICTBS_INT_LIQ_DETAILS' || SQLERRM);
        RETURN FALSE;
    END;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('populate ICTBS_INT_LIQ_DETAILS failed-->' || SQLERRM);
      RETURN FALSE;
  END FN_INSUPD_INT_LIQ_DET;

  FUNCTION FN_PAYIN_VALIDATE(P_FUNCTION_ID IN VARCHAR2,
                             P_STDTDTOP    IN OUT STPKS_STDTDTOP_MAIN.TY_STDTDTOP,
                             P_ERR_FLAG    IN OUT NUMBER) RETURN BOOLEAN IS

    GL_COUNT     NUMBER := 0;
    CASHGL_COUNT NUMBER := 0;

    L_PAYIN_TOTAL      NUMBER(22, 3) := 0;
    L_PAYIN_PERCENTAGE NUMBER(22, 3) := 0;
    L_AC_STAT_FROZEN   VARCHAR2(1);
    L_AC_STAT_NO_DR    VARCHAR2(1);

    L_PR_INT ICTMS_PR_INT%ROWTYPE;

    L_PROD            ICTM_PR_INT.PRODUCT_CODE%TYPE;
    L_AC_STAT_DORMANT VARCHAR2(1);
    CHEQUE_COUNT      NUMBER := 0;
    SAV_COUNT         NUMBER := 0;

    L_ACC_BAL        STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    OFFSETFCY_AMOUNT NUMBER;
    OFFSET_XRATE     ACTBS_HANDOFF.EXCH_RATE%TYPE;

    L_SECTORCODE    DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT       DATE;
    L_DRVALDT       DATE;
    L_LATE_CLEARING VARCHAR2(10);
    L_ERROR_CODE    VARCHAR2(10);
    L_RESULT        VARCHAR2(1);

    L_ACY_AVL_BAL   STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_BAL_MULTIMODE STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_LIM_BAL       STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    CURSOR CUR_FACILITY_LINKAGE(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTM_CUST_ACCOUNT_LINKAGES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    TYPE TY_FACILITY_LINKAGE IS TABLE OF CUR_FACILITY_LINKAGE%ROWTYPE INDEX BY BINARY_INTEGER;
    L_FACILITY_LINKAGE TY_FACILITY_LINKAGE;
    TYPE TY_EXPIRY_DATE IS TABLE OF GETM_FACILITY.LINE_EXPIRY_DATE%TYPE INDEX BY BINARY_INTEGER;
    L_EXPIRED_DATE TY_EXPIRY_DATE;
    L_ERR_CODE     ERTB_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM    VARCHAR2(2000);
    L_EXPIRY_COUNT NUMBER := 0;
    L_EXPIRY_DATE  DATE;
    L_LIAB_NO      VARCHAR2(20);

    L_BRANCH STTMS_BRANCH%ROWTYPE;

    L_TY_STDCUSAC STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_IDX1        NUMBER := 0;

    CURSOR CUR_TD_JNT_HOLDERS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM STTMS_AC_LINKED_ENTITIES
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
    TYPE TY_TD_JNT_HOLDERS IS TABLE OF STTMS_AC_LINKED_ENTITIES%ROWTYPE INDEX BY BINARY_INTEGER;
    L_TY_TD_JNT_HOLDERS TY_TD_JNT_HOLDERS;

    L_BALREC STTM_ACCOUNT_BALANCE%ROWTYPE;
  BEGIN
    DBG('Inside fn_payinout_validate');
    DBG('First checking for v_ictm_tdtopup_payin count :' ||
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);

    IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT > 0 THEN
      FOR I IN P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.FIRST .. P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.LAST LOOP
        DBG('p_stdtdtop.v_ictms_tdtopup_payin(i).multimode_payopt....' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
            .MULTIMODE_PAYOPT);
        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PAYOPT = 'S' THEN
          DBG('looping for payin details' || I || '  FIR ACCC ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_OFFSET_BRN);

          IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
           .MULTIMODE_TDOFFSET_ACC IS NULL THEN
            DBG('Payin offset account cannot be null');
            PR_LOG_ERROR('FLEXCUBE', 'ST-CUS400', '');
            P_ERR_FLAG := -1;
            RETURN FALSE;
          END IF;

          IF CUR_FACILITY_LINKAGE%ISOPEN THEN
            CLOSE CUR_FACILITY_LINKAGE;
          END IF;
          OPEN CUR_FACILITY_LINKAGE(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                    .MULTIMODE_OFFSET_BRN,
                                    P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                    .MULTIMODE_TDOFFSET_ACC);
          FETCH CUR_FACILITY_LINKAGE BULK COLLECT
            INTO L_FACILITY_LINKAGE;
          L_EXPIRY_COUNT := 0;
          IF L_FACILITY_LINKAGE.COUNT > 0 THEN
            FOR J IN 1 .. L_FACILITY_LINKAGE.COUNT LOOP
              DBG('Customer no ' || L_FACILITY_LINKAGE(J).CUSTOMER_NO);
              BEGIN
                SELECT LIABILITY_NO
                  INTO L_LIAB_NO
                  FROM STTM_CUSTOMER
                 WHERE CUSTOMER_NO = L_FACILITY_LINKAGE(J).CUSTOMER_NO;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('In when others ' || SQLERRM);
                  L_LIAB_NO := NULL;
              END;
              IF L_FACILITY_LINKAGE(J).LINKAGE_TYPE = 'F' THEN
                IF NOT
                    ELPKS_FACILITY_SERVICE.FN_GET_LINE_EXP_DT(L_FACILITY_LINKAGE(J)
                                                              .LINKED_REF_NO,
                                                              L_LIAB_NO,
                                                              L_EXPIRY_DATE,
                                                              L_ERR_CODE,
                                                              L_ERR_PARAM) THEN
                  DBG('Failed in Elpks_Facility_Service.Fn_Get_Line_Exp_Dt' ||
                      SQLERRM);
                  RETURN FALSE;
                ELSE
                  L_EXPIRED_DATE(J) := L_EXPIRY_DATE;
                END IF;
                IF (L_EXPIRED_DATE(J) < GLOBAL.APPLICATION_DATE) THEN
                  L_EXPIRY_COUNT := L_EXPIRY_COUNT + 1;
                END IF;
              END IF;
              DBG('Calculated Balance Amount greater than limit balance...error message...');
            END LOOP;
          END IF;
          CLOSE CUR_FACILITY_LINKAGE;
          IF L_EXPIRY_COUNT > 0 THEN
            DBG('Inside expired  OD lines ');
            IF NOT ACPKS_MISC.FN_GETAVLBAL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_ACC_BAL,
                                           'Y',
                                           'N',
                                           'Y') THEN
              DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
              RETURN FALSE;
            END IF;
          ELSE
            DBG('Inside available OD lines ');
            IF NOT ACPKS_MISC.FN_GETAVLBAL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                           .MULTIMODE_OFFSET_BRN,
                                           P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                           .MULTIMODE_TDOFFSET_ACC,
                                           L_ACC_BAL,
                                           'Y',
                                           'Y',
                                           'Y') THEN
              DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
              RETURN FALSE;
            END IF;
          END IF;

          DBG('Offset Branch ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_OFFSET_BRN);
          DBG('Offset Account ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_TDOFFSET_ACC);

          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                      .MULTIMODE_OFFSET_BRN,
                                                      P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                      .MULTIMODE_TDOFFSET_ACC,
                                                      'N',
                                                      L_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDOFFSET_CCY := L_BALREC.CCY;
          L_ACY_AVL_BAL := L_BALREC.ACY_WITHDRAWABLE_BAL;

          DBG('Got avl bal as --->' || L_ACC_BAL);
          DBG('tdccy ---->' || P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY);
          DBG('offsetccy ----->' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_TDOFFSET_CCY);
          DBG('global.lcy ----->' || GLOBAL.LCY);
          IF ((P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
             .MULTIMODE_TDOFFSET_CCY = GLOBAL.LCY) AND
             (P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY = GLOBAL.LCY)) OR
             (P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
             .MULTIMODE_TDOFFSET_CCY = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY) THEN
            DBG('In the case where td , offset ccy r same as local ccy....');
            DBG('hv to compare acc avl bal with offset lcy amt.....');

            IF (NVL(L_ACY_AVL_BAL, 0) <
               NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT,
                    0)) THEN
              DBG('TD Amount greater than available balance...calculating balance amount...');
              IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                L_BAL_MULTIMODE := NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                       .MULTIMODE_TDAMOUNT,
                                       0) - NVL(L_ACY_AVL_BAL, 0);
              ELSE
                L_BAL_MULTIMODE := NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                       .MULTIMODE_TDAMOUNT,
                                       0);
              END IF;
              IF (NVL(L_ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                DBG('Total Amount greater than available balance...calculating limit balance amount...');
                IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                  L_LIM_BAL := NVL(L_ACC_BAL, 0) - NVL(L_ACY_AVL_BAL, 0);
                ELSE
                  L_LIM_BAL := NVL(L_ACC_BAL, 0);
                END IF;
              END IF;
              IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                    L_LIM_BAL || ' balance Td amount ' || L_BAL_MULTIMODE);
                L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                               .MULTIMODE_TDOFFSET_ACC;
                PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-010', L_ERR_PARAM);

              ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                IF L_EXPIRY_COUNT > 0 THEN
                  DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-012', L_ERR_PARAM);
                ELSE
                  DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-011', L_ERR_PARAM);
                END IF;
              END IF;
            END IF;

          ELSE
            OFFSETFCY_AMOUNT := NULL;
            OFFSET_XRATE     := NULL;
            DBG('its in the else part of forign currency');

            IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN     (I).BRN,
                                               P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY,
                                               P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN     (I)
                                               .MULTIMODE_TDOFFSET_CCY,
                                               P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN     (I)
                                               .MULTIMODE_TDAMOUNT,
                                               'Y',
                                               OFFSETFCY_AMOUNT,
                                               OFFSET_XRATE,
                                               P_ERR_FLAG) THEN
              DBG('failed');
              DBG(SQLERRM);
              RETURN FALSE;
            END IF;
            DBG('so comparing acc avl bal with offset fcy amt...as this will hv the td offset amt in ac ccy...');

            IF (NVL(L_ACY_AVL_BAL, 0) < NVL(OFFSETFCY_AMOUNT, 0)) THEN

              DBG('TD Amount greater than available balance...calculating balance amount...');
              IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0) -
                                   NVL(L_ACY_AVL_BAL, 0);
              ELSE
                L_BAL_MULTIMODE := NVL(OFFSETFCY_AMOUNT, 0);
              END IF;
              IF (NVL(L_ACY_AVL_BAL, 0) <= NVL(L_ACC_BAL, 0)) THEN
                DBG('Total Amount greater than available balance...calculating limit balance amount...');
                IF NVL(L_ACY_AVL_BAL, 0) > 0 THEN
                  L_LIM_BAL := NVL(L_ACC_BAL, 0) - NVL(L_ACY_AVL_BAL, 0);
                ELSE
                  L_LIM_BAL := NVL(L_ACC_BAL, 0);
                END IF;
              END IF;
              IF (NVL(L_BAL_MULTIMODE, 0) <= NVL(L_LIM_BAL, 0)) THEN
                DBG('Calculated Balance Amount less than limit balance...override message... ' ||
                    L_LIM_BAL || ' balance Td amount ' || L_BAL_MULTIMODE);
                L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                               .MULTIMODE_TDOFFSET_ACC;
                PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-010', L_ERR_PARAM);

              ELSIF (NVL(L_BAL_MULTIMODE, 0) > NVL(L_LIM_BAL, 0)) THEN
                IF L_EXPIRY_COUNT > 0 THEN
                  DBG('Calculated Balance Amount greater than limit balance expired error message ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-012', L_ERR_PARAM);
                ELSE
                  DBG('Calculated Balance Amount greater than limit balance avl error message ' ||
                      L_LIM_BAL || ' balance Td amount ' ||
                      L_BAL_MULTIMODE);
                  L_ERR_PARAM := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                 .MULTIMODE_TDOFFSET_ACC;
                  PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-011', L_ERR_PARAM);
                END IF;
              END IF;
            END IF;

          END IF;

          L_IDX1 := L_IDX1 + 1;
          L_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(L_IDX1).MULTIMODE_OFFSET_BRN := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                                                .MULTIMODE_OFFSET_BRN;
          L_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(L_IDX1).MULTIMODE_TDOFFSET_ACC := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                                                  .MULTIMODE_TDOFFSET_ACC;
          L_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(L_IDX1).MULTIMODE_PAYOPT := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                                            .MULTIMODE_PAYOPT;

        END IF;
      END LOOP;
    END IF;

    IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT > 0 THEN

      L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PROD);

      IF NVL(L_PR_INT.PAYMENT_METHOD, 'B') = 'D' THEN

        DBG('Top-Up is not allowed for Discounted Deposit');
        PR_LOG_ERROR('FLEXCUBE', 'ST-TOP-001', '');
        P_ERR_FLAG := -1;
      END IF;

      DBG('looping for payin details');
      FOR I IN P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.FIRST .. P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.LAST LOOP

        DBG('payin--->' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
            .MULTIMODE_PAYOPT);

        L_PAYIN_TOTAL := L_PAYIN_TOTAL + P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                        .MULTIMODE_TDAMOUNT;

        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
         .MULTIMODE_PERCENTAGE IS NOT NULL THEN
          L_PAYIN_PERCENTAGE := L_PAYIN_PERCENTAGE + P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                               .MULTIMODE_PERCENTAGE;
        END IF;

        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
         .MULTIMODE_PAYOPT NOT IN ('S', 'G', 'C') OR P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
           .MULTIMODE_PAYOPT IS NULL THEN
          PR_LOG_ERROR('FLEXCUBE',
                       'ST-TD-100',
                       '@ICTMS_TD_DETAILS.PAYIN_OPTION~');
          P_ERR_FLAG := -1;
        END IF;
        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PAYOPT = 'S' THEN
          IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
           .MULTIMODE_OFFSET_BRN IS NULL OR P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
             .MULTIMODE_TDOFFSET_ACC IS NULL THEN
            PR_LOG_ERROR('FLEXCUBE', 'ST-TD-129', '');
            P_ERR_FLAG := -1;
          END IF;

          L_BRANCH := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                    .MULTIMODE_OFFSET_BRN);

          IF L_BRANCH.BRANCH_CODE IS NULL THEN

            PR_LOG_ERROR('FLEXCUBE',
                         'ST-ACC-115',
                         '@ICTMS_TD_DETAILS.OFFSET_BRN~' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_OFFSET_BRN || '~');
            P_ERR_FLAG := -1;
          END IF;
          DBG('p_stdtdtop.v_ictms_tdtopup_payin(i).multimode_tdoffset_acc: ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_TDOFFSET_ACC);
          DBG('p_stdtdtop.v_ictms_tdtopup_payin(i).multimode_offset_brn: ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_OFFSET_BRN);

          BEGIN
            SELECT NVL(AC_STAT_FROZEN, 'N'),
                   NVL(AC_STAT_NO_DR, 'N'),
                   NVL(AC_STAT_DORMANT, 'N')
              INTO L_AC_STAT_FROZEN, L_AC_STAT_NO_DR, L_AC_STAT_DORMANT
              FROM STTMS_CUST_ACCOUNT
             WHERE BRANCH_CODE = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                  .MULTIMODE_OFFSET_BRN
               AND ACCOUNT_TYPE <> 'Y'
               AND AUTH_STAT = 'A'
               AND RECORD_STAT = 'O'
               AND CUST_AC_NO = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                  .MULTIMODE_TDOFFSET_ACC;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              PR_LOG_ERROR('FLEXCUBE',
                           'ST-ACC-115',
                           '@ICTMS_TD_DETAILS.OFFSET_ACC~' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                           .MULTIMODE_TDOFFSET_ACC || '~');
              P_ERR_FLAG := -1;
          END;

          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                      .MULTIMODE_OFFSET_BRN,
                                                      P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                      .MULTIMODE_TDOFFSET_ACC,
                                                      'N',
                                                      L_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          L_AC_STAT_DORMANT := L_BALREC.AC_STAT_DORMANT;

          IF L_AC_STAT_FROZEN = 'Y' THEN
            PR_LOG_ERROR('FLEXCUBE',
                         'AC-VAC04',
                         '@ICTMS_TD_DETAILS.OFFSET_ACC~' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_TDOFFSET_ACC || '~');
            P_ERR_FLAG := -1;
          END IF;
          IF L_AC_STAT_NO_DR = 'Y' THEN
            PR_LOG_ERROR('FLEXCUBE',
                         'AC-VAC07',
                         '@' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_TDOFFSET_ACC || '~');
            P_ERR_FLAG := -1;
          END IF;

          IF L_AC_STAT_DORMANT = 'Y' THEN
            PR_LOG_ERROR('FLEXCUBE',
                         'AC-VAC05',
                         '@' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                         .MULTIMODE_TDOFFSET_ACC || '~');
            P_ERR_FLAG := -1;
          END IF;

          SAV_COUNT := SAV_COUNT + 1;
        ELSIF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PAYOPT = 'G' THEN
          GL_COUNT := GL_COUNT + 1;
        ELSIF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PAYOPT = 'C' THEN
          CASHGL_COUNT := CASHGL_COUNT + 1;

        END IF;

      END LOOP;
    ELSE
      DBG('No payin details entered');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR('FLEXCUBE', 'ST-TOP-003', '');
    END IF;
    IF GL_COUNT > 1 OR CASHGL_COUNT > 1 THEN
      DBG('payin for GL or Cash cannot be greater than 1');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-214', '');
    END IF;

    DBG('cheque_count-->' || CHEQUE_COUNT);
    DBG('sav_count-->' || SAV_COUNT);
    DBG('gl_count-->' || GL_COUNT);
    DBG('cashgl_count -->' || CASHGL_COUNT);

    DBG('l_payin_total is :' || L_PAYIN_TOTAL);

    IF L_PAYIN_TOTAL <> P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT THEN
      DBG('Payin Details is not equal to Top-Up amount');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR('FLEXCUBE', 'ST-TOP-016', '');
    END IF;

    DBG('l_payin_percentage is :' || L_PAYIN_PERCENTAGE);

    IF NOT (L_PAYIN_PERCENTAGE = 0 OR L_PAYIN_PERCENTAGE = 100) THEN
      DBG('Total Payin Percentage is not consistent');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-207', '');
    END IF;

    L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC;
    L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN;
    L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY         := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY;
    L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO     := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CUST_NO;

    DBG('TD brn-->' || L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('TD acc-->' || L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

    BEGIN
      SELECT JOINT_AC_INDICATOR
        INTO L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR
        FROM STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
         AND CUST_AC_NO = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED INS ELECT' || SQLERRM);
    END;
    DBG('JOINT_AC_INDICATOR-->' ||
        L_TY_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);
    IF CUR_TD_JNT_HOLDERS%ISOPEN THEN
      CLOSE CUR_TD_JNT_HOLDERS;
    END IF;
    OPEN CUR_TD_JNT_HOLDERS(P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN,
                            P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC);
    FETCH CUR_TD_JNT_HOLDERS BULK COLLECT
      INTO L_TY_TD_JNT_HOLDERS;
    CLOSE CUR_TD_JNT_HOLDERS;
    DBG('TD joint holders count-->' || L_TY_TD_JNT_HOLDERS.COUNT);
    IF L_TY_TD_JNT_HOLDERS.COUNT > 0 THEN
      FOR K IN L_TY_TD_JNT_HOLDERS.FIRST .. L_TY_TD_JNT_HOLDERS.LAST LOOP
        L_TY_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(K) := L_TY_TD_JNT_HOLDERS(K);
      END LOOP;
    END IF;
    DBG('calling stpks_stdcusac_utils_1.fn_validate_joint_holders');
    DBG('Top up payin count' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);
    DBG('CASA PAYIN details' ||
        L_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);

    IF L_TY_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_1.FN_VALIDATE_JOINT_HOLDERS('STDTDTOP',
                                                           L_TY_STDCUSAC) THEN
        DBG('FAILED IN STPKS_STDCUSAC_UTILS_1.fn_validate_joint_holders' ||
            SQLERRM);
      END IF;

    END IF;

    RETURN TRUE;
  END FN_PAYIN_VALIDATE;

  FUNCTION FN_PAYIN_DEFAULT(P_FUNCTION_ID IN VARCHAR2,
                            P_STDTDTOP    IN OUT STPKS_STDTDTOP_MAIN.TY_STDTDTOP,
                            P_ACTION_CODE IN VARCHAR2,
                            P_ERR_FLAG    IN OUT NUMBER) RETURN BOOLEAN IS

    L_CCY_RES     VARCHAR2(1);
    L_CCY_S       VARCHAR2(3);
    L_LOCAL_CCY   VARCHAR2(3);
    L_ROW_AMT     NUMBER(22, 3) := 0;
    L_TOTAL       NUMBER(22, 3) := 0;
    L_INSEQNO     NUMBER := 1;
    L_CASH_GL     DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_WF_ROW      STTMS_BRANCH_WF_DEF_MASTER%ROWTYPE;
    L_PAYIN_TOTAL NUMBER(22, 3) := 0;
    I             NUMBER;
    L_CCY         VARCHAR2(3);

    L_GL_MASTER  GLTMS_GLMASTER%ROWTYPE;
    L_BRANCH_REC STTMS_BRANCH%ROWTYPE;
    L_PAYIN_REC  STTMS_PAYIN_MODE%ROWTYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Inside fn_payinout_default ' ||
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);
    BEGIN
      SELECT NVL(MAX(SEQNO), 1)
        INTO L_INSEQNO

        FROM ICTM_TDTOPUP_PAYIN
       WHERE BRN = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN
         AND ACC = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC
         AND CCY = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_INSEQNO := 1;
      WHEN OTHERS THEN
        DBG('Failed to index the payin details');
        RETURN FALSE;
    END;

    DBG('First checking for v_ictm_tdtopup_payin count :' ||
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);
    IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT > 0 THEN
      DBG('looping for payin details');
      FOR I IN P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.FIRST .. P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.LAST LOOP
        DBG('payin loop count :' || I);
        DBG('payin Seq cnt :' || L_INSEQNO);
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).BRN := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN;
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).ACC := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC;
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).CCY := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY;
        P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).SEQNO := L_INSEQNO;

        DBG('multimode_tdamount :' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
            .MULTIMODE_TDAMOUNT);
        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT IS NULL THEN
          DBG('multimode_percentage :' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_PERCENTAGE);

          IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
           .MULTIMODE_PERCENTAGE IS NOT NULL THEN
            IF I = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT THEN
              P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT -
                                                                        L_TOTAL;
            ELSE
              L_ROW_AMT := (P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                           .MULTIMODE_PERCENTAGE *
                            P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT) /
                           100.00;
              L_TOTAL := L_TOTAL + L_ROW_AMT;
              P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT := L_ROW_AMT;
            END IF;
          ELSE
            DBG('Both Percentage or Payin Amount cannot be null');
            P_ERR_FLAG := -1;
            PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-210', '');
          END IF;
        END IF;
        DBG('l_total :' || L_TOTAL);
        DBG('multimode_tdamount for ' || I || 'row is  :' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
            .MULTIMODE_TDAMOUNT);

        IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
         .MULTIMODE_PAYOPT NOT IN ('S', 'Y') THEN
          DBG('Payin Option: ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_PAYOPT);

          DBG('Selecting GL code from the branch for pay in option : ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_PAYOPT);

          BEGIN

            IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
             .MULTIMODE_PAYOPT NOT IN ('C') THEN
              L_PAYIN_REC := TDPKS_UTILS.FN_GET_PAYIN_MODE(P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN,
                                                           P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                           .MULTIMODE_PAYOPT);

            END IF;

            DBG('Selecting GL code from the branch for pay in option CASH for TDTP ');
            DBG('The branch code is ' ||
                P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN);
            DBG('The TILL ID is ' || CSPKSS_ARC.G_TILL_ID);
            DBG('The currency code is ' ||
                P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY);

            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;

              L_TB_CLUSTER_DATA('I') := I;

              L_TB_CLUSTER_DATA('GL_CODE') := L_PAYIN_REC.GL_CODE;
              DBG('Calling stpks_stdtdtop_utils_cluster.fn_payin_default');
              IF NOT
                  STPKS_STDTDTOP_UTILS_CLUSTER.FN_PAYIN_DEFAULT(P_FUNCTION_ID,
                                                                P_STDTDTOP,
                                                                P_ACTION_CODE,
                                                                P_ERR_FLAG,
                                                                L_FN_CALL_ID,
                                                                L_TB_CLUSTER_DATA) THEN
                DBG('Failure has happened in stpks_stdtdtop_utils_cluster.fn_payin_default');
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                RETURN FALSE;
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('I') THEN
                DBG('returned with' || L_TB_CLUSTER_DATA('I') || '#');
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('GL_CODE') THEN
                L_PAYIN_REC.GL_CODE := L_TB_CLUSTER_DATA('GL_CODE');
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              IF GWPKS_UTIL.PKG_ACTTYPE IN ('SAVEAUTOAUTH') THEN
                IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                 .MULTIMODE_PAYOPT IN ('C') THEN
                  SELECT CASH_GL
                    INTO L_PAYIN_REC.GL_CODE
                    FROM DETMS_TIL_VLT_CCY_PARAMS A, DETM_TIL_VLT_MASTER B
                   WHERE A.BRANCH_CODE = B.BRANCH_CODE
                     AND A.TILL_ID = B.TILL_ID

                     AND A.BRANCH_CODE = GWPKS_TDTOPUPCREATE.G_BRNCODE

                     AND A.TILL_ID = CSPKSS_ARC.G_TILL_ID
                     AND A.CCY_CD = P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY
                     AND B.AUTH_STAT = 'A'
                     AND B.RECORD_STAT = 'O';
                  DBG('Selecting GL code from the till is ' ||
                      L_PAYIN_REC.GL_CODE);
                END IF;
              END IF;
              DBG('Finally the l_payin_rec.gl_code is' ||
                  L_PAYIN_REC.GL_CODE);

              P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_OFFSET_BRN := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN;

            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;

            P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDOFFSET_ACC := L_PAYIN_REC.GL_CODE;

            IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PAYOPT IN ('C') THEN
              P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_OFFSET_BRN := GWPKS_TDTOPUPCREATE.G_BRNCODE;
            END IF;

            DBG('Offset GL for Option: ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_TDOFFSET_ACC);
            DBG('Offset BRN  for Option: ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_OFFSET_BRN);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('GL Code is not maintained');
              PR_LOG_ERROR('FLEXCUBE',
                           'ST-ACC-120',
                           P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN || '~' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                           .MULTIMODE_PAYOPT || '~');
              P_ERR_FLAG := -1;
              RETURN FALSE;
            WHEN OTHERS THEN
              DBG('GL Code is not maintained: ' || SQLERRM);
              PR_LOG_ERROR('FLEXCUBE',
                           'ST-ACC-120',
                           P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN || '~' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                           .MULTIMODE_PAYOPT || '~');
              P_ERR_FLAG := -1;
              RETURN FALSE;
          END;
          IF L_PAYIN_REC.GL_CODE IS NOT NULL THEN

            BEGIN

              L_GL_MASTER  := CSPKS_FUNCTION_CACHE.FN_GET_GL_MASTER_REC_FRC(L_PAYIN_REC.GL_CODE);
              L_BRANCH_REC := GLOBAL_FRC.FN_GET_BRN_REC_FRC(P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN);

              IF (NVL(L_GL_MASTER.CCY_RES, '#') = 'F' AND
                 P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY =
                 L_BRANCH_REC.BRANCH_LCY) OR
                 (NVL(L_GL_MASTER.CCY_RES, '#') = 'S' AND
                 L_GL_MASTER.RES_CCY <>
                 P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY) THEN
                PR_LOG_ERROR('FLEXCUBE',
                             'AC-VGL01',
                             L_PAYIN_REC.GL_CODE || '~' ||
                             P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY || '~');
                P_ERR_FLAG := -1;
              END IF;

            EXCEPTION
              WHEN OTHERS THEN
                DBG('In WOT of select statement in fn_deposit_def_validate with: ' ||
                    SQLERRM || ' and trace: ' ||
                    DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                PR_LOG_ERROR('FLEXCUBE', 'ST-UPCA0033', '');
                P_ERR_FLAG := -1;
            END;
          END IF;
        END IF;
        L_INSEQNO := L_INSEQNO + 1;
      END LOOP;
    ELSE
      DBG('No payin details entered');
      P_ERR_FLAG := -1;
      PR_LOG_ERROR('FLEXCUBE', 'ST-ACC-197', '');
    END IF;

    DBG('Pay in Count------>' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT);
    I := P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT;
    IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT > 0 THEN
      FOR I IN 1 .. P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT LOOP
        IF NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_PERCENTAGE, 0) > 0 THEN
          DBG('Pay in Percentage--->' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
              .MULTIMODE_PERCENTAGE);

          IF I = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT THEN
            DBG('Last record in pay-in details');
            P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT -
                                                                      L_PAYIN_TOTAL;
            DBG('amount ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_TDAMOUNT);
          ELSE

            P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I).MULTIMODE_TDAMOUNT := (P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT *
                                                                      NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                                                           .MULTIMODE_PERCENTAGE,
                                                                           0) / 100);

            DBG('p_stdtdtop.v_ictms_tdtopup_payin(i).MULTIMODE_PAYOPT' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_PAYOPT);
            DBG('p_stdtdtop.v_ictms_tdtopup_payin(i).MULTIMODE_TDOFFSET_CCY' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_TDOFFSET_CCY);
            IF P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
             .MULTIMODE_TDOFFSET_CCY = 'S' THEN
              SELECT CCY
                INTO L_CCY
                FROM STTM_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                    .MULTIMODE_TDOFFSET_ACC
                 AND BRANCH_CODE = P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                    .MULTIMODE_OFFSET_BRN;
            ELSE
              L_CCY := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY;

            END IF;

            DBG('l_ccy ' || L_CCY);
            IF NOT CYPKSS.FN_AMT_ROUND(L_CCY,
                                       P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                       .MULTIMODE_TDAMOUNT,
                                       P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                       .MULTIMODE_TDAMOUNT) THEN
              DBG('Failed in doing Round OFF of amount to offset currency');
            END IF;
            DBG('After Round OFF l_tdpayout_rec.redmamt  ' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                .MULTIMODE_TDAMOUNT);
          END IF;

        END IF;
        L_PAYIN_TOTAL := L_PAYIN_TOTAL + NVL(P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
                                             .MULTIMODE_TDAMOUNT,
                                             0);
        DBG('TDAMT--->' || P_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(I)
            .MULTIMODE_TDAMOUNT);
      END LOOP;
    END IF;
    DBG('l_payin_total--->' || L_PAYIN_TOTAL);

    RETURN TRUE;
  END FN_PAYIN_DEFAULT;

  FUNCTION FN_GET_LAST_FIN_TXN(P_BRN              IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                               P_ACC              IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                               P_TOPUP_VALUE_DATE IN DATE)

   RETURN BOOLEAN IS
    L_COUNT NUMBER := 0;
    L_DATE  DATE;
  BEGIN
    DBG('In fn_get_last_fin_txn');

    SELECT COUNT(*)
      INTO L_COUNT

      FROM TDTB_EVENT_DETAILS

     WHERE ACC = P_ACC
       AND BRN = P_BRN
       AND EVENT_DATE > P_TOPUP_VALUE_DATE;
    IF L_COUNT > 0 THEN
      BEGIN
        SELECT MAX(EVENT_DATE)
          INTO L_DATE

          FROM TDTB_EVENT_DETAILS

         WHERE ACC = P_ACC
           AND BRN = P_BRN
         ORDER BY EVENT_DATE;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('wrror while fetching max of event date ' || SQLERRM ||
              ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

      END;
      IF L_DATE > P_TOPUP_VALUE_DATE THEN
        DBG('Top up can be back value dated only up to the value date of the last financial transaction' ||
            L_COUNT || '~' || L_DATE);
        PR_LOG_ERROR('FLEXCUBE', 'ST-TOP-004', L_DATE);
        RETURN FALSE;
      END IF;
    END IF;

    RETURN TRUE;

  END FN_GET_LAST_FIN_TXN;

  FUNCTION FN_FIND_LIQD_AMT(P_BRN       IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                            P_ACC       IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                            P_PROD      IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                            P_FROM_DATE IN DATE,

                            P_LIQD_AMT   OUT DBMS_SQL.NUMBER_TABLE,
                            P_TAX_AMT    OUT DBMS_SQL.NUMBER_TABLE,
                            P_ERROR_CODE IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_START_DT          DATE;
    L_TO_DATE           DATE;
    L_FLAG              NUMBER := 0;
    L_AMT_LIQD_TILLDATE DBMS_SQL.NUMBER_TABLE;
    L_AMT_TAX_TILLDATE  DBMS_SQL.NUMBER_TABLE;

    L_REC_ICTM_ACC ICTM_ACC%ROWTYPE;
    L_LIQ_INT      NUMBER := 0;

    L_BROKEN_DATE ICTB_TD_BROKEN.BROKEN_DATE%TYPE;
    L_SEQ_NO      ICTB_TD_BROKEN.SEQ_NO%TYPE;

    L_PREV_LIQN_DATE DATE;
    L_RULE           ICTM_PR_INT.RULE%TYPE;
    L_PROD_REC       ICTM_PR_INT%ROWTYPE;
  BEGIN
    DBG('Inside FN_FIND_LIQD_AMT');

    L_TO_DATE := GLOBAL.APPLICATION_DATE;

    P_LIQD_AMT.DELETE;

    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);

    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(P_PROD);
    L_RULE     := L_PROD_REC.RULE;

    DBG('Before Computing liquidation amount' || P_FROM_DATE);

    FOR EACH_REC IN (SELECT HIS.*
                       FROM ICTB_ENTRIES_HISTORY HIS, ICTM_RULE_FRM B
                      WHERE B.FRM_NO = HIS.FRM_NO
                        AND HIS.BRN = P_BRN
                        AND HIS.ACC = P_ACC
                        AND HIS.PROD = P_PROD
                        AND B.RULE_ID = L_RULE

                        AND HIS.LIQN = 'Y'
                        AND HIS.ENTRY_PASSED = 'Y'
                        AND HIS.ENT_DT >= P_FROM_DATE
                        AND B.BOOK_FLAG = 'B'
                      ORDER BY ENT_DT DESC) LOOP

      BEGIN

        L_BROKEN_DATE := NULL;
        BEGIN
          SELECT MAX(BROKEN_DATE)
            INTO L_BROKEN_DATE
            FROM ICTB_TD_BROKEN
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND LIQD = 'Y'
             AND NVL(IS_TAX, 'N') = 'N'
             AND NVL(IS_PENALTY, 'N') = 'N'
             AND NVL(ACCR, 'N') = 'N'
             AND FRM_NO = EACH_REC.FRM_NO
             AND BROKEN_DATE > EACH_REC.ENT_DT
             AND BROKEN_DATE <= L_TO_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_BROKEN_DATE := NULL;
            DBG(SQLERRM);
        END;

        DBG('l_broken_date~l_prev_liqn_date~each_rec.ent_dt~each_rec.frm_no' ||
            L_BROKEN_DATE || '~' || L_PREV_LIQN_DATE || '~' ||
            EACH_REC.ENT_DT || '~' || EACH_REC.FRM_NO);
        IF L_PREV_LIQN_DATE IS NOT NULL THEN
          DBG('Redemption entry identified in broken td already for date' ||
              L_PREV_LIQN_DATE ||
              'should not refer entries history anymore');
          IF EACH_REC.ENT_DT != L_PREV_LIQN_DATE THEN
            DBG('Interest liqn date for different date ..exit the loop');
            EXIT;
          END IF;
        END IF;

        IF L_BROKEN_DATE IS NOT NULL THEN
          DBG('l_broken_date' || L_BROKEN_DATE);
          L_SEQ_NO := 0;
          BEGIN
            SELECT NVL(MAX(SEQ_NO), 0)
              INTO L_SEQ_NO
              FROM ICTB_TD_BROKEN
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND LIQD = 'Y'
               AND NVL(IS_TAX, 'N') = 'N'
               AND NVL(IS_PENALTY, 'N') = 'N'
               AND NVL(ACCR, 'N') = 'N'
               AND FRM_NO = EACH_REC.FRM_NO
               AND BROKEN_DATE = L_BROKEN_DATE;
          EXCEPTION
            WHEN OTHERS THEN
              L_SEQ_NO := 0;
              DBG(SQLERRM);
          END;

          FOR EACH_BR_TD IN (SELECT *
                               FROM ICTB_TD_BROKEN
                              WHERE BRN = EACH_REC.BRN
                                AND ACC = EACH_REC.ACC
                                AND LIQD = 'Y'
                                AND NVL(IS_TAX, 'N') = 'N'
                                AND NVL(IS_PENALTY, 'N') = 'N'
                                AND NVL(ACCR, 'N') = 'N'
                                AND FRM_NO = EACH_REC.FRM_NO

                                AND BROKEN_DATE = L_BROKEN_DATE
                                AND NVL(SEQ_NO, 0) = L_SEQ_NO)

           LOOP

            L_PREV_LIQN_DATE := EACH_REC.ENT_DT;
            IF L_AMT_LIQD_TILLDATE.EXISTS(EACH_BR_TD.FRM_NO) THEN

              L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) := L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) +
                                                        EACH_BR_TD.NEW_LIQD_AMT;

            ELSE

              L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO) := EACH_BR_TD.NEW_LIQD_AMT;

            END IF;
            DBG('each_br_td.frm_no .. ' || EACH_BR_TD.FRM_NO);
            DBG('l_amt_liqd_tilldate(each_br_td.frm_no) .. ' ||
                L_AMT_LIQD_TILLDATE(EACH_BR_TD.FRM_NO));

            DBG('each_br_td.new_liqd_amt  .. ' || EACH_BR_TD.NEW_LIQD_AMT);

            L_FLAG := 1;
            EXIT;
          END LOOP;
        END IF;
        IF L_FLAG <> 1 THEN
          DBG('each_rec.amt  .. ' || EACH_REC.AMT);

          IF L_AMT_LIQD_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN

            L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) +
                                                    EACH_REC.AMT;

          ELSE

            L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := EACH_REC.AMT;

          END IF;
          DBG('each_rec.frm_no .. ' || EACH_REC.FRM_NO);
          DBG('each_rec.amt  .. ' || EACH_REC.AMT);
          DBG('l_amt_liqd_tilldate(each_rec.frm_no) .. ' ||
              L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO));

        END IF;

        IF L_FLAG = 1 THEN

          DBG('Liquidated int amount tillnow:' ||
              L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO));

          IF G_INT_LIQD.EXISTS(EACH_REC.FRM_NO) THEN
            DBG('g_int_liqd' || G_INT_LIQD(EACH_REC.FRM_NO));
            L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) := L_AMT_LIQD_TILLDATE(EACH_REC.FRM_NO) -
                                                    NVL(G_INT_LIQD(EACH_REC.FRM_NO),
                                                        0);
          END IF;

        END IF;

        L_TO_DATE := EACH_REC.ENT_DT;
        L_FLAG    := 0;
      END;
    END LOOP;

    P_LIQD_AMT := L_AMT_LIQD_TILLDATE;

    DBG('Before Computing tax amount');
    L_FLAG := 0;

    L_TO_DATE        := GLOBAL.APPLICATION_DATE;
    L_PREV_LIQN_DATE := NULL;

    FOR EACH_REC IN (SELECT *
                       FROM ICTB_ENTRIES_HISTORY
                      WHERE BRN = P_BRN
                        AND ACC = P_ACC
                        AND PROD = P_PROD
                        AND DRCR = 'D'
                        AND LIQN = 'Y'
                        AND ENTRY_PASSED = 'Y'
                        AND ENT_DT >= P_FROM_DATE
                      ORDER BY ENT_DT DESC) LOOP

      BEGIN

        L_BROKEN_DATE := NULL;
        BEGIN
          SELECT MAX(BROKEN_DATE)
            INTO L_BROKEN_DATE
            FROM ICTB_TD_BROKEN
           WHERE BRN = P_BRN
             AND ACC = P_ACC
             AND LIQD = 'Y'
             AND NVL(IS_TAX, 'N') = 'Y'
             AND NVL(IS_PENALTY, 'N') = 'N'
             AND NVL(ACCR, 'N') = 'N'
             AND FRM_NO = EACH_REC.FRM_NO
             AND BROKEN_DATE > EACH_REC.ENT_DT
             AND BROKEN_DATE <= L_TO_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_BROKEN_DATE := NULL;
        END;

        DBG('l_broken_date~l_prev_liqn_date~each_rec.ent_dt~each_rec.frm_no' ||
            L_BROKEN_DATE || '~' || L_PREV_LIQN_DATE || '~' ||
            EACH_REC.ENT_DT || '~' || EACH_REC.FRM_NO);
        IF L_PREV_LIQN_DATE IS NOT NULL THEN
          DBG('Redemption entry identified in broken td already for date' ||
              L_PREV_LIQN_DATE ||
              'should not refer entries history anymore');
          IF EACH_REC.ENT_DT != L_PREV_LIQN_DATE THEN
            DBG('Tax liqn date for different date ..exit the loop');
            EXIT;
          END IF;
        END IF;

        IF L_BROKEN_DATE IS NOT NULL THEN
          L_SEQ_NO := 0;
          BEGIN
            SELECT NVL(MAX(SEQ_NO), 0)
              INTO L_SEQ_NO
              FROM ICTB_TD_BROKEN
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND LIQD = 'Y'
               AND NVL(IS_TAX, 'N') = 'Y'
               AND NVL(IS_PENALTY, 'N') = 'N'
               AND NVL(ACCR, 'N') = 'N'
               AND FRM_NO = EACH_REC.FRM_NO
               AND BROKEN_DATE = L_BROKEN_DATE;
          EXCEPTION
            WHEN OTHERS THEN
              L_SEQ_NO := 0;
              DBG(SQLERRM);
          END;

          FOR EACH_BR_TD IN (SELECT *
                               FROM ICTB_TD_BROKEN
                              WHERE BRN = EACH_REC.BRN
                                AND ACC = EACH_REC.ACC
                                AND LIQD = 'Y'
                                AND NVL(IS_TAX, 'N') = 'Y'
                                AND NVL(IS_PENALTY, 'N') = 'N'
                                AND NVL(ACCR, 'N') = 'N'

                                AND BROKEN_DATE = L_BROKEN_DATE
                                AND FRM_NO = EACH_REC.FRM_NO
                                AND NVL(SEQ_NO, 0) = L_SEQ_NO)

           LOOP

            L_PREV_LIQN_DATE := EACH_REC.ENT_DT;
            IF L_AMT_TAX_TILLDATE.EXISTS(EACH_BR_TD.FRM_NO) THEN
              L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) := L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) +
                                                       EACH_BR_TD.NEW_LIQD_AMT;

            ELSE
              L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO) := EACH_BR_TD.NEW_LIQD_AMT;
            END IF;
            DBG('each_br_td.frm_no .. ' || EACH_BR_TD.FRM_NO);
            DBG('each_br_td.new_liqd_amt  .. ' || EACH_BR_TD.NEW_LIQD_AMT);
            DBG('l_amt_tax_tilldate(each_br_td.frm_no) .. ' ||
                L_AMT_TAX_TILLDATE(EACH_BR_TD.FRM_NO));

            L_FLAG := 1;
            EXIT;
          END LOOP;
        END IF;
        IF L_FLAG <> 1 THEN

          IF L_AMT_TAX_TILLDATE.EXISTS(EACH_REC.FRM_NO) THEN
            L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) +
                                                   EACH_REC.AMT;
          ELSE
            L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := EACH_REC.AMT;
          END IF;
          DBG('each_rec.frm_no .. ' || EACH_REC.FRM_NO);
          DBG('each_rec.amt  .. ' || EACH_REC.AMT);
          DBG('l_amt_tax_tilldate(each_rec.frm_no) .. ' ||
              L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO));

        END IF;

        IF L_FLAG = 1 THEN

          IF G_TAX_LIQD.EXISTS(EACH_REC.FRM_NO) THEN
            DBG('Liquidated tax amount tillnow:' ||
                L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) || '~' ||
                G_TAX_LIQD(EACH_REC.FRM_NO));
            L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) := L_AMT_TAX_TILLDATE(EACH_REC.FRM_NO) -
                                                   NVL(G_TAX_LIQD(EACH_REC.FRM_NO),
                                                       0);
          END IF;

          EXIT;
        END IF;

        L_TO_DATE := EACH_REC.ENT_DT;
        L_FLAG    := 0;
      END;
    END LOOP;

    P_TAX_AMT := L_AMT_TAX_TILLDATE;

    DBG('Successfully coming out of fn_find_liqd_amt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in wot of fn_find_liqd_amt-->' || SQLERRM);
      DBG(' Tracer-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERROR_CODE := 'IC-MU0008';
      RETURN FALSE;
  END FN_FIND_LIQD_AMT;

  FUNCTION FN_TOPUP_TD(P_TOPUP_REF IN VARCHAR2,
                       P_TD_ACC    IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                       P_TD_BRN    IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                       P_TD_CCY    IN STTM_CUST_ACCOUNT.CCY%TYPE,
                       P_ERR_CODE  OUT ERTBS_MSGS.ERR_CODE%TYPE,
                       P_ERR_PARAM OUT ERTBS_MSGS.MESSAGE%TYPE)
    RETURN BOOLEAN IS

    TDAMOUNT     NUMBER;
    OFFSETACC    STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    OFFSETBRN    STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    OFFSETCCY    STTM_CUST_ACCOUNT.CCY%TYPE;
    L_SERIAL_NO  VARCHAR2(15);
    L_TXN_REF_NO VARCHAR2(16);
    L_PROD       ICTM_ACC_PR.PROD%TYPE;
    PAY_MTHD     VARCHAR2(1);

    TDFCY_AMOUNT     NUMBER;
    OFFSETFCY_AMOUNT NUMBER;
    TDLCY_AMOUNT     NUMBER;
    OFFSETLCY_AMOUNT NUMBER;
    OFFSET_XRATE     ACTBS_HANDOFF.EXCH_RATE%TYPE;
    TD_XRATE         ACTBS_HANDOFF.EXCH_RATE%TYPE;
    TDEXCEPTION EXCEPTION;

    TB_ACCHANDOFF    ACPKSS.TBL_ACHOFF;
    L_TB_LOOKUP      ACPKSS.TBL_LOOKUP;
    L_TXN_CODE       VARCHAR2(16);
    L_COUNT          NUMBER := 1;
    RELATED_CUSTOMER STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_ACC_BAL        STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_TOPUPPAYIN_REC ICTM_TDTOPUP_PAYIN%ROWTYPE;
    L_TDPAYIN_REC    ICTM_TDPAYIN_DETAILS%ROWTYPE;

    L_TOPUP_AMT        ICTB_TDTOPUP_DETAIL.TOPUP_AMOUNT%TYPE;
    L_CASH_GL          DETMS_TIL_VLT_CCY_PARAMS.CASH_GL%TYPE;
    L_TOPUP_VALUE_DATE DATE;
    L_ERR_TYPE         ERTBS_MSGS.TYPE%TYPE;
    CURSOR CUR_TDPAYIN IS
      SELECT *
        FROM ICTM_TDTOPUP_PAYIN
       WHERE TOPUP_REF_NO = P_TOPUP_REF
         AND BRN = P_TD_BRN
         AND ACC = P_TD_ACC;
    L_MAKER_ID      ICTB_TDTOPUP_DETAIL.MAKER_ID%TYPE;
    L_ACC_REC       STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_FINAL_AMT     NUMBER;

    L_ICTM_ACC     ICTM_ACC%ROWTYPE;
    L_PAYOUT_COUNT NUMBER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    PROCEDURE POPULATE_ACCHANDOFF(ACCOUNT      VARCHAR2,
                                  BRANCH       VARCHAR2,
                                  CURRENCY     VARCHAR2,
                                  P_TRN_CODE   VARCHAR2,
                                  P_TXN_REF_NO VARCHAR2,
                                  P_AMT_LCY    NUMBER,
                                  P_AMT_FCY    NUMBER,
                                  P_XRATE      NUMBER,
                                  LOOKUP_CNT   NUMBER) IS
      L_TOPUP_VALUE_DATE DATE;
    BEGIN
      DBG('INSIDE populate acchandoff starts >-->');
      BEGIN
        SELECT MAKER_ID, TOPUP_VALUE_DATE
          INTO L_MAKER_ID, L_TOPUP_VALUE_DATE
          FROM ICTB_TDTOPUP_DETAIL
         WHERE BRN = P_TD_BRN
           AND ACC = P_TD_ACC
           AND TOPUP_REF_NO = P_TOPUP_REF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('Inside no data');
          L_MAKER_ID := NULL;
      END;
      DBG('l_maker_id~l_topup_value_date--->' || L_MAKER_ID || '~' ||
          L_TOPUP_VALUE_DATE);

      DBG('Count at first is :' || L_COUNT);
      TB_ACCHANDOFF(L_COUNT) := NULL;
      TB_ACCHANDOFF(L_COUNT).USER_ID := NVL(L_MAKER_ID, G_USER_ID);
      TB_ACCHANDOFF(L_COUNT).MODULE := 'IC';
      TB_ACCHANDOFF(L_COUNT).AMOUNT_TAG := L_TB_LOOKUP(LOOKUP_CNT).AMTTAG;
      TB_ACCHANDOFF(L_COUNT).EVENT := 'DTOP';
      TB_ACCHANDOFF(L_COUNT).EVENT_SR_NO := L_COUNT;
      TB_ACCHANDOFF(L_COUNT).TRN_CODE := L_TB_LOOKUP(LOOKUP_CNT).TRNCODE;

      IF GWPKS_UTIL.G_FROM_BEAN THEN
        TB_ACCHANDOFF(L_COUNT).TRN_DT := NVL(GWPKS_UTIL.G_BRANCH_DATE,
                                             G_APPLICATION_DATE);
      ELSE
        TB_ACCHANDOFF(L_COUNT).TRN_DT := G_APPLICATION_DATE;
      END IF;
      TB_ACCHANDOFF(L_COUNT).TRN_REF_NO := P_TXN_REF_NO;
      TB_ACCHANDOFF(L_COUNT).INSTRUMENT_CODE := '';
      TB_ACCHANDOFF(L_COUNT).VALUE_DT := L_TOPUP_VALUE_DATE;
      TB_ACCHANDOFF(L_COUNT).TXN_INIT_DATE := G_APPLICATION_DATE;
      TB_ACCHANDOFF(L_COUNT).RELATED_ACCOUNT := P_TD_ACC;
      TB_ACCHANDOFF(L_COUNT).RELATED_CUSTOMER := RELATED_CUSTOMER;

      DBG('gwpks_util.g_xref-->' || GWPKS_UTIL.G_XREF);
      DBG('p_txn_ref_no-->' || P_TXN_REF_NO);
      IF GWPKS_UTIL.G_FROM_BEAN THEN
        DBG('TD topup from TDTP');
        TB_ACCHANDOFF(L_COUNT).EXTERNAL_REF_NO := GWPKS_UTIL.G_XREF;
      ELSE
        DBG('TD topup from STDTDTOP');

        TB_ACCHANDOFF(L_COUNT).EXTERNAL_REF_NO := P_TXN_REF_NO;
      END IF;
      TB_ACCHANDOFF(L_COUNT).NETTING_IND := L_TB_LOOKUP(LOOKUP_CNT).NETIND;
      TB_ACCHANDOFF(L_COUNT).DRCR_IND := L_TB_LOOKUP(LOOKUP_CNT).DRCRIND;
      TB_ACCHANDOFF(L_COUNT).AC_BRANCH := BRANCH;
      TB_ACCHANDOFF(L_COUNT).AC_NO := ACCOUNT;
      TB_ACCHANDOFF(L_COUNT).AC_CCY := CURRENCY;
      TB_ACCHANDOFF(L_COUNT).FCY_AMOUNT := P_AMT_FCY;
      TB_ACCHANDOFF(L_COUNT).LCY_AMOUNT := P_AMT_LCY;
      TB_ACCHANDOFF(L_COUNT).EXCH_RATE := P_XRATE;

      DBG(' user_id       ---->  ' || TB_ACCHANDOFF(L_COUNT).USER_ID);
      DBG(' module        ---->  ' || TB_ACCHANDOFF(L_COUNT).MODULE);
      DBG(' amount_tag        ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .AMOUNT_TAG);
      DBG(' event         ---->  ' || TB_ACCHANDOFF(L_COUNT).EVENT);
      DBG(' event_sr_no       ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .EVENT_SR_NO);
      DBG(' trn_code      ---->  ' || TB_ACCHANDOFF(L_COUNT).TRN_CODE);
      DBG(' trn_dt        ---->  ' || TB_ACCHANDOFF(L_COUNT).TRN_DT);
      DBG(' trn_ref_no        ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .TRN_REF_NO);
      DBG(' instrument_code   ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .INSTRUMENT_CODE);
      DBG(' value_dt      ---->  ' || TB_ACCHANDOFF(L_COUNT).VALUE_DT);
      DBG(' txn_init_date     ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .TXN_INIT_DATE);
      DBG(' related_account   ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .RELATED_ACCOUNT);
      DBG(' related_customer  ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .RELATED_CUSTOMER);
      DBG(' external_ref_no   ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .EXTERNAL_REF_NO);
      DBG(' netting_ind       ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .NETTING_IND);
      DBG(' drcr_ind      ---->  ' || TB_ACCHANDOFF(L_COUNT).DRCR_IND);
      DBG(' ac_branch     ---->  ' || TB_ACCHANDOFF(L_COUNT).AC_BRANCH);
      DBG(' ac_no         ---->  ' || TB_ACCHANDOFF(L_COUNT).AC_NO);
      DBG(' ac_ccy        ---->  ' || TB_ACCHANDOFF(L_COUNT).AC_CCY);
      DBG(' fcy_amount        ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .FCY_AMOUNT);
      DBG(' lcy_amount        ---->  ' || TB_ACCHANDOFF(L_COUNT)
          .LCY_AMOUNT);
      DBG(' exch_rate     ---->  ' || TB_ACCHANDOFF(L_COUNT).EXCH_RATE);
      DBG(' Finished credit leg');

      L_COUNT := L_COUNT + 1;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('populate acchandoff failed-->' || SQLERRM);
        RAISE TDEXCEPTION;
    END POPULATE_ACCHANDOFF;

  BEGIN
    DBG('Inside call to fn_topup_td');

    GLOBAL.PR_RESET_SKIP_KERNEL;
    DBG('cspks_req_global.g_release_type: ' ||
        CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      IF NOT STPKS_STDTDTOP_UTILS_CLUSTER.FN_PRE_TOPUP_TD(P_TOPUP_REF,
                                                          P_TD_ACC,
                                                          P_TD_BRN,
                                                          P_TD_CCY,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAM) THEN

        DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.FN_PRE_TOPUP_TD package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      DBG('paremeters values acc-brn-ccy:' || P_TD_ACC || '~' || P_TD_BRN);
      DBG('Before pr set globals');
      PR_SET_GLOBALS;
      DBG('After call to pr_set_globals');

      BEGIN

        SELECT PROD
          INTO L_PROD
          FROM ICTMS_ACC_PR A, ICTMS_PRODUCT_DEFINITION B
         WHERE A.ACC = P_TD_ACC
           AND A.BRN = P_TD_BRN
           AND A.RECORD_STAT = 'O'
           AND A.WAIVE = 'N'
           AND A.PROD = B.PRODUCT_CODE
           AND B.PRODUCT_TYPE IN ('I', 'P')
           AND NVL(B.TAX, 'N') = 'N';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('inside no data found in ictm_acc_pr for ac:' || P_TD_ACC);
          P_ERR_CODE  := 'ST-CUS97';
          P_ERR_PARAM := 'Special Conditions not Maintained for A/C :' ||
                         P_TD_ACC;
          RETURN FALSE;
        WHEN OTHERS THEN
          DBG('When others in select prod from ictm_acc_pr :' || P_TD_ACC || '~' ||
              SQLERRM);
          P_ERR_CODE  := 'ST-CUS96';
          P_ERR_PARAM := 'Product not maintained properly for A/C :' ||
                         P_TD_ACC;
          RETURN FALSE;
      END;
      IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_TD_BRN, P_TD_ACC, L_ACC_REC) THEN
        DBG('Could not get account');
      END IF;
      CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACC_REC.ACCOUNT_CLASS,
                                    L_ACC_CLASS_REC,
                                    P_ERR_CODE);

      IF L_ACC_CLASS_REC.INT_RATE_OPTION_TOPUP <> 'C' THEN

        BEGIN
          SELECT TOPUP_VALUE_DATE
            INTO L_TOPUP_VALUE_DATE
            FROM ICTB_TDTOPUP_DETAIL
           WHERE BRN = P_TD_BRN
             AND ACC = P_TD_ACC
             AND TOPUP_REF_NO = P_TOPUP_REF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Inside no data' || SQLERRM);
            L_TOPUP_VALUE_DATE := GLOBAL.APPLICATION_DATE;
        END;

        BEGIN
          SELECT NVL(TD_AMOUNT, 0) + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
            INTO L_FINAL_AMT
            FROM ICTMS_TD_DETAILS
           WHERE BRN = P_TD_BRN
             AND ACC = P_TD_ACC;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('error while calculating total td amount');
        END;

        IF NOT STPKS_STDTDTOP_UTILS.FN_APPLY_RATES(P_TD_ACC,
                                                   P_TD_BRN,
                                                   L_FINAL_AMT,
                                                   L_TOPUP_VALUE_DATE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAM) THEN
          DBG('Failed in   stpks_stdtdtop_utils.fn_apply_rates' || SQLERRM);
          RETURN FALSE;
        END IF;

      END IF;

      DBG('Before call trpks to get l_serial_no');

      L_TXN_REF_NO := P_TOPUP_REF;

      OPEN CUR_TDPAYIN;
      LOOP
        FETCH CUR_TDPAYIN
          INTO L_TOPUPPAYIN_REC;
        EXIT WHEN CUR_TDPAYIN%NOTFOUND;

        PR_CONV_TDPAYINDET(L_TOPUPPAYIN_REC, L_TDPAYIN_REC);

        DBG('l_tdpayin_rec.multimode_payopt is  :' ||
            L_TDPAYIN_REC.MULTIMODE_PAYOPT);

        IF L_TDPAYIN_REC.MULTIMODE_PAYOPT = 'S' THEN
          BEGIN
            SELECT CCY
              INTO OFFSETCCY
              FROM STTM_CUST_ACCOUNT
             WHERE CUST_AC_NO = L_TDPAYIN_REC.MULTIMODE_TDOFFSET_ACC
               AND BRANCH_CODE = L_TDPAYIN_REC.MULTIMODE_OFFSET_BRN;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Error select ccy for offset acc :' || SQLERRM);
              RETURN FALSE;
          END;
        ELSE
          OFFSETCCY := P_TD_CCY;
        END IF;

        TDAMOUNT  := L_TDPAYIN_REC.MULTIMODE_TDAMOUNT;
        OFFSETACC := L_TDPAYIN_REC.MULTIMODE_TDOFFSET_ACC;
        OFFSETBRN := L_TDPAYIN_REC.MULTIMODE_OFFSET_BRN;

        IF L_TDPAYIN_REC.MULTIMODE_PAYOPT = 'C' THEN
          SELECT CASH_GL
            INTO L_CASH_GL
            FROM DETMS_TIL_VLT_CCY_PARAMS A, DETM_TIL_VLT_MASTER B
           WHERE A.BRANCH_CODE = B.BRANCH_CODE
             AND A.TILL_ID = B.TILL_ID

             AND A.BRANCH_CODE = GWPKS_TDTOPUPCREATE.G_BRNCODE

             AND A.TILL_ID = CSPKSS_ARC.G_TILL_ID
             AND A.CCY_CD = OFFSETCCY
             AND B.AUTH_STAT = 'A'
             AND B.RECORD_STAT = 'O';
          DBG('Selecting GL code from the till is ' || L_CASH_GL);
          OFFSETACC := L_CASH_GL;
        END IF;
        DBG('offsetacc >' || OFFSETACC);

        DBG('l serial no :' || L_SERIAL_NO);
        DBG('l txn ref no :' || L_TXN_REF_NO);
        DBG('Offset Acc is :' || OFFSETACC);
        DBG('offsetccy is :' || OFFSETCCY);
        DBG('tdamount is :' || TDAMOUNT);
        DBG('Rt td~off~global ccy :' || P_TD_CCY || '~' || OFFSETCCY || '~' ||
            G_LCY);

        IF P_TD_CCY = G_LCY THEN
          TDLCY_AMOUNT := TDAMOUNT;
          TD_XRATE     := 1;
          TDFCY_AMOUNT := NULL;

          IF OFFSETCCY = P_TD_CCY THEN
            OFFSETLCY_AMOUNT := TDAMOUNT;
            OFFSET_XRATE     := 1;
            OFFSETFCY_AMOUNT := NULL;
          ELSIF OFFSETCCY != P_TD_CCY THEN
            DBG('offsetccy != p_td_ccy');

            GLOBAL.PR_RESET_SKIP_KERNEL;
            DBG('cspks_req_global.g_release_type: ' ||
                CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 1;

              L_TB_CLUSTER_DATA('seqno') := L_TOPUPPAYIN_REC.SEQNO;
              L_TB_CLUSTER_DATA('tdamount') := L_TOPUPPAYIN_REC.MULTIMODE_TDAMOUNT;
              L_TB_CLUSTER_DATA('offset_ccy') := OFFSETCCY;
              DBG('check check');
              DBG('jpcheck' || L_TB_CLUSTER_DATA('offset_ccy'));
              IF NOT
                  STPKS_STDTDTOP_UTILS_CLUSTER.FN_TOPUP_TD(P_TOPUP_REF,
                                                           P_TD_ACC,
                                                           P_TD_BRN,
                                                           P_TD_CCY,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN

                DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.FN_TOPUP_TD package' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;

              IF L_TB_CLUSTER_DATA.EXISTS('l_exchrate') THEN
                OFFSET_XRATE := L_TB_CLUSTER_DATA('l_exchrate');
                DBG('returned with' || L_TB_CLUSTER_DATA('l_exchrate') || '#');
              END IF;
              IF L_TB_CLUSTER_DATA.EXISTS('l_offsetfcyamt') THEN
                OFFSETFCY_AMOUNT := L_TB_CLUSTER_DATA('l_offsetfcyamt');
                DBG('ofsetamt' || L_TB_CLUSTER_DATA('l_offsetfcyamt'));
              END IF;

              IF L_TB_CLUSTER_DATA.EXISTS('l_offsetlcyamt') THEN
                OFFSETLCY_AMOUNT := L_TB_CLUSTER_DATA('l_offsetlcyamt');
              END IF;

            END IF;

            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              OFFSETFCY_AMOUNT := NULL;
              OFFSET_XRATE     := NULL;
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TD_BRN,
                                                 P_TD_CCY,
                                                 OFFSETCCY,
                                                 TDAMOUNT,
                                                 'Y',
                                                 OFFSETFCY_AMOUNT,
                                                 OFFSET_XRATE,
                                                 P_ERR_CODE) THEN
                DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
                RETURN FALSE;
              END IF;
              OFFSETLCY_AMOUNT := TDAMOUNT;

            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;

            DBG('amount:' || TDAMOUNT || OFFSETFCY_AMOUNT || '~' ||
                OFFSET_XRATE);

          END IF;
        ELSIF P_TD_CCY != G_LCY THEN
          DBG('p_td_ccy != g_lcy');
          TDLCY_AMOUNT := NULL;
          TD_XRATE     := NULL;
          IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TD_BRN,
                                             P_TD_CCY,
                                             G_LCY,
                                             TDAMOUNT,
                                             'Y',
                                             TDLCY_AMOUNT,
                                             TD_XRATE,
                                             P_ERR_CODE) THEN
            DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');
            RETURN FALSE;
          END IF;
          TDFCY_AMOUNT := TDAMOUNT;
          DBG('TD amount converted to lcy:' || TDAMOUNT || '~' ||
              TDLCY_AMOUNT || '~' || TD_XRATE);

          IF OFFSETCCY = P_TD_CCY THEN
            OFFSETLCY_AMOUNT := TDLCY_AMOUNT;
            OFFSET_XRATE     := TD_XRATE;
            OFFSETFCY_AMOUNT := TDAMOUNT;
          ELSIF OFFSETCCY != G_LCY THEN

            DBG('offsetccy != g_lcy ');
            OFFSETFCY_AMOUNT := NULL;
            OFFSET_XRATE     := NULL;
            OFFSETLCY_AMOUNT := TDLCY_AMOUNT;
            IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(P_TD_BRN,
                                               G_LCY,
                                               OFFSETCCY,
                                               OFFSETLCY_AMOUNT,
                                               'Y',
                                               OFFSETFCY_AMOUNT,
                                               OFFSET_XRATE,
                                               P_ERR_CODE) THEN
              DBG('ICDEPOSIT Failed in ICPKSS_UTIL.fn_amt1_to_amt2 in fn_book_td');

            END IF;
            DBG('offset conversion amount to lcy:' || TDAMOUNT || '~' ||
                OFFSETLCY_AMOUNT || '~' || OFFSETFCY_AMOUNT || '~' ||
                OFFSET_XRATE);

          ELSE
            OFFSETLCY_AMOUNT := TDLCY_AMOUNT;
            OFFSET_XRATE     := 1;
            OFFSETFCY_AMOUNT := NULL;
          END IF;
        END IF;

        IF L_TDPAYIN_REC.MULTIMODE_PAYOPT = 'S' THEN
          DBG('This is for TD Booked from branch...');
          IF NOT
              ACPKS_MISC.FN_GETAVLBAL(OFFSETBRN, OFFSETACC, L_ACC_BAL, 'Y') THEN
            DBG('Failed in call to fn_getavlbal for the TD Offset Account.');
            RETURN FALSE;
          END IF;
          DBG('Got avl bal as --->' || L_ACC_BAL);
          DBG('p_td_ccy ---->' || P_TD_CCY);
          DBG('offsetccy ----->' || OFFSETCCY);
          DBG('g_lcy---->' || G_LCY);
          DBG('Offset lcy amount --->' || OFFSETLCY_AMOUNT);
          IF ((OFFSETCCY = G_LCY) AND (P_TD_CCY = G_LCY)) THEN
            DBG('In the case where td , offset ccy r same as local ccy....');
            DBG('hv to compare acc avl bal with offset lcy amt.....');
            IF (L_ACC_BAL < OFFSETLCY_AMOUNT) THEN
              DBG('Balance will go into -ve...So hv to throw back for this case...');
              P_ERR_CODE  := 'ST-CUS101';
              P_ERR_PARAM := '';
              RETURN FALSE;
            END IF;
          ELSE
            DBG('this is the case where td, offset and local ccy of the branch might not be same...');
            DBG('so comparing acc avl bal with offset fcy amt...as this will hv the td offset amt in ac ccy...');
            IF (L_ACC_BAL < OFFSETFCY_AMOUNT) THEN
              DBG('Balance will go into -ve...So hv to throw back for this case...');
              P_ERR_CODE  := 'ST-CUS101';
              P_ERR_PARAM := '';
              RETURN FALSE;
            END IF;
          END IF;
        END IF;

        DBG('At the end tds:' || TDLCY_AMOUNT || '~' || TDFCY_AMOUNT || '~' ||
            TD_XRATE);
        DBG('At the end off:' || OFFSETLCY_AMOUNT || '~' ||
            OFFSETFCY_AMOUNT || '~' || OFFSET_XRATE);

        L_TB_LOOKUP.DELETE;
        BEGIN
          SELECT CUST_NO
            INTO RELATED_CUSTOMER
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_TD_ACC
             AND BRANCH_CODE = P_TD_BRN;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error while selecting related customer :' || SQLERRM);
            RETURN FALSE;
        END;

        BEGIN
          IF NOT ACPKSS.ACFN_LOOKUP(L_PROD, 'DEBK', L_TB_LOOKUP, P_ERR_CODE) THEN
            DBG('Error in fn lookup :' || P_ERR_CODE || '~' || SQLERRM);
            RETURN FALSE;
          END IF;
        END;

        IF L_TB_LOOKUP.COUNT <> 0 THEN
          FOR LOOKUP_CNT IN L_TB_LOOKUP.FIRST .. L_TB_LOOKUP.LAST LOOP
            IF L_TB_LOOKUP(LOOKUP_CNT).DRCRIND = 'C' THEN
              BEGIN
                POPULATE_ACCHANDOFF(P_TD_ACC,
                                    P_TD_BRN,
                                    P_TD_CCY,
                                    L_TXN_CODE,
                                    L_TXN_REF_NO,
                                    TDLCY_AMOUNT,
                                    TDFCY_AMOUNT,
                                    TD_XRATE,
                                    LOOKUP_CNT);
              EXCEPTION
                WHEN TDEXCEPTION THEN
                  DBG('Exception in forming acchandoff');
                  RETURN FALSE;
              END;
            END IF;
            IF L_TB_LOOKUP(LOOKUP_CNT).DRCRIND = 'D' THEN

              BEGIN
                POPULATE_ACCHANDOFF(OFFSETACC,
                                    OFFSETBRN,
                                    OFFSETCCY,
                                    L_TXN_CODE,
                                    L_TXN_REF_NO,
                                    OFFSETLCY_AMOUNT,
                                    OFFSETFCY_AMOUNT,
                                    OFFSET_XRATE,
                                    LOOKUP_CNT);
              EXCEPTION
                WHEN TDEXCEPTION THEN
                  DBG('Exception in forming acchandoff');
                  RETURN FALSE;
              END;

            END IF;

          END LOOP;
        END IF;
        L_TB_LOOKUP.DELETE;
        FOR I IN TB_ACCHANDOFF.FIRST .. TB_ACCHANDOFF.LAST LOOP
          DBG('ac no :' || TB_ACCHANDOFF(I).AC_NO);
        END LOOP;

        IF TB_ACCHANDOFF.COUNT > 0 THEN

          DBG('total table row count ' || TB_ACCHANDOFF.COUNT);
          DBG('p_td_acc..' || P_TD_ACC);
          DBG('p_td_brn..' || P_TD_BRN);
          IF NOT ICPKSS_BOD.FN_CUSTLIM_TDLIQ('FLEXCUBE',
                                             'TDTOP',
                                             P_TD_ACC,
                                             P_TD_BRN,
                                             P_ERR_CODE,
                                             P_ERR_PARAM,
                                             TB_ACCHANDOFF,
                                             NULL) THEN
            DBG('Failed in fn_Custlim_tdliq-->' || SQLERRM);
            L_ERR_TYPE := OVPKSS.FN_GETTYPE(P_ERR_CODE);
            DBG('err_code--' || P_ERR_CODE);
            DBG('l_err_type--' || L_ERR_TYPE);
            DBG('p_err_param--' || P_ERR_PARAM);
            IF L_ERR_TYPE = 'E' THEN
              RETURN FALSE;
            ELSE
              DBG('Going to proceed as the error type is override');
              ICPKSS_BOD.PR_DELCUSTLIM_OVD(P_ERR_CODE, P_ERR_PARAM);
            END IF;
          END IF;

          GLOBAL.PR_RESET_SKIP_KERNEL;
          DBG('cspks_req_global.g_release_type: ' ||
              CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_FN_CALL_ID      := 2;
            IF NOT STPKS_STDTDTOP_UTILS_CLUSTER.FN_TOPUP_TD(P_TOPUP_REF,
                                                            P_TD_ACC,
                                                            P_TD_BRN,
                                                            P_TD_CCY,
                                                            TB_ACCHANDOFF,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAM) THEN

              DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.FN_TOPUP_TD package' ||
                  SQLERRM);
              RETURN FALSE;
            END IF;
          END IF;

          IF NOT ACPKSS.FN_ACHANDOFF(L_TXN_REF_NO,
                                     1,
                                     G_APPLICATION_DATE,
                                     TB_ACCHANDOFF,
                                     'B',
                                     'Y',
                                     'Y',
                                     G_USER_ID,
                                     P_ERR_CODE,
                                     P_ERR_PARAM) THEN
            DBG('Acc Handoff Failed with ' || P_ERR_CODE);
            RETURN FALSE;
          END IF;
        END IF;

        TB_ACCHANDOFF.DELETE;
      END LOOP;

      UPDATE ICTMS_TDTOPUP_PAYIN
         SET REFERENCE_NO = L_TXN_REF_NO
       WHERE BRN = P_TD_BRN
         AND ACC = P_TD_ACC
         AND TOPUP_REF_NO = P_TOPUP_REF;

      DBG('exiting the multimode loop as well as pay_mthd:' || PAY_MTHD);

      DBG(' p_td_brn ::' || P_TD_BRN);
      DBG(' p_td_acc ::' || P_TD_ACC);
      DBG(' global.application_date ::' || GLOBAL.APPLICATION_DATE);
      ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_TD_BRN, P_TD_ACC);
      DBG(' after :: icpks_ude.pr_make_ude_row');

      BEGIN
        SELECT *
          INTO L_ICTM_ACC
          FROM ICTM_ACC
         WHERE BRN = P_TD_BRN
           AND ACC = P_TD_ACC;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC', 'Failed in Selecing from ICTM_ACC');
      END;

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_TD_BRN
           AND ACC = P_TD_ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC',
                         'Failed in Selecing from ictm_tdpayout_details');
      END;

      BEGIN
        UPDATE ICTM_TD_DETAILS
           SET PROJECTED_INT_TILL_MAT = G_TOTAL_INTEREST
         WHERE BRN = P_TD_BRN
           AND ACC = P_TD_ACC;
      END;

      IF NOT FN_INSUPD_INT_LIQ_DET(P_TD_ACC, P_TD_BRN) THEN
        DBG('Failed in insert/update in ICTBS_INT_LIQ_DETAILS');
        RETURN FALSE;
      END IF;
      STPKS_STDTDTOP_UTILS.G_RATE_BASIS_AMOUNT := L_FINAL_AMT;

    END IF;

    DBG('cspks_req_global.g_release_type: ' ||
        CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      IF NOT STPKS_STDTDTOP_UTILS_CLUSTER.FN_POST_TOPUP_TD(P_TOPUP_REF,
                                                           P_TD_ACC,
                                                           P_TD_BRN,
                                                           P_TD_CCY,
                                                           L_FN_CALL_ID,
                                                           L_TB_CLUSTER_DATA,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAM) THEN

        DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.FN_POST_TOPUP_TD package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning true from  fn_topup_td');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_topup_td' || SQLERRM);
      RETURN FALSE;
  END FN_TOPUP_TD;

  FUNCTION FN_BUILD_DEPAMT_SDE(P_BRN             ICTBS_CALC_QUEUE.BRN%TYPE,
                               P_ACC             ICTBS_CALC_QUEUE.ACC%TYPE,
                               P_SDE_ID          VARCHAR2,
                               P_FROM_DT         DATE,
                               P_END_DT          DATE,
                               P_TB_ACC_SDE_VALS OUT ICPKSS_MAINT.TB_ACC_SDE_VALS)

   RETURN BOOLEAN IS
    L_INDEX           INTEGER;
    L_HASH_DT         PLS_INTEGER;
    L_TB_ACC_SDE_VALS ICPKSS_MAINT.TB_ACC_SDE_VALS;
    L_REC_ICTM_ACC    ICTM_ACC%ROWTYPE;
    L_LIQ_INT         NUMBER := 0;
    L_BROKEN_INT      NUMBER := 0;
    CURSOR CUR_TXN IS
      SELECT A.*

        FROM TDTB_EVENT_DETAILS A

       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND EVENT_DATE >= P_FROM_DT
         AND EVENT_DATE <= P_END_DT

       ORDER BY EVENT_DATE;

    TYPE TY_TB_TXN_DET IS TABLE OF CUR_TXN%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_TXN_DET   TY_TB_TXN_DET;
    L_PAYOUT_COUNT INTEGER := 0;

    CURSOR CUR_TXN_HIS IS
      SELECT A.*
        FROM TDTB_EVENT_DET_HISTORY A
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND EVENT_DATE >= P_FROM_DT
         AND EVENT_DATE <= P_END_DT
       ORDER BY EVENT_DATE;

    TYPE TY_TB_TXN_DET_HIS IS TABLE OF CUR_TXN_HIS%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_TXN_DET_HIS TY_TB_TXN_DET_HIS;
    L_INDEX1         INTEGER;

    L_FROM_DT DATE;
    L_TO_DT   DATE;

  BEGIN
    DBG('Start of fn_build_depamt_sde  to apportion for acc~p_brn~p_sde_id ' ||
        P_ACC || '~' || P_BRN || '~' || P_SDE_ID);
    DBG('p_from_dt=' || P_FROM_DT || 'p_end_dt=' || P_END_DT);

    IF CUR_TXN%ISOPEN THEN
      CLOSE CUR_TXN;
    END IF;

    OPEN CUR_TXN;
    FETCH CUR_TXN BULK COLLECT
      INTO L_TB_TXN_DET;
    CLOSE CUR_TXN;

    DBG('l_tb_txn_detc.count =' || L_TB_TXN_DET.COUNT);

    IF L_TB_TXN_DET.COUNT = 0 THEN
      IF CUR_TXN_HIS%ISOPEN THEN
        CLOSE CUR_TXN_HIS;
      END IF;

      OPEN CUR_TXN_HIS;
      FETCH CUR_TXN_HIS BULK COLLECT
        INTO L_TB_TXN_DET_HIS;
      CLOSE CUR_TXN_HIS;
      DBG('l_tb_txn_det_his.count--->' || L_TB_TXN_DET_HIS.COUNT);
    END IF;

    IF (L_TB_TXN_DET.COUNT > 0) OR (L_TB_TXN_DET_HIS.COUNT > 0) THEN

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Payout For Interest');
          L_PAYOUT_COUNT := 0;
      END;

      BEGIN
        SELECT *
          INTO L_REC_ICTM_ACC
          FROM ICTM_ACC A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in select from ictm_Acc' || SQLERRM);
          L_REC_ICTM_ACC := NULL;
      END;

      IF L_REC_ICTM_ACC.INTEREST_RATE < 0 AND L_PAYOUT_COUNT > 0 THEN
        L_PAYOUT_COUNT := 0;
      END IF;

      IF NOT G_IS_DEP_INIT_AMT THEN
        IF (L_REC_ICTM_ACC.BOOK_ACC = P_ACC AND L_PAYOUT_COUNT = 0) THEN

          DBG('l_rec_ictm_Acc.Int_Start_Date-->' ||
              L_REC_ICTM_ACC.INT_START_DATE);
          IF L_REC_ICTM_ACC.INT_START_DATE > P_FROM_DT THEN
            L_FROM_DT := P_FROM_DT;
            L_TO_DT   := P_END_DT - 1;
          ELSE
            L_FROM_DT := L_REC_ICTM_ACC.INT_START_DATE;
            L_TO_DT   := P_FROM_DT;
          END IF;

          IF NOT FN_GET_LIQD_INT(P_ACC,
                                 P_BRN,

                                 L_FROM_DT,

                                 L_TO_DT,
                                 NULL,
                                 L_LIQ_INT) THEN
            DBG('Failed in getting the liq interest so far from entries history' ||
                SQLERRM);
          END IF;
          DBG('l_liq_int initally =' || L_LIQ_INT);

        END IF;
        IF L_REC_ICTM_ACC.BOOK_ACC = P_ACC THEN

          L_FROM_DT := NULL;
          L_TO_DT   := NULL;
          IF L_REC_ICTM_ACC.INT_START_DATE > P_FROM_DT THEN
            L_FROM_DT := P_FROM_DT;
            L_TO_DT   := P_END_DT - 1;
          ELSE
            L_FROM_DT := L_REC_ICTM_ACC.INT_START_DATE;
            L_TO_DT   := GLOBAL.APPLICATION_DATE;
          END IF;

          IF NOT FN_GET_BROKEN_INT(P_ACC,
                                   P_BRN,

                                   L_FROM_DT,
                                   L_TO_DT,

                                   L_BROKEN_INT) THEN
            DBG('Failed in getting the fn_get_broken_int' || SQLERRM);
          END IF;
          DBG('Got the l_broken_int=' || L_BROKEN_INT);
        END IF;
        L_LIQ_INT := NVL(L_LIQ_INT, 0) + NVL(L_BROKEN_INT, 0);
        DBG(' After adjusting broken interest l_liq_int=' || L_LIQ_INT);

      END IF;

      IF L_TB_TXN_DET.COUNT > 0 THEN

        L_INDEX := L_TB_TXN_DET.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP

          IF L_INDEX = L_TB_TXN_DET.LAST THEN
            L_TB_ACC_SDE_VALS(L_INDEX).TO_DT := P_END_DT;
          ELSE
            L_TB_ACC_SDE_VALS(L_INDEX).TO_DT := L_TB_TXN_DET(L_TB_TXN_DET.NEXT(L_INDEX))
                                                .EVENT_DATE - 1;
          END IF;

          L_TB_ACC_SDE_VALS(L_INDEX).SDE_ID := P_SDE_ID;
          L_TB_ACC_SDE_VALS(L_INDEX).FROM_DT := L_TB_TXN_DET(L_INDEX)
                                                .EVENT_DATE;
          L_TB_ACC_SDE_VALS(L_INDEX).SDE_VAL := L_TB_TXN_DET(L_INDEX)
                                                .BALANCE + L_LIQ_INT;

          L_INDEX := L_TB_TXN_DET.NEXT(L_INDEX);
        END LOOP;

      ELSIF L_TB_TXN_DET_HIS.COUNT > 0 THEN
        L_INDEX1 := L_TB_TXN_DET_HIS.FIRST;
        WHILE L_INDEX1 IS NOT NULL LOOP

          IF L_INDEX1 = L_TB_TXN_DET_HIS.LAST THEN
            L_TB_ACC_SDE_VALS(L_INDEX1).TO_DT := P_END_DT;
          ELSE
            L_TB_ACC_SDE_VALS(L_INDEX1).TO_DT := L_TB_TXN_DET_HIS(L_TB_TXN_DET_HIS.NEXT(L_INDEX1))
                                                 .EVENT_DATE - 1;
          END IF;

          L_TB_ACC_SDE_VALS(L_INDEX1).SDE_ID := P_SDE_ID;
          L_TB_ACC_SDE_VALS(L_INDEX1).FROM_DT := L_TB_TXN_DET_HIS(L_INDEX1)
                                                 .EVENT_DATE;
          L_TB_ACC_SDE_VALS(L_INDEX1).SDE_VAL := L_TB_TXN_DET_HIS(L_INDEX1)
                                                 .BALANCE + L_LIQ_INT;

          L_INDEX1 := L_TB_TXN_DET_HIS.NEXT(L_INDEX1);
        END LOOP;
      END IF;

    ELSE
      BEGIN
        SELECT LIQ_AMT
          INTO L_TB_ACC_SDE_VALS(1).SDE_VAL
          FROM ICTBS_INT_LIQ_DETAILS I
         WHERE I.BRANCH_CODE = P_BRN
           AND I.ACCOUNT_NUMBER = P_ACC
           AND TO_DATE = (SELECT MAX(TO_DATE)
                            FROM ICTBS_INT_LIQ_DETAILS J

                           WHERE J.BRANCH_CODE = P_BRN
                             AND J.ACCOUNT_NUMBER = P_ACC

                          );

      EXCEPTION
        WHEN OTHERS THEN
          DBG('WO Exception in select from  ICTBS_INT_LIQ_DETAILS nw will get from ictm_td_Details');
          SELECT (NVL(TD_AMOUNT, 0) + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0))
            INTO L_TB_ACC_SDE_VALS(1).SDE_VAL
            FROM ICTMS_TD_DETAILS J
           WHERE J.BRN = P_BRN
             AND J.ACC = P_ACC;
      END;

      L_TB_ACC_SDE_VALS(1).SDE_ID := P_SDE_ID;
      L_TB_ACC_SDE_VALS(1).FROM_DT := P_FROM_DT;
      L_TB_ACC_SDE_VALS(1).TO_DT := P_END_DT;

    END IF;

    IF L_TB_ACC_SDE_VALS.COUNT > 0 THEN
      L_INDEX := L_TB_ACC_SDE_VALS.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        DBG(L_INDEX || '~' || L_TB_ACC_SDE_VALS(L_INDEX).SDE_ID || '~' || L_TB_ACC_SDE_VALS(L_INDEX)
            .FROM_DT || '~' || L_TB_ACC_SDE_VALS(L_INDEX).TO_DT || '~' || L_TB_ACC_SDE_VALS(L_INDEX)
            .SDE_VAL);
        L_INDEX := L_TB_ACC_SDE_VALS.NEXT(L_INDEX);
      END LOOP;
    END IF;
    P_TB_ACC_SDE_VALS := L_TB_ACC_SDE_VALS;
    DBG('End of fn_build_depamt_sde');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_build_depamt_sde' || SQLERRM);
      RETURN FALSE;
  END FN_BUILD_DEPAMT_SDE;

  PROCEDURE PR_CONSOL_CALC_DATES(P_TB_CALC_OUT IN OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC) IS
    L_INDEX       PLS_INTEGER;
    L_TB_CALC_OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_NEW_INDEX   PLS_INTEGER;
  BEGIN
    IF P_TB_CALC_OUT.COUNT > 0 THEN
      L_INDEX := P_TB_CALC_OUT.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        IF P_TB_CALC_OUT(L_INDEX).J IN (1, 3) THEN
          IF P_TB_CALC_OUT(L_INDEX)
           .FROM_DATE <= P_TB_CALC_OUT(L_INDEX).TO_DATE THEN
            L_NEW_INDEX := P_TB_CALC_OUT(L_INDEX)
                           .J ||
                            FN_HASH_DATE(P_TB_CALC_OUT(L_INDEX).TO_DATE);
            IF L_TB_CALC_OUT.EXISTS(L_NEW_INDEX) THEN
              IF L_TB_CALC_OUT(L_NEW_INDEX).CAPITAL_INDEX IS NOT NULL THEN
                L_TB_CALC_OUT(L_NEW_INDEX).TENOR := P_TB_CALC_OUT(L_INDEX)
                                                    .TENOR;
              END IF;
              L_TB_CALC_OUT(L_NEW_INDEX).AMOUNT := L_TB_CALC_OUT(L_NEW_INDEX)
                                                   .AMOUNT + P_TB_CALC_OUT(L_INDEX)
                                                   .AMOUNT;
            ELSE
              L_TB_CALC_OUT(L_NEW_INDEX) := P_TB_CALC_OUT(L_INDEX);
            END IF;
          END IF;

        ELSE
          L_NEW_INDEX := P_TB_CALC_OUT(L_INDEX)
                         .J || FN_HASH_DATE(P_TB_CALC_OUT(L_INDEX).TO_DATE);
          L_TB_CALC_OUT(L_NEW_INDEX) := P_TB_CALC_OUT(L_INDEX);
        END IF;

        P_TB_CALC_OUT(L_INDEX).CAPITAL_INDEX := NULL;
        L_INDEX := P_TB_CALC_OUT.NEXT(L_INDEX);
      END LOOP;
      P_TB_CALC_OUT := L_TB_CALC_OUT;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exceptino in   pr_consol_calc_dates' || SQLERRM);
  END PR_CONSOL_CALC_DATES;

  PROCEDURE PR_BUILD_CONSOL_TBL(P_TB_CALC_IN    IN STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,
                                P_TB_CALC_ADJ   IN STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,
                                P_TB_TXN_DET    IN TY_TB_TXN_DET,
                                P_CALC_IDX      IN INTEGER,
                                P_TB_CALC_OUT   IN OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,
                                P_LAST_LIQ_DATE IN DATE) IS

    L_COUNT         INTEGER := 0;
    L_INDEX         PLS_INTEGER;
    L_TMP_IDX       PLS_INTEGER;
    L_FROM_DATE     DATE;
    L_TO_DATE       DATE;
    L_TMP_FIRST_REC INTEGER := 0;
    L_TODAY         DATE := GLOBAL.APPLICATION_DATE;
    L_TMP_CALC_OUT  STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_TMP_CALC_REC  STPKS_STDTDTOP_UTILS.TY_REC_CALC;
  BEGIN

    DBG('p_tb_calc_in' || P_TB_CALC_IN.COUNT);
    IF P_TB_CALC_IN.COUNT > 0 THEN
      L_INDEX := P_TB_CALC_IN.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP

        DBG('Value for j' || P_CALC_IDX || 'p_tb_txn_det.count' ||
            P_TB_TXN_DET.COUNT);
        IF P_CALC_IDX = 1 THEN
          IF P_TB_TXN_DET.COUNT > 0 THEN
            L_TMP_FIRST_REC := 0;
            L_TMP_IDX       := P_TB_TXN_DET.FIRST;
            WHILE L_TMP_IDX IS NOT NULL LOOP
              DBG('event_date : ' || P_TB_TXN_DET(L_TMP_IDX)
                  .G_EVENT_DETAIL_REC.EVENT_DATE);
              DBG('to_date : ' || P_TB_CALC_IN(P_TB_CALC_IN.LAST).TO_DATE);

              IF P_TB_TXN_DET(L_TMP_IDX)
               .G_EVENT_DETAIL_REC.EVENT_DATE > P_LAST_LIQ_DATE THEN
                EXIT;
              END IF;
              DBG('from_date : ' || P_TB_CALC_IN(L_INDEX).FROM_DATE);

              IF P_TB_TXN_DET(L_TMP_IDX).G_EVENT_DETAIL_REC.EVENT_DATE >= P_TB_CALC_IN(L_INDEX)
                 .FROM_DATE THEN

                L_TMP_FIRST_REC := L_TMP_FIRST_REC + 1;
                IF L_TMP_FIRST_REC = 1 THEN

                  L_FROM_DATE := P_TB_TXN_DET(L_TMP_IDX)
                                 .G_EVENT_DETAIL_REC.EVENT_DATE;

                ELSE

                  L_TO_DATE := P_TB_TXN_DET(L_TMP_IDX)
                               .G_EVENT_DETAIL_REC.EVENT_DATE - 1;

                  L_COUNT := P_TB_CALC_OUT.COUNT + 1;
                  P_TB_CALC_OUT(L_COUNT) := P_TB_CALC_IN(L_INDEX);
                  P_TB_CALC_OUT(L_COUNT).FROM_DATE := NVL(L_FROM_DATE,
                                                          P_TB_CALC_IN(L_INDEX)
                                                          .FROM_DATE);
                  P_TB_CALC_OUT(L_COUNT).TO_DATE := NVL(L_TO_DATE,
                                                        P_TB_CALC_IN(L_INDEX)
                                                        .TO_DATE);

                  L_FROM_DATE := L_TO_DATE + 1;

                END IF;
              END IF;
              L_TMP_IDX := P_TB_TXN_DET.NEXT(L_TMP_IDX);
            END LOOP;
          END IF;
        ELSIF P_CALC_IDX > 1 THEN

          L_COUNT := P_TB_CALC_OUT.COUNT + 1;
          P_TB_CALC_OUT(L_COUNT) := P_TB_CALC_IN(L_INDEX);
          IF P_CALC_IDX = 3 THEN
            DBG('Every record being build here must be recalculated till the application date');
            L_TMP_CALC_REC           := P_TB_CALC_IN(L_INDEX);
            L_TMP_CALC_REC.FROM_DATE := P_TB_CALC_IN(L_INDEX).TO_DATE + 1;
            L_TMP_CALC_REC.TO_DATE   := L_TODAY;
            PR_POP_ALL_ROWS(L_TMP_CALC_REC, P_TB_CALC_OUT);
          END IF;
        END IF;
        L_INDEX := P_TB_CALC_IN.NEXT(L_INDEX);
      END LOOP;
    END IF;

    IF P_CALC_IDX = 3 THEN
      IF P_TB_CALC_ADJ.COUNT > 0 THEN
        L_INDEX := P_TB_CALC_ADJ.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP

          L_TMP_CALC_REC   := P_TB_CALC_ADJ(L_INDEX);
          L_TMP_CALC_REC.J := 3;

          L_TMP_CALC_REC.FROM_DATE := P_LAST_LIQ_DATE;
          L_TMP_CALC_REC.TO_DATE   := L_TODAY;
          PR_POP_ALL_ROWS(L_TMP_CALC_REC, P_TB_CALC_OUT);
          L_INDEX := P_TB_CALC_ADJ.NEXT(L_INDEX);
        END LOOP;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exceptino in   pr_build_consol_tbl' || SQLERRM);
  END PR_BUILD_CONSOL_TBL;

  PROCEDURE PR_BUILD_TBL(P_ACC       VARCHAR2,
                         P_BRN       VARCHAR2,
                         P_FROM_DATE DATE,
                         P_TO_DATE   DATE,
                         P_AMOUNT    NUMBER,
                         P_TENOR     NUMBER,
                         P_J         INTEGER,
                         P_TB_CALC   IN OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC) IS
    L_COUNT INTEGER := 0;

  BEGIN
    L_COUNT := P_TB_CALC.COUNT + 1;
    P_TB_CALC(L_COUNT).ACC := P_ACC;
    P_TB_CALC(L_COUNT).BRN := P_BRN;
    P_TB_CALC(L_COUNT).FROM_DATE := P_FROM_DATE;
    P_TB_CALC(L_COUNT).TO_DATE := P_TO_DATE;
    P_TB_CALC(L_COUNT).AMOUNT := P_AMOUNT;
    P_TB_CALC(L_COUNT).TENOR := P_TENOR;
    P_TB_CALC(L_COUNT).J := P_J;

    IF P_J = 1 THEN
      P_TB_CALC(L_COUNT).CAPITAL_INDEX := L_COUNT;
    END IF;

  END PR_BUILD_TBL;

  FUNCTION FN_UPD_TOPUP_SETTLED(P_ACC              IN VARCHAR2,
                                P_BRN              IN VARCHAR2,
                                P_AMOUNT           IN NUMBER,
                                P_TB_MODIFIED_RECS OUT TY_TB_TXN_DET,
                                P_TB_TOPUP_SETTLED OUT TY_TB_TXN_DET,
                                P_ERR_CODE         OUT VARCHAR2,
                                P_ERR_PARAM        OUT VARCHAR2)

   RETURN BOOLEAN IS
    L_COUNT        INTEGER;
    L_INDEX        INTEGER;
    L_TOTAL_AMOUNT NUMBER;
    L_CURR_AMT     NUMBER := 0;
    L_HASH_DT      PLS_INTEGER;

    CURSOR CUR_TXN IS
      SELECT A.*
        FROM TDTB_EVENT_DETAILS A
       WHERE BRN = P_BRN
         AND ACC = P_ACC
       ORDER BY EVENT_DATE DESC;

    TYPE TY_TB_EVENT_DETAILS IS TABLE OF CUR_TXN%ROWTYPE INDEX BY PLS_INTEGER;

    L_TB_TXN_DET    TY_TB_EVENT_DETAILS;
    L_UPD_TXN_DET   TY_TB_TXN_DET;
    L_UPD_TXN_DET_1 TY_TB_EVENT_DETAILS;

    L_CUM_ADJ_AMT    NUMBER := 0;
    L_REDEM_FLAG     VARCHAR2(1);
    L_TOPUP_VALUE_DT BOOLEAN := FALSE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Start of fn_upd_topup_settled to apportion for acc~p_brn ' ||
        P_ACC || '~' || P_BRN || '~' || P_AMOUNT);

    IF CUR_TXN%ISOPEN THEN
      CLOSE CUR_TXN;
    END IF;

    OPEN CUR_TXN;
    FETCH CUR_TXN BULK COLLECT
      INTO L_TB_TXN_DET;
    CLOSE CUR_TXN;
    ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FLAG);

    IF L_TB_TXN_DET.COUNT > 0 THEN
      IF NVL(L_REDEM_FLAG, '*') = 'Y' THEN

        DBG('Full Redemption .... Redemption amount will not be entered');
        L_INDEX := L_TB_TXN_DET.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP

          IF L_INDEX = L_TB_TXN_DET.LAST THEN

            L_TB_TXN_DET(L_INDEX).TOPUP_AMT := L_TB_TXN_DET(L_INDEX).BALANCE;

          END IF;
          L_HASH_DT := FN_HASH_DATE(L_TB_TXN_DET(L_INDEX).EVENT_DATE);

          L_CURR_AMT := L_TB_TXN_DET(L_INDEX)
                        .TOPUP_AMT - L_TB_TXN_DET(L_INDEX).TOPUP_AMT_SETTLED;
          L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC := L_TB_TXN_DET(L_INDEX);
          L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED := L_UPD_TXN_DET(L_HASH_DT)
                                                                           .G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED +
                                                                            L_CURR_AMT;

          L_UPD_TXN_DET(L_HASH_DT).CUR_ADJ_AMT := L_CURR_AMT;

          L_INDEX := L_TB_TXN_DET.NEXT(L_INDEX);
        END LOOP;

      ELSE
        DBG('Partial  Redemption .for ' || P_AMOUNT || 'count is' ||
            L_TB_TXN_DET.COUNT);
        L_TOTAL_AMOUNT := P_AMOUNT;

        L_INDEX := L_TB_TXN_DET.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP
          IF L_TOTAL_AMOUNT = 0 THEN
            EXIT;
          END IF;
          L_TOPUP_VALUE_DT := FALSE;
          IF L_INDEX = L_TB_TXN_DET.LAST THEN
            L_TOPUP_VALUE_DT := TRUE;

            DBG('l_tb_txn_det(l_index).topup_amt~l_tb_txn_det(l_index).amt_settled' || L_TB_TXN_DET(L_INDEX)
                .TOPUP_AMT || '~' || L_TB_TXN_DET(L_INDEX)
                .TOPUP_AMT_SETTLED);
            DBG('getting avail bal now..');

            DBG('l_tb_txn_det(l_index).balance' || L_TB_TXN_DET(L_INDEX)
                .BALANCE);
            L_TB_TXN_DET(L_INDEX).TOPUP_AMT := L_TB_TXN_DET(L_INDEX).BALANCE;
            DBG('Amount available for first record will be: ' || L_TB_TXN_DET(L_INDEX)
                .TOPUP_AMT);

            L_CURR_AMT := L_TB_TXN_DET(L_INDEX).TOPUP_AMT - L_TB_TXN_DET(L_INDEX)
                          .TOPUP_AMT_SETTLED;

            DBG('2....l_curr_amt~l_total_amount~topup_amt_settled' ||
                L_CURR_AMT || '~' || L_TOTAL_AMOUNT || '~' || L_TB_TXN_DET(L_INDEX)
                .TOPUP_AMT_SETTLED);

            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID      := 1;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              DBG('calling stpks_stdtdtop_utils_cluster.fn_upd_topup_settled');
              IF NOT
                  STPKS_STDTDTOP_UTILS_CLUSTER.FN_UPD_TOPUP_SETTLED(P_ACC,
                                                                    P_BRN,
                                                                    P_AMOUNT,
                                                                    P_TB_MODIFIED_RECS,
                                                                    P_TB_TOPUP_SETTLED,
                                                                    P_ERR_CODE,
                                                                    P_ERR_PARAM,
                                                                    L_FN_CALL_ID,
                                                                    L_TB_CLUSTER_DATA) THEN
                DBG('stpks_stdtdtop_utils_cluster.fn_upd_topup_settled failed with :-');
                RETURN FALSE;
              END IF;
            END IF;
            IF NOT GLOBAL.G_SKIP_KERNEL THEN

              IF L_TOTAL_AMOUNT > L_CURR_AMT THEN

                DBG('Redemption amount is greater than TD amount');
                P_ERR_CODE  := 'IC-REDMN-13';
                P_ERR_PARAM := NULL;
                RETURN FALSE;
              END IF;

            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;

          END IF;
          L_HASH_DT  := FN_HASH_DATE(L_TB_TXN_DET(L_INDEX).EVENT_DATE);
          L_CURR_AMT := L_TB_TXN_DET(L_INDEX)
                        .TOPUP_AMT - L_TB_TXN_DET(L_INDEX).TOPUP_AMT_SETTLED;

          DBG('3....l_curr_amt~l_total_amount~topup_amt_settled~TOPUPAMT' ||
              L_CURR_AMT || '~' || L_TOTAL_AMOUNT || '~' || L_TB_TXN_DET(L_INDEX)
              .TOPUP_AMT_SETTLED || '~' || L_TB_TXN_DET(L_INDEX).TOPUP_AMT);
          IF (L_CURR_AMT < L_TOTAL_AMOUNT) THEN
            DBG('Current amount is less than total amount');
            L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC := L_TB_TXN_DET(L_INDEX);
            IF NOT L_TOPUP_VALUE_DT THEN

              L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED := L_UPD_TXN_DET(L_HASH_DT)
                                                                               .G_EVENT_DETAIL_REC
                                                                               .TOPUP_AMT_SETTLED +

                                                                                L_CURR_AMT;
            END IF;
            L_UPD_TXN_DET(L_HASH_DT).CUR_ADJ_AMT := L_CURR_AMT;
            L_TOTAL_AMOUNT := L_TOTAL_AMOUNT - L_CURR_AMT;
            DBG('l_total_amount ~l_curr_amt' || L_TOTAL_AMOUNT || '~' ||
                L_CURR_AMT);
          ELSE
            DBG('Current amount is greater than total amount');
            L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC := L_TB_TXN_DET(L_INDEX);
            IF NOT L_TOPUP_VALUE_DT THEN

              L_UPD_TXN_DET(L_HASH_DT).G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED := L_UPD_TXN_DET(L_HASH_DT)
                                                                               .G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED +

                                                                                L_TOTAL_AMOUNT;
            ELSE
              DBG('Amount adjusted from td amount and not topup amount ..settled will not be updated');
            END IF;
            L_UPD_TXN_DET(L_HASH_DT).CUR_ADJ_AMT := L_TOTAL_AMOUNT;

            DBG('l_total_amount ~l_curr_amt' || L_TOTAL_AMOUNT || '~' ||
                L_CURR_AMT);
            L_TOTAL_AMOUNT := 0;
          END IF;

          L_INDEX := L_TB_TXN_DET.NEXT(L_INDEX);
        END LOOP;
      END IF;
    END IF;

    L_CUM_ADJ_AMT := 0;
    L_COUNT       := 0;
    IF L_UPD_TXN_DET.COUNT > 0 THEN
      L_INDEX := L_UPD_TXN_DET.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_CUM_ADJ_AMT := L_CUM_ADJ_AMT + L_UPD_TXN_DET(L_INDEX).CUR_ADJ_AMT;
        L_UPD_TXN_DET(L_INDEX).CUR_CUM_ADJ := L_CUM_ADJ_AMT;

        L_UPD_TXN_DET(L_INDEX).G_EVENT_DETAIL_REC.BALANCE := L_UPD_TXN_DET(L_INDEX)
                                                             .G_EVENT_DETAIL_REC.BALANCE -
                                                              NVL(L_UPD_TXN_DET(L_INDEX)
                                                                  .CUR_CUM_ADJ,
                                                                  0);
        L_COUNT := L_COUNT + 1;
        L_UPD_TXN_DET_1(L_COUNT) := L_UPD_TXN_DET(L_INDEX)
                                    .G_EVENT_DETAIL_REC;

        P_TB_MODIFIED_RECS(L_INDEX) := L_UPD_TXN_DET(L_INDEX);
        P_TB_TOPUP_SETTLED(L_INDEX) := L_UPD_TXN_DET(L_INDEX);

        L_INDEX := L_UPD_TXN_DET.NEXT(L_INDEX);
      END LOOP;
    END IF;

    IF L_UPD_TXN_DET_1.COUNT > 0 THEN

      FORALL L_IDX IN L_UPD_TXN_DET_1.FIRST .. L_UPD_TXN_DET_1.LAST

        UPDATE TDTB_EVENT_DETAILS
           SET TOPUP_AMT_SETTLED = L_UPD_TXN_DET_1(L_IDX).TOPUP_AMT_SETTLED,
               BALANCE           = L_UPD_TXN_DET_1(L_IDX).BALANCE
         WHERE ACC = L_UPD_TXN_DET_1(L_IDX).ACC
           AND BRN = L_UPD_TXN_DET_1(L_IDX).BRN
           AND EVENT_DATE = L_UPD_TXN_DET_1(L_IDX).EVENT_DATE;

    END IF;
    IF L_TB_TXN_DET.COUNT > 0 THEN
      L_INDEX := L_TB_TXN_DET.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_HASH_DT := FN_HASH_DATE(L_TB_TXN_DET(L_INDEX).EVENT_DATE);
        IF NOT P_TB_TOPUP_SETTLED.EXISTS(L_HASH_DT) THEN
          P_TB_TOPUP_SETTLED(L_HASH_DT).G_EVENT_DETAIL_REC := L_TB_TXN_DET(L_INDEX);
        END IF;
        L_INDEX := L_TB_TXN_DET.NEXT(L_INDEX);
      END LOOP;
    END IF;

    DBG('End of fn_upd_topup_settled');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_upd_topup_settled' || SQLERRM);
      RETURN FALSE;
  END FN_UPD_TOPUP_SETTLED;

  FUNCTION FN_BUILD_REC_CALC(P_ACC              VARCHAR2,
                             P_BRN              VARCHAR2,
                             P_TB_MODIFIED_RECS IN TY_TB_TXN_DET,
                             P_TB_TOPUP_SETTLED IN TY_TB_TXN_DET,
                             P_TB_CALC          OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,
                             P_ADJ_STDATE       OUT DATE,
                             P_ERROR_CODE       OUT VARCHAR2,
                             P_ERROR_PARAM      OUT VARCHAR2) RETURN BOOLEAN IS

    L_HSH_START_INDEX PLS_INTEGER;

    L_TB_TXN_DET     TY_TB_TXN_DET;
    L_LAST_LIQ_DATE  DATE;
    L_INDEX          PLS_INTEGER;
    L_FROM_DATE      DATE;
    L_TO_DATE        DATE;
    L_START_DATE     DATE;
    L_ACT_START_DATE DATE;
    L_TENOR_REDAMT   NUMBER;
    L_TENOR_REMAMT   NUMBER;

    L_TODAY DATE := NVL(ICPKS_FCJ_ICDREDMN.G_REDM_EXEC_DATE,
                        GLOBAL.APPLICATION_DATE);

    L_REC_ICTM_ACC ICTM_ACC%ROWTYPE;
    L_TB_CALC_1    STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_TB_CALC_2    STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_TB_CALC_3    STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_TB_CALC_4    STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_FULL_REDEM   VARCHAR2(1);

    L_ACC_REC       STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;

    L_PREV_RED   BOOLEAN;
    L_LIQ_COUNT  NUMBER := 0;
    L_REC_ACC_PR ICTB_ACC_PR%ROWTYPE;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('Start of fn_build_rec_calc');
    DBG('printing ictb_tdtopup_settled');
    G_ADJ_START_DATE := NULL;
    DBG('***********************************************************************************');

    IF P_TB_TOPUP_SETTLED.COUNT > 0 THEN

      DBG(' event_date~topup_amt~topup_amt_settled ~cur_adj_amt~cur_cum_adj~liqd_amt~balance~redem_amt');

      L_INDEX := P_TB_TOPUP_SETTLED.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        DBG(P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.EVENT_DATE || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.TOPUP_AMT || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.TOPUP_AMT_SETTLED || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .CUR_ADJ_AMT || '~' || P_TB_TOPUP_SETTLED(L_INDEX).CUR_CUM_ADJ || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.LIQD_AMT || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.BALANCE || '~' || P_TB_TOPUP_SETTLED(L_INDEX)
            .G_EVENT_DETAIL_REC.REDEM_AMT);

        L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_INDEX);
      END LOOP;
    END IF;

    DBG('***********************************************************************************');
    L_PREV_RED := STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT;
    ICPKSS_MAINT.PR_GET_FULL_REDEM(L_FULL_REDEM);

    IF NOT FN_GET_LAST_LIQ_DT(P_ACC,
                              P_BRN,
                              NULL,
                              P_TB_TOPUP_SETTLED,
                              L_LAST_LIQ_DATE) THEN

      DBG('Failed in getting fn_get_last_liq_dt ');
    END IF;
    DBG('l_last_liq_date ~l_full_redem=' || L_LAST_LIQ_DATE || '~' ||
        L_FULL_REDEM);

    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, L_ACC_REC) THEN
      DBG('Could not get account');
    END IF;
    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACC_REC.ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  P_ERROR_CODE);

    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);

    BEGIN
      SELECT *
        INTO L_REC_ACC_PR
        FROM ICTBS_ACC_PR A
       WHERE A.ACC = P_ACC
         AND A.BRN = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO exception in select from ictb_acc_pr ');
    END;

    IF P_TB_MODIFIED_RECS.COUNT > 0 THEN
      L_START_DATE := P_TB_MODIFIED_RECS(P_TB_MODIFIED_RECS.FIRST)
                      .G_EVENT_DETAIL_REC.EVENT_DATE;
    END IF;

    DBG('l_start_Date' || L_START_DATE);

    IF L_START_DATE IS NOT NULL THEN

      DBG('l_act_start_Date ' || L_ACT_START_DATE);

      L_HSH_START_INDEX := FN_HASH_DATE(L_START_DATE);
      L_INDEX           := P_TB_TOPUP_SETTLED.PRIOR(L_HSH_START_INDEX);
      WHILE L_INDEX IS NOT NULL LOOP
        IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT > 0 THEN
          L_ACT_START_DATE := P_TB_TOPUP_SETTLED(L_INDEX)
                              .G_EVENT_DETAIL_REC.EVENT_DATE;
          EXIT;
        END IF;
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_INDEX);
      END LOOP;

      IF L_ACT_START_DATE IS NULL THEN

        L_LIQ_COUNT := 0;
        L_INDEX     := P_TB_TOPUP_SETTLED.NEXT(L_HSH_START_INDEX);
        WHILE L_INDEX IS NOT NULL LOOP
          IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT > 0 THEN
            L_LIQ_COUNT := 1;
            EXIT;
          END IF;
          L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_INDEX);
        END LOOP;

        IF L_LIQ_COUNT > 0 THEN
          L_ACT_START_DATE := L_REC_ICTM_ACC.INT_START_DATE;
        END IF;
      END IF;

    ELSE

      IF P_TB_TOPUP_SETTLED.COUNT > 0 THEN
        L_START_DATE := P_TB_TOPUP_SETTLED(P_TB_TOPUP_SETTLED.FIRST)
                        .G_EVENT_DETAIL_REC.EVENT_DATE;
      END IF;

    END IF;

    G_ADJ_START_DATE := L_START_DATE;
    DBG('g_adj_start_date assinged as ' || G_ADJ_START_DATE);

    L_START_DATE := NVL(L_ACT_START_DATE, L_START_DATE);

    P_ADJ_STDATE := L_START_DATE;

    L_HSH_START_INDEX := FN_HASH_DATE(L_START_DATE);
    IF P_TB_TOPUP_SETTLED.EXISTS(L_HSH_START_INDEX) THEN
      L_INDEX := L_HSH_START_INDEX;
    ELSE
      L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_HSH_START_INDEX);
    END IF;
    WHILE L_INDEX IS NOT NULL LOOP
      L_TB_TXN_DET(L_INDEX) := P_TB_TOPUP_SETTLED(L_INDEX);
      L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_INDEX);
    END LOOP;

    DBG('count' || L_TB_TXN_DET.COUNT);
    IF L_TB_TXN_DET.COUNT > 0 THEN
      L_INDEX := L_TB_TXN_DET.FIRST;

      WHILE L_INDEX IS NOT NULL LOOP

        L_FROM_DATE := L_TB_TXN_DET(L_INDEX).G_EVENT_DETAIL_REC.EVENT_DATE;
        DBG('l_from_date=' || L_FROM_DATE);

        IF NVL(ICPKS_FCJ_ICDREDMN.G_TENOR_CHANGE, 'N') = 'N' THEN
          STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;
          IF NOT ICPKS_UTIL.FN_GET_RATECHART_TENOR(L_FULL_REDEM,
                                                   L_ACC_CLASS_REC,
                                                   P_BRN,
                                                   P_ACC,
                                                   L_FROM_DATE,
                                                   L_TODAY,
                                                   L_TENOR_REDAMT) THEN
            DBG('Failed to get the tenor');
          END IF;
        END IF;

        IF NVL(ICPKS_FCJ_ICDREDMN.G_TENOR_CHANGE, 'N') = 'Y' THEN
          L_FULL_REDEM := NULL;
        END IF;

        STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := TRUE;
        IF NOT ICPKS_UTIL.FN_GET_RATECHART_TENOR(L_FULL_REDEM,
                                                 L_ACC_CLASS_REC,
                                                 P_BRN,
                                                 P_ACC,
                                                 L_REC_ICTM_ACC.INT_START_DATE,
                                                 L_REC_ICTM_ACC.MATURITY_DATE,
                                                 L_TENOR_REMAMT) THEN
          DBG('Failed to get the tenor');
        END IF;

        IF NVL(ICPKS_FCJ_ICDREDMN.G_TENOR_CHANGE, 'N') = 'Y' THEN
          L_FULL_REDEM   := 'Y';
          L_TENOR_REDAMT := L_TENOR_REMAMT;
        END IF;

        IF L_FROM_DATE < L_LAST_LIQ_DATE THEN

          IF L_TB_TXN_DET.NEXT(L_INDEX) IS NOT NULL THEN
            L_TO_DATE := L_TB_TXN_DET(L_TB_TXN_DET.NEXT(L_INDEX))
                         .G_EVENT_DETAIL_REC.EVENT_DATE - 1;
            DBG('Next rec is not null l_to_date' || L_TO_DATE);
          ELSE
            L_TO_DATE := L_FROM_DATE;
            DBG('Last record  l_to_date' || L_TO_DATE);
          END IF;

          DBG('Liq Period - l_tb_txn_det(l_index).cur_adj_amt' || L_TB_TXN_DET(L_INDEX)
              .CUR_ADJ_AMT);

          IF L_TB_TXN_DET(L_INDEX).CUR_ADJ_AMT > 0 THEN
            PR_BUILD_TBL(P_ACC,
                         P_BRN,
                         L_FROM_DATE,
                         L_TO_DATE,
                         L_TB_TXN_DET(L_INDEX).CUR_ADJ_AMT,
                         L_TENOR_REDAMT,
                         1,
                         L_TB_CALC_1);
          END IF;
          IF NVL(L_FULL_REDEM, 'N') != 'Y' THEN

            PR_BUILD_TBL(P_ACC,
                         P_BRN,
                         L_FROM_DATE,
                         L_TO_DATE,
                         L_TB_TXN_DET(L_INDEX).G_EVENT_DETAIL_REC.BALANCE,
                         L_TENOR_REMAMT,
                         2,
                         L_TB_CALC_2);

          END IF;
        ELSE
          DBG('Event date > last liqn date');
          DBG('l_tb_txn_det(l_index).cur_adj_amt' || L_TB_TXN_DET(L_INDEX)
              .CUR_ADJ_AMT);

          IF L_TB_TXN_DET.NEXT(L_INDEX) IS NOT NULL THEN
            L_TO_DATE := L_TB_TXN_DET(L_TB_TXN_DET.NEXT(L_INDEX))
                         .G_EVENT_DETAIL_REC.EVENT_DATE - 1;
          ELSE

            DBG('l_rec_acc_pr.next_liq_dt=' || L_REC_ACC_PR.NEXT_LIQ_DT);

            IF L_REC_ACC_PR.NEXT_LIQ_DT IS NULL THEN
              L_TO_DATE := LEAST(L_TODAY - 1,
                                 L_REC_ICTM_ACC.MATURITY_DATE - 1);
            ELSE

              L_TO_DATE := LEAST(L_TODAY - 1,
                                 L_REC_ICTM_ACC.MATURITY_DATE - 1,
                                 L_REC_ACC_PR.NEXT_LIQ_DT);
            END IF;

            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_FN_CALL_ID      := 2;

              L_TB_CLUSTER_DATA('to_date') := L_TO_DATE;
              L_TB_CLUSTER_DATA('today') := L_TODAY;

              IF NOT
                  STPKS_STDTDTOP_UTILS_CLUSTER.FN_BUILD_REC_CALC(P_ACC,
                                                                 P_BRN,
                                                                 P_TB_MODIFIED_RECS,
                                                                 P_TB_TOPUP_SETTLED,
                                                                 P_TB_CALC,
                                                                 P_ADJ_STDATE,
                                                                 P_ERROR_CODE,
                                                                 P_ERROR_PARAM,
                                                                 L_FN_CALL_ID,
                                                                 L_TB_CLUSTER_DATA) THEN
                DBG('Failed while calling stpks_stdtdtop_utils_cluster.fn_build_rec_calc package' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;

              IF L_TB_CLUSTER_DATA.EXISTS('to_date') THEN
                L_TO_DATE := L_TB_CLUSTER_DATA('to_date');
              END IF;

            END IF;

            DBG('Last record' || L_TO_DATE);
          END IF;
          IF L_TB_TXN_DET(L_INDEX).CUR_ADJ_AMT > 0

           THEN
            PR_BUILD_TBL(P_ACC,
                         P_BRN,
                         L_FROM_DATE,
                         L_TO_DATE,
                         L_TB_TXN_DET(L_INDEX).CUR_ADJ_AMT,
                         L_TENOR_REDAMT,
                         3,
                         L_TB_CALC_3);
          END IF;
          IF NVL(L_FULL_REDEM, 'N') != 'Y' THEN
            PR_BUILD_TBL(P_ACC,
                         P_BRN,
                         L_FROM_DATE,
                         L_TO_DATE,
                         L_TB_TXN_DET(L_INDEX).G_EVENT_DETAIL_REC.BALANCE,
                         L_TENOR_REMAMT,
                         4,
                         L_TB_CALC_4);
          END IF;
        END IF;
        L_INDEX := L_TB_TXN_DET.NEXT(L_INDEX);
      END LOOP;

    END IF;

    PR_BUILD_CONSOL_TBL(L_TB_CALC_1,
                        L_TB_CALC_1,
                        L_TB_TXN_DET,
                        1,
                        P_TB_CALC,
                        L_LAST_LIQ_DATE);
    IF NVL(L_FULL_REDEM, 'N') != 'Y' THEN

      PR_BUILD_CONSOL_TBL(L_TB_CALC_2,
                          L_TB_CALC_2,
                          L_TB_TXN_DET,
                          2,
                          P_TB_CALC,
                          L_LAST_LIQ_DATE);
    END IF;

    PR_BUILD_CONSOL_TBL(L_TB_CALC_3,
                        L_TB_CALC_1,
                        L_TB_TXN_DET,
                        3,
                        P_TB_CALC,
                        L_LAST_LIQ_DATE);
    IF NVL(L_FULL_REDEM, 'N') != 'Y' THEN
      PR_BUILD_CONSOL_TBL(L_TB_CALC_4,
                          L_TB_CALC_4,
                          L_TB_TXN_DET,
                          4,
                          P_TB_CALC,
                          L_LAST_LIQ_DATE);
    END IF;

    PR_PRINT_TB_CALC(P_TB_CALC);

    IF L_FULL_REDEM IS NOT NULL THEN
      DBG('Now to consolidate the table across dates (for one date entry for consolidated  amount )');
      PR_CONSOL_CALC_DATES(P_TB_CALC);
      DBG('After consolidating...');
      PR_PRINT_TB_CALC(P_TB_CALC);
    END IF;

    DBG('cspks_req_global.g_release_type: ' ||
        CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_FN_CALL_ID      := 1;
      IF NOT
          STPKS_STDTDTOP_UTILS_CLUSTER.FN_BUILD_REC_CALC(P_ACC,
                                                         P_BRN,
                                                         P_TB_MODIFIED_RECS,
                                                         P_TB_TOPUP_SETTLED,
                                                         P_TB_CALC,
                                                         P_ADJ_STDATE,
                                                         P_ERROR_CODE,
                                                         P_ERROR_PARAM,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DBG('Failed while calling stpks_stdtdtop_utils_cluster.FN_TOPUP_TD package' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      PR_PRINT_TB_CALC(P_TB_CALC);
    END IF;

    STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := L_PREV_RED;
    DBG('End of fn_build_rec_calc');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_build_rec_calc' || SQLERRM);
      RETURN FALSE;
  END FN_BUILD_REC_CALC;

  FUNCTION FN_PROJ_INTRATE(P_FUNCTION_ID      IN VARCHAR2,
                           P_BRN              IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_ACC              IN STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_PRODUCT_CODE     IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                           P_TOPUP_VALUE_DATE IN STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE)

   RETURN NUMBER IS
    L_INT_RATE      ICTB_UDEVALS.RATE%TYPE;
    L_BRNCD         VARCHAR2(25);
    L_CCY           STTM_CUST_ACCOUNT.CCY%TYPE;
    L_ACLASS        STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_ACC_OPEN_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_INT_START_DT  ICTM_ACC.INT_START_DATE%TYPE;

    L_RP_RATE    NUMBER;
    L_ERR_CODE   ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAMS ERTBS_MSGS.MESSAGE%TYPE;
    L_RP_DTLS    COPKS_RP_PROCESSING.TY_REC_RP_DETAILS;

  BEGIN

    SELECT CCY, ACCOUNT_CLASS, AC_OPEN_DATE
      INTO L_CCY, L_ACLASS, L_ACC_OPEN_DATE
      FROM STTM_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ACC
       AND BRANCH_CODE = P_BRN;
    L_BRNCD := ICPKS_UDE.FN_GET_BRANCH(P_BRN,
                                       L_ACLASS,
                                       L_CCY,
                                       P_PRODUCT_CODE);
    DBG('Inside fn_proj_Intrate' || P_BRN || '--' || L_ACLASS || '--' ||
        L_CCY || '--' || P_PRODUCT_CODE || '--' || P_ACC);
    DBG('l_brncd--->' || L_BRNCD);
    DBG('p_topup_value_date--->' || P_TOPUP_VALUE_DATE);

    BEGIN

      SELECT NVL((NVL(A1.AMT, 0) + NVL(A1.RATE, 0) +
                 NVL(A1.UDE_VARIANCE, 0)),
                 0)
        INTO L_INT_RATE
        FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
       WHERE A1.PROD = PR.PRODUCT_CODE
         AND A1.PROD = NVL(P_PRODUCT_CODE, A1.PROD)
         AND A1.COND_KEY = P_BRN || P_ACC
         AND A1.UDE_ID = PR.INT_RATE_UDE
         AND A1.UDE_EFF_DT =
             (SELECT MAX(A2.UDE_EFF_DT)
                FROM ICTB_UDEVALS A2
               WHERE A2.COND_KEY = P_BRN || P_ACC
                 AND A2.UDE_EFF_DT <= P_TOPUP_VALUE_DATE);

      DBG('l_int_rate11-->' || L_INT_RATE);

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('In No Data Found');
        L_INT_RATE := NULL;
    END;
    IF NVL(L_INT_RATE, '0') = '0' THEN
      DBG('Cominh here111-->');

      BEGIN
        SELECT NVL((NVL(A1.AMT, 0) + NVL(A1.RATE, 0) +
                   NVL(A1.UDE_VARIANCE, 0)),
                   0)
          INTO L_INT_RATE
          FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
         WHERE A1.PROD = PR.PRODUCT_CODE
           AND A1.PROD = NVL(P_PRODUCT_CODE, A1.PROD)
           AND A1.COND_KEY = L_BRNCD || L_ACLASS || L_CCY
           AND A1.UDE_ID = PR.INT_RATE_UDE
           AND A1.UDE_EFF_DT >= P_TOPUP_VALUE_DATE
           AND A1.UDE_EFF_DT =
               (SELECT MIN(A2.UDE_EFF_DT)
                  FROM ICTB_UDEVALS A2
                 WHERE A2.COND_KEY = A1.COND_KEY);

        DBG('l_int_rate22-->' || L_INT_RATE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed --->' || SQLERRM);
          L_INT_RATE := NULL;
      END;
    END IF;

    IF L_INT_RATE IS NOT NULL THEN
      IF NOT STPKS_STDCUSAC_UTILS_1.FN_RATEPICK(P_ACC,
                                                P_BRN,
                                                L_INT_RATE,
                                                L_RP_RATE,
                                                L_ERR_CODE,
                                                L_ERR_PARAMS) THEN
        DBG('Failed in FN_RATEPICK function');
      ELSE
        COPKS_RP_PROCESSING.PR_GET_RP_DETAILS(L_RP_DTLS,
                                              L_ERR_CODE,
                                              L_ERR_PARAMS);
        DBG('Rp variance-->' || L_RP_RATE || 'Actual int rate' ||
            L_INT_RATE);

        DBG('VARIANCE TYPE-->' || L_RP_DTLS.P_VAR_TYPE);
        IF L_RP_DTLS.P_VAR_TYPE IS NOT NULL THEN
          IF L_RP_DTLS.P_VAR_TYPE = 'F' THEN
            L_INT_RATE := NVL(L_RP_RATE, 0);
          ELSIF L_RP_DTLS.P_VAR_TYPE = 'P' THEN
            L_INT_RATE := L_INT_RATE +
                          (L_INT_RATE * (NVL(L_RP_RATE, 0) / 100));
          ELSIF L_RP_DTLS.P_VAR_TYPE = 'V' THEN
            L_INT_RATE := L_INT_RATE + NVL(L_RP_RATE, 0);
          END IF;
        ELSE
          L_INT_RATE := L_INT_RATE + NVL(L_RP_RATE, 0);
        END IF;
        DBG('After appying interest rate with RP variance' || L_INT_RATE);
      END IF;
    END IF;

    DBG('Returing from Fn_PROJ_INTRATE');
    RETURN L_INT_RATE;
  END FN_PROJ_INTRATE;

  FUNCTION FN_GET_LIQD_DATES(P_ACC              VARCHAR2,
                             P_BRN              VARCHAR2,
                             P_ADJ_ST_DATE      DATE,
                             P_TB_TOPUP_SETTLED TY_TB_TXN_DET,
                             P_TB_LIQD_DATES    OUT TY_TB_LIQ_DATES,
                             P_ERROR_CODE       OUT VARCHAR2,
                             P_ERROR_PARAM      OUT VARCHAR2) RETURN BOOLEAN IS

    L_TB_ENT_DT TY_TB_DATES;
    L_INDEX     PLS_INTEGER;
    L_HSH_INDEX PLS_INTEGER;

  BEGIN
    DBG('Start of fn_get_liqd_dates');

    L_HSH_INDEX := FN_HASH_DATE(P_ADJ_ST_DATE);
    IF P_TB_TOPUP_SETTLED.COUNT > 0 THEN
      IF P_TB_TOPUP_SETTLED.EXISTS(L_HSH_INDEX) THEN
        L_INDEX := L_HSH_INDEX;
      ELSE
        L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_HSH_INDEX);
      END IF;
      WHILE L_INDEX IS NOT NULL LOOP
        IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT > 0 THEN
          L_TB_ENT_DT(L_INDEX) := P_TB_TOPUP_SETTLED(L_INDEX)
                                  .G_EVENT_DETAIL_REC.EVENT_DATE;
        END IF;
        L_INDEX := P_TB_TOPUP_SETTLED.NEXT(L_INDEX);
      END LOOP;

    END IF;
    IF L_TB_ENT_DT.COUNT > 0 THEN
      L_INDEX := L_TB_ENT_DT.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_HSH_INDEX := FN_HASH_DATE(L_TB_ENT_DT(L_INDEX));

        P_TB_LIQD_DATES(L_HSH_INDEX).START_DATE := L_TB_ENT_DT(L_INDEX);

        IF L_TB_ENT_DT.NEXT(L_INDEX) IS NOT NULL THEN
          P_TB_LIQD_DATES(L_HSH_INDEX).END_DATE := L_TB_ENT_DT(L_TB_ENT_DT.NEXT(L_INDEX));
        ELSE
          P_TB_LIQD_DATES(L_HSH_INDEX).END_DATE := L_TB_ENT_DT(L_INDEX);
        END IF;

        L_INDEX := L_TB_ENT_DT.NEXT(L_INDEX);
      END LOOP;
    END IF;

    DBG('End of fn_get_liqd_dates');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN

      DBG('in exception of fn_get_liqd_dates ' || SQLERRM);
      RETURN FALSE;

  END FN_GET_LIQD_DATES;

  PROCEDURE PR_GRP_FRM(P_IN_TB_MEMO_REC  IN STPKS_TD_REDEMPTION.TY_MEMO_REC,
                       P_OUT_TB_MEMO_REC OUT STPKS_TD_REDEMPTION.TY_MEMO_REC) IS
  BEGIN
    DBG('p_in_tb_memo_rec.count' || P_IN_TB_MEMO_REC.COUNT);
    IF P_IN_TB_MEMO_REC.COUNT > 0 THEN
      FOR REC IN P_IN_TB_MEMO_REC.FIRST .. P_IN_TB_MEMO_REC.LAST LOOP
        IF NOT P_OUT_TB_MEMO_REC.EXISTS(P_IN_TB_MEMO_REC(REC).FRM_NO) THEN
          P_OUT_TB_MEMO_REC(P_IN_TB_MEMO_REC(REC).FRM_NO) := P_IN_TB_MEMO_REC(REC);
        ELSE
          P_OUT_TB_MEMO_REC(P_IN_TB_MEMO_REC(REC).FRM_NO).AMT := NVL(P_OUT_TB_MEMO_REC(P_IN_TB_MEMO_REC(REC).FRM_NO).AMT,
                                                                     0) + P_IN_TB_MEMO_REC(REC).AMT;

        END IF;
      END LOOP;
    END IF;
  END PR_GRP_FRM;

  FUNCTION FN_APPLY_RATES(P_ACC         VARCHAR2,
                          P_BRN         VARCHAR2,
                          P_AMOUNT      NUMBER,
                          P_DATE        DATE,
                          P_ERROR_CODE  OUT VARCHAR2,
                          P_ERROR_PARAM OUT VARCHAR2) RETURN BOOLEAN IS
    L_TOPUP_FLAG VARCHAR2(1);
    L_ACC_REC    STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUM_FLAG   BOOLEAN := FALSE;
    L_AMT        NUMBER := 0;
    L_PROD_REC   ICTMS_ACC_PR%ROWTYPE;
  BEGIN
    DBG('Start of fn_apply_rates' || P_ACC || '~' || P_BRN || '~' ||
        P_AMOUNT);

    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, L_ACC_REC) THEN
      DBG('Could not get account');
    END IF;

    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);

    PR_GET_ISTOPUP(L_TOPUP_FLAG);
    DBG('l_topup_flag' || L_TOPUP_FLAG);
    IF NVL(L_TOPUP_FLAG, 'N') = 'Y' THEN
      STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY := 0;
    END IF;
    G_RATE_BASIS_AMOUNT := P_AMOUNT;
    L_AMT               := 0;

    IF STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT OR
       NVL(L_TOPUP_FLAG, 'N') = 'Y' THEN
      PR_SET_ISCUMAMT('Y');
      L_CUM_FLAG := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_FLAG(P_BRN, P_ACC);
      IF L_CUM_FLAG THEN

        DBG('cumulative flag is set ');
        L_AMT := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(L_ACC_REC, 'Y');
        DBG('fn_get_cum_amt=' || L_AMT);
        G_RATE_BASIS_AMOUNT := L_AMT;
      ELSE
        DBG('cumulative flag is not set ');
        L_AMT := 0;
      END IF;

    END IF;
    IF NOT STPKS_TD_REDEMPTION.FN_APPLY_RATE(P_BRN,
                                             P_ACC,
                                             'Y',
                                             NULL,
                                             L_PROD_REC.PROD,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             P_DATE,
                                             NULL) THEN
      DBG('Failed in fn_apply_rate');
      RETURN FALSE;
    END IF;

    DBG('icpks_partition_info.g_This_Part: ' ||
        ICPKS_PARTITION_INFO.G_THIS_PART);
    BEGIN
      SELECT SEQ_NO
        INTO ICPKS_PARTITION_INFO.G_THIS_PART
        FROM CSTB_CUSTACSEQ
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_ACC;
      DBG('icpks_partition_info.g_This_Part: ' ||
          ICPKS_PARTITION_INFO.G_THIS_PART);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('icpks_partition_info.g_This_Part will not be set.');
    END;

    IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_BRN,
                                               P_ACC,
                                               P_ERROR_CODE,
                                               P_ERROR_PARAM) THEN
      DBG('maint resolution for acc gave error ' || P_ERROR_CODE || '~' ||
          P_ERROR_PARAM);
    END IF;
    ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);
    DBG('Returning true from fn_apply_rates');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_apply_rates' || SQLERRM ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_APPLY_RATES;

  FUNCTION FN_POPULATE_CAP_INT(P_TB_CALC STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,

                               P_CAPITALISED_INT OUT NUMBER) RETURN BOOLEAN IS
    L_INDEX           PLS_INTEGER;
    L_CAPITALISED_INT NUMBER := 0;
  BEGIN
    DBG('Start of fn_populate_cap_int :' || P_TB_CALC.COUNT);

    IF P_TB_CALC.COUNT > 0 THEN
      L_INDEX := P_TB_CALC.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        IF P_TB_CALC(L_INDEX).J = 1 THEN

          L_CAPITALISED_INT := L_CAPITALISED_INT +
                               NVL(P_TB_CALC(L_INDEX).INTEREST, 0) -
                               NVL(P_TB_CALC(L_INDEX).TAX, 0);

        END IF;
        L_INDEX := P_TB_CALC.NEXT(L_INDEX);
      END LOOP;
    END IF;
    P_CAPITALISED_INT := NVL(L_CAPITALISED_INT, 0);

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('sqlerrm' || SQLERRM);
      RETURN FALSE;
  END FN_POPULATE_CAP_INT;

  FUNCTION FN_COMPUTE_INT(P_ACC                    VARCHAR2,
                          P_BRN                    VARCHAR2,
                          P_CCY                    VARCHAR2,
                          P_ADJ_ST_DATE            DATE,
                          P_TB_TOPUP_SETTLED       TY_TB_TXN_DET,
                          P_TB_CALC                IN OUT STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC,
                          P_MEMO_REC1              OUT STPKS_TD_REDEMPTION.TY_MEMO_REC,
                          P_MEMO_REC2              OUT STPKS_TD_REDEMPTION.TY_MEMO_REC,
                          P_MEMO_REC3              OUT STPKS_TD_REDEMPTION.TY_MEMO_REC,
                          P_MEMO_REC4              OUT STPKS_TD_REDEMPTION.TY_MEMO_REC,
                          PKG_REDEM_AMT_ACCR       OUT DBMS_SQL.NUMBER_TABLE,
                          PKG_TAX_ON_REDEM_AMT     OUT DBMS_SQL.NUMBER_TABLE,
                          PKG_PENALTY_ON_REDEM_AMT OUT DBMS_SQL.NUMBER_TABLE,
                          P_ERROR_CODE             OUT VARCHAR2,
                          P_ERROR_PARAMS           OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_INDEX                PLS_INTEGER;
    L_PREV_INDEX           PLS_INTEGER;
    L_APPLY_RATES          BOOLEAN := TRUE;
    L_TOPUP_RATES          BOOLEAN := TRUE;
    L_PROD                 ICTMS_ACC_PR%ROWTYPE;
    L_PROD_REC             ICTM_PR_INT%ROWTYPE;
    L_RULE                 ICTM_PR_INT.RULE%TYPE;
    L_ACT_ADJ_AMOUNT       NUMBER := 0;
    L_CUR_ADJ_AMOUNT       NUMBER := 0;
    L_ADJ_AMOUNT           NUMBER := 0;
    L_REC_ICTM_ACC         ICTM_ACC%ROWTYPE;
    L_TB_LIQN_DATES        TY_TB_LIQ_DATES;
    L_CURR_IDX             PLS_INTEGER;
    TB_G_MEMO_REC          STPKS_TD_REDEMPTION.TY_MEMO_REC;
    PKG_TEMP_MEMO_REC1     STPKS_TD_REDEMPTION.TY_MEMO_REC;
    PKG_TEMP_MEMO_REC2     STPKS_TD_REDEMPTION.TY_MEMO_REC;
    PKG_TEMP_MEMO_REC3     STPKS_TD_REDEMPTION.TY_MEMO_REC;
    PKG_TEMP_MEMO_REC4     STPKS_TD_REDEMPTION.TY_MEMO_REC;
    L_ACC_REC              STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC        STTM_ACCOUNT_CLASS%ROWTYPE;
    L_TOPUP_FLAG           VARCHAR2(1);
    L_BOOK_FLAG            VARCHAR2(1);
    L_CUM_FLAG             BOOLEAN := FALSE;
    L_AMT                  NUMBER(22, 3);
    L_PAYOUT_COUNT         INTEGER := 0;
    L_AMT_RATE_PICKUP      NUMBER := 0;
    L_PREV_AMT_RATE_PICKUP NUMBER := 0;

    L_START_DATE_REMAMT DATE;
    L_REPOP_AT_LIQ      ICTM_PR_INT_ACLASS.REPOP_AT_LIQ%TYPE;
    L_TMP_CNT           INTEGER := 0;
    L_TMP_LIQ_AMT       INTEGER := 0;
    L_TMP_TOPUP_AMT     INTEGER := 0;
    L_RED_ADJ_DATE      DATE;
    L_REM_ADJ_DATE      DATE;
    L_RATE_ST_DATE      DATE;
    L_PREV_RATES        BOOLEAN := FALSE;

    L_FULL_REDMN      VARCHAR2(1);
    L_TB_CAPITAL_INT  DBMS_SQL.NUMBER_TABLE;
    L_CAPITALISED_INT NUMBER;

    L_INT_J_2            NUMBER := 0;
    L_HSH_INDEX          PLS_INTEGER;
    L_ICTM_PR_INT_ACLASS ICTM_PR_INT_ACLASS%ROWTYPE;
    L_DEP_AMT_INIT_SDE   BOOLEAN := FALSE;
  BEGIN

    DBG('Start of fn_compute_int');
    PR_PRINT_TB_CALC(P_TB_CALC);
    L_PROD     := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);
    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(L_PROD.PROD);
    L_RULE     := L_PROD_REC.RULE;

    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, L_ACC_REC) THEN
      DBG('Could not get account');
    END IF;
    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACC_REC.ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  P_ERROR_CODE);

    ICPKSS_MAINT.PR_GET_FULL_REDEM(L_FULL_REDMN);
    L_FULL_REDMN := NVL(L_FULL_REDMN, 'X');
    IF L_FULL_REDMN = 'Y' THEN
      DBG('Full Redemption');
    ELSIF L_FULL_REDMN = 'N' THEN
      DBG('Partial  Redemption');
    ELSE
      DBG('Not  Redemption');
    END IF;

    BEGIN
      SELECT COUNT(*)
        INTO L_PAYOUT_COUNT
        FROM ICTM_TDPAYOUT_DETAILS
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PAYOUT_COMPONENT = 'I';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('No Payout For Interest');
        L_PAYOUT_COUNT := 0;
    END;

    IF NOT FN_IS_DEP_AMT_INT_SDE(L_PROD.PROD, L_DEP_AMT_INIT_SDE) THEN
      DBG('Failed in fn_is_dep_amt_int_sde');
    END IF;

    DBG('l_rec_ictm_Acc.acc' || L_REC_ICTM_ACC.ACC ||
        ' : l_rec_ictm_acc.book_acc :' || L_REC_ICTM_ACC.BOOK_ACC);

    IF ((L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
       L_PAYOUT_COUNT = 0) AND NOT L_DEP_AMT_INIT_SDE)

       OR STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y'

     THEN

      IF NOT FN_GET_LIQD_DATES(P_ACC,
                               P_BRN,
                               P_ADJ_ST_DATE,
                               P_TB_TOPUP_SETTLED,
                               L_TB_LIQN_DATES,
                               P_ERROR_CODE,
                               P_ERROR_PARAMS) THEN
        DBG('Failed in fn_get_liqd_dates ');
      END IF;
    END IF;

    L_ICTM_PR_INT_ACLASS := ICPKS_CACHE.FN_GET_INT_ACLASS_FRC(L_PROD.PROD,
                                                              L_ACC_REC.ACCOUNT_CLASS,
                                                              P_CCY);

    IF P_TB_CALC.COUNT > 0 THEN
      L_INDEX := P_TB_CALC.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP

        L_APPLY_RATES := TRUE;

        DBG('About to call memo accrual  with: fromdate' || P_TB_CALC(L_INDEX)
            .FROM_DATE || 'To Date' || P_TB_CALC(L_INDEX).TO_DATE || 'j = ' || P_TB_CALC(L_INDEX).J ||
            'amount = ' || P_TB_CALC(L_INDEX).AMOUNT);

        G_RATE_TENOR                             := P_TB_CALC(L_INDEX).TENOR;
        G_RATE_CCY                               := P_CCY;
        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT      := P_TB_CALC(L_INDEX)
                                                    .AMOUNT;
        STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := P_TB_CALC(L_INDEX)
                                                    .AMOUNT;

        IF L_INDEX != P_TB_CALC.FIRST THEN

          L_PREV_INDEX := P_TB_CALC.PRIOR(L_INDEX);

          DBG('p_tb_calc(l_index).from_date=' || P_TB_CALC(L_INDEX)
              .FROM_DATE);
          DBG('g_adj_start_date=' || G_ADJ_START_DATE);

          IF P_TB_CALC(L_INDEX).J != P_TB_CALC(L_PREV_INDEX).J THEN
            L_START_DATE_REMAMT := NULL;
          END IF;

          IF P_TB_CALC(L_INDEX)
           .FROM_DATE <
              NVL(G_ADJ_START_DATE, P_TB_CALC(L_INDEX).FROM_DATE - 1) THEN
            DBG('Rate pickup should not happen since p_tb_calc(l_index).from_date < g_adj_start_date');
            L_APPLY_RATES := FALSE;
            L_PREV_RATES  := TRUE;
          ELSIF P_TB_CALC(L_INDEX)
           .J = P_TB_CALC(L_PREV_INDEX).J AND

                 L_PREV_AMT_RATE_PICKUP = L_AMT_RATE_PICKUP AND P_TB_CALC(L_INDEX)
                .TENOR = P_TB_CALC(L_PREV_INDEX).TENOR THEN

            IF L_PREV_RATES THEN
              L_APPLY_RATES := TRUE;
              L_PREV_RATES  := FALSE;
              DBG('rate pickup required');

            ELSE

              DBG('Amount = ' || P_TB_CALC(L_INDEX).AMOUNT || 'Tenor = ' || P_TB_CALC(L_INDEX)
                  .TENOR);
              DBG('Same amount and tenor ..No Ratepickup is required again..');
              L_APPLY_RATES := FALSE;

            END IF;

          ELSIF NOT STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT THEN
            DBG('Adjustments shouldnt happen when the amount/tenor is different');

          END IF;
        END IF;

        DBG('Setting redemption flag ');
        IF P_TB_CALC(L_INDEX).J IN (1, 3) THEN
          DBG('Inside if. Setting redemption flag as TRUE');
          ICPKS_FCJ_ICDREDMN.G_REDM_FLAG := TRUE;
          IF P_TB_CALC(L_INDEX).J = 1 THEN
            ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := TRUE;
            ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
          ELSE
            ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := TRUE;
            ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;
          END IF;
        ELSE
          DBG('Inside else. Setting redemption flag as FALSE');
          ICPKS_FCJ_ICDREDMN.G_REDM_FLAG := FALSE;

          ICPKS_FCJ_ICDREDMN.G_REDEM_ACCR := FALSE;
          ICPKS_FCJ_ICDREDMN.G_REDEM_LIQ  := FALSE;

        END IF;

        IF P_TB_CALC(L_INDEX).J = 3 OR P_TB_CALC(L_INDEX).J = 4 THEN
          L_START_DATE_REMAMT := LEAST(NVL(L_START_DATE_REMAMT,
                                           P_TB_CALC(L_INDEX).FROM_DATE),
                                       P_TB_CALC(L_INDEX).FROM_DATE);

          DBG('l_start_Date_remamt=' || L_START_DATE_REMAMT);

          IF L_ICTM_PR_INT_ACLASS.REPOP_AT_LIQ = 'N' AND
             L_START_DATE_REMAMT = P_TB_CALC(L_INDEX).FROM_DATE THEN

            DBG('Repop at liqn is N and hence ratepickup will not happen here');
            L_TMP_LIQ_AMT   := 0;
            L_TMP_TOPUP_AMT := 0;

            L_HSH_INDEX := FN_HASH_DATE(L_START_DATE_REMAMT);
            IF P_TB_TOPUP_SETTLED.EXISTS(L_HSH_INDEX) THEN
              L_TMP_LIQ_AMT   := NVL(P_TB_TOPUP_SETTLED(L_HSH_INDEX)
                                     .G_EVENT_DETAIL_REC.LIQD_AMT,
                                     0);
              L_TMP_TOPUP_AMT := NVL(P_TB_TOPUP_SETTLED(L_HSH_INDEX)
                                     .G_EVENT_DETAIL_REC.TOPUP_AMT,
                                     0);
            ELSE
              L_TMP_LIQ_AMT   := 0;
              L_TMP_TOPUP_AMT := 0;
            END IF;

            DBG('l_tmp_liq_amt~l_tmp_topup_amt=' || L_TMP_LIQ_AMT || '~' ||
                L_TMP_TOPUP_AMT);
            IF L_TMP_LIQ_AMT > 0 THEN
              L_TMP_CNT := 0;
              BEGIN
                SELECT COUNT(1)
                  INTO L_TMP_CNT
                  FROM ICTM_ACC_EFFDT
                 WHERE BRN = P_BRN
                   AND ACC = P_ACC
                   AND UDE_EFF_DT = L_START_DATE_REMAMT;
              EXCEPTION
                WHEN OTHERS THEN
                  L_TMP_CNT := 0;
                  DBG('ude pickup not done so far for liqn date' ||
                      L_START_DATE_REMAMT);
              END;
              DBG('l_tmp_cnt=' || L_TMP_CNT);

              IF NOT (L_TMP_CNT = 0 AND L_TMP_TOPUP_AMT > 0) THEN
                IF P_TB_CALC(L_INDEX).J = 3 THEN
                  L_RATE_ST_DATE := L_RED_ADJ_DATE;
                ELSE
                  L_RATE_ST_DATE := L_REM_ADJ_DATE;
                END IF;
              END IF;
            END IF;
          END IF;
        END IF;

        IF L_AMT_RATE_PICKUP = 0 THEN
          L_AMT_RATE_PICKUP      := P_TB_CALC(L_INDEX).AMOUNT;
          L_PREV_AMT_RATE_PICKUP := P_TB_CALC(L_INDEX).AMOUNT;
        END IF;

        IF P_TB_CALC(L_INDEX).J IN (2, 4) THEN
          DBG('PROCESSING remaining amount');
          STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := TRUE;
          STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY      := 0;

          IF ((L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
             L_PAYOUT_COUNT = 0) AND NOT L_DEP_AMT_INIT_SDE)

             OR STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y'

           THEN
            DBG(' stpks_td_redemption.g_broken_amount=' ||
                STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
            STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT +
                                                   G_LIQD_INT_TILL_DATE;
            DBG(' stpks_td_redemption.g_broken_amount=' ||
                STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
          END IF;

        ELSE

          IF NOT L_DEP_AMT_INIT_SDE THEN
            IF L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
               L_PAYOUT_COUNT = 0 AND P_TB_CALC(L_INDEX).J = 3 AND
               L_FULL_REDMN = 'Y' THEN

              IF L_CAPITALISED_INT IS NULL THEN
                IF NOT FN_POPULATE_CAP_INT(P_TB_CALC, L_CAPITALISED_INT)

                 THEN
                  DBG('Failed in getting the capital interest');
                END IF;
              END IF;
              P_TB_CALC(L_INDEX).CAPITAL_INDEX := L_CAPITALISED_INT;
              STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT +
                                                     L_CAPITALISED_INT;

              DBG('stpks_td_redemption.g_broken_amount changed as ' ||
                  STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);

            END IF;
          END IF;

          DBG('PROCESSING redemption amount');
          STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;
          IF NVL(ICPKS_FCJ_ICDREDMN.G_TENOR_CHANGE, 'N') = 'N' THEN
            STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY := 1;
          END IF;
        END IF;

        PR_GET_ISTOPUP(L_TOPUP_FLAG);
        DBG('l_topup_flag' || L_TOPUP_FLAG);
        IF NVL(L_TOPUP_FLAG, 'N') = 'Y' THEN

          STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY := 0;
          L_TOPUP_RATES                         := FALSE;

        END IF;

        DBG('p_tb_calc(l_index).amount' || P_TB_CALC(L_INDEX).AMOUNT);
        IF L_APPLY_RATES AND L_TOPUP_RATES THEN
          L_PREV_RATES   := FALSE;
          L_RATE_ST_DATE := NVL(L_RATE_ST_DATE,
                                P_TB_CALC(L_INDEX).FROM_DATE);
          DBG('Ratepcickup will happen from' || L_RATE_ST_DATE);
          IF P_TB_CALC(L_INDEX).J = 1 THEN

            L_RED_ADJ_DATE := P_TB_CALC(L_INDEX).FROM_DATE;
          ELSIF P_TB_CALC(L_INDEX).J = 2 THEN

            L_REM_ADJ_DATE := P_TB_CALC(L_INDEX).FROM_DATE;
          END IF;
          IF NOT FN_APPLY_RATES(P_ACC,
                                P_BRN,
                                L_AMT_RATE_PICKUP,

                                L_RATE_ST_DATE,
                                P_ERROR_CODE,
                                P_ERROR_PARAMS) THEN
            DBG('Failed in   fn_apply_rates' || SQLERRM);
            RETURN FALSE;
          END IF;
          L_RATE_ST_DATE := NULL;
        END IF;
        P_TB_CALC(L_INDEX).AMOUNT := STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT;
        IF P_TB_CALC(L_INDEX).J IN (1, 3) THEN

          ICPKS_BOD.G_PENALTY := L_AMT_RATE_PICKUP;

        ELSE
          ICPKS_BOD.G_PENALTY := 0;
        END IF;

        IF NOT STPKS_TD_REDEMPTION.FN_DO_MEMO_ACCRUAL(P_BRN,
                                                      P_ACC,
                                                      P_TB_CALC     (L_INDEX)
                                                      .FROM_DATE,
                                                      P_TB_CALC     (L_INDEX)
                                                      .TO_DATE,
                                                      L_RULE,
                                                      L_PROD.PROD,
                                                      TB_G_MEMO_REC,
                                                      P_ERROR_CODE,
                                                      P_ERROR_PARAMS) THEN
          DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
          P_ERROR_CODE := 'IC-MU0008';
          DBG('error in stpks_stdtdtop_utils.fn_matamt_comp---> ' ||
              SQLERRM);
          RETURN FALSE;
        END IF;

        SELECT NVL(SUM(DECODE(A.DRCR_IND, 'C', AMT, -AMT)), 0)
          INTO P_TB_CALC(L_INDEX).INTEREST
          FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
         WHERE B.FRM_NO = A.FRM_NO
           AND A.BRN = P_BRN
           AND A.ACC = P_ACC
           AND A.PROD = L_PROD.PROD
           AND B.RULE_ID = L_RULE
           AND B.BOOK_FLAG = 'B';

        DBG('Neg p_tb_calc(l_index) .interest' || P_TB_CALC(L_INDEX)
            .INTEREST);

        SELECT SUM(AMT)
          INTO P_TB_CALC(L_INDEX).PENALTY
          FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
         WHERE B.FRM_NO = A.FRM_NO
           AND A.BRN = P_BRN
           AND A.ACC = P_ACC
           AND A.PROD = L_PROD.PROD
           AND B.RULE_ID = L_RULE
           AND A.DRCR_IND = 'D'
           AND A.IS_TAX = 'N'
           AND B.BOOK_FLAG = 'P';
        DBG('Neg p_tb_calc(l_index) .penalty' || P_TB_CALC(L_INDEX)
            .PENALTY);

        SELECT SUM(AMT)
          INTO P_TB_CALC(L_INDEX).TAX
          FROM ICTW_MEMO_BOOKING
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PROD = L_PROD.PROD
           AND IS_TAX = 'Y';

        L_ADJ_AMOUNT := NVL(P_TB_CALC(L_INDEX).INTEREST, '0') -
                        NVL(P_TB_CALC(L_INDEX).TAX, '0');

        BEGIN
          SELECT 'Rate Date' || UDE_EFF_DT || '~' || UDE_VAL_LIST
            INTO P_TB_CALC(L_INDEX).RATE
            FROM ICTB_UDEVAL_ROW
           WHERE COND_KEY LIKE P_BRN || P_ACC
             AND COND_TYPE = 0
             AND UDE_EFF_DT =
                 (SELECT MAX(UDE_EFF_DT)
                    FROM ICTB_UDEVAL_ROW
                   WHERE COND_KEY LIKE P_BRN || P_ACC
                     AND COND_TYPE = 0
                     AND UDE_EFF_DT <= P_TB_CALC(L_INDEX).FROM_DATE
                     AND PROD = L_PROD.PROD)
             AND PROD = L_PROD.PROD;
        EXCEPTION
          WHEN OTHERS THEN

            DBG('Error in getting the ude_val_list from ictb_udeval_row' ||
                SQLERRM);
        END;

        DBG('l_tb_liqn_dates.count' || L_TB_LIQN_DATES.COUNT);
        IF L_TB_LIQN_DATES.COUNT > 0 THEN

          L_CURR_IDX := FN_HASH_DATE(P_TB_CALC(L_INDEX).TO_DATE + 1);
          IF L_TB_LIQN_DATES.EXISTS(L_CURR_IDX) THEN
            DBG('on a liqn date add the  interest(int - tax-penalty) to the tdamount for calc in next cycle');
            L_ACT_ADJ_AMOUNT    := L_ACT_ADJ_AMOUNT + L_ADJ_AMOUNT +
                                   L_CUR_ADJ_AMOUNT + G_ADJ_INT_TILL_DATE;
            L_CUR_ADJ_AMOUNT    := 0;
            L_ADJ_AMOUNT        := 0;
            G_ADJ_INT_TILL_DATE := 0;
            DBG('l_act_adj_amount=' || L_ACT_ADJ_AMOUNT);

          ELSE
            DBG('On a topup date keep accumulating the interest ...');
            L_CUR_ADJ_AMOUNT := L_CUR_ADJ_AMOUNT + L_ADJ_AMOUNT;
          END IF;
        END IF;
        IF P_TB_CALC.EXISTS(P_TB_CALC.NEXT(L_INDEX)) THEN
          IF (P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
             .FROM_DATE >= P_TB_CALC(L_INDEX).TO_DATE) AND
             ((P_TB_CALC(P_TB_CALC.NEXT(L_INDEX)).J = P_TB_CALC(L_INDEX).J) OR
             NVL(L_TOPUP_FLAG, 'N') = 'Y') THEN

            L_PREV_AMT_RATE_PICKUP := L_AMT_RATE_PICKUP;
            L_AMT_RATE_PICKUP      := P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
                                      .AMOUNT;

            P_TB_CALC(P_TB_CALC.NEXT(L_INDEX)).AMOUNT := P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
                                                         .AMOUNT +
                                                          L_ACT_ADJ_AMOUNT;
          ELSE

            IF P_TB_CALC(L_INDEX).J = 2 THEN
              L_INT_J_2 := L_ACT_ADJ_AMOUNT;
              DBG('l_int_J_2 :' || L_INT_J_2);

            END IF;

            L_ACT_ADJ_AMOUNT       := 0;
            L_CUR_ADJ_AMOUNT       := 0;
            L_ADJ_AMOUNT           := 0;
            L_AMT_RATE_PICKUP      := 0;
            L_PREV_AMT_RATE_PICKUP := 0;

            IF P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
             .J = 4 AND NVL(L_TOPUP_FLAG, 'N') = 'N' THEN
              L_ACT_ADJ_AMOUNT := L_INT_J_2;
              L_INT_J_2        := 0;
              DBG('l_int_J_2 :' || L_INT_J_2);
              L_PREV_AMT_RATE_PICKUP := 0;
              L_AMT_RATE_PICKUP := P_TB_CALC(P_TB_CALC.NEXT(L_INDEX)).AMOUNT;
              P_TB_CALC(P_TB_CALC.NEXT(L_INDEX)).AMOUNT := P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
                                                           .AMOUNT +
                                                            L_ACT_ADJ_AMOUNT;
              DBG('p_tb_calc(p_tb_calc.next(l_index)).amount :' || P_TB_CALC(P_TB_CALC.NEXT(L_INDEX))
                  .AMOUNT);
            END IF;

          END IF;
        END IF;

        IF TB_G_MEMO_REC.COUNT > 0 THEN
          DBG('Moving into Temp');
          FOR REC IN TB_G_MEMO_REC.FIRST .. TB_G_MEMO_REC.LAST LOOP
            DBG('tb_g_memo_rec(rec).amt--->' || TB_G_MEMO_REC(REC).AMT);
            DBG('tb_g_memo_rec(rec).drcr_ind--->' || TB_G_MEMO_REC(REC)
                .DRCR_IND);
            DBG('tb_g_memo_rec(rec).istax--->' || TB_G_MEMO_REC(REC)
                .IS_TAX);
            IF P_TB_CALC(L_INDEX).J = 1 THEN
              PKG_TEMP_MEMO_REC1(PKG_TEMP_MEMO_REC1.COUNT + 1) := TB_G_MEMO_REC(REC);
            ELSIF P_TB_CALC(L_INDEX).J = 2 THEN
              PKG_TEMP_MEMO_REC2(PKG_TEMP_MEMO_REC2.COUNT + 1) := TB_G_MEMO_REC(REC);
            ELSIF P_TB_CALC(L_INDEX).J = 3 THEN
              PKG_TEMP_MEMO_REC3(PKG_TEMP_MEMO_REC3.COUNT + 1) := TB_G_MEMO_REC(REC);
            ELSIF P_TB_CALC(L_INDEX).J = 4 THEN
              PKG_TEMP_MEMO_REC4(PKG_TEMP_MEMO_REC4.COUNT + 1) := TB_G_MEMO_REC(REC);
            END IF;

          END LOOP;
        END IF;
        DBG('Done with processing fromdate' || P_TB_CALC(L_INDEX)
            .FROM_DATE || 'To Date' || P_TB_CALC(L_INDEX).TO_DATE || 'j = ' || P_TB_CALC(L_INDEX).J ||
            'amount = ' || P_TB_CALC(L_INDEX).AMOUNT);
        DBG('Interest' || P_TB_CALC(L_INDEX).INTEREST || 'Penalty :' || P_TB_CALC(L_INDEX)
            .PENALTY || 'Tax : ' || P_TB_CALC(L_INDEX).TAX);
        L_INDEX := P_TB_CALC.NEXT(L_INDEX);

        DELETE FROM ICTW_MEMO_BOOKING A
         WHERE A.BRN = P_BRN
           AND A.ACC = P_ACC
           AND A.PROD = L_PROD.PROD;
        DBG(SQL%ROWCOUNT || 'ROWS deleted from ictw_memo_booking');

      END LOOP;
      DBG('Calling pr_grp_frm');
      PR_GRP_FRM(PKG_TEMP_MEMO_REC1, PKG_TEMP_MEMO_REC1);
      PR_GRP_FRM(PKG_TEMP_MEMO_REC2, PKG_TEMP_MEMO_REC2);
      PR_GRP_FRM(PKG_TEMP_MEMO_REC3, PKG_TEMP_MEMO_REC3);
      PR_GRP_FRM(PKG_TEMP_MEMO_REC4, PKG_TEMP_MEMO_REC4);
      DBG('pkg_temp_memo_rec1.COUNT : ' || PKG_TEMP_MEMO_REC1.COUNT);
      IF PKG_TEMP_MEMO_REC1.COUNT > 0 THEN
        L_INDEX := PKG_TEMP_MEMO_REC1.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP

          SELECT BOOK_FLAG
            INTO L_BOOK_FLAG
            FROM ICTMS_RULE_FRM
           WHERE RULE_ID = L_RULE
             AND FRM_NO = PKG_TEMP_MEMO_REC1(L_INDEX).FRM_NO;
          DBG('l_book_flag : ' || L_BOOK_FLAG);
          IF (PKG_TEMP_MEMO_REC1(L_INDEX)
             .DRCR_IND = 'C' AND
              NVL(PKG_TEMP_MEMO_REC1(L_INDEX).IS_TAX, 'N') = 'N') OR
             (PKG_TEMP_MEMO_REC1(L_INDEX)
             .DRCR_IND = 'D' AND NVL(L_BOOK_FLAG, 'B') != 'P' AND
              NVL(PKG_TEMP_MEMO_REC1(L_INDEX).IS_TAX, 'N') = 'N') THEN
            DBG('Entering Interest');

            IF PKG_REDEM_AMT_ACCR.EXISTS(L_INDEX) THEN
              PKG_REDEM_AMT_ACCR(L_INDEX) := PKG_REDEM_AMT_ACCR(L_INDEX) + PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            ELSE
              PKG_REDEM_AMT_ACCR(L_INDEX) := PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            END IF;
            DBG('Pkg_redem_amt_accr : ' || PKG_REDEM_AMT_ACCR(L_INDEX));

          ELSIF PKG_TEMP_MEMO_REC1(L_INDEX)
           .DRCR_IND = 'D' AND
                 NVL(PKG_TEMP_MEMO_REC1(L_INDEX).IS_TAX, 'N') = 'N' AND
                 L_BOOK_FLAG = 'P' THEN

            DBG('Entering Penalty');
            IF PKG_PENALTY_ON_REDEM_AMT.EXISTS(L_INDEX) THEN
              PKG_PENALTY_ON_REDEM_AMT(L_INDEX) := PKG_PENALTY_ON_REDEM_AMT(L_INDEX) + PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            ELSE
              PKG_PENALTY_ON_REDEM_AMT(L_INDEX) := PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            END IF;
            DBG('pkg_penalty_on_redem_amt : ' ||
                PKG_PENALTY_ON_REDEM_AMT(L_INDEX));

          ELSIF NVL(PKG_TEMP_MEMO_REC1(L_INDEX).IS_TAX, 'N') = 'Y' THEN

            DBG('pkg_tax_on_redem_amt');
            IF PKG_TAX_ON_REDEM_AMT.EXISTS(L_INDEX) THEN
              PKG_TAX_ON_REDEM_AMT(L_INDEX) := PKG_TAX_ON_REDEM_AMT(L_INDEX) + PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            ELSE
              PKG_TAX_ON_REDEM_AMT(L_INDEX) := PKG_TEMP_MEMO_REC1(L_INDEX).AMT;
            END IF;
            DBG('Pkg_tax_on_redem_amt : ' || PKG_TAX_ON_REDEM_AMT(L_INDEX));

          END IF;
          L_INDEX := PKG_TEMP_MEMO_REC1.NEXT(L_INDEX);
        END LOOP;

      END IF;
      DBG('Assigning to p_memo_rec1, 2, 3, 4');
      P_MEMO_REC1 := PKG_TEMP_MEMO_REC1;
      P_MEMO_REC2 := PKG_TEMP_MEMO_REC2;
      P_MEMO_REC3 := PKG_TEMP_MEMO_REC3;
      P_MEMO_REC4 := PKG_TEMP_MEMO_REC4;

    END IF;
    DBG('Returning from fn_compute_int');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in  fn_compute_int...' || SQLERRM);
      RETURN FALSE;
  END FN_COMPUTE_INT;

  FUNCTION FN_COMP_INT_MATDT(P_ACC               VARCHAR2,
                             P_BRN               VARCHAR2,
                             P_REF_NO            VARCHAR2,
                             P_AMOUNT            NUMBER,
                             P_FROM_DATE         DATE,
                             P_TO_DATE           DATE,
                             P_INT_RED_PERIOD    NUMBER,
                             P_INT_REM_PERIOD    NUMBER,
                             P_TB_RED_CALC_BRKUP IN OUT TY_TB_RED_BRKUP,
                             P_MAT_AMOUNT        OUT NUMBER,
                             P_ERROR_CODE        OUT VARCHAR2,
                             P_ERROR_PARAMS      OUT VARCHAR2) RETURN BOOLEAN IS

    L_LIQ_DAYS       ICTM_PR_INT.LIQN_DAYS%TYPE;
    L_LIQ_MONTHS     ICTM_PR_INT.LIQN_MONTHS%TYPE;
    L_LIQ_YEARS      ICTM_PR_INT.LIQN_YEARS%TYPE;
    L_PROD           ICTMS_ACC_PR%ROWTYPE;
    L_PROD_REC       ICTM_PR_INT%ROWTYPE;
    L_RULE           ICTM_PR_INT.RULE%TYPE;
    G_CALC_FROM      DATE;
    G_CALC_TO        DATE;
    L_LAST_DT        DATE;
    L_REC_ICTM_ACC   ICTM_ACC%ROWTYPE;
    L_INT_REM_PERIOD NUMBER := P_INT_REM_PERIOD;
    L_ADJ_AMOUNT     NUMBER;
    L_MAT_AMOUNT     NUMBER := 0;
    L_ACC_PR         ICTB_ACC_PR%ROWTYPE;
    L_MEMO_REC       STPKS_TD_REDEMPTION.TY_MEMO_REC;
    L_TOPUP_FLAG     VARCHAR2(1) := 'N';
    L_CUM_FLAG       BOOLEAN := FALSE;
    L_LOOP_CNT       INTEGER := 0;
    L_COUNT          NUMBER := 1;

    L_TB_MAT_CALC   TY_TB_REC_CALC;
    L_TMPCNT        INTEGER := 0;
    L_INT_PAY_COUNT NUMBER := 0;

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

  BEGIN
    DBG('start  fn_comp_int_matdt' || P_MAT_AMOUNT || '~' || P_AMOUNT || '~' ||
        P_INT_RED_PERIOD || '~' || P_INT_REM_PERIOD);
    DBG('p_from_date=' || P_FROM_DATE || '~' || 'p_to_Date=' || P_TO_DATE);

    L_PROD           := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);
    L_PROD_REC       := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(L_PROD.PROD);
    L_RULE           := L_PROD_REC.RULE;
    L_LIQ_DAYS       := L_PROD_REC.LIQN_DAYS;
    L_LIQ_MONTHS     := L_PROD_REC.LIQN_MONTHS;
    L_LIQ_YEARS      := L_PROD_REC.LIQN_YEARS;
    L_REC_ICTM_ACC   := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
    G_CALC_FROM      := P_FROM_DATE;
    G_CALC_TO        := P_TO_DATE;
    L_INT_REM_PERIOD := NVL(P_INT_REM_PERIOD, 0);
    L_MAT_AMOUNT     := P_AMOUNT;
    DBG('l_mat_amount :' || L_MAT_AMOUNT);

    PR_GET_ISTOPUP(L_TOPUP_FLAG);
    DBG('l_topup_flag' || L_TOPUP_FLAG);

    DBG('l_mat_amount :' || L_MAT_AMOUNT);

    BEGIN
      SELECT *
        INTO L_ACC_PR
        FROM ICTB_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('exception in select from acc_pr ' || SQLERRM);
    END;

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      L_TB_CLUSTER_DATA('l_prod') := L_PROD.PROD;
      L_TB_CLUSTER_DATA('l_rule') := L_RULE;
      L_TB_CLUSTER_DATA('l_liq_days') := L_LIQ_DAYS;
      L_TB_CLUSTER_DATA('l_liq_months') := L_LIQ_MONTHS;
      L_TB_CLUSTER_DATA('l_liq_years') := L_LIQ_YEARS;
      IF NOT
          STPKS_STDTDTOP_UTILS_CLUSTER.FN_COMP_INT_MATDT(P_ACC,
                                                         P_BRN,
                                                         P_REF_NO,
                                                         P_AMOUNT,
                                                         P_FROM_DATE,
                                                         P_TO_DATE,
                                                         P_INT_RED_PERIOD,
                                                         P_INT_REM_PERIOD,
                                                         P_TB_RED_CALC_BRKUP,
                                                         P_MAT_AMOUNT,
                                                         P_ERROR_CODE,
                                                         P_ERROR_PARAMS,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA) THEN
        DBG('Failed in stpks_stdtdtop_utils_cluster.fn_comp_int_matdt -->' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('Succesfully returned from stpks_stdtdtop_utils_cluster.fn_comp_int_matdt');
      IF L_TB_CLUSTER_DATA.EXISTS('l_liq_days') THEN
        L_LIQ_DAYS := L_TB_CLUSTER_DATA('l_liq_days');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_liq_months') THEN
        L_LIQ_MONTHS := L_TB_CLUSTER_DATA('l_liq_months');
      END IF;
      IF L_TB_CLUSTER_DATA.EXISTS('l_liq_years') THEN
        L_LIQ_YEARS := L_TB_CLUSTER_DATA('l_liq_years');
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;

    STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := TRUE;
    STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY      := 0;
    IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
       NVL(L_LIQ_DAYS, 0) = 0 OR
       (L_REC_ICTM_ACC.BOOK_ACC != L_REC_ICTM_ACC.ACC) THEN
      L_LAST_DT := G_CALC_TO - 1;

    ELSE
      L_LAST_DT := L_ACC_PR.NEXT_LIQ_DT;
    END IF;

    IF STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y' THEN

      L_LAST_DT := L_ACC_PR.NEXT_LIQ_DT;
    END IF;

    DBG('l_last_dt ' || L_LAST_DT || 'g_calc_to=' || G_CALC_TO);
    IF L_LAST_DT > G_CALC_TO THEN
      L_LAST_DT := G_CALC_TO;
      DBG('l_last_dt in if' || L_LAST_DT);
    END IF;

    WHILE (L_LAST_DT <= G_CALC_TO) LOOP
      DBG('g_calc_from~g_calc_to~l_last_dt' || G_CALC_FROM || '~' ||
          G_CALC_TO || '~' || L_LAST_DT);
      ICPKSS_MAINT.PR_SET_REDEM_AMT(L_MAT_AMOUNT);
      STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_MAT_AMOUNT;
      IF NOT STPKS_TD_REDEMPTION.FN_DO_MEMO_ACCRUAL(P_BRN,
                                                    P_ACC,
                                                    G_CALC_FROM,
                                                    L_LAST_DT,
                                                    L_RULE,
                                                    L_PROD.PROD,
                                                    L_MEMO_REC,
                                                    P_ERROR_CODE,
                                                    P_ERROR_PARAMS) THEN
        DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
        P_ERROR_CODE := 'IC-MU0008';
        DBG('error in stpks_stdtdtop_utils.fn_matamt_comp---> ' || SQLERRM);
        RETURN FALSE;
      END IF;

      L_TMPCNT := L_TB_MAT_CALC.COUNT + 1;
      L_TB_MAT_CALC(L_TMPCNT).ACC := P_ACC;
      L_TB_MAT_CALC(L_TMPCNT).BRN := P_BRN;
      L_TB_MAT_CALC(L_TMPCNT).J := 5;
      L_TB_MAT_CALC(L_TMPCNT).FROM_DATE := G_CALC_FROM;
      L_TB_MAT_CALC(L_TMPCNT).TO_DATE := L_LAST_DT;
      L_TB_MAT_CALC(L_TMPCNT).AMOUNT := L_MAT_AMOUNT;

      SELECT NVL(SUM(DECODE(A.DRCR_IND, 'C', AMT, -AMT)), 0)
        INTO L_TB_MAT_CALC(L_TMPCNT).INTEREST
        FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
       WHERE B.FRM_NO = A.FRM_NO
         AND A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = L_PROD.PROD
         AND B.RULE_ID = L_RULE
         AND B.BOOK_FLAG = 'B';

      SELECT SUM(AMT)
        INTO L_TB_MAT_CALC(L_TMPCNT).PENALTY
        FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
       WHERE B.FRM_NO = A.FRM_NO
         AND A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = L_PROD.PROD
         AND B.RULE_ID = L_RULE
         AND A.DRCR_IND = 'D'
         AND A.IS_TAX = 'N'
         AND B.BOOK_FLAG = 'P';

      SELECT NVL(SUM(AMT), 0)
        INTO L_TB_MAT_CALC(L_TMPCNT).TAX
        FROM ICTW_MEMO_BOOKING
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD = L_PROD.PROD
         AND IS_TAX = 'Y';

      SELECT NVL(SUM(DECODE(DRCR_IND, 'C', AMT, -AMT)), 0)
        INTO L_ADJ_AMOUNT
        FROM ICTW_MEMO_BOOKING
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD = L_PROD.PROD;

      BEGIN
        SELECT 'Rate Date' || UDE_EFF_DT || '~' || UDE_VAL_LIST
          INTO L_TB_MAT_CALC(L_TMPCNT).RATE
          FROM ICTB_UDEVAL_ROW
         WHERE COND_KEY LIKE P_BRN || P_ACC
           AND COND_TYPE = 0
           AND UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                               FROM ICTB_UDEVAL_ROW
                              WHERE COND_KEY LIKE P_BRN || P_ACC
                                AND COND_TYPE = 0
                                AND UDE_EFF_DT <= G_CALC_FROM
                                AND PROD = L_PROD.PROD)
           AND PROD = L_PROD.PROD;
      EXCEPTION
        WHEN OTHERS THEN

          DBG('Error in getting the ude_val_list from ictb_udeval_row' ||
              SQLERRM);
      END;

      G_TOTAL_INTEREST := G_TOTAL_INTEREST + L_TB_MAT_CALC(L_TMPCNT)
                         .INTEREST;
      G_TOTAL_TAX      := G_TOTAL_TAX + L_TB_MAT_CALC(L_TMPCNT).TAX;

      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).BRN := P_BRN;
      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).ACC := P_ACC;
      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).LIQN_DATE := L_LAST_DT + 1;

      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).INTEREST_ONLY := L_TB_MAT_CALC(L_TMPCNT)
                                                                 .INTEREST +
                                                                  L_INT_REM_PERIOD +
                                                                  L_STDTPSIM_TAX;
      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).PENALTY := L_TB_MAT_CALC(L_TMPCNT)
                                                           .PENALTY;
      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).TAX := L_TB_MAT_CALC(L_TMPCNT)
                                                       .TAX + L_STDTPSIM_TAX;

      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).INTEREST := L_ADJ_AMOUNT +
                                                            L_INT_REM_PERIOD;

      DBG('l_adj_amount remaining period----->' || L_ADJ_AMOUNT ||
          'l_mat_amount' || L_MAT_AMOUNT);

      BEGIN
        SELECT COUNT(*)
          INTO L_INT_PAY_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Payout For Interest');
          L_INT_PAY_COUNT := 0;
      END;
      DBG('l_int_pay_count-->' || L_INT_PAY_COUNT);

      IF L_TB_MAT_CALC(L_TMPCNT).INTEREST < 0 AND L_INT_PAY_COUNT > 0 THEN
        DBG('l_adj_amount-->' || L_ADJ_AMOUNT);
        DBG('l_int_pay_count-->' || L_INT_PAY_COUNT);
        L_INT_PAY_COUNT := 0;
        DBG('l_int_pay_count-->' || L_INT_PAY_COUNT);

      END IF;

      IF L_TB_MAT_CALC(L_TMPCNT)
       .INTEREST < 0 AND (L_REC_ICTM_ACC.BOOK_ACC = L_REC_ICTM_ACC.ACC) THEN
        L_MAT_AMOUNT := L_MAT_AMOUNT + P_INT_RED_PERIOD;
        DBG('l_mat_amount ' || L_MAT_AMOUNT);
        DBG('p_int_red_period ' || P_INT_RED_PERIOD);
      END IF;

      IF (L_REC_ICTM_ACC.BOOK_ACC = L_REC_ICTM_ACC.ACC) AND
         L_INT_PAY_COUNT = 0 THEN
        L_MAT_AMOUNT := L_MAT_AMOUNT + L_ADJ_AMOUNT + L_INT_REM_PERIOD;
      END IF;
      L_INT_REM_PERIOD := 0;
      DBG('l_mat_amount ----->' || L_MAT_AMOUNT);

      STPKS_STDTPSIM_KERNEL.G_REC_CALC(L_COUNT).AMOUNT := L_MAT_AMOUNT;
      L_COUNT := L_COUNT + 1;

      DBG('Deleting ictw_memo_booking');
      DELETE FROM ICTW_MEMO_BOOKING A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = L_PROD.PROD;

      IF NVL(L_LIQ_YEARS, 0) = 0 AND NVL(L_LIQ_MONTHS, 0) = 0 AND
         NVL(L_LIQ_DAYS, 0) = 0 OR
         (L_REC_ICTM_ACC.BOOK_ACC != L_REC_ICTM_ACC.ACC) AND
         STPKSS_STDCUSTD_KERNEL.G_SIMULATION <> 'Y' THEN

        EXIT;
      END IF;

      EXIT WHEN L_LAST_DT >= G_CALC_TO;
      G_CALC_FROM := L_LAST_DT + 1;

      L_PROD_REC.DAYS_BF_MTHEND := NVL(L_PROD_REC.DAYS_BF_MTHEND, 0);
      IF L_PROD_REC.LIQN_START_ACCOUNT = 'Y' AND
         L_REC_ICTM_ACC.INT_START_DATE =
         LAST_DAY(L_REC_ICTM_ACC.INT_START_DATE) THEN
        L_LAST_DT := ADD_MONTHS(L_LAST_DT + 1 + L_PROD_REC.DAYS_BF_MTHEND,
                                12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                     L_LIQ_DAYS - L_PROD_REC.DAYS_BF_MTHEND - 1;
      ELSE
        L_LAST_DT := ADD_MONTHS(L_LAST_DT + L_PROD_REC.DAYS_BF_MTHEND,
                                12 * L_LIQ_YEARS + L_LIQ_MONTHS) +
                     L_LIQ_DAYS - L_PROD_REC.DAYS_BF_MTHEND;
      END IF;

      DBG('l_last_dt---->' || L_LAST_DT);

      IF L_LOOP_CNT = 0 THEN
        IF L_LAST_DT >= G_CALC_TO AND G_CALC_FROM <= (G_CALC_TO - 1) THEN
          L_LOOP_CNT := L_LOOP_CNT + 1;
          L_LAST_DT  := G_CALC_TO - 1;
          DBG('l_last_dt in if2' || L_LAST_DT);
        END IF;

      END IF;
    END LOOP;

    DBG(' g_total_interest=' || G_TOTAL_INTEREST);
    DBG(' g_total_tax=' || G_TOTAL_TAX);

    P_MAT_AMOUNT := L_MAT_AMOUNT;
    DBG('end  fn_comp_int_matdt maturity amount' || P_MAT_AMOUNT);
    DBG('Printing l_tb_mat_calc');
    PR_PRINT_TB_CALC(L_TB_MAT_CALC);

    IF P_REF_NO IS NOT NULL THEN
      IF NOT FN_POP_BRKUP_CALC(P_REF_NO, L_TB_MAT_CALC, P_TB_RED_CALC_BRKUP) THEN
        DBG('Failed in populating TDTB_REDM_CALC_BRKUP table');
      END IF;
    END IF;

    L_TB_MAT_CALC.DELETE;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in  fn_comp_int_matdt...' || SQLERRM);
      RETURN FALSE;
  END FN_COMP_INT_MATDT;

  FUNCTION FN_COMP_INT_ADJDATE(P_ACC              VARCHAR2,
                               P_BRN              VARCHAR2,
                               P_ADJ_ST_DATE      DATE,
                               P_TB_TOPUP_SETTLED IN TY_TB_TXN_DET,
                               P_INTEREST         OUT NUMBER,
                               P_MEMO_INT         OUT NUMBER,
                               P_ERROR_CODE       OUT VARCHAR2,
                               P_ERROR_PARAMS     OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_LIQ_INT         NUMBER := 0;
    L_REC_ICTM_ACC    ICTM_ACC%ROWTYPE;
    L_PAYOUT_COUNT    INTEGER := 0;
    L_BROKEN_INT      INTEGER := 0;
    L_LAST_LIQ_DATE   DATE;
    L_PROD            ICTMS_ACC_PR%ROWTYPE;
    L_PROD_REC        ICTM_PR_INT%ROWTYPE;
    L_RULE            ICTM_PR_INT.RULE%TYPE;
    L_MEMO_REC        STPKS_TD_REDEMPTION.TY_MEMO_REC;
    L_ADJ_AMOUNT      NUMBER := 0;
    L_BALANCE         NUMBER := 0;
    L_REDEM_FULL_FLAG VARCHAR2(1);

    L_IDX                 PLS_INTEGER;
    L_FROM_DATE           DATE;
    L_TO_DATE             DATE;
    L_CURR_LIQ_INT        NUMBER := 0;
    L_ADJ_INT             NUMBER := 0;
    L_ADJ_TAX             NUMBER := 0;
    L_IS_DEP_AMT_INIT_SDE BOOLEAN := FALSE;

    L_INDEX     PLS_INTEGER;
    L_HSH_INDEX PLS_INTEGER;

    L_TB_EVENT_DATES TY_TB_TXN_DET;

  BEGIN
    DBG('Start of fn_comp_int_adjdate p_adj_st_date=' || P_ADJ_ST_DATE);
    P_MEMO_INT := 0;

    G_INT_LIQD.DELETE;
    G_TAX_LIQD.DELETE;

    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);

    IF NOT FN_GET_LAST_LIQ_DT(P_ACC,
                              P_BRN,
                              P_ADJ_ST_DATE,
                              P_TB_TOPUP_SETTLED,
                              L_LAST_LIQ_DATE) THEN

      DBG('Failed in getting fn_get_last_liq_dt ');
    END IF;
    ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FULL_FLAG);
    DBG('l_redem_full_flag=' || L_REDEM_FULL_FLAG);
    L_LAST_LIQ_DATE := NVL(L_LAST_LIQ_DATE, L_REC_ICTM_ACC.INT_START_DATE);

    DBG('l_last_liq_date=' || L_LAST_LIQ_DATE);

    L_PROD     := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);
    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(L_PROD.PROD);
    L_RULE     := L_PROD_REC.RULE;

    DBG('Calculating the interest from interest start date till last liquidation date');

    IF P_TB_TOPUP_SETTLED.COUNT > 0 THEN
      L_HSH_INDEX := FN_HASH_DATE(P_ADJ_ST_DATE);
      IF P_TB_TOPUP_SETTLED.EXISTS(L_HSH_INDEX) THEN
        L_INDEX := L_HSH_INDEX;
      ELSE
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_HSH_INDEX);
      END IF;
      WHILE L_INDEX IS NOT NULL LOOP
        L_TB_EVENT_DATES(L_INDEX) := P_TB_TOPUP_SETTLED(L_INDEX);
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_INDEX);
      END LOOP;

    END IF;

    IF L_TB_EVENT_DATES.COUNT > 0 THEN
      STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');

      IF NOT FN_IS_DEP_AMT_INT_SDE(L_PROD.PROD, L_IS_DEP_AMT_INIT_SDE) THEN
        DBG('Failed in identifying dep_amt_init SDE');
        L_IS_DEP_AMT_INIT_SDE := FALSE;
      END IF;

      L_LIQ_INT := 0;
      L_IDX     := L_TB_EVENT_DATES.FIRST;
      WHILE L_IDX IS NOT NULL LOOP
        L_FROM_DATE := L_TB_EVENT_DATES(L_IDX).G_EVENT_DETAIL_REC.EVENT_DATE;

        IF L_TB_EVENT_DATES.NEXT(L_IDX) IS NOT NULL THEN
          L_TO_DATE := L_TB_EVENT_DATES(L_TB_EVENT_DATES.NEXT(L_IDX))
                       .G_EVENT_DETAIL_REC.EVENT_DATE - 1;

        ELSE
          DBG('Processing the last record..exit');
          EXIT;
        END IF;

        IF NOT L_IS_DEP_AMT_INIT_SDE THEN
          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT := L_TB_EVENT_DATES(L_IDX)
                                                 .G_EVENT_DETAIL_REC.BALANCE +
                                                  L_LIQ_INT;

        ELSE
          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := L_TB_EVENT_DATES(L_IDX)
                                                      .G_EVENT_DETAIL_REC.BALANCE;
        END IF;

        IF NOT STPKS_TD_REDEMPTION.FN_DO_MEMO_ACCRUAL(P_BRN,
                                                      P_ACC,
                                                      L_FROM_DATE,
                                                      L_TO_DATE,
                                                      L_RULE,
                                                      L_PROD.PROD,
                                                      L_MEMO_REC,
                                                      P_ERROR_CODE,
                                                      P_ERROR_PARAMS) THEN
          DBG('failed in FN_DO_MEMO_ACCRUAL ' || SQLERRM);
          P_ERROR_CODE := 'IC-MU0008';
          DBG('error in stpks_stdtdtop_utils.fn_matamt_comp---> ' ||
              SQLERRM);
          RETURN FALSE;
        END IF;

        L_ADJ_INT := 0;
        L_ADJ_TAX := 0;
        FOR I IN (SELECT A.*
                    FROM ICTW_MEMO_BOOKING A, ICTM_RULE_FRM B
                   WHERE B.FRM_NO = A.FRM_NO
                     AND A.BRN = P_BRN
                     AND A.ACC = P_ACC
                     AND A.PROD = L_PROD.PROD
                     AND B.RULE_ID = L_RULE
                     AND B.BOOK_FLAG != 'P') LOOP

          IF I.DRCR_IND = 'C' THEN
            L_ADJ_INT := L_ADJ_INT + NVL(I.AMT, 0);
          END IF;
          IF I.DRCR_IND = 'D' AND I.IS_TAX = 'N' THEN
            L_ADJ_INT := L_ADJ_INT - NVL(I.AMT, 0);
          END IF;
          IF I.IS_TAX = 'Y' THEN
            L_ADJ_TAX := L_ADJ_TAX + NVL(I.AMT, 0);
          END IF;
          IF G_INT_LIQD.EXISTS(I.FRM_NO) THEN
            G_INT_LIQD(I.FRM_NO) := G_INT_LIQD(I.FRM_NO) +
                                    NVL(L_ADJ_INT, 0);
          ELSE
            G_INT_LIQD(I.FRM_NO) := NVL(L_ADJ_INT, 0);
          END IF;
          IF G_TAX_LIQD.EXISTS(I.FRM_NO) THEN
            G_TAX_LIQD(I.FRM_NO) := G_TAX_LIQD(I.FRM_NO) +
                                    NVL(L_ADJ_TAX, 0);
          ELSE
            G_TAX_LIQD(I.FRM_NO) := NVL(L_ADJ_TAX, 0);
          END IF;
        END LOOP;

        DBG('Interest is ' || L_ADJ_AMOUNT);

        L_ADJ_AMOUNT := L_ADJ_AMOUNT + NVL(L_ADJ_INT, 0) -
                        NVL(L_ADJ_TAX, 0);

        L_CURR_LIQ_INT := L_CURR_LIQ_INT + L_ADJ_AMOUNT;

        IF L_TB_EVENT_DATES.NEXT(L_IDX) IS NOT NULL THEN
          IF NVL(L_TB_EVENT_DATES(L_TB_EVENT_DATES.NEXT(L_IDX))
                 .G_EVENT_DETAIL_REC.LIQD_AMT,
                 0) > 0 THEN
            L_LIQ_INT      := L_LIQ_INT + L_CURR_LIQ_INT;
            L_CURR_LIQ_INT := 0;
          END IF;
        END IF;
        IF P_ADJ_ST_DATE > L_LAST_LIQ_DATE THEN
          P_MEMO_INT := P_MEMO_INT + L_ADJ_AMOUNT;

        END IF;
        DELETE FROM ICTW_MEMO_BOOKING A
         WHERE A.BRN = P_BRN
           AND A.ACC = P_ACC
           AND A.PROD = L_PROD.PROD;

        L_ADJ_AMOUNT := 0;
        L_IDX        := L_TB_EVENT_DATES.NEXT(L_IDX);
      END LOOP;
    END IF;

    STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');

    P_INTEREST := L_LIQ_INT;
    DBG('End of fn_comp_int_adjdate p_interest~p_memo_int' || P_INTEREST || '~' ||
        P_MEMO_INT);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in  fn_comp_int_adjdate...' || SQLERRM);
      RETURN FALSE;
  END FN_COMP_INT_ADJDATE;

  FUNCTION FN_GET_CURR_REDEMINT(P_ACC_NO             VARCHAR2,
                                P_BRN_CODE           VARCHAR2,
                                P_ADJ_START_DATE     DATE,
                                P_TB_TOPUP_SETTLED   TY_TB_TXN_DET,
                                P_MEMO_REC1          STPKS_TD_REDEMPTION.TY_MEMO_REC,
                                P_MEMO_REC2          STPKS_TD_REDEMPTION.TY_MEMO_REC,
                                P_MEMO_REC3          STPKS_TD_REDEMPTION.TY_MEMO_REC,
                                P_CURR_REDEM_INT     OUT NUMBER,
                                P_CURR_REDEM_TAX     OUT NUMBER,
                                P_CURR_REDEM_PENALTY OUT NUMBER)
    RETURN BOOLEAN IS
    L_INDEX                   PLS_INTEGER;
    L_DIFF_AMT                NUMBER := 0;
    L_INTEREST_1              NUMBER := 0;
    L_INTEREST_2              NUMBER := 0;
    L_INTEREST_3              NUMBER := 0;
    L_PENALTY_1               NUMBER := 0;
    L_PENALTY_2               NUMBER := 0;
    L_PENALTY_3               NUMBER := 0;
    L_TAX_1                   NUMBER := 0;
    L_TAX_2                   NUMBER := 0;
    L_TAX_3                   NUMBER := 0;
    L_PROD                    ICTMS_ACC_PR%ROWTYPE;
    L_PROD_REC                ICTM_PR_INT%ROWTYPE;
    L_RULE                    ICTM_PR_INT.RULE%TYPE;
    L_HASH_INDEX              PLS_INTEGER;
    L_LIQ_ADJ_DATE            DATE;
    L_FROM_DATE               DATE;
    L_AMT_LIQD_TILLDATE       DBMS_SQL.NUMBER_TABLE;
    L_TAX_LIQD_TILLDATE       DBMS_SQL.NUMBER_TABLE;
    L_TOTAL_INT_LIQD_TILLDATE NUMBER := 0;
    L_TOTAL_TAX_LIQD_TILLDATE NUMBER := 0;
    L_ERROR_CODE              VARCHAR2(255);
    L_REC_ICTM_ACC            ICTM_ACC%ROWTYPE;
    L_DIFF_INTEREST           NUMBER := 0;
    L_DIFF_TAX                NUMBER := 0;
    PROCEDURE PR_GET_COMP(P_RULE     VARCHAR2,
                          P_MEMO_REC STPKS_TD_REDEMPTION.TY_MEMO_REC,
                          P_INTEREST OUT NUMBER,
                          P_PENALTY  OUT NUMBER,
                          P_TAX      OUT NUMBER) IS
      L_INDEX     PLS_INTEGER;
      L_INTEREST  NUMBER := 0;
      L_PENALTY   NUMBER := 0;
      L_TAX       NUMBER := 0;
      L_BOOK_FLAG ICTMS_RULE_FRM.BOOK_FLAG%TYPE;
    BEGIN
      IF P_MEMO_REC.COUNT > 0 THEN
        L_INDEX := P_MEMO_REC.FIRST;
        WHILE L_INDEX IS NOT NULL LOOP

          SELECT BOOK_FLAG
            INTO L_BOOK_FLAG
            FROM ICTMS_RULE_FRM
           WHERE RULE_ID = P_RULE
             AND FRM_NO = P_MEMO_REC(L_INDEX).FRM_NO;

          IF (P_MEMO_REC(L_INDEX)
             .DRCR_IND = 'C' AND NVL(P_MEMO_REC(L_INDEX).IS_TAX, 'N') = 'N')

           THEN
            L_INTEREST := L_INTEREST + P_MEMO_REC(L_INDEX).AMT;
          ELSIF

           (P_MEMO_REC(L_INDEX)
           .DRCR_IND = 'D' AND NVL(L_BOOK_FLAG, 'B') != 'P' AND
            NVL(P_MEMO_REC(L_INDEX).IS_TAX, 'N') = 'N') THEN

            L_INTEREST := L_INTEREST - P_MEMO_REC(L_INDEX).AMT;
          ELSIF P_MEMO_REC(L_INDEX).DRCR_IND = 'D' AND
                 NVL(P_MEMO_REC(L_INDEX).IS_TAX, 'N') = 'N' AND
                 L_BOOK_FLAG = 'P' THEN
            L_PENALTY := L_PENALTY + P_MEMO_REC(L_INDEX).AMT;
          ELSIF NVL(P_MEMO_REC(L_INDEX).IS_TAX, 'N') = 'Y' THEN
            L_TAX := L_TAX + P_MEMO_REC(L_INDEX).AMT;

          END IF;
          L_INDEX := P_MEMO_REC.NEXT(L_INDEX);
        END LOOP;
        P_INTEREST := L_INTEREST;
        P_PENALTY  := L_PENALTY;
        P_TAX      := L_TAX;
      END IF;
      DBG('Returning from pr_get_comp' || P_INTEREST || '~' || P_PENALTY || '~' ||
          P_TAX);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO Exception in pr_get_comp' || SQLERRM);
    END PR_GET_COMP;

  BEGIN
    DBG('Start of fn_get_curr_redemInt');
    L_PROD     := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC_NO, P_BRN_CODE);
    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_PR_INT(L_PROD.PROD);
    L_RULE     := L_PROD_REC.RULE;

    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC_NO, P_BRN_CODE);

    PR_GET_COMP(L_RULE, P_MEMO_REC1, L_INTEREST_1, L_PENALTY_1, L_TAX_1);
    PR_GET_COMP(L_RULE, P_MEMO_REC2, L_INTEREST_2, L_PENALTY_2, L_TAX_2);
    PR_GET_COMP(L_RULE, P_MEMO_REC3, L_INTEREST_3, L_PENALTY_3, L_TAX_3);

    L_HASH_INDEX := FN_HASH_DATE(P_ADJ_START_DATE);
    IF P_TB_TOPUP_SETTLED.EXISTS(L_HASH_INDEX) THEN
      L_INDEX := L_HASH_INDEX;
    ELSE
      L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_HASH_INDEX);
    END IF;
    WHILE L_INDEX IS NOT NULL LOOP
      IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT > 0 THEN
        L_LIQ_ADJ_DATE := P_TB_TOPUP_SETTLED(L_INDEX)
                          .G_EVENT_DETAIL_REC.EVENT_DATE;
        EXIT;
      END IF;
      L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_INDEX);
    END LOOP;
    L_FROM_DATE := NVL(L_LIQ_ADJ_DATE, L_REC_ICTM_ACC.INT_START_DATE);

    IF NOT FN_FIND_LIQD_AMT(P_BRN_CODE,
                            P_ACC_NO,
                            L_PROD.PROD,
                            L_FROM_DATE,
                            L_AMT_LIQD_TILLDATE,
                            L_TAX_LIQD_TILLDATE,
                            L_ERROR_CODE) THEN

      DBG('failed in liqd amount and tax calculation -->' || L_ERROR_CODE);
      RETURN FALSE;
    END IF;

    IF L_AMT_LIQD_TILLDATE.COUNT > 0 THEN
      L_INDEX := L_AMT_LIQD_TILLDATE.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_TOTAL_INT_LIQD_TILLDATE := L_TOTAL_INT_LIQD_TILLDATE +
                                     L_AMT_LIQD_TILLDATE(L_INDEX);
        L_INDEX                   := L_AMT_LIQD_TILLDATE.NEXT(L_INDEX);
      END LOOP;
    END IF;

    IF L_TAX_LIQD_TILLDATE.COUNT > 0 THEN
      L_INDEX := L_TAX_LIQD_TILLDATE.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_TOTAL_TAX_LIQD_TILLDATE := L_TOTAL_TAX_LIQD_TILLDATE +
                                     L_TAX_LIQD_TILLDATE(L_INDEX);
        L_INDEX                   := L_TAX_LIQD_TILLDATE.NEXT(L_INDEX);
      END LOOP;
    END IF;

    L_DIFF_INTEREST      := L_TOTAL_INT_LIQD_TILLDATE -
                            (NVL(L_INTEREST_1, 0) + NVL(L_INTEREST_2, 0));
    L_DIFF_TAX           := L_TOTAL_TAX_LIQD_TILLDATE -
                            (NVL(L_TAX_1, 0) + NVL(L_TAX_2, 0));
    P_CURR_REDEM_INT     := NVL(L_INTEREST_3, 0) - NVL(L_DIFF_INTEREST, 0);
    P_CURR_REDEM_TAX     := NVL(L_TAX_3, 0) - NVL(L_DIFF_TAX, 0);
    P_CURR_REDEM_PENALTY := NVL(L_PENALTY_1, 0) + NVL(L_PENALTY_3, 0);

    DBG('l_diff_interest~l_diff_tax' || L_DIFF_INTEREST || '~' ||
        L_DIFF_TAX);
    DBG('p_curr_redem_int~p_curr_redem_tax~p_curr_Redem_penalty' ||
        P_CURR_REDEM_INT || '~' || P_CURR_REDEM_TAX || '~' ||
        P_CURR_REDEM_PENALTY);
    DBG('Returning from fn_get_curr_redemInt');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END FN_GET_CURR_REDEMINT;

  FUNCTION FN_MATAMT_COMP(P_SOURCE            IN VARCHAR2,
                          P_ACTION_CODE       IN VARCHAR2,
                          P_ICDREDMN          IN OUT TDVWS_TD_REDEMPTION%ROWTYPE,
                          P_TB_RED_CALC_BRKUP OUT TY_TB_RED_BRKUP,
                          P_ERROR_CODE        OUT VARCHAR2,
                          P_ERROR_PARAMS      OUT VARCHAR2) RETURN BOOLEAN IS
    L_TB_CALC STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_INDEX   PLS_INTEGER;
    L_FLD     VARCHAR2(1000);

    L_REC_ICTM_ACC           ICTM_ACC%ROWTYPE;
    L_PROD                   ICTMS_ACC_PR%ROWTYPE;
    P_MEMO_REC1              STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC2              STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC3              STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC4              STPKS_TD_REDEMPTION.TY_MEMO_REC;
    PKG_REDEM_AMT_ACCR       DBMS_SQL.NUMBER_TABLE;
    PKG_TAX_ON_REDEM_AMT     DBMS_SQL.NUMBER_TABLE;
    PKG_PENALTY_ON_REDEM_AMT DBMS_SQL.NUMBER_TABLE;
    L_RED_AMT_1              NUMBER := 0;
    L_REM_AMT_2              NUMBER := 0;
    L_RED_AMT_3              NUMBER := 0;
    L_REM_AMT_4              NUMBER := 0;
    L_CALC_DATE              DATE;
    L_ADJ_START_DATE         DATE;
    L_FINAL_AMT              NUMBER := 0;
    L_FROM_DATE              DATE;
    L_MAT_AMT                NUMBER := 0;
    L_PAYOUT_COUNT           NUMBER := 0;
    L_TOPUP_FLAG             VARCHAR2(1);
    L_TOPUP_RATES            BOOLEAN := FALSE;
    L_ACC_REC                STTM_CUST_ACCOUNT%ROWTYPE;
    L_ACC_CLASS_REC          STTM_ACCOUNT_CLASS%ROWTYPE;
    L_AMT                    NUMBER := 0;
    L_CUM_FLAG               BOOLEAN := FALSE;
    L_TMP_FRM_DT             DATE;
    L_TMP_FINAL_AMT          NUMBER := 0;
    L_KEY                    VARCHAR2(70);
    L_ACC_PR                 ICTB_ACC_PR%ROWTYPE;
    L_DATE                   DATE;

    P_SID    VARCHAR2(50);
    P_SERIAL VARCHAR2(50);

    L_TB_TOPUP_SETTLED    TY_TB_TXN_DET;
    L_TB_TOPUP_MODIFIED   TY_TB_TXN_DET;
    L_IS_DEP_AMT_INIT_SDE BOOLEAN := FALSE;
    L_TB_REDM_CALC_BRKUP  TY_TB_RED_BRKUP;
    L_ADJ_INT             NUMBER := 0;
    L_FUNCTION_ID         SMTB_MENU.FUNCTION_ID%TYPE;
    L_BALREC              STTM_ACCOUNT_BALANCE%ROWTYPE;
    L_ACTION              VARCHAR2(32767);

    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;

    L_BROKEN_INT           NUMBER := 0;
    L_ACY_WITHDRAWABLE_BAL STTMS_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    PROCEDURE PR_SET_BASIC_PARAMS IS
    BEGIN
      IF NVL(P_ICDREDMN.WAIVE_INTEREST, 'N') = 'N' THEN
        ICPKS_BOD.G_WAVE_INTEREST := 0;
      ELSE
        ICPKS_BOD.G_WAVE_INTEREST := 1;
      END IF;

      IF NVL(P_ICDREDMN.REDEMPTION_MODE, '*') = 'N' THEN

        STPKS_TD_REDEMPTION.PKG_FROM_BROKEN_TD := TRUE;
        DBG('Setting the stpks_td_redemption.pkg_From_broken_td as true and icpkss_maint.pr_set_full_redem to Y here');
        ICPKSS_MAINT.PR_SET_FULL_REDEM('Y');
      ELSIF NVL(P_ICDREDMN.REDEMPTION_MODE, '*') = 'Y' THEN

        ICPKSS_MAINT.PR_SET_FULL_REDEM('N');
        DBG('Setting the  icpkss_maint.pr_set_full_redem to N here');
      END IF;

    END PR_SET_BASIC_PARAMS;

  BEGIN
    DBG('Start of fn_matamt_comp');

    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      IF NOT
          STPKS_STDTDTOP_UTILS_CLUSTER.FN_PRE_MATAMT_COMP(P_SOURCE,
                                                          P_ACTION_CODE,
                                                          P_ICDREDMN,
                                                          P_TB_RED_CALC_BRKUP,
                                                          P_ERROR_CODE,
                                                          P_ERROR_PARAMS) THEN
        DBG('Failed in stpks_stdtdtop_utils_cluster.fn_pre_matamt_comp -->' ||
            SQLERRM);
        RETURN FALSE;
      END IF;
      DBG('Succesfully returned from stpks_stdtdtop_utils_cluster.fn_pre_matamt_comp');
    END IF;

    IF NOT GLOBAL.G_SKIP_KERNEL THEN

      G_PENALTY_REDEMPTION := 0;

      G_TOTAL_INTEREST := 0;
      G_TOTAL_TAX      := 0;

      L_KEY := P_ICDREDMN.BRN_CODE || P_ICDREDMN.AC_NO;
      IF ICPKS_CACHE.PKG_TB_ICTM_ACC.EXISTS(L_KEY) THEN
        ICPKS_CACHE.PKG_TB_ICTM_ACC.DELETE(L_KEY);
      END IF;

      L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ICDREDMN.AC_NO,
                                                    P_ICDREDMN.BRN_CODE);

      L_PROD := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ICDREDMN.AC_NO,
                                                P_ICDREDMN.BRN_CODE);
      IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_ICDREDMN.BRN_CODE,
                                       P_ICDREDMN.AC_NO,
                                       L_ACC_REC) THEN
        DBG('Could not get account');
      END IF;
      CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACC_REC.ACCOUNT_CLASS,
                                    L_ACC_CLASS_REC,
                                    P_ERROR_CODE);

      PR_SET_BASIC_PARAMS;

      IF NOT FN_IS_DEP_AMT_INT_SDE(L_PROD.PROD, L_IS_DEP_AMT_INIT_SDE) THEN
        DBG('Failed in identifying dep_amt_init SDE');
        L_IS_DEP_AMT_INIT_SDE := FALSE;
      END IF;

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_ICDREDMN.BRN_CODE
           AND ACC = P_ICDREDMN.AC_NO
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Payout For Interest');
          L_PAYOUT_COUNT := 0;
      END;

      IF P_ICDREDMN.REDEMPTION_MODE = 'N' AND
         P_ICDREDMN.WAIVE_INTEREST = 'N' THEN

        IF L_REC_ICTM_ACC.MATURITY_DATE <= GLOBAL.APPLICATION_DATE THEN
          P_ICDREDMN.MATURITY_AMOUNT := L_REC_ICTM_ACC.MATURITY_AMOUNT;
          P_ICDREDMN.INTEREST_RATE   := L_REC_ICTM_ACC.INTEREST_RATE;

          BEGIN
            SELECT TD_AMOUNT + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
              INTO P_ICDREDMN.PRINCIPAL_AMOUNT
              FROM ICTM_TD_DETAILS
             WHERE ACC = P_ICDREDMN.AC_NO
               AND BRN = P_ICDREDMN.BRN_CODE;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in ICTM_TD_DEATILS Query');
          END;
          RETURN TRUE;
        END IF;

      END IF;

      SAVEPOINT SAV_MAT1;

      DBG('<<<<<< step1 >>>>>>>>: savepoint sav_mat1 set. updating the topup settled table ictb_tdtopup_settled');
      IF NOT FN_UPD_TOPUP_SETTLED(P_ICDREDMN.AC_NO,
                                  P_ICDREDMN.BRN_CODE,
                                  P_ICDREDMN.REDEMPTION_AMT,
                                  L_TB_TOPUP_MODIFIED,
                                  L_TB_TOPUP_SETTLED,
                                  P_ERROR_CODE,
                                  P_ERROR_PARAMS) THEN
        DEBUG.PR_DEBUG('IC',
                       'fAILED IN  OF STUB stpks_stdtdtop_utils.fn_upd_topup_settled' ||
                       P_ERROR_CODE);
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, L_FLD);
        RETURN FALSE;
      END IF;

      DBG('<<<<<< step2 >>>>>>>>: fn_build_rec_calc');
      IF NOT FN_BUILD_REC_CALC(P_ICDREDMN.AC_NO,
                               P_ICDREDMN.BRN_CODE,
                               L_TB_TOPUP_MODIFIED,
                               L_TB_TOPUP_SETTLED,
                               L_TB_CALC,
                               L_ADJ_START_DATE,
                               P_ERROR_CODE,
                               P_ERROR_PARAMS) THEN
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, L_FLD);
        DBG('Failed in fn_build_rec_calc ');
        RETURN FALSE;
      END IF;

      IF L_ADJ_START_DATE != L_REC_ICTM_ACC.INT_START_DATE

       THEN
        DBG('<<<<<< step3 >>>>>>>>: calling fn_comp_int_adjdate to get the int liqd till date ');
        IF NOT FN_COMP_INT_ADJDATE(P_ICDREDMN.AC_NO,
                                   P_ICDREDMN.BRN_CODE,
                                   L_ADJ_START_DATE,
                                   L_TB_TOPUP_SETTLED,
                                   G_LIQD_INT_TILL_DATE,
                                   G_ADJ_INT_TILL_DATE,
                                   P_ERROR_CODE,
                                   P_ERROR_PARAMS) THEN
          OVPKSS.PR_APPENDTBL(P_ERROR_CODE, L_FLD);
          DBG('Failed in fn_build_rec_calc ');
          RETURN FALSE;
        END IF;

        IF L_PAYOUT_COUNT > 0 OR
           L_REC_ICTM_ACC.ACC <> L_REC_ICTM_ACC.BOOK_ACC THEN
          L_ADJ_INT            := G_ADJ_INT_TILL_DATE;
          G_ADJ_INT_TILL_DATE  := 0;
          G_LIQD_INT_TILL_DATE := 0;
          DBG('l_adj_int--->' || L_ADJ_INT);
        END IF;

      END IF;
      DBG('g_liqd_int_till_date~g_adj_int_till_date~' ||
          G_LIQD_INT_TILL_DATE || '~' || G_ADJ_INT_TILL_DATE);

      BEGIN
        SELECT MAX(ENT_DT)
          INTO L_CALC_DATE
          FROM ICTBS_ENTRIES_HISTORY A
         WHERE A.ACC = P_ICDREDMN.AC_NO
           AND A.BRN = P_ICDREDMN.BRN_CODE
           AND A.LIQN = 'Y'
           AND A.ENTRY_PASSED = 'Y';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No liquidations has happened .. inside no_data_found');
          L_CALC_DATE := NULL;
        WHEN OTHERS THEN
          DBG('In WOT of max of LIQ entry date--> ' || SQLERRM);
          RETURN FALSE;
      END;
      DBG('l_calc_date is :' || L_CALC_DATE);
      DBG('l_rec_ictm_acc.acc is :' || L_REC_ICTM_ACC.ACC);
      DBG('l_rec_ictm_acc.book_acc is :' || L_REC_ICTM_ACC.BOOK_ACC);
      DBG('l_payout_count is :' || L_PAYOUT_COUNT);
      IF L_CALC_DATE IS NULL AND
         L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
         L_PAYOUT_COUNT = 0 THEN
        DBG('Going to call fn_get_broken_int');
        IF NOT FN_GET_BROKEN_INT(L_REC_ICTM_ACC.ACC,
                                 L_REC_ICTM_ACC.BRN,
                                 L_REC_ICTM_ACC.INT_START_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_BROKEN_INT) THEN
          DBG('Failed in getting the fn_get_broken_int' || SQLERRM);
        END IF;
        DBG('Got l_broken_int as :' || L_BROKEN_INT);
      END IF;

      DBG('<<<<<< step4 >>>>>>>>::Done with building the calc tables....about to call fn_compute_int now..(compute int till current_date - 1)');

      IF NOT FN_COMPUTE_INT(P_ICDREDMN.AC_NO,
                            P_ICDREDMN.BRN_CODE,
                            P_ICDREDMN.CCY,
                            L_ADJ_START_DATE,
                            L_TB_TOPUP_SETTLED,
                            L_TB_CALC,
                            P_MEMO_REC1,
                            P_MEMO_REC2,
                            P_MEMO_REC3,
                            P_MEMO_REC4,
                            PKG_REDEM_AMT_ACCR,
                            PKG_TAX_ON_REDEM_AMT,
                            PKG_PENALTY_ON_REDEM_AMT,
                            P_ERROR_CODE,
                            P_ERROR_PARAMS) THEN

        DBG('Failed in computing the interest ');
        OVPKSS.PR_APPENDTBL(P_ERROR_CODE, L_FLD);
        DBG('Failed in fn_build_rec_calc ');
        RETURN FALSE;
      END IF;

      DBG('p_icdredmn.redem_ref_no--->' || P_ICDREDMN.REDEM_REF_NO);

      DBG('p_icdredmn.REDEMPTION_MODE--->' || P_ICDREDMN.REDEMPTION_MODE);
      DBG('p_icdredmn.REDEM_INT_PAYOUT--->' || P_ICDREDMN.REDEM_INT_PAYOUT);
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
        G_CURR_REDEM_INT     := 0;
        G_CURR_REDEM_TAX     := 0;
        G_CURR_REDEM_PENALTY := 0;
        IF NOT FN_GET_CURR_REDEMINT(P_ICDREDMN.AC_NO,
                                    P_ICDREDMN.BRN_CODE,
                                    L_ADJ_START_DATE,
                                    L_TB_TOPUP_SETTLED,
                                    P_MEMO_REC1,
                                    P_MEMO_REC2,
                                    P_MEMO_REC3,
                                    G_CURR_REDEM_INT,
                                    G_CURR_REDEM_TAX,
                                    G_CURR_REDEM_PENALTY) THEN
          DBG('Failed in getting current redemption interest details ');
        END IF;
      ELSE
        G_CURR_REDEM_INT     := 0;
        G_CURR_REDEM_TAX     := 0;
        G_CURR_REDEM_PENALTY := 0;
      END IF;
      DBG('g_Curr_Redem_int-->' || G_CURR_REDEM_INT);
      DBG('g_Curr_Redem_Tax-->' || G_CURR_REDEM_TAX);
      DBG('g_Curr_Redem_Penalty-->' || G_CURR_REDEM_PENALTY);

      IF P_ICDREDMN.REDEM_REF_NO IS NOT NULL THEN
        IF NOT FN_POP_BRKUP_CALC(P_ICDREDMN.REDEM_REF_NO,
                                 L_TB_CALC,
                                 L_TB_REDM_CALC_BRKUP) THEN
          DBG('Failed in populating TDTB_REDM_CALC_BRKUP table');
        END IF;
      END IF;

      DBG('<<<<<< step5 >>>>>>>>:Now plsql table is having all the interest, tax , penalty details for J = 1,2,3,4..');
      DBG('calculating interest/tax for remaining amount from redemption date to maturity date .');

      DBG('Start date : ' || L_ADJ_START_DATE || 'Liqn end date ' ||
          L_CALC_DATE);

      DBG('printing the values in plsql table');
      PR_PRINT_TB_CALC(L_TB_CALC);

      L_INDEX := L_TB_CALC.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        IF L_TB_CALC(L_INDEX).J = 1 THEN
          L_RED_AMT_1          := L_RED_AMT_1 +
                                  NVL(L_TB_CALC(L_INDEX).INTEREST, 0) -
                                  NVL(L_TB_CALC(L_INDEX).PENALTY, 0) -
                                  NVL(L_TB_CALC(L_INDEX).TAX, 0);
          G_PENALTY_REDEMPTION := NVL(G_PENALTY_REDEMPTION, 0) +
                                  NVL(L_TB_CALC(L_INDEX).PENALTY, 0);

          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            G_TOTAL_INTEREST := G_TOTAL_INTEREST +
                                NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
            G_TOTAL_TAX      := G_TOTAL_TAX +
                                NVL(L_TB_CALC(L_INDEX).TAX, 0);
            DBG('Inside j=1 g_total_interest-->' || G_TOTAL_INTEREST);
            DBG('Inside j=1 g_total_tax-->' || G_TOTAL_INTEREST);
          END IF;

        ELSIF L_TB_CALC(L_INDEX).J = 2 THEN

          IF CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDRDSIM' THEN
            L_REM_AMT_2 := L_REM_AMT_2 +
                           NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
          ELSE

            L_REM_AMT_2 := L_REM_AMT_2 +
                           NVL(L_TB_CALC(L_INDEX).INTEREST, 0) -
                           NVL(L_TB_CALC(L_INDEX).PENALTY, 0) -
                           NVL(L_TB_CALC(L_INDEX).TAX, 0);

          END IF;

          G_TOTAL_INTEREST := G_TOTAL_INTEREST +
                              NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
          G_TOTAL_TAX      := G_TOTAL_TAX + NVL(L_TB_CALC(L_INDEX).TAX, 0);

        ELSIF L_TB_CALC(L_INDEX).J = 3 THEN
          L_RED_AMT_3 := L_RED_AMT_3 + NVL(L_TB_CALC(L_INDEX).INTEREST, 0) -
                         NVL(L_TB_CALC(L_INDEX).PENALTY, 0) -
                         NVL(L_TB_CALC(L_INDEX).TAX, 0);

          IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
            G_TOTAL_INTEREST := G_TOTAL_INTEREST +
                                NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
            G_TOTAL_TAX      := G_TOTAL_TAX +
                                NVL(L_TB_CALC(L_INDEX).TAX, 0);
            DBG('Inside j=3 g_total_interest-->' || G_TOTAL_INTEREST);
            DBG('Inside j=3 g_total_tax-->' || G_TOTAL_INTEREST);
          END IF;

          G_PENALTY_REDEMPTION := NVL(G_PENALTY_REDEMPTION, 0) +
                                  NVL(L_TB_CALC(L_INDEX).PENALTY, 0);
        ELSIF L_TB_CALC(L_INDEX).J = 4 THEN

          IF CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID') = 'ICDRDSIM' THEN
            L_REM_AMT_4 := L_REM_AMT_4 +
                           NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
          ELSE

            L_REM_AMT_4 := L_REM_AMT_4 +
                           NVL(L_TB_CALC(L_INDEX).INTEREST, 0) -
                           NVL(L_TB_CALC(L_INDEX).PENALTY, 0) -
                           NVL(L_TB_CALC(L_INDEX).TAX, 0);
          END IF;

          G_TOTAL_INTEREST := G_TOTAL_INTEREST +
                              NVL(L_TB_CALC(L_INDEX).INTEREST, 0);
          G_TOTAL_TAX      := G_TOTAL_TAX + NVL(L_TB_CALC(L_INDEX).TAX, 0);

          IF (STPKS_STDTPSIM_KERNEL.G_STDTPSIM = 'Y' AND
             P_ACTION_CODE = 'COMPUTE') THEN
            L_STDTPSIM_TAX := L_STDTPSIM_TAX +
                              NVL(L_TB_CALC(L_INDEX).TAX, 0);
          END IF;
          DBG('l_stdtpsim_tax new is ' || L_INDEX || '~' || L_STDTPSIM_TAX);

          L_FINAL_AMT := L_TB_CALC(L_INDEX).AMOUNT;

          IF L_TB_CALC(L_INDEX).FROM_DATE > L_TB_CALC(L_INDEX).TO_DATE THEN
            L_FROM_DATE := L_TB_CALC(L_INDEX).FROM_DATE;

          ELSE
            L_FROM_DATE := L_TB_CALC(L_INDEX).TO_DATE + 1;
          END IF;

        END IF;
        L_INDEX := L_TB_CALC.NEXT(L_INDEX);
      END LOOP;
      DBG(' g_penalty_redemption=' || G_PENALTY_REDEMPTION);

      DBG(' g_total_interest=' || G_TOTAL_INTEREST);
      DBG(' g_total_tax=' || G_TOTAL_TAX);

      DBG('l_red_amt_1~l_red_amt_2~l_red_amt_3~l_red_amt_4' || L_RED_AMT_1 || '~' ||
          L_REM_AMT_2 || '~' || L_RED_AMT_3 || '~' || L_REM_AMT_4);
      DBG('l_acc_pr.next_liq_dt ' || L_ACC_PR.NEXT_LIQ_DT);
      DBG('global.application_date ' || GLOBAL.APPLICATION_DATE);
      DBG('l_rec_ictm_Acc.move_int_to_unclaimed ' ||
          L_REC_ICTM_ACC.MOVE_INT_TO_UNCLAIMED);

      IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') THEN
        L_FUNCTION_ID := CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID');
      ELSE
        L_FUNCTION_ID := 'X';
      END IF;

      IF L_FUNCTION_ID = 'STDCUSTD'

       THEN
        BEGIN
          SELECT *
            INTO L_ACC_PR
            FROM ICTB_ACC_PR
           WHERE ACC = P_ICDREDMN.AC_NO
             AND BRN = P_ICDREDMN.BRN_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('exception in select from acc_pr ' || SQLERRM);
        END;
        IF L_ACC_PR.NEXT_LIQ_DT < GLOBAL.APPLICATION_DATE AND
           NVL(L_REC_ICTM_ACC.MOVE_INT_TO_UNCLAIMED, 'N') = 'N' THEN

          BEGIN
            SELECT TD_AMOUNT + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
              INTO L_FINAL_AMT
              FROM ICTM_TD_DETAILS
             WHERE ACC = P_ICDREDMN.AC_NO
               AND BRN = P_ICDREDMN.BRN_CODE;

          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed in ICTM_TD_DEATILS Query');
          END;

          L_FROM_DATE := L_REC_ICTM_ACC.INT_START_DATE;
          L_REM_AMT_2 := 0;
          L_REM_AMT_4 := 0;
          L_MAT_AMT   := L_FINAL_AMT;

        END IF;
      END IF;

      IF L_FINAL_AMT > 0 THEN
        DBG('l_rec_ictm_Acc.acc' || L_REC_ICTM_ACC.ACC ||
            ' : l_rec_ictm_acc.book_acc :' || L_REC_ICTM_ACC.BOOK_ACC);

        PR_GET_ISTOPUP(L_TOPUP_FLAG);
        DBG('l_topup_flag' || L_TOPUP_FLAG);
        IF L_TOPUP_FLAG = 'Y' THEN
          STPKS_TD_REDEMPTION.PKG_PENALTY_APPLY := 0;
          L_TOPUP_RATES                         := TRUE;
        END IF;

        DBG('calling fn_comp_int_matdt : ' || L_FINAL_AMT);
        DBG('l_rem_amt_2 :' || L_REM_AMT_2 || 'l_rem_amt_4 :' ||
            L_REM_AMT_4);
        DBG('l_from_date=' || L_FROM_DATE || 'to date: ' ||
            L_REC_ICTM_ACC.MATURITY_DATE);

        DBG('p_icdredmn.next_mat_date-->' || P_ICDREDMN.NEXT_MAT_DATE);
        IF P_ICDREDMN.ACTION_FLAG = 'T' THEN
          L_DATE := P_ICDREDMN.NEXT_MAT_DATE;
        ELSE
          L_DATE := L_REC_ICTM_ACC.MATURITY_DATE;
        END IF;

        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_FN_CALL_ID      := 2;

          L_TB_CLUSTER_DATA('l_from_date') := L_FROM_DATE;
          L_TB_CLUSTER_DATA('l_date') := L_DATE;
          L_TB_CLUSTER_DATA('int_start_date') := L_REC_ICTM_ACC.INT_START_DATE;

          IF NOT
              STPKS_STDTDTOP_UTILS_CLUSTER.FN_MATAMT_COMP(P_SOURCE,
                                                          P_ACTION_CODE,
                                                          P_ICDREDMN,
                                                          P_TB_RED_CALC_BRKUP,
                                                          L_FN_CALL_ID,
                                                          L_TB_CLUSTER_DATA,
                                                          P_ERROR_CODE,
                                                          P_ERROR_PARAMS) THEN

            DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.fn_matamt_comp package' ||
                SQLERRM);
            RETURN FALSE;
          END IF;

          IF L_TB_CLUSTER_DATA.EXISTS('l_date') THEN
            L_DATE := L_TB_CLUSTER_DATA('l_date');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('l_from_date') THEN
            L_FROM_DATE := L_TB_CLUSTER_DATA('l_from_date');
          END IF;

        END IF;

        IF NOT FN_COMP_INT_MATDT(P_ICDREDMN.AC_NO,
                                 P_ICDREDMN.BRN_CODE,
                                 P_ICDREDMN.REDEM_REF_NO,
                                 L_FINAL_AMT,
                                 L_FROM_DATE,

                                 L_DATE,
                                 L_REM_AMT_2,
                                 L_REM_AMT_4,
                                 L_TB_REDM_CALC_BRKUP,
                                 L_MAT_AMT,
                                 P_ERROR_CODE,
                                 P_ERROR_PARAMS) THEN

          DBG('Failed in fn_comp_int_matdt');
        END IF;

        DBG('Already accrued amount but not liquidated so far to be added in projected interest   till mat date and mat amt');
        DBG('l_mat_amt-->' || L_MAT_AMT);
        DBG('g_total_interest-->' || G_TOTAL_INTEREST);
        L_MAT_AMT        := L_MAT_AMT + NVL(G_ADJ_INT_TILL_DATE, 0);
        G_TOTAL_INTEREST := G_TOTAL_INTEREST + NVL(G_ADJ_INT_TILL_DATE, 0) +
                            NVL(L_ADJ_INT, 0);
        DBG('l_mat_amt final-->' || L_MAT_AMT);
        DBG('g_total_interest final-->' || G_TOTAL_INTEREST);

        L_ACTION      := '#';
        L_FUNCTION_ID := '#';
        IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('FUNCTIONID') THEN
          L_FUNCTION_ID := NVL(CSPKS_REQ_GLOBAL.G_HEADER('FUNCTIONID'), '#');
        END IF;

        IF CSPKS_REQ_GLOBAL.G_HEADER.EXISTS('ACTION') THEN
          L_ACTION := NVL(CSPKS_REQ_GLOBAL.G_HEADER('ACTION'), '#');
        END IF;

        IF ((L_FUNCTION_ID = 'STDTDSIM' AND L_ACTION = 'COMPUTE')

           OR STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y')

           AND L_REC_ICTM_ACC.ACC <> L_REC_ICTM_ACC.BOOK_ACC THEN

          L_MAT_AMT := L_FINAL_AMT;
        END IF;

      END IF;

      BEGIN
        SELECT ACY_WITHDRAWABLE_BAL

          INTO L_ACY_WITHDRAWABLE_BAL
          FROM STTMS_ACCOUNT_BALANCE
         WHERE CUST_AC_NO = P_ICDREDMN.AC_NO
           AND CUST_AC_BRN = P_ICDREDMN.BRN_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in STTMS_Account_Balance Query');
      END;
      DBG('l_acy_withdrawable_bal--->' || L_ACY_WITHDRAWABLE_BAL);

      IF L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
         L_PAYOUT_COUNT = 0 THEN
        BEGIN
          SELECT TD_AMOUNT + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
            INTO P_ICDREDMN.PRINCIPAL_AMOUNT
            FROM ICTM_TD_DETAILS
           WHERE ACC = P_ICDREDMN.AC_NO
             AND BRN = P_ICDREDMN.BRN_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed in ICTM_TD_DEATILS Query');
        END;
      ELSE

        P_ICDREDMN.PRINCIPAL_AMOUNT := L_ACY_WITHDRAWABLE_BAL;

      END IF;

      DBG('p_icdredmn.PRINCIPAL_AMOUNT=' || P_ICDREDMN.PRINCIPAL_AMOUNT);
      DBG('p_icdredmn.redemption_mode~p_icdredmn.waive_interest~p_icdredmn.wave_penalty =' ||
          P_ICDREDMN.REDEMPTION_MODE || '~' || P_ICDREDMN.WAIVE_INTEREST || '~' ||
          P_ICDREDMN.WAVE_PENALTY);
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN

        IF NVL(P_ICDREDMN.WAIVE_INTEREST, 'N') = 'Y' AND
           NVL(P_ICDREDMN.WAVE_PENALTY, 'N') = 'Y' THEN

          IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(P_ICDREDMN.BRN_CODE,
                                                      P_ICDREDMN.AC_NO,
                                                      'N',
                                                      L_BALREC) THEN
            DEBUG.PR_DEBUG('AC',
                           'Failed in Get_Sttm_Account_Balance .. : ' ||
                           SQLERRM);
          END IF;
          P_ICDREDMN.MATURITY_AMOUNT := L_BALREC.ACY_CURR_ACC_BAL;

        ELSE

          IF L_REC_ICTM_ACC.MATURITY_DATE <= GLOBAL.APPLICATION_DATE THEN
            P_ICDREDMN.MATURITY_AMOUNT := L_REC_ICTM_ACC.MATURITY_AMOUNT;
            P_ICDREDMN.INTEREST_RATE   := L_REC_ICTM_ACC.INTEREST_RATE;
          ELSE
            DBG(' l_rec_ictm_acc.acc~l_rec_ictm_acc.book_acc~l_payout_count =' ||
                L_REC_ICTM_ACC.ACC || '~' || L_REC_ICTM_ACC.BOOK_ACC || '~' ||
                L_PAYOUT_COUNT);
            IF L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC AND
               L_PAYOUT_COUNT = 0 THEN
              IF P_ICDREDMN.REDEM_INT_PAYOUT IN ('P', 'I') THEN

                P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.PRINCIPAL_AMOUNT +
                                             NVL(L_RED_AMT_1, 0) +

                                             NVL(G_CURR_REDEM_INT, 0) -
                                             NVL(G_CURR_REDEM_TAX, 0) -
                                             NVL(G_CURR_REDEM_PENALTY, 0);

              ELSE

                P_ICDREDMN.REDEMPTION_AMT := NVL(L_ACY_WITHDRAWABLE_BAL, 0);
              END IF;
            ELSE

              IF P_ICDREDMN.REDEM_INT_PAYOUT = 'P' THEN
                P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.PRINCIPAL_AMOUNT +
                                             NVL(G_CURR_REDEM_INT, 0) -
                                             NVL(G_CURR_REDEM_TAX, 0) -
                                             NVL(G_CURR_REDEM_PENALTY, 0);
              ELSE

                P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.PRINCIPAL_AMOUNT;
              END IF;
            END IF;
            P_ICDREDMN.MATURITY_AMOUNT := P_ICDREDMN.REDEMPTION_AMT;
          END IF;
        END IF;
        DBG('p_icdredmn.maturity_amount=' || P_ICDREDMN.MATURITY_AMOUNT);

      ELSE

        P_ICDREDMN.MATURITY_AMOUNT := L_MAT_AMT;
      END IF;

      DBG('l_rec_ictm_acc.acc-->' || L_REC_ICTM_ACC.ACC);
      DBG('l_rec_ictm_acc.book_acc-->' || L_REC_ICTM_ACC.BOOK_ACC);
      DBG('l_payout_count-->' || L_PAYOUT_COUNT);
      DBG('l_tb_calc count-->' || L_TB_CALC.COUNT);
      IF (L_REC_ICTM_ACC.ACC = L_REC_ICTM_ACC.BOOK_ACC)

         OR (L_REC_ICTM_ACC.ACC <> L_REC_ICTM_ACC.BOOK_ACC)

       THEN
        DBG('Assigning l_db_calc to g_int_rec_calc');
        STPKS_STDTPSIM_KERNEL.G_INT_REC_CALC := L_TB_CALC;
      END IF;

      DBG(' l_broken_int is :' || L_BROKEN_INT);
      P_ICDREDMN.MATURITY_AMOUNT := P_ICDREDMN.MATURITY_AMOUNT +
                                    NVL(L_BROKEN_INT, 0);
      DBG(' p_icdredmn.maturity_amount final is :' ||
          P_ICDREDMN.MATURITY_AMOUNT);
      IF P_ICDREDMN.REDEMPTION_MODE = 'N' THEN
        P_ICDREDMN.REDEMPTION_AMT := P_ICDREDMN.REDEMPTION_AMT +
                                     NVL(L_BROKEN_INT, 0);
        DBG(' p_icdredmn.redemption_amt final is :' ||
            P_ICDREDMN.REDEMPTION_AMT);
      END IF;

      P_ICDREDMN.INTEREST_RATE := STPKS_STDTDTOP_UTILS.FN_PROJ_INTRATE('STDCUSTD',
                                                                       P_ICDREDMN.BRN_CODE,
                                                                       P_ICDREDMN.AC_NO,
                                                                       L_PROD.PROD,

                                                                       GLOBAL.APPLICATION_DATE);

      DBG('Interest Rate-->' || P_ICDREDMN.INTEREST_RATE);

      DBG(' p_icdredmn.redemption_amt =' || P_ICDREDMN.REDEMPTION_AMT);
      ROLLBACK TO SAV_MAT1;
      P_TB_RED_CALC_BRKUP := L_TB_REDM_CALC_BRKUP;

      GLOBAL.PR_RESET_SKIP_KERNEL;
      DBG('cspks_req_global.g_release_type: ' ||
          CSPKS_REQ_GLOBAL.G_RELEASE_TYPE);
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA('l_red_amt_3') := L_RED_AMT_3;
        L_TB_CLUSTER_DATA('l_rem_amt_4') := L_REM_AMT_4;
        IF NOT
            STPKS_STDTDTOP_UTILS_CLUSTER.FN_MATAMT_COMP(P_SOURCE,
                                                        P_ACTION_CODE,
                                                        P_ICDREDMN,
                                                        P_TB_RED_CALC_BRKUP,
                                                        L_FN_CALL_ID,
                                                        L_TB_CLUSTER_DATA,
                                                        P_ERROR_CODE,
                                                        P_ERROR_PARAMS) THEN

          DBG('Failed while calling stpks_stdtdtop_utils_CLUSTER.FN_TOPUP_TD package' ||
              SQLERRM);
          RETURN FALSE;
        END IF;
      END IF;

    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;

    DBG('End of fn_matamt_comp');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_matamt_comp' || SQLERRM ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      RETURN FALSE;
  END FN_MATAMT_COMP;

  FUNCTION FN_ACCOUNTING(P_BRN              VARCHAR2,
                         P_ACC              VARCHAR2,
                         P_CCY              VARCHAR2,
                         P_TB_TOPUP_SETTLED TY_TB_TXN_DET,
                         P_MEMO_REC         STPKS_TD_REDEMPTION.TY_MEMO_REC,
                         P_ERROR_CODE       OUT VARCHAR2,
                         P_ERR_PARAM        OUT VARCHAR2) RETURN BOOLEAN IS
    L_SERIAL_NO         VARCHAR2(15);
    L_TXN_REF_NO        VARCHAR2(16);
    L_SEQ               VARCHAR2(4) := 'ZIRD';
    L_REC_ICTM_ACC      ICTM_ACC%ROWTYPE;
    L_AMT_LIQD_TILLDATE DBMS_SQL.NUMBER_TABLE;
    L_TAX_LIQD_TILLDATE DBMS_SQL.NUMBER_TABLE;
    L_PROD              ICTM_ACC_PR%ROWTYPE;

    L_FROM_DATE    DATE;
    L_LIQ_ADJ_DATE DATE;
    L_OFFSET_ACC   ICTM_TDREDMPAYOUT_DETAILS.OFFSET_ACC%TYPE;
    L_INT_ACC      VARCHAR2(20);

    L_INDEX      PLS_INTEGER;
    L_HASH_INDEX PLS_INTEGER;
    L_TYPE       VARCHAR2(1);
  BEGIN
    IF P_MEMO_REC.COUNT > 0 THEN
      L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);
      L_PROD         := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);

      L_HASH_INDEX := FN_HASH_DATE(G_ADJ_START_DATE);
      IF P_TB_TOPUP_SETTLED.EXISTS(L_HASH_INDEX) THEN
        L_INDEX := L_HASH_INDEX;
      ELSE
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_HASH_INDEX);
      END IF;
      WHILE L_INDEX IS NOT NULL LOOP
        IF P_TB_TOPUP_SETTLED(L_INDEX).G_EVENT_DETAIL_REC.LIQD_AMT > 0 THEN
          L_LIQ_ADJ_DATE := P_TB_TOPUP_SETTLED(L_INDEX)
                            .G_EVENT_DETAIL_REC.EVENT_DATE;
          EXIT;
        END IF;
        L_INDEX := P_TB_TOPUP_SETTLED.PRIOR(L_INDEX);
      END LOOP;

      IF L_LIQ_ADJ_DATE IS NULL THEN

        L_FROM_DATE := L_REC_ICTM_ACC.INT_START_DATE;

      ELSE
        L_FROM_DATE := L_LIQ_ADJ_DATE;
      END IF;
      DBG('l_from_date -->' || L_FROM_DATE);

      IF NOT FN_FIND_LIQD_AMT(P_BRN,
                              P_ACC,
                              L_PROD.PROD,
                              L_FROM_DATE,
                              L_AMT_LIQD_TILLDATE,
                              L_TAX_LIQD_TILLDATE,
                              P_ERROR_CODE) THEN

        DBG('failed in liqd amount and tax calculation -->' ||
            P_ERROR_CODE);
        RETURN FALSE;
      END IF;

      IF NOT TRPKSS.FN_GET_PROCESS_REFNO(P_BRN,
                                         L_SEQ,
                                         GLOBAL.APPLICATION_DATE,
                                         L_SERIAL_NO,
                                         L_TXN_REF_NO,
                                         P_ERROR_CODE) THEN
        DBG('trpkss.fn_get_process_refno failed ' || P_ERROR_CODE);
        RETURN FALSE;
      END IF;

      DBG('l_amt_liqd_tilldate=' || L_AMT_LIQD_TILLDATE.COUNT);
      STPKS_TD_REDEMPTION.PR_PRINT_INT(L_AMT_LIQD_TILLDATE);
      DBG('l_tax_liqd_tilldate=' || L_TAX_LIQD_TILLDATE.COUNT);
      STPKS_TD_REDEMPTION.PR_PRINT_INT(L_TAX_LIQD_TILLDATE);

      STPKS_TD_REDEMPTION.PKG_TAX_LIQD_TILLDATE := L_TAX_LIQD_TILLDATE;

      ICPKS_FCJ_ICDREDMN.PR_GET_REDM_INT_PARAMS(L_TYPE, L_OFFSET_ACC);

      DBG('l_offset_acc' || L_OFFSET_ACC);
      IF L_OFFSET_ACC IS NOT NULL THEN
        L_INT_ACC := L_OFFSET_ACC;
      ELSE
        L_INT_ACC := L_REC_ICTM_ACC.BOOK_ACC;
      END IF;

      DBG('l_Int_acc' || L_INT_ACC);

      IF NOT STPKS_TD_REDEMPTION.FN_ACLOOKUP(L_TXN_REF_NO,
                                             P_BRN,
                                             L_PROD.PROD,
                                             P_CCY,
                                             P_ACC,

                                             L_INT_ACC,
                                             L_AMT_LIQD_TILLDATE,
                                             P_MEMO_REC,
                                             P_ERROR_CODE,
                                             P_ERR_PARAM) THEN
        DBG('Failed in Fn_aclookup:' || P_ERROR_CODE);

        RETURN FALSE;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_Accounting:' || SQLERRM);
      RETURN FALSE;
  END FN_ACCOUNTING;

  FUNCTION FN_REDEM_TD(P_BRN          IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                       P_ACC          IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                       P_ERROR_CODE   IN OUT VARCHAR2,
                       P_ERROR_PARAMS IN OUT VARCHAR2)

   RETURN BOOLEAN IS
    L_REC_ICTM_ACC     ICTM_ACC%ROWTYPE;
    L_PROD             ICTM_ACC_PR%ROWTYPE;
    L_CCY              STTM_CUST_ACCOUNT.CCY%TYPE;
    L_ACCOUNT_CLASS    STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_AVG_BAL          NUMBER;
    L_TB_CALC          STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_TB_CONSOL        STPKS_STDTDTOP_UTILS.TY_TB_REC_CALC;
    L_ADJ_START_DATE   DATE;
    L_RED_FLAG         VARCHAR2(1);
    L_REDEM_AMOUNT     NUMBER := 0;
    L_INT_RATE         NUMBER := 0;
    L_MAT_AMT          NUMBER := 0;
    P_MEMO_REC1        STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC2        STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC3        STPKS_TD_REDEMPTION.TY_MEMO_REC;
    P_MEMO_REC4        STPKS_TD_REDEMPTION.TY_MEMO_REC;
    L_REDEM_AMT_ACCR   DBMS_SQL.NUMBER_TABLE;
    L_TAX_ON_REDEM_AMT DBMS_SQL.NUMBER_TABLE;

    L_PENALTY_ON_REDEM_AMT DBMS_SQL.NUMBER_TABLE;
    L_IDX                  PLS_INTEGER;

    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_ACC_REC       STTM_CUST_ACCOUNT%ROWTYPE;

    L_PREV_RED BOOLEAN;

    L_TB_TOPUP_MODIFIED TY_TB_TXN_DET;
    L_TB_TOPUP_SETTLED  TY_TB_TXN_DET;

    L_PAYOUT_COUNT NUMBER;

  --clever savings sampath starts
    l_serial_no  VARCHAR2(16);
    l_trn_ref_no actb_daily_log.trn_ref_no%type;
    L_REVERSE_EXTRA_ACCRUALS ICTB_ENTRIES.ACCRUED_AMT%TYPE;
    --clever savings sampath ends

  --Pro Savings Sampath Starts
    L_CUSTOMER_NO STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    --Pro Savings Sampath Ends

  BEGIN

    DBG('Entered FN_REDEM_TD for account ' || P_ACC);
    G_TOPUP_ADHOC_TD_REDMN := FALSE;
    ICPKSS_MAINT.PR_GET_FULL_REDEM(L_RED_FLAG);
    IF NVL(L_RED_FLAG, '*') = 'Y' THEN
      STPKS_TD_REDEMPTION.PKG_FROM_BROKEN_TD := TRUE;

      STPKS_TD_REDEMPTION.PKG_IS_BROKEN_TD := TRUE;
      L_REDEM_AMOUNT                       := 0;
    ELSE
      ICPKSS_MAINT.PR_GET_REDEM_AMT(L_REDEM_AMOUNT);
    END IF;
    L_PROD         := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);
    L_REC_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC, P_BRN);

    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, L_ACC_REC) THEN
      DBG('Could not get account');
    END IF;
    L_CCY           := L_ACC_REC.CCY;
    L_ACCOUNT_CLASS := L_ACC_REC.ACCOUNT_CLASS;

    CVPKS_UTILS.GET_ACCOUNT_CLASS(L_ACCOUNT_CLASS,
                                  L_ACC_CLASS_REC,
                                  P_ERROR_CODE);

    IF NOT FN_UPD_TOPUP_SETTLED(P_ACC,
                                P_BRN,
                                L_REDEM_AMOUNT,
                                L_TB_TOPUP_MODIFIED,
                                L_TB_TOPUP_SETTLED,
                                P_ERROR_CODE,
                                P_ERROR_PARAMS) THEN
      DEBUG.PR_DEBUG('IC',
                     'fAILED IN  OF STUB stpks_stdtdtop_utils.fn_upd_topup_settled');
    END IF;

    IF NOT FN_BUILD_REC_CALC(P_ACC,
                             P_BRN,
                             L_TB_TOPUP_MODIFIED,
                             L_TB_TOPUP_SETTLED,
                             L_TB_CALC,
                             L_ADJ_START_DATE,
                             P_ERROR_CODE,
                             P_ERROR_PARAMS) THEN
      DBG('Failed in fn_build_rec_calc ');
    END IF;
    DBG('Done with building the calc tables....about to process now..');

    DBG('l_tb_calc.count : ' || L_TB_CALC.COUNT || 'l_tb_consol.count : ' ||
        L_TB_CONSOL.COUNT);
    IF NOT FN_COMPUTE_INT(P_ACC,
                          P_BRN,
                          L_CCY,
                          L_ADJ_START_DATE,
                          L_TB_TOPUP_SETTLED,
                          L_TB_CALC,
                          P_MEMO_REC1,
                          P_MEMO_REC2,
                          P_MEMO_REC3,
                          P_MEMO_REC4,
                          L_REDEM_AMT_ACCR,
                          L_TAX_ON_REDEM_AMT,
                          L_PENALTY_ON_REDEM_AMT,
                          P_ERROR_CODE,
                          P_ERROR_PARAMS) THEN

      DBG('Failed in computing the interest ');
    END IF;

    DBG('printing the values in plsql table');
    PR_PRINT_TB_CALC(L_TB_CALC);
    DBG('printing the values in consolidated plsql table');
    PR_PRINT_TB_CALC(L_TB_CONSOL);
    STPKS_TD_REDEMPTION.PKG_REDEM_AMT_ACCR   := L_REDEM_AMT_ACCR;
    STPKS_TD_REDEMPTION.PKG_TAX_ON_REDEM_AMT := L_TAX_ON_REDEM_AMT;

    IF P_MEMO_REC2.COUNT > 0 THEN

      L_IDX := P_MEMO_REC2.FIRST;
      WHILE L_IDX IS NOT NULL LOOP
        IF P_MEMO_REC2(L_IDX)
         .DRCR_IND = 'D' AND P_MEMO_REC2(L_IDX).IS_TAX = 'N' THEN

          IF L_PENALTY_ON_REDEM_AMT.EXISTS(L_IDX) THEN
            P_MEMO_REC2(L_IDX).AMT := L_PENALTY_ON_REDEM_AMT(L_IDX);
            DBG('Neg printing Amount' || P_MEMO_REC2(L_IDX).AMT);

          END IF;

          EXIT;
        END IF;
        L_IDX := P_MEMO_REC2.NEXT(L_IDX);
      END LOOP;

      STPKS_TD_REDEMPTION.PKG_J                  := 1;
      STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := TRUE;
      IF NOT FN_ACCOUNTING(P_BRN,
                           P_ACC,
                           L_CCY,
                           L_TB_TOPUP_SETTLED,
                           P_MEMO_REC2,
                           P_ERROR_CODE,
                           P_ERROR_PARAMS) THEN
        DBG('Failed in fn_Accounting');
        RETURN FALSE;
      END IF;
    END IF;

    IF (P_MEMO_REC1.COUNT > 0 AND L_RED_FLAG = 'Y') THEN
      DBG('Full redemption');
      STPKS_TD_REDEMPTION.PKG_J                  := 1;
      STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;
      IF NOT FN_ACCOUNTING(P_BRN,
                           P_ACC,
                           L_CCY,
                           L_TB_TOPUP_SETTLED,
                           P_MEMO_REC1,
                           P_ERROR_CODE,
                           P_ERROR_PARAMS) THEN
        DBG('Failed in fn_Accounting');
        RETURN FALSE;
      END IF;
    END IF;

    IF NVL(ICPKS_FCJ_ICDREDMN.G_TENOR_CHANGE, 'N') = 'Y' THEN
      DBG('tenor change');
      RETURN TRUE;
    END IF;

    IF P_MEMO_REC3.COUNT > 0 THEN
      STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;
      STPKS_TD_REDEMPTION.PKG_J                  := 2;

      IF P_MEMO_REC2.COUNT = 0 AND P_MEMO_REC1.COUNT = 0 THEN
        G_TOPUP_ADHOC_TD_REDMN := TRUE;
      END IF;

      IF NOT FN_ACCOUNTING(P_BRN,
                           P_ACC,
                           L_CCY,
                           L_TB_TOPUP_SETTLED,
                           P_MEMO_REC3,
                           P_ERROR_CODE,
                           P_ERROR_PARAMS) THEN
        DBG('Failed in fn_Accounting');
        RETURN FALSE;
      END IF;
    END IF;

    IF STPKS_TD_REDEMPTION.PKG_FROM_BROKEN_TD THEN
      BEGIN
        UPDATE ICTB_ACC_PR A
           SET NEXT_EVENT_DT = GLOBAL.APPLICATION_DATE
         WHERE BRN = P_BRN
           AND ACC = P_ACC;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WO Exception in updating ictb_acc_pr ' || SQLERRM);
          RETURN FALSE;
      END;
      SELECT NVL(TD_AMOUNT, 0) + NVL(TOPUP_AMT, 0) - NVL(REDEM_AMT, 0)
        INTO L_AVG_BAL
        FROM ICTMS_TD_DETAILS
       WHERE BRN = P_BRN
         AND ACC = P_ACC;

      STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT      := L_AVG_BAL;
      STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT_INIT := L_AVG_BAL;

      L_PREV_RED                                 := STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT;
      STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := FALSE;

      IF NOT
          ICPKS_UTIL.FN_GET_RATECHART_TENOR(L_RED_FLAG,
                                            L_ACC_CLASS_REC,
                                            P_BRN,
                                            P_ACC,
                                            L_REC_ICTM_ACC.INT_START_DATE,
                                            GLOBAL.APPLICATION_DATE,
                                            STPKS_TD_REDEMPTION.G_TENOR) THEN
        DBG('Failed to get the tenor');
      END IF;
      STPKS_TD_REDEMPTION.PKG_PROCESSING_REM_AMT := L_PREV_RED;
      IF STPKS_TD_REDEMPTION.G_TENOR = 0 THEN
        STPKS_TD_REDEMPTION.G_TENOR := 1;
      END IF;
      DBG('stpks_td_redemption.g_tenor=' || STPKS_TD_REDEMPTION.G_TENOR);

      DBG('g_broken_amount b4 fn_insert_td_details' ||
          STPKS_TD_REDEMPTION.G_BROKEN_AMOUNT);
      DBG('g_tenor b4 fn_insert_td_details' || STPKS_TD_REDEMPTION.G_TENOR);

      IF NOT STPKS_TD_REDEMPTION.FN_INSERT_TD_DETAILS(P_BRN,
                                                      P_ACC,
                                                      L_CCY,
                                                      L_ACCOUNT_CLASS) THEN
        DBG('Failed in stpks_td_redemption.fn_insert_td_details - FN_INSERT_TD_DETAILS error' ||
            SQLERRM);
        P_ERROR_CODE := 'IC-MU0005';
      END IF;

      DBG('Updating accrued_dr/cr to 0');

      UPDATE STTMS_CUST_ACCOUNT
         SET ACY_ACCRUED_DR_IC = 0, ACY_ACCRUED_CR_IC = 0
       WHERE CUST_AC_NO = P_ACC
         AND BRANCH_CODE = P_BRN;

     --clever savings sampath starts
         IF L_PROD.PROD IN ('SY01','GY01','RY01','SY02','GY02','RY02') AND STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN
         BEGIN
          SELECT NVL(A.ACCRUED_AMT, 0)
            INTO L_REVERSE_EXTRA_ACCRUALS
            FROM ICTB_ENTRIES A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.PROD = L_PROD.PROD
             AND A.FRM_NO = '2';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_REVERSE_EXTRA_ACCRUALS := 0;
        END;

        DBG('L_REVERSE_EXTRA_ACCRUALS='||L_REVERSE_EXTRA_ACCRUALS);

        END IF;
         --clever savings sampath ends

     --pro savings sampath starts
      IF L_PROD.PROD IN ('PS01', 'PS02', 'PS03', 'PS04',
        'PS05',
        'PS06',
        'PS07',
        'PS08',
        'PS09',
        'PS10',
        'PS11',
        'PS12',
        'PS13',
        'PS14') AND 
		STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        BEGIN
          SELECT NVL(A.ACCRUED_AMT, 0)
            INTO L_REVERSE_EXTRA_ACCRUALS
            FROM ICTB_ENTRIES A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.PROD = L_PROD.PROD
             AND A.FRM_NO = '2';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_REVERSE_EXTRA_ACCRUALS := 0;
        END;

        DBG('L_REVERSE_EXTRA_ACCRUALS=' || L_REVERSE_EXTRA_ACCRUALS);

      END IF;
      --pro savings sampath ends

      DBG('Setting all amounts to zero in ictb_entries');
      UPDATE ICTBS_ENTRIES
         SET AMT           = 0,
             ACCRUED_AMT   = 0,
             AMT_TO_ACCRUE = 0,
             CUR_RUN_ACCR  = 0,
             DAILY_AMT     = 0,
             ACQUIRED_AMT  = 0,
             ACQUIRED_ADJ  = 0
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD = L_PROD.PROD;

      DBG('Coming out of stpks_stdtdtop_utils.FN_REDEM_TD..');

      DELETE FROM ICTBS_ENTRIES_HISTORY_ACCR
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND ENT_DT >= GLOBAL.APPLICATION_DATE;

      DELETE FROM ICTBS_ENTRIES_HIST_ZEROACCR
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND ENT_DT >= GLOBAL.APPLICATION_DATE;

    ELSE

      IF NOT STPKS_TD_REDEMPTION.FN_INSERT_TD_DETAILS(P_BRN,
                                                      P_ACC,
                                                      L_CCY,
                                                      L_ACCOUNT_CLASS) THEN
        DBG('FAILED IN PR_BROKEN_PARTIAL_TD ' || SQLERRM);
        P_ERROR_CODE := 'IC-TDR011';
      END IF;

      UPDATE ICTMS_TD_DETAILS
         SET REDEM_AMT = NVL(REDEM_AMT, 0) + L_REDEM_AMOUNT
       WHERE BRN = P_BRN
         AND ACC = P_ACC;

      BEGIN
        SELECT INTEREST_RATE, MATURITY_AMOUNT
          INTO L_INT_RATE, L_MAT_AMT
          FROM ICTBS_TDREDEMPTION_MASTER
         WHERE ACC_NO = P_ACC
           AND BRANCH_CODE = P_BRN
           AND AUTH_STATUS = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          L_INT_RATE := 0;
          L_MAT_AMT  := 0;
      END;
      DBG('44444444');

      UPDATE ICTM_ACC
         SET INTEREST_RATE = L_INT_RATE, MATURITY_AMOUNT = L_MAT_AMT
       WHERE ACC = P_ACC
         AND BRN = P_BRN;

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS
         WHERE BRN = P_BRN
           AND ACC = P_ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Payout For Interest');
          L_PAYOUT_COUNT := 0;
      END;

      IF ((L_REC_ICTM_ACC.BOOK_ACC <> L_REC_ICTM_ACC.ACC) OR
         (L_PAYOUT_COUNT > 0)) THEN
        ICPKS_CALC.PR_CALC_PROJ_INT_TILL_MAT(P_BRN,
                                             P_ACC,
                                             GLOBAL.APPLICATION_DATE);
      ELSE
        BEGIN
          UPDATE ICTM_TD_DETAILS
             SET PROJECTED_INT_TILL_MAT = G_TOTAL_INTEREST
           WHERE BRN = P_BRN
             AND ACC = P_ACC;
        END;
      END IF;

    END IF;
    STPKS_STDTDTOP_UTILS.PR_SET_ISCUMAMT('N');

    IF (ICPKS_BOD.G_WAVE_PENALTY = 'N') THEN
      ICPKS_BOD.G_PENALTY := L_REDEM_AMOUNT;
    END IF;
    DBG('This is the penalty basis :' || L_REDEM_AMOUNT);

  --clever savings sampath starts
    DBG('P_ACC=' || P_ACC);
    DBG('L_PROD.PROD=' || L_PROD.PROD);
    DBG('L_CCY=' || L_CCY);

    IF L_PROD.PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      IF NOT trpkss.fn_get_product_refno(P_BRN,
                                         'REDM',
                                         global.application_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         P_ERROR_CODE) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);

      END IF;

      IF NOT
          STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS(l_trn_ref_no,
                                                                         'ILIQ',
                                                                         P_BRN,
                                                                         P_ACC,
                                                                         L_CCY,
                                                                         L_PROD.PROD,
                                                                         P_ERROR_CODE,
                                                                         P_ERROR_PARAMS) THEN

        DBG('FAILED IN REVERSING THE LIQUIDATION FOR THE EXTRA TOP UP');

        PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

        RETURN FALSE;

      ELSE

        DBG('SUCCESS IN REVERSING THE LIQUIDATION FOR THE EXTRA TOP UP');

        DBG('ABOUT TO START REVERSING EXTRA TOPUP TAX');
        IF NOT
            STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_TAX(l_trn_ref_no,
                                                                  'ILIQ',
                                                                  P_BRN,
                                                                  P_ACC,
                                                                  L_CCY,
                                                                  L_PROD.PROD,
                                                                  P_ERROR_CODE,
                                                                  P_ERROR_PARAMS) THEN

          DBG('FAILED IN REVERSING THE TAX BACK TO CASA');

          PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

          RETURN FALSE;

        ELSE

          DBG('SUCCESS IN REVERSING THE TAX BACK TO CASA');

          DBG('ABOUT TO START REVERSING EXTRA TOPUP ACCRUALS');
          IF NOT
              STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_ACCRUALS(l_trn_ref_no,
                                                                   'IACR',
                                                                   P_BRN,
                                                                   P_ACC,
                                                                   L_CCY,
                                                                   L_PROD.PROD,
                                                                   L_REVERSE_EXTRA_ACCRUALS,
                                                                   P_ERROR_CODE,
                                                                   P_ERROR_PARAMS) THEN

            DBG('FAILED IN REVERSING THE ACCRUALS FOR THE EXTRA TOP UP BACK TO GL');

            PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN REVERSING THE ACCRUALS FOR THE EXTRA TOP UP BACK TO GL');

            IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

            IF NOT
                ICPKS_ICDREDMN_CUSTOM.FN_POST_INSURANCE_FEE('FLEXUCBE',
                                                            'ICDREDMN',
                                                            'AUTH',
                                                            P_ACC,
                                                            P_BRN,
                                                            L_CCY,
                                                            P_ERROR_CODE,
                                                            P_ERROR_PARAMS) THEN

              DBG('FAILED IN CHARGING THE INSURANCE FEE');

              PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

              RETURN FALSE;

            ELSE

              DBG('SUCCESS IN CHARGING THE INSURANCE FEE');

              --Notification Starts
              BEGIN
                SELECT A.CUST_NO
                  INTO L_CUSTOMER_NO
                  FROM STTM_CUST_ACCOUNT A
                 WHERE A.CUST_AC_NO = P_ACC
                   AND A.BRANCH_CODE = P_BRN
                   AND A.CCY = L_CCY;
              EXCEPTION
                WHEN OTHERS THEN
                  L_CUSTOMER_NO := NULL;
              END;

              BEGIN

                IF L_CUSTOMER_NO IS NOT NULL THEN

                  IFPKS_CLEVER_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                         P_ACC,
                                                                         L_CCY,
                                                                         P_BRN,
                                                                         'CLOSE',
                                                                         NULL);

                  IF NOT
                      IFPKS_CLEVER_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(L_CUSTOMER_NO,p_acc,
                                                                      'CLOSE') THEN

                    DBG('FAILED IN PUSHING THE NOTIFICATION');

                    IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                           P_ACC,
                                                                           L_CCY,
                                                                           P_BRN,
                                                                           'CLOSE',
                                                                           'F');

                  ELSE

                    DBG('SUCCESS IN PUSHING THE NOTIFICATION');

                    IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                           P_ACC,
                                                                           L_CCY,
                                                                           P_BRN,
                                                                           'CLOSE',
                                                                           'S');

                  END IF;

                END IF;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;

              --Notification Ends

              RETURN TRUE;

            END IF;

            ELSE


            --Notification Starts for normal close means close on maturity
                BEGIN
                  SELECT A.CUST_NO
                    INTO L_CUSTOMER_NO
                    FROM STTM_CUST_ACCOUNT A
                   WHERE A.CUST_AC_NO = P_ACC
                     AND A.BRANCH_CODE = P_BRN
                     AND A.CCY = L_CCY;
                EXCEPTION
                  WHEN OTHERS THEN
                    L_CUSTOMER_NO := NULL;
                END;

                BEGIN

                  IF L_CUSTOMER_NO IS NOT NULL THEN

                    IFPKS_CLEVER_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                        P_ACC,
                                                                        L_CCY,
                                                                        P_BRN,
                                                                        'CLOSE',
                                                                        NULL);

                    IF NOT
                        IFPKS_CLEVER_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(L_CUSTOMER_NO,p_acc,
                                                                     'CLOSE') THEN

                      DBG('FAILED IN PUSHING THE NOTIFICATION');

                      IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'F');

                    ELSE

                      DBG('SUCCESS IN PUSHING THE NOTIFICATION');

                      IFPKS_CLEVER_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'S');

                    END IF;

                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;

                --Notification Ends for normal close means close on maturity

                 RETURN TRUE;

            END IF;

          END IF;

        END IF;

        RETURN TRUE;

      END IF;
    END IF;
    --clever savings sampath ends

  --Pro Savings Sampath Starts
    IF L_PROD.PROD IN ('PS01', 'PS02', 'PS03', 'PS04',
        'PS05',
        'PS06',
        'PS07',
        'PS08',
        'PS09',
        'PS10',
        'PS11',
        'PS12',
        'PS13',
        'PS14') --AND												   
    --P_ACC = '000116040'
     THEN

      IF NOT trpkss.fn_get_product_refno(P_BRN,
                                         'REDM',
                                         global.application_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         P_ERROR_CODE) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);

      END IF;

      IF NOT
          STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV(l_trn_ref_no,
                                                                                 --P_AMT_TAG,
                                                                                 --P_TAG_AMT,
                                                                                 'ILIQ',
                                                                                 --P_CR_GL,
                                                                                 --P_DR_GL,
                                                                                 P_BRN,
                                                                                 P_ACC,
                                                                                 L_CCY,
                                                                                 L_PROD.PROD,
                                                                                 P_ERROR_CODE,
                                                                                 P_ERROR_PARAMS) THEN

        DBG('FAILED IN REVERSING THE LIQUIDATION FOR THE EXTRA TOP UP FOR PRO-SAVINGS');

        PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

        RETURN FALSE;

      ELSE

        DBG('SUCCESS IN REVERSING THE LIQUIDATION FOR THE EXTRA TOP UP FOR PRO-SAVINGS');

        DBG('ABOUT TO START REVERSING EXTRA TOPUP TAX FOR PRO-SAVINGS');
        IF NOT
            STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV(l_trn_ref_no,
                                                                          --P_AMT_TAG,
                                                                          --P_TAG_AMT,
                                                                          'ILIQ',
                                                                          --P_CR_GL,
                                                                          --P_DR_GL,
                                                                          P_BRN,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          L_PROD.PROD,
                                                                          P_ERROR_CODE,
                                                                          P_ERROR_PARAMS) THEN

          DBG('FAILED IN REVERSING THE TAX BACK TO CASA FOR PRO-SAVINGS');

          PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

          RETURN FALSE;

        ELSE

          DBG('SUCCESS IN REVERSING THE TAX BACK TO CASA FOR PRO-SAVINGS');

          DBG('ABOUT TO START REVERSING EXTRA TOPUP ACCRUALS FOR PRO-SAVINGS');
          IF NOT
              STPKS_TD_REDEMPTION_CUSTOM.FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV(l_trn_ref_no,
                                                                           --P_AMT_TAG,
                                                                           --P_TAG_AMT,
                                                                           'IACR',
                                                                           --P_CR_GL,
                                                                           --P_DR_GL,
                                                                           P_BRN,
                                                                           P_ACC,
                                                                           L_CCY,
                                                                           L_PROD.PROD,
                                                                           L_REVERSE_EXTRA_ACCRUALS,
                                                                           P_ERROR_CODE,
                                                                           P_ERROR_PARAMS) THEN

            DBG('FAILED IN REVERSING THE ACCRUALS FOR THE EXTRA TOP UP BACK TO GL FOR PRO-SAVINGS');

            PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

            RETURN FALSE;

          ELSE

            DBG('SUCCESS IN REVERSING THE ACCRUALS FOR THE EXTRA TOP UP BACK TO GL FOR PRO-SAVINGS');

            IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

              IF NOT
                  ICPKS_ICDREDMN_CUSTOM.FN_POST_INSURANCE_FEE('FLEXUCBE',
                                                              'ICDREDMN',
                                                              'AUTH',
                                                              P_ACC,
                                                              P_BRN,
                                                              L_CCY,
                                                              P_ERROR_CODE,
                                                              P_ERROR_PARAMS) THEN

                DBG('FAILED IN CHARGING THE INSURANCE FEE FOR PRO-SAVINGS');

                PR_LOG_ERROR('FLEXCUBE', P_ERROR_CODE, P_ERROR_PARAMS);

                RETURN FALSE;

              ELSE

                DBG('SUCCESS IN CHARGING THE INSURANCE FEE FOR PRO-SAVINGS');



                --Notification Starts
                BEGIN
                  SELECT A.CUST_NO
                    INTO L_CUSTOMER_NO
                    FROM STTM_CUST_ACCOUNT A
                   WHERE A.CUST_AC_NO = P_ACC
                     AND A.BRANCH_CODE = P_BRN
                     AND A.CCY = L_CCY;
                EXCEPTION
                  WHEN OTHERS THEN
                    L_CUSTOMER_NO := NULL;
                END;

                BEGIN

                  IF L_CUSTOMER_NO IS NOT NULL THEN

                    IFPKS_PRO_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                        P_ACC,
                                                                        L_CCY,
                                                                        P_BRN,
                                                                        'CLOSE',
                                                                        NULL);

                    IF NOT
                        IFPKS_PRO_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(L_CUSTOMER_NO,
                                                                     'CLOSE') THEN

                      DBG('FAILED IN PUSHING THE NOTIFICATION');

                      IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'F');

                    ELSE

                      DBG('SUCCESS IN PUSHING THE NOTIFICATION');

                      IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'S');

                    END IF;

                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;

                --Notification Ends

                RETURN TRUE;

              END IF;


            ELSE

            --Notification Starts for normal close means close on maturity
                BEGIN
                  SELECT A.CUST_NO
                    INTO L_CUSTOMER_NO
                    FROM STTM_CUST_ACCOUNT A
                   WHERE A.CUST_AC_NO = P_ACC
                     AND A.BRANCH_CODE = P_BRN
                     AND A.CCY = L_CCY;
                EXCEPTION
                  WHEN OTHERS THEN
                    L_CUSTOMER_NO := NULL;
                END;

                BEGIN

                  IF L_CUSTOMER_NO IS NOT NULL THEN

                    IFPKS_PRO_SAVINGS_UTILS.PR_INSERT_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                        P_ACC,
                                                                        L_CCY,
                                                                        P_BRN,
                                                                        'CLOSE',
                                                                        NULL);

                    IF NOT
                        IFPKS_PRO_SAVINGS_UTILS.FN_PUSH_NOTIFICATION(L_CUSTOMER_NO,
                                                                     'CLOSE') THEN

                      DBG('FAILED IN PUSHING THE NOTIFICATION');

                      IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'F');

                    ELSE

                      DBG('SUCCESS IN PUSHING THE NOTIFICATION');

                      IFPKS_PRO_SAVINGS_UTILS.PR_UPDATE_PUSH_NOTIF_STATUS(L_CUSTOMER_NO,
                                                                          P_ACC,
                                                                          L_CCY,
                                                                          P_BRN,
                                                                          'CLOSE',
                                                                          'S');

                    END IF;

                  END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    NULL;
                END;

                --Notification Ends for normal close means close on maturity

                 RETURN TRUE;

            END IF;

          END IF;

        END IF;

        RETURN TRUE;

      END IF;
    END IF;
    --Pro Savings Sampath Ends

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_REDEM_TD ' || SQLERRM);
      RETURN FALSE;
  END FN_REDEM_TD;

  FUNCTION FN_MAINT_LOG(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_MULTI_TRIP_ID    IN VARCHAR2,
                        P_REQUEST_NO       IN VARCHAR2,
                        P_RECORD_MASTER    IN STTBS_RECORD_MASTER%ROWTYPE,
                        P_STDTDTOP         IN STPKS_STDTDTOP_MAIN.TY_STDTDTOP,
                        P_PREV_STDTDTOP    IN STPKS_STDTDTOP_MAIN.TY_STDTDTOP,
                        P_WRK_STDTDTOP     IN STPKS_STDTDTOP_MAIN.TY_STDTDTOP,
                        P_TANKING_STATUS   IN VARCHAR2,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_MAIN_FUNCTION    VARCHAR2(50) := P_FUNCTION_ID;
    L_AUTH_STAT        VARCHAR2(32767) := NULL;
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    L_KEY_ID           VARCHAR2(32767);
    L_MOD_NO           NUMBER := 1;
    L_BLK              VARCHAR2(32767) := NULL;
    L_FLD              VARCHAR2(32767) := NULL;
    L_DBT              VARCHAR2(32767) := NULL;
    L_DBC              VARCHAR2(32767) := NULL;
    L_REC_ACTION       VARCHAR2(32767) := 'M';
    L_DTL_KEY          VARCHAR2(32767) := NULL;
    L_PREV_COUNT       NUMBER := 0;
    L_WRK_COUNT        NUMBER := 0;
    L_COUNT            NUMBER := 0;
    L_LOG_COUNT        NUMBER := 0;
    L_FLD_COUNT        NUMBER := 0;
    L_MATCHED_REC      NUMBER := 0;
    L_REC_FOUND        BOOLEAN := FALSE;
    L_PREV_FOUND       BOOLEAN := FALSE;
    L_WRK_FOUND        BOOLEAN := FALSE;
    L_REC_MODIFIED     BOOLEAN := FALSE;
    L_RECORD_LOG       STTBS_RECORD_LOG%ROWTYPE;
    L_FIELD_LOG        STTBS_FIELD_LOG%ROWTYPE;
    L_TB_FIELD_LOG     CSPKS_REQ_GLOBAL.TY_TB_FLD_LOG;
    L_FUNC_TYPE        VARCHAR2(32767);

    PROCEDURE PR_LOG_CHANGE(P_DBC     IN VARCHAR2,
                            P_ACTION  IN VARCHAR2,
                            P_OLD_VAL IN VARCHAR2,
                            P_NEW_VAL IN VARCHAR2) IS
    BEGIN
      IF NVL(P_OLD_VAL, '@') <> NVL(P_NEW_VAL, '@') THEN
        L_FLD_COUNT             := L_FLD_COUNT + 1;
        L_LOG_COUNT             := NVL(L_TB_FIELD_LOG.COUNT, 0) + 1;
        L_FIELD_LOG.DETAIL_KEY  := L_DTL_KEY;
        L_FIELD_LOG.BLOCK_NAME  := L_BLK;
        L_FIELD_LOG.FIELD_NAME  := P_DBC;
        L_FIELD_LOG.TABLE_NAME  := L_DBT;
        L_FIELD_LOG.ITEM_NO     := L_FLD_COUNT;
        L_FIELD_LOG.RECORD_STAT := P_ACTION;
        IF LENGTH(P_OLD_VAL) > 2000 THEN
          L_FIELD_LOG.OLD_VALUE := SUBSTR(P_OLD_VAL, 1, 2000);
        ELSE
          L_FIELD_LOG.OLD_VALUE := P_OLD_VAL;
        END IF;
        IF LENGTH(P_NEW_VAL) > 2000 THEN
          L_FIELD_LOG.NEW_VALUE := SUBSTR(P_NEW_VAL, 1, 2000);
        ELSE
          L_FIELD_LOG.NEW_VALUE := P_NEW_VAL;
        END IF;
        L_TB_FIELD_LOG(L_LOG_COUNT) := L_FIELD_LOG;
      END IF;
    END PR_LOG_CHANGE;

  BEGIN
    DBG('In Fn_Maint_Log');
    L_KEY_ID := '~ICTB_TDTOPUP_DETAIL~' ||
                P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO || '~';
    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_NEW,
        CSPKS_REQ_GLOBAL.P_MODIFY,
        CSPKS_REQ_GLOBAL.P_CLOSE,
        CSPKS_REQ_GLOBAL.P_REOPEN,
        CSPKS_REQ_GLOBAL.P_AUTH,
        CSPKS_REQ_GLOBAL.P_DELETE,
        CSPKS_REQ_GLOBAL.P_VERSION_DELETE) THEN
      DBG('Maintenance Log is Required ..');
      IF L_KEY_ID IS NOT NULL THEN
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_AUTH,
            CSPKS_REQ_GLOBAL.P_DELETE,
            CSPKS_REQ_GLOBAL.P_VERSION_DELETE) THEN
          IF P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO IS NOT NULL THEN
            L_MOD_NO := P_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO;
          ELSE
            L_MOD_NO := P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO;
          END IF;
        ELSE
          L_MOD_NO := P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO;
        END IF;

        L_AUTH_STAT := NVL(P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.AUTH_STAT,
                           'U');
        IF NOT CSPKS_REQ_UTILS.FN_MAINT_LOG(P_SOURCE,
                                            P_SOURCE_OPERATION,
                                            P_FUNCTION_ID,
                                            P_ACTION_CODE,
                                            P_MULTI_TRIP_ID,
                                            P_REQUEST_NO,
                                            'ICTBS_TDTOPUP_DETAIL',
                                            L_KEY_ID,
                                            L_MOD_NO,
                                            L_AUTH_STAT,
                                            P_TANKING_STATUS,
                                            P_RECORD_MASTER,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
          DBG('Failed in   Cspks_Req_Utils.Fn_Maint_Log..');
          RETURN FALSE;
        END IF;
        IF CSPKS_REQ_UTILS.FN_FIELD_LOG_REQD(P_FUNCTION_ID, P_ACTION_CODE) THEN
          L_FIELD_LOG.KEY_ID      := L_KEY_ID;
          L_FIELD_LOG.MOD_NO      := L_MOD_NO;
          L_FIELD_LOG.FUNCTION_ID := P_FUNCTION_ID;

          L_DBT := 'ICTB_TDTOPUP_DETAIL';

          L_BLK          := 'ICTBS_TDTOPUP_DETAIL';
          L_REC_MODIFIED := FALSE;
          L_PREV_FOUND   := FALSE;
          L_WRK_FOUND    := FALSE;

          IF P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO IS NOT NULL THEN
            DBG('Record Has Been Sent..');
            L_PREV_FOUND := TRUE;
          END IF;
          IF P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO IS NOT NULL THEN
            DBG('Record Has Been Sent..');
            L_WRK_FOUND := TRUE;
          END IF;
          IF L_PREV_FOUND THEN
            L_DTL_KEY := '~ICTB_TDTOPUP_DETAIL~' ||
                         P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO || '~';
          ELSIF L_WRK_FOUND THEN
            L_DTL_KEY := '~ICTB_TDTOPUP_DETAIL~' ||
                         P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO || '~';
          END IF;
          IF L_WRK_FOUND OR L_PREV_FOUND THEN
            IF L_WRK_FOUND AND L_PREV_FOUND THEN
              L_REC_ACTION := 'M';
            ELSIF L_WRK_FOUND AND (NOT L_PREV_FOUND) THEN
              L_REC_ACTION := 'N';
            ELSIF (NOT L_WRK_FOUND) AND L_PREV_FOUND THEN
              L_REC_ACTION := 'D';
            END IF;
            PR_LOG_CHANGE('BRN',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.BRN);
            PR_LOG_CHANGE('ACC',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ACC);
            PR_LOG_CHANGE('CCY',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CCY);
            PR_LOG_CHANGE('TOPUP_REF_NO',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_REF_NO);
            PR_LOG_CHANGE('TOPUP_AMOUNT',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_AMOUNT);
            PR_LOG_CHANGE('TOPUP_VALUE_DATE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_VALUE_DATE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_VALUE_DATE);
            PR_LOG_CHANGE('MATAMT_BEFORE_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATAMT_BEFORE_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATAMT_BEFORE_TOPUP);
            PR_LOG_CHANGE('INTRATE_BEFORE_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.INTRATE_BEFORE_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.INTRATE_BEFORE_TOPUP);
            PR_LOG_CHANGE('NARRATIVE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.NARRATIVE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.NARRATIVE);
            PR_LOG_CHANGE('TOPUP_DATE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_DATE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TOPUP_DATE);
            PR_LOG_CHANGE('TD_OPEN_DATE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TD_OPEN_DATE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TD_OPEN_DATE);
            PR_LOG_CHANGE('TENOR_DD',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_DD,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_DD);
            PR_LOG_CHANGE('TENOR_MM',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_MM,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_MM);
            PR_LOG_CHANGE('TENOR_YY',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_YY,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TENOR_YY);
            PR_LOG_CHANGE('MATDATE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATDATE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATDATE);
            PR_LOG_CHANGE('TDAMT_BEFORE_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TDAMT_BEFORE_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TDAMT_BEFORE_TOPUP);
            PR_LOG_CHANGE('TDAMT_AFTER_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TDAMT_AFTER_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.TDAMT_AFTER_TOPUP);
            PR_LOG_CHANGE('MATAMT_AFTER_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATAMT_AFTER_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MATAMT_AFTER_TOPUP);
            PR_LOG_CHANGE('INTRATE_AFTER_TOPUP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.INTRATE_AFTER_TOPUP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.INTRATE_AFTER_TOPUP);
            PR_LOG_CHANGE('EXT_REFERENCE',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.EXT_REFERENCE,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.EXT_REFERENCE);
            PR_LOG_CHANGE('CUST_NO',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CUST_NO,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CUST_NO);
            PR_LOG_CHANGE('MAKER_ID',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MAKER_ID,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MAKER_ID);
            PR_LOG_CHANGE('MAKER_DT_STAMP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MAKER_DT_STAMP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MAKER_DT_STAMP);
            PR_LOG_CHANGE('CHECKER_ID',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CHECKER_ID,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CHECKER_ID);
            PR_LOG_CHANGE('CHECKER_DT_STAMP',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CHECKER_DT_STAMP,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.CHECKER_DT_STAMP);
            PR_LOG_CHANGE('MOD_NO',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.MOD_NO);
            PR_LOG_CHANGE('RECORD_STAT',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.RECORD_STAT,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.RECORD_STAT);
            PR_LOG_CHANGE('AUTH_STAT',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.AUTH_STAT,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.AUTH_STAT);
            PR_LOG_CHANGE('ONCE_AUTH',
                          L_REC_ACTION,
                          P_PREV_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ONCE_AUTH,
                          P_WRK_STDTDTOP.V_ICTBS_TDTOPUP_DETAIL.ONCE_AUTH);
          END IF;

          L_DBT        := 'ICTM_TDTOPUP_PAYIN';
          L_BLK        := 'ICTMS_TDTOPUP_PAYIN';
          L_WRK_COUNT  := P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT;
          L_PREV_COUNT := P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT;
          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              L_DTL_KEY      := '~ICTM_TDTOPUP_PAYIN~' || P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                               .TOPUP_REF_NO || '~' || P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX).BRN || '~' || P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX).ACC || '~' || P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                               .SEQNO || '~';
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_PREV_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                  IF (NVL(P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                          .SEQNO,
                          -1) = NVL(P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                     .SEQNO,
                                     -1)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND   := TRUE;
                    L_MATCHED_REC := L_INDEX1;
                    PR_LOG_CHANGE('MULTIMODE_PAYOPT',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .MULTIMODE_PAYOPT,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .MULTIMODE_PAYOPT);
                    PR_LOG_CHANGE('MULTIMODE_TDAMOUNT',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .MULTIMODE_TDAMOUNT,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .MULTIMODE_TDAMOUNT);
                    PR_LOG_CHANGE('MULTIMODE_OFFSET_BRN',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .MULTIMODE_OFFSET_BRN,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .MULTIMODE_OFFSET_BRN);
                    PR_LOG_CHANGE('MULTIMODE_TDOFFSET_ACC',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .MULTIMODE_TDOFFSET_ACC,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .MULTIMODE_TDOFFSET_ACC);
                    PR_LOG_CHANGE('MULTIMODE_PERCENTAGE',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .MULTIMODE_PERCENTAGE,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .MULTIMODE_PERCENTAGE);
                    PR_LOG_CHANGE('SEQNO',
                                  'M',
                                  P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                  .SEQNO,
                                  P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN (L_INDEX)
                                  .SEQNO);

                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('New Record Found..');
                PR_LOG_CHANGE('MULTIMODE_PAYOPT',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_PAYOPT);
                PR_LOG_CHANGE('MULTIMODE_TDAMOUNT',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_TDAMOUNT);
                PR_LOG_CHANGE('MULTIMODE_OFFSET_BRN',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_OFFSET_BRN);
                PR_LOG_CHANGE('MULTIMODE_TDOFFSET_ACC',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_TDOFFSET_ACC);
                PR_LOG_CHANGE('MULTIMODE_PERCENTAGE',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_PERCENTAGE);
                PR_LOG_CHANGE('SEQNO',
                              'N',
                              NULL,
                              P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .SEQNO);
              END IF;
            END LOOP;
          END IF;
          L_PREV_COUNT := P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT;
          L_WRK_COUNT  := P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN.COUNT;
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_PREV_COUNT LOOP
              L_REC_FOUND    := FALSE;
              L_REC_MODIFIED := FALSE;
              IF L_WRK_COUNT > 0 THEN
                FOR L_INDEX1 IN 1 .. L_WRK_COUNT LOOP
                  IF (NVL(P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                          .SEQNO,
                          -1) = NVL(P_WRK_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX1)
                                     .SEQNO,
                                     -1)) THEN
                    DBG('Record Found..');
                    L_REC_FOUND := TRUE;
                    EXIT;

                  END IF;
                END LOOP;
              END IF;
              IF NOT L_REC_FOUND THEN
                DBG('Record Deleted..');
                L_DTL_KEY := '~ICTM_TDTOPUP_PAYIN~' || P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                            .TOPUP_REF_NO || '~' || P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX).BRN || '~' || P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX).ACC || '~' || P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                            .SEQNO || '~';
                PR_LOG_CHANGE('MULTIMODE_PAYOPT',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_PAYOPT,
                              NULL);
                PR_LOG_CHANGE('MULTIMODE_TDAMOUNT',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_TDAMOUNT,
                              NULL);
                PR_LOG_CHANGE('MULTIMODE_OFFSET_BRN',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_OFFSET_BRN,
                              NULL);
                PR_LOG_CHANGE('MULTIMODE_TDOFFSET_ACC',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_TDOFFSET_ACC,
                              NULL);
                PR_LOG_CHANGE('MULTIMODE_PERCENTAGE',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .MULTIMODE_PERCENTAGE,
                              NULL);
                PR_LOG_CHANGE('SEQNO',
                              'D',
                              P_PREV_STDTDTOP.V_ICTMS_TDTOPUP_PAYIN(L_INDEX)
                              .SEQNO,
                              NULL);
              END IF;
            END LOOP;
          END IF;

          L_COUNT := L_TB_FIELD_LOG.COUNT;
          IF L_COUNT > 0 THEN
            DBG('Inserting Into Field Log..');
            BEGIN
              FORALL L_INDEX IN 1 .. L_COUNT
                INSERT INTO STTBS_FIELD_LOG
                VALUES L_TB_FIELD_LOG
                  (L_INDEX);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in Insert into Field Log..');
                DBG(SQLERRM);
                P_ERR_CODE   := 'ST-UPLD-001';
                P_ERR_PARAMS := '@STTBS_FIELD_LOG';
            END;
          END IF;

        END IF;
      END IF;
    END IF;

    DBG('Returning Success From Fn_Maint_Log..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Maint_Log ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MAINT_LOG;

  FUNCTION FN_RESTORE_EVENT_DET(P_BRN    IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_ACC    IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                P_CCY    VARCHAR2,
                                P_ACTION VARCHAR2) RETURN BOOLEAN IS

  BEGIN
    DBG('Start of fn_restore_event_Det');
    DELETE FROM TDTB_EVENT_DETAILS
     WHERE ACC = P_ACC
       AND BRN = P_BRN;

    INSERT INTO TDTB_EVENT_DETAILS
      (ACC,
       BRN,
       EVENT_DATE,
       CCY,
       TOPUP_AMT,
       TOPUP_AMT_SETTLED,
       LIQD_AMT,
       REDEM_AMT,
       BALANCE)
      SELECT ACC,
             BRN,
             EVENT_DATE,
             CCY,
             TOPUP_AMT,
             TOPUP_AMT_SETTLED,
             LIQD_AMT,
             REDEM_AMT,
             BALANCE
        FROM TDTB_EVENT_DET_HISTORY
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND VERSION_NO = (SELECT MAX(VERSION_NO)
                             FROM TDTB_EVENT_DET_HISTORY
                            WHERE ACC = P_ACC
                              AND BRN = P_BRN);

    DBG('Returning true of fn_restore_event_Det');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_restore_event_Det' || SQLERRM);
      RETURN FALSE;
  END FN_RESTORE_EVENT_DET;

  FUNCTION FN_TOPUP_SETTLED(P_BRN       IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                            P_ACC       IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                            P_CCY       VARCHAR2,
                            P_ACTION    VARCHAR2,
                            P_DATE      DATE,
                            P_AMOUNT    NUMBER,
                            P_ERR_CODE  IN OUT VARCHAR2,
                            P_ERR_PARAM IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_REC_EVENT_DETAILS TDTB_EVENT_DETAILS%ROWTYPE;

    L_CUST_ACC_REC  STTM_CUST_ACCOUNT%ROWTYPE;
    L_LIQ_INT       NUMBER;
    L_REC_ACC       ICTM_ACC%ROWTYPE;
    L_REDEM_REC     ICTB_TDREDEMPTION_MASTER%ROWTYPE;
    L_LAST_LIQ_DATE DATE;
    L_CURR_TD_AMT   NUMBER := 0;
    L_PAYOUT_COUNT  NUMBER := 0;
    L_TOTAL_TD_AMT  NUMBER := 0;
    L_ADJ_AMT       NUMBER := 0;
    L_PROD_REC      ICTMS_ACC_PR%ROWTYPE;
    L_PAY_MTHD      ICTM_PR_INT.PAYMENT_METHOD%TYPE;
    L_FLD           VARCHAR2(1000);
    L_TMP_CNT       NUMBER := 0;
    L_BROKEN_INT    NUMBER := 0;
    L_LIQ_TAX       NUMBER := 0;
    L_COUNT         INTEGER := 0;

    L_TB_TOPUP_SETTLED  TY_TB_TXN_DET;
    L_TB_TOPUP_MODIFIED TY_TB_TXN_DET;

    L_PR_INT ICTMS_PR_INT%ROWTYPE;
    L_BALREC STTM_ACCOUNT_BALANCE%ROWTYPE;
    PROCEDURE PR_MOVE_TO_HISTORY IS
      L_VERSION_NO NUMBER;
    BEGIN

      SELECT MAX(VERSION_NO)
        INTO L_VERSION_NO
        FROM TDTB_EVENT_DET_HISTORY
       WHERE ACC = P_ACC
         AND BRN = P_BRN;

      L_VERSION_NO := NVL(L_VERSION_NO, 0) + 1;

      INSERT INTO TDTB_EVENT_DET_HISTORY
        (ACC,
         BRN,
         EVENT_DATE,
         CCY,
         TOPUP_AMT,
         TOPUP_AMT_SETTLED,
         LIQD_AMT,
         REDEM_AMT,
         BALANCE,

         VERSION_NO)
        SELECT ACC,
               BRN,
               EVENT_DATE,
               CCY,
               TOPUP_AMT,
               TOPUP_AMT_SETTLED,
               LIQD_AMT,
               REDEM_AMT,
               BALANCE,

               L_VERSION_NO
          FROM TDTB_EVENT_DETAILS
         WHERE ACC = P_ACC
           AND BRN = P_BRN;
      IF P_ACTION NOT IN ('TENOR_CHG1') THEN
        DELETE FROM TDTB_EVENT_DETAILS
         WHERE ACC = P_ACC
           AND BRN = P_BRN;
      END IF;

    END PR_MOVE_TO_HISTORY;

  BEGIN
    DBG('start of fn_topup_settled action code ' || P_ACTION || '~' ||
        P_AMOUNT);

    L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(P_ACC, P_BRN);

    L_PR_INT := ICPKS_CACHE.FN_GET_PR_INT_FRC(L_PROD_REC.PROD);

    DBG('l_pay_mthd=' || L_PR_INT.PAYMENT_METHOD);
    IF NVL(L_PR_INT.PAYMENT_METHOD, 'B') != 'B'

     THEN

      DBG('Topup not allowed for payment types :' ||
          L_PR_INT.PAYMENT_METHOD || ' Returning true');
      RETURN TRUE;
    END IF;

    IF P_ACTION IN ('TENOR_CHG1') THEN

      PR_MOVE_TO_HISTORY;
      RETURN TRUE;
    ELSIF P_ACTION IN ('TENOR_CHG2') THEN

      IF NOT FN_RESTORE_EVENT_DET(P_BRN, P_ACC, P_CCY, P_ACTION) THEN
        DBG('Failed in restoring the tdtb_event_details after tenor change');
        RETURN FALSE;
      END IF;

      RETURN TRUE;
    END IF;

    IF P_ACTION IN ('NEW') THEN

      L_REC_EVENT_DETAILS.ACC               := P_ACC;
      L_REC_EVENT_DETAILS.BRN               := P_BRN;
      L_REC_EVENT_DETAILS.CCY               := P_CCY;
      L_REC_EVENT_DETAILS.EVENT_DATE        := P_DATE;
      L_REC_EVENT_DETAILS.TOPUP_AMT         := 0;
      L_REC_EVENT_DETAILS.TOPUP_AMT_SETTLED := 0;
      L_REC_EVENT_DETAILS.LIQD_AMT          := 0;
      L_REC_EVENT_DETAILS.BALANCE           := 0;
      L_REC_EVENT_DETAILS.REDEM_AMT         := 0;

    ELSE

      BEGIN
        SELECT *

          INTO L_REC_EVENT_DETAILS
          FROM TDTB_EVENT_DETAILS

         WHERE ACC = P_ACC
           AND BRN = P_BRN

           AND EVENT_DATE = (SELECT MAX(EVENT_DATE)
                               FROM TDTB_EVENT_DETAILS

                              WHERE ACC = P_ACC
                                AND BRN = P_BRN);
      EXCEPTION
        WHEN OTHERS THEN

          L_REC_EVENT_DETAILS := NULL;
      END;

    END IF;

    IF P_ACTION = 'ROLL' THEN

      PR_MOVE_TO_HISTORY;

      L_REC_EVENT_DETAILS.BALANCE := P_AMOUNT;

      L_REC_EVENT_DETAILS.TOPUP_AMT         := 0;
      L_REC_EVENT_DETAILS.TOPUP_AMT_SETTLED := 0;
      L_REC_EVENT_DETAILS.LIQD_AMT          := 0;
      L_REC_EVENT_DETAILS.REDEM_AMT         := 0;
      L_REC_EVENT_DETAILS.EVENT_DATE        := P_DATE;

      INSERT INTO TDTB_EVENT_DETAILS VALUES L_REC_EVENT_DETAILS;

    ELSIF P_ACTION = 'NEW' THEN

      L_REC_EVENT_DETAILS.BALANCE := P_AMOUNT;

      IF P_AMOUNT IS NULL OR L_REC_EVENT_DETAILS.BALANCE IS NULL THEN

        DBG('Amount or balance is null...returning false');
        RETURN FALSE;
      END IF;

      L_TMP_CNT := 0;

      BEGIN
        SELECT COUNT(1)
          INTO L_TMP_CNT
          FROM TDTB_EVENT_DETAILS
         WHERE ACC = P_ACC
           AND BRN = P_BRN
           AND (NVL(TOPUP_AMT, 0) > 0 OR NVL(REDEM_AMT, 0) > 0);

      EXCEPTION
        WHEN OTHERS THEN
          L_TMP_CNT := 0;
          DBG(SQLERRM);
      END;

      IF L_TMP_CNT = 0 THEN
        BEGIN
          INSERT INTO TDTB_EVENT_DETAILS VALUES L_REC_EVENT_DETAILS;
        EXCEPTION

          WHEN OTHERS THEN
            DBG('Error on insert into tdtb_event_details' || SQLERRM);
        END;
      END IF;
    ELSIF P_ACTION = 'CLOSE' THEN

      PR_MOVE_TO_HISTORY;
      DBG('Moved to history');

    ELSIF P_ACTION = 'TOPUP' THEN

      IF NVL(L_REC_EVENT_DETAILS.EVENT_DATE, P_DATE + 1) != P_DATE THEN

        L_REC_EVENT_DETAILS.ACC               := P_ACC;
        L_REC_EVENT_DETAILS.BRN               := P_BRN;
        L_REC_EVENT_DETAILS.CCY               := P_CCY;
        L_REC_EVENT_DETAILS.EVENT_DATE        := P_DATE;
        L_REC_EVENT_DETAILS.TOPUP_AMT         := P_AMOUNT;
        L_REC_EVENT_DETAILS.TOPUP_AMT_SETTLED := 0;
        L_REC_EVENT_DETAILS.BALANCE           := L_REC_EVENT_DETAILS.BALANCE +
                                                 P_AMOUNT;

        L_REC_EVENT_DETAILS.LIQD_AMT  := 0;
        L_REC_EVENT_DETAILS.REDEM_AMT := 0;

        INSERT INTO TDTB_EVENT_DETAILS VALUES L_REC_EVENT_DETAILS;

      ELSE

        UPDATE TDTB_EVENT_DETAILS
           SET TOPUP_AMT = NVL(TOPUP_AMT, 0) + P_AMOUNT,
               BALANCE   = L_REC_EVENT_DETAILS.BALANCE + P_AMOUNT

         WHERE ACC = L_REC_EVENT_DETAILS.ACC
           AND BRN = L_REC_EVENT_DETAILS.BRN
           AND EVENT_DATE = L_REC_EVENT_DETAILS.EVENT_DATE;

      END IF;
    ELSIF P_ACTION = 'LIQD' THEN

      BEGIN
        SELECT MAX(ENT_DT)
          INTO L_LAST_LIQ_DATE
          FROM ICTB_ENTRIES_HISTORY
         WHERE ACC = L_REC_EVENT_DETAILS.ACC
           AND BRN = L_REC_EVENT_DETAILS.BRN
           AND LIQN = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WO excpetion ' || SQLERRM);
      END;
      DBG('l_last_liq_date=' || L_LAST_LIQ_DATE);
      DBG('p_date=' || P_DATE);

      IF NOT FN_GET_LIQD_INT(L_REC_EVENT_DETAILS.ACC,
                             L_REC_EVENT_DETAILS.BRN,
                             L_LAST_LIQ_DATE,
                             L_LAST_LIQ_DATE,
                             NULL,
                             L_LIQ_INT) THEN
        DBG('Failed in getting the liq interest so far from entries history' ||
            SQLERRM);
      END IF;

      L_COUNT := 0;
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM TDTB_EVENT_DETAILS
         WHERE ACC = L_REC_EVENT_DETAILS.ACC
           AND BRN = L_REC_EVENT_DETAILS.BRN
           AND EVENT_DATE = (P_DATE + 1);
      EXCEPTION
        WHEN OTHERS THEN
          L_COUNT := 0;
      END;
      DBG('l_count=' || L_COUNT);

      IF (NVL(L_REC_EVENT_DETAILS.EVENT_DATE, P_DATE) != P_DATE + 1) AND
         NVL(L_COUNT, 0) = 0 THEN

        L_REC_EVENT_DETAILS.TOPUP_AMT         := 0;
        L_REC_EVENT_DETAILS.TOPUP_AMT_SETTLED := 0;
        L_REC_EVENT_DETAILS.LIQD_AMT          := L_LIQ_INT;
        L_REC_EVENT_DETAILS.REDEM_AMT         := 0;
        L_REC_EVENT_DETAILS.EVENT_DATE        := P_DATE + 1;

        INSERT INTO TDTB_EVENT_DETAILS VALUES L_REC_EVENT_DETAILS;

      ELSE

        UPDATE TDTB_EVENT_DETAILS
           SET LIQD_AMT = NVL(LIQD_AMT, 0) + L_LIQ_INT
         WHERE ACC = L_REC_EVENT_DETAILS.ACC
           AND BRN = L_REC_EVENT_DETAILS.BRN
           AND EVENT_DATE = L_REC_EVENT_DETAILS.EVENT_DATE;

      END IF;
    ELSIF P_ACTION IN ('REDEM') THEN

      IF NOT ICPKS_CACHE.FN_CLEARCACHE THEN
        DBG('Failed in clearing the cache for cust_Account');
      END IF;

      L_REC_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(L_REC_EVENT_DETAILS.ACC,
                                               L_REC_EVENT_DETAILS.BRN);

      IF NOT ICPKS_CACHE.FN_GETCUSTACC(L_REC_EVENT_DETAILS.BRN,
                                       L_REC_EVENT_DETAILS.ACC,
                                       L_CUST_ACC_REC) THEN
        DBG('Failed in select from sttm_cust_account');
      END IF;

      IF NOT CVPKS_UTILS.GET_STTM_ACCOUNT_BALANCE(L_REC_EVENT_DETAILS.BRN,
                                                  L_REC_EVENT_DETAILS.ACC,
                                                  'N',
                                                  L_BALREC) THEN
        DEBUG.PR_DEBUG('AC',
                       'Failed in Get_Sttm_Account_Balance .. : ' ||
                       SQLERRM);
      END IF;

      BEGIN
        SELECT *
          INTO L_REDEM_REC
          FROM ICTB_TDREDEMPTION_MASTER
         WHERE ACC_NO = L_REC_EVENT_DETAILS.ACC
           AND BRANCH_CODE = L_REC_EVENT_DETAILS.BRN
           AND REDEM_REF_NO =
               (SELECT MAX(REDEM_REF_NO)
                  FROM ICTB_TDREDEMPTION_MASTER
                 WHERE ACC_NO = L_REC_EVENT_DETAILS.ACC
                   AND BRANCH_CODE = L_REC_EVENT_DETAILS.BRN);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in select from ictb_tdredemption_master');
      END;

      DBG('l_BalRec.Acy_Withdrawable_Bal =' ||
          L_BALREC.ACY_WITHDRAWABLE_BAL);

      IF NVL(L_REC_EVENT_DETAILS.EVENT_DATE, P_DATE + 1) != P_DATE THEN
        DBG('Record not available on the event date');

        L_REC_EVENT_DETAILS.TOPUP_AMT := 0;

        L_REC_EVENT_DETAILS.TOPUP_AMT_SETTLED := 0;

        L_REC_EVENT_DETAILS.LIQD_AMT   := 0;
        L_REC_EVENT_DETAILS.REDEM_AMT  := NVL(L_REDEM_REC.REDEMPTION_AMT,
                                              P_AMOUNT);
        L_REC_EVENT_DETAILS.EVENT_DATE := P_DATE;

        INSERT INTO TDTB_EVENT_DETAILS VALUES L_REC_EVENT_DETAILS;
        L_CURR_TD_AMT := L_REC_EVENT_DETAILS.BALANCE;

      ELSE
        DBG('Record available on the event date');

        UPDATE TDTB_EVENT_DETAILS
           SET REDEM_AMT = NVL(REDEM_AMT, 0) +
                           NVL(L_REDEM_REC.REDEMPTION_AMT, P_AMOUNT)

         WHERE ACC = L_REC_EVENT_DETAILS.ACC
           AND BRN = L_REC_EVENT_DETAILS.BRN
           AND EVENT_DATE = L_REC_EVENT_DETAILS.EVENT_DATE
        RETURNING BALANCE INTO L_CURR_TD_AMT;

      END IF;

      IF L_REDEM_REC.REDEMPTION_AMT IS NULL THEN
        DBG('REDEM ENTRIES FOR SWEEP.HENCE RETURNING');
        RETURN TRUE;
      END IF;

      DBG('Current TD amount = ' || L_CURR_TD_AMT);
      DBG('Now to correct the adjustments on this balance');

      BEGIN
        SELECT COUNT(*)
          INTO L_PAYOUT_COUNT
          FROM ICTM_TDPAYOUT_DETAILS

         WHERE BRN = L_REC_EVENT_DETAILS.BRN
           AND ACC = L_REC_EVENT_DETAILS.ACC
           AND PAYOUT_COMPONENT = 'I';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('No Payout For Interest');
          L_PAYOUT_COUNT := 0;
      END;
      DBG('here with source' || CSPKS_REQ_GLOBAL.G_HEADER('SOURCE'));
      IF (L_REC_ACC.ACC = L_REC_ACC.BOOK_ACC AND L_PAYOUT_COUNT = 0)

       THEN

        BEGIN
          SELECT MAX(ENT_DT)
            INTO L_LAST_LIQ_DATE
            FROM ICTB_ENTRIES_HISTORY

           WHERE ACC = L_REC_EVENT_DETAILS.ACC
             AND BRN = L_REC_EVENT_DETAILS.BRN

             AND LIQN = 'Y';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('WO excpetion ' || SQLERRM);
        END;

        DBG('l_last_liq_date=' || L_LAST_LIQ_DATE);

        IF NOT FN_GET_LIQD_INT(

                               L_REC_EVENT_DETAILS.ACC,
                               L_REC_EVENT_DETAILS.BRN,

                               L_REC_ACC.INT_START_DATE,
                               GLOBAL.APPLICATION_DATE,
                               NULL,
                               L_LIQ_INT) THEN
          DBG('Failed in getting the liq interest so far from entries history' ||
              SQLERRM);
        END IF;

        DBG('l_liq_int initally =' || L_LIQ_INT);
        IF NOT FN_GET_BROKEN_INT(

                                 L_REC_EVENT_DETAILS.ACC,
                                 L_REC_EVENT_DETAILS.BRN,

                                 L_REC_ACC.INT_START_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_BROKEN_INT) THEN
          DBG('Failed in getting the fn_get_broken_int' || SQLERRM);
        END IF;
        DBG('Got the l_broken_int=' || L_BROKEN_INT);
        L_LIQ_INT := NVL(L_LIQ_INT, 0) + NVL(L_BROKEN_INT, 0);
        DBG(' After adjusting broken interest l_liq_int=' || L_LIQ_INT);
        DBG('  l_liq_int=' || L_LIQ_INT);

        L_TOTAL_TD_AMT := L_CURR_TD_AMT + L_LIQ_INT;

        DBG('l_total_td_amt  = ' || L_TOTAL_TD_AMT);

        L_ADJ_AMT := L_TOTAL_TD_AMT - L_BALREC.ACY_CURR_ACC_BAL;
        DBG('l_adj_amt  = ' || L_ADJ_AMT);

        IF L_ADJ_AMT <> 0 THEN

          IF NOT FN_UPD_TOPUP_SETTLED(

                                      L_REC_EVENT_DETAILS.ACC,
                                      L_REC_EVENT_DETAILS.BRN,

                                      L_ADJ_AMT,
                                      L_TB_TOPUP_MODIFIED,
                                      L_TB_TOPUP_SETTLED,
                                      P_ERR_CODE,
                                      P_ERR_PARAM) THEN
            DEBUG.PR_DEBUG('IC',
                           'fAILED IN  OF STUB stpks_stdtdtop_utils.fn_upd_topup_settled' ||
                           P_ERR_CODE);
            OVPKSS.PR_APPENDTBL(P_ERR_CODE, L_FLD);
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      IF L_REDEM_REC.REDEMPTION_MODE = 'N' THEN

        PR_MOVE_TO_HISTORY;
      END IF;
    END IF;
    DBG('End  of fn_topup_settled');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO exception in fn_topup_settled' || SQLERRM);
      RETURN FALSE;
  END FN_TOPUP_SETTLED;

  FUNCTION FN_GET_BASIS_AMT(P_BRN VARCHAR2,
                            P_ACC VARCHAR2,
                            P_DT  DATE,
                            P_AMT OUT NUMBER,
                            P_CCY OUT VARCHAR2) RETURN BOOLEAN IS
    L_BASIS_AMT NUMBER;

    L_CCY TDTB_EVENT_DETAILS.CCY%TYPE;
  BEGIN
    DBG('Start of fn_get_basis_amt');

    BEGIN
      SELECT BALANCE, CCY
        INTO L_BASIS_AMT, L_CCY

        FROM TDTB_EVENT_DETAILS
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND EVENT_DATE = (SELECT MAX(EVENT_DATE)

                             FROM TDTB_EVENT_DETAILS
                            WHERE ACC = P_ACC
                              AND BRN = P_BRN
                              AND EVENT_DATE <= P_DT);
    EXCEPTION
      WHEN OTHERS THEN

        BEGIN
          SELECT BALANCE, CCY
            INTO L_BASIS_AMT, L_CCY
            FROM TDTB_EVENT_DETAILS
           WHERE ACC = P_ACC
             AND BRN = P_BRN
             AND EVENT_DATE = (SELECT MIN(EVENT_DATE)
                                 FROM TDTB_EVENT_DETAILS
                                WHERE ACC = P_ACC
                                  AND BRN = P_BRN);
        EXCEPTION
          WHEN OTHERS THEN

            L_BASIS_AMT := 0;
        END;
    END;
    P_AMT := L_BASIS_AMT;
    P_CCY := L_CCY;
    DBG('End of fn_get_basis_amt' || L_BASIS_AMT || '~' || L_CCY);
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO exception in fn_get_basis_amt' || SQLERRM);
      RETURN FALSE;
  END FN_GET_BASIS_AMT;

  FUNCTION FN_COMP_CUM_AMT(P_FUNC_ID     VARCHAR2,
                           P_ACTION_CODE VARCHAR2,
                           P_ACC_REC     STTM_CUST_ACCOUNT%ROWTYPE,
                           P_DT          DATE) RETURN NUMBER IS
    L_RUN_DATE DATE;
    L_RUN_SEQ  ICTB_CUMDET.RUN_SEQ%TYPE;
    L_CUM_AMT  ICTB_CUMDET.CUM_AMT%TYPE;
  BEGIN
    DBG('Start of fn_comp_cum_amt');

    BEGIN
      SELECT MAX(RUN_DT)
        INTO L_RUN_DATE
        FROM ICTB_CUMDET
       WHERE BRN = P_ACC_REC.BRANCH_CODE
         AND ACC = P_ACC_REC.CUST_AC_NO
         AND RUN_DT <= P_DT;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Err in getting run date' || SQLERRM);
        L_RUN_DATE := NULL;
    END;

    IF L_RUN_DATE IS NOT NULL THEN
      BEGIN
        SELECT MAX(RUN_SEQ)
          INTO L_RUN_SEQ
          FROM ICTB_CUMDET
         WHERE BRN = P_ACC_REC.BRANCH_CODE
           AND ACC = P_ACC_REC.CUST_AC_NO
           AND RUN_DT = L_RUN_DATE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Err in getting run_seq' || SQLERRM);
      END;

      BEGIN
        SELECT CUM_AMT
          INTO L_CUM_AMT
          FROM ICTB_CUMDET
         WHERE BRN = P_ACC_REC.BRANCH_CODE
           AND ACC = P_ACC_REC.CUST_AC_NO
           AND RUN_DT = L_RUN_DATE
           AND RUN_SEQ = L_RUN_SEQ;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Err in getting cum_amt' || SQLERRM);
      END;
    ELSE
      L_CUM_AMT := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(P_ACC_REC, 'Y');
    END IF;
    DBG('End of fn_comp_cum_amt' || L_CUM_AMT);
    RETURN L_CUM_AMT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO exception in fn_get_basis_amt' || SQLERRM);
      RETURN 0;
  END FN_COMP_CUM_AMT;

  FUNCTION FN_UPD_CUMDET(P_ACC     VARCHAR2,
                         P_BRN     VARCHAR2,
                         P_CCY     VARCHAR2,
                         P_CUST_NO VARCHAR2,
                         P_ACLASS  VARCHAR2,
                         P_DATE    DATE)

   RETURN BOOLEAN IS
    L_COUNT    INTEGER := 0;
    L_CUM_FLAG BOOLEAN := FALSE;
    CURSOR CUR_ACCTS_TODAY IS
      SELECT A.*
        FROM ICTM_ACC A, STTM_CUST_ACCOUNT B
       WHERE A.ACC = B.CUST_AC_NO
         AND A.BRN = B.BRANCH_CODE
         AND A.BOOK_CCY = B.CCY
         AND B.CUST_NO = P_CUST_NO
         AND B.CCY = P_CCY
         AND B.ACCOUNT_CLASS = P_ACLASS
         AND NVL(A.INTRATE_CUMAMT_REQD, 'N') = 'Y'

         AND B.AC_OPEN_DATE = P_DATE;

    TYPE TY_TB_CUR_ACCTS IS TABLE OF CUR_ACCTS_TODAY%ROWTYPE INDEX BY PLS_INTEGER;

    L_TB_ACCTS TY_TB_CUR_ACCTS;

  BEGIN
    DBG('Start of fn_upd_cumdet');
    DBG('Called during Td auth, This is to check if any TDs already created on same day with cum_flag checked, if so update repop_rate for those Tds');

    IF CUR_ACCTS_TODAY%ISOPEN THEN
      CLOSE CUR_ACCTS_TODAY;
    END IF;
    OPEN CUR_ACCTS_TODAY;
    FETCH CUR_ACCTS_TODAY BULK COLLECT
      INTO L_TB_ACCTS;
    CLOSE CUR_ACCTS_TODAY;

    DBG('l_tb_accts.count=' || L_TB_ACCTS.COUNT);

    IF L_TB_ACCTS.COUNT = 0 THEN

      DBG('No accounts opened with cumulative flag checked today (or  only one account is opened ..return from here..');
    ELSE
      DBG('Rates of ' || L_TB_ACCTS.COUNT ||
          'accounts opened today must be repicked up on todays eod...');
      FORALL L_INDEX IN L_TB_ACCTS.FIRST .. L_TB_ACCTS.LAST
        UPDATE ICTB_CUMDET
           SET REPOP_RATE = 'Y'
         WHERE BRN = L_TB_ACCTS(L_INDEX).BRN
           AND ACC = L_TB_ACCTS(L_INDEX).ACC;
    END IF;

    DBG('End of fn_upd_cumdet');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_upd_cumdet' || SQLERRM);
      RETURN FALSE;
  END FN_UPD_CUMDET;

  FUNCTION FN_REPICKUP_RATES(P_BRN VARCHAR2) RETURN BOOLEAN IS
    CURSOR CUR_ACCTS IS
      SELECT *
        FROM ICTB_CUMDET
       WHERE BRN = P_BRN
         AND REPOP_RATE = 'Y'
         AND AC_OPEN_DT = GLOBAL.APPLICATION_DATE;

    TYPE TY_TB_CUR_ACCTS IS TABLE OF CUR_ACCTS%ROWTYPE INDEX BY PLS_INTEGER;

    L_TB_ACCTS TY_TB_CUR_ACCTS;
  BEGIN
    DBG('Start of fn_Repickup_Rates');
    DBG('During Eod, Rate repickup must happen for accounts which has repop_rate checked');

    IF CUR_ACCTS%ISOPEN THEN
      CLOSE CUR_ACCTS;
    END IF;
    OPEN CUR_ACCTS;
    FETCH CUR_ACCTS BULK COLLECT
      INTO L_TB_ACCTS;
    CLOSE CUR_ACCTS;
    DBG('No.of.accounts  to repickup = ' || L_TB_ACCTS.COUNT);
    IF L_TB_ACCTS.COUNT > 0 THEN

      FORALL L_INDEX IN L_TB_ACCTS.FIRST .. L_TB_ACCTS.LAST
        UPDATE ICTM_ACC_UDEVALS
           SET UDE_EFF_DT = L_TB_ACCTS(L_INDEX).AC_OPEN_DT
         WHERE BRN = L_TB_ACCTS(L_INDEX).BRN
           AND ACC = L_TB_ACCTS(L_INDEX).ACC
           AND UDE_EFF_DT = L_TB_ACCTS(L_INDEX).AC_OPEN_DT;
    END IF;
    DBG('End of fn_Repickup_Rates');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_Repickup_Rates' || SQLERRM);
      RETURN FALSE;
  END FN_REPICKUP_RATES;

  FUNCTION FN_CALC_MATAMT_BULK(P_BRN VARCHAR2) RETURN BOOLEAN IS
    L_INDEX    PLS_INTEGER;
    L_CUM_FLAG BOOLEAN := FALSE;
    L_ERR_CODE VARCHAR2(255);
    L_ERR_MSG  VARCHAR2(255);
    L_INT_RATE NUMBER;
    CURSOR CUR_ACCTS IS
      SELECT *
        FROM ICTB_CUMDET
       WHERE BRN = P_BRN
         AND REPOP_RATE = 'Y'
         AND AC_OPEN_DT = GLOBAL.APPLICATION_DATE;

    TYPE TY_TB_CUR_ACCTS IS TABLE OF CUR_ACCTS%ROWTYPE INDEX BY PLS_INTEGER;
    L_ICDREDMN     TDVWS_TD_REDEMPTION%ROWTYPE;
    L_TB_ACCTS     TY_TB_CUR_ACCTS;
    L_TOTAL_AMOUNT NUMBER;
    L_ACC_REC      STTM_CUST_ACCOUNT%ROWTYPE;
    L_PROD_REC     ICTM_ACC_PR%ROWTYPE;
    L_CUMAMT       NUMBER := 0;

    L_ICTM_ACC_REC ICTMS_ACC%ROWTYPE;
    L_PAYOUT_COUNT NUMBER;

    L_TB_CALC_BRKUP STPKS_STDTDTOP_UTILS.TY_TB_RED_BRKUP;
  BEGIN
    DBG('Start of fn_calc_matamt_bulk');
    DBG('For accounts whose rate has been repicked up during eod, new maturity amount and rate to be arrived.. ');

    IF CUR_ACCTS%ISOPEN THEN
      CLOSE CUR_ACCTS;
    END IF;
    OPEN CUR_ACCTS;
    FETCH CUR_ACCTS BULK COLLECT
      INTO L_TB_ACCTS;
    CLOSE CUR_ACCTS;
    DBG('No.of.accounts  to process = ' || L_TB_ACCTS.COUNT);
    IF L_TB_ACCTS.COUNT > 0 THEN
      L_INDEX := L_TB_ACCTS.FIRST;
      WHILE L_INDEX IS NOT NULL LOOP
        L_ICDREDMN := NULL;
        L_TB_CALC_BRKUP.DELETE;
        IF NOT ICPKS_CACHE.FN_GETCUSTACC(L_TB_ACCTS(L_INDEX).BRN,
                                         L_TB_ACCTS(L_INDEX).ACC,
                                         L_ACC_REC) THEN
          DBG('Could not get account');
        END IF;

        L_PROD_REC := ICPKS_CACHE.FN_GET_ICTMS_ACC_PR(L_TB_ACCTS(L_INDEX).ACC,
                                                      L_TB_ACCTS(L_INDEX).BRN);

        IF FN_IS_TOPUP_APPLICABLE(L_TB_ACCTS(L_INDEX).ACC,
                                  L_TB_ACCTS(L_INDEX).BRN) THEN
          DBG('Processing Topup account... ' || L_TB_ACCTS(L_INDEX).ACC);

          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');

          L_ICDREDMN.BRN_CODE := L_TB_ACCTS(L_INDEX).BRN;
          L_ICDREDMN.AC_NO    := L_TB_ACCTS(L_INDEX).ACC;

          L_ICDREDMN.WAVE_PENALTY   := 'Y';
          L_ICDREDMN.REDEMPTION_AMT := 0;
          L_ICDREDMN.CCY            := L_ACC_REC.CCY;
          L_CUMAMT                  := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(L_ACC_REC,
                                                                             'Y');
          DBG('calling stpks_stdtdtop_utils.fn_matamt_comp to calculate Maturity Amount before Top-Up');
          IF NOT STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP('FLEXCUBE',
                                                     'NEW',
                                                     L_ICDREDMN,
                                                     L_TB_CALC_BRKUP,
                                                     L_ERR_CODE,
                                                     L_ERR_MSG) THEN
            DBG('failed after calling fn_matamt_comp');
            L_ERR_CODE := 'ST-TDMAT-01';
            L_ERR_MSG  := NULL;

          END IF;
          L_TOTAL_AMOUNT := L_ICDREDMN.MATURITY_AMOUNT;
          STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');
        ELSE

          DBG('Processing  account... ' || L_TB_ACCTS(L_INDEX).ACC);
          DBG('Going to call PR_CALC_MATURITY');

          L_CUMAMT := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(L_ACC_REC, 'Y');

          STPKS_STDCUSAC_UTILS_1.PR_CALC_MATURITY(L_TB_ACCTS     (L_INDEX).BRN,
                                                  L_TB_ACCTS     (L_INDEX).ACC,
                                                  L_PROD_REC.PROD,
                                                  L_TOTAL_AMOUNT,
                                                  'STDCUSAC',
                                                  'N',
                                                  NULL);
          DBG('In TOTAL_AMOUNT-->' || L_TOTAL_AMOUNT);
        END IF;
        L_TB_ACCTS(L_INDEX).CUM_AMT := L_CUMAMT;

        L_INT_RATE := STPKS_STDCUSAC_UTILS_1.FN_PROJ_INTRATE('STDCUSAC',
                                                             L_TB_ACCTS     (L_INDEX).BRN,
                                                             L_TB_ACCTS     (L_INDEX).ACC,
                                                             L_PROD_REC.PROD);

        UPDATE ICTM_ACC
           SET MATURITY_AMOUNT = L_TOTAL_AMOUNT, INTEREST_RATE = L_INT_RATE
         WHERE BRN = L_TB_ACCTS(L_INDEX).BRN
           AND ACC = L_TB_ACCTS(L_INDEX).ACC;
        DBG('Processed acc' || L_TB_ACCTS(L_INDEX).ACC || 'mat amount =' ||
            L_TOTAL_AMOUNT || 'interest_rate = ' || L_INT_RATE ||
            '~l_Cumamt=' || L_CUMAMT);

        L_ICTM_ACC_REC := ICPKS_CACHE.FN_GET_ICTM_ACC(P_ACC => L_TB_ACCTS(L_INDEX).ACC,
                                                      P_BRN => L_TB_ACCTS(L_INDEX).BRN);

        BEGIN
          SELECT COUNT(*)
            INTO L_PAYOUT_COUNT
            FROM ICTM_TDPAYOUT_DETAILS
           WHERE BRN = L_TB_ACCTS(L_INDEX).BRN
             AND ACC = L_TB_ACCTS(L_INDEX).ACC
             AND PAYOUT_COMPONENT = 'I';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Payout For Interest');
            L_PAYOUT_COUNT := 0;
        END;

        IF ((L_ICTM_ACC_REC.BOOK_ACC <> L_ICTM_ACC_REC.ACC) OR
           (L_PAYOUT_COUNT > 0)) THEN
          ICPKS_CALC.PR_CALC_PROJ_INT_TILL_MAT(L_TB_ACCTS             (L_INDEX).BRN,
                                               L_TB_ACCTS             (L_INDEX).ACC,
                                               GLOBAL.APPLICATION_DATE);
        ELSE
          BEGIN
            UPDATE ICTM_TD_DETAILS
               SET PROJECTED_INT_TILL_MAT = G_TOTAL_INTEREST
             WHERE BRN = L_TB_ACCTS(L_INDEX).BRN
               AND ACC = L_TB_ACCTS(L_INDEX).ACC;
          END;
        END IF;

        L_TOTAL_AMOUNT := NULL;
        L_INT_RATE     := NULL;
        L_INDEX        := L_TB_ACCTS.NEXT(L_INDEX);
      END LOOP;

      FORALL L_IDX IN L_TB_ACCTS.FIRST .. L_TB_ACCTS.LAST
        UPDATE ICTB_CUMDET
           SET REPOP_RATE = 'N', CUM_AMT = L_TB_ACCTS(L_IDX).CUM_AMT
         WHERE BRN = L_TB_ACCTS(L_IDX).BRN
           AND ACC = L_TB_ACCTS(L_IDX).ACC
           AND REPOP_RATE = 'Y'
           AND AC_OPEN_DT = GLOBAL.APPLICATION_DATE;

    END IF;
    DBG('End of fn_calc_matamt_bulk');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in fn_calc_matamt_bulk' || SQLERRM);
      RETURN FALSE;
  END FN_CALC_MATAMT_BULK;

  FUNCTION FN_IS_DEP_AMT_INT_SDE(P_PROD                VARCHAR2,
                                 P_IS_DEP_AMT_INIT_SDE OUT BOOLEAN)
    RETURN BOOLEAN IS
    L_RULE_ID          ICTM_PR_INT.RULE%TYPE;
    L_COUNT            NUMBER := 0;
    L_DEP_AMT_INIT_CNT NUMBER := 0;
    L_DEPOSIT_AMT_CNT  NUMBER := 0;
  BEGIN
    DBG('Start of fn_is_dep_amt_int_sde');
    BEGIN
      SELECT A.RULE
        INTO L_RULE_ID
        FROM ICTM_PR_INT A
       WHERE A.PRODUCT_CODE = P_PROD;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed in getting the rule_id ' || SQLERRM);
        RETURN FALSE;
    END;
    DBG('l_rule_id-->' || L_RULE_ID);
    DBG('Check if DEP_AMT_INIT is used in Credit Book Formula');
    BEGIN
      SELECT COUNT(1)
        INTO L_DEP_AMT_INIT_CNT
        FROM ICTM_EXPR
       WHERE RULE_ID = L_RULE_ID
         AND FRM_NO IN (SELECT FRM_NO
                          FROM ICTM_RULE_FRM
                         WHERE RULE_ID = L_RULE_ID
                           AND BOOK_FLAG = 'B'

                        )
         AND RESULT LIKE '%DEP_AMT_INIT%';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO Exception in Checking if DEP_AMT_INIT is used in Credit Book Formula' ||
            SQLERRM);
        L_DEP_AMT_INIT_CNT := 0;
    END;
    DBG('l_dep_amt_init_cnt-->' || L_DEP_AMT_INIT_CNT);
    DBG('Check if DEPOSIT_AMOUNT is used in Credit Book Formula');
    L_DEPOSIT_AMT_CNT := 0;
    BEGIN
      SELECT COUNT(1)
        INTO L_DEPOSIT_AMT_CNT
        FROM ICTM_EXPR
       WHERE RULE_ID = L_RULE_ID
         AND FRM_NO IN (SELECT FRM_NO
                          FROM ICTM_RULE_FRM
                         WHERE RULE_ID = L_RULE_ID
                           AND BOOK_FLAG = 'B'

                        )
         AND RESULT LIKE '%DEPOSIT_AMOUNT%';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO Exception in Checking if DEPOSIT_AMOUNT is used in Credit Book Formula' ||
            SQLERRM);
        L_DEPOSIT_AMT_CNT := 0;
    END;
    DBG('l_deposit_amt_cnt-->' || L_DEPOSIT_AMT_CNT);
    IF L_DEP_AMT_INIT_CNT > 0 AND L_DEPOSIT_AMT_CNT = 0 THEN
      DBG('p_is_dep_amt_init_sde IS TRUE');
      P_IS_DEP_AMT_INIT_SDE := TRUE;
    ELSE
      DBG('p_is_dep_amt_init_sde IS FALSE');
      P_IS_DEP_AMT_INIT_SDE := FALSE;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Check if DEP_AMT_INIT is used in Credit Book Formula' ||
          SQLERRM);
      P_IS_DEP_AMT_INIT_SDE := FALSE;
      RETURN FALSE;
  END FN_IS_DEP_AMT_INT_SDE;

BEGIN
  PKG_DEBUG_REQD := NVL(CSPKSS_OS_PARAM.GET_PARAM_VAL('REAL_DEBUG'), 'N');
END STPKS_STDTDTOP_UTILS;
