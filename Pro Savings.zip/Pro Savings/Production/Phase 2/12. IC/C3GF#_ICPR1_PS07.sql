CREATE OR REPLACE PROCEDURE C3GF#_ICPR1_PS07(P_BRN    VARCHAR2,
                                             P_ACC    VARCHAR2,
                                             P_PROD   VARCHAR2,
                                             P_END_DT VARCHAR2,
                                             tb_icent IN OUT icpkss_test.rec_icent) IS
  TYPE FRM_REC IS RECORD(
    BRN         VARCHAR2(3),
    ACC         VARCHAR2(20),
    ELEM_ID     VARCHAR2(30),
    ELEM_VAL    NUMBER,
    DATE_FRM    DATE,
    ORDER_BY_DT DATE);
  UDE_CCY    CHAR(3);
  ACC_CCY    CHAR(3);
  CCON_STAT  BOOLEAN;
  P_END_DATE DATE := TO_DATE(P_END_DT, 'YYYYMMDD');
  TYPE FRM_CURSOR IS REF CURSOR RETURN FRM_REC;
  C_ELEMENT FRM_CURSOR;
  ELEM_REC  FRM_REC;

  CALC_FROM     DATE;
  CALC_TO       DATE;
  FC_DATE       DATE;
  NXT_CALC_DATE DATE;
  L_TO_DATE     DATE;
  TYPE FRM_TAB IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  FRM_ATAB FRM_TAB;
  FRM_DTAB FRM_TAB;
  FRM_LTAB FRM_TAB;

  k INTEGER := 0;
  TYPE ELEM_TAB_REC IS RECORD(
    DS                    DATE,
    DAYS                  NUMBER,
    DEPOSIT_AMOUNT        NUMBER,
    PRO_SAVINGS_TOPUP_AMT NUMBER,
    YEAR                  NUMBER,
    INTEREST_RATE         NUMBER,
    TAX_RATE              NUMBER,
    TOPUP_EXTRA_RATE      NUMBER,
    FORMULA1              NUMBER,
    FORMULA2              NUMBER,
    FORMULA3              NUMBER,
    FORMULA4              NUMBER);

  TYPE ELEM_TAB IS TABLE OF ELEM_TAB_REC INDEX BY BINARY_INTEGER;
  ATAB          ELEM_TAB;
  LTAB          ELEM_TAB;
  L_SDE_TAB     ICPKS_SDE.TB_SDE_REC;
  L_SDE_TOV_TAB ICPKS_SDE.TB_TOV_REC;
  NULREC        ELEM_TAB_REC;
  TAB_IDX       NUMBER := 0;

  ATAB_ROWS             INTEGER;
  LTAB_ROWS             INTEGER;
  ACUR_ROW              INTEGER := 0;
  LCUR_ROW              INTEGER := 0;
  liqn_dt               DATE := icpkss_calc.g_ictb_acc_pr.next_liq_dt;
  DEF_LIQN_DT           DATE := icpkss_calc.g_ictb_acc_pr.defer_liq_dt;
  l_udevals             icpks_ude.ty_udeval_tab;
  udestr                VARCHAR2(4000);
  jai                   pls_integer;
  sr                    NUMBER;
  pop_sep               NUMBER;
  l_udeid               ictms_acc_udevals.ude_id%TYPE;
  l_udeval              ictms_acc_udevals.ude_value%TYPE;
  DAYS                  NUMBER;
  DEPOSIT_AMOUNT        NUMBER;
  PRO_SAVINGS_TOPUP_AMT NUMBER;
  YEAR                  NUMBER;
  INTEREST_RATE         NUMBER;
  TAX_RATE              NUMBER;
  TOPUP_EXTRA_RATE      NUMBER;
  FORMULA1              NUMBER;
  FORMULA2              NUMBER;
  FORMULA3              NUMBER;
  FORMULA4              NUMBER;

  APY_FRM_NO ICTBS_APY.FRM_NO%TYPE;
  jp         INTEGER := 0;
  CURSOR c IS
    SELECT e.*, rowid
      FROM ICTBS_ENTRIES e
     WHERE e.brn = P_BRN
       and e.acc = P_ACC
       and e.prod = P_PROD
       AND e.frm_no IN (1, 2, 3, 4);

  R_ACC_PR  ICTMS_ACC_PR%ROWTYPE;
  R_IS_VALS ICTBS_IS_VALS%ROWTYPE;
  R_ENTRIES C%ROWTYPE;

  ACCR_DT   DATE;
  SLIQ      DATE;
  TMP_TO    DATE;
  FROM_DT   DATE;
  TO_DT     DATE;
  TO_DT_1   DATE;
  TODATE    DATE;
  PREV_TO   DATE;
  CALC_ACCR BOOLEAN;
  POP_ACCR  BOOLEAN;
  POP_LIQN  BOOLEAN;
  CALC_LIQN BOOLEAN := TRUE;
  TYPE TOV_TAB IS TABLE OF ICTMS_SDE.SDE_ID%TYPE INDEX BY BINARY_INTEGER;
  TOV_ELEM TOV_TAB;

  I INTEGER;
  J INTEGER;
  P INTEGER := 0;

  -- *****************************************
  -- VNDEAB SFR#1325 START OF CHANGES
  -- *****************************************

  A_OR_L ICTBS_ICALC_STMT.A_OR_L%TYPE;

  -- *****************************************
  -- VNDEAB SFR#1325 END OF CHANGES
  -- *****************************************
  --sampath starts
  L_ACCRUED ICTB_ENTRIES.ACCRUED_AMT%TYPE;
  --sampath ends
  
  PROCEDURE dbg(p_str in varchar2) as
  BEGIN
  
    IF debug.pkg_debug_on <> 2 THEN
      debug.pr_debug('IC', 'C3GF#_ICPR1_PS07 --> :' || p_str);
    END IF;
  
  END dbg;

  PROCEDURE SETVAL(T   IN OUT NOCOPY ELEM_TAB,
                   FLD VARCHAR2,
                   IDX INTEGER,
                   N   NUMBER) IS
  BEGIN
  
    IF NOT T.EXISTS(IDX) THEN
      T(IDX) := NULREC; -- Set To Null. Undef.Table rows have wierd values
      T(IDX).DS := FROM_DT + IDX;
    END IF;
  
    IF FLD = 'DAYS' THEN
      T(IDX).DAYS := N;
    ELSIF FLD = 'DEPOSIT_AMOUNT' THEN
      T(IDX).DEPOSIT_AMOUNT := N;
    ELSIF FLD = 'PRO_SAVINGS_TOPUP_AMT' THEN
      T(IDX).PRO_SAVINGS_TOPUP_AMT := N;
    ELSIF FLD = 'YEAR' THEN
      T(IDX).YEAR := N;
    ELSIF FLD = 'INTEREST_RATE' THEN
      T(IDX).INTEREST_RATE := N;
    ELSIF FLD = 'TAX_RATE' THEN
      T(IDX).TAX_RATE := N;
    ELSIF FLD = 'TOPUP_EXTRA_RATE' THEN
      T(IDX).TOPUP_EXTRA_RATE := N;
    ELSIF FLD = 'FORMULA1' THEN
      T(IDX).FORMULA1 := N;
    ELSIF FLD = 'FORMULA2' THEN
      T(IDX).FORMULA2 := N;
    ELSIF FLD = 'FORMULA3' THEN
      T(IDX).FORMULA3 := N;
    ELSIF FLD = 'FORMULA4' THEN
      T(IDX).FORMULA4 := N;
    END IF;
  END SETVAL;

  PROCEDURE FILL_VAL(T IN OUT ELEM_TAB) IS
    I         INTEGER;
    J         INTEGER;
    A         INTEGER;
    l_year    number;
    l_to_dt   date;
    l_to_year number;
    P         INTEGER := 0;
  
  BEGIN
    P := T.FIRST;
    T(P).DAYS := NVL(T(P).DAYS, 0);
    T(P).DEPOSIT_AMOUNT := NVL(T(P).DEPOSIT_AMOUNT, 0);
    T(P).PRO_SAVINGS_TOPUP_AMT := NVL(T(P).PRO_SAVINGS_TOPUP_AMT, 0);
    T(P).YEAR := NVL(T(P).YEAR, 0);
    T(P).INTEREST_RATE := NVL(T(P).INTEREST_RATE, 0);
    T(P).TAX_RATE := NVL(T(P).TAX_RATE, 0);
    T(P).TOPUP_EXTRA_RATE := NVL(T(P).TOPUP_EXTRA_RATE, 0);
    T(P).FORMULA1 := NVL(T(P).FORMULA1, 0);
    T(P).FORMULA2 := NVL(T(P).FORMULA2, 0);
    T(P).FORMULA3 := NVL(T(P).FORMULA3, 0);
    T(P).FORMULA4 := NVL(T(P).FORMULA4, 0);
    I := T.NEXT(P);
    J := T.LAST;
    WHILE I <= J LOOP
      T(I).DAYS := NVL(T(I).DAYS, NVL(T(P).DAYS, 0));
      T(I).DEPOSIT_AMOUNT := NVL(T(I).DEPOSIT_AMOUNT,
                                 NVL(T(P).DEPOSIT_AMOUNT, 0));
      T(I).PRO_SAVINGS_TOPUP_AMT := NVL(T(I).PRO_SAVINGS_TOPUP_AMT,
                                        NVL(T(P).PRO_SAVINGS_TOPUP_AMT, 0));
      T(I).YEAR := NVL(T(I).YEAR, NVL(T(P).YEAR, 0));
      T(I).INTEREST_RATE := NVL(T(I).INTEREST_RATE,
                                NVL(T(P).INTEREST_RATE, 0));
      T(I).TAX_RATE := NVL(T(I).TAX_RATE, NVL(T(P).TAX_RATE, 0));
      T(I).TOPUP_EXTRA_RATE := NVL(T(I).TOPUP_EXTRA_RATE,
                                   NVL(T(P).TOPUP_EXTRA_RATE, 0));
      T(I).FORMULA1 := NVL(T(I).FORMULA1, NVL(T(P).FORMULA1, 0));
      T(I).FORMULA2 := NVL(T(I).FORMULA2, NVL(T(P).FORMULA2, 0));
      T(I).FORMULA3 := NVL(T(I).FORMULA3, NVL(T(P).FORMULA3, 0));
      T(I).FORMULA4 := NVL(T(I).FORMULA4, NVL(T(P).FORMULA4, 0));
      P := I;
      I := T.NEXT(I);
    END LOOP;
  END FILL_VAL;

  PROCEDURE POP_SPL_ELEMS IS
    se_tab icpkss_maint.tb_acc_sde_vals;
    i      integer;
  begin
    se_tab.delete;
    se_tab := icpkss_maint.fn_get_sde_vals(p_brn,
                                           p_acc,
                                           'DEPOSIT_AMOUNT',
                                           from_dt,
                                           to_dt);
    if nvl(se_tab.count, 0) != 0 then
      for i in se_tab.first .. se_tab.last loop
        IF CALC_ACCR AND nvl(se_tab(i).from_dt, from_dt) <= ACCR_DT THEN
          setval(atab,
                 se_tab(i).sde_id,
                 nvl(se_tab(i).from_dt, from_dt) - from_dt,
                 nvl(se_tab(i).sde_val, 0));
        END IF;
        setval(ltab,
               se_tab(i).sde_id,
               nvl(se_tab(i).from_dt, from_dt) - from_dt,
               nvl(se_tab(i).sde_val, 0));
      end loop;
    end if;
  
    se_tab.delete;
    se_tab := icpkss_maint.fn_get_sde_vals(p_brn,
                                           p_acc,
                                           'PRO_SAVINGS_TOPUP_AMT',
                                           from_dt,
                                           to_dt);
    if nvl(se_tab.count, 0) != 0 then
      for i in se_tab.first .. se_tab.last loop
        IF CALC_ACCR AND nvl(se_tab(i).from_dt, from_dt) <= ACCR_DT THEN
          setval(atab,
                 se_tab(i).sde_id,
                 nvl(se_tab(i).from_dt, from_dt) - from_dt,
                 nvl(se_tab(i).sde_val, 0));
        END IF;
        setval(ltab,
               se_tab(i).sde_id,
               nvl(se_tab(i).from_dt, from_dt) - from_dt,
               nvl(se_tab(i).sde_val, 0));
      end loop;
    end if;
  
    se_tab.delete;
  end pop_spl_elems;

  PROCEDURE CALC_DLY_AMT(A   IN ELEM_TAB,
                         L   IN ELEM_TAB,
                         F   OUT FRM_TAB,
                         NCD OUT DATE) IS
    I     INTEGER;
    J     INTEGER;
    DAYS  NUMBER;
    MONTH NUMBER;
    YEAR  NUMBER;
    DUMMY BOOLEAN;
  
  BEGIN
  
    BEGIN
      I := A.LAST;
      J := L.LAST;
      icpkss_util.dbg('P_END_DATE ' || P_END_DATE);
      IF I = J OR J = 0 THEN
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := TO_DT + 1;
      ELSE
        IF L.NEXT(I) IS NOT NULL THEN
          J := L.NEXT(I);
        END IF;
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                L(J).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := L(J).DS;
      END IF;
      IF DAYS > 0 THEN
        F(1) := L(I).FORMULA1 / DAYS;
      ELSE
        F(1) := 0;
      END IF;
	 --sampath starts
      ICPKS_UTIL.DBG('L(I).FORMULA1=' || L(I).FORMULA1);
      ICPKS_UTIL.DBG('DAYS=' || DAYS);
      ICPKSS_UTIL.dbg('FORMULA1 CALC_DLY_AMT BEFORE ROUNDING=' || F(1));
      --sampath ends
      DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(1), F(1));
	  --sampath starts
      ICPKSS_UTIL.dbg('FORMULA1 CALC_DLY_AMT AFTER ROUNDING');
      --sampath ends	
      icpkss_util.dbg('P_END_DATE ' || P_END_DATE);
      IF I = J OR J = 0 THEN
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := TO_DT + 1;
      ELSE
        IF L.NEXT(I) IS NOT NULL THEN
          J := L.NEXT(I);
        END IF;
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                L(J).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := L(J).DS;
      END IF;
	--sampath starts for formula2
      DAYS := 1; --always consider DAYS as 
    
      ICPKS_UTIL.DBG('L(I).FORMULA2=' || L(I).FORMULA2);
      ICPKS_UTIL.DBG('A(I).FORMULA2=' || A(I).FORMULA2);
      ICPKS_UTIL.DBG('DAYS=' || DAYS);
      ICPKS_UTIL.DBG('L(I).PRO_SAVINGS_TOPUP_AMT=' || L(I)
                     .PRO_SAVINGS_TOPUP_AMT);
    
      ICPKS_UTIL.DBG('L(I).TOPUP_EXTRA_RATE=' || L(I).TOPUP_EXTRA_RATE);
      ICPKS_UTIL.DBG('L(I).DS=' || L(I).DS);
      ICPKS_UTIL.DBG('A(I).PRO_SAVINGS_TOPUP_AMT=' || A(I)
                     .PRO_SAVINGS_TOPUP_AMT);
    
      ICPKS_UTIL.DBG('A(I).TOPUP_EXTRA_RATE=' || A(I).TOPUP_EXTRA_RATE);
      ICPKS_UTIL.DBG('A(I).DS=' || A(I).DS);
      --sampath ends for formula2  
      IF DAYS > 0 THEN
		--sampath starts
        ICPKSS_UTIL.dbg('INSIDE IF FORMULA2 FOR DAYS FOR DAILY CALC AMT FIELD');
        --sampath ends							   
        --F(2) := L(I).FORMULA2 / DAYS; --sampath commented
		--sampath starts      
        F(2) := (PRO_SAVINGS_TOPUP_AMT * 1 * TOPUP_EXTRA_RATE) /
                (YEAR * 100);
        --sampath ends		  
      ELSE
	    --sampath starts
        ICPKSS_UTIL.dbg('INSIDE ELSE FORMULA2 FOR DAYS FOR DAILY CALC AMT FIELD');
        --sampath ends
		
        F(2) := 0;
      END IF;
	  --sampath starts
      ICPKS_UTIL.DBG('L(I).FORMULA2=' || L(I).FORMULA2);
      ICPKS_UTIL.DBG('DAYS=' || DAYS);
    
      ICPKSS_UTIL.dbg('FORMULA2 CALC_DLY_AMT BEFORE ROUNDING=' || F(2));
      --sampath ends 		
      DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(2), F(2));
		--sampath starts
      ICPKSS_UTIL.dbg('FORMULA2 CALC_DLY_AMT AFTER ROUNDING');
      --sampath ends						   
      icpkss_util.dbg('P_END_DATE ' || P_END_DATE);
      IF I = J OR J = 0 THEN
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := TO_DT + 1;
      ELSE
        IF L.NEXT(I) IS NOT NULL THEN
          J := L.NEXT(I);
        END IF;
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                L(J).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := L(J).DS;
      END IF;
      IF DAYS > 0 THEN
        F(3) := L(I).FORMULA3 / DAYS;
      ELSE
        F(3) := 0;
      END IF;
	--sampath starts
      ICPKS_UTIL.DBG('L(I).FORMULA3=' || L(I).FORMULA3);
      ICPKS_UTIL.DBG('DAYS=' || DAYS);
    
      ICPKSS_UTIL.dbg('FORMULA3 CALC_DLY_AMT BEFORE ROUNDING=' || F(3));
      --sampath ends 
      DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(3), F(3));
	--sampath starts
      ICPKSS_UTIL.dbg('FORMULA3 CALC_DLY_AMT AFTER ROUNDING');
      --sampath ends  						   
      icpkss_util.dbg('P_END_DATE ' || P_END_DATE);
      IF I = J OR J = 0 THEN
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := TO_DT + 1;
      ELSE
        IF L.NEXT(I) IS NOT NULL THEN
          J := L.NEXT(I);
        END IF;
        ICPKSS_UTIL.PR_GET_DAYS(A(I).DS,
                                L(J).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
        NCD := L(J).DS;
      END IF;
      IF DAYS > 0 THEN
		--sampath starts
        ICPKSS_UTIL.dbg('INSIDE IF FORMULA4 FOR DAYS FOR DAILY CALC AMT FIELD');
        --sampath ends   		
        F(4) := L(I).FORMULA4 / DAYS;
      ELSE				  
		--sampath starts
        ICPKSS_UTIL.dbg('INSIDE ELSE FORMULA4 FOR DAYS FOR DAILY CALC AMT FIELD');
        --sampath ends 																		  
        F(4) := 0;
      END IF;
      DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(4), F(4));
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NCD := NULL;
        F(1) := NULL;
        F(2) := NULL;
        F(3) := NULL;
        F(4) := NULL;
      WHEN OTHERS THEN
        icpkss_util.dbg('Inside when others of CALC_DLY_AMT ' || SQLERRM);
        NCD := NULL;
        F(1) := NULL;
        F(2) := NULL;
        F(3) := NULL;
        F(4) := NULL;
    END;
  
  END CALC_DLY_AMT;
  PROCEDURE CALC_FRM(T      IN OUT ELEM_TAB,
                     F      IN OUT FRM_TAB,
                     gen_IS BOOLEAN := FALSE) IS
    CUR_DATE     DATE;
    L            INTEGER := T.LAST;
    I            INTEGER := 0;
    DAYS         NUMBER;
    MONTH        NUMBER;
    YEAR         NUMBER;
    DUMMY        BOOLEAN;
    ADJ_AMOUNT   NUMBER(22, 3) := 0;
    L_ERROR_CODE VARCHAR2(100);
    L_ERROR_MSG  VARCHAR2(1000);
    T_DATE       DATE;
    r_print      icpkss_test.rec_print;
    -- *****************************************
    -- VNDEAB SFR#1325 START OF CHANGES
    -- *****************************************
  
    L_RUN_SEQ ICTBS_ICALC_STMT.RUN_SEQ%TYPE;
    TYPE X_TYPE IS TABLE OF ICTBS_ICALC_STMT%ROWTYPE INDEX BY PLS_INTEGER;
    X X_TYPE;
    -- *****************************************
    -- VNDEAB SFR#1325 END OF CHANGES
    -- *****************************************
	
	--sampath starts
    L_FORMULA_2_EXECUTE_ONCE BOOLEAN := FALSE;
    --sampath ends 										  
  
  BEGIN
    -- *****************************************
    -- VNDEAB SFR#1325 START OF CHANGES
    -- *****************************************
  
    L_RUN_SEQ := TO_CHAR(SYSDATE, 'RRDDDHH24MISS');
    -- *****************************************
    -- VNDEAB SFR#1325 END OF CHANGES
    -- *****************************************
  
    WHILE I <= L LOOP
      FORMULA1              := 0;
      FORMULA2              := 0;
      FORMULA3              := 0;
      FORMULA4              := 0;
      DAYS                  := T(I).DAYS;
      DEPOSIT_AMOUNT        := T(I).DEPOSIT_AMOUNT;
      PRO_SAVINGS_TOPUP_AMT := T(I).PRO_SAVINGS_TOPUP_AMT;
      YEAR                  := T(I).YEAR;
    
      T_DATE        := T(I).DS;
      INTEREST_RATE := ICPKS_UTIL.GETRP_RATE_AMT('R',
                                                 P_BRN,
                                                 P_ACC,
                                                 P_PROD,
                                                 'PS07/INTEREST_RATE/1',
                                                 ACC_CCY,
                                                 T(I).INTEREST_RATE);
      dbg('Orig Start Date  ' || T(T.FIRST).DS);
      dbg('Orig End Date ' || TO_DT);
      IF I = L THEN
        ICPKSS_UTIL.PR_GET_DAYS(T(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
      ELSE
        ICPKSS_UTIL.PR_GET_DAYS(T(I).DS,
                                T(T.NEXT(I)).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
      END IF;
      IF DEPOSIT_AMOUNT > 0 THEN
        FORMULA1 := (DEPOSIT_AMOUNT * DAYS * INTEREST_RATE) / (YEAR * 100);
        --DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY,FORMULA1,FORMULA1);--VINAY_RASHAD FRBKNL changes
        --Moved rounding from within the loop to outside the loop so that it should do rounding after the amount is summed up and not individual amount round of.
        --This is done to avoid the 1 cent difference in actual calculation and flexcube calculation
        T(I).FORMULA1 := FORMULA1;
      
        -- *****************************************
        -- VNDEAB SFR#1325 START OF CHANGES
        -- *****************************************
      
        X(NVL(X.LAST, 0) + 1).BRN := P_BRN;
        X(X.LAST).ACC := P_ACC;
        X(X.LAST).PROD := P_PROD;
        X(X.LAST).RUN_DT := GLOBAL.APPLICATION_DATE;
        X(X.LAST).RUN_SEQ := L_RUN_SEQ;
        X(X.LAST).A_OR_L := A_OR_L;
        X(X.LAST).EOC_FLAG := GLOBAL.branch_status;
        X(X.LAST).FRM_NO := 1;
        X(X.LAST).EXPR_LINE := 1;
        X(X.LAST).DS := T(I).DS;
        X(X.LAST).DS_VALUE := 'DAYS|' || DAYS || '~DEPOSIT_AMOUNT|' ||
                              DEPOSIT_AMOUNT || '~INTEREST_RATE|' ||
                              INTEREST_RATE || '~YEAR|' || YEAR || '~';
        X(X.LAST).FROM_DT := FROM_DT;
        X(X.LAST).TO_DT := TO_DT;
        X(X.LAST).COND_EXPR := 'DEPOSIT_AMOUNT > 0';
        X(X.LAST).COND_VALUE := '{DEPOSIT_AMOUNT = ' || DEPOSIT_AMOUNT ||
                                '} > 0';
        X(X.LAST).COND_TS := 'DEPOSIT_AMOUNT|' || DEPOSIT_AMOUNT || '~';
        X(X.LAST).RESULT_EXPR := '(DEPOSIT_AMOUNT*DAYS*INTEREST_RATE)/(YEAR*100)';
        X(X.LAST).RESULT_VALUE := '({DEPOSIT_AMOUNT = ' || DEPOSIT_AMOUNT ||
                                  '}*{DAYS = ' || DAYS ||
                                  '}*{INTEREST_RATE = ' || INTEREST_RATE ||
                                  '})/({YEAR = ' || YEAR || '}*100)';
        X(X.LAST).RESULT_TS := 'DAYS|' || DAYS || '~DEPOSIT_AMOUNT|' ||
                               DEPOSIT_AMOUNT || '~INTEREST_RATE|' ||
                               INTEREST_RATE || '~YEAR|' || YEAR || '~';
        X(X.LAST).RESULT := T(I).FORMULA1;
      
        -- *****************************************
        -- VNDEAB SFR#1325 END OF CHANGES
        -- *****************************************
      
      END IF;
    
      TOPUP_EXTRA_RATE := ICPKS_UTIL.GETRP_RATE_AMT('R',
                                                    P_BRN,
                                                    P_ACC,
                                                    P_PROD,
                                                    'PS07/TOPUP_EXTRA_RATE/2',
                                                    ACC_CCY,
                                                    T(I).TOPUP_EXTRA_RATE);
      dbg('Orig Start Date  ' || T(T.FIRST).DS);
      dbg('Orig End Date ' || TO_DT);
	--sampath starts
      dbg('This is top up extra rate:');
      dbg('Orig Start Date  ' || T(T.FIRST).DS);
      dbg('Orig End Date ' || TO_DT);
      dbg('Orig End Date T(I).DS' || T(I).DS);
      --dbg('Orig End Date TO_DT + 1' || TO_DT + 1);
      dbg('Orig End Date FROM_DT ' || FROM_DT);
      --dbg('Orig End Date T(T.NEXT(I)).DS' || T(T.NEXT(I)).DS);
      dbg('Orig End Date I' || I);
      dbg('Orig End Date L' || L);
      --sampath ends					
      IF I = L THEN
        ICPKSS_UTIL.PR_GET_DAYS(T(I).DS,
                                TO_DT + 1,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
      ELSE
        ICPKSS_UTIL.PR_GET_DAYS(T(I).DS,
                                T(T.NEXT(I)).DS,
                                '6',
                                DAYS,
                                MONTH,
                                YEAR,
                                FROM_DT,
                                TO_DT + 1);
      END IF;
      IF PRO_SAVINGS_TOPUP_AMT > 0 AND NOT L_FORMULA_2_EXECUTE_ONCE THEN --sampath added AND condition
        FORMULA2 := (PRO_SAVINGS_TOPUP_AMT * 1 * TOPUP_EXTRA_RATE) / --sampath DAYS replaced by 1
                    (YEAR * 100);
        --DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY,FORMULA2,FORMULA2);--VINAY_RASHAD FRBKNL changes
        --Moved rounding from within the loop to outside the loop so that it should do rounding after the amount is summed up and not individual amount round of.
        --This is done to avoid the 1 cent difference in actual calculation and flexcube calculation
        T(I).FORMULA2 := FORMULA2;
      
        -- *****************************************
        -- VNDEAB SFR#1325 START OF CHANGES
        -- *****************************************
      
        X(NVL(X.LAST, 0) + 1).BRN := P_BRN;
        X(X.LAST).ACC := P_ACC;
        X(X.LAST).PROD := P_PROD;
        X(X.LAST).RUN_DT := GLOBAL.APPLICATION_DATE;
        X(X.LAST).RUN_SEQ := L_RUN_SEQ;
        X(X.LAST).A_OR_L := A_OR_L;
        X(X.LAST).EOC_FLAG := GLOBAL.branch_status;
        X(X.LAST).FRM_NO := 2;
        X(X.LAST).EXPR_LINE := 1;
        X(X.LAST).DS := T(I).DS;
        X(X.LAST).DS_VALUE := 'DAYS|' || 1 || '~PRO_SAVINGS_TOPUP_AMT|' || --sampath DAYS replaced by 1
                              PRO_SAVINGS_TOPUP_AMT || '~TOPUP_EXTRA_RATE|' ||
                              TOPUP_EXTRA_RATE || '~YEAR|' || YEAR || '~';
        X(X.LAST).FROM_DT := FROM_DT;
        X(X.LAST).TO_DT := TO_DT;
        X(X.LAST).COND_EXPR := 'PRO_SAVINGS_TOPUP_AMT > 0';
        X(X.LAST).COND_VALUE := '{PRO_SAVINGS_TOPUP_AMT = ' ||
                                PRO_SAVINGS_TOPUP_AMT || '} > 0';
        X(X.LAST).COND_TS := 'PRO_SAVINGS_TOPUP_AMT|' ||
                             PRO_SAVINGS_TOPUP_AMT || '~';
        X(X.LAST).RESULT_EXPR := '(PRO_SAVINGS_TOPUP_AMT*DAYS*TOPUP_EXTRA_RATE)/(YEAR*100)';
        X(X.LAST).RESULT_VALUE := '({PRO_SAVINGS_TOPUP_AMT = ' ||
                                  PRO_SAVINGS_TOPUP_AMT || '}*{DAYS = ' || 1 || --sampath DAYS replaced by 1
                                  '}*{TOPUP_EXTRA_RATE = ' ||
                                  TOPUP_EXTRA_RATE || '})/({YEAR = ' || YEAR ||
                                  '}*100)';
        X(X.LAST).RESULT_TS := 'DAYS|' || 1 || '~PRO_SAVINGS_TOPUP_AMT|' || --sampath DAYS replaced by 1
                               PRO_SAVINGS_TOPUP_AMT ||
                               '~TOPUP_EXTRA_RATE|' || TOPUP_EXTRA_RATE ||
                               '~YEAR|' || YEAR || '~';
        X(X.LAST).RESULT := T(I).FORMULA2;
      
        -- *****************************************
        -- VNDEAB SFR#1325 END OF CHANGES
        -- *****************************************
		    --sampath starts
        L_FORMULA_2_EXECUTE_ONCE := TRUE;
        --sampath ends				 
      
      END IF;
    
      F(1) := F(1) + FORMULA1;
      F(2) := F(2) + FORMULA2;
    
      icpkss_test.find_key(p_prod, r_print);
      IF r_print.il_product = 'Y' THEN
        IF NOT ilpkss_services.fn_pop_ic_formula_interest(p_brn,
                                                          p_acc,
                                                          p_prod,
                                                          t_date,
                                                          1,
                                                          FORMULA1,
                                                          l_error_code,
                                                          l_error_msg) THEN
          icpkss_util.dbg('Failed in storing formulawise interest for ILM ' ||
                          l_error_code);
          ROLLBACK TO BEFORE_CALC;
          RAISE_APPLICATION_ERROR(-20101, SQLERRM);
        END IF;
      END IF;
      IF r_print.il_product = 'Y' THEN
        IF NOT ilpkss_services.fn_pop_ic_formula_interest(p_brn,
                                                          p_acc,
                                                          p_prod,
                                                          t_date,
                                                          2,
                                                          FORMULA2,
                                                          l_error_code,
                                                          l_error_msg) THEN
          icpkss_util.dbg('Failed in storing formulawise interest for ILM ' ||
                          l_error_code);
          ROLLBACK TO BEFORE_CALC;
          RAISE_APPLICATION_ERROR(-20101, SQLERRM);
        END IF;
      END IF;
      I := T.NEXT(I);
    END LOOP;
  
    FORMULA1 := F(1) - NVL(ADJ_AMOUNT, 0);
    ADJ_AMOUNT := NULL;
    F(1) := FORMULA1;
    DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(1), F(1)); --Vinay-Rashad FRBKNL
    ICPKSS_UTIL.dbg('Amount after round off for F(1):= ' || F(1));
    FORMULA2 := F(2) - NVL(ADJ_AMOUNT, 0);
    ADJ_AMOUNT := NULL;
    F(2) := FORMULA2;
    DUMMY := CYPKSS.FN_AMT_ROUND(ACC_CCY, F(2), F(2)); --Vinay-Rashad FRBKNL
    ICPKSS_UTIL.dbg('Amount after round off for F(2):= ' || F(2));
  
    TAX_RATE := ICPKS_UTIL.GETRP_RATE_AMT('R',
                                          P_BRN,
                                          P_ACC,
                                          P_PROD,
                                          'PS07/TAX_RATE/3',
                                          ACC_CCY,
                                          T(L).TAX_RATE);
    ICPKSS_UTIL.PR_GET_DAYS(FROM_DT,
                            TO_DT + 1,
                            '6',
                            DAYS,
                            MONTH,
                            YEAR,
                            FROM_DT,
                            TO_DT + 1);
    IF FORMULA1 > 0 THEN
      DUMMY := ICPKS_UTIL.fn_get_int_amt_rounded('PS07',
                                                 3,
                                                 p_acc,
                                                 p_prod,
                                                 gen_IS,
                                                 FORMULA1);
      FORMULA3 := (FORMULA1 * (TAX_RATE / 100));
      T(L).FORMULA3 := (FORMULA1 * (TAX_RATE / 100));
      DUMMY := ICPKS_UTIL.fn_get_tax_amt_rounded('PS07',
                                                 3,
                                                 p_acc,
                                                 p_prod,
                                                 FORMULA3);
      T(L).FORMULA3 := FORMULA3;
    
      -- *****************************************
      -- VNDEAB SFR#1325 START OF CHANGES
      -- *****************************************
    
      X(NVL(X.LAST, 0) + 1).BRN := P_BRN;
      X(X.LAST).ACC := P_ACC;
      X(X.LAST).PROD := P_PROD;
      X(X.LAST).RUN_DT := GLOBAL.APPLICATION_DATE;
      X(X.LAST).RUN_SEQ := L_RUN_SEQ;
      X(X.LAST).A_OR_L := A_OR_L;
      X(X.LAST).EOC_FLAG := GLOBAL.branch_status;
      X(X.LAST).FRM_NO := 3;
      X(X.LAST).EXPR_LINE := 1;
      X(X.LAST).DS := T(L).DS;
      X(X.LAST).DS_VALUE := 'TAX_RATE|' || TAX_RATE || '~';
      X(X.LAST).FROM_DT := FROM_DT;
      X(X.LAST).TO_DT := TO_DT;
      X(X.LAST).COND_EXPR := 'FORMULA1>0';
      X(X.LAST).COND_VALUE := 'FORMULA1>0';
      X(X.LAST).COND_TS := '';
      X(X.LAST).RESULT_EXPR := '(FORMULA1*(TAX_RATE/100))';
      X(X.LAST).RESULT_VALUE := '(FORMULA1*({TAX_RATE = ' || TAX_RATE ||
                                '}/100))';
      X(X.LAST).RESULT_TS := 'TAX_RATE|' || TAX_RATE || '~';
      X(X.LAST).RESULT := T(L).FORMULA3;
    
      -- *****************************************
      -- VNDEAB SFR#1325 END OF CHANGES
      -- *****************************************
    
      FORMULA3 := FORMULA3 - NVL(ADJ_AMOUNT, 0);
      ADJ_AMOUNT := NULL;
      F(3) := FORMULA3;
    END IF;
  
    TAX_RATE := ICPKS_UTIL.GETRP_RATE_AMT('R',
                                          P_BRN,
                                          P_ACC,
                                          P_PROD,
                                          'PS07/TAX_RATE/4',
                                          ACC_CCY,
                                          T(L).TAX_RATE);
    ICPKSS_UTIL.PR_GET_DAYS(FROM_DT,
                            TO_DT + 1,
                            '6',
                            DAYS,
                            MONTH,
                            YEAR,
                            FROM_DT,
                            TO_DT + 1);
    IF FORMULA2 > 0 THEN
      DUMMY := ICPKS_UTIL.fn_get_int_amt_rounded('PS07',
                                                 4,
                                                 p_acc,
                                                 p_prod,
                                                 gen_IS,
                                                 FORMULA2);
	--sampath starts
      FOR G IN c LOOP
      
        IF G.FRM_NO = 2 THEN
        
          L_ACCRUED := G.ACCRUED_AMT;
          EXIT;
        
        END IF;
      
      END LOOP;
      -- R_ENTRIES
    
      DBG('L_ACCRUED=' || L_ACCRUED);
    
      FORMULA2 := L_ACCRUED;
    
      DBG('FORMULA2=' || FORMULA2);
    
      --sampath ends  										 
      FORMULA4 := (FORMULA2 * (TAX_RATE / 100));
      T(L).FORMULA4 := (FORMULA2 * (TAX_RATE / 100));
      DUMMY := ICPKS_UTIL.fn_get_tax_amt_rounded('PS07',
                                                 4,
                                                 p_acc,
                                                 p_prod,
                                                 FORMULA4);
      T(L).FORMULA4 := FORMULA4;
    
      -- *****************************************
      -- VNDEAB SFR#1325 START OF CHANGES
      -- *****************************************
    
      X(NVL(X.LAST, 0) + 1).BRN := P_BRN;
      X(X.LAST).ACC := P_ACC;
      X(X.LAST).PROD := P_PROD;
      X(X.LAST).RUN_DT := GLOBAL.APPLICATION_DATE;
      X(X.LAST).RUN_SEQ := L_RUN_SEQ;
      X(X.LAST).A_OR_L := A_OR_L;
      X(X.LAST).EOC_FLAG := GLOBAL.branch_status;
      X(X.LAST).FRM_NO := 4;
      X(X.LAST).EXPR_LINE := 1;
      X(X.LAST).DS := T(L).DS;
      X(X.LAST).DS_VALUE := 'TAX_RATE|' || TAX_RATE || '~';
      X(X.LAST).FROM_DT := FROM_DT;
      X(X.LAST).TO_DT := TO_DT;
      X(X.LAST).COND_EXPR := 'FORMULA2>0';
      X(X.LAST).COND_VALUE := 'FORMULA2>0';
      X(X.LAST).COND_TS := '';
      X(X.LAST).RESULT_EXPR := '(FORMULA2*(TAX_RATE/100))';
      X(X.LAST).RESULT_VALUE := '(FORMULA2*({TAX_RATE = ' || TAX_RATE ||
                                '}/100))';
      X(X.LAST).RESULT_TS := 'TAX_RATE|' || TAX_RATE || '~';
      X(X.LAST).RESULT := T(L).FORMULA4;
    
      -- *****************************************
      -- VNDEAB SFR#1325 END OF CHANGES
      -- *****************************************
    
      FORMULA4 := FORMULA4 - NVL(ADJ_AMOUNT, 0);
      ADJ_AMOUNT := NULL;
      F(4) := FORMULA4;
    END IF;
  
    -- *****************************************
    -- VNDEAB SFR#1325 START OF CHANGES
    -- *****************************************
  
    IF X.COUNT > 0 THEN
      FORALL RW IN X.FIRST .. X.LAST
        INSERT INTO ICTBS_ICALC_STMT VALUES X (RW);
      X.DELETE;
    END IF;
  
    -- *****************************************
    -- VNDEAB SFR#1325 END OF CHANGES
    -- *****************************************
  
	ICPKSS_UTIL.dbg('NOW genERATING PERIODIC FORMULAE');		   
  END CALC_FRM;
  -- Store Formula values

BEGIN

  SAVEPOINT BEFORE_CALC; -- First Establish a Savepoint

  -- NULREC IS AN EMPTY ELEM_TAB RECORD USED FOR INITIALISING NEW ROWS
  NULREC.DS                    := NULL;
  NULREC.DAYS                  := NULL;
  NULREC.DEPOSIT_AMOUNT        := NULL;
  NULREC.PRO_SAVINGS_TOPUP_AMT := NULL;
  NULREC.YEAR                  := NULL;
  NULREC.INTEREST_RATE         := NULL;
  NULREC.TAX_RATE              := NULL;
  NULREC.TOPUP_EXTRA_RATE      := NULL;
  NULREC.FORMULA1              := NULL;
  NULREC.FORMULA2              := NULL;
  NULREC.FORMULA3              := NULL;
  NULREC.FORMULA4              := NULL;

  FRM_ATAB(1) := 0;
  FRM_LTAB(1) := 0;
  FRM_ATAB(2) := 0;
  FRM_LTAB(2) := 0;
  FRM_ATAB(3) := 0;
  FRM_LTAB(3) := 0;
  FRM_ATAB(4) := 0;
  FRM_LTAB(4) := 0;

  -- Now Get List of Turnover Elements
  ---------------------<Get Date From And Date To>-----------------------
  from_dt     := icpkss_calc.g_ictb_acc_pr.first_calc_dt;
  accr_dt     := icpkss_calc.g_ictb_acc_pr.next_accr_dt;
  liqn_dt     := icpkss_calc.g_ictb_acc_pr.next_liq_dt;
  def_liqn_dt := icpkss_calc.g_ictb_acc_pr.defer_liq_dt;
  sliq        := icpkss_calc.g_ictb_acc_pr.last_schd_liq_dt;
  fc_date     := icpkss_calc.g_ictb_acc_pr.first_calc_dt;
  acc_ccy     := icpkss_calc.g_cust_acc.ccy;
  if icpkss_calc.g_prod_rec.ude_ccy = 'ACY' then
    ude_ccy := acc_ccy;
  else
    ude_ccy := global.lcy;
  end if;
  CALC_LIQN := (LIQN_DT IS NOT NULL);
  CALC_ACCR := (ACCR_DT IS NOT NULL);
  IF CALC_ACCR AND CALC_LIQN THEN
    ACCR_DT := LEAST(ACCR_DT, LIQN_DT);
  END IF;
  IF ACCR_DT IS NULL AND LIQN_DT IS NULL THEN
    RETURN;
  END IF;
  IF ACCR_DT IS NULL THEN
    TO_DT := LIQN_DT;
  ELSIF LIQN_DT IS NULL THEN
    TO_DT := ACCR_DT;
  ELSE
    TO_DT := GREATEST(ACCR_DT, LIQN_DT);
  END IF;
  IF FC_DATE > TO_DT THEN
    RETURN;
  END IF;

  ATAB(0) := NULREC;
  LTAB(0) := NULREC;
  ATAB(0).DS := FROM_DT;
  LTAB(0).DS := FROM_DT;
  icpks_ude.pr_get_udevals(icpkss_calc.g_ictb_acc_pr.brn,
                           icpkss_calc.g_ictb_acc_pr.acc,
                           icpkss_calc.g_ictb_acc_pr.prod,
                           icpkss_calc.g_cust_acc.account_class ||
                           icpkss_calc.g_cust_acc.ccy,
                           from_dt,
                           to_dt,
                           liqn_dt,
                           icpkss_calc.g_ictb_acc_pr.sc_map_dt,
                           icpkss_calc.g_ictb_acc_pr.gc_map_dt,
                           l_udevals);
  jai := NULL;
  SR  := l_udevals.FIRST;
  WHILE sr <= l_udevals.LAST LOOP
  
    LOOP
      udestr   := icpkss_util.fn_get_next_param(l_udevals(sr).ude_vals, jai);
      pop_sep  := INSTR(udestr, '|', 1, 1);
      l_udeid  := SUBSTR(udestr, 1, pop_sep - 1);
      l_udeval := to_number(SUBSTR(udestr, pop_sep + 1));
      IF CALC_LIQN AND l_udevals(sr).ude_eff_dt <= liqn_dt THEN
        IF L_UDEID = 'INTEREST_RATE' THEN
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).INTEREST_RATE := l_udeval;
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        ELSIF L_UDEID = 'TAX_RATE' THEN
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).TAX_RATE := l_udeval;
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        ELSIF L_UDEID = 'TOPUP_EXTRA_RATE' THEN
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).TOPUP_EXTRA_RATE := l_udeval;
          LTAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        END IF;
      END IF;
      IF CALC_ACCR AND l_udevals(sr).ude_eff_dt <= accr_dt THEN
        l_udeval := to_number(SUBSTR(udestr, pop_sep + 1));
        IF L_UDEID = 'INTEREST_RATE' THEN
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).INTEREST_RATE := l_udeval;
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        ELSIF L_UDEID = 'TAX_RATE' THEN
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).TAX_RATE := l_udeval;
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        ELSIF L_UDEID = 'TOPUP_EXTRA_RATE' THEN
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).TOPUP_EXTRA_RATE := l_udeval;
          ATAB(l_udevals(sr).ude_eff_dt - from_dt).DS := l_udevals(sr)
                                                         .ude_eff_dt;
        END IF;
      END IF;
      EXIT WHEN jai = 0;
    END LOOP;
    sr := l_udevals.NEXT(sr);
  END LOOP;
  POP_SPL_ELEMS;

  IF FC_DATE > FROM_DT THEN
    TAB_IDX := FROM_DT - FC_DATE;
    IF CALC_ACCR THEN
      SETVAL(ATAB, NULL, TAB_IDX, NULL);
    END IF;
    IF CALC_LIQN THEN
      SETVAL(LTAB, NULL, TAB_IDX, NULL);
    END IF;
  END IF;
  IF CALC_LIQN THEN
    TO_DT_1   := LIQN_DT;
    LTAB_ROWS := LTAB.COUNT;
    FILL_VAL(LTAB);
  END IF;
  IF CALC_ACCR THEN
    TO_DT_1   := ACCR_DT;
    ATAB_ROWS := ATAB.COUNT;
    FILL_VAL(ATAB);
  END IF;

  ----------------------------------------------------------------------

  -- *****************************************
  -- VNDEAB SFR#1325 START OF CHANGES
  -- *****************************************

  IF Icpkss_test.g_bkval_calc THEN
    A_OR_L := 'B';
  ELSE
    A_OR_L := 'C';
  END IF;

  -- *****************************************
  -- VNDEAB SFR#1325 END OF CHANGES
  -- *****************************************
  IF CALC_LIQN THEN
    TO_DT := LIQN_DT;
    CALC_FRM(LTAB, FRM_LTAB, TRUE);
  END IF;
  IF CALC_ACCR THEN
    TO_DT := ACCR_DT;
    CALC_FRM(ATAB, FRM_ATAB, FALSE);
    TO_DT := nvl(LIQN_DT, ACCR_DT);
    IF CALC_LIQN THEN
	  --sampath starts
      ICPKSS_UTIL.DBG('BEFORE CALLIN CALC_DLY_AMT APPLE');
      --sampath ends												  												
      CALC_DLY_AMT(ATAB, LTAB, FRM_DTAB, NXT_CALC_DATE);
    END IF;
  END IF;
  ICPKSS_UTIL.dbg('CALCULATED');							 
  -- NOW PASS BOOKING ENTRIES

  jp := tb_icent.FIRST;
  WHILE jp <= tb_icent.LAST LOOP
    IF CALC_ACCR AND tb_icent(jp).FRM_NO IN (1, 2) THEN
		--sampath starts
      DBG('nvl(frm_atab(tb_icent(jp).frm_no), 0)=' ||
          nvl(frm_atab(tb_icent(jp).frm_no), 0));
      --sampath ends 												   
      tb_icent(jp).amt_to_accrue := nvl(frm_atab(tb_icent(jp).frm_no), 0);
	--sampath starts
      DBG('tb_icent(jp).amt_to_accrue=' || tb_icent(jp).amt_to_accrue);
      --sampath ends  					 
      IF CALC_LIQN THEN
		--sampath starts
        DBG('nvl(FRM_DTAB(tb_icent(jp).frm_no), 0)=' ||
            nvl(FRM_DTAB(tb_icent(jp).frm_no), 0));
        --sampath ends										 
        tb_icent(jp).daily_amt := nvl(FRM_DTAB(tb_icent(jp).frm_no), 0);
		--sampath starts
        DBG('tb_icent(jp).daily_amt=' || tb_icent(jp).daily_amt);
        --sampath ends 
      END IF;
    ELSE
      tb_icent(jp).amt_to_accrue := 0;
      tb_icent(jp).daily_amt := 0;
    END IF;
    tb_icent(jp).amt := nvl(FRM_LTAB(tb_icent(jp).frm_no), 0);
    tb_icent(jp).next_calc_due_date := nxt_calc_date;
    jp := tb_icent.NEXT(jp);
  END LOOP;
  ICPKSS_UTIL.dbg('FINISHED PS07');
  ----------------------------------------------------------------------

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK TO BEFORE_CALC; -- UNDO ALL CALCULATIONS SO FAR AND THEN BOMB
    RAISE_APPLICATION_ERROR(-20101, 'C3GF#_ICPR1_PS07-> ' || SQLERRM);
    ----------------------------------------------------------------------

END C3GF#_ICPR1_PS07;
