CREATE OR REPLACE PACKAGE BODY stpks_td_redemption_custom AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_td_redemption_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('IC', L_MSG);
  END DBG;

  PROCEDURE PR_BROKEN_TD(P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                         P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                         P_ERR_CODE       IN OUT VARCHAR2,
                         P_ERR_PARAM      IN OUT VARCHAR2,
                         P_FN_CALL_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA) IS
  BEGIN
    DBG('Start  of stpks_td_redemption_custom.PR_BROKEN_TD');

    DBG('End    of stpks_td_redemption_custom.PR_BROKEN_TD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.PR_BROKEN_TD' ||
          SQLERRM);
  END PR_BROKEN_TD;

  FUNCTION FN_BROKEN_PARTIAL_TD(P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                                P_ERR_CODE       IN OUT VARCHAR2,
                                P_ERR_PARAM      IN OUT VARCHAR2,
                                P_FN_CALL_ID     IN OUT NUMBER,
                                P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_td_redemption_custom.FN_BROKEN_PARTIAL_TD');

    DBG('End    of stpks_td_redemption_custom.FN_BROKEN_PARTIAL_TD');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_BROKEN_PARTIAL_TD' ||
          SQLERRM);
      RETURN FALSE;
  END FN_BROKEN_PARTIAL_TD;

  FUNCTION FN_MEMO_ACCRUAL(P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                           P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                           P_START_DATE     IN DATE,
                           P_END_DATE       IN DATE,
                           P_RULE           IN ICTM_PR_INT.RULE%TYPE,
                           P_PROD           IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                           P_MEMO_REC       IN OUT STPKS_TD_REDEMPTION.TY_MEMO_REC,
                           P_ERR_CODE       IN OUT VARCHAR2,
                           P_ERR_PARAM      IN OUT VARCHAR2,
                           P_FN_CALL_ID     IN OUT NUMBER,
                           P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_td_redemption_custom.Fn_Memo_Accrual');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.Fn_Memo_Accrual' ||
          SQLERRM);
      RETURN FALSE;
  END FN_MEMO_ACCRUAL;

  --Pro Savings Sampath Starts
  FUNCTION FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                                       P_TXN_REF_NO IN VARCHAR2,
                                                       --P_AMT_TAG    IN VARCHAR2,
                                                       --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                                       P_EVENT IN VARCHAR2,
                                                       --P_CR_GL      IN VARCHAR2,
                                                       --P_DR_GL      IN VARCHAR2,
                                                       P_BRN       IN VARCHAR2,
                                                       P_ACC       IN VARCHAR2,
                                                       P_CCY       IN VARCHAR2,
                                                       P_PROD      IN VARCHAR2,
                                                       P_ERR_CODE  IN OUT VARCHAR2,
                                                       P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    l_cavw_entries            cavw_entries%rowtype;
    L_REVERSE_EXTRA_ILIQ_AMTS ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                    VARCHAR2(1);
    tb_AccHandoff             acpkss.tbl_AcHoff;
    L_VALUE_DATE              DATE;
    RELATED_CUSTOMER          VARCHAR2(20);
    L_NETTING_INDICATOR       VARCHAR2(1);
    L_MIS_HEAD                VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS   ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY          STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG               NUMBER;
    L_EXCH_RATE               ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT              ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT              ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_12TH_LIQUIDATION_DATE   ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_24TH_LIQUIDATION_DATE   ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_CUST_ACCOUNT            STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN                    VARCHAR2(25);

    L_LIQUIDAITON_COUNT NUMBER := 0;

    L_OLD_MAT_DATE ICTM_TD_CLOSURE_RENEW.OLD_MAT_DATE%TYPE;

  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV');

    DBG('P_PROD=' || P_PROD);
    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts
    IF P_PROD IN ('PS01', 'PS02', 'PS03', 'PS04',
                  'PS05',
                  'PS06',
                  'PS07',
                  'PS08',
                  'PS09',
                  'PS10',
                  'PS11',
                  'PS12',
                  'PS13',
                  'PS14') THEN			  
      --PLS PUT IF BREAK LOGIC

      BEGIN
        SELECT A.OLD_MAT_DATE
          INTO L_OLD_MAT_DATE
          FROM ICTM_TD_CLOSURE_RENEW A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND SEQNO IN (SELECT MAX(SEQNO)
                           FROM ICTM_TD_CLOSURE_RENEW B
                          WHERE B.ACC = P_ACC
                            AND B.BRN = P_BRN);
      EXCEPTION
        WHEN OTHERS THEN
          L_OLD_MAT_DATE := NULL;
      END;

      DBG('L_OLD_MAT_DATE=' || L_OLD_MAT_DATE);

      IF L_OLD_MAT_DATE IS NOT NULL AND
         STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT IN ('I', 'P') --'P'
             AND PAYOUTTYPE = 'S'
             AND ROWNUM = 1;

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        DBG('L_PAYOUTCASA_CCY=' || L_PAYOUTCASA_CCY);

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

          DBG('INSIDE 60K PLAN ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '60K_PLAN_A';

          ELSE

            L_PLAN := '60K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '60K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN

          DBG('INSIDE 200K PLAN ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '200K_PLAN_A';

          ELSE

            L_PLAN := '200K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '200K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        END IF;

		IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS05', 'PS06') THEN
        
          DBG('INSIDE 100K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '100K_PLAN_A';
          
          ELSE
          
            L_PLAN := '100K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '100K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS07', 'PS08') THEN
        
          DBG('INSIDE 300K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '300K_PLAN_A';
          
          ELSE
          
            L_PLAN := '300K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '300K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS09', 'PS10') THEN
        
          DBG('INSIDE 600K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '600K_PLAN_A';
          
          ELSE
          
            L_PLAN := '600K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '600K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS11', 'PS12') THEN
        
          DBG('INSIDE 720K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '720K_PLAN_A';
          
          ELSE
          
            L_PLAN := '720K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '720K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
      
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS13', 'PS14') THEN
        
          DBG('INSIDE 1320K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '1320K_PLAN_A';
          
          ELSE
          
            L_PLAN := '1320K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '1320K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
		
		
        DBG('L_REVERSE_EXTRA_ILIQ_AMTS=' || L_REVERSE_EXTRA_ILIQ_AMTS);

        IF L_REVERSE_EXTRA_ILIQ_AMTS <= 0 THEN

          RETURN TRUE;

        END IF;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --USD AMOUNT
                                          'Y',
                                          L_FCY_AMOUNT, --KHR AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);
          DBG('GLOBAL.CURRENT_BRANCH=' || GLOBAL.CURRENT_BRANCH);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          GLOBAL.LCY, --USD TO GET LCY AMOUNT
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT NOTHING BUT FCY AMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT NOTHING BUT LCY AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        TB_ACCHANDOFF(1).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; -- '384000021'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished Debit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        --TB_ACCHANDOFF(2).AC_NO := '344330001'; --pls check

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          tb_AccHandoff(2).AC_NO := '623130001';--'344330001';

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          tb_AccHandoff(2).AC_NO := '623140001';--'344340001';

        END IF;

        TB_ACCHANDOFF(2).AC_CCY := P_CCY;-- L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE; --FIXED NOW

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished Credit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP LIQUIDATIONS FOR PRO-SAVINGS');

        END IF;

      ELSIF L_OLD_MAT_DATE IS NULL AND
            STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT IN ('I', 'P') --'P'
             AND PAYOUTTYPE = 'S'
             AND ROWNUM = 1;

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

          DBG('INSIDE 60K PLAN ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '60K_PLAN_A';

          ELSE

            L_PLAN := '60K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '60K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN

          DBG('INSIDE 200K PLAN ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '200K_PLAN_A';

          ELSE

            L_PLAN := '200K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '200K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        END IF;

		IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS05', 'PS06') THEN
        
          DBG('INSIDE 100K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '100K_PLAN_A';
          
          ELSE
          
            L_PLAN := '100K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '100K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS07', 'PS08') THEN
        
          DBG('INSIDE 300K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '300K_PLAN_A';
          
          ELSE
          
            L_PLAN := '300K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '300K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS09', 'PS10') THEN
        
          DBG('INSIDE 600K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '600K_PLAN_A';
          
          ELSE
          
            L_PLAN := '600K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '600K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS11', 'PS12') THEN
        
          DBG('INSIDE 720K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '720K_PLAN_A';
          
          ELSE
          
            L_PLAN := '720K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '720K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS13', 'PS14') THEN
        
          DBG('INSIDE 1320K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '1320K_PLAN_A';
          
          ELSE
          
            L_PLAN := '1320K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '1320K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRA_ILIQ_AMTS := 0;
              
            END;
          
          END IF;
        
        END IF;
		
        DBG('L_REVERSE_EXTRA_ILIQ_AMTS=' || L_REVERSE_EXTRA_ILIQ_AMTS);

        IF L_REVERSE_EXTRA_ILIQ_AMTS <= 0 THEN

          RETURN TRUE;

        END IF;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --USD AMOUNT
                                          'Y',
                                          L_FCY_AMOUNT, --KHR AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);
          DBG('GLOBAL.CURRENT_BRANCH=' || GLOBAL.CURRENT_BRANCH);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          GLOBAL.LCY, --USD TO GET LCY AMOUNT
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT NOTHING BUT FCY AMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT NOTHING BUT LCY AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        TB_ACCHANDOFF(1).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; -- '384000021'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished credit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        --TB_ACCHANDOFF(2).AC_NO := '344330001'; --pls check

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          tb_AccHandoff(2).AC_NO := '623130001';-- '344330001';

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          tb_AccHandoff(2).AC_NO := '623140001';-- '344340001';

        END IF;

        TB_ACCHANDOFF(2).AC_CCY := P_CCY;-- L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE; --FIXED NOW

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished debit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP LIQUIDATIONS FOR PRO-SAVINGS');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;



    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS_PRO_SAV;

  FUNCTION FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                             P_TXN_REF_NO IN VARCHAR2,
                                             --P_AMT_TAG    IN VARCHAR2,
                                             --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                             P_EVENT IN VARCHAR2,
                                             --P_CR_GL      IN VARCHAR2,
                                             --P_DR_GL      IN VARCHAR2,
                                             P_BRN                    IN VARCHAR2,
                                             P_ACC                    IN VARCHAR2,
                                             P_CCY                    IN VARCHAR2,
                                             P_PROD                   IN VARCHAR2,
                                             P_REVERSE_EXTRA_ACCRUALS IN ICTB_ENTRIES.ACCRUED_AMT%TYPE,
                                             P_ERR_CODE               IN OUT VARCHAR2,
                                             P_ERR_PARAM              IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    l_cavw_entries           cavw_entries%rowtype;
    L_REVERSE_TAX_AMOUNT     ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                   VARCHAR2(1);
    tb_AccHandoff            acpkss.tbl_AcHoff;
    L_VALUE_DATE             DATE;
    RELATED_CUSTOMER         VARCHAR2(20);
    L_NETTING_INDICATOR      VARCHAR2(1);
    L_MIS_HEAD               VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG              NUMBER;
    L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_ICTB_ACC_PR            ICTB_ACC_PR%ROWTYPE;
    L_REVERSE_EXTRA_ACCRUALS ICTB_ENTRIES.ACCRUED_AMT%TYPE;

    L_OLD_MAT_DATE ICTM_TD_CLOSURE_RENEW.OLD_MAT_DATE%TYPE;

  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV');

    DBG('P_PROD=' || P_PROD);
    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    IF P_PROD IN ('PS01', 'PS02', 'PS03', 'PS04',
        'PS05',
        'PS06',
        'PS07',
        'PS08',
        'PS09',
        'PS10',
        'PS11',
        'PS12',
        'PS13',
        'PS14') THEN

      DBG('INSIDE TD PRODUCT=' || P_PROD);
      DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
          STPKS_TD_REDEMPTION.pkg_penalty_apply);

      --PLS PUT IF BREAK LOGIC

      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Last Liquidation
        BEGIN
          SELECT *
            INTO L_ICTB_ACC_PR
            FROM ICTB_ACC_PR A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.CCY = P_CCY;
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTB_ACC_PR := NULL;
        END;

        DBG('LAST LIQUIDATION DATE=' || L_ICTB_ACC_PR.LAST_LIQ_DT);
        DBG('P_ACC=' || P_ACC);
        DBG('P_BRN=' || P_BRN);
        DBG('P_PROD=' || P_PROD);
        --Get Accrued Amount

        /*BEGIN
          SELECT NVL(A.ACCRUED_AMT, 0)
            INTO L_REVERSE_EXTRA_ACCRUALS
            FROM ICTB_ENTRIES A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.PROD = P_PROD
             AND A.FRM_NO = '2';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_REVERSE_EXTRA_ACCRUALS := 0;
        END;*/

        L_REVERSE_EXTRA_ACCRUALS := NVL(P_REVERSE_EXTRA_ACCRUALS, 0);

        DBG('APPLE');

        DBG('L_REVERSE_EXTRA_ACCRUALS=' || L_REVERSE_EXTRA_ACCRUALS);

        IF L_REVERSE_EXTRA_ACCRUALS <= 0 THEN

          RETURN TRUE;

        END IF;

        IF P_CCY = 'KHR' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --USD
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy,
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRA_ACCRUALS, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

        ELSIF P_CCY = 'USD' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'IACR'; --pls check
        TB_ACCHANDOFF(1).EVENT := 'IACR'; --pls check
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'CLX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        --TB_ACCHANDOFF(1).AC_NO := '344330001'; --debit  GL

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          TB_ACCHANDOFF(1).AC_NO := '344330001'; --Resident

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          tb_AccHandoff(1).AC_NO := '344340001'; --Non-Resident

        END IF;

        TB_ACCHANDOFF(1).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished credit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'IACR'; --pls check
        TB_ACCHANDOFF(2).EVENT := 'IACR'; --pls check
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'CLX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          TB_ACCHANDOFF(2).AC_NO := '623130001';

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          tb_AccHandoff(2).AC_NO := '623140001';

        END IF;

        TB_ACCHANDOFF(2).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished debit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA ACCRUALS FOR PRO-SAVINGS');

        END IF;


        RETURN TRUE;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_ACCRUALS_PRO_SAV;

  FUNCTION FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV( --P_TXN_CODE   IN VARCHAR2,
                                              P_TXN_REF_NO IN VARCHAR2,
                                              --P_AMT_TAG    IN VARCHAR2,
                                              --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                              P_EVENT IN VARCHAR2,
                                              --P_CR_GL      IN VARCHAR2,
                                              --P_DR_GL      IN VARCHAR2,
                                              P_BRN       IN VARCHAR2,
                                              P_ACC       IN VARCHAR2,
                                              P_CCY       IN VARCHAR2,
                                              P_PROD      IN VARCHAR2,
                                              P_ERR_CODE  IN OUT VARCHAR2,
                                              P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    l_cavw_entries           cavw_entries%rowtype;
    L_REVERSE_EXTRATOPUP_TAX ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                   VARCHAR2(1);
    tb_AccHandoff            acpkss.tbl_AcHoff;
    L_VALUE_DATE             DATE;
    RELATED_CUSTOMER         VARCHAR2(20);
    L_NETTING_INDICATOR      VARCHAR2(1);
    L_MIS_HEAD               VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG              NUMBER;
    L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_CUST_ACCOUNT           STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN                   VARCHAR2(25);
    L_12TH_LIQUIDATION_DATE  ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_24TH_LIQUIDATION_DATE  ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

    L_LIQUIDAITON_COUNT NUMBER := 0;

    L_OLD_MAT_DATE ICTM_TD_CLOSURE_RENEW.OLD_MAT_DATE%TYPE;

  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV');

    DBG('P_PROD=' || P_PROD);

    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts

    IF P_PROD IN ('PS01', 'PS02', 'PS03', 'PS04',
        'PS05',
        'PS06',
        'PS07',
        'PS08',
        'PS09',
        'PS10',
        'PS11',
        'PS12',
        'PS13',
        'PS14') THEN									 
      --PLS PUT IF BREAK LOGIC

      BEGIN
        SELECT A.OLD_MAT_DATE
          INTO L_OLD_MAT_DATE
          FROM ICTM_TD_CLOSURE_RENEW A
         WHERE A.ACC = P_ACC
           AND A.BRN = P_BRN
           AND SEQNO IN (SELECT MAX(SEQNO)
                           FROM ICTM_TD_CLOSURE_RENEW B
                          WHERE B.ACC = P_ACC
                            AND B.BRN = P_BRN);
      EXCEPTION
        WHEN OTHERS THEN
          L_OLD_MAT_DATE := NULL;
      END;

      DBG('L_OLD_MAT_DATE=' || L_OLD_MAT_DATE);

      IF L_OLD_MAT_DATE IS NOT NULL AND
         STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '60K_PLAN_A';

          ELSE

            L_PLAN := '60K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '60K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '200K_PLAN_A';

          ELSE

            L_PLAN := '200K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '200K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        END IF;

		IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS05', 'PS06') THEN
        
          DBG('INSIDE 100K_PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '100K_PLAN_A';
          
          ELSE
          
            L_PLAN := '100K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '100K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS07', 'PS08') THEN
        
          DBG('INSIDE 300K_PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '300K_PLAN_A';
          
          ELSE
          
            L_PLAN := '300K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '300K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS09', 'PS10') THEN
        
          DBG('INSIDE 600K_PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '600K_PLAN_A';
          
          ELSE
          
            L_PLAN := '600K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '600K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS11', 'PS12') THEN
        
          DBG('INSIDE 720K_PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '720K_PLAN_A';
          
          ELSE
          
            L_PLAN := '720K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '720K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS13', 'PS14') THEN
        
          DBG('INSIDE 1320K_PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                       AND A.trn_dt > L_OLD_MAT_DATE
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '1320K_PLAN_A';
          
          ELSE
          
            L_PLAN := '1320K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '1320K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                         AND A.trn_dt > L_OLD_MAT_DATE
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE
                 AND A.trn_dt > L_OLD_MAT_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.trn_dt > L_OLD_MAT_DATE;
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;													 
        DBG('L_REVERSE_EXTRATOPUP_TAX=' || L_REVERSE_EXTRATOPUP_TAX);

        IF L_REVERSE_EXTRATOPUP_TAX <= 0 THEN

          RETURN TRUE;

        END IF;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT IN ('I', 'P') --'P'
             AND PAYOUTTYPE = 'S'
             AND ROWNUM = 1;

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --USD amount
                                          'Y',
                                          L_FCY_AMOUNT, --KHR amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy, --usd to get lcy amount
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRATOPUP_TAX, --KHR amount nothing but FCY Amount
                                          'Y',
                                          L_LCY_AMOUNT, --USD amount nothing but LCY Amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000021'; --debit TAX GL resident

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000022'; --debit TAX GL non-resident

        END IF;

        /*IF P_PROD IN ('PS01', 'PS03') THEN

          tb_AccHandoff(1).AC_NO := '623130001';

        ELSIF P_PROD IN ('PS02', 'PS04') THEN

          tb_AccHandoff(1).AC_NO := '623140001';

        END IF;*/

        TB_ACCHANDOFF(1).AC_CCY := P_CCY;--L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT; --fixed now
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished credit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN;

        TB_ACCHANDOFF(2).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; --Credit CASA

        TB_ACCHANDOFF(2).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished debit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP_TAX FOR PRO-SAVINGS');

        END IF;



        RETURN TRUE;

      ELSIF L_OLD_MAT_DATE IS NULL AND
            STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS01', 'PS02') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '60K_PLAN_A';

          ELSE

            L_PLAN := '60K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '60K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        END IF;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS03', 'PS04') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := '200K_PLAN_A';

          ELSE

            L_PLAN := '200K_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = '200K_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        END IF;
		
		IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS05', 'PS06') THEN
        
          DBG('INSIDE 100K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '100K_PLAN_A';
          
          ELSE
          
            L_PLAN := '100K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '100K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS07', 'PS08') THEN
        
          DBG('INSIDE 300K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '300K_PLAN_A';
          
          ELSE
          
            L_PLAN := '300K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '300K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS09', 'PS10') THEN
        
          DBG('INSIDE 600K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '600K_PLAN_A';
          
          ELSE
          
            L_PLAN := '600K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '600K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS11', 'PS12') THEN
        
          DBG('INSIDE 720K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '720K_PLAN_A';
          
          ELSE
          
            L_PLAN := '720K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '720K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;
        
        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('PS13', 'PS14') THEN
        
          DBG('INSIDE 1320K PLAN ACCOUNT CLASS');
        
          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT
            
              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION
          
            WHEN OTHERS THEN
            
              L_LIQUIDAITON_COUNT := 0;
            
          END;
        
          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN
          
            L_PLAN := '1320K_PLAN_A';
          
          ELSE
          
            L_PLAN := '1320K_PLAN_B';
          
          END IF;
        
          DBG('L_PLAN=' || L_PLAN);
        
          IF L_PLAN = '1320K_PLAN_B' THEN
            --which means crossed 12 liquidations
          
            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;
          
            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          ELSE
          
            BEGIN
            
              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';
            
            EXCEPTION
            
              WHEN OTHERS THEN
              
                L_REVERSE_EXTRATOPUP_TAX := 0;
              
            END;
          
          END IF;
        
        END IF;												 
        DBG('L_REVERSE_EXTRATOPUP_TAX=' || L_REVERSE_EXTRATOPUP_TAX);

        IF L_REVERSE_EXTRATOPUP_TAX <= 0 THEN

          RETURN TRUE;

        END IF;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT IN ('I', 'P') --'P'
             AND PAYOUTTYPE = 'S'
             AND ROWNUM = 1;

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC);
        DBG('L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN=' ||
            L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN);

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --USD amount
                                          'Y',
                                          L_FCY_AMOUNT, --KHR amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy, --usd to get lcy amount
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRATOPUP_TAX, --KHR amount nothing but FCY Amount
                                          'Y',
                                          L_LCY_AMOUNT, --USD amount nothing but LCY Amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        IF P_PROD IN ('PS01', 'PS03', 'PS05', 'PS07', 'PS09', 'PS11', 'PS13') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000021'; --debit TAX GL resident

        ELSIF P_PROD IN ('PS02', 'PS04', 'PS06', 'PS08', 'PS10', 'PS12', 'PS14') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000022'; --debit TAX GL non-resident

        END IF;

        /*IF P_PROD IN ('PS01', 'PS03') THEN

          tb_AccHandoff(1).AC_NO := '623130001';

        ELSIF P_PROD IN ('PS02', 'PS04') THEN

          tb_AccHandoff(1).AC_NO := '623140001';

        END IF;*/

        TB_ACCHANDOFF(1).AC_CCY := P_CCY;--L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT; --fixed now
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished credit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN;

        TB_ACCHANDOFF(2).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; --Credit CASA

        TB_ACCHANDOFF(2).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished debit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP_TAX FOR PRO-SAVINGS');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_TOPUP_TAX_PRO_SAV;

  --Pro Savings Sampath Ends

  --clever savings sampath starts

  FUNCTION FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS( --P_TXN_CODE   IN VARCHAR2,
                                               P_TXN_REF_NO IN VARCHAR2,
                                               --P_AMT_TAG    IN VARCHAR2,
                                               --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                               P_EVENT IN VARCHAR2,
                                               --P_CR_GL      IN VARCHAR2,
                                               --P_DR_GL      IN VARCHAR2,
                                               P_BRN       IN VARCHAR2,
                                               P_ACC       IN VARCHAR2,
                                               P_CCY       IN VARCHAR2,
                                               P_PROD      IN VARCHAR2,
                                               P_ERR_CODE  IN OUT VARCHAR2,
                                               P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    --sampath starts
    l_cavw_entries            cavw_entries%rowtype;
    L_REVERSE_EXTRA_ILIQ_AMTS ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                    VARCHAR2(1);
    tb_AccHandoff             acpkss.tbl_AcHoff;
    L_VALUE_DATE              DATE;
    RELATED_CUSTOMER          VARCHAR2(20);
    L_NETTING_INDICATOR       VARCHAR2(1);
    L_MIS_HEAD                VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS   ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY          STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG               NUMBER;
    L_EXCH_RATE               ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT              ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT              ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_12TH_LIQUIDATION_DATE   ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_24TH_LIQUIDATION_DATE   ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_CUST_ACCOUNT            STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN                    VARCHAR2(25);

    L_LIQUIDAITON_COUNT NUMBER := 0;

    --sampath ends
  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS');

    DBG('P_PROD=' || P_PROD);
    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts
    IF P_PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      --PLS PUT IF BREAK LOGIC

      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN

          DBG('INSIDE SILVER ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := 'SILVER_PLAN_A';

          ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE > 366

                                                                                      AND
                                                                                      GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 731*/
           L_LIQUIDAITON_COUNT >= 12 AND L_LIQUIDAITON_COUNT < 24 THEN

            L_PLAN := 'SILVER_PLAN_B';

          ELSE

            L_PLAN := 'SILVER_PLAN_C';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = 'SILVER_PLAN_C' THEN
            --which means crossed 24 liquidations

            --Get 24th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_24TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --USD
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.ac_no = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 24; --24th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_24TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_24TH_LIQUIDATION_DATE=' || L_24TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    -- A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_24TH_LIQUIDATION_DATE; --Greater than 24th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSIF L_PLAN = 'SILVER_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --USD
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          DBG('L_LIQUIDAITON_COUNT=' || L_LIQUIDAITON_COUNT);

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := 'GOLD_PLAN_A';

          ELSE

            L_PLAN := 'GOLD_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = 'GOLD_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    ---A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRA_ILIQ_AMTS
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'ILIQ'
                 AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
                 AND A.drcr_ind = 'C';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRA_ILIQ_AMTS := 0;

            END;

          END IF;

        ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

          DBG('INSIDE RUBY ACCOUNT CLASS');

          BEGIN

            SELECT DECODE(P_CCY,
                          'USD',
                          NVL(SUM(A.LCY_AMOUNT), 0),
                          NVL(SUM(A.FCY_AMOUNT), 0))
              INTO L_REVERSE_EXTRA_ILIQ_AMTS
              FROM CAVW_ENTRIES A
             WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                  --A.RELATED_ACCOUNT = P_ACC)
               AND A.PRODUCT = P_PROD
               AND A.EVENT = 'ILIQ'
               AND A.AMOUNT_TAG = 'ILIQ'
               AND A.TRN_CODE = 'PTP' --TOP UP EXTRA RATE LIQUIDATION
               AND A.drcr_ind = 'C';

          EXCEPTION

            WHEN OTHERS THEN

              L_REVERSE_EXTRA_ILIQ_AMTS := 0;

          END;

        END IF;

        DBG('L_REVERSE_EXTRA_ILIQ_AMTS=' || L_REVERSE_EXTRA_ILIQ_AMTS);

        IF L_REVERSE_EXTRA_ILIQ_AMTS <= 0 THEN

          RETURN TRUE;

        END IF;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --USD AMOUNT
                                          'Y',
                                          L_FCY_AMOUNT, --KHR AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);
          DBG('GLOBAL.CURRENT_BRANCH=' || GLOBAL.CURRENT_BRANCH);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT CYPKSS.FN_AMT1_TO_AMT2(GLOBAL.CURRENT_BRANCH,
                                          P_CCY,
                                          GLOBAL.LCY, --USD TO GET LCY AMOUNT
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRA_ILIQ_AMTS, --KHR AMOUNT NOTHING BUT FCY AMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --USD AMOUNT NOTHING BUT LCY AMOUNT
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.PR_DEBUG('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ILIQ_AMTS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        TB_ACCHANDOFF(1).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; -- '384000021'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished Debit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'ILIQ';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'PTP'; --'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        --TB_ACCHANDOFF(2).AC_NO := '344330001'; --pls check

        IF P_PROD IN ('RY01') THEN

          tb_AccHandoff(2).AC_NO := '623110001'; --'344310001'; --fixed during pro savings for clever savings

        ELSIF P_PROD IN ('RY02') THEN

          tb_AccHandoff(2).AC_NO := '623120001'; --'344320001'; --fixed during pro savings for clever savings

        ELSIF P_PROD IN ('SY01', 'GY01') THEN

          TB_ACCHANDOFF(2).AC_NO := '623130001'; --'344330001'; --debit TAX GL --fixed during pro savings for clever savings

        ELSIF P_PROD IN ('SY02', 'GY02') THEN

          TB_ACCHANDOFF(2).AC_NO := '623140001'; --'344340001'; --fixed during pro savings for clever savings

        END IF;

        TB_ACCHANDOFF(2).AC_CCY := P_CCY; --L_PAYOUTCASA_CCY; --fixed during pro savings for clever savings

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;  --FIXED NOW

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished Credit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP LIQUIDATIONS');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_TOPUP_LIQUIDATIONS;

  FUNCTION FN_REVERSE_EXTRA_ACCRUALS1(P_TXN_REF_NO IN VARCHAR2,
                                      P_AMT_TAG    IN VARCHAR2,
                                      P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                      P_EVENT      IN VARCHAR2,

                                      P_BRN       IN VARCHAR2,
                                      P_ACC       IN VARCHAR2,
                                      P_CCY       IN VARCHAR2,
                                      P_PROD      IN VARCHAR2,
                                      P_ERR_CODE  IN OUT VARCHAR2,
                                      P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    --sampath starts
    l_cavw_entries           cavw_entries%rowtype;
    L_REVERSE_TAX_AMOUNT     ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                   VARCHAR2(1);
    tb_AccHandoff            acpkss.tbl_AcHoff;
    L_VALUE_DATE             DATE;
    RELATED_CUSTOMER         VARCHAR2(20);
    L_NETTING_INDICATOR      VARCHAR2(1);
    L_MIS_HEAD               VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG              NUMBER;
    L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_ICTB_ACC_PR            ICTB_ACC_PR%ROWTYPE;
    L_REVERSE_EXTRA_ACCRUALS ICTB_ENTRIES.ACCRUED_AMT%TYPE;
    --sampath ends
  BEGIN
    DBG('Start  of stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS1');

    DBG('P_PROD=' || P_PROD);
    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts

    IF P_PROD IN ('SY01', 'SY02') THEN

      DBG('INSIDE TD PRODUCT=' || P_PROD);
      DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
          STPKS_TD_REDEMPTION.pkg_penalty_apply);

      --PLS PUT IF BREAK LOGIC

      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Last Liquidation
        BEGIN
          SELECT *
            INTO L_ICTB_ACC_PR
            FROM ICTB_ACC_PR A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.CCY = P_CCY;
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTB_ACC_PR := NULL;
        END;

        DBG('LAST LIQUIDATION DATE=' || L_ICTB_ACC_PR.LAST_LIQ_DT);

        --Get Accrued Amount

        BEGIN

          --this is only current month accruals as it will become zero after every liquidation
          SELECT --NVL(SUM(LCY_AMOUNT), 0)
           NVL(A.ACCRUED_AMT, 0)
            INTO L_REVERSE_EXTRA_ACCRUALS --system will do all entries as zero in stpks_stdtdtop_utils package
            FROM ICTB_ENTRIES A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.PROD = P_PROD
             AND A.FRM_NO = '2';

        EXCEPTION

          WHEN OTHERS THEN

            L_REVERSE_EXTRA_ACCRUALS := 0;

        END;

        DBG('L_REVERSE_EXTRA_ACCRUALS=' || L_REVERSE_EXTRA_ACCRUALS);

        IF P_CCY = 'KHR' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRA_ACCRUALS, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

        ELSIF P_CCY = 'USD' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := P_AMT_TAG;
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        TB_ACCHANDOFF(1).AC_NO := '344310001'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished debit leg');

        SELECT DECODE(SIGN(P_TAG_AMT), 1, 'D', 'C') INTO L_DRCR FROM DUAL;

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := P_AMT_TAG;
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'TCS'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        TB_ACCHANDOFF(2).AC_NO := '623110001';

        TB_ACCHANDOFF(2).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished credit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA ACCRUALS1');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS1' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_ACCRUALS1;

  FUNCTION FN_REVERSE_EXTRA_ACCRUALS( --P_TXN_CODE   IN VARCHAR2,
                                     P_TXN_REF_NO IN VARCHAR2,
                                     --P_AMT_TAG    IN VARCHAR2,
                                     --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                     P_EVENT IN VARCHAR2,
                                     --P_CR_GL      IN VARCHAR2,
                                     --P_DR_GL      IN VARCHAR2,
                                     P_BRN                    IN VARCHAR2,
                                     P_ACC                    IN VARCHAR2,
                                     P_CCY                    IN VARCHAR2,
                                     P_PROD                   IN VARCHAR2,
                                     P_REVERSE_EXTRA_ACCRUALS IN ICTB_ENTRIES.ACCRUED_AMT%TYPE,
                                     P_ERR_CODE               IN OUT VARCHAR2,
                                     P_ERR_PARAM              IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    --sampath starts
    l_cavw_entries           cavw_entries%rowtype;
    L_REVERSE_TAX_AMOUNT     ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                   VARCHAR2(1);
    tb_AccHandoff            acpkss.tbl_AcHoff;
    L_VALUE_DATE             DATE;
    RELATED_CUSTOMER         VARCHAR2(20);
    L_NETTING_INDICATOR      VARCHAR2(1);
    L_MIS_HEAD               VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG              NUMBER;
    L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_ICTB_ACC_PR            ICTB_ACC_PR%ROWTYPE;
    L_REVERSE_EXTRA_ACCRUALS ICTB_ENTRIES.ACCRUED_AMT%TYPE;
    --sampath ends
  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS');

    DBG('P_PROD=' || P_PROD);
    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts

    IF P_PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      DBG('INSIDE TD PRODUCT=' || P_PROD);
      DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
          STPKS_TD_REDEMPTION.pkg_penalty_apply);

      --PLS PUT IF BREAK LOGIC

      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Last Liquidation
        BEGIN
          SELECT *
            INTO L_ICTB_ACC_PR
            FROM ICTB_ACC_PR A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.CCY = P_CCY;
        EXCEPTION
          WHEN OTHERS THEN
            L_ICTB_ACC_PR := NULL;
        END;

        DBG('LAST LIQUIDATION DATE=' || L_ICTB_ACC_PR.LAST_LIQ_DT);
        DBG('P_ACC=' || P_ACC);
        DBG('P_BRN=' || P_BRN);
        DBG('P_PROD=' || P_PROD);
        --Get Accrued Amount

        /*BEGIN
          SELECT NVL(A.ACCRUED_AMT, 0)
            INTO L_REVERSE_EXTRA_ACCRUALS
            FROM ICTB_ENTRIES A
           WHERE A.ACC = P_ACC
             AND A.BRN = P_BRN
             AND A.PROD = P_PROD
             AND A.FRM_NO = '2';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            L_REVERSE_EXTRA_ACCRUALS := 0;
        END;*/

        L_REVERSE_EXTRA_ACCRUALS := NVL(P_REVERSE_EXTRA_ACCRUALS, 0);

        DBG('APPLE');

        DBG('L_REVERSE_EXTRA_ACCRUALS=' || L_REVERSE_EXTRA_ACCRUALS);

        IF L_REVERSE_EXTRA_ACCRUALS <= 0 THEN

          RETURN TRUE;

        END IF;

        IF P_CCY = 'KHR' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate
          IF NOT CYPKS.FN_GETRATE(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --USD
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy,
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRA_ACCRUALS, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

        ELSIF P_CCY = 'USD' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);

          --Get Rate

          L_LCY_AMOUNT := L_REVERSE_EXTRA_ACCRUALS;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'IACR'; --pls check
        TB_ACCHANDOFF(1).EVENT := 'IACR'; --pls check
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'CLX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        --TB_ACCHANDOFF(1).AC_NO := '344330001'; --debit  GL

        IF P_PROD IN ('RY01') THEN

          TB_ACCHANDOFF(1).AC_NO := '344310001';

        ELSIF P_PROD IN ('RY02') THEN

          tb_AccHandoff(1).AC_NO := '344320001';

        ELSIF P_PROD IN ('SY01', 'GY01') THEN

          tb_AccHandoff(1).AC_NO := '344330001';

        ELSIF P_PROD IN ('SY02', 'GY02') THEN

          tb_AccHandoff(1).AC_NO := '344340001';

        END IF;


        TB_ACCHANDOFF(1).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished debit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'IACR'; --pls check
        TB_ACCHANDOFF(2).EVENT := 'IACR'; --pls check
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'CLX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := P_BRN;

        IF P_PROD IN ('RY01') THEN

          TB_ACCHANDOFF(2).AC_NO := '623110001';

        ELSIF P_PROD IN ('RY02') THEN

          tb_AccHandoff(2).AC_NO := '623120001';

        ELSIF P_PROD IN ('SY01', 'GY01') THEN

          tb_AccHandoff(2).AC_NO := '623130001';

        ELSIF P_PROD IN ('SY02', 'GY02') THEN

          tb_AccHandoff(2).AC_NO := '623140001';

        END IF;

        TB_ACCHANDOFF(2).AC_CCY := P_CCY;

        IF P_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished credit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA ACCRUALS');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_ACCRUALS' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_ACCRUALS;

  FUNCTION FN_REVERSE_EXTRA_TOPUP_TAX( --P_TXN_CODE   IN VARCHAR2,
                                      P_TXN_REF_NO IN VARCHAR2,
                                      --P_AMT_TAG    IN VARCHAR2,
                                      --P_TAG_AMT    IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                                      P_EVENT IN VARCHAR2,
                                      --P_CR_GL      IN VARCHAR2,
                                      --P_DR_GL      IN VARCHAR2,
                                      P_BRN       IN VARCHAR2,
                                      P_ACC       IN VARCHAR2,
                                      P_CCY       IN VARCHAR2,
                                      P_PROD      IN VARCHAR2,
                                      P_ERR_CODE  IN OUT VARCHAR2,
                                      P_ERR_PARAM IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    --sampath starts
    l_cavw_entries           cavw_entries%rowtype;
    L_REVERSE_EXTRATOPUP_TAX ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_DRCR                   VARCHAR2(1);
    tb_AccHandoff            acpkss.tbl_AcHoff;
    L_VALUE_DATE             DATE;
    RELATED_CUSTOMER         VARCHAR2(20);
    L_NETTING_INDICATOR      VARCHAR2(1);
    L_MIS_HEAD               VARCHAR2(20);
    L_ICTM_TDPAYOUT_DETAILS  ICTM_TDPAYOUT_DETAILS%ROWTYPE;
    L_PAYOUTCASA_CCY         STTM_CUST_ACCOUNT.CCY%TYPE;
    L_RATE_FLAG              NUMBER;
    L_EXCH_RATE              ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_LCY_AMOUNT             ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_FCY_AMOUNT             ACTB_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_CUST_ACCOUNT           STTM_CUST_ACCOUNT%ROWTYPE;
    L_PLAN                   VARCHAR2(25);
    L_12TH_LIQUIDATION_DATE  ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;
    L_24TH_LIQUIDATION_DATE  ICTB_ACC_PR.NEXT_LIQ_DT%TYPE;

    L_LIQUIDAITON_COUNT NUMBER := 0;
    --sampath ends
  BEGIN
    DBG('Start of stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_TAX');

    DBG('P_PROD=' || P_PROD);

    DBG('STPKS_TD_REDEMPTION.pkg_penalty_apply=' ||
        STPKS_TD_REDEMPTION.pkg_penalty_apply);

    --sampath starts

    IF P_PROD IN ('SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') THEN

      --PLS PUT IF BREAK LOGIC

      IF STPKS_TD_REDEMPTION.pkg_penalty_apply = 1 THEN

        DBG('tdpks_utils.g_accr_adj_stdt=' || TDPKS_UTILS.G_ACCR_ADJ_STDT);
        DBG('global.application_Date=' || GLOBAL.APPLICATION_DATE);
        L_VALUE_DATE := NVL(TDPKS_UTILS.G_ACCR_ADJ_STDT,
                            GLOBAL.APPLICATION_DATE);
        DBG('Value date - ' || L_VALUE_DATE);

        DBG('P_ACC=' || P_ACC);
        DBG('P_CCY=' || P_CCY);
        DBG('P_BRN=' || P_BRN);

        L_NETTING_INDICATOR := 'N'; --NVL(PKG_LOOKUP(1).NETIND, 'N');
        L_MIS_HEAD          := NULL; --PKG_LOOKUP(1).MIS_HEAD;

        --Get Account class of the TD Account
        BEGIN

          SELECT *
            INTO L_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = P_ACC
             AND A.BRANCH_CODE = P_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A';

        EXCEPTION
          WHEN OTHERS THEN
            L_CUST_ACCOUNT := NULL;
        END;

        IF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('SY01', 'SY02') THEN

          DBG('INSIDE SILVER ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN

          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := 'SILVER_PLAN_A';

          ELSIF /*GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE > 366

                                                                                      AND
                                                                                      GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 731*/
           L_LIQUIDAITON_COUNT >= 12 AND L_LIQUIDAITON_COUNT < 24 THEN

            L_PLAN := 'SILVER_PLAN_B';

          ELSE

            L_PLAN := 'SILVER_PLAN_C';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = 'SILVER_PLAN_C' THEN
            --which means crossed 24 liquidations

            --Get 24th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_24TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.ac_no = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 24; --24th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_24TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_24TH_LIQUIDATION_DATE=' || L_24TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_24TH_LIQUIDATION_DATE; --Greater than 24th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSIF L_PLAN = 'SILVER_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('GY01', 'GY02') THEN

          DBG('INSIDE GOLD ACCOUNT CLASS');

          BEGIN
            SELECT count(1)
              INTO L_LIQUIDAITON_COUNT

              FROM (SELECT ROWNUM rn,
                           A.trn_dt,
                           DECODE(L_CUST_ACCOUNT.CCY, --'USD',
                                  'USD',
                                  NVL(SUM(A.LCY_AMOUNT), 0),
                                  NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                      FROM CAVW_ENTRIES A
                     WHERE A.ac_no = P_ACC
                       AND A.PRODUCT = L_CUST_ACCOUNT.ACCOUNT_CLASS
                       AND A.EVENT = 'ILIQ'
                       AND A.AMOUNT_TAG = 'ILIQ'
                       AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                       AND A.drcr_ind = 'C'
                     GROUP BY ROWNUM, A.TRN_DT
                     ORDER BY TRN_DT);
          EXCEPTION

            WHEN OTHERS THEN

              L_LIQUIDAITON_COUNT := 0;

          END;

          --check if we are in the first year plan or second year plan or third year plan
          --IF GLOBAL.application_date - L_CUST_ACCOUNT.AC_OPEN_DATE <= 366 THEN
          IF L_LIQUIDAITON_COUNT < 12 THEN

            L_PLAN := 'GOLD_PLAN_A';

          ELSE

            L_PLAN := 'GOLD_PLAN_B';

          END IF;

          DBG('L_PLAN=' || L_PLAN);

          IF L_PLAN = 'GOLD_PLAN_B' THEN
            --which means crossed 12 liquidations

            --Get 12th liquidation date
            BEGIN
              SELECT TRN_DT
                INTO L_12TH_LIQUIDATION_DATE
                FROM (SELECT ROWNUM rn,
                             A.trn_dt,
                             DECODE(P_CCY, --'USD',
                                    'USD',
                                    NVL(SUM(A.LCY_AMOUNT), 0),
                                    NVL(SUM(A.FCY_AMOUNT), 0)) --, TRN_DT + 1
                        FROM CAVW_ENTRIES A
                       WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND --'000115328'
                            --A.RELATED_ACCOUNT = P_ACC) --'000115356'
                         AND A.PRODUCT = P_PROD
                         AND A.EVENT = 'ILIQ'
                         AND A.AMOUNT_TAG = 'ILIQ'
                         AND A.TRN_CODE = 'PRC' --Get normal basic TD details
                         AND A.drcr_ind = 'C'
                       GROUP BY ROWNUM, A.TRN_DT
                       ORDER BY TRN_DT)
               WHERE RN = 12; --12th liquidation
            EXCEPTION
              WHEN OTHERS THEN
                L_12TH_LIQUIDATION_DATE := NULL;
            END;

            DBG('L_12TH_LIQUIDATION_DATE=' || L_12TH_LIQUIDATION_DATE);

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D'
                 AND A.TRN_DT > L_12TH_LIQUIDATION_DATE; --Greater than 12th liquidation

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          ELSE

            BEGIN

              SELECT DECODE(P_CCY,
                            'USD',
                            NVL(SUM(A.LCY_AMOUNT), 0),
                            NVL(SUM(A.FCY_AMOUNT), 0))
                INTO L_REVERSE_EXTRATOPUP_TAX
                FROM CAVW_ENTRIES A
               WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                    --A.RELATED_ACCOUNT = P_ACC)
                 AND A.PRODUCT = P_PROD
                 AND A.EVENT = 'ILIQ'
                 AND A.AMOUNT_TAG = 'TAX'
                 AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
                 AND A.drcr_ind = 'D';

            EXCEPTION

              WHEN OTHERS THEN

                L_REVERSE_EXTRATOPUP_TAX := 0;

            END;

          END IF;

        ELSIF L_CUST_ACCOUNT.ACCOUNT_CLASS IN ('RY01', 'RY02') THEN

          DBG('INSIDE RUBY ACCOUNT CLASS');

          BEGIN

            SELECT DECODE(P_CCY,
                          'USD',
                          NVL(SUM(A.LCY_AMOUNT), 0),
                          NVL(SUM(A.FCY_AMOUNT), 0))
              INTO L_REVERSE_EXTRATOPUP_TAX
              FROM CAVW_ENTRIES A
             WHERE A.AC_NO = P_ACC --(A.AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC AND
                  --A.RELATED_ACCOUNT = P_ACC)
               AND A.PRODUCT = P_PROD
               AND A.EVENT = 'ILIQ'
               AND A.AMOUNT_TAG = 'TAX'
               AND A.TRN_CODE = 'TCX' --TOP UP EXTRA TAX
               AND A.drcr_ind = 'D';

          EXCEPTION

            WHEN OTHERS THEN

              L_REVERSE_EXTRATOPUP_TAX := 0;

          END;

        END IF;

        DBG('L_REVERSE_EXTRATOPUP_TAX=' || L_REVERSE_EXTRATOPUP_TAX);

        IF L_REVERSE_EXTRATOPUP_TAX <= 0 THEN

          RETURN TRUE;

        END IF;

        --Get TD Payout CASA ACCOUNT Details
        BEGIN

          SELECT *
            INTO L_ICTM_TDPAYOUT_DETAILS
            FROM ICTM_TDPAYOUT_DETAILS A
           WHERE A.ACC = P_ACC
             AND PAYOUT_COMPONENT = 'P'
             AND PAYOUTTYPE = 'S';

        EXCEPTION
          WHEN OTHERS THEN
            L_ICTM_TDPAYOUT_DETAILS := NULL;
        END;

        --Get TD Payout CASA Account Currency
        BEGIN
          SELECT A.CCY
            INTO L_PAYOUTCASA_CCY
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_AC_NO = L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC
             AND A.BRANCH_CODE = L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN
             AND A.RECORD_STAT = 'O'
             AND A.AUTH_STAT = 'A'
             AND A.ONCE_AUTH = 'Y';
        EXCEPTION

          WHEN OTHERS THEN
            L_PAYOUTCASA_CCY := NULL;
        END;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN
          --TD Account currency is KHR and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  L_PAYOUTCASA_CCY, --USD
                                  'COMM',

                                  'S',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR SELL RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --khr amount FCYAMOUNT
                                          'Y',
                                          L_LCY_AMOUNT, --usd amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN
          --TD Account currency is USD and Payout CASA Currency is KHR

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --USD
                                  L_PAYOUTCASA_CCY, --KHR
                                  'COMM',

                                  'B',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR BUY RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          L_PAYOUTCASA_CCY,
                                          'COMM',
                                          'S',
                                          L_REVERSE_EXTRATOPUP_TAX, --USD amount
                                          'Y',
                                          L_FCY_AMOUNT, --KHR amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED FCY AMOUNT FOR SELL RATE=' ||
                             L_FCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := L_FCY_AMOUNT;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          --Get Rate
          IF NOT cypks.fn_getrate(GLOBAL.CURRENT_BRANCH,
                                  P_CCY, --KHR
                                  GLOBAL.LCY, --L_PAYOUTCASA_CCY, --KHR
                                  'STANDARD',

                                  'M',

                                  L_EXCH_RATE,
                                  L_RATE_FLAG,
                                  P_ERR_CODE) THEN

            RETURN FALSE;

          ELSE

            DEBUG.PR_DEBUG('AC',
                           'DERIVED EXCHANGE RATE FOR MID RATE=' ||
                           L_EXCH_RATE);

            --convert Amount using above Rate
            --derive lcy amount
            IF NOT Cypkss.Fn_Amt1_To_Amt2(GLOBAL.current_branch,
                                          P_CCY,
                                          GLOBAL.lcy, --usd to get lcy amount
                                          'STANDARD',
                                          'M',
                                          L_REVERSE_EXTRATOPUP_TAX, --KHR amount nothing but FCY Amount
                                          'Y',
                                          L_LCY_AMOUNT, --USD amount nothing but LCY Amount
                                          L_EXCH_RATE,
                                          P_ERR_CODE) THEN
              DEBUG.pr_debug('AC',
                             'Error while computing LCY ' || P_ERR_CODE);
              P_ERR_CODE := SQLCODE;
              RETURN FALSE;

            ELSE

              DEBUG.PR_DEBUG('AC',
                             'DERIVED LCY AMOUNT FOR SELL RATE=' ||
                             L_LCY_AMOUNT);

            END IF;

          END IF;

          L_LCY_AMOUNT := L_LCY_AMOUNT;

          L_FCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          DBG('INSIDE IF TD ACCOUNT CURRENCY=' || P_CCY);
          DBG('INSIDE IF L_PAYOUTCASA_CCY ACCOUNT CURRENCY=' ||
              L_PAYOUTCASA_CCY);

          L_LCY_AMOUNT := L_REVERSE_EXTRATOPUP_TAX;

          L_FCY_AMOUNT := NULL;

        END IF;

        TB_ACCHANDOFF(1) := NULL;

        TB_ACCHANDOFF(1).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(1).MODULE := 'IC';
        TB_ACCHANDOFF(1).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(1).EVENT := P_EVENT;
        TB_ACCHANDOFF(1).EVENT_SR_NO := 1;
        TB_ACCHANDOFF(1).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(1).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(1).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(1).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(1).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(1).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(1).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(1).DRCR_IND := 'D'; --debit TAX GL

        TB_ACCHANDOFF(1).AC_BRANCH := P_BRN;

        IF P_PROD IN ('SY01', 'GY01', 'RY01') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000021'; --debit TAX GL

        ELSIF P_PROD IN ('SY02', 'GY02', 'RY02') THEN

          TB_ACCHANDOFF(1).AC_NO := '384000022';

        END IF;

        TB_ACCHANDOFF(1).AC_CCY := P_CCY;-- L_PAYOUTCASA_CCY; --fixed during pro savings for clever savings

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;--fixed now
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(1).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(1).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(1).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(1).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(1).PRODUCT := P_PROD;

        DBG(' user_id--------> ' || TB_ACCHANDOFF(1).USER_ID);
        DBG(' module--------->  ' || TB_ACCHANDOFF(1).MODULE);
        DBG(' amount_tag-----> ' || TB_ACCHANDOFF(1).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(1).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(1).EVENT_SR_NO);
        DBG(' trn_code-------> ' || TB_ACCHANDOFF(1).TRN_CODE);
        DBG(' trn_dt---------> ' || TB_ACCHANDOFF(1).TRN_DT);
        DBG(' trn_ref_no-----> ' || TB_ACCHANDOFF(1).TRN_REF_NO);
        DBG(' instrument_code->' || TB_ACCHANDOFF(1).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(1).VALUE_DT);
        DBG(' txn_init_date--->' || TB_ACCHANDOFF(1).TXN_INIT_DATE);
        DBG(' related_account->' || TB_ACCHANDOFF(1).RELATED_ACCOUNT);
        DBG(' external_ref_no->' || TB_ACCHANDOFF(1).EXTERNAL_REF_NO);
        DBG(' netting_ind----->' || TB_ACCHANDOFF(1).NETTING_IND);
        DBG(' drcr_ind-------->' || TB_ACCHANDOFF(1).DRCR_IND);
        DBG(' ac_branch------> ' || TB_ACCHANDOFF(1).AC_BRANCH);
        DBG(' ac_no----------->' || TB_ACCHANDOFF(1).AC_NO);
        DBG(' ac_ccy---------->' || TB_ACCHANDOFF(1).AC_CCY);
        DBG(' fcy_amount-----> ' || TB_ACCHANDOFF(1).FCY_AMOUNT);
        DBG(' lcy_amount-----> ' || TB_ACCHANDOFF(1).LCY_AMOUNT);
        DBG(' exch_rate------> ' || TB_ACCHANDOFF(1).EXCH_RATE);

        DBG(' Finished debit leg');

        TB_ACCHANDOFF(2) := NULL;

        TB_ACCHANDOFF(2).USER_ID := NVL(GWPKS_UTIL.G_MAKERID,
                                        GLOBAL.USER_ID);
        TB_ACCHANDOFF(2).MODULE := 'IC';
        TB_ACCHANDOFF(2).AMOUNT_TAG := 'TAX';
        TB_ACCHANDOFF(2).EVENT := P_EVENT;
        TB_ACCHANDOFF(2).EVENT_SR_NO := 2;
        TB_ACCHANDOFF(2).TRN_CODE := 'TCX'; -- P_TXN_CODE; --pls check
        TB_ACCHANDOFF(2).TRN_DT := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).TRN_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).INSTRUMENT_CODE := '';

        TB_ACCHANDOFF(2).VALUE_DT := L_VALUE_DATE;
        TB_ACCHANDOFF(2).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
        TB_ACCHANDOFF(2).RELATED_ACCOUNT := P_ACC;
        TB_ACCHANDOFF(2).RELATED_CUSTOMER := RELATED_CUSTOMER;
        TB_ACCHANDOFF(2).EXTERNAL_REF_NO := P_TXN_REF_NO;
        TB_ACCHANDOFF(2).NETTING_IND := L_NETTING_INDICATOR;
        TB_ACCHANDOFF(2).DRCR_IND := 'C'; --Credit Payout

        TB_ACCHANDOFF(2).AC_BRANCH := L_ICTM_TDPAYOUT_DETAILS.OFFSET_BRN;

        TB_ACCHANDOFF(2).AC_NO := L_ICTM_TDPAYOUT_DETAILS.OFFSET_ACC; --Credit CASA

        TB_ACCHANDOFF(2).AC_CCY := L_PAYOUTCASA_CCY;

        IF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT; --FIXED NOW
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'KHR' AND L_PAYOUTCASA_CCY = 'KHR' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := L_FCY_AMOUNT;
          TB_ACCHANDOFF(2).EXCH_RATE := L_EXCH_RATE;

        ELSIF P_CCY = 'USD' AND L_PAYOUTCASA_CCY = 'USD' THEN

          TB_ACCHANDOFF(2).LCY_AMOUNT := L_LCY_AMOUNT;
          TB_ACCHANDOFF(2).FCY_AMOUNT := NULL;
          TB_ACCHANDOFF(2).EXCH_RATE := NULL;

        END IF;

        TB_ACCHANDOFF(2).PRODUCT := P_PROD;

        DBG(' user_id------->  ' || TB_ACCHANDOFF(2).USER_ID);
        DBG(' module-------->  ' || TB_ACCHANDOFF(2).MODULE);
        DBG(' amount_tag---->  ' || TB_ACCHANDOFF(2).AMOUNT_TAG);
        DBG(' event--------->  ' || TB_ACCHANDOFF(2).EVENT);
        DBG(' event_sr_no--->  ' || TB_ACCHANDOFF(2).EVENT_SR_NO);
        DBG(' trn_code------>  ' || TB_ACCHANDOFF(2).TRN_CODE);
        DBG(' trn_dt-------->  ' || TB_ACCHANDOFF(2).TRN_DT);
        DBG(' trn_ref_no---->  ' || TB_ACCHANDOFF(2).TRN_REF_NO);
        DBG(' instrument_code> ' || TB_ACCHANDOFF(2).INSTRUMENT_CODE);
        DBG(' value_dt-------> ' || TB_ACCHANDOFF(2).VALUE_DT);
        DBG(' txn_init_date->  ' || TB_ACCHANDOFF(2).TXN_INIT_DATE);
        DBG(' related_accounT> ' || TB_ACCHANDOFF(2).RELATED_ACCOUNT);
        DBG(' external_ref_no> ' || TB_ACCHANDOFF(2).EXTERNAL_REF_NO);
        DBG(' netting_ind--->  ' || TB_ACCHANDOFF(2).NETTING_IND);
        DBG(' drcr_ind------>  ' || TB_ACCHANDOFF(2).DRCR_IND);
        DBG(' ac_branch----->  ' || TB_ACCHANDOFF(2).AC_BRANCH);
        DBG(' ac_no--------->  ' || TB_ACCHANDOFF(2).AC_NO);
        DBG(' ac_ccy-------->  ' || TB_ACCHANDOFF(2).AC_CCY);
        DBG(' fcy_amount---->  ' || TB_ACCHANDOFF(2).FCY_AMOUNT);
        DBG(' lcy_amount---->  ' || TB_ACCHANDOFF(2).LCY_AMOUNT);
        DBG(' exch_rate----->  ' || TB_ACCHANDOFF(2).EXCH_RATE);

        DBG(' Finished credit leg');

        IF NOT ACPKSS.FN_ACHANDOFF(P_TXN_REF_NO,
                                   1,
                                   GLOBAL.APPLICATION_DATE,
                                   TB_ACCHANDOFF,
                                   'B',
                                   'N',
                                   'N',
                                   GLOBAL.USER_ID,
                                   P_ERR_CODE,
                                   P_ERR_PARAM) THEN
          ICPKSS_UTIL.DBG('Acc Handoff Failed with ' || SQLERRM);

          IF P_ERR_CODE IS NOT NULL THEN
            OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAM);
          END IF;

          P_ERR_CODE := P_ERR_CODE;

        ELSE

          DBG('SUCCESS IN REVERSING THE EXTRA TOPUP_TAX');

        END IF;

        RETURN TRUE;

      END IF;

    END IF;

    --sampath ends

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_REVERSE_EXTRA_TOPUP_TAX' ||
          SQLERRM);
      RETURN FALSE;
  END FN_REVERSE_EXTRA_TOPUP_TAX;

  --clever savings sampath ends

  FUNCTION FN_DO_ACCOUNTING(P_TXN_CODE       IN VARCHAR2,
                            P_TXN_REF_NO     IN VARCHAR2,
                            P_AMT_TAG        IN VARCHAR2,
                            P_TAG_AMT        IN STTMS_CUST_ACCOUNT.ACY_AVL_BAL%TYPE,
                            P_EVENT          IN VARCHAR2,
                            P_CR_GL          IN VARCHAR2,
                            P_DR_GL          IN VARCHAR2,
                            P_BRN            IN VARCHAR2,
                            P_ACC            IN VARCHAR2,
                            P_CCY            IN VARCHAR2,
                            P_PROD           IN VARCHAR2,
                            P_ERR_CODE       IN OUT VARCHAR2,
                            P_ERR_PARAM      IN OUT VARCHAR2,
                            P_FN_CALL_ID     IN OUT NUMBER,
                            P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_td_redemption_custom.FN_DO_ACCOUNTING');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_DO_ACCOUNTING' ||
          SQLERRM);
      RETURN FALSE;
  END FN_DO_ACCOUNTING;

  FUNCTION FN_APPLY_RATE(P_BRN            IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                         P_ACC            IN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE,
                         P_AC_CLASS_TYPE  IN STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE,
                         P_ACCOUNT_CLASS  IN STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE,
                         P_PRODUCT_CODE   IN ICTM_PR_INT.PRODUCT_CODE%TYPE,
                         P_CCY            IN STTMS_CUST_ACCOUNT.CCY%TYPE,
                         P_AVG_BAL        IN NUMBER,
                         P_NEWTENOR       IN NUMBER,
                         P_ORIGINALTENOR  IN NUMBER,
                         P_AC_OPEN_DATE   IN DATE,
                         P_PPO            IN VARCHAR2,
                         P_FN_CALL_ID     IN OUT NUMBER,
                         P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In stpks_td_redemption_custom.FN_APPLY_RATE');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.FN_APPLY_RATE' ||
          SQLERRM);
      RETURN FALSE;
  END FN_APPLY_RATE;

  FUNCTION FN_ACLOOKUP(P_TXN_REF_NO        IN VARCHAR2,
                       P_BRN               IN VARCHAR2,
                       P_PRODUCT_CODE      IN VARCHAR2,
                       P_CCY               IN VARCHAR2,
                       P_ACC               IN VARCHAR2,
                       P_BOOK_ACCOUNT      IN VARCHAR2,
                       P_AMT_LIQD_TILLDATE IN OUT DBMS_SQL.NUMBER_TABLE,
                       TB_G_MEMO_REC       IN STPKS_TD_REDEMPTION.TY_MEMO_REC,
                       P_ERR_CODE          IN OUT VARCHAR2,
                       P_ERR_PARAM         IN OUT VARCHAR2,
                       P_FN_CALL_ID        IN NUMBER,
                       P_TB_CUSTOM_DATA    IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('Start  of stpks_td_redemption_cluster.FN_ACLOOKUP');
    DBG('End  of stpks_td_redemption_cluster.FN_ACLOOKUP');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_cluster.FN_ACLOOKUP' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ACLOOKUP;

  FUNCTION FN_ACCR_ADJ(P_TXN_REF_NO     IN VARCHAR2,
                       P_BRN            IN VARCHAR2,
                       P_PRODUCT_CODE   IN VARCHAR2,
                       P_CCY            IN VARCHAR2,
                       P_ACC            IN VARCHAR2,
                       TB_G_MEMO_REC    IN STPKS_TD_REDEMPTION.TY_MEMO_REC,
                       P_ERR_CODE       IN OUT VARCHAR2,
                       P_ERR_PARAM      IN OUT VARCHAR2,
                       P_FN_CALL_ID     IN OUT NUMBER,
                       P_TB_CUSTOM_DATA IN OUT GLOBAL.TY_TB_CUSTOM_DATA)
    RETURN BOOLEAN IS
  BEGIN
    DBG('In stpks_td_redemption_custom.fn_accr_adj');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in stpks_td_redemption_custom.fn_accr_adj' ||
          SQLERRM);
      RETURN FALSE;
  END FN_ACCR_ADJ;

END STPKS_TD_REDEMPTION_CUSTOM;
