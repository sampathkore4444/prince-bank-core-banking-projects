CREATE OR REPLACE PACKAGE BODY icpks_test AS

  TYPE TY_LOOKUP_CACHE IS TABLE OF ACPKS.TBL_LOOKUP INDEX BY VARCHAR2(50);

  PKG_LOOKUP_CACHE TY_LOOKUP_CACHE;
  PKG_CHG_COUNT    NUMBER;

  PKG_RES_RETRY_COUNT NUMBER := 0;
  PKG_RES_RETRY_RANGE NUMBER := 0;

  TYPE MS_TB IS TABLE OF DATE INDEX BY BINARY_INTEGER;
  TYPE MS_TB1 IS TABLE OF VARCHAR2(20) INDEX BY BINARY_INTEGER;
  TB_MS_BRN           MS_TB1;
  TB_MS_REF_ACC       MS_TB1;
  TB_MS_FRM_DT        MS_TB;
  TB_MS_TO_DT         MS_TB;
  TB_MS_RECEIVER      MS_TB1;
  TB_MS_MEDIA         MS_TB1;
  TB_MS_DEFAULT_MEDIA MS_TB1;
  TB_MS_CUST          MS_TB1;

  TB_MS_MODULE MS_TB1;

  TYPE TB_REC_RULEFRM IS TABLE OF ICTMS_RULE_FRM%ROWTYPE INDEX BY BINARY_INTEGER;
  TB_RULEFRM TB_REC_RULEFRM;
  TYPE TB_REC_RULEELEM IS TABLE OF ICTMS_RULE_FRM_ELEMENTS%ROWTYPE INDEX BY BINARY_INTEGER;
  TB_RULEFRM_ELEM TB_REC_RULEELEM;

  TYPE TB_REC_RULEUDE IS TABLE OF ICTMS_RULE_UDE%ROWTYPE INDEX BY BINARY_INTEGER;
  TB_RULE_UDE TB_REC_RULEUDE;

  TB_CUR_PRODRUN_LCY ICPKSS_TEST.TICNT14;
  FRMLISTFRM         VARCHAR2(4000);
  FRMLISTELEM        VARCHAR2(4000);
  FRMLISTUDE         VARCHAR2(32676);
  REPOP_CASE         BOOLEAN := FALSE;
  DEFR_CASE          BOOLEAN := FALSE;

  L_BOOK_ACC ICTMS_ACC.BOOK_ACC%TYPE;
  L_BOOK_BRN ICTMS_ACC.BOOK_BRN%TYPE;
  L_BOOK_CCY ICTMS_ACC.BOOK_CCY%TYPE;
  TYPE L_PRINT IS TABLE OF ICTMS_PR_INT%ROWTYPE INDEX BY BINARY_INTEGER;

  PKG_CHG_ADV_CNT NUMBER := 0;

  L_PR_INT           L_PRINT;
  G_CUSTOMER_NAME1   STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
  G_CUST_IND_TC_REQD STTMS_CUSTOMER.INDIVIDUAL_TAX_CERT_REQD%TYPE;
  G_BRANCH_REC       STTMS_BRANCH%ROWTYPE;
  L_INSTANCE         NUMBER;

  TB_ACCPR_BRN_BAK     T1;
  TB_ACCPR_ACC_BAK     T2;
  TB_ACCPR_PRD_BAK     T3;
  TB_ACCPR_SCMAPDT_BAK T4;
  TB_ACCPR_GCMAPDT_BAK T5;

  TB_ACCPR_INCMTH_BAK T12;

  TB_ACCPR_PRDTYPE_BAK T16;
  TB_ACCPR_HASACCR_BAK T17;

  TB_ACCPR_PRODACCR_BAK T19;
  TB_ACCPR_HASPRBLM_BAK T20;

  TB_ACCPR_FFCALCDAT_BAK  T23;
  TB_ACCPR_IMATPRBLMS_BAK T24;
  TB_ACCPR_DEPOSIT_BAK    T25;
  TB_ACCPR_ACLASS_BAK     T26;
  TB_ACCPR_CCY_BAK        T27;

  TB_ACCPR_ROWID_BAK         T29;
  TB_ACCPR_PROCESS_BAK       T30;
  TB_RECALC_ACCR_ON_LIQN_BAK T36;

  TB_CUR_PRODRUN_LCY_BAK TICNT14;
  TB_HOFF_PROD_BAK       ACPKSS.TBL_ACHOFF;
  FRMLIST                VARCHAR2(32767);
  FRMLISTLIQ             VARCHAR2(32767);
  FRMLIST_BAK            VARCHAR2(32767);
  FRMLISTLIQ_BAK         VARCHAR2(32767);

  PKG_STOP_DEFR_POSTING BOOLEAN := FALSE;

  TB_LAST_CALC_DT_BAK            T6;
  TB_LAST_LIQ_DT_BAK             T7;
  TB_NEXT_LIQ_DT_BAK             T8;
  TB_LAST_ACCR_DT_BAK            T9;
  TB_NEXT_ACCR_DT_BAK            T10;
  TB_LAST_SCHD_LIQ_DT_BAK        T11;
  TB_NEXT_SCHD_LIQ_DT_BAK        T13;
  TB_FIRST_CALC_DT_BAK           T14;
  TB_NEXT_SCHD_ACCR_DT_BAK       T15;
  TB_NEXT_CALC_DT_BAK            T18;
  TB_BKVAL_MINCALC_DATE_BAK      T21;
  TB_BKVAL_RECALC_FLAG_BAK       T22;
  TB_DEFER_LIQ_DT_BAK            T31;
  TB_NEXT_EVENT_DT_BAK           T28;
  TB_ICENT_HIST_BRN_BAK          TB1;
  TB_ICENT_HIST_ACC_BAK          TB2;
  TB_ICENT_HIST_PROD_BAK         TB3;
  TB_ICENT_HIST_FRM_NO_BAK       TB4;
  TB_ICENT_HIST_ENT_DT_BAK       TB5;
  TB_ICENT_HIST_AMT_BAK          TB6;
  TB_ICENT_HIST_ACCRUED_AMT_BAK  TB7;
  TB_ICENT_HIST_AMT_ACCRUE_BAK   TB8;
  TB_ICENT_HIST_CUR_RUN_ACCR_BAK TB9;
  TB_ICENT_HIST_RUN_DATE_BAK     TB10;
  TB_ICENT_HIST_ACCR_BAK         TB11;
  TB_ICENT_HIST_LIQN_BAK         TB12;
  TB_ICENT_HIST_ENTRY_TYPE_BAK   TB13;
  TB_ICENT_HIST_CCY_BAK          TB14;
  TB_ICENT_HIST_LCY_AMT_BAK      TB15;
  TB_ICENT_HIST_LAST_ACCR_BAK    TB16;
  TB_ICENT_HIST_CURACCR_LCY_BAK  TB15;
  TB_ICENT_HIST_ENTRY_PASSED_BAK TB17;
  TB_RACCR_BRN_BAK               TICNT1;
  TB_RACCR_ACC_BAK               TICNT2;
  TB_RACCR_PROD_BAK              TICNT3;
  TB_RACCR_FRM_NO_BAK            TICNT4;
  TB_ICTMACC_UPD_ACC_BAK         T2;
  TB_ICTMACC_UPD_BRN_BAK         T1;
  TB_ICTMACC_UPD_ISDT_BAK        T6;
  TB_ICENT_HIST_ADJ_BAK          REC_ICENT_HIST;

  G_SLEEP_TIMER NUMBER := 30;

  BULK_ERRORS EXCEPTION;
  PRAGMA EXCEPTION_INIT(BULK_ERRORS, -24381);
  L_ERROR_INDEX INTEGER := 0;

  TYPE TY_REC_FATCA_LIQNET IS RECORD(
    SUM_ESCROW     NUMBER,
    SUM_ESCROW_LCY NUMBER,
    SUM_TPBL       NUMBER,
    SUM_TPBL_LCY   NUMBER);
  TYPE TY_TB_FATCA_LIQNET IS TABLE OF TY_REC_FATCA_LIQNET INDEX BY VARCHAR2(4);
  L_FATCA_LIQNET TY_TB_FATCA_LIQNET;

  PROCEDURE DBG(MSG VARCHAR2) IS
  BEGIN
    IF (DEBUG.PKG_DEBUG_ON <> 2) THEN
      DEBUG.PR_DEBUG('IC', 'icpkss_test --> ' || MSG);
    END IF;
  END DBG;
  PROCEDURE PR_MSTB_INSERT;

  FUNCTION FN_FIND_LAST_CHILD(P_PARENT_PHY_BRN VARCHAR2,
                              P_PARENT_PHY_ACC VARCHAR2,
                              P_CHILD_SYS_ACC  VARCHAR2,
                              P_CHILD_SYS_BRN  VARCHAR2,
                              P_AMOUNT         NUMBER,
                              P_TAG            VARCHAR2) RETURN BOOLEAN;

  FUNCTION FN_FIND_LAST_CHILD_ONLIQ(P_PARENT_PHY_BRN VARCHAR2,
                                    P_PARENT_PHY_ACC VARCHAR2,
                                    P_CHILD_SYS_ACC  VARCHAR2,
                                    P_CHILD_SYS_BRN  VARCHAR2,
                                    P_AMOUNT         NUMBER,
                                    P_TAG            VARCHAR2) RETURN BOOLEAN;

  PROCEDURE PR_RETRY_RESOLUTION(P_BRN VARCHAR2);

  PROCEDURE PR_UPDATE_OD_INT(P_FRM_NO          ICTMS_RULE_FRM.FRM_NO%TYPE,
                             P_BRN             ICTM_ACC.BRN%TYPE,
                             P_RELATED_ACCOUNT ACTB_DAILY_LOG.RELATED_ACCOUNT%TYPE,
                             P_PROD            ICTM_ACC_PR.PROD%TYPE,
                             P_LCY_AMT         ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                             P_FCY_AMT         ACTB_DAILY_LOG.FCY_AMOUNT%TYPE,
                             P_ACC_CCY         STTM_CUST_ACCOUNT.CCY%TYPE,
                             P_LCY             STTM_CUST_ACCOUNT.CCY%TYPE,
                             P_DT              DATE);

  PROCEDURE LPG(MSG VARCHAR2, P_ACC VARCHAR2);

  PROCEDURE PR_POP_NET_TABLE(POS1 NUMBER) IS
  BEGIN
    TB_ICENT_LIQNET(POS1).BRN := TB_ICENT(POS1).BRN;
    TB_ICENT_LIQNET(POS1).ACC := TB_ICENT(POS1).ACC;
    TB_ICENT_LIQNET(POS1).PROD := TB_ICENT(POS1).PROD;
    TB_ICENT_LIQNET(POS1).FRM_NO := TB_ICENT(POS1).FRM_NO;
    TB_ICENT_LIQNET(POS1).AMT := TB_ICENT(POS1).AMT;
    TB_ICENT_LIQNET(POS1).ACCRUED_AMT := TB_ICENT(POS1).ACCRUED_AMT;
    TB_ICENT_LIQNET(POS1).AMT_TO_ACCRUE := TB_ICENT(POS1).AMT_TO_ACCRUE;
    TB_ICENT_LIQNET(POS1).CUR_RUN_ACCR := TB_ICENT(POS1).CUR_RUN_ACCR;
    TB_ICENT_LIQNET(POS1).ENT_DT := TB_ICENT(POS1).ENT_DT;
    TB_ICENT_LIQNET(POS1).DRCR := TB_ICENT(POS1).DRCR;
    TB_ICENT_LIQNET(POS1).HAS_ACCR := TB_ICENT(POS1).HAS_ACCR;
    TB_ICENT_LIQNET(POS1).DAILY_AMT := TB_ICENT(POS1).DAILY_AMT;
    TB_ICENT_LIQNET(POS1).NEXT_CALC_DUE_DATE := TB_ICENT(POS1)
                                                .NEXT_CALC_DUE_DATE;
    TB_ICENT_LIQNET(POS1).ACQUIRED_AMT := TB_ICENT(POS1).ACQUIRED_AMT;
    TB_ICENT_LIQNET(POS1).ACQUIRED_ADJ := TB_ICENT(POS1).ACQUIRED_ADJ;
    TB_ICENT_LIQNET(POS1).ROW_ID := TB_ICENT(POS1).ROW_ID;
    TB_ICENT_LIQNET(POS1).AMT_NOT_ACCRUED := TB_ICENT(POS1).AMT_NOT_ACCRUED;
    TB_ICENT_LIQNET(POS1).PROCESS := TB_ICENT(POS1).PROCESS;
    TB_ICENT_LIQNET(POS1).LCY_AMT := 0;
    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := 0;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
  END;

  PROCEDURE LOG_PROBLEM(P_ROWNUM NUMBER, P_OP VARCHAR2, P_ERR VARCHAR2);

  PROCEDURE PR_LOOKUP(P_PROD       VARCHAR2,
                      P_EVENT      VARCHAR2,
                      P_STATUS     VARCHAR2,
                      P_LOOKUP_TAB IN OUT NOCOPY ACPKS.TBL_LOOKUP) IS
    IDX    VARCHAR2(50);
    ERRMSG VARCHAR2(10000);
  BEGIN
    IDX := P_PROD || '~' || P_EVENT || '~' || NVL(P_STATUS, 'NORM');
    IF PKG_LOOKUP_CACHE.EXISTS(IDX) THEN
      P_LOOKUP_TAB := PKG_LOOKUP_CACHE(IDX);
    ELSE
      IF NOT
          ACPKSS.ACFN_LOOKUP(P_PROD, P_EVENT, P_STATUS, P_LOOKUP_TAB, ERRMSG) THEN
        DBG('Lookup Failed');
        DBG('failed in acpks.aclookup');
        RAISE_APPLICATION_ERROR(-20008, 'Lookup failed with ' || ERRMSG);
      ELSE
        PKG_LOOKUP_CACHE(IDX) := P_LOOKUP_TAB;
      END IF;
    END IF;
  END PR_LOOKUP;

  PROCEDURE PR_DEL_ICTB_JOB_CTL(P_BRN         VARCHAR2,
                                P_PROCESS     VARCHAR2,
                                P_FUNCTION_ID VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DELETE ICTB_JOB_CTL
     WHERE BRN = P_BRN
       AND FUNCTION_ID = P_FUNCTION_ID
       AND PROCESS = P_PROCESS;
  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      COMMIT;
  END PR_DEL_ICTB_JOB_CTL;

  PROCEDURE PR_INS_ICTB_JOB_CTL(P_BRN         VARCHAR2,
                                P_PROCESS     VARCHAR2,
                                L_JOB_NAME    VARCHAR2,
                                L_WHAT        VARCHAR2,
                                P_FUNCTION_ID VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO ICTB_JOB_CTL
      (BRN, PROCESS, JOB, STATUS, FUNCTION_ID, WHAT, START_TIME, SEQ_NO)
    VALUES
      (P_BRN,
       P_PROCESS,
       L_JOB_NAME,
       NULL,
       P_FUNCTION_ID,
       L_WHAT,
       SYSDATE,
       TRSQ_JOB_SEQ.NEXTVAL);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      COMMIT;
  END PR_INS_ICTB_JOB_CTL;

  PROCEDURE PR_TAKE_ICTBACCPR_BAK IS
  BEGIN
    DBG('Inside pr_take_ictbaccpr_bak');
  
    TB_ACCPR_ROWID_BAK := TB_ROWID;
  
    TB_ACCPR_BRN_BAK        := TB_BRN;
    TB_ACCPR_ACC_BAK        := TB_ACC;
    TB_ACCPR_PRD_BAK        := TB_PROD;
    TB_ACCPR_SCMAPDT_BAK    := TB_SC_MAP_DT;
    TB_ACCPR_GCMAPDT_BAK    := TB_GC_MAP_DT;
    TB_ACCPR_INCMTH_BAK     := TB_INC_MTH;
    TB_ACCPR_PRDTYPE_BAK    := TB_PROD_TYPE;
    TB_ACCPR_HASACCR_BAK    := TB_HAS_ACCR;
    TB_ACCPR_PRODACCR_BAK   := TB_PROD_ACCR;
    TB_ACCPR_FFCALCDAT_BAK  := TB_FIRST_FIRST_CALC_DATE;
    TB_ACCPR_IMATPRBLMS_BAK := TB_IMAT_PROBLEMS;
    TB_ACCPR_DEPOSIT_BAK    := TB_DEPOSIT;
    TB_ACCPR_ACLASS_BAK     := TB_ACLASS;
    TB_ACCPR_CCY_BAK        := TB_CCY;
    TB_ACCPR_PROCESS_BAK    := TB_PROCESS;
    TB_LAST_CALC_DT_BAK     := TB_LAST_CALC_DT;
  
    TB_NEXT_LIQ_DT_BAK         := TB_NEXT_LIQ_DT;
    TB_LAST_ACCR_DT_BAK        := TB_LAST_ACCR_DT;
    TB_NEXT_ACCR_DT_BAK        := TB_NEXT_ACCR_DT;
    TB_LAST_SCHD_LIQ_DT_BAK    := TB_LAST_SCHD_LIQ_DT;
    TB_NEXT_SCHD_LIQ_DT_BAK    := TB_NEXT_SCHD_LIQ_DT;
    TB_FIRST_CALC_DT_BAK       := TB_FIRST_CALC_DT;
    TB_NEXT_SCHD_ACCR_DT_BAK   := TB_NEXT_SCHD_ACCR_DT;
    TB_NEXT_CALC_DT_BAK        := TB_NEXT_CALC_DT;
    TB_BKVAL_MINCALC_DATE_BAK  := TB_BKVAL_MINCALC_DATE;
    TB_BKVAL_RECALC_FLAG_BAK   := TB_BKVAL_RECALC_FLAG;
    TB_DEFER_LIQ_DT_BAK        := TB_DEFER_LIQ_DT;
    TB_NEXT_EVENT_DT_BAK       := TB_NEXT_EVENT_DT;
    TB_ACCPR_HASPRBLM_BAK      := TB_HAS_PROBLEMS;
    TB_LAST_LIQ_DT_BAK         := TB_LAST_LIQ_DT;
    TB_RECALC_ACCR_ON_LIQN_BAK := TB_RECALC_ACCR_ON_LIQN;
    DBG('Before Returning hogayaa restore pr_take_ictbaccpr_bak');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error occured while taking back up of IC TB ACC PR ');
      DBG('Oracle error ' || SQLERRM);
  END PR_TAKE_ICTBACCPR_BAK;

  PROCEDURE PR_TAKE_PLSQL_TAB_BAK IS
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Here in pr_take_plsql_tab_bak Start ');
    TB_ICENT_HIST_UPD_BAK          := TB_ICENT_HIST_UPD;
    TB_ICENT_UPD_ACC_BAK           := TB_ICENT_UPD_ACC;
    TB_ICENT_UPD_AMT_BAK           := TB_ICENT_UPD_AMT;
    TB_ICENT_UPD_ACCRUED_AMT_BAK   := TB_ICENT_UPD_ACCRUED_AMT;
    TB_ICENT_UPD_AMT_TO_ACCRUE_BAK := TB_ICENT_UPD_AMT_TO_ACCRUE;
    TB_ICENT_UPD_CUR_RUN_ACCR_BAK  := TB_ICENT_UPD_CUR_RUN_ACCR;
    TB_ICENT_UPD_ENT_DT_BAK        := TB_ICENT_UPD_ENT_DT;
    TB_ICENT_UPD_DRCR_BAK          := TB_ICENT_UPD_DRCR;
    TB_ICENT_UPD_DAILY_AMT_BAK     := TB_ICENT_UPD_DAILY_AMT;
    TB_ICNT_UPD_NXT_CLC_DUE_DT_BAK := TB_ICENT_UPD_NEXT_CALC_DUE_DT;
    TB_ICENT_UPD_ACQUIRED_ADJ_BAK  := TB_ICENT_UPD_ACQUIRED_ADJ;
    TB_ICENT_UPD_ACQUIRED_AMT_BAK  := TB_ICENT_UPD_ACQUIRED_AMT;
    TB_ICENT_UPD_ROWID_BAK         := TB_ICENT_UPD_ROWID;
    TB_ICENT_LIQNET_BAK            := TB_ICENT_LIQNET;
    TB_ICENT_PROD_BAK              := TB_ICENT_PROD;
  
    TB_CUR_PRODRUN_LCY_BAK := TB_CUR_PRODRUN_LCY;
    TB_HOFF_PROD_BAK       := TB_HOFF_PROD;
    PR_TAKE_ICTBACCPR_BAK;
    TB_ICENT_HIST_BRN_BAK          := TB_ICENT_HIST_BRN;
    TB_ICENT_HIST_ACC_BAK          := TB_ICENT_HIST_ACC;
    TB_ICENT_HIST_PROD_BAK         := TB_ICENT_HIST_PROD;
    TB_ICENT_HIST_FRM_NO_BAK       := TB_ICENT_HIST_FRM_NO;
    TB_ICENT_HIST_ENT_DT_BAK       := TB_ICENT_HIST_ENT_DT;
    TB_ICENT_HIST_AMT_BAK          := TB_ICENT_HIST_AMT;
    TB_ICENT_HIST_ACCRUED_AMT_BAK  := TB_ICENT_HIST_ACCRUED_AMT;
    TB_ICENT_HIST_AMT_ACCRUE_BAK   := TB_ICENT_HIST_AMT_TO_ACCRUE;
    TB_ICENT_HIST_CUR_RUN_ACCR_BAK := TB_ICENT_HIST_CUR_RUN_ACCR;
    TB_ICENT_HIST_RUN_DATE_BAK     := TB_ICENT_HIST_RUN_DATE;
    TB_ICENT_HIST_ACCR_BAK         := TB_ICENT_HIST_ACCR;
    TB_ICENT_HIST_LIQN_BAK         := TB_ICENT_HIST_LIQN;
    TB_ICENT_HIST_ENTRY_TYPE_BAK   := TB_ICENT_HIST_ENTRY_TYPE;
    TB_ICENT_HIST_CCY_BAK          := TB_ICENT_HIST_CCY;
    TB_ICENT_HIST_LCY_AMT_BAK      := TB_ICENT_HIST_LCY_AMT;
    TB_ICENT_HIST_LAST_ACCR_BAK    := TB_ICENT_HIST_LAST_CUR_ACCR;
    TB_ICENT_HIST_CURACCR_LCY_BAK  := TB_ICENT_HIST_CURACCR_LCY;
    TB_ICENT_HIST_ENTRY_PASSED_BAK := TB_ICENT_HIST_ENTRY_PASSED;
    TB_RACCR_BRN_BAK               := TB_RACCR_BRN;
    TB_RACCR_ACC_BAK               := TB_RACCR_ACC;
    TB_RACCR_PROD_BAK              := TB_RACCR_PROD;
    TB_RACCR_FRM_NO_BAK            := TB_RACCR_FRM_NO;
    TB_ICTMACC_UPD_ACC_BAK         := TB_ICTMACC_UPD_ACC;
    TB_ICTMACC_UPD_BRN_BAK         := TB_ICTMACC_UPD_BRN;
    TB_ICTMACC_UPD_ISDT_BAK        := TB_ICTMACC_UPD_ISDT;
    TB_ICENT_HIST_ADJ_BAK          := TB_ICENT_HIST_ADJ;
    FRMLIST_BAK                    := FRMLIST;
    FRMLISTLIQ_BAK                 := FRMLISTLIQ;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      ICPKS_TEST_CLUSTER.PR_TAKE_PLSQL_TAB_BAK(L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
    END IF;
  
    DBG('Here in pr_take_plsql_tab_bak End');
  END;
  PROCEDURE PR_TAKE_PLSQL_TAB_RESTORE IS
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('Here in pr_take_plsql_tab_restore Start ');
    TB_ICENT_HIST_UPD             := TB_ICENT_HIST_UPD_BAK;
    TB_ICENT_UPD_ACC              := TB_ICENT_UPD_ACC_BAK;
    TB_ICENT_UPD_AMT              := TB_ICENT_UPD_AMT_BAK;
    TB_ICENT_UPD_ACCRUED_AMT      := TB_ICENT_UPD_ACCRUED_AMT_BAK;
    TB_ICENT_UPD_AMT_TO_ACCRUE    := TB_ICENT_UPD_AMT_TO_ACCRUE_BAK;
    TB_ICENT_UPD_CUR_RUN_ACCR     := TB_ICENT_UPD_CUR_RUN_ACCR_BAK;
    TB_ICENT_UPD_ENT_DT           := TB_ICENT_UPD_ENT_DT_BAK;
    TB_ICENT_UPD_DRCR             := TB_ICENT_UPD_DRCR_BAK;
    TB_ICENT_UPD_DAILY_AMT        := TB_ICENT_UPD_DAILY_AMT_BAK;
    TB_ICENT_UPD_NEXT_CALC_DUE_DT := TB_ICNT_UPD_NXT_CLC_DUE_DT_BAK;
    TB_ICENT_UPD_ACQUIRED_ADJ     := TB_ICENT_UPD_ACQUIRED_ADJ_BAK;
    TB_ICENT_UPD_ACQUIRED_AMT     := TB_ICENT_UPD_ACQUIRED_AMT_BAK;
    TB_ICENT_UPD_ROWID            := TB_ICENT_UPD_ROWID_BAK;
    TB_ICENT_LIQNET               := TB_ICENT_LIQNET_BAK;
    TB_ICENT_PROD                 := TB_ICENT_PROD_BAK;
  
    TB_CUR_PRODRUN_LCY          := TB_CUR_PRODRUN_LCY_BAK;
    TB_HOFF_PROD                := TB_HOFF_PROD_BAK;
    TB_ROWID                    := TB_ACCPR_ROWID_BAK;
    TB_BRN                      := TB_ACCPR_BRN_BAK;
    TB_ACC                      := TB_ACCPR_ACC_BAK;
    TB_PROD                     := TB_ACCPR_PRD_BAK;
    TB_SC_MAP_DT                := TB_ACCPR_SCMAPDT_BAK;
    TB_GC_MAP_DT                := TB_ACCPR_GCMAPDT_BAK;
    TB_INC_MTH                  := TB_ACCPR_INCMTH_BAK;
    TB_PROD_TYPE                := TB_ACCPR_PRDTYPE_BAK;
    TB_HAS_ACCR                 := TB_ACCPR_HASACCR_BAK;
    TB_RECALC_ACCR_ON_LIQN      := TB_RECALC_ACCR_ON_LIQN_BAK;
    TB_PROD_ACCR                := TB_ACCPR_PRODACCR_BAK;
    TB_FIRST_FIRST_CALC_DATE    := TB_ACCPR_FFCALCDAT_BAK;
    TB_IMAT_PROBLEMS            := TB_ACCPR_IMATPRBLMS_BAK;
    TB_DEPOSIT                  := TB_ACCPR_DEPOSIT_BAK;
    TB_ACLASS                   := TB_ACCPR_ACLASS_BAK;
    TB_CCY                      := TB_ACCPR_CCY_BAK;
    TB_PROCESS                  := TB_ACCPR_PROCESS_BAK;
    TB_LAST_CALC_DT             := TB_LAST_CALC_DT_BAK;
    TB_LAST_LIQ_DT              := TB_LAST_LIQ_DT_BAK;
    TB_NEXT_LIQ_DT              := TB_NEXT_LIQ_DT_BAK;
    TB_LAST_ACCR_DT             := TB_LAST_ACCR_DT_BAK;
    TB_NEXT_ACCR_DT             := TB_NEXT_ACCR_DT_BAK;
    TB_LAST_SCHD_LIQ_DT         := TB_LAST_SCHD_LIQ_DT_BAK;
    TB_NEXT_SCHD_LIQ_DT         := TB_NEXT_SCHD_LIQ_DT_BAK;
    TB_FIRST_CALC_DT            := TB_FIRST_CALC_DT_BAK;
    TB_NEXT_SCHD_ACCR_DT        := TB_NEXT_SCHD_ACCR_DT_BAK;
    TB_NEXT_CALC_DT             := TB_NEXT_CALC_DT_BAK;
    TB_BKVAL_MINCALC_DATE       := TB_BKVAL_MINCALC_DATE_BAK;
    TB_BKVAL_RECALC_FLAG        := TB_BKVAL_RECALC_FLAG_BAK;
    TB_DEFER_LIQ_DT             := TB_DEFER_LIQ_DT_BAK;
    TB_NEXT_EVENT_DT            := TB_NEXT_EVENT_DT_BAK;
    TB_ICENT_HIST_BRN           := TB_ICENT_HIST_BRN_BAK;
    TB_ICENT_HIST_ACC           := TB_ICENT_HIST_ACC_BAK;
    TB_ICENT_HIST_PROD          := TB_ICENT_HIST_PROD_BAK;
    TB_ICENT_HIST_FRM_NO        := TB_ICENT_HIST_FRM_NO_BAK;
    TB_ICENT_HIST_ENT_DT        := TB_ICENT_HIST_ENT_DT_BAK;
    TB_ICENT_HIST_AMT           := TB_ICENT_HIST_AMT_BAK;
    TB_ICENT_HIST_ACCRUED_AMT   := TB_ICENT_HIST_ACCRUED_AMT_BAK;
    TB_ICENT_HIST_AMT_TO_ACCRUE := TB_ICENT_HIST_AMT_ACCRUE_BAK;
    TB_ICENT_HIST_CUR_RUN_ACCR  := TB_ICENT_HIST_CUR_RUN_ACCR_BAK;
    TB_ICENT_HIST_RUN_DATE      := TB_ICENT_HIST_RUN_DATE_BAK;
    TB_ICENT_HIST_ACCR          := TB_ICENT_HIST_ACCR_BAK;
    TB_ICENT_HIST_LIQN          := TB_ICENT_HIST_LIQN_BAK;
    TB_ICENT_HIST_ENTRY_TYPE    := TB_ICENT_HIST_ENTRY_TYPE_BAK;
    TB_ICENT_HIST_CCY           := TB_ICENT_HIST_CCY_BAK;
    TB_ICENT_HIST_LCY_AMT       := TB_ICENT_HIST_LCY_AMT_BAK;
    TB_ICENT_HIST_LAST_CUR_ACCR := TB_ICENT_HIST_LAST_ACCR_BAK;
    TB_ICENT_HIST_CURACCR_LCY   := TB_ICENT_HIST_CURACCR_LCY_BAK;
    TB_ICENT_HIST_ENTRY_PASSED  := TB_ICENT_HIST_ENTRY_PASSED_BAK;
    TB_RACCR_BRN                := TB_RACCR_BRN_BAK;
    TB_RACCR_ACC                := TB_RACCR_ACC_BAK;
    TB_RACCR_PROD               := TB_RACCR_PROD_BAK;
    TB_RACCR_FRM_NO             := TB_RACCR_FRM_NO_BAK;
    TB_ICTMACC_UPD_ACC          := TB_ICTMACC_UPD_ACC_BAK;
    TB_ICTMACC_UPD_BRN          := TB_ICTMACC_UPD_BRN_BAK;
    TB_ICTMACC_UPD_ISDT         := TB_ICTMACC_UPD_ISDT_BAK;
    TB_ICENT_HIST_ADJ           := TB_ICENT_HIST_ADJ_BAK;
    FRMLIST                     := FRMLIST_BAK;
    FRMLISTLIQ                  := FRMLISTLIQ_BAK;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      ICPKS_TEST_CLUSTER.PR_TAKE_PLSQL_TAB_RESTORE(L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA);
    END IF;
  
    DBG('Here in pr_take_plsql_tab_restore End');
  END;

  PROCEDURE PR_PURGE_PLSQL_TABS;

  PROCEDURE PR_UNCLAIMED_GL(P_PROD         VARCHAR2,
                            P_ACC_ROLE     VARCHAR2,
                            L_ACCOUNT_HEAD OUT VARCHAR2) IS
  
    CURSOR CR_UNCLAIMED_GL IS
      SELECT A.ACCOUNT_HEAD
        FROM CSTM_BRANCH_PRODRTH_DETAIL A
       WHERE A.PRODUCT_CODE = P_PROD
         AND A.ACCOUNTING_ROLE = P_ACC_ROLE
         AND A.STATUS = 'NORM'
         AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
         AND A.PRODUCT_CODE IN (SELECT PRODUCT_CODE
                                  FROM CSTM_BRANCH_PRODRTH_MASTER
                                 WHERE PRODUCT_CODE = P_PROD
                                   AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                                   AND STATUS = 'NORM'
                                   AND RECORD_STAT = 'O'
                                   AND AUTH_STAT = 'A')
      UNION
      SELECT A.ACCOUNT_HEAD
        FROM CSTMS_PRODUCT_ACCROLE A
       WHERE A.PRODUCT_CODE = P_PROD
         AND A.ACCOUNTING_ROLE = P_ACC_ROLE
         AND A.ACCOUNT_HEAD NOT IN
             (SELECT A. ACCOUNT_HEAD
                FROM CSTM_BRANCH_PRODRTH_DETAIL A
               WHERE A.PRODUCT_CODE = P_PROD
                 AND A.ACCOUNTING_ROLE = P_ACC_ROLE
                 AND A.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                 AND A.STATUS = 'NORM'
                 AND A.PRODUCT_CODE IN
                     (SELECT PRODUCT_CODE
                        FROM CSTM_BRANCH_PRODRTH_MASTER
                       WHERE PRODUCT_CODE = P_PROD
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                         AND STATUS = 'NORM'
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A'));
  
  BEGIN
    DBG('pr_unclaimed_gl starts');
    L_ACCOUNT_HEAD := NULL;
    OPEN CR_UNCLAIMED_GL;
    FETCH CR_UNCLAIMED_GL
      INTO L_ACCOUNT_HEAD;
    IF CR_UNCLAIMED_GL%NOTFOUND THEN
      L_ACCOUNT_HEAD := NULL;
    END IF;
    CLOSE CR_UNCLAIMED_GL;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('pr_unclaimed_gl failed-->' || SQLERRM);
      L_ACCOUNT_HEAD := NULL;
  END PR_UNCLAIMED_GL;

  PROCEDURE PR_POST_INTRDAY_ACCR_ENT_FR_AC(PHANDOFF   ACPKS.TBL_ACHOFF,
                                           P_ERR_FLAG OUT NUMBER) IS
  BEGIN
    DBG('Will post entries for accrual for the accounts as its EOD.-->' ||
        PHANDOFF.COUNT);
    FOR I IN 1 .. PHANDOFF.COUNT LOOP
      DBG('here inside loop');
      IF I > 1 THEN
        DBG('inside this-->' || I || '~' || PHANDOFF(I).RELATED_ACCOUNT || '~' || PHANDOFF(I - 1)
            .RELATED_ACCOUNT || '~' || PHANDOFF(I - 1).AC_BRANCH || '~' || PHANDOFF(I)
            .AC_BRANCH);
        IF PHANDOFF(I - 1).RELATED_ACCOUNT <> PHANDOFF(I)
           .RELATED_ACCOUNT OR PHANDOFF(I - 1).AC_BRANCH <> PHANDOFF(I)
           .AC_BRANCH THEN
          DBG('Calling icpks_deferred_entries.pr_post_entries for Brn: ' || PHANDOFF(I - 1)
              .AC_BRANCH || ' Acc: ' || PHANDOFF(I - 1).RELATED_ACCOUNT ||
              ' Seq No: ' || ICPKS_PARTITION_INFO.G_THIS_PART);
          ICPKS_DEFERRED_ENTRIES.PR_POST_ENTRIES(PHANDOFF                        (I - 1)
                                                 .AC_BRANCH,
                                                 PHANDOFF                        (I - 1)
                                                 .RELATED_ACCOUNT,
                                                 ICPKS_PARTITION_INFO.G_THIS_PART,
                                                 FALSE,
                                                 P_ERR_FLAG);
        END IF;
      END IF;
    END LOOP;
    DBG('here 44');
    DBG('Calling pr_post_entries for last record: : ' || PHANDOFF(PHANDOFF.COUNT)
        .AC_BRANCH || ' Acc: ' || PHANDOFF(PHANDOFF.COUNT).RELATED_ACCOUNT ||
        ' Seq No: ' || ICPKS_PARTITION_INFO.G_THIS_PART);
    ICPKS_DEFERRED_ENTRIES.PR_POST_ENTRIES(PHANDOFF                        (PHANDOFF.COUNT)
                                           .AC_BRANCH,
                                           PHANDOFF                        (PHANDOFF.COUNT)
                                           .RELATED_ACCOUNT,
                                           ICPKS_PARTITION_INFO.G_THIS_PART,
                                           FALSE,
                                           P_ERR_FLAG);
    DBG('Returning from pr_post_intrday_accr_ent_fr_ac   p_err_flag = ' ||
        P_ERR_FLAG);
  END PR_POST_INTRDAY_ACCR_ENT_FR_AC;

  PROCEDURE PR_UPD_ACCR_ENT(P_ENT_HIST  ICTB_ENTRIES_HISTORY%ROWTYPE,
                            P_TAB       CHAR,
                            P_IS_UPD    CHAR,
                            P_PROCESS   NUMBER,
                            P_ENT_DT    DATE,
                            P_UPD_COUNT IN OUT NUMBER) IS
  
    L_CUR_RUN_ACCR NUMBER := 0;
  
  BEGIN
    DBG('Inside pr_upd_accr_ent ' || P_TAB || '~' || P_IS_UPD || '~' ||
        P_ENT_DT || '~');
    DBG('is it updating/inserting here-->p_ent_hist.acc=' ||
        P_ENT_HIST.ACC || '~' || 'p_ent_hist.brn=' || '~' ||
        P_ENT_HIST.BRN || 'p_ent_hist.frm_no=' || P_ENT_HIST.FRM_NO || '~' ||
        'p_ent_hist.ent_dt=' || P_ENT_HIST.ENT_DT || '~' ||
        'p_ent_hist.amt=' || P_ENT_HIST.AMT || '~' ||
        'p_ent_hist.accrued_amt' || P_ENT_HIST.ACCRUED_AMT || '~' ||
        'p_ent_hist.amt_to_accrue =' || P_ENT_HIST.AMT_TO_ACCRUE || '~' ||
        'p_ent_hist.cur_run_accr=' || P_ENT_HIST.CUR_RUN_ACCR);
  
    IF P_TAB = 'Z' AND P_IS_UPD = 'Y' THEN
      UPDATE ICTBS_ENTRIES_HIST_ZEROACCR
         SET AMT               = NVL(P_ENT_HIST.AMT, 0),
             ACCRUED_AMT       = NVL(P_ENT_HIST.ACCRUED_AMT, 0),
             CUR_RUN_ACCR      = NVL(P_ENT_HIST.CUR_RUN_ACCR, 0),
             AMT_TO_ACCRUE     = NVL(P_ENT_HIST.AMT_TO_ACCRUE, 0),
             RUN_DATE          = P_ENT_HIST.RUN_DATE,
             ENTRY_TYPE        = P_ENT_HIST.ENTRY_TYPE,
             CCY               = P_ENT_HIST.CCY,
             LCY_AMT           = NVL(P_ENT_HIST.LCY_AMT, 0),
             LAST_CUR_RUN_ACCR = NVL(P_ENT_HIST.LAST_CUR_RUN_ACCR, 0),
             CUR_RUN_ACCR_LCY  = NVL(P_ENT_HIST.CUR_RUN_ACCR_LCY, 0),
             ENTRY_PASSED      = P_ENT_HIST.ENTRY_PASSED,
             PROCESS           = NVL(P_PROCESS, 1)
       WHERE BRN = P_ENT_HIST.BRN
         AND ACC = P_ENT_HIST.ACC
         AND PROD = P_ENT_HIST.PROD
         AND FRM_NO = P_ENT_HIST.FRM_NO
         AND ENT_DT = NVL(P_ENT_HIST.ENT_DT, P_ENT_DT)
         AND PROCESS = NVL(P_PROCESS, 1);
    
      P_UPD_COUNT := SQL%ROWCOUNT;
    ELSIF P_TAB = 'A' AND P_IS_UPD = 'Y' THEN
      DBG('is it updating here-->' || P_ENT_HIST.ACC || '~' ||
          P_ENT_HIST.BRN);
      L_CUR_RUN_ACCR := P_ENT_HIST.CUR_RUN_ACCR;
      UPDATE ICTBS_ENTRIES_HISTORY_ACCR
         SET AMT         = NVL(P_ENT_HIST.AMT, 0),
             ACCRUED_AMT = NVL(P_ENT_HIST.ACCRUED_AMT, 0)
             
            ,
             CUR_RUN_ACCR = NVL(P_ENT_HIST.CUR_RUN_ACCR, 0)
             
            ,
             AMT_TO_ACCRUE = NVL(P_ENT_HIST.AMT_TO_ACCRUE, 0),
             RUN_DATE      = P_ENT_HIST.RUN_DATE,
             ENTRY_TYPE    = P_ENT_HIST.ENTRY_TYPE,
             CCY           = P_ENT_HIST.CCY
             
            ,
             LCY_AMT = NVL(P_ENT_HIST.LCY_AMT, 0)
             
            ,
             CUR_RUN_ACCR_LCY = NVL(P_ENT_HIST.CUR_RUN_ACCR_LCY, 0)
             
            ,
             ENTRY_PASSED = P_ENT_HIST.ENTRY_PASSED,
             PROCESS      = NVL(P_PROCESS, 1)
       WHERE BRN = P_ENT_HIST.BRN
         AND ACC = P_ENT_HIST.ACC
         AND PROD = P_ENT_HIST.PROD
         AND FRM_NO = P_ENT_HIST.FRM_NO
         AND ENT_DT = NVL(P_ENT_HIST.ENT_DT, P_ENT_DT)
         AND PROCESS = NVL(P_PROCESS, 1)
      
      RETURNING CUR_RUN_ACCR INTO L_CUR_RUN_ACCR;
      DBG('after update cur_run_accr is ' || L_CUR_RUN_ACCR);
    
      P_UPD_COUNT := SQL%ROWCOUNT;
    
      IF P_UPD_COUNT > 0 AND L_CUR_RUN_ACCR = 0 AND
         NVL(P_ENT_HIST.AMT, 0) = 0 AND NVL(P_ENT_HIST.ACCRUED_AMT, 0) = 0 AND
         NVL(P_ENT_HIST.AMT_TO_ACCRUE, 0) = 0 THEN
        P_UPD_COUNT := -1;
      END IF;
    
    ELSIF P_TAB = 'Z' AND P_IS_UPD = 'N' THEN
      INSERT INTO ICTB_ENTRIES_HIST_ZEROACCR
        (BRN,
         ACC,
         PROD,
         FRM_NO,
         ENT_DT,
         AMT,
         ACCRUED_AMT,
         CUR_RUN_ACCR,
         AMT_TO_ACCRUE,
         RUN_DATE,
         ENTRY_TYPE,
         CCY,
         LCY_AMT,
         CUR_RUN_ACCR_LCY,
         LAST_CUR_RUN_ACCR,
         DRCR,
         ENTRY_PASSED,
         PROCESS)
      VALUES
        (P_ENT_HIST.BRN,
         P_ENT_HIST.ACC,
         P_ENT_HIST.PROD,
         P_ENT_HIST.FRM_NO,
         NVL(P_ENT_HIST.ENT_DT, P_ENT_DT),
         NVL(P_ENT_HIST.AMT, 0),
         NVL(P_ENT_HIST.ACCRUED_AMT, 0),
         NVL(P_ENT_HIST.CUR_RUN_ACCR, 0),
         NVL(P_ENT_HIST.AMT_TO_ACCRUE, 0),
         P_ENT_HIST.RUN_DATE,
         P_ENT_HIST.ENTRY_TYPE,
         P_ENT_HIST.CCY,
         NVL(P_ENT_HIST.LCY_AMT, 0),
         NVL(P_ENT_HIST.CUR_RUN_ACCR_LCY, 0),
         NVL(P_ENT_HIST.LAST_CUR_RUN_ACCR, 0),
         P_ENT_HIST.DRCR,
         P_ENT_HIST.ENTRY_PASSED,
         NVL(P_PROCESS, 1));
      P_UPD_COUNT := SQL%ROWCOUNT;
    
      DELETE FROM ICTBS_ENTRIES_HISTORY_ACCR
       WHERE BRN = P_ENT_HIST.BRN
         AND ACC = P_ENT_HIST.ACC
         AND PROD = P_ENT_HIST.PROD
         AND FRM_NO = P_ENT_HIST.FRM_NO
         AND ENT_DT = NVL(P_ENT_HIST.ENT_DT, P_ENT_DT)
         AND PROCESS = NVL(P_PROCESS, 1);
      DBG('Record Deleted from Accr ' || SQL%ROWCOUNT);
    
    ELSIF P_TAB = 'A' AND P_IS_UPD = 'N' THEN
      INSERT INTO ICTBS_ENTRIES_HISTORY_ACCR
        (BRN,
         ACC,
         PROD,
         FRM_NO,
         ENT_DT,
         AMT,
         ACCRUED_AMT,
         CUR_RUN_ACCR,
         AMT_TO_ACCRUE,
         RUN_DATE,
         ENTRY_TYPE,
         CCY,
         LCY_AMT,
         CUR_RUN_ACCR_LCY,
         DRCR,
         ENTRY_PASSED,
         PROCESS)
      VALUES
        (P_ENT_HIST.BRN,
         P_ENT_HIST.ACC,
         P_ENT_HIST.PROD,
         P_ENT_HIST.FRM_NO,
         NVL(P_ENT_HIST.ENT_DT, P_ENT_DT),
         NVL(P_ENT_HIST.AMT, 0),
         NVL(P_ENT_HIST.ACCRUED_AMT, 0),
         NVL(P_ENT_HIST.CUR_RUN_ACCR, 0),
         NVL(P_ENT_HIST.AMT_TO_ACCRUE, 0),
         P_ENT_HIST.RUN_DATE,
         P_ENT_HIST.ENTRY_TYPE,
         P_ENT_HIST.CCY,
         NVL(P_ENT_HIST.LCY_AMT, 0),
         NVL(P_ENT_HIST.CUR_RUN_ACCR_LCY, 0),
         P_ENT_HIST.DRCR,
         P_ENT_HIST.ENTRY_PASSED,
         NVL(P_PROCESS, 1));
      P_UPD_COUNT := SQL%ROWCOUNT;
    
      DELETE FROM ICTBS_ENTRIES_HIST_ZEROACCR
       WHERE BRN = P_ENT_HIST.BRN
         AND ACC = P_ENT_HIST.ACC
         AND PROD = P_ENT_HIST.PROD
         AND FRM_NO = P_ENT_HIST.FRM_NO
         AND ENT_DT = NVL(P_ENT_HIST.ENT_DT, P_ENT_DT)
         AND PROCESS = NVL(P_PROCESS, 1);
      DBG('Record Deleted from ZeroAccr ' || SQL%ROWCOUNT);
    END IF;
    DBG('Coming out from pr_upd_accr_ent ' || P_UPD_COUNT || '~');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Error is...' || SQLERRM);
      RAISE;
  END PR_UPD_ACCR_ENT;

  FUNCTION FN_PROPAGATE_TD_RATE_TO_CL(P_BRN     IN STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                      P_PROCESS IN NUMBER) RETURN BOOLEAN IS
  
    L_TD_RATE           ICTBS_UDEVALS.AMT%TYPE;
    L_TD_EFFECTIVE_DATE ICTB_UDEVALS.UDE_EFF_DT%TYPE;
    L_TD_CURRENCY       CLTB_ACCOUNT_LINKAGES.LINKED_CCY%TYPE;
    L_CL_ACCOUNT_NUMBER CLTB_ACCOUNT_LINKAGES.ACCOUNT_NUMBER%TYPE;
    L_CL_BRANCH_CODE    CLTB_ACCOUNT_LINKAGES.BRANCH_CODE%TYPE;
    L_CL_INTEREST_RATE  CLTB_ACCOUNT_UDE_VALUES.UDE_VALUE%TYPE;
    L_NEXT_WORKING_DAY  STTM_DATES.NEXT_WORKING_DAY%TYPE;
  
    TYPE TY_CUST_TD_ACCOUNTS IS TABLE OF CATMS_AMOUNT_BLOCKS%ROWTYPE INDEX BY BINARY_INTEGER;
    TB_CUST_TD_ACCOUNTS TY_CUST_TD_ACCOUNTS;
  
    CURSOR CR_CUST_TD IS
      SELECT CA.*
        FROM CATMS_AMOUNT_BLOCKS CA
       WHERE CA.BRANCH = P_BRN
         AND CA.AMOUNT_BLOCK_TYPE = 'L'
         AND CA.RECORD_STAT = 'O'
         AND CA.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND NVL(CA.EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
             GLOBAL.APPLICATION_DATE;
  
    CURSOR CR_CUST_TD_PROCESS IS
      SELECT CA.*
        FROM CATMS_AMOUNT_BLOCKS CA
       WHERE CA.BRANCH = P_BRN
         AND CA.AMOUNT_BLOCK_TYPE = 'L'
         AND CA.RECORD_STAT = 'O'
         AND CA.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE
         AND NVL(CA.EXPIRY_DATE, GLOBAL.APPLICATION_DATE) >=
             GLOBAL.APPLICATION_DATE
         AND EXISTS (SELECT 1
                FROM CSTB_CUSTACSEQ AC
               WHERE AC.BRANCH_CODE = CA.BRANCH
                 AND AC.CUST_AC_NO = CA.ACCOUNT
                 AND AC.SEQ_NO = P_PROCESS);
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    SELECT NEXT_WORKING_DAY
      INTO L_NEXT_WORKING_DAY
      FROM STTM_DATES
     WHERE BRANCH_CODE = P_BRN;
  
    IF P_IC_MAX_PROCESS = 1 THEN
      OPEN CR_CUST_TD;
      FETCH CR_CUST_TD BULK COLLECT
        INTO TB_CUST_TD_ACCOUNTS;
      CLOSE CR_CUST_TD;
    ELSE
      OPEN CR_CUST_TD_PROCESS;
      FETCH CR_CUST_TD_PROCESS BULK COLLECT
        INTO TB_CUST_TD_ACCOUNTS;
      CLOSE CR_CUST_TD_PROCESS;
    END IF;
  
    DBG('tb_cust_td_accounts.count :' || TB_CUST_TD_ACCOUNTS.COUNT);
    IF TB_CUST_TD_ACCOUNTS.COUNT > 0 THEN
      FOR TMP IN TB_CUST_TD_ACCOUNTS.FIRST .. TB_CUST_TD_ACCOUNTS.LAST LOOP
        BEGIN
          SELECT NVL((NVL(A1.AMT, 0) + NVL(A1.RATE, 0) +
                     NVL(A1.UDE_VARIANCE, 0)),
                     0),
                 A1.UDE_EFF_DT
            INTO L_TD_RATE, L_TD_EFFECTIVE_DATE
            FROM ICTB_UDEVALS A1, ICTM_PR_INT PR
           WHERE A1.PROD = PR.PRODUCT_CODE
             AND A1.COND_KEY = TB_CUST_TD_ACCOUNTS(TMP)
                .BRANCH || TB_CUST_TD_ACCOUNTS(TMP).ACCOUNT
             AND A1.UDE_ID = PR.INT_RATE_UDE
             AND A1.UDE_EFF_DT =
                 (SELECT MAX(A2.UDE_EFF_DT)
                    FROM ICTB_UDEVALS A2
                   WHERE A2.COND_KEY = TB_CUST_TD_ACCOUNTS(TMP)
                        .BRANCH || TB_CUST_TD_ACCOUNTS(TMP).ACCOUNT
                     AND A2.UDE_EFF_DT >= GLOBAL.APPLICATION_DATE
                     AND A2.UDE_EFF_DT <= L_NEXT_WORKING_DAY - 1);
        
          SELECT ACCOUNT_NUMBER, BRANCH_CODE, LINKED_CCY
            INTO L_CL_ACCOUNT_NUMBER, L_CL_BRANCH_CODE, L_TD_CURRENCY
            FROM CLTB_ACCOUNT_LINKAGES
           WHERE AMT_BLOCK_NO = TB_CUST_TD_ACCOUNTS(TMP).AMOUNT_BLOCK_NO;
        
          SELECT NVL(U.UDE_VALUE, 0)
            INTO L_CL_INTEREST_RATE
            FROM CLTB_ACCOUNT_UDE_VALUES U
           WHERE U.ACCOUNT_NUMBER = L_CL_ACCOUNT_NUMBER
             AND U.BRANCH_CODE = L_CL_BRANCH_CODE
             AND U.RATE_CODE = TB_CUST_TD_ACCOUNTS(TMP).ACCOUNT
             AND U.EFFECTIVE_DATE =
                 (SELECT MAX(U1.EFFECTIVE_DATE)
                    FROM CLTB_ACCOUNT_UDE_VALUES U1
                   WHERE U1.ACCOUNT_NUMBER = U.ACCOUNT_NUMBER
                     AND U1.BRANCH_CODE = U.BRANCH_CODE
                     AND U1.RATE_CODE = U.RATE_CODE
                     AND U1.EFFECTIVE_DATE <= GLOBAL.APPLICATION_DATE);
        
          IF L_CL_INTEREST_RATE <> L_TD_RATE THEN
            INSERT INTO CLTB_ACCOUNT_TDUDE_RATE
              (ACCOUNT_NUMBER,
               BRANCH_CODE,
               RATE_CODE,
               EFFECTIVE_DATE,
               INT_RATE,
               CCY)
            VALUES
              (L_CL_ACCOUNT_NUMBER,
               L_CL_BRANCH_CODE,
               TB_CUST_TD_ACCOUNTS(TMP).ACCOUNT,
               L_TD_EFFECTIVE_DATE,
               L_TD_RATE,
               L_TD_CURRENCY);
          
          END IF;
        
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('In No Data found. CL rate pickup not required skipping the account : ' || TB_CUST_TD_ACCOUNTS(TMP)
                .ACCOUNT);
          WHEN OTHERS THEN
            DBG('some exception. CL rate pickup not required skipping the account : ' || TB_CUST_TD_ACCOUNTS(TMP)
                .ACCOUNT);
        END;
      END LOOP;
    END IF;
  
    COMMIT;
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed --->' || SQLERRM);
      RETURN FALSE;
    
  END FN_PROPAGATE_TD_RATE_TO_CL;

  PROCEDURE PR_ICEOD_WRAP(P_BRN           VARCHAR2,
                          P_DT            DATE,
                          P_TO_DT         IN OUT DATE,
                          P_TAX_PROD      VARCHAR2,
                          P_PROCESS       NUMBER DEFAULT 1,
                          P_AC_CLASS_TYPE IN ICTBS_ACC_PR.AC_CLASS_TYPE%TYPE) IS
    CURSOR CUR_ICTB_ACCPR IS
      SELECT P.BRN,
             P.ACC,
             P.PROD,
             P.SC_MAP_DT,
             P.GC_MAP_DT,
             P.LAST_CALC_DT,
             P.LAST_LIQ_DT,
             P.NEXT_LIQ_DT,
             P.LAST_ACCR_DT,
             P.NEXT_ACCR_DT,
             P.LAST_SCHD_LIQ_DT,
             P.INC_MTH,
             P.NEXT_SCHD_LIQ_DT,
             P.FIRST_CALC_DT,
             P.NEXT_SCHD_ACCR_DT,
             P.PROD_TYPE,
             P.HAS_ACCR,
             P.NEXT_CALC_DT,
             P.PROD_ACCR,
             P.HAS_PROBLEMS,
             P.BKVAL_MINCALC_DATE,
             P.BKVAL_RECALC_FLAG,
             P.FIRST_FIRST_CALC_DATE,
             P.IMAT_PROBLEMS,
             P.DEPOSIT,
             P.ACLASS,
             P.CCY,
             P.PROCESS,
             P.NEXT_EVENT_DT,
             P.DEFER_LIQ_DT,
             P.ROWID
             
            ,
             P.SYS_AC_LEVEL,
             P.SUBLEVEL
             
            ,
             P.RECALC_ACCR_ON_LIQN
        FROM ICTBS_ACC_PR P
      
       WHERE P.BRN = P_BRN
            
         AND P.NEXT_EVENT_DT <= P_TO_DT
         AND P.PROD_TYPE IN ('I', 'P')
         AND P.HAS_PROBLEMS = 'N'
            
         AND COALESCE(P.STOP_IC, 'N') = 'N'
         AND COALESCE(P.TAX_PRODUCT, 'N') = P_TAX_PROD
         AND COALESCE(P.PROCESS, 1) = COALESCE(P_PROCESS, 1)
            
         AND P.AC_CLASS_TYPE = P_AC_CLASS_TYPE
      
       ORDER BY P.SYS_AC_LEVEL,
                P.SUBLEVEL,
                
                P.ACLASS,
                P.CCY,
                P.NEXT_EVENT_DT,
                P.ACC,
                P.PROD;
  
    L_ACC    STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_BRN    STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_PROD   ICTBS_ACC_PR.PROD%TYPE;
    L_ACLASS STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY    STTMS_CUST_ACCOUNT.CCY%TYPE;
  
    L_ACLASS_NEXT STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;
    L_CCY_NEXT    STTMS_CUST_ACCOUNT.CCY%TYPE;
    REC_NO_NEXT   NUMBER;
  
    L_IS_HOLIDAY   VARCHAR2(1);
    L_PROD_NEXT    ICTB_ACC_PR.PROD%TYPE;
    ERRMSG         VARCHAR2(2000);
    EPRM           VARCHAR2(2000);
    CALC_DONE      BOOLEAN := FALSE;
    J              INTEGER := 0;
    L_LAST_REC     BINARY_INTEGER;
    REC_CHAR       VARCHAR2(10);
    REC_CHAR_NEXT  VARCHAR2(10);
    IACR_CNT       NUMBER;
    REC_NO         NUMBER;
    VD_ERR         VARCHAR2(255);
    VD_ERP         VARCHAR2(255);
    L_UDE_ID       ICTMS_PR_INT_UDEVALS.UDE_ID%TYPE;
    L_UDE_VALUE    ICTMS_PR_INT_UDEVALS.UDE_VALUE%TYPE;
    L_RATE_CODE    ICTMS_PR_INT_UDEVALS.RATE_CODE%TYPE;
    L_TD_RATE_CODE ICTMS_PR_INT_UDEVALS.TD_RATE_CODE%TYPE;
  
    L_UDE_VARIANCE ICTMS_ACC_UDEVALS.UDE_VARIANCE%TYPE;
    TYPE TY_UDE_VARIANCE IS TABLE OF ICTM_ACC_UDEVALS.UDE_VARIANCE%TYPE INDEX BY BINARY_INTEGER;
    TB_UDE_VARIANCE TY_UDE_VARIANCE;
  
    L_REDEM_DATE      DATE;
    L_REDEMPTION_TYPE VARCHAR2(1);
    L_AC_CLASS_TYPE   VARCHAR2(1);
  
    TYPE TYPPRECS IS RECORD(
      DAY        NUMBER,
      REC_LIST   LONG,
      PROCESS_DT DATE);
    TYPE TB_PRECS IS TABLE OF TYPPRECS INDEX BY BINARY_INTEGER;
    TB_REPOP_ACC    ICPKS_TEST.TICNT2;
    TB_REPOP_BRN    ICPKS_TEST.TICNT1;
    TB_REPOP_PROD   ICPKS_TEST.TICNT3;
    TB_REPOP_LIQ_DT ICPKS_TEST.TICNT13;
    TB_REPOP_CCY    ICPKS_TEST.TB14;
  
    TB_REPOP_ACC_BAK    ICPKS_TEST.TICNT2;
    TB_REPOP_BRN_BAK    ICPKS_TEST.TICNT1;
    TB_REPOP_PROD_BAK   ICPKS_TEST.TICNT3;
    TB_REPOP_LIQ_DT_BAK ICPKS_TEST.TICNT13;
    TB_REPOP_CCY_BAK    ICPKS_TEST.TB14;
  
    PROCESS_THESE TB_PRECS;
    A             DATE;
    B             VARCHAR2(32767);
    LAST_POS      PLS_INTEGER := NULL;
    LAST_POS_NEXT PLS_INTEGER := NULL;
    LAST_REC_NO   NUMBER := 0;
    JSP           NUMBER := 0;
    BUG1          BINARY_INTEGER;
    L_PREVREC     INTEGER := 0;
    REPOP_ACC     ICTBS_ACC_PR.ACC%TYPE;
    ACPR_LOOP_EXCPTN     EXCEPTION;
    DO_PROCESS_EXCPN     EXCEPTION;
    EXCPN_FOR_ACC        EXCEPTION;
    PRD_ACCR_LIQNET_EXCP EXCEPTION;
    L_ACC_STATUS STTMS_CUST_ACCOUNT.ACC_STATUS%TYPE;
    L_WHAT       VARCHAR2(255);
    N_PART       NUMBER;
    RETSTAT      INTEGER;
    K            NUMBER;
    L_JOB_NAME   USER_SCHEDULER_JOBS.JOB_NAME%TYPE;
    L_CCY_BOOK   STTMS_CUST_ACCOUNT.CCY%TYPE;
  
    R_PR1           REC_PRINT;
    L_DEFERRED_FLAG ICTM_PR_INT.DEFERRED_FLAG%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_COMP_FLAG VARCHAR2(1);
  
    VDBAL_UPDATE_EXCPN EXCEPTION;
  
    BULK_ERRORS EXCEPTION;
    PRAGMA EXCEPTION_INIT(BULK_ERRORS, -24381);
    L_ERROR_INDEX INTEGER := 0;
  
    CURSOR C_JOB IS
    
      SELECT 1
        FROM ICTB_JOB_CTL
       WHERE FUNCTION_ID = 'VDBALUPD'
         AND BRN = P_BRN
            
         AND STATUS IS NULL
         AND PROCESS = P_PROCESS;
  
    L_ACCOUNT     ILTMS_ACCOUNT.ACCOUNT%TYPE;
    L_BOOKING_BRN ILTBS_SYS_ACCOUNT.BOOKING_ACC_BRANCH%TYPE;
    L_BOOKING_ACC ILTBS_SYS_ACCOUNT.BOOKING_ACC%TYPE;
    L_ACC_BRANCH  ILTBS_SYS_ACCOUNT.BRANCH_CODE%TYPE;
  
    TB_REPOP_ACC_BAK    ICPKS_TEST.TICNT2;
    TB_REPOP_BRN_BAK    ICPKS_TEST.TICNT1;
    TB_REPOP_PROD_BAK   ICPKS_TEST.TICNT3;
    TB_REPOP_LIQ_DT_BAK ICPKS_TEST.TICNT13;
    TB_REPOP_CCY_BAK    ICPKS_TEST.TB14;
    L_LCY_AMT           NUMBER := 0;
    P_ERR_CODE          NUMBER := 0;
    L_PROCESS_INT_ADJ   VARCHAR2(1);
  
    L_UDE_TYPE ICTM_RULE_UDE.UDE_TYPE%TYPE;
    L_RULE_ID  ICTM_RULE_UDE.RULE_ID%TYPE;
    L_CNTR1    NUMBER := 0;
    L_BRANCH   ICTM_RATES.BRANCH_CODE%TYPE;
    L_RATE     ICTM_RATES.RATE%TYPE;
  
    L_FATCA_RECORD           CHAR(1);
    L_FATCA_EXT_CUSTOMER_SDE NUMBER := NULL;
  
    L_ERR_TYPE        ERTBS_MSGS.TYPE%TYPE;
    L_ACC_STATUS_NEXT STTM_CUST_ACCOUNT.ACC_STATUS%TYPE;
  
    L_CUST_ACCOUNT ILTB_SYS_ACCOUNT.ACCOUNT%TYPE;
    L_CUST_BRANCH  ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE;
  
    TB_ACCR_HOFF_CONS ACPKS.TBL_ACHOFF;
    TB_LIQN_HOFF_CONS ACPKS.TBL_ACHOFF;
    L_ACCR_CNTR       NUMBER;
    L_LIQN_CNTR       NUMBER;
    L_COUNT           NUMBER;
    L_INDEX           INTEGER;
    L_IDX             INTEGER;
    L_UPD_COUNT       NUMBER;
    L_ERR_FLAG        NUMBER;
    L_P_DT            DATE := P_DT;
  
    TYPE TY_TB_EVENT_DATES IS TABLE OF DATE INDEX BY VARCHAR2(23);
    L_TB_ACC_EVENT_DATES TY_TB_EVENT_DATES;
    L_TMP_PROCESS_DT     DATE;
  
    TYPE TY_TB_EVENT_DATES_1 IS TABLE OF NUMBER INDEX BY VARCHAR2(23);
    L_TB_ACC_LIQN_RECDS TY_TB_EVENT_DATES_1;
  
    L_IC_SKIP_RECALC_LIQN NUMBER := 0;
  
    K_TB1                          NUMBER := 0;
    TB_ICENT_HIST_BRN_TEST         TB1;
    TB_ICENT_HIST_ACC_TEST         TB2;
    TB_ICENT_HIST_PROD_TEST        TB3;
    TB_ICENT_HIST_FRM_NO_TEST      TB4;
    TB_ICENT_HIST_AMT_TEST         TB6;
    TB_ICENT_HIST_ACCRUED_AMT_TEST TB7;
    TB_ICENT_HIST_CUR_RUN_ACCR_T   TB9;
    TB_ICENT_HIST_AMT_TO_ACCRUE_T  TB8;
    TB_ICENT_HIST_RUN_DATE_TEST    TB10;
    TB_ICENT_HIST_ENTRY_TYPE_TEST  TB13;
    TB_ICENT_HIST_CCY_TEST         TB14;
    TB_ICENT_HIST_LCY_AMT_TEST     TB15;
    TB_ICENT_HIST_CURACCR_LCY_TEST TB15;
    TB_ICENT_HIST_ENTRY_PASSED_T   TB17;
    TB_ICENT_HIST_ACCR_TEST        TB11;
    TB_ICENT_HIST_LIQN_TEST        TB12;
    TB_ICENT_HIST_LAST_CUR_ACCR_T  TB16;
  
    PROCEDURE PR_APPEND(P_EVE_DATE DATE, P_RECORD NUMBER) IS
      DAY        NUMBER;
      L_DAY      NUMBER;
      L_REC_LIST LONG;
    BEGIN
      DAY   := TB_NEXT_EVENT_DT(P_RECORD) - MIN_EVENT_DT;
      L_DAY := DAY;
      IF NOT PROCESS_THESE.EXISTS(L_DAY) THEN
        DBG('this is the first record for the day');
        PROCESS_THESE(L_DAY).REC_LIST := P_RECORD;
        DBG('reclist populated as' || P_RECORD || '~' || P_EVE_DATE);
        PROCESS_THESE(L_DAY).PROCESS_DT := P_EVE_DATE;
        DBG('day is' || L_DAY);
        PROCESS_THESE(L_DAY).DAY := L_DAY;
      ELSE
        PROCESS_THESE(L_DAY).PROCESS_DT := P_EVE_DATE;
      
        L_REC_LIST := '~' || PROCESS_THESE(L_DAY).REC_LIST || '~';
      
        IF INSTR(L_REC_LIST, '~' || P_RECORD || '~', 1) = 0 THEN
        
          PROCESS_THESE(L_DAY).REC_LIST := PROCESS_THESE(L_DAY)
                                           .REC_LIST || '~' || P_RECORD;
        END IF;
      END IF;
      DBG('process_these(l_day).rec_list ' || PROCESS_THESE(L_DAY)
          .REC_LIST);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('in append giving hand with ' || '~' || SQLERRM);
        LOG_PROBLEM(P_RECORD,
                    'c',
                    'pr_append ' || SUBSTR(SQLERRM, 1, 1950));
        RAISE;
    END PR_APPEND;
  
    PROCEDURE PR_DO_PROCESS(P_REC_NO NUMBER, P_DT DATE) IS
      I             NUMBER;
      J             NUMBER := 0;
      L_START_INDEX BINARY_INTEGER;
      LAST_REC      NUMBER := 0;
      H             BINARY_INTEGER;
      L_EXIST       BOOLEAN;
      L_END_INDEX   BINARY_INTEGER;
      L_COUNT       NUMBER := 0;
      L_UPD         BOOLEAN;
      REPOP_PROD    ICTBS_ACC_PR.PROD%TYPE;
      REPOP_ACLASS  ICTBS_ACC_PR.ACLASS%TYPE;
      REPOP_CCY     ICTBS_ACC_PR.CCY%TYPE;
      PREV_COUNT    NUMBER := 0;
      K             NUMBER := 0;
      L_ENTRY_COUNT NUMBER := 0;
      X             VARCHAR2(10);
      Y             VARCHAR2(10);
      POS           NUMBER;
      POS1          NUMBER;
      CALC_ACC      STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
      R_PRINT       ICPKSS_TEST.REC_PRINT;
      L_MONTH_END   DATE;
      ACNTG_FAILED EXCEPTION;
      CALL_FAILED  EXCEPTION;
      L_CNTR          NUMBER := 0;
      L_BRNCD         ICTMS_PR_INT_UDEVALS.BRANCH_CODE%TYPE;
      SR_NO           NUMBER;
      L_XRATE         NUMBER;
      L_JOB_NAME      USER_SCHEDULER_JOBS.JOB_NAME%TYPE;
      L_NEXT_CALC_DT  ICTBS_ENTRIES.NEXT_CALC_DUE_DATE%TYPE;
      L_PR_INT_ACLASS ICTMS_PR_INT_ACLASS%ROWTYPE;
    
      ADAY                CHAR(2);
      L_RECALC_CURR_CYCLE BOOLEAN := TRUE;
    
      L_BKUP_NEXT_ACCR_DATE    DATE;
      L_BKUP_NEXT_SCHD_ACCR_DT DATE;
    
      --sampath starts
      L_AC_OPEN_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
      --sampath ends
    
    BEGIN
      I := P_REC_NO;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        L_FN_CALL_ID := 14;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('i') := I;
      
        L_TB_CLUSTER_DATA('l_prod') := L_PROD;
        L_TB_CLUSTER_DATA('l_acc_status') := L_ACC_STATUS;
      
        ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                         P_DT,
                                         P_TO_DT,
                                         P_TAX_PROD,
                                         P_PROCESS,
                                         P_AC_CLASS_TYPE,
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
      
        IF GLOBAL.G_SKIP_KERNEL THEN
          L_PREVREC := L_TB_CLUSTER_DATA('i');
        
          L_PROD       := L_TB_CLUSTER_DATA('l_prod');
          L_ACC_STATUS := L_TB_CLUSTER_DATA('l_acc_status');
        
          GLOBAL.PR_RESET_SKIP_KERNEL;
        
          RETURN;
        END IF;
      END IF;
    
      L_BKUP_NEXT_ACCR_DATE    := NULL;
      L_BKUP_NEXT_SCHD_ACCR_DT := NULL;
    
      DBG('inside do process for :' || I || ' - ' || P_DT);
      TB_ICENT.DELETE;
      TB_PAST_ADJ_ICENT.DELETE;
      IF NVL(TB_ACC(I), '###') <> NVL(L_ACC, '***') THEN
        DBG('account is different ' || TB_ACC(I) || '~' || L_ACC || '~' ||
            TB_HOFF_CONS.COUNT);
      
        NULL;
      
      END IF;
      PR_TAKE_PLSQL_TAB_BAK;
      DBG('entered into do process for' || TB_ACC(I) || ' - ' || TB_CCY(I) || '~' ||
          TB_ACLASS(I));
      DBG('here aclass ,ccy is ' || L_ACLASS || '~' || L_CCY);
      IF NVL(TB_ACLASS(I), '***') <> NVL(L_ACLASS, '###') OR
         NVL(TB_CCY(I), '****') <> NVL(L_CCY, '###') THEN
        DBG('account class/ ccy change ' || TB_ACLASS(I) || '~' ||
            TB_CCY(I) || 'old is ' || L_CCY || '~' || L_ACLASS);
        DBG('account class type is ' || G_ACC_TYPE);
      
        G_ACC_TYPE := CSPKS_FUNCTION_CACHE.FN_GET_ACC_CLASS_REC_FRC(TB_ACLASS(I))
                      .AC_CLASS_TYPE;
      
        DBG('account class type is ' || G_ACC_TYPE);
        G_STTM_CUSTACC.CCY := TB_CCY(I);
        L_ACLASS           := TB_ACLASS(I);
        L_CCY              := TB_CCY(I);
      END IF;
      DBG('accrual at prod level is completed sucessfully');
      DBG('check for the if conditions');
      DBG(TB_ACC(I) || 'tb_acc(i) <> l_acc' || L_ACC);
      DBG(TB_BRN(I) || ' tb_brn(i) <> l_brn ' || L_BRN);
      SAVEPOINT ABOUT_TO_PROCESS;
      IF NVL(TB_ACC(I), '***') <> NVL(L_ACC, '###') OR
         NVL(TB_BRN(I), '***') <> NVL(L_BRN, '###') THEN
        DBG('getting ictm_acc custacc media');
        DBG('getting the ictms_acc parameters for brn ' || TB_ACC(I));
      
        IF TB_SYS_AC_LEVEL(I) IS NOT NULL THEN
          DBG('Before selecting account for system_account in iltbs_sys_account - ' ||
              TB_ACC(I));
          SELECT ACCOUNT, BOOKING_ACC_BRANCH, BOOKING_ACC, BRANCH_CODE
            INTO L_ACCOUNT, L_BOOKING_BRN, L_BOOKING_ACC, L_ACC_BRANCH
            FROM ILTBS_SYS_ACCOUNT
          
           WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
             AND SYSTEM_ACCOUNT = TB_ACC(I);
          DBG('Before selecting from ictm_acc for account - ' || L_ACCOUNT);
          SELECT *
            INTO G_ICTM_ACC
            FROM ICTMS_ACC
          
           WHERE BRN = L_ACC_BRANCH
             AND ACC = L_ACCOUNT;
          G_ICTM_ACC.BOOK_BRN := L_BOOKING_BRN;
          G_ICTM_ACC.BOOK_ACC := L_BOOKING_ACC;
          DBG('before selecting cust details for account - ' || L_ACCOUNT ||
              ' l_booking_brn ' || L_BOOKING_BRN || ' l_booking_acc ' ||
              L_BOOKING_ACC);
          SELECT *
            INTO G_STTM_CUSTACC
            FROM STTMS_CUST_ACCOUNT
          
           WHERE BRANCH_CODE = L_ACC_BRANCH
             AND CUST_AC_NO = L_ACCOUNT;
        
          BEGIN
          
            SELECT CCY
              INTO L_CCY_BOOK
              FROM STTMS_CUST_ACCOUNT
             WHERE BRANCH_CODE = L_BOOKING_BRN
               AND CUST_AC_NO = L_BOOKING_ACC;
          
            G_ICTM_ACC.BOOK_CCY := L_CCY_BOOK;
            DBG('l_ccy_book  ' || L_CCY_BOOK);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('aSSIGNING book_ccy  ' || G_ICTM_ACC.BOOK_CCY);
              RETURN;
          END;
        
        ELSE
        
          SELECT *
            INTO G_ICTM_ACC
            FROM ICTMS_ACC
           WHERE BRN = TB_BRN(I)
             AND ACC = TB_ACC(I);
        
          DBG('here for book_ccy  ' || G_ICTM_ACC.BOOK_CCY);
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 1;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          
            L_TB_CLUSTER_DATA('ACC') := TB_ACC(I);
            L_TB_CLUSTER_DATA('PROD') := TB_PROD(I);
            L_TB_CLUSTER_DATA('PRODTYPE') := TB_PROD_TYPE(I);
          
            ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(TB_BRN(I),
                                             P_DT,
                                             P_TO_DT,
                                             P_TAX_PROD,
                                             P_PROCESS,
                                             P_AC_CLASS_TYPE,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
          END IF;
        
          IF NVL(G_STTM_CUSTACC.CUST_AC_NO, '#12456') <> TB_ACC(I) THEN
            IF NOT ICPKS_CACHE.FN_GETCUSTACC(TB_BRN(I),
                                             TB_ACC(I),
                                             G_STTM_CUSTACC) THEN
              DBG('Could not get account');
              RETURN;
            END IF;
          END IF;
        
        END IF;
      
        IF NVL(G_BRANCH_REC.INDIVIDUAL_TAX_CERT_REQD, 'N') = 'Y' THEN
          SELECT DEFAULT_MEDIA, CUSTOMER_NAME1, INDIVIDUAL_TAX_CERT_REQD
            INTO G_DEFAULT_MEDIA, G_CUSTOMER_NAME1, G_CUST_IND_TC_REQD
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = G_STTM_CUSTACC.CUST_NO;
        ELSE
          G_DEFAULT_MEDIA := 'MAIL';
        END IF;
      
        L_ACC := TB_ACC(I);
        L_BRN := TB_BRN(I);
      END IF;
      DBG('global parameters are set');
      DBG('here acc/ brn /prod are ' || L_ACC || '~' || L_BRN || '~' ||
          L_PROD);
    
      ICPKS_PARTITION_INFO.G_THIS_PART := P_PROCESS;
    
      IF NVL(TB_PROD(I), '****') <> NVL(L_PROD, '###') OR
         NVL(G_STTM_CUSTACC.ACC_STATUS, '****') <>
         NVL(L_ACC_STATUS, '####') THEN
        PR_CACHE_PROD(TB_PROD(I), G_STTM_CUSTACC.ACC_STATUS);
        L_PROD       := TB_PROD(I);
        L_ACC_STATUS := G_STTM_CUSTACC.ACC_STATUS;
      END IF;
      DBG('after cache product' || TB_ACLASS(I));
      FIND_KEY(TB_PROD(I), R_PRINT);
    
      ICPKS_PARTITION_INFO.G_THIS_PART := NVL(P_PROCESS, 1);
      DBG('CHECKING ENTRIES FOR ' || TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
          TB_PROD(I) || '~' || ICPKS_PARTITION_INFO.G_THIS_PART || '~' ||
          P_PROCESS);
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('i') := I;
        L_TB_CLUSTER_DATA('comp_flag') := L_COMP_FLAG;
      
        ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                         P_DT,
                                         P_TO_DT,
                                         P_TAX_PROD,
                                         P_PROCESS,
                                         P_AC_CLASS_TYPE,
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
        L_COMP_FLAG := L_TB_CLUSTER_DATA('comp_flag');
      END IF;
    
      FOR CUR_ICENT IN (SELECT E.*, E.ROWID ROW_ID
                          FROM ICTBS_ENTRIES E
                         WHERE E.BRN = TB_BRN(I)
                           AND E.ACC = TB_ACC(I)
                           AND E.PROD = TB_PROD(I)
                           AND E.PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART) LOOP
        J := J + 1;
        TB_ICENT(J).ACC := CUR_ICENT.ACC;
        TB_ICENT(J).BRN := CUR_ICENT.BRN;
        TB_ICENT(J).PROD := CUR_ICENT.PROD;
        TB_ICENT(J).FRM_NO := CUR_ICENT.FRM_NO;
        TB_ICENT(J).AMT := NVL(CUR_ICENT.AMT, 0);
        TB_ICENT(J).ACCRUED_AMT := NVL(CUR_ICENT.ACCRUED_AMT, 0);
        TB_ICENT(J).AMT_TO_ACCRUE := NVL(CUR_ICENT.AMT_TO_ACCRUE, 0);
        TB_ICENT(J).CUR_RUN_ACCR := NVL(CUR_ICENT.CUR_RUN_ACCR, 0);
        TB_ICENT(J).ENT_DT := CUR_ICENT.ENT_DT;
        TB_ICENT(J).DRCR := CUR_ICENT.DRCR;
        TB_ICENT(J).HAS_ACCR := CUR_ICENT.HAS_ACCR;
        TB_ICENT(J).DAILY_AMT := NVL(CUR_ICENT.DAILY_AMT, 0);
        TB_ICENT(J).NEXT_CALC_DUE_DATE := CUR_ICENT.NEXT_CALC_DUE_DATE;
        TB_ICENT(J).ACQUIRED_AMT := NVL(CUR_ICENT.ACQUIRED_AMT, 0);
        TB_ICENT(J).ACQUIRED_ADJ := NVL(CUR_ICENT.ACQUIRED_ADJ, 0);
        TB_ICENT(J).ROW_ID := CUR_ICENT.ROW_ID;
      
        FOR CUR_PAST_ADJ_ICENT IN (SELECT E.*, E.ROWID ROW_ID
                                     FROM ICTB_PAST_ADJ_ENTRIES E
                                    WHERE E.BRN = CUR_ICENT.BRN
                                      AND E.ACC = CUR_ICENT.ACC
                                      AND E.PROD = CUR_ICENT.PROD
                                      AND E.FRM_NO = CUR_ICENT.FRM_NO) LOOP
          TB_PAST_ADJ_ICENT(J).ACQUIRED_AMT := CUR_PAST_ADJ_ICENT.ACQUIRED_AMT;
          TB_PAST_ADJ_ICENT(J).ACQUIRED_ADJ := CUR_PAST_ADJ_ICENT.ACQUIRED_ADJ;
          TB_PAST_ADJ_ICENT(J).ROW_ID := CUR_PAST_ADJ_ICENT.ROW_ID;
          DBG('J here is ##1 ' || J);
          DBG('cur_icent.acc ' || CUR_ICENT.ACC);
          DBG('tb_past_adj_icent(j).ACQUIRED_AMT ' || TB_PAST_ADJ_ICENT(J)
              .ACQUIRED_AMT);
          DBG('tb_past_adj_icent(j).ACQUIRED_adj ' || TB_PAST_ADJ_ICENT(J)
              .ACQUIRED_ADJ);
          DBG('cur_icent.prod ' || CUR_ICENT.PROD);
          DBG('cur_icent.frm_no ' || CUR_ICENT.FRM_NO);
        END LOOP;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID := 3;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('j') := J;
          L_TB_CLUSTER_DATA('tb_icent(j).acc') := TB_ICENT(J).ACC;
          L_TB_CLUSTER_DATA('tb_icent(j).brn') := TB_ICENT(J).BRN;
          L_TB_CLUSTER_DATA('tb_icent(j).prod') := TB_ICENT(J).PROD;
          L_TB_CLUSTER_DATA('tb_icent(j).frm_no') := TB_ICENT(J).FRM_NO;
        
          ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                           P_DT,
                                           P_TO_DT,
                                           P_TAX_PROD,
                                           P_PROCESS,
                                           P_AC_CLASS_TYPE,
                                           L_FN_CALL_ID,
                                           L_TB_CLUSTER_DATA);
        END IF;
      
      END LOOP;
      DBG('Record in ictb entries :' || TB_ICENT.COUNT ||
          'first and next calc dt are' || TB_FIRST_CALC_DT(I) || '~' ||
          TB_NEXT_CALC_DT(I) || '~' || P_DT || '~' || TB_NEXT_LIQ_DT(I) || '~' ||
          P_TO_DT);
    
      DBG('tb_recalc_accr_on_liqn(i) before =' ||
          TB_RECALC_ACCR_ON_LIQN(I));
      IF CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
        BEGIN
          SELECT RECALC_ACCR_ON_LIQN
            INTO TB_RECALC_ACCR_ON_LIQN(I)
            FROM ICTB_ACC_PR
           WHERE ACC = TB_ACC(I)
             AND BRN = TB_BRN(I)
             AND PROD = TB_PROD(I);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('WO Exception in getting latest value of tb_recalc_accr_on_liqn' ||
                SQLERRM);
            TB_RECALC_ACCR_ON_LIQN(I) := 'Y';
        END;
      ELSE
        TB_RECALC_ACCR_ON_LIQN(I) := 'Y';
      END IF;
    
      DBG('tb_recalc_accr_on_liqn(i) after =' || TB_RECALC_ACCR_ON_LIQN(I));
    
      IF TB_NEXT_LIQ_DT(I) <= P_TO_DT THEN
        DBG('RECALCULATION HAPPENS APPLE');
        L_RECALC_CURR_CYCLE := TRUE;
      ELSE
        --DBG('RECALCULATION DOES NOT HAPPEN APPLE');
      
        IF TB_ICENT(J).PROD IN ('SY01', 'SY02', 'GY01', 'GY02') THEN
          --sampath
        
          --  L_RECALC_CURR_CYCLE := TRUE; --sampath
        
          --GLOBAL.APPLICATION_DATE - ICPKSS_CALC.G_ICTM_ACC.INT_START_DATE + 1 --account opening date
        
          BEGIN
            SELECT ST.AC_OPEN_DATE
              INTO L_AC_OPEN_DATE
              FROM STTMS_CUST_ACCOUNT ST
             WHERE CUST_AC_NO = TB_ACC(I)
               AND BRANCH_CODE = TB_BRN(I);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_AC_OPEN_DATE := NULL;
          END;
        
          DBG('l_ac_open_date' || L_AC_OPEN_DATE);
        
          IF GLOBAL.APPLICATION_DATE - L_AC_OPEN_DATE IN
             (365, 366, 367, 368, 369, 370, 371, 372, 730, 731, 732) AND TB_ICENT(J)
            .PROD IN ('SY01', 'SY02') THEN
          
            DBG('RECALCULATION HAPPENS APPLE');
          
            L_RECALC_CURR_CYCLE := TRUE;
          
          ELSE
          
            DBG('RECALCULATION DOES NOT HAPPEN APPLE');
          
            L_RECALC_CURR_CYCLE := FALSE;
          
          END IF;
        
          IF GLOBAL.APPLICATION_DATE - L_AC_OPEN_DATE IN
             (365, 366, 367, 368, 369, 370, 371, 372) AND TB_ICENT(J)
            .PROD IN ('GY01', 'GY02') THEN
          
            DBG('RECALCULATION HAPPENS APPLE');
          
            L_RECALC_CURR_CYCLE := TRUE;
          
          ELSE
          
            DBG('RECALCULATION DOES NOT HAPPEN APPLE');
          
            L_RECALC_CURR_CYCLE := FALSE;
          
          END IF;
          --sampath
        
        ELSE
          DBG('RECALCULATION DOES NOT HAPPEN APPLE');
          L_RECALC_CURR_CYCLE := FALSE;
        
        END IF; --sampath
      
      END IF;
    
      IF TB_RECALC_ACCR_ON_LIQN(I) IS NULL THEN
        DBG('check how this is null....assigned default value as Y');
        TB_RECALC_ACCR_ON_LIQN(I) := 'Y';
      END IF;
    
      IF (((TB_NEXT_CALC_DT(I) <= P_TO_DT OR
         L_RECALC_CURR_CYCLE
         
         AND TB_FIRST_CALC_DT(I) <= P_TO_DT) AND
         TB_RECALC_ACCR_ON_LIQN(I) = 'Y') OR P_TAX_PROD = 'Y' OR
         NVL(L_COMP_FLAG, 'N') = 'Y')
      
       THEN
      
        DBG('INSIDE RECALCULATION PROCESS APPLE');
      
        DBG('TB_NEXT_LIQ_DT(I)=' || TB_NEXT_LIQ_DT(I));
      
        ICPKSS_CALC.G_ICTB_ACC_PR.BRN               := TB_BRN(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.ACC               := TB_ACC(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD              := TB_PROD(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT         := TB_SC_MAP_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT         := TB_GC_MAP_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT      := TB_LAST_CALC_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT       := TB_LAST_LIQ_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT       := TB_NEXT_LIQ_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT      := TB_LAST_ACCR_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := TB_NEXT_SCHD_ACCR_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := TB_NEXT_ACCR_DT(I);
        DBG('Next accr Dt ' || TB_NEXT_ACCR_DT(I) || '~ Next Liq Dt' ||
            TB_NEXT_LIQ_DT(I) || '~ Last Accr dt' || TB_LAST_ACCR_DT(I) ||
            '~ First Calc dt' || TB_FIRST_CALC_DT(I));
        DBG('processing' || P_DT || '~ to date ' || P_TO_DT ||
            '~ accr freq' || R_PRINT.ACCR_FREQ);
        IF NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'Y' THEN
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT := TB_NEXT_ACCR_DT(I);
        ELSE
          IF TB_HAS_ACCR(I) = 'Y' THEN
            IF (TB_NEXT_ACCR_DT(I) IS NOT NULL AND
               
               NVL(TB_NEXT_LIQ_DT(I), TB_NEXT_ACCR_DT(I)) = P_DT AND
               TB_NEXT_ACCR_DT(I) > P_DT AND
               (TB_LAST_ACCR_DT(I) < P_DT OR TB_LAST_ACCR_DT(I) IS NULL)) THEN
              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT := P_DT;
            ELSIF TB_NEXT_LIQ_DT(I) < TB_NEXT_ACCR_DT(I) THEN
              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT := TB_NEXT_LIQ_DT(I);
            ELSIF (R_PRINT.ACCR_FREQ = 'D' AND
                  P_TO_DT >= TB_FIRST_CALC_DT(I) AND
                  ((TB_NEXT_ACCR_DT(I) < P_TO_DT AND P_DT <> P_TO_DT) OR
                  
                  NVL(TB_NEXT_LIQ_DT(I), P_TO_DT) >= P_TO_DT)) THEN
              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := LEAST(NVL(TB_NEXT_LIQ_DT(I),
                                                                       P_TO_DT),
                                                                   P_TO_DT);
              ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT;
            ELSIF (R_PRINT.ACCR_FREQ = 'D' AND
                  P_TO_DT < TB_FIRST_CALC_DT(I) AND
                  ((TB_NEXT_ACCR_DT(I) < P_TO_DT AND P_DT <> P_TO_DT) OR
                  TB_NEXT_LIQ_DT(I) >= P_TO_DT)) THEN
              DBG('skipping account ' || TB_BRN(I) || ' ' || TB_ACC(I) || ' ' ||
                  TB_PROD(I) || ' as it is a future valued deposit');
              LPG('Skipping account ' || TB_BRN(I) || ' ' || TB_ACC(I) || ' ' ||
                  TB_PROD(I) || ' as it is a Future Valued Deposit',
                  '');
            
            END IF;
          END IF;
        
          L_BKUP_NEXT_ACCR_DATE    := TB_NEXT_ACCR_DT(I);
          L_BKUP_NEXT_SCHD_ACCR_DT := TB_NEXT_SCHD_ACCR_DT(I);
          DBG('l_bkup_next_accr_date~l_bkup_next_schd_accr_dt' ||
              L_BKUP_NEXT_ACCR_DATE || '~' || L_BKUP_NEXT_SCHD_ACCR_DT);
        
          TB_NEXT_ACCR_DT(I) := GREATEST(ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT,
                                         NVL(TB_LAST_LIQ_DT(I),
                                             ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT - 1) + 1);
          TB_NEXT_SCHD_ACCR_DT(I) := NVL(ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT,
                                         GREATEST(TB_NEXT_SCHD_ACCR_DT(I),
                                                  ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT));
        END IF;
        ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT := TB_LAST_SCHD_LIQ_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH          := TB_INC_MTH(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT := TB_NEXT_SCHD_LIQ_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT    := TB_FIRST_CALC_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE        := TB_PROD_TYPE(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR         := TB_HAS_ACCR(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT     := TB_NEXT_CALC_DT(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR        := TB_PROD_ACCR(I);
        ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT     := TB_DEFER_LIQ_DT(I);
        ICPKSS_CALC.G_CUST_ACC.CCY                 := TB_CCY(I);
        ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS       := TB_ACLASS(I);
      
        ICPKSS_CALC.G_ICTB_ACC_PR.BKVAL_RECALC_FLAG := TB_BKVAL_RECALC_FLAG(I);
        IF (NVL(TB_PROD(I), '***') <> NVL(REPOP_PROD, '###') OR
           NVL(TB_ACLASS(I), '***') <> NVL(REPOP_ACLASS, '###') OR
           NVL(TB_CCY(I), '***') <> NVL(REPOP_CCY, '###')) THEN
          ICPKS_UDE.PR_PREPARE_GC(TB_BRN(I),
                                  TB_ACLASS(I),
                                  TB_CCY(I),
                                  TB_PROD(I),
                                  TB_FIRST_CALC_DT(I),
                                  P_TO_DT,
                                  TB_NEXT_LIQ_DT(I));
        END IF;
        IF NVL(CALC_ACC, '****') <> NVL(TB_ACC(I), '####') THEN
          DBG('checking for acc_type --> ' || G_ICTM_ACC.ACC_TYPE);
          IF G_ICTM_ACC.ACC_TYPE = 'N' THEN
            ICPKS_SDE.PR_PREPARE_SDE(TB_BRN(I),
                                     TB_ACC(I),
                                     TB_CCY(I),
                                     P_REC_NO,
                                     LAST_REC_NO);
          ELSE
            ICPKS_SDE.PR_PREPARE_SDE_CONSOL(TB_BRN(I),
                                            TB_ACC(I),
                                            TB_CCY(I),
                                            P_REC_NO,
                                            LAST_REC_NO);
          END IF;
          CALC_ACC := TB_ACC(I);
        END IF;
        BEGIN
          DBG('calling icpkss_calc.set_acc_details for penalty value setting ' ||
              TB_ACC(I));
          ICPKSS_CALC.SET_ACC_DETAILS(TB_BRN(I), TB_ACC(I));
          DBG('calling pr_calc for ' || TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
              TB_PROD(I) || '~' || P_DT);
          PR_CALC(TB_BRN(I), TB_ACC(I), TB_PROD(I), P_DT, TB_ICENT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('in when others of calling calc ' || SQLERRM);
            LOG_PROBLEM(I,
                        'c',
                        'wot in pr_calc ' || SUBSTR(SQLERRM, 1, 1900));
            TB_ICENT.DELETE;
            RAISE;
        END;
        CALC_DONE := TRUE;
        SR_NO     := CSPKSS_UTILS.FN_HASH40(TB_PROD(I));
        DBG('the hash value ' || SR_NO);
      
        DBG('Restoring next accrual date after calc is over...' ||
            TB_NEXT_ACCR_DT(I) || '~' || TB_NEXT_SCHD_ACCR_DT(I));
      
        DBG('l_bkup_next_accr_date~l_bkup_next_schd_accr_dt' ||
            L_BKUP_NEXT_ACCR_DATE || '~' || L_BKUP_NEXT_SCHD_ACCR_DT);
      
        TB_NEXT_ACCR_DT(I) := LEAST(TB_NEXT_ACCR_DT(I),
                                    NVL(L_BKUP_NEXT_ACCR_DATE,
                                        TB_NEXT_ACCR_DT(I)));
        TB_NEXT_SCHD_ACCR_DT(I) := LEAST(TB_NEXT_SCHD_ACCR_DT(I),
                                         NVL(L_BKUP_NEXT_SCHD_ACCR_DT,
                                             TB_NEXT_SCHD_ACCR_DT(I)));
      
        DBG('done with Restoring next accrual date after calc is over...' ||
            TB_NEXT_ACCR_DT(I) || '~' || TB_NEXT_SCHD_ACCR_DT(I));
        L_BKUP_NEXT_ACCR_DATE    := NULL;
        L_BKUP_NEXT_SCHD_ACCR_DT := NULL;
      
        L_NEXT_CALC_DT := TB_NEXT_LIQ_DT(I) + 1;
        IF TB_ICENT.COUNT > 0 AND TB_PROD.EXISTS(I) THEN
          FOR REC_ICENT IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
            IF TB_ICENT(REC_ICENT).NEXT_CALC_DUE_DATE IS NOT NULL AND
                TB_PROD(I) = TB_ICENT(REC_ICENT).PROD THEN
              L_NEXT_CALC_DT := LEAST(NVL(TB_ICENT(REC_ICENT)
                                          .NEXT_CALC_DUE_DATE,
                                          L_NEXT_CALC_DT),
                                      L_NEXT_CALC_DT);
            END IF;
          END LOOP;
        END IF;
      
        IF TB_PRINT(SR_NO)
         .TAX_CATEGORY IS NULL OR
            CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
        
          DBG('Before wwerwe ' || TB_NEXT_CALC_DT(I));
        
          IF L_NEXT_CALC_DT IS NOT NULL THEN
            TB_NEXT_CALC_DT(I) := LEAST(TB_NEXT_LIQ_DT(I) + 1,
                                        L_NEXT_CALC_DT);
          ELSE
            TB_NEXT_CALC_DT(I) := TB_NEXT_LIQ_DT(I) + 1;
          END IF;
          DBG('After wwerwe ' || TB_NEXT_CALC_DT(I));
        
          DBG('after setting next calc dt to next liq dt + 1 is' ||
              TB_NEXT_CALC_DT(I));
        
        ELSE
          IF TB_PRINT(SR_NO).DEFERRED_FLAG = 'Y' THEN
            DBG('tb_defer_liq_dt(i) ' || TB_DEFER_LIQ_DT(I));
            TB_NEXT_CALC_DT(I) := LEAST(TB_NEXT_LIQ_DT(I),
                                        NVL(TB_DEFER_LIQ_DT(I),
                                            TB_NEXT_LIQ_DT(I)));
          ELSE
            TB_NEXT_CALC_DT(I) := TB_NEXT_LIQ_DT(I);
          END IF;
          DBG('setting next calc date to next liq date coz tax category is ' || TB_PRINT(SR_NO)
              .TAX_CATEGORY);
        END IF;
        IF ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS = 'N' THEN
        
          TB_LAST_CALC_DT(I) := LEAST(APPDT, NVL(TB_NEXT_LIQ_DT(I), APPDT));
        ELSE
          TB_LAST_CALC_DT(I) := P_DT;
        END IF;
        DBG('here last calc dt is ' || TB_LAST_CALC_DT(I));
      ELSE
        DBG('Calculation is skipped for acc...' || TB_ACC(I));
      END IF;
      IF NVL(TB_HAS_PROBLEMS(I), 'N') <> 'Y' THEN
        DBG('no problems so proceeding');
        IF (NVL(TB_PROD(I), '***') <> NVL(REPOP_PROD, '###') OR
           NVL(TB_ACLASS(I), '***') <> NVL(REPOP_ACLASS, '###') OR
           NVL(TB_CCY(I), '***') <> NVL(REPOP_CCY, '###')) THEN
        
          DBG('tb_prod for ' || I || ' is ' || TB_PROD(I));
          DBG('repop_prod for ' || I || ' is ' || TB_PROD(I));
          DBG('tb_aclass for ' || I || ' is ' || TB_PROD(I));
          DBG('repop_aclass for ' || I || ' is ' || TB_PROD(I));
        
          IF NVL(TB_REPOP_ACC.COUNT, 0) <> 0 THEN
            IF TB_GC.COUNT > 0 THEN
              FOR K IN TB_GC.FIRST .. TB_GC.LAST LOOP
                L_UDE_ID    := TB_GC(K).UDE_ID;
                L_UDE_VALUE := TB_GC(K).UDE_VALUE;
                L_RATE_CODE := TB_GC(K).RATE_CODE;
              
                L_TD_RATE_CODE := TB_GC(K).TD_RATE_CODE;
                DBG('and the repop parameters are ' || L_UDE_ID || ' - ' ||
                    L_UDE_VALUE);
              
                FOR I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST LOOP
                  DBG('Picking UDE variance for this account: ' ||
                      TB_REPOP_ACC(I));
                  BEGIN
                    SELECT UDE_VARIANCE
                      INTO L_UDE_VARIANCE
                      FROM (SELECT UDE_VARIANCE
                              FROM ICTMS_ACC_UDEVALS
                             WHERE ACC = TB_REPOP_ACC(I)
                               AND BRN = TB_REPOP_BRN(I)
                               AND PROD = TB_GC(K).PRODUCT_CODE
                               AND UDE_ID = L_UDE_ID
                             ORDER BY UDE_EFF_DT DESC)
                     WHERE ROWNUM = 1;
                    TB_UDE_VARIANCE(I) := L_UDE_VARIANCE;
                  
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DBG('failed in ude variance select');
                      TB_UDE_VARIANCE(I) := 0;
                  END;
                
                END LOOP;
                DBG('Selection successfull successful');
              
                BEGIN
                  FORALL I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST
                    INSERT INTO ICTMS_ACC_UDEVALS
                      (BRN,
                       ACC,
                       PROD,
                       UDE_EFF_DT,
                       UDE_ID,
                       UDE_VALUE,
                       RATE_CODE,
                       RECORD_STAT,
                       AUTH_STAT,
                       
                       TD_RATE_CODE,
                       UDE_VARIANCE)
                    VALUES
                      (TB_REPOP_BRN(I),
                       TB_REPOP_ACC(I),
                       TB_GC(K).PRODUCT_CODE,
                       TB_REPOP_LIQ_DT(I) + 1,
                       L_UDE_ID,
                       L_UDE_VALUE,
                       L_RATE_CODE,
                       'O',
                       'A',
                       
                       L_TD_RATE_CODE,
                       TB_UDE_VARIANCE(I));
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('dup val on index .. skp insert');
                END;
              END LOOP;
            
              DBG('Inserting into ictm_acc_effdt');
              BEGIN
                FORALL I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST
                  INSERT INTO ICTM_ACC_EFFDT
                    (BRN, ACC, PROD, UDE_EFF_DT, RECORD_STAT, ONCE_AUTH)
                  VALUES
                    (TB_REPOP_BRN(I),
                     TB_REPOP_ACC(I),
                     TB_REPOP_PROD(I),
                     TB_REPOP_LIQ_DT(I) + 1,
                     'O',
                     'Y');
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  DBG('dup val on index so skip insert');
              END;
              DBG('through with gc population');
              FOR S IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST LOOP
                DBG('calling icpkss_calc.pr_pop_sc for ' ||
                    TB_REPOP_BRN(S) || '~' || TB_REPOP_ACC(S) || '~' ||
                    TB_REPOP_PROD(S) || '~' || P_DT || '~' ||
                    TB_REPOP_CCY(S));
                ICPKSS_CALC.PR_POP_SC(TB_REPOP_BRN(S),
                                      TB_REPOP_ACC(S),
                                      TB_REPOP_PROD(S),
                                      P_DT + 1,
                                      TB_REPOP_CCY(S));
                REPOP_CASE := TRUE;
              END LOOP;
            END IF;
            TB_REPOP_ACC.DELETE;
            TB_REPOP_BRN.DELETE;
            TB_REPOP_CCY.DELETE;
            TB_REPOP_LIQ_DT.DELETE;
            TB_GC.DELETE;
            TB_UDE_VARIANCE.DELETE;
            DBG('coming out of gc and sc population');
          END IF;
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID := 22;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
            L_TB_CLUSTER_DATA('g_sttm_custacc.account_class') := G_STTM_CUSTACC.ACCOUNT_CLASS;
            L_TB_CLUSTER_DATA('g_sttm_custacc.ccy') := G_STTM_CUSTACC.CCY;
            ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                             P_DT,
                                             P_TO_DT,
                                             P_TAX_PROD,
                                             P_PROCESS,
                                             P_AC_CLASS_TYPE,
                                             L_PR_INT_ACLASS,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
          END IF;
        
          IF NOT GLOBAL.G_SKIP_KERNEL THEN
          
            L_PR_INT_ACLASS := ICPKS_CACHE.FN_GET_INT_ACLASS_FRC(TB_PROD(I),
                                                                 G_STTM_CUSTACC.ACCOUNT_CLASS,
                                                                 G_STTM_CUSTACC.CCY);
          
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          REPOP := L_PR_INT_ACLASS.REPOP_AT_LIQ;
          DBG('Repop after  cache-->' || REPOP);
          L_RULE_ID := ICPKS_CACHE.FN_GET_PR_INT_FRC(TB_PROD(I)).RULE;
          DBG('rule id after  cache-->' || L_RULE_ID);
          DBG('rule id from print-->' || R_PRINT.RULE);
        
          DBG('Rule is got as ' || L_RULE_ID);
        
          DBG('got the repop for aclass ' || G_STTM_CUSTACC.ACCOUNT_CLASS || '~' ||
              G_STTM_CUSTACC.CCY);
          DBG('repop is ' || REPOP);
          TB_GC.DELETE;
          IF REPOP = 'Y' THEN
            DBG('going to take the gc into the pl/sql table');
            SELECT COUNT(*)
              INTO L_CNTR
              FROM ICTMS_PR_INT_EFFDT
             WHERE BRANCH_CODE = TB_BRN(I)
               AND ACLASS = TB_ACLASS(I)
               AND CCY_CODE = TB_CCY(I)
               AND PRODUCT_CODE = TB_PROD(I)
               AND RECORD_STAT = 'O'
               AND AUTH_STAT = 'A';
            IF L_CNTR > 0 THEN
              L_BRNCD := TB_BRN(I);
            ELSE
              L_BRNCD := 'ALL';
            END IF;
            FOR GC IN (SELECT U.*
                         FROM ICTMS_PR_INT_UDEVALS U, ICTMS_ACC_PR P
                        WHERE U.BRANCH_CODE = L_BRNCD
                          AND U.ACLASS = TB_ACLASS(I)
                          AND U.CCY_CODE = TB_CCY(I)
                          AND U.PRODUCT_CODE = TB_PROD(I)
                          AND U.UDE_EFF_DT <= P_DT + 1
                          AND U.UDE_EFF_DT =
                              (SELECT NVL(MAX(E.UDE_EFF_DT), P_DT + 2)
                                 FROM ICTMS_PR_INT_EFFDT E
                                WHERE E.BRANCH_CODE = L_BRNCD
                                  AND E.ACLASS = TB_ACLASS(I)
                                  AND E.CCY_CODE = TB_CCY(I)
                                  AND E.PRODUCT_CODE = TB_PROD(I)
                                  AND E.UDE_EFF_DT <= P_DT + 1
                                  AND E.RECORD_STAT = 'O'
                                  AND E.AUTH_STAT = 'A')
                          AND P.BRN = TB_BRN(I)
                          AND P.ACC = TB_ACC(I)
                          AND P.PROD = TB_PROD(I)
                          AND P.WAIVE = 'N') LOOP
              K := K + 1;
            
              DBG('Rule id-->' || R_PRINT.RULE);
              L_UDE_TYPE := ICPKS_CACHE.FN_GET_RULE_UDE_FRC(L_RULE_ID, GC.UDE_ID)
                            .UDE_TYPE;
            
              DBG('udetype is :' || L_UDE_TYPE || '~' || GC.RATE_CODE || '~');
              IF L_UDE_TYPE = 'C' AND GC.RATE_CODE IS NOT NULL THEN
                L_RATE_CODE := NULL;
                BEGIN
                  SELECT COUNT(*)
                    INTO L_CNTR1
                    FROM ICTMS_RATES
                   WHERE BRANCH_CODE = TB_BRN(I)
                     AND RATE_CODE = GC.RATE_CODE
                     AND CCY_CODE = TB_CCY(I)
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A';
                
                  IF L_CNTR1 > 0 THEN
                    L_BRANCH := TB_BRN(I);
                  ELSE
                    L_BRANCH := 'ALL';
                  END IF;
                  SELECT RATE
                    INTO L_RATE
                    FROM ICTMS_RATES
                   WHERE BRANCH_CODE = L_BRANCH
                     AND RATE_CODE = GC.RATE_CODE
                     AND CCY_CODE = TB_CCY(I)
                     AND EFF_DT <= P_DT + 1
                     AND EFF_DT = (SELECT NVL(MAX(EFF_DT), P_DT + 2)
                                     FROM ICTM_RATES
                                    WHERE RATE_CODE = GC.RATE_CODE
                                      AND BRANCH_CODE = L_BRANCH
                                      AND CCY_CODE = TB_CCY(I)
                                      AND EFF_DT <= P_DT + 1
                                      AND RECORD_STAT = 'O'
                                      AND AUTH_STAT = 'A')
                     AND RECORD_STAT = 'O'
                     AND AUTH_STAT = 'A';
                EXCEPTION
                  WHEN OTHERS THEN
                    L_RATE := 0;
                END;
                L_UDE_VALUE := NVL(GC.UDE_VALUE, 0) + L_RATE;
              ELSIF L_UDE_TYPE = 'C' AND GC.TD_RATE_CODE IS NOT NULL THEN
                L_RATE_CODE    := NULL;
                L_UDE_VALUE    := NVL(GC.UDE_VALUE, 0);
                L_TD_RATE_CODE := GC.TD_RATE_CODE;
              ELSE
                L_RATE_CODE    := GC.RATE_CODE;
                L_UDE_VALUE    := GC.UDE_VALUE;
                L_TD_RATE_CODE := NULL;
              END IF;
            
              DBG('going to take ude' || GC.UDE_ID);
              TB_GC(K).PRODUCT_CODE := GC.PRODUCT_CODE;
              TB_GC(K).ACLASS := GC.ACLASS;
              TB_GC(K).CCY_CODE := GC.CCY_CODE;
              TB_GC(K).UDE_EFF_DT := GC.UDE_EFF_DT;
              TB_GC(K).UDE_ID := GC.UDE_ID;
            
              TB_GC(K).UDE_VALUE := L_UDE_VALUE;
              TB_GC(K).RATE_CODE := L_RATE_CODE;
              TB_GC(K).TD_RATE_CODE := L_TD_RATE_CODE;
            
            END LOOP;
            DBG('through with repop');
          END IF;
          REPOP_PROD   := TB_PROD(I);
          REPOP_ACLASS := TB_ACLASS(I);
          REPOP_CCY    := TB_CCY(I);
          DBG('changed the repop set variables');
        END IF;
        IF REPOP = 'Y' AND TB_NEXT_LIQ_DT(I) = P_DT AND
           NVL(TB_ACC(I), '###') <> NVL(REPOP_ACC, '***') AND
           TB_GC.COUNT > 0 THEN
          DBG('repopulate on liquidation for acc' || ' - ' || TB_ACC(I) ||
              ' - ' || TB_CCY(I));
          PREV_COUNT := NVL(TB_REPOP_ACC.COUNT, 0) + 1;
        
          DBG('l_account :' || L_ACCOUNT);
          DBG('tb_acc(i) :' || TB_ACC(I));
          IF TB_SYS_AC_LEVEL(I) IS NOT NULL THEN
            TB_REPOP_ACC(PREV_COUNT) := L_ACCOUNT;
            DBG('Inside not null condition');
          ELSE
            TB_REPOP_ACC(PREV_COUNT) := TB_ACC(I);
            DBG('Inside null condition');
          END IF;
        
          TB_REPOP_BRN(PREV_COUNT) := TB_BRN(I);
          TB_REPOP_PROD(PREV_COUNT) := TB_PROD(I);
          TB_REPOP_CCY(PREV_COUNT) := TB_CCY(I);
          TB_REPOP_LIQ_DT(PREV_COUNT) := TB_NEXT_LIQ_DT(I);
          REPOP_ACC := TB_ACC(I);
        END IF;
        DBG('complete end of repop');
      
        IF G_ACC_TYPE = 'Y' THEN
          BEGIN
            SELECT DISTINCT A.REDEM_DATE, REDEMPTION_TYPE
              INTO L_REDEM_DATE, L_REDEMPTION_TYPE
              FROM ICTB_REDEMPTION_DETAIL A
             WHERE A.BRN = TB_BRN(I)
               AND A.ACC = TB_ACC(I)
               AND A.REDEMPTION_TYPE IN ('M', 'F');
            DBG('l_redem_date in iceod wrap****** ' || L_REDEM_DATE);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_REDEM_DATE := NULL;
          END;
        
        ELSE
          L_REDEM_DATE := NULL;
        END IF;
      
        DBG('l_redem_date in iceod wrap****** ' || L_REDEM_DATE);
        DBG('global.application_date in iceod wrap****** ' ||
            GLOBAL.APPLICATION_DATE);
        DBG('l_redemption_type in iceod wrap****** ' || L_REDEMPTION_TYPE);
        IF (L_REDEM_DATE IS NOT NULL AND
           L_REDEM_DATE <> GLOBAL.APPLICATION_DATE) OR
           (L_REDEM_DATE IS NOT NULL AND L_REDEMPTION_TYPE = 'M') THEN
          TB_HAS_ACCR(I) := 'N';
          DBG(' tb_has_accr(i) set as iceod wrap****** ' || TB_HAS_ACCR(I));
        END IF;
        DBG(' tb_has_accr(i) set as iceod wrap****** ' || TB_HAS_ACCR(I));
      
        L_ENTRY_COUNT := TB_ICENT.COUNT;
        DBG('entry count here for tb_icent is ' || L_ENTRY_COUNT);
        IF L_ENTRY_COUNT <> 0 THEN
          DBG('next accr dt is ' || TB_NEXT_ACCR_DT(I) ||
              'tb_recalc_accr_on_liqn(i)=' || TB_RECALC_ACCR_ON_LIQN(I));
        
          L_P_DT := P_DT;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 21;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                             P_DT,
                                             P_TO_DT,
                                             P_TAX_PROD,
                                             P_PROCESS,
                                             P_AC_CLASS_TYPE,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
          
            IF L_TB_CLUSTER_DATA.EXISTS('l_p_dt') THEN
              L_P_DT := L_TB_CLUSTER_DATA('l_p_dt');
            END IF;
          
          END IF;
        
          IF TB_NEXT_ACCR_DT(I) <= P_DT AND TB_HAS_ACCR(I) = 'Y'
          
           THEN
            DBG('pr_accrue being called');
            BEGIN
              PR_ACCRUE(P_DT, I, TB_ICENT);
            EXCEPTION
              WHEN OTHERS THEN
                LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
                    'WOT in pr_accrue ' || SUBSTR(SQLERRM, 1, 1500),
                    '');
                TB_ICENT.DELETE;
                RAISE;
            END;
            DBG('after calling pr_accrue');
          
            IF NOT G_POP_ACCR_ENTRY THEN
              DBG('No accrual entry for this account posted..need not updated accr entries for ' ||
                  TB_ACC(I));
              G_TB_SKIPPED_ACCTS(P_BRN || TB_ACC(I) || TB_PROD(I)) := 1;
            END IF;
          
            IF ICPKS_TEST.G_MOD_CURRUNACCR THEN
              DBG('g_mod_currunaccr is true, Already prod accrual done for this day need not do it again. Will reset g_mod_currunaccr to False');
              ICPKS_TEST.G_MOD_CURRUNACCR := FALSE;
            ELSE
              DBG('g_mod_currunaccr is false..will do prod accrual');
            
              IF NVL(TB_PROD_ACCR(I), 'N') = 'Y' THEN
                FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
                  DBG('inside loop for prod accrual' || FRMLIST || '~' || TB_ICENT(J)
                      .HAS_ACCR);
                  IF TB_ICENT(J).HAS_ACCR = 'Y' THEN
                    X   := TB_PROD(I) || TB_ICENT(J).FRM_NO;
                    POS := CSPKES_MISC.FN_GETPARAM_NO(FRMLIST, X, '~');
                    DBG('got the position as' || '~' || POS);
                    IF POS <> 0 AND TB_ICENT_PROD.EXISTS(POS) THEN
                    
                      IF TB_ICENT_PROD.EXISTS(POS) THEN
                      
                        DBG('exits and amount is' || TB_ICENT_PROD(POS).AMT);
                        DBG('I will add' || TB_ICENT(J).CUR_RUN_ACCR);
                      
                        IF ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED.EXISTS(J) THEN
                          TB_ICENT_PROD(POS).CUR_RUN_ACCR := NVL(TB_ICENT_PROD(POS)
                                                                 .CUR_RUN_ACCR,
                                                                 0) +
                                                             ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED(J);
                        ELSE
                          TB_ICENT_PROD(POS).CUR_RUN_ACCR := NVL(TB_ICENT_PROD(POS)
                                                                 .CUR_RUN_ACCR,
                                                                 0) +
                                                             NVL(TB_ICENT(J)
                                                                 .CUR_RUN_ACCR,
                                                                 0);
                        END IF;
                      
                        TB_ICENT_PROD(POS).ACQUIRED_AMT := NVL(TB_ICENT_PROD(POS)
                                                               .ACQUIRED_AMT,
                                                               0) +
                                                           NVL(TB_ICENT(J)
                                                               .ACQUIRED_AMT,
                                                               0);
                        TB_ICENT_PROD(POS).ACQUIRED_ADJ := NVL(TB_ICENT_PROD(POS)
                                                               .ACQUIRED_ADJ,
                                                               0) +
                                                           NVL(TB_ICENT(J)
                                                               .ACQUIRED_ADJ,
                                                               0);
                      
                        IF TB_PAST_ADJ_ICENT.EXISTS(J) AND
                           TB_PAST_ADJ_ICENT_PROD.EXISTS(POS) THEN
                          DBG('Adding past values to prod table. Existing case 1');
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT_PROD(POS)
                                                                          .ACQUIRED_AMT,
                                                                          0) +
                                                                      NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_AMT,
                                                                          0);
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT_PROD(POS)
                                                                          .ACQUIRED_ADJ,
                                                                          0) +
                                                                      NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_ADJ,
                                                                          0);
                        ELSIF TB_PAST_ADJ_ICENT.EXISTS(J) THEN
                          DBG('Adding past values to prod table. New case 1');
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_AMT,
                                                                          0);
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_ADJ,
                                                                          0);
                        END IF;
                      
                      ELSE
                      
                        IF ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED.EXISTS(J) THEN
                          TB_ICENT_PROD(POS).CUR_RUN_ACCR := ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED(J);
                        ELSE
                          TB_ICENT_PROD(POS).CUR_RUN_ACCR := NVL(TB_ICENT(J)
                                                                 .CUR_RUN_ACCR,
                                                                 0);
                        END IF;
                      
                        TB_ICENT_PROD(POS).ACQUIRED_AMT := NVL(TB_ICENT(J)
                                                               .ACQUIRED_AMT,
                                                               0);
                        TB_ICENT_PROD(POS).ACQUIRED_ADJ := NVL(TB_ICENT(J)
                                                               .ACQUIRED_ADJ,
                                                               0);
                      
                        IF TB_PAST_ADJ_ICENT.EXISTS(J) THEN
                          DBG('Adding past values to prod table. New case 2');
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_AMT,
                                                                          0);
                          TB_PAST_ADJ_ICENT_PROD(POS).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                                          .ACQUIRED_ADJ,
                                                                          0);
                        END IF;
                      
                      END IF;
                    
                      DBG('in prosd accrual and lcy' || '~' || LCY || '~' ||
                          TB_CCY(I));
                    
                      IF TB_CUR_PRODRUN_LCY.EXISTS(POS) THEN
                      
                        TB_CUR_PRODRUN_LCY(POS) := NVL(TB_CURRUN_ACCR_LCY(J),
                                                       0) + NVL(TB_CUR_PRODRUN_LCY(POS),
                                                                0);
                      
                      ELSE
                        TB_CUR_PRODRUN_LCY(POS) := NVL(TB_CURRUN_ACCR_LCY(J),
                                                       0);
                      
                      END IF;
                    
                      DBG('assigned tb_cur_prodrun_lcy ' || POS || ' ' ||
                          TB_CUR_PRODRUN_LCY(POS));
                      TB_CURRUN_ACCR_LCY.DELETE(J);
                      DBG('after adding i got' || TB_ICENT_PROD(POS).AMT);
                      TB_ICENT(J).ACQUIRED_ADJ := TB_ICENT(J).ACQUIRED_AMT;
                    ELSE
                      DBG('this is a new combination' || TB_ICENT(J)
                          .CUR_RUN_ACCR);
                      DBG('details may be required..');
                      POS := NVL(TB_ICENT_PROD.COUNT, 0) + 1;
                      TB_ICENT_PROD(POS) := TB_ICENT(J);
                    
                      IF ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED.EXISTS(J) THEN
                        DBG('Assign cur_run_Accr from icpkss_test.g_tb_amt_not_accrued  instead of tb_icent Old Value' || ICPKSS_TEST.TB_ICENT_PROD(POS)
                            .CUR_RUN_ACCR || 'New value -' ||
                            ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED(J));
                        ICPKSS_TEST.TB_ICENT_PROD(POS).CUR_RUN_ACCR := ICPKSS_TEST.G_TB_AMT_NOT_ACCRUED(J);
                      END IF;
                    
                      DBG('tb_past_adj_icent.count is #### ' ||
                          TB_PAST_ADJ_ICENT.COUNT);
                      DBG('j here is --> ' || J);
                      IF TB_PAST_ADJ_ICENT.EXISTS(J) THEN
                        DBG('Jana Updating stuff here ');
                        DBG('tb_past_adj_icent(j) acquired_amt ' || TB_PAST_ADJ_ICENT(J)
                            .ACQUIRED_AMT);
                        DBG('tb_past_adj_icent(j) acquired_adj ' || TB_PAST_ADJ_ICENT(J)
                            .ACQUIRED_ADJ);
                        TB_PAST_ADJ_ICENT_PROD(POS) := TB_PAST_ADJ_ICENT(J);
                      END IF;
                    
                      DBG('copied entire entrie here');
                      TB_CUR_PRODRUN_LCY(POS) := NVL(TB_CURRUN_ACCR_LCY(J),
                                                     0);
                      DBG('just before clean up');
                      TB_CURRUN_ACCR_LCY.DELETE(J);
                      DBG('after cleaning it up');
                      IF FRMLIST IS NULL THEN
                        FRMLIST := X;
                      ELSE
                        FRMLIST := FRMLIST || '~' || X;
                      END IF;
                      TB_ICENT(J).ACQUIRED_ADJ := TB_ICENT(J).ACQUIRED_AMT;
                    END IF;
                  END IF;
                END LOOP;
                DBG('prod accrual completed sucessfully' || FRMLIST);
              END IF;
              DBG('accr completed..is it correct' || TB_ICENT_PROD.COUNT);
            END IF;
          
          ELSE
            DBG('No accrual for today..need not populate accrual tables for acc' ||
                ICPKSS_TEST.TB_ACC(I) || 'tb_recalc_accr_on_liqn(i)=' ||
                TB_RECALC_ACCR_ON_LIQN(I));
            ICPKSS_TEST.G_TB_SKIPPED_ACCTS(ICPKSS_TEST.TB_BRN(I) || ICPKSS_TEST.TB_ACC(I) || ICPKSS_TEST.TB_PROD(I)) := 1;
          
            IF L_TB_ACC_EVENT_DATES.EXISTS(ICPKSS_TEST.TB_BRN(I) ||
                                           ICPKSS_TEST.TB_ACC(I)) THEN
              IF L_TB_ACC_EVENT_DATES(ICPKSS_TEST.TB_BRN(I) ||
                                      ICPKSS_TEST.TB_ACC(I)) = P_DT THEN
                DBG('l_tb_acc_event_dates supposed to have records for dates when accrual has happpened..since no accrual happend for today..deleting the record');
                L_TB_ACC_EVENT_DATES.DELETE(ICPKSS_TEST.TB_BRN(I) ||
                                            ICPKSS_TEST.TB_ACC(I));
              END IF;
            END IF;
          
          END IF;
        
          BEGIN
            DBG('Selecting deferred_flag for: ' || TB_PROD(I));
            SELECT NVL(DEFERRED_FLAG, 'N')
              INTO L_DEFERRED_FLAG
              FROM ICTMS_PR_INT
             WHERE PRODUCT_CODE = TB_PROD(I);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed while selecting deferred_flag with: ' || SQLERRM);
              L_DEFERRED_FLAG := 'N';
          END;
          DBG('To call Pr_Liq_Int or not to :: ' || TB_ACC(I) || '~' || P_DT);
          DBG('Tb_Next_Liq_Dt(i): ' || TB_NEXT_LIQ_DT(I) ||
              ' Tb_Has_Problems(i): ' || TB_HAS_PROBLEMS(I) ||
              ' Tb_Deposit(i): ' || TB_DEPOSIT(I));
          DBG('l_Deferred_Flag: ' || L_DEFERRED_FLAG ||
              ' Tb_defer_Liq_Dt(i): ' || TB_DEFER_LIQ_DT(I));
        
          L_PROCESS_INT_ADJ := 'N';
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID := 15;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_TB_CLUSTER_DATA('i') := I;
            L_TB_CLUSTER_DATA('l_process_int_adj') := L_PROCESS_INT_ADJ;
            ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                             P_DT,
                                             P_TO_DT,
                                             P_TAX_PROD,
                                             P_PROCESS,
                                             P_AC_CLASS_TYPE,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
            L_PROCESS_INT_ADJ := L_TB_CLUSTER_DATA('l_process_int_adj');
          END IF;
        
          DBG('l_process_int_adj: ' || L_PROCESS_INT_ADJ);
        
          IF (TB_NEXT_LIQ_DT(I) <= P_DT AND
             NVL(TB_HAS_PROBLEMS(I), 'N') <> 'Y' AND
             NVL(TB_DEPOSIT(I), 'N') <> 'Y')
            
             OR NVL(L_PROCESS_INT_ADJ, 'N') = 'Y'
          
           THEN
          
            IF L_TB_ACC_EVENT_DATES.EXISTS(P_BRN || TB_ACC(I)) THEN
              IF L_TB_ACC_EVENT_DATES(P_BRN || TB_ACC(I)) <=
                 TB_NEXT_LIQ_DT(I) THEN
                L_TB_ACC_LIQN_RECDS(P_BRN || TB_ACC(I)) := 1;
              END IF;
            END IF;
          
            BEGIN
              PR_LIQ_INT(P_DT, I, TB_ICENT);
            EXCEPTION
              WHEN OTHERS THEN
                LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
                    'WOT in pr_liq_int ' || SUBSTR(SQLERRM, 1, 1500),
                    '');
              
                TB_ICENT.DELETE;
                L_TB_ACC_LIQN_RECDS.DELETE(P_BRN || TB_ACC(I));
                RAISE;
            END;
            IF NVL(PKG_LIQ_NETTING, 'N') = 'Y' AND
               NVL(R_PRINT.DEFERRED_FLAG, 'N') = 'N' THEN
              FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
              
                L_FATCA_RECORD := ICPKS_CACHE.FN_GET_ISFATCAPROD(TB_PROD(I),
                                                                 TB_ICENT(J)
                                                                 .FRM_NO);
                DBG('product~frmno~isfatca :' || TB_PROD(I) || '~' || TB_ICENT(J)
                    .FRM_NO || '~' || L_FATCA_RECORD);
                IF L_FATCA_RECORD = 'Y' THEN
                  BEGIN
                    DBG('before process, net escrow : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_ESCROW || ' net tpbl : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_TPBL);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      L_FATCA_LIQNET(TB_PROD(I)).SUM_ESCROW := 0;
                      L_FATCA_LIQNET(TB_PROD(I)).SUM_TPBL := 0;
                      L_FATCA_LIQNET(TB_PROD(I)).SUM_ESCROW_LCY := 0;
                      L_FATCA_LIQNET(TB_PROD(I)).SUM_TPBL_LCY := 0;
                  END;
                  DBG('acc~brn : ' || TB_ICENT(J).ACC || '~' || TB_ICENT(J).BRN);
                  L_FATCA_EXT_CUSTOMER_SDE := ICPKS_CACHE.FN_GET_FATCA_EXT_CUST(TB_ICENT(J).BRN,
                                                                                TB_ICENT(J).ACC);
                  DBG('external customer status is : ' ||
                      L_FATCA_EXT_CUSTOMER_SDE);
                  IF L_FATCA_EXT_CUSTOMER_SDE = 1 THEN
                    L_FATCA_LIQNET(TB_PROD(I)).SUM_ESCROW := NVL(L_FATCA_LIQNET(TB_PROD(I))
                                                                 .SUM_ESCROW,
                                                                 0) +
                                                             NVL(TB_ICENT(J).AMT,
                                                                 0);
                    L_FATCA_LIQNET(TB_PROD(I)).SUM_ESCROW_LCY := NVL(L_FATCA_LIQNET(TB_PROD(I))
                                                                     .SUM_ESCROW_LCY,
                                                                     0) +
                                                                 NVL(TB_ICENT(J)
                                                                     .LCY_AMT,
                                                                     0);
                    DBG('escrow sum altered to : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_ESCROW);
                    DBG('escrow sum lcy altered to : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_ESCROW_LCY);
                  ELSE
                    L_FATCA_LIQNET(TB_PROD(I)).SUM_TPBL := NVL(L_FATCA_LIQNET(TB_PROD(I))
                                                               .SUM_TPBL,
                                                               0) +
                                                           NVL(TB_ICENT(J).AMT,
                                                               0);
                    L_FATCA_LIQNET(TB_PROD(I)).SUM_TPBL_LCY := NVL(L_FATCA_LIQNET(TB_PROD(I))
                                                                   .SUM_TPBL_LCY,
                                                                   0) +
                                                               NVL(TB_ICENT(J)
                                                                   .LCY_AMT,
                                                                   0);
                    DBG('tax payable sum altered to : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_TPBL);
                    DBG('tax payable sum lcy altered to : ' || L_FATCA_LIQNET(TB_PROD(I))
                        .SUM_TPBL_LCY);
                  END IF;
                END IF;
              
                Y    := TB_PROD(I) || TB_ICENT(J).FRM_NO;
                POS1 := CSPKES_MISC.FN_GETPARAM_NO(FRMLISTLIQ, Y, '~');
                IF POS1 <> 0 THEN
                  DBG('this already exists amount was' || TB_ICENT_LIQNET(POS1).AMT);
                  TB_ICENT_LIQNET(POS1).AMT := NVL(TB_ICENT_LIQNET(POS1).AMT,
                                                   0) +
                                               NVL(TB_ICENT(J).AMT, 0);
                  TB_ICENT_LIQNET(POS1).ACQUIRED_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                            .ACQUIRED_AMT,
                                                            0) +
                                                        NVL(TB_ICENT(J)
                                                            .ACQUIRED_AMT,
                                                            0);
                
                  IF TB_CCY(I) <> LCY THEN
                    DBG('Are the cutrrencys different');
                    L_LCY_AMT := NULL;
                    L_XRATE   := NULL;
                  
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                         .LCY_AMT,
                                                         0) +
                                                     NVL(TB_ICENT(J).LCY_AMT,
                                                         0);
                    DBG('tb_icent_liqnet(pos1).lcy_amt ' || TB_ICENT_LIQNET(POS1)
                        .LCY_AMT);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT_LIQNET(POS1)
                                                              .ACQUIRED_LCY,
                                                              0) +
                                                          NVL(TB_ICENT(J)
                                                              .ACQUIRED_LCY,
                                                              0);
                    DBG('tb_icent_liqnet(pos1).acquired_lcy ' || TB_ICENT_LIQNET(POS1)
                        .ACQUIRED_LCY);
                  ELSE
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                         .LCY_AMT,
                                                         0) +
                                                     NVL(TB_ICENT(J).AMT, 0);
                    DBG('tb_icent_liqnet(pos1).lcy_amt ' || TB_ICENT_LIQNET(POS1)
                        .LCY_AMT);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT_LIQNET(POS1)
                                                              .ACQUIRED_LCY,
                                                              0) +
                                                          NVL(TB_ICENT(J)
                                                              .ACQUIRED_AMT,
                                                              0);
                  END IF;
                
                ELSE
                  POS1 := NVL(TB_ICENT_LIQNET.COUNT, 0) + 1;
                  TB_ICENT_LIQNET(POS1) := TB_ICENT(J);
                
                  IF TB_CCY(I) <> LCY THEN
                    DBG('Are the cutrrencys different');
                    L_LCY_AMT := NULL;
                    L_XRATE   := NULL;
                  
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT(J).LCY_AMT,
                                                         0);
                    DBG('tb_icent_liqnet(pos1).lcy_amt ' || TB_ICENT_LIQNET(POS1)
                        .LCY_AMT);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT(J)
                                                              .ACQUIRED_LCY,
                                                              0);
                  
                    DBG('tb_icent_liqnet(pos1).acquired_lcy ' || TB_ICENT_LIQNET(POS1)
                        .ACQUIRED_LCY);
                  ELSE
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT(J).AMT, 0);
                    DBG('tb_icent_liqnet(pos1).lcy_amt ' || TB_ICENT_LIQNET(POS1)
                        .LCY_AMT);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT(J)
                                                              .ACQUIRED_AMT,
                                                              0);
                  END IF;
                
                  IF FRMLISTLIQ IS NULL THEN
                    FRMLISTLIQ := Y;
                  ELSE
                    FRMLISTLIQ := FRMLISTLIQ || '~' || Y;
                  END IF;
                END IF;
                TB_ICENT(J).AMT := 0;
                TB_ICENT(J).ACCRUED_AMT := 0;
                TB_ICENT(J).AMT_TO_ACCRUE := 0;
                TB_ICENT(J).CUR_RUN_ACCR := 0;
                TB_ICENT(J).DAILY_AMT := 0;
                TB_ICENT(J).ACQUIRED_AMT := 0;
                TB_ICENT(J).ACQUIRED_ADJ := 0;
              END LOOP;
              DBG('Liq netting sucessfully done');
            END IF;
          
            IF NVL(PKG_LIQ_NETTING, 'N') = 'Y' AND
               NVL(R_PRINT.DEFERRED_FLAG, 'N') = 'Y' THEN
              FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
                TB_ICENT(J).AMT := 0;
                TB_ICENT(J).ACCRUED_AMT := 0;
                TB_ICENT(J).AMT_TO_ACCRUE := 0;
                TB_ICENT(J).CUR_RUN_ACCR := 0;
                TB_ICENT(J).DAILY_AMT := 0;
                TB_ICENT(J).ACQUIRED_AMT := 0;
                TB_ICENT(J).ACQUIRED_ADJ := 0;
              END LOOP;
            END IF;
          
          END IF;
          DBG('next wotking day dyn is coming as :' || DYN_NWD);
        
          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID := 20;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_TB_CLUSTER_DATA('i') := I;
            L_TB_CLUSTER_DATA('r_print.accr_freq') := R_PRINT.ACCR_FREQ;
            L_TB_CLUSTER_DATA('dyn_nwd') := DYN_NWD;
            ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                             P_DT,
                                             P_TO_DT,
                                             P_TAX_PROD,
                                             P_PROCESS,
                                             P_AC_CLASS_TYPE,
                                             L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
          END IF;
          IF NOT GLOBAL.G_SKIP_KERNEL THEN
          
            IF P_DT < DYN_NWD - 1 AND R_PRINT.ACCR_FREQ = 'D' AND
               TB_HAS_ACCR(I) = 'Y' AND
               NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'Y' THEN
              DBG('adjs are to be done ' || TB_NEXT_ACCR_DT(I) || '~' ||
                  P_TO_DT || '~' || TB_NEXT_LIQ_DT(I) || '~' || DYN_NWD);
              IF TB_NEXT_LIQ_DT(I) IS NOT NULL THEN
                IF TB_NEXT_ACCR_DT(I) = P_TO_DT AND
                   TB_NEXT_LIQ_DT(I) > TB_NEXT_ACCR_DT(I) AND
                   TB_NEXT_LIQ_DT(I) > DYN_NWD - 1 THEN
                  DBG('so lets update the dates to : ');
                  TB_NEXT_ACCR_DT(I) := DYN_NWD - 1;
                  TB_NEXT_SCHD_ACCR_DT(I) := DYN_NWD - 1;
                  TB_NEXT_CALC_DT(I) := DYN_NWD - 1;
                ELSE
                  DBG('in else we put dates as ');
                  TB_NEXT_ACCR_DT(I) := LEAST(DYN_NWD - 1,
                                              TB_NEXT_LIQ_DT(I));
                  TB_NEXT_SCHD_ACCR_DT(I) := LEAST(DYN_NWD - 1,
                                                   TB_NEXT_LIQ_DT(I));
                  TB_NEXT_CALC_DT(I) := LEAST(DYN_NWD - 1,
                                              TB_NEXT_LIQ_DT(I));
                END IF;
              
              ELSE
                DBG(' Next Liqn date is null..Possibly notice accounts? ');
                TB_NEXT_ACCR_DT(I) := DYN_NWD - 1;
                TB_NEXT_SCHD_ACCR_DT(I) := DYN_NWD - 1;
                TB_NEXT_CALC_DT(I) := DYN_NWD - 1;
              END IF;
            
            END IF;
          
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          DBG('finally the dates are :' || TB_NEXT_ACCR_DT(I) || ' - ' ||
              TB_NEXT_SCHD_ACCR_DT(I) || '~' || TB_NEXT_CALC_DT(I));
          LAST_REC := NVL(TB_ICENT_UPD_ACC.COUNT, 0);
          FOR I IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
            DBG('inserting for entries update' || '~' || LAST_REC);
            DBG('values of i--> ' || I);
            TB_ICENT_UPD_ACC(LAST_REC + I) := TB_ICENT(I).ACC;
            DBG('tb_icent_upd_acc through');
            TB_ICENT_UPD_AMT(LAST_REC + I) := NVL(TB_ICENT(I).AMT, 0);
            DBG('tb_icent_upd_amt through');
            TB_ICENT_UPD_ACCRUED_AMT(LAST_REC + I) := NVL(TB_ICENT(I)
                                                          .ACCRUED_AMT,
                                                          0);
            DBG('tb_icent_upd_accrued_amt through');
            TB_ICENT_UPD_AMT_TO_ACCRUE(LAST_REC + I) := NVL(TB_ICENT(I)
                                                            .AMT_TO_ACCRUE,
                                                            0);
            DBG('tb_icent_upd_amt_to_accrue through');
            TB_ICENT_UPD_CUR_RUN_ACCR(LAST_REC + I) := NVL(TB_ICENT(I)
                                                           .CUR_RUN_ACCR,
                                                           0);
            DBG('tb_icent_upd_cur_run_accr through');
            TB_ICENT_UPD_ENT_DT(LAST_REC + I) := TB_ICENT(I).ENT_DT;
            DBG('tb_icent_upd_ent_dt through');
            TB_ICENT_UPD_DRCR(LAST_REC + I) := TB_ICENT(I).DRCR;
            DBG('tb_icent_upd_drcr through');
            TB_ICENT_UPD_DAILY_AMT(LAST_REC + I) := NVL(TB_ICENT(I)
                                                        .DAILY_AMT,
                                                        0);
            DBG('tb_icent_upd_daily_amt through');
            TB_ICENT_UPD_NEXT_CALC_DUE_DT(LAST_REC + I) := TB_ICENT(I)
                                                           .NEXT_CALC_DUE_DATE;
            DBG('tb_icent_upd_next_calc_due_dt through');
            TB_ICENT_UPD_ACQUIRED_ADJ(LAST_REC + I) := NVL(TB_ICENT(I)
                                                           .ACQUIRED_ADJ,
                                                           0);
            DBG('tb_icent_upd_acquired_adj through');
            TB_ICENT_UPD_ACQUIRED_AMT(LAST_REC + I) := NVL(TB_ICENT(I)
                                                           .ACQUIRED_AMT,
                                                           0);
            DBG('tb_icent_upd_acquired_amt');
            TB_ICENT_UPD_ROWID(LAST_REC + I) := TB_ICENT(I).ROW_ID;
          
            IF (TB_PAST_ADJ_ICENT.EXISTS(I)) THEN
              DBG('Updating the record for past adjustment entries');
              TB_ICENT_PAST_ADJ_UPD_ROWID(LAST_REC + I) := TB_PAST_ADJ_ICENT(I)
                                                           .ROW_ID;
              DBG('tb_past_adj_icent(i).acquired_amt ' || TB_PAST_ADJ_ICENT(I)
                  .ACQUIRED_AMT);
              DBG('tb_past_adj_icent(i).acquired_adj ' || TB_PAST_ADJ_ICENT(I)
                  .ACQUIRED_ADJ);
            
              TB_ICENT_PAST_ADJ_UPD_ACQ_ADJ(LAST_REC + I) := TB_PAST_ADJ_ICENT(I)
                                                             .ACQUIRED_ADJ;
              TB_ICENT_PAST_ADJ_UPD_ACQ_AMT(LAST_REC + I) := TB_PAST_ADJ_ICENT(I)
                                                             .ACQUIRED_AMT;
            END IF;
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 4;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('i') := I;
              L_TB_CLUSTER_DATA('last_rec') := LAST_REC;
            
              ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                               P_DT,
                                               P_TO_DT,
                                               P_TAX_PROD,
                                               P_PROCESS,
                                               P_AC_CLASS_TYPE,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
            
            END IF;
          
          END LOOP;
        END IF;
      
      END IF;
    
      L_PREVREC := I;
    EXCEPTION
      WHEN ACNTG_FAILED THEN
        LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
            'Bombed in pr_do_process acntg_failed ' ||
            SUBSTR(SQLERRM, 1, 1500),
            TB_ACC(I));
        DBG('error is...' || SQLERRM);
        PR_TAKE_PLSQL_TAB_RESTORE;
        RAISE;
      WHEN CALL_FAILED THEN
        DBG('error is...' || SQLERRM);
        LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
            'call_failed do_process ' || SUBSTR(SQLERRM, 1, 1500),
            TB_ACC(I));
        PR_TAKE_PLSQL_TAB_RESTORE;
        RAISE;
      WHEN OTHERS THEN
        DBG('Error is...' || SQLERRM);
        LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' || 'WOT do_process ' ||
            SUBSTR(SQLERRM, 1, 1500),
            TB_ACC(I));
        LOG_PROBLEM(I, 'A', 'WOT do_process ' || SUBSTR(SQLERRM, 1, 1900));
      
        PR_TAKE_PLSQL_TAB_RESTORE;
        RAISE;
    END PR_DO_PROCESS;
  BEGIN
  
    G_RECALC_LIQNDT := 'Y';
  
    DBG('Adhoc Holiday check ');
    IF NOT ICPKS_HOLIDAY.FN_PROCESS_ADHOC_HOLIDAY(P_BRN) THEN
      DBG('Adhoc  Holiday check has returned false');
    END IF;
  
    BEGIN
      SELECT EOD_COMMIT_COUNT
        INTO L_COMMIT_FREQ
        FROM CSTB_COMMITFREQ
       WHERE MODULE_ID = 'IC'
         AND FUNCTION_ID = 'ICEOD';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      
        BEGIN
          SELECT EOD_COMMIT_COUNT
            INTO L_COMMIT_FREQ
            FROM CSTB_COMMITFREQ
           WHERE MODULE_ID = 'ic'
             AND FUNCTION_ID = 'ICEOD';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('inside no data found......of commit freq');
            L_COMMIT_FREQ := 500;
          
        END;
    END;
    IF L_COMMIT_FREQ > 6000 THEN
      L_COMMIT_FREQ := 6000;
    END IF;
    DBG('just going to open the main cursor...scene1' || P_BRN || '~' ||
        L_COMMIT_FREQ);
  
    DBG('calling income recognition function' || P_DT || '~' || P_PROCESS);
  
    IF NOT STPKS_STATUS.FN_INCOMERECOG(P_BRN,
                                       P_PROCESS,
                                       
                                       GLOBAL.APPLICATION_DATE,
                                       ERRMSG,
                                       EPRM) THEN
      DBG('Income recognition failed #: ' || ERRMSG || ' ' || EPRM);
      ERRMSG := 'ST-ACSTC15';
      DBG('failed in income recognition');
    
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID      := 10;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                       P_DT,
                                       P_TO_DT,
                                       P_TAX_PROD,
                                       P_PROCESS,
                                       P_AC_CLASS_TYPE,
                                       L_FN_CALL_ID,
                                       L_TB_CLUSTER_DATA);
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      OPEN CUR_ICTB_ACCPR;
    
      G_TB_SYS_ACCTS.DELETE;
      G_TB_SYS_ACCTS_TAX.DELETE;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    LOOP
      DBG('just before bulk fetch');
      ICPKSS_HASH_PR.INIT_HASH_PR;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        L_FN_CALL_ID := 11;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_commit_freq') := L_COMMIT_FREQ;
      
        ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                         P_DT,
                                         P_TO_DT,
                                         P_TAX_PROD,
                                         P_PROCESS,
                                         P_AC_CLASS_TYPE,
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
      END IF;
    
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        FETCH CUR_ICTB_ACCPR BULK COLLECT
          INTO TB_BRN,
               TB_ACC,
               TB_PROD,
               TB_SC_MAP_DT,
               TB_GC_MAP_DT,
               TB_LAST_CALC_DT,
               TB_LAST_LIQ_DT,
               TB_NEXT_LIQ_DT,
               TB_LAST_ACCR_DT,
               TB_NEXT_ACCR_DT,
               TB_LAST_SCHD_LIQ_DT,
               TB_INC_MTH,
               TB_NEXT_SCHD_LIQ_DT,
               TB_FIRST_CALC_DT,
               TB_NEXT_SCHD_ACCR_DT,
               TB_PROD_TYPE,
               TB_HAS_ACCR,
               TB_NEXT_CALC_DT,
               TB_PROD_ACCR,
               TB_HAS_PROBLEMS,
               TB_BKVAL_MINCALC_DATE,
               TB_BKVAL_RECALC_FLAG,
               TB_FIRST_FIRST_CALC_DATE,
               TB_IMAT_PROBLEMS,
               TB_DEPOSIT,
               TB_ACLASS,
               TB_CCY,
               TB_PROCESS,
               TB_NEXT_EVENT_DT,
               TB_DEFER_LIQ_DT,
               TB_ROWID
               
              ,
               TB_SYS_AC_LEVEL,
               TB_SUBLEVEL,
               TB_RECALC_ACCR_ON_LIQN
               
               LIMIT L_COMMIT_FREQ;
      
      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
      G_IC_RUNNING := TRUE;
      L_LAST_REC   := TB_ACC.LAST;
      DBG('in this fetch we got ' || '~' || L_LAST_REC || '~' ||
          'to process');
      DBG('going for min date');
    
      IF TB_NEXT_EVENT_DT.COUNT = 0 THEN
        DBG('nothing to process so exiting');
        EXIT;
      END IF;
    
      MIN_EVENT_DT := TB_NEXT_EVENT_DT(1);
      DBG('min_event_dt is ' || MIN_EVENT_DT);
      FOR I IN TB_ACC.FIRST .. L_LAST_REC LOOP
        ICPKSS_HASH_PR.SET_ACC_ROWS(TB_ACC(I), I);
        PR_APPEND(TB_NEXT_EVENT_DT(I), I);
        L_TB_ACC_EVENT_DATES(P_BRN || TB_ACC(I)) := TB_NEXT_EVENT_DT(I);
      END LOOP;
      DBG('completed the process string making...' || 'from' ||
          MIN_EVENT_DT || 'to' || P_TO_DT);
      PR_TAKE_PLSQL_TAB_BAK;
      J := PROCESS_THESE.FIRST;
      DBG('abount to open the loop for processing ' || P_TO_DT || '~' ||
          MIN_EVENT_DT);
      WHILE J <= (P_TO_DT - MIN_EVENT_DT) LOOP
        BEGIN
          SAVEPOINT SP_PROCESS_DAY;
          DBG('calling process_these.exists for ' || PROCESS_THESE(PROCESS_THESE(J).DAY)
              .REC_LIST);
          IF PROCESS_THESE.EXISTS(PROCESS_THESE(J).DAY) THEN
            DBG('process_these.exists true for ' || PROCESS_THESE(PROCESS_THESE(J).DAY)
                .REC_LIST);
          ELSE
            DBG('process_these.exists false for ' || PROCESS_THESE(PROCESS_THESE(J).DAY)
                .REC_LIST);
          END IF;
          IF PROCESS_THESE.EXISTS(PROCESS_THESE(J).DAY) THEN
            A := PROCESS_THESE(J).PROCESS_DT;
            B := PROCESS_THESE(J).REC_LIST;
          
            TB_ICENT_LIQNET.DELETE;
            FRMLISTLIQ := NULL;
          
            L_ACC := NULL;
            DBG('going to process for the date...' || '~' || A || '~' || B);
          
            DBG('period end is ' || PER_END);
            DYN_NWD := LEAST(CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                          P_BRN,
                                                          A,
                                                          'N',
                                                          1),
                             PER_END + 1);
          
            DBG('dyn_nwd before comparing with app date ' || DYN_NWD ||
                GLOBAL.APPLICATION_DATE || PKG_PROCESS_TILL);
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 17;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('dyn_nwd') := DYN_NWD;
            
              ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                               P_DT,
                                               P_TO_DT,
                                               P_TAX_PROD,
                                               P_PROCESS,
                                               P_AC_CLASS_TYPE,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
            END IF;
          
            IF PKG_PROCESS_TILL <> 'S' AND
               DYN_NWD = GLOBAL.APPLICATION_DATE THEN
              DYN_NWD := NWD + 1;
              DBG('in pr_iceod_wrap for dyn_nwd- reset' || DYN_NWD);
            END IF;
          
            IF REPOP_CASE THEN
              IF ICPKS_TEST.P_IC_MAX_PROCESS = 1 THEN
              
                ICPKS_UDE.PR_MAKE_UDE_ROW(P_BRN);
              
              ELSE
                ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_SEQ(P_BRN, P_PROCESS);
              END IF;
            
            END IF;
          
            DBG('calling acpkss_vdbal.fn_batch_update for ' || P_BRN);
          
            IF CSPKS_FEATURE.FN_INSTALLED('VDBALINIC') THEN
            
              N_PART := NVL(CSPKSS_PARALLEL_STREAM.FN_STREAM_COUNT('VDBALUPD',
                                                                   P_BRN),
                            0);
              IF N_PART = 1 THEN
              
                IF NOT ACPKS_VDBAL.FN_BATCH_UPDATE(P_BRN, VD_ERR, VD_ERP) THEN
                  DBG('failed in vd balance update' || VD_ERR);
                  DBG('failed in vd bal update ' || VD_ERP);
                  LPG('Failed in vd bal update ' || VD_ERR || '~' ||
                      VD_ERP || '~' || SUBSTR(SQLERRM, 1, 1000),
                      '');
                
                  RAISE VDBAL_UPDATE_EXCPN;
                END IF;
              
              ELSE
              
                IF NOT ACPKS_VDBAL.FN_UPDATE_FOR_SEQ(P_BRN,
                                                     VD_ERR,
                                                     VD_ERP,
                                                     P_PROCESS) THEN
                  DBG('Failed in acpks_vdbal.fn_update_for_seq : ' ||
                      VD_ERR || '~' || VD_ERP);
                  LPG('Failed in vd bal update ' || VD_ERR || '~' ||
                      VD_ERP || '~' || SUBSTR(SQLERRM, 1, 1000),
                      '');
                  RAISE VDBAL_UPDATE_EXCPN;
                END IF;
              
              END IF;
            
            END IF;
          
            G_TB_SKIPPED_ACCTS.DELETE;
            LOOP
              BEGIN
                SAVEPOINT SP_PROCESS_DAY1;
              
                DBG('Loop starts here');
                DBG('errmsg is :' || ERRMSG);
                ERRMSG := NULL;
              
                ICPKS_TEST.G_TB_AMT_NOT_ACCRUED.DELETE;
                ICPKS_TEST.G_MOD_CURRUNACCR := FALSE;
              
                REC_CHAR := ICPKSS_UTIL.FN_GET_NEXT_PARAM(B, LAST_POS);
                REC_NO   := TO_NUMBER(REC_CHAR);
                IF TB_ACC.EXISTS(REC_NO) AND TB_BRN.EXISTS(REC_NO) THEN
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                    L_FN_CALL_ID := 18;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('rec_no') := REC_NO;
                    ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                                     P_DT,
                                                     P_TO_DT,
                                                     P_TAX_PROD,
                                                     P_PROCESS,
                                                     P_AC_CLASS_TYPE,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA);
                  END IF;
                
                  TB_BASIC_HOFF(1).EVENT := 'IACR';
                  TB_BASIC_HOFF(1).MODULE := 'IC';
                  TB_BASIC_HOFF(1).EVENT_SR_NO := 1;
                  TB_BASIC_HOFF(1).TRN_DT := NVL(APPDT, A);
                  TB_BASIC_HOFF(1).VALUE_DT := A;
                  TB_BASIC_HOFF(1).AC_BRANCH := P_BRN;
                  TB_BASIC_HOFF(1).USER_ID := UID;
                  TB_BASIC_HOFF(1).BATCH_NO := 0;
                  TB_BASIC_HOFF(1).CURR_NO := 0;
                  TB_BASIC_HOFF(1).AVLDAYS := 0;
                  TB_BASIC_HOFF(1).TXN_INIT_DATE := APPDT;
                  JSP := 0;
                  LOOP
                    DBG('inside the second loop ');
                    BEGIN
                      EXIT WHEN TB_ACC(REC_NO) <> TB_ACC(REC_NO + JSP + 1);
                      JSP := JSP + 1;
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        DBG('no problem this may be the last fetched record');
                        EXIT;
                    END;
                  END LOOP;
                  LAST_REC_NO := REC_NO + JSP;
                  DBG('here last rec no is ' || LAST_REC_NO);
                  BEGIN
                    DBG('calling pr_do_process for ' || REC_NO || '~' || A);
                    PR_DO_PROCESS(REC_NO, A);
                  
                  EXCEPTION
                    WHEN OTHERS THEN
                      LPG(TB_BRN(REC_NO) || '~' || TB_ACC(REC_NO) || '~' ||
                          'WOT in PR_DO_PROCESS ' ||
                          SUBSTR(SQLERRM, 1, 1500),
                          '');
                    
                      RAISE DO_PROCESS_EXCPN;
                    
                  END;
                  DBG('out of do process for ' || '~' || A);
                
                  G_PROCESS_IC_DATE := A;
                  DBG('#27325546 g_process_ic_date  ' || '~' ||
                      G_PROCESS_IC_DATE);
                
                  DBG('Pass accounting for account and prod - new fix');
                  DBG('Calling acpkss for passing accr and liqd entries ' || '~' || A ||
                      '~ count is ' || TB_HOFF_CONS.COUNT);
                  IF NVL(TB_HOFF_CONS.COUNT, 0) <> 0 THEN
                    DBG('There are some cons entries ' || '~' ||
                        TB_HOFF_CONS.COUNT);
                    OVPKSS.PR_INITERRTBL;
                  
                    IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH',
                                                  P_BRN) THEN
                      DBG('this is intraday');
                      L_ACCR_CNTR := 0;
                      L_LIQN_CNTR := 0;
                    
                      L_INDEX := TB_HOFF_CONS.FIRST;
                      WHILE L_INDEX <= TB_HOFF_CONS.LAST LOOP
                        DBG('event is-->' || TB_HOFF_CONS(L_INDEX).EVENT);
                        IF TB_HOFF_CONS(L_INDEX).EVENT = 'IACR' THEN
                          L_ACCR_CNTR := L_ACCR_CNTR + 1;
                          TB_ACCR_HOFF_CONS(L_ACCR_CNTR) := TB_HOFF_CONS(L_INDEX);
                        ELSE
                          L_LIQN_CNTR := L_LIQN_CNTR + 1;
                          TB_LIQN_HOFF_CONS(L_LIQN_CNTR) := TB_HOFF_CONS(L_INDEX);
                        END IF;
                        L_INDEX := TB_HOFF_CONS.NEXT(L_INDEX);
                      END LOOP;
                      DBG('Number of IACR entries: ' || L_ACCR_CNTR);
                      DBG('Number of non IACR (LIQD) entries: ' ||
                          L_LIQN_CNTR);
                    
                      DBG('before calling icpks_deferred_entries.pr_store_entries -->' ||
                          TB_ACCR_HOFF_CONS.COUNT);
                      ICPKS_DEFERRED_ENTRIES.PR_STORE_ENTRIES(P_BRN || 'IC',
                                                              TB_ACCR_HOFF_CONS,
                                                              P_PROCESS);
                      DBG('count of data-->' || TB_ACCR_HOFF_CONS.COUNT || '~' ||
                          TB_LIQN_HOFF_CONS.COUNT);
                      IF TB_ACCR_HOFF_CONS.COUNT > 0 THEN
                        DBG('here 5');
                        FOR J IN 1 .. TB_ACCR_HOFF_CONS.COUNT LOOP
                          DBG('here 1-->' || TB_ACCR_HOFF_CONS(J).EVENT || '~' || TB_ACCR_HOFF_CONS(J)
                              .RELATED_ACCOUNT);
                        END LOOP;
                      END IF;
                      DBG('here 4');
                      IF TB_LIQN_HOFF_CONS.COUNT > 0 THEN
                        DBG('here 6');
                        FOR K IN 1 .. TB_LIQN_HOFF_CONS.COUNT LOOP
                          DBG('here 22-->' || TB_LIQN_HOFF_CONS(K).EVENT || '~' || TB_LIQN_HOFF_CONS(K)
                              .RELATED_ACCOUNT);
                        END LOOP;
                      END IF;
                    
                      DBG('here 7');
                      IF TB_LIQN_HOFF_CONS.COUNT <> 0 THEN
                        DBG('before calling 2  pr_post_intrday_accr_ent_fr_ac-->');
                      
                        PR_POST_INTRDAY_ACCR_ENT_FR_AC(TB_LIQN_HOFF_CONS,
                                                       L_ERR_FLAG);
                        IF L_ERR_FLAG = 1 THEN
                          DBG('Failed in posting accounting entries..' ||
                              REC_NO);
                          LOG_PROBLEM((REC_NO),
                                      'B',
                                      'Intrdyposting failed' ||
                                      SUBSTR(ERRMSG, 1, 1900));
                          TB_HOFF_CONS.DELETE;
                          TB_LIQN_HOFF_CONS.DELETE;
                          PR_TAKE_PLSQL_TAB_RESTORE;
                          DBG('Rollback done here - till sp_process_day - 1');
                          ROLLBACK TO SP_PROCESS_DAY1;
                        END IF;
                      
                      END IF;
                      DBG('here 8');
                    
                      IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                                 1,
                                                 APPDT,
                                                 TB_LIQN_HOFF_CONS,
                                                 'B',
                                                 'Y',
                                                 'N',
                                                 UID,
                                                 ERRMSG,
                                                 EPRM) THEN
                        DBG('Failed in passing the entry...log this');
                        LOG_PROBLEM((REC_NO),
                                    'B',
                                    'excpn for acc ' ||
                                    SUBSTR(ERRMSG, 1, 1900) || '##' ||
                                    'Technical error##');
                        TB_HOFF_CONS.DELETE;
                        TB_LIQN_HOFF_CONS.DELETE;
                        PR_TAKE_PLSQL_TAB_RESTORE;
                        DBG('Rollback done here - till sp_process_day - 2');
                        ROLLBACK TO SP_PROCESS_DAY1;
                      END IF;
                      DBG('here 9');
                      TB_ACCR_HOFF_CONS.DELETE;
                      TB_LIQN_HOFF_CONS.DELETE;
                      TB_HOFF_CONS.DELETE;
                    ELSE
                      DBG('is it coming here?');
                    
                      DBG('Interest Liquidation To CASA Account ON EOD-CASALIQ');
                      DBG('Transaction account in pr_iceod_wrap..' ||
                          L_ACC);
                      DBG('Transaction branch in pr_iceod_wrap....' ||
                          L_BRN);
                      IF NOT ICPKSS_BOD.FN_CUSTLIM_TDLIQ('FLEXCUBE',
                                                         'CASALIQ',
                                                         L_ACC,
                                                         L_BRN,
                                                         ERRMSG,
                                                         EPRM,
                                                         TB_HOFF_CONS,
                                                         NULL) THEN
                        L_ERR_TYPE := OVPKSS.FN_GETTYPE(ERRMSG);
                        DBG('err_code--' || ERRMSG);
                        DBG('l_err_type--' || L_ERR_TYPE);
                        DBG('eprm--' || EPRM);
                        IF L_ERR_TYPE = 'E' THEN
                          DBG('Failed in fn_Custlim_tdliq-->' || SQLERRM ||
                              'TRACE ' ||
                              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
                          LOG_PROBLEM((REC_NO),
                                      'B',
                                      'Failed with' ||
                                      SUBSTR(ERRMSG, 1, 1900) || EPRM);
                          TB_HOFF_CONS.DELETE;
                          PR_TAKE_PLSQL_TAB_RESTORE;
                          DBG('Rollback done here - till sp_process_day - 3');
                          ROLLBACK TO SP_PROCESS_DAY1;
                        ELSE
                          DBG('Going to proceed as the error type is override');
                        END IF;
                      
                      END IF;
                    
                      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                         (CSPKS_REQ_GLOBAL.P_CLUSTER,
                          CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                        L_FN_CALL_ID := 1;
                      
                        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                        L_TB_CLUSTER_DATA('l_prod') := TB_PROD(REC_NO);
                        L_TB_CLUSTER_DATA('l_brn') := L_BRN;
                        L_TB_CLUSTER_DATA('l_acc') := L_ACC;
                        ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                                         P_DT,
                                                         P_TO_DT,
                                                         P_TAX_PROD,
                                                         P_PROCESS,
                                                         P_AC_CLASS_TYPE,
                                                         G_ICTM_ACC,
                                                         TB_HOFF_CONS,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA,
                                                         ERRMSG,
                                                         EPRM);
                        DBG(' call to pr_iceod_wrap :');
                        IF ERRMSG IS NOT NULL THEN
                          LOG_PROBLEM((REC_NO),
                                      'B',
                                      'Failed with' ||
                                      SUBSTR(ERRMSG, 1, 1900) || EPRM);
                          TB_HOFF_CONS.DELETE;
                          PR_TAKE_PLSQL_TAB_RESTORE;
                          ERRMSG := NULL;
                          ROLLBACK TO SP_PROCESS_DAY1;
                        END IF;
                      END IF;
                      IF NOT GLOBAL.G_SKIP_KERNEL THEN
                      
                        IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                                   1,
                                                   APPDT,
                                                   TB_HOFF_CONS,
                                                   'B',
                                                   'Y',
                                                   'N',
                                                   UID,
                                                   ERRMSG,
                                                   EPRM) THEN
                          DBG('Failed in passing the entry...log this');
                          LOG_PROBLEM((REC_NO),
                                      'B',
                                      'excpn for acc ' ||
                                      SUBSTR(ERRMSG, 1, 1900));
                          TB_HOFF_CONS.DELETE;
                          PR_TAKE_PLSQL_TAB_RESTORE;
                        
                          DBG('Rollback done here - till about_to_process - 1');
                          ROLLBACK TO ABOUT_TO_PROCESS;
                        END IF;
                      
                      ELSE
                        GLOBAL.PR_RESET_SKIP_KERNEL;
                      END IF;
                    
                      TB_HOFF_CONS.DELETE;
                    END IF;
                  ELSE
                    DBG('No entries so nothing to do!!!!cons - new fix');
                  END IF;
                
                  FIND_KEY(TB_PROD(REC_NO), R_PR1);
                  L_DEFERRED_FLAG := NVL(R_PR1.DEFERRED_FLAG, 'N');
                  DBG('BAN prod~deferred_flag:' || TB_PROD(REC_NO) || '~' ||
                      L_DEFERRED_FLAG);
                
                  IF L_DEFERRED_FLAG = 'Y'
                  
                   THEN
                    DBG('existing code');
                  
                    DBG('next defer liq date is : ' ||
                        TB_DEFER_LIQ_DT(REC_NO));
                    DBG('a----->' || A);
                    DBG('next event date is : ' ||
                        TB_NEXT_EVENT_DT(REC_NO));
                  
                    IF A >= NVL(TB_DEFER_LIQ_DT(REC_NO), SYSDATE + 9999) THEN
                      TB_NEXT_EVENT_DT(REC_NO) := LEAST(NVL(TB_NEXT_CALC_DT(REC_NO),
                                                            SYSDATE + 9999),
                                                        NVL(TB_NEXT_ACCR_DT(REC_NO),
                                                            SYSDATE + 9999),
                                                        NVL(TB_NEXT_LIQ_DT(REC_NO),
                                                            SYSDATE + 9999));
                    ELSE
                    
                      TB_NEXT_EVENT_DT(REC_NO) := LEAST(NVL(TB_NEXT_CALC_DT(REC_NO),
                                                            SYSDATE + 9999),
                                                        NVL(TB_NEXT_ACCR_DT(REC_NO),
                                                            SYSDATE + 9999),
                                                        NVL(TB_NEXT_LIQ_DT(REC_NO),
                                                            SYSDATE + 9999),
                                                        NVL(TB_DEFER_LIQ_DT(REC_NO),
                                                            SYSDATE + 9999));
                    
                    END IF;
                  
                    DBG('next event date is : ' ||
                        TB_NEXT_EVENT_DT(REC_NO));
                  
                  ELSE
                    DBG('holiday fixxxxx');
                    TB_NEXT_EVENT_DT(REC_NO) := LEAST(NVL(TB_NEXT_CALC_DT(REC_NO),
                                                          SYSDATE + 9999),
                                                      NVL(TB_NEXT_ACCR_DT(REC_NO),
                                                          SYSDATE + 9999),
                                                      NVL(TB_NEXT_LIQ_DT(REC_NO),
                                                          SYSDATE + 9999));
                    DBG('next event date is : ' ||
                        TB_NEXT_EVENT_DT(REC_NO));
                  END IF;
                
                  DBG('next event date comes out here to be' ||
                      TB_NEXT_EVENT_DT(REC_NO) || '~' ||
                      TB_NEXT_ACCR_DT(REC_NO));
                  DBG('calc and liq dates are' || TB_NEXT_CALC_DT(REC_NO) || '~' ||
                      TB_NEXT_LIQ_DT(REC_NO));
                  DBG('mincalc date is coming as ' || ' - ' ||
                      TB_BKVAL_MINCALC_DATE(REC_NO) || ' - ' ||
                      TB_BKVAL_RECALC_FLAG(REC_NO) || '~' || P_TO_DT);
                  IF TB_NEXT_EVENT_DT(TO_NUMBER(REC_NO)) <= P_TO_DT AND
                     (TB_NEXT_EVENT_DT(TO_NUMBER(REC_NO)) > A OR
                      L_DEFERRED_FLAG = 'Y') THEN
                    DBG('records next event date is still less than p_to_dt ' ||
                        P_TO_DT);
                    PR_APPEND(TB_NEXT_EVENT_DT(REC_NO), REC_NO);
                  
                    IF L_TB_ACC_LIQN_RECDS.EXISTS(P_BRN || TB_ACC(REC_NO)) AND
                       L_TB_ACC_EVENT_DATES.EXISTS(P_BRN || TB_ACC(REC_NO)) THEN
                      DBG('l_tb_acc_event_dates changed..for acc~old_date~new_date' ||
                          TB_ACC(REC_NO) || '~' ||
                          L_TB_ACC_EVENT_DATES(P_BRN || TB_ACC(REC_NO)) || '~' ||
                          TB_NEXT_EVENT_DT(REC_NO));
                      L_TB_ACC_EVENT_DATES(P_BRN || TB_ACC(REC_NO)) := TB_NEXT_EVENT_DT(REC_NO);
                      L_TB_ACC_LIQN_RECDS.DELETE(P_BRN || TB_ACC(REC_NO));
                    END IF;
                  
                  END IF;
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                    L_FN_CALL_ID := 19;
                    L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                    L_TB_CLUSTER_DATA('rec_no') := REC_NO;
                  
                    ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                                     P_DT,
                                                     P_TO_DT,
                                                     P_TAX_PROD,
                                                     P_PROCESS,
                                                     P_AC_CLASS_TYPE,
                                                     L_FN_CALL_ID,
                                                     L_TB_CLUSTER_DATA);
                  END IF;
                
                  BEGIN
                  
                    IF LAST_POS = 0 THEN
                      DBG('We are processing the last record so setting l_aclass_next/l_ccy_next to ###');
                      L_ACLASS_NEXT     := '###';
                      L_CCY_NEXT        := '###';
                      L_ACC_STATUS_NEXT := '###';
                      L_PROD_NEXT       := '###';
                    ELSE
                      LAST_POS_NEXT := LAST_POS;
                      REC_CHAR_NEXT := ICPKSS_UTIL.FN_GET_NEXT_PARAM(B,
                                                                     LAST_POS_NEXT);
                      REC_NO_NEXT   := TO_NUMBER(REC_CHAR_NEXT);
                      L_ACLASS_NEXT := TB_ACLASS(REC_NO_NEXT);
                      L_CCY_NEXT    := TB_CCY(REC_NO_NEXT);
                      L_PROD_NEXT   := TB_PROD(REC_NO_NEXT);
                    
                      IF TB_SYS_AC_LEVEL(REC_NO_NEXT) IS NOT NULL THEN
                        SELECT ACCOUNT, BRANCH_CODE
                          INTO L_CUST_ACCOUNT, L_CUST_BRANCH
                          FROM ILTBS_SYS_ACCOUNT
                         WHERE SYSTEM_ACCOUNT = TB_ACC(REC_NO_NEXT)
                           AND SYSTEM_ACCOUNT_BRANCH = TB_BRN(REC_NO_NEXT);
                        SELECT ACC_STATUS
                          INTO L_ACC_STATUS_NEXT
                          FROM STTM_CUST_ACCOUNT
                         WHERE BRANCH_CODE = L_CUST_BRANCH
                           AND CUST_AC_NO = L_CUST_ACCOUNT;
                      ELSE
                      
                        SELECT ACC_STATUS
                          INTO L_ACC_STATUS_NEXT
                          FROM STTM_CUST_ACCOUNT
                         WHERE BRANCH_CODE = TB_BRN(REC_NO_NEXT)
                           AND CUST_AC_NO = TB_ACC(REC_NO_NEXT);
                        DBG('After taking next status ' ||
                            L_ACC_STATUS_NEXT);
                      
                      END IF;
                    END IF;
                    DBG('Various values are last_pos_next - ' ||
                        LAST_POS_NEXT || ' , rec_no_next -' || REC_NO_NEXT ||
                        ' l_aclass_next -' || L_ACLASS_NEXT ||
                        ' l_ccy_next - ' || L_CCY_NEXT ||
                        ' tb_aclass(rec_no) - ' || TB_ACLASS(REC_NO) ||
                        ' tb_ccy(rec_no) - ' || TB_CCY(REC_NO));
                    DBG('Current and next status is ' ||
                        G_STTM_CUSTACC.ACC_STATUS || L_ACC_STATUS_NEXT);
                  
                    IF NVL(TB_ACLASS(REC_NO), '***') <>
                       NVL(L_ACLASS_NEXT, '###') OR
                       NVL(TB_CCY(REC_NO), '****') <>
                       NVL(L_CCY_NEXT, '###') OR
                       NVL(TB_PROD(REC_NO), '****') <>
                       NVL(L_PROD_NEXT, '###') OR
                       NVL(G_STTM_CUSTACC.ACC_STATUS, '****') <>
                       NVL(L_ACC_STATUS_NEXT, '###') THEN
                      DBG('account class/ ccy change ' ||
                          TB_ACLASS(REC_NO) || '~' || TB_CCY(REC_NO) ||
                          'old is ' || L_CCY || '~' || L_ACLASS);
                      DBG('account class type is ' || G_ACC_TYPE);
                    
                      IF NVL(TB_ICENT_PROD.COUNT, 0) <> 0 THEN
                        DBG('going to call prod accrual' ||
                            TB_ICENT_PROD.COUNT);
                      
                        IF NOT FN_POP_PROD_ACCR_ENTRIES(TB_CCY(REC_NO),
                                                        G_STTM_CUSTACC.ACC_STATUS,
                                                        A,
                                                        P_PROCESS,
                                                        TB_ICENT_PROD) THEN
                          DBG('Failed in fn_prod_accr_entries');
                          TB_ICENT_PROD.DELETE;
                          TB_CUR_PRODRUN_LCY.DELETE;
                          FRMLIST := NULL;
                          RAISE PRD_ACCR_LIQNET_EXCP;
                        END IF;
                      
                        TB_ICENT_PROD.DELETE;
                        TB_CUR_PRODRUN_LCY.DELETE;
                        FRMLIST := NULL;
                      END IF;
                    
                      IF NVL(TB_ICENT_LIQNET.COUNT, 0) <> 0 THEN
                        DBG('going to liq netting');
                      
                        BEGIN
                          DBG('calling pr_liq_netting for ' || P_BRN || '~' || A || '~' ||
                              REC_NO || '~');
                          PR_LIQ_NETTING(P_BRN
                                         
                                        ,
                                         A,
                                         REC_NO,
                                         TB_ICENT_LIQNET);
                        EXCEPTION
                          WHEN OTHERS THEN
                            DBG('pr_liq_netting raised exceptions @@!! ' ||
                                SQLERRM);
                            TB_ICENT_LIQNET.DELETE;
                            FRMLISTLIQ := NULL;
                            RAISE PRD_ACCR_LIQNET_EXCP;
                        END;
                        TB_ICENT_LIQNET.DELETE;
                        FRMLISTLIQ := NULL;
                      END IF;
                    
                      IF TB_HOFF_PROD.COUNT <> 0 THEN
                        DBG('going to call acpkss for prod level entries ' ||
                            APPDT);
                        OVPKSS.PR_INITERRTBL;
                      
                        GLOBAL.SET_PRODUCT_ACCRUAL('P');
                      
                        IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                                   1,
                                                   APPDT,
                                                   TB_HOFF_PROD,
                                                   'B',
                                                   'Y',
                                                   'N',
                                                   UID,
                                                   ERRMSG,
                                                   EPRM) THEN
                        
                          DBG('failed in passing the entry...log this' ||
                              ERRMSG || EPRM);
                          LOG_PROBLEM(L_PREVREC,
                                      'b'
                                      
                                     ,
                                      SUBSTR(('prod actng failed in doprocess ' ||
                                             ' ~ ' ||
                                             DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||
                                             ' ~ ' || ERRMSG),
                                             1,
                                             3900));
                          TB_HOFF_PROD.DELETE;
                          RAISE PRD_ACCR_LIQNET_EXCP;
                        END IF;
                        TB_HOFF_PROD.DELETE;
                        GLOBAL.SET_PRODUCT_ACCRUAL('N');
                      END IF;
                    END IF;
                  EXCEPTION
                    WHEN PRD_ACCR_LIQNET_EXCP THEN
                      ICPKSS_EOD.EOD_RETSTAT := -1;
                    
                      GLOBAL.SET_PRODUCT_ACCRUAL('N');
                      DBG('Rollback done here - 1');
                      ROLLBACK;
                      RETURN;
                    
                    WHEN OTHERS THEN
                      ICPKSS_EOD.EOD_RETSTAT := -1;
                      DBG('Rollback done here - 2');
                      GLOBAL.SET_PRODUCT_ACCRUAL('N');
                      ROLLBACK;
                      RETURN;
                  END;
                
                ELSE
                  DBG('for this number account does not exists :' ||
                      REC_NO);
                END IF;
              
              EXCEPTION
                WHEN DO_PROCESS_EXCPN THEN
                  DBG('in user defined exception ');
                  LPG(TB_BRN(REC_NO) || '~' || TB_ACC(REC_NO) || '~' ||
                      'WOT in PR_DO_PROCESS ' || SUBSTR(SQLERRM, 1, 1500),
                      '');
                  PR_TAKE_PLSQL_TAB_RESTORE;
                  TB_HOFF_CONS.DELETE;
                
                  LOG_PROBLEM(REC_NO,
                              'B',
                              'pr_do_process-do_process_excpn' ||
                              SUBSTR(SQLERRM, 1, 1950));
                
                  DBG('Rollback done here -till about_to_process - 2');
                  ROLLBACK TO ABOUT_TO_PROCESS;
                
              END;
              EXIT WHEN LAST_POS = 0;
            END LOOP;
            DBG('calling acpkss for passing accr and liqd entries ' || '~' || A ||
                '~ count is ' || TB_HOFF_CONS.COUNT);
          
            IF NVL(TB_HOFF_CONS.COUNT, 0) <> 0 THEN
              DBG('there are some cons entries ' || '~' ||
                  TB_HOFF_CONS.COUNT);
            
              OVPKSS.PR_INITERRTBL;
            
              IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH', P_BRN) THEN
                L_ACCR_CNTR := 0;
                L_LIQN_CNTR := 0;
              
                L_INDEX := TB_HOFF_CONS.FIRST;
                WHILE L_INDEX <= TB_HOFF_CONS.LAST LOOP
                  DBG('event is-->' || TB_HOFF_CONS(L_INDEX).EVENT);
                  IF TB_HOFF_CONS(L_INDEX).EVENT = 'IACR' THEN
                    L_ACCR_CNTR := L_ACCR_CNTR + 1;
                    TB_ACCR_HOFF_CONS(L_ACCR_CNTR) := TB_HOFF_CONS(L_INDEX);
                  ELSE
                    L_LIQN_CNTR := L_LIQN_CNTR + 1;
                    TB_LIQN_HOFF_CONS(L_LIQN_CNTR) := TB_HOFF_CONS(L_INDEX);
                  END IF;
                  L_INDEX := TB_HOFF_CONS.NEXT(L_INDEX);
                END LOOP;
                DBG('Number of IACR entries: ' || L_ACCR_CNTR);
                DBG('Number of non IACR (LIQD) entries: ' || L_LIQN_CNTR);
              
                ICPKS_DEFERRED_ENTRIES.PR_STORE_ENTRIES(P_BRN || 'IC',
                                                        TB_ACCR_HOFF_CONS,
                                                        P_PROCESS);
                DBG('count of data 1-->' || TB_ACCR_HOFF_CONS.COUNT || '~' ||
                    TB_LIQN_HOFF_CONS.COUNT);
              
                IF TB_ACCR_HOFF_CONS.COUNT > 0 THEN
                  FOR J IN 1 .. TB_ACCR_HOFF_CONS.COUNT LOOP
                    DBG('here 41-->' || TB_ACCR_HOFF_CONS(J).EVENT || '~' || TB_ACCR_HOFF_CONS(J)
                        .RELATED_ACCOUNT);
                  END LOOP;
                END IF;
              
                IF TB_LIQN_HOFF_CONS.COUNT > 0 THEN
                  FOR K IN 1 .. TB_LIQN_HOFF_CONS.COUNT LOOP
                    DBG('here 51-->' || TB_LIQN_HOFF_CONS(J).EVENT || '~' || TB_LIQN_HOFF_CONS(J)
                        .RELATED_ACCOUNT);
                  END LOOP;
                END IF;
              
                PR_POST_INTRDAY_ACCR_ENT_FR_AC(TB_ACCR_HOFF_CONS,
                                               L_ERR_FLAG);
                IF L_ERR_FLAG = 1 THEN
                  LOG_PROBLEM((REC_NO),
                              'B',
                              'Posting Intraday entries failed ' ||
                              SUBSTR(ERRMSG, 1, 1900));
                  TB_HOFF_CONS.DELETE;
                  TB_ACCR_HOFF_CONS.DELETE;
                  TB_LIQN_HOFF_CONS.DELETE;
                
                  RAISE ACPR_LOOP_EXCPTN;
                END IF;
              
                IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                           1,
                                           APPDT,
                                           TB_LIQN_HOFF_CONS,
                                           'B',
                                           'Y',
                                           'N',
                                           UID,
                                           ERRMSG,
                                           EPRM) THEN
                  DBG('Failed in passing the entry...log this');
                  LOG_PROBLEM((REC_NO),
                              'B',
                              'excpn for acc ' || '~' || EPRM || '~' ||
                              SUBSTR(ERRMSG, 1, 1000) || '##' ||
                              'Technical error##');
                  TB_HOFF_CONS.DELETE;
                  TB_LIQN_HOFF_CONS.DELETE;
                
                  RAISE ACPR_LOOP_EXCPTN;
                
                END IF;
                TB_HOFF_CONS.DELETE;
                TB_LIQN_HOFF_CONS.DELETE;
                TB_ACCR_HOFF_CONS.DELETE;
              ELSE
              
                IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                           1,
                                           APPDT,
                                           TB_HOFF_CONS,
                                           'B',
                                           'Y',
                                           'N',
                                           UID,
                                           ERRMSG,
                                           EPRM) THEN
                  DBG('Failed in passing the entry...log this');
                
                  LOG_PROBLEM((REC_NO),
                              'B',
                              'excpn for acc ' || '~' || EPRM || '~' ||
                              SUBSTR(ERRMSG, 1, 1000));
                  TB_HOFF_CONS.DELETE;
                
                  RAISE ACPR_LOOP_EXCPTN;
                
                END IF;
                TB_HOFF_CONS.DELETE;
              END IF;
              DBG('no entries so nothing to do!!!!cons');
            
            END IF;
          
            IF TB_ICENT_PROD.COUNT <> 0 THEN
              DBG('going for product accruals... ' || P_DT);
            
              IF NOT FN_POP_PROD_ACCR_ENTRIES(TB_CCY(REC_NO),
                                              G_STTM_CUSTACC.ACC_STATUS,
                                              A,
                                              P_PROCESS,
                                              TB_ICENT_PROD) THEN
                DBG('Failed in fn_prod_accr_entries');
                TB_ICENT_PROD.DELETE;
                TB_CUR_PRODRUN_LCY.DELETE;
                FRMLIST := NULL;
                RAISE ACPR_LOOP_EXCPTN;
              END IF;
            
              DBG('some entries are there for prod accr also' || '~' ||
                  TB_HOFF_PROD.COUNT);
              TB_ICENT_PROD.DELETE;
              TB_PAST_ADJ_ICENT_PROD.DELETE;
              TB_CUR_PRODRUN_LCY.DELETE;
              FRMLIST := NULL;
            END IF;
          
            DBG('after checking for prod accruals checking for liq netting ');
            IF TB_ICENT_LIQNET.COUNT <> 0 THEN
              DBG('liq netting!!!' || TB_HOFF_PROD.COUNT);
              BEGIN
                PR_LIQ_NETTING(P_BRN, P_DT, REC_NO, TB_ICENT_LIQNET);
              EXCEPTION
                WHEN OTHERS THEN
                  TB_ICENT_LIQNET.DELETE;
                  FRMLISTLIQ := NULL;
                  RAISE ACPR_LOOP_EXCPTN;
              END;
              DBG('some liqnetting to be done' || TB_HOFF_PROD.COUNT);
              TB_ICENT_LIQNET.DELETE;
              FRMLISTLIQ := NULL;
            END IF;
            IF TB_HOFF_PROD.COUNT <> 0 THEN
              DBG('here hoff_prod has got entries ' || TB_HOFF_PROD.COUNT);
              OVPKSS.PR_INITERRTBL;
            
              GLOBAL.SET_PRODUCT_ACCRUAL('P');
              IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                         1,
                                         APPDT,
                                         TB_HOFF_PROD,
                                         'B',
                                         'Y',
                                         'N',
                                         UID,
                                         ERRMSG,
                                         EPRM) THEN
                DBG('Failed in passing the entry...log this');
              
                LOG_PROBLEM((REC_NO),
                            'B',
                            'acpr_loop_excptn ' || '~' || EPRM || '~' ||
                            SUBSTR(ERRMSG, 1, 1000));
                TB_HOFF_PROD.DELETE;
                RAISE ACPR_LOOP_EXCPTN;
              END IF;
              TB_HOFF_PROD.DELETE;
              GLOBAL.SET_PRODUCT_ACCRUAL('N');
            ELSE
              DBG('no entries for prod accrual also');
            END IF;
            DBG('updated the accpr now attack ent history' ||
                TB_ICENT_HIST_UPD.COUNT || '~' || TB_ICENT_HIST_UPD.LAST || '~' ||
                TB_ICENT_HIST_UPD.FIRST);
            DBG('Pr_iceod_wrap ::  Updated the accpr now attack ent history');
          
            DBG('Pr_iceod_wrap :: Hist Acc cnt: ' ||
                TB_ICENT_HIST_ACC.COUNT);
          
            IF TB_ICENT_HIST_ACC.COUNT <> 0 OR TB_ICENT_HIST_UPD.COUNT <> 0 THEN
              L_INDEX := 0;
              L_IDX   := 0;
            
              IF NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N' THEN
                IF NOT
                    CEPKSS_DATE.FN_ISHOLIDAY('LCL', P_BRN, A, L_IS_HOLIDAY) THEN
                  DBG('cepkss_date.fn_isholiday has returned false... but continuing');
                  NULL;
                END IF;
                DBG('g_ic_accr_on_holidays = N and l_is_holiday = ' ||
                    L_IS_HOLIDAY);
              ELSE
                L_IS_HOLIDAY := 'W';
              END IF;
              L_IS_HOLIDAY := NVL(L_IS_HOLIDAY, 'W');
            
              IF TB_ICENT_HIST_ACC.COUNT > 0 THEN
                FOR J IN TB_ICENT_HIST_ACC.FIRST .. TB_ICENT_HIST_ACC.LAST LOOP
                  DBG('tb_icent_hist_acc(j)~tb_icent_hist_accr(j)~tb_icent_hist_liqn(j)' ||
                      TB_ICENT_HIST_ACC(J) || '~' || TB_ICENT_HIST_ACCR(J) || '~' ||
                      TB_ICENT_HIST_LIQN(J));
                  IF TB_ICENT_HIST_ACCR(J) = 'Y' THEN
                  
                    DBG('l_is_holiday~tb_icent_hist_acc(j)~tb_icent_hist_cur_run_accr(j)=' ||
                        L_IS_HOLIDAY || '~' || TB_ICENT_HIST_ACC(J) || '~' ||
                        TB_ICENT_HIST_CUR_RUN_ACCR(J));
                    IF L_IS_HOLIDAY = 'W'
                      
                       OR
                       (L_IS_HOLIDAY = 'H' AND NOT
                        G_TB_SKIPPED_ACCTS.EXISTS(TB_ICENT_HIST_BRN(J) ||
                                                                          TB_ICENT_HIST_ACC(J) ||
                                                                          TB_ICENT_HIST_PROD(J))) THEN
                    
                      IF NVL(TB_ICENT_HIST_AMT(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_ACCRUED_AMT(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J), 0) <= 0 THEN
                        DBG('1_Explicitly making cur_run_Accr to 0 since amt and amt_to_accure is 0');
                        TB_ICENT_HIST_CUR_RUN_ACCR(J) := 0;
                      
                        IF TB_ICENT_HIST_CURACCR_LCY(J) <> 0 THEN
                          DBG('for some reason, the cur_accr_lcy is not zero..will make it 0 since insertion in zero accrual table' ||
                              TB_ICENT_HIST_CURACCR_LCY(J));
                          TB_ICENT_HIST_CURACCR_LCY(J) := 0;
                        END IF;
                      
                      END IF;
                    
                      IF L_TB_ACC_EVENT_DATES.EXISTS(TB_ICENT_HIST_BRN(J) ||
                                                     TB_ICENT_HIST_ACC(J)) THEN
                        L_TMP_PROCESS_DT := L_TB_ACC_EVENT_DATES(TB_ICENT_HIST_BRN(J) ||
                                                                 TB_ICENT_HIST_ACC(J));
                        DBG('Assign l_tmp_process_dt as inital process date - ' ||
                            L_TMP_PROCESS_DT);
                      ELSE
                        L_TMP_PROCESS_DT := A;
                        DBG('Assign l_tmp_process_dt as current process date  - ' ||
                            L_TMP_PROCESS_DT);
                      END IF;
                    
                      IF NVL(TB_ICENT_HIST_AMT(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_ACCRUED_AMT(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J), 0) = 0 AND
                         NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J), 0) = 0 THEN
                      
                        IF NOT (L_IS_HOLIDAY = 'W' AND
                            NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N' AND
                            L_TMP_PROCESS_DT <> A) THEN
                        
                          L_IDX := L_IDX + 1;
                          TB_ICENT_ZEROACCR_HIST(L_IDX).BRN := TB_ICENT_HIST_BRN(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).ACC := TB_ICENT_HIST_ACC(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).PROD := TB_ICENT_HIST_PROD(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).FRM_NO := TB_ICENT_HIST_FRM_NO(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).ENT_DT := A;
                          TB_ICENT_ZEROACCR_HIST(L_IDX).AMT := NVL(TB_ICENT_HIST_AMT(J),
                                                                   0);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).ACCRUED_AMT := NVL(TB_ICENT_HIST_ACCRUED_AMT(J),
                                                                           0);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).CUR_RUN_ACCR := NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J),
                                                                            0);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).AMT_TO_ACCRUE := NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J),
                                                                             0);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).RUN_DATE := TB_ICENT_HIST_RUN_DATE(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).ENTRY_TYPE := TB_ICENT_HIST_ENTRY_TYPE(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).CCY := TB_ICENT_HIST_CCY(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).LCY_AMT := TB_ICENT_HIST_LCY_AMT(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).CUR_RUN_ACCR_LCY := TB_ICENT_HIST_CURACCR_LCY(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(J),
                                                                                        TB_ICENT_HIST_FRM_NO(J));
                          TB_ICENT_ZEROACCR_HIST(L_IDX).ENTRY_PASSED := TB_ICENT_HIST_ENTRY_PASSED(J);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).PROCESS := NVL(P_PROCESS,
                                                                       1);
                          TB_ICENT_ZEROACCR_HIST(L_IDX).LAST_CUR_RUN_ACCR := TB_ICENT_HIST_LAST_CUR_ACCR(J);
                        END IF;
                      ELSE
                      
                        IF NOT (L_IS_HOLIDAY = 'W' AND
                            NVL(ICPKSS_TEST.TB_ICENT_HIST_CUR_RUN_ACCR(J),
                                    0) = 0 AND
                            NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N'
                            
                            AND L_TMP_PROCESS_DT <> A)
                        
                         THEN
                        
                          L_INDEX := L_INDEX + 1;
                          TB_ICENT_ACCR_HIST(L_INDEX).BRN := TB_ICENT_HIST_BRN(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).ACC := TB_ICENT_HIST_ACC(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).PROD := TB_ICENT_HIST_PROD(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).FRM_NO := TB_ICENT_HIST_FRM_NO(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).ENT_DT := A;
                          TB_ICENT_ACCR_HIST(L_INDEX).AMT := NVL(TB_ICENT_HIST_AMT(J),
                                                                 0);
                          TB_ICENT_ACCR_HIST(L_INDEX).ACCRUED_AMT := NVL(TB_ICENT_HIST_ACCRUED_AMT(J),
                                                                         0);
                          TB_ICENT_ACCR_HIST(L_INDEX).CUR_RUN_ACCR := NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J),
                                                                          0);
                          TB_ICENT_ACCR_HIST(L_INDEX).AMT_TO_ACCRUE := NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J),
                                                                           0);
                          TB_ICENT_ACCR_HIST(L_INDEX).RUN_DATE := TB_ICENT_HIST_RUN_DATE(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).ENTRY_TYPE := TB_ICENT_HIST_ENTRY_TYPE(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).CCY := TB_ICENT_HIST_CCY(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).LCY_AMT := TB_ICENT_HIST_LCY_AMT(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).CUR_RUN_ACCR_LCY := TB_ICENT_HIST_CURACCR_LCY(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(J),
                                                                                      TB_ICENT_HIST_FRM_NO(J));
                          TB_ICENT_ACCR_HIST(L_INDEX).ENTRY_PASSED := TB_ICENT_HIST_ENTRY_PASSED(J);
                          TB_ICENT_ACCR_HIST(L_INDEX).PROCESS := NVL(P_PROCESS,
                                                                     1);
                        
                        END IF;
                      END IF;
                    END IF;
                    IF TB_ICENT_HIST_LIQN(J) = 'N' THEN
                      DBG('Non liqn entry..getting deleted here ..' ||
                          TB_ICENT_HIST_ACC(J));
                      TB_ICENT_HIST_BRN.DELETE(J);
                      TB_ICENT_HIST_ACC.DELETE(J);
                      TB_ICENT_HIST_PROD.DELETE(J);
                      TB_ICENT_HIST_FRM_NO.DELETE(J);
                      TB_ICENT_HIST_AMT.DELETE(J);
                      TB_ICENT_HIST_ACCRUED_AMT.DELETE(J);
                      TB_ICENT_HIST_CUR_RUN_ACCR.DELETE(J);
                      TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE(J);
                      TB_ICENT_HIST_RUN_DATE.DELETE(J);
                      TB_ICENT_HIST_ENTRY_TYPE.DELETE(J);
                      TB_ICENT_HIST_CCY.DELETE(J);
                      TB_ICENT_HIST_LCY_AMT.DELETE(J);
                      TB_ICENT_HIST_CURACCR_LCY.DELETE(J);
                      TB_ICENT_HIST_ENTRY_PASSED.DELETE(J);
                    
                      TB_ICENT_HIST_ACCR.DELETE(J);
                      TB_ICENT_HIST_LIQN.DELETE(J);
                      TB_ICENT_HIST_LAST_CUR_ACCR.DELETE(J);
                    
                    ELSE
                      K_TB1 := K_TB1 + 1;
                      DBG('1.Populating a liqn entry here for' ||
                          TB_ICENT_HIST_ACC(J));
                      TB_ICENT_HIST_BRN_TEST(K_TB1) := TB_ICENT_HIST_BRN(J);
                      TB_ICENT_HIST_ACC_TEST(K_TB1) := TB_ICENT_HIST_ACC(J);
                      TB_ICENT_HIST_PROD_TEST(K_TB1) := TB_ICENT_HIST_PROD(J);
                      TB_ICENT_HIST_FRM_NO_TEST(K_TB1) := TB_ICENT_HIST_FRM_NO(J);
                      TB_ICENT_HIST_AMT_TEST(K_TB1) := TB_ICENT_HIST_AMT(J);
                      TB_ICENT_HIST_ACCRUED_AMT_TEST(K_TB1) := TB_ICENT_HIST_ACCRUED_AMT(J);
                      TB_ICENT_HIST_CUR_RUN_ACCR_T(K_TB1) := TB_ICENT_HIST_CUR_RUN_ACCR(J);
                      TB_ICENT_HIST_AMT_TO_ACCRUE_T(K_TB1) := TB_ICENT_HIST_AMT_TO_ACCRUE(J);
                      TB_ICENT_HIST_RUN_DATE_TEST(K_TB1) := TB_ICENT_HIST_RUN_DATE(J);
                      TB_ICENT_HIST_ENTRY_TYPE_TEST(K_TB1) := TB_ICENT_HIST_ENTRY_TYPE(J);
                      TB_ICENT_HIST_CCY_TEST(K_TB1) := TB_ICENT_HIST_CCY(J);
                      TB_ICENT_HIST_LCY_AMT_TEST(K_TB1) := TB_ICENT_HIST_LCY_AMT(J);
                      TB_ICENT_HIST_CURACCR_LCY_TEST(K_TB1) := TB_ICENT_HIST_CURACCR_LCY(J);
                      TB_ICENT_HIST_ENTRY_PASSED_T(K_TB1) := TB_ICENT_HIST_ENTRY_PASSED(J);
                      TB_ICENT_HIST_ACCR_TEST(K_TB1) := TB_ICENT_HIST_ACCR(J);
                      TB_ICENT_HIST_LIQN_TEST(K_TB1) := TB_ICENT_HIST_LIQN(J);
                      TB_ICENT_HIST_LAST_CUR_ACCR_T(K_TB1) := TB_ICENT_HIST_LAST_CUR_ACCR(J);
                    
                    END IF;
                  
                  ELSIF TB_ICENT_HIST_LIQN(J) = 'Y' THEN
                    K_TB1 := K_TB1 + 1;
                    DBG('2.Populating a liqn entry here for' ||
                        TB_ICENT_HIST_ACC(J));
                    TB_ICENT_HIST_BRN_TEST(K_TB1) := TB_ICENT_HIST_BRN(J);
                    TB_ICENT_HIST_ACC_TEST(K_TB1) := TB_ICENT_HIST_ACC(J);
                    TB_ICENT_HIST_PROD_TEST(K_TB1) := TB_ICENT_HIST_PROD(J);
                    TB_ICENT_HIST_FRM_NO_TEST(K_TB1) := TB_ICENT_HIST_FRM_NO(J);
                    TB_ICENT_HIST_AMT_TEST(K_TB1) := TB_ICENT_HIST_AMT(J);
                    TB_ICENT_HIST_ACCRUED_AMT_TEST(K_TB1) := TB_ICENT_HIST_ACCRUED_AMT(J);
                    TB_ICENT_HIST_CUR_RUN_ACCR_T(K_TB1) := TB_ICENT_HIST_CUR_RUN_ACCR(J);
                    TB_ICENT_HIST_AMT_TO_ACCRUE_T(K_TB1) := TB_ICENT_HIST_AMT_TO_ACCRUE(J);
                    TB_ICENT_HIST_RUN_DATE_TEST(K_TB1) := TB_ICENT_HIST_RUN_DATE(J);
                    TB_ICENT_HIST_ENTRY_TYPE_TEST(K_TB1) := TB_ICENT_HIST_ENTRY_TYPE(J);
                    TB_ICENT_HIST_CCY_TEST(K_TB1) := TB_ICENT_HIST_CCY(J);
                    TB_ICENT_HIST_LCY_AMT_TEST(K_TB1) := TB_ICENT_HIST_LCY_AMT(J);
                    TB_ICENT_HIST_CURACCR_LCY_TEST(K_TB1) := TB_ICENT_HIST_CURACCR_LCY(J);
                    TB_ICENT_HIST_ENTRY_PASSED_T(K_TB1) := TB_ICENT_HIST_ENTRY_PASSED(J);
                    TB_ICENT_HIST_ACCR_TEST(K_TB1) := TB_ICENT_HIST_ACCR(J);
                    TB_ICENT_HIST_LIQN_TEST(K_TB1) := TB_ICENT_HIST_LIQN(J);
                    TB_ICENT_HIST_LAST_CUR_ACCR_T(K_TB1) := TB_ICENT_HIST_LAST_CUR_ACCR(J);
                  
                  END IF;
                END LOOP;
              
                IF TB_ICENT_HIST_ACC.COUNT > 0 THEN
                  TB_ICENT_HIST_BRN.DELETE;
                  TB_ICENT_HIST_ACC.DELETE;
                  TB_ICENT_HIST_PROD.DELETE;
                  TB_ICENT_HIST_FRM_NO.DELETE;
                  TB_ICENT_HIST_AMT.DELETE;
                  TB_ICENT_HIST_ACCRUED_AMT.DELETE;
                  TB_ICENT_HIST_CUR_RUN_ACCR.DELETE;
                  TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE;
                  TB_ICENT_HIST_RUN_DATE.DELETE;
                  TB_ICENT_HIST_ENTRY_TYPE.DELETE;
                  TB_ICENT_HIST_CCY.DELETE;
                  TB_ICENT_HIST_LCY_AMT.DELETE;
                  TB_ICENT_HIST_CURACCR_LCY.DELETE;
                  TB_ICENT_HIST_ENTRY_PASSED.DELETE;
                  TB_ICENT_HIST_ACCR.DELETE;
                  TB_ICENT_HIST_LIQN.DELETE;
                  TB_ICENT_HIST_LAST_CUR_ACCR.DELETE;
                
                  TB_ICENT_HIST_BRN           := TB_ICENT_HIST_BRN_TEST;
                  TB_ICENT_HIST_ACC           := TB_ICENT_HIST_ACC_TEST;
                  TB_ICENT_HIST_PROD          := TB_ICENT_HIST_PROD_TEST;
                  TB_ICENT_HIST_FRM_NO        := TB_ICENT_HIST_FRM_NO_TEST;
                  TB_ICENT_HIST_AMT           := TB_ICENT_HIST_AMT_TEST;
                  TB_ICENT_HIST_ACCRUED_AMT   := TB_ICENT_HIST_ACCRUED_AMT_TEST;
                  TB_ICENT_HIST_CUR_RUN_ACCR  := TB_ICENT_HIST_CUR_RUN_ACCR_T;
                  TB_ICENT_HIST_AMT_TO_ACCRUE := TB_ICENT_HIST_AMT_TO_ACCRUE_T;
                  TB_ICENT_HIST_RUN_DATE      := TB_ICENT_HIST_RUN_DATE_TEST;
                  TB_ICENT_HIST_ENTRY_TYPE    := TB_ICENT_HIST_ENTRY_TYPE_TEST;
                  TB_ICENT_HIST_CCY           := TB_ICENT_HIST_CCY_TEST;
                  TB_ICENT_HIST_LCY_AMT       := TB_ICENT_HIST_LCY_AMT_TEST;
                  TB_ICENT_HIST_CURACCR_LCY   := TB_ICENT_HIST_CURACCR_LCY_TEST;
                  TB_ICENT_HIST_ENTRY_PASSED  := TB_ICENT_HIST_ENTRY_PASSED_T;
                  TB_ICENT_HIST_ACCR          := TB_ICENT_HIST_ACCR_TEST;
                  TB_ICENT_HIST_LIQN          := TB_ICENT_HIST_LIQN_TEST;
                  TB_ICENT_HIST_LAST_CUR_ACCR := TB_ICENT_HIST_LAST_CUR_ACCR_T;
                
                  TB_ICENT_HIST_BRN_TEST.DELETE;
                  TB_ICENT_HIST_ACC_TEST.DELETE;
                  TB_ICENT_HIST_PROD_TEST.DELETE;
                  TB_ICENT_HIST_FRM_NO_TEST.DELETE;
                  TB_ICENT_HIST_AMT_TEST.DELETE;
                  TB_ICENT_HIST_ACCRUED_AMT_TEST.DELETE;
                  TB_ICENT_HIST_CUR_RUN_ACCR_T.DELETE;
                  TB_ICENT_HIST_AMT_TO_ACCRUE_T.DELETE;
                  TB_ICENT_HIST_RUN_DATE_TEST.DELETE;
                  TB_ICENT_HIST_ENTRY_TYPE_TEST.DELETE;
                  TB_ICENT_HIST_CCY_TEST.DELETE;
                  TB_ICENT_HIST_LCY_AMT_TEST.DELETE;
                  TB_ICENT_HIST_CURACCR_LCY_TEST.DELETE;
                  TB_ICENT_HIST_ENTRY_PASSED_T.DELETE;
                  TB_ICENT_HIST_ACCR_TEST.DELETE;
                  TB_ICENT_HIST_LIQN_TEST.DELETE;
                  TB_ICENT_HIST_LAST_CUR_ACCR_T.DELETE;
                
                END IF;
                K_TB1 := 0;
              
              END IF;
            END IF;
            IF TB_ICENT_ACCR_HIST.COUNT <> 0 THEN
              BEGIN
                FORALL X IN INDICES OF TB_ICENT_ACCR_HIST SAVE EXCEPTIONS
                  INSERT INTO ICTBS_ENTRIES_HISTORY_ACCR
                    (BRN,
                     ACC,
                     PROD,
                     FRM_NO,
                     ENT_DT,
                     AMT,
                     ACCRUED_AMT,
                     CUR_RUN_ACCR,
                     AMT_TO_ACCRUE,
                     RUN_DATE,
                     ENTRY_TYPE,
                     CCY,
                     LCY_AMT,
                     CUR_RUN_ACCR_LCY,
                     DRCR,
                     ENTRY_PASSED,
                     PROCESS)
                  VALUES
                    (TB_ICENT_ACCR_HIST(X).BRN,
                     TB_ICENT_ACCR_HIST(X).ACC,
                     TB_ICENT_ACCR_HIST(X).PROD,
                     TB_ICENT_ACCR_HIST(X).FRM_NO,
                     TB_ICENT_ACCR_HIST(X).ENT_DT,
                     TB_ICENT_ACCR_HIST(X).AMT,
                     TB_ICENT_ACCR_HIST(X).ACCRUED_AMT,
                     TB_ICENT_ACCR_HIST(X).CUR_RUN_ACCR,
                     TB_ICENT_ACCR_HIST(X).AMT_TO_ACCRUE,
                     TB_ICENT_ACCR_HIST(X).RUN_DATE,
                     TB_ICENT_ACCR_HIST(X).ENTRY_TYPE,
                     TB_ICENT_ACCR_HIST(X).CCY,
                     TB_ICENT_ACCR_HIST(X).LCY_AMT,
                     TB_ICENT_ACCR_HIST(X).CUR_RUN_ACCR_LCY,
                     TB_ICENT_ACCR_HIST(X).DRCR,
                     TB_ICENT_ACCR_HIST(X).ENTRY_PASSED,
                     TB_ICENT_ACCR_HIST(X).PROCESS);
                DBG('Through with bulk insert into ICTBS_ENTRIES_HISTORY_ACCR');
              EXCEPTION
                WHEN BULK_ERRORS THEN
                  DBG('insert into entries hist failed with ' || SQLERRM ||
                      ' for : ' || A);
                  DBG('SQL%BULK_EXCEPTIONS.COUNT ' ||
                      SQL%BULK_EXCEPTIONS.COUNT);
                
                  FOR J IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
                    L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                    DBG('~j = ' || J ||
                        ' ***** SQL%BULK_EXCEPTIONS(j).ERROR_INDEX = ' ||
                        L_ERROR_INDEX);
                    DBG('SQL%BULK_EXCEPTIONS (j).ERROR_CODE =' || SQL%BULK_EXCEPTIONS(J)
                        .ERROR_CODE);
                    IF ABS(SQL%BULK_EXCEPTIONS(J).ERROR_CODE) = 1 THEN
                      L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                      DBG(' l_error_index =' || L_ERROR_INDEX || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                          .CUR_RUN_ACCR || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                          .LCY_AMT || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                          .CUR_RUN_ACCR_LCY || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX).BRN || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX).ACC || '~' || TB_ICENT_ACCR_HIST(L_ERROR_INDEX).PROD);
                      UPDATE ICTBS_ENTRIES_HISTORY_ACCR
                         SET AMT              = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX).AMT,
                                                    0),
                             ACCRUED_AMT      = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                    .ACCRUED_AMT,
                                                    0),
                             CUR_RUN_ACCR     = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                    .CUR_RUN_ACCR,
                                                    0),
                             AMT_TO_ACCRUE    = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                    .AMT_TO_ACCRUE,
                                                    0),
                             RUN_DATE         = TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                .RUN_DATE,
                             ENTRY_TYPE       = TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                .ENTRY_TYPE,
                             CCY              = TB_ICENT_ACCR_HIST(L_ERROR_INDEX).CCY,
                             LCY_AMT          = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                    .LCY_AMT,
                                                    0),
                             CUR_RUN_ACCR_LCY = NVL(TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                    .CUR_RUN_ACCR_LCY,
                                                    0),
                             ENTRY_PASSED     = TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                                                .ENTRY_PASSED
                       WHERE BRN = TB_ICENT_ACCR_HIST(L_ERROR_INDEX).BRN
                         AND ACC = TB_ICENT_ACCR_HIST(L_ERROR_INDEX).ACC
                         AND PROD = TB_ICENT_ACCR_HIST(L_ERROR_INDEX).PROD
                         AND FRM_NO = TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                            .FRM_NO
                         AND ENT_DT = A
                         AND PROCESS = TB_ICENT_ACCR_HIST(L_ERROR_INDEX)
                            .PROCESS;
                      DBG('UPDATED ictbs_entries_accr_history successfully');
                    END IF;
                  END LOOP;
                WHEN OTHERS THEN
                  DBG('insert into entries hist accr failed with ' ||
                      SQLERRM || ' for : ' || A);
                  DECLARE
                    L_ERROR_COUNT NUMBER := 0;
                    J             NUMBER := 0;
                  BEGIN
                    L_ERROR_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
                    FOR I IN 1 .. L_ERROR_COUNT LOOP
                      J := 0;
                      FOR K IN TB_ICENT_ACCR_HIST.FIRST .. TB_ICENT_ACCR_HIST.LAST LOOP
                        J := J + 1;
                        IF J = SQL%BULK_EXCEPTIONS(I).ERROR_INDEX THEN
                          BEGIN
                            LPG('insert into entries hist failed with ' || '~' || TB_ICENT_ACCR_HIST(K).ACC || '~' ||
                                SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(I)
                                               .ERROR_CODE),
                                       1,
                                       1900),
                                TB_ICENT_ACCR_HIST(K).ACC);
                          EXCEPTION
                            WHEN OTHERS THEN
                              NULL;
                          END;
                          EXIT;
                        END IF;
                      END LOOP;
                    END LOOP;
                  END;
              END;
            
              BEGIN
                DBG(' apy... just before moving to hist');
                IF CSPKS_FEATURE.FN_INSTALLED('APY', P_BRN) THEN
                  FOR K IN TB_ICENT_ACCR_HIST.FIRST .. TB_ICENT_ACCR_HIST.LAST LOOP
                    BEGIN
                      INSERT INTO ICTBS_APY_HISTORY
                        (BRN,
                         ACC,
                         PROD,
                         FRM_NO,
                         ENT_DT,
                         AMT,
                         ACCRUED_AMT,
                         AMT_TO_ACCRUE,
                         RUN_DATE,
                         LIQN)
                        SELECT E.BRN,
                               E.ACC,
                               E.PROD,
                               E.FRM_NO,
                               A,
                               E.AMT,
                               E.ACCRUED_AMT,
                               E.AMT_TO_ACCRUE,
                               TB_ICENT_ACCR_HIST(K).RUN_DATE,
                               'N'
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                           AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD
                           AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC;
                      DBG(' apy... after inst into history');
                    EXCEPTION
                      WHEN DUP_VAL_ON_INDEX THEN
                        DBG(' in dup val');
                        UPDATE ICTBS_APY_HISTORY
                           SET AMT        =
                               (SELECT E.AMT
                                  FROM ICTBS_APY E
                                 WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                                   AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC
                                   AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD),
                               ACCRUED_AMT =
                               (SELECT E.ACCRUED_AMT
                                  FROM ICTBS_APY E
                                 WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                                   AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC
                                   AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD),
                               ENT_DT      = A
                         WHERE BRN = TB_ICENT_ACCR_HIST(K).BRN
                           AND ACC = TB_ICENT_ACCR_HIST(K).ACC
                           AND PROD = TB_ICENT_ACCR_HIST(K).PROD;
                    END;
                  END LOOP;
                END IF;
              
              EXCEPTION
                WHEN OTHERS THEN
                  DBG(' apy... error ' || SQLERRM);
              END;
            
              BEGIN
                FORALL X IN INDICES OF ICPKSS_TEST.TB_ICENT_ACCR_HIST
                  DELETE FROM ICTB_ENTRIES_HIST_ZEROACCR
                   WHERE BRN = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X).BRN
                     AND ACC = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X).ACC
                     AND PROD = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X).PROD
                     AND FRM_NO = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X).FRM_NO
                     AND ENT_DT = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X).ENT_DT
                     AND PROCESS = ICPKSS_TEST.TB_ICENT_ACCR_HIST(X)
                        .PROCESS;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed in deleting the accrual entries from zero accr table-' ||
                      SQLERRM);
              END;
            
            END IF;
          
            DBG('going to populate ictb_entries_hist_zeroaccr for 0 accrual accounts ' ||
                TB_ICENT_ZEROACCR_HIST.COUNT);
            IF TB_ICENT_ZEROACCR_HIST.COUNT <> 0 THEN
            
              BEGIN
                FORALL X IN TB_ICENT_ZEROACCR_HIST.FIRST .. TB_ICENT_ZEROACCR_HIST.LAST SAVE
                                                            EXCEPTIONS
                  INSERT INTO ICTB_ENTRIES_HIST_ZEROACCR
                    (BRN,
                     ACC,
                     PROD,
                     FRM_NO,
                     ENT_DT,
                     AMT,
                     ACCRUED_AMT,
                     CUR_RUN_ACCR,
                     AMT_TO_ACCRUE,
                     RUN_DATE,
                     ENTRY_TYPE,
                     CCY,
                     LCY_AMT,
                     CUR_RUN_ACCR_LCY,
                     LAST_CUR_RUN_ACCR,
                     DRCR,
                     ENTRY_PASSED,
                     PROCESS)
                  VALUES
                    (TB_ICENT_ZEROACCR_HIST(X).BRN,
                     TB_ICENT_ZEROACCR_HIST(X).ACC,
                     TB_ICENT_ZEROACCR_HIST(X).PROD,
                     TB_ICENT_ZEROACCR_HIST(X).FRM_NO,
                     TB_ICENT_ZEROACCR_HIST(X).ENT_DT,
                     TB_ICENT_ZEROACCR_HIST(X).AMT,
                     TB_ICENT_ZEROACCR_HIST(X).ACCRUED_AMT,
                     TB_ICENT_ZEROACCR_HIST(X).CUR_RUN_ACCR,
                     TB_ICENT_ZEROACCR_HIST(X).AMT_TO_ACCRUE,
                     TB_ICENT_ZEROACCR_HIST(X).RUN_DATE,
                     TB_ICENT_ZEROACCR_HIST(X).ENTRY_TYPE,
                     TB_ICENT_ZEROACCR_HIST(X).CCY,
                     TB_ICENT_ZEROACCR_HIST(X).LCY_AMT,
                     TB_ICENT_ZEROACCR_HIST(X).CUR_RUN_ACCR_LCY,
                     TB_ICENT_ZEROACCR_HIST(X).LAST_CUR_RUN_ACCR,
                     TB_ICENT_ZEROACCR_HIST(X).DRCR,
                     TB_ICENT_ZEROACCR_HIST(X).ENTRY_PASSED,
                     TB_ICENT_ZEROACCR_HIST(X).PROCESS);
                DBG('Through with bulk zero accr insert');
              EXCEPTION
                WHEN BULK_ERRORS THEN
                  DBG('insert into zero accr entries hist failed with ' ||
                      SQLERRM || ' for : ' || A);
                  DBG('SQL%BULK_EXCEPTIONS.COUNT zero accr' ||
                      SQL%BULK_EXCEPTIONS.COUNT);
                
                  FOR J IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
                    L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                  
                    DBG('~j = ' || J ||
                        ' ***** SQL%BULK_EXCEPTIONS(j).ERROR_INDEX = ' ||
                        L_ERROR_INDEX);
                    DBG('SQL%BULK_EXCEPTIONS (j).ERROR_CODE =' || SQL%BULK_EXCEPTIONS(J)
                        .ERROR_CODE);
                  
                    IF ABS(SQL%BULK_EXCEPTIONS(J).ERROR_CODE) = 1 THEN
                      L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                      DBG('zero accr  l_error_index =' || L_ERROR_INDEX);
                    
                      UPDATE ICTB_ENTRIES_HIST_ZEROACCR
                         SET AMT               = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).AMT,
                                                     0),
                             ACCRUED_AMT       = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .ACCRUED_AMT,
                                                     0),
                             CUR_RUN_ACCR      = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .CUR_RUN_ACCR,
                                                     0),
                             AMT_TO_ACCRUE     = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .AMT_TO_ACCRUE,
                                                     0),
                             RUN_DATE          = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                 .RUN_DATE,
                             ENTRY_TYPE        = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                 .ENTRY_TYPE,
                             CCY               = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).CCY,
                             LCY_AMT           = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .LCY_AMT,
                                                     0),
                             LAST_CUR_RUN_ACCR = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .LAST_CUR_RUN_ACCR,
                                                     0),
                             CUR_RUN_ACCR_LCY  = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                     .CUR_RUN_ACCR_LCY,
                                                     0),
                             ENTRY_PASSED      = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                                 .ENTRY_PASSED
                       WHERE BRN = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).BRN
                         AND ACC = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).ACC
                         AND PROD = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).PROD
                         AND FRM_NO = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                            .FRM_NO
                         AND ENT_DT = A
                         AND PROCESS = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                            .PROCESS;
                    
                      DBG('zero accr finished ');
                    END IF;
                  END LOOP;
                WHEN OTHERS THEN
                  DBG('insert into entries hist zero accr failed with ' ||
                      SQLERRM || ' for : ' || A);
                  DECLARE
                    L_ERROR_COUNT NUMBER := 0;
                    J             NUMBER := 0;
                  BEGIN
                    L_ERROR_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
                    FOR I IN 1 .. L_ERROR_COUNT LOOP
                      J := 0;
                      FOR K IN TB_ICENT_ZEROACCR_HIST.FIRST .. TB_ICENT_ZEROACCR_HIST.LAST LOOP
                        J := J + 1;
                        IF J = SQL%BULK_EXCEPTIONS(I).ERROR_INDEX THEN
                          BEGIN
                            LPG('insert into entries zero hist failed with ' || '~' || TB_ICENT_ZEROACCR_HIST(K).ACC || '~' ||
                                SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(I)
                                               .ERROR_CODE),
                                       1,
                                       1900),
                                TB_ICENT_ZEROACCR_HIST(K).ACC);
                          EXCEPTION
                            WHEN OTHERS THEN
                              NULL;
                          END;
                          EXIT;
                        END IF;
                      END LOOP;
                    END LOOP;
                  END;
              END;
            
              BEGIN
                FORALL X IN INDICES OF ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST
                  DELETE FROM ICTBS_ENTRIES_HISTORY_ACCR
                   WHERE BRN = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X).BRN
                     AND ACC = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X).ACC
                     AND PROD = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X).PROD
                     AND FRM_NO = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X)
                        .FRM_NO
                     AND ENT_DT = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X)
                        .ENT_DT
                     AND PROCESS = ICPKSS_TEST.TB_ICENT_ZEROACCR_HIST(X)
                        .PROCESS;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed in deleting the accrual entries from ictbs_entries_history_accr table-' ||
                      SQLERRM);
              END;
            
            END IF;
          
            IF TB_ICENT_HIST_ACC.COUNT <> 0 THEN
              DBG('before calling the entries history' ||
                  TB_ICENT_HIST_ACC.COUNT);
              DBG('values of a --> ' || A);
            
              BEGIN
              
                FORALL K IN INDICES OF TB_ICENT_HIST_ACC SAVE EXCEPTIONS
                
                  INSERT INTO ICTBS_ENTRIES_HISTORY
                    (BRN,
                     ACC,
                     PROD,
                     FRM_NO,
                     ENT_DT,
                     AMT,
                     ACCRUED_AMT,
                     CUR_RUN_ACCR,
                     AMT_TO_ACCRUE,
                     RUN_DATE,
                     ACCR,
                     LIQN,
                     ENTRY_TYPE,
                     CCY,
                     LCY_AMT,
                     LAST_CUR_RUN_ACCR,
                     CUR_RUN_ACCR_LCY,
                     ENTRY_PASSED,
                     
                     PROCESS,
                     DRCR
                     
                     )
                  VALUES
                    (TB_ICENT_HIST_BRN(K),
                     TB_ICENT_HIST_ACC(K),
                     TB_ICENT_HIST_PROD(K),
                     TB_ICENT_HIST_FRM_NO(K),
                     A,
                     NVL(TB_ICENT_HIST_AMT(K), 0),
                     NVL(TB_ICENT_HIST_ACCRUED_AMT(K), 0),
                     
                     DECODE(TB_ICENT_HIST_LIQN(K),
                            'Y',
                            0,
                            NVL(TB_ICENT_HIST_CUR_RUN_ACCR(K), 0)),
                     
                     NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(K), 0),
                     TB_ICENT_HIST_RUN_DATE(K),
                     TB_ICENT_HIST_ACCR(K),
                     TB_ICENT_HIST_LIQN(K),
                     TB_ICENT_HIST_ENTRY_TYPE(K),
                     TB_ICENT_HIST_CCY(K),
                     TB_ICENT_HIST_LCY_AMT(K),
                     TB_ICENT_HIST_LAST_CUR_ACCR(K),
                     
                     DECODE(TB_ICENT_HIST_LIQN(K),
                            'Y',
                            0,
                            NVL(TB_ICENT_HIST_CURACCR_LCY(K), 0)),
                     
                     TB_ICENT_HIST_ENTRY_PASSED(K),
                     
                     NVL(P_PROCESS, 1),
                     ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(K),
                                             TB_ICENT_HIST_FRM_NO(K))
                     
                     );
                DBG('through with bulk insert');
              EXCEPTION
              
                WHEN BULK_ERRORS THEN
                  DBG('insert into entries hist failed with ' || SQLERRM ||
                      ' for : ' || A);
                  DBG('SQL%BULK_EXCEPTIONS.COUNT ' ||
                      SQL%BULK_EXCEPTIONS.COUNT);
                
                  FOR J IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
                    L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                  
                    DBG('~j = ' || J ||
                        ' ***** SQL%BULK_EXCEPTIONS(j).ERROR_INDEX = ' ||
                        L_ERROR_INDEX);
                    DBG('SQL%BULK_EXCEPTIONS (j).ERROR_CODE =' || SQL%BULK_EXCEPTIONS(J)
                        .ERROR_CODE);
                  
                    DBG('tb_icent_hist_amt(l_error_index)=' ||
                        TB_ICENT_HIST_AMT(L_ERROR_INDEX));
                  
                    DBG('tb_icent_hist_brn (l_error_index) ~' ||
                        TB_ICENT_HIST_BRN(L_ERROR_INDEX));
                    DBG('tb_icent_hist_acc (l_error_index) ~' ||
                        TB_ICENT_HIST_ACC(L_ERROR_INDEX));
                    DBG('tb_icent_hist_prod (l_error_index) ~' ||
                        TB_ICENT_HIST_PROD(L_ERROR_INDEX));
                    DBG('tb_icent_hist_frm_no (l_error_index) ~' ||
                        TB_ICENT_HIST_FRM_NO(L_ERROR_INDEX));
                    DBG('ent_dt = a ~' || A);
                  
                    DBG('tb_icent_hist_accrued_amt(l_error_index) ~' ||
                        TB_ICENT_HIST_ACCRUED_AMT(L_ERROR_INDEX));
                    DBG('tb_icent_hist_cur_run_accr(l_error_index) ~' ||
                        TB_ICENT_HIST_CUR_RUN_ACCR(L_ERROR_INDEX));
                    DBG('tb_icent_hist_run_date(l_error_index) ~' ||
                        TB_ICENT_HIST_RUN_DATE(L_ERROR_INDEX));
                    DBG('tb_icent_hist_accr (l_error_index) ~' ||
                        TB_ICENT_HIST_ACCR(L_ERROR_INDEX));
                    DBG('tb_icent_hist_liqn (l_error_index) ~' ||
                        TB_ICENT_HIST_LIQN(L_ERROR_INDEX));
                    DBG('tb_icent_hist_entry_type(l_error_index) ~' ||
                        TB_ICENT_HIST_ENTRY_TYPE(L_ERROR_INDEX));
                    DBG('tb_icent_hist_ccy (l_error_index) ~' ||
                        TB_ICENT_HIST_CCY(L_ERROR_INDEX));
                    DBG('tb_icent_hist_lcy_amt(l_error_index) ~' ||
                        TB_ICENT_HIST_LCY_AMT(L_ERROR_INDEX));
                    DBG('tb_icent_hist_last_cur_accr(l_error_index) ~' ||
                        TB_ICENT_HIST_LAST_CUR_ACCR(L_ERROR_INDEX));
                    DBG('tb_icent_hist_curaccr_lcy(l_error_index) ~' ||
                        TB_ICENT_HIST_CURACCR_LCY(L_ERROR_INDEX));
                    DBG('tb_icent_hist_entry_passed(l_error_index) ~' ||
                        TB_ICENT_HIST_ENTRY_PASSED(L_ERROR_INDEX));
                  
                    IF ABS(SQL%BULK_EXCEPTIONS(J).ERROR_CODE) = 1 THEN
                      L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
                      DBG(' l_error_index =' || L_ERROR_INDEX);
                    
                      UPDATE ICTBS_ENTRIES_HISTORY
                         SET AMT           = NVL(TB_ICENT_HIST_AMT(L_ERROR_INDEX),
                                                 0),
                             ACCRUED_AMT   = NVL(TB_ICENT_HIST_ACCRUED_AMT(L_ERROR_INDEX),
                                                 0),
                             CUR_RUN_ACCR  = NVL(TB_ICENT_HIST_CUR_RUN_ACCR(L_ERROR_INDEX),
                                                 0),
                             AMT_TO_ACCRUE = NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(L_ERROR_INDEX),
                                                 0),
                             RUN_DATE      = TB_ICENT_HIST_RUN_DATE(L_ERROR_INDEX),
                             ACCR          = TB_ICENT_HIST_ACCR(L_ERROR_INDEX),
                             LIQN          = TB_ICENT_HIST_LIQN(L_ERROR_INDEX),
                             ENTRY_TYPE    = TB_ICENT_HIST_ENTRY_TYPE(L_ERROR_INDEX),
                             CCY           = TB_ICENT_HIST_CCY(L_ERROR_INDEX),
                             
                             LCY_AMT = DECODE(TB_ICENT_HIST_LIQN(L_ERROR_INDEX),
                                              'Y',
                                              0,
                                              NVL(TB_ICENT_HIST_LCY_AMT(L_ERROR_INDEX),
                                                  0)),
                             
                             LAST_CUR_RUN_ACCR = NVL(TB_ICENT_HIST_LAST_CUR_ACCR(L_ERROR_INDEX),
                                                     0),
                             
                             CUR_RUN_ACCR_LCY = DECODE(TB_ICENT_HIST_LIQN(L_ERROR_INDEX),
                                                       'Y',
                                                       0,
                                                       NVL(TB_ICENT_HIST_CURACCR_LCY(L_ERROR_INDEX),
                                                           0)),
                             
                             ENTRY_PASSED = TB_ICENT_HIST_ENTRY_PASSED(L_ERROR_INDEX)
                       WHERE BRN = TB_ICENT_HIST_BRN(L_ERROR_INDEX)
                         AND ACC = TB_ICENT_HIST_ACC(L_ERROR_INDEX)
                         AND PROD = TB_ICENT_HIST_PROD(L_ERROR_INDEX)
                         AND FRM_NO = TB_ICENT_HIST_FRM_NO(L_ERROR_INDEX)
                         AND ENT_DT = A;
                      DBG('UPDATED ictbs_entries_history successfully');
                    END IF;
                  END LOOP;
                
                WHEN OTHERS THEN
                
                  DBG('insert into entries hist failed with ' || SQLERRM ||
                      ' for : ' || A);
                
                  DECLARE
                    L_ERROR_COUNT NUMBER := 0;
                    J             NUMBER := 0;
                  BEGIN
                    L_ERROR_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
                  
                    FOR I IN 1 .. L_ERROR_COUNT LOOP
                      J := 0;
                    
                      FOR K IN TB_ICENT_HIST_ACC.FIRST .. TB_ICENT_HIST_ACC.LAST LOOP
                        J := J + 1;
                        IF J = SQL%BULK_EXCEPTIONS(I).ERROR_INDEX THEN
                          BEGIN
                            LPG('insert into entries hist failed with ' || '~' ||
                                TB_ICENT_HIST_ACC(K) || '~' ||
                                SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(I)
                                               .ERROR_CODE),
                                       1,
                                       1900),
                                TB_ICENT_HIST_ACC(K));
                          EXCEPTION
                            WHEN OTHERS THEN
                              NULL;
                          END;
                          EXIT;
                        END IF;
                      END LOOP;
                    END LOOP;
                  
                  END;
                
              END;
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID := 5;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                L_TB_CLUSTER_DATA('a') := TO_CHAR(A, 'dd-mon-rrrr');
              
                ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                                 P_DT,
                                                 P_TO_DT,
                                                 P_TAX_PROD,
                                                 P_PROCESS,
                                                 P_AC_CLASS_TYPE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
              END IF;
            
              BEGIN
                DBG(' apy... just before moving to hist');
              
                IF CSPKS_FEATURE.FN_INSTALLED('APY', P_BRN) THEN
                  FOR K IN TB_ICENT_HIST_ACC.FIRST .. TB_ICENT_HIST_ACC.LAST LOOP
                    BEGIN
                      INSERT INTO ICTBS_APY_HISTORY
                        (BRN,
                         ACC,
                         PROD,
                         FRM_NO,
                         ENT_DT,
                         AMT,
                         ACCRUED_AMT,
                         AMT_TO_ACCRUE,
                         RUN_DATE,
                         LIQN)
                        SELECT E.BRN,
                               E.ACC,
                               E.PROD,
                               E.FRM_NO,
                               A,
                               E.AMT,
                               E.ACCRUED_AMT,
                               E.AMT_TO_ACCRUE,
                               TB_ICENT_HIST_RUN_DATE(K),
                               TB_ICENT_HIST_LIQN(K)
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                           AND E.PROD = TB_ICENT_HIST_PROD(K)
                           AND E.ACC = TB_ICENT_HIST_ACC(K);
                      DBG(' apy... after inst into history');
                    EXCEPTION
                      WHEN DUP_VAL_ON_INDEX THEN
                        DBG(' in dup val');
                        UPDATE ICTBS_APY_HISTORY
                           SET AMT        =
                               (SELECT E.AMT
                                  FROM ICTBS_APY E
                                 WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                                   AND E.ACC = TB_ICENT_HIST_ACC(K)
                                   AND E.PROD = TB_ICENT_HIST_PROD(K)),
                               ACCRUED_AMT =
                               (SELECT E.ACCRUED_AMT
                                  FROM ICTBS_APY E
                                 WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                                   AND E.ACC = TB_ICENT_HIST_ACC(K)
                                   AND E.PROD = TB_ICENT_HIST_PROD(K)),
                               ENT_DT      = A
                         WHERE BRN = TB_ICENT_HIST_BRN(K)
                           AND ACC = TB_ICENT_HIST_ACC(K)
                           AND PROD = TB_ICENT_HIST_PROD(K);
                    END;
                  END LOOP;
                END IF;
              
              EXCEPTION
                WHEN OTHERS THEN
                  DBG(' apy... error ' || SQLERRM);
              END;
            END IF;
            DBG('tb_icent_hist_upd.COUNT~l_is_holiday~g_tb_skipped_Accts.count' ||
                TB_ICENT_HIST_UPD.COUNT || '~' || L_IS_HOLIDAY || '~' ||
                G_TB_SKIPPED_ACCTS.COUNT);
            IF NVL(TB_ICENT_HIST_UPD.COUNT, 0) <> 0 THEN
              FOR EACH_ROW IN TB_ICENT_HIST_UPD.FIRST .. TB_ICENT_HIST_UPD.LAST LOOP
              
                IF L_IS_HOLIDAY = 'W'
                  
                   OR
                   (L_IS_HOLIDAY = 'H' AND NOT
                    G_TB_SKIPPED_ACCTS.EXISTS(TB_ICENT_HIST_UPD(EACH_ROW)
                                                                      .BRN || TB_ICENT_HIST_UPD(EACH_ROW).ACC || TB_ICENT_HIST_UPD(EACH_ROW).PROD)) THEN
                
                  IF TB_ICENT_HIST_UPD(EACH_ROW).LIQN = 'N' THEN
                  
                    IF TB_ICENT_HIST_UPD(EACH_ROW).DRCR IS NULL THEN
                      TB_ICENT_HIST_UPD(EACH_ROW).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_UPD(EACH_ROW).PROD,
                                                                                  TB_ICENT_HIST_UPD(EACH_ROW)
                                                                                  .FRM_NO);
                      DBG('tb_icent_hist_upd(each_row).drcr=' || TB_ICENT_HIST_UPD(EACH_ROW).DRCR);
                    END IF;
                  
                    IF NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).ACCRUED_AMT, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT_TO_ACCRUE, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR, 0) <= 0 THEN
                      DBG('2_Explicitly making cur_run_Accr to 0 since amt and amt_to_accure is 0');
                      TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR := 0;
                    
                      IF TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR_LCY <> 0 THEN
                        DBG('for some reason, the cur_accr_lcy is not zero..will make it 0 since insertion in zero accrual table' || TB_ICENT_HIST_UPD(EACH_ROW)
                            .CUR_RUN_ACCR_LCY);
                        TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR_LCY := 0;
                      END IF;
                    
                    END IF;
                  
                    IF NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).ACCRUED_AMT, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT_TO_ACCRUE, 0) = 0 AND
                       NVL(TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR, 0) = 0 THEN
                      PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                                      'Z',
                                      'Y',
                                      P_PROCESS,
                                      A,
                                      L_UPD_COUNT);
                      IF L_UPD_COUNT = 0 THEN
                        PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                                        'Z',
                                        'N',
                                        P_PROCESS,
                                        A,
                                        L_UPD_COUNT);
                      END IF;
                    ELSE
                      PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                                      'A',
                                      'Y',
                                      P_PROCESS,
                                      A,
                                      L_UPD_COUNT);
                      IF L_UPD_COUNT = 0 THEN
                        PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                                        'A',
                                        'N',
                                        P_PROCESS,
                                        A,
                                        L_UPD_COUNT);
                      
                      ELSIF L_UPD_COUNT = -1 THEN
                      
                        TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR := 0;
                        TB_ICENT_HIST_UPD(EACH_ROW).LCY_AMT := 0;
                        TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR_LCY := 0;
                        DBG('24390157 IC_INTRADAY_PERF: Explicitly updating cur_run_accr,lcy_amt,cur_run_accr_lcy to zero, since this condtion will get satisfied only if cur_run_accr is 0');
                      
                        ICPKSS_TEST.PR_UPD_ACCR_ENT(ICPKSS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                                    'Z',
                                                    'N',
                                                    P_PROCESS,
                                                    A,
                                                    L_UPD_COUNT);
                      
                      END IF;
                    END IF;
                  ELSE
                  
                    UPDATE ICTBS_ENTRIES_HISTORY
                       SET AMT = NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0)
                     WHERE BRN = TB_ICENT_HIST_UPD(EACH_ROW).BRN
                       AND ACC = TB_ICENT_HIST_UPD(EACH_ROW).ACC
                       AND PROD = TB_ICENT_HIST_UPD(EACH_ROW).PROD
                       AND FRM_NO = TB_ICENT_HIST_UPD(EACH_ROW).FRM_NO
                       AND ENT_DT =
                           NVL(TB_ICENT_HIST_UPD(EACH_ROW).ENT_DT, A);
                  END IF;
                END IF;
              END LOOP;
            END IF;
            TB_ICENT_HIST_UPD.DELETE;
            IF NVL(TB_ICENT_HIST_ADJ.COUNT, 0) <> 0 THEN
              DBG('tb_icent_hist_adj count is more than 0 so updating the amt with adj amt in entries history');
              BUG1 := TB_ICENT_HIST_ADJ.FIRST;
              WHILE BUG1 <= TB_ICENT_HIST_ADJ.LAST LOOP
                DBG('adjustments are being done' || TB_ICENT_HIST_ADJ(BUG1).ACC || '~' || TB_ICENT_HIST_ADJ(BUG1).AMT);
                DBG('lcy amount is ' || TB_ICENT_HIST_ADJ(BUG1).LCY_AMT);
                UPDATE ICTBS_ENTRIES_HISTORY E
                   SET E.AMT     = E.AMT + TB_ICENT_HIST_ADJ(BUG1).AMT,
                       E.LCY_AMT = E.LCY_AMT + TB_ICENT_HIST_ADJ(BUG1)
                                  .LCY_AMT
                 WHERE E.BRN = TB_ICENT_HIST_ADJ(BUG1).BRN
                   AND E.ACC = TB_ICENT_HIST_ADJ(BUG1).ACC
                   AND E.PROD = TB_ICENT_HIST_ADJ(BUG1).PROD
                   AND E.FRM_NO = TB_ICENT_HIST_ADJ(BUG1).FRM_NO
                   AND E.ENT_DT = TB_ICENT_HIST_ADJ(BUG1).ENT_DT;
                BUG1 := TB_ICENT_HIST_ADJ.NEXT(BUG1);
              END LOOP;
            END IF;
            DBG('going to call next record date' || PROCESS_THESE.COUNT);
            DBG('just before going to update acpr' || L_LAST_REC);
          
            IF CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
              L_IC_SKIP_RECALC_LIQN := 1;
            ELSE
              L_IC_SKIP_RECALC_LIQN := 0;
            END IF;
          
            FORALL UPD IN INDICES OF TB_ROWID
              UPDATE ICTBS_ACC_PR
              
                 SET NEXT_ACCR_DT = LEAST(TB_NEXT_ACCR_DT(UPD),
                                          NVL(TB_NEXT_LIQ_DT(UPD),
                                              TB_NEXT_ACCR_DT(UPD))),
                     
                     NEXT_LIQ_DT        = TB_NEXT_LIQ_DT(UPD),
                     NEXT_EVENT_DT      = TB_NEXT_EVENT_DT(UPD),
                     NEXT_CALC_DT       = TB_NEXT_CALC_DT(UPD),
                     NEXT_SCHD_ACCR_DT  = TB_NEXT_SCHD_ACCR_DT(UPD),
                     NEXT_SCHD_LIQ_DT   = TB_NEXT_SCHD_LIQ_DT(UPD),
                     HAS_PROBLEMS       = TB_HAS_PROBLEMS(UPD),
                     LAST_SCHD_LIQ_DT   = TB_LAST_SCHD_LIQ_DT(UPD),
                     LAST_ACCR_DT       = TB_LAST_ACCR_DT(UPD),
                     LAST_LIQ_DT        = TB_LAST_LIQ_DT(UPD),
                     LAST_CALC_DT       = TB_LAST_CALC_DT(UPD),
                     FIRST_CALC_DT      = TB_FIRST_CALC_DT(UPD),
                     BKVAL_RECALC_FLAG  = TB_BKVAL_RECALC_FLAG(UPD),
                     BKVAL_MINCALC_DATE = TB_BKVAL_MINCALC_DATE(UPD),
                     DEFER_LIQ_DT       = TB_DEFER_LIQ_DT(UPD),
                     
                     RECALC_ACCR_ON_LIQN =
                     (CASE
                       WHEN (TB_NEXT_LIQ_DT(UPD) <=
                            LEAST(TB_NEXT_ACCR_DT(UPD),
                                   NVL(TB_NEXT_LIQ_DT(UPD), TB_NEXT_ACCR_DT(UPD))) AND
                            TB_LAST_ACCR_DT(UPD) =
                            LEAST(TB_NEXT_ACCR_DT(UPD),
                                   NVL(TB_NEXT_LIQ_DT(UPD), TB_NEXT_ACCR_DT(UPD))) AND
                            L_IC_SKIP_RECALC_LIQN = 1) THEN
                        RECALC_ACCR_ON_LIQN
                       ELSE
                        'Y'
                     END)
              
               WHERE ROWID = TB_ROWID(UPD);
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID      := 16;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                               P_DT,
                                               P_TO_DT,
                                               P_TAX_PROD,
                                               P_PROCESS,
                                               P_AC_CLASS_TYPE,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
            END IF;
          
            IF NVL(TB_ICENT_UPD_ACC.COUNT, 0) <> 0 THEN
              DBG('just going to update ictb_entries' ||
                  TB_ICENT_UPD_ACC.COUNT);
              FORALL I IN TB_ICENT_UPD_ACC.FIRST .. TB_ICENT_UPD_ACC.LAST
                UPDATE ICTBS_ENTRIES
                   SET AMT           = NVL(TB_ICENT_UPD_AMT(I), 0),
                       ACCRUED_AMT   = NVL(TB_ICENT_UPD_ACCRUED_AMT(I), 0),
                       AMT_TO_ACCRUE = NVL(TB_ICENT_UPD_AMT_TO_ACCRUE(I), 0),
                       CUR_RUN_ACCR  = NVL(TB_ICENT_UPD_CUR_RUN_ACCR(I), 0),
                       ENT_DT        = TB_ICENT_UPD_ENT_DT(I),
                       
                       DRCR               = TB_ICENT_UPD_DRCR(I),
                       DAILY_AMT          = NVL(TB_ICENT_UPD_DAILY_AMT(I), 0),
                       NEXT_CALC_DUE_DATE = TB_ICENT_UPD_NEXT_CALC_DUE_DT(I),
                       ACQUIRED_AMT       = NVL(TB_ICENT_UPD_ACQUIRED_AMT(I),
                                                0),
                       ACQUIRED_ADJ       = NVL(TB_ICENT_UPD_ACQUIRED_ADJ(I),
                                                0)
                 WHERE ROWID = TB_ICENT_UPD_ROWID(I);
            
              DBG('Going to update ictb_past_adj_entries here. This is a blind update and has to be reverted');
              IF (TB_ICENT_PAST_ADJ_UPD_ROWID.COUNT > 0) THEN
                FOR I IN TB_ICENT_PAST_ADJ_UPD_ROWID.FIRST .. TB_ICENT_PAST_ADJ_UPD_ROWID.LAST LOOP
                  IF (TB_ICENT_PAST_ADJ_UPD_ROWID.EXISTS(I)) THEN
                    DBG('Update the ictb_past_adj_entries table for ' ||
                        TB_ICENT_PAST_ADJ_UPD_ROWID(I));
                  
                    DBG('tb_icent_past_adj_upd_acq_amt(i) ' ||
                        TB_ICENT_PAST_ADJ_UPD_ACQ_AMT(I));
                    DBG('tb_icent_past_adj_upd_acq_adj(i) ' ||
                        TB_ICENT_PAST_ADJ_UPD_ACQ_ADJ(I));
                    UPDATE ICTB_PAST_ADJ_ENTRIES
                       SET ACQUIRED_AMT = TB_ICENT_PAST_ADJ_UPD_ACQ_AMT(I),
                           ACQUIRED_ADJ = TB_ICENT_PAST_ADJ_UPD_ACQ_ADJ(I)
                     WHERE ROWID = TB_ICENT_PAST_ADJ_UPD_ROWID(I);
                  
                  END IF;
                END LOOP;
              END IF;
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID      := 6;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              
                ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                                 P_DT,
                                                 P_TO_DT,
                                                 P_TAX_PROD,
                                                 P_PROCESS,
                                                 P_AC_CLASS_TYPE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
              END IF;
            
            END IF;
            DBG('going to update repop cases');
            DBG('Count for repop here: ' || TB_REPOP_ACC.COUNT);
            IF TB_REPOP_ACC.COUNT <> 0 THEN
              DBG('updating the repop cases');
              IF TB_GC.COUNT > 0 THEN
                FOR K IN TB_GC.FIRST .. TB_GC.LAST LOOP
                  L_UDE_ID    := TB_GC(K).UDE_ID;
                  L_UDE_VALUE := TB_GC(K).UDE_VALUE;
                  L_RATE_CODE := TB_GC(K).RATE_CODE;
                
                  L_TD_RATE_CODE := TB_GC(K).TD_RATE_CODE;
                
                  FOR I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST LOOP
                    BEGIN
                      SELECT UDE_VARIANCE
                        INTO L_UDE_VARIANCE
                        FROM (SELECT UDE_VARIANCE
                                FROM ICTMS_ACC_UDEVALS
                               WHERE ACC = TB_REPOP_ACC(I)
                                 AND BRN = TB_REPOP_BRN(I)
                                 AND PROD = TB_GC(K).PRODUCT_CODE
                                 AND UDE_ID = L_UDE_ID
                               ORDER BY UDE_EFF_DT DESC)
                       WHERE ROWNUM = 1;
                      TB_UDE_VARIANCE(I) := L_UDE_VARIANCE;
                    
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        DBG('failed in ude variance select');
                        TB_UDE_VARIANCE(I) := 0;
                    END;
                  
                  END LOOP;
                  DBG('Selection successfull successful');
                
                  DBG('inserting into ictm_acc_udevals');
                  BEGIN
                    FORALL I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST
                      INSERT INTO ICTMS_ACC_UDEVALS
                        (BRN,
                         ACC,
                         PROD,
                         UDE_EFF_DT,
                         UDE_ID,
                         UDE_VALUE,
                         RATE_CODE,
                         RECORD_STAT,
                         AUTH_STAT,
                         
                         TD_RATE_CODE,
                         UDE_VARIANCE)
                      VALUES
                        (TB_REPOP_BRN(I),
                         TB_REPOP_ACC(I),
                         TB_GC(K).PRODUCT_CODE,
                         TB_REPOP_LIQ_DT(I) + 1,
                         L_UDE_ID,
                         L_UDE_VALUE,
                         L_RATE_CODE,
                         'O',
                         'A',
                         
                         L_TD_RATE_CODE,
                         TB_UDE_VARIANCE(I));
                  EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN
                      DBG('dup val on index fnd... skip insert');
                  END;
                END LOOP;
              
                DBG('inserting into ictm_acc_effdt');
                BEGIN
                  FORALL I IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST
                    INSERT INTO ICTM_ACC_EFFDT
                      (BRN, ACC, PROD, UDE_EFF_DT, RECORD_STAT, ONCE_AUTH)
                    VALUES
                      (TB_REPOP_BRN(I),
                       TB_REPOP_ACC(I),
                       TB_REPOP_PROD(I),
                       TB_REPOP_LIQ_DT(I) + 1,
                       'O',
                       'Y');
                EXCEPTION
                  WHEN DUP_VAL_ON_INDEX THEN
                    DBG('dup val on index just skip insert');
                END;
                FOR S IN TB_REPOP_ACC.FIRST .. TB_REPOP_ACC.LAST LOOP
                  DBG('calling icpkss_calc.pr_pop_sc for ' ||
                      TB_REPOP_ACC(S) || '~' || TB_REPOP_PROD(S));
                  ICPKSS_CALC.PR_POP_SC(TB_REPOP_BRN(S),
                                        TB_REPOP_ACC(S),
                                        TB_REPOP_PROD(S),
                                        P_DT + 1,
                                        TB_REPOP_CCY(S));
                
                  ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(TB_REPOP_BRN(S),
                                                      TB_REPOP_ACC(S));
                END LOOP;
              END IF;
              TB_REPOP_ACC.DELETE;
              TB_REPOP_BRN.DELETE;
              TB_REPOP_CCY.DELETE;
              TB_REPOP_LIQ_DT.DELETE;
              TB_GC.DELETE;
            END IF;
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 7;
              DBG('calling call id 7 for insertion into Ictb_liqd_receivable');
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                               P_DT,
                                               P_TO_DT,
                                               P_TAX_PROD,
                                               P_PROCESS,
                                               P_AC_CLASS_TYPE,
                                               L_FN_CALL_ID,
                                               L_TB_CLUSTER_DATA);
              DBG(' call to pr_iceod_wrap for IC RECEIVABLES done :');
            END IF;
          
            PR_MSTB_INSERT;
            DBG('after dly msg out insert if any ');
            IF NVL(TB_ICTMACC_UPD_ACC.COUNT, 0) <> 0 THEN
              DBG('tb_ictmacc_upd_acc.count is greater than 0 so updating ictm_acc with last_is_date');
              FORALL PJ IN TB_ICTMACC_UPD_ACC.FIRST .. TB_ICTMACC_UPD_ACC.LAST
                UPDATE ICTMS_ACC
                   SET LAST_IS_DATE = TB_ICTMACC_UPD_ISDT(PJ)
                 WHERE ACC = TB_ICTMACC_UPD_ACC(PJ)
                   AND BRN = TB_ICTMACC_UPD_BRN(PJ);
            END IF;
          
          END IF;
          PR_PURGE_PLSQL_TABS;
          DBG('after purging the pl/sql tables ');
          IF CSPKS_FEATURE.FN_INSTALLED('DEFERLIQ', P_BRN) THEN
          
            BEGIN
              DBG('b4 calling pr_liq_defr brn-->' || P_BRN || ' date-->' || A);
              PR_LIQ_DEFR(P_BRN, A);
              DBG('after calling pr_liq_defr');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('in wo while calling pr_liq_defr-->' || SQLERRM);
              
                PR_PURGE_PLSQL_TABS;
              
                DBG('Rollback done here - till Sp_Dfr_Liqd');
                ROLLBACK TO SP_DFR_LIQD;
              
            END;
          END IF;
          DBG('Commiting here');
          COMMIT;
        EXCEPTION
          WHEN ACPR_LOOP_EXCPTN THEN
            DBG('Into acpr_loop_excptn');
            BEGIN
              LPG('Into acpr_loop_excptn ' || SUBSTR(SQLERRM, 1, 1900), '');
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
            DBG('Rollback done here - till sp_process_day');
            ROLLBACK TO SP_PROCESS_DAY;
            PR_PURGE_PLSQL_TABS;
          
          WHEN VDBAL_UPDATE_EXCPN THEN
            DBG('VDBAL_UPDATE_EXCPN: ' || SQLERRM);
            DBG('Rollback done here - till sp_process_day');
            ROLLBACK TO SP_PROCESS_DAY;
            PR_PURGE_PLSQL_TABS;
            RAISE;
          
          WHEN OTHERS THEN
            DBG('into wot of accpr loop -> ' || SQLERRM);
            DBG('Rollback done here - till sp_process_day');
            ROLLBACK TO SP_PROCESS_DAY;
            PR_PURGE_PLSQL_TABS;
        END;
      
        FOR UPD IN TB_ROWID.FIRST .. TB_ROWID.LAST LOOP
        
          DBG('UPD' || UPD);
          UPDATE ICTBS_ACC_PR
             SET NEXT_EVENT_DT = LEAST(DEFER_LIQ_DT, NEXT_LIQ_DT)
           WHERE ROWID = TB_ROWID(UPD)
             AND NEXT_EVENT_DT = NEXT_LIQ_DT
             AND DEFER_LIQ_DT > GLOBAL.APPLICATION_DATE
             AND DEPOSIT = 'N';
          DBG('SQL%ROWCOUNT' || SQL%ROWCOUNT);
        END LOOP;
      
        DBG('Commit here..6616 line in icpks_Test');
        COMMIT;
        DBG('J' || J);
        PROCESS_THESE.DELETE(J);
        J := PROCESS_THESE.NEXT(J);
        DBG('after next i am here with ' || J);
        IF J IS NULL THEN
          DBG('j is now so exiting ' || '~' || J);
          EXIT;
        END IF;
      END LOOP;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        L_FN_CALL_ID := 12;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('l_exit') := 'N';
      
        ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                         P_DT,
                                         P_TO_DT,
                                         P_TAX_PROD,
                                         P_PROCESS,
                                         P_AC_CLASS_TYPE,
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
      
        IF L_TB_CLUSTER_DATA('l_exit') = 'Y' THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          EXIT;
        END IF;
      END IF;
    
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        EXIT WHEN CUR_ICTB_ACCPR%NOTFOUND;
      
      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
    END LOOP;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      GLOBAL.PR_RESET_SKIP_KERNEL;
      L_FN_CALL_ID      := 13;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      ICPKS_TEST_CLUSTER.PR_ICEOD_WRAP(P_BRN,
                                       P_DT,
                                       P_TO_DT,
                                       P_TAX_PROD,
                                       P_PROCESS,
                                       P_AC_CLASS_TYPE,
                                       L_FN_CALL_ID,
                                       L_TB_CLUSTER_DATA);
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      CLOSE CUR_ICTB_ACCPR;
    
    ELSE
      GLOBAL.PR_RESET_SKIP_KERNEL;
    END IF;
  
    DBG('Through from all the loops');
  
    DELETE FROM ICTB_INTRADAY_ACC_PR_BKUP WHERE BRN = P_BRN;
    DBG('Cleared ICTB_INTRADAY_ACC_PR_BKUP' || SQL%ROWCOUNT);
  
    G_TB_SKIPPED_ACCTS.DELETE;
    L_TB_ACC_EVENT_DATES.DELETE;
    L_TB_ACC_LIQN_RECDS.DELETE;
  
    IF NOT ICPKSS_ACCR_INT.FN_SET_ACC_ACCR(P_BRN,
                                           NULL,
                                           
                                           P_PROCESS,
                                           VD_ERR,
                                           VD_ERP) THEN
      DBG('icpks_accr_int.fn_set_acc_accr retured false');
      DBG('Vd Err ' || VD_ERR);
      DBG('Vd Erp ' || VD_ERP);
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBG('All the accounts got processed');
    WHEN OTHERS THEN
      DBG('failed in main function with ' || SQLERRM);
    
      TB_HOFF_CONS.DELETE;
      PR_TAKE_PLSQL_TAB_RESTORE;
    
      DBG('Rollback done here - till sp_process_day1');
      ROLLBACK TO SP_PROCESS_DAY1;
      PR_PURGE_PLSQL_TABS;
    
      RAISE;
  END PR_ICEOD_WRAP;

  PROCEDURE PR_CACHE_PROD(P_PROD   VARCHAR2,
                          P_STATUS STTMS_CONTRACT_STATUSES.STATUS_CODE%TYPE) IS
    CURSOR CUR_ICTM_PRINT IS
      SELECT * FROM ICTMS_PR_INT WHERE PRODUCT_CODE = P_PROD;
    CURSOR CUR_RULEFRM(P_RULE VARCHAR2) IS
      SELECT * FROM ICTMS_RULE_FRM WHERE RULE_ID = P_RULE;
    H BINARY_INTEGER;
  
    PROCEDURE POP_STR(STR_VAL VARCHAR2, STR_POS VARCHAR2, K BINARY_INTEGER) IS
    BEGIN
      DBG('Inside pop_str');
      IF STR_POS = 1 THEN
        TB_PRINT(K).FRM_VAL_STR := STR_VAL ||
                                   RPAD(NVL(SUBSTR(TB_PRINT(K).FRM_VAL_STR,
                                                   2),
                                            ' '),
                                        (L_COMMIT_FREQ - 1));
      ELSE
        TB_PRINT(K).FRM_VAL_STR := RPAD(NVL(SUBSTR(TB_PRINT(K).FRM_VAL_STR,
                                                   1,
                                                   STR_POS - 1),
                                            ' '),
                                        STR_POS - 1) || STR_VAL ||
                                   RPAD(NVL(SUBSTR(TB_PRINT(K).FRM_VAL_STR,
                                                   STR_POS + 1),
                                            ' '),
                                        (L_COMMIT_FREQ - STR_POS));
      END IF;
    END POP_STR;
  BEGIN
    H := CSPKSS_UTILS.FN_HASH40(P_PROD);
  
    IF NOT TB_PRINT.EXISTS(H) THEN
      FOR EACH_ROW IN CUR_ICTM_PRINT LOOP
        TB_PRINT(H).PRODUCT_CODE := EACH_ROW.PRODUCT_CODE;
        TB_PRINT(H).RULE := EACH_ROW.RULE;
        TB_PRINT(H).LIQN_DAYS := EACH_ROW.LIQN_DAYS;
        TB_PRINT(H).LIQN_MONTHS := EACH_ROW.LIQN_MONTHS;
        TB_PRINT(H).LIQN_YEARS := EACH_ROW.LIQN_YEARS;
        TB_PRINT(H).LIQN_START_ACCOUNT := EACH_ROW.LIQN_START_ACCOUNT;
        TB_PRINT(H).LIQN_START_DATE := EACH_ROW.LIQN_START_DATE;
        TB_PRINT(H).LIQN_EOM := EACH_ROW.LIQN_EOM;
        TB_PRINT(H).ACCR_PROD_LEVEL := EACH_ROW.ACCR_PROD_LEVEL;
        TB_PRINT(H).ACCR_FREQ := EACH_ROW.ACCR_FREQ;
        TB_PRINT(H).ACCR_MONTH := EACH_ROW.ACCR_MONTH;
        TB_PRINT(H).ACCR_EOM := EACH_ROW.ACCR_EOM;
        TB_PRINT(H).ACCR_DAY := EACH_ROW.ACCR_DAY;
        TB_PRINT(H).UDE_CCY := EACH_ROW.UDE_CCY;
        TB_PRINT(H).FIRST_CALC_DATE := EACH_ROW.FIRST_CALC_DATE;
        TB_PRINT(H).FIRST_ACCR_DATE := EACH_ROW.FIRST_ACCR_DATE;
        TB_PRINT(H).BACK_CALC_FLAG := EACH_ROW.BACK_CALC_FLAG;
        TB_PRINT(H).LIQN_BF_MTHEND := EACH_ROW.LIQN_BF_MTHEND;
        TB_PRINT(H).DAYS_BF_MTHEND := EACH_ROW.DAYS_BF_MTHEND;
        TB_PRINT(H).PNL_REPLACE := EACH_ROW.PNL_REPLACE;
      
        TB_PRINT(H).DEFERRED_FLAG := EACH_ROW.DEFERRED_FLAG;
        TB_PRINT(H).CALC_DAYS := EACH_ROW.CALC_DAYS;
      
        TB_PRINT(H).IL_TYPE := EACH_ROW.IL_TYPE;
        TB_PRINT(H).IL_PRODUCT := EACH_ROW.IL_PRODUCT;
      
        IF EACH_ROW.ACCR_FREQ = 'M' THEN
          TB_PRINT(H).MTH_COUNT := 1;
        ELSIF EACH_ROW.ACCR_FREQ = 'Q' THEN
          TB_PRINT(H).MTH_COUNT := 3;
        ELSIF EACH_ROW.ACCR_FREQ = 'S' THEN
          TB_PRINT(H).MTH_COUNT := 6;
        ELSIF EACH_ROW.ACCR_FREQ = 'A' THEN
          TB_PRINT(H).MTH_COUNT := 12;
        END IF;
        FOR LVAR IN CUR_RULEFRM(EACH_ROW.RULE) LOOP
          POP_STR(LVAR.TAX_PAY_CCY_FLAG, LVAR.FRM_NO, H);
        
          IF LVAR.BOOK_FLAG = 'T' THEN
            TB_PRINT(H).TAX_CATEGORY := LVAR.TAX_CATEGORY;
            DBG('Setting the Tax Category ' || TB_PRINT(H).TAX_CATEGORY);
          END IF;
        
        END LOOP;
      
        BEGIN
          SELECT 'Y'
            INTO TB_PRINT(H).IS_FMT
            FROM ICTM_IS_FMT
           WHERE RULE_ID = TB_PRINT(H).RULE
             AND ROWNUM = 1;
        EXCEPTION
          WHEN OTHERS THEN
            TB_PRINT(H).IS_FMT := 'N';
        END;
      
      END LOOP;
    END IF;
  
  END PR_CACHE_PROD;

  PROCEDURE PR_ACCRUE(P_DT     DATE,
                      I        NUMBER,
                      TB_ICENT IN OUT NOCOPY REC_ICENT) IS
  
    R_PR            REC_PRINT;
    AMT_NOT_ACCRUED ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    ERR_CODE        ERTBS_MSGS.ERR_CODE%TYPE;
    TBFRM           TBFRMTYP;
  
    E_PRM            VARCHAR2(255);
    NEW_NEXT_CALC_DT DATE;
  
    LAST_REC           NUMBER := 0;
    L_ENTRY_TYPE       CHAR(1);
    ERM                VARCHAR2(2000);
    L_LAST_CUR_ACCR    NUMBER := 0;
    L_PREV_ACCRUED_AMT NUMBER := 0;
    C                  NUMBER := 0;
    EXP_CONV EXCEPTION;
    L_ACCRUAL_TILL_DATE    DATE;
    L_NEW_LIQD_AMT         NUMBER := 0;
    L_REM_TD_AMT_TO_ACCRUE NUMBER := 0;
    L_PREV_ACCR_ADJ_AMT    NUMBER := 0;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    L_COMPUTE_FLAG VARCHAR2(1);
    L_IS_HOLIDAY   VARCHAR2(1) := 'W';
  
    PROCEDURE EMSG IS
    BEGIN
      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_ACCRUE->');
    END EMSG;
  
    PROCEDURE UPD_ACC IS
      R_PR                REC_PRINT;
      NXT_ACCR_DT         ICVWS_ACCPR_SEL.NEXT_ACCR_DT%TYPE;
      ADAY                CHAR(2);
      L_INIT_NEXT_ACCR_DT DATE := NULL;
      L_INIT_LAST_ACCR_DT DATE := NULL;
      L_XRATE             NUMBER(14, 7);
      L_CURR_LCY          ICTBS_ENTRIES.CUR_RUN_ACCR%TYPE;
      L_NEXT_DATE         DATE := NULL;
      L_COUNT             PLS_INTEGER := 0;
    BEGIN
      DBG('Inside upd_acc of pr_accrue');
      DBG('By the time I came in ' || TB_NEXT_SCHD_ACCR_DT(I) || '~' ||
          TB_NEXT_ACCR_DT(I) || '~' || TB_LAST_ACCR_DT(I));
      L_INIT_NEXT_ACCR_DT := TB_NEXT_ACCR_DT(I);
      L_INIT_LAST_ACCR_DT := TB_LAST_ACCR_DT(I);
      DBG('Init next/last accr dt is ' || L_INIT_NEXT_ACCR_DT || '~' ||
          L_INIT_LAST_ACCR_DT);
      FIND_KEY(TB_PROD(I), R_PR);
      DBG('calling pr_entries_accrue for ' || P_DT || '~' || I || '~' ||
          TBFRM.COUNT);
      PR_ENTRIES_ACCRUE(P_DT, I, TBFRM);
      DBG('after calling pr_entries_accrue ' || TB_NEXT_SCHD_ACCR_DT(I) || '~' ||
          TB_NEXT_ACCR_DT(I));
      IF TB_NEXT_SCHD_ACCR_DT(I) = TB_NEXT_ACCR_DT(I) THEN
        DBG('Next schd accr dt is same as next accr dt and accr frequency is ' ||
            R_PR.ACCR_FREQ);
        IF R_PR.ACCR_FREQ = 'D' THEN
          IF NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N' THEN
          
            IF PKG_PROCESS_TILL <> 'S' THEN
              NXT_ACCR_DT := L_ACCRUAL_TILL_DATE + 1;
              DBG('nxt_accr_dt first ' || NXT_ACCR_DT);
            
            ELSE
              NXT_ACCR_DT := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                          GLOBAL.CURRENT_BRANCH,
                                                          L_ACCRUAL_TILL_DATE,
                                                          'N',
                                                          1);
              DBG('nxt_accr_dt next ' || NXT_ACCR_DT);
            END IF;
          
          ELSE
            NXT_ACCR_DT := P_DT + 1;
          END IF;
        ELSIF R_PR.ACCR_FREQ = 'L' THEN
          NXT_ACCR_DT := ADD_MONTHS(P_DT,
                                    (12 * R_PR.LIQN_YEARS + R_PR.LIQN_MONTHS)) +
                         R_PR.LIQN_DAYS;
        ELSE
          NXT_ACCR_DT := ADD_MONTHS(P_DT, R_PR.MTH_COUNT);
        END IF;
        DBG('Next accr date is' || '~' || NXT_ACCR_DT);
        ADAY := LTRIM(RTRIM(TO_CHAR(NVL(R_PR.ACCR_DAY, 0), '00')));
        DBG('aday is ' || ADAY);
        IF ADAY != '00' AND ADAY != '31' THEN
          IF ADAY < TO_CHAR(NXT_ACCR_DT, 'DD') THEN
          
            NXT_ACCR_DT := TRUNC(NXT_ACCR_DT, 'MON') + ADAY - 1;
          END IF;
        END IF;
        DBG('Finally I decided it to be on' || NXT_ACCR_DT);
        DBG('New next calc dt is ' || NEW_NEXT_CALC_DT);
        DBG('tb_next_liq_dt is ' || TB_NEXT_LIQ_DT(I));
      
        TB_LAST_ACCR_DT(I) := L_ACCRUAL_TILL_DATE;
        TB_NEXT_ACCR_DT(I) := NXT_ACCR_DT;
        TB_NEXT_SCHD_ACCR_DT(I) := NXT_ACCR_DT;
        DBG('tb_next_accr_dt(i)=' || TB_NEXT_ACCR_DT(I) || 'p_dt=' || P_DT);
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := NVL(NEW_NEXT_CALC_DT,
                                    
                                    GREATEST(TB_NEXT_ACCR_DT(I),
                                             (TRUNC(P_DT) + 1)));
        
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(NVL(NEW_NEXT_CALC_DT, TRUNC(P_DT) + 1),
                                 TB_NEXT_LIQ_DT(I));
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            DBG('p_dt ' || P_DT);
            TB_NEXT_CALC_DT(I) := LEAST(NVL(NEW_NEXT_CALC_DT,
                                            
                                            GREATEST(TB_NEXT_ACCR_DT(I),
                                                     (TRUNC(P_DT) + 1))),
                                        
                                        NVL(TB_NEXT_LIQ_DT(I),
                                            
                                            GREATEST(TB_NEXT_ACCR_DT(I),
                                                     (TRUNC(P_DT) + 1))));
          
          END IF;
        END IF;
      ELSIF TB_NEXT_SCHD_ACCR_DT(I) < TB_NEXT_ACCR_DT(I) THEN
        DBG('schd accrdate is less than next accr date');
        IF R_PR.ACCR_FREQ = 'D' THEN
          NXT_ACCR_DT := TB_NEXT_ACCR_DT(I) + 1;
        ELSIF R_PR.ACCR_FREQ = 'L' THEN
          NXT_ACCR_DT := ADD_MONTHS(TB_NEXT_SCHD_ACCR_DT(I),
                                    (12 * R_PR.LIQN_YEARS + R_PR.LIQN_MONTHS)) +
                         R_PR.LIQN_DAYS;
          WHILE NXT_ACCR_DT < TB_NEXT_ACCR_DT(I) LOOP
            NXT_ACCR_DT := ADD_MONTHS(NXT_ACCR_DT,
                                      (12 * R_PR.LIQN_YEARS +
                                      R_PR.LIQN_MONTHS)) + R_PR.LIQN_DAYS;
          END LOOP;
        ELSE
          NXT_ACCR_DT := ADD_MONTHS(P_DT, R_PR.MTH_COUNT);
        END IF;
        DBG('Really final date decided is' || NXT_ACCR_DT);
        ADAY := LTRIM(RTRIM(TO_CHAR(NVL(R_PR.ACCR_DAY, 0), '00')));
        IF ADAY != '00' AND ADAY != '31' THEN
          IF ADAY < TO_CHAR(NXT_ACCR_DT, 'DD') THEN
            NXT_ACCR_DT := TRUNC(P_DT, 'MON') + ADAY - 1;
          END IF;
        END IF;
        TB_LAST_ACCR_DT(I) := TB_NEXT_ACCR_DT(I);
        TB_NEXT_ACCR_DT(I) := NXT_ACCR_DT;
        TB_NEXT_SCHD_ACCR_DT(I) := NXT_ACCR_DT;
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := NVL(NEW_NEXT_CALC_DT, TRUNC(P_DT) + 1);
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(NVL(NEW_NEXT_CALC_DT, TRUNC(P_DT) + 1),
                                 TB_NEXT_LIQ_DT(I));
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            TB_NEXT_CALC_DT(I) := LEAST(NVL(NEW_NEXT_CALC_DT,
                                            TRUNC(P_DT) + 1),
                                        TB_NEXT_LIQ_DT(I));
          END IF;
        END IF;
      ELSE
        TB_LAST_ACCR_DT(I) := TB_NEXT_ACCR_DT(I);
        TB_NEXT_ACCR_DT(I) := TB_NEXT_SCHD_ACCR_DT(I);
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := NVL(NEW_NEXT_CALC_DT, TRUNC(P_DT) + 1);
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(NVL(NEW_NEXT_CALC_DT, TRUNC(P_DT) + 1),
                                 TB_NEXT_LIQ_DT(I));
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            TB_NEXT_CALC_DT(I) := LEAST(NVL(NEW_NEXT_CALC_DT,
                                            TRUNC(P_DT) + 1),
                                        TB_NEXT_LIQ_DT(I));
          END IF;
        END IF;
      END IF;
    
      IF R_PR.ACCR_FREQ <> 'D' THEN
        TB_NEXT_CALC_DT(I) := LEAST(NVL(TB_NEXT_ACCR_DT(I),
                                        TB_NEXT_CALC_DT(I)),
                                    TB_NEXT_CALC_DT(I));
      END IF;
    
      DBG('Here just after the mains...' || TB_NEXT_ACCR_DT(I) || '~' ||
          TB_LAST_ACCR_DT(I) || '~' || TB_NEXT_CALC_DT(I));
    
      IF G_RECALC_LIQNDT = 'N' THEN
        DBG('tb_last_accr_dt~tb_next_accr_dt(i)~icpkss_test.g_ictm_acc.maturity_Date =' ||
            TB_LAST_ACCR_DT(I) || '~' || TB_NEXT_ACCR_DT(I) || '~' ||
            ICPKSS_TEST.G_ICTM_ACC.MATURITY_DATE);
        IF TB_NEXT_ACCR_DT(I) > ICPKSS_TEST.G_ICTM_ACC.MATURITY_DATE AND
           TB_LAST_ACCR_DT(I) < ICPKSS_TEST.G_ICTM_ACC.MATURITY_DATE THEN
          TB_NEXT_ACCR_DT(I) := ICPKSS_TEST.G_ICTM_ACC.MATURITY_DATE - 1;
          DBG('Next accrual date modified here as' || TB_NEXT_ACCR_DT(I));
        END IF;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 4;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('l_init_next_accr_dt') := TO_CHAR(L_INIT_NEXT_ACCR_DT,
                                                            'dd-mon-rrrr');
        L_TB_CLUSTER_DATA('l_init_last_accr_dt') := TO_CHAR(L_INIT_LAST_ACCR_DT,
                                                            'dd-mon-rrrr');
      
        ICPKS_TEST_CLUSTER.PR_ACCRUE(P_DT,
                                     I,
                                     TB_ICENT,
                                     
                                     L_FN_CALL_ID,
                                     L_TB_CLUSTER_DATA);
      END IF;
    
      IF L_INIT_NEXT_ACCR_DT = L_INIT_LAST_ACCR_DT THEN
        DBG('Entries History insert upd table init next accr dt and last accr dt are same ' ||
            L_INIT_NEXT_ACCR_DT);
        FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
          LAST_REC := NVL(TB_ICENT_HIST_UPD.COUNT, 0) + 1;
          DBG('Inside for update of entries_history_plsql table' ||
              LAST_REC || '~' || TB_ICENT(J).ACC || '~' || TB_ICENT(J).PROD || '~' || TB_ICENT(J)
              .FRM_NO || '~' || TB_ICENT(J).ENT_DT);
          IF G_ONLIQ_FLAG = 'Y' THEN
            L_ENTRY_TYPE := 'O';
          ELSE
            L_ENTRY_TYPE := 'I';
          END IF;
        
          DBG('cur run accr from history ' || L_LAST_CUR_ACCR);
          DBG('In adj case last rec is' || LAST_REC);
          TB_ICENT_HIST_UPD(LAST_REC).BRN := TB_ICENT(J).BRN;
          TB_ICENT_HIST_UPD(LAST_REC).ACC := TB_ICENT(J).ACC;
          TB_ICENT_HIST_UPD(LAST_REC).PROD := TB_ICENT(J).PROD;
          TB_ICENT_HIST_UPD(LAST_REC).FRM_NO := TB_ICENT(J).FRM_NO;
          TB_ICENT_HIST_UPD(LAST_REC).ENT_DT := TB_ICENT(J).ENT_DT;
          TB_ICENT_HIST_UPD(LAST_REC).AMT := NVL(TB_ICENT(J).AMT, 0);
          TB_ICENT_HIST_UPD(LAST_REC).ACCRUED_AMT := NVL(TB_ICENT(J)
                                                         .ACCRUED_AMT,
                                                         0);
          TB_ICENT_HIST_UPD(LAST_REC).AMT_TO_ACCRUE := NVL(TB_ICENT(J)
                                                           .AMT_TO_ACCRUE,
                                                           0);
          TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR := NVL(TB_ICENT(J)
                                                          .CUR_RUN_ACCR,
                                                          0);
          TB_ICENT_HIST_UPD(LAST_REC).RUN_DATE := GLOBAL.APPLICATION_DATE;
          TB_ICENT_HIST_UPD(LAST_REC).ACCR := 'Y';
          TB_ICENT_HIST_UPD(LAST_REC).LIQN := 'N';
          TB_ICENT_HIST_UPD(LAST_REC).ENTRY_TYPE := L_ENTRY_TYPE;
          TB_ICENT_HIST_UPD(LAST_REC).CCY := TB_CCY(I);
          TB_ICENT_HIST_UPD(LAST_REC).LCY_AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                     .LCY_AMT,
                                                     0);
          TB_ICENT_HIST_UPD(LAST_REC).LAST_CUR_RUN_ACCR := NVL(L_LAST_CUR_ACCR,
                                                               0);
          TB_ICENT_HIST_UPD(LAST_REC).ENTRY_PASSED := 'Y';
          DBG('After step1');
        
          DBG('Lcy amount incorrect issue: tb_icent_hist_upd(last_rec).lcy_amt = ' || TB_ICENT_HIST_UPD(LAST_REC)
              .LCY_AMT);
          IF TB_CCY(I) <> LCY THEN
            TB_ICENT_HIST_UPD(LAST_REC).LCY_AMT := 0;
            TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                               TB_CCY(I),
                                               LCY,
                                               NVL(TB_ICENT(J).AMT, 0),
                                               'Y',
                                               TB_ICENT_HIST_UPD(LAST_REC)
                                               .LCY_AMT,
                                               TBFRM(TB_ICENT(J).FRM_NO).XRATE,
                                               ERR_CODE) THEN
              DBG('Failed in amt conversion for' || TB_CCY(I) || LCY);
              RAISE EXP_CONV;
            END IF;
          ELSE
            TB_ICENT_HIST_UPD(LAST_REC).LCY_AMT := NVL(TB_ICENT(J).AMT, 0);
          END IF;
          DBG('After Lcy amount incorrect issue: tb_icent_hist_upd(last_rec).lcy_amt = ' || TB_ICENT_HIST_UPD(LAST_REC)
              .LCY_AMT);
        
          IF TB_CCY(I) <> LCY THEN
            TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR_LCY := 0;
            TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            TB_CCY(I),
                                            LCY,
                                            NVL(TB_ICENT(J).CUR_RUN_ACCR, 0),
                                            'Y',
                                            TB_ICENT_HIST_UPD(LAST_REC)
                                            .CUR_RUN_ACCR_LCY,
                                            TBFRM(TB_ICENT(J).FRM_NO).XRATE,
                                            ERR_CODE) THEN
              DBG('Failed in amt conversion for' || TB_CCY(I) || LCY);
            
              RAISE EXP_CONV;
            END IF;
          ELSE
            DBG('In else of diffrent ccy');
            TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR_LCY := NVL(TB_ICENT(J)
                                                                .CUR_RUN_ACCR,
                                                                0);
          END IF;
          DBG('just before asignment');
        
          TB_CURRUN_ACCR_LCY(J) := NVL(TB_ICENT_HIST_UPD(LAST_REC)
                                       .CUR_RUN_ACCR_LCY,
                                       0);
          DBG('After assigning');
        END LOOP;
      ELSE
        DBG('Init next accrual and last accrual are not same');
        LAST_REC := NVL(TB_ICENT_HIST_ACC.COUNT, 0) + 1;
        DBG('Entries History insert' || TB_ICENT.COUNT);
        FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
          DBG('after getting the last rec..' || LAST_REC);
          DBG('VALUES OF J --> ' || J);
          DBG('Inside for update of entries_history_plsql table' ||
              LAST_REC || '~' || TB_ICENT(J).ACC || '~' || TB_ICENT(J).PROD || '~' || TB_ICENT(J)
              .FRM_NO || '~' || TB_ICENT(J).ENT_DT);
          IF G_ONLIQ_FLAG = 'Y' THEN
            L_ENTRY_TYPE := 'O';
          ELSE
            L_ENTRY_TYPE := 'I';
          END IF;
          DBG('here next liq dt / p_dt / deposit ' || TB_NEXT_LIQ_DT(I) || '~' || P_DT || '~' ||
              TB_DEPOSIT(I));
          IF TB_NEXT_LIQ_DT(I) <> P_DT OR TB_DEPOSIT(I) = 'Y' OR
             TB_NEXT_LIQ_DT(I) < L_INIT_LAST_ACCR_DT OR
             TB_NEXT_LIQ_DT(I) IS NULL OR
             ICPKS_INTRADAY_NEW.G_IC_BKGRND_JOB = 1 THEN
            DBG('Going to update entries history table ');
            TB_ICENT_HIST_BRN(LAST_REC) := TB_ICENT(J).BRN;
            DBG('tb_icent_hist_brn: ' || TB_ICENT(J).BRN);
            TB_ICENT_HIST_ACC(LAST_REC) := TB_ICENT(J).ACC;
            DBG('tb_icent_hist_acc: ' || TB_ICENT(J).ACC);
            TB_ICENT_HIST_PROD(LAST_REC) := TB_ICENT(J).PROD;
            DBG('tb_icent_hist_prod: ' || TB_ICENT(J).PROD);
            TB_ICENT_HIST_FRM_NO(LAST_REC) := TB_ICENT(J).FRM_NO;
            DBG('tb_icent_hist_frm_no: ' || TB_ICENT(J).FRM_NO);
            TB_ICENT_HIST_ENT_DT(LAST_REC) := TB_ICENT(J).ENT_DT;
            DBG('tb_icent_hist_ent_dt: ' || TB_ICENT(J).ENT_DT);
            TB_ICENT_HIST_AMT(LAST_REC) := NVL(TB_ICENT(J).AMT, 0);
            DBG('tb_icent_hist_amt: ' || TB_ICENT(J).AMT);
            TB_ICENT_HIST_ACCRUED_AMT(LAST_REC) := NVL(TB_ICENT(J)
                                                       .ACCRUED_AMT,
                                                       0);
            DBG('tb_icent_hist_accrued_amt: ' || TB_ICENT(J).ACCRUED_AMT);
            TB_ICENT_HIST_AMT_TO_ACCRUE(LAST_REC) := NVL(TB_ICENT(J)
                                                         .AMT_TO_ACCRUE,
                                                         0);
            DBG('tb_icent_hist_amt_to_accrue: ' || TB_ICENT(J)
                .AMT_TO_ACCRUE);
            TB_ICENT_HIST_CUR_RUN_ACCR(LAST_REC) := NVL(TB_ICENT(J)
                                                        .CUR_RUN_ACCR,
                                                        0);
            DBG('tb_icent_hist_cur_run_accr: ' || TB_ICENT(J).CUR_RUN_ACCR);
            TB_ICENT_HIST_RUN_DATE(LAST_REC) := GLOBAL.APPLICATION_DATE;
            DBG('11111');
            TB_ICENT_HIST_ACCR(LAST_REC) := 'Y';
            DBG('22222');
            TB_ICENT_HIST_LIQN(LAST_REC) := 'N';
            DBG('333333');
            TB_ICENT_HIST_ENTRY_TYPE(LAST_REC) := L_ENTRY_TYPE;
            DBG('444444 entry type ' || L_ENTRY_TYPE);
            TB_ICENT_HIST_CCY(LAST_REC) := TB_CCY(I);
            DBG('555555555 CCY: ' || TB_CCY(I));
            TB_ICENT_HIST_LCY_AMT(LAST_REC) := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                   .LCY_AMT,
                                                   0);
            DBG('66666 Lcy amt: ' || TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT);
            TB_ICENT_HIST_LAST_CUR_ACCR(LAST_REC) := 0;
            DBG('after step1');
            TB_ICENT_HIST_ENTRY_PASSED(LAST_REC) := 'Y';
          
            IF TB_CCY(I) <> LCY THEN
              L_CURR_LCY := NULL;
              L_XRATE    := NULL;
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                 TB_CCY(I),
                                                 LCY,
                                                 NVL(TB_ICENT(J).AMT, 0),
                                                 'Y',
                                                 L_CURR_LCY,
                                                 L_XRATE,
                                                 ERR_CODE) THEN
                DBG('Failed in amt conversion for' || TB_CCY(I) || LCY);
                RAISE EXP_CONV;
              END IF;
              TB_ICENT_HIST_LCY_AMT(LAST_REC) := NVL(L_CURR_LCY, 0);
            ELSE
              TB_ICENT_HIST_LCY_AMT(LAST_REC) := NVL(TB_ICENT(J).AMT, 0);
            END IF;
            DBG('After Lcy amount incorrect issue: tb_icent_hist_lcy_amt(last_rec) = ' ||
                TB_ICENT_HIST_LCY_AMT(LAST_REC));
          
            IF TB_CCY(I) <> LCY THEN
              DBG('currencies are different' || TB_CCY(I) || '~' || LCY);
              DBG('formula number...' || TB_ICENT(J).FRM_NO);
              L_CURR_LCY := NULL;
              L_XRATE    := NULL;
              IF NOT
                  ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                              TB_CCY(I),
                                              LCY,
                                              NVL(TB_ICENT(J).CUR_RUN_ACCR, 0),
                                              'Y',
                                              L_CURR_LCY,
                                              
                                              L_XRATE,
                                              ERR_CODE) THEN
                DBG('Failed in amt conversion for this is a main cond' ||
                    TB_CCY(I) || LCY);
              
                RAISE EXP_CONV;
              ELSE
                TB_ICENT_HIST_CURACCR_LCY(LAST_REC) := NVL(L_CURR_LCY, 0);
              END IF;
            ELSE
              DBG('before the main table update');
              TB_ICENT_HIST_CURACCR_LCY(LAST_REC) := NVL(TB_ICENT(J)
                                                         .CUR_RUN_ACCR,
                                                         0);
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := L_XRATE;
            END IF;
            DBG('before doing rituals for pl/sql table');
            TB_CURRUN_ACCR_LCY(J) := NVL(TB_ICENT_HIST_CURACCR_LCY(LAST_REC),
                                         0);
            LAST_REC := LAST_REC + 1;
            DBG('After update of pl/sql table');
          
          ELSE
            DBG('CASA account - tb_next_liq_dt = P_Dt..Else case ..cur_run_accr lcy to be arrived');
            IF TB_CCY(I) <> LCY THEN
              DBG('currencies are different' || TB_CCY(I) || '~' || LCY);
              DBG('formula number...' || TB_ICENT(J).FRM_NO);
              L_CURR_LCY := NULL;
              L_XRATE    := NULL;
              IF NOT
                  ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                              TB_CCY(I),
                                              LCY,
                                              NVL(TB_ICENT(J).CUR_RUN_ACCR, 0),
                                              'Y',
                                              L_CURR_LCY,
                                              L_XRATE,
                                              ERR_CODE) THEN
                DBG('Failed in amt conversion for this is a main cond' ||
                    TB_CCY(I) || LCY);
                RAISE EXP_CONV;
              ELSE
                TB_CURRUN_ACCR_LCY(J) := NVL(L_CURR_LCY, 0);
              END IF;
            ELSE
              DBG('before the main table update');
              TB_CURRUN_ACCR_LCY(J) := NVL(TB_ICENT(J).CUR_RUN_ACCR, 0);
            
            END IF;
          
          END IF;
        END LOOP;
      END IF;
      DBG('Going to insert into history');
      TBFRM.DELETE;
      DBG('upd_acc of accr issaying bye here..bye bye good luck');
    EXCEPTION
    
      WHEN EXP_CONV THEN
        DBG(' ERROR WHILE CONVERTING');
        LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' ||
            'ERROR WHILE CONVERTING ' || SUBSTR(SQLERRM, 1, 1500),
            TB_ACC(I));
        RAISE;
      WHEN OTHERS THEN
        DBG('Some hand here in upd_acc of accrue jai hind ->' || SQLERRM);
        LOG_PROBLEM(I,
                    'B',
                    'upd_acc of accrue ' || SUBSTR(SQLERRM, 1, 1900));
        RAISE;
    END UPD_ACC;
  
  BEGIN
  
    DBG('In the main procedure of pr accrue');
  
    G_MOD_CURRUNACCR := FALSE;
    G_TB_AMT_NOT_ACCRUED.DELETE;
    G_POP_ACCR_ENTRY    := FALSE;
    L_ACCRUAL_TILL_DATE := TB_NEXT_ACCR_DT(I);
    G_ACCRUAL_REVERSAL  := 'N';
    SAVEPOINT SP_ACCR;
    DBG('Issued the save point..' || NVL(TB_PROD(I), '###'));
    FIND_KEY(TB_PROD(I), R_PR);
    DBG('after find key...no problems');
    IF R_PR.ACCR_FREQ = 'D' THEN
      DBG('Daily accrual');
      TBFRM_PAST_ADJ.DELETE;
      IF NVL(ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS, 'N') = 'N' THEN
        DBG('No accrual in holidays');
      
        IF NOT
            CEPKSS_DATE.FN_ISHOLIDAY('LCL', TB_BRN(I), P_DT, L_IS_HOLIDAY) THEN
          DBG('cepkss_date.fn_isholiday has returned false... but continuing');
          NULL;
        END IF;
      
        FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
          DBG('check point ic_accr_on_holidays is N. Acc is : ' || TB_ICENT(J).ACC);
          DBG('p_dt :' || P_DT);
          DBG('tb_next_liq_dt(i) :' || TB_NEXT_LIQ_DT(I));
          DBG('tb_icent(j).amt :' || TB_ICENT(J).AMT);
          DBG('l_prev_accrued_amt ' || L_PREV_ACCRUED_AMT);
          DBG('tb_icent(j).accrued_amt :' || TB_ICENT(J).ACCRUED_AMT);
          DBG('tb_icent(j).cur_run_accr :' || TB_ICENT(J).CUR_RUN_ACCR);
          DBG('tb_icent(j).amt_not_accrued :' || TB_ICENT(J)
              .AMT_NOT_ACCRUED);
          DBG('tb_icent(j).daily_amt :' || TB_ICENT(J).DAILY_AMT);
          DBG('tb_first_calc_dt(i) :' || TB_FIRST_CALC_DT(I));
          DBG('tb_last_calc_dt(i) :' || TB_LAST_CALC_DT(I));
          DBG('tb_last_accr_dt(i) :' || TB_LAST_ACCR_DT(I));
          DBG('tb_next_calc_dt(i) :' || TB_NEXT_CALC_DT(I));
          DBG('tb_next_accr_dt(i) :' || TB_NEXT_ACCR_DT(I));
          L_PREV_ACCRUED_AMT := NVL(TB_ICENT(J).ACCRUED_AMT, 0);
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            GLOBAL.PR_RESET_SKIP_KERNEL;
            L_FN_CALL_ID := 1;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            TBFRM(TB_ICENT(J).FRM_NO) := NULREC;
          
            L_TB_CLUSTER_DATA('j') := J;
            L_TB_CLUSTER_DATA('appdt') := TO_CHAR(APPDT, 'dd-mon-rrrr');
            L_TB_CLUSTER_DATA('lcy') := LCY;
            L_TB_CLUSTER_DATA('r_pr.accr_freq') := R_PR.ACCR_FREQ;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt') := TBFRM(TB_ICENT(J).FRM_NO).AMT;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                      .LCY_AMT;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                    .XRATE;
            L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue') := TB_ICENT(J)
                                                              .AMT_TO_ACCRUE;
          
            L_TB_CLUSTER_DATA('dyn_nwd') := DYN_NWD;
          
            L_TB_CLUSTER_DATA('l_compute_flag') := NULL;
            ICPKS_TEST_CLUSTER.PR_ACCRUE(P_DT,
                                         I,
                                         TB_ICENT,
                                         
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
          
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).amt') THEN
              TBFRM(TB_ICENT(J).FRM_NO).AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).lcy_amt') THEN
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).xrate') THEN
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tb_icent(j).amt_to_accrue') THEN
              TB_ICENT(J).AMT_TO_ACCRUE := L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue');
            END IF;
          
            IF L_TB_CLUSTER_DATA.EXISTS('dyn_nwd') THEN
              DYN_NWD := L_TB_CLUSTER_DATA('dyn_nwd');
            END IF;
          
            IF L_TB_CLUSTER_DATA.EXISTS('l_compute_flag') THEN
              L_COMPUTE_FLAG := L_TB_CLUSTER_DATA('l_compute_flag');
            END IF;
          
          END IF;
        
          IF NOT GLOBAL.G_SKIP_KERNEL THEN
          
            IF PKG_PROCESS_TILL <> 'S' THEN
              DBG('l_accrual_till_date before -' || L_ACCRUAL_TILL_DATE);
              L_ACCRUAL_TILL_DATE := LEAST((DYN_NWD - 1), TB_NEXT_LIQ_DT(I));
              DBG('l_accrual_till_date after -' || L_ACCRUAL_TILL_DATE);
            END IF;
          
            IF TB_ICENT(J).HAS_ACCR = 'Y' THEN
              IF TB_LAST_CALC_DT(I) = APPDT THEN
                AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0) -
                                   NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                DBG('details here are' || TB_ICENT(J).AMT_TO_ACCRUE || '~' || TB_ICENT(J)
                    .ACCRUED_AMT);
                TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE,
                                                 0);
              ELSIF P_DT = TB_NEXT_LIQ_DT(I) THEN
                AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT, 0) -
                                   NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT, 0);
              ELSIF P_DT = TB_LAST_CALC_DT(I) AND
                    NVL(L_COMPUTE_FLAG, 'N') = 'N' THEN
                AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0) -
                                   NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE,
                                                 0);
              ELSE
              
                IF PKG_PROCESS_TILL <> 'S' THEN
                  L_ACCRUAL_TILL_DATE := LEAST((DYN_NWD - 1),
                                               TB_NEXT_LIQ_DT(I));
                  IF L_ACCRUAL_TILL_DATE = TB_NEXT_LIQ_DT(I) THEN
                    AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT, 0) -
                                       NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                  
                  ELSE
                    AMT_NOT_ACCRUED := NVL(TB_ICENT(J).DAILY_AMT, 0) *
                                       (L_ACCRUAL_TILL_DATE -
                                        NVL(TB_LAST_ACCR_DT(I),
                                            TB_FIRST_CALC_DT(I)));
                  END IF;
                ELSE
                  IF DYN_NWD > PER_END THEN
                  
                    L_ACCRUAL_TILL_DATE := LEAST((DYN_NWD - 1),
                                                 TB_NEXT_LIQ_DT(I));
                    IF L_ACCRUAL_TILL_DATE = TB_NEXT_LIQ_DT(I) THEN
                      AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT, 0) -
                                         NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                    
                    ELSE
                      AMT_NOT_ACCRUED := NVL(TB_ICENT(J).DAILY_AMT, 0) *
                                         (L_ACCRUAL_TILL_DATE -
                                          NVL(TB_LAST_ACCR_DT(I),
                                              TB_FIRST_CALC_DT(I)));
                    END IF;
                  ELSE
                    AMT_NOT_ACCRUED     := NVL(TB_ICENT(J).DAILY_AMT, 0) *
                                           (P_DT -
                                            NVL(TB_LAST_ACCR_DT(I),
                                                TB_FIRST_CALC_DT(I)));
                    L_ACCRUAL_TILL_DATE := P_DT;
                  END IF;
                END IF;
              
                TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE,
                                                 0) +
                                             NVL(AMT_NOT_ACCRUED, 0);
              END IF;
            
            ELSE
              DBG('has_accr is N ... hence accrual amounts not to be populated..');
              AMT_NOT_ACCRUED := 0;
              TB_ICENT(J).AMT_TO_ACCRUE := 0;
            END IF;
          
            DBG('Amount not accrued to be ' || AMT_NOT_ACCRUED);
            DBG('l_prev_accrued_amt:' || L_PREV_ACCRUED_AMT);
            TB_ICENT(J).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT, 0) +
                                       NVL(AMT_NOT_ACCRUED, 0);
            DBG('Accrued amount is ' || TB_ICENT(J).ACCRUED_AMT);
            TBFRM(TB_ICENT(J).FRM_NO) := NULREC;
            IF TB_CCY(I) <> LCY THEN
              DBG('currencies are different' || TB_CCY(I) || '~' || LCY);
              TBFRM(TB_ICENT(J).FRM_NO).AMT := NVL(AMT_NOT_ACCRUED, 0);
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := 0;
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            
              IF NVL(AMT_NOT_ACCRUED, 0) <> 0 THEN
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                   TB_CCY(I),
                                                   LCY,
                                                   NVL(AMT_NOT_ACCRUED, 0),
                                                   'Y',
                                                   TBFRM(TB_ICENT(J).FRM_NO)
                                                   .LCY_AMT,
                                                   TBFRM(TB_ICENT(J).FRM_NO)
                                                   .XRATE,
                                                   ERR_CODE) THEN
                
                  EMSG;
                  RAISE EXP_CONV;
                END IF;
              ELSE
                TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := 0;
              END IF;
            
              DBG('here lcy amt is after conv' || TBFRM(TB_ICENT(J).FRM_NO)
                  .LCY_AMT);
            ELSE
              DBG('currencies are same so lcy amount is amt not accrued ' ||
                  TB_CCY(I) || '~' || LCY || '~' || AMT_NOT_ACCRUED);
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := NVL(AMT_NOT_ACCRUED, 0);
              TBFRM(TB_ICENT(J).FRM_NO).AMT := 0;
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            END IF;
          
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          DBG('Next calc due dt is ' || TB_ICENT(J).NEXT_CALC_DUE_DATE || '~' ||
              NEW_NEXT_CALC_DT);
          NEW_NEXT_CALC_DT := NVL(NEW_NEXT_CALC_DT,
                                  TB_ICENT(J).NEXT_CALC_DUE_DATE);
          DBG('new next calc dt is ' || NEW_NEXT_CALC_DT);
          TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_ICENT(J)
                                                        .ACQUIRED_AMT,
                                                        0);
        
          IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
            DBG('There are some past entries.. going to do tat ');
            DBG('tb_past_adj_icent(j).acquired_amt ' || TB_PAST_ADJ_ICENT(J)
                .ACQUIRED_AMT);
            DBG('tb_past_adj_icent(j).acquired_adj ' || TB_PAST_ADJ_ICENT(J)
                .ACQUIRED_ADJ);
            TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT(J)
                                                                   .ACQUIRED_AMT,
                                                                   0);
            TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                                   .ACQUIRED_ADJ,
                                                                   0);
          END IF;
        
          TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_ICENT(J)
                                                        .ACQUIRED_ADJ,
                                                        0);
          TBFRM(TB_ICENT(J).FRM_NO).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT,
                                                       0);
          DBG('The diff amounts are acqd amt/acqd adj/accr amt are ' || TB_ICENT(J)
              .ACQUIRED_AMT || '~' || TB_ICENT(J).ACQUIRED_ADJ || '~' ||
              L_PREV_ACCRUED_AMT);
          IF R_PR.ACCR_FREQ = 'D' THEN
            DBG('I am always here only for debug, accr freq is daily' ||
                TB_LAST_ACCR_DT(I) || '~' || TB_NEXT_ACCR_DT(I));
          
            IF TB_LAST_ACCR_DT(I) >= TB_NEXT_ACCR_DT(I) AND
               L_IS_HOLIDAY = 'W' THEN
            
              IF TB_ICENT(J).CUR_RUN_ACCR + NVL(AMT_NOT_ACCRUED, 0) = 0 AND
                  NVL(AMT_NOT_ACCRUED, 0) <> 0 THEN
                DBG('After intraday accrual, same day entries getting reversed (rate made 0) in next accrual..');
                DBG('1_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                    'Value - ' || AMT_NOT_ACCRUED);
                G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
              END IF;
            
              DBG('tb_icent(j).cur_run_accr=' || TB_ICENT(J).CUR_RUN_ACCR || '~' ||
                  AMT_NOT_ACCRUED);
              TB_ICENT(J).CUR_RUN_ACCR := TB_ICENT(J)
                                          .CUR_RUN_ACCR +
                                           NVL(AMT_NOT_ACCRUED, 0);
            
              IF (TB_ICENT(J)
                 .CUR_RUN_ACCR <> 0 AND NVL(AMT_NOT_ACCRUED, 0) = 0) AND
                 (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) =
                 NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
                DBG('1_Cur_run_accr is retained with prev value here...Will set g_mod_currunaccr to true');
                G_MOD_CURRUNACCR := TRUE;
              END IF;
              IF (TB_ICENT(J)
                 .CUR_RUN_ACCR <> 0 AND NVL(AMT_NOT_ACCRUED, 0) <> 0 AND TB_ICENT(J)
                 .CUR_RUN_ACCR <> NVL(AMT_NOT_ACCRUED, 0)) OR
                 (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) <>
                 NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
                DBG('2_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                    'Value - ' || AMT_NOT_ACCRUED);
                G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
              END IF;
            
            ELSE
            
              TB_ICENT(J).CUR_RUN_ACCR := NVL(AMT_NOT_ACCRUED, 0);
            END IF;
          
            IF NVL(AMT_NOT_ACCRUED, 0) <> 0 AND NOT G_POP_ACCR_ENTRY THEN
              DBG('Found an entry for accrual...will populate accr_entries table');
              G_POP_ACCR_ENTRY := TRUE;
            END IF;
          
            TB_ICENT(J).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT, 0) +
                                       NVL(AMT_NOT_ACCRUED, 0);
            TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0);
            DBG('amt_not_accrued ' || AMT_NOT_ACCRUED);
            DBG('tb_icent(j).cur_run_accr ' || TB_ICENT(J).CUR_RUN_ACCR);
            DBG('tb_icent(j).accrued_amt ' || TB_ICENT(J).ACCRUED_AMT);
            DBG('tb_icent(j).amt_to_accrue ' || TB_ICENT(J).AMT_TO_ACCRUE);
            IF NVL(TB_PROD_ACCR(I), 'N') <> 'Y' THEN
              DBG('Product accrual is YES');
              TB_ICENT(J).ACQUIRED_ADJ := NVL(TB_ICENT(J).ACQUIRED_AMT, 0);
              DBG('acqd adj ' || TB_ICENT(J).ACQUIRED_ADJ);
            
              IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
                TB_PAST_ADJ_ICENT(J).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                         .ACQUIRED_AMT,
                                                         0);
                DBG('tb_past_adj_icent(j).acquired_adj ### ' || TB_PAST_ADJ_ICENT(J)
                    .ACQUIRED_ADJ);
              END IF;
            
            END IF;
          END IF;
          DBG('Coming out of the loop');
        END LOOP;
        DBG('OUT of loop pr_accrue daily upd_acc');
      ELSE
      
        DBG('accrual is on holidays also');
        FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
          L_PREV_ACCRUED_AMT := NVL(TB_ICENT(J).ACCRUED_AMT, 0);
          DBG('check point :' || TB_ICENT(J).ACC);
          DBG('p_dt :' || P_DT);
          DBG('tb_icent(j).FRM_NO :' || TB_ICENT(J).FRM_NO);
          DBG('tb_next_liq_dt(i) :' || TB_NEXT_LIQ_DT(I));
          DBG('tb_icent(j).amt :' || TB_ICENT(J).AMT);
          DBG('l_prev_accrued_amt ' || L_PREV_ACCRUED_AMT);
          DBG('tb_icent(j).accrued_amt :' || TB_ICENT(J).ACCRUED_AMT);
          DBG('tb_icent(j).amt_to_accrue :' || TB_ICENT(J).amt_to_accrue);
          DBG('tb_icent(j).cur_run_accr :' || TB_ICENT(J).CUR_RUN_ACCR);
          DBG('tb_icent(j).amt_not_accrued :' || TB_ICENT(J)
              .AMT_NOT_ACCRUED);
          DBG('tb_icent(j).daily_amt :' || TB_ICENT(J).DAILY_AMT);
          DBG('tb_first_calc_dt(i) :' || TB_FIRST_CALC_DT(I));
          DBG('tb_last_calc_dt(i) :' || TB_LAST_CALC_DT(I));
          DBG('tb_last_accr_dt(i) :' || TB_LAST_ACCR_DT(I));
          DBG('tb_next_calc_dt(i) :' || TB_NEXT_CALC_DT(I));
          DBG('tb_next_accr_dt(i) :' || TB_NEXT_ACCR_DT(I));
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            GLOBAL.PR_RESET_SKIP_KERNEL;
            L_FN_CALL_ID := 2;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            TBFRM(TB_ICENT(J).FRM_NO) := NULREC;
            L_TB_CLUSTER_DATA('j') := J;
            L_TB_CLUSTER_DATA('appdt') := TO_CHAR(APPDT, 'dd-mon-rrrr');
            L_TB_CLUSTER_DATA('lcy') := LCY;
            L_TB_CLUSTER_DATA('r_pr.accr_freq') := R_PR.ACCR_FREQ;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt') := TBFRM(TB_ICENT(J).FRM_NO).AMT;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                      .LCY_AMT;
            L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                    .XRATE;
            L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue') := TB_ICENT(J)
                                                              .AMT_TO_ACCRUE;
          
            ICPKS_TEST_CLUSTER.PR_ACCRUE(P_DT,
                                         I,
                                         TB_ICENT,
                                         
                                         L_FN_CALL_ID,
                                         L_TB_CLUSTER_DATA);
          
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).amt') THEN
              TBFRM(TB_ICENT(J).FRM_NO).AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).lcy_amt') THEN
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).xrate') THEN
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate');
            END IF;
            IF L_TB_CLUSTER_DATA.EXISTS('tb_icent(j).amt_to_accrue') THEN
              TB_ICENT(J).AMT_TO_ACCRUE := L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue');
            END IF;
          END IF;
        
          IF NOT GLOBAL.G_SKIP_KERNEL THEN
          
            IF TB_ICENT(J).HAS_ACCR = 'Y' THEN
              IF P_DT = TB_NEXT_LIQ_DT(I) THEN
                DBG('APPLE1 ORANGE1 MANGO1');
              
                IF TB_ICENT(J)
                 .PROD IN
                    ('CLE1', 'SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') AND TB_ICENT(J)
                   .FRM_NO = '2' THEN
                  --Liquidation date
                  --sampath
                
                  AMT_NOT_ACCRUED := TB_ICENT(J).DAILY_AMT; --0; --NVL(TB_ICENT(J).AMT, 0);
                
                  DBG('AMT_NOT_ACCRUED1=' || AMT_NOT_ACCRUED);
                
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                
                  DBG('AMT_NOT_ACCRUED2=' || TB_ICENT(J).AMT_NOT_ACCRUED);
                
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).ACCRUED_AMT,
                                                   0); --or l_prev_accrued_amt but not --NVL(TB_ICENT(J).AMT, 0);
                
                  TB_ICENT(j).AMT := NVL(TB_ICENT(J).ACCRUED_AMT, 0); --or l_prev_accrued_amt
                
                  IF TB_LAST_ACCR_DT(I) = TB_LAST_CALC_DT(i) THEN
                  
                    DBG('DURING BOD');
                  
                    TB_ICENT(J).DAILY_AMT := 0;
                    TB_ICENT(J).AMT_NOT_ACCRUED := 0;
                    AMT_NOT_ACCRUED := 0;
                    TB_ICENT(J).CUR_RUN_ACCR := 0;
                  
                    --TB_ICENT(j).AMT := 0;
                    --TB_ICENT(j).amt_to_accrue := 0;
                  
                  END IF;
                
                ELSIF TB_ICENT(J).PROD IN ('PS01', 'PS02', 'PS03', 'PS04') AND TB_ICENT(J)
                      .FRM_NO = '2' THEN
                  --Liquidation date
                  --sampath
                
                  AMT_NOT_ACCRUED := TB_ICENT(J).DAILY_AMT; --0; --NVL(TB_ICENT(J).AMT, 0);
                
                  DBG('AMT_NOT_ACCRUED1=' || AMT_NOT_ACCRUED);
                
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                
                  DBG('AMT_NOT_ACCRUED2=' || TB_ICENT(J).AMT_NOT_ACCRUED);
                
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).ACCRUED_AMT,
                                                   0); --or l_prev_accrued_amt but not --NVL(TB_ICENT(J).AMT, 0);
                
                  TB_ICENT(j).AMT := NVL(TB_ICENT(J).ACCRUED_AMT, 0); --or l_prev_accrued_amt
                
                  IF TB_LAST_ACCR_DT(I) = TB_LAST_CALC_DT(i) THEN
                  
                    DBG('DURING BOD');
                  
                    TB_ICENT(J).DAILY_AMT := 0;
                    TB_ICENT(J).AMT_NOT_ACCRUED := 0;
                    AMT_NOT_ACCRUED := 0;
                    TB_ICENT(J).CUR_RUN_ACCR := 0;
                  
                    --TB_ICENT(j).AMT := 0;
                    --TB_ICENT(j).amt_to_accrue := 0;
                  
                  END IF;
                
                ELSE
                  --sampath
                
                  AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT, 0) -
                                     NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT, 0);
                
                END IF; --sampath
              
              ELSIF P_DT = TB_LAST_CALC_DT(I) THEN
                --topup day or normdal day
                DBG('APPLE2 ORANGE2 MANGO2');
              
                --IF TB_ICENT(J).PROD = 'CLE1' AND TB_ICENT(J).FRM_NO = '4' THEN
                --sampath
              
                --IF l_prev_accrued_amt > 0 THEN
                --sampath
              
                --  AMT_NOT_ACCRUED := l_prev_accrued_amt;---- +
                -- NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0); --0.03;--l_prev_accrued_amt;
              
                -- ELSE
                --sampath
              
                --   AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0) -
                --NVL(TB_ICENT(J).ACCRUED_AMT, 0);
              
                --  END IF;
              
                --  ELSE
                --sampath
              
                IF TB_ICENT(J)
                 .PROD IN
                    ('CLE1', 'SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') AND TB_ICENT(J)
                   .FRM_NO = '2' THEN
                  --sampath
                
                  AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0);
                
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).ACCRUED_AMT,
                                                   0) +
                                               NVL(AMT_NOT_ACCRUED, 0); --added line now
                
                ELSIF TB_ICENT(J).PROD IN ('PS01', 'PS02', 'PS03', 'PS04') AND TB_ICENT(J)
                      .FRM_NO = '2' THEN
                  --sampath
                
                  AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0);
                
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).ACCRUED_AMT,
                                                   0) +
                                               NVL(AMT_NOT_ACCRUED, 0); --added line now
                
                ELSE
                  --sampath
                
                  AMT_NOT_ACCRUED := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0) -
                                     NVL(TB_ICENT(J).ACCRUED_AMT, 0);
                
                  TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                
                  TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE,
                                                   0);
                END IF; --sampath
              
                --   END IF; --sampath
              
                DBG('AMT_NOT_ACCRUED=' || AMT_NOT_ACCRUED);
              
              ELSE
                DBG('APPLE3 ORANGE3 MANGO3'); --likely topup next day
              
                DBG('P_DT=' || P_DT);
                DBG('TB_LAST_ACCR_DT(I)=' || TB_LAST_ACCR_DT(I));
              
                AMT_NOT_ACCRUED := NVL(TB_ICENT(J).DAILY_AMT, 0) *
                                   (P_DT - TB_LAST_ACCR_DT(I));
              
                -- IF TB_ICENT(J).FRM_NO = '4' THEN --sampath
              
                --  TB_ICENT(J).AMT_NOT_ACCRUED := 0.04 *
                --                    (P_DT - TB_LAST_ACCR_DT(I));
              
                -- ELSE --sampath                   
                TB_ICENT(J).AMT_NOT_ACCRUED := NVL(AMT_NOT_ACCRUED, 0);
                -- END IF; --sampath
              
                TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE,
                                                 0) +
                                             NVL(TB_ICENT(J).AMT_NOT_ACCRUED,
                                                 0);
              END IF;
            
            ELSE
              --IF TB_ICENT(J)
              --   .PROD IN
              --    ('CLE1', 'SY01', 'SY02', 'GY01', 'GY02', 'RY01', 'RY02') AND TB_ICENT(J)
              --   .FRM_NO = '4' THEN
              --sampath
            
              -- TB_ICENT(J).AMT := TB_ICENT(2).ACCRUED_AMT * 6/100;
            
              -- ELSE --sampath   
              DBG('has_accr is N ... hence accrual amounts not to be populated..');
              AMT_NOT_ACCRUED := 0;
              TB_ICENT(J).AMT_NOT_ACCRUED := 0;
              TB_ICENT(J).AMT_TO_ACCRUE := 0;
              -- END IF; --sampath
            
            END IF;
          
            DBG('amt_not_accrued : ' || AMT_NOT_ACCRUED);
          
            TB_ICENT(J).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT, 0) +
                                       NVL(AMT_NOT_ACCRUED, 0);
          
            DBG('set tb_icent(j).accrued_amt ' || TB_ICENT(J).ACCRUED_AMT);
            DBG('set tb_icent(j).amt_to_accrue  ' || TB_ICENT(J)
                .AMT_TO_ACCRUE);
            TBFRM(TB_ICENT(J).FRM_NO) := NULREC;
            IF TB_CCY(I) <> LCY THEN
              DBG('Currencies are different ' || TB_CCY(I) || '~' || LCY);
              TBFRM(TB_ICENT(J).FRM_NO).AMT := NVL(AMT_NOT_ACCRUED, 0);
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := 0;
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
              IF NOT
                  ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                              TB_CCY(I),
                                              LCY,
                                              NVL(AMT_NOT_ACCRUED, 0),
                                              'Y',
                                              TBFRM(TB_ICENT(J).FRM_NO)
                                              .LCY_AMT,
                                              TBFRM(TB_ICENT(J).FRM_NO).XRATE,
                                              ERR_CODE) THEN
              
                EMSG;
                RAISE EXP_CONV;
              END IF;
              DBG('Lcy amt after conversion is ' || TBFRM(TB_ICENT(J).FRM_NO)
                  .LCY_AMT);
            ELSE
              DBG('CCYs are same ');
              TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := NVL(TB_ICENT(J)
                                                       .AMT_NOT_ACCRUED,
                                                       0);
              TBFRM(TB_ICENT(J).FRM_NO).AMT := 0;
              TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            END IF;
          
          ELSE
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          DBG('After calc amt new next calc dt and next calc due date are ' ||
              NEW_NEXT_CALC_DT || '~' || TB_ICENT(J).NEXT_CALC_DUE_DATE);
          NEW_NEXT_CALC_DT := NVL(NEW_NEXT_CALC_DT,
                                  TB_ICENT(J).NEXT_CALC_DUE_DATE);
          DBG('Here new next calc dt is ' || NEW_NEXT_CALC_DT);
          TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_ICENT(J)
                                                        .ACQUIRED_AMT,
                                                        0);
        
          IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
            DBG('There are some past entries.. going to do tat ');
            DBG('tb_past_adj_icent(j).acquired_amt ' || TB_PAST_ADJ_ICENT(J)
                .ACQUIRED_AMT);
            DBG('tb_past_adj_icent(j).acquired_adj ' || TB_PAST_ADJ_ICENT(J)
                .ACQUIRED_ADJ);
            TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT(J)
                                                                   .ACQUIRED_AMT,
                                                                   0);
            TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                                   .ACQUIRED_ADJ,
                                                                   0);
          END IF;
        
          TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_ICENT(J)
                                                        .ACQUIRED_ADJ,
                                                        0);
          TBFRM(TB_ICENT(J).FRM_NO).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT,
                                                       0);
          IF R_PR.ACCR_FREQ = 'D' THEN
            DBG('I am always here');
          
            IF TB_LAST_ACCR_DT(I) = TB_NEXT_ACCR_DT(I) THEN
            
              IF TB_ICENT(J).CUR_RUN_ACCR + NVL(AMT_NOT_ACCRUED, 0) = 0 AND
                  NVL(AMT_NOT_ACCRUED, 0) <> 0 THEN
                DBG('After intraday accrual, same day entries getting reversed (rate made 0) in next accrual..');
                DBG('3_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                    'Value - ' || AMT_NOT_ACCRUED);
                G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
              END IF;
            
              DBG('Already accrual happend earlier...must sum the cur_run_accr for this accrual entry');
              TB_ICENT(J).CUR_RUN_ACCR := TB_ICENT(J)
                                          .CUR_RUN_ACCR +
                                           NVL(AMT_NOT_ACCRUED, 0);
            
              IF (TB_ICENT(J)
                 .CUR_RUN_ACCR <> 0 AND NVL(AMT_NOT_ACCRUED, 0) = 0) AND
                 (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) =
                 NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
                DBG('2_Cur_run_accr is retained with prev value here...Will set g_mod_currunaccr to true');
                G_MOD_CURRUNACCR := TRUE;
              END IF;
              IF (TB_ICENT(J)
                 .CUR_RUN_ACCR <> 0 AND NVL(AMT_NOT_ACCRUED, 0) <> 0 AND TB_ICENT(J)
                 .CUR_RUN_ACCR <> NVL(AMT_NOT_ACCRUED, 0)) OR
                 (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) <>
                 NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
                DBG('4_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                    'Value - ' || AMT_NOT_ACCRUED);
                G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
              END IF;
            
            ELSE
              DBG('Intraday accrual did not happen earlier for this day..');
            
              TB_ICENT(J).CUR_RUN_ACCR := NVL(AMT_NOT_ACCRUED, 0);
            END IF;
            TB_ICENT(J).ACCRUED_AMT := NVL(L_PREV_ACCRUED_AMT, 0) +
                                       NVL(AMT_NOT_ACCRUED, 0);
            TB_ICENT(J).AMT_TO_ACCRUE := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0);
            IF NVL(TB_PROD_ACCR(I), 'N') <> 'Y' THEN
              TB_ICENT(J).ACQUIRED_ADJ := NVL(TB_ICENT(J).ACQUIRED_AMT, 0);
            
              IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
                TB_PAST_ADJ_ICENT(J).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                         .ACQUIRED_AMT,
                                                         0);
                DBG('tb_past_adj_icent(j).acquired_adj ## ' || TB_PAST_ADJ_ICENT(J)
                    .ACQUIRED_ADJ);
              END IF;
            
            END IF;
          END IF;
          DBG('amt_not_accrued : ' || AMT_NOT_ACCRUED);
          DBG('tb_icent(j).accrued_amt :' || TB_ICENT(J).ACCRUED_AMT);
          DBG('tb_icent(j).amt_to_accrue :' || TB_ICENT(J).AMT_TO_ACCRUE);
          DBG('tb_icent(j).cur_run_accr :' || TB_ICENT(J).CUR_RUN_ACCR);
        
          IF NVL(AMT_NOT_ACCRUED, 0) <> 0 AND NOT G_POP_ACCR_ENTRY THEN
            DBG('Found an entry for accrual...will populate accr_entries table');
            G_POP_ACCR_ENTRY := TRUE;
          END IF;
        
        END LOOP;
      END IF;
    ELSE
    
      DBG('In the else part boss this person dont require daily accrual');
      FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
        L_PREV_ACCRUED_AMT := NVL(TB_ICENT(J).ACCRUED_AMT, 0);
        AMT_NOT_ACCRUED    := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0) -
                              NVL(TB_ICENT(J).ACCRUED_AMT, 0);
      
        DBG('new_next_calc_dt~tb_icent(j).next_calc_due_date:' ||
            NEW_NEXT_CALC_DT || '~' || TB_ICENT(J).NEXT_CALC_DUE_DATE);
        NEW_NEXT_CALC_DT := NVL(NEW_NEXT_CALC_DT,
                                TB_ICENT(J).NEXT_CALC_DUE_DATE);
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID := 3;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('j') := J;
          L_TB_CLUSTER_DATA('appdt') := TO_CHAR(APPDT, 'dd-mon-rrrr');
          L_TB_CLUSTER_DATA('lcy') := LCY;
          L_TB_CLUSTER_DATA('r_pr.accr_freq') := R_PR.ACCR_FREQ;
        
          IF NOT TBFRM.EXISTS(TB_ICENT(J).FRM_NO) THEN
            TBFRM(TB_ICENT(J).FRM_NO) := NULREC;
          END IF;
        
          L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt') := TBFRM(TB_ICENT(J).FRM_NO).AMT;
          L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                    .LCY_AMT;
          L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate') := TBFRM(TB_ICENT(J).FRM_NO)
                                                                  .XRATE;
          L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue') := TB_ICENT(J)
                                                            .AMT_TO_ACCRUE;
        
          L_TB_CLUSTER_DATA('tb_icent(j).accrued_amt') := TB_ICENT(J)
                                                          .ACCRUED_AMT;
          L_TB_CLUSTER_DATA('tb_icent(j).amt') := TB_ICENT(J).AMT;
          L_TB_CLUSTER_DATA('amt_not_accrued') := AMT_NOT_ACCRUED;
          L_TB_CLUSTER_DATA('ccy') := TB_CCY(I);
          L_TB_CLUSTER_DATA('l_init_last_accr_dt') := TB_LAST_ACCR_DT(I);
          L_TB_CLUSTER_DATA('l_init_first_first_calc_dt') := TB_FIRST_FIRST_CALC_DATE(I);
          L_TB_CLUSTER_DATA('l_init_next_liq_dt') := TB_NEXT_LIQ_DT(I);
        
          ICPKS_TEST_CLUSTER.PR_ACCRUE(P_DT,
                                       I,
                                       TB_ICENT,
                                       
                                       L_FN_CALL_ID,
                                       L_TB_CLUSTER_DATA);
          IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).amt') THEN
            TBFRM(TB_ICENT(J).FRM_NO).AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).amt');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).lcy_amt') THEN
            TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).lcy_amt');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(j).frm_no).xrate') THEN
            TBFRM(TB_ICENT(J).FRM_NO).XRATE := L_TB_CLUSTER_DATA('tbfrm(tb_icent(j).frm_no).xrate');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('tb_icent(j).amt_to_accrue') THEN
            TB_ICENT(J).AMT_TO_ACCRUE := L_TB_CLUSTER_DATA('tb_icent(j).amt_to_accrue');
          END IF;
        
          IF L_TB_CLUSTER_DATA.EXISTS('amt_not_accrued') THEN
            AMT_NOT_ACCRUED := L_TB_CLUSTER_DATA('amt_not_accrued');
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('tb_icent(j).accrued_amt') THEN
            TB_ICENT(J).ACCRUED_AMT := L_TB_CLUSTER_DATA('tb_icent(j).accrued_amt');
          END IF;
        
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF TB_CCY(I) <> LCY THEN
            DBG('Ccys are different ');
            TBFRM(TB_ICENT(J).FRM_NO).AMT := NVL(AMT_NOT_ACCRUED, 0);
            TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := 0;
            TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            TB_CCY(I),
                                            LCY,
                                            NVL(AMT_NOT_ACCRUED, 0),
                                            'Y',
                                            TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT,
                                            TBFRM(TB_ICENT(J).FRM_NO).XRATE,
                                            ERR_CODE) THEN
              DBG('Utils failed to translate the amount..its not my problem' ||
                  ERR_CODE);
            
              EMSG;
              RAISE EXP_CONV;
            END IF;
          ELSE
            DBG('ccys are the same ');
            TBFRM(TB_ICENT(J).FRM_NO).LCY_AMT := NVL(AMT_NOT_ACCRUED, 0);
            TBFRM(TB_ICENT(J).FRM_NO).AMT := 0;
            TBFRM(TB_ICENT(J).FRM_NO).XRATE := NULL;
          END IF;
          TB_ICENT(J).ACCRUED_AMT := NVL(TB_ICENT(J).AMT_TO_ACCRUE, 0);
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_ICENT(J)
                                                      .ACQUIRED_AMT,
                                                      0);
      
        IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
          DBG('There are some past entries.. going to do tat ');
          DBG('tb_past_adj_icent(j).acquired_amt ' || TB_PAST_ADJ_ICENT(J)
              .ACQUIRED_AMT);
          DBG('tb_past_adj_icent(j).acquired_adj ' || TB_PAST_ADJ_ICENT(J)
              .ACQUIRED_ADJ);
          TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_AMT := NVL(TB_PAST_ADJ_ICENT(J)
                                                                 .ACQUIRED_AMT,
                                                                 0);
          TBFRM_PAST_ADJ(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                                 .ACQUIRED_ADJ,
                                                                 0);
        END IF;
      
        TBFRM(TB_ICENT(J).FRM_NO).ACQUIRED_ADJ := NVL(TB_ICENT(J)
                                                      .ACQUIRED_ADJ,
                                                      0);
      
        DBG('tb_last_accr_dt(i)~tb_next_accr_dt(i)=' || TB_LAST_ACCR_DT(I) || '~' ||
            TB_NEXT_ACCR_DT(I));
        DBG('tb_icent(j).cur_run_accr~amt_not_accrued' || TB_ICENT(J)
            .CUR_RUN_ACCR || '~' || AMT_NOT_ACCRUED);
        IF TB_LAST_ACCR_DT(I) >= TB_NEXT_ACCR_DT(I) THEN
        
          IF TB_ICENT(J).CUR_RUN_ACCR + NVL(AMT_NOT_ACCRUED, 0) = 0 AND
              NVL(AMT_NOT_ACCRUED, 0) <> 0 THEN
            DBG('After intraday accrual, same day entries getting reversed (rate made 0) in next accrual..');
            DBG('5_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                'Value - ' || AMT_NOT_ACCRUED);
            G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
          END IF;
        
          TB_ICENT(J).CUR_RUN_ACCR := TB_ICENT(J).CUR_RUN_ACCR +
                                       NVL(AMT_NOT_ACCRUED, 0);
          DBG('tb_icent(j).cur_run_accr - added - ' || TB_ICENT(J)
              .CUR_RUN_ACCR);
        
          IF (TB_ICENT(J).CUR_RUN_ACCR > 0 AND NVL(AMT_NOT_ACCRUED, 0) = 0) AND
             (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) =
             NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
            DBG('3_Cur_run_accr is retained with prev value here...Will set g_mod_currunaccr to true');
            G_MOD_CURRUNACCR := TRUE;
          END IF;
          IF (TB_ICENT(J).CUR_RUN_ACCR <> 0 AND NVL(AMT_NOT_ACCRUED, 0) <> 0 AND TB_ICENT(J)
             .CUR_RUN_ACCR <> NVL(AMT_NOT_ACCRUED, 0)) OR
             (NVL(TB_ICENT(J).ACQUIRED_AMT, 0) <>
             NVL(TB_ICENT(J).ACQUIRED_ADJ, 0)) THEN
            DBG('6_Store the amt_not_accrued in g_tb_amt_not_accrued index' || J ||
                'Value - ' || AMT_NOT_ACCRUED);
            G_TB_AMT_NOT_ACCRUED(J) := NVL(AMT_NOT_ACCRUED, 0);
          END IF;
        
        ELSE
          TB_ICENT(J).CUR_RUN_ACCR := NVL(AMT_NOT_ACCRUED, 0);
          DBG('tb_icent(j).cur_run_accr  ' || TB_ICENT(J).CUR_RUN_ACCR);
        END IF;
      
        IF NVL(TB_PROD_ACCR(I), 'N') <> 'Y' THEN
          TB_ICENT(J).ACQUIRED_ADJ := NVL(TB_ICENT(J).ACQUIRED_AMT, 0);
        
          IF (TB_PAST_ADJ_ICENT.EXISTS(J)) THEN
            TB_PAST_ADJ_ICENT(J).ACQUIRED_ADJ := NVL(TB_PAST_ADJ_ICENT(J)
                                                     .ACQUIRED_AMT,
                                                     0);
            DBG('tb_past_adj_icent(j).acquired_adj ' || TB_PAST_ADJ_ICENT(J)
                .ACQUIRED_ADJ);
          END IF;
        
        END IF;
        DBG('amt_not_accrued : ' || AMT_NOT_ACCRUED);
        DBG('tb_icent(j).accrued_amt :' || TB_ICENT(J).ACCRUED_AMT);
        DBG('tb_icent(j).acquired amt  :' || TB_ICENT(J).ACQUIRED_AMT);
        DBG('tb_icent(j).cur_run_accr :' || TB_ICENT(J).CUR_RUN_ACCR);
      
        IF NVL(AMT_NOT_ACCRUED, 0) <> 0 AND NOT G_POP_ACCR_ENTRY THEN
          DBG('Found an entry for accrual...will populate accr_entries table');
          G_POP_ACCR_ENTRY := TRUE;
        END IF;
      
      END LOOP;
    END IF;
    DBG('Going to call upd_acc for updating the acc and passing the entries');
    UPD_ACC;
    DBG('Great we are going of the pr_accrue' || TB_NEXT_ACCR_DT(I));
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Some problems in book and accrue..so jai hind' || SQLERRM);
      ERM                    := SQLERRM;
      ICPKSS_EOD.EOD_RETSTAT := 1;
      DBG('Rollback done here - till sp_accr');
      ROLLBACK TO SP_ACCR;
    
      LOG_PROBLEM(I, 'A', 'pr_accrue ' || SUBSTR(ERM, 1, 1900));
      RAISE;
  END PR_ACCRUE;

  PROCEDURE FIND_PROD_LOOKUP(P_PROD     VARCHAR2,
                             P_EVENT    VARCHAR2,
                             P_TBLOOKUP IN OUT ACPKS.TBL_LOOKUP) IS
    L_ST_INDEX   NUMBER;
    START_INDEX  NUMBER;
    END_INDEX    NUMBER;
    L_NU         NUMBER := 1;
    L_ACC_STATUS STTMS_CUST_ACCOUNT.ACC_STATUS%TYPE;
  BEGIN
  
    L_ACC_STATUS := NVL(G_STTM_CUSTACC.ACC_STATUS, 'NORM');
    PR_LOOKUP(P_PROD, P_EVENT, L_ACC_STATUS, P_TBLOOKUP);
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('in find_prod_lookup - sql err ' || SQLERRM);
      RAISE;
  END FIND_PROD_LOOKUP;

  PROCEDURE FIND_ACLOOKUP(P_PROD   VARCHAR2,
                          P_EVENT  VARCHAR2,
                          P_STATUS STTMS_CONTRACT_STATUSES.STATUS_CODE%TYPE) IS
    L_TBLOOKUP   ACPKS.TBL_LOOKUP;
    INDX         NUMBER;
    ERRMSG       VARCHAR2(2000);
    L_END_NUMBER NUMBER;
    IDX          VARCHAR2(50);
  BEGIN
  
    IND := CSPKSS_UTILS.FN_HASH40(P_PROD);
  
    IDX := P_PROD || '~' || P_EVENT || '~' || NVL(P_STATUS, 'NORM');
    IF PKG_LOOKUP_CACHE.EXISTS(IDX) THEN
      L_TBLOOKUP := PKG_LOOKUP_CACHE(IDX);
    ELSE
      IF NOT
          ACPKSS.ACFN_LOOKUP(P_PROD, P_EVENT, P_STATUS, L_TBLOOKUP, ERRMSG) THEN
        DBG('Lookup Failed');
        DBG('failed in acpks.aclookup');
      
      ELSE
        PKG_LOOKUP_CACHE(IDX) := L_TBLOOKUP;
      
      END IF;
    END IF;
  
    IF L_TBLOOKUP.COUNT > 0 THEN
    
      IF L_TBL_LOOKUP.COUNT = 0 THEN
        INDX := 1;
      ELSE
        INDX := L_TBL_LOOKUP.LAST + 1;
      END IF;
      DBG('indx = ' || TO_CHAR(INDX));
      IF P_EVENT = 'IACR' THEN
      
        L_PRODINDEX(IND).ACCR_START_INDEX := INDX;
      ELSE
        L_PRODINDEX(IND).LIQ_START_INDEX := INDX;
      END IF;
      FOR I IN L_TBLOOKUP.FIRST .. L_TBLOOKUP.LAST LOOP
        L_TBL_LOOKUP(INDX) := L_TBLOOKUP(I);
        INDX := INDX + 1;
      END LOOP;
    
      L_END_NUMBER := INDX;
      IF P_EVENT = 'IACR' THEN
      
        L_PRODINDEX(IND).ACCR_END_INDEX := L_TBL_LOOKUP.LAST;
      ELSE
      
        L_PRODINDEX(IND).LIQ_END_INDEX := L_TBL_LOOKUP.LAST;
      END IF;
    END IF;
  
    L_TBLOOKUP.DELETE;
  END FIND_ACLOOKUP;

  PROCEDURE PR_MISCAC(P_PROD IN VARCHAR2, P_BOOK_GL IN OUT VARCHAR2) IS
    L_ST_INDEX NUMBER;
    ERR_CODE   VARCHAR2(255);
  BEGIN
    DBG('Inside pr_miscAC');
    IF P_PROD <> PKG_LAST_PROD THEN
      L_ST_INDEX      := CSPKSS_UTILS.FN_HASH40(P_PROD);
      PKG_LAST_ACLIST := L_PRODINDEX(L_ST_INDEX).MISCACLIST;
      PKG_LAST_PROD   := P_PROD;
    END IF;
    P_BOOK_GL := PKG_LAST_ACLIST;
    DBG('Misc Dr/Cr accounts are ' || P_BOOK_GL);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in pr_miscAC');
      RAISE;
  END PR_MISCAC;

  PROCEDURE PR_LIQ_INT(P_DT     DATE,
                       I        NUMBER,
                       TB_ICENT IN OUT NOCOPY REC_ICENT) IS
    L_ACC_TYPE       STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    TBFRM            TBFRMTYP;
    R_PR             REC_PRINT;
    L_DEFAULT_MEDIA  STTMS_CUSTOMER.DEFAULT_MEDIA%TYPE;
    D                NUMBER(2);
    M                NUMBER(2);
    Y                NUMBER(2);
    N                NUMBER(2) := 0;
    FC_DT            DATE;
    L_NEXT_LIQ_DT    DATE;
    L_NEXT_SCHD_DATE DATE;
    CURGC            NUMBER;
  
    LAST_REC           NUMBER;
    ERR_CODE           VARCHAR2(2000);
    ERM                VARCHAR2(2000);
    L_XRATE            ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_INIT_LAST_LIQ_DT DATE;
    L_LAST_CUR_ACCR    ICTBS_ENTRIES.CUR_RUN_ACCR%TYPE := 0;
    L_CUR_LCY          ICTBS_ENTRIES.CUR_RUN_ACCR%TYPE := 0;
    EXP_CONV       EXCEPTION;
    UPD_ACC_FAILED EXCEPTION;
  
    L_END_DATE DATE;
  
    L_ACQUIRED VARCHAR2(1) := 'N';
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    PROCEDURE EMSG IS
      ERR_CODE VARCHAR2(2000);
      ERM      VARCHAR2(2000);
    BEGIN
      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_LIQ_ENT->');
    END EMSG;
  
    PROCEDURE UPD_ACC IS
      JP       NUMBER;
      MS_COUNT BINARY_INTEGER;
    
      L_LIQN_EOM        ICTMS_PR_INT.LIQN_EOM%TYPE;
      L_LIQN_START_DATE ICTMS_PR_INT.LIQN_START_DATE%TYPE;
      L_LIQ_TEMP_DATE   VARCHAR2(50);
      L_NLS_FORMAT      VARCHAR2(64);
    
      L_DEFR_FLG        ICTMS_PR_INT.DEFERRED_FLAG%TYPE;
      L_CALC_DAYS       ICTMS_PR_INT.CALC_DAYS%TYPE;
      L_TMP_NEXT_LIQ_DT DATE;
      L_TMP_DEFR_LIQ_DT DATE;
    
      L_TAXCAT_IND_TC_REQD STTMS_BRANCH.INDIVIDUAL_TAX_CERT_REQD%TYPE;
    
      L_IL_PRODUCT ICTMS_PR_INT.IL_PRODUCT%TYPE;
    
      L_NEXT_DATE DATE := NULL;
      CALL_FAIL EXCEPTION;
      IDX NUMBER;
    
      DAY               NUMBER := 0;
      MM                NUMBER := 0;
      YY                NUMBER := 0;
      L_BOOL            BOOLEAN;
      L_NEXT_LIQ_DT_TMP DATE;
    
    BEGIN
      DBG('Inside upd_acc call of liquidation');
      DBG('calls pr_entries_liq for passing entries for ' || P_DT || '~' || I || '~' ||
          TBFRM.COUNT);
    
      DBG('tb_acc --> ' || TB_ACC(I) || ' tb_defer_liq_dt --> ' ||
          TB_DEFER_LIQ_DT(I) || ' tb_next_liq_dt --> ' ||
          TB_NEXT_LIQ_DT(I));
    
      L_ACC_TYPE := G_ACC_TYPE;
      DBG('the acc type is ' || L_ACC_TYPE);
      FIND_KEY(TB_PROD(I), R_PR);
      DBG('I got the deferred_flag as --->' || R_PR.DEFERRED_FLAG);
    
      IF (NVL(TB_DEFER_LIQ_DT(I), TB_NEXT_LIQ_DT(I)) <= TB_NEXT_LIQ_DT(I)) OR
         (G_ONLIQ_FLAG = 'Y' AND NOT ICPKS_BOD.G_FROMBOD) THEN
      
        IF G_ONLIQ_FLAG = 'Y' AND NOT (ICPKS_BOD.G_FROMBOD) AND
           NOT (ICPKS_BOD.G_FROM_TD) AND NVL(R_PR.DEFERRED_FLAG, 'N') = 'Y'
          
           OR (NVL(R_PR.DEFERRED_FLAG, 'N') = 'Y' AND
           ICPKS_BOD.G_DONTCLOSETD = 'Y') THEN
        
          DBG('B4 upd acc call of pr_liq_defr');
          BEGIN
            IF G_ONLIQ_FLAG <> 'Y' THEN
            
              PKG_STOP_DEFR_POSTING := TRUE;
            
            END IF;
            ICPKSS_TEST.PR_LIQ_DEFR(TB_BRN(I), P_DT);
          
            IF NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('IC_NADJ_PADJ_TAGS_REQD'),
                   'N') <> 'Y' THEN
              IF TBFRM.COUNT > 0 THEN
              
                IDX := TBFRM.FIRST;
                WHILE IDX <= TBFRM.LAST LOOP
                  TBFRM(IDX).ACQUIRED_AMT := 0;
                  IDX := TBFRM.NEXT(IDX);
                END LOOP;
              
              END IF;
            END IF;
          
          EXCEPTION
          
            WHEN OTHERS THEN
              DBG('Came to the WO during call to pr_liq_defr ' || SQLERRM);
              RAISE CALL_FAIL;
          END;
          DBG('After upd acc call of pr_liq_defr');
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID      := 5;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        
          L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
          L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
          L_TB_CLUSTER_DATA('l_onliq_flag') := G_ONLIQ_FLAG;
          L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
          L_TB_CLUSTER_DATA('l_entry_passed') := NULL;
        
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          PR_ENTRIES_LIQ(P_DT, I, TBFRM);
          TBFRM.DELETE;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        DBG('After coming back from pr_entries_liq');
      END IF;
    
      D := NVL(R_PR.LIQN_DAYS, 0);
      M := NVL(R_PR.LIQN_MONTHS, 0);
      Y := NVL(R_PR.LIQN_YEARS, 0);
      N := NVL(R_PR.DAYS_BF_MTHEND, 0);
    
      L_LIQN_EOM        := R_PR.LIQN_EOM;
      L_LIQN_START_DATE := R_PR.LIQN_START_DATE;
      DBG('Liqun at eom --> ' || L_LIQN_EOM);
      DBG('Liquidation Start Date--> ' || TO_CHAR(L_LIQN_START_DATE));
    
      L_DEFR_FLG        := R_PR.DEFERRED_FLAG;
      L_CALC_DAYS       := R_PR.CALC_DAYS;
      L_TMP_NEXT_LIQ_DT := TB_NEXT_LIQ_DT(I);
      L_TMP_DEFR_LIQ_DT := TB_DEFER_LIQ_DT(I);
      DBG('Deferred flag --> ' || L_DEFR_FLG);
      DBG('Calc days --> ' || L_CALC_DAYS);
      DBG('Next liquidation date --> ' || L_TMP_NEXT_LIQ_DT);
      DBG('Defer liquidation date --> ' || L_TMP_DEFR_LIQ_DT);
    
      DBG('The liqn days/months/years for the prod ' || TB_PROD(I) ||
          ' are ' || D || M || Y || N);
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 25;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
        L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
        L_TB_CLUSTER_DATA('l_onliq_flag') := G_ONLIQ_FLAG;
        L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
        L_TB_CLUSTER_DATA('d') := D;
        L_TB_CLUSTER_DATA('m') := M;
        L_TB_CLUSTER_DATA('y') := Y;
        L_TB_CLUSTER_DATA('n') := N;
        L_TB_CLUSTER_DATA('l_liqn_start_date') := L_LIQN_START_DATE;
      
        L_TB_CLUSTER_DATA('l_entry_passed') := NULL;
      
        ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                      I,
                                      TB_ICENT,
                                      L_FN_CALL_ID,
                                      L_TB_CLUSTER_DATA);
      
        IF L_TB_CLUSTER_DATA.EXISTS('d') THEN
          D := L_TB_CLUSTER_DATA('d');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('m') THEN
          M := L_TB_CLUSTER_DATA('m');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('y') THEN
          Y := L_TB_CLUSTER_DATA('y');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('n') THEN
          N := L_TB_CLUSTER_DATA('n');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_liqn_start_date') THEN
          L_LIQN_START_DATE := L_TB_CLUSTER_DATA('l_liqn_start_date');
        END IF;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      IF NVL(G_ICTM_ACC.HAS_IS, 'N') = 'Y' THEN
        DBG('Interest statement is there so inserting into ictb_dly_msg_out for ' ||
            TB_ACC(I));
        BEGIN
          INSERT INTO ICTBS_DLY_MSG_OUT
            (BRN, ACC, CUST, FROM_DT, TO_DT)
          VALUES
            (G_STTM_CUSTACC.BRANCH_CODE,
             TB_ACC(I),
             G_STTM_CUSTACC.CUST_NO,
             NVL(TB_LAST_LIQ_DT(I) + 1, TB_FIRST_CALC_DT(I)),
             P_DT);
          MS_COUNT := NVL(TB_MS_BRN.COUNT, 0) + 1;
          TB_MS_BRN(MS_COUNT) := TB_BRN(I);
          TB_MS_REF_ACC(MS_COUNT) := TB_ACC(I);
          TB_MS_RECEIVER(MS_COUNT) := G_STTM_CUSTACC.CUST_NO;
          TB_MS_MEDIA(MS_COUNT) := L_DEFAULT_MEDIA;
          TB_MS_FRM_DT(MS_COUNT) := NVL(TB_LAST_LIQ_DT(I) + 1,
                                        TB_FIRST_CALC_DT(I));
          TB_MS_TO_DT(MS_COUNT) := P_DT;
          TB_MS_DEFAULT_MEDIA(MS_COUNT) := G_DEFAULT_MEDIA;
        
          IF NVL(G_STTM_CUSTACC.MUDARABAH_ACCOUNTS, 'N') = 'Y' THEN
            TB_MS_MODULE(MS_COUNT) := 'IP';
          ELSE
            TB_MS_MODULE(MS_COUNT) := 'IC';
          END IF;
        
        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            DBG('In dup val on index in ictb_dly_msg_out');
            NULL;
        END;
        DBG('Last date is ' || G_ICTM_ACC.LAST_IS_DATE || '~' || P_DT);
        IF NVL(G_ICTM_ACC.LAST_IS_DATE, TO_DATE(1, 'J')) < P_DT THEN
          DBG('Last interest statement is less than p_dt ' || P_DT);
          JP := NVL(TB_ICTMACC_UPD_ACC.COUNT, 0) + 1;
          TB_ICTMACC_UPD_ACC(JP) := G_ICTM_ACC.ACC;
          TB_ICTMACC_UPD_BRN(JP) := G_ICTM_ACC.BRN;
          TB_ICTMACC_UPD_ISDT(JP) := G_ICTM_ACC.LAST_IS_DATE;
        END IF;
      
        IF G_ONLIQ_FLAG = 'Y' THEN
          PR_MSTB_INSERT;
        END IF;
      
      END IF;
      DBG('Going to get the first calc dt' || TB_FIRST_CALC_DT(I) || '~' ||
          'opdt is ' || '~' || P_DT);
      IF TB_FIRST_CALC_DT(I) <= P_DT THEN
        IF TB_INC_MTH(I) = 'Y' AND D = 0 AND M + Y <> 0 THEN
          DBG('In if');
          FC_DT := ADD_MONTHS(TB_NEXT_SCHD_LIQ_DT(I) + N,
                              FLOOR(MONTHS_BETWEEN(TB_NEXT_LIQ_DT(I),
                                                   TB_NEXT_SCHD_LIQ_DT(I)))) + 1 - N;
        ELSE
          DBG('In else');
          FC_DT := TB_NEXT_LIQ_DT(I) + 1;
        END IF;
      ELSE
        DBG('In else case');
        FC_DT := TB_FIRST_CALC_DT(I);
      END IF;
      DBG('Final first calc date comes out as' || FC_DT);
      IF D = 0 AND M = 0 AND Y = 0 THEN
        DBG(' I am here with my brain all ZEROS');
        L_NEXT_LIQ_DT    := NULL;
        L_NEXT_SCHD_DATE := NULL;
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 23;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        
          L_TB_CLUSTER_DATA('l_acc_type') := L_ACC_TYPE;
          L_TB_CLUSTER_DATA('g_ictm_acc.maturity_date') := G_ICTM_ACC.MATURITY_DATE;
          L_TB_CLUSTER_DATA('g_ictm_acc.next_maturity_date') := G_ICTM_ACC.NEXT_MATURITY_DATE;
        
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        
          IF L_TB_CLUSTER_DATA.EXISTS('l_next_liq_dt') THEN
            L_NEXT_LIQ_DT := L_TB_CLUSTER_DATA('l_next_liq_dt');
          END IF;
        
          IF L_TB_CLUSTER_DATA.EXISTS('l_next_schd_date') THEN
            L_NEXT_SCHD_DATE := L_TB_CLUSTER_DATA('l_next_schd_date');
          END IF;
        
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF L_ACC_TYPE = 'Y' THEN
            DBG('This is a deposit mat date is ' ||
                G_ICTM_ACC.MATURITY_DATE);
            IF G_ICTM_ACC.MATURITY_DATE > P_DT THEN
              L_NEXT_LIQ_DT    := G_ICTM_ACC.MATURITY_DATE - 1;
              L_NEXT_SCHD_DATE := G_ICTM_ACC.MATURITY_DATE - 1;
            END IF;
            DBG('For deposits the next_liq dt is ' || L_NEXT_LIQ_DT);
          END IF;
        END IF;
        TB_NEXT_LIQ_DT(I) := L_NEXT_LIQ_DT;
        TB_NEXT_SCHD_LIQ_DT(I) := L_NEXT_SCHD_DATE;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID      := 8;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          TB_FIRST_CALC_DT(I) := P_DT + 1;
          TB_LAST_LIQ_DT(I) := P_DT;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        TB_INC_MTH(I) := 'N';
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := TRUNC(P_DT) + 1;
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            TB_NEXT_CALC_DT(I) := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
          END IF;
        END IF;
        TB_LAST_ACCR_DT(I) := TB_LAST_ACCR_DT(I);
        TB_NEXT_ACCR_DT(I) := TB_NEXT_ACCR_DT(I);
        TB_NEXT_SCHD_ACCR_DT(I) := TB_NEXT_SCHD_ACCR_DT(I);
      ELSIF TB_NEXT_LIQ_DT(I) != TB_NEXT_SCHD_LIQ_DT(I) THEN
        DBG('I am here with liq dt and next schd liq dt not same');
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID      := 9;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF R_PR.IL_PRODUCT = 'Y' THEN
            SELECT CLOSURE_DATE
              INTO L_END_DATE
              FROM ILTBS_SYS_ACCOUNT
            
             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
               AND SYSTEM_ACCOUNT = TB_ACC(I);
            IF L_END_DATE IS NOT NULL THEN
              TB_NEXT_LIQ_DT(I) := P_DT;
            ELSE
              TB_NEXT_LIQ_DT(I) := TB_NEXT_SCHD_LIQ_DT(I);
            END IF;
          
          ELSE
            TB_NEXT_LIQ_DT(I) := TB_NEXT_SCHD_LIQ_DT(I);
          
          END IF;
        
          TB_FIRST_CALC_DT(I) := FC_DT;
          TB_LAST_LIQ_DT(I) := P_DT;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        TB_INC_MTH(I) := 'N';
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := TRUNC(P_DT) + 1;
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            TB_NEXT_CALC_DT(I) := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
          END IF;
        END IF;
        TB_LAST_ACCR_DT(I) := TB_LAST_ACCR_DT(I);
        TB_NEXT_ACCR_DT(I) := LEAST(TB_NEXT_ACCR_DT(I),
                                    TB_NEXT_SCHD_LIQ_DT(I));
        TB_NEXT_SCHD_ACCR_DT(I) := TB_NEXT_SCHD_ACCR_DT(I);
      ELSE
        DBG('For any other case of liquidation' || '~N' || N || 'Y' || Y || 'd' || D || 'M' || M);
      
        L_NEXT_LIQ_DT := ADD_MONTHS(TB_NEXT_SCHD_LIQ_DT(I) + N, 12 * Y + M) + D - N;
      
        IF R_PR.LIQN_START_ACCOUNT = 'Y' AND
           G_ICTM_ACC.INT_START_DATE = LAST_DAY(G_ICTM_ACC.INT_START_DATE) THEN
          L_NEXT_LIQ_DT := ADD_MONTHS(TB_NEXT_SCHD_LIQ_DT(I) + 1 + N,
                                      12 * Y + M) + D - N - 1;
        END IF;
      
        IF R_PR.LIQN_START_ACCOUNT = 'Y' AND
           G_ICTM_ACC.INT_START_DATE <> LAST_DAY(G_ICTM_ACC.INT_START_DATE) AND
           ((D = 0) AND (Y > 0 OR M > 0)) AND
           TO_NUMBER(TO_CHAR(G_ICTM_ACC.INT_START_DATE, 'DD')) <> 1
        
         THEN
          L_NEXT_LIQ_DT_TMP := L_NEXT_LIQ_DT;
          DAY               := TO_NUMBER(TO_CHAR(G_ICTM_ACC.INT_START_DATE,
                                                 'DD')) - 1;
        
          IF DAY = 0 THEN
            DAY := 1;
          END IF;
        
          MM     := TO_NUMBER(TO_CHAR(L_NEXT_LIQ_DT, 'MM'));
          YY     := TO_NUMBER(TO_CHAR(L_NEXT_LIQ_DT, 'RRRR'));
          L_BOOL := CEPKS_DATE.FN_FORMDATE(DAY, MM, YY, L_NEXT_LIQ_DT);
        
          IF L_NEXT_LIQ_DT IS NULL OR
             L_NEXT_LIQ_DT = LAST_DAY(L_NEXT_LIQ_DT) THEN
            L_NEXT_LIQ_DT := L_NEXT_LIQ_DT_TMP - 1;
          END IF;
        END IF;
      
        DBG('here next liq dt is ' || L_NEXT_LIQ_DT);
      
        GLOBAL.PR_RESET_SKIP_KERNEL;
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          L_FN_CALL_ID      := 24;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        
          L_TB_CLUSTER_DATA('l_acc_type') := L_ACC_TYPE;
          L_TB_CLUSTER_DATA('g_ictm_acc.maturity_date') := G_ICTM_ACC.MATURITY_DATE;
          L_TB_CLUSTER_DATA('g_ictm_acc.next_maturity_date') := G_ICTM_ACC.NEXT_MATURITY_DATE;
          L_TB_CLUSTER_DATA('l_next_liq_dt') := L_NEXT_LIQ_DT;
        
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        
          IF L_TB_CLUSTER_DATA.EXISTS('l_next_liq_dt') THEN
            L_NEXT_LIQ_DT := L_TB_CLUSTER_DATA('l_next_liq_dt');
          END IF;
        
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          IF L_ACC_TYPE = 'Y' THEN
            DBG('inside acc type deposit!!!!' || '~' ||
                G_ICTM_ACC.MATURITY_DATE || '~' || L_NEXT_LIQ_DT);
          
            IF G_ICTM_ACC.MATURITY_DATE > P_DT AND
               L_NEXT_LIQ_DT > G_ICTM_ACC.MATURITY_DATE - 1 THEN
              L_NEXT_LIQ_DT    := G_ICTM_ACC.MATURITY_DATE - 1;
              L_NEXT_SCHD_DATE := G_ICTM_ACC.MATURITY_DATE - 1;
            END IF;
          
            DBG('For deposit next liq dt is ' || L_NEXT_LIQ_DT);
          END IF;
        END IF;
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID      := 10;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          TB_NEXT_LIQ_DT(I) := L_NEXT_LIQ_DT;
          TB_NEXT_SCHD_LIQ_DT(I) := L_NEXT_LIQ_DT;
          TB_FIRST_CALC_DT(I) := FC_DT;
          TB_LAST_LIQ_DT(I) := P_DT;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
        TB_INC_MTH(I) := 'N';
      
        IF R_PR.TAX_CATEGORY IS NULL OR
           CSPKS_FEATURE.FN_INSTALLED('IC_SKIP_RECALC_LIQN') THEN
          TB_NEXT_CALC_DT(I) := TRUNC(P_DT) + 1;
        ELSE
          IF R_PR.DEFERRED_FLAG = 'Y' THEN
            L_NEXT_DATE := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
            TB_NEXT_CALC_DT(I) := LEAST(L_NEXT_DATE,
                                        NVL(TB_DEFER_LIQ_DT(I), L_NEXT_DATE));
          ELSE
            TB_NEXT_CALC_DT(I) := LEAST(TRUNC(P_DT) + 1, L_NEXT_LIQ_DT);
          END IF;
        END IF;
        TB_LAST_ACCR_DT(I) := TB_LAST_ACCR_DT(I);
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID      := 11;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          TB_LAST_SCHD_LIQ_DT(I) := P_DT;
          TB_NEXT_ACCR_DT(I) := LEAST(TB_NEXT_ACCR_DT(I),
                                      TB_NEXT_SCHD_LIQ_DT(I));
          TB_NEXT_SCHD_ACCR_DT(I) := TB_NEXT_SCHD_ACCR_DT(I);
        
          IF NVL(R_PR.DEFERRED_FLAG, 'N') <> 'Y' THEN
            TB_DEFER_LIQ_DT(I) := TB_NEXT_LIQ_DT(I);
            DBG('Have set the deeferrd liquidation date also.... ' ||
                TB_DEFER_LIQ_DT(I));
          END IF;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
      END IF;
    
      IF R_PR.TAX_CATEGORY IS NOT NULL THEN
        IF NOT CVPKSS_UTILS.FN_GET_BRANCH_RECORD(GLOBAL.CURRENT_BRANCH,
                                                 G_BRANCH_REC) THEN
          DBG('Could not get the branch_details ');
        END IF;
        IF NVL(G_BRANCH_REC.INDIVIDUAL_TAX_CERT_REQD, 'N') = 'Y' THEN
          SELECT INDIVIDUAL_TAX_CERT_REQD
            INTO L_TAXCAT_IND_TC_REQD
            FROM TATMS_TAX_CATEGORY
           WHERE TAX_CATEGORY = R_PR.TAX_CATEGORY;
        
          SELECT CUSTOMER_NAME1, INDIVIDUAL_TAX_CERT_REQD
            INTO G_CUSTOMER_NAME1, G_CUST_IND_TC_REQD
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = G_STTM_CUSTACC.CUST_NO;
        
          IF NVL(L_TAXCAT_IND_TC_REQD, 'N') = 'Y' AND
             NVL(G_CUST_IND_TC_REQD, 'N') = 'Y' THEN
          
            INSERT INTO MSTBS_MSG_HANDOFF
              (REFERENCE_NO,
               MODULE,
               MSG_TYPE,
               RECEIVER,
               NAME,
               SERIAL_NO,
               HOLD_STATUS,
               DIRECTIVE_STATUS,
               PROCESSED_FLAG,
               BRANCH,
               MEDIA,
               FROM_DATE)
            VALUES
              (G_STTM_CUSTACC.CUST_AC_NO,
               'TA',
               'IND_TAX_CERT',
               G_STTM_CUSTACC.CUST_NO,
               G_CUSTOMER_NAME1,
               1,
               'N',
               'B',
               'N',
               GLOBAL.CURRENT_BRANCH,
               'MAIL',
               P_DT);
          END IF;
        END IF;
      END IF;
    
      DBG('Liquidation upd is done  and got next liq dt/first calc dt /last liq dt as' ||
          TB_NEXT_LIQ_DT(I) || '~' || FC_DT || '~' || P_DT);
    EXCEPTION
      WHEN CALL_FAIL THEN
        DBG('Call to pr_liq_defr failed ' || SQLERRM);
        RAISE;
      WHEN OTHERS THEN
        DBG('In when others of upd_acc of pr_liq_int ' || SQLERRM);
        LOG_PROBLEM(I,
                    'B',
                    'upd_acc of pr_liq_int ' || SUBSTR(SQLERRM, 1, 1900));
        RAISE;
    END UPD_ACC;
  
  BEGIN
  
    SAVEPOINT SP_LIQ_INT;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                    I,
                                    TB_ICENT,
                                    L_FN_CALL_ID,
                                    L_TB_CLUSTER_DATA);
    END IF;
  
    DBG('before taking count');
    DBG('inside liquidation..of interest..' || TB_ICENT.COUNT);
    FOR K IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('IDX') := K;
        L_TB_CLUSTER_DATA('FRM_NO') := TB_ICENT(K).FRM_NO;
        ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                      I,
                                      TB_ICENT,
                                      L_FN_CALL_ID,
                                      L_TB_CLUSTER_DATA);
      END IF;
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 13;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                      I,
                                      TB_ICENT,
                                      L_FN_CALL_ID,
                                      L_TB_CLUSTER_DATA);
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
      DBG('just entred liquidation loop last liq date is :' ||
          TB_LAST_LIQ_DT(I));
      L_INIT_LAST_LIQ_DT := TB_LAST_LIQ_DT(I);
      DBG('inside the loop of entries in liq int acquired amount is' || TB_ICENT(K)
          .ACQUIRED_AMT);
      DBG('and the amount is coming as' || TB_ICENT(K).AMT);
      TBFRM(TB_ICENT(K).FRM_NO) := NULREC;
      TBFRM(TB_ICENT(K).FRM_NO).ACQUIRED_AMT := TB_ICENT(K).ACQUIRED_AMT;
    
      IF ICPKSS_BOOK.FN_BOOK_ACC_TYPE(TB_ICENT(K).PROD) = 'I' THEN
      
        L_BOOK_ACC := G_ICTM_ACC.BOOK_ACC;
        L_BOOK_BRN := G_ICTM_ACC.BOOK_BRN;
        L_BOOK_CCY := G_ICTM_ACC.BOOK_CCY;
        DBG('l_book_ccy for prod I ' || L_BOOK_CCY || '~' || L_BOOK_ACC);
      ELSE
        L_BOOK_ACC := G_ICTM_ACC.CHARGE_BOOK_ACC;
        L_BOOK_BRN := G_ICTM_ACC.CHARGE_BOOK_BRN;
        L_BOOK_CCY := G_ICTM_ACC.CHARGE_BOOK_CCY;
        DBG('l_book_ccy for prod else ' || L_BOOK_CCY || '~' || L_BOOK_ACC);
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        GLOBAL.PR_RESET_SKIP_KERNEL;
        L_FN_CALL_ID := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('k') := K;
        L_TB_CLUSTER_DATA('l_book_acc') := L_BOOK_ACC;
        L_TB_CLUSTER_DATA('l_book_brn') := L_BOOK_BRN;
        L_TB_CLUSTER_DATA('g_sttm_custacc.cust_ac_no') := G_STTM_CUSTACC.CUST_AC_NO;
        L_TB_CLUSTER_DATA('l_book_ccy') := L_BOOK_CCY;
        L_TB_CLUSTER_DATA('g_sttm_custacc.ccy') := G_STTM_CUSTACC.CCY;
        L_TB_CLUSTER_DATA('lcy') := LCY;
      
        IF NOT TBFRM.EXISTS(TB_ICENT(K).FRM_NO) THEN
          TBFRM(TB_ICENT(K).FRM_NO) := NULREC;
        END IF;
      
        L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).amt') := TBFRM(TB_ICENT(K).FRM_NO).AMT;
        L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).lcy_amt') := TBFRM(TB_ICENT(K).FRM_NO)
                                                                  .LCY_AMT;
        L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).book_amt') := TBFRM(TB_ICENT(K).FRM_NO)
                                                                   .BOOK_AMT;
        L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).xrate') := TBFRM(TB_ICENT(K).FRM_NO)
                                                                .XRATE;
      
        ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                      I,
                                      TB_ICENT,
                                      L_FN_CALL_ID,
                                      L_TB_CLUSTER_DATA);
      
        IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(k).frm_no).amt') THEN
          TBFRM(TB_ICENT(K).FRM_NO).AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).amt');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(k).frm_no).lcy_amt') THEN
          TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).lcy_amt');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(k).frm_no).book_amt') THEN
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_AMT := L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).book_amt');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('tbfrm(tb_icent(k).frm_no).xrate') THEN
          TBFRM(TB_ICENT(K).FRM_NO).XRATE := L_TB_CLUSTER_DATA('tbfrm(tb_icent(k).frm_no).xrate');
        END IF;
      
        IF L_TB_CLUSTER_DATA.EXISTS('l_book_acc') THEN
          L_BOOK_ACC := L_TB_CLUSTER_DATA('l_book_acc');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_book_brn') THEN
          L_BOOK_BRN := L_TB_CLUSTER_DATA('l_book_brn');
        END IF;
        IF L_TB_CLUSTER_DATA.EXISTS('l_book_ccy') THEN
          L_BOOK_CCY := L_TB_CLUSTER_DATA('l_book_ccy');
        END IF;
      
      END IF;
    
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF (L_BOOK_ACC <> G_STTM_CUSTACC.CUST_AC_NO AND
           L_BOOK_CCY <> G_STTM_CUSTACC.CCY) THEN
          DBG('here inside the first if in pr_liq_int book_ccy not equal to acc ccy so converting');
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_AMT := NULL;
          TBFRM(TB_ICENT(K).FRM_NO).XRATE := NULL;
        
          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID := 14;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_TB_CLUSTER_DATA('PROD') := TB_ICENT(K).PROD;
          
            L_TB_CLUSTER_DATA('FRM_NO') := TB_ICENT(K).FRM_NO;
            L_TB_CLUSTER_DATA('L_BOOK_CCY') := L_BOOK_CCY;
            L_TB_CLUSTER_DATA('L_BOOK_BRN') := L_BOOK_BRN;
            L_TB_CLUSTER_DATA('LCY') := LCY;
            L_TB_CLUSTER_DATA('XRATE') := TBFRM(TB_ICENT(K).FRM_NO).XRATE;
            L_TB_CLUSTER_DATA('BOOK_AMT') := TBFRM(TB_ICENT(K).FRM_NO) .
                                              BOOK_AMT;
          
            ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                          I,
                                          TB_ICENT,
                                          L_FN_CALL_ID,
                                          L_TB_CLUSTER_DATA);
          
            IF L_TB_CLUSTER_DATA.EXISTS('XRATE') THEN
              TBFRM(TB_ICENT(K).FRM_NO).XRATE := L_TB_CLUSTER_DATA('XRATE');
            END IF;
          
          END IF;
          GLOBAL.PR_RESET_SKIP_KERNEL;
        
          IF NOT
              ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                          G_STTM_CUSTACC.CCY,
                                          L_BOOK_CCY,
                                          NVL(TB_ICENT(K).AMT, 0),
                                          'Y',
                                          TBFRM(TB_ICENT(K).FRM_NO).BOOK_AMT,
                                          TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                          ERR_CODE) THEN
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID      := 15;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                            I,
                                            TB_ICENT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            EMSG;
            RAISE EXP_CONV;
          END IF;
          DBG('here amt and book amt are ' || TB_ICENT(K).AMT || '~' || TBFRM(TB_ICENT(K).FRM_NO)
              .BOOK_AMT);
        
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_ACQUIRED_AMT := NULL;
          TBFRM(TB_ICENT(K).FRM_NO).XRATE := NULL;
        
          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID := 16;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            L_TB_CLUSTER_DATA('PROD') := TB_ICENT(K).PROD;
            ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                          I,
                                          TB_ICENT,
                                          L_FN_CALL_ID,
                                          L_TB_CLUSTER_DATA);
          END IF;
          GLOBAL.PR_RESET_SKIP_KERNEL;
        
          IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                             G_STTM_CUSTACC.CCY,
                                             L_BOOK_CCY,
                                             NVL(TB_ICENT(K).ACQUIRED_AMT, 0),
                                             'Y',
                                             TBFRM(TB_ICENT(K).FRM_NO)
                                             .BOOK_ACQUIRED_AMT,
                                             TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                             ERR_CODE) THEN
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID      := 17;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                            I,
                                            TB_ICENT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            EMSG;
            RAISE EXP_CONV;
          END IF;
          DBG('here amt and book amt are ' || TB_ICENT(K).ACQUIRED_AMT || '~' || TBFRM(TB_ICENT(K).FRM_NO)
              .BOOK_ACQUIRED_AMT);
        
          GLOBAL.PR_RESET_SKIP_KERNEL;
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
            L_FN_CALL_ID      := 18;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
            ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                          I,
                                          TB_ICENT,
                                          L_FN_CALL_ID,
                                          L_TB_CLUSTER_DATA);
          END IF;
          GLOBAL.PR_RESET_SKIP_KERNEL;
        
        ELSE
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_AMT := TB_ICENT(K).AMT;
          DBG('ccys are same so book amt is ' || TBFRM(TB_ICENT(K).FRM_NO)
              .BOOK_AMT);
        
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_ACQUIRED_AMT := TB_ICENT(K)
                                                         .ACQUIRED_AMT;
          DBG('ccys are same so book amt is ' || TBFRM(TB_ICENT(K).FRM_NO)
              .BOOK_ACQUIRED_AMT);
        
        END IF;
      
        IF L_BOOK_CCY <> LCY THEN
          DBG('book ccy not lcy amount is :' || TB_ICENT(K).AMT);
          TBFRM(TB_ICENT(K).FRM_NO).AMT := TB_ICENT(K).AMT;
        
          DBG('book ccy not lcy acquired amount is :' || TB_ICENT(K)
              .ACQUIRED_AMT);
          TBFRM(TB_ICENT(K).FRM_NO).ACQUIRED_AMT := TB_ICENT(K).ACQUIRED_AMT;
        
          IF TB_CCY(I) = LCY THEN
            DBG('Book ccy is not LCY But the interest calculation account is');
            TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT := TB_ICENT(K).AMT;
            TBFRM(TB_ICENT(K).FRM_NO).LCY_ACQUIRED_AMT := TB_ICENT(K)
                                                          .ACQUIRED_AMT;
          ELSE
            DBG('here tb_ccy <> lcy ');
            TBFRM(TB_ICENT(K).FRM_NO).XRATE := NULL;
            TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT := NULL;
            TBFRM(TB_ICENT(K).FRM_NO).LCY_ACQUIRED_AMT := NULL;
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 19;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('PROD') := TB_ICENT(K).PROD;
            
              L_TB_CLUSTER_DATA('FRM_NO') := TB_ICENT(K).FRM_NO;
              L_TB_CLUSTER_DATA('L_BOOK_CCY') := L_BOOK_CCY;
              L_TB_CLUSTER_DATA('L_BOOK_BRN') := L_BOOK_BRN;
              L_TB_CLUSTER_DATA('LCY') := LCY;
              L_TB_CLUSTER_DATA('XRATE') := TBFRM(TB_ICENT(K).FRM_NO).XRATE;
              L_TB_CLUSTER_DATA('BOOK_AMT') := TBFRM(TB_ICENT(K).FRM_NO) .
                                                BOOK_AMT;
            
              ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                            I,
                                            TB_ICENT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
            
              IF L_TB_CLUSTER_DATA.EXISTS('XRATE') THEN
                TBFRM(TB_ICENT(K).FRM_NO).XRATE := L_TB_CLUSTER_DATA('XRATE');
              END IF;
            
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            L_BOOK_CCY,
                                            LCY,
                                            NVL(TBFRM(TB_ICENT(K).FRM_NO)
                                                .BOOK_AMT,
                                                0),
                                            'Y',
                                            TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT,
                                            TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                            ERR_CODE) THEN
            
              GLOBAL.PR_RESET_SKIP_KERNEL;
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID      := 20;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                              I,
                                              TB_ICENT,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA);
              END IF;
            
              EMSG;
              RAISE EXP_CONV;
            END IF;
          
            GLOBAL.PR_RESET_SKIP_KERNEL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
              L_FN_CALL_ID := 21;
              L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              L_TB_CLUSTER_DATA('PROD') := TB_ICENT(K).PROD;
              ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                            I,
                                            TB_ICENT,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA);
            END IF;
            GLOBAL.PR_RESET_SKIP_KERNEL;
          
            IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                               L_BOOK_CCY,
                                               LCY,
                                               NVL(TBFRM(TB_ICENT(K).FRM_NO)
                                                   .BOOK_ACQUIRED_AMT,
                                                   0),
                                               'Y',
                                               TBFRM(TB_ICENT(K).FRM_NO)
                                               .LCY_ACQUIRED_AMT,
                                               TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                               ERR_CODE) THEN
            
              GLOBAL.PR_RESET_SKIP_KERNEL;
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                L_FN_CALL_ID      := 22;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                              I,
                                              TB_ICENT,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA);
              END IF;
              GLOBAL.PR_RESET_SKIP_KERNEL;
            
              EMSG;
              RAISE EXP_CONV;
            END IF;
          
          END IF;
        ELSE
          DBG('book ccy equal to lcy so lcy amt and  amt are ' || TBFRM(TB_ICENT(K).FRM_NO)
              .BOOK_AMT || '~' || TB_ICENT(K).AMT);
          TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT := TBFRM(TB_ICENT(K).FRM_NO)
                                               .BOOK_AMT;
          TBFRM(TB_ICENT(K).FRM_NO).AMT := TB_ICENT(K).AMT;
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_AMT := NULL;
        
          TBFRM(TB_ICENT(K).FRM_NO).LCY_ACQUIRED_AMT := TBFRM(TB_ICENT(K).FRM_NO)
                                                        .BOOK_ACQUIRED_AMT;
          TBFRM(TB_ICENT(K).FRM_NO).ACQUIRED_AMT := TB_ICENT(K).ACQUIRED_AMT;
          TBFRM(TB_ICENT(K).FRM_NO).BOOK_ACQUIRED_AMT := NULL;
        
        END IF;
      
      ELSE
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
      TB_ICENT(K).LCY_AMT := NVL(TBFRM(TB_ICENT(K).FRM_NO).LCY_AMT, 0);
      TB_ICENT(K).ACQUIRED_LCY := NVL(TBFRM(TB_ICENT(K).FRM_NO)
                                      .LCY_ACQUIRED_AMT,
                                      0);
    
      DBG('amounts from tb_frm are lcy amt /amt /book_amt ' || TBFRM(TB_ICENT(K).FRM_NO)
          .LCY_AMT || '~' || TBFRM(TB_ICENT(K).FRM_NO).AMT || '~' || TBFRM(TB_ICENT(K).FRM_NO)
          .BOOK_AMT);
      BEGIN
        IF (TB_LAST_ACCR_DT(I) = TB_NEXT_ACCR_DT(I)) THEN
          DBG('last accr date and next acr dt is same');
        
          LAST_REC := NVL(TB_ICENT_HIST_UPD.COUNT, 0) + 1;
          IF G_ONLIQ_FLAG = 'Y' THEN
            TB_ICENT_HIST_UPD(LAST_REC).ENTRY_TYPE := 'O';
          ELSE
            TB_ICENT_HIST_UPD(LAST_REC).ENTRY_TYPE := 'I';
          END IF;
          DBG('Entries History update as today is next_accr dt and last accr dt');
          TB_ICENT_HIST_UPD(LAST_REC).BRN := TB_ICENT(K).BRN;
          TB_ICENT_HIST_UPD(LAST_REC).ACC := TB_ICENT(K).ACC;
          TB_ICENT_HIST_UPD(LAST_REC).PROD := TB_ICENT(K).PROD;
          TB_ICENT_HIST_UPD(LAST_REC).FRM_NO := TB_ICENT(K).FRM_NO;
          TB_ICENT_HIST_UPD(LAST_REC).ENT_DT := TB_ICENT(K).ENT_DT;
          TB_ICENT_HIST_UPD(LAST_REC).AMT := TB_ICENT(K).AMT;
          TB_ICENT_HIST_UPD(LAST_REC).ACCRUED_AMT := TB_ICENT(K).ACCRUED_AMT;
          TB_ICENT_HIST_UPD(LAST_REC).AMT_TO_ACCRUE := TB_ICENT(K)
                                                       .AMT_TO_ACCRUE;
          TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR := NVL(TB_ICENT(K)
                                                          .CUR_RUN_ACCR,
                                                          0);
          TB_ICENT_HIST_UPD(LAST_REC).RUN_DATE := GLOBAL.APPLICATION_DATE;
          TB_ICENT_HIST_UPD(LAST_REC).ACCR := 'Y';
          TB_ICENT_HIST_UPD(LAST_REC).LIQN := 'N';
          TB_ICENT_HIST_UPD(LAST_REC).CCY := TB_CCY(I);
          TB_ICENT_HIST_UPD(LAST_REC).LCY_AMT := TBFRM(TB_ICENT(K).FRM_NO)
                                                 .LCY_AMT;
          TB_ICENT_HIST_UPD(LAST_REC).LAST_CUR_RUN_ACCR := L_LAST_CUR_ACCR;
          TB_ICENT_HIST_UPD(LAST_REC).ENTRY_PASSED := 'Y';
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          
            L_FN_CALL_ID      := 6;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          
            L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
            L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
            L_TB_CLUSTER_DATA('l_onliq_flag') := G_ONLIQ_FLAG;
            L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
            L_TB_CLUSTER_DATA('l_entry_passed') := NULL;
          
            ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                          I,
                                          TB_ICENT,
                                          L_FN_CALL_ID,
                                          L_TB_CLUSTER_DATA);
          
            TB_ICENT_HIST_UPD(LAST_REC).ENTRY_PASSED := NVL(L_TB_CLUSTER_DATA('l_entry_passed'),
                                                            'Y');
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          DBG('acc ' || TB_ICENT(K).ACC);
          DBG('accrued_amt ' || TB_ICENT(K).ACCRUED_AMT);
          DBG('amt_to_accrue ' || TB_ICENT(K).AMT_TO_ACCRUE);
          DBG('cur_run_accr ' || TB_ICENT(K).CUR_RUN_ACCR);
          DBG('last_cur_run_accr ' || L_LAST_CUR_ACCR);
          IF TB_CCY(I) <> LCY THEN
            DBG('tb ccy and lcy are different');
            TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR_LCY := NULL;
            TBFRM(TB_ICENT(K).FRM_NO).XRATE := NULL;
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            TB_CCY(I),
                                            LCY,
                                            NVL(TB_ICENT(K).CUR_RUN_ACCR, 0) -
                                            NVL(L_LAST_CUR_ACCR, 0),
                                            'Y',
                                            TB_ICENT_HIST_UPD(LAST_REC)
                                            .CUR_RUN_ACCR_LCY,
                                            TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                            ERR_CODE) THEN
              DBG('Failed in amt conversion for' || TB_CCY(I) || LCY);
            
              RAISE EXP_CONV;
            END IF;
          ELSE
            DBG('This is a local currency account');
            TB_ICENT_HIST_UPD(LAST_REC).CUR_RUN_ACCR_LCY := NVL(TB_ICENT(K)
                                                                .CUR_RUN_ACCR,
                                                                0);
          END IF;
          DBG('After assigning the main fellow...');
          TB_CURRUN_ACCR_LCY(K) := TB_ICENT_HIST_UPD(LAST_REC)
                                   .CUR_RUN_ACCR_LCY;
        ELSIF L_INIT_LAST_LIQ_DT = P_DT THEN
          DBG('This is a adjustment case l_init_last_liq_dt and p_dt are same ' ||
              L_INIT_LAST_LIQ_DT || '~' || P_DT);
          LAST_REC := NVL(TB_ICENT_HIST_ADJ.COUNT, 0) + 1;
          DBG('Updating the table icent_hist_adj ' || LAST_REC || '~' || TB_ICENT(K).ACC || '~' || TB_ICENT(K).PROD || '~' || TB_ICENT(K)
              .ENT_DT || '~' || TB_ICENT(K).AMT);
          TB_ICENT_HIST_ADJ(LAST_REC).BRN := TB_ICENT(K).BRN;
          TB_ICENT_HIST_ADJ(LAST_REC).ACC := TB_ICENT(K).ACC;
          TB_ICENT_HIST_ADJ(LAST_REC).PROD := TB_ICENT(K).PROD;
          TB_ICENT_HIST_ADJ(LAST_REC).FRM_NO := TB_ICENT(K).FRM_NO;
          TB_ICENT_HIST_ADJ(LAST_REC).ENT_DT := TB_ICENT(K).ENT_DT;
          TB_ICENT_HIST_ADJ(LAST_REC).AMT := TB_ICENT(K).AMT;
          TB_ICENT_HIST_ADJ(LAST_REC).CCY := TB_CCY(I);
          TB_ICENT_HIST_ADJ(LAST_REC).LCY_AMT := TBFRM(TB_ICENT(K).FRM_NO)
                                                 .LCY_AMT;
          IF TB_CCY(I) <> LCY THEN
            TB_ICENT_HIST_ADJ(LAST_REC).CUR_RUN_ACCR_LCY := NULL;
            TBFRM(TB_ICENT(K).FRM_NO).XRATE := NULL;
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            TB_CCY(I),
                                            LCY,
                                            NVL(TB_ICENT(K).CUR_RUN_ACCR, 0),
                                            'Y',
                                            TB_ICENT_HIST_ADJ(LAST_REC)
                                            .CUR_RUN_ACCR_LCY,
                                            TBFRM(TB_ICENT(K).FRM_NO).XRATE,
                                            ERR_CODE) THEN
              DBG('Failed in amt conversion for' || TB_CCY(I) || LCY);
            
              RAISE EXP_CONV;
            END IF;
          ELSE
            DBG('In adj..this seems OK');
            TB_ICENT_HIST_ADJ(LAST_REC).CUR_RUN_ACCR_LCY := NVL(TB_ICENT(K)
                                                                .CUR_RUN_ACCR,
                                                                0);
          END IF;
          DBG('After this seems OK');
          TB_CURRUN_ACCR_LCY(K) := NVL(TB_ICENT_HIST_ADJ(LAST_REC)
                                       .CUR_RUN_ACCR_LCY,
                                       0);
        ELSE
          DBG('In the else condition of last accr dt and init accr dt');
          LAST_REC := NVL(TB_ICENT_HIST_ACC.COUNT, 0) + 1;
          DBG('Just insert normal case this record is going to be :' ||
              LAST_REC);
          IF TB_LAST_ACCR_DT(I) = P_DT THEN
            TB_ICENT_HIST_ACCR(LAST_REC) := 'Y';
          ELSE
            TB_ICENT_HIST_ACCR(LAST_REC) := 'N';
          END IF;
          DBG('Entries History insert');
          TB_ICENT_HIST_BRN(LAST_REC) := TB_ICENT(K).BRN;
          TB_ICENT_HIST_ACC(LAST_REC) := TB_ICENT(K).ACC;
          TB_ICENT_HIST_PROD(LAST_REC) := TB_ICENT(K).PROD;
          TB_ICENT_HIST_FRM_NO(LAST_REC) := TB_ICENT(K).FRM_NO;
          TB_ICENT_HIST_ENT_DT(LAST_REC) := TB_ICENT(K).ENT_DT;
          TB_ICENT_HIST_AMT(LAST_REC) := NVL(TB_ICENT(K).AMT, 0);
          TB_ICENT_HIST_ACCRUED_AMT(LAST_REC) := NVL(TB_ICENT(K).ACCRUED_AMT,
                                                     0);
          TB_ICENT_HIST_AMT_TO_ACCRUE(LAST_REC) := NVL(TB_ICENT(K)
                                                       .AMT_TO_ACCRUE,
                                                       0);
          TB_ICENT_HIST_CUR_RUN_ACCR(LAST_REC) := NVL(TB_ICENT(K)
                                                      .CUR_RUN_ACCR,
                                                      0);
          TB_ICENT_HIST_RUN_DATE(LAST_REC) := GLOBAL.APPLICATION_DATE;
          TB_ICENT_HIST_LIQN(LAST_REC) := 'Y';
          TB_ICENT_HIST_ENTRY_TYPE(LAST_REC) := 'I';
          TB_ICENT_HIST_CCY(LAST_REC) := TB_CCY(I);
          TB_ICENT_HIST_LCY_AMT(LAST_REC) := NVL(TBFRM(TB_ICENT(K).FRM_NO)
                                                 .LCY_AMT,
                                                 0);
          TB_ICENT_HIST_LAST_CUR_ACCR(LAST_REC) := 0;
        
          IF NVL(TB_DEFER_LIQ_DT(I), TB_NEXT_LIQ_DT(I)) <= P_DT THEN
            TB_ICENT_HIST_ENTRY_PASSED(LAST_REC) := 'Y';
          ELSE
            TB_ICENT_HIST_ENTRY_PASSED(LAST_REC) := 'N';
          END IF;
        
          IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
             (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          
            L_FN_CALL_ID      := 7;
            L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          
            L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
            L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
            L_TB_CLUSTER_DATA('l_amt') := NULL;
            L_TB_CLUSTER_DATA('l_onliq_flag') := G_ONLIQ_FLAG;
            L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
            L_TB_CLUSTER_DATA('l_entry_passed') := NULL;
          
            L_TB_CLUSTER_DATA('k') := K;
          
            ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                          I,
                                          TB_ICENT,
                                          L_FN_CALL_ID,
                                          L_TB_CLUSTER_DATA);
          
            TB_ICENT_HIST_ENTRY_PASSED(LAST_REC) := NVL(L_TB_CLUSTER_DATA('l_entry_passed'),
                                                        TB_ICENT_HIST_ENTRY_PASSED(LAST_REC));
            GLOBAL.PR_RESET_SKIP_KERNEL;
          END IF;
        
          DBG('aaa tb_icent_hist_upd(last_rec).acc:= ' || TB_ICENT(K).ACC);
          DBG('aaa tb_icent_hist_upd(last_rec).accrued_amt:= ' || TB_ICENT(K)
              .ACCRUED_AMT);
          DBG('aaa tb_icent_hist_upd(last_rec).amt_to_accrue:= ' || TB_ICENT(K)
              .AMT_TO_ACCRUE);
          DBG('aaa tb_icent_hist_upd(last_rec).cur_run_accr:= ' || TB_ICENT(K)
              .CUR_RUN_ACCR);
          DBG('aaa tb_icent_hist_upd(last_rec).last_cur_run_accr:= ' ||
              L_LAST_CUR_ACCR);
          IF TB_CCY(I) <> LCY THEN
            DBG('currencies are different while populating the ent hist' ||
                TB_CCY(I) || '~' || LCY);
            L_CUR_LCY := NULL;
            L_XRATE   := NULL;
            IF NOT
                ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                            TB_CCY(I),
                                            LCY,
                                            NVL(TB_ICENT(K).CUR_RUN_ACCR, 0),
                                            'Y',
                                            L_CUR_LCY,
                                            L_XRATE,
                                            ERR_CODE) THEN
              DBG('Failed in amt conversion for this is a main cond' ||
                  TB_CCY(I) || LCY);
            
              TB_ICENT_HIST_CURACCR_LCY(LAST_REC) := 0;
              RAISE EXP_CONV;
            ELSE
              DBG('Now i will update the table');
              TB_ICENT_HIST_CURACCR_LCY(LAST_REC) := NVL(L_CUR_LCY, 0);
            END IF;
          ELSE
            DBG('Here before prod level accrual update');
            TB_ICENT_HIST_CURACCR_LCY(LAST_REC) := NVL(TB_ICENT(K)
                                                       .CUR_RUN_ACCR,
                                                       0);
            DBG('Here after prod level accrual update');
          END IF;
          DBG('Before final assgnment');
          TB_CURRUN_ACCR_LCY(K) := NVL(TB_ICENT_HIST_CURACCR_LCY(LAST_REC),
                                       0);
        END IF;
        IF TB_ICENT(K).ACQUIRED_AMT <> 0 THEN
          DBG('here acquired amt is not 0 ' || TB_ICENT(K).ACQUIRED_AMT);
          LAST_REC := TB_ICENT_HIST_ADJ.COUNT;
          DBG('Going to update icent_hist_adj table after getting the record from ictb_adj_interest');
          FOR IFLEX IN (SELECT /*+ IC_FAST_ADJ */
                         A.*
                          FROM ICTBS_ADJ_INTEREST A
                         WHERE BRN = TB_BRN(I)
                           AND ACC = TB_ACC(I)
                           AND PROD = TB_PROD(I)
                           AND FRM_NO = TB_ICENT(K).FRM_NO) LOOP
            DBG('acquired amount is not ZERO' || TB_ICENT(K).ACQUIRED_AMT);
            LAST_REC := LAST_REC + 1;
            TB_ICENT_HIST_ADJ(LAST_REC).BRN := TB_BRN(I);
            TB_ICENT_HIST_ADJ(LAST_REC).ACC := TB_ACC(I);
            TB_ICENT_HIST_ADJ(LAST_REC).PROD := TB_PROD(I);
            TB_ICENT_HIST_ADJ(LAST_REC).FRM_NO := IFLEX.FRM_NO;
            TB_ICENT_HIST_ADJ(LAST_REC).ENT_DT := IFLEX.ENT_DT;
            TB_ICENT_HIST_ADJ(LAST_REC).AMT := NVL(IFLEX.AMT, 0);
            TB_ICENT_HIST_ADJ(LAST_REC).CCY := TB_CCY(I);
            TB_ICENT_HIST_ADJ(LAST_REC).LCY_AMT := NVL(IFLEX.LCY_AMT, 0);
          END LOOP;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when others of nside begin in liq ent ' || SQLERRM);
      END;
      DBG('Once out  of hist tables');
      IF NVL(PKG_LIQ_NETTING, 'N') = 'N' THEN
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
          GLOBAL.PR_RESET_SKIP_KERNEL;
          L_FN_CALL_ID := 12;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('k') := K;
          ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                        I,
                                        TB_ICENT,
                                        L_FN_CALL_ID,
                                        L_TB_CLUSTER_DATA);
        END IF;
      
        IF NOT GLOBAL.G_SKIP_KERNEL THEN
        
          DBG('Liqd netting is N so updating all the amts to 0');
          TB_ICENT(K).AMT := 0;
          TB_ICENT(K).ACCRUED_AMT := 0;
          TB_ICENT(K).AMT_TO_ACCRUE := 0;
          TB_ICENT(K).CUR_RUN_ACCR := 0;
          TB_ICENT(K).DAILY_AMT := 0;
          TB_ICENT(K).ACQUIRED_AMT := 0;
          TB_ICENT(K).ACQUIRED_ADJ := 0;
        
          IF (TB_PAST_ADJ_ICENT.EXISTS(K)) THEN
            DBG('Adj amt to 0');
            TB_PAST_ADJ_ICENT(K).ACQUIRED_AMT := 0;
          
            TB_PAST_ADJ_ICENT(K).ACQUIRED_ADJ := 0;
          END IF;
        
          TB_ICENT(K).LCY_AMT := 0;
          TB_ICENT(K).ACQUIRED_LCY := 0;
        
        ELSE
          GLOBAL.PR_RESET_SKIP_KERNEL;
        END IF;
      
      END IF;
    END LOOP;
    DBG('going to call upd_acc and having frm number as ' || TBFRM.COUNT);
    BEGIN
      UPD_ACC;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 4;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('l_next_liq_dt') := L_NEXT_LIQ_DT;
        L_TB_CLUSTER_DATA('tb_next_schd_liq_dt(i)') := TB_NEXT_SCHD_LIQ_DT(I);
        L_TB_CLUSTER_DATA('tb_next_liq_dt(i)') := TB_NEXT_LIQ_DT(I);
      
        DBG('l_Tb_Cluster_Data(l_next_liq_dt)' ||
            L_TB_CLUSTER_DATA('l_next_liq_dt'));
        DBG('l_Tb_Cluster_Data(tb_next_schd_liq_dt(i))' ||
            L_TB_CLUSTER_DATA('tb_next_schd_liq_dt(i)'));
        DBG('l_Tb_Cluster_Data(tb_next_liq_dt(i)' ||
            L_TB_CLUSTER_DATA('tb_next_liq_dt(i)'));
      
        ICPKS_TEST_CLUSTER.PR_LIQ_INT(P_DT,
                                      I,
                                      TB_ICENT,
                                      L_FN_CALL_ID,
                                      L_TB_CLUSTER_DATA);
      END IF;
    
    EXCEPTION
    
      WHEN OTHERS THEN
        LPG(TB_BRN(I) || '~' || TB_ACC(I) || '~' || 'WOT in upd_acc ' ||
            SUBSTR(SQLERRM, 1, 1500),
            TB_ACC(I));
        RAISE UPD_ACC_FAILED;
    END;
    IF NVL(G_ACQUIRED_INTR, 'N') = 'N' THEN
      DECLARE
        CURSOR CR_ADJINT IS
          SELECT BRN, ACC, PROD, FRM_NO, ENT_DT, CCY, AMT, LCY_AMT
            FROM ICTBS_ADJ_INTEREST
           WHERE BRN = TB_BRN(I)
             AND ACC = TB_ACC(I)
             AND PROD = TB_PROD(I)
           ORDER BY BRN, ACC, PROD, FRM_NO, ENT_DT;
      
      BEGIN
        LAST_REC := TB_ICENT_HIST_ADJ.COUNT + 1;
        FOR CR_ADINT IN CR_ADJINT LOOP
          BEGIN
            DBG('going to insert ictb_adj_interest_history');
            INSERT INTO ICTB_ADJ_INTEREST_HISTORY
              (BRN, ACC, PROD, FRM_NO, ENT_DT, LIQN_DT, CCY, AMT, LCY_AMT)
            VALUES
              (CR_ADINT.BRN,
               CR_ADINT.ACC,
               CR_ADINT.PROD,
               CR_ADINT.FRM_NO,
               CR_ADINT.ENT_DT,
               P_DT,
               CR_ADINT.CCY,
               CR_ADINT.AMT,
               CR_ADINT.LCY_AMT);
          
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('in exp for ictb_adj_interest_history insert ');
              NULL;
          END;
        
          LAST_REC := NVL(TB_ICENT_HIST_UPD.COUNT, 0) + 1;
          IF G_ONLIQ_FLAG = 'Y' THEN
            TB_ICENT_HIST_UPD(LAST_REC).ENTRY_TYPE := 'O';
          ELSE
            TB_ICENT_HIST_UPD(LAST_REC).ENTRY_TYPE := 'I';
          END IF;
          DBG('Entries History insert');
          DBG('Ramesh - I think This is Redundant. Pls 2 Check Xtremely Shady looking Loop Index');
        
          DBG('SQL%ROWCOUNT ' || SQL%ROWCOUNT);
          IF SQL%ROWCOUNT > 0 THEN
            DBG('DELETE ictbs_adj_interest for ' || TB_ACC(I));
            DELETE ICTBS_ADJ_INTEREST
             WHERE BRN = TB_BRN(I)
               AND ACC = TB_ACC(I)
               AND PROD = TB_PROD(I);
          END IF;
        
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('adj entries have some major HAAATH' || SQLERRM);
          LOG_PROBLEM(I,
                      'B',
                      'liq int adj ent ' || SUBSTR(SQLERRM, 1, 1900));
          EMSG;
      END;
    END IF;
    DBG('Going out of liquidation of inteREST');
    TB_BKVAL_MINCALC_DATE(I) := NULL;
    TB_BKVAL_RECALC_FLAG(I) := 'N';
    TB_RECALC_ACCR_ON_LIQN(I) := 'Y';
  
  EXCEPTION
    WHEN EXP_CONV THEN
      DBG('ERROR WHILE CONVERTING');
      DBG('Rollback done sp_liq_int');
      ROLLBACK TO SP_LIQ_INT;
      DBG('ab ....pr_liq_int=> ' || SQLERRM);
      LOG_PROBLEM(I,
                  'B',
                  'exp_conv in liq_int ' || SUBSTR(SQLERRM, 1, 1900));
      RAISE;
    WHEN UPD_ACC_FAILED THEN
      DBG('Problem during call to upd_acc ');
      DBG('Rollback done sp_liq_int 2');
      ROLLBACK TO SP_LIQ_INT;
      RAISE;
    WHEN OTHERS THEN
      ICPKSS_EOD.EOD_RETSTAT := 1;
      ERM                    := SQLERRM;
      DBG('Rollback done sp_liq_int - 3');
      ROLLBACK TO SP_LIQ_INT;
      DBG('ab kya huva ....pr_liq_int=> ' || SQLERRM);
      LOG_PROBLEM(I, 'B', 'WOT in pr_liq_int ' || SUBSTR(SQLERRM, 1, 1900));
      RAISE;
  END PR_LIQ_INT;

  PROCEDURE FIND_ENTHIST_ACCRUE(P_PROD      VARCHAR2,
                                P_EVE       VARCHAR2,
                                P_FRM_NO    VARCHAR2,
                                P_HOFF_PROD IN OUT NOCOPY ACPKSS.TBL_ACHOFF) IS
    START_INDEX NUMBER;
    END_INDEX   NUMBER;
    L_NU        NUMBER := 0;
    L_ST_INDEX  BINARY_INTEGER;
    L_HOFF_PROD ACPKSS.TBL_ACHOFF;
  BEGIN
    DBG('Just before getting the hash..' || P_PROD || '~' || P_FRM_NO);
    L_ST_INDEX := CSPKSS_UTILS.FN_HASH40(P_PROD || P_FRM_NO);
    DBG('In enthhistaccrue' || L_ST_INDEX);
    IF TB_HOFF_PROD.EXISTS(L_ST_INDEX) THEN
      IF P_EVE = 'IACR' THEN
        START_INDEX := L_PROD_ENTINDEX(L_ST_INDEX).ACCR_START_INDEX;
        END_INDEX   := L_PROD_ENTINDEX(L_ST_INDEX).ACCR_END_INDEX;
      ELSE
        START_INDEX := L_PROD_ENTINDEX(L_ST_INDEX).LIQ_START_INDEX;
        END_INDEX   := L_PROD_ENTINDEX(L_ST_INDEX).LIQ_END_INDEX;
      END IF;
      DBG('got the indexes' || START_INDEX || '~' || END_INDEX);
      FOR J IN START_INDEX .. END_INDEX LOOP
        P_HOFF_PROD(L_NU) := TB_HOFF_PROD(J);
        L_NU := L_NU + 1;
      END LOOP;
    ELSE
      DBG('There are no entries for this prod frm combination');
    END IF;
  END FIND_ENTHIST_ACCRUE;

  PROCEDURE PR_LIQ_NETTING(P_BRN    VARCHAR2,
                           P_DT     DATE,
                           P_ROWNUM NUMBER,
                           TB_ICENT IN OUT NOCOPY REC_ICENT) IS
    H                  BINARY_INTEGER;
    INDX               NUMBER;
    L_XRATE            ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_REF              ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    L_FRM_NO           ICTMS_RULE_FRM.FRM_NO%TYPE;
    L_TBLOOKUP         ACPKSS.TBL_LOOKUP;
    L_TB_HOFF_PROD     ACPKSS.TBL_ACHOFF;
    ERRCODE            ERTBS_MSGS.ERR_CODE%TYPE;
    ERR_CODE           ERTBS_MSGS.ERR_CODE%TYPE;
    L_TAX_PAY_CCY_FLAG ICTMS_RULE_FRM.TAX_PAY_CCY_FLAG%TYPE;
    L_LCY_AMT          ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_RULE             ICTMS_RULE_FRM.RULE_ID%TYPE;
    R_PR               REC_PRINT;
    JAI                NUMBER := 0;
    M                  NUMBER := 0;
    EXP_CONV EXCEPTION;
    NUM              NUMBER;
    L_TEMP_HOFF_PROD ACPKSS.TBL_ACHOFF;
    L_TEMP_IDX       NUMBER := 0;
    PROCEDURE EMSG IS
    BEGIN
      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_LIQ_NETTING->');
    END EMSG;
  BEGIN
    DBG('Inside procedure PR_LIQ_NETTING');
    DBG('Just after when entered I have ' || TB_HOFF_PROD.COUNT || '~' ||
        P_ROWNUM);
    TB_BASIC_HOFF(1).EVENT := 'ILIQ';
    IF TB_ICENT.COUNT > 0 THEN
      FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
      
        FIND_PROD_LOOKUP(TB_ICENT(J).PROD, 'ILIQ', L_TBLOOKUP);
        FIND_KEY(TB_ICENT(J).PROD, R_PR);
        SAVEPOINT SP_NETTING;
        L_REF := TB_BRN(P_ROWNUM) || TB_ICENT(J).PROD || TB_CCY(P_ROWNUM) ||
                 LTRIM(RTRIM(TO_CHAR(TB_ICENT(J).FRM_NO, '00000'))) || 'L';
        DBG('reference number looks like this :' || L_REF);
        IF L_TBLOOKUP.COUNT > 0 THEN
          FOR I IN L_TBLOOKUP.FIRST .. L_TBLOOKUP.LAST LOOP
            DBG('Inside lookup');
            NUM := I;
          
            L_FRM_NO := TO_NUMBER(SUBSTR(L_TBLOOKUP(I).ACCROLE,
                                         INSTR(L_TBLOOKUP(I).ACCROLE,
                                               '-',
                                               -1) + 1));
            H        := CSPKSS_UTILS.FN_HASH40(TB_PROD(P_ROWNUM) || TB_ICENT(J)
                                               .FRM_NO);
            DBG('after getting the hash value' || L_TBLOOKUP(I).ACCROLE);
            DBG('frm number is ' || TB_ICENT(J).FRM_NO);
            DBG('amount tag after formula is ' || L_FRM_NO || ' - ' || L_TBLOOKUP(I)
                .AMTTAG);
            DBG('reference numbr is' || L_REF);
            DBG('Account ' || L_TBLOOKUP(I).ACCOUNT || ' DRCR ' || L_TBLOOKUP(I)
                .DRCRIND || ' ' || TB_ICENT(J).ACC);
            IF (SUBSTR(L_TBLOOKUP(I).ACCROLE,
                       INSTR(L_TBLOOKUP(I).ACCROLE, '-', 1, 1) + 1,
                       
                       4) NOT IN ('BOOK', 'TEXP') AND
               L_FRM_NO = TB_ICENT(J).FRM_NO AND L_TBLOOKUP(I)
               .AMTTAG IN ('ILIQ', 'TAX', 'FATCA_TAX', 'FATCA_REFERRAL')) THEN
            
              DBG('something to do loop for amttag : ' || L_TBLOOKUP(I)
                  .AMTTAG);
            
              DBG('amount before fatca : ' || TB_ICENT(J).AMT);
              IF L_TBLOOKUP(I).AMTTAG = 'FATCA_TAX' THEN
                TB_ICENT(J).AMT := L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL;
                TB_ICENT(J).LCY_AMT := L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                       .SUM_TPBL_LCY;
                L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL := 0;
                L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL_LCY := 0;
              ELSIF L_TBLOOKUP(I).AMTTAG = 'FATCA_REFERRAL' THEN
                TB_ICENT(J).AMT := L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                   .SUM_ESCROW;
                TB_ICENT(J).LCY_AMT := L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                       .SUM_ESCROW_LCY;
                L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW := 0;
                L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW_LCY := 0;
              END IF;
              DBG('amount after fatca : ' || TB_ICENT(J).AMT);
            
              JAI := NVL(TB_HOFF_PROD.COUNT, 0) + 1;
              DBG('The index is  ' || JAI || '~ count is ' ||
                  TB_HOFF_PROD.COUNT);
              TB_HOFF_PROD(JAI) := TB_BASIC_HOFF(1);
              DBG('After basic hoff assignment');
              TB_HOFF_PROD(JAI).TRN_REF_NO := L_REF;
              IF L_TBLOOKUP(I).ACCOUNT = 'USERINPUT' THEN
                TB_HOFF_PROD(JAI).AC_NO := TB_ICENT(J).ACC;
              ELSE
                TB_HOFF_PROD(JAI).AC_NO := L_TBLOOKUP(I).ACCOUNT;
              END IF;
              DBG('tb_hoff_prod(jai).ac_no ' || TB_HOFF_PROD(JAI).AC_NO);
              TB_HOFF_PROD(JAI).AC_BRANCH := TB_BRN(P_ROWNUM);
              TB_HOFF_PROD(JAI).AC_CCY := G_STTM_CUSTACC.CCY;
              DBG('After currency assignment ' || TB_HOFF_PROD(JAI).AC_CCY);
              TB_HOFF_PROD(JAI).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
              TB_HOFF_PROD(JAI).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
              TB_HOFF_PROD(JAI).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
              DBG('Check for ccys ' || TB_CCY(P_ROWNUM) || '~' || LCY);
              IF TB_CCY(P_ROWNUM) <> LCY THEN
                DBG('Are the cutrrencys different');
                L_LCY_AMT := NULL;
                L_XRATE   := NULL;
                IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(P_ROWNUM),
                                                   TB_CCY(P_ROWNUM),
                                                   LCY,
                                                   NVL(TB_ICENT(J).AMT, 0),
                                                   'Y',
                                                   L_LCY_AMT,
                                                   L_XRATE,
                                                   ERR_CODE) THEN
                  DBG('Bombed in liq  netting conversion');
                
                  RAISE EXP_CONV;
                ELSE
                
                  TB_HOFF_PROD(JAI).LCY_AMOUNT := NVL(TB_ICENT(J).LCY_AMT,
                                                      0);
                
                  TB_HOFF_PROD(JAI).EXCH_RATE := L_XRATE;
                  TB_HOFF_PROD(JAI).FCY_AMOUNT := NVL(TB_ICENT(J).AMT, 0);
                END IF;
              ELSE
                DBG('Now assign the things here');
                TB_HOFF_PROD(JAI).LCY_AMOUNT := NVL(TB_ICENT(J).AMT, 0);
                TB_HOFF_PROD(JAI).EXCH_RATE := NULL;
                TB_HOFF_PROD(JAI).FCY_AMOUNT := NULL;
              END IF;
              DBG('After conversion lcy/fcy ' || TB_HOFF_PROD(JAI)
                  .LCY_AMOUNT || '~' || TB_HOFF_PROD(JAI).FCY_AMOUNT);
              IF SUBSTR(L_TBLOOKUP(I).ACCROLE,
                        INSTR(L_TBLOOKUP(I).ACCROLE, '-', 1, 1) + 1,
                        4) = 'TPBL' AND L_TBLOOKUP(I).AMTTAG IN ('TAX') THEN
                L_RULE             := SUBSTR(L_TBLOOKUP(I).ACCROLE,
                                             1,
                                             INSTR(L_TBLOOKUP(I).ACCROLE,
                                                   '-',
                                                   1,
                                                   1) - 1);
                L_TAX_PAY_CCY_FLAG := SUBSTR(R_PR.FRM_VAL_STR, L_FRM_NO, 1);
              
                DBG('l_tax_pay_ccy_flag ' || L_TAX_PAY_CCY_FLAG);
                IF NVL(L_TAX_PAY_CCY_FLAG, 'A') = 'L' AND TB_HOFF_PROD(JAI)
                  .AC_CCY <> LCY
                
                 THEN
                  TB_HOFF_PROD(JAI).AC_CCY := LCY;
                  TB_HOFF_PROD(JAI).FCY_AMOUNT := 0;
                  TB_HOFF_PROD(JAI).EXCH_RATE := 0;
                END IF;
              END IF;
            
              TB_HOFF_PROD(JAI).VALUE_DT := P_DT + 1;
            
              TB_HOFF_PROD(JAI).PRODUCT_ACCRUAL := 'P';
              TB_HOFF_PROD(JAI).NETTING_IND := L_TBLOOKUP(I).NETIND;
              TB_HOFF_PROD(JAI).AVLDAYS := 0;
              TB_HOFF_PROD(JAI).RELATED_CUSTOMER := NULL;
              TB_HOFF_PROD(JAI).TXN_INIT_DATE := APPDT;
              TB_HOFF_PROD(JAI).MIS_HEAD := L_TBLOOKUP(I).MIS_HEAD;
              TB_HOFF_PROD(JAI).NETTING_IND := 'N';
              DBG('THis is comleted here');
            
              TB_HOFF_PROD(JAI).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PROD(JAI)
                                                                             .AC_CCY,
                                                                             TB_HOFF_PROD(JAI)
                                                                             .FCY_AMOUNT,
                                                                             LCY,
                                                                             TB_HOFF_PROD(JAI)
                                                                             .LCY_AMOUNT);
              DBG('The lcy amt is ' || TB_HOFF_PROD(JAI).LCY_AMOUNT);
            ELSIF (SUBSTR(L_TBLOOKUP(I).ACCROLE,
                          INSTR(L_TBLOOKUP(I).ACCROLE, '-', 1, 1) + 1,
                          
                          4) NOT IN ('BOOK', 'TEXP') AND
                  L_FRM_NO = TB_ICENT(J).FRM_NO AND L_TBLOOKUP(I)
                  .AMTTAG IN ('INT_NADJ',
                              'TAX_NADJ',
                              'IACQUIRED',
                              'TAX_ADJ',
                              'INT_PADJ') AND TB_ICENT(J)
                  .ACQUIRED_AMT <> 0) THEN
              DBG('Inside the elsif Condition for acquired amount');
              JAI := NVL(TB_HOFF_PROD.COUNT, 0) + 1;
              DBG('The index is  ' || JAI || '~ count is ' ||
                  TB_HOFF_PROD.COUNT);
              TB_HOFF_PROD(JAI) := TB_BASIC_HOFF(1);
              TB_HOFF_PROD(JAI).TRN_REF_NO := L_REF;
              IF L_TBLOOKUP(I).ACCOUNT = 'USERINPUT' THEN
                TB_HOFF_PROD(JAI).AC_NO := TB_ICENT(J).ACC;
              ELSE
                TB_HOFF_PROD(JAI).AC_NO := L_TBLOOKUP(I).ACCOUNT;
              END IF;
              DBG('tb_hoff_prod(jai).ac_no ' || TB_HOFF_PROD(JAI).AC_NO);
              TB_HOFF_PROD(JAI).AC_BRANCH := TB_BRN(P_ROWNUM);
              TB_HOFF_PROD(JAI).AC_CCY := TB_CCY(P_ROWNUM);
              TB_HOFF_PROD(JAI).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
              TB_HOFF_PROD(JAI).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
              TB_HOFF_PROD(JAI).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
              TB_HOFF_PROD(JAI).NETTING_IND := 'N';
            
              TB_HOFF_PROD(JAI).PRODUCT_ACCRUAL := 'P';
              DBG('Check for ccys ' || TB_CCY(P_ROWNUM) || '~' || LCY);
              IF TB_CCY(P_ROWNUM) <> LCY THEN
                TB_HOFF_PROD(JAI).FCY_AMOUNT := TB_ICENT(J).ACQUIRED_AMT;
                TB_HOFF_PROD(JAI).LCY_AMOUNT := NULL;
                TB_HOFF_PROD(JAI).EXCH_RATE := NULL;
                IF NOT
                    ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(P_ROWNUM),
                                                TB_CCY(P_ROWNUM),
                                                LCY,
                                                NVL(TB_HOFF_PROD(JAI)
                                                    .FCY_AMOUNT,
                                                    0),
                                                'Y',
                                                TB_HOFF_PROD(JAI).LCY_AMOUNT,
                                                TB_HOFF_PROD(JAI).EXCH_RATE,
                                                ERRCODE) THEN
                  DBG('Haath in rate conversion we can not post this so log...');
                  EMSG;
                
                  RAISE EXP_CONV;
                END IF;
                TB_HOFF_PROD(JAI).LCY_AMOUNT := TB_ICENT(J).ACQUIRED_LCY;
              ELSE
                TB_HOFF_PROD(JAI).LCY_AMOUNT := TB_ICENT(J).ACQUIRED_AMT;
                TB_HOFF_PROD(JAI).FCY_AMOUNT := NULL;
                TB_HOFF_PROD(JAI).EXCH_RATE := NULL;
              END IF;
              DBG('Acquired amount for liq netting is lcy/fcy' || TB_HOFF_PROD(JAI)
                  .LCY_AMOUNT || '~' || TB_HOFF_PROD(JAI).FCY_AMOUNT);
              IF SUBSTR(L_TBLOOKUP(I).ACCROLE,
                        INSTR(L_TBLOOKUP(I).ACCROLE, '-', 1, 1) + 1,
                        4) = 'TPBL' AND L_TBLOOKUP(I).AMTTAG IN ('TAX') THEN
                L_RULE             := SUBSTR(L_TBLOOKUP(I).ACCROLE,
                                             1,
                                             INSTR(L_TBLOOKUP(I).ACCROLE,
                                                   '-',
                                                   1,
                                                   1) - 1);
                L_TAX_PAY_CCY_FLAG := SUBSTR(R_PR.FRM_VAL_STR, L_FRM_NO, 1);
                IF NVL(L_TAX_PAY_CCY_FLAG, 'A') = 'L' AND TB_HOFF_PROD(H)
                  .AC_CCY <> LCY THEN
                  TB_HOFF_PROD(JAI).AC_CCY := LCY;
                  TB_HOFF_PROD(JAI).FCY_AMOUNT := 0;
                  TB_HOFF_PROD(JAI).EXCH_RATE := 0;
                END IF;
              END IF;
              IF L_TBLOOKUP(I).AMTTAG IN ('TAX_NADJ', 'INT_NADJ') THEN
                TB_HOFF_PROD(JAI).FCY_AMOUNT := ABS(TB_HOFF_PROD(JAI)
                                                    .FCY_AMOUNT);
                TB_HOFF_PROD(JAI).LCY_AMOUNT := ABS(TB_HOFF_PROD(JAI)
                                                    .LCY_AMOUNT);
              END IF;
            
              TB_HOFF_PROD(JAI).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PROD(JAI)
                                                                             .AC_CCY,
                                                                             TB_HOFF_PROD(JAI)
                                                                             .FCY_AMOUNT,
                                                                             LCY,
                                                                             TB_HOFF_PROD(JAI)
                                                                             .LCY_AMOUNT);
            
              DBG(' sig amt ' || TO_CHAR(TB_HOFF_PROD(JAI).LCY_AMOUNT));
            
            END IF;
          
          END LOOP;
        END IF;
        DBG('Just after end loop I have ' || TB_HOFF_PROD.COUNT);
        L_TEMP_HOFF_PROD.DELETE;
        L_TEMP_IDX := 0;
        M          := TB_HOFF_PROD.FIRST;
        WHILE M IS NOT NULL LOOP
          IF TB_HOFF_PROD(M).LCY_AMOUNT = 0 THEN
            DBG('lcy amount is zero we can not post this even in liq netting');
            TB_HOFF_PROD.DELETE(M);
          
          ELSE
            L_TEMP_IDX := L_TEMP_IDX + 1;
            L_TEMP_HOFF_PROD(L_TEMP_IDX) := TB_HOFF_PROD(M);
            TB_HOFF_PROD.DELETE(M);
          
          END IF;
          M := TB_HOFF_PROD.NEXT(M);
        END LOOP;
      
        IF L_TEMP_HOFF_PROD.COUNT > 0 THEN
          TB_HOFF_PROD := L_TEMP_HOFF_PROD;
        END IF;
      
        TB_ICENT(J).AMT := 0;
        TB_ICENT(J).ACCRUED_AMT := 0;
        TB_ICENT(J).AMT_TO_ACCRUE := 0;
        TB_ICENT(J).CUR_RUN_ACCR := 0;
        TB_ICENT(J).DAILY_AMT := 0;
        TB_ICENT(J).ACQUIRED_AMT := 0;
      
        TB_ICENT(J).LCY_AMT := 0;
        TB_ICENT(J).ACQUIRED_LCY := 0;
      
      END LOOP;
    END IF;
  EXCEPTION
  
    WHEN EXP_CONV THEN
      DBG(' IN EXP CONV of liq netting');
      LOG_PROBLEM(P_ROWNUM,
                  'B',
                  'Exp Conv in liq netting ' || SUBSTR(SQLERRM, 1, 1900));
      TB_HOFF_PROD.DELETE(JAI);
      RAISE;
    WHEN OTHERS THEN
      DBG('In major exceptions of liq netting  : ' || SQLERRM);
      LOG_PROBLEM(P_ROWNUM,
                  'B',
                  'WOT in liq netting ' || SUBSTR(SQLERRM, 1, 1900));
      TB_HOFF_PROD.DELETE(JAI);
      RAISE;
  END PR_LIQ_NETTING;

  PROCEDURE FIND_KEY(P_PROD VARCHAR2, P_ICTMPRINT IN OUT REC_PRINT) IS
    H BINARY_INTEGER;
  BEGIN
    H           := CSPKSS_UTILS.FN_HASH40(P_PROD);
    P_ICTMPRINT := TB_PRINT(H);
  END FIND_KEY;

  PROCEDURE PR_CALC(P_BRN     VARCHAR2,
                    P_ACC     VARCHAR2,
                    P_PROD    VARCHAR2,
                    P_DT      DATE,
                    TBL_ICENT IN OUT NOCOPY REC_ICENT) IS
    R_PR       REC_PRINT;
    L_TB_ICENT REC_ICENT;
  
    L_RULE ICTMS_PR_INT.RULE%TYPE;
  
  BEGIN
    DBG('Jut inside pr_calc' || P_PROD);
  
    FIND_KEY(P_PROD, R_PR);
    DBG('sending the details' || P_PROD || '~' || R_PR.RULE);
    DBG('and entries here are ..' || TBL_ICENT.COUNT);
  
    IF R_PR.IS_FMT = 'Y' THEN
      DELETE FROM ICTBS_IS_VALS V
       WHERE V.BRN = P_BRN
         AND V.ACC = P_ACC
         AND V.RULE_ID = R_PR.RULE
         AND V.FRM_DT >= ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT;
    END IF;
  
    ICPKSS_CALC.G_PROD_REC.UDE_CCY := R_PR.UDE_CCY;
  
    IF G_ICTM_ACC.ACC_TYPE = 'N' THEN
      DBG('Calling shell normal');
      C3GF#_ICPR1_CALC_SHELL_NORMAL(P_BRN,
                                    P_ACC,
                                    P_PROD,
                                    TO_CHAR(P_DT, 'YYYYMMDD'),
                                    R_PR.RULE,
                                    TBL_ICENT);
    ELSE
      DBG('Calling shell combined');
      C3GF#_ICP1_CALC_SHELL_COMBINED(P_BRN,
                                     P_ACC,
                                     P_PROD,
                                     TO_CHAR(P_DT, 'YYYYMMDD'),
                                     R_PR.RULE,
                                     TBL_ICENT);
    END IF;
  
    DBG('Here we had ' || TBL_ICENT.COUNT);
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of pr_calc : ' || SQLERRM);
    
      TBL_ICENT.DELETE;
      RAISE;
    
  END PR_CALC;
  PROCEDURE PR_INIT_VALS(P_BRN VARCHAR2) IS
  BEGIN
    DBG('Just going for initialisation of the data');
    APPDT           := GLOBAL.APPLICATION_DATE;
    LCY             := GLOBAL.LCY;
    UID             := GLOBAL.USER_ID;
    NULREC.AMT      := NULL;
    NULREC.BOOK_AMT := NULL;
    NULREC.XRATE    := NULL;
    NULREC.LCY_AMT  := NULL;
    SELECT D.NEXT_WORKING_DAY - 1
      INTO NWD
      FROM STTMS_DATES D
     WHERE D.BRANCH_CODE = P_BRN;
    DBG('Going to select the liq_netting indicator' || NWD);
    SELECT NVL(LIQ_NETTING, 'N')
      INTO PKG_LIQ_NETTING
      FROM ICTMS_BRANCH_PARAMETERS
     WHERE BRANCH_CODE = P_BRN;
    DBG('Acrual on holidays??');
  
    ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS := ICPKSS_EOD.FN_GET_ACCRUE_ON_HOL_FLAG(P_BRN);
    DBG('Acrual on holidays??' || ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS);
  
  END PR_INIT_VALS;

  PROCEDURE LPG(MSG VARCHAR2, P_ACC VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO ICTBS_PROBLEM_LOG
      (LOGTIME, BRN, OP, PROD, ACC, ERRM)
    VALUES
      (SYSDATE, GLOBAL.CURRENT_BRANCH, '', NULL, P_ACC, MSG);
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
      DBG('WO Exception in Autonomous txn lpg will commit now' || SQLERRM);
      COMMIT;
  END LPG;

  PROCEDURE LOG_PROBLEM(P_ROWNUM NUMBER, P_OP VARCHAR2, P_ERR VARCHAR2) IS
    PROCEDURE LOG_PROBLEM_MAIN IS
      PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
    
      IF P_ROWNUM = -1 AND P_OP = 'Y' THEN
        INSERT INTO ICTBS_BOOK_ERR
          (BRN, OP, PROD, ACC, ERRM)
        VALUES
          (GLOBAL.CURRENT_BRANCH, P_OP, NULL, NULL, P_ERR);
      
        INSERT INTO ICTBS_PROBLEM_LOG
          (LOGTIME, BRN, OP, PROD, ACC, ERRM)
        VALUES
          (SYSDATE, GLOBAL.CURRENT_BRANCH, P_OP, NULL, NULL, P_ERR);
      
      ELSE
        INSERT INTO ICTBS_BOOK_ERR
          (BRN, OP, PROD, ACC, ERRM)
        VALUES
          (TB_BRN(P_ROWNUM),
           P_OP,
           TB_PROD(P_ROWNUM),
           TB_ACC(P_ROWNUM),
           P_ERR);
      
        INSERT INTO ICTBS_PROBLEM_LOG
          (LOGTIME, BRN, OP, PROD, ACC, ERRM)
        VALUES
          (SYSDATE,
           TB_BRN(P_ROWNUM),
           P_OP,
           TB_PROD(P_ROWNUM),
           TB_ACC(P_ROWNUM),
           P_ERR);
      
      END IF;
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WO Exception in log_problem_main' || SQLERRM);
        NULL;
        COMMIT;
      
    END LOG_PROBLEM_MAIN;
  BEGIN
    LOG_PROBLEM_MAIN;
    TB_HAS_PROBLEMS(P_ROWNUM) := 'Y';
    ICPKSS_EOD.EOD_RETSTAT := 1;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WO Exception in log_problem ' || SQLERRM);
    
  END LOG_PROBLEM;

  PROCEDURE PR_ENTRIES_ACCRUE(P_DT DATE, I NUMBER, TBFRM TBFRMTYP) IS
    R_PR      ICPKS_TEST.REC_PRINT;
    TB_LOOKUP ACPKSS.TBL_LOOKUP;
    NULROW    ACTBS_HANDOFF%ROWTYPE;
    REF       ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    LASTREC   NUMBER := 0;
    FRM_NO    ICTB_ENTRIES.FRM_NO%TYPE;
    P_HD_ACC  STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    P_HD_BRN  STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    P_HD_CCY  STTMS_CUST_ACCOUNT.CCY%TYPE;
  
    CONS_COUNT         NUMBER;
    HOFF_COUNT         NUMBER;
    TB_HOFF            ACPKSS.TBL_ACHOFF;
    L_CCY              CYTMS_CCY_PAIR_DEFN.CCY1%TYPE;
    L_ACQUIRED_FCY_AMT ACTBS_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_ACQUIRED_LCY_AMT ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_RATE             ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    ERR_CODE           VARCHAR2(255);
    ERRMSG             VARCHAR2(32760);
    DUMMY              ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    J                  INTEGER := 0;
    TEMP_HOFF          ACPKSS.TBL_ACHOFF;
    SR                 NUMBER;
    EXP_CONV EXCEPTION;
    NOT_A_CM EXCEPTION;
  
    L_ACCR_FOR_REDEM_AMOUNT ICTBS_REDEMPTION_DETAIL.ACCR_FOR_REDEM_AMT%TYPE;
    L_REDEM_DATE            DATE;
    L_PPO                   ICTBS_REDEMPTION_DETAIL.PPO%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    L_ACCR_FLAG VARCHAR2(1);
    PROCEDURE EMSG IS
    BEGIN
      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_ACCRUE->');
    END EMSG;
  BEGIN
    DBG('Inside pr_entries_accrue');
    LASTREC := NVL(TB_RACCR_ACC.COUNT, 0) + 1;
    TB_BASIC_HOFF(1).EVENT := 'IACR';
    DBG('last rec is ' || LASTREC);
    IF TBFRM.COUNT > 0 THEN
      DBG('tbfrm cout is more than 0');
      FIND_KEY(TB_PROD(I), R_PR);
    
      IF R_PR.IL_PRODUCT = 'Y' AND NVL(R_PR.IL_TYPE, '*') = '1' THEN
        RETURN;
      END IF;
    
      DBG('In accrual entries for ' || TB_ACC(I));
    
      FIND_PROD_LOOKUP(TB_PROD(I), 'IACR', TB_LOOKUP);
    
      IF TB_LOOKUP.COUNT > 0 THEN
        DBG('Lookup has some...' || TB_LOOKUP.COUNT);
        FOR K IN TB_LOOKUP.FIRST .. TB_LOOKUP.LAST LOOP
          L_ACQUIRED_FCY_AMT := 0;
          L_ACQUIRED_LCY_AMT := 0;
          BEGIN
            DBG('Lookup has some...tb_lookup(k).accrole' || TB_LOOKUP(K)
                .ACCROLE);
            FRM_NO := TO_NUMBER(SUBSTR(TB_LOOKUP(K).ACCROLE,
                                       INSTR(TB_LOOKUP(K).ACCROLE, '-', -1) + 1));
            DBG('Frm no is ' || FRM_NO);
            L_ACCR_FLAG := NULL;
          
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              GLOBAL.PR_RESET_SKIP_KERNEL;
              L_FN_CALL_ID      := 2;
              L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
            
              L_TB_CLUSTER_DATA('tb_lookup(k).accrole') := TB_LOOKUP(K)
                                                           .ACCROLE;
              L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_LOOKUP(K)
                                                          .AMTTAG;
              L_TB_CLUSTER_DATA('l_accr_flag') := L_ACCR_FLAG;
            
              ICPKS_TEST_CLUSTER.PR_ENTRIES_ACCRUE(P_DT,
                                                   I,
                                                   TBFRM,
                                                   L_FN_CALL_ID,
                                                   L_TB_CLUSTER_DATA);
            
              L_ACCR_FLAG := L_TB_CLUSTER_DATA('l_accr_flag');
            END IF;
          
            DBG('l_accr_flag: ' || L_ACCR_FLAG);
          
            IF NOT GLOBAL.G_SKIP_KERNEL THEN
            
              IF (G_ACCRUAL_REVERSAL = 'Y' OR
                 (G_ACCRUAL_REVERSAL = 'N' AND
                 NVL(TB_PROD_ACCR(I), 'N') = 'N')) OR
                 (NVL(L_ACCR_FLAG, 'x') = 'Y') THEN
                DUMMY := TBFRM(FRM_NO).LCY_AMT;
                DBG('frm no is' || FRM_NO);
                DBG('Accrual lcy amount is' || TBFRM(FRM_NO).LCY_AMT ||
                    'fcy amount is' || TBFRM(FRM_NO).AMT);
                TB_HOFF(K) := TB_BASIC_HOFF(1);
                TB_HOFF(K).RELATED_ACCOUNT := TB_ACC(I);
                REF := TB_BRN(I) || TB_PROD(I) || TB_CCY(I) ||
                       LPAD(FRM_NO, 6, '0');
              
                TB_HOFF(K).TRN_REF_NO := REF;
                TB_HOFF(K).AC_NO := TB_LOOKUP(K).ACCOUNT;
                TB_HOFF(K).DRCR_IND := TB_LOOKUP(K).DRCRIND;
                TB_HOFF(K).TRN_CODE := TB_LOOKUP(K).TRNCODE;
                TB_HOFF(K).AMOUNT_TAG := TB_LOOKUP(K).AMTTAG;
                TB_HOFF(K).MIS_HEAD := TB_LOOKUP(K).MIS_HEAD;
                TB_HOFF(K).NETTING_IND := TB_LOOKUP(K).NETIND;
                TB_HOFF(K).AC_CCY := TB_CCY(I);
                L_CCY := TB_CCY(I);
                TB_HOFF(K).RELATED_CUSTOMER := G_STTM_CUSTACC.CUST_NO;
                DBG('The accrole is ->' || TB_LOOKUP(K).ACCROLE);
              
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                  L_FN_CALL_ID := 1;
                  L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                  L_TB_CLUSTER_DATA('tb_hoff(k).related_reference') := TB_HOFF(K)
                                                                       .RELATED_REFERENCE;
                  L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                  L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                  L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                
                  L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_LOOKUP(K)
                                                              .AMTTAG;
                  L_TB_CLUSTER_DATA('frm_no') := FRM_NO;
                  L_TB_CLUSTER_DATA('l_acquired_lcy_amt') := L_ACQUIRED_LCY_AMT;
                  L_TB_CLUSTER_DATA('l_acquired_fcy_amt') := L_ACQUIRED_FCY_AMT;
                
                  ICPKS_TEST_CLUSTER.PR_ENTRIES_ACCRUE(P_DT,
                                                       I,
                                                       TBFRM,
                                                       L_FN_CALL_ID,
                                                       L_TB_CLUSTER_DATA);
                
                  L_ACQUIRED_LCY_AMT := L_TB_CLUSTER_DATA('l_acquired_lcy_amt');
                  L_ACQUIRED_FCY_AMT := L_TB_CLUSTER_DATA('l_acquired_fcy_amt');
                  TB_HOFF(K).RELATED_REFERENCE := L_TB_CLUSTER_DATA('tb_hoff(k).related_reference');
                
                END IF;
              
                IF (INSTR(TB_LOOKUP(K).ACCROLE, '-PNL-') > 0) OR
                   (INSTR(TB_LOOKUP(K).ACCROLE, '-PNL_ADJ-') > 0) THEN
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                    L_FN_CALL_ID := 3;
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    L_TB_CLUSTER_DATA('r_pr.pnl_replace') := R_PR.PNL_REPLACE;
                    L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                    L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                    L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                    L_TB_CLUSTER_DATA('tb_hoff(k).ac_no') := TB_HOFF(K)
                                                             .AC_NO;
                    L_TB_CLUSTER_DATA('tb_hoff(k).ac_branch') := TB_HOFF(K)
                                                                 .AC_BRANCH;
                    L_TB_CLUSTER_DATA('tb_hoff(k).ac_ccy') := TB_HOFF(K)
                                                              .AC_CCY;
                    L_TB_CLUSTER_DATA('l_ccy') := L_CCY;
                    L_TB_CLUSTER_DATA('tb_lookup(k).accrole') := TB_LOOKUP(K)
                                                                 .ACCROLE;
                  
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_ACCRUE(P_DT,
                                                         I,
                                                         TBFRM,
                                                         L_FN_CALL_ID,
                                                         L_TB_CLUSTER_DATA);
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('tb_hoff(k).ac_no') THEN
                      TB_HOFF(K).AC_NO := L_TB_CLUSTER_DATA('tb_hoff(k).ac_no');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('tb_hoff(k).ac_branch') THEN
                      TB_HOFF(K).AC_BRANCH := L_TB_CLUSTER_DATA('tb_hoff(k).ac_branch');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('tb_hoff(k).ac_ccy') THEN
                      TB_HOFF(K).AC_CCY := L_TB_CLUSTER_DATA('tb_hoff(k).ac_ccy');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_ccy') THEN
                      L_CCY := L_TB_CLUSTER_DATA('l_ccy');
                    END IF;
                  END IF;
                  IF NOT GLOBAL.G_SKIP_KERNEL THEN
                  
                    IF NVL(R_PR.PNL_REPLACE, 'N') = 'Y' THEN
                    
                      DBG('We are not supposed to use Dropped CM module');
                      RAISE NOT_A_CM;
                    
                    END IF;
                  
                  ELSE
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  END IF;
                
                END IF;
                DBG('g_accrual_reversal is ->' || G_ACCRUAL_REVERSAL);
                DBG('tb_lookup(k).amttag is ->' || TB_LOOKUP(K).AMTTAG);
              
                IF G_ACCRUAL_REVERSAL = 'Y' AND TB_LOOKUP(K)
                  .AMTTAG = 'IACR_ADJ' THEN
                  L_ACQUIRED_FCY_AMT := -1 *
                                        NVL(TBFRM(FRM_NO).ACCRUED_AMT, 0) +
                                        NVL(TBFRM(FRM_NO).ACQUIRED_ADJ, 0);
                
                  TB_RACCR_BRN(LASTREC + K) := TB_BRN(I);
                  TB_RACCR_ACC(LASTREC + K) := TB_ACC(I);
                  TB_RACCR_PROD(LASTREC + K) := TB_PROD(I);
                  TB_RACCR_FRM_NO(LASTREC + K) := FRM_NO;
                
                ELSIF G_ACCRUAL_REVERSAL = 'N' AND TB_LOOKUP(K)
                     .AMTTAG = 'IACR_ADJ' THEN
                
                  L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO)
                                        .ACQUIRED_AMT -
                                         NVL(TBFRM(FRM_NO).ACQUIRED_ADJ, 0);
                
                  IF L_CCY <> LCY THEN
                    L_RATE := NULL;
                    IF NOT
                        ICPKS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                   L_CCY,
                                                   LCY,
                                                   NVL(L_ACQUIRED_FCY_AMT, 0),
                                                   'Y',
                                                   L_ACQUIRED_LCY_AMT,
                                                   L_RATE,
                                                   ERR_CODE) THEN
                      ERRMSG := ERR_CODE;
                      DBG('Conversion gave hand' || '~' || LCY || '~' ||
                          TB_CCY(I));
                      EMSG;
                    END IF;
                  ELSE
                    L_ACQUIRED_LCY_AMT := L_ACQUIRED_FCY_AMT;
                  END IF;
                
                ELSIF G_ACCRUAL_REVERSAL = 'N' AND TB_LOOKUP(K)
                     .AMTTAG = 'IACR_ADJ_PREV' THEN
                  IF (TBFRM_PAST_ADJ.EXISTS(FRM_NO)) THEN
                    DBG('Came until here for prev entries ##1 ');
                    DBG('nvl((tbfrm_past_adj(frm_no).acquired_amt),0) ' ||
                        NVL((TBFRM_PAST_ADJ(FRM_NO).ACQUIRED_AMT), 0));
                    DBG('nvl((tbfrm_past_adj(frm_no).acquired_adj),0) ' ||
                        NVL((TBFRM_PAST_ADJ(FRM_NO).ACQUIRED_ADJ), 0));
                  
                    L_ACQUIRED_FCY_AMT := NVL((TBFRM_PAST_ADJ(FRM_NO)
                                              .ACQUIRED_AMT),
                                              0) - NVL((TBFRM_PAST_ADJ(FRM_NO)
                                                       .ACQUIRED_ADJ),
                                                       0);
                    DBG('l_acquired_fcy_amt ' || L_ACQUIRED_FCY_AMT);
                  ELSE
                    DBG('Came until here for prev entries ##2 ');
                    L_ACQUIRED_FCY_AMT := 0;
                  END IF;
                  IF L_CCY <> LCY THEN
                    L_RATE := NULL;
                    IF NOT
                        ICPKS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                   L_CCY,
                                                   LCY,
                                                   NVL(L_ACQUIRED_FCY_AMT, 0),
                                                   'Y',
                                                   L_ACQUIRED_LCY_AMT,
                                                   L_RATE,
                                                   ERR_CODE) THEN
                      ERRMSG := ERR_CODE;
                      DBG('Conversion gave hand' || '~' || LCY || '~' ||
                          TB_CCY(I));
                      EMSG;
                    END IF;
                  ELSE
                    L_ACQUIRED_LCY_AMT := L_ACQUIRED_FCY_AMT;
                  END IF;
                ELSIF G_ACCRUAL_REVERSAL = 'N' AND TB_LOOKUP(K)
                     .AMTTAG = 'IACR_ADJ_CURR' THEN
                  IF (TBFRM_PAST_ADJ.EXISTS(FRM_NO)) THEN
                    DBG('Came until here for prev entries ##3 ');
                  
                    L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO)
                                          .ACQUIRED_AMT -
                                           NVL(TBFRM(FRM_NO).ACQUIRED_ADJ, 0) -
                                           (NVL(TBFRM_PAST_ADJ(FRM_NO)
                                                .ACQUIRED_AMT,
                                                0) - NVL(TBFRM_PAST_ADJ(FRM_NO)
                                                         .ACQUIRED_ADJ,
                                                         0));
                    DBG('l_acquired_fcy_amt ' || L_ACQUIRED_FCY_AMT);
                  
                  ELSE
                    DBG('Came until here for prev entries ##4 ');
                    L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO)
                                          .ACQUIRED_AMT -
                                           NVL(TBFRM(FRM_NO).ACQUIRED_ADJ, 0);
                  END IF;
                  IF L_CCY <> LCY THEN
                    L_RATE := NULL;
                    IF NOT
                        ICPKS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                   L_CCY,
                                                   LCY,
                                                   NVL(L_ACQUIRED_FCY_AMT, 0),
                                                   'Y',
                                                   L_ACQUIRED_LCY_AMT,
                                                   L_RATE,
                                                   ERR_CODE) THEN
                      ERRMSG := ERR_CODE;
                      DBG('Conversion gave hand' || '~' || LCY || '~' ||
                          TB_CCY(I));
                      EMSG;
                    END IF;
                  ELSE
                    L_ACQUIRED_LCY_AMT := L_ACQUIRED_FCY_AMT;
                  END IF;
                
                ELSIF TB_LOOKUP(K).AMTTAG = 'IACR' THEN
                
                  DBG('Coming in for amount tag as IACR');
                  DBG('The values now are :' || TBFRM(FRM_NO).AMT);
                  DBG('The lcy amount in the table is:' || TBFRM(FRM_NO)
                      .LCY_AMT);
                
                  IF NVL(TBFRM(FRM_NO).AMT, 0) = 0 THEN
                    L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO).LCY_AMT;
                    DBG('FCY-Amt = LCY-Amt');
                  ELSE
                    L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO).AMT;
                  END IF;
                  DBG('The acqrd amt now is:' || L_ACQUIRED_FCY_AMT);
                
                  L_ACQUIRED_LCY_AMT := NVL(TBFRM(FRM_NO).LCY_AMT, 0);
                
                END IF;
              
                DBG('After amt_tag,g_accrual_reversal IF');
                DBG('l_acquired_fcy_amt is ->' || L_ACQUIRED_FCY_AMT);
                DBG('l_acquired_lcy_amt is ->' || L_ACQUIRED_LCY_AMT);
                DBG('The currencies are l_ccy ->' || L_CCY || '<-lcy->' || LCY);
                IF L_CCY <> LCY THEN
                  L_RATE := NULL;
                  IF NOT ICPKS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                    L_CCY,
                                                    LCY,
                                                    NVL(L_ACQUIRED_FCY_AMT, 0),
                                                    'Y',
                                                    L_ACQUIRED_LCY_AMT,
                                                    L_RATE,
                                                    ERR_CODE) THEN
                    ERRMSG := ERR_CODE;
                    DBG('Conversion gave hand' || '~' || LCY || '~' ||
                        TB_CCY(I));
                    EMSG;
                  
                    RAISE EXP_CONV;
                  END IF;
                  TB_HOFF(K).FCY_AMOUNT := L_ACQUIRED_FCY_AMT;
                  TB_HOFF(K).EXCH_RATE := L_RATE;
                  TB_HOFF(K).LCY_AMOUNT := L_ACQUIRED_LCY_AMT;
                ELSE
                  TB_HOFF(K).FCY_AMOUNT := NULL;
                  TB_HOFF(K).EXCH_RATE := NULL;
                
                  TB_HOFF(K).LCY_AMOUNT := L_ACQUIRED_LCY_AMT;
                END IF;
                DBG('Just b4 significant amt. tb_hoff(k).fcy_amount ->' || TB_HOFF(K)
                    .FCY_AMOUNT);
                DBG('Just b4 significant amt. tb_hoff(k).lcy_amount ->' || TB_HOFF(K)
                    .LCY_AMOUNT);
                TB_HOFF(K).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF(K)
                                                                        .AC_CCY,
                                                                        TB_HOFF(K)
                                                                        .FCY_AMOUNT,
                                                                        LCY,
                                                                        TB_HOFF(K)
                                                                        .LCY_AMOUNT);
                DBG('Just after significant amt. tb_hoff(k).fcy_amount ->' || TB_HOFF(K)
                    .FCY_AMOUNT);
                DBG('Just after significant amt. tb_hoff(k).lcy_amount ->' || TB_HOFF(K)
                    .LCY_AMOUNT);
                IF TB_HOFF(K).AC_CCY <> LCY AND TB_HOFF(K).FCY_AMOUNT <> 0 AND
                    NVL(TB_HOFF(K).LCY_AMOUNT, 0) = 0 THEN
                  INSERT INTO ICTBS_XLOG
                    (RUN_DT, BRN, ACC, PROD, OP, EX_TYPE, PRM1)
                  VALUES
                    (APPDT,
                     TB_BRN(I),
                     TB_ACC(I),
                     TB_PROD(I),
                     'L',
                     'C',
                     LTRIM(RTRIM(CSFNS_FORMAT_AMT(TB_CCY(I),
                                                  TB_HOFF(K).FCY_AMOUNT))) || ' ' ||
                     TB_CCY(I) || ' = 0 ' || LCY);
                END IF;
              
                IF (TB_HOFF(K)
                   .AC_CCY <> LCY AND NVL(TB_HOFF(K).FCY_AMOUNT, 0) = 0) OR
                   (NVL(TB_HOFF(K).LCY_AMOUNT, 0) = 0 AND TB_HOFF(K)
                   .AC_CCY = LCY)
                
                 THEN
                  DBG('This row is getting deleted as lcy amount is' || '~' || TB_HOFF(K)
                      .LCY_AMOUNT);
                  TB_HOFF.DELETE(K);
                ELSE
                  DBG('Phew! Now tb_hoff can be added to temp_hoff');
                  SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
                  TEMP_HOFF(SR) := TB_HOFF(K);
                END IF;
              ELSE
                DBG('Nothing to be done here');
              END IF;
            
            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('This frm no has nothing to be done');
              NULL;
          END;
        END LOOP;
      
        UPDATE ICTB_REDEMPTION_DETAIL
           SET ADJ_FOR_REDEM_ACCR = 'Y'
         WHERE ACC = TB_ACC(I)
           AND BRN = TB_BRN(I)
           AND REDEMPTION_TYPE = 'P'
           AND REDEM_DATE >= P_DT;
      
      END IF;
      HOFF_COUNT := NVL(TEMP_HOFF.COUNT, 0);
      CONS_COUNT := NVL(TB_HOFF_CONS.COUNT, 0);
      IF CONS_COUNT <> 0 THEN
        CONS_COUNT := CONS_COUNT + 1;
      END IF;
      DBG('Here so called hoff count is' || '~' || HOFF_COUNT || '~' ||
          CONS_COUNT);
      IF HOFF_COUNT <> 0 THEN
        J := TEMP_HOFF.FIRST;
        WHILE J <= TEMP_HOFF.LAST LOOP
          TB_HOFF_CONS(CONS_COUNT + J) := TEMP_HOFF(J);
          J := TEMP_HOFF.NEXT(J);
        END LOOP;
      END IF;
    END IF;
    TB_HOFF.DELETE;
    TEMP_HOFF.DELETE;
  EXCEPTION
  
    WHEN EXP_CONV THEN
      DBG(' WHILE CONVERTING!!');
      RAISE;
    
    WHEN NOT_A_CM THEN
      DBG(' WHILE NOT_A_CM!!');
      RAISE;
    
    WHEN OTHERS THEN
      DBG('In accrual entries pr_entries_accrue =>' || SQLERRM);
      LOG_PROBLEM(I,
                  'B',
                  'WOT in pr_entries_accrue ' || SUBSTR(SQLERRM, 1, 1900));
      RAISE;
  END PR_ENTRIES_ACCRUE;

  PROCEDURE PR_ENTRIES_LIQ(P_DT DATE, I NUMBER, TBFRM TBFRMTYP) IS
    R_PR      ICPKS_TEST.REC_PRINT;
    TB_LOOKUP ACPKSS.TBL_LOOKUP;
    NULROW    ACTBS_HANDOFF%ROWTYPE;
    REF       ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    LASTREC   NUMBER := 0;
    FRM_NO    ICTB_ENTRIES.FRM_NO%TYPE;
    P_HD_ACC  STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    P_HD_BRN  STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    P_HD_CCY  STTMS_CUST_ACCOUNT.CCY%TYPE;
  
    CONS_COUNT         NUMBER;
    HOFF_COUNT         NUMBER;
    TB_HOFF            ACPKSS.TBL_ACHOFF;
    L_CCY              CYTMS_CCY_PAIR_DEFN.CCY1%TYPE;
    L_ACQUIRED_FCY_AMT ACTBS_DAILY_LOG.FCY_AMOUNT%TYPE;
    L_ACQUIRED_LCY_AMT ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_RATE             ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_TAX_PAY_CCY_FLAG VARCHAR2(1);
    ERR_CODE           VARCHAR2(255);
    ERRMSG             VARCHAR2(32760);
    DUMMY              ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    J                  NUMBER;
    TEMP_HOFF          ACPKSS.TBL_ACHOFF;
    SR                 NUMBER;
    L_BOOK_GL          VARCHAR2(1000);
  
    L_ACC_REC   STTBS_ACCOUNT%ROWTYPE;
    L_DR_INT_GL BOOLEAN := FALSE;
  
    L_COLLATERAL_LINE BOOLEAN := FALSE;
    L_FRM_NO1         ICTBS_SODDR_INT_DUE.FRM_NO%TYPE;
    L_INT_AMT_DUE1    ICTBS_SODDR_INT_DUE.AMT_DUE%TYPE;
    L_LIQD_DATE1      DATE;
  
    L_LINE_COUNT NUMBER;
    L_SEQ        VARCHAR2(10);
  
    L_DR_INT_RECV_GL    ICTMS_PR_INT.DR_INT_RECV_GL%TYPE;
    L_DR_INT_USING_RECV STTMS_ACCOUNT_CLASS.DR_INT_USING_RECV%TYPE;
    L_DR_INT_DAYS       STTMS_ACCOUNT_CLASS.DR_INT_LIQD_DAYS%TYPE;
  
    L_DR_INT_NOTICE   STTMS_ACCOUNT_CLASS.DR_INT_NOTICE%TYPE;
    L_FRM_NO          ICTBS_DR_INT_DUE.FRM_NO%TYPE;
    L_INT_AMT_DUE     ICTBS_DR_INT_DUE.AMT_DUE%TYPE;
    L_XRATE           ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    L_INT_AMT         STTMS_CUST_ACCOUNT.DR_INT_DUE%TYPE;
    L_LIQD_DATE       DATE;
    L_DR_INT_BOOK_ACC ICTBS_DR_INT_DUE.BOOK_ACC%TYPE;
    L_DR_INT_BOOK_BRN ICTBS_DR_INT_DUE.BOOK_BRN%TYPE;
  
    EXP_CONV EXCEPTION;
  
    L_SYS_ACC_TYPE   ILTB_SYS_ACCOUNT.ACC_TYPE%TYPE;
    L_ACC_TYPE       ILTM_ACCOUNT.ACC_TYPE%TYPE;
    L_COUNT          NUMBER;
    L_BRANCH         ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACCOUNT        ILTB_SYS_ACCOUNT.ACCOUNT%TYPE;
    L_SWEEP_BASIS    ILTB_SYS_ACCOUNT.SWEEP_BASIS%TYPE;
    L_TMP_AMT        ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_PARENT_ACCOUNT ILTM_ACCOUNT.PARENT_ACCOUNT%TYPE;
    L_PARENT_ACC_BRN ILTM_ACCOUNT.PARENT_ACCOUNT_BRANCH%TYPE;
  
    L_PROD_REC ICTM_PR_INT%ROWTYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_EMPTY_CLUSTER_DATA GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    L_TRN_REF_NO            VARCHAR2(20);
  
    L_ILIQ_FLAG VARCHAR2(1);
  
    L_FATCA_EXT_CUSTOMER_SDE NUMBER := NULL;
    L_REFERRAL_TABLE         TATBS_FATCA_REFERRAL%ROWTYPE;
    L_REFERRAL_NEEDED        BOOLEAN := FALSE;
    L_ERR_CODE               ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM              VARCHAR2(255);
  
    L_FATCA_AUDIT_LOG  TATBS_FATCA_AUDIT_LOG%ROWTYPE;
    L_ACCOUNT_CLASS    STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_FATCA_AUDIT_REQD BOOLEAN := FALSE;
  
    L_SYS_ACCOUNT_REC ILTB_SYS_ACCOUNT%ROWTYPE;
    L_BOOL            BOOLEAN := FALSE;
    L_COUNT_2         NUMBER := 0;
  
    CURSOR C_CHILD_SYS_ACC(P_HDR_BRANCH ILTB_SYS_ACCOUNT.POOL_HDR_SYS_ACC_BRN%TYPE,
                           P_HDR_ACC    ILTB_SYS_ACCOUNT.POOL_HDR_SYS_ACC%TYPE,
                           P_SYS_ACC    ILTB_SYS_ACCOUNT.SYSTEM_ACCOUNT%TYPE) IS
      SELECT *
        FROM ILTB_SYS_ACCOUNT
       WHERE POOL_HDR_SYS_ACC_BRN = P_HDR_BRANCH
         AND POOL_HDR_SYS_ACC = P_HDR_ACC
         AND CLOSURE_INDICATOR = 'N'
         AND SYSTEM_ACCOUNT <> P_SYS_ACC
         AND ACC_TYPE = 'C';
    L_LAST_LIQDT ICTB_ACC_PR.LAST_LIQ_DT%TYPE;
    L_RUN_DT     ICTB_ENTRIES_HISTORY.RUN_DATE%TYPE;
    L_COUNTER    NUMBER := 0;
    L_TEMP_AMT   STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    CURSOR C_ENTRIES(C_BRANCH_CODE ILTBS_SYS_ACCOUNT.BRANCH_CODE% TYPE,
                     C_ACCOUNT     ILTBS_SYS_ACCOUNT.ACCOUNT% TYPE,
                     P_AMT_TAG     ACTB_DAILY_LOG.AMOUNT_TAG%TYPE) IS
      SELECT *
        FROM ACTB_DAILY_LOG
       WHERE AC_BRANCH = C_BRANCH_CODE
         AND AC_NO = C_ACCOUNT
         AND VALUE_DT = GLOBAL.APPLICATION_DATE
         AND TRN_DT = GLOBAL.APPLICATION_DATE
         AND EVENT = 'ILIQ'
         AND AMOUNT_TAG = P_AMT_TAG
       ORDER BY AC_ENTRY_SR_NO;
    L_BAL          STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_AMT          ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_CHILD_AMT    ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_PROC_BRANCH  ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE;
    L_PROC_ACCOUNT ILTB_SYS_ACCOUNT.ACCOUNT%TYPE;
  
    L_AMOUNT             STTM_CUST_ACCOUNT.ACY_AVL_BAL%TYPE;
    L_STTM_ACCOUNT_CLASS STTMS_ACCOUNT_CLASS%ROWTYPE;
    PROCEDURE EMSG IS
    BEGIN
      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_ACCRUE->');
    END EMSG;
  BEGIN
    DBG('Start of pr_entries_liq');
    DBG('Processing for g_sttm_custacc.cust_no ' || G_STTM_CUSTACC.CUST_NO);
    LASTREC := TB_RACCR.LAST + 1;
    TB_BASIC_HOFF(1).EVENT := 'ILIQ';
    IF TBFRM.COUNT > 0 THEN
      DBG('tbfrm count is > 0 :' || TB_HOFF_CONS.COUNT);
      FIND_KEY(TB_PROD(I), R_PR);
      FIND_PROD_LOOKUP(TB_PROD(I), 'ILIQ', TB_LOOKUP);
      IF TB_LOOKUP.COUNT > 0 THEN
        DBG('Even lookup has some to post :' || TB_LOOKUP.COUNT);
        FOR K IN TB_LOOKUP.FIRST .. TB_LOOKUP.LAST LOOP
          L_ACQUIRED_LCY_AMT := 0;
          L_ACQUIRED_FCY_AMT := 0;
          DBG('Entered here ' || K);
          L_DR_INT_GL := FALSE;
          BEGIN
          
            L_ILIQ_FLAG := NULL;
            IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
               (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
              GLOBAL.PR_RESET_SKIP_KERNEL;
              L_FN_CALL_ID := 2;
              L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
              L_TB_CLUSTER_DATA('tb_lookup(k).accrole') := TB_LOOKUP(K)
                                                           .ACCROLE;
              L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_LOOKUP(K)
                                                          .AMTTAG;
              L_TB_CLUSTER_DATA('l_iliq_flag') := L_ILIQ_FLAG;
            
              L_TB_CLUSTER_DATA('tb_lookup(k).drcrind') := TB_LOOKUP(K)
                                                           .DRCRIND;
              L_TB_CLUSTER_DATA('tb_lookup(k).account') := TB_LOOKUP(K)
                                                           .ACCOUNT;
              L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
              L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
              L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
            
              ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                I,
                                                TBFRM,
                                                L_FN_CALL_ID,
                                                L_TB_CLUSTER_DATA);
            
              L_ILIQ_FLAG := L_TB_CLUSTER_DATA('l_iliq_flag');
              TB_LOOKUP(K).ACCOUNT := L_TB_CLUSTER_DATA('tb_lookup(k).account');
            END IF;
            DBG('l_iliq_flag: ' || L_ILIQ_FLAG);
          
            IF NOT GLOBAL.G_SKIP_KERNEL THEN
            
              IF (NVL(L_ILIQ_FLAG, 'x') = 'Y') OR
                 ((SUBSTR(TB_LOOKUP(K).ACCROLE,
                          
                          INSTR(TB_LOOKUP(K).ACCROLE, '-', 1, 1) + 1,
                          4) IN ('BOOK', 'TEXP') AND
                 PKG_LIQ_NETTING = 'Y') OR PKG_LIQ_NETTING = 'N') THEN
                FRM_NO := TO_NUMBER(SUBSTR(TB_LOOKUP(K).ACCROLE,
                                           INSTR(TB_LOOKUP(K).ACCROLE,
                                                 '-',
                                                 -1) + 1));
                DUMMY := TBFRM(FRM_NO).LCY_AMT;
                TB_HOFF(K) := TB_BASIC_HOFF(1);
                REF := TB_BRN(I) || TB_PROD(I) || TB_CCY(I) ||
                       LPAD(FRM_NO, 6, '0');
              
                TB_HOFF(K).AC_BRANCH := TB_BRN(I);
                TB_HOFF(K).TRN_REF_NO := REF;
                TB_HOFF(K).DRCR_IND := TB_LOOKUP(K).DRCRIND;
                TB_HOFF(K).TRN_CODE := TB_LOOKUP(K).TRNCODE;
                TB_HOFF(K).AMOUNT_TAG := TB_LOOKUP(K).AMTTAG;
                TB_HOFF(K).MIS_HEAD := TB_LOOKUP(K).MIS_HEAD;
                TB_HOFF(K).NETTING_IND := TB_LOOKUP(K).NETIND;
              
                IF DEFR_CASE THEN
                
                  DBG('inside defr case');
                  DBG('tb_next_liq_dt (i)---->' || TB_NEXT_LIQ_DT(I));
                  DBG('tb_last_liq_dt (i)--->' || TB_LAST_LIQ_DT(I));
                  DBG('p_dt--->' || P_DT);
                
                  IF NVL(TB_NEXT_LIQ_DT(I), P_DT) < P_DT THEN
                    TB_HOFF(K).VALUE_DT := NVL(TB_NEXT_LIQ_DT(I) + 1, P_DT);
                    DBG('tb_hoff (k).value_dt--->' || TB_HOFF(K).VALUE_DT);
                  ELSE
                    TB_HOFF(K).VALUE_DT := NVL(TB_LAST_LIQ_DT(I) + 1, P_DT);
                    DBG('tb_hoff (k).value_dt--->' || TB_HOFF(K).VALUE_DT);
                  END IF;
                
                  DBG('g_sttm_custacc.mudarabah_accounts' ||
                      G_STTM_CUSTACC.MUDARABAH_ACCOUNTS);
                  IF G_STTM_CUSTACC.MUDARABAH_ACCOUNTS = 'Y' THEN
                    SELECT MAX(PC_START_DATE)
                      INTO TB_HOFF(K).VALUE_DT
                      FROM STTM_PERIOD_CODES
                     WHERE PC_START_DATE <= GLOBAL.APPLICATION_DATE;
                  END IF;
                  DBG('Final Value Date--->' || TB_HOFF(K).VALUE_DT);
                
                ELSE
                  TB_HOFF(K).VALUE_DT := P_DT + 1;
                END IF;
              
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                
                  L_FN_CALL_ID      := 5;
                  L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
                
                  L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
                  L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
                  L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
                  L_TB_CLUSTER_DATA('l_value_dt') := TB_HOFF(K).VALUE_DT;
                  L_TB_CLUSTER_DATA('l_book_acc') := L_BOOK_ACC;
                
                  L_TB_CLUSTER_DATA('l_book_brn') := L_BOOK_BRN;
                  L_TB_CLUSTER_DATA('l_book_ccy') := L_BOOK_CCY;
                  L_TB_CLUSTER_DATA('frm_no') := FRM_NO;
                  L_TB_CLUSTER_DATA('tb_lookup(k).account') := TB_LOOKUP(K)
                                                               .ACCOUNT;
                
                  ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                    I,
                                                    TBFRM,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA);
                  TB_HOFF(K).VALUE_DT := L_TB_CLUSTER_DATA('l_value_dt');
                  L_BOOK_ACC := L_TB_CLUSTER_DATA('l_book_acc');
                
                  L_BOOK_BRN := L_TB_CLUSTER_DATA('l_book_brn');
                  L_BOOK_CCY := L_TB_CLUSTER_DATA('l_book_ccy');
                
                END IF;
              
                TB_HOFF(K).RELATED_CUSTOMER := G_STTM_CUSTACC.CUST_NO;
              
                IF
                
                 TB_SYS_AC_LEVEL.COUNT <> 0 THEN
                  TB_HOFF(K).RELATED_ACCOUNT := G_ICTM_ACC.ACC;
                
                ELSE
                  TB_HOFF(K).RELATED_ACCOUNT := TB_ACC(I);
                END IF;
                DBG('tb_hoff(k).related_account-->' || TB_HOFF(K)
                    .RELATED_ACCOUNT);
              
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                  L_FN_CALL_ID := 1;
                  L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                  L_TB_CLUSTER_DATA('tb_hoff(k).related_reference') := TB_HOFF(K)
                                                                       .RELATED_REFERENCE;
                  L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                  L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                  L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                  ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                    I,
                                                    TBFRM,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA);
                  TB_HOFF(K).RELATED_REFERENCE := L_TB_CLUSTER_DATA('tb_hoff(k).related_reference');
                END IF;
              
                IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                   (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                  L_FN_CALL_ID := 9;
                  IF K = TB_LOOKUP.FIRST THEN
                    DBG('entered if for trn_ref_no');
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    L_TB_CLUSTER_DATA('l_trn_ref_no') := NULL;
                    L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                    L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                    L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                    L_TB_CLUSTER_DATA('l_value_dt') := GLOBAL.APPLICATION_DATE;
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                      I,
                                                      TBFRM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
                    IF L_TB_CLUSTER_DATA.EXISTS('l_trn_ref_no') THEN
                      L_TRN_REF_NO := L_TB_CLUSTER_DATA('l_trn_ref_no');
                    END IF;
                  END IF;
                  IF L_TRN_REF_NO IS NOT NULL THEN
                    DBG('the value is  ' || L_TRN_REF_NO);
                    TB_HOFF(K).TRN_REF_NO := L_TRN_REF_NO;
                    DBG('assigned the reference number ' || TB_HOFF(K)
                        .TRN_REF_NO);
                  END IF;
                END IF;
              
                DBG('tb_lookup(k).account --> ' || TB_LOOKUP(K).ACCOUNT);
              
                IF TB_LOOKUP(K).ACCOUNT = 'USERINPUT' THEN
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 4;
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    L_TB_CLUSTER_DATA('tb_hoff(k).trn_code') := TB_HOFF(K)
                                                                .TRN_CODE;
                    L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                    L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                    L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                      I,
                                                      TBFRM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
                    TB_HOFF(K).TRN_CODE := L_TB_CLUSTER_DATA('tb_hoff(k).trn_code');
                  END IF;
                  DBG('test trn_code' || TB_HOFF(K).TRN_CODE);
                
                  IF ICPKS_BOD.G_FROMBOD THEN
                    DBG('the call is from icbod');
                    IF ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' AND
                       ICPKS_BOD.UNCLAIMED_PROCESS = 'N' THEN
                      TB_HOFF(K).AC_NO := ICPKS_BOD.PKG_UNCLAIMED_INT_GL;
                    ELSIF ICPKS_BOD.PKG_ICTM_ACC.RD_MOVE_MAT_TO_UNCLAIMED = 'Y' AND
                          ICPKS_BOD.UNCLAIMED_PROCESS = 'N' THEN
                      TB_HOFF(K).AC_NO := ICPKS_BOD.PKG_UNCLAIMED_MAT_GL;
                    ELSE
                      DBG('Our Case should come here Raju ' || L_BOOK_ACC);
                      TB_HOFF(K).AC_NO := L_BOOK_ACC;
                    END IF;
                  ELSE
                    DBG('Not g_frombod : ' || L_BOOK_ACC);
                    TB_HOFF(K).AC_NO := L_BOOK_ACC;
                  END IF;
                  TB_HOFF(K).AC_BRANCH := NVL(L_BOOK_BRN, TB_BRN(I));
                  L_CCY := NVL(L_BOOK_CCY, TB_CCY(I));
                  TB_HOFF(K).AC_CCY := L_CCY;
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 11;
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    L_TB_CLUSTER_DATA('tb_hoff(k).trn_code') := TB_HOFF(K)
                                                                .TRN_CODE;
                    L_TB_CLUSTER_DATA('tb_prod(i)') := TB_PROD(I);
                    L_TB_CLUSTER_DATA('tb_acc(i)') := TB_ACC(I);
                    L_TB_CLUSTER_DATA('tb_brn(i)') := TB_BRN(I);
                    L_TB_CLUSTER_DATA('temp_hoff(sr).drcr_ind') := TB_HOFF(K)
                                                                   .DRCR_IND;
                    L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_HOFF(K)
                                                                .AMOUNT_TAG;
                    L_TB_CLUSTER_DATA('tbfrm(frm_no).acquired_amt') := TBFRM(FRM_NO)
                                                                       .ACQUIRED_AMT;
                    L_TB_CLUSTER_DATA('temp_hoff(sr).ac_branch') := TB_HOFF(K)
                                                                    .AC_BRANCH;
                    L_TB_CLUSTER_DATA('temp_hoff(sr).ac_no') := TB_HOFF(K)
                                                                .AC_NO;
                    L_TB_CLUSTER_DATA('tbfrm(frm_no).amt') := TBFRM(FRM_NO).AMT;
                    L_TB_CLUSTER_DATA('l_cust') := TB_HOFF(K)
                                                   .RELATED_CUSTOMER;
                  
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                      I,
                                                      TBFRM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).ac_no') THEN
                      TB_HOFF(K).AC_NO := L_TB_CLUSTER_DATA('temp_hoff(sr).ac_no');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_gl') THEN
                      IF L_TB_CLUSTER_DATA('l_dr_int_gl') = 'TRUE' THEN
                        L_DR_INT_GL := TRUE;
                      ELSE
                        L_DR_INT_GL := FALSE;
                      END IF;
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_using_recv') THEN
                      L_DR_INT_USING_RECV := L_TB_CLUSTER_DATA('l_dr_int_using_recv');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_days') THEN
                      L_DR_INT_DAYS := L_TB_CLUSTER_DATA('l_dr_int_days');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_notice') THEN
                      L_DR_INT_NOTICE := L_TB_CLUSTER_DATA('l_dr_int_notice');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_recv_gl') THEN
                      L_DR_INT_RECV_GL := L_TB_CLUSTER_DATA('l_dr_int_recv_gl');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_collateral_line') THEN
                      IF L_TB_CLUSTER_DATA('l_collateral_line') = 'TRUE' THEN
                        L_COLLATERAL_LINE := TRUE;
                      ELSE
                        L_COLLATERAL_LINE := FALSE;
                      END IF;
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('od_int_revr') THEN
                      L_PROD_REC.OD_INT_REVR := L_TB_CLUSTER_DATA('od_int_revr');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_book_acc') THEN
                      L_DR_INT_BOOK_ACC := L_TB_CLUSTER_DATA('l_dr_int_book_acc');
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_book_brn') THEN
                      L_DR_INT_BOOK_BRN := L_TB_CLUSTER_DATA('l_dr_int_book_brn');
                    END IF;
                  END IF;
                  IF NOT GLOBAL.G_SKIP_KERNEL THEN
                  
                    IF (TB_HOFF(K)
                       .DRCR_IND = 'D' AND
                        (TB_HOFF(K)
                        .AMOUNT_TAG = 'ILIQ' OR
                         (TB_HOFF(K).AMOUNT_TAG IN ('IACQUIRED', 'INT_PADJ') AND TBFRM(FRM_NO)
                         .ACQUIRED_AMT > 0))) THEN
                      ICPKSS_UTIL. PR_GET_ICTM_PR_INT(TB_PROD(I),
                                                      L_PROD_REC);
                    END IF;
                  
                    IF (TB_HOFF(K)
                       .DRCR_IND = 'D' AND
                        (TB_HOFF(K)
                        .AMOUNT_TAG = 'ILIQ' OR
                         (TB_HOFF(K).AMOUNT_TAG IN ('IACQUIRED', 'INT_PADJ') AND TBFRM(FRM_NO)
                         .ACQUIRED_AMT > 0)) AND G_ONLIQ_FLAG = 'N') THEN
                      DBG('here for ' || TB_HOFF(K).AC_NO);
                      L_DR_INT_GL := FALSE;
                    
                      L_COLLATERAL_LINE := FALSE;
                    
                      IF NOT CVPKSS_UTILS.GET_STTB_ACC(TB_HOFF  (K).AC_BRANCH,
                                                       TB_HOFF  (K).AC_NO,
                                                       L_ACC_REC) THEN
                        DBG('Error while retrieving account details for ' || TB_HOFF(K)
                            .AC_BRANCH || '~' || TB_HOFF(K).AC_NO);
                        ERR_CODE := 'IC-DRINT01';
                        EMSG;
                      END IF;
                      IF L_ACC_REC.AC_OR_GL = 'A' THEN
                        DBG('Account class is ' || L_ACC_REC.AC_CLASS);
                      
                        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                           (CSPKS_REQ_GLOBAL.P_CUSTOM,
                            CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                          L_FN_CALL_ID := 10;
                          L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                          L_TB_CLUSTER_DATA('l_account_class') := L_ACC_REC.AC_CLASS;
                          L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
                          L_TB_CLUSTER_DATA('l_cust') := TB_HOFF(K)
                                                         .RELATED_CUSTOMER;
                          L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
                          ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                            I,
                                                            TBFRM,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA);
                        
                          IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_using_recv') THEN
                            L_DR_INT_USING_RECV := L_TB_CLUSTER_DATA('l_dr_int_using_recv');
                          END IF;
                          IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_using_recv') THEN
                            L_DR_INT_DAYS := L_TB_CLUSTER_DATA('l_dr_int_days');
                          END IF;
                          IF L_TB_CLUSTER_DATA.EXISTS('l_dr_int_notice') THEN
                            L_DR_INT_NOTICE := L_TB_CLUSTER_DATA('l_dr_int_notice');
                          END IF;
                        END IF;
                        GLOBAL.PR_RESET_SKIP_KERNEL;
                      
                        L_STTM_ACCOUNT_CLASS := CSPKS_FUNCTION_CACHE.FN_GET_ACC_CLASS_REC_FRC(L_ACC_REC.AC_CLASS);
                        L_DR_INT_USING_RECV  := NVL(L_STTM_ACCOUNT_CLASS.DR_INT_USING_RECV,
                                                    'N');
                        L_DR_INT_DAYS        := NVL(L_STTM_ACCOUNT_CLASS.DR_INT_LIQD_DAYS,
                                                    0);
                        DBG('l_dr_int_using_recv after cache: ' ||
                            L_DR_INT_USING_RECV);
                        DBG('l_dr_int_days after cache: ' || L_DR_INT_DAYS);
                      
                        DBG('l_dr_int_using_recv : ' ||
                            L_DR_INT_USING_RECV);
                      
                        IF L_DR_INT_USING_RECV = 'Y' AND L_DR_INT_DAYS = 0 THEN
                          IF NOT
                              ACPKSS_MISC.FN_GETAVLBAL(TB_HOFF (K).AC_BRANCH,
                                                       TB_HOFF (K).AC_NO,
                                                       L_AMOUNT,
                                                       'Y') THEN
                            DBG('Failed in Call to fn_GetAvlBal for ' || TB_HOFF(K)
                                .AC_NO);
                          END IF;
                          DBG('Account balance after Call to fn_GetAvlBal : ' ||
                              L_AMOUNT);
                          DBG('tbfrm(frm_no).amt : ' || TBFRM(FRM_NO).AMT);
                          IF L_AMOUNT >= TBFRM(FRM_NO).AMT THEN
                            L_DR_INT_USING_RECV := 'N';
                          END IF;
                        END IF;
                      
                        SELECT COUNT(*)
                          INTO L_LINE_COUNT
                          FROM STTMS_CUST_ACCOUNT_LINKAGES
                         WHERE CUST_AC_NO = L_ACC_REC.AC_GL_NO
                           AND BRANCH_CODE = L_ACC_REC.BRANCH_CODE
                           AND LINKAGE_TYPE = 'F';
                      
                      END IF;
                    
                      DBG('L_LINE_COUNT is ' || L_LINE_COUNT);
                    
                      IF L_LINE_COUNT > 0 THEN
                        L_COLLATERAL_LINE := TRUE;
                      END IF;
                    
                      DBG('l_dr_int_using_recv is ' || L_DR_INT_USING_RECV);
                      IF L_DR_INT_USING_RECV = 'Y' THEN
                      
                        L_DR_INT_RECV_GL := ICPKS_CACHE.FN_GET_PR_INT_FRC(TB_PROD(I))
                                            .DR_INT_RECV_GL;
                      
                        DBG('Dr interest receivable GL is ' ||
                            L_DR_INT_RECV_GL);
                        IF L_DR_INT_RECV_GL IS NOT NULL THEN
                          L_DR_INT_BOOK_ACC := TB_HOFF(K).AC_NO;
                          L_DR_INT_BOOK_BRN := TB_HOFF(K).AC_BRANCH;
                          TB_HOFF(K).AC_NO := L_DR_INT_RECV_GL;
                          L_DR_INT_GL := TRUE;
                        ELSE
                          DBG('Dr interest receivable GL is NULL for product ' ||
                              TB_PROD(I));
                          DBG('Passing entries into A/c -->' || TB_HOFF(K)
                              .AC_NO);
                        END IF;
                      END IF;
                    END IF;
                  
                  ELSE
                    GLOBAL.PR_RESET_SKIP_KERNEL;
                  END IF;
                
                ELSE
                
                  TB_HOFF(K).AC_NO := TB_LOOKUP(K).ACCOUNT;
                  TB_HOFF(K).AC_BRANCH := TB_BRN(I);
                  L_CCY := TB_CCY(I);
                  TB_HOFF(K).AC_CCY := L_CCY;
                  DBG('currency for gl got as' || L_CCY || '~' || FRM_NO);
                  DBG('paise hai kya??' || '~' || TBFRM(FRM_NO).BOOK_AMT || '~' || TBFRM(FRM_NO).AMT);
                END IF;
                DBG('HERE accouting ' || TB_HOFF(K).AC_NO || '~' || TB_HOFF(K)
                    .AC_CCY);
              
                DBG('sys ac level count ' || TB_SYS_AC_LEVEL.COUNT);
                DBG('product level il type value is ' || R_PR.IL_TYPE);
              
                DBG('g_onliq_flag value here is --->' || G_ONLIQ_FLAG);
              
                IF TB_SYS_AC_LEVEL.COUNT <> 0 AND G_ONLIQ_FLAG <> 'Y' THEN
                
                  DBG('going to select the ACC TYPE for ' || TB_ACC(I) || ';' ||
                      TB_BRN(I));
                  BEGIN
                    SELECT BRANCH_CODE, ACCOUNT, ACC_TYPE, SWEEP_BASIS
                      INTO L_BRANCH,
                           L_ACCOUNT,
                           L_SYS_ACC_TYPE,
                           L_SWEEP_BASIS
                      FROM ILTB_SYS_ACCOUNT
                     WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                       AND SYSTEM_ACCOUNT = TB_ACC(I);
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('selection of physical account failed- ' ||
                          SQLERRM);
                      L_BRANCH       := NULL;
                      L_ACCOUNT      := NULL;
                      L_SYS_ACC_TYPE := NULL;
                      L_SWEEP_BASIS  := NULL;
                  END;
                  IF L_BRANCH IS NOT NULL AND L_ACCOUNT IS NOT NULL AND
                     L_SYS_ACC_TYPE IS NOT NULL THEN
                    BEGIN
                      SELECT ACC_TYPE
                        INTO L_ACC_TYPE
                        FROM ILTM_ACCOUNT
                       WHERE BRANCH_CODE = L_BRANCH
                         AND ACCOUNT = L_ACCOUNT
                            
                         AND PARENT_ACCOUNT = ACCOUNT
                            
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A';
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('selection of acc type failed- ' || SQLERRM);
                        L_ACC_TYPE := NULL;
                    END;
                  END IF;
                  DBG('l_acC_type--->' || L_SYS_ACC_TYPE);
                  IF NVL(L_ACC_TYPE, 'X') = 'P' THEN
                  
                    IF NOT FN_LIQ_ADJUSTMENT(TB_BRN(I),
                                             TB_ACC(I),
                                             L_BRANCH,
                                             L_ACCOUNT,
                                             TBFRM(FRM_NO).AMT,
                                             TB_HOFF(K).AMOUNT_TAG) THEN
                      DBG('fAILED IN fn_liq_adjustment FOR THE ACCOUNT -' ||
                          TB_ACC(I));
                    END IF;
                  
                  END IF;
                
                  IF NVL(L_SYS_ACC_TYPE, 'X') = 'P' THEN
                  
                    IF NVL(L_SWEEP_BASIS, 'X') = 'V' THEN
                      SELECT COUNT(*)
                        INTO L_COUNT
                        FROM ILTB_VD_CONTRIBUTIONS
                       WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                         AND SYSTEM_ACCOUNT = TB_ACC(I)
                         AND CONTRIBUTION <> 0
                         AND VALUE_DATE BETWEEN (TB_LAST_LIQ_DT(I) + 1) AND
                             TB_NEXT_LIQ_DT(I);
                    ELSIF NVL(L_SWEEP_BASIS, 'X') = 'B' THEN
                      SELECT COUNT(*)
                        INTO L_COUNT
                        FROM ILTB_BD_CONTRIBUTIONS
                       WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                         AND SYSTEM_ACCOUNT = TB_ACC(I)
                         AND CONTRIBUTION <> 0
                         AND BOOK_DATE BETWEEN (TB_LAST_LIQ_DT(I) + 1) AND
                             TB_NEXT_LIQ_DT(I);
                    END IF;
                  
                    IF L_COUNT > 0 THEN
                    
                      G_TB_SYS_ACCTS.DELETE(L_ACCOUNT || L_BRANCH);
                      G_TB_SYS_ACCTS_TAX.DELETE(L_ACCOUNT || L_BRANCH);
                    
                      DBG('deleted the physical account and its childs since its own contribution is not 0 for the period');
                    
                    END IF;
                  
                  END IF;
                
                END IF;
              
                IF TB_SYS_AC_LEVEL.COUNT <> 0 AND R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                  .ACCOUNT <> 'USERINPUT' THEN
                  DBG('going to select the booking account for ' ||
                      TB_ACC(I) || ';' || TB_BRN(I));
                  BEGIN
                    SELECT BOOKING_ACC, BOOKING_ACC_CCY, BOOKING_ACC_BRANCH
                      INTO TB_HOFF(K).AC_NO,
                           TB_HOFF(K).AC_CCY,
                           TB_HOFF(K).AC_BRANCH
                      FROM ILTBS_SYS_ACCOUNT
                    
                     WHERE SYSTEM_ACCOUNT_BRANCH =
                           (SELECT HEADER_ACC_BRN
                              FROM ILTBS_SYS_ACCOUNT
                             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                               AND SYSTEM_ACCOUNT = TB_ACC(I))
                       AND SYSTEM_ACCOUNT =
                           (SELECT POOL_HDR_SYS_ACC
                              FROM ILTBS_SYS_ACCOUNT
                             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                               AND SYSTEM_ACCOUNT = TB_ACC(I)
                                  
                               AND ACC_TYPE <> 'H');
                  
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DBG('In the W-N-D of the select of book account');
                      DBG('This is because we should not change the GL for the Parent acount');
                      TB_HOFF(K).AC_BRANCH := G_STTM_CUSTACC.BRANCH_CODE;
                    
                      DBG('assign account branch ' || TB_HOFF(K).AC_BRANCH);
                  END;
                
                  DBG('tb_hoff(k) .ac_no--' || TB_HOFF(K).AC_NO);
                  DBG('tb_hoff(k) .ac_ccy--' || TB_HOFF(K).AC_CCY);
                  DBG('tb_hoff(k) .ac_branch--' || TB_HOFF(K).AC_BRANCH);
                
                  BEGIN
                    SELECT CUST_NO
                      INTO TB_HOFF(K).RELATED_CUSTOMER
                      FROM STTBS_ACCOUNT
                     WHERE AC_GL_NO = TB_HOFF(K).AC_NO
                       AND BRANCH_CODE = TB_HOFF(K).AC_BRANCH;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('In W-O-T of the booking account select');
                      NULL;
                  END;
                
                  L_CCY := TB_HOFF(K).AC_CCY;
                
                  DBG('onliq flag is --->' || G_ONLIQ_FLAG);
                  DBG('amt is m --->' || TBFRM(FRM_NO).AMT);
                  IF G_ONLIQ_FLAG = 'Y' AND TBFRM(FRM_NO).AMT <> 0 THEN
                    DBG('this is a online liquidation case--->');
                    L_TEMP_AMT := NULL;
                    BEGIN
                      SELECT *
                        INTO L_SYS_ACCOUNT_REC
                        FROM ILTB_SYS_ACCOUNT
                       WHERE BRANCH_CODE = TB_HOFF(K).AC_BRANCH
                         AND ACCOUNT = TB_HOFF(K).AC_NO
                         AND ACC_TYPE = 'P'
                         AND CLOSURE_INDICATOR = 'N';
                      L_BOOL := TRUE;
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('In W-O-T of the booking account select');
                        L_BOOL := FALSE;
                    END;
                    DBG('l_sys_account_rec.system_account-->' ||
                        L_SYS_ACCOUNT_REC.SYSTEM_ACCOUNT);
                    DBG('l_sys_account_rec.sweep_basis-->' ||
                        L_SYS_ACCOUNT_REC.SWEEP_BASIS);
                    IF L_BOOL THEN
                      IF NVL(L_SYS_ACCOUNT_REC.SWEEP_BASIS, 'X') = 'V' THEN
                        SELECT COUNT(*)
                          INTO L_COUNT_2
                          FROM ILTB_VD_CONTRIBUTIONS
                         WHERE SYSTEM_ACCOUNT_BRANCH =
                               L_SYS_ACCOUNT_REC.SYSTEM_ACCOUNT_BRANCH
                           AND SYSTEM_ACCOUNT =
                               L_SYS_ACCOUNT_REC.SYSTEM_ACCOUNT
                           AND CONTRIBUTION <> 0
                           AND VALUE_DATE BETWEEN (TB_LAST_LIQ_DT(I) + 1) AND
                               TB_NEXT_LIQ_DT(I);
                      ELSIF NVL(L_SYS_ACCOUNT_REC.SWEEP_BASIS, 'X') = 'B' THEN
                        SELECT COUNT(*)
                          INTO L_COUNT_2
                          FROM ILTB_BD_CONTRIBUTIONS
                         WHERE SYSTEM_ACCOUNT_BRANCH =
                               L_SYS_ACCOUNT_REC.SYSTEM_ACCOUNT_BRANCH
                           AND SYSTEM_ACCOUNT =
                               L_SYS_ACCOUNT_REC.SYSTEM_ACCOUNT
                           AND CONTRIBUTION <> 0
                           AND BOOK_DATE BETWEEN (TB_LAST_LIQ_DT(I) + 1) AND
                               TB_NEXT_LIQ_DT(I);
                      END IF;
                    
                      DBG('l_count_2 value here is--->' || L_COUNT_2);
                      IF L_COUNT_2 = 0 THEN
                        BEGIN
                          SELECT DECODE(TB_HOFF(K).AC_CCY,
                                        LCY,
                                        NVL(LCY_AMOUNT, 0),
                                        NVL(FCY_AMOUNT, 0))
                            INTO L_AMT
                            FROM ACTB_DAILY_LOG
                           WHERE AC_BRANCH = TB_HOFF(K).AC_BRANCH
                             AND AC_NO = TB_HOFF(K).AC_NO
                             AND EVENT = 'ILIQ'
                             AND RELATED_ACCOUNT =
                                 (SELECT PARENT_ACCOUNT
                                    FROM ILTM_ACCOUNT
                                   WHERE BRANCH_CODE = TB_HOFF(K).AC_BRANCH
                                     AND ACCOUNT = TB_HOFF(K).AC_NO
                                     AND RECORD_STAT = 'O'
                                     AND AUTH_STAT = 'A'
                                     AND ACC_TYPE = 'C')
                             AND AMOUNT_TAG = TB_HOFF(K).AMOUNT_TAG;
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            BEGIN
                            
                              SELECT DECODE(TB_HOFF(K).AC_CCY,
                                            LCY,
                                            NVL(LCY_AMOUNT, 0),
                                            NVL(FCY_AMOUNT, 0))
                                INTO L_AMT
                                FROM ACTB_DAILY_LOG
                               WHERE AC_BRANCH = TB_HOFF(K).AC_BRANCH
                                 AND AC_NO = TB_HOFF(K).AC_NO
                                 AND EVENT = 'ILIQ'
                                 AND RELATED_ACCOUNT =
                                     (SELECT PARENT_ACCOUNT
                                        FROM ILTM_ACCOUNT
                                       WHERE BRANCH_CODE = TB_HOFF(K)
                                            .AC_BRANCH
                                         AND ACCOUNT = TB_HOFF(K).AC_NO
                                         AND RECORD_STAT = 'O'
                                         AND AUTH_STAT = 'A'
                                         AND ACC_TYPE = 'P')
                                 AND AMOUNT_TAG = TB_HOFF(K).AMOUNT_TAG;
                            EXCEPTION
                              WHEN OTHERS THEN
                                DBG('other exception' || SQLERRM);
                                L_AMT := NULL;
                            END;
                          WHEN OTHERS THEN
                            DBG('other exception' || SQLERRM);
                            L_AMT := NULL;
                        END;
                        DBG('l_amt value here is--->' || L_AMT);
                        DBG('here values are--->' || TB_HOFF(K).AC_BRANCH || '~' || TB_HOFF(K)
                            .AC_NO || '~' || TB_HOFF(K).AMOUNT_TAG);
                      
                        IF NOT FN_ONLIQ_ADJUSTMENT(TB_HOFF(K).AC_BRANCH,
                                                   TB_HOFF(K).AC_NO,
                                                   L_AMT,
                                                   TB_HOFF(K).AMOUNT_TAG) THEN
                          DBG('fAILED IN fn_liq_adjustment FOR THE ACCOUNT -' ||
                              TB_ACC(I));
                        END IF;
                      
                        L_COUNTER := 0;
                        FOR L_SYS_ACC IN C_CHILD_SYS_ACC(L_SYS_ACCOUNT_REC.POOL_HDR_SYS_ACC_BRN,
                                                         L_SYS_ACCOUNT_REC.POOL_HDR_SYS_ACC,
                                                         TB_ACC(I)) LOOP
                          DBG('am inside C_CHILD_SYS_ACC loop');
                          BEGIN
                            SELECT DECODE(TB_HOFF(K).AC_CCY,
                                          LCY,
                                          NVL(LCY_AMOUNT, 0),
                                          NVL(FCY_AMOUNT, 0))
                              INTO L_CHILD_AMT
                              FROM ACTB_DAILY_LOG
                             WHERE AC_BRANCH = L_SYS_ACC.BRANCH_CODE
                               AND AC_NO = L_SYS_ACC.ACCOUNT
                               AND EVENT = 'ILIQ'
                               AND RELATED_ACCOUNT = TB_HOFF(K).AC_NO
                               AND AMOUNT_TAG = TB_HOFF(K).AMOUNT_TAG;
                          EXCEPTION
                            WHEN OTHERS THEN
                              DBG('in wot exp of l_child_amt' || SQLERRM);
                              L_CHILD_AMT := NULL;
                              L_COUNTER   := L_COUNTER + 1;
                          END;
                          DBG('childs liquidated amt-->' || L_CHILD_AMT || '~' ||
                              L_COUNTER);
                          IF L_CHILD_AMT IS NOT NULL THEN
                            IF NOT FN_FIND_LAST_CHILD_ONLIQ(TB_HOFF                        (K)
                                                            .AC_BRANCH,
                                                            TB_HOFF                        (K)
                                                            .AC_NO,
                                                            L_SYS_ACC.SYSTEM_ACCOUNT,
                                                            L_SYS_ACC.SYSTEM_ACCOUNT_BRANCH,
                                                            L_CHILD_AMT,
                                                            TB_HOFF                        (K)
                                                            .AMOUNT_TAG)
                            
                             THEN
                              DBG('Failed in call to fn_find_last_child');
                            END IF;
                          END IF;
                        
                        END LOOP;
                        DBG('counter value here is--->' || L_COUNTER);
                        IF L_COUNTER <> 0 THEN
                          DBG('this is not the last child');
                        ELSE
                          DBG('This account is the last child so liquidate all the amt from parent since parents contribution is 0');
                          BEGIN
                            SELECT BRANCH_CODE, ACCOUNT
                              INTO L_PROC_BRANCH, L_PROC_ACCOUNT
                              FROM ILTB_SYS_ACCOUNT
                             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                               AND SYSTEM_ACCOUNT = TB_ACC(I)
                               AND ACC_TYPE = 'C'
                               AND CLOSURE_INDICATOR = 'N';
                          EXCEPTION
                            WHEN OTHERS THEN
                              DBG('selection of physical account failed- ' ||
                                  SQLERRM);
                              L_PROC_BRANCH  := NULL;
                              L_PROC_ACCOUNT := NULL;
                          END;
                          DBG('l_proc_branch,l_proc_account--->' ||
                              L_PROC_BRANCH || '~' || L_PROC_ACCOUNT);
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                
                ELSIF TB_SYS_AC_LEVEL.COUNT <> 0 AND R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                     .ACCOUNT = 'USERINPUT' THEN
                  BEGIN
                    SELECT BOOKING_ACC
                      INTO TB_HOFF(K).RELATED_ACCOUNT
                      FROM ILTBS_SYS_ACCOUNT
                     WHERE SYSTEM_ACCOUNT_BRANCH =
                           (SELECT HEADER_ACC_BRN
                              FROM ILTBS_SYS_ACCOUNT
                             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                               AND SYSTEM_ACCOUNT = TB_ACC(I))
                       AND SYSTEM_ACCOUNT =
                           (SELECT POOL_HDR_SYS_ACC
                              FROM ILTBS_SYS_ACCOUNT
                             WHERE SYSTEM_ACCOUNT_BRANCH = TB_BRN(I)
                               AND SYSTEM_ACCOUNT = TB_ACC(I)
                               AND ACC_TYPE <> 'H');
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DBG('In the W-N-D of the select of book account');
                      DBG('This is because we should not change the GL for the Parent acount');
                      TB_HOFF(K).AC_BRANCH := G_STTM_CUSTACC.BRANCH_CODE;
                    
                      DBG('assign account branch ' || TB_HOFF(K).AC_BRANCH);
                  END;
                
                END IF;
                DBG('afterILM sys acc selection accouting' || TB_HOFF(K)
                    .AC_NO || '~' || TB_HOFF(K).AC_CCY || '~' || TB_HOFF(K)
                    .AC_BRANCH);
              
                IF TB_LOOKUP(K).AMTTAG IN ('IACQUIRED',
                               'TAX_ADJ',
                               'INT_PADJ',
                               'INT_NADJ',
                               'TAX_PADJ',
                               'TAX_NADJ') THEN
                  DBG(' I camee into iacquired case' || TBFRM(FRM_NO)
                      .ACQUIRED_AMT);
                  L_ACQUIRED_FCY_AMT := TBFRM(FRM_NO).ACQUIRED_AMT;
                
                  IF R_PR.IL_TYPE IS NOT NULL THEN
                    IF L_CCY <> TB_CCY(I) THEN
                      DBG('currencies are different ' || L_CCY || '~' ||
                          TB_CCY(I));
                      L_ACQUIRED_LCY_AMT := NULL;
                      L_RATE             := NULL;
                      IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                         TB_CCY(I),
                                                         L_CCY,
                                                         NVL(L_ACQUIRED_FCY_AMT,
                                                             0),
                                                         'Y',
                                                         L_ACQUIRED_LCY_AMT,
                                                         L_RATE,
                                                         ERR_CODE) THEN
                        EMSG;
                      
                        RAISE EXP_CONV;
                      END IF;
                      DBG('l_acquired_lcy_amt-->' || L_ACQUIRED_LCY_AMT || '~' ||
                          L_RATE);
                      L_ACQUIRED_FCY_AMT := L_ACQUIRED_LCY_AMT;
                    END IF;
                  END IF;
                
                  IF L_CCY <> LCY THEN
                    DBG('l_ccy not same as lcy ' || L_CCY || '~' || LCY);
                    L_ACQUIRED_LCY_AMT := NULL;
                    L_RATE             := NULL;
                  
                    IF TB_LOOKUP(K).ACCOUNT = 'USERINPUT' THEN
                      TB_HOFF(K).FCY_AMOUNT := NVL(TBFRM(FRM_NO)
                                                   .BOOK_ACQUIRED_AMT,
                                                   TBFRM(FRM_NO).ACQUIRED_AMT);
                    ELSE
                      TB_HOFF(K).FCY_AMOUNT := NVL(TBFRM(FRM_NO)
                                                   .ACQUIRED_AMT,
                                                   TBFRM(FRM_NO)
                                                   .BOOK_ACQUIRED_AMT);
                    END IF;
                  
                    TB_HOFF(K).LCY_AMOUNT := TBFRM(FRM_NO).LCY_ACQUIRED_AMT;
                    TB_HOFF(K).EXCH_RATE := NVL(TBFRM(FRM_NO).XRATE, 1);
                  
                  ELSE
                  
                    TB_HOFF(K).LCY_AMOUNT := TBFRM(FRM_NO).LCY_ACQUIRED_AMT;
                  
                    TB_HOFF(K).FCY_AMOUNT := NULL;
                    TB_HOFF(K).EXCH_RATE := NULL;
                  END IF;
                
                ELSE
                  DBG('This is not acquired case l_ccy :' || L_CCY ||
                      ' - ' || LCY);
                
                  L_TMP_AMT := NULL;
                
                  IF G_ONLIQ_FLAG <> 'Y' THEN
                    IF TB_SYS_AC_LEVEL.COUNT <> 0 AND R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                      .ACCOUNT <> 'USERINPUT' AND TB_HOFF(K)
                      .AMOUNT_TAG = 'ILIQ' THEN
                    
                      IF G_TB_SYS_ACCTS.EXISTS(TB_HOFF(K).AC_NO || TB_HOFF(K)
                                               .AC_BRANCH) THEN
                      
                        IF G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_CHILD_ACCTS.COUNT > 2 THEN
                        
                          DBG('tb_hoff(k).lcy_amount--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt--->' || TBFRM(FRM_NO).AMT);
                          IF NOT
                              FN_FIND_LAST_CHILD(TB_HOFF(K).AC_BRANCH,
                                                 TB_HOFF(K).AC_NO,
                                                 TB_ACC(I),
                                                 TB_BRN(I),
                                                 
                                                 TBFRM  (FRM_NO).AMT,
                                                 TB_HOFF(K).AMOUNT_TAG)
                          
                           THEN
                            DBG('Failed in call to fn_find_last_child');
                          END IF;
                        
                        ELSIF G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_CHILD_ACCTS.COUNT = 2 THEN
                        
                          DBG('In else part-->');
                          DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                        
                          IF (G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS(G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS.FIRST)
                             .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS(G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS.LAST)
                             .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                            .AMT <> 0 THEN
                          
                            DBG('changing the amt here');
                            L_TMP_AMT := G_TB_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                                         .P_CONT_AMT;
                          END IF;
                        
                        END IF;
                      END IF;
                    
                    ELSIF TB_SYS_AC_LEVEL.COUNT <> 0 AND R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                         .ACCOUNT <> 'USERINPUT' AND TB_HOFF(K)
                         .AMOUNT_TAG = 'TAX' THEN
                    
                      IF G_TB_SYS_ACCTS_TAX.EXISTS(TB_HOFF(K).AC_NO || TB_HOFF(K)
                                                   .AC_BRANCH) THEN
                      
                        IF G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_CHILD_ACCTS_TAX.COUNT > 2 THEN
                        
                          DBG('tb_hoff(k).lcy_amount--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt--->' || TBFRM(FRM_NO).AMT);
                          IF NOT
                              FN_FIND_LAST_CHILD(TB_HOFF(K).AC_BRANCH,
                                                 TB_HOFF(K).AC_NO,
                                                 TB_ACC(I),
                                                 TB_BRN(I),
                                                 TBFRM(FRM_NO).AMT,
                                                 TB_HOFF(K).AMOUNT_TAG)
                          
                           THEN
                            DBG('Failed in call to fn_find_last_child');
                          END IF;
                        ELSIF G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_CHILD_ACCTS_TAX.COUNT = 2 THEN
                          DBG('In else part-->');
                          DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                          IF (G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS_TAX(G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS_TAX.FIRST)
                             .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS_TAX(G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS_TAX.LAST)
                             .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                            .AMT <> 0 THEN
                          
                            DBG('changing the amt here');
                            L_TMP_AMT := G_TB_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_CHILD_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                                         .P_CONT_AMT;
                          END IF;
                        
                        END IF;
                      END IF;
                    
                    END IF;
                  
                    DBG('am here inside onliq flag Y condition');
                  ELSIF G_ONLIQ_FLAG = 'Y' AND TB_SYS_AC_LEVEL.COUNT <> 0 AND
                        R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                       .ACCOUNT <> 'USERINPUT' THEN
                    L_TEMP_AMT := NULL;
                    IF TB_HOFF(K).AMOUNT_TAG = 'ILIQ' THEN
                      IF G_TB_ONL_SYS_ACCTS.EXISTS(TB_HOFF(K).AC_NO || TB_HOFF(K)
                                                   .AC_BRANCH) THEN
                      
                        IF G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_ONL_CHILD_ACCTS.COUNT = 2 THEN
                          DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                        
                          IF (G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS(G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS.FIRST)
                             .P_ACCOUNT = L_PROC_ACCOUNT OR G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS(G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS.LAST)
                             .P_ACCOUNT = L_PROC_ACCOUNT) AND TBFRM(FRM_NO)
                            .AMT <> 0 THEN
                            DBG('changing the amt here');
                            L_TEMP_AMT := G_TB_ONL_SYS_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                                          .P_CONT_AMT;
                            DBG('l_temp_amt-->' || L_TEMP_AMT);
                          END IF;
                        
                        END IF;
                      END IF;
                    ELSIF TB_HOFF(K).AMOUNT_TAG = 'TAX' THEN
                      IF G_TB_ONL_SYS_ACCTS_TAX.EXISTS(TB_HOFF(K).AC_NO || TB_HOFF(K)
                                                       .AC_BRANCH) THEN
                      
                        IF G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                         .G_TB_ONL_CHILD_ACCTS_TAX.COUNT = 2 THEN
                          DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                              .LCY_AMOUNT);
                          DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                              .LCY_AMT);
                          DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                          IF (G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS_TAX(G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS_TAX.FIRST)
                             .P_ACCOUNT = L_PROC_ACCOUNT OR G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS_TAX(G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS_TAX.LAST)
                             .P_ACCOUNT = L_PROC_ACCOUNT) AND TBFRM(FRM_NO)
                            .AMT <> 0 THEN
                            DBG('changing the amt here');
                            L_TEMP_AMT := G_TB_ONL_SYS_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH).G_TB_ONL_CHILD_ACCTS_TAX(TB_HOFF(K).AC_NO || TB_HOFF(K).AC_BRANCH)
                                          .P_CONT_AMT;
                            DBG('l_temp_amt-->' || L_TEMP_AMT);
                          END IF;
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                  DBG('tb_lookup(k) .account--->' || TB_LOOKUP(K).ACCOUNT);
                  DBG('tb_sys_ac_level.COUNT--->' || TB_SYS_AC_LEVEL.COUNT);
                  DBG('r_pr.il_type--->' || R_PR.IL_TYPE);
                  DBG('tb_hoff(k).amount_tag--->' || TB_HOFF(K).AMOUNT_TAG);
                  IF TB_SYS_AC_LEVEL.COUNT <> 0 AND R_PR.IL_TYPE = '1' AND TB_LOOKUP(K)
                    .ACCOUNT = 'USERINPUT' THEN
                    DBG('am here inside--->');
                    BEGIN
                      SELECT PARENT_ACCOUNT, PARENT_ACCOUNT_BRANCH
                        INTO L_PARENT_ACCOUNT, L_PARENT_ACC_BRN
                        FROM ILTM_ACCOUNT
                       WHERE ACCOUNT = TB_HOFF(K).AC_NO
                         AND BRANCH_CODE = TB_HOFF(K).AC_BRANCH
                         AND RECORD_STAT = 'O'
                         AND AUTH_STAT = 'A'
                         AND ACC_TYPE = 'C';
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        DBG('In the W-N-D of the select of parent account');
                        L_PARENT_ACCOUNT := TB_HOFF(K).AC_NO;
                        L_PARENT_ACC_BRN := TB_HOFF(K).AC_BRANCH;
                    END;
                    DBG('parent account is--->' || L_PARENT_ACCOUNT);
                    DBG('parent branch is--->' || L_PARENT_ACC_BRN);
                    IF G_ONLIQ_FLAG <> 'Y' THEN
                      IF TB_HOFF(K).AMOUNT_TAG = 'ILIQ' THEN
                        IF G_TB_SYS_ACCTS.EXISTS(L_PARENT_ACCOUNT ||
                                                 L_PARENT_ACC_BRN) THEN
                        
                          IF G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                           .G_TB_CHILD_ACCTS.COUNT = 2 THEN
                            DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                                .LCY_AMOUNT);
                            DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                                .LCY_AMT);
                            DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                          
                            IF (G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS(G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS.FIRST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS(G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS.LAST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                              .AMT <> 0 THEN
                              DBG('changing the amt here');
                              L_TMP_AMT := G_TB_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                                           .P_CONT_AMT;
                              DBG('l_tmp_amt-->' || L_TMP_AMT);
                            END IF;
                          
                          END IF;
                        END IF;
                      
                      ELSIF TB_HOFF(K).AMOUNT_TAG = 'TAX' THEN
                        IF G_TB_SYS_ACCTS_TAX.EXISTS(L_PARENT_ACCOUNT ||
                                                     L_PARENT_ACC_BRN) THEN
                        
                          IF G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                           .G_TB_CHILD_ACCTS_TAX.COUNT = 2 THEN
                            DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                                .LCY_AMOUNT);
                            DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                                .LCY_AMT);
                            DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                            IF (G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS_TAX(G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS_TAX.FIRST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS_TAX(G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS_TAX.LAST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                              .AMT <> 0 THEN
                              DBG('changing the amt here');
                              L_TMP_AMT := G_TB_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_CHILD_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                                           .P_CONT_AMT;
                              DBG('l_tmp_amt-->' || L_TMP_AMT);
                            END IF;
                          END IF;
                        END IF;
                      
                      END IF;
                    ELSIF G_ONLIQ_FLAG = 'Y' THEN
                      DBG('am here inside onliq flag Y condition');
                      L_TEMP_AMT := NULL;
                      IF TB_HOFF(K).AMOUNT_TAG = 'ILIQ' THEN
                        IF G_TB_ONL_SYS_ACCTS.EXISTS(L_PARENT_ACCOUNT ||
                                                     L_PARENT_ACC_BRN) THEN
                        
                          IF G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                           .G_TB_ONL_CHILD_ACCTS.COUNT = 2 THEN
                            DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                                .LCY_AMOUNT);
                            DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                                .LCY_AMT);
                            DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                          
                            IF (G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS(G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS.FIRST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS(G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS.LAST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                              .AMT <> 0 THEN
                              DBG('changing the amt here');
                              L_TEMP_AMT := G_TB_ONL_SYS_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                                            .P_CONT_AMT;
                              DBG('l_temp_amt-->' || L_TEMP_AMT);
                            END IF;
                          
                          END IF;
                        END IF;
                      ELSIF TB_HOFF(K).AMOUNT_TAG = 'TAX' THEN
                        IF G_TB_ONL_SYS_ACCTS_TAX.EXISTS(L_PARENT_ACCOUNT ||
                                                         L_PARENT_ACC_BRN) THEN
                        
                          IF G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                           .G_TB_ONL_CHILD_ACCTS_TAX.COUNT = 2 THEN
                            DBG('tb_hoff(k).lcy_amount1--->' || TB_HOFF(K)
                                .LCY_AMOUNT);
                            DBG('tbfrm(frm_no).lcy_amt1--->' || TBFRM(FRM_NO)
                                .LCY_AMT);
                            DBG('tbfrm(frm_no).amt1--->' || TBFRM(FRM_NO).AMT);
                            IF (G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS_TAX(G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS_TAX.FIRST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO OR G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS_TAX(G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS_TAX.LAST)
                               .P_ACCOUNT = TB_HOFF(K).AC_NO) AND TBFRM(FRM_NO)
                              .AMT <> 0 THEN
                              DBG('changing the amt here');
                              L_TEMP_AMT := G_TB_ONL_SYS_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN).G_TB_ONL_CHILD_ACCTS_TAX(L_PARENT_ACCOUNT || L_PARENT_ACC_BRN)
                                            .P_CONT_AMT;
                              DBG('l_temp_amt-->' || L_TEMP_AMT);
                            END IF;
                          END IF;
                        END IF;
                      END IF;
                    
                    END IF;
                  END IF;
                
                  DBG('l_tmp_amt-->' || L_TMP_AMT);
                
                  DBG('Here the amounts are tbfrm(frm_no).book_amt ' || TBFRM(FRM_NO)
                      .BOOK_AMT || ' - tbfrm(frm_no).amt' || TBFRM(FRM_NO).AMT);
                  IF L_CCY <> LCY THEN
                    DBG('currencies are different ' || L_CCY || '~' || LCY);
                  
                    IF TB_LOOKUP(K).ACCOUNT = 'USERINPUT' THEN
                      TB_HOFF(K).FCY_AMOUNT := NVL(TBFRM(FRM_NO).BOOK_AMT,
                                                   TBFRM(FRM_NO).AMT);
                    ELSE
                      TB_HOFF(K).FCY_AMOUNT := NVL(TBFRM(FRM_NO).AMT,
                                                   TBFRM(FRM_NO).BOOK_AMT);
                    END IF;
                    TB_HOFF(K).LCY_AMOUNT := TBFRM(FRM_NO).LCY_AMT;
                    TB_HOFF(K).EXCH_RATE := NVL(TBFRM(FRM_NO).XRATE, 1);
                  
                    IF TB_LOOKUP(K).ACCOUNT <> 'USERINPUT' AND
                        L_CCY <> NVL(L_BOOK_CCY, L_CCY) AND
                        L_BOOK_CCY <> LCY THEN
                      IF NOT CYPKS.FN_AMT_TO_RATE(L_CCY,
                                                  LCY,
                                                  TB_HOFF(K).FCY_AMOUNT,
                                                  TB_HOFF(K).LCY_AMOUNT,
                                                  TB_HOFF(K).EXCH_RATE) THEN
                        DBG('failed in exchange rate conversion');
                        TB_HOFF(K).EXCH_RATE := NVL(TBFRM(FRM_NO).XRATE, 1);
                      END IF;
                    END IF;
                  
                  ELSE
                  
                    DBG('All are of same currency');
                  
                    TB_HOFF(K).LCY_AMOUNT := TBFRM(FRM_NO).LCY_AMT;
                    TB_HOFF(K).FCY_AMOUNT := NULL;
                    TB_HOFF(K).EXCH_RATE := NULL;
                  
                  END IF;
                
                  DBG('tb_hoff(k).fcy_amount is--->' || TB_HOFF(K)
                      .FCY_AMOUNT);
                  DBG('tb_hoff(k).lcy_amount --->' || TB_HOFF(K)
                      .LCY_AMOUNT);
                  DBG('tb_hoff(k).exch_rate  is--->' || TB_HOFF(K)
                      .EXCH_RATE);
                
                  IF R_PR.IL_TYPE IS NOT NULL THEN
                  
                    IF G_ONLIQ_FLAG = 'Y' AND L_TEMP_AMT IS NOT NULL THEN
                      DBG('l_tmp_amt here 1 is--->' || L_TMP_AMT);
                      DBG('l_temp_amt here 1 is--->' || L_TEMP_AMT);
                      L_TMP_AMT := L_TEMP_AMT;
                    END IF;
                  
                    DBG('After assigning l_temp_amt in case of online liq is --->' ||
                        L_TMP_AMT);
                  
                    TB_HOFF(K).FCY_AMOUNT := NVL(L_TMP_AMT,
                                                 TB_HOFF(K).FCY_AMOUNT);
                  
                    IF L_CCY <> TB_CCY(I) THEN
                      DBG('currencies are different ' || L_CCY || '~' ||
                          TB_CCY(I));
                      L_ACQUIRED_FCY_AMT := NULL;
                      L_RATE             := NULL;
                      IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                         TB_CCY(I),
                                                         L_CCY,
                                                         NVL(TB_HOFF(K)
                                                             .FCY_AMOUNT,
                                                             0),
                                                         'Y',
                                                         L_ACQUIRED_FCY_AMT,
                                                         L_RATE,
                                                         ERR_CODE) THEN
                        EMSG;
                      
                        RAISE EXP_CONV;
                      END IF;
                      TB_HOFF(K).FCY_AMOUNT := L_ACQUIRED_FCY_AMT;
                    END IF;
                    IF L_CCY <> LCY THEN
                      L_ACQUIRED_LCY_AMT := NULL;
                      L_RATE             := NULL;
                      IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_BRN(I),
                                                         L_CCY,
                                                         LCY,
                                                         
                                                         NVL(TB_HOFF(K)
                                                             .FCY_AMOUNT,
                                                             0),
                                                         'Y',
                                                         L_ACQUIRED_LCY_AMT,
                                                         L_RATE,
                                                         ERR_CODE) THEN
                        EMSG;
                        RAISE EXP_CONV;
                      
                      END IF;
                    
                      TB_HOFF(K).EXCH_RATE := L_RATE;
                      TB_HOFF(K).LCY_AMOUNT := L_ACQUIRED_LCY_AMT;
                    ELSE
                      TB_HOFF(K).LCY_AMOUNT := NVL(L_TMP_AMT,
                                                   TB_HOFF(K).LCY_AMOUNT);
                      TB_HOFF(K).FCY_AMOUNT := NULL;
                      TB_HOFF(K).EXCH_RATE := NULL;
                    
                    END IF;
                  
                    DBG('tb_hoff(k).fcy_amount-->' || TB_HOFF(K)
                        .FCY_AMOUNT || '~' || L_RATE);
                  
                    DBG('tb_hoff(k).fcy_amount after  is--->' || TB_HOFF(K)
                        .FCY_AMOUNT);
                    DBG('tb_hoff(k).lcy_amount after --->' || TB_HOFF(K)
                        .LCY_AMOUNT);
                    DBG('tb_hoff(k).exch_rate after is--->' || TB_HOFF(K)
                        .EXCH_RATE);
                  
                  END IF;
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 3;
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_LOOKUP(K)
                                                                .AMTTAG;
                    L_TB_CLUSTER_DATA('frm_no') := FRM_NO;
                    L_TB_CLUSTER_DATA('l_ccy') := L_CCY;
                    L_TB_CLUSTER_DATA('lcy') := LCY;
                  
                    L_TB_CLUSTER_DATA('l_brn') := TB_BRN(I);
                    L_TB_CLUSTER_DATA('l_acc') := TB_ACC(I);
                    L_TB_CLUSTER_DATA('l_prod') := TB_PROD(I);
                  
                    L_TB_CLUSTER_DATA('tb_hoff(k).lcy_amount') := TB_HOFF(K)
                                                                  .LCY_AMOUNT;
                    L_TB_CLUSTER_DATA('tb_hoff(k).fcy_amount') := TB_HOFF(K)
                                                                  .FCY_AMOUNT;
                    L_TB_CLUSTER_DATA('tb_hoff(k).exch_rate') := TB_HOFF(K)
                                                                 .EXCH_RATE;
                  
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                      I,
                                                      TBFRM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
                  
                    TB_HOFF(K).LCY_AMOUNT := L_TB_CLUSTER_DATA('tb_hoff(k).lcy_amount');
                    TB_HOFF(K).FCY_AMOUNT := L_TB_CLUSTER_DATA('tb_hoff(k).fcy_amount');
                    TB_HOFF(K).EXCH_RATE := L_TB_CLUSTER_DATA('tb_hoff(k).exch_rate');
                  END IF;
                
                END IF;
              
                DBG('tb_acc(i) : ' || TB_ACC(I) || ' tb_brn(i) : ' ||
                    TB_BRN(I));
                DBG('tb_hoff(k).amount_tag : ' || TB_HOFF(K).AMOUNT_TAG);
                DBG('trn ref no : ' || TB_HOFF(K).TRN_REF_NO);
              
                DBG('lcy_amt~fcy_amt~basis_amount~drcr_ind~amt_tag : ' || TB_HOFF(K)
                    .LCY_AMOUNT || '~' || TB_HOFF(K).FCY_AMOUNT || '~' ||
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT || '~' || TB_HOFF(K)
                    .DRCR_IND || '~' || TB_HOFF(K).AMOUNT_TAG);
                IF TB_HOFF(K)
                 .AMOUNT_TAG = 'ILIQ' AND TB_HOFF(K).DRCR_IND = 'C' AND
                    NVL(L_FATCA_AUDIT_LOG.BASIS_AMOUNT, 0) = 0 AND
                    NVL(NVL(TB_HOFF(K).FCY_AMOUNT, TB_HOFF(K).LCY_AMOUNT), 0) <> 0 THEN
                  L_FATCA_AUDIT_LOG.BASIS_AMOUNT := NVL(NVL(TB_HOFF(K)
                                                            .FCY_AMOUNT,
                                                            TB_HOFF(K)
                                                            .LCY_AMOUNT),
                                                        0);
                
                  L_FATCA_AUDIT_LOG.TRANSACTION_CODE := TB_HOFF(K).TRN_CODE;
                  DBG('trncode : ' || L_FATCA_AUDIT_LOG.TRANSACTION_CODE);
                
                  L_REFERRAL_TABLE.AMOUNT_TAG         := TB_HOFF(K)
                                                         .AMOUNT_TAG;
                  L_REFERRAL_TABLE.TRANSACTION_CODE   := TB_HOFF(K).TRN_CODE;
                  L_REFERRAL_TABLE.TRANSACTION_AMOUNT := NVL(NVL(TB_HOFF(K)
                                                                 .FCY_AMOUNT,
                                                                 TB_HOFF(K)
                                                                 .LCY_AMOUNT),
                                                             0);
                  DBG('BASIS trncode~amtTag~basis : ' ||
                      L_REFERRAL_TABLE.TRANSACTION_CODE || '~' ||
                      L_REFERRAL_TABLE.AMOUNT_TAG || '~' ||
                      L_REFERRAL_TABLE.TRANSACTION_AMOUNT);
                
                END IF;
              
                IF TB_HOFF(K).AMOUNT_TAG IN ('FATCA_TAX', 'FATCA_REFERRAL') THEN
                  L_FATCA_EXT_CUSTOMER_SDE := ICPKS_CACHE.FN_GET_FATCA_EXT_CUST(TB_BRN(I),
                                                                                TB_ACC(I));
                
                  DBG('external customer status is : ' ||
                      L_FATCA_EXT_CUSTOMER_SDE);
                  IF (L_FATCA_EXT_CUSTOMER_SDE = 1 AND TB_HOFF(K)
                     .AMOUNT_TAG = 'FATCA_TAX') OR
                     (L_FATCA_EXT_CUSTOMER_SDE = 0 AND TB_HOFF(K)
                     .AMOUNT_TAG = 'FATCA_REFERRAL') THEN
                    TB_HOFF(K).LCY_AMOUNT := 0;
                    TB_HOFF(K).FCY_AMOUNT := 0;
                    DBG('set the unwanted entry as zero >>->');
                  END IF;
                
                  IF L_FATCA_EXT_CUSTOMER_SDE = 0 AND TB_HOFF(K)
                    .DRCR_IND = 'D' AND TB_HOFF(K).AMOUNT_TAG = 'FATCA_TAX' THEN
                    DBG('fatca audit log is required as the fatca decision is taken');
                    L_FATCA_AUDIT_REQD                  := TRUE;
                    L_FATCA_AUDIT_LOG.CUSTOMER_ID       := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(TB_BRN(I),
                                                                                                TB_ACC(I));
                    L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER := TB_BRN(I) ||
                                                           TB_ACC(I);
                    BEGIN
                      SELECT A.CUSTOMER_NAME1,
                             A.CUSTOMER_TYPE,
                             B.FATCA_CLASFCN
                        INTO L_FATCA_AUDIT_LOG.BENIFICIARY_NAME,
                             L_FATCA_AUDIT_LOG.CUSTOMER_TYPE,
                             L_FATCA_AUDIT_LOG.FATCA_CLASSIFICATION
                        FROM STTMS_CUSTOMER A, STTMS_CUST_FATCA B
                       WHERE A.CUSTOMER_NO = B.CUSTOMER_NO
                         AND A.CUSTOMER_NO = L_FATCA_AUDIT_LOG.CUSTOMER_ID;
                    
                      SELECT ACCOUNT_CLASS
                        INTO L_ACCOUNT_CLASS
                        FROM STTMS_CUST_ACCOUNT
                       WHERE CUST_AC_NO = TB_ACC(I)
                         AND BRANCH_CODE = TB_BRN(I);
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('Failed while fetching customer name and customer type with : ' ||
                            SQLERRM);
                    END;
                    L_FATCA_AUDIT_LOG.OBLIGATION_TYPE := 'A';
                    DBG('account class coming here from cache is : ' ||
                        L_ACCOUNT_CLASS);
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_US_SOURCED(L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER,
                                                                         L_ACCOUNT_CLASS,
                                                                         L_FATCA_AUDIT_LOG.US_SOURCED_STATUS) THEN
                      DBG('Failed while fetching us sourced flag');
                    END IF;
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_GRANDFATHERED(L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER,
                                                                            L_ACCOUNT_CLASS,
                                                                            L_FATCA_AUDIT_LOG.GRANDFATHERED_STATUS) THEN
                      DBG('Failed while fetching fatca grandfathered flag');
                    END IF;
                    DBG('global.application_date : ' ||
                        GLOBAL.APPLICATION_DATE);
                    L_FATCA_AUDIT_LOG.WITHHOLDING_DATE := GLOBAL.APPLICATION_DATE;
                    DBG('date returned as : ' ||
                        L_FATCA_AUDIT_LOG.WITHHOLDING_DATE);
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_RECALCITRANT(L_FATCA_AUDIT_LOG.CUSTOMER_ID,
                                                                           L_FATCA_AUDIT_LOG.RECALCITRANT) THEN
                      DBG('Failed while fetching fatca recalcitrant flag');
                    END IF;
                    IF NOT
                        STPKSS_FATCA_OBLIG_ENTRY.FN_GET_FATCA_BALANCE(L_FATCA_AUDIT_LOG.CUSTOMER_ID,
                                                                      L_FATCA_AUDIT_LOG.FATCA_BALANCE) THEN
                      DBG('failed while fetching fatca balance inside API');
                    END IF;
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT_TAG      := 'ILIQ';
                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT_CURRENCY := TB_HOFF(K)
                                                               .AC_CCY;
                  
                    L_FATCA_AUDIT_LOG.TAX_CURRENCY        := TB_HOFF(K)
                                                             .AC_CCY;
                    L_FATCA_AUDIT_LOG.TAX_AMOUNT          := NVL(NVL(TB_HOFF(K)
                                                                     .FCY_AMOUNT,
                                                                     TB_HOFF(K)
                                                                     .LCY_AMOUNT),
                                                                 0);
                    L_FATCA_AUDIT_LOG.WITHHOLDING_USER_ID := 'SYSTEM';
                    IF L_FATCA_AUDIT_LOG.TAX_AMOUNT = 0 THEN
                      L_FATCA_AUDIT_LOG.DECISION := 'N';
                    ELSE
                      L_FATCA_AUDIT_LOG.DECISION := 'Y';
                    END IF;
                    L_FATCA_AUDIT_LOG.OBLIGATION_BRANCH := TB_BRN(I);
                    L_FATCA_AUDIT_LOG.TAX_AMOUNT_TAG    := 'FATCA_TAX';
                    DBG('sucessfully assigned all audit log values, basis~tax : ' ||
                        L_FATCA_AUDIT_LOG.BASIS_AMOUNT || '~' ||
                        L_FATCA_AUDIT_LOG.TAX_AMOUNT);
                  END IF;
                
                  IF TB_HOFF(K)
                   .AMOUNT_TAG = 'FATCA_TAX' AND TB_HOFF(K).DRCR_IND = 'C' THEN
                    L_REFERRAL_TABLE.TAX_GL         := TB_HOFF(K).AC_NO;
                    L_REFERRAL_TABLE.TAX_AMOUNT_TAG := TB_HOFF(K).AMOUNT_TAG;
                    L_REFERRAL_TABLE.TAX_CURRENCY   := TB_HOFF(K).AC_CCY;
                  ELSIF TB_HOFF(K)
                   .AMOUNT_TAG = 'FATCA_REFERRAL' AND TB_HOFF(K)
                        .DRCR_IND = 'C' AND L_FATCA_EXT_CUSTOMER_SDE = 1 THEN
                    L_REFERRAL_NEEDED               := TRUE;
                    L_REFERRAL_TABLE.CUSTOMER_ID    := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(TB_BRN(I),
                                                                                            TB_ACC(I));
                    L_REFERRAL_TABLE.ACCOUNT_BRANCH := TB_BRN(I);
                    BEGIN
                      SELECT BOOK_ACC
                        INTO L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT
                        FROM ICTMS_ACC
                       WHERE ACC = TB_ACC(I)
                         AND BRN = TB_BRN(I);
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('ictm_acc not available :' || SQLERRM);
                        L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT := TB_HOFF(K)
                                                                .RELATED_ACCOUNT;
                    END;
                    L_REFERRAL_TABLE.ESCROW_GL         := TB_HOFF(K).AC_NO;
                    L_REFERRAL_TABLE.MODULE_CODE       := 'IC';
                    L_REFERRAL_TABLE.OBLIGATION_NUMBER := TB_BRN(I) ||
                                                          TB_ACC(I);
                    L_REFERRAL_TABLE.EVENT_CODE        := TB_HOFF(K).EVENT;
                    L_REFERRAL_TABLE.EVENT_SEQ_NO      := TB_HOFF(K)
                                                          .EVENT_SR_NO;
                  
                    L_REFERRAL_TABLE.TRANSACTION_CURRENCY := TB_HOFF(K)
                                                             .AC_CCY;
                  
                    L_REFERRAL_TABLE.TAX_AMOUNT := NVL(TB_HOFF(K).FCY_AMOUNT,
                                                       TB_HOFF(K).LCY_AMOUNT);
                  END IF;
                
                  IF PKG_LIQ_NETTING = 'Y' AND TB_HOFF(K)
                    .AMOUNT_TAG = 'FATCA_REFERRAL' THEN
                    L_REFERRAL_TABLE.TRANSACTION_AMOUNT := NVL(TB_HOFF(K)
                                                               .FCY_AMOUNT,
                                                               TB_HOFF(K)
                                                               .LCY_AMOUNT);
                    L_REFERRAL_TABLE.TAX_AMOUNT         := NVL(TB_HOFF(K)
                                                               .FCY_AMOUNT,
                                                               TB_HOFF(K)
                                                               .LCY_AMOUNT);
                  END IF;
                
                END IF;
              
                DBG(' amount now got as' || TB_HOFF(K).LCY_AMOUNT);
                DBG(' fcy amount now got as' || TB_HOFF(K).FCY_AMOUNT);
                IF SUBSTR(TB_LOOKUP(K).ACCROLE,
                          INSTR(TB_LOOKUP(K).ACCROLE, '-', 1, 1) + 1,
                          4) = 'TPBL' AND TB_LOOKUP(K)
                  .AMTTAG IN ('TAX', 'TAX_PADJ', 'TAX_NADJ', 'TAX_ADJ') THEN
                  DBG('Inside this TPBL case');
                  L_TAX_PAY_CCY_FLAG := SUBSTR(R_PR.FRM_VAL_STR, FRM_NO, 1);
                  IF NVL(L_TAX_PAY_CCY_FLAG, 'A') = 'L' AND TB_HOFF(K)
                    .AC_CCY <> LCY THEN
                    TB_HOFF(K).AC_CCY := LCY;
                    TB_HOFF(K).FCY_AMOUNT := 0;
                    TB_HOFF(K).EXCH_RATE := 0;
                  END IF;
                END IF;
                TB_HOFF(K).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF(K)
                                                                        .AC_CCY,
                                                                        TB_HOFF(K)
                                                                        .FCY_AMOUNT,
                                                                        LCY,
                                                                        TB_HOFF(K)
                                                                        .LCY_AMOUNT);
                IF TB_HOFF(K).AC_CCY <> LCY AND TB_HOFF(K).FCY_AMOUNT <> 0 AND TB_HOFF(K)
                   .LCY_AMOUNT = 0 THEN
                  DBG('Inside log exception');
                  INSERT INTO ICTBS_XLOG
                    (RUN_DT, BRN, ACC, PROD, OP, EX_TYPE, PRM1)
                  VALUES
                    (APPDT,
                     TB_BRN(I),
                     TB_ACC(I),
                     TB_PROD(I),
                     'L',
                     'C',
                     LTRIM(RTRIM(CSFNS_FORMAT_AMT(TB_CCY(I),
                                                  TB_HOFF(K).FCY_AMOUNT))) || ' ' ||
                     TB_CCY(I) || ' = 0 ' || LCY);
                END IF;
              
                IF (TB_HOFF(K)
                   .AC_CCY <> LCY AND NVL(TB_HOFF(K).FCY_AMOUNT, 0) = 0) OR
                   (NVL(TB_HOFF(K).LCY_AMOUNT, 0) = 0 AND TB_HOFF(K)
                   .AC_CCY = LCY) OR
                  
                   (TB_HOFF(K).LCY_AMOUNT < 0 AND TB_HOFF(K)
                   .AMOUNT_TAG IN ('TAX_PADJ', 'INT_PADJ')) OR
                   (TB_HOFF(K).LCY_AMOUNT > 0 AND TB_HOFF(K)
                   .AMOUNT_TAG IN ('TAX_NADJ', 'INT_NADJ')) THEN
                  DBG('seems this is a dummy entry' || TB_HOFF(K)
                      .AMOUNT_TAG);
                  DBG('seems this is a dummy entry' || TB_HOFF(K).AC_NO);
                  TB_HOFF.DELETE(K);
                ELSE
                  DBG('seems this is  real' || TB_HOFF(K).AMOUNT_TAG || TB_HOFF(K)
                      .LCY_AMOUNT);
                  DBG('seems this is  real' || TB_HOFF(K).AC_NO);
                
                  BEGIN
                    DBG('Updating sftbs_incdis for Account ' || TB_HOFF(K)
                        .RELATED_ACCOUNT);
                    UPDATE SFTBS_INCDIS
                       SET DISTRIBUTED_STAT = 'Y'
                     WHERE BRANCH_NO = TB_HOFF(K).AC_BRANCH
                       AND TD_ACCOUNT_NO = TB_HOFF(K).RELATED_ACCOUNT
                       AND DISTRIBUTED_STAT IS NULL;
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('Some Error In sftbs_incdis Table Updating For Account ' || TB_HOFF(K)
                          .RELATED_ACCOUNT);
                  END;
                
                  IF TB_HOFF(K).AMOUNT_TAG IN ('TAX_NADJ', 'INT_NADJ') THEN
                    IF TB_HOFF(K).AC_CCY <> LCY THEN
                      TB_HOFF(K).FCY_AMOUNT := ABS(TB_HOFF(K).FCY_AMOUNT);
                    END IF;
                    TB_HOFF(K).LCY_AMOUNT := ABS(TB_HOFF(K).LCY_AMOUNT);
                  END IF;
                
                  IF L_DR_INT_GL THEN
                    L_FRM_NO := FRM_NO;
                    DBG('1 Updating/Inserting ictms_dr_int_due for brn,acc,prod,frm_no -' || TB_HOFF(K)
                        .RELATED_ACCOUNT || '~' || TB_PROD(I) || '~' ||
                        TO_CHAR(FRM_NO));
                    L_LIQD_DATE := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                                TB_BRN(I),
                                                                P_DT,
                                                                'N',
                                                                L_DR_INT_DAYS);
                    BEGIN
                      UPDATE ICTBS_DR_INT_DUE
                         SET BOOK_BRN = L_DR_INT_BOOK_BRN,
                             BOOK_ACC = L_DR_INT_BOOK_ACC,
                             BOOK_CCY = TB_HOFF(K).AC_CCY,
                             RECV_GL  = L_DR_INT_RECV_GL,
                             TRN_DT   = NVL(TB_HOFF(K).TRN_DT,
                                            GLOBAL.APPLICATION_DATE),
                             DUE_DT   = L_LIQD_DATE,
                             TRN_CODE = TB_HOFF(K).TRN_CODE,
                             AMT_DUE  = DECODE(TB_HOFF(K).AC_CCY,
                                               LCY,
                                               NVL(TB_HOFF(K).LCY_AMOUNT, 0),
                                               NVL(TB_HOFF(K).FCY_AMOUNT, 0))
                       WHERE BRN = TB_BRN(I)
                         AND ACC = TB_HOFF(K).RELATED_ACCOUNT
                         AND PROD = TB_PROD(I)
                         AND FRM_NO = L_FRM_NO
                         AND AMT_TAG = TB_HOFF(K).AMOUNT_TAG
                         AND ENT_DT = P_DT
                         AND REF_NO = TB_HOFF(K).TRN_REF_NO;
                      IF SQL%NOTFOUND THEN
                      
                        IF TB_HOFF(K).AC_CCY = LCY THEN
                          L_INT_AMT_DUE := TB_HOFF(K).LCY_AMOUNT;
                        ELSE
                          L_INT_AMT_DUE := TB_HOFF(K).FCY_AMOUNT;
                        END IF;
                        INSERT INTO ICTBS_DR_INT_DUE
                          (BRN,
                           ACC,
                           BOOK_CCY,
                           PROD,
                           FRM_NO,
                           AMT_TAG,
                           BOOK_BRN,
                           BOOK_ACC,
                           REF_NO,
                           RECV_GL,
                           TRN_DT,
                           ENT_DT,
                           DUE_DT,
                           TRN_CODE,
                           AMT_DUE,
                           AMT_SETTLD,
                           NOTICE_GENERATED,
                           PROD_TYPE)
                        VALUES
                          (TB_BRN(I),
                           TB_HOFF(K).RELATED_ACCOUNT,
                           TB_HOFF(K).AC_CCY,
                           TB_PROD(I),
                           L_FRM_NO,
                           TB_HOFF(K).AMOUNT_TAG,
                           L_DR_INT_BOOK_BRN,
                           L_DR_INT_BOOK_ACC,
                           TB_HOFF(K).TRN_REF_NO,
                           L_DR_INT_RECV_GL,
                           NVL(TB_HOFF(K).TRN_DT, GLOBAL.APPLICATION_DATE),
                           P_DT,
                           L_LIQD_DATE,
                           TB_HOFF(K).TRN_CODE,
                           NVL(L_INT_AMT_DUE, 0),
                           0,
                           'N',
                           'I');
                      END IF;
                      DBG('Updating debit interest amount due in sttm_cust_account');
                      DBG('here drint_due_amt is ' || L_INT_AMT_DUE || TB_HOFF(K)
                          .AC_CCY);
                      UPDATE STTMS_CUST_ACCOUNT
                         SET DR_INT_DUE = NVL(DR_INT_DUE, 0) + L_INT_AMT_DUE
                       WHERE CUST_AC_NO = L_DR_INT_BOOK_ACC
                         AND BRANCH_CODE = L_DR_INT_BOOK_BRN;
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('In WOT while inserting into ictms_dr_int_due-' ||
                            SQLERRM);
                        ERR_CODE := 'IC-DRINT04';
                        EMSG;
                    END;
                  END IF;
                
                  IF L_COLLATERAL_LINE THEN
                    L_FRM_NO1 := FRM_NO;
                    DBG('2 Updating/Inserting ictms_dr_int_due for brn,acc,prod,frm_no -' || TB_HOFF(K)
                        .RELATED_ACCOUNT || '~' || TB_PROD(I) || '~' ||
                        TO_CHAR(FRM_NO));
                  
                    IF TB_HOFF(K).AC_CCY = LCY THEN
                      L_INT_AMT_DUE1 := TB_HOFF(K).LCY_AMOUNT;
                    ELSE
                      L_INT_AMT_DUE1 := TB_HOFF(K).FCY_AMOUNT;
                    END IF;
                    BEGIN
                    
                      SELECT NVL(MAX(TO_NUMBER(SEQ_NO)), 0)
                      
                        INTO L_SEQ
                        FROM ICTBS_SODDR_INT_DUE
                       WHERE ACC = TB_HOFF(K).RELATED_ACCOUNT
                         AND BRN = TB_HOFF(K).AC_BRANCH;
                      DBG('picked up from select ' || L_SEQ);
                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        L_SEQ := 0;
                        DBG('picked up from select ' || L_SEQ);
                      WHEN OTHERS THEN
                        L_SEQ := 0;
                        DBG('picked up from others ' || L_SEQ);
                    END;
                    DBG('finally wil insert  ' || L_SEQ);
                    INSERT INTO ICTBS_SODDR_INT_DUE
                    VALUES
                      (TB_BRN(I),
                       TB_HOFF(K).RELATED_ACCOUNT,
                       TB_PROD(I),
                       L_FRM_NO1,
                       TB_HOFF(K).AMOUNT_TAG,
                       
                       P_DT,
                       TB_HOFF(K).AC_BRANCH,
                       TB_HOFF(K).AC_NO,
                       TB_HOFF(K).TRN_REF_NO,
                       TB_HOFF(K).AC_CCY,
                       NVL(TB_HOFF(K).TRN_DT, GLOBAL.APPLICATION_DATE),
                       TB_HOFF(K).TRN_CODE,
                       L_INT_AMT_DUE1,
                       0,
                       L_SEQ + 1);
                  END IF;
                
                  IF NVL(L_PROD_REC.OD_INT_REVR, 'N') = 'Y' THEN
                  
                    PR_UPDATE_OD_INT(FRM_NO,
                                     TB_BRN(I),
                                     TB_HOFF(K).RELATED_ACCOUNT,
                                     TB_PROD(I),
                                     TB_HOFF(K).LCY_AMOUNT,
                                     TB_HOFF(K).FCY_AMOUNT,
                                     TB_HOFF(K).AC_CCY,
                                     LCY,
                                     NVL(TB_HOFF(K).VALUE_DT, P_DT));
                  
                    L_PROD_REC.OD_INT_REVR := 'N';
                  END IF;
                
                  SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
                  TEMP_HOFF(SR) := TB_HOFF(K);
                
                  IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                     (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
                    L_FN_CALL_ID := 7;
                    DBG('calling call id 7 : ' || TB_LOOKUP(K).ACCROLE || '~' || TB_LOOKUP(K)
                        .AMTTAG);
                    L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
                    IF TB_LOOKUP.EXISTS(K) THEN
                      L_TB_CLUSTER_DATA('tb_lookup(k).accrole') := TB_LOOKUP(K)
                                                                   .ACCROLE;
                      L_TB_CLUSTER_DATA('tb_lookup(k).amttag') := TB_LOOKUP(K)
                                                                  .AMTTAG;
                      L_TB_CLUSTER_DATA('tb_lookup(k).account') := TB_LOOKUP(K)
                                                                   .ACCOUNT;
                    END IF;
                    L_TB_CLUSTER_DATA('sr') := SR;
                    IF TEMP_HOFF.EXISTS(SR) THEN
                      L_TB_CLUSTER_DATA('temp_hoff(sr).drcr_ind') := TEMP_HOFF(SR)
                                                                     .DRCR_IND;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).event') := TEMP_HOFF(SR)
                                                                  .EVENT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).lcy_amount') := TEMP_HOFF(SR)
                                                                       .LCY_AMOUNT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).fcy_amount') := TEMP_HOFF(SR)
                                                                       .FCY_AMOUNT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).ac_ccy') := TEMP_HOFF(SR)
                                                                   .AC_CCY;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).ac_no') := TEMP_HOFF(SR)
                                                                  .AC_NO;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).trn_code') := TEMP_HOFF(SR)
                                                                     .TRN_CODE;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).related_account') := TEMP_HOFF(SR)
                                                                            .RELATED_ACCOUNT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).trn_ref_no') := TEMP_HOFF(SR)
                                                                       .TRN_REF_NO;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).ac_branch') := TEMP_HOFF(SR)
                                                                      .AC_BRANCH;
                    
                      L_TB_CLUSTER_DATA('temp_hoff(sr).amount_tag') := TEMP_HOFF(SR)
                                                                       .AMOUNT_TAG;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).exch_rate') := TEMP_HOFF(SR)
                                                                      .EXCH_RATE;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).trn_dt') := TEMP_HOFF(SR)
                                                                   .TRN_DT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).value_dt') := TEMP_HOFF(SR)
                                                                     .VALUE_DT;
                      L_TB_CLUSTER_DATA('temp_hoff(sr).product') := TB_PROD(I);
                    
                    END IF;
                    ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                                      I,
                                                      TBFRM,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA);
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).ac_branch') THEN
                      TEMP_HOFF(SR).AC_BRANCH := L_TB_CLUSTER_DATA('temp_hoff(sr).ac_branch');
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).ac_no') THEN
                      TEMP_HOFF(SR).AC_NO := L_TB_CLUSTER_DATA('temp_hoff(sr).ac_no');
                    
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).trn_code') THEN
                      TEMP_HOFF(SR).TRN_CODE := L_TB_CLUSTER_DATA('temp_hoff(sr).trn_code');
                      DBG('temp_hoff(sr). trn_code: ' || TEMP_HOFF(SR) .
                          TRN_CODE);
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).value_dt') THEN
                      TEMP_HOFF(SR).VALUE_DT := L_TB_CLUSTER_DATA('temp_hoff(sr).value_dt');
                      DBG('temp_hoff(sr).value_dt:' || TEMP_HOFF(SR)
                          .VALUE_DT);
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).lcy_amount') THEN
                      TEMP_HOFF(SR).LCY_AMOUNT := L_TB_CLUSTER_DATA('temp_hoff(sr).lcy_amount');
                      DBG('temp_hoff(sr).lcy_amount:' || TEMP_HOFF(SR)
                          .LCY_AMOUNT);
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).fcy_amount') THEN
                      TEMP_HOFF(SR).FCY_AMOUNT := L_TB_CLUSTER_DATA('temp_hoff(sr).fcy_amount');
                      DBG('temp_hoff(sr).fcy_amount:' || TEMP_HOFF(SR)
                          .FCY_AMOUNT);
                    END IF;
                  
                    DBG('call to pr_entries_liq for IC RECEIVABLES done : ');
                    DBG('temp_hoff(sr).ac_no: ' || TEMP_HOFF(SR).AC_NO);
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).product') THEN
                      TB_PROD(I) := L_TB_CLUSTER_DATA('temp_hoff(sr).product');
                    END IF;
                  
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).ac_ccy') THEN
                      TEMP_HOFF(SR).AC_CCY := L_TB_CLUSTER_DATA('temp_hoff(sr).ac_ccy');
                    END IF;
                    IF L_TB_CLUSTER_DATA.EXISTS('temp_hoff(sr).exch_rate') THEN
                      TEMP_HOFF(SR).EXCH_RATE := L_TB_CLUSTER_DATA('temp_hoff(sr).exch_rate');
                    END IF;
                  
                  END IF;
                
                END IF;
              
              ELSIF PKG_LIQ_NETTING = 'Y' AND TB_LOOKUP(K)
                   .AMTTAG IN ('FATCA_REFERRAL', 'FATCA_TAX') THEN
                DBG('in here to post referral entry for acc~brn~amtTag~escrowgl~ccy : ' ||
                    TB_ACC(I) || '~' || TB_BRN(I) || '~' || TB_LOOKUP(K)
                    .AMTTAG || '~' || TB_LOOKUP(K).ACCOUNT || '~' ||
                    TB_CCY(I));
                L_FATCA_EXT_CUSTOMER_SDE := ICPKS_CACHE.FN_GET_FATCA_EXT_CUST(TB_BRN(I),
                                                                              TB_ACC(I));
                DBG('external customer status is : ' ||
                    L_FATCA_EXT_CUSTOMER_SDE);
                IF TB_LOOKUP(K).AMTTAG = 'FATCA_TAX' THEN
                  L_REFERRAL_TABLE.TAX_GL         := TB_LOOKUP(K).ACCOUNT;
                  L_REFERRAL_TABLE.TAX_AMOUNT_TAG := TB_LOOKUP(K).AMTTAG;
                  L_REFERRAL_TABLE.TAX_CURRENCY   := TB_CCY(I);
                ELSIF TB_LOOKUP(K).AMTTAG = 'FATCA_REFERRAL' AND
                       L_FATCA_EXT_CUSTOMER_SDE = 1 THEN
                  L_REFERRAL_NEEDED               := TRUE;
                  L_REFERRAL_TABLE.CUSTOMER_ID    := ICPKS_CACHE.FN_GET_FATCA_BENEFICIARY(TB_BRN(I),
                                                                                          TB_ACC(I));
                  L_REFERRAL_TABLE.ACCOUNT_BRANCH := TB_BRN(I);
                  BEGIN
                    SELECT BOOK_ACC
                      INTO L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT
                      FROM ICTMS_ACC
                     WHERE ACC = TB_ACC(I)
                       AND BRN = TB_BRN(I);
                  EXCEPTION
                    WHEN OTHERS THEN
                      DBG('ictm_acc not available :' || SQLERRM);
                      L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT := TB_ACC(I);
                  END;
                  L_REFERRAL_TABLE.ESCROW_GL            := TB_LOOKUP(K)
                                                           .ACCOUNT;
                  L_REFERRAL_TABLE.MODULE_CODE          := 'IC';
                  L_REFERRAL_TABLE.OBLIGATION_NUMBER    := TB_BRN(I) ||
                                                           TB_ACC(I);
                  L_REFERRAL_TABLE.EVENT_CODE           := 'ILIQ';
                  L_REFERRAL_TABLE.EVENT_SEQ_NO         := 1;
                  L_REFERRAL_TABLE.AMOUNT_TAG           := TB_LOOKUP(K)
                                                           .AMTTAG;
                  L_REFERRAL_TABLE.TRANSACTION_CODE     := TB_LOOKUP(K)
                                                           .TRNCODE;
                  L_REFERRAL_TABLE.TRANSACTION_CURRENCY := TB_CCY(I);
                  DBG('passed all the assignments amt is : ' ||
                      L_REFERRAL_TABLE.TRANSACTION_AMOUNT || ' and ' ||
                      L_REFERRAL_TABLE.TAX_AMOUNT);
                END IF;
              
              ELSE
                DBG('Sorry boss nothing of booking type');
              END IF;
            
            ELSE
              GLOBAL.PR_RESET_SKIP_KERNEL;
            END IF;
          
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG('In nodata found');
              TB_HOFF.DELETE(K);
              NULL;
          END;
        END LOOP;
      
        IF L_REFERRAL_NEEDED AND L_REFERRAL_TABLE.TRANSACTION_AMOUNT <> 0 THEN
          DBG('writing to FATCA referral table');
          IF NOT
              TAPKSS_NEW.FN_INSERT_FATCA_REFERRAL(L_REFERRAL_TABLE.CUSTOMER_ID,
                                                  L_REFERRAL_TABLE.ACCOUNT_BRANCH,
                                                  L_REFERRAL_TABLE.BENIFICIARY_ACCOUNT,
                                                  L_REFERRAL_TABLE.ESCROW_GL,
                                                  L_REFERRAL_TABLE.TAX_GL,
                                                  L_REFERRAL_TABLE.OBLIGATION_NUMBER,
                                                  L_REFERRAL_TABLE.EVENT_CODE,
                                                  L_REFERRAL_TABLE.EVENT_SEQ_NO,
                                                  L_REFERRAL_TABLE.AMOUNT_TAG,
                                                  L_REFERRAL_TABLE.TRANSACTION_CODE,
                                                  L_REFERRAL_TABLE.TAX_AMOUNT_TAG,
                                                  L_REFERRAL_TABLE.TRANSACTION_CURRENCY,
                                                  L_REFERRAL_TABLE.TRANSACTION_AMOUNT,
                                                  L_REFERRAL_TABLE.TAX_CURRENCY,
                                                  L_REFERRAL_TABLE.TAX_AMOUNT,
                                                  L_ERR_CODE,
                                                  L_ERR_PARAM,
                                                  L_REFERRAL_TABLE.MODULE_CODE) THEN
            DBG('failed while trying to insert into referral with : ' ||
                L_ERR_CODE);
            LOG_PROBLEM(I,
                        'B',
                        'Failed while inserting into FATCA referral with ' +
                        L_ERR_CODE + '~' + L_ERR_PARAM);
          END IF;
        
        ELSIF L_FATCA_AUDIT_REQD THEN
          BEGIN
            INSERT INTO TATBS_FATCA_AUDIT_LOG VALUES L_FATCA_AUDIT_LOG;
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('Record already present for the day, so updating the values on the same date');
              UPDATE TATBS_FATCA_AUDIT_LOG
                 SET TAX_AMOUNT   = TAX_AMOUNT +
                                    L_FATCA_AUDIT_LOG.TAX_AMOUNT,
                     BASIS_AMOUNT = BASIS_AMOUNT +
                                    L_FATCA_AUDIT_LOG.BASIS_AMOUNT
               WHERE CUSTOMER_ID = L_FATCA_AUDIT_LOG.CUSTOMER_ID
                 AND OBLIGATION_NUMBER =
                     L_FATCA_AUDIT_LOG.OBLIGATION_NUMBER
                 AND TAX_AMOUNT_TAG = L_FATCA_AUDIT_LOG.TAX_AMOUNT_TAG
                 AND WITHHOLDING_DATE = L_FATCA_AUDIT_LOG.WITHHOLDING_DATE;
            WHEN OTHERS THEN
              DBG('failed while trying to insert into audit table with : ' ||
                  SQLERRM);
              LOG_PROBLEM(I,
                          'B',
                          'Failed to insert FATCA audit with ' + SQLCODE);
          END;
        
        END IF;
      
      END IF;
      HOFF_COUNT := NVL(TEMP_HOFF.COUNT, 0);
      CONS_COUNT := NVL(TB_HOFF_CONS.COUNT, 0);
      DBG('Here so called hoff count is' || '~' || HOFF_COUNT || '~' ||
          CONS_COUNT);
      IF CONS_COUNT <> 0 THEN
        CONS_COUNT := CONS_COUNT + 1;
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
        IF TEMP_HOFF.COUNT > 0 THEN
          FOR J IN TEMP_HOFF.FIRST .. TEMP_HOFF.LAST LOOP
            L_FN_CALL_ID := 8;
            DBG('calling call id 8 : ' || TEMP_HOFF(J).AC_NO || '~' || TEMP_HOFF(J)
                .TRN_CODE);
            L_TB_CLUSTER_DATA := L_TB_EMPTY_CLUSTER_DATA;
            L_TB_CLUSTER_DATA('j') := J;
            L_TB_CLUSTER_DATA('temp_hoff(j).ac_no') := TEMP_HOFF(J).AC_NO;
            L_TB_CLUSTER_DATA('temp_hoff(j).trn_code') := TEMP_HOFF(J)
                                                          .TRN_CODE;
            ICPKS_TEST_CLUSTER.PR_ENTRIES_LIQ(P_DT,
                                              I,
                                              TBFRM,
                                              L_FN_CALL_ID,
                                              L_TB_CLUSTER_DATA);
            TEMP_HOFF(J).AC_NO := L_TB_CLUSTER_DATA('temp_hoff(j).ac_no');
            TEMP_HOFF(J).TRN_CODE := L_TB_CLUSTER_DATA('temp_hoff(j).trn_code');
          END LOOP;
        END IF;
      
      END IF;
    
      IF HOFF_COUNT <> 0 THEN
        J := TEMP_HOFF.FIRST;
        WHILE J <= TEMP_HOFF.LAST LOOP
          DBG('this should be final test' || TEMP_HOFF(J).LCY_AMOUNT || TEMP_HOFF(J)
              .AC_NO);
          TB_HOFF_CONS(CONS_COUNT + J) := TEMP_HOFF(J);
          J := TEMP_HOFF.NEXT(J);
        END LOOP;
      END IF;
    END IF;
  
    IF ICPKSS_BOD.G_FROMBOD THEN
      DBG('The call is from icpkss_bod ');
      IF TB_HOFF_CONS.COUNT <> 0 THEN
        IF (ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y' OR
           ICPKS_BOD.PKG_ICTM_ACC.RD_MOVE_MAT_TO_UNCLAIMED = 'Y') AND
           ICPKS_BOD.UNCLAIMED_PROCESS = 'N'
        
         THEN
          PR_MISCAC(TB_PROD(I), L_BOOK_GL);
        
          DBG('Before call to get unclaimed int gl........... ');
          IF ((ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y') AND
             (L_BOOK_GL IS NULL)) THEN
            PR_UNCLAIMED_GL(TB_PROD(I), 'INT_UNCLAIMED', L_BOOK_GL);
          END IF;
          DBG('l_book_gl --> ' || L_BOOK_GL);
        
          IF ICPKS_BOD.PKG_ICTM_ACC.MOVE_INT_TO_UNCLAIMED = 'Y'
          
           THEN
            BEGIN
              ICPKS_BOOK.PR_PROCESS_RECON_ACC(TB_BRN(I),
                                              TB_ACC(I),
                                              TB_PROD(I),
                                              P_DT,
                                              L_BOOK_GL,
                                              TB_CCY(I),
                                              'I',
                                              TB_HOFF_CONS);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('PR_PROCESS_RECON_ACC Failed---> ' || SQLERRM);
                EMSG;
            END;
          END IF;
        END IF;
      END IF;
    END IF;
  
    TEMP_HOFF.DELETE;
    TB_HOFF.DELETE;
    DBG('End if pr_entries_liq');
  EXCEPTION
  
    WHEN EXP_CONV THEN
      DBG(' EXP WHILE CONVERTING');
      RAISE;
    WHEN OTHERS THEN
      DBG('Some problem in posting the liq entries pr_entries_liq =>' ||
          SQLERRM);
      LOG_PROBLEM(I,
                  'B',
                  'WOT in entries liq ' || SUBSTR(SQLERRM, 1, 1900));
      RAISE;
  END PR_ENTRIES_LIQ;

  FUNCTION FN_TDS_DATA_COLLECTION(P_BRN             VARCHAR2,
                                  P_TO_DT           DATE,
                                  P_ERROR_CODE      IN OUT VARCHAR2,
                                  P_ERROR_PARAMETER IN OUT VARCHAR2,
                                  P_PROCESS         IN NUMBER DEFAULT 1)
    RETURN BOOLEAN IS
    CURSOR CUR_TDS_PRODUCTS_HIST(P_FROM_DT DATE, P_TO_DT DATE) IS
      SELECT A.ACC, SUM(A.CUR_RUN_ACCR) AMT
      
        FROM ICTBS_ENTRIES_HISTORY_ACCR A, CSTMS_PRODUCT P
      
       WHERE A.BRN = P_BRN
         AND A.PROD = P.PRODUCT_CODE
         AND A.ENT_DT BETWEEN P_FROM_DT AND P_TO_DT
         AND P.INCLUDE_FOR_TDS_CALC = 'Y'
            
         AND PROCESS = NVL(P_PROCESS, 1)
      
       GROUP BY A.ACC;
    L_FIN_YEAR   STTMS_FIN_CYCLE.FIN_CYCLE%TYPE;
    L_FC_STRT_DT DATE;
    L_FC_END_DT  DATE;
    L_ACC        STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_CUST_NO    STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_CUSTACC    STTMS_CUST_ACCOUNT%ROWTYPE;
    L_TDS_COUNT  NUMBER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
  
    DBG('Get count of TDS products first ');
    SELECT COUNT(1)
      INTO L_TDS_COUNT
      FROM CSTMS_PRODUCT
     WHERE INCLUDE_FOR_TDS_CALC = 'Y';
  
    DBG('TDS count = ' || L_TDS_COUNT);
  
    IF L_TDS_COUNT = 0 THEN
      DBG('I really dont need to proceed now and spend more time here..');
      RETURN TRUE;
    
    END IF;
  
    SELECT CURRENT_CYCLE
      INTO L_FIN_YEAR
      FROM STTMS_BRANCH
     WHERE BRANCH_CODE = P_BRN;
    SELECT FC_START_DATE, FC_END_DATE
      INTO L_FC_STRT_DT, L_FC_END_DT
      FROM STTMS_FIN_CYCLE
     WHERE FIN_CYCLE = L_FIN_YEAR;
    DBG('Fin year/strt dt and End Dt are ' || L_FIN_YEAR || '~' ||
        L_FC_STRT_DT || '~' || L_FC_END_DT);
    FOR EACH_ROW IN CUR_TDS_PRODUCTS_HIST(L_FC_STRT_DT, L_FC_END_DT) LOOP
      IF EACH_ROW.ACC <> NVL(L_ACC, '***') THEN
        L_ACC := EACH_ROW.ACC;
      
        IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, L_ACC, L_CUSTACC) THEN
          DBG('Could not get account');
          RETURN FALSE;
        END IF;
        L_CUST_NO := L_CUSTACC.CUST_NO;
      
      END IF;
      UPDATE ICTBS_TDS_DETAILS
         SET INTEREST_AMOUNT = EACH_ROW.AMT
       WHERE CUSTOMER_NO = L_CUST_NO
         AND BRN = P_BRN
         AND ACC = EACH_ROW.ACC
         AND FIN_YEAR = L_FIN_YEAR;
      IF SQL%NOTFOUND THEN
        INSERT INTO ICTBS_TDS_DETAILS
          (CUSTOMER_NO, BRN, ACC, FIN_YEAR, INTEREST_AMOUNT, TDS_AMOUNT)
        VALUES
          (L_CUST_NO, P_BRN, EACH_ROW.ACC, L_FIN_YEAR, EACH_ROW.AMT, 0);
      END IF;
    
      GLOBAL.PR_RESET_SKIP_KERNEL;
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        L_TB_CLUSTER_DATA('each_row.acc') := EACH_ROW.ACC;
        L_TB_CLUSTER_DATA('l_cust_no') := L_CUST_NO;
        DBG('Calling icpks_test_cluster.fn_tds_data_collection');
        IF NOT
            ICPKS_TEST_CLUSTER.FN_TDS_DATA_COLLECTION(P_BRN,
                                                      P_TO_DT,
                                                      P_ERROR_CODE,
                                                      P_ERROR_PARAMETER,
                                                      P_PROCESS,
                                                      L_FN_CALL_ID,
                                                      L_TB_CLUSTER_DATA) THEN
          DBG('FAILED IN icpks_test_cluster.fn_tds_data_collection');
          RETURN FALSE;
        END IF;
      END IF;
      GLOBAL.PR_RESET_SKIP_KERNEL;
    
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_tds_data_collection ' || SQLERRM);
      RETURN FALSE;
  END;

  FUNCTION FN_UPDATE_TDS_AMOUNT(P_BRN         VARCHAR2,
                                P_ERROR_CODE  IN OUT VARCHAR2,
                                P_ERROR_PARAM IN OUT VARCHAR2,
                                P_PROCESS     IN NUMBER DEFAULT 1)
    RETURN BOOLEAN IS
    CURSOR C_DAILY_LOG IS
      SELECT NVL(A.RELATED_ACCOUNT, A.AC_NO) AC_NO,
             A.RELATED_CUSTOMER,
             A.FINANCIAL_CYCLE,
             SUM(DECODE(A.AC_CCY, GLOBAL.LCY, A.LCY_AMOUNT, A.FCY_AMOUNT)) AMT
        FROM ACTBS_DAILY_LOG A, CSTB_CUSTACSEQ B
       WHERE A.AC_BRANCH = P_BRN
         AND A.MODULE = 'IC'
         AND A.DELETE_STAT <> 'D'
         AND NVL(A.RELATED_ACCOUNT, A.AC_NO) = B.CUST_AC_NO
         AND A.AC_BRANCH = B.BRANCH_CODE
         AND B.SEQ_NO = P_PROCESS
         AND A.PRODUCT IN (SELECT P.PRODUCT_CODE
                             FROM ICTMS_PRODUCT_DEFINITION P
                            WHERE P.TAX = 'Y')
         AND A.EVENT = 'ILIQ'
         AND A.CUST_GL = 'A'
       GROUP BY NVL(A.RELATED_ACCOUNT, A.AC_NO),
                A.RELATED_CUSTOMER,
                A.FINANCIAL_CYCLE;
  BEGIN
    FOR EACH_ROW IN C_DAILY_LOG LOOP
      UPDATE ICTBS_TDS_DETAILS
         SET TDS_AMOUNT = TDS_AMOUNT + EACH_ROW.AMT
       WHERE CUSTOMER_NO = EACH_ROW.RELATED_CUSTOMER
         AND BRN = P_BRN
         AND ACC = EACH_ROW.AC_NO
         AND FIN_YEAR = EACH_ROW.FINANCIAL_CYCLE;
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;

  FUNCTION FN_ICEOD_WRAP(P_BRN           VARCHAR2,
                         P_TAX_PROD      VARCHAR2,
                         P_PROCESS       NUMBER DEFAULT 1,
                         P_AC_CLASS_TYPE IN ICTBS_ACC_PR.AC_CLASS_TYPE%TYPE)
    RETURN INTEGER AS
    EOD_STAT        STTMS_BRANCH.END_OF_INPUT%TYPE;
    PRO_TILL        CHAR(1);
    BOD_STAT        NUMBER := 0;
    N_INV           INTEGER;
    N               INTEGER;
    TO_DT           DATE;
    FROM_DT         DATE;
    RET_VAL         INTEGER := 0;
    VD_ERR          VARCHAR2(2000);
    VD_ERP          VARCHAR2(2000);
    MAINT_ERR_CODE  VARCHAR2(100);
    MAINT_ERR_PARAM VARCHAR2(2000);
    PKG_BKVAL_REQD  BOOLEAN := FALSE;
    CHG_DT          DATE;
    PERRCODE        VARCHAR2(100);
    T_FROM_DT       DATE;
  
    L_WHAT  VARCHAR2(255);
    N_PART  NUMBER;
    K       NUMBER;
    RETSTAT INTEGER;
  
    N_CHG_PROD NUMBER;
  
    L_ERROR_CODE      VARCHAR2(10);
    L_ERROR_PARAMETER VARCHAR2(50);
    L_ERR_COUNT       NUMBER;
  
    LCHGSTARTADVREQD NUMBER := 0;
    L_JOB_NAME       USER_SCHEDULER_JOBS.JOB_NAME%TYPE;
    CURSOR C_JOB IS
    
      SELECT 1
        FROM ICTB_JOB_CTL
       WHERE
      
       UPPER(WHAT) LIKE '%PR_UPDATE_FOR_VDBAL_SEQ%'
       AND BRN = P_BRN
       AND STATUS IS NULL
       AND PROCESS = P_PROCESS;
  
    CURSOR CUR_BKVAL_REQD IS
      SELECT I.*
        FROM ICTMS_PR_INT I, CSTM_PRODUCT P
       WHERE I.PRODUCT_CODE = P.PRODUCT_CODE
         AND I.BACK_CALC_FLAG = 'Y'
         AND P.AUTH_STAT = 'A'
         AND P.RECORD_STAT = 'O'
         AND P.PRODUCT_START_DATE <= APPDT;
    L_NUM_PROC ICTM_BRANCH_PARAMETERS.NUM_PROCESS%TYPE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
    RETVAL                  INTEGER;
  
    REV_CHG_DT DATE;
  
    L_START_TIME     TIMESTAMP;
    L_START_CHG_TIME TIMESTAMP;
  
  BEGIN
  
    DBG('Start of function fn_iceod_wrap');
  
    ICPKS_PARTITION_INFO.G_THIS_PART := NVL(P_PROCESS, 1);
  
    DBG('After this Debug would be available in SYSTEM');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 11;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      RETVAL := ICPKS_TEST_CLUSTER.FN_ICEOD_WRAP(P_BRN,
                                                 P_TAX_PROD,
                                                 P_PROCESS,
                                                 P_AC_CLASS_TYPE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
      IF RETVAL = 0 THEN
        DBG('Error in From icpks_test_cluster.fn_iceod_wrap');
      ELSE
        DBG('Back From icpks_test_cluster.fn_iceod_wrap');
      END IF;
    END IF;
  
    ICPKS_UTIL.PR_UPDATE_LINE_ACCOUNT(P_BRN, P_PROCESS);
  
    IF ICPKS_TEST.P_IC_MAX_PROCESS = 1 THEN
    
      GLOBAL.PR_INIT(P_BRN);
    END IF;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 4;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      RETVAL            := ICPKS_TEST_CLUSTER.FN_ICEOD_WRAP(P_BRN,
                                                            P_TAX_PROD,
                                                            P_PROCESS,
                                                            P_AC_CLASS_TYPE,
                                                            L_FN_CALL_ID,
                                                            L_TB_CLUSTER_DATA);
      IF RETVAL = 0 THEN
        DBG('Error in From icpks_test_cluster.fn_iceod_wrap');
      ELSE
        DBG('Back From icpks_test_cluster.fn_iceod_wrap');
      END IF;
    END IF;
  
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      IF GLOBALS_ADDON.ILM_INSTALLED = 'Y' THEN
        DBG('about to call ilpks_batch_0.fn_check_pre_IC_EOD');
        DBG('p_brn' || P_BRN);
        DBG('global.application_date' || GLOBAL.APPLICATION_DATE);
        IF NOT ILPKS_BATCH_0.FN_CHECK_PRE_IC_EOD(P_BRN,
                                                 GLOBAL.APPLICATION_DATE,
                                                 L_ERROR_CODE,
                                                 L_ERROR_PARAMETER) THEN
          DBG('Failed in icpks_test.pr_iceod_wrap in call to ilpks_batch_0.fn_check_pre_IC_EOD');
          DBG('l_error_code' || L_ERROR_CODE);
          DBG('l_error_parameter' || L_ERROR_PARAMETER);
        
          IF L_ERROR_CODE = 'IL-BCH-098' THEN
          
            RETURN - 6;
          ELSE
            RETURN - 7;
          END IF;
        END IF;
      END IF;
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    PR_INIT_VALS(P_BRN);
  
    SELECT B.END_OF_INPUT
      INTO EOD_STAT
      FROM STTMS_BRANCH B
     WHERE B.BRANCH_CODE = P_BRN;
  
    IF GLOBAL.X9$ <> 'EURDAB' THEN
      IF EOD_STAT = 'N' THEN
        RETURN - 2;
      ELSIF EOD_STAT <> 'T' THEN
        RETURN - 3;
      END IF;
    END IF;
  
    BEGIN
      SELECT PROCESS_TILL
        INTO PRO_TILL
        FROM ICTMS_BRANCH_PARAMETERS
       WHERE BRANCH_CODE = P_BRN
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN - 5;
    END;
    PKG_PROCESS_TILL        := PRO_TILL;
    ICPKS_TEST.G_ONLIQ_FLAG := 'N';
  
    DELETE ICTBS_BOOK_ERR E
     WHERE E.BRN = P_BRN
       AND EXISTS
     (SELECT 1
              FROM CSTB_CUSTACSEQ
             WHERE BRANCH_CODE = P_BRN
               AND CUST_AC_NO = E.ACC
               AND SEQ_NO = ICPKS_PARTITION_INFO.GETPART);
  
    BEGIN
      ICPKSS_UTIL.PR_CREATE_CCYTAB(P_BRN);
    EXCEPTION
      WHEN OTHERS THEN
        DBG(' Bombed while creating the ccy tab ' || SQLERRM);
        LOG_PROBLEM(-1,
                    'Y',
                    'WOT in create CCY tab ' || SUBSTR(SQLERRM, 1, 1900));
        RETURN - 4;
    END;
  
    IF ICPKS_TEST.P_IC_MAX_PROCESS = 1 THEN
    
      IF CSPKS_FEATURE.FN_INSTALLED('DORMUPD', GLOBAL.CURRENT_BRANCH) THEN
        IF (P_TAX_PROD = 'N' AND P_AC_CLASS_TYPE <> 'L') THEN
          IF NOT ACPKS_EOD.FN_MARK_DORMANCY_NEW(P_BRN, APPDT, PERRCODE) THEN
            RETURN - 1;
          END IF;
        
        END IF;
      END IF;
    
      IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN,
                                                 MAINT_ERR_CODE,
                                                 MAINT_ERR_PARAM) THEN
        RETURN - 1;
      END IF;
    
      ICPKSS_UDE.PR_MAKE_UDE_ROW(P_BRN);
    
      IF CSPKS_FEATURE.FN_INSTALLED('IC_RERESOLVE', GLOBAL.HEAD_OFFICE) THEN
        DBG('PKG_RES_RETRY_COUNT --> ' || PKG_RES_RETRY_COUNT);
        IF PKG_RES_RETRY_COUNT > 0 THEN
          FOR I IN 1 .. PKG_RES_RETRY_COUNT LOOP
            DBG('RESOLUTION RETRY COUNT:' || I);
            PR_RETRY_RESOLUTION(P_BRN);
            IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(P_BRN,
                                                       MAINT_ERR_CODE,
                                                       MAINT_ERR_PARAM) THEN
              DBG('FAILED IN RETRY COUNT:' || I);
            END IF;
          
            ICPKSS_UDE.PR_MAKE_UDE_ROW;
          
          END LOOP;
        END IF;
        DBG('RETRY DONE');
      END IF;
    
    END IF;
    BEGIN
      SELECT NVL(PC_END_DATE, NWD)
        INTO PER_END
        FROM STTMS_BRANCH B, STTMS_PERIOD_CODES P
       WHERE B.BRANCH_CODE = P_BRN
         AND P.PERIOD_CODE = B.CURRENT_PERIOD
         AND P.FIN_CYCLE = B.CURRENT_CYCLE;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN - 2;
    END;
    IF PRO_TILL = 'S' THEN
      TO_DT := APPDT;
    ELSE
      TO_DT := NWD;
    END IF;
    IF NWD >= PER_END THEN
      TO_DT := PER_END;
    END IF;
    ICPKSS_TEST.NWD := TO_DT;
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      RETVAL := ICPKS_TEST_CLUSTER.FN_ICEOD_WRAP(P_BRN,
                                                 P_TAX_PROD,
                                                 P_PROCESS,
                                                 P_AC_CLASS_TYPE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
      IF RETVAL = 0 THEN
        DBG('Error in From icpks_test_cluster.fn_iceod_wrap');
      ELSE
        DBG('Back From icpks_test_cluster.fn_iceod_wrap');
      END IF;
    END IF;
  
    DBG('final nwd is' || TO_DT || '~' || ICPKSS_TEST.NWD);
  
    G_IC_RUNNING := FALSE;
  
    IF (P_TAX_PROD = 'N' AND P_AC_CLASS_TYPE <> 'L') THEN
    
      IF CSPKS_FEATURE.FN_INSTALLED('VDBALINIC') THEN
        L_START_TIME := SYSTIMESTAMP;
      
        N_PART := NVL(CSPKS_PARALLEL_STREAM.FN_STREAM_COUNT('VDBALUPD',
                                                            P_BRN),
                      0);
      
        SELECT NUM_PROCESS
          INTO L_NUM_PROC
          FROM ICTM_BRANCH_PARAMETERS
         WHERE BRANCH_CODE = P_BRN;
      
        IF N_PART = 1 AND L_NUM_PROC = 1 THEN
        
          IF NOT ACPKS_VDBAL.FN_BATCH_UPDATE(P_BRN, VD_ERR, VD_ERP) THEN
            RETURN - 1;
          END IF;
        ELSE
        
          IF NOT
              ACPKS_VDBAL.FN_UPDATE_FOR_SEQ(P_BRN, VD_ERR, VD_ERP, P_PROCESS) THEN
            DBG('Failed in acpks_vdbal.fn_update_for_seq : ' || VD_ERR || '~' ||
                VD_ERP);
            LPG('Failed in vd bal update ' || VD_ERR || '~' || VD_ERP || '~' ||
                SUBSTR(SQLERRM, 1, 1000),
                '');
            RETURN - 1;
          END IF;
        
        END IF;
      
      END IF;
    
    ELSIF (P_TAX_PROD = 'Y' AND P_AC_CLASS_TYPE <> 'L') THEN
      IF NOT FN_TDS_DATA_COLLECTION(P_BRN, TO_DT, VD_ERR, VD_ERP, P_PROCESS) THEN
        DBG('Failed in TDS data collection ' || VD_ERR);
        RETURN - 1;
      END IF;
    END IF;
    IF P_AC_CLASS_TYPE <> 'L' THEN
    
      ICPKSS_BOOK.PR_ACCRUAL_REVERSAL(P_BRN, P_PROCESS);
    END IF;
    FOR Z IN CUR_BKVAL_REQD LOOP
      PKG_BKVAL_REQD := TRUE;
      EXIT;
    END LOOP;
    IF (PKG_BKVAL_REQD AND P_AC_CLASS_TYPE <> 'L') THEN
    
      IF ICPKS_TEST.P_IC_MAX_PROCESS = 1 THEN
      
        IF NOT ICPKSS_TEST.FN_MARK_BKCALC_FOR_UDEVALS(P_BRN) THEN
          RETURN - 1;
        END IF;
      
      END IF;
    
      IF NOT ICPKSS_TEST.FN_BKVAL_CALC(P_BRN, NULL) THEN
        RETURN - 1;
      END IF;
    END IF;
    IF NVL(TB_BRN.COUNT, 0) <> 0 THEN
      ICPKSS_TEST.TB_BRN.DELETE;
      ICPKSS_TEST.TB_ACC.DELETE;
      ICPKSS_TEST.TB_NEXT_CALC_DT.DELETE;
      ICPKSS_TEST.TB_NEXT_LIQ_DT.DELETE;
      ICPKSS_TEST.TB_NEXT_ACCR_DT.DELETE;
      ICPKSS_TEST.TB_LAST_CALC_DT.DELETE;
      ICPKSS_TEST.TB_LAST_LIQ_DT.DELETE;
      ICPKSS_TEST.TB_LAST_ACCR_DT.DELETE;
      ICPKSS_TEST.TB_FIRST_CALC_DT.DELETE;
    
      ICPKSS_TEST.TB_PROD.DELETE;
      ICPKSS_TEST.TB_SC_MAP_DT.DELETE;
      ICPKSS_TEST.TB_GC_MAP_DT.DELETE;
      ICPKSS_TEST.TB_LAST_SCHD_LIQ_DT.DELETE;
      ICPKSS_TEST.TB_INC_MTH.DELETE;
      ICPKSS_TEST.TB_NEXT_SCHD_LIQ_DT.DELETE;
      ICPKSS_TEST.TB_NEXT_SCHD_ACCR_DT.DELETE;
      ICPKSS_TEST.TB_PROD_TYPE.DELETE;
      ICPKSS_TEST.TB_HAS_ACCR.DELETE;
      ICPKSS_TEST.TB_PROD_ACCR.DELETE;
      ICPKSS_TEST.TB_HAS_PROBLEMS.DELETE;
      ICPKSS_TEST.TB_BKVAL_MINCALC_DATE.DELETE;
      ICPKSS_TEST.TB_BKVAL_RECALC_FLAG.DELETE;
      ICPKSS_TEST.TB_FIRST_FIRST_CALC_DATE.DELETE;
      ICPKSS_TEST.TB_IMAT_PROBLEMS.DELETE;
      ICPKSS_TEST.TB_DEPOSIT.DELETE;
      ICPKSS_TEST.TB_ACLASS.DELETE;
      ICPKSS_TEST.TB_CCY.DELETE;
      ICPKSS_TEST.TB_PROCESS.DELETE;
      ICPKSS_TEST.TB_DEFER_LIQ_DT.DELETE;
      ICPKSS_TEST.TB_NEXT_EVENT_DT.DELETE;
      ICPKSS_TEST.TB_ROWID.DELETE;
      ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN.DELETE;
    
    END IF;
    PR_PURGE_PLSQL_TABS;
  
    UPDATE ICTBS_ACC_PR
       SET HAS_PROBLEMS       = 'N',
           BKVAL_RECALC_FLAG  = NULL,
           BKVAL_MINCALC_DATE = NULL
    
     WHERE BRN = P_BRN
       AND HAS_PROBLEMS = 'Y'
          
       AND PROCESS = P_PROCESS;
    COMMIT;
  
    SELECT LEAST(NVL(MIN(P.NEXT_ACCR_DT), APPDT),
                 NVL(MIN(P.NEXT_LIQ_DT), APPDT),
                 NVL(MIN(P.NEXT_CALC_DT), APPDT))
      INTO FROM_DT
      FROM ICTBS_ACC_PR P
     WHERE P.BRN = P_BRN
       AND P.PROD_TYPE = 'I'
          
       AND (STOP_IC IS NULL OR STOP_IC = 'N');
  
    IF FROM_DT > APPDT THEN
      FROM_DT := APPDT;
    END IF;
  
    T_FROM_DT := APPDT;
  
    IF P_AC_CLASS_TYPE <> 'L' THEN
    
      SELECT COUNT(1)
        INTO LCHGSTARTADVREQD
        FROM STTMS_ACCOUNT_CLASS
       WHERE CHG_START_ADV = 'Y'
         AND ROWNUM = 1;
    
      DBG('Account classes with charge start adv as yes' ||
          LCHGSTARTADVREQD);
    
      IF PKG_CHG_COUNT > 0 AND NVL(LCHGSTARTADVREQD, 0) <> 0 THEN
        WHILE (T_FROM_DT <= TO_DT) LOOP
          ICPKSS_CHARGE.PR_CHARGE_START_ADVICE(T_FROM_DT, P_PROCESS);
          T_FROM_DT := T_FROM_DT + 1;
        END LOOP;
      
      ELSE
        DBG('No account classes with charge start advice as Yes');
      
      END IF;
    END IF;
    L_START_TIME := SYSTIMESTAMP;
  
    IF NOT ICPKS_UTIL.FN_VALIDATE_MIN_MAX_UDE_EOD(P_BRN, P_PROCESS) THEN
      DBG('FN_Validate_Min_Max_UDE_EOD has returned false');
    END IF;
  
    GLOBAL.PR_RESET_SKIP_KERNEL;
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 3;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      L_TB_CLUSTER_DATA('from_dt') := FROM_DT;
      L_TB_CLUSTER_DATA('to_dt') := TO_DT;
    
      RETVAL := ICPKS_TEST_CLUSTER.FN_ICEOD_WRAP(P_BRN,
                                                 P_TAX_PROD,
                                                 P_PROCESS,
                                                 P_AC_CLASS_TYPE,
                                                 L_FN_CALL_ID,
                                                 L_TB_CLUSTER_DATA);
      IF RETVAL = 0 THEN
        DBG('Error in From icpks_test_cluster.fn_iceod_wrap');
      ELSE
        DBG('Back From icpks_test_cluster.fn_iceod_wrap');
      END IF;
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    ICPKSS_TEST.PR_ICEOD_WRAP(P_BRN,
                              FROM_DT,
                              TO_DT,
                              P_TAX_PROD,
                              P_PROCESS,
                              P_AC_CLASS_TYPE);
  
    IF CSPKS_FEATURE.FN_INSTALLED('IC_INTRADAY_BATCH', P_BRN) THEN
      DBG('Will now post intraday accrual entries..');
      ICPKS_DEFERRED_ENTRIES.PR_POST_ENTRIES(P_BRN,
                                             ICPKS_PARTITION_INFO.G_THIS_PART,
                                             TRUE);
    END IF;
  
    G_IC_RUNNING := FALSE;
  
    UPDATE ICTBS_ACC_PR
       SET IMAT_PROBLEMS = 'N'
     WHERE IMAT_PROBLEMS = 'Y'
       AND BRN = P_BRN;
    COMMIT;
  
    IF P_TAX_PROD = 'N' THEN
      PR_PURGE_PLSQL_TABS;
    
      IF NVL(TB_BRN.COUNT, 0) <> 0 THEN
        ICPKSS_TEST.TB_BRN.DELETE;
        ICPKSS_TEST.TB_ACC.DELETE;
        ICPKSS_TEST.TB_NEXT_CALC_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_LAST_CALC_DT.DELETE;
        ICPKSS_TEST.TB_LAST_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_LAST_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_FIRST_CALC_DT.DELETE;
        ICPKSS_TEST.TB_PROD.DELETE;
        ICPKSS_TEST.TB_SC_MAP_DT.DELETE;
        ICPKSS_TEST.TB_GC_MAP_DT.DELETE;
        ICPKSS_TEST.TB_LAST_SCHD_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_INC_MTH.DELETE;
        ICPKSS_TEST.TB_NEXT_SCHD_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_SCHD_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_PROD_TYPE.DELETE;
        ICPKSS_TEST.TB_HAS_ACCR.DELETE;
        ICPKSS_TEST.TB_PROD_ACCR.DELETE;
        ICPKSS_TEST.TB_HAS_PROBLEMS.DELETE;
        ICPKSS_TEST.TB_BKVAL_MINCALC_DATE.DELETE;
        ICPKSS_TEST.TB_BKVAL_RECALC_FLAG.DELETE;
        ICPKSS_TEST.TB_FIRST_FIRST_CALC_DATE.DELETE;
        ICPKSS_TEST.TB_IMAT_PROBLEMS.DELETE;
        ICPKSS_TEST.TB_DEPOSIT.DELETE;
        ICPKSS_TEST.TB_ACLASS.DELETE;
        ICPKSS_TEST.TB_CCY.DELETE;
        ICPKSS_TEST.TB_PROCESS.DELETE;
        ICPKSS_TEST.TB_DEFER_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_EVENT_DT.DELETE;
        ICPKSS_TEST.TB_ROWID.DELETE;
        ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN.DELETE;
        DBG('after all deletes');
      END IF;
    
      IF P_AC_CLASS_TYPE <> 'L' THEN
        BOD_STAT := ICPKSS_BOD.ICFN_BOD(P_BRN, FROM_DT, P_PROCESS);
      END IF;
      IF P_AC_CLASS_TYPE <> 'L' THEN
        BOD_STAT := ICPKSS_BOD.FN_PR_UNCLAIMED(P_BRN, APPDT, P_PROCESS);
      
      END IF;
    
      ICPKS_BOD.G_FROMBOD         := FALSE;
      ICPKS_BOD.UNCLAIMED_PROCESS := NULL;
    
      IF BOD_STAT <> 0 THEN
        ICPKSS_EOD.EOD_RETSTAT := 4;
      END IF;
    
      IF GLOBAL.VDBAL_UPDATE = 'ONLINE' THEN
      
        SELECT COUNT(*)
          INTO N_CHG_PROD
          FROM CSTM_PRODUCT P, ICTM_PR_CHG C
         WHERE P.PRODUCT_CODE = C.PRODUCT_CODE
           AND P.RECORD_STAT = 'O'
           AND P.ONCE_AUTH = 'Y';
        IF N_CHG_PROD <> 0 THEN
          IF NOT ACPKSS_VDBAL.FN_UPDATE_CHG_ONL(P_BRN,
                                                VD_ERR,
                                                VD_ERP,
                                                P_PROCESS) THEN
            RETURN - 1;
          END IF;
        END IF;
      
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 2;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
        RETVAL            := ICPKS_TEST_CLUSTER.FN_ICEOD_WRAP(P_BRN,
                                                              P_TAX_PROD,
                                                              P_PROCESS,
                                                              P_AC_CLASS_TYPE,
                                                              L_FN_CALL_ID,
                                                              L_TB_CLUSTER_DATA);
        IF RETVAL = 0 THEN
          DBG('Error in From icpks_test_cluster.fn_iceod_wrap');
        ELSE
          DBG('Back From icpks_test_cluster.fn_iceod_wrap');
        END IF;
      END IF;
    
      IF PKG_CHG_COUNT > 0 THEN
        L_START_CHG_TIME := SYSTIMESTAMP;
      
        IF NOT ICPKS_CHARGE.FN_LIQUIDATE_CHARGES(P_BRN, VD_ERR, P_PROCESS) THEN
          RETURN - 1;
        END IF;
      
        SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
          INTO CHG_DT
          FROM (SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
                  FROM ICTBS_ACC_PR P
                 WHERE P.BRN = P_BRN
                   AND P.PROD_TYPE IN ('C', 'S')
                   AND P.HAS_PROBLEMS = 'N'
                   AND NVL(P.PROCESS, 1) = NVL(P_PROCESS, 1)
                   AND P.BILLING_PROD = 'N'
                   AND ((EXISTS
                        (SELECT 1
                            FROM ICTMS_PR_CHG C
                           WHERE NVL(PRODUCT_CODE, P.PROD) = P.PROD
                             AND C.CHARGE_BASIS = 'MINIMUM-CHARGE')) OR
                       (EXISTS (SELECT 1
                                   FROM ICTM_PR_CHG_PRODS D, ICTMS_PR_CHG E
                                  WHERE D.CHG_PROD = E.PRODUCT_CODE
                                    AND D.PRODUCT = P.PROD)))
                UNION ALL
                SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
                  FROM ICTBS_ACC_PR P
                 WHERE P.BRN = P_BRN
                   AND P.PROD_TYPE IN ('C', 'S')
                   AND P.HAS_PROBLEMS = 'N'
                   AND NVL(P.PROCESS, 1) = NVL(P_PROCESS, 1)
                   AND P.BILLING_PROD = 'N'
                   AND (EXISTS (SELECT 1
                                  FROM ICTBS_CHG_VAL
                                 WHERE BRN = P_BRN
                                   AND ACC = P.ACC
                                   AND NVL(PROD, P.PROD) = P.PROD
                                   AND ELEM_VAL > 0
                                   AND NVL(ITM_DT, TO_DT) <= TO_DT)));
      
        WHILE CHG_DT <= TO_DT LOOP
        
          IF NOT ICPKSS_CHARGE.FN_CHARGE(P_BRN, CHG_DT, VD_ERR, P_PROCESS) THEN
          
            RETURN - 1;
          END IF;
          CHG_DT := CHG_DT + 1;
        
          SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
            INTO REV_CHG_DT
            FROM (SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
                    FROM ICTBS_ACC_PR P
                   WHERE P.BRN = P_BRN
                     AND P.PROD_TYPE IN ('C', 'S')
                     AND P.HAS_PROBLEMS = 'N'
                     AND NVL(P.PROCESS, 1) = NVL(P_PROCESS, 1)
                     AND P.BILLING_PROD = 'N'
                     AND ((EXISTS
                          (SELECT 1
                              FROM ICTMS_PR_CHG C
                             WHERE NVL(PRODUCT_CODE, P.PROD) = P.PROD
                               AND C.CHARGE_BASIS = 'MINIMUM-CHARGE')) OR
                         (EXISTS (SELECT 1
                                     FROM ICTM_PR_CHG_PRODS D, ICTMS_PR_CHG E
                                    WHERE D.CHG_PROD = E.PRODUCT_CODE
                                      AND D.PRODUCT = P.PROD)))
                  UNION ALL
                  SELECT MIN(NEXT_LIQ_DT) NEXT_LIQ_DT
                    FROM ICTBS_ACC_PR P
                   WHERE P.BRN = P_BRN
                     AND P.PROD_TYPE IN ('C', 'S')
                     AND P.HAS_PROBLEMS = 'N'
                     AND NVL(P.PROCESS, 1) = NVL(P_PROCESS, 1)
                     AND P.BILLING_PROD = 'N'
                     AND (EXISTS (SELECT 1
                                    FROM ICTBS_CHG_VAL
                                   WHERE BRN = P_BRN
                                     AND ACC = P.ACC
                                     AND NVL(PROD, P.PROD) = P.PROD
                                     AND ELEM_VAL > 0
                                     AND NVL(ITM_DT, TO_DT) <= TO_DT)));
        
          IF REV_CHG_DT > CHG_DT THEN
            CHG_DT := REV_CHG_DT;
          END IF;
        
        END LOOP;
      
      END IF;
    
      IF BOD_STAT <> 0 THEN
        ICPKSS_EOD.EOD_RETSTAT := 4;
      END IF;
    END IF;
    IF (P_TAX_PROD = 'Y' AND P_AC_CLASS_TYPE <> 'L') THEN
      IF NOT FN_UPDATE_TDS_AMOUNT(P_BRN, VD_ERR, VD_ERP, P_PROCESS) THEN
        RETURN - 1;
      END IF;
    END IF;
  
    IF NOT FN_PROPAGATE_TD_RATE_TO_CL(P_BRN, P_PROCESS) THEN
      RETURN - 1;
    END IF;
  
    COMMIT;
    RETURN ICPKSS_EOD.EOD_RETSTAT;
  EXCEPTION
    WHEN OTHERS THEN
    
      ICPKSS_HASH_PR.INIT_HASH_PR;
      G_IC_RUNNING := FALSE;
    
      IF NVL(TB_BRN.COUNT, 0) > 0 THEN
        ICPKSS_TEST.TB_BRN.DELETE;
        ICPKSS_TEST.TB_ACC.DELETE;
        ICPKSS_TEST.TB_NEXT_CALC_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_LAST_CALC_DT.DELETE;
        ICPKSS_TEST.TB_LAST_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_LAST_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_FIRST_CALC_DT.DELETE;
        ICPKSS_TEST.TB_PROD.DELETE;
        ICPKSS_TEST.TB_SC_MAP_DT.DELETE;
        ICPKSS_TEST.TB_GC_MAP_DT.DELETE;
        ICPKSS_TEST.TB_LAST_SCHD_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_INC_MTH.DELETE;
        ICPKSS_TEST.TB_NEXT_SCHD_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_NEXT_SCHD_ACCR_DT.DELETE;
        ICPKSS_TEST.TB_PROD_TYPE.DELETE;
        ICPKSS_TEST.TB_HAS_ACCR.DELETE;
        ICPKSS_TEST.TB_PROD_ACCR.DELETE;
        ICPKSS_TEST.TB_HAS_PROBLEMS.DELETE;
        ICPKSS_TEST.TB_BKVAL_MINCALC_DATE.DELETE;
        ICPKSS_TEST.TB_BKVAL_RECALC_FLAG.DELETE;
        ICPKSS_TEST.TB_FIRST_FIRST_CALC_DATE.DELETE;
        ICPKSS_TEST.TB_IMAT_PROBLEMS.DELETE;
        ICPKSS_TEST.TB_DEPOSIT.DELETE;
        ICPKSS_TEST.TB_ACLASS.DELETE;
        ICPKSS_TEST.TB_CCY.DELETE;
        ICPKSS_TEST.TB_PROCESS.DELETE;
        ICPKSS_TEST.TB_NEXT_EVENT_DT.DELETE;
        ICPKSS_TEST.TB_DEFER_LIQ_DT.DELETE;
        ICPKSS_TEST.TB_ROWID.DELETE;
        ICPKSS_TEST.TB_SYS_AC_LEVEL.DELETE;
        ICPKSS_TEST.TB_SUBLEVEL.DELETE;
        ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN.DELETE;
      END IF;
      DBG('Rollback done here ');
      ROLLBACK;
    
      TB_HOFF_CONS.DELETE;
      TB_HOFF_PROD.DELETE;
    
      DBG('In when others of fn_iceod_wrap ' || SQLERRM);
      ACPKSS.PR_SET_BATCH_ACC(FALSE);
      DBG(SQLERRM);
      DBG(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
      RETURN - 1;
  END FN_ICEOD_WRAP;

  FUNCTION FN_MARK_BKCALC_FOR_UDEVALS(P_BRN ICTBS_ACC_PR.BRN%TYPE)
    RETURN BOOLEAN IS
    TYPE T1 IS TABLE OF ICTBS_BACK_DATED_EVENTS.BRN%TYPE INDEX BY BINARY_INTEGER;
    TYPE T2 IS TABLE OF ICTBS_BACK_DATED_EVENTS.ACC%TYPE INDEX BY BINARY_INTEGER;
    TYPE T3 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROD%TYPE INDEX BY BINARY_INTEGER;
    TYPE T4 IS TABLE OF ICTBS_BACK_DATED_EVENTS.EVENT_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T5 IS TABLE OF ICTBS_BACK_DATED_EVENTS.EVENT_DATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T6 IS TABLE OF ICTBS_BACK_DATED_EVENTS.VALUE_DT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T7 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_ID%TYPE INDEX BY BINARY_INTEGER;
    TYPE T8 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_AMT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T9 IS TABLE OF ICTBS_BACK_DATED_EVENTS.RATE_CODE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T10 IS TABLE OF ICTBS_BACK_DATED_EVENTS.RATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T11 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_CHG_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T12 IS TABLE OF ICTBS_BACK_DATED_EVENTS.ENT_AMOUNT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T13 IS TABLE OF ICTBS_BACK_DATED_EVENTS.DRCR_IND%TYPE INDEX BY BINARY_INTEGER;
    TYPE T14 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROCESS_STATUS%TYPE INDEX BY BINARY_INTEGER;
    TYPE T15 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROCESS_FROM_DATE%TYPE INDEX BY BINARY_INTEGER;
    TB_BKDT_EVENTS_BRN            T1;
    TB_BKDT_EVENTS_ACC            T2;
    TB_BKDT_EVENTS_PROD           T3;
    TB_BKDT_EVENTS_EVENT_TYPE     T4;
    TB_BKDT_EVENTS_EVENT_DATE     T5;
    TB_BKDT_EVENTS_VALUE_DT       T6;
    TB_BKDT_EVENTS_UDE_ID         T7;
    TB_BKDT_EVENTS_UDE_AMT        T8;
    TB_BKDT_EVENTS_RATE_CODE      T9;
    TB_BKDT_EVENTS_RATE           T10;
    TB_BKDT_EVENTS_UDE_CHG_TYPE   T11;
    TB_BKDT_EVENTS_ENT_AMOUNT     T12;
    TB_BKDT_EVENTS_ENT_DRCR_IND   T13;
    TB_BKDT_EVENTS_ENT_PROC_STAT  T14;
    TB_BKDT_EVENTS_ENT_PROC_FRMDT T15;
    TYPE TB1 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.BRN%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB2 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.PROD%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB3 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.COND_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB4 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.COND_KEY%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB5 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.UDE_ID%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB6 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.UDE_EFF_DT%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB7 IS TABLE OF ROWID INDEX BY BINARY_INTEGER;
    TB_BKDT_EVEDEL_BRN        TB1;
    TB_BKDT_EVEDEL_PROD       TB2;
    TB_BKDT_EVEDEL_COND_TYPE  TB3;
    TB_BKDT_EVEDEL_COND_KEY   TB4;
    TB_BKDT_EVEDEL_UDE_ID     TB5;
    TB_BKDT_EVEDEL_UDE_EFF_DT TB6;
    TYPE TC1 IS TABLE OF ICTBS_ACC_PR.BKVAL_MINCALC_DATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE TC2 IS TABLE OF ICTBS_ACC_PR.BKVAL_RECALC_FLAG%TYPE INDEX BY BINARY_INTEGER;
  
    TYPE TC3 IS TABLE OF ICTBS_ACC_PR.NEXT_LIQ_DT%TYPE INDEX BY BINARY_INTEGER;
    TB_BKACCPR_NEXTLIQ_DT TC3;
    L_UDE_EFF_DT          ICTBS_BACK_DATED_UDEVALS.UDE_EFF_DT%TYPE;
    L_BV_POOL_PERIOD      STTMS_BRANCH.BACK_VALUE_DAYS%TYPE;
  
    TB_BKACCPR_RECALC_FLAG   TC2;
    TB_BKACCPR_MINCALC_DATE  TC1;
    TB_BKACCPR_ROWID         TB7;
    L_BACK_VALUED_EVENTS_REC ICTBS_BACK_DATED_EVENTS%ROWTYPE;
    NULREC                   ICTBS_BACK_DATED_EVENTS%ROWTYPE;
    I                        NUMBER := 0;
    J                        NUMBER := 0;
    SR                       NUMBER := 0;
  
    L_ICTMS_ACC ICTM_ACC%ROWTYPE;
    CURSOR CR_UDEVALS(P_BRN VARCHAR2) IS
      SELECT *
        FROM ICTBS_BACK_DATED_UDEVALS I, ICTMS_PR_INT P
       WHERE I.BRN = P_BRN
         AND I.PROD = P.PRODUCT_CODE
         AND (P.BACK_CALC_FLAG = 'Y' OR
             (P.DEFERRED_FLAG = 'Y' AND P.CALC_DAYS > 0))
      
       ORDER BY COND_TYPE, COND_KEY, UDE_EFF_DT DESC;
  
    CURSOR CR_SC_ACC_PR(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
      SELECT A.*, ROWID ROW_ID
        FROM ICTBS_ACC_PR A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = P_PROD;
    CURSOR CR_GC_ACC_PR(P_BRN      VARCHAR2,
                        P_PROD     VARCHAR2,
                        P_COND_KEY VARCHAR2) IS
      SELECT A.*, ROWID ROW_ID
        FROM ICTBS_ACC_PR A
       WHERE A.BRN = P_BRN
         AND A.PROD = P_PROD
         AND A.ACLASS || A.CCY = P_COND_KEY
            
         AND A.SC_MAP_DT IS NULL;
  
    FUNCTION FN_MARK_BKCALC_FOR_IL(P_BRANCH                IN ILTBS_SYS_ACCOUNT.BRANCH_CODE%TYPE,
                                   P_PRODUCT_CODE          IN ICTMS_PR_INT.PRODUCT_CODE%TYPE,
                                   P_LIQN_START_ACCOUNT    IN ICTMS_PR_INT.LIQN_START_ACCOUNT%TYPE,
                                   P_START_LIQ_DT          IN ILTBS_SYS_ACCOUNT.EFF_DATE%TYPE,
                                   P_LIQN_DAYS             IN ICTMS_PR_INT.LIQN_DAYS%TYPE,
                                   P_LIQN_MONTHS           IN ICTMS_PR_INT.LIQN_MONTHS%TYPE,
                                   P_LIQN_YEARS            IN ICTMS_PR_INT.LIQN_YEARS%TYPE,
                                   P_UDE_EFF_DATE          IN ILTBS_SYS_ACCOUNT.EFF_DATE%TYPE,
                                   P_CHANGE_TYPE           IN VARCHAR2,
                                   P_CONDITION_TYPE        IN NUMBER,
                                   P_COND_KEY              IN ICTBS_BACK_DATED_UDEVALS.COND_KEY%TYPE,
                                   TB_BKACCPR_RECALC_FLAG  IN OUT TC2,
                                   TB_BKACCPR_MINCALC_DATE IN OUT TC1,
                                   TB_BKACCPR_ROWID        IN OUT TB7,
                                   TB_BKACCPR_NEXTLIQ_DT   IN OUT TC3,
                                   P_SR                    IN OUT NUMBER)
      RETURN BOOLEAN IS
      CURSOR CR_SPECIAL_CONDITIONS(C_ACC VARCHAR2, C_UDE_EFF_DATE DATE) IS
        SELECT A.*,
               B.SYSTEM_ACCOUNT_BRANCH,
               B.ACCOUNT CUST_ACCOUNT,
               A.ROWID
          FROM ICTBS_ACC_PR A, ILTBS_SYS_ACCOUNT B, ICTMS_ACC_PR C
         WHERE A.BRN = P_BRANCH
           AND A.PROD = P_PRODUCT_CODE
           AND B.BRANCH_CODE = A.BRN
           AND INSTR(C_ACC, B.ACCOUNT, 1) > 0
           AND B.SYSTEM_ACCOUNT = A.ACC
           AND NVL(A.SYSTEM_ACCOUNT, 'N') = 'Y'
           AND C.BRN = A.BRN
           AND C.ACC = B.ACCOUNT
           AND C.PROD = P_PRODUCT_CODE
              
           AND NVL(A.STOP_IC, 'N') NOT IN ('D', 'Y')
              
           AND NVL(C.WAIVE, 'N') = 'N'
           AND (NVL(A.LAST_LIQ_DT, (C_UDE_EFF_DATE - 1)) >= C_UDE_EFF_DATE OR
               A.BKVAL_MINCALC_DATE IS NOT NULL);
      CURSOR CR_GENERAL_CONDITIONS(C_UDE_EFF_DATE DATE) IS
        SELECT A.*,
               B.SYSTEM_ACCOUNT_BRANCH,
               B.ACCOUNT CUST_ACCOUNT,
               A.ROWID
          FROM ICTBS_ACC_PR A, ILTBS_SYS_ACCOUNT B
         WHERE A.BRN = P_BRANCH
           AND A.PROD = P_PRODUCT_CODE
           AND INSTR(P_COND_KEY, A.ACLASS || A.CCY, 1) > 0
           AND B.BRANCH_CODE = A.BRN
           AND B.SYSTEM_ACCOUNT = A.ACC
           AND NVL(A.SYSTEM_ACCOUNT, 'N') = 'Y'
              
           AND NVL(A.STOP_IC, 'N') NOT IN ('D', 'Y')
           AND ((NVL(A.LAST_LIQ_DT, C_UDE_EFF_DATE - 1) >= C_UDE_EFF_DATE AND
               NVL(A.SC_MAP_DT, C_UDE_EFF_DATE + 1) > C_UDE_EFF_DATE) OR
               A.BKVAL_MINCALC_DATE IS NOT NULL);
      CURSOR C_SYS_CUR(C_BRANCH       VARCHAR2,
                       C_GROUP_CODE   VARCHAR2,
                       C_UDE_EFF_DATE VARCHAR2) IS
        SELECT A.SYSTEM_ACCOUNT_BRANCH,
               A.SYSTEM_ACCOUNT,
               A.ACC_TYPE,
               B.PROD,
               B.ROWID
          FROM ILTBS_SYS_ACCOUNT A, ICTB_ACC_PR B
         WHERE B.BRN = A.BRANCH_CODE
           AND B.ACC = A.SYSTEM_ACCOUNT
           AND A.BRANCH_CODE = C_BRANCH
           AND A.GROUP_CODE = C_GROUP_CODE
           AND A.EFF_DATE =
               (SELECT MAX(EFF_DATE)
                  FROM ILTBS_SYS_ACCOUNT C
                 WHERE C.BRANCH_CODE = A.BRANCH_CODE
                   AND C.GROUP_CODE = A.GROUP_CODE
                   AND C.ACCOUNT = A.ACCOUNT
                   AND C.ACC_TYPE = A.ACC_TYPE
                   AND EFF_DATE <= C_UDE_EFF_DATE);
      L_NEXT_LIQD_DT          DATE;
      L_ROWID                 VARCHAR2(20);
      L_BKVAL_MINCALC_DATE    ICTBS_ACC_PR.BKVAL_MINCALC_DATE%TYPE;
      L_LAST_LIQ_DT           ICTBS_ACC_PR.LAST_LIQ_DT%TYPE;
      L_PREV_CUST_ACCOUNT     ICTBS_ACC_SYS_MAP.CUST_AC_NO%TYPE;
      L_COMBVT_DATE           DATE;
      L_COMBVT_DATE_POOL      DATE;
      L_VAL_DT                DATE;
      L_INT_START_DATE        DATE;
      L_MASTER_NEXT_LIQ_DT    DATE;
      L_MASTER_INT_START_DATE DATE;
      L_GROUP_CODE            ILTMS_GROUP_CODE.GROUP_CODE%TYPE;
      TYPE G_GRP_TAB IS TABLE OF ILTMS_GROUP_CODE.GROUP_CODE%TYPE INDEX BY VARCHAR2(64);
      G_GRP_LIST G_GRP_TAB;
    BEGIN
      DBG('Start of function fn_mark_bkcalc_for_il');
      DBG('Incoming parameters -->' || P_CONDITION_TYPE || '~' ||
          P_COND_KEY || '~' || P_UDE_EFF_DATE || '~' || P_PRODUCT_CODE || '~' ||
          P_LIQN_START_ACCOUNT);
      L_NEXT_LIQD_DT := NULL;
      IF P_CONDITION_TYPE = 0 THEN
      
        DBG('Inside spl condition check ');
        FOR REC IN CR_SPECIAL_CONDITIONS(SUBSTR(P_COND_KEY, 4),
                                         P_UDE_EFF_DATE) LOOP
          DBG('Some spl condition entries are there !!!');
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := NULL;
            DBG('For special condition liquidation start set ');
            DBG('Select interest start date for cust account - ' ||
                REC.CUST_ACCOUNT);
            SELECT INT_START_DATE
              INTO L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.BRN
               AND ACC = REC.CUST_ACCOUNT;
            DBG('Getting the next interest start date for date - ' ||
                L_INT_START_DATE);
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            DBG('Getting next liqd date for the prod - ' || REC.PROD ||
                ' and date - ' || L_INT_START_DATE);
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         L_INT_START_DATE,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          ELSIF (P_LIQN_START_ACCOUNT = 'N' AND L_NEXT_LIQD_DT IS NULL) THEN
            DBG('Liqd flag not set ');
            DBG('Getting next liqd date for the start liq date passed ');
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         P_START_LIQ_DT,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          END IF;
          SELECT GROUP_CODE
            INTO L_GROUP_CODE
            FROM ILTBS_SYS_ACCOUNT
           WHERE BRANCH_CODE = REC.BRN
             AND SYSTEM_ACCOUNT = REC.ACC;
          DBG('Group code selected for the account - ' || REC.ACC ||
              ' is - ' || L_GROUP_CODE);
          IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
            DBG('Updating for the group code the value 0 for eff_date - ' ||
                P_UDE_EFF_DATE);
            DBG('Branch value is ' || REC.BRN);
            FOR SYS_REC IN C_SYS_CUR(REC.BRN, L_GROUP_CODE, P_UDE_EFF_DATE) LOOP
              DBG('Inside sys account cursor - ' || SYS_REC.SYSTEM_ACCOUNT);
              TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
              TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(REC.BKVAL_MINCALC_DATE,
                                                         P_UDE_EFF_DATE),
                                                     P_UDE_EFF_DATE);
              TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
              TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_NEXT_LIQD_DT;
              P_SR := P_SR + 1;
            END LOOP;
            G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
          END IF;
          DBG('Selecting the back valued date from acc pr for account - ' ||
              REC.ACC);
          SELECT A.BKVAL_MINCALC_DATE, A.LAST_LIQ_DT, A.ROWID
            INTO L_BKVAL_MINCALC_DATE, L_LAST_LIQ_DT, L_ROWID
            FROM ICTBS_ACC_PR A
           WHERE BRN = P_BRANCH
             AND ACC = REC.ACC
             AND PROD = P_PRODUCT_CODE;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := NULL;
            DBG('Select interest start date for the account - ' ||
                REC.CUST_ACCOUNT);
            SELECT INT_START_DATE
              INTO L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.SYSTEM_ACCOUNT_BRANCH
               AND ACC = REC.CUST_ACCOUNT;
            DBG('Selecting the next int start date for date - ' ||
                L_INT_START_DATE);
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            DBG('Selecting next liq date for the date - ' ||
                L_INT_START_DATE);
            L_MASTER_NEXT_LIQ_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                               L_INT_START_DATE,
                                                                               GLOBAL.APPLICATION_DATE,
                                                                               P_LIQN_DAYS,
                                                                               P_LIQN_MONTHS,
                                                                               P_LIQN_YEARS);
          ELSE
            L_MASTER_NEXT_LIQ_DT := L_NEXT_LIQD_DT;
          END IF;
          DBG('Liquidation date for master in SC-->' ||
              L_MASTER_NEXT_LIQ_DT);
          IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
            DBG('Updating for the group code the value 0 for eff_date - ' ||
                P_UDE_EFF_DATE);
            DBG('Branch value is ' || REC.BRN);
            FOR SYS_REC IN C_SYS_CUR(REC.BRN, L_GROUP_CODE, P_UDE_EFF_DATE) LOOP
              DBG('Inside sys account cursor - ' || SYS_REC.SYSTEM_ACCOUNT);
              TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
              TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(L_BKVAL_MINCALC_DATE,
                                                         P_UDE_EFF_DATE),
                                                     P_UDE_EFF_DATE);
              TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
              TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_MASTER_NEXT_LIQ_DT;
              P_SR := P_SR + 1;
            END LOOP;
            G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
          END IF;
          DBG('Here AFTER the ROW TYPE UPDATE AND i ');
        END LOOP;
      ELSE
        L_PREV_CUST_ACCOUNT := '###';
        L_COMBVT_DATE       := NULL;
        FOR REC IN CR_GENERAL_CONDITIONS(P_UDE_EFF_DATE) LOOP
          DBG('In loop for general condition for acc -->' || REC.ACC);
          IF L_PREV_CUST_ACCOUNT <> REC.ACC THEN
            SELECT COMBVT_DATE, INT_START_DATE
              INTO L_COMBVT_DATE, L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.BRN
               AND ACC = REC.CUST_ACCOUNT;
          END IF;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            L_NEXT_LIQD_DT   := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                           L_INT_START_DATE,
                                                                           GLOBAL.APPLICATION_DATE,
                                                                           P_LIQN_DAYS,
                                                                           P_LIQN_MONTHS,
                                                                           P_LIQN_YEARS);
          ELSIF (P_LIQN_START_ACCOUNT = 'N' AND L_NEXT_LIQD_DT IS NULL) THEN
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         P_START_LIQ_DT,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          END IF;
          SELECT GROUP_CODE
            INTO L_GROUP_CODE
            FROM ILTBS_SYS_ACCOUNT
           WHERE BRANCH_CODE = REC.BRN
             AND SYSTEM_ACCOUNT = REC.ACC;
          DBG('Group code selected for the account - ' || REC.ACC ||
              ' is - ' || L_GROUP_CODE);
          IF REC.LAST_LIQ_DT > NVL(L_COMBVT_DATE, REC.LAST_LIQ_DT - 1) THEN
            IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
              FOR SYS_REC IN C_SYS_CUR(REC.BRN,
                                       L_GROUP_CODE,
                                       P_UDE_EFF_DATE) LOOP
                L_VAL_DT := GREATEST(P_UDE_EFF_DATE,
                                     NVL(L_COMBVT_DATE, P_UDE_EFF_DATE));
                TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
                TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(REC.BKVAL_MINCALC_DATE,
                                                           L_VAL_DT),
                                                       L_VAL_DT);
                TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
                TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_NEXT_LIQD_DT;
                P_SR := P_SR + 1;
              END LOOP;
            END IF;
          END IF;
          SELECT COMBVT_DATE, INT_START_DATE
            INTO L_COMBVT_DATE_POOL, L_MASTER_INT_START_DATE
            FROM ICTMS_ACC
           WHERE BRN = REC.BRN
             AND ACC = REC.CUST_ACCOUNT;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_MASTER_INT_START_DATE := ADD_MONTHS(L_MASTER_INT_START_DATE,
                                                  12 * P_LIQN_YEARS +
                                                  P_LIQN_MONTHS) +
                                       P_LIQN_DAYS - 1;
            L_MASTER_NEXT_LIQ_DT    := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                                  L_MASTER_INT_START_DATE,
                                                                                  GLOBAL.APPLICATION_DATE,
                                                                                  P_LIQN_DAYS,
                                                                                  P_LIQN_MONTHS,
                                                                                  P_LIQN_YEARS);
          ELSE
            L_MASTER_NEXT_LIQ_DT := L_NEXT_LIQD_DT;
          END IF;
          SELECT A.BKVAL_MINCALC_DATE, A.LAST_LIQ_DT, A.ROWID
            INTO L_BKVAL_MINCALC_DATE, L_LAST_LIQ_DT, L_ROWID
            FROM ICTBS_ACC_PR A
           WHERE BRN = P_BRANCH
             AND ACC = REC.ACC
             AND PROD = P_PRODUCT_CODE;
          IF L_LAST_LIQ_DT > NVL(L_COMBVT_DATE_POOL, L_LAST_LIQ_DT - 1) THEN
            IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
              DBG('Updating for the group code the value 0 for eff_date - ' ||
                  P_UDE_EFF_DATE);
              DBG('Branch value is ' || REC.BRN);
              FOR SYS_REC IN C_SYS_CUR(REC.BRN,
                                       L_GROUP_CODE,
                                       P_UDE_EFF_DATE) LOOP
                DBG('Inside sys account cursor - ' ||
                    SYS_REC.SYSTEM_ACCOUNT);
                L_VAL_DT := GREATEST(P_UDE_EFF_DATE,
                                     NVL(L_COMBVT_DATE_POOL, P_UDE_EFF_DATE));
                TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
                TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(L_BKVAL_MINCALC_DATE,
                                                           L_VAL_DT),
                                                       L_VAL_DT);
                TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
                TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_MASTER_NEXT_LIQ_DT;
                P_SR := P_SR + 1;
              END LOOP;
              G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
            END IF;
          END IF;
          L_PREV_CUST_ACCOUNT := REC.CUST_ACCOUNT;
        END LOOP;
      END IF;
      DBG('End of function fn_mark_bkcalc_for_il');
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others of function fn_update_stopic' || SQLERRM);
        RETURN FALSE;
    END FN_MARK_BKCALC_FOR_IL;
  
  BEGIN
    DBG('entered the bkval udevals');
    FOR C1 IN CR_UDEVALS(P_BRN) LOOP
      DBG('Just going to do the things..' || C1.COND_KEY || '~' || C1.PROD);
      IF C1.COND_TYPE = 0 THEN
        DBG('Type Is O');
        I  := NVL(TB_BKDT_EVENTS_BRN.COUNT, 0) + 1;
        SR := NVL(TB_BKACCPR_RECALC_FLAG.COUNT, 0) + 1;
        FOR C2 IN CR_SC_ACC_PR(C1.BRN, SUBSTR(C1.COND_KEY, 4), C1.PROD) LOOP
          DBG('Inside loop of C2' || SR);
          IF NVL(C2.LAST_LIQ_DT, C1.UDE_EFF_DT - 1) >= C1.UDE_EFF_DT OR
             C2.BKVAL_MINCALC_DATE IS NOT NULL THEN
            TB_BKACCPR_RECALC_FLAG(SR) := 'Y';
            TB_BKACCPR_MINCALC_DATE(SR) := LEAST(NVL(C2.BKVAL_MINCALC_DATE,
                                                     C1.UDE_EFF_DT),
                                                 C1.UDE_EFF_DT);
            TB_BKACCPR_ROWID(SR) := C2.ROW_ID;
          
            DBG('tb_bkaccpr_mincalc_date(sr) before-->' ||
                TB_BKACCPR_MINCALC_DATE(SR));
            L_ICTMS_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(C2.ACC, C2.BRN);
            DBG('l_ictms_acc.int_start_date-->' ||
                L_ICTMS_ACC.INT_START_DATE);
            TB_BKACCPR_MINCALC_DATE(SR) := GREATEST(TB_BKACCPR_MINCALC_DATE(SR),
                                                    L_ICTMS_ACC.INT_START_DATE);
            DBG('tb_bkaccpr_mincalc_date(sr) After-->' ||
                TB_BKACCPR_MINCALC_DATE(SR));
          
            SR                                    := SR + 1;
            L_BACK_VALUED_EVENTS_REC              := NULREC;
            L_BACK_VALUED_EVENTS_REC.BRN          := C2.BRN;
            L_BACK_VALUED_EVENTS_REC.ACC          := C2.ACC;
            L_BACK_VALUED_EVENTS_REC.PROD         := C2.PROD;
            L_BACK_VALUED_EVENTS_REC.EVENT_TYPE   := 'U';
            L_BACK_VALUED_EVENTS_REC.EVENT_DATE   := GLOBAL.APPLICATION_DATE;
            L_BACK_VALUED_EVENTS_REC.VALUE_DT     := C1.UDE_EFF_DT;
            L_BACK_VALUED_EVENTS_REC.UDE_ID       := C1.UDE_ID;
            L_BACK_VALUED_EVENTS_REC.UDE_AMT      := C1.AMT;
            L_BACK_VALUED_EVENTS_REC.RATE_CODE    := C1.RATE_CODE;
            L_BACK_VALUED_EVENTS_REC.RATE         := C1.RATE;
            L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE := C1.CHANGE_TYPE;
            IF C1.UDE_EFF_DT < C2.FIRST_FIRST_CALC_DATE THEN
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'E';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C2.FIRST_FIRST_CALC_DATE;
            ELSE
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'P';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C1.UDE_EFF_DT;
            END IF;
            TB_BKDT_EVENTS_BRN(I) := L_BACK_VALUED_EVENTS_REC.BRN;
            TB_BKDT_EVENTS_ACC(I) := L_BACK_VALUED_EVENTS_REC.ACC;
            TB_BKDT_EVENTS_PROD(I) := L_BACK_VALUED_EVENTS_REC.PROD;
            TB_BKDT_EVENTS_EVENT_TYPE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_TYPE;
            TB_BKDT_EVENTS_EVENT_DATE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_DATE;
            TB_BKDT_EVENTS_VALUE_DT(I) := L_BACK_VALUED_EVENTS_REC.VALUE_DT;
            TB_BKDT_EVENTS_UDE_ID(I) := L_BACK_VALUED_EVENTS_REC.UDE_ID;
            TB_BKDT_EVENTS_UDE_AMT(I) := L_BACK_VALUED_EVENTS_REC.UDE_AMT;
            TB_BKDT_EVENTS_RATE_CODE(I) := L_BACK_VALUED_EVENTS_REC.RATE_CODE;
            TB_BKDT_EVENTS_RATE(I) := L_BACK_VALUED_EVENTS_REC.RATE;
            TB_BKDT_EVENTS_UDE_CHG_TYPE(I) := L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE;
            TB_BKDT_EVENTS_ENT_AMOUNT(I) := L_BACK_VALUED_EVENTS_REC.ENT_AMOUNT;
            TB_BKDT_EVENTS_ENT_DRCR_IND(I) := L_BACK_VALUED_EVENTS_REC.DRCR_IND;
            TB_BKDT_EVENTS_ENT_PROC_STAT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS;
            TB_BKDT_EVENTS_ENT_PROC_FRMDT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE;
            I := I + 1;
            DBG('Here after the row type update and i ');
          END IF;
        END LOOP;
      ELSE
        DBG('before i');
        I := NVL(TB_BKDT_EVENTS_BRN.COUNT, 0) + 1;
        DBG('Affter i');
        SR := NVL(TB_BKACCPR_RECALC_FLAG.COUNT, 0) + 1;
        DBG('I am in else condition');
      
        FOR C3 IN CR_GC_ACC_PR(C1.BRN, C1.PROD, SUBSTR(C1.COND_KEY, 4))
        
         LOOP
          DBG('Inside loop for cursor cr_gc_acc_pr-->Branch' || C1.BRN ||
              'Product - ' || C1.PROD || 'Condition Key - ' ||
              SUBSTR(C1.COND_KEY, 4));
          IF (NVL(C3.LAST_LIQ_DT, C1.UDE_EFF_DT - 1) >= C1.UDE_EFF_DT AND
             NVL(C3.SC_MAP_DT, C1.UDE_EFF_DT + 1) > C1.UDE_EFF_DT) OR
             C3.BKVAL_MINCALC_DATE IS NOT NULL THEN
            DBG('updating gc for the above');
            TB_BKACCPR_RECALC_FLAG(SR) := 'Y';
            DBG('After Y');
            TB_BKACCPR_MINCALC_DATE(SR) := LEAST(NVL(C3.BKVAL_MINCALC_DATE,
                                                     C1.UDE_EFF_DT),
                                                 C1.UDE_EFF_DT);
            DBG('After date');
            TB_BKACCPR_ROWID(SR) := C3.ROW_ID;
            DBG('After rowid');
            SR := SR + 1;
            DBG('After our hand');
            L_BACK_VALUED_EVENTS_REC              := NULREC;
            L_BACK_VALUED_EVENTS_REC.BRN          := C3.BRN;
            L_BACK_VALUED_EVENTS_REC.ACC          := C3.ACC;
            L_BACK_VALUED_EVENTS_REC.PROD         := C3.PROD;
            L_BACK_VALUED_EVENTS_REC.EVENT_TYPE   := 'U';
            L_BACK_VALUED_EVENTS_REC.EVENT_DATE   := GLOBAL.APPLICATION_DATE;
            L_BACK_VALUED_EVENTS_REC.VALUE_DT     := C1.UDE_EFF_DT;
            L_BACK_VALUED_EVENTS_REC.UDE_ID       := C1.UDE_ID;
            L_BACK_VALUED_EVENTS_REC.UDE_AMT      := C1.AMT;
            L_BACK_VALUED_EVENTS_REC.RATE_CODE    := C1.RATE_CODE;
            L_BACK_VALUED_EVENTS_REC.RATE         := C1.RATE;
            L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE := C1.CHANGE_TYPE;
            DBG('Just going for EP');
            IF C1.UDE_EFF_DT < C3.FIRST_FIRST_CALC_DATE THEN
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'E';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C3.FIRST_FIRST_CALC_DATE;
            ELSE
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'P';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C1.UDE_EFF_DT;
            END IF;
            DBG('After EP');
            TB_BKDT_EVENTS_BRN(I) := L_BACK_VALUED_EVENTS_REC.BRN;
            TB_BKDT_EVENTS_ACC(I) := L_BACK_VALUED_EVENTS_REC.ACC;
            TB_BKDT_EVENTS_PROD(I) := L_BACK_VALUED_EVENTS_REC.PROD;
            TB_BKDT_EVENTS_EVENT_TYPE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_TYPE;
            TB_BKDT_EVENTS_EVENT_DATE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_DATE;
            TB_BKDT_EVENTS_VALUE_DT(I) := L_BACK_VALUED_EVENTS_REC.VALUE_DT;
            TB_BKDT_EVENTS_UDE_ID(I) := L_BACK_VALUED_EVENTS_REC.UDE_ID;
            TB_BKDT_EVENTS_UDE_AMT(I) := L_BACK_VALUED_EVENTS_REC.UDE_AMT;
            TB_BKDT_EVENTS_RATE_CODE(I) := L_BACK_VALUED_EVENTS_REC.RATE_CODE;
            TB_BKDT_EVENTS_RATE(I) := L_BACK_VALUED_EVENTS_REC.RATE;
            TB_BKDT_EVENTS_UDE_CHG_TYPE(I) := L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE;
            TB_BKDT_EVENTS_ENT_AMOUNT(I) := L_BACK_VALUED_EVENTS_REC.ENT_AMOUNT;
            TB_BKDT_EVENTS_ENT_DRCR_IND(I) := L_BACK_VALUED_EVENTS_REC.DRCR_IND;
            TB_BKDT_EVENTS_ENT_PROC_STAT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS;
            TB_BKDT_EVENTS_ENT_PROC_FRMDT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE;
            DBG('Just going for i');
            I := I + 1;
          END IF;
        END LOOP;
      END IF;
    
      DBG('Inside else part for the call to fn_mark_bkcalc_for_il');
      DBG('ude eff date is ' || C1.UDE_EFF_DT);
      IF C1.IL_PRODUCT = 'Y' THEN
        DBG('Product is IL product ');
      
        L_UDE_EFF_DT := C1.UDE_EFF_DT;
      
        DBG('Final ude eff date is ' || L_UDE_EFF_DT);
        IF NOT FN_MARK_BKCALC_FOR_IL(C1.BRN,
                                     C1.PROD,
                                     C1.LIQN_START_ACCOUNT,
                                     C1.LIQN_START_DATE,
                                     C1.LIQN_DAYS,
                                     C1.LIQN_MONTHS,
                                     C1.LIQN_YEARS,
                                     L_UDE_EFF_DT,
                                     C1.CHANGE_TYPE,
                                     C1.COND_TYPE,
                                     C1.COND_KEY,
                                     TB_BKACCPR_RECALC_FLAG,
                                     TB_BKACCPR_MINCALC_DATE,
                                     TB_BKACCPR_ROWID,
                                     TB_BKACCPR_NEXTLIQ_DT,
                                     SR) THEN
          DBG('Failedin function fn_mark_bkclac_for_il');
          RETURN FALSE;
        END IF;
      END IF;
    
      DBG('before etc');
      TB_BKDT_EVEDEL_BRN(J) := C1.BRN;
      TB_BKDT_EVEDEL_PROD(J) := C1.PROD;
      TB_BKDT_EVEDEL_COND_TYPE(J) := C1.COND_TYPE;
      TB_BKDT_EVEDEL_COND_KEY(J) := C1.COND_KEY;
      TB_BKDT_EVEDEL_UDE_ID(J) := C1.UDE_ID;
      TB_BKDT_EVEDEL_UDE_EFF_DT(J) := C1.UDE_EFF_DT;
      J := J + 1;
    END LOOP;
    DBG('After end loop');
    IF NVL(TB_BKDT_EVENTS_ACC.COUNT, 0) <> 0 THEN
      DBG('Before inserting into ictbs_back_dated_events ' ||
          TB_BKDT_EVENTS_ACC.COUNT);
      FORALL K IN TB_BKDT_EVENTS_ACC.FIRST .. TB_BKDT_EVENTS_ACC.LAST
        INSERT INTO ICTBS_BACK_DATED_EVENTS
          (BRN,
           ACC,
           PROD,
           EVENT_TYPE,
           EVENT_DATE,
           VALUE_DT,
           UDE_ID,
           UDE_AMT,
           RATE_CODE,
           RATE,
           UDE_CHG_TYPE,
           ENT_AMOUNT,
           DRCR_IND,
           PROCESS_STATUS,
           PROCESS_FROM_DATE)
        VALUES
          (TB_BKDT_EVENTS_BRN(K),
           TB_BKDT_EVENTS_ACC(K),
           TB_BKDT_EVENTS_PROD(K),
           TB_BKDT_EVENTS_EVENT_TYPE(K),
           TB_BKDT_EVENTS_EVENT_DATE(K),
           TB_BKDT_EVENTS_VALUE_DT(K),
           TB_BKDT_EVENTS_UDE_ID(K),
           TB_BKDT_EVENTS_UDE_AMT(K),
           TB_BKDT_EVENTS_RATE_CODE(K),
           TB_BKDT_EVENTS_RATE(K),
           TB_BKDT_EVENTS_UDE_CHG_TYPE(K),
           TB_BKDT_EVENTS_ENT_AMOUNT(K),
           TB_BKDT_EVENTS_ENT_DRCR_IND(K),
           TB_BKDT_EVENTS_ENT_PROC_STAT(K),
           TB_BKDT_EVENTS_ENT_PROC_FRMDT(K));
    END IF;
  
    DBG('After the back dated events..insert');
    IF NVL(TB_BKDT_EVEDEL_BRN.COUNT, 0) <> 0 THEN
      FORALL K IN TB_BKDT_EVEDEL_BRN.FIRST .. TB_BKDT_EVEDEL_BRN.LAST
        DELETE FROM ICTBS_BACK_DATED_UDEVALS
         WHERE BRN = TB_BKDT_EVEDEL_BRN(K)
           AND PROD = TB_BKDT_EVEDEL_PROD(K)
           AND COND_TYPE = TB_BKDT_EVEDEL_COND_TYPE(K)
           AND COND_KEY = TB_BKDT_EVEDEL_COND_KEY(K)
           AND UDE_ID = TB_BKDT_EVEDEL_UDE_ID(K)
           AND UDE_EFF_DT = TB_BKDT_EVEDEL_UDE_EFF_DT(K);
    END IF;
    DBG('After the back dated udevals..delte');
    DBG('Goig to update back calc date as');
    IF NVL(TB_BKACCPR_ROWID.COUNT, 0) <> 0 THEN
      FORALL K IN TB_BKACCPR_ROWID.FIRST .. TB_BKACCPR_ROWID.LAST
        UPDATE ICTBS_ACC_PR
           SET BKVAL_RECALC_FLAG  = TB_BKACCPR_RECALC_FLAG(K),
               BKVAL_MINCALC_DATE = TB_BKACCPR_MINCALC_DATE(K)
         WHERE ROWID = TB_BKACCPR_ROWID(K);
    END IF;
    DBG('update and commit');
  
    DBG('the transaction would be commited only if is from gateway(gw)  - global.pkg_is_txn_via_gw ' ||
        GLOBAL.PKG_IS_TXN_VIA_GW);
  
    DBG('icpks_test.g_onliq_flag is :' || ICPKS_TEST.G_ONLIQ_FLAG);
  
    IF GLOBAL.PKG_IS_TXN_VIA_GW <> 'Y' AND NOT GWPKS_UTIL.G_FROM_BEAN AND
       NVL(ICPKS_TEST.G_ONLIQ_FLAG, 'N') <> 'Y' THEN
    
      DBG('Commiting the transaction as it is NOT COMING from the gateway');
      COMMIT;
    ELSE
      DBG('the commit will not happen as the txn is coming via gateway');
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_mark_bkcalc_for_udevals' || SQLERRM);
      RETURN FALSE;
  END FN_MARK_BKCALC_FOR_UDEVALS;

  FUNCTION FN_BKVAL_CALC(PBRANCH VARCHAR2, PACCOUNT VARCHAR2) RETURN BOOLEAN IS
    TBL_ACC                  ICPKS_TEST.T2;
    TBL_BRN                  ICPKS_TEST.T1;
    TBL_PROD                 ICPKS_TEST.T3;
    TBL_FRM_NO               ICPKS_TEST.TB4;
    TBL_ACQUIRED_AMT         ICPKS_TEST.TICNT14;
    TBL_PREV_YR_ACQUIRED_AMT ICPKS_TEST.TICNT14;
    L_FC_STRT_DT             DATE;
    TBL_DAILY_AMT            ICPKS_TEST.TICNT5;
    TBL_ROW_ID               ICPKS_TEST.T29;
    L_PREV_ACC               VARCHAR2(23);
    L_LIQ_PERIOD_START       DATE;
    L_LIQ_PERIOD_END         DATE;
    L_CALC_AMT               NUMBER(22, 3);
    L_CALC_AMT_LCY           NUMBER(22, 3);
    L_RATE                   NUMBER(14, 7);
    L_ERR_CODE               ERTBS_MSGS.ERR_CODE%TYPE;
    WORK_REC                 ICTWS_BACK_PR%ROWTYPE;
    L_TMPVAR1                DATE;
    L_TMPVAR2                DATE;
    L_NEXT_LIQ_PERIOD_START  ICTBS_ENTRIES_HISTORY.ENT_DT%TYPE;
    L_DIFF_AMT               NUMBER(22, 3);
    L_DIFF_AMT_LCY           NUMBER(22, 3);
    IM_COUNT1                INTEGER := 0;
    IM_COUNT2                INTEGER := 0;
    C1                       NUMBER := 0;
    TB_ICENT                 ICPKS_TEST.REC_ICENT;
    SR                       NUMBER := 0;
    K                        NUMBER := 0;
    L_INLOOP                 BOOLEAN := FALSE;
    L_ICTM_ACC               ICTMS_ACC%ROWTYPE;
  
    L_GROUP_CODE ILTBS_SYS_ACCOUNT.GROUP_CODE%TYPE;
    L_ERROR_CODE VARCHAR2(1000);
    ERRMSG       VARCHAR2(1000);
    L_CUST_AC_NO ICTBS_ACC_SYS_MAP.CUST_AC_NO%TYPE;
  
    L_TD_BROKEN_DATE DATE;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
    CURSOR CR_BKVAL_CALC(BRANCH VARCHAR2, ACCOUNT VARCHAR2) IS
      SELECT A.*, ROWID ROW_ID
        FROM ICTBS_ACC_PR A
       WHERE BRN = BRANCH
         AND ACC = NVL(ACCOUNT, ACC)
         AND NVL(STOP_IC, 'N') = 'N'
         AND HAS_PROBLEMS = 'N'
         AND BKVAL_RECALC_FLAG = 'Y'
         AND A.PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART
       ORDER BY SYS_AC_LEVEL,
                SUBLEVEL,
                
                BRN,
                ACC;
    CURSOR CR_HIST_LIQN(BRANCH   VARCHAR2,
                        ACCOUNT  VARCHAR2,
                        PRODUCT  VARCHAR2,
                        START_DT DATE) IS
      SELECT DISTINCT BRN,
                      ACC,
                      PROD,
                      
                      ENT_DT
        FROM ICTBS_ENTRIES_HISTORY
       WHERE BRN = BRANCH
         AND ACC = ACCOUNT
         AND PROD = PRODUCT
         AND LIQN = 'Y'
         AND ENT_DT > START_DT
         AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART
       ORDER BY ENT_DT ASC;
    CURSOR CR_HIST_LIQN_DET(BRANCH   VARCHAR2,
                            ACCOUNT  VARCHAR2,
                            PRODUCT  VARCHAR2,
                            START_DT DATE) IS
      SELECT A.BRN,
             A.ACC,
             A.PROD,
             A.FRM_NO,
             A.ENT_DT,
             A.CCY,
             A.AMT,
             A.LCY_AMT
        FROM ICTBS_ENTRIES_HISTORY A
       WHERE A.BRN = BRANCH
         AND A.ACC = ACCOUNT
         AND A.PROD = PRODUCT
         AND A.LIQN = 'Y'
         AND A.ENT_DT = START_DT
         AND A.PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART
       ORDER BY FRM_NO ASC;
    CURSOR CR_INT_ADJ(BRANCH VARCHAR2, ACCOUNT VARCHAR2, PRODUCT VARCHAR2) IS
      SELECT BRN,
             ACC,
             PROD,
             FRM_NO,
             CCY,
             SUM(AMT) TOT_ACY,
             SUM(LCY_AMT) TOT_LCY
        FROM ICTBS_ADJ_INTEREST
       WHERE BRN = BRANCH
         AND ACC = ACCOUNT
         AND PROD = PRODUCT
       GROUP BY BRN, ACC, PROD, FRM_NO, CCY;
  
    CURSOR CR_INT_ADJ_PAST_YR(BRANCH        VARCHAR2,
                              ACCOUNT       VARCHAR2,
                              PRODUCT       VARCHAR2,
                              YR_START_DATE DATE,
                              FRML_NO       NUMBER) IS
      SELECT BRN,
             ACC,
             PROD,
             FRM_NO,
             CCY,
             SUM(AMT) TOT_ACY,
             SUM(LCY_AMT) TOT_LCY
        FROM ICTBS_ADJ_INTEREST
       WHERE BRN = BRANCH
         AND ACC = ACCOUNT
         AND PROD = PRODUCT
         AND FRM_NO = FRML_NO
         AND ENT_DT < YR_START_DATE
       GROUP BY BRN, ACC, PROD, FRM_NO, CCY;
  
    CURSOR CR_LIQDT(L_BRN      VARCHAR2,
                    L_ACC      VARCHAR2,
                    L_PROD     VARCHAR2,
                    L_LIQN     VARCHAR2,
                    L_BKVAL_DT DATE) IS
      SELECT ENT_DT
        FROM ICTBS_ENTRIES_HISTORY
       WHERE BRN = L_BRN
         AND ACC = L_ACC
         AND PROD = L_PROD
         AND LIQN = 'Y'
         AND ENT_DT < L_BKVAL_DT
         AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART
       ORDER BY ENT_DT DESC;
    L_RULE_ACC_OPEN VARCHAR2(1);
    L_AC_OPEN_DATE  DATE;
  BEGIN
    DBG('Inside ICPKSS_TEST.BKVAL_CALC');
  
    ICPKSS_TEST.G_BKVAL_CALC := TRUE;
  
    FOR EACH_REC IN CR_BKVAL_CALC(PBRANCH, PACCOUNT) LOOP
      TB_ICENT.DELETE;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 3;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        L_TB_CLUSTER_DATA('each_rec.brn') := EACH_REC.BRN;
        L_TB_CLUSTER_DATA('each_rec.acc') := EACH_REC.ACC;
        L_TB_CLUSTER_DATA('each_rec.prod') := EACH_REC.PROD;
      
        IF ICPKS_TEST_CLUSTER.FN_BKVAL_CALC(EACH_REC.BRN,
                                            EACH_REC.ACC,
                                            L_FN_CALL_ID,
                                            L_TB_CLUSTER_DATA) THEN
          DBG('Back from fn_bkval_calc');
          NULL;
        END IF;
      END IF;
    
      IF NOT GLOBAL.G_SKIP_KERNEL THEN
      
        IF NVL(TB_BRN.COUNT, 0) <> 0 THEN
          ICPKSS_TEST.TB_BRN.DELETE;
          ICPKSS_TEST.TB_ACC.DELETE;
          ICPKSS_TEST.TB_NEXT_CALC_DT.DELETE;
          ICPKSS_TEST.TB_NEXT_LIQ_DT.DELETE;
          ICPKSS_TEST.TB_NEXT_ACCR_DT.DELETE;
          ICPKSS_TEST.TB_LAST_CALC_DT.DELETE;
          ICPKSS_TEST.TB_LAST_LIQ_DT.DELETE;
          ICPKSS_TEST.TB_LAST_ACCR_DT.DELETE;
          ICPKSS_TEST.TB_FIRST_CALC_DT.DELETE;
          DBG('after all deletes');
        END IF;
        ICPKSS_TEST.TB_BRN(1) := EACH_REC.BRN;
        ICPKSS_TEST.TB_ACC(1) := EACH_REC.ACC;
        ICPKSS_TEST.TB_PROD(1) := EACH_REC.PROD;
        ICPKSS_TEST.TB_NEXT_CALC_DT(1) := EACH_REC.NEXT_CALC_DT;
        ICPKSS_TEST.TB_NEXT_LIQ_DT(1) := EACH_REC.NEXT_LIQ_DT;
        ICPKSS_TEST.TB_NEXT_ACCR_DT(1) := EACH_REC.NEXT_ACCR_DT;
        ICPKSS_TEST.TB_LAST_LIQ_DT(1) := EACH_REC.LAST_LIQ_DT;
        ICPKSS_TEST.TB_FIRST_CALC_DT(1) := EACH_REC.FIRST_CALC_DT;
        ICPKSS_TEST.TB_LAST_ACCR_DT(1) := EACH_REC.LAST_ACCR_DT;
        ICPKSS_TEST.TB_LAST_LIQ_DT(1) := EACH_REC.LAST_LIQ_DT;
        ICPKSS_TEST.TB_LAST_CALC_DT(1) := EACH_REC.LAST_CALC_DT;
      
        IF EACH_REC.SYS_AC_LEVEL IS NOT NULL THEN
          SELECT ACCOUNT,
                 'N',
                 ACCOUNT,
                 BOOKING_ACC_BRANCH,
                 BOOKING_ACC,
                 BOOKING_ACC_CCY,
                 EFF_DATE,
                 GROUP_CODE
            INTO L_CUST_AC_NO,
                 L_ICTM_ACC.ACC_TYPE,
                 L_ICTM_ACC.CALC_ACC,
                 L_ICTM_ACC.BOOK_BRN,
                 L_ICTM_ACC.BOOK_ACC,
                 L_ICTM_ACC.BOOK_CCY,
                 L_ICTM_ACC.INT_START_DATE,
                 L_GROUP_CODE
            FROM ILTBS_SYS_ACCOUNT
           WHERE (BRANCH_CODE = TB_BRN(1) OR
                 SYSTEM_ACCOUNT_BRANCH = TB_BRN(1))
             AND (SYSTEM_ACCOUNT = TB_ACC(1) OR ACCOUNT = TB_ACC(1))
             AND ROWNUM < 2;
        END IF;
      
        IF GLOBALS_ADDON.ILM_INSTALLED = 'Y' AND
           EACH_REC.SYS_AC_LEVEL IS NOT NULL THEN
          DBG('In selection of ilm 1');
          DBG('In selection of ilm 11' || 'BRN' || TB_BRN(1) || 'ACC' ||
              TB_ACC(1));
          SELECT A.*
            INTO L_ICTM_ACC
            FROM ICTMS_ACC A, ILTBS_SYS_ACCOUNT B
           WHERE A.BRN = B.BRANCH_CODE
             AND A.ACC = B.ACCOUNT
             AND B.SYSTEM_ACCOUNT_BRANCH = TB_BRN(1)
             AND B.SYSTEM_ACCOUNT = TB_ACC(1)
             AND ROWNUM < 2;
          SELECT A.*
            INTO G_STTM_CUSTACC
            FROM STTMS_CUST_ACCOUNT A, ILTBS_SYS_ACCOUNT B
           WHERE A. BRANCH_CODE = B.BRANCH_CODE
             AND A. CUST_AC_NO = B.ACCOUNT
             AND B.SYSTEM_ACCOUNT_BRANCH = TB_BRN(1)
             AND B.SYSTEM_ACCOUNT = TB_ACC(1)
             AND ROWNUM < 2;
        ELSE
          DBG('In selection of else');
        
          G_ICTM_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(TB_ACC(1), TB_BRN(1));
          L_ICTM_ACC := G_ICTM_ACC;
        
          IF NOT
              ICPKS_CACHE.FN_GETCUSTACC(TB_BRN(1), TB_ACC(1), G_STTM_CUSTACC) THEN
            DBG('Could not get account');
            RETURN FALSE;
          END IF;
        
        END IF;
        IF L_PREV_ACC <>
           NVL(EACH_REC.BRN, PBRANCH) || NVL(EACH_REC.ACC, PACCOUNT) THEN
          NULL;
        
          DBG('the transaction would be commited only if is from gateway(gw)  - global.pkg_is_txn_via_gw ' ||
              GLOBAL.PKG_IS_TXN_VIA_GW);
          DBG('icpks_test.g_onliq_flag is-->' || ICPKS_TEST.G_ONLIQ_FLAG);
        
          IF GLOBAL.PKG_IS_TXN_VIA_GW <> 'Y' AND
             NOT STPKS_STDCUSAC_UTILS_2.G_AC_CLOSURE AND
             NOT GWPKS_UTIL.G_FROM_BEAN AND
             NVL(ICPKS_TEST.G_ONLIQ_FLAG, 'N') <> 'Y' THEN
            DBG('Commiting the transaction as it is NOT COMING from the gateway');
            COMMIT;
          ELSE
            DBG('the commit will not happen as the txn is coming via gateway');
          END IF;
        
        END IF;
        DBG('Inside lOOP');
        DBG(EACH_REC.BRN || EACH_REC.ACC || EACH_REC.PROD);
        FOR EACH_ROW IN (SELECT A.*, ROWID
                           FROM ICTBS_ENTRIES A
                          WHERE BRN = EACH_REC.BRN
                            AND ACC = EACH_REC.ACC
                            AND PROD = EACH_REC.PROD
                            AND PROCESS = EACH_REC.PROCESS) LOOP
          TB_ICENT(EACH_ROW.FRM_NO).BRN := EACH_ROW.BRN;
          TB_ICENT(EACH_ROW.FRM_NO).ACC := EACH_ROW.ACC;
          TB_ICENT(EACH_ROW.FRM_NO).PROD := EACH_ROW.PROD;
          TB_ICENT(EACH_ROW.FRM_NO).FRM_NO := EACH_ROW.FRM_NO;
          TB_ICENT(EACH_ROW.FRM_NO).AMT := 0;
          TB_ICENT(EACH_ROW.FRM_NO).ACCRUED_AMT := 0;
          TB_ICENT(EACH_ROW.FRM_NO).CUR_RUN_ACCR := 0;
          TB_ICENT(EACH_ROW.FRM_NO).AMT_TO_ACCRUE := 0;
          TB_ICENT(EACH_ROW.FRM_NO).ENT_DT := EACH_ROW.ENT_DT;
          TB_ICENT(EACH_ROW.FRM_NO).HAS_ACCR := EACH_ROW.HAS_ACCR;
          TB_ICENT(EACH_ROW.FRM_NO).DAILY_AMT := EACH_ROW.DAILY_AMT;
          TB_ICENT(EACH_ROW.FRM_NO).NEXT_CALC_DUE_DATE := EACH_ROW.NEXT_CALC_DUE_DATE;
          TB_ICENT(EACH_ROW.FRM_NO).ACQUIRED_AMT := 0;
          C1 := C1 + 1;
        END LOOP;
        DBG('Inside back calc sending entriees' || TB_ICENT.COUNT);
        INSERT INTO ICTWS_BACK_IS_VALS
          SELECT *
            FROM ICTBS_IS_VALS
           WHERE BRN = EACH_REC.BRN
             AND ACC = EACH_REC.ACC
             AND PROCESS = EACH_REC.PROCESS;
        DBG('ICPKSS_EOD.BKVAL_CALC table backup complete');
      
        L_LIQ_PERIOD_START := NULL;
        FOR L_VAR IN CR_LIQDT(EACH_REC.BRN,
                              EACH_REC.ACC,
                              EACH_REC.PROD,
                              'Y',
                              EACH_REC.BKVAL_MINCALC_DATE) LOOP
          DBG('Inside the existence of liq loop' || L_VAR.ENT_DT);
          L_LIQ_PERIOD_START := L_VAR.ENT_DT;
          EXIT;
        END LOOP;
        IF L_LIQ_PERIOD_START IS NULL THEN
        
          IF EACH_REC.SYS_AC_LEVEL IS NOT NULL THEN
          
            IF GLOBALS_ADDON.ILM_INSTALLED = 'Y' THEN
              SELECT EFF_DATE
                INTO L_TMPVAR1
                FROM ILTBS_SYS_ACCOUNT
               WHERE SYSTEM_ACCOUNT_BRANCH = EACH_REC.BRN
                 AND SYSTEM_ACCOUNT = EACH_REC.ACC;
            ELSE
              SELECT EFF_DATE
                INTO L_TMPVAR1
                FROM ILTBS_SYS_ACCOUNT
               WHERE BRANCH_CODE = EACH_REC.BRN
                 AND SYSTEM_ACCOUNT = EACH_REC.ACC;
            END IF;
          END IF;
        
          IF EACH_REC.SYS_AC_LEVEL IS NOT NULL THEN
            SELECT INT_START_DATE
              INTO L_TMPVAR1
              FROM ICTMS_ACC A, ILTBS_SYS_ACCOUNT B
             WHERE A.ACC = B.ACCOUNT
               AND A.BRN = B.BRANCH_CODE
               AND B.SYSTEM_ACCOUNT_BRANCH = EACH_REC.BRN
               AND B.SYSTEM_ACCOUNT = EACH_REC.ACC
               AND ROWNUM < 2;
            DBG('after selecting tmpvarl for ');
          ELSE
            SELECT INT_START_DATE
              INTO L_TMPVAR1
              FROM ICTMS_ACC
             WHERE BRN = EACH_REC.BRN
               AND ACC = EACH_REC.ACC;
            DBG('after selecting tmpvarl normal acount');
          END IF;
        
          IF NVL(EACH_REC.DEPOSIT, 'N') = 'Y' AND
             NVL(G_STTM_CUSTACC.MUDARABAH_ACCOUNTS, 'N') = 'Y' THEN
            BEGIN
              DBG('l_tmpvar1- before - ' || L_TMPVAR1);
            
              SELECT LEAST(LAST_LIQ_DT + 1, L_TMPVAR1)
              
                INTO L_TMPVAR1
                FROM ICTBS_ACC_PR
               WHERE BRN = EACH_REC.BRN
                 AND ACC = EACH_REC.ACC
                 AND PROD = EACH_REC.PROD;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
            DBG('l_tmpvar1- after - ' || L_TMPVAR1);
          END IF;
        
          L_TMPVAR1 := GREATEST(NVL(L_TMPVAR1, SYSDATE - 2000),
                                EACH_REC.FIRST_FIRST_CALC_DATE);
        
          DBG('After greatest the l_liq_period_start comes to :' ||
              L_TMPVAR1);
          L_LIQ_PERIOD_START := L_TMPVAR1 - 1;
        
        ELSE
          L_TMPVAR1 := GREATEST(L_LIQ_PERIOD_START + 1,
                                EACH_REC.FIRST_FIRST_CALC_DATE);
          DBG('in else ... After greatest the l_liq_period_start comes to :' ||
              L_TMPVAR1);
          L_LIQ_PERIOD_START := L_TMPVAR1 - 1;
        
        END IF;
      
        IF NVL(EACH_REC.DEPOSIT, 'N') = 'Y' AND
           NVL(G_STTM_CUSTACC.MUDARABAH_ACCOUNTS, 'N') = 'N' THEN
          DBG('TD account');
          BEGIN
            SELECT MAX(BROKEN_DATE)
              INTO L_TD_BROKEN_DATE
              FROM ICTB_TD_BROKEN
             WHERE BRN = EACH_REC.BRN
               AND ACC = EACH_REC.ACC;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            
              DBG('No redemptions');
              L_TD_BROKEN_DATE := '';
          END;
        
          DBG('Broken Date:' || L_TD_BROKEN_DATE);
          IF L_TD_BROKEN_DATE IS NOT NULL THEN
          
            IF L_TD_BROKEN_DATE > L_LIQ_PERIOD_START THEN
            
              L_LIQ_PERIOD_START := L_TD_BROKEN_DATE;
            
            END IF;
          
          END IF;
        END IF;
      
        BEGIN
          SELECT RU.INT_ACC_OPEN
            INTO L_RULE_ACC_OPEN
            FROM ICTM_RULE RU, ICTM_PR_INT PR
           WHERE PR.RULE = RU.RULE_ID
             AND PR.PRODUCT_CODE = EACH_REC.PROD;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_RULE_ACC_OPEN := NULL;
        END;
        DBG('l_rule_ACC_OPEN' || L_RULE_ACC_OPEN);
        IF NVL(L_RULE_ACC_OPEN, 'N') = 'N' THEN
          BEGIN
            SELECT ST.AC_OPEN_DATE
              INTO L_AC_OPEN_DATE
              FROM STTMS_CUST_ACCOUNT ST
             WHERE CUST_AC_NO = EACH_REC.ACC
               AND BRANCH_CODE = EACH_REC.BRN;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_AC_OPEN_DATE := NULL;
          END;
          DBG('l_ac_open_date' || L_AC_OPEN_DATE);
        
          IF TRUNC(L_NEXT_LIQ_PERIOD_START, 'MONTH') <=
             TRUNC(L_AC_OPEN_DATE, 'MONTH') THEN
            BEGIN
              SELECT LAST_DAY(L_NEXT_LIQ_PERIOD_START)
                INTO L_NEXT_LIQ_PERIOD_START
                FROM DUAL;
              DBG('l_next_liq_period_start in trun' ||
                  L_NEXT_LIQ_PERIOD_START);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_NEXT_LIQ_PERIOD_START := NULL;
            END;
          END IF;
        END IF;
      
        L_NEXT_LIQ_PERIOD_START := L_LIQ_PERIOD_START;
        DBG('got the liquidation start date got as' || '~' ||
            L_LIQ_PERIOD_START);
      
        IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
           (CSPKS_REQ_GLOBAL.P_CUSTOM, CSPKS_REQ_GLOBAL.P_CLUSTER) THEN
          L_FN_CALL_ID := 2;
          L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
          L_TB_CLUSTER_DATA('l_liq_period_start') := L_LIQ_PERIOD_START;
          IF NOT ICPKS_TEST_CLUSTER.FN_BKVAL_CALC(EACH_REC.BRN,
                                                  EACH_REC.ACC,
                                                  L_FN_CALL_ID,
                                                  L_TB_CLUSTER_DATA) THEN
            DBG('FAILED IN  icpks_test_cluster.fn_bkval_calc');
            RETURN FALSE;
          END IF;
          IF L_TB_CLUSTER_DATA.EXISTS('l_liq_period_start') THEN
            L_LIQ_PERIOD_START := L_TB_CLUSTER_DATA('l_liq_period_start');
          END IF;
        END IF;
      
        FOR ADJ_REC IN CR_HIST_LIQN(EACH_REC.BRN,
                                    EACH_REC.ACC,
                                    EACH_REC.PROD,
                                    L_LIQ_PERIOD_START) LOOP
          DECLARE
            K BINARY_INTEGER;
            L BINARY_INTEGER;
          BEGIN
            K := TB_ICENT.FIRST;
            IF K IS NOT NULL THEN
              L := TB_ICENT.LAST;
              WHILE K <= L LOOP
              
                TB_ICENT(K).AMT := 0;
                TB_ICENT(K).ACCRUED_AMT := 0;
                TB_ICENT(K).CUR_RUN_ACCR := 0;
                TB_ICENT(K).AMT_TO_ACCRUE := 0;
                IF K = L THEN
                  K := L + 1;
                ELSE
                  K := TB_ICENT.NEXT(K);
                END IF;
              END LOOP;
            END IF;
          END;
          L_INLOOP := TRUE;
        
          ICPKSS_TEST.TB_NEXT_CALC_DT(1) := ADJ_REC.ENT_DT + 1;
          ICPKSS_TEST.TB_NEXT_LIQ_DT(1) := ADJ_REC.ENT_DT;
          ICPKSS_TEST.TB_NEXT_ACCR_DT(1) := ADJ_REC.ENT_DT;
          ICPKSS_TEST.TB_LAST_LIQ_DT(1) := L_NEXT_LIQ_PERIOD_START;
        
          ICPKSS_TEST.TB_FIRST_CALC_DT(1) := L_NEXT_LIQ_PERIOD_START + 1;
        
          ICPKSS_TEST.TB_LAST_ACCR_DT(1) := L_NEXT_LIQ_PERIOD_START;
          ICPKSS_TEST.TB_LAST_CALC_DT(1) := L_NEXT_LIQ_PERIOD_START;
          ICPKSS_TEST.TB_LAST_SCHD_LIQ_DT(1) := L_NEXT_LIQ_PERIOD_START;
        
          DBG('Before pr_calc' || ADJ_REC.BRN || ADJ_REC.ACC ||
              ADJ_REC.PROD || L_NEXT_LIQ_PERIOD_START);
          ICPKSS_CALC.G_ICTB_ACC_PR.BRN              := EACH_REC.BRN;
          ICPKSS_CALC.G_ICTB_ACC_PR.ACC              := EACH_REC.ACC;
          ICPKSS_CALC.G_ICTB_ACC_PR.PROD             := EACH_REC.PROD;
          ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT        := EACH_REC.SC_MAP_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT        := EACH_REC.GC_MAP_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT     := L_NEXT_LIQ_PERIOD_START;
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT      := L_NEXT_LIQ_PERIOD_START;
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT      := ADJ_REC.ENT_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT     := L_NEXT_LIQ_PERIOD_START;
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT     := ADJ_REC.ENT_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT := EACH_REC.LAST_SCHD_LIQ_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH          := EACH_REC.INC_MTH;
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT := EACH_REC.NEXT_SCHD_LIQ_DT;
        
          ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT := L_NEXT_LIQ_PERIOD_START + 1;
        
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := EACH_REC.NEXT_SCHD_ACCR_DT;
          ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE         := EACH_REC.PROD_TYPE;
          ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR          := EACH_REC.HAS_ACCR;
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT      := ADJ_REC.ENT_DT + 1;
          ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR         := EACH_REC.PROD_ACCR;
          ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT      := EACH_REC.DEFER_LIQ_DT;
          ICPKSS_CALC.G_CUST_ACC.CCY                  := EACH_REC.CCY;
          ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS        := EACH_REC.ACLASS;
          ICPKSS_CALC.G_ICTB_ACC_PR.BKVAL_RECALC_FLAG := EACH_REC.BKVAL_RECALC_FLAG;
          DBG('ICPKSS_EOD.BKVAL_CALC acc_pr updation over');
          DBG('Before pr_calc' || ADJ_REC.BRN || ADJ_REC.ACC ||
              ADJ_REC.PROD || L_NEXT_LIQ_PERIOD_START);
        
          IF L_ICTM_ACC.ACC_TYPE = 'N' THEN
            ICPKS_SDE.PR_PREPARE_SDE(ADJ_REC.BRN,
                                     ADJ_REC.ACC,
                                     EACH_REC.CCY,
                                     1,
                                     1);
          ELSE
            ICPKS_SDE.PR_PREPARE_SDE_CONSOL(ADJ_REC.BRN,
                                            ADJ_REC.ACC,
                                            EACH_REC.CCY,
                                            1,
                                            1);
          END IF;
          DBG('came out sucessfully from prepare sde');
        
          DBG('WILL GET GCS FOR THE PERIOD ' || APPDT || ' TO ' ||
              ADJ_REC.ENT_DT);
        
          ICPKS_UDE.PR_PREPARE_GC(EACH_REC.BRN,
                                  EACH_REC.ACLASS,
                                  EACH_REC.CCY,
                                  EACH_REC.PROD,
                                  L_NEXT_LIQ_PERIOD_START + 1,
                                  ADJ_REC.ENT_DT,
                                  EACH_REC.NEXT_LIQ_DT);
          DBG('After prepare GC any problem');
          PR_CACHE_PROD(EACH_REC.PROD, NULL);
          ICPKS_TEST.PR_CALC(ADJ_REC.BRN,
                             ADJ_REC.ACC,
                             ADJ_REC.PROD,
                             EACH_REC.BKVAL_MINCALC_DATE,
                             TB_ICENT);
          FOR ADJ_REC_DET IN CR_HIST_LIQN_DET(ADJ_REC.BRN,
                                              ADJ_REC.ACC,
                                              ADJ_REC.PROD,
                                              ADJ_REC.ENT_DT) LOOP
            IF TB_ICENT.EXISTS(ADJ_REC_DET.FRM_NO) THEN
              DBG('got the amount from calc as' || TB_ICENT(ADJ_REC_DET.FRM_NO).AMT);
              DBG('formula number is' || ADJ_REC_DET.FRM_NO);
              L_CALC_AMT := TB_ICENT(ADJ_REC_DET.FRM_NO).AMT;
            
              IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
                 (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
                GLOBAL.PR_RESET_SKIP_KERNEL;
                L_FN_CALL_ID      := 1;
                L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
              
                L_TB_CLUSTER_DATA('l_prod') := ADJ_REC_DET.PROD;
                L_TB_CLUSTER_DATA('l_frm_no') := ADJ_REC_DET.FRM_NO;
                L_TB_CLUSTER_DATA('l_end_dt') := ADJ_REC_DET.ENT_DT;
                L_TB_CLUSTER_DATA('l_calc_amt') := TB_ICENT(ADJ_REC_DET.FRM_NO).AMT;
                IF ICPKS_TEST_CLUSTER.FN_BKVAL_CALC(ADJ_REC_DET.BRN,
                                                    ADJ_REC_DET.ACC,
                                                    L_FN_CALL_ID,
                                                    L_TB_CLUSTER_DATA) THEN
                  DBG('Back from fn_bkval_calc');
                  NULL;
                END IF;
              END IF;
            
              IF NOT GLOBAL.G_SKIP_KERNEL THEN
              
                IF ADJ_REC_DET.CCY IS NULL THEN
                  ADJ_REC_DET.CCY := EACH_REC.CCY;
                END IF;
              
                DBG('deleting the already done amount ' ||
                    NVL(ADJ_REC_DET.AMT, 0));
                L_DIFF_AMT := NVL(L_CALC_AMT, 0) - NVL(ADJ_REC_DET.AMT, 0);
              
                IF ADJ_REC_DET.CCY <> LCY AND L_DIFF_AMT <> 0 THEN
                  L_RATE := NULL;
                  DBG('Now doing currency conversion');
                
                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(ADJ_REC_DET.BRN,
                                                     ADJ_REC_DET.CCY,
                                                     GLOBAL.LCY,
                                                     L_DIFF_AMT,
                                                     'Y',
                                                     L_DIFF_AMT_LCY,
                                                     L_RATE,
                                                     L_ERR_CODE) THEN
                    DBG('Error in ccy conversion');
                    RETURN FALSE;
                  END IF;
                ELSE
                  L_DIFF_AMT_LCY := L_DIFF_AMT;
                END IF;
                DBG('updating the adj interset table' || ADJ_REC_DET.BRN ||
                    ADJ_REC_DET.ACC || ADJ_REC_DET.PROD);
                UPDATE ICTBS_ADJ_INTEREST
                   SET AMT = L_DIFF_AMT, LCY_AMT = L_DIFF_AMT_LCY
                 WHERE BRN = ADJ_REC_DET.BRN
                   AND ACC = ADJ_REC_DET.ACC
                   AND PROD = ADJ_REC_DET.PROD
                   AND FRM_NO = ADJ_REC_DET.FRM_NO
                   AND ENT_DT = ADJ_REC_DET.ENT_DT;
              
                IF SQL%ROWCOUNT = 0 AND
                   (L_DIFF_AMT <> 0 OR L_DIFF_AMT_LCY <> 0)
                
                 THEN
                  INSERT INTO ICTBS_ADJ_INTEREST
                    (BRN, ACC, PROD, FRM_NO, ENT_DT, CCY, AMT, LCY_AMT)
                  VALUES
                    (ADJ_REC_DET.BRN,
                     ADJ_REC_DET.ACC,
                     ADJ_REC_DET.PROD,
                     ADJ_REC_DET.FRM_NO,
                     ADJ_REC_DET.ENT_DT,
                     ADJ_REC_DET.CCY,
                     L_DIFF_AMT,
                     L_DIFF_AMT_LCY);
                END IF;
              
              ELSE
                DBG('fn_bkval_calc Code Skipped');
                GLOBAL.PR_RESET_SKIP_KERNEL;
              END IF;
            
            END IF;
          END LOOP;
          L_NEXT_LIQ_PERIOD_START := ADJ_REC.ENT_DT;
        END LOOP;
        K := NVL(TBL_ACQUIRED_AMT.COUNT, 0);
        FOR INT_ADJ_REC IN CR_INT_ADJ(EACH_REC.BRN,
                                      EACH_REC.ACC,
                                      EACH_REC.PROD) LOOP
          IF TB_ICENT.EXISTS(INT_ADJ_REC.FRM_NO) THEN
          
            K := K + 1;
            DBG('Amount acquired cameout as' || INT_ADJ_REC.TOT_ACY || '~' ||
                INT_ADJ_REC.TOT_LCY);
            IF INT_ADJ_REC.CCY = LCY THEN
              TBL_ACQUIRED_AMT(K) := INT_ADJ_REC.TOT_LCY;
            ELSE
              TBL_ACQUIRED_AMT(K) := INT_ADJ_REC.TOT_ACY;
            END IF;
          
            BEGIN
              SELECT FC_START_DATE
                INTO L_FC_STRT_DT
                FROM STTMS_FIN_CYCLE
               WHERE FIN_CYCLE =
                     (SELECT CURRENT_CYCLE
                        FROM STTMS_BRANCH
                       WHERE BRANCH_CODE = EACH_REC.BRN);
              DBG('Got the current financial yr as ' || L_FC_STRT_DT);
              FOR INT_ADJ_PAST_YR IN CR_INT_ADJ_PAST_YR(EACH_REC.BRN,
                                                        EACH_REC.ACC,
                                                        EACH_REC.PROD,
                                                        L_FC_STRT_DT,
                                                        INT_ADJ_REC.FRM_NO) LOOP
                DBG('Amount acquired cameout as' ||
                    INT_ADJ_PAST_YR.TOT_ACY || '~' ||
                    INT_ADJ_PAST_YR.TOT_LCY);
                IF INT_ADJ_PAST_YR.CCY = LCY THEN
                  TBL_PREV_YR_ACQUIRED_AMT(K) := INT_ADJ_PAST_YR.TOT_LCY;
                ELSE
                  TBL_PREV_YR_ACQUIRED_AMT(K) := INT_ADJ_PAST_YR.TOT_ACY;
                END IF;
              END LOOP;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Came in exception ' || SQLERRM);
            END;
          
            TBL_DAILY_AMT(K) := TB_ICENT(INT_ADJ_REC.FRM_NO).DAILY_AMT;
            TBL_ACC(K) := INT_ADJ_REC.ACC;
            TBL_BRN(K) := INT_ADJ_REC.BRN;
            TBL_PROD(K) := INT_ADJ_REC.PROD;
            TBL_FRM_NO(K) := INT_ADJ_REC.FRM_NO;
          END IF;
        END LOOP;
        DBG('B4 SELECT FROM  ICTWS_ACC_PR ');
        DBG('AFTER UPDATE OF  ICTB_ACC_PR ');
        DBG('B4 DELETE OF ICTBS_IS_VALS');
        DELETE ICTBS_IS_VALS
         WHERE BRN = EACH_REC.BRN
           AND ACC = EACH_REC.ACC
           AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART;
      
        FOR INS_INDX IN (SELECT *
                           FROM ICTWS_BACK_IS_VALS
                          WHERE BRN = EACH_REC.BRN
                            AND ACC = EACH_REC.ACC
                            AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART) LOOP
          BEGIN
            INSERT INTO ICTBS_IS_VALS
              (BRN,
               ACC,
               RULE_ID,
               FRM_NO,
               FRM_DT,
               FRM_EL1,
               FRM_EL2,
               FRM_VAL,
               DAYS,
               PROCESS)
            VALUES
              (INS_INDX.BRN,
               INS_INDX.ACC,
               INS_INDX.RULE_ID,
               INS_INDX.FRM_NO,
               INS_INDX.FRM_DT,
               INS_INDX.FRM_EL1,
               INS_INDX.FRM_EL2,
               INS_INDX.FRM_VAL,
               INS_INDX.DAYS,
               INS_INDX.PROCESS);
          
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
              DBG('Insertion failed because of Duplicate records in ICTBS_IS_VALS');
            WHEN OTHERS THEN
              DBG('insertion failed to ICTBS_IS_VALS' || SQLERRM);
            
          END;
        
        END LOOP;
      
        DELETE ICTWS_BACK_IS_VALS
         WHERE BRN = EACH_REC.BRN
           AND ACC = EACH_REC.ACC
           AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART;
      
        TBL_ROW_ID(SR) := EACH_REC.ROW_ID;
        SR := SR + 1;
        DBG('ICPKSS_TEST.BKVAL_CALC Deletion over');
        L_PREV_ACC := EACH_REC.BRN || EACH_REC.ACC;
      
      ELSE
        DBG('fn_bkval_calc Code Skipped');
        GLOBAL.PR_RESET_SKIP_KERNEL;
      END IF;
    
    END LOOP;
    IF NVL(TBL_ROW_ID.COUNT, 0) <> 0 THEN
      FORALL K IN TBL_ROW_ID.FIRST .. TBL_ROW_ID.LAST
        UPDATE ICTBS_ACC_PR
           SET BKVAL_RECALC_FLAG = 'N', BKVAL_MINCALC_DATE = NULL
         WHERE ROWID = TBL_ROW_ID(K)
           AND NVL(STOP_IC, 'N') = 'N';
    END IF;
    IF NVL(TBL_ACC.COUNT, 0) <> 0 THEN
      FORALL K IN TBL_ACC.FIRST .. TBL_ACC.LAST
        UPDATE ICTBS_ENTRIES
           SET ACQUIRED_AMT = TBL_ACQUIRED_AMT(K)
         WHERE BRN = TBL_BRN(K)
           AND ACC = TBL_ACC(K)
           AND PROD = TBL_PROD(K)
           AND FRM_NO = TBL_FRM_NO(K)
           AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART;
    
      BEGIN
        FOR K IN TBL_ACC.FIRST .. TBL_ACC.LAST LOOP
          IF (TBL_PREV_YR_ACQUIRED_AMT.EXISTS(K)) THEN
            DBG('Update is here ');
            DBG('tbl_prev_yr_acquired_amt(k) ' ||
                TBL_PREV_YR_ACQUIRED_AMT(K));
            DBG('tbl_frm_no(k) ' || TBL_FRM_NO(K));
            UPDATE ICTB_PAST_ADJ_ENTRIES
               SET ACQUIRED_AMT = TBL_PREV_YR_ACQUIRED_AMT(K)
             WHERE BRN = TBL_BRN(K)
               AND ACC = TBL_ACC(K)
               AND PROD = TBL_PROD(K)
               AND FRM_NO = TBL_FRM_NO(K);
            IF SQL%ROWCOUNT = 0 THEN
              DBG('Going to insert as count is 0 ');
              INSERT INTO ICTB_PAST_ADJ_ENTRIES
                (BRN, ACC, PROD, FRM_NO, ACQUIRED_AMT)
              VALUES
                (TBL_BRN(K),
                 TBL_ACC(K),
                 TBL_PROD(K),
                 TBL_FRM_NO(K),
                 TBL_PREV_YR_ACQUIRED_AMT(K));
            END IF;
          END IF;
        END LOOP;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In exception ' || SQLERRM);
      END;
    
      FORALL K IN TBL_ACC.FIRST .. TBL_ACC.LAST
        DELETE ICTWS_BACK_IS_VALS
         WHERE BRN = TBL_BRN(K)
           AND ACC = TBL_ACC(K)
           AND PROCESS = ICPKS_PARTITION_INFO.G_THIS_PART;
    END IF;
  
    TBL_BRN.DELETE;
    TBL_ACC.DELETE;
    TBL_ACQUIRED_AMT.DELETE;
    TBL_PREV_YR_ACQUIRED_AMT.DELETE;
    TBL_PROD.DELETE;
    TBL_FRM_NO.DELETE;
    TBL_ROW_ID.DELETE;
    TB_ICENT.DELETE;
  
    ICPKSS_TEST.G_BKVAL_CALC := FALSE;
  
    DBG('the transaction would be commited only if is from gateway(gw)  - global.pkg_is_txn_via_gw ' ||
        GLOBAL.PKG_IS_TXN_VIA_GW);
    DBG('icpks_test.g_onliq_flag is = ' || ICPKS_TEST.G_ONLIQ_FLAG);
  
    IF GLOBAL.PKG_IS_TXN_VIA_GW <> 'Y' AND
       NOT STPKS_STDCUSAC_UTILS_2.G_AC_CLOSURE AND
       NOT GWPKS_UTIL.G_FROM_BEAN AND
       NVL(ICPKS_TEST.G_ONLIQ_FLAG, 'N') <> 'Y' THEN
      DBG('Commiting the transaction as it is NOT COMING from the gateway');
      COMMIT;
    ELSE
      DBG('the commit will not happen as the txn is coming via gateway');
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('IN WHEN OTHERS OF ICPKSS_TEST.BKVAL_CALC WITH ' || SQLERRM);
      DBG(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
      ICPKSS_TEST.G_BKVAL_CALC := FALSE;
    
      RETURN FALSE;
  END;

  PROCEDURE PR_PURGE_PLSQL_TABS IS
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
    DBG('inside purge..');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      DBG(1);
      ICPKS_TEST_CLUSTER.PR_PURGE_PLSQL_TABS(L_FN_CALL_ID,
                                             L_TB_CLUSTER_DATA);
      DBG(2);
    END IF;
  
    TB_ICENT_HIST_BRN.DELETE;
    TB_ICENT_HIST_ACC.DELETE;
    TB_ICENT_HIST_PROD.DELETE;
    TB_ICENT_HIST_FRM_NO.DELETE;
    TB_ICENT_HIST_ENT_DT.DELETE;
    TB_ICENT_HIST_AMT.DELETE;
    TB_ICENT_HIST_ACCRUED_AMT.DELETE;
    TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE;
    TB_ICENT_HIST_CUR_RUN_ACCR.DELETE;
    TB_ICENT_HIST_RUN_DATE.DELETE;
    TB_ICENT_HIST_ACCR.DELETE;
    TB_ICENT_HIST_LIQN.DELETE;
    TB_ICENT_HIST_ENTRY_TYPE.DELETE;
    TB_ICENT_HIST_CCY.DELETE;
    TB_ICENT_HIST_LCY_AMT.DELETE;
    TB_ICENT_HIST_LAST_CUR_ACCR.DELETE;
    TB_ICENT_HIST_CURACCR_LCY.DELETE;
  
    TB_ICENT_HIST_UPD.DELETE;
    TB_ICENT_HIST_ADJ.DELETE;
    DBG('history purge completed');
  
    TB_ICENT_UPD_BRN.DELETE;
    TB_ICENT_UPD_ACC.DELETE;
  
    TB_ICENT_PAST_ADJ_UPD_ROWID.DELETE;
    TB_ICENT_PAST_ADJ_UPD_ACQ_AMT.DELETE;
    TB_ICENT_PAST_ADJ_UPD_ACQ_ADJ.DELETE;
    G_TB_SKIPPED_ACCTS.DELETE;
  
    TB_ICENT_UPD_PROD.DELETE;
    TB_ICENT_UPD_FRM_NO.DELETE;
    TB_ICENT_UPD_AMT.DELETE;
    TB_ICENT_UPD_ACCRUED_AMT.DELETE;
    TB_ICENT_UPD_AMT_TO_ACCRUE.DELETE;
    TB_ICENT_UPD_CUR_RUN_ACCR.DELETE;
    TB_ICENT_UPD_ENT_DT.DELETE;
    TB_ICENT_UPD_DRCR.DELETE;
    TB_ICENT_UPD_HAS_ACCR.DELETE;
    TB_ICENT_UPD_DAILY_AMT.DELETE;
    TB_ICENT_UPD_NEXT_CALC_DUE_DT.DELETE;
    TB_ICENT_UPD_ACQUIRED_AMT.DELETE;
    TB_ICENT_UPD_ROWID.DELETE;
    DBG('entries upd deletion done');
  
    TB_ICENT.DELETE;
  
    TB_ICENT_LIQNET.DELETE;
  
    TB_ICENT_PROD.DELETE;
  
    TB_ICTMACC_UPD_ACC.DELETE;
    TB_ICTMACC_UPD_BRN.DELETE;
    TB_ICTMACC_UPD_ISDT.DELETE;
    FRMLIST    := NULL;
    FRMLISTLIQ := NULL;
    DBG('All deletion done');
    TB_ICENT_ZEROACCR_HIST.DELETE;
    TB_ICENT_ACCR_HIST.DELETE;
  
    TB_ICENT_HIST_UPD_BAK.DELETE;
    TB_ICENT_LIQNET_BAK.DELETE;
    TB_ICENT_PROD_BAK.DELETE;
    TB_ICENT_UPD_ACC_BAK.DELETE;
    TB_ICENT_UPD_ACCRUED_AMT_BAK.DELETE;
    TB_ICENT_UPD_ACQUIRED_ADJ_BAK.DELETE;
    TB_ICENT_UPD_ACQUIRED_AMT_BAK.DELETE;
    TB_ICENT_UPD_AMT_BAK.DELETE;
    TB_ICENT_UPD_AMT_TO_ACCRUE_BAK.DELETE;
    TB_ICENT_UPD_CUR_RUN_ACCR_BAK.DELETE;
    TB_ICENT_UPD_DAILY_AMT_BAK.DELETE;
    TB_ICENT_UPD_DRCR_BAK.DELETE;
    TB_ICENT_UPD_ENT_DT_BAK.DELETE;
    TB_ICENT_UPD_HAS_ACCR_BAK.DELETE;
    TB_ICENT_UPD_ROWID_BAK.DELETE;
    TB_ICNT_UPD_NXT_CLC_DUE_DT_BAK.DELETE;
  
    ICPKS_TEST.G_TB_AMT_NOT_ACCRUED.DELETE;
    ICPKS_TEST.G_MOD_CURRUNACCR := FALSE;
  
    DBMS_SESSION.FREE_UNUSED_USER_MEMORY;
    IF NOT ICPKS_CACHE.FN_CLEARCACHE THEN
      DBG('Could not clear cache');
      RETURN;
    END IF;
  
  END PR_PURGE_PLSQL_TABS;
  PROCEDURE PR_MSTB_INSERT IS
    MS BINARY_INTEGER;
  BEGIN
  
    IF TB_MS_REF_ACC.COUNT > 0 THEN
    
      IF CSPKS_FEATURE.FN_INSTALLED('ICINTSTMT', GLOBAL.CURRENT_BRANCH) THEN
      
        FORALL MST IN TB_MS_REF_ACC.FIRST .. TB_MS_REF_ACC.LAST
          INSERT INTO MSTB_DLY_MSG_OUT
            (BRANCH,
             REFERENCE_NO,
             ESN,
             MODULE,
             MSG_TYPE,
             RECEIVER,
             MEDIA,
             MSG_STATUS,
             GENERATE_STATUS,
             HOLD_STATUS,
             AUTH_STAT,
             FROM_DATE,
             TO_DATE,
             DIRECTIVE_STATUS,
             CUST_AC_NO)
          VALUES
            (TB_MS_BRN(MST),
             TB_MS_REF_ACC(MST),
             1,
             
             TB_MS_MODULE(MST),
             DECODE(TB_MS_MODULE(MST), 'IC', 'INTST', 'IPINTST')
             
            ,
             TB_MS_RECEIVER(MST)
             
            ,
             NVL(TB_MS_DEFAULT_MEDIA(MST), 'MAIL'),
             'N',
             'N',
             'N',
             'A',
             TB_MS_FRM_DT(MST),
             TB_MS_TO_DT(MST),
             'B',
             TB_MS_REF_ACC(MST));
        TB_MS_BRN.DELETE;
        TB_MS_REF_ACC.DELETE;
        TB_MS_RECEIVER.DELETE;
        TB_MS_MEDIA.DELETE;
        TB_MS_FRM_DT.DELETE;
        TB_MS_TO_DT.DELETE;
        TB_MS_DEFAULT_MEDIA.DELETE;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in insert into the dly out' || SQLERRM);
      TB_MS_BRN.DELETE;
      TB_MS_REF_ACC.DELETE;
      TB_MS_RECEIVER.DELETE;
      TB_MS_MEDIA.DELETE;
      TB_MS_FRM_DT.DELETE;
      TB_MS_TO_DT.DELETE;
      TB_MS_DEFAULT_MEDIA.DELETE;
  END PR_MSTB_INSERT;
  PROCEDURE PR_UPD_TBL(P_LIQ_DT DATE) IS
    BUG1        NUMBER;
    L_INDEX1    NUMBER := 0;
    L_IDX       NUMBER := 0;
    L_UPD_COUNT NUMBER;
  BEGIN
    DBG('Calling pr_upd_tbl');
  
    IF TB_ICENT_HIST_ACC.COUNT <> 0 THEN
      L_INDEX1 := 0;
      L_IDX    := 0;
      FOR J IN TB_ICENT_HIST_ACC.FIRST .. TB_ICENT_HIST_ACC.LAST LOOP
        IF TB_ICENT_HIST_ACCR(J) = 'Y' THEN
        
          IF NVL(TB_ICENT_HIST_AMT(J), 0) = 0 AND
             NVL(TB_ICENT_HIST_ACCRUED_AMT(J), 0) = 0 AND
             NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J), 0) = 0 AND
             NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J), 0) = 0 THEN
            L_IDX := L_IDX + 1;
            TB_ICENT_ZEROACCR_HIST(L_IDX).BRN := TB_ICENT_HIST_BRN(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).ACC := TB_ICENT_HIST_ACC(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).PROD := TB_ICENT_HIST_PROD(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).FRM_NO := TB_ICENT_HIST_FRM_NO(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).ENT_DT := P_LIQ_DT;
            TB_ICENT_ZEROACCR_HIST(L_IDX).AMT := NVL(TB_ICENT_HIST_AMT(J),
                                                     0);
            TB_ICENT_ZEROACCR_HIST(L_IDX).ACCRUED_AMT := NVL(TB_ICENT_HIST_ACCRUED_AMT(J),
                                                             0);
            TB_ICENT_ZEROACCR_HIST(L_IDX).CUR_RUN_ACCR := NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J),
                                                              0);
            TB_ICENT_ZEROACCR_HIST(L_IDX).AMT_TO_ACCRUE := NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J),
                                                               0);
            TB_ICENT_ZEROACCR_HIST(L_IDX).RUN_DATE := TB_ICENT_HIST_RUN_DATE(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).ENTRY_TYPE := TB_ICENT_HIST_ENTRY_TYPE(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).CCY := TB_ICENT_HIST_CCY(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).LCY_AMT := TB_ICENT_HIST_LCY_AMT(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).CUR_RUN_ACCR_LCY := TB_ICENT_HIST_CURACCR_LCY(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(J),
                                                                          TB_ICENT_HIST_FRM_NO(J));
            TB_ICENT_ZEROACCR_HIST(L_IDX).ENTRY_PASSED := TB_ICENT_HIST_ENTRY_PASSED(J);
            TB_ICENT_ZEROACCR_HIST(L_IDX).PROCESS := ICPKS_PARTITION_INFO.G_THIS_PART;
            TB_ICENT_ZEROACCR_HIST(L_IDX).LAST_CUR_RUN_ACCR := TB_ICENT_HIST_LAST_CUR_ACCR(J);
          ELSE
          
            L_INDEX1 := L_INDEX1 + 1;
            TB_ICENT_ACCR_HIST(L_INDEX1).BRN := TB_ICENT_HIST_BRN(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).ACC := TB_ICENT_HIST_ACC(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).PROD := TB_ICENT_HIST_PROD(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).FRM_NO := TB_ICENT_HIST_FRM_NO(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).ENT_DT := P_LIQ_DT;
            TB_ICENT_ACCR_HIST(L_INDEX1).AMT := NVL(TB_ICENT_HIST_AMT(J), 0);
            TB_ICENT_ACCR_HIST(L_INDEX1).ACCRUED_AMT := NVL(TB_ICENT_HIST_ACCRUED_AMT(J),
                                                            0);
            TB_ICENT_ACCR_HIST(L_INDEX1).CUR_RUN_ACCR := NVL(TB_ICENT_HIST_CUR_RUN_ACCR(J),
                                                             0);
            TB_ICENT_ACCR_HIST(L_INDEX1).AMT_TO_ACCRUE := NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(J),
                                                              0);
            TB_ICENT_ACCR_HIST(L_INDEX1).RUN_DATE := TB_ICENT_HIST_RUN_DATE(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).ENTRY_TYPE := TB_ICENT_HIST_ENTRY_TYPE(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).CCY := TB_ICENT_HIST_CCY(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).LCY_AMT := TB_ICENT_HIST_LCY_AMT(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).CUR_RUN_ACCR_LCY := TB_ICENT_HIST_CURACCR_LCY(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(J),
                                                                         TB_ICENT_HIST_FRM_NO(J));
            TB_ICENT_ACCR_HIST(L_INDEX1).ENTRY_PASSED := TB_ICENT_HIST_ENTRY_PASSED(J);
            TB_ICENT_ACCR_HIST(L_INDEX1).PROCESS := ICPKS_PARTITION_INFO.G_THIS_PART;
          
          END IF;
        
          IF TB_ICENT_HIST_LIQN(J) = 'N' THEN
            TB_ICENT_HIST_BRN.DELETE(J);
            TB_ICENT_HIST_ACC.DELETE(J);
            TB_ICENT_HIST_PROD.DELETE(J);
            TB_ICENT_HIST_FRM_NO.DELETE(J);
            TB_ICENT_HIST_AMT.DELETE(J);
            TB_ICENT_HIST_ACCRUED_AMT.DELETE(J);
            TB_ICENT_HIST_CUR_RUN_ACCR.DELETE(J);
            TB_ICENT_HIST_AMT_TO_ACCRUE.DELETE(J);
            TB_ICENT_HIST_RUN_DATE.DELETE(J);
            TB_ICENT_HIST_ENTRY_TYPE.DELETE(J);
            TB_ICENT_HIST_CCY.DELETE(J);
            TB_ICENT_HIST_LCY_AMT.DELETE(J);
            TB_ICENT_HIST_CURACCR_LCY.DELETE(J);
            TB_ICENT_HIST_ENTRY_PASSED.DELETE(J);
          
            TB_ICENT_HIST_ACCR.DELETE(J);
            TB_ICENT_HIST_LIQN.DELETE(J);
            TB_ICENT_HIST_LAST_CUR_ACCR.DELETE(J);
          END IF;
        END IF;
      END LOOP;
    END IF;
    IF TB_ICENT_ACCR_HIST.COUNT <> 0 THEN
      BEGIN
        FORALL X IN INDICES OF TB_ICENT_ACCR_HIST
          INSERT INTO ICTBS_ENTRIES_HISTORY_ACCR
            (BRN,
             ACC,
             PROD,
             FRM_NO,
             ENT_DT,
             AMT,
             ACCRUED_AMT,
             CUR_RUN_ACCR,
             AMT_TO_ACCRUE,
             RUN_DATE,
             ENTRY_TYPE,
             CCY,
             LCY_AMT,
             CUR_RUN_ACCR_LCY,
             DRCR,
             ENTRY_PASSED,
             PROCESS)
          VALUES
            (TB_ICENT_ACCR_HIST(X).BRN,
             TB_ICENT_ACCR_HIST(X).ACC,
             TB_ICENT_ACCR_HIST(X).PROD,
             TB_ICENT_ACCR_HIST(X).FRM_NO,
             TB_ICENT_ACCR_HIST(X).ENT_DT,
             TB_ICENT_ACCR_HIST(X).AMT,
             TB_ICENT_ACCR_HIST(X).ACCRUED_AMT,
             TB_ICENT_ACCR_HIST(X).CUR_RUN_ACCR,
             TB_ICENT_ACCR_HIST(X).AMT_TO_ACCRUE,
             TB_ICENT_ACCR_HIST(X).RUN_DATE,
             TB_ICENT_ACCR_HIST(X).ENTRY_TYPE,
             TB_ICENT_ACCR_HIST(X).CCY,
             TB_ICENT_ACCR_HIST(X).LCY_AMT,
             TB_ICENT_ACCR_HIST(X).CUR_RUN_ACCR_LCY,
             TB_ICENT_ACCR_HIST(X).DRCR,
             TB_ICENT_ACCR_HIST(X).ENTRY_PASSED,
             TB_ICENT_ACCR_HIST(X).PROCESS);
      
        DBG('Through with bulk insert into ICTBS_ENTRIES_HISTORY_ACCR');
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          DBG('insert into entries hist  accr failed with ' || SQLERRM ||
              ' for : ' || P_LIQ_DT);
      END;
    
      BEGIN
        DBG(' APY... just before moving to hist');
      
        IF CSPKS_FEATURE.FN_INSTALLED('APY', GLOBAL.CURRENT_BRANCH) THEN
        
          FOR K IN TB_ICENT_ACCR_HIST.FIRST .. TB_ICENT_ACCR_HIST.LAST LOOP
            BEGIN
              INSERT INTO ICTBS_APY_HISTORY
                (BRN,
                 ACC,
                 PROD,
                 FRM_NO,
                 ENT_DT,
                 AMT,
                 ACCRUED_AMT,
                 AMT_TO_ACCRUE,
                 RUN_DATE,
                 LIQN)
                SELECT E.BRN,
                       E.ACC,
                       E.PROD,
                       E.FRM_NO,
                       P_LIQ_DT,
                       E.AMT,
                       E.ACCRUED_AMT,
                       E.AMT_TO_ACCRUE,
                       TB_ICENT_ACCR_HIST(K).RUN_DATE,
                       'N'
                  FROM ICTBS_APY E
                 WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                   AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD
                   AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC;
              DBG(' APY... after inst into history');
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG(' in dup val');
                UPDATE ICTBS_APY_HISTORY
                   SET AMT        =
                       (SELECT E.AMT
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                           AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC
                           AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD),
                       ACCRUED_AMT =
                       (SELECT E.ACCRUED_AMT
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_ACCR_HIST(K).BRN
                           AND E.ACC = TB_ICENT_ACCR_HIST(K).ACC
                           AND E.PROD = TB_ICENT_ACCR_HIST(K).PROD),
                       ENT_DT      = P_LIQ_DT
                 WHERE BRN = TB_ICENT_ACCR_HIST(K).BRN
                   AND ACC = TB_ICENT_ACCR_HIST(K).ACC
                   AND PROD = TB_ICENT_ACCR_HIST(K).PROD;
            END;
          END LOOP;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG(' APY... Error ' || SQLERRM);
      END;
    END IF;
  
    DBG('going to populate ictb_entries_hist_zeroaccr for 0 accrual accounts ' ||
        TB_ICENT_ZEROACCR_HIST.COUNT);
    IF TB_ICENT_ZEROACCR_HIST.COUNT <> 0 THEN
    
      BEGIN
        FORALL X IN TB_ICENT_ZEROACCR_HIST.FIRST .. TB_ICENT_ZEROACCR_HIST.LAST SAVE
                                                    EXCEPTIONS
          INSERT INTO ICTB_ENTRIES_HIST_ZEROACCR
            (BRN,
             ACC,
             PROD,
             FRM_NO,
             ENT_DT,
             AMT,
             ACCRUED_AMT,
             CUR_RUN_ACCR,
             AMT_TO_ACCRUE,
             RUN_DATE,
             ENTRY_TYPE,
             CCY,
             LCY_AMT,
             CUR_RUN_ACCR_LCY,
             LAST_CUR_RUN_ACCR,
             DRCR,
             ENTRY_PASSED,
             PROCESS)
          VALUES
            (TB_ICENT_ZEROACCR_HIST(X).BRN,
             TB_ICENT_ZEROACCR_HIST(X).ACC,
             TB_ICENT_ZEROACCR_HIST(X).PROD,
             TB_ICENT_ZEROACCR_HIST(X).FRM_NO,
             TB_ICENT_ZEROACCR_HIST(X).ENT_DT,
             TB_ICENT_ZEROACCR_HIST(X).AMT,
             TB_ICENT_ZEROACCR_HIST(X).ACCRUED_AMT,
             TB_ICENT_ZEROACCR_HIST(X).CUR_RUN_ACCR,
             TB_ICENT_ZEROACCR_HIST(X).AMT_TO_ACCRUE,
             TB_ICENT_ZEROACCR_HIST(X).RUN_DATE,
             TB_ICENT_ZEROACCR_HIST(X).ENTRY_TYPE,
             TB_ICENT_ZEROACCR_HIST(X).CCY,
             TB_ICENT_ZEROACCR_HIST(X).LCY_AMT,
             TB_ICENT_ZEROACCR_HIST(X).CUR_RUN_ACCR_LCY,
             TB_ICENT_ZEROACCR_HIST(X).LAST_CUR_RUN_ACCR,
             TB_ICENT_ZEROACCR_HIST(X).DRCR,
             TB_ICENT_ZEROACCR_HIST(X).ENTRY_PASSED,
             TB_ICENT_ZEROACCR_HIST(X).PROCESS);
        DBG('Through with bulk zero accr insert');
      EXCEPTION
        WHEN BULK_ERRORS THEN
          DBG('insert into zero accr entries hist failed with ' || SQLERRM);
          DBG('SQL%BULK_EXCEPTIONS.COUNT zero accr' ||
              SQL%BULK_EXCEPTIONS.COUNT);
        
          FOR J IN 1 .. SQL%BULK_EXCEPTIONS.COUNT LOOP
            L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
          
            DBG('~j = ' || J ||
                ' ***** SQL%BULK_EXCEPTIONS(j).ERROR_INDEX = ' ||
                L_ERROR_INDEX);
            DBG('SQL%BULK_EXCEPTIONS (j).ERROR_CODE =' || SQL%BULK_EXCEPTIONS(J)
                .ERROR_CODE);
          
            IF ABS(SQL%BULK_EXCEPTIONS(J).ERROR_CODE) = 1 THEN
              L_ERROR_INDEX := SQL%BULK_EXCEPTIONS(J).ERROR_INDEX;
              DBG('zero accr  l_error_index =' || L_ERROR_INDEX);
            
              UPDATE ICTB_ENTRIES_HIST_ZEROACCR
                 SET AMT               = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).AMT,
                                             0),
                     ACCRUED_AMT       = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .ACCRUED_AMT,
                                             0),
                     CUR_RUN_ACCR      = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .CUR_RUN_ACCR,
                                             0),
                     AMT_TO_ACCRUE     = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .AMT_TO_ACCRUE,
                                             0),
                     RUN_DATE          = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                         .RUN_DATE,
                     ENTRY_TYPE        = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                         .ENTRY_TYPE,
                     CCY               = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).CCY,
                     LCY_AMT           = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .LCY_AMT,
                                             0),
                     LAST_CUR_RUN_ACCR = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .LAST_CUR_RUN_ACCR,
                                             0),
                     CUR_RUN_ACCR_LCY  = NVL(TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                             .CUR_RUN_ACCR_LCY,
                                             0),
                     ENTRY_PASSED      = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                                         .ENTRY_PASSED
               WHERE BRN = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).BRN
                 AND ACC = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).ACC
                 AND PROD = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).PROD
                 AND FRM_NO = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX).FRM_NO
                 AND ENT_DT = P_LIQ_DT
                 AND PROCESS = TB_ICENT_ZEROACCR_HIST(L_ERROR_INDEX)
                    .PROCESS;
            
              DBG('zero accr finished ');
            END IF;
          END LOOP;
        WHEN OTHERS THEN
          DBG('insert into entries hist zero accr failed with ' || SQLERRM);
          DECLARE
            L_ERROR_COUNT NUMBER := 0;
            J             NUMBER := 0;
          BEGIN
            L_ERROR_COUNT := SQL%BULK_EXCEPTIONS.COUNT;
            FOR I IN 1 .. L_ERROR_COUNT LOOP
              J := 0;
              FOR K IN TB_ICENT_ZEROACCR_HIST.FIRST .. TB_ICENT_ZEROACCR_HIST.LAST LOOP
                J := J + 1;
                IF J = SQL%BULK_EXCEPTIONS(I).ERROR_INDEX THEN
                  BEGIN
                    LPG('insert into entries zero hist failed with ' || '~' || TB_ICENT_ZEROACCR_HIST(K).ACC || '~' ||
                        SUBSTR(SQLERRM(-SQL%BULK_EXCEPTIONS(I).ERROR_CODE),
                               1,
                               1900),
                        TB_ICENT_ZEROACCR_HIST(K).ACC);
                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
                  EXIT;
                END IF;
              END LOOP;
            END LOOP;
          END;
      END;
    
    END IF;
  
    IF TB_ICENT_HIST_ACC.COUNT <> 0 THEN
      DBG('before calling the entries history' || TB_ICENT_HIST_ACC.COUNT);
      DBG('Values ofp_liq_dt--> ' || P_LIQ_DT);
      BEGIN
      
        FORALL K IN INDICES OF TB_ICENT_HIST_ACC
        
          INSERT INTO ICTBS_ENTRIES_HISTORY
            (BRN,
             ACC,
             PROD,
             FRM_NO,
             ENT_DT,
             AMT,
             ACCRUED_AMT,
             CUR_RUN_ACCR,
             AMT_TO_ACCRUE,
             RUN_DATE,
             ACCR,
             LIQN,
             ENTRY_TYPE,
             CCY,
             LCY_AMT,
             LAST_CUR_RUN_ACCR,
             CUR_RUN_ACCR_LCY,
             
             DRCR
             
            ,
             ENTRY_PASSED,
             PROCESS)
          VALUES
            (TB_ICENT_HIST_BRN(K),
             TB_ICENT_HIST_ACC(K),
             TB_ICENT_HIST_PROD(K),
             TB_ICENT_HIST_FRM_NO(K),
             P_LIQ_DT,
             NVL(TB_ICENT_HIST_AMT(K), 0),
             NVL(TB_ICENT_HIST_ACCRUED_AMT(K), 0),
             
             DECODE(TB_ICENT_HIST_LIQN(K),
                    'Y',
                    0,
                    NVL(TB_ICENT_HIST_CUR_RUN_ACCR(K), 0)),
             
             NVL(TB_ICENT_HIST_AMT_TO_ACCRUE(K), 0),
             TB_ICENT_HIST_RUN_DATE(K),
             TB_ICENT_HIST_ACCR(K),
             TB_ICENT_HIST_LIQN(K),
             TB_ICENT_HIST_ENTRY_TYPE(K),
             TB_ICENT_HIST_CCY(K),
             TB_ICENT_HIST_LCY_AMT(K),
             TB_ICENT_HIST_LAST_CUR_ACCR(K),
             TB_ICENT_HIST_CURACCR_LCY(K),
             
             ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_PROD(K),
                                     TB_ICENT_HIST_FRM_NO(K))
             
            ,
             TB_ICENT_HIST_ENTRY_PASSED(K),
             ICPKS_PARTITION_INFO.G_THIS_PART);
        DBG('Through with bulk insert');
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          DBG('insert into entries hist failed with ' || SQLERRM ||
              ' for : ' || P_LIQ_DT);
      END;
      BEGIN
        DBG(' APY... just before moving to hist');
      
        IF CSPKS_FEATURE.FN_INSTALLED('APY', GLOBAL.CURRENT_BRANCH) THEN
        
          FOR K IN TB_ICENT_HIST_ACC.FIRST .. TB_ICENT_HIST_ACC.LAST LOOP
            BEGIN
              INSERT INTO ICTBS_APY_HISTORY
                (BRN,
                 ACC,
                 PROD,
                 FRM_NO,
                 ENT_DT,
                 AMT,
                 ACCRUED_AMT,
                 AMT_TO_ACCRUE,
                 RUN_DATE,
                 LIQN)
                SELECT E.BRN,
                       E.ACC,
                       E.PROD,
                       E.FRM_NO,
                       P_LIQ_DT,
                       E.AMT,
                       E.ACCRUED_AMT,
                       E.AMT_TO_ACCRUE,
                       TB_ICENT_HIST_RUN_DATE(K),
                       TB_ICENT_HIST_LIQN(K)
                  FROM ICTBS_APY E
                 WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                   AND E.PROD = TB_ICENT_HIST_PROD(K)
                   AND E.ACC = TB_ICENT_HIST_ACC(K);
              DBG(' APY... after inst into history');
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG(' in dup val');
                UPDATE ICTBS_APY_HISTORY
                   SET AMT        =
                       (SELECT E.AMT
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                           AND E.ACC = TB_ICENT_HIST_ACC(K)
                           AND E.PROD = TB_ICENT_HIST_PROD(K)),
                       ACCRUED_AMT =
                       (SELECT E.ACCRUED_AMT
                          FROM ICTBS_APY E
                         WHERE E.BRN = TB_ICENT_HIST_BRN(K)
                           AND E.ACC = TB_ICENT_HIST_ACC(K)
                           AND E.PROD = TB_ICENT_HIST_PROD(K)),
                       ENT_DT      = P_LIQ_DT
                 WHERE BRN = TB_ICENT_HIST_BRN(K)
                   AND ACC = TB_ICENT_HIST_ACC(K)
                   AND PROD = TB_ICENT_HIST_PROD(K);
            END;
          END LOOP;
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG(' APY... Error ' || SQLERRM);
      END;
    
    END IF;
    IF NVL(TB_ICENT_HIST_UPD.COUNT, 0) <> 0 THEN
      FOR EACH_ROW IN TB_ICENT_HIST_UPD.FIRST .. TB_ICENT_HIST_UPD.LAST LOOP
      
        IF TB_ICENT_HIST_UPD(EACH_ROW).LIQN = 'N' THEN
        
          IF TB_ICENT_HIST_UPD(EACH_ROW).DRCR IS NULL THEN
            TB_ICENT_HIST_UPD(EACH_ROW).DRCR := ICPKS_CACHE.FN_DRCR_IND(TB_ICENT_HIST_UPD(EACH_ROW).PROD,
                                                                        TB_ICENT_HIST_UPD(EACH_ROW)
                                                                        .FRM_NO);
            DBG('tb_icent_hist_upd(each_row).drcr=' || TB_ICENT_HIST_UPD(EACH_ROW).DRCR);
          END IF;
        
          IF NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0) = 0 AND
             NVL(TB_ICENT_HIST_UPD(EACH_ROW).ACCRUED_AMT, 0) = 0 AND
             NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT_TO_ACCRUE, 0) = 0 AND
             NVL(TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR, 0) = 0 THEN
            PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                            'Z',
                            'Y',
                            ICPKS_PARTITION_INFO.GETPART,
                            P_LIQ_DT,
                            L_UPD_COUNT);
            IF L_UPD_COUNT = 0 THEN
              PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                              'Z',
                              'N',
                              ICPKS_PARTITION_INFO.GETPART,
                              P_LIQ_DT,
                              L_UPD_COUNT);
            END IF;
          ELSE
            PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                            'A',
                            'Y',
                            ICPKS_PARTITION_INFO.GETPART,
                            P_LIQ_DT,
                            L_UPD_COUNT);
            IF L_UPD_COUNT = 0 THEN
              PR_UPD_ACCR_ENT(TB_ICENT_HIST_UPD(EACH_ROW),
                              'A',
                              'N',
                              ICPKS_PARTITION_INFO.GETPART,
                              P_LIQ_DT,
                              L_UPD_COUNT);
            
            ELSIF L_UPD_COUNT = -1 THEN
              TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR := 0;
              TB_ICENT_HIST_UPD(EACH_ROW).LCY_AMT := 0;
              TB_ICENT_HIST_UPD(EACH_ROW).CUR_RUN_ACCR_LCY := 0;
              DBG('24390157 IC_INTRADAY_PERF: Explicitly updating cur_run_accr,lcy_amt,cur_run_accr_lcy to zero, since this condtion will get satisfied only if cur_run_accr is 0');
              ICPKSS_TEST.PR_UPD_ACCR_ENT(ICPKSS_TEST.TB_ICENT_HIST_UPD(EACH_ROW),
                                          'Z',
                                          'N',
                                          ICPKS_PARTITION_INFO.GETPART,
                                          P_LIQ_DT,
                                          L_UPD_COUNT);
            
            END IF;
          END IF;
        ELSE
        
          UPDATE ICTBS_ENTRIES_HISTORY
             SET AMT = NVL(TB_ICENT_HIST_UPD(EACH_ROW).AMT, 0)
           WHERE BRN = TB_ICENT_HIST_UPD(EACH_ROW).BRN
             AND ACC = TB_ICENT_HIST_UPD(EACH_ROW).ACC
             AND PROD = TB_ICENT_HIST_UPD(EACH_ROW).PROD
             AND FRM_NO = TB_ICENT_HIST_UPD(EACH_ROW).FRM_NO
             AND ENT_DT = NVL(TB_ICENT_HIST_UPD(EACH_ROW).ENT_DT, P_LIQ_DT);
        END IF;
      END LOOP;
    END IF;
    DBG('Updation is through');
    TB_ICENT_HIST_UPD.DELETE;
    IF NVL(TB_ICENT_HIST_ADJ.COUNT, 0) <> 0 THEN
      BUG1 := TB_ICENT_HIST_ADJ.FIRST;
      WHILE BUG1 <= TB_ICENT_HIST_ADJ.LAST LOOP
        DBG('adjustments are being done' || TB_ICENT_HIST_ADJ(BUG1).ACC || '~' || TB_ICENT_HIST_ADJ(BUG1).AMT);
        DBG('lcy amount is ' || TB_ICENT_HIST_ADJ(BUG1).LCY_AMT);
        UPDATE ICTBS_ENTRIES_HISTORY E
           SET E.AMT     = E.AMT + TB_ICENT_HIST_ADJ(BUG1).AMT,
               E.LCY_AMT = E.LCY_AMT + TB_ICENT_HIST_ADJ(BUG1).LCY_AMT
         WHERE E.BRN = TB_ICENT_HIST_ADJ(BUG1).BRN
           AND E.ACC = TB_ICENT_HIST_ADJ(BUG1).ACC
           AND E.PROD = TB_ICENT_HIST_ADJ(BUG1).PROD
           AND E.FRM_NO = TB_ICENT_HIST_ADJ(BUG1).FRM_NO
           AND E.ENT_DT = TB_ICENT_HIST_ADJ(BUG1).ENT_DT;
        BUG1 := TB_ICENT_HIST_ADJ.NEXT(BUG1);
      END LOOP;
    END IF;
  
    FORALL UPD IN INDICES OF TB_ROWID
      UPDATE ICTBS_ACC_PR
         SET NEXT_ACCR_DT       = LEAST(TB_NEXT_ACCR_DT(UPD),
                                        TB_NEXT_LIQ_DT(UPD)),
             NEXT_LIQ_DT        = TB_NEXT_LIQ_DT(UPD),
             NEXT_EVENT_DT      = TB_NEXT_EVENT_DT(UPD),
             NEXT_CALC_DT       = TB_NEXT_CALC_DT(UPD),
             NEXT_SCHD_ACCR_DT  = TB_NEXT_SCHD_ACCR_DT(UPD),
             NEXT_SCHD_LIQ_DT   = TB_NEXT_SCHD_LIQ_DT(UPD),
             HAS_PROBLEMS       = TB_HAS_PROBLEMS(UPD),
             LAST_SCHD_LIQ_DT   = TB_LAST_SCHD_LIQ_DT(UPD),
             LAST_ACCR_DT       = TB_LAST_ACCR_DT(UPD),
             LAST_LIQ_DT        = TB_LAST_LIQ_DT(UPD),
             LAST_CALC_DT       = TB_LAST_CALC_DT(UPD),
             FIRST_CALC_DT      = TB_FIRST_CALC_DT(UPD),
             BKVAL_RECALC_FLAG  = TB_BKVAL_RECALC_FLAG(UPD),
             BKVAL_MINCALC_DATE = TB_BKVAL_MINCALC_DATE(UPD)
       WHERE ROWID = TB_ROWID(UPD);
    IF NVL(TB_RACCR_ACC.COUNT, 0) <> 0 THEN
      FORALL J IN TB_RACCR_ACC.FIRST .. TB_RACCR_ACC.LAST
        DELETE FROM ICTBS_ADJ_INTEREST
         WHERE BRN = TB_RACCR_BRN(J)
           AND ACC = TB_RACCR_ACC(J)
           AND PROD = TB_RACCR_PROD(J)
           AND FRM_NO = TB_RACCR_FRM_NO(J);
    END IF;
    IF NVL(TB_ICENT_UPD_ACC.COUNT, 0) <> 0 THEN
      DBG('Just going to update entries' || TB_ICENT_UPD_ACC.COUNT);
      FORALL I IN TB_ICENT_UPD_ACC.FIRST .. TB_ICENT_UPD_ACC.LAST
        UPDATE ICTBS_ENTRIES
           SET AMT                = NVL(TB_ICENT_UPD_AMT(I), 0),
               ACCRUED_AMT        = NVL(TB_ICENT_UPD_ACCRUED_AMT(I), 0),
               AMT_TO_ACCRUE      = NVL(TB_ICENT_UPD_AMT_TO_ACCRUE(I), 0),
               CUR_RUN_ACCR       = NVL(TB_ICENT_UPD_CUR_RUN_ACCR(I), 0),
               ENT_DT             = TB_ICENT_UPD_ENT_DT(I),
               DRCR               = TB_ICENT_UPD_DRCR(I),
               DAILY_AMT          = NVL(TB_ICENT_UPD_DAILY_AMT(I), 0),
               NEXT_CALC_DUE_DATE = TB_ICENT_UPD_NEXT_CALC_DUE_DT(I),
               ACQUIRED_AMT       = NVL(TB_ICENT_UPD_ACQUIRED_AMT(I), 0),
               ACQUIRED_ADJ       = NVL(TB_ICENT_UPD_ACQUIRED_ADJ(I), 0)
         WHERE ROWID = TB_ICENT_UPD_ROWID(I);
    END IF;
  END PR_UPD_TBL;
  PROCEDURE PR_PENDING_ACCR_BOD(P_BRN    VARCHAR2,
                                P_ACC    VARCHAR2,
                                P_PROD   VARCHAR2,
                                P_LIQ_DT DATE) IS
    CURSOR CUR_ACCPR IS
      SELECT BRN,
             ACC,
             PROD,
             SC_MAP_DT,
             GC_MAP_DT,
             LAST_CALC_DT,
             LAST_LIQ_DT,
             NEXT_LIQ_DT,
             LAST_ACCR_DT,
             NEXT_ACCR_DT,
             LAST_SCHD_LIQ_DT,
             INC_MTH,
             NEXT_SCHD_LIQ_DT,
             FIRST_CALC_DT,
             NEXT_SCHD_ACCR_DT,
             PROD_TYPE,
             HAS_ACCR,
             NEXT_CALC_DT,
             PROD_ACCR,
             DEFER_LIQ_DT,
             HAS_PROBLEMS,
             BKVAL_MINCALC_DATE,
             BKVAL_RECALC_FLAG,
             FIRST_FIRST_CALC_DATE,
             IMAT_PROBLEMS,
             DEPOSIT,
             ACLASS,
             CCY,
             NEXT_EVENT_DT,
             RECALC_ACCR_ON_LIQN,
             ROWID
        FROM ICTBS_ACC_PR P
       WHERE P.BRN = P_BRN
         AND P.PROD = P_PROD
         AND P.ACC = P_ACC
         AND P.PROD_TYPE IN ('I', 'P')
         AND NVL(HAS_PROBLEMS, 'N') <> 'Y'
       ORDER BY P.NEXT_LIQ_DT;
  
    J             NUMBER := 0;
    L_ENTRY_COUNT NUMBER := 0;
  
    LAST_REC NUMBER := 0;
  
    L_BRN_BK  ICTBS_ACC_PR.BRN%TYPE;
    L_ACC_BK  ICTBS_ACC_PR.ACC%TYPE;
    L_PROD_BK ICTBS_ACC_PR.PROD%TYPE;
  
  BEGIN
    ICPKS_TEST.LCY   := GLOBAL.LCY;
    ICPKS_TEST.UID   := NVL(GLOBAL.USER_ID, 'SYSTEM');
    ICPKS_TEST.APPDT := GLOBAL.APPLICATION_DATE;
  
    ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_BRN, P_ACC);
  
    ICPKS_TEST.DYN_NWD := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                       GLOBAL.CURRENT_BRANCH,
                                                       P_LIQ_DT,
                                                       'N',
                                                       1);
    ICPKS_TEST.NWD := ICPKS_TEST.DYN_NWD;
    ICPKS_TEST.PKG_LIQ_NETTING := 'N';
    ICPKS_TEST.TB_BASIC_HOFF(1).EVENT := 'IACR';
    ICPKS_TEST.TB_BASIC_HOFF(1).MODULE := 'IC';
    ICPKS_TEST.TB_BASIC_HOFF(1).EVENT_SR_NO := 1;
    ICPKS_TEST.TB_BASIC_HOFF(1).TRN_DT := APPDT;
    ICPKS_TEST.TB_BASIC_HOFF(1).AC_BRANCH := P_BRN;
    ICPKS_TEST.TB_BASIC_HOFF(1).USER_ID := UID;
    ICPKS_TEST.TB_BASIC_HOFF(1).BATCH_NO := 0;
    ICPKS_TEST.TB_BASIC_HOFF(1).CURR_NO := 0;
    ICPKS_TEST.TB_BASIC_HOFF(1).AVLDAYS := 0;
    ICPKS_TEST.TB_BASIC_HOFF(1).TXN_INIT_DATE := APPDT;
  
    IF ICPKS_TEST.TB_BRN.EXISTS(1) THEN
      L_BRN_BK  := ICPKS_TEST.TB_BRN(1);
      L_ACC_BK  := ICPKS_TEST.TB_ACC(1);
      L_PROD_BK := ICPKS_TEST.TB_PROD(1);
    END IF;
  
    OPEN CUR_ACCPR;
    FETCH CUR_ACCPR
      INTO ICPKS_TEST.TB_BRN(1),
           ICPKS_TEST.TB_ACC(1),
           ICPKS_TEST.TB_PROD(1),
           ICPKS_TEST.TB_SC_MAP_DT(1),
           ICPKS_TEST.TB_GC_MAP_DT(1),
           ICPKS_TEST.TB_LAST_CALC_DT(1),
           ICPKS_TEST.TB_LAST_LIQ_DT(1),
           ICPKS_TEST.TB_NEXT_LIQ_DT(1),
           ICPKS_TEST.TB_LAST_ACCR_DT(1),
           ICPKS_TEST.TB_NEXT_ACCR_DT(1),
           ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(1),
           ICPKS_TEST.TB_INC_MTH(1),
           ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(1),
           ICPKS_TEST.TB_FIRST_CALC_DT(1),
           ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(1),
           ICPKS_TEST.TB_PROD_TYPE(1),
           ICPKS_TEST.TB_HAS_ACCR(1),
           ICPKS_TEST.TB_NEXT_CALC_DT(1),
           ICPKS_TEST.TB_PROD_ACCR(1),
           ICPKS_TEST.TB_DEFER_LIQ_DT(1),
           ICPKS_TEST.TB_HAS_PROBLEMS(1),
           ICPKS_TEST.TB_BKVAL_MINCALC_DATE(1),
           ICPKS_TEST.TB_BKVAL_RECALC_FLAG(1),
           ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE(1),
           ICPKS_TEST.TB_IMAT_PROBLEMS(1),
           ICPKS_TEST.TB_DEPOSIT(1),
           ICPKS_TEST.TB_ACLASS(1),
           ICPKS_TEST.TB_CCY(1),
           ICPKS_TEST.TB_NEXT_EVENT_DT(1),
           ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN(1),
           ICPKS_TEST.TB_ROWID(1);
    CLOSE CUR_ACCPR;
  
    IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_BRN, P_ACC, G_STTM_CUSTACC) THEN
      DBG('Could not get account');
      RETURN;
    END IF;
  
    SELECT *
      INTO ICPKS_TEST.G_ICTM_ACC
      FROM ICTMS_ACC
     WHERE BRN = P_BRN
       AND ACC = P_ACC;
    DBG('select cust acc details');
  
    ICPKS_TEST.G_ACC_TYPE := G_STTM_CUSTACC.ACCOUNT_TYPE;
  
    SELECT DEFAULT_MEDIA, CUSTOMER_NAME1, INDIVIDUAL_TAX_CERT_REQD
      INTO ICPKS_TEST.G_DEFAULT_MEDIA, G_CUSTOMER_NAME1, G_CUST_IND_TC_REQD
      FROM STTMS_CUSTOMER
     WHERE CUSTOMER_NO = ICPKS_TEST.G_STTM_CUSTACC.CUST_NO;
    ICPKS_TEST.PR_CACHE_PROD(ICPKS_TEST.TB_PROD(1),
                             ICPKS_TEST.G_STTM_CUSTACC.ACC_STATUS);
    FOR CUR_ICENT IN (SELECT E.*, E.ROWID ROW_ID
                        FROM ICTBS_ENTRIES E
                       WHERE E.BRN = ICPKS_TEST.TB_BRN(1)
                         AND E.ACC = ICPKS_TEST.TB_ACC(1)
                         AND E.PROD = ICPKS_TEST.TB_PROD(1)) LOOP
      J := J + 1;
      ICPKS_TEST.TB_ICENT(J).ACC := CUR_ICENT.ACC;
      ICPKS_TEST.TB_ICENT(J).BRN := CUR_ICENT.BRN;
      ICPKS_TEST.TB_ICENT(J).PROD := CUR_ICENT.PROD;
      ICPKS_TEST.TB_ICENT(J).FRM_NO := CUR_ICENT.FRM_NO;
      ICPKS_TEST.TB_ICENT(J).AMT := NVL(CUR_ICENT.AMT, 0);
      ICPKS_TEST.TB_ICENT(J).ACCRUED_AMT := NVL(CUR_ICENT.ACCRUED_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).AMT_TO_ACCRUE := NVL(CUR_ICENT.AMT_TO_ACCRUE,
                                                  0);
      ICPKS_TEST.TB_ICENT(J).CUR_RUN_ACCR := NVL(CUR_ICENT.CUR_RUN_ACCR, 0);
      ICPKS_TEST.TB_ICENT(J).ENT_DT := CUR_ICENT.ENT_DT;
      ICPKS_TEST.TB_ICENT(J).DRCR := CUR_ICENT.DRCR;
      ICPKS_TEST.TB_ICENT(J).HAS_ACCR := CUR_ICENT.HAS_ACCR;
      ICPKS_TEST.TB_ICENT(J).DAILY_AMT := NVL(CUR_ICENT.DAILY_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).NEXT_CALC_DUE_DATE := CUR_ICENT.NEXT_CALC_DUE_DATE;
      ICPKS_TEST.TB_ICENT(J).ACQUIRED_AMT := NVL(CUR_ICENT.ACQUIRED_AMT, 0);
      ICPKS_TEST.TB_ICENT(J).ACQUIRED_ADJ := NVL(CUR_ICENT.ACQUIRED_ADJ, 0);
      ICPKS_TEST.TB_ICENT(J).ROW_ID := CUR_ICENT.ROW_ID;
    
    END LOOP;
    ICPKSS_CALC.G_ICTB_ACC_PR.BRN                 := ICPKS_TEST.TB_BRN(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.ACC                 := ICPKS_TEST.TB_ACC(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD                := ICPKS_TEST.TB_PROD(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT           := ICPKS_TEST.TB_SC_MAP_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT           := ICPKS_TEST.TB_GC_MAP_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT        := ICPKS_TEST.TB_LAST_CALC_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT         := ICPKS_TEST.TB_LAST_LIQ_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT         := ICPKS_TEST.TB_NEXT_LIQ_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT        := ICPKS_TEST.TB_LAST_ACCR_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT        := ICPKS_TEST.TB_NEXT_ACCR_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT    := ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH             := ICPKS_TEST.TB_INC_MTH(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT    := ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT       := ICPKS_TEST.TB_FIRST_CALC_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT   := ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE           := ICPKS_TEST.TB_PROD_TYPE(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR            := ICPKS_TEST.TB_HAS_ACCR(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT        := ICPKS_TEST.TB_NEXT_CALC_DT(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR           := ICPKS_TEST.TB_PROD_ACCR(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT        := ICPKS_TEST.TB_DEFER_LIQ_DT(1);
    ICPKSS_CALC.G_CUST_ACC.CCY                    := ICPKS_TEST.TB_CCY(1);
    ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS          := ICPKS_TEST.TB_ACLASS(1);
    ICPKSS_CALC.G_ICTB_ACC_PR.RECALC_ACCR_ON_LIQN := ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN(1);
    ICPKS_UDE.PR_PREPARE_GC(ICPKS_TEST.TB_BRN(1),
                            ICPKS_TEST.TB_ACLASS(1),
                            ICPKS_TEST.TB_CCY(1),
                            ICPKS_TEST.TB_PROD(1),
                            ICPKS_TEST.TB_FIRST_CALC_DT(1),
                            P_LIQ_DT,
                            ICPKS_TEST.TB_NEXT_LIQ_DT(1));
    IF ICPKS_TEST.G_ICTM_ACC.ACC_TYPE = 'N' THEN
      ICPKS_SDE.PR_PREPARE_SDE(ICPKS_TEST.TB_BRN(1),
                               ICPKS_TEST.TB_ACC(1),
                               ICPKS_TEST.TB_CCY(1),
                               1,
                               1);
    ELSE
      ICPKS_SDE.PR_PREPARE_SDE_CONSOL(ICPKS_TEST.TB_BRN(1),
                                      ICPKS_TEST.TB_ACC(1),
                                      ICPKS_TEST.TB_CCY(1),
                                      1,
                                      1);
    END IF;
    ICPKS_TEST.PR_CALC(ICPKS_TEST.TB_BRN(1),
                       ICPKS_TEST.TB_ACC(1),
                       ICPKS_TEST.TB_PROD(1),
                       P_LIQ_DT,
                       ICPKS_TEST.TB_ICENT);
    ICPKS_TEST.TB_NEXT_CALC_DT(1) := ICPKS_TEST.TB_NEXT_LIQ_DT(1) + 1;
    IF ICPKSS_EOD.G_IC_ACCR_ON_HOLIDAYS = 'N' THEN
      ICPKS_TEST.TB_LAST_CALC_DT(1) := APPDT;
    ELSE
      ICPKS_TEST.TB_LAST_CALC_DT(1) := P_LIQ_DT;
    END IF;
    L_ENTRY_COUNT := ICPKS_TEST.TB_ICENT.COUNT;
    IF L_ENTRY_COUNT <> 0 THEN
      IF ICPKS_TEST.TB_NEXT_ACCR_DT(1) <= P_LIQ_DT AND
         ICPKS_TEST.TB_HAS_ACCR(1) = 'Y' THEN
        DBG('PR_ACCRUE BEING CALLED');
        ICPKS_TEST.TB_BASIC_HOFF(1).EVENT := 'IACR';
        ICPKS_TEST.TB_BASIC_HOFF(1).TRN_DT := APPDT;
      
        IF ICPKS_TEST.TB_NEXT_ACCR_DT(1) <= APPDT THEN
          ICPKS_TEST.TB_BASIC_HOFF(1).VALUE_DT := ICPKS_TEST.TB_NEXT_ACCR_DT(1);
        ELSE
          IF G_STTM_CUSTACC.MUDARABAH_ACCOUNTS = 'Y' THEN
            SELECT MAX(PC_START_DATE)
              INTO ICPKS_TEST.TB_BASIC_HOFF(1).VALUE_DT
              FROM STTM_PERIOD_CODES
             WHERE PC_START_DATE <= APPDT;
          ELSE
            ICPKS_TEST.TB_BASIC_HOFF(1).VALUE_DT := APPDT;
          END IF;
        END IF;
      
        ICPKS_TEST.TB_PROD_ACCR(1) := 'N';
        ICPKS_TEST.PR_ACCRUE(P_LIQ_DT, 1, ICPKS_TEST.TB_ICENT);
      END IF;
    END IF;
    DBG('tb_icent_upd variables moved down now');
    DBG('icpks icent count here is :' || ICPKS_TEST.TB_ICENT.COUNT);
  
    LAST_REC := NVL(ICPKS_TEST.TB_ICENT_UPD_ACC.LAST, 0);
    DBG('inserting for entries update icpkstest' || '~' || LAST_REC);
    IF ICPKS_TEST.TB_ICENT.COUNT <> 0 THEN
      FOR J IN ICPKS_TEST.TB_ICENT.FIRST .. ICPKS_TEST.TB_ICENT.LAST LOOP
        DBG('inside loop the rec count is :' || LAST_REC);
        TB_ICENT_UPD_ACC(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J).ACC;
        TB_ICENT_UPD_AMT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J).AMT;
        TB_ICENT_UPD_ACCRUED_AMT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                  .ACCRUED_AMT;
        TB_ICENT_UPD_AMT_TO_ACCRUE(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                    .AMT_TO_ACCRUE;
        TB_ICENT_UPD_CUR_RUN_ACCR(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                   .CUR_RUN_ACCR;
        TB_ICENT_UPD_ENT_DT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J).ENT_DT;
        TB_ICENT_UPD_DRCR(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J).DRCR;
        TB_ICENT_UPD_DAILY_AMT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                .DAILY_AMT;
        TB_ICENT_UPD_NEXT_CALC_DUE_DT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                       .NEXT_CALC_DUE_DATE;
        TB_ICENT_UPD_ACQUIRED_ADJ(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                   .ACQUIRED_ADJ;
        TB_ICENT_UPD_ACQUIRED_AMT(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J)
                                                   .ACQUIRED_AMT;
        TB_ICENT_UPD_ROWID(LAST_REC + J) := ICPKS_TEST.TB_ICENT(J).ROW_ID;
      END LOOP;
    END IF;
    PR_UPD_TBL(P_LIQ_DT);
    PR_PURGE_PLSQL_TABS;
  
    IF L_BRN_BK IS NOT NULL THEN
      BEGIN
        SELECT BRN,
               ACC,
               PROD,
               SC_MAP_DT,
               GC_MAP_DT,
               LAST_CALC_DT,
               LAST_LIQ_DT,
               NEXT_LIQ_DT,
               LAST_ACCR_DT,
               NEXT_ACCR_DT,
               LAST_SCHD_LIQ_DT,
               INC_MTH,
               NEXT_SCHD_LIQ_DT,
               FIRST_CALC_DT,
               NEXT_SCHD_ACCR_DT,
               PROD_TYPE,
               HAS_ACCR,
               NEXT_CALC_DT,
               PROD_ACCR,
               DEFER_LIQ_DT,
               HAS_PROBLEMS,
               BKVAL_MINCALC_DATE,
               BKVAL_RECALC_FLAG,
               FIRST_FIRST_CALC_DATE,
               IMAT_PROBLEMS,
               DEPOSIT,
               ACLASS,
               CCY,
               NEXT_EVENT_DT,
               RECALC_ACCR_ON_LIQN,
               ROWID
          INTO ICPKS_TEST.TB_BRN(1),
               ICPKS_TEST.TB_ACC(1),
               ICPKS_TEST.TB_PROD(1),
               ICPKS_TEST.TB_SC_MAP_DT(1),
               ICPKS_TEST.TB_GC_MAP_DT(1),
               ICPKS_TEST.TB_LAST_CALC_DT(1),
               ICPKS_TEST.TB_LAST_LIQ_DT(1),
               ICPKS_TEST.TB_NEXT_LIQ_DT(1),
               ICPKS_TEST.TB_LAST_ACCR_DT(1),
               ICPKS_TEST.TB_NEXT_ACCR_DT(1),
               ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(1),
               ICPKS_TEST.TB_INC_MTH(1),
               ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(1),
               ICPKS_TEST.TB_FIRST_CALC_DT(1),
               ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(1),
               ICPKS_TEST.TB_PROD_TYPE(1),
               ICPKS_TEST.TB_HAS_ACCR(1),
               ICPKS_TEST.TB_NEXT_CALC_DT(1),
               ICPKS_TEST.TB_PROD_ACCR(1),
               ICPKS_TEST.TB_DEFER_LIQ_DT(1),
               ICPKS_TEST.TB_HAS_PROBLEMS(1),
               ICPKS_TEST.TB_BKVAL_MINCALC_DATE(1),
               ICPKS_TEST.TB_BKVAL_RECALC_FLAG(1),
               ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE(1),
               ICPKS_TEST.TB_IMAT_PROBLEMS(1),
               ICPKS_TEST.TB_DEPOSIT(1),
               ICPKS_TEST.TB_ACLASS(1),
               ICPKS_TEST.TB_CCY(1),
               ICPKS_TEST.TB_NEXT_EVENT_DT(1),
               ICPKS_TEST.TB_RECALC_ACCR_ON_LIQN(1),
               ICPKS_TEST.TB_ROWID(1)
          FROM ICTBS_ACC_PR P
         WHERE P.BRN = L_BRN_BK
           AND P.ACC = L_ACC_BK
           AND P.PROD = L_PROD_BK;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('This might be Close on maturity case,  ictbs_acc_pr entry would be deleted already');
      END;
    
    END IF;
  
  END PR_PENDING_ACCR_BOD;

  PROCEDURE PR_ICALC(P_BRN   VARCHAR2,
                     P_ACC   VARCHAR2,
                     P_PROD  VARCHAR2,
                     FROM_DT DATE,
                     TO_DT   DATE) IS
    R_ID      ICTMS_RULE.RULE_ID%TYPE;
    C         INTEGER := DBMS_SQL.OPEN_CURSOR;
    SSQL      VARCHAR2(255);
    I         INTEGER;
    CNT       INTEGER := 0;
    L_UDE_CCY ICTMS_PR_INT.UDE_CCY%TYPE;
    CURSOR CR_ICTB(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
      SELECT *
        FROM ICTBS_ACC_PR
       WHERE ACC = P_ACC
         AND BRN = P_BRN
         AND PROD = P_PROD;
    REC_ICTBACC_PR ICTBS_ACC_PR%ROWTYPE;
    L_FROM_DT      DATE;
    L_TO_DT        DATE;
  
    L_PRODUCT_DEFN ICTMS_PRODUCT_DEFINITION%ROWTYPE;
  
    FUNCTION Q(S VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
      RETURN CSPKES_MISC.FN_GETCHR(39) || S || CSPKES_MISC.FN_GETCHR(39);
    END Q;
  BEGIN
    BEGIN
    
      SELECT I.RULE, I.UDE_CCY
        INTO R_ID, L_UDE_CCY
        FROM ICTMS_PR_INT I
       WHERE I.PRODUCT_CODE = P_PROD;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20101, 'NO SUCH PRODUCT ' || P_PROD);
    END;
    DBG('GOT RULE ' || R_ID);
    DBG('You are inside icpks test ');
    DELETE FROM ICTBS_IIS_VAL I
     WHERE I.BRN = P_BRN
       AND I.ACC = P_ACC
       AND I.RULE_ID = R_ID
       AND I.PROD = P_PROD;
  
    DBG('DELETED OLD I-ISVALS');
    DBG('p brn is :' || P_BRN || '~' || P_ACC);
  
    ICPKSS_CALC.SET_ACC_DETAILS(P_BRN, P_ACC);
  
    CNT := 0;
    FOR X IN CR_ICTB(P_BRN, P_ACC, P_PROD) LOOP
      DBG('Inside loop for ictb acc pr ssss');
      CNT                                         := CNT + 1;
      ICPKSS_CALC.G_ICTB_ACC_PR.BRN               := X.BRN;
      ICPKSS_CALC.G_ICTB_ACC_PR.ACC               := X.ACC;
      ICPKSS_CALC.G_ICTB_ACC_PR.PROD              := X.PROD;
      ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT         := X.SC_MAP_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT         := X.GC_MAP_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.LAST_CALC_DT      := X.LAST_CALC_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.LAST_LIQ_DT       := X.LAST_LIQ_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT       := X.NEXT_LIQ_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.LAST_ACCR_DT      := X.LAST_ACCR_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT      := X.NEXT_ACCR_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT  := X.LAST_SCHD_LIQ_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.INC_MTH           := X.INC_MTH;
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_LIQ_DT  := X.NEXT_SCHD_LIQ_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT     := X.FIRST_CALC_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_SCHD_ACCR_DT := X.NEXT_SCHD_ACCR_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.PROD_TYPE         := X.PROD_TYPE;
      ICPKSS_CALC.G_ICTB_ACC_PR.HAS_ACCR          := X.HAS_ACCR;
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_CALC_DT      := X.NEXT_CALC_DT;
      ICPKSS_CALC.G_ICTB_ACC_PR.PROD_ACCR         := X.PROD_ACCR;
      ICPKSS_CALC.G_ICTB_ACC_PR.DEFER_LIQ_DT      := X.DEFER_LIQ_DT;
      ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS        := X.ACLASS;
      ICPKSS_CALC.G_CUST_ACC.CCY                  := X.CCY;
    
      ICPKS_TEST.TB_BRN(CNT) := X.BRN;
      ICPKS_TEST.TB_ACC(CNT) := X.ACC;
      ICPKS_TEST.TB_PROD(CNT) := X.PROD;
      ICPKS_TEST.TB_SC_MAP_DT(CNT) := X.SC_MAP_DT;
      ICPKS_TEST.TB_GC_MAP_DT(CNT) := X.GC_MAP_DT;
      ICPKS_TEST.TB_LAST_CALC_DT(CNT) := X.LAST_CALC_DT;
      ICPKS_TEST.TB_LAST_LIQ_DT(CNT) := X.LAST_LIQ_DT;
      ICPKS_TEST.TB_NEXT_LIQ_DT(CNT) := X.NEXT_LIQ_DT;
      ICPKS_TEST.TB_LAST_ACCR_DT(CNT) := X.LAST_ACCR_DT;
      ICPKS_TEST.TB_NEXT_ACCR_DT(CNT) := X.NEXT_ACCR_DT;
      ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(CNT) := X.LAST_SCHD_LIQ_DT;
      ICPKS_TEST.TB_INC_MTH(CNT) := X.INC_MTH;
      ICPKS_TEST.TB_NEXT_SCHD_LIQ_DT(CNT) := X.NEXT_SCHD_LIQ_DT;
      ICPKS_TEST.TB_FIRST_CALC_DT(CNT) := X.FIRST_CALC_DT;
      ICPKS_TEST.TB_NEXT_SCHD_ACCR_DT(CNT) := X.NEXT_SCHD_ACCR_DT;
      ICPKS_TEST.TB_PROD_TYPE(CNT) := X.PROD_TYPE;
      ICPKS_TEST.TB_HAS_ACCR(CNT) := X.HAS_ACCR;
      ICPKS_TEST.TB_NEXT_CALC_DT(CNT) := X.NEXT_CALC_DT;
      ICPKS_TEST.TB_PROD_ACCR(CNT) := X.PROD_ACCR;
      ICPKS_TEST.TB_HAS_PROBLEMS(CNT) := X.HAS_PROBLEMS;
      ICPKS_TEST.TB_BKVAL_MINCALC_DATE(CNT) := X.BKVAL_MINCALC_DATE;
      ICPKS_TEST.TB_BKVAL_RECALC_FLAG(CNT) := X.BKVAL_RECALC_FLAG;
      ICPKS_TEST.TB_FIRST_FIRST_CALC_DATE(CNT) := X.FIRST_FIRST_CALC_DATE;
      ICPKS_TEST.TB_IMAT_PROBLEMS(CNT) := X.IMAT_PROBLEMS;
      ICPKS_TEST.TB_DEPOSIT(CNT) := X.DEPOSIT;
      ICPKS_TEST.TB_ACLASS(CNT) := X.ACLASS;
      ICPKS_TEST.TB_CCY(CNT) := X.CCY;
      ICPKS_TEST.TB_NEXT_EVENT_DT(CNT) := X.NEXT_EVENT_DT;
    
      DBG('initially icpkss_calc.g_ictb_acc_pr.first_calc_dt =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT);
      DBG('initially icpkss_calc.g_ictb_acc_pr.last_schd_liq_dt =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT);
      ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT := LEAST(ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT,
                                                       FROM_DT);
      ICPKS_TEST.TB_FIRST_CALC_DT(CNT) := LEAST(ICPKS_TEST.TB_FIRST_CALC_DT(CNT),
                                                FROM_DT);
      ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT := LEAST(ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT,
                                                          FROM_DT);
      ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(CNT) := LEAST(ICPKS_TEST.TB_LAST_SCHD_LIQ_DT(CNT),
                                                   FROM_DT);
      DBG('icpkss_calc.g_ictb_acc_pr.first_calc_dt CHANGED TO  =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.FIRST_CALC_DT);
      DBG('icpkss_calc.g_ictb_acc_pr.last_schd_liq_dt changed to =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.LAST_SCHD_LIQ_DT);
    
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT := LEAST(ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT,
                                                     TO_DT);
      ICPKS_TEST.TB_NEXT_LIQ_DT(CNT) := LEAST(ICPKS_TEST.TB_NEXT_LIQ_DT(CNT),
                                              TO_DT);
      ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT := LEAST(ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT,
                                                      TO_DT);
      ICPKS_TEST.TB_NEXT_ACCR_DT(CNT) := LEAST(ICPKS_TEST.TB_NEXT_ACCR_DT(CNT),
                                               TO_DT);
      DBG('  icpkss_calc.g_ictb_acc_pr.next_liq_dt =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_LIQ_DT);
      DBG('  icpks_test.tb_next_liq_dt(cnt) =' ||
          ICPKS_TEST.TB_NEXT_LIQ_DT(CNT));
      DBG('  icpkss_calc.g_ictb_acc_pr.next_accr_dt =' ||
          ICPKSS_CALC.G_ICTB_ACC_PR.NEXT_ACCR_DT);
      DBG(' icpks_test.tb_next_accr_dt(cnt) =' ||
          ICPKS_TEST.TB_NEXT_ACCR_DT(CNT));
    
      ICPKSS_CALC.G_PROD_REC.UDE_CCY := L_UDE_CCY;
      DBG('before end loop');
    END LOOP;
    DBG('check the variables:' || ICPKSS_CALC.G_ICTB_ACC_PR.BRN || '~' ||
        ICPKSS_CALC.G_ICTB_ACC_PR.ACC);
    DBG('acc:' || ICPKSS_CALC.G_ICTB_ACC_PR.PROD || '~' ||
        ICPKSS_CALC.G_CUST_ACC.ACCOUNT_CLASS);
    DBG('xx:' || ICPKSS_CALC.G_ICTB_ACC_PR.SC_MAP_DT || '~' ||
        ICPKSS_CALC.G_ICTB_ACC_PR.GC_MAP_DT);
    DBG('ccy:' || ICPKSS_CALC.G_CUST_ACC.CCY);
    ICPKS_SDE.PR_PREPARE_SDE(ICPKSS_CALC.G_ICTB_ACC_PR.BRN,
                             ICPKSS_CALC.G_ICTB_ACC_PR.ACC,
                             ICPKSS_CALC.G_CUST_ACC.CCY,
                             1,
                             1);
  
    ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(ICPKSS_CALC.G_ICTB_ACC_PR.BRN,
                                        ICPKSS_CALC.G_ICTB_ACC_PR.ACC);
    DBG('You are inside icpks test 2 ');
    DBG('values to icpks ude :' || ICPKS_TEST.TB_ACLASS(1));
    DBG(ICPKS_TEST.TB_CCY(1) || '~' || ICPKS_TEST.TB_PROD(1));
    DBG(ICPKS_TEST.TB_FIRST_CALC_DT(1) || '~' || FROM_DT || '~' ||
        ICPKS_TEST.TB_NEXT_LIQ_DT(1));
    ICPKS_UDE.PR_PREPARE_GC(ICPKS_TEST.TB_BRN(1),
                            ICPKS_TEST.TB_ACLASS(1),
                            ICPKS_TEST.TB_CCY(1),
                            ICPKS_TEST.TB_PROD(1),
                            ICPKS_TEST.TB_FIRST_CALC_DT(1),
                            FROM_DT,
                            ICPKS_TEST.TB_NEXT_LIQ_DT(1));
    DBG('prod code :' || P_PROD);
  
    L_PRODUCT_DEFN := ICPKS_CACHE.FN_GET_PRODUCT_DEFN_FRC(P_PROD);
    DBG('Dep and Prod type :' || L_PRODUCT_DEFN.DEP || '~' ||
        L_PRODUCT_DEFN.PRODUCT_TYPE);
  
    DBG('brn and acc :' || P_BRN || '~' || P_ACC);
  
    IF NVL(ICPKS_FCJ_ICDCALAC.G_INDICATOR, '****') <> 'ICDCALAC' THEN
      DBG('COULD NOT BYPASS ICDCALAC');
    
      IF L_PRODUCT_DEFN.DEP = 'Y' AND
         L_PRODUCT_DEFN.PRODUCT_TYPE IN ('I', 'P')
      
       THEN
        BEGIN
        
          SELECT INT_START_DATE, (MATURITY_DATE - 1)
            INTO L_FROM_DT, L_TO_DT
            FROM ICTM_ACC
           WHERE BRN = P_BRN
             AND ACC = P_ACC;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error selecting from dt and to dt from ictm_acc ');
            RAISE;
        END;
      
        L_FROM_DT := NVL(FROM_DT, L_FROM_DT);
        L_TO_DT   := NVL(TO_DT, L_TO_DT);
      
      ELSE
        L_FROM_DT := FROM_DT;
        L_TO_DT   := TO_DT;
      END IF;
    
    ELSE
      DBG('Bypassed..........Congrats!!! It is passing ICDCALAC ');
      L_FROM_DT := FROM_DT;
      L_TO_DT   := TO_DT;
    END IF;
  
    DBG('L from dt and L to dt :' || L_FROM_DT || '~' || L_TO_DT);
  
    PR_CACHE_PROD(P_PROD, NULL);
  
    DBG('#24368360 r_id :' || R_ID);
    IF R_ID IS NOT NULL THEN
      DBG('#24382870 inside if');
      SSQL := 'BEGIN ' ||
              DBMS_ASSERT.SIMPLE_SQL_NAME('C3GF#_IIPR1_' || R_ID) ||
              '(:p_brn,:p_acc,:p_prod,TO_DATE(:l_from_dt,' || Q('YYYYMMDD') ||
              '),TO_DATE(:l_to_dt,' || Q('YYYYMMDD') ||
              '),icpks_test.tb_icent); END;';
    
      DBG('#24382870  final About To Parse ' || SSQL);
    
      DBG('About To Parse ' || SSQL);
      DBMS_SQL.PARSE(C, SSQL, DBMS_SQL.NATIVE);
    
      DBMS_SQL.BIND_VARIABLE(C, 'p_brn', P_BRN);
      DBMS_SQL.BIND_VARIABLE(C, 'p_acc', P_ACC);
      DBMS_SQL.BIND_VARIABLE(C, 'p_prod', P_PROD);
      DBMS_SQL.BIND_VARIABLE(C,
                             'l_from_dt',
                             TO_CHAR(L_FROM_DT, 'YYYYMMDD'));
      DBMS_SQL.BIND_VARIABLE(C, 'l_to_dt', TO_CHAR(L_TO_DT, 'YYYYMMDD'));
    
      DBG('About To Execute ' || SSQL);
      I := DBMS_SQL.EXECUTE(C);
      DBMS_SQL.CLOSE_CURSOR(C);
    END IF;
  
    IF DBMS_SQL.IS_OPEN(C) THEN
      DBMS_SQL.CLOSE_CURSOR(C);
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLERRM);
      BEGIN
        IF DBMS_SQL.IS_OPEN(C) THEN
          DBMS_SQL.CLOSE_CURSOR(C);
        END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          RAISE;
      END;
    
      RAISE;
  END PR_ICALC;

  PROCEDURE PR_LIQ_DEFR(P_BRN VARCHAR2, P_DT DATE) IS
    L_ICENTHIST_FRM  ICTBS_ENTRIES_HISTORY.FRM_NO%TYPE;
    L_ICENTHIST_AMT  ICTBS_ENTRIES_HISTORY.AMT%TYPE;
    L_ICENTHIST_DRCR ICTBS_ENTRIES_HISTORY.DRCR%TYPE;
    L_ICENT_FRM      ICTBS_ENTRIES.FRM_NO%TYPE;
    L_ICENT_AMT      ICTBS_ENTRIES.AMT%TYPE;
    L_ICENT_DRCR     ICTBS_ENTRIES.DRCR%TYPE;
    L_NET_AMT        NUMBER := 0;
    L_CUR            NUMBER := 0;
    L_CCY            STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_LCY            STTMS_BRANCH.BRANCH_LCY%TYPE;
    ERR_CODE         ERTBS_MSGS.ERR_CODE%TYPE;
    L_ACC            ICTBS_ENTRIES_HISTORY.ACC%TYPE;
    L_PROD           ICTBS_ENTRIES_HISTORY.PROD%TYPE;
    L_REC            NUMBER;
    L_RES            VARCHAR2(50);
    ERRMSG           VARCHAR2(2000);
    EPRM             VARCHAR2(2000);
    L_PREVREC        INTEGER := 0;
    ACNTG_FAILED EXCEPTION;
    TBFRM              TBFRMTYP;
    TB_ICENT_UPD_ROWID T29;
    TB_ICENT_ROWID     T29;
  
    TB_ICENT_UPD_ROWID_BAK T29;
    TB_ICENT_ROWID_BAK     T29;
    L_ICENT_CUR_BAK        NUMBER;
    L_ICENTHIST_CUR_BAK    NUMBER;
  
    R_PRINT         ICPKSS_TEST.REC_PRINT;
    L_ICENT_CUR     NUMBER := 0;
    L_ICENTHIST_CUR NUMBER := 0;
    L_TMP_LIQ_DT    DATE;
    CUR_ROW         NUMBER;
  
    POS1 NUMBER;
    Y    VARCHAR2(10);
  
    FRMLISTLIQ_DEFR VARCHAR2(32000);
    L_ACLASS        ICTBS_ACC_PR.ACLASS%TYPE;
    L_PREV_ROW      NUMBER;
    L_CUSTACC       STTM_CUST_ACCOUNT%ROWTYPE;
  
    L_MATURITY_DATE DATE;
    L_ADJAMT        ICTBS_ADJ_INTEREST.AMT%TYPE;
    TBHIST          TB_HISTUP;
    L_TAG_AMT_LCY   NUMBER(22, 7);
    L_XRATE         NUMBER;
    L_COUNT         NUMBER;
    L_DEFER_LIQ_CUR NUMBER := 0;
  
    L_BRANCH  ILTBS_SYS_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACCOUNT ILTBS_SYS_ACCOUNT.ACCOUNT%TYPE;
  
    L_LCY_AMT  NUMBER := 0;
    P_ERR_CODE NUMBER := 0;
  
    L_FATCA_RECORD           CHAR(1);
    L_FATCA_EXT_CUSTOMER_SDE NUMBER := NULL;
  
  BEGIN
    DBG('In procedure pr_liq_defr brn --> ' || P_BRN || ' date --> ' || P_DT);
    DEFR_CASE := TRUE;
    PR_INIT_VALS(P_BRN);
    DBG('After pr_init_vals for brn : ' || P_BRN);
    TB_BASIC_HOFF(1).MODULE := 'IC';
    TB_BASIC_HOFF(1).EVENT_SR_NO := 1;
    TB_BASIC_HOFF(1).USER_ID := UID;
    TB_BASIC_HOFF(1).TXN_INIT_DATE := APPDT;
    TB_BASIC_HOFF(1).TRN_DT := NVL(APPDT, P_DT);
    DBG('After assigning into tb_basic_hoff');
  
    IF NVL(TB_ROWID.COUNT, 0) <> 0 THEN
    
      CUR_ROW := TB_ROWID.FIRST;
    
      WHILE CUR_ROW <= TB_ROWID.LAST LOOP
      
        BEGIN
          SAVEPOINT SP_DFR_LIQD1;
        
          DBG(CUR_ROW || '~' || TB_BRN(CUR_ROW) || '~' || TB_ACC(CUR_ROW) || '~' ||
              TB_PROD(CUR_ROW) || '~' || TB_DEFER_LIQ_DT(CUR_ROW) || '~' ||
              G_ONLIQ_FLAG || '~' || TB_LAST_LIQ_DT(CUR_ROW) || '~' ||
              TB_NEXT_SCHD_LIQ_DT(CUR_ROW) || '~' ||
              TB_LAST_ACCR_DT(CUR_ROW));
        
          IF TB_DEFER_LIQ_DT(CUR_ROW) <= P_DT AND
             ((TB_DEPOSIT(CUR_ROW) = 'Y' AND
              TB_DEFER_LIQ_DT(CUR_ROW) < P_DT AND
              ICPKS_BOD.G_BODSTAT = 'Y') OR TB_DEPOSIT(CUR_ROW) = 'N')
            
             OR
             (G_ONLIQ_FLAG = 'Y' AND (P_DT > TB_LAST_LIQ_DT(CUR_ROW) AND
              P_DT <= TB_DEFER_LIQ_DT(CUR_ROW)) AND
              (TB_DEFER_LIQ_DT(CUR_ROW) <= TB_NEXT_SCHD_LIQ_DT(CUR_ROW))) THEN
            DBG('Processing ictbs_acc_pr for row -->' || CUR_ROW);
          
            IF GLOBAL.BRANCH_STATUS = 'T' THEN
              IF NVL(TB_LAST_ACCR_DT(CUR_ROW), TO_DATE(1, 'J')) <
                 TB_DEFER_LIQ_DT(CUR_ROW) THEN
                DBG('pr_pending_accr_bod for monthrly accrual case STARTS --> ');
              
                DBG('updating next_accr_dt with last_accr_dt');
              
                UPDATE ICTBS_ACC_PR
                   SET NEXT_ACCR_DT = NVL(TB_LAST_ACCR_DT(CUR_ROW),
                                          TB_DEFER_LIQ_DT(CUR_ROW))
                 WHERE BRN = TB_BRN(CUR_ROW)
                   AND ACC = TB_ACC(CUR_ROW)
                   AND PROD = TB_PROD(CUR_ROW)
                   AND NEXT_ACCR_DT IS NOT NULL;
              
                PR_PENDING_ACCR_BOD(TB_BRN(CUR_ROW),
                                    TB_ACC(CUR_ROW),
                                    TB_PROD(CUR_ROW),
                                    TB_DEFER_LIQ_DT(CUR_ROW));
              END IF;
            END IF;
          
            IF NVL(L_ACC, '***') <> NVL(TB_ACC(CUR_ROW), '***') THEN
              IF NVL(TB_HOFF_CONS.COUNT, 0) <> 0 THEN
                DBG('Inside pr liq defr A/c changed so passing A/c Entries' ||
                    APPDT);
                OVPKSS.PR_INITERRTBL;
                IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                           1,
                                           APPDT,
                                           TB_HOFF_CONS,
                                           'B',
                                           'Y',
                                           'N',
                                           UID,
                                           ERRMSG,
                                           EPRM) THEN
                  DBG('In pr defr liq acpkss gave hand ' || ' - ' ||
                      ERRMSG);
                  LOG_PROBLEM(CUR_ROW,
                              'B',
                              SUBSTR('pr_liq_defr ' || ERRMSG || EPRM,
                                     1,
                                     2000));
                
                  TB_HOFF_CONS.DELETE;
                  RAISE ACNTG_FAILED;
                END IF;
              
                DBG('Posted entries sucessfully in pr_liq_defr for :' || P_DT ||
                    ' - ' || L_ACC);
                TB_HOFF_CONS.DELETE;
              ELSE
                DBG('No entries for acc :' || L_ACC);
              END IF;
              PR_TAKE_PLSQL_TAB_BAK;
              TB_ICENT_UPD_ROWID_BAK := TB_ICENT_UPD_ROWID;
              TB_ICENT_ROWID_BAK     := TB_ICENT_ROWID;
              L_ICENT_CUR_BAK        := L_ICENT_CUR;
              L_ICENTHIST_CUR_BAK    := L_ICENTHIST_CUR;
            END IF;
          
            IF NVL(TB_ACLASS(CUR_ROW), '***') <> NVL(L_ACLASS, '###') OR
               NVL(TB_CCY(CUR_ROW), '****') <> NVL(L_CCY, '###') THEN
              IF TB_ICENT_LIQNET.COUNT <> 0 THEN
                DBG('calling pr_liq_netting in liq defr for aclass change');
                G_STTM_CUSTACC.CCY := NVL(L_CCY, TB_CCY(L_PREV_ROW));
                BEGIN
                  PR_LIQ_NETTING(P_BRN, P_DT, L_PREV_ROW, TB_ICENT_LIQNET);
                EXCEPTION
                  WHEN OTHERS THEN
                    TB_ICENT_LIQNET.DELETE;
                    RAISE;
                END;
                TB_ICENT_LIQNET.DELETE;
              END IF;
              IF TB_HOFF_PROD.COUNT <> 0 THEN
                DBG('Going to call acpkss for prod level entries ' ||
                    APPDT);
                OVPKSS.PR_INITERRTBL;
                IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                           1,
                                           APPDT,
                                           TB_HOFF_PROD,
                                           'B',
                                           'Y',
                                           'N',
                                           UID,
                                           ERRMSG,
                                           EPRM) THEN
                  DBG('Failed in passing the entry...log this' || ERRMSG || EPRM);
                
                  LOG_PROBLEM(L_PREVREC,
                              'B',
                              'actng failed in liq defer ' ||
                              SUBSTR(ERRMSG, 1, 1900));
                  TB_HOFF_PROD.DELETE;
                  RAISE ACNTG_FAILED;
                END IF;
                TB_HOFF_PROD.DELETE;
              END IF;
              L_ACLASS := TB_ACLASS(CUR_ROW);
              L_CCY    := TB_CCY(CUR_ROW);
            END IF;
          
            IF NVL(L_PROD, '****') <> NVL(TB_PROD(CUR_ROW), '****') THEN
              DBG('Product change happening l_prod -->' || L_PROD ||
                  ' tb_prod(' || CUR_ROW || ')-->' || TB_PROD(CUR_ROW));
              L_PROD := TB_PROD(CUR_ROW);
              PR_CACHE_PROD(TB_PROD(CUR_ROW), NULL);
            END IF;
            DBG('Pr_liq_defr :: #1 Calling Find_Key for prod: ' ||
                TB_PROD(CUR_ROW));
            FIND_KEY(TB_PROD(CUR_ROW), R_PRINT);
            IF NVL(L_ACC, '***') <> NVL(TB_ACC(CUR_ROW), '***') THEN
              DBG('Account change happening l_acc -->' || L_ACC ||
                  ' tb_acc(' || CUR_ROW || ') -->' || TB_ACC(CUR_ROW));
            
              BEGIN
                SELECT *
                  INTO G_ICTM_ACC
                  FROM ICTMS_ACC
                 WHERE BRN = TB_BRN(CUR_ROW)
                   AND ACC = TB_ACC(CUR_ROW);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('It should be AND ILM account');
              END;
            
              IF TB_SYS_AC_LEVEL.EXISTS(CUR_ROW) THEN
                DBG('tb_sys_ac_level(' || CUR_ROW || ')-->' ||
                    TB_SYS_AC_LEVEL(CUR_ROW));
                IF TB_SYS_AC_LEVEL(CUR_ROW) IS NOT NULL THEN
                
                  SELECT B.*
                    INTO G_ICTM_ACC
                    FROM ILTBS_SYS_ACCOUNT A, ICTMS_ACC B
                   WHERE A.SYSTEM_ACCOUNT_BRANCH = TB_BRN(CUR_ROW)
                     AND A.SYSTEM_ACCOUNT = TB_ACC(CUR_ROW)
                     AND B.BRN = A.BRANCH_CODE
                     AND B.ACC = A.ACCOUNT;
                END IF;
              END IF;
            
              L_BOOK_ACC := G_ICTM_ACC.BOOK_ACC;
              L_BOOK_BRN := G_ICTM_ACC.BOOK_BRN;
              L_BOOK_CCY := G_ICTM_ACC.BOOK_CCY;
            
              IF NOT ICPKS_CACHE.FN_GETCUSTACC(G_ICTM_ACC.BRN,
                                               G_ICTM_ACC.ACC,
                                               L_CUSTACC) THEN
                DBG('Could not get account');
                RETURN;
              END IF;
            
              G_STTM_CUSTACC := L_CUSTACC;
            
              L_CCY := L_CUSTACC.CCY;
            
              L_ACC := TB_ACC(CUR_ROW);
            
            END IF;
            BEGIN
              DBG('Branch-->' || TB_BRN(CUR_ROW) || 'Acc-->' ||
                  TB_ACC(CUR_ROW) || 'Prod-->' || TB_PROD(CUR_ROW) ||
                  'last liq dt-->' || TB_LAST_LIQ_DT(CUR_ROW) ||
                  'defer liq dt-->' || TB_DEFER_LIQ_DT(CUR_ROW));
              L_CUR := 0;
            
              TB_ICENT_HIST_UPD.DELETE;
              TB_ICENT.DELETE;
            
              FOR CUR_ICENT_HIST IN (SELECT E.*, E.ROWID ROW_ID
                                       FROM ICTBS_ENTRIES_HISTORY E
                                      WHERE E.BRN = TB_BRN(CUR_ROW)
                                        AND E.ACC = TB_ACC(CUR_ROW)
                                        AND E.PROD = TB_PROD(CUR_ROW)
                                        AND NVL(E.ENTRY_PASSED, 'Y') = 'N'
                                        AND E.LIQN = 'Y'
                                        AND E.ENT_DT >=
                                            TB_LAST_LIQ_DT(CUR_ROW)
                                        AND E.ENT_DT <=
                                            TB_DEFER_LIQ_DT(CUR_ROW)
                                     
                                      ORDER BY E.BRN,
                                               E.ACC,
                                               E.PROD,
                                               E.ENT_DT,
                                               E.FRM_NO) LOOP
                L_CUR := L_CUR + 1;
              
                IF ICPKS_BOD.G_BODSTAT = 'Y' AND L_CUR > 1 THEN
                
                  IF TB_ICENT_HIST_UPD(L_CUR - 1)
                   .ACC = CUR_ICENT_HIST.ACC AND TB_ICENT_HIST_UPD(L_CUR - 1)
                     .FRM_NO = CUR_ICENT_HIST.FRM_NO THEN
                    EXIT;
                  END IF;
                END IF;
              
                TB_ICENT_HIST_UPD(L_CUR).BRN := CUR_ICENT_HIST.BRN;
                TB_ICENT_HIST_UPD(L_CUR).ACC := CUR_ICENT_HIST.ACC;
                TB_ICENT_HIST_UPD(L_CUR).PROD := CUR_ICENT_HIST.PROD;
                TB_ICENT_HIST_UPD(L_CUR).FRM_NO := CUR_ICENT_HIST.FRM_NO;
                TB_ICENT_HIST_UPD(L_CUR).ENT_DT := CUR_ICENT_HIST.ENT_DT;
                TB_ICENT_HIST_UPD(L_CUR).AMT := CUR_ICENT_HIST.AMT;
                TB_ICENT_HIST_UPD(L_CUR).ACCRUED_AMT := CUR_ICENT_HIST.ACCRUED_AMT;
                TB_ICENT_HIST_UPD(L_CUR).AMT_TO_ACCRUE := CUR_ICENT_HIST.AMT_TO_ACCRUE;
                TB_ICENT_HIST_UPD(L_CUR).CUR_RUN_ACCR := CUR_ICENT_HIST.CUR_RUN_ACCR;
                TB_ICENT_HIST_UPD(L_CUR).RUN_DATE := CUR_ICENT_HIST.RUN_DATE;
                TB_ICENT_HIST_UPD(L_CUR).ACCR := CUR_ICENT_HIST.ACCR;
                TB_ICENT_HIST_UPD(L_CUR).LIQN := CUR_ICENT_HIST.LIQN;
                TB_ICENT_HIST_UPD(L_CUR).ENTRY_TYPE := CUR_ICENT_HIST.ENTRY_TYPE;
                TB_ICENT_HIST_UPD(L_CUR).CCY := CUR_ICENT_HIST.CCY;
                TB_ICENT_HIST_UPD(L_CUR).LCY_AMT := CUR_ICENT_HIST.LCY_AMT;
                TB_ICENT_HIST_UPD(L_CUR).LAST_CUR_RUN_ACCR := CUR_ICENT_HIST.LAST_CUR_RUN_ACCR;
                TB_ICENT_HIST_UPD(L_CUR).CUR_RUN_ACCR_LCY := CUR_ICENT_HIST.CUR_RUN_ACCR_LCY;
                TB_ICENT_HIST_UPD(L_CUR).DRCR := CUR_ICENT_HIST.DRCR;
                TB_ICENT_HIST_UPD(L_CUR).ENTRY_PASSED := CUR_ICENT_HIST.ENTRY_PASSED;
                DBG('tb_icent_hist_upd(' || L_CUR || ').amt --> ' || TB_ICENT_HIST_UPD(L_CUR).AMT);
                DBG('tb_icent_hist_upd(' || L_CUR ||
                    ').amt_to_accrue --> ' || TB_ICENT_HIST_UPD(L_CUR)
                    .AMT_TO_ACCRUE);
                DBG('tb_icent_hist_upd(' || L_CUR || ').cur_run_accr --> ' || TB_ICENT_HIST_UPD(L_CUR)
                    .CUR_RUN_ACCR);
                DBG('tb_icent_hist_upd(' || L_CUR || ').lcy_amt --> ' || TB_ICENT_HIST_UPD(L_CUR)
                    .LCY_AMT);
                DBG('tb_icent_hist_upd(' || L_CUR || ').accrued_amt --> ' || TB_ICENT_HIST_UPD(L_CUR)
                    .ACCRUED_AMT);
                TB_ICENT_UPD_ROWID(L_ICENTHIST_CUR) := CUR_ICENT_HIST.ROW_ID;
                L_ICENTHIST_CUR := L_ICENTHIST_CUR + 1;
              END LOOP;
              DBG('ic entries history gave me : ' ||
                  NVL(TB_ICENT_HIST_UPD.COUNT, 0));
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('In WNDF of ICTBS_ENTRIES_HISTORY select');
              WHEN OTHERS THEN
                DBG('In WO of ICTBS_ENTRIES_HISTORY select');
                DBG('SqlErrm --> ' || SQLERRM);
                RAISE;
            END;
          
            DBG('tbfrm count in pr_liq_defr-->' || NVL(TBFRM.COUNT, 0));
            IF TBFRM.COUNT <> 0 THEN
              FOR I IN TBFRM.FIRST .. TBFRM.LAST LOOP
                DBG('Amt-->' || TBFRM(I).AMT || 'XRate-->' || TBFRM(I)
                    .XRATE || 'lcy amt-->' || TBFRM(I).LCY_AMT ||
                    'book amt-->' || TBFRM(I).BOOK_AMT ||
                    'Acquired Amt-->' || TBFRM(I).ACQUIRED_AMT ||
                    'Accrued Amt-->' || TBFRM(I).ACCRUED_AMT ||
                    'Accrued Adj-->' || TBFRM(I).ACQUIRED_ADJ);
              END LOOP;
            END IF;
          
            TBFRM.DELETE;
            IF NVL(TB_ICENT_HIST_UPD.COUNT, 0) <> 0 THEN
              FOR CUR_ICENT_HIST IN TB_ICENT_HIST_UPD.FIRST .. TB_ICENT_HIST_UPD.LAST LOOP
              
                TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT := TB_ICENT_HIST_UPD(CUR_ICENT_HIST).AMT;
                DBG('tbfrm(' || TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO ||
                    ').amt --> ' || TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT);
                BEGIN
                  L_CUR := 0;
                  FOR CUR_ICENT IN (SELECT E.*, E.ROWID ROW_ID
                                      FROM ICTBS_ENTRIES E
                                     WHERE E.BRN = TB_BRN(CUR_ROW)
                                       AND E.ACC = TB_ACC(CUR_ROW)
                                       AND E.PROD = TB_PROD(CUR_ROW)
                                       AND E.FRM_NO = TB_ICENT_HIST_UPD(CUR_ICENT_HIST)
                                          .FRM_NO
                                    
                                     ORDER BY E.BRN, E.ACC, E.PROD, E.FRM_NO) LOOP
                    L_CUR := L_CUR + 1;
                    TB_ICENT(L_CUR).ACC := CUR_ICENT.ACC;
                    TB_ICENT(L_CUR).BRN := CUR_ICENT.BRN;
                    TB_ICENT(L_CUR).PROD := CUR_ICENT.PROD;
                    TB_ICENT(L_CUR).FRM_NO := CUR_ICENT.FRM_NO;
                    TB_ICENT(L_CUR).AMT := NVL(CUR_ICENT.AMT, 0);
                    TB_ICENT(L_CUR).ACCRUED_AMT := NVL(CUR_ICENT.ACCRUED_AMT,
                                                       0);
                    TB_ICENT(L_CUR).AMT_TO_ACCRUE := NVL(CUR_ICENT.AMT_TO_ACCRUE,
                                                         0);
                    TB_ICENT(L_CUR).CUR_RUN_ACCR := NVL(CUR_ICENT.CUR_RUN_ACCR,
                                                        0);
                    TB_ICENT(L_CUR).ENT_DT := CUR_ICENT.ENT_DT;
                    TB_ICENT(L_CUR).DRCR := CUR_ICENT.DRCR;
                    TB_ICENT(L_CUR).HAS_ACCR := CUR_ICENT.HAS_ACCR;
                    TB_ICENT(L_CUR).DAILY_AMT := NVL(CUR_ICENT.DAILY_AMT, 0);
                    TB_ICENT(L_CUR).NEXT_CALC_DUE_DATE := CUR_ICENT.NEXT_CALC_DUE_DATE;
                    TB_ICENT(L_CUR).ACQUIRED_AMT := NVL(CUR_ICENT.ACQUIRED_AMT,
                                                        0);
                    TB_ICENT(L_CUR).ACQUIRED_ADJ := NVL(CUR_ICENT.ACQUIRED_ADJ,
                                                        0);
                    TB_ICENT(L_CUR).ROW_ID := CUR_ICENT.ROW_ID;
                    DBG('tb_icent(' || L_CUR || ').amt --> ' || TB_ICENT(L_CUR).AMT);
                    DBG('tb_icent(' || L_CUR || ').amt_to_accrue --> ' || TB_ICENT(L_CUR)
                        .AMT_TO_ACCRUE);
                    DBG('tb_icent(' || L_CUR || ').cur_run_accr --> ' || TB_ICENT(L_CUR)
                        .CUR_RUN_ACCR);
                    DBG('tb_icent(' || L_CUR || ').daily_amt --> ' || TB_ICENT(L_CUR)
                        .DAILY_AMT);
                    DBG('tb_icent(' || L_CUR || ').accrued_amt --> ' || TB_ICENT(L_CUR)
                        .ACCRUED_AMT);
                    DBG('tb_icent(' || L_CUR || ').acquired_amt --> ' || TB_ICENT(L_CUR)
                        .ACQUIRED_AMT);
                    DBG('tbfrm(' || TB_ICENT(L_CUR).FRM_NO || ').amt --> ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT);
                  
                    DBG('g_Onliq_Flag: ' || G_ONLIQ_FLAG ||
                        ' r_Print.Deferred_Flag: ' ||
                        R_PRINT.DEFERRED_FLAG || ' p_Dt: ' || P_DT ||
                        ' Tb_Defer_Liq_Dt(Cur_Row): ' ||
                        TB_DEFER_LIQ_DT(CUR_ROW));
                    DBG('Before :: amt :: ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT || '~' || TB_ICENT(L_CUR)
                        .ACQUIRED_AMT);
                  
                    IF ((G_ONLIQ_FLAG = 'N') OR
                       (R_PRINT.DEFERRED_FLAG = 'Y' AND
                       TB_DEFER_LIQ_DT(CUR_ROW) <= P_DT)) THEN
                      DBG('Upding the amt :: ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT || '~' || TB_ICENT(L_CUR)
                          .ACQUIRED_AMT);
                    
                      TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT := NVL(TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT,
                                                               0) +
                                                           NVL(TB_ICENT(L_CUR)
                                                               .ACQUIRED_AMT,
                                                               0);
                    
                      IF NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('IC_NADJ_PADJ_TAGS_REQD'),
                             'N') = 'Y' THEN
                        TBFRM(TB_ICENT(L_CUR).FRM_NO).ACQUIRED_AMT := NVL(TB_ICENT(L_CUR)
                                                                          .ACQUIRED_AMT,
                                                                          0);
                      END IF;
                    
                      DBG('After upd :: ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT);
                    END IF;
                    DBG('The amt :: ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT);
                  
                    DBG('tbfrm(' || TB_ICENT(L_CUR).FRM_NO || ').amt --> ' || TBFRM(TB_ICENT(L_CUR).FRM_NO).AMT);
                    TB_ICENT_ROWID(L_ICENT_CUR) := CUR_ICENT.ROW_ID;
                    L_ICENT_CUR := L_ICENT_CUR + 1;
                  
                  END LOOP;
                  DBG('ictb entries gave me : ' || NVL(TB_ICENT.COUNT, 0));
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('In WNDF of ICTBS_ENTRIES select ');
                  WHEN OTHERS THEN
                    DBG('In WO of ICTBS_ENTRIES select');
                    DBG('SqlErrm --> ' || SQLERRM);
                    RAISE;
                END;
              
                BEGIN
                  FOR ADJ_INT_HIST IN (SELECT *
                                         FROM ICTBS_ADJ_INTEREST_HISTORY
                                        WHERE BRN = TB_BRN(CUR_ROW)
                                          AND ACC = TB_ACC(CUR_ROW)
                                          AND PROD = TB_PROD(CUR_ROW)
                                          AND FRM_NO = TB_ICENT_HIST_UPD(CUR_ICENT_HIST)
                                             .FRM_NO
                                          AND LIQN_DT =
                                              TB_LAST_LIQ_DT(CUR_ROW)
                                        ORDER BY ENT_DT) LOOP
                    DBG('Brn-->' || ADJ_INT_HIST.BRN || '~Acc-->' ||
                        ADJ_INT_HIST.ACC || '~Prod-->' ||
                        ADJ_INT_HIST.PROD || '~Frm_No-->' ||
                        ADJ_INT_HIST.FRM_NO || '~Ent_Dt-->' ||
                        ADJ_INT_HIST.ENT_DT || '~Liqn_Dt-->' ||
                        ADJ_INT_HIST.LIQN_DT || '~Ccy-->' ||
                        ADJ_INT_HIST.CCY || '~Amt-->' || ADJ_INT_HIST.AMT ||
                        '~Lcy_Amt-->' || ADJ_INT_HIST.LCY_AMT);
                  
                    IF G_ONLIQ_FLAG = 'N' THEN
                      TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT := NVL(TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT,
                                                                                 0) +
                                                                             NVL(ADJ_INT_HIST.AMT,
                                                                                 0);
                    END IF;
                  END LOOP;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('In WOT of ICTBS_ENTRIES select: ' || SQLERRM);
                END;
              
                SELECT BRANCH_LCY
                  INTO L_LCY
                  FROM STTMS_BRANCH
                 WHERE BRANCH_CODE = TB_ICENT_HIST_UPD(CUR_ICENT_HIST).BRN;
                TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).XRATE := NULL;
                TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).LCY_AMT := NULL;
              
                TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).BOOK_AMT := TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT;
                DBG('Book ccy -->' || L_BOOK_CCY || ' A/c ccy-->' || L_CCY ||
                    ' lcy-->' || L_LCY);
                IF L_BOOK_CCY <> L_CCY THEN
                  IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).BRN,
                                                     L_CCY,
                                                     L_BOOK_CCY,
                                                     
                                                     NVL(TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT,
                                                         0),
                                                     'Y',
                                                     TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                     .BOOK_AMT,
                                                     TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                     .XRATE,
                                                     ERR_CODE) THEN
                    ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_LIQ_DEFR');
                  END IF;
                ELSE
                
                  TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).BOOK_AMT := TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT;
                END IF;
                IF L_BOOK_CCY <> L_LCY THEN
                
                  IF TB_ICENT_HIST_UPD(CUR_ICENT_HIST).CCY = L_LCY
                  
                   THEN
                  
                    TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).LCY_AMT := NVL(TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).AMT,
                                                                                   0);
                  
                  ELSE
                    TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).LCY_AMT := NULL;
                    TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).XRATE := NULL;
                    IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).BRN,
                                                       L_BOOK_CCY,
                                                       L_LCY,
                                                       NVL(TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                           .BOOK_AMT,
                                                           0),
                                                       'Y',
                                                       TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                       .LCY_AMT,
                                                       TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                       .XRATE,
                                                       ERR_CODE) THEN
                      ICPKSS_UTIL.SET_ERR(ERR_CODE, 'PR_LIQ_DEFR');
                    END IF;
                  END IF;
                ELSE
                  TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).LCY_AMT := TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO)
                                                                             .BOOK_AMT;
                
                  TBFRM(TB_ICENT_HIST_UPD(CUR_ICENT_HIST).FRM_NO).BOOK_AMT := NULL;
                END IF;
              
              END LOOP;
            END IF;
            DBG('B4 calling pr_entries_liq:' || CUR_ROW || ' Prod -->' ||
                TB_PROD(CUR_ROW));
          
            IF GLOBAL.X9$ <> 'AEDRAK' THEN
            
              IF PKG_STOP_DEFR_POSTING THEN
                IF TBFRM.COUNT <> 0 THEN
                  TBFRM.DELETE;
                END IF;
              END IF;
            
            END IF;
            ICPKSS_TEST.PR_ENTRIES_LIQ(TB_DEFER_LIQ_DT(CUR_ROW),
                                       CUR_ROW,
                                       TBFRM);
          
            IF NVL(PKG_LIQ_NETTING, 'N') = 'Y' AND TB_ICENT.COUNT <> 0 THEN
              DBG('In liq netting case of defer liq' || TB_ICENT.COUNT);
              FOR J IN TB_ICENT.FIRST .. TB_ICENT.LAST LOOP
                DBG('Inside the loop of liq netting');
              
                L_FATCA_RECORD := ICPKS_CACHE.FN_GET_ISFATCAPROD(TB_ICENT(J).PROD,
                                                                 TB_ICENT(J)
                                                                 .FRM_NO);
                DBG('product~frmno~isfatca :' || TB_ICENT(J).PROD || '~' || TB_ICENT(J)
                    .FRM_NO || '~' || L_FATCA_RECORD);
                IF L_FATCA_RECORD = 'Y' THEN
                  BEGIN
                    DBG('before process, net escrow : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_ESCROW || ' net tpbl : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_TPBL);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW := 0;
                      L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL := 0;
                      L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW_LCY := 0;
                      L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL_LCY := 0;
                  END;
                  DBG('acc~brn : ' || TB_ICENT(J).ACC || '~' || TB_ICENT(J).BRN);
                  L_FATCA_EXT_CUSTOMER_SDE := ICPKS_CACHE.FN_GET_FATCA_EXT_CUST(TB_ICENT(J).BRN,
                                                                                TB_ICENT(J).ACC);
                  DBG('external customer status is : ' ||
                      L_FATCA_EXT_CUSTOMER_SDE);
                  IF L_FATCA_EXT_CUSTOMER_SDE = 1 THEN
                    L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW := NVL(L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                                                       .SUM_ESCROW,
                                                                       0) +
                                                                   NVL(TB_ICENT(J).AMT,
                                                                       0);
                    L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_ESCROW_LCY := NVL(L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                                                           .SUM_ESCROW_LCY,
                                                                           0) +
                                                                       NVL(TB_ICENT(J)
                                                                           .LCY_AMT,
                                                                           0);
                    DBG('escrow sum altered to : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_ESCROW);
                    DBG('escrow sum lcy altered to : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_ESCROW_LCY);
                  ELSE
                    L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL := NVL(L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                                                     .SUM_TPBL,
                                                                     0) +
                                                                 NVL(TB_ICENT(J).AMT,
                                                                     0);
                    L_FATCA_LIQNET(TB_ICENT(J).PROD).SUM_TPBL_LCY := NVL(L_FATCA_LIQNET(TB_ICENT(J).PROD)
                                                                         .SUM_TPBL_LCY,
                                                                         0) +
                                                                     NVL(TB_ICENT(J)
                                                                         .LCY_AMT,
                                                                         0);
                    DBG('tax payable sum altered to : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_TPBL);
                    DBG('tax payable sum lcy altered to : ' || L_FATCA_LIQNET(TB_ICENT(J).PROD)
                        .SUM_TPBL_LCY);
                  END IF;
                END IF;
              
                Y := TB_ICENT(J).PROD || TB_ICENT(J).FRM_NO;
                DBG('y comes out as ' || Y);
              
                POS1 := CSPKES_MISC.FN_GETPARAM_NO(FRMLISTLIQ_DEFR, Y, '~');
                DBG('position of the same is ' || POS1);
                IF POS1 <> 0 THEN
                
                  IF TB_ICENT_LIQNET.EXISTS(POS1) THEN
                    TB_ICENT_LIQNET(POS1).AMT := NVL(TB_ICENT_LIQNET(POS1).AMT,
                                                     0) + NVL(TBFRM(TB_ICENT(J).FRM_NO).AMT,
                                                              0);
                  ELSE
                    TB_ICENT_LIQNET(POS1).AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO).AMT,
                                                     0);
                  END IF;
                
                  TB_ICENT_LIQNET(POS1).ACQUIRED_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                            .ACQUIRED_AMT,
                                                            0) +
                                                        NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                            .ACQUIRED_AMT,
                                                            0);
                  DBG('The amount is  ' || TB_ICENT_LIQNET(POS1).AMT);
                
                  IF ICPKS_TEST.G_STTM_CUSTACC.CCY <> LCY THEN
                  
                    DBG('Are the cutrrencys different');
                  
                    L_LCY_AMT := NULL;
                    L_XRATE   := NULL;
                  
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                         .LCY_AMT,
                                                         0) +
                                                     NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                         .LCY_AMT,
                                                         0);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT_LIQNET(POS1)
                                                              .ACQUIRED_LCY,
                                                              0) +
                                                          NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                              .LCY_ACQUIRED_AMT,
                                                              0);
                  ELSE
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TB_ICENT_LIQNET(POS1)
                                                         .LCY_AMT,
                                                         0) +
                                                     NVL(TBFRM(TB_ICENT(J).FRM_NO).AMT,
                                                         0);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TB_ICENT_LIQNET(POS1)
                                                              .ACQUIRED_LCY,
                                                              0) +
                                                          NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                              .ACQUIRED_AMT,
                                                              0);
                  END IF;
                
                ELSE
                  POS1 := NVL(TB_ICENT_LIQNET.COUNT, 0) + 1;
                  TB_ICENT_LIQNET(POS1) := TB_ICENT(J);
                  TB_ICENT_LIQNET(POS1).AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO).AMT,
                                                   0);
                  TB_ICENT_LIQNET(POS1).ACQUIRED_AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                            .ACQUIRED_AMT,
                                                            0);
                
                  IF ICPKS_TEST.G_STTM_CUSTACC.CCY <> LCY THEN
                    DBG('Are the cutrrencys different');
                  
                    L_LCY_AMT := NULL;
                    L_XRATE   := NULL;
                  
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                         .LCY_AMT,
                                                         0);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                              .LCY_ACQUIRED_AMT,
                                                              0);
                  
                  ELSE
                  
                    TB_ICENT_LIQNET(POS1).LCY_AMT := NVL(TBFRM(TB_ICENT(J).FRM_NO).AMT,
                                                         0);
                  
                    TB_ICENT_LIQNET(POS1).ACQUIRED_LCY := NVL(TBFRM(TB_ICENT(J).FRM_NO)
                                                              .ACQUIRED_AMT,
                                                              0);
                  
                  END IF;
                
                  IF FRMLISTLIQ_DEFR IS NULL THEN
                    FRMLISTLIQ_DEFR := Y;
                  ELSE
                    FRMLISTLIQ_DEFR := FRMLISTLIQ_DEFR || '~' || Y;
                  END IF;
                
                  DBG('The amount is  ' || TB_ICENT_LIQNET(POS1).AMT);
                END IF;
                TB_ICENT(J).AMT := 0;
                TB_ICENT(J).ACCRUED_AMT := 0;
                TB_ICENT(J).AMT_TO_ACCRUE := 0;
                TB_ICENT(J).CUR_RUN_ACCR := 0;
                TB_ICENT(J).DAILY_AMT := 0;
                TB_ICENT(J).ACQUIRED_AMT := 0;
                TB_ICENT(J).ACQUIRED_ADJ := 0;
              END LOOP;
              DBG('Liq netting sucessfully done');
            END IF;
            TBFRM.DELETE;
            DBG('After comming out of pr_entries_liq');
            DBG('tb_hoff_cons count is :' || TB_HOFF_CONS.COUNT);
            TB_ICENT_HIST_UPD.DELETE;
            TB_ICENT.DELETE;
            L_CUR := 0;
            FIND_KEY(TB_PROD(CUR_ROW), R_PRINT);
          
            IF G_ONLIQ_FLAG = 'Y' THEN
              L_TMP_LIQ_DT := TB_NEXT_SCHD_LIQ_DT(CUR_ROW);
            ELSE
              L_TMP_LIQ_DT := TB_NEXT_LIQ_DT(CUR_ROW);
            END IF;
          
            DBG('B4 calculating defer liq dt deferred_flag-->' ||
                R_PRINT.DEFERRED_FLAG || ' calc days-->' ||
                R_PRINT.CALC_DAYS || ' next liq dt-->' || L_TMP_LIQ_DT);
            IF R_PRINT.DEFERRED_FLAG = 'Y' THEN
              IF R_PRINT.CALC_DAYS > 0 THEN
              
                TB_DEFER_LIQ_DT(CUR_ROW) := L_TMP_LIQ_DT +
                                            R_PRINT.CALC_DAYS;
              
              ELSE
                TB_DEFER_LIQ_DT(CUR_ROW) := L_TMP_LIQ_DT;
              END IF;
            ELSE
              TB_DEFER_LIQ_DT(CUR_ROW) := L_TMP_LIQ_DT;
            END IF;
          END IF;
          L_PREV_ROW := CUR_ROW;
          CUR_ROW    := TB_ROWID.NEXT(CUR_ROW);
        
        EXCEPTION
          WHEN ACNTG_FAILED THEN
            DBG('In ACNTG_FAILED of pr_liq_defr for ');
            DBG('Error is --> ' || SQLERRM);
          
            PR_TAKE_PLSQL_TAB_RESTORE;
            TB_ICENT_UPD_ROWID := TB_ICENT_UPD_ROWID_BAK;
            TB_ICENT_ROWID     := TB_ICENT_ROWID_BAK;
            L_ICENT_CUR        := L_ICENT_CUR_BAK;
            L_ICENTHIST_CUR    := L_ICENTHIST_CUR_BAK;
            DBG('Rollback done Sp_Dfr_Liqd1');
            ROLLBACK TO SP_DFR_LIQD1;
        END;
      
      END LOOP;
    END IF;
    IF NVL(TB_HOFF_CONS.COUNT, 0) <> 0 THEN
      DBG('There are some cons entries ' || '~' || TB_HOFF_CONS.COUNT);
      OVPKSS.PR_INITERRTBL;
      IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                 1,
                                 APPDT,
                                 TB_HOFF_CONS,
                                 'B',
                                 'Y',
                                 'N',
                                 UID,
                                 ERRMSG,
                                 EPRM) THEN
        DBG('Failed in passing the entry...log this ' || ERRMSG || ' ' || EPRM);
      
        LOG_PROBLEM(-1,
                    'Y',
                    SUBSTR('pr_liq_defr ' || ERRMSG || EPRM, 1, 2000));
        TB_HOFF_CONS.DELETE;
      
        PR_TAKE_PLSQL_TAB_RESTORE;
        TB_ICENT_UPD_ROWID := TB_ICENT_UPD_ROWID_BAK;
        TB_ICENT_ROWID     := TB_ICENT_ROWID_BAK;
        L_ICENT_CUR        := L_ICENT_CUR_BAK;
        L_ICENTHIST_CUR    := L_ICENTHIST_CUR_BAK;
        DBG('Rollback done here Sp_Dfr_Liqd1');
        ROLLBACK TO SP_DFR_LIQD1;
      
      END IF;
      TB_HOFF_CONS.DELETE;
    ELSE
      DBG('No entries so nothing to do!!!!cons');
    END IF;
  
    IF TB_ICENT_LIQNET.COUNT <> 0 THEN
      DBG('calling pr_liq_netting in liq_defr outside loop');
      G_STTM_CUSTACC.CCY := TB_CCY(L_PREV_ROW);
      BEGIN
        PR_LIQ_NETTING(P_BRN, P_DT, L_PREV_ROW, TB_ICENT_LIQNET);
      EXCEPTION
        WHEN OTHERS THEN
          TB_ICENT_LIQNET.DELETE;
          RAISE;
      END;
      TB_ICENT_LIQNET.DELETE;
    END IF;
    IF TB_HOFF_PROD.COUNT <> 0 THEN
      DBG('Going to call acpkss for prod level entries in liq defer' ||
          APPDT);
      OVPKSS.PR_INITERRTBL;
      IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                 1,
                                 APPDT,
                                 TB_HOFF_PROD,
                                 'B',
                                 'Y',
                                 'N',
                                 UID,
                                 ERRMSG,
                                 EPRM) THEN
        DBG('Failed in passing the entry...log this' || ERRMSG || EPRM);
      
        LOG_PROBLEM(L_PREVREC,
                    'B',
                    'Liq defer actng failed ' || SUBSTR(ERRMSG, 1, 1900));
        TB_HOFF_PROD.DELETE;
        RAISE ACNTG_FAILED;
      END IF;
      TB_HOFF_PROD.DELETE;
    END IF;
  
    IF NVL(TB_ROWID.COUNT, 0) <> 0 THEN
      BEGIN
      
        FORALL UPD IN INDICES OF TB_ROWID
          UPDATE ICTBS_ACC_PR
             SET DEFER_LIQ_DT = TB_DEFER_LIQ_DT(UPD)
           WHERE ROWID = TB_ROWID(UPD);
        DBG('Through with ICTBS_ACC_PR update');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in ictbs_acc_pr update -->' || SQLERRM);
          RAISE;
      END;
    END IF;
  
    IF NVL(TB_ICENT_UPD_ROWID.COUNT, 0) <> 0 THEN
      FOR I IN TB_ICENT_UPD_ROWID.FIRST .. TB_ICENT_UPD_ROWID.LAST LOOP
        DECLARE
          L_ACC          ICTB_ENTRIES_HISTORY.ACC%TYPE := NULL;
          L_BRN          ICTB_ENTRIES_HISTORY.BRN%TYPE := NULL;
          L_PROD         ICTB_ENTRIES_HISTORY.PROD %TYPE := NULL;
          L_AMT          ICTB_ENTRIES_HISTORY.AMT%TYPE := NULL;
          L_ACQUIRED_AMT ICTB_ENTRIES.ACQUIRED_AMT%TYPE := NULL;
          L_FRMNO        ICTB_ENTRIES.FRM_NO%TYPE;
          L_ENT_DT       ICTB_ENTRIES_HISTORY.ENT_DT%TYPE;
          L_HIS_ACQUIRED NUMBER := 0;
        
          CURSOR CR_ADJINT(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
            SELECT BRN, ACC, PROD, FRM_NO, ENT_DT, CCY, AMT, LCY_AMT
              FROM ICTBS_ADJ_INTEREST
             WHERE BRN = P_BRN
               AND ACC = P_ACC
               AND PROD = P_PROD
             ORDER BY BRN, ACC, PROD, FRM_NO, ENT_DT;
        
        BEGIN
          SELECT ACC, BRN, PROD, AMT, FRM_NO, ENT_DT
            INTO L_ACC, L_BRN, L_PROD, L_AMT, L_FRMNO, L_ENT_DT
            FROM ICTB_ENTRIES_HISTORY
           WHERE ROWID = TB_ICENT_UPD_ROWID(I);
          DBG('L_ACC' || L_ACC);
          DBG('l_brn' || L_BRN);
          DBG('l_prod' || L_PROD);
          DBG('l_amt' || L_AMT);
          BEGIN
            SELECT NVL(ACQUIRED_AMT, '0')
              INTO L_ACQUIRED_AMT
              FROM ICTB_ENTRIES
             WHERE ACC = L_ACC
               AND BRN = L_BRN
               AND PROD = L_PROD
               AND FRM_NO = L_FRMNO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_ACQUIRED_AMT := '0';
              DBG('No data found' || L_ACQUIRED_AMT);
            WHEN OTHERS THEN
              L_ACQUIRED_AMT := '0';
              DBG('In When others ' || SQLERRM);
          END;
          DBG('L_ACQUIRED_AMT' || L_ACQUIRED_AMT);
        
          L_AMT := L_AMT + L_ACQUIRED_AMT;
          DBG('l_amt' || L_AMT);
        
          BEGIN
            SELECT NVL(SUM(AMT), 0)
              INTO L_HIS_ACQUIRED
              FROM ICTBS_ADJ_INTEREST_HISTORY
             WHERE BRN = L_BRN
               AND ACC = L_ACC
               AND PROD = L_PROD
               AND FRM_NO = L_FRMNO
                  
               AND ENT_DT = L_ENT_DT;
          EXCEPTION
            WHEN OTHERS THEN
              L_HIS_ACQUIRED := 0;
          END;
          DBG('L_HIS_ACQUIRED :' || L_HIS_ACQUIRED);
        
          BEGIN
            SELECT NVL(SUM(AMT), 0)
              INTO L_ACQUIRED_AMT
              FROM ICTBS_ADJ_INTEREST
             WHERE BRN = L_BRN
               AND ACC = L_ACC
               AND PROD = L_PROD
               AND FRM_NO = L_FRMNO
               AND ENT_DT = L_ENT_DT;
          EXCEPTION
            WHEN OTHERS THEN
              L_ACQUIRED_AMT := 0;
          END;
          DBG('L_ACQUIRED_AMT :' || L_ACQUIRED_AMT);
        
          UPDATE ICTB_ENTRIES_HISTORY
             SET AMT = AMT + L_ACQUIRED_AMT + L_HIS_ACQUIRED
           WHERE ROWID = TB_ICENT_UPD_ROWID(I);
          DBG('Going to update the ictbs_entries for :' || L_ACC);
          UPDATE ICTBS_ENTRIES
             SET ACQUIRED_AMT = 0.0, ACQUIRED_ADJ = 0.0
           WHERE ACC = L_ACC
             AND BRN = L_BRN
             AND PROD = L_PROD
             AND FRM_NO = L_FRMNO;
          DBG('UPDATE DONE FOR i :' || I);
          DBG('UPDATE DONE FOR RECS :' || SQL%ROWCOUNT);
        
          FOR CR_ADINT IN CR_ADJINT(L_BRN, L_ACC, L_PROD) LOOP
            BEGIN
              DBG('going to update amt for back period ent dates in liq_defer');
              IF CR_ADINT.ENT_DT <> L_ENT_DT THEN
                DBG('Updated only for back dated period ' ||
                    CR_ADINT.ENT_DT);
                UPDATE ICTB_ENTRIES_HISTORY
                   SET AMT = AMT + CR_ADINT.AMT
                 WHERE BRN = CR_ADINT.BRN
                   AND ACC = CR_ADINT.ACC
                   AND PROD = CR_ADINT.PROD
                   AND FRM_NO = CR_ADINT.FRM_NO
                   AND ENT_DT = CR_ADINT.ENT_DT;
              END IF;
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG('in exp for ictb_adj_interest_history insert ');
                NULL;
            END;
            DBG('Entries History insert for back period');
            DBG('SQL%ROWCOUNT ' || SQL%ROWCOUNT);
          END LOOP;
        
          FOR CR_ADINT IN CR_ADJINT(L_BRN, L_ACC, L_PROD) LOOP
            BEGIN
              DBG('going to insert ictb_adj_interest_history in liq_defer');
              INSERT INTO ICTB_ADJ_INTEREST_HISTORY
                (BRN,
                 ACC,
                 PROD,
                 FRM_NO,
                 ENT_DT,
                 LIQN_DT,
                 CCY,
                 AMT,
                 LCY_AMT)
              VALUES
                (CR_ADINT.BRN,
                 CR_ADINT.ACC,
                 CR_ADINT.PROD,
                 CR_ADINT.FRM_NO,
                 CR_ADINT.ENT_DT,
                 P_DT,
                 CR_ADINT.CCY,
                 CR_ADINT.AMT,
                 CR_ADINT.LCY_AMT);
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                DBG('in exp for ictb_adj_interest_history insert ');
                NULL;
            END;
            DBG('Entries History insert');
            DBG('SQL%ROWCOUNT ' || SQL%ROWCOUNT);
            IF SQL%ROWCOUNT > 0 THEN
            
              DBG('DELETE ictbs_adj_interest for ' || CR_ADINT.ACC || ' ' ||
                  CR_ADINT.PROD || ' ' || CR_ADINT.FRM_NO);
              DELETE ICTBS_ADJ_INTEREST
               WHERE BRN = CR_ADINT.BRN
                 AND ACC = CR_ADINT.ACC
                 AND PROD = CR_ADINT.PROD
                 AND FRM_NO = CR_ADINT.FRM_NO
                 AND ENT_DT = CR_ADINT.ENT_DT;
            
            END IF;
          END LOOP;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('In When others 1' || SQLERRM);
        END;
      END LOOP;
    END IF;
  
    IF NVL(TB_ICENT_ROWID.COUNT, 0) <> 0 THEN
      BEGIN
        FORALL UPD IN TB_ICENT_ROWID.FIRST .. TB_ICENT_ROWID.LAST
          UPDATE ICTBS_ENTRIES
             SET ACQUIRED_AMT = 0.0, ACQUIRED_ADJ = 0.0
           WHERE ROWID = TB_ICENT_ROWID(UPD);
        DBG('Through with ICTBS_ENTRIES update');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in ictbs_entries update -->' || SQLERRM);
          RAISE;
      END;
    END IF;
    IF NVL(TB_ICENT_UPD_ROWID.COUNT, 0) <> 0 THEN
      BEGIN
        FORALL I IN TB_ICENT_UPD_ROWID.FIRST .. TB_ICENT_UPD_ROWID.LAST
          UPDATE ICTBS_ENTRIES_HISTORY
             SET ENTRY_PASSED = 'Y'
           WHERE ROWID = TB_ICENT_UPD_ROWID(I);
        DBG('Through with ICTBS_ENTRIES_HISTORY update');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in ictbs_entries_history update -->' || SQLERRM);
          RAISE;
      END;
    END IF;
    DEFR_CASE := FALSE;
  
    TBFRM.DELETE;
    TB_ICENT_UPD_ROWID.DELETE;
    TB_ICENT_ROWID.DELETE;
  
    PR_PURGE_PLSQL_TABS;
  
    DBG('Just b4 comming out of pr_liq_defr');
  EXCEPTION
    WHEN ACNTG_FAILED THEN
      DBG('In ACNTG_FAILED of pr_liq_defr for ');
      DBG('Error is --> ' || SQLERRM);
      DEFR_CASE := FALSE;
      RAISE;
    WHEN NO_DATA_FOUND THEN
      LOG_PROBLEM(CUR_ROW, 'B', SUBSTR('pr_liq_defr ' || SQLERRM, 1, 2000));
      DEFR_CASE := FALSE;
      DBG('No Accounts to Process in pr_liq_defr');
    WHEN OTHERS THEN
      DBG('In WO of pr_liq_defr --> ' || SQLERRM);
      LOG_PROBLEM(CUR_ROW, 'B', SUBSTR('pr_liq_defr ' || SQLERRM, 1, 2000));
      DEFR_CASE := FALSE;
      RAISE;
  END PR_LIQ_DEFR;

  FUNCTION FN_UPDATE_LMTB_LINEACC_UTIL(P_BRN             IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                                       P_ERROR_CODE      IN OUT VARCHAR2,
                                       P_ERROR_PARAMETER IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_EFF_LIMIT_AMT LMTB_LINEACC_UTIL.EFF_LIMIT_AMT%TYPE;
    L_DATE          DATE;
    L_NWD           DATE;
    CURSOR UPDATE_LINEACC_UTIL_EL IS
      SELECT A.INTEREST_CALC_ACC,
             A.LMT_AMT_BASIS,
             NVL(A.COLLATERAL_CONTRIBUTION, 0) COLLATERAL_CONTRIBUTION,
             NVL(A.TRANSFER_AMOUNT, 0) TRANSFER_AMOUNT,
             A.LIAB_ID,
             A.LINE_CD,
             A.LINE_START_DATE,
             NVL(A.LIMIT_AMOUNT, 0) LIMIT_AMOUNT,
             NVL(A.UTILISATION, 0) UTILISATION,
             NVL(A.MATURED_UTIL, 0) MATURED_UTIL,
             A.LINE_EXPIRY_DATE
        FROM ELVWS_LIMITS_INT A, STTMS_CUST_ACCOUNT B
       WHERE A.INTEREST_REQD = 'Y'
         AND NVL(A.AVAILABILITY_FLAG, 'Y') = 'Y'
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A'
         AND A.INTEREST_CALC_ACC = B.CUST_AC_NO
         AND B.BRANCH_CODE = P_BRN
         AND A.INTEREST_CALC_ACC IS NOT NULL
       ORDER BY A.INTEREST_CALC_ACC;
    CURSOR UPDATE_LINEACC_UTIL IS
      SELECT A.INTEREST_CALC_ACC,
             A.LMT_AMT_BASIS,
             NVL(A.COLLATERAL_CONTRIBUTION, 0) COLLATERAL_CONTRIBUTION,
             NVL(A.TRANSFER_AMOUNT, 0) TRANSFER_AMOUNT,
             A.LIAB_ID,
             A.LINE_CD,
             A.LINE_START_DATE,
             NVL(A.LIMIT_AMOUNT, 0) LIMIT_AMOUNT,
             NVL(A.UTILISATION, 0) UTILISATION,
             NVL(A.MATURED_UTIL, 0) MATURED_UTIL,
             A.LINE_EXPIRY_DATE
        FROM LMTMS_LIMITS A, STTMS_CUST_ACCOUNT B
       WHERE A.INTEREST_REQD = 'Y'
         AND NVL(A.AVAILABILITY_FLAG, 'Y') = 'Y'
         AND A.RECORD_STAT = 'O'
         AND A.AUTH_STAT = 'A'
         AND A.INTEREST_CALC_ACC = B.CUST_AC_NO
         AND B.BRANCH_CODE = P_BRN
         AND A.INTEREST_CALC_ACC IS NOT NULL
       ORDER BY A.INTEREST_CALC_ACC;
  BEGIN
    DBG('Icpks_test--->Start of function icpks_test.fn_update_lmtb_lineacc_util');
    IF ELPKS.LIMITS_MODULE = 'LM' THEN
    
      FOR EACH_ACC IN UPDATE_LINEACC_UTIL LOOP
        DBG('Icpks_test--->Going to call function lmpks_misc.fn_calc_eff_line_amt');
        L_EFF_LIMIT_AMT := LMPKS_MISC.FN_CALC_EFF_LINE_AMT(EACH_ACC.LMT_AMT_BASIS,
                                                           EACH_ACC.LIMIT_AMOUNT,
                                                           EACH_ACC.TRANSFER_AMOUNT,
                                                           EACH_ACC.COLLATERAL_CONTRIBUTION);
        BEGIN
          DBG('Icpks_test--->Going to insert into lmtb_lineacc_util');
          INSERT INTO LMTB_LINEACC_UTIL
            (BRN,
             ACC,
             LIABILITY_ID,
             LINE_ID,
             APPL_DT,
             LIMIT_AMOUNT,
             EFF_LIMIT_AMT,
             UTILIZATION,
             MATURED_AMT,
             EXPIRY_DATE)
          VALUES
            (P_BRN,
             EACH_ACC.INTEREST_CALC_ACC,
             EACH_ACC.LIAB_ID,
             EACH_ACC.LINE_CD,
             GLOBAL.APPLICATION_DATE,
             EACH_ACC.LIMIT_AMOUNT,
             L_EFF_LIMIT_AMT,
             EACH_ACC.UTILISATION,
             EACH_ACC.MATURED_UTIL,
             EACH_ACC.LINE_EXPIRY_DATE);
        EXCEPTION
          WHEN DUP_VAL_ON_INDEX THEN
            DBG('Icpks_test-->In DUP_VAL_ON_INDEX while inserting into lmtb_lineacc_util.May be a case of rerun');
            NULL;
        END;
      END LOOP;
    
    ELSE
    
      IF ELPKSS.ELCM_INTERFACE = 'TABLE' THEN
      
        BEGIN
        
          L_DATE := GLOBAL.APPLICATION_DATE;
          SELECT NEXT_WORKING_DAY
            INTO L_NWD
            FROM STTM_DATES
           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        
          WHILE L_DATE < L_NWD LOOP
          
            FOR EACH_ACC IN UPDATE_LINEACC_UTIL_EL LOOP
            
              DBG('Icpks_test--->Going to call function elpks_facility_service.fn_calc_eff_line_amt');
            
              L_EFF_LIMIT_AMT := ELPKS_FACILITY_SERVICE.FN_CALC_EFF_LINE_AMT(EACH_ACC.LMT_AMT_BASIS,
                                                                             EACH_ACC.LIMIT_AMOUNT,
                                                                             EACH_ACC.TRANSFER_AMOUNT,
                                                                             EACH_ACC.COLLATERAL_CONTRIBUTION);
              BEGIN
                DBG('Icpks_test--->Going to insert into lmtb_lineacc_util');
                INSERT INTO LMTB_LINEACC_UTIL
                  (BRN,
                   ACC,
                   LIABILITY_ID,
                   LINE_ID,
                   APPL_DT,
                   LIMIT_AMOUNT,
                   EFF_LIMIT_AMT,
                   UTILIZATION,
                   MATURED_AMT,
                   EXPIRY_DATE)
                VALUES
                  (P_BRN,
                   EACH_ACC.INTEREST_CALC_ACC,
                   EACH_ACC.LIAB_ID,
                   EACH_ACC.LINE_CD,
                   
                   L_DATE,
                   EACH_ACC.LIMIT_AMOUNT,
                   L_EFF_LIMIT_AMT,
                   EACH_ACC.UTILISATION,
                   EACH_ACC.MATURED_UTIL,
                   EACH_ACC.LINE_EXPIRY_DATE);
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  DBG('Icpks_test-->In DUP_VAL_ON_INDEX while inserting into lmtb_lineacc_util.May be a case of rerun');
                  NULL;
              END;
            END LOOP;
            L_DATE := L_DATE + 1;
          END LOOP;
          RETURN TRUE;
        
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Icpks_test--->In when others of function fn_update_lmtb_lineacc_util');
            DBG('Icpks_test--->Oracle exception is :' || SQLERRM);
            RETURN FALSE;
        END;
      ELSE
        DBG('Webservice has to be inserted here');
      END IF;
    
    END IF;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Icpks_test--->In when others of function fn_update_lmtb_lineacc_util');
      DBG('Icpks_test--->Oracle exception is :' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_LMTB_LINEACC_UTIL;

  FUNCTION FN_IC_JOBS(P_BRN IN STTMS_BRANCH.BRANCH_CODE%TYPE) RETURN INTEGER AS
    L_WHAT       VARCHAR2(255);
    J            NUMBER;
    L_JOB_NAME   USER_SCHEDULER_JOBS.JOB_NAME%TYPE;
    L_CNT_FAILED NUMBER := 0;
    CURSOR C_JOB IS
    
      SELECT 1
        FROM ICTB_JOB_CTL
       WHERE UPPER(WHAT) LIKE '%ICPKS_TEST.PR_IC_JOB_SEQ%'
         AND BRN = P_BRN
            
         AND STATUS IS NULL;
  
    RETSTAT INTEGER;
    P_STMT  VARCHAR2(1000);
  BEGIN
    DBG('In main job func');
    DELETE ICTB_JOB_CTL
    
     WHERE BRN = P_BRN
       AND UPPER(WHAT) LIKE '%ICPKS_TEST.PR_IC_JOB_SEQ%';
  
    COMMIT;
  
    FOR I IN 1 .. ICPKS_TEST.P_IC_MAX_PROCESS
    
     LOOP
    
      L_WHAT := 'BEGIN' || CHR(10);
      L_WHAT := L_WHAT || 'icpks_test.pr_ic_job_seq (' || CHR(39) || P_BRN ||
                CHR(39) || ',' || I || ');' || CHR(10);
      L_WHAT := L_WHAT || 'debug.pr_close_db;' || CHR(10);
      L_WHAT := L_WHAT || 'END;' || CHR(10);
    
      SELECT SYS_CONTEXT('USERENV', 'INSTANCE') INTO L_INSTANCE FROM DUAL;
    
      L_JOB_NAME := 'P_' || I ||
                    TO_CHAR(GLOBAL.APPLICATION_DATE, 'DDMMRRRR') ||
                    TO_CHAR(SYSDATE, 'HH24MISS') || 'IC' || P_BRN;
      DBG('The Job Name For IC_JOBS is ' || L_JOB_NAME);
    
      INSERT INTO ICTB_JOB_CTL
        (BRN, PROCESS, JOB, STATUS, START_TIME, WHAT, SEQ_NO)
      VALUES
        (P_BRN,
         I,
         
         L_JOB_NAME,
         NULL,
         SYSDATE,
         L_WHAT,
         TRSQ_JOB_SEQ.NEXTVAL);
      COMMIT;
    
      DBMS_SCHEDULER.CREATE_JOB(JOB_NAME   => L_JOB_NAME,
                                JOB_TYPE   => 'PLSQL_BLOCK',
                                JOB_ACTION => L_WHAT,
                                
                                REPEAT_INTERVAL => NULL,
                                ENABLED         => FALSE,
                                COMMENTS        => 'IC_JOBS');
    
      DBMS_SCHEDULER.SET_ATTRIBUTE(NAME      => L_JOB_NAME,
                                   ATTRIBUTE => 'instance_id',
                                   VALUE     => L_INSTANCE);
      DBMS_SCHEDULER.ENABLE(L_JOB_NAME);
    
      DBG('l_what ' || L_WHAT);
    
    END LOOP;
    LOOP
      DBG('Looping for finish');
      DBMS_LOCK.SLEEP(30);
      OPEN C_JOB;
      FETCH C_JOB
        INTO J;
      IF C_JOB%NOTFOUND THEN
        J := 0;
      END IF;
      CLOSE C_JOB;
      EXIT WHEN J = 0;
    END LOOP;
    DBG('All Done');
  
    SELECT COUNT(1)
      INTO L_CNT_FAILED
      FROM ICTB_JOB_CTL
     WHERE BRN = P_BRN
       AND UPPER(WHAT) LIKE '%ICPKS_TEST.PR_IC_JOB_SEQ%'
       AND STATUS < 0;
    IF L_CNT_FAILED > 0 THEN
      RETURN - 1;
    ELSE
      RETURN 0;
    END IF;
  
  END FN_IC_JOBS;
  PROCEDURE PR_IC_JOB_SEQ(P_BRN IN STTMS_BRANCH.BRANCH_CODE%TYPE,
                          P_SEQ IN NUMBER) IS
    RETSTAT INTEGER;
  
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
    L_FN_CALL_ID            NUMBER;
  
  BEGIN
    DEBUG.PR_CLOSE;
  
    GLOBAL.PR_INIT(P_BRN);
    DEBUG.PR_SET_ASYNC_REF('ICEOD_' || P_BRN || '_' || P_SEQ || '_' ||
                           TO_CHAR(GLOBAL.APPLICATION_DATE, 'DDMMRRRR') ||
                           GLOBAL.BRANCH_STATUS);
  
    GLOBAL.SET_FUNC_TYPE('B');
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      ICPKS_TEST_CLUSTER.PR_IC_JOB_SEQ(P_BRN,
                                       P_SEQ,
                                       L_FN_CALL_ID,
                                       L_TB_CLUSTER_DATA);
    END IF;
  
    ICPKS_PARTITION_INFO.G_THIS_PART := P_SEQ;
  
    DBG('IC PARALLEL STREAMING ::icpks_test.p_ic_max_process' ||
        ICPKS_TEST.P_IC_MAX_PROCESS);
    BEGIN
      SELECT NVL(NUM_PROCESS, 1)
        INTO P_IC_MAX_PROCESS
        FROM ICTMS_BRANCH_PARAMETERS
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Exception in selecting IC branch parameter for branch:' ||
            GLOBAL.CURRENT_BRANCH || 'Error:' || SQLERRM);
    END;
    DBG('IC PARALLEL STREAMING :::icpks_test.p_ic_max_process' ||
        ICPKS_TEST.P_IC_MAX_PROCESS);
  
    RETSTAT := ICPKSS_TEST.FN_ICEOD_WRAP(P_BRN, 'N', P_SEQ, 'O');
  
    IF RETSTAT < 0 THEN
      ROLLBACK;
    END IF;
  
    UPDATE ICTB_JOB_CTL
       SET STATUS = RETSTAT, END_TIME = SYSDATE
     WHERE BRN = P_BRN
       AND UPPER(WHAT) LIKE '%ICPKS_TEST.PR_IC_JOB_SEQ%'
       AND PROCESS = P_SEQ;
    DBG('Done for ' || P_SEQ);
    COMMIT;
  END PR_IC_JOB_SEQ;

  PROCEDURE PR_IC_EOD(P_BRANCH IN VARCHAR2, P_ERRCODE IN OUT VARCHAR2) IS
  
    ONL_UPD STTMS_BANK.ONLINE_GL_UPDATE%TYPE;
  
    EOD_STAT STTMS_BRANCH.END_OF_INPUT%TYPE := '*';
  
    J               INTEGER;
    I               INTEGER;
    PERRCODE        VARCHAR2(100);
    MAINT_ERR_CODE  VARCHAR2(100);
    MAINT_ERR_PARAM VARCHAR2(100);
  
    L_OPER VARCHAR2(1);
  
    L_COUNT NUMBER;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
    CURSOR C_REJ_CHQ IS
      SELECT M.*
        FROM CSTB_CLEARING_MASTER M
       WHERE M.ACC_BRANCH = P_BRANCH
         AND M.REFERENCE_NO IN
             (SELECT N.REFERENCE_NO
                FROM CGTB_MODULE_CHQ_STATUS N
               WHERE N.ACC_BRANCH = M.ACC_BRANCH
                 AND N.MODULE_CODE = 'TD'
                 AND N.STATUS = 'R'
                 AND NVL(N.RETN_NOTIFIED_TO_MODULE, 'N') <> 'Y');
    L_TY_REJ_CHK ICPKS_BOD.TY_REJ_CHK;
    P_ERRMSG     VARCHAR2(1000) := NULL;
  
    L_ERR_CODE  ERTBS_MSGS.ERR_CODE%TYPE;
    L_ERR_PARAM VARCHAR2(250);
  
  BEGIN
    DBG('Inside icpks_test.pr_ic_eod');
  
    IF NOT GLOBALS_FRC.FN_GET_BRN_REC_WRP(GLOBAL.CURRENT_BRANCH,
                                          L_ERR_CODE,
                                          L_ERR_PARAM) THEN
      DEBUG.PR_DEBUG('AC', 'Failed in the FRC function..');
    ELSE
      DEBUG.PR_DEBUG('AC', 'Success from FRC..');
    END IF;
  
    EOD_STAT := GLOBALS_FRC.G_TBL_STTM_BRANCH_REC.END_OF_INPUT;
  
    DBG('End of Input status' || EOD_STAT);
  
    IF EOD_STAT <> 'B' THEN
      DBG('If not BOD stage update ICEOD STATUS');
      UPDATE STTMS_BRANCH
         SET ICEOD_STATUS = 'Y'
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
      COMMIT;
    END IF;
  
    BEGIN
      SELECT NVL(NUM_PROCESS, 1)
        INTO P_IC_MAX_PROCESS
        FROM ICTMS_BRANCH_PARAMETERS
       WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Exception in selecting IC branch parameter for branch:' ||
            GLOBAL.CURRENT_BRANCH || 'Error:' || SQLERRM);
    END;
    DBG('Value of l_ic_max_process is ' || P_IC_MAX_PROCESS);
  
    DBG('eod_stat 2' || EOD_STAT);
    IF EOD_STAT = 'B' THEN
      DBG('if bod then call ic functions');
    
      IF ICPKS_TEST.P_IC_MAX_PROCESS > 1 THEN
        J := ICPKSS_BOD.FN_IC_JOBS(GLOBAL.CURRENT_BRANCH);
      ELSE
      
        J := ICPKSS_BOD.ICFN_BOD(GLOBAL.CURRENT_BRANCH,
                                 GLOBAL.APPLICATION_DATE,
                                 1);
      END IF;
      IF J = -1 THEN
        P_ERRCODE := 'IC-BOD004';
      ELSIF J = -4 THEN
        P_ERRCODE := 'IC-BOD015';
      ELSIF J = -5 THEN
        P_ERRCODE := 'IC-ED0010';
      ELSIF J = 1 THEN
      
        P_ERRCODE := '';
      ELSIF J = 0 THEN
      
        P_ERRCODE := '';
      END IF;
    END IF;
    IF EOD_STAT = 'T' THEN
    
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT
          FROM CSTM_ACCT_TRFR_MASTER A
         WHERE A.BRANCH_CODE = P_BRANCH
           AND NOT EXISTS
         (SELECT 1
                  FROM CSTMS_BRANCH_TRFR_PARAM B
                 WHERE A.BRANCH_CODE = B.BRANCH_CODE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Unable to get account/branch transfer data due to ' ||
              SQLERRM);
          L_COUNT := 0;
      END;
    
      IF L_COUNT > 0 THEN
        DBG('Branch transfere parameter not maintained for the branch ' ||
            P_BRANCH);
        P_ERRCODE := 'CS-TRFR-02';
        RETURN;
      END IF;
    
      DBG('if EOTI then call ic functions');
    
      BEGIN
        SELECT COUNT(*) INTO L_COUNT FROM EITBS_RUNNING_PROGRAMS;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in getting count from eitbs_running_programs');
          L_COUNT := 0;
      END;
      IF L_COUNT > 0 THEN
        DBG('ICEOD cannot be started ,some Batch processes still running.');
        P_ERRCODE := 'IC-ED0005';
      
        RETURN;
      END IF;
    
      IF C_REJ_CHQ%ISOPEN THEN
        CLOSE C_REJ_CHQ;
      END IF;
    
      OPEN C_REJ_CHQ;
      FETCH C_REJ_CHQ BULK COLLECT
        INTO L_TY_REJ_CHK;
      CLOSE C_REJ_CHQ;
      DBG('l_ty_rej_chk.count-->' || L_TY_REJ_CHK.COUNT);
      IF L_TY_REJ_CHK.COUNT > 0 THEN
        DBG('calling fn_rev_td_chq_txn');
        IF NOT ICPKS_BOD.FN_REV_TD_CHQ_TXN(P_BRANCH,
                                           L_TY_REJ_CHK,
                                           P_ERRCODE,
                                           P_ERRMSG) THEN
          DBG('Failed in fn_rev_td_chq_txn');
        END IF;
      END IF;
    
      IF NOT STPKS_STDTDTOP_UTILS.FN_REPICKUP_RATES(GLOBAL.CURRENT_BRANCH) THEN
        DBG('Failed in stpks_stdtdtop_utils.fn_Repickup_Rates');
      END IF;
    
      IF ICPKS_TEST.P_IC_MAX_PROCESS > 1
      
       THEN
      
        DELETE FROM ICTB_JOB_CTL
         WHERE BRN = GLOBAL.CURRENT_BRANCH
           AND START_TIME IS NOT NULL;
        COMMIT;
      
        DBG('Calling acpkss_eod.fn_mark_dormancy_new for ' ||
            GLOBAL.CURRENT_BRANCH || '~' || GLOBAL.APPLICATION_DATE);
        IF NOT ACPKS_EOD.FN_MARK_DORMANCY_NEW(GLOBAL.CURRENT_BRANCH,
                                              GLOBAL.APPLICATION_DATE,
                                              PERRCODE) THEN
          P_ERRCODE := 'IC-ED0001';
          RETURN;
        END IF;
        DBG('After dormancy updation');
      
        DBG('Calling icpkss_resolve_maint.fn_resolve_brn');
        IF NOT ICPKSS_RESOLVE_MAINT.FN_RESOLVE_BRN(GLOBAL.CURRENT_BRANCH,
                                                   MAINT_ERR_CODE,
                                                   MAINT_ERR_PARAM) THEN
          DBG('maintenance Resolution gave error ' || MAINT_ERR_CODE || '~' ||
              MAINT_ERR_PARAM);
          P_ERRCODE := 'IC-ED0001';
          RETURN;
        
        END IF;
        DBG('After maintenance resolution');
        DBG('Calling icpkss_ude.pr_make_ude_row');
      
        IF NOT ICPKSS_TEST.FN_MARK_BKCALC_FOR_UDEVALS(P_BRANCH) THEN
          P_ERRCODE := 'IC-ED0001';
          RETURN;
        END IF;
      
        DBG('special condition opulation through');
      
        I := ICPKSS_TEST.FN_IC_JOBS(GLOBAL.CURRENT_BRANCH);
      ELSE
        I := ICPKSS_TEST.FN_ICEOD_WRAP(GLOBAL.CURRENT_BRANCH, 'N', 1, 'O');
      END IF;
    
      IF EOD_STAT <> 'N' THEN
        IF I >= 0 THEN
          DBG('Before calling fn_prod_accr_acctng');
          J := FN_PROD_ACCR_ACCTNG(P_BRANCH);
          DBG('after fn_prod_accr_acctng-->' || J);
        END IF;
      END IF;
    
      IF NOT STPKS_STDTDTOP_UTILS.FN_CALC_MATAMT_BULK(GLOBAL.CURRENT_BRANCH) THEN
        DBG('Failed in stpks_stdtdtop_utils.fn_Repickup_Rates');
      END IF;
    
      IF (I = -1) OR (J = -1) THEN
        P_ERRCODE := 'IC-ED0001';
      
      ELSIF I = -2 THEN
        P_ERRCODE := 'IC-ED0002';
      ELSIF I = -3 THEN
        P_ERRCODE := 'IC-ED0003';
      ELSIF I = -4 THEN
      
        P_ERRCODE := 'IC-ED0006';
      ELSIF I = -5 THEN
      
        P_ERRCODE := 'IC-ED0010';
      
      ELSIF I = -6 THEN
        P_ERRCODE := 'IL-BCH-098';
      ELSIF I = -7 THEN
        P_ERRCODE := 'IL-BCH-099';
      
      ELSIF I = 1 THEN
      
        P_ERRCODE := '';
      ELSIF I = 0 THEN
        P_ERRCODE := '';
      END IF;
    
      IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
         (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
        L_FN_CALL_ID      := 1;
        L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
      
        ICPKS_TEST_CLUSTER.PR_IC_EOD(P_BRANCH,
                                     P_ERRCODE,
                                     L_FN_CALL_ID,
                                     L_TB_CLUSTER_DATA);
      
      END IF;
    
    END IF;
  
    DBG('coming out of loop:::Update sttm_branch');
    UPDATE STTMS_BRANCH
       SET ICEOD_STATUS = 'N'
     WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    DBG('Returning successfully from pr_ic_eod');
    RETURN;
  END PR_IC_EOD;

  PROCEDURE PR_HANDOOF_MT935 IS
    CURSOR CR_AC_RCA(P_TODAY STTMS_DATES.TODAY%TYPE) IS
      SELECT DISTINCT SUBSTR(R.COND_KEY, 4) ACC,
                      R.UDE_EFF_DT UDE_EFF_DT,
                      R.UDE_VAL_LIST UDE_VAL_LIST,
                      S.CUST_NO,
                      SUBSTR(R.COND_KEY, 1, 3) BRN,
                      R.PROD
        FROM CSTMS_PRODUCT_EVENT_ADVICE E,
             ICTB_UDEVAL_ROW            R
             
            ,
             STTMS_CUST_ACCOUNT S
       WHERE SUBSTR(R.COND_KEY, 1, 3) = GLOBAL.CURRENT_BRANCH
         AND SUBSTR(R.COND_KEY, 4) = S.CUST_AC_NO
         AND S.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
            
         AND R.UDE_EFF_DT >= P_TODAY
         AND E.PRODUCT_CODE = R.PROD
         AND E.EVENT_CODE = 'UDCH'
         AND E.MSG_TYPE = 'RTCHG_ADVICE'
         AND NVL(E.SUPPRESS, 'N') = 'N'
            
         AND S.CUST_NO = (SELECT CUSTOMER_NO
                            FROM STTMS_CUSTOMER
                           WHERE LOCAL_BRANCH = GLOBAL.CURRENT_BRANCH
                             AND CUSTOMER_NO = S.CUST_NO)
         AND S.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
       ORDER BY R.UDE_EFF_DT;
  
    CURSOR CR_BACKDATED_RCA(P_TODAY STTMS_DATES.TODAY%TYPE) IS
      SELECT DISTINCT R.ACC        ACC,
                      R.UDE_EFF_DT UDE_EFF_DT,
                      R.UDE_VALUE  UDE_VAL,
                      S.CUST_NO    CUST_NO,
                      R.BRN        BRN,
                      R.PROD       PROD,
                      R.UDE_ID     UDE_ID,
                      R.RATE_CODE  RATE_CODE
        FROM CSTMS_PRODUCT_EVENT_ADVICE E,
             ICTMS_ACC_UDEVALS          R
             
            ,
             STTMS_CUST_ACCOUNT S
       WHERE R.BRN = GLOBAL.CURRENT_BRANCH
         AND R.ACC = S.CUST_AC_NO
         AND S.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
            
         AND R.UDE_EFF_DT < P_TODAY
         AND E.PRODUCT_CODE = R.PROD
         AND E.EVENT_CODE = 'UDCH'
         AND E.MSG_TYPE = 'RTCHG_ADVICE'
         AND NVL(E.SUPPRESS, 'N') = 'N'
         AND S.CUST_NO = (SELECT CUSTOMER_NO
                            FROM STTMS_CUSTOMER
                           WHERE LOCAL_BRANCH = GLOBAL.CURRENT_BRANCH
                             AND CUSTOMER_NO = S.CUST_NO)
         AND S.BRANCH_CODE = GLOBAL.CURRENT_BRANCH
            
         AND R.UDE_EFF_DT = (SELECT MAX(UDE_EFF_DT)
                               FROM ICTMS_ACC_UDEVALS
                              WHERE BRN = GLOBAL.CURRENT_BRANCH
                                AND ACC = S.CUST_AC_NO
                                AND PROD = R.PROD
                                   
                                AND UDE_EFF_DT < P_TODAY);
  
    CURSOR CR_ACC_RCA(P_TODAY STTMS_DATES.TODAY%TYPE) IS
      SELECT DISTINCT P.BRN,
                      P.PROD,
                      P.ACC,
                      A.CUST_NO,
                      TO_DATE(CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4)) UDE_EFF_DT
        FROM (SELECT *
                FROM ICTBS_ACTION_LOG
               WHERE TBL_NAME = 'ICTMS_PR_INT_EFFDT') L,
             STTMS_CUST_ACCOUNT A,
             CSTMS_PRODUCT_EVENT_ADVICE E,
             ICTBS_ACC_PR P
       WHERE P.BRN = GLOBAL.CURRENT_BRANCH
         AND P.BRN = A.BRANCH_CODE
         AND P.ACC = A.CUST_AC_NO
         AND P.PROD = L.PROD
         AND NVL(P.STOP_IC, 'N') = 'N'
         AND L.BRN_DATE = P_TODAY
         AND CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4) >= P.GC_MAP_DT
         AND CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 3) = P.CCY
         AND L.ACTION = 'L'
         AND E.PRODUCT_CODE = P.PROD
         AND E.EVENT_CODE = 'UDCH'
         AND E.MSG_TYPE = 'RTCHG_ADVICE'
         AND NVL(E.SUPPRESS, 'N') = 'N'
      UNION ALL
      SELECT DISTINCT P.BRN,
                      P.PROD,
                      P.ACC,
                      A.CUST_NO,
                      TO_DATE(CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4)) UDE_EFF_DT
        FROM ICTBS_ACTION_LOG           L,
             STTMS_CUST_ACCOUNT         A,
             CSTMS_PRODUCT_EVENT_ADVICE E,
             ICTMS_ACC_PR               P
       WHERE P.BRN = GLOBAL.CURRENT_BRANCH
         AND P.ACC = A.CUST_AC_NO
         AND P.PROD = L.PROD
         AND NVL(P.GEN_UCA, 'N') = 'Y'
         AND L.TBL_NAME = 'ICTMS_PR_INT_EFFDT'
         AND L.BRN_DATE = P_TODAY
         AND L.ACTION = 'L'
         AND E.PRODUCT_CODE = P.PROD
         AND E.EVENT_CODE = 'UDCH'
         AND E.MSG_TYPE = 'RTCHG_ADVICE'
         AND NVL(E.SUPPRESS, 'N') = 'N'
         AND A.RECORD_STAT = 'O'
         AND TO_DATE(CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4)) = P_TODAY
      UNION ALL
      SELECT DISTINCT P.BRN,
                      P.PROD,
                      A.CUST_AC_NO,
                      A.CUST_NO,
                      TO_DATE(CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4)) UDE_EFF_DT
        FROM ICTBS_ACTION_LOG           L,
             STTMS_CUST_ACCOUNT         A,
             CSTMS_PRODUCT_EVENT_ADVICE E,
             ICTBS_ACC_PR               P,
             ICTB_ACC_SYS_MAP           Q
       WHERE P.BRN = GLOBAL.CURRENT_BRANCH
         AND P.ACC = Q.POOL_SYSTEM_AC_NO
         AND Q.AC_TYPE <> 'P'
         AND Q.CUST_AC_NO = A.CUST_AC_NO
         AND P.PROD = L.PROD
         AND NVL(P.STOP_IC, 'N') = 'N'
         AND L.TBL_NAME = 'ICTMS_PR_INT_EFFDT'
         AND L.BRN_DATE = P_TODAY
         AND CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4) >= P.GC_MAP_DT
         AND CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 3) = P.CCY
         AND L.ACTION = 'L'
         AND E.PRODUCT_CODE = P.PROD
         AND E.EVENT_CODE = 'UDCH'
         AND E.MSG_TYPE = 'RTCHG_ADVICE'
         AND NVL(E.SUPPRESS, 'N') = 'N'
         AND A.RECORD_STAT = 'O'
         AND TO_DATE(CSPKES_MISC.FN_GETPARAM(L.KEY_VAL, 4)) = P_TODAY;
  
    L_GEN_UCA           VARCHAR2(1);
    MSG_HANDOFF_REC     MSTBS_MSG_HANDOFF%ROWTYPE;
    BOOL                BOOLEAN;
    BAD_DCNS            VARCHAR2(200);
    LDCN                MSTBS_DLY_MSG_OUT.DCN%TYPE;
    LSERNO              VARCHAR2(4);
    ERR_CODE            ERTBS_MSGS.ERR_CODE%TYPE;
    P_TODAY             STTMS_DATES.TODAY%TYPE;
    L_RETURN            VARCHAR2(2000);
    L_UDE_ID            VARCHAR2(50);
    I                   NUMBER;
    J                   NUMBER;
    L_COUNT             NUMBER;
    L_UDE_TYPE          ICTMS_RULE_UDE.UDE_TYPE%TYPE;
    L_RATE              NUMBER(24, 5);
    L_CUST_COUNT        NUMBER := 0;
    L_PREV_VALUE        NUMBER(24, 7);
    L_CHANGE_BOOL       BOOLEAN := FALSE;
    L_GEN_UDE_VAL       NUMBER(24, 5);
    L_RATE_CODE         VARCHAR2(10);
    L_ACC_CLASS         STTMS_ACCOUNT_CLASS.ACCOUNT_CLASS%TYPE;
    L_CCY               STTMS_CUST_ACCOUNT.CCY%TYPE;
    L_REC_LEVY_EFF_RATE NUMBER(24, 5);
    L_DR_UDE_VALUE      NUMBER(24, 5);
    L_GEN_COUNT         NUMBER := 0;
    L_FLOAT_RATE        ICTMS_ACC_UDEVALS.RATE_CODE%TYPE;
    L_REPOP_AT_LIQ      ICTMS_PR_INT_ACLASS.REPOP_AT_LIQ%TYPE := 'N';
    V_UDE_VAL_LIST      ICTBS_UDEVAL_ROW.UDE_VAL_LIST%TYPE;
    L_RETURN_POP        VARCHAR2(2000);
    L_UDE_ID_POP        VARCHAR2(50);
    L_RATE_POP          NUMBER(24, 5);
    L_POP_PROCD         BOOLEAN := FALSE;
    V_UDE_EFF_DT        DATE;
    L_COMM_DT           DATE;
    L_NEXT_WORKING_DATE DATE;
    L_WORK_PARAM        ICTMS_BRANCH_PARAMETERS.PROCESS_TILL%TYPE;
    L_AC_OPEN_DATE      DATE;
  
    L_FN_CALL_ID            NUMBER;
    L_TB_CLUSTER_DATA       GLOBAL.TY_TB_CLUSTER_DATA;
    L_TB_CLUSTER_DATA_EMPTY GLOBAL.TY_TB_CLUSTER_DATA;
  
  BEGIN
  
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE IN
       (CSPKS_REQ_GLOBAL.P_CLUSTER, CSPKS_REQ_GLOBAL.P_CUSTOM) THEN
      L_FN_CALL_ID      := 1;
      L_TB_CLUSTER_DATA := L_TB_CLUSTER_DATA_EMPTY;
    
      ICPKS_TEST_CLUSTER.PR_HANDOOF_MT935(L_FN_CALL_ID, L_TB_CLUSTER_DATA);
    END IF;
    IF NOT GLOBAL.G_SKIP_KERNEL THEN
    
      DBG('inside the procedure pr_handoof_mt935-->' ||
          GLOBAL.PROCESS_DATE || GLOBAL.CURRENT_BRANCH);
    
      P_TODAY := GLOBAL.PROCESS_DATE;
    
      DBG('todays date is-->' || P_TODAY);
      FOR C1 IN CR_AC_RCA(P_TODAY) LOOP
        BEGIN
          DBG('inside the procedure pr_handoof_mt935 c1.brn-->' || C1.BRN);
          DBG('inside the procedure pr_handoof_mt935 c1.acc-->' || C1.ACC);
          DBG('inside the procedure pr_handoof_mt935 c1.prod-->' ||
              C1.PROD);
          DBG('c1.cust_no here coming is-->' || C1.CUST_NO);
          SELECT NVL(A.GEN_UCA, 'N')
            INTO L_GEN_UCA
            FROM ICTMS_ACC_PR A
           WHERE A.BRN = C1.BRN
             AND A.ACC = C1.ACC
             AND A.PROD = C1.PROD
             AND A.WAIVE = 'N'
             AND A.RECORD_STAT = 'O';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('when oters selecting l_gen_uca-->' || SQLERRM);
            L_GEN_UCA := 'N';
        END;
        DBG('inside the procedure pr_handoof_mt935 l_gen_uca-->' ||
            L_GEN_UCA);
        IF L_GEN_UCA = 'Y' THEN
          I            := 1;
          J            := 1;
          L_COUNT      := 0;
          L_CUST_COUNT := 0;
          LOOP
            L_RETURN := CSPKES_MISC.FN_GETPARAM(C1.UDE_VAL_LIST, I, '~');
            DBG('l_return-->' || L_RETURN);
            IF L_RETURN = 'EOPL' THEN
              DBG('exiting');
              EXIT;
            END IF;
            DBG('l_ude_id-->' || L_UDE_ID);
            L_UDE_ID := SUBSTR(L_RETURN, 1, INSTR(L_RETURN, '|') - 1);
            DBG('l_ude_id-->' || L_UDE_ID);
            L_RATE := SUBSTR(L_RETURN, INSTR(L_RETURN, '|') + 1);
            DBG('l_rate-->' || L_RATE);
            DBG('l_count-->' || L_COUNT);
            SELECT NVL(UDE_TYPE, 'W')
              INTO L_UDE_TYPE
              FROM ICTMS_RULE_UDE
             WHERE RULE_ID = (SELECT RULE
                                FROM ICTMS_PR_INT
                               WHERE PRODUCT_CODE = C1.PROD)
               AND UDE_ID = L_UDE_ID;
            DBG('l_ude_type-->' || L_UDE_TYPE);
            DBG('c1.ude_eff_dt is-->' || C1.UDE_EFF_DT);
          
            BEGIN
              SELECT REPOP_AT_LIQ
                INTO L_REPOP_AT_LIQ
                FROM ICTMS_PR_INT_ACLASS
               WHERE PRODUCT_CODE = C1.PROD
                 AND ACLASS =
                     (SELECT ACCOUNT_CLASS
                        FROM STTMS_CUST_ACCOUNT
                       WHERE CUST_AC_NO = C1.ACC
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH)
                 AND CCY =
                     (SELECT CCY
                        FROM STTMS_CUST_ACCOUNT
                       WHERE CUST_AC_NO = C1.ACC
                         AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH);
            EXCEPTION
              WHEN OTHERS THEN
                DBG('inisde when others while selecting repop_at_liq-->' ||
                    SQLERRM);
                L_REPOP_AT_LIQ := 'N';
            END;
          
            DBG('re pop at liquidation is-->' || L_REPOP_AT_LIQ);
            L_CHANGE_BOOL := FALSE;
            IF L_UDE_TYPE = 'R' THEN
              IF NVL(L_REPOP_AT_LIQ, 'N') <> 'Y' THEN
                DBG('this is not the case of re populate at liquidation');
                BEGIN
                  DBG('going to select from sttms_cust_account');
                  SELECT ACCOUNT_CLASS, CCY
                    INTO L_ACC_CLASS, L_CCY
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = C1.ACC
                     AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
                  DBG('account class is-->' || L_ACC_CLASS);
                  DBG('account currency is-->' || L_CCY);
                
                  BEGIN
                    DBG('before selecting l_gen_ude_val and l_rate_code-->' ||
                        L_UDE_ID || '-->' || C1.UDE_EFF_DT);
                    SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                      INTO L_GEN_UDE_VAL, L_RATE_CODE
                      FROM ICTMS_PR_INT_UDEVALS
                     WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                       AND ACLASS = L_ACC_CLASS
                       AND CCY_CODE = L_CCY
                       AND PRODUCT_CODE =
                           (SELECT PRODUCT_CODE
                              FROM ICTMS_PR_INT_ACLASS
                             WHERE ACLASS = L_ACC_CLASS
                               AND CCY = L_CCY)
                       AND UDE_ID = L_UDE_ID
                       AND UDE_EFF_DT =
                           (SELECT MAX(UDE_EFF_DT)
                              FROM ICTMS_PR_INT_UDEVALS
                             WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                               AND ACLASS = L_ACC_CLASS
                               AND CCY_CODE = L_CCY
                               AND PRODUCT_CODE =
                                   (SELECT PRODUCT_CODE
                                      FROM ICTMS_PR_INT_ACLASS
                                     WHERE ACLASS = L_ACC_CLASS
                                       AND CCY = L_CCY)
                               AND UDE_ID = L_UDE_ID
                               AND UDE_EFF_DT <= C1.UDE_EFF_DT);
                    DBG('  l_gen_ude_val is-->' || L_GEN_UDE_VAL);
                    DBG(' l_rate_code -->' || L_RATE_CODE);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DBG('inside no data found so checking the maintenance for all l_ude_id-->' ||
                          L_UDE_ID || '-->' || C1.UDE_EFF_DT);
                      SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                        INTO L_GEN_UDE_VAL, L_RATE_CODE
                        FROM ICTMS_PR_INT_UDEVALS
                       WHERE BRANCH_CODE = 'ALL'
                         AND ACLASS = L_ACC_CLASS
                         AND CCY_CODE = L_CCY
                         AND PRODUCT_CODE =
                             (SELECT PRODUCT_CODE
                                FROM ICTMS_PR_INT_ACLASS
                               WHERE ACLASS = L_ACC_CLASS
                                 AND CCY = L_CCY)
                         AND UDE_ID = L_UDE_ID
                         AND UDE_EFF_DT =
                             (SELECT MAX(UDE_EFF_DT)
                                FROM ICTMS_PR_INT_UDEVALS
                               WHERE BRANCH_CODE = 'ALL'
                                 AND ACLASS = L_ACC_CLASS
                                 AND CCY_CODE = L_CCY
                                 AND PRODUCT_CODE =
                                     (SELECT PRODUCT_CODE
                                        FROM ICTMS_PR_INT_ACLASS
                                       WHERE ACLASS = L_ACC_CLASS
                                         AND CCY = L_CCY)
                                 AND UDE_ID = L_UDE_ID
                                 AND UDE_EFF_DT <= C1.UDE_EFF_DT);
                      DBG('now the l_gen_ude_val is-->' || L_GEN_UDE_VAL);
                      DBG('now the l_rate_code is-->' || L_RATE_CODE);
                    WHEN OTHERS THEN
                      DBG('inside whn others of selecting ude value-->' ||
                          SQLERRM);
                    
                  END;
                  IF NVL(L_RATE_CODE, 'XXX') = 'XXX' THEN
                    DBG('ude value is there');
                    L_REC_LEVY_EFF_RATE := L_GEN_UDE_VAL;
                  ELSE
                    DBG('rate code is der ofr ude value');
                    SELECT RATE + NVL(L_GEN_UDE_VAL, 0)
                    
                      INTO L_REC_LEVY_EFF_RATE
                      FROM ICTMS_RATES
                     WHERE RATE_CODE = L_RATE_CODE
                       AND CCY_CODE = L_CCY
                       AND RECORD_STAT = 'O'
                       AND AUTH_STAT = 'A'
                       AND EFF_DT = (SELECT MAX(EFF_DT)
                                       FROM ICTMS_RATES
                                      WHERE RATE_CODE = L_RATE_CODE
                                        AND CCY_CODE = L_CCY
                                        AND RECORD_STAT = 'O'
                                        AND AUTH_STAT = 'A'
                                        AND EFF_DT <= P_TODAY);
                    DBG('after the select of rate code-->' ||
                        L_REC_LEVY_EFF_RATE);
                  END IF;
                
                  DBG('here the rate is-->' || L_REC_LEVY_EFF_RATE);
                  DBG('here the special rate is-->' || L_RATE);
                  IF L_REC_LEVY_EFF_RATE <> L_RATE THEN
                    DBG('seems to be rate are changing');
                    L_COMM_DT := C1.UDE_EFF_DT;
                    DBG('after assinging te dates');
                    L_CHANGE_BOOL := TRUE;
                  ELSIF L_REC_LEVY_EFF_RATE = L_RATE THEN
                    DBG('seems to be rate is not changed');
                    L_CHANGE_BOOL := FALSE;
                  END IF;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('inisde no data found');
                    NULL;
                  WHEN OTHERS THEN
                    DBG('inisde when others while selecting from ICTMS_PR_INT_UDEVALS-->' ||
                        SQLERRM);
                    EXIT;
                END;
              
              ELSE
                DBG('this is the case of repopulate at liquidation-->' ||
                    GLOBAL.CURRENT_BRANCH || C1.ACC || '-->' || C1.PROD ||
                    '-->' || P_TODAY);
              
                BEGIN
                  SELECT AC_OPEN_DATE
                    INTO L_AC_OPEN_DATE
                    FROM STTMS_CUST_ACCOUNT
                   WHERE CUST_AC_NO = C1.ACC
                     AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
                  DBG('the account opening date is-->' || L_AC_OPEN_DATE);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('unable to get the account opening date-->' ||
                        SQLERRM);
                    RETURN;
                END;
              
                IF L_AC_OPEN_DATE <> C1.UDE_EFF_DT THEN
                  DBG('account opening date is not today so can consider the case of repopulate');
                  BEGIN
                    SELECT UDE_VAL_LIST, UDE_EFF_DT
                      INTO V_UDE_VAL_LIST, V_UDE_EFF_DT
                      FROM ICTBS_UDEVAL_ROW
                     WHERE COND_KEY = GLOBAL.CURRENT_BRANCH || C1.ACC
                       AND COND_TYPE = '0'
                       AND PROD = C1.PROD
                       AND UDE_EFF_DT =
                           (SELECT MAX(UDE_EFF_DT)
                              FROM ICTBS_UDEVAL_ROW
                             WHERE COND_KEY =
                                   GLOBAL.CURRENT_BRANCH || C1.ACC
                               AND COND_TYPE = '0'
                               AND PROD = C1.PROD
                                  
                               AND UDE_EFF_DT < C1.UDE_EFF_DT);
                    L_POP_PROCD := TRUE;
                    DBG('v_ude_val_list coming here is-->' ||
                        V_UDE_VAL_LIST);
                    DBG('v_ude_eff_dt coming here is-->' || V_UDE_EFF_DT);
                  EXCEPTION
                  
                    WHEN NO_DATA_FOUND THEN
                      L_POP_PROCD := FALSE;
                      DBG('inside no data found so trying luck again ');
                      BEGIN
                        DBG('going to select from sttms_cust_account re pop at liquidation');
                        SELECT ACCOUNT_CLASS, CCY
                          INTO L_ACC_CLASS, L_CCY
                          FROM STTMS_CUST_ACCOUNT
                         WHERE CUST_AC_NO = C1.ACC
                           AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
                        DBG('account class is re pop at liquidation-->' ||
                            L_ACC_CLASS);
                        DBG('account currency is re pop at liquidation-->' ||
                            L_CCY);
                        BEGIN
                          DBG('before selecting l_gen_ude_val and l_rate_code re pop at liquidation-->' ||
                              L_UDE_ID || '-->' || C1.UDE_EFF_DT);
                          SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                            INTO L_GEN_UDE_VAL, L_RATE_CODE
                            FROM ICTMS_PR_INT_UDEVALS
                           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                             AND ACLASS = L_ACC_CLASS
                             AND CCY_CODE = L_CCY
                             AND PRODUCT_CODE =
                                 (SELECT PRODUCT_CODE
                                    FROM ICTMS_PR_INT_ACLASS
                                   WHERE ACLASS = L_ACC_CLASS
                                     AND CCY = L_CCY)
                             AND UDE_ID = L_UDE_ID
                             AND UDE_EFF_DT =
                                 (SELECT MAX(UDE_EFF_DT)
                                    FROM ICTMS_PR_INT_UDEVALS
                                   WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                                     AND ACLASS = L_ACC_CLASS
                                     AND CCY_CODE = L_CCY
                                     AND PRODUCT_CODE =
                                         (SELECT PRODUCT_CODE
                                            FROM ICTMS_PR_INT_ACLASS
                                           WHERE ACLASS = L_ACC_CLASS
                                             AND CCY = L_CCY)
                                     AND UDE_ID = L_UDE_ID
                                     AND UDE_EFF_DT <= C1.UDE_EFF_DT);
                          DBG('  l_gen_ude_val is re pop at liquidation-->' ||
                              L_GEN_UDE_VAL);
                          DBG(' l_rate_code re pop at liquidation-->' ||
                              L_RATE_CODE);
                        EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                            DBG('inside no data found so checking the maintenance for all l_ude_id re pop at liquidation-->' ||
                                L_UDE_ID || '-->' || C1.UDE_EFF_DT);
                            SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                              INTO L_GEN_UDE_VAL, L_RATE_CODE
                              FROM ICTMS_PR_INT_UDEVALS
                             WHERE BRANCH_CODE = 'ALL'
                               AND ACLASS = L_ACC_CLASS
                               AND CCY_CODE = L_CCY
                               AND PRODUCT_CODE =
                                   (SELECT PRODUCT_CODE
                                      FROM ICTMS_PR_INT_ACLASS
                                     WHERE ACLASS = L_ACC_CLASS
                                       AND CCY = L_CCY)
                               AND UDE_ID = L_UDE_ID
                               AND UDE_EFF_DT =
                                   (SELECT MAX(UDE_EFF_DT)
                                      FROM ICTMS_PR_INT_UDEVALS
                                     WHERE BRANCH_CODE = 'ALL'
                                       AND ACLASS = L_ACC_CLASS
                                       AND CCY_CODE = L_CCY
                                       AND PRODUCT_CODE =
                                           (SELECT PRODUCT_CODE
                                              FROM ICTMS_PR_INT_ACLASS
                                             WHERE ACLASS = L_ACC_CLASS
                                               AND CCY = L_CCY)
                                       AND UDE_ID = L_UDE_ID
                                       AND UDE_EFF_DT <= C1.UDE_EFF_DT);
                            DBG('now the l_gen_ude_val is re pop at liquidation-->' ||
                                L_GEN_UDE_VAL);
                            DBG('now the l_rate_code is re pop at liquidation-->' ||
                                L_RATE_CODE);
                          WHEN OTHERS THEN
                            DBG('inside whn others of selecting ude value re pop at liquidation-->' ||
                                SQLERRM);
                          
                        END;
                        IF NVL(L_RATE_CODE, 'XXX') = 'XXX' THEN
                          DBG('ude value is there re pop at liquidation');
                          L_REC_LEVY_EFF_RATE := L_GEN_UDE_VAL;
                        ELSE
                          DBG('rate code is der ofr ude value re pop at liquidation');
                          SELECT RATE + NVL(L_GEN_UDE_VAL, 0)
                          
                            INTO L_REC_LEVY_EFF_RATE
                            FROM ICTMS_RATES
                           WHERE RATE_CODE = L_RATE_CODE
                             AND CCY_CODE = L_CCY
                             AND RECORD_STAT = 'O'
                             AND AUTH_STAT = 'A'
                             AND EFF_DT =
                                 (SELECT MAX(EFF_DT)
                                    FROM ICTMS_RATES
                                   WHERE RATE_CODE = L_RATE_CODE
                                     AND CCY_CODE = L_CCY
                                     AND RECORD_STAT = 'O'
                                     AND AUTH_STAT = 'A'
                                     AND EFF_DT <= P_TODAY);
                          DBG('after the select of rate code re pop at liquidation-->' ||
                              L_REC_LEVY_EFF_RATE);
                        END IF;
                        DBG('here the rate is re pop at liquidation-->' ||
                            L_REC_LEVY_EFF_RATE);
                        DBG('here the special rate is re pop at liquidation-->' ||
                            L_RATE);
                        IF L_REC_LEVY_EFF_RATE <> L_RATE THEN
                          DBG('seems to be rate are changing re pop at liquidation');
                          L_COMM_DT := C1.UDE_EFF_DT;
                          DBG('after assinging te dates re pop at liquidation');
                          L_CHANGE_BOOL := TRUE;
                        ELSIF L_REC_LEVY_EFF_RATE = L_RATE THEN
                          DBG('seems to be rate is not changed re pop at liquidation');
                          L_CHANGE_BOOL := FALSE;
                        END IF;
                      EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                          DBG('inisde no data found re pop at liquidation');
                          NULL;
                        WHEN OTHERS THEN
                          DBG('inisde when others while selecting from ICTMS_PR_INT_UDEVALS re pop at liquidation-->' ||
                              SQLERRM);
                          EXIT;
                      END;
                    
                    WHEN OTHERS THEN
                      DBG('inside when others while selecting v_ude_val_list re pop at liquidation-->' ||
                          SQLERRM);
                      L_POP_PROCD := FALSE;
                  END;
                
                ELSE
                  DBG('account is opened today');
                  L_POP_PROCD   := FALSE;
                  L_CHANGE_BOOL := FALSE;
                END IF;
              
                DBG('after selecting the   v_ude_val_list');
                IF L_POP_PROCD THEN
                  DBG('got something for    v_ude_val_list');
                  J := 1;
                  LOOP
                    DBG('here the comparing ude id is-->' || L_UDE_ID);
                  
                    L_RETURN_POP := CSPKES_MISC.FN_GETPARAM(V_UDE_VAL_LIST,
                                                            J,
                                                            '~');
                    DBG('l_return_pop-->' || L_RETURN_POP);
                    IF L_RETURN_POP = 'EOPL' THEN
                      DBG('exiting from pop from re pop');
                      EXIT;
                    END IF;
                    DBG('l_ude_id_pop-->' || L_UDE_ID_POP);
                    L_UDE_ID_POP := SUBSTR(L_RETURN_POP,
                                           1,
                                           INSTR(L_RETURN_POP, '|') - 1);
                    IF L_UDE_ID = L_UDE_ID_POP THEN
                      DBG('both seems to be matching');
                      L_RATE_POP := SUBSTR(L_RETURN_POP,
                                           INSTR(L_RETURN_POP, '|') + 1);
                      DBG(' comparable l_rate is-->' || L_RATE);
                      DBG(' comparable  l_rate_pop is-->' || L_RATE_POP);
                      IF L_RATE <> L_RATE_POP THEN
                        DBG('seems to be rates rates changed here for re pop-->' ||
                            C1.UDE_EFF_DT);
                      
                        L_COMM_DT := C1.UDE_EFF_DT;
                        DBG('after assigning the ude eff date');
                        L_CHANGE_BOOL := TRUE;
                      END IF;
                    END IF;
                    DBG('l_return_pop-->' || L_RETURN_POP);
                    DBG('now the value of j is-->' || J);
                    J := J + 1;
                  END LOOP;
                END IF;
              END IF;
            
              SELECT COUNT(1)
                INTO L_CUST_COUNT
                FROM STTMS_CUSTOMER
               WHERE CUSTOMER_NO = C1.CUST_NO
                 AND LOCAL_BRANCH = GLOBAL.CURRENT_BRANCH;
              DBG('l_cust_count-->' || L_CUST_COUNT);
              DBG('customer is-->' || C1.CUST_NO);
              DBG('cond_key is1-->' || GLOBAL.CURRENT_BRANCH || C1.ACC);
              DBG('ude is1-->' || L_UDE_ID);
              DBG('effective date is1-->' || C1.UDE_EFF_DT);
              BEGIN
                SELECT COUNT(*)
                  INTO L_GEN_COUNT
                  FROM ICTBS_UDE_MT935_VALUES
                 WHERE COND_KEY = GLOBAL.CURRENT_BRANCH || C1.ACC
                      
                   AND UDE_ID = L_UDE_ID
                      
                   AND UDE_EFF_DT = C1.UDE_EFF_DT;
                DBG('l_gen_count i got is-->' || L_GEN_COUNT);
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('inisce when others here-->' || SQLERRM);
                  L_GEN_COUNT := 0;
              END;
            
              BEGIN
                SELECT NVL(PROCESS_TILL, 'X')
                  INTO L_WORK_PARAM
                  FROM ICTMS_BRANCH_PARAMETERS
                 WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
                DBG('process till here is-->' || L_WORK_PARAM);
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('inside when others of selecting process till-->' ||
                      SQLERRM);
                  L_WORK_PARAM := 'X';
              END;
              L_NEXT_WORKING_DATE := CEPKSS_DATE.FN_GETNEXTWDAY(GLOBAL.CURRENT_BRANCH);
              DBG('the next working date for the branch is-->' ||
                  L_NEXT_WORKING_DATE);
              DBG('here the process till coming is-->' || L_WORK_PARAM);
              DBG('here the c1.ude_eff_dt coming is-->' || C1.UDE_EFF_DT);
              DBG('here the global.application_date coming is-->' ||
                  GLOBAL.APPLICATION_DATE);
              IF L_CHANGE_BOOL THEN
                DBG('rate is changed hence proceeding further c1.ude_eff_dt-->' ||
                    C1.UDE_EFF_DT || '-->' || L_NEXT_WORKING_DATE);
                IF C1.UDE_EFF_DT >= L_NEXT_WORKING_DATE THEN
                  DBG('here effective date is greater than the next working date');
                  L_CHANGE_BOOL := FALSE;
                END IF;
              END IF;
            
              DBG('the count if generation is-->' || L_GEN_COUNT);
              IF L_CHANGE_BOOL THEN
                DBG('rate seems to be changed for the ude');
                IF L_GEN_COUNT = 0 THEN
                
                  DBG('so its generated');
                  IF L_CUST_COUNT <> 0 THEN
                    DBG('before generating the reference no -->' ||
                        L_COMM_DT);
                    IF NOT TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                                       'MSOG',
                                                       
                                                       GLOBAL.PROCESS_DATE,
                                                       
                                                       LSERNO,
                                                       LDCN,
                                                       ERR_CODE) THEN
                      RAISE_APPLICATION_ERROR(-20001,
                                              'DCN could not be got');
                      DBG('DCN generation bombed ' || ERR_CODE);
                    END IF;
                    DBG('DCN generated ' || LDCN);
                    DBG('the ude id is-->' || L_UDE_ID);
                    INSERT INTO MSTBS_MSG_HANDOFF
                      (DCN,
                       BRANCH,
                       PRODUCT,
                       REFERENCE_NO,
                       ESN,
                       MODULE,
                       MSG_TYPE,
                       RECEIVER,
                       MEDIA,
                       SWIFT_MSG_TYPE,
                       MSG_STATUS,
                       GENERATE_STATUS,
                       HOLD_STATUS,
                       AUTH_STAT,
                       DIRECTIVE_STATUS,
                       FROM_DATE,
                       CUST_AC_NO)
                    VALUES
                      (LDCN,
                       C1.BRN,
                       C1.PROD,
                       C1.ACC,
                       1,
                       'IC',
                       'RTCHG_ADVICE',
                       C1.CUST_NO,
                       'SWIFT',
                       '935',
                       'N',
                       'N',
                       'N',
                       'A',
                       'B',
                       
                       L_COMM_DT,
                       C1.ACC);
                    DBG('no of rows inserted into mstbs_msg_hoff is-->' ||
                        SQL%ROWCOUNT);
                    DBG('going to insert into Ictbs_ude_mt935_values');
                    DBG('here the dcn is-->' || LDCN);
                    DBG('here the ude id is-->' || L_UDE_ID);
                    DBG('here the rate is-->' || L_RATE);
                    DBG('here the ude eff dt is-->' || C1.UDE_EFF_DT);
                    BEGIN
                      INSERT INTO ICTBS_UDE_MT935_VALUES
                        (DCN, UDE_ID, UDE_VALUE, UDE_EFF_DT, COND_KEY)
                      VALUES
                        (LDCN,
                         L_UDE_ID,
                         L_RATE,
                         
                         L_COMM_DT,
                         GLOBAL.CURRENT_BRANCH || C1.ACC);
                      DBG('no of rows inserted is-->' || SQL%ROWCOUNT);
                    EXCEPTION
                      WHEN OTHERS THEN
                        DBG('inside ehen others while inserting Ictbs_ude_mt935_values-->' ||
                            SQLERRM);
                        EXIT;
                    END;
                    SELECT *
                      INTO MSG_HANDOFF_REC
                      FROM MSTBS_MSG_HANDOFF
                     WHERE DCN = LDCN;
                    DBG('going to call the function mspkss.fn_generate_msg_out');
                    BOOL := MSPKSS.FN_GENERATE_MSG_OUT(MSG_HANDOFF_REC,
                                                       'N',
                                                       BAD_DCNS);
                    IF BOOL THEN
                      DBG('message generation succesfull');
                    ELSE
                      DBG('message generation failed');
                    END IF;
                  ELSE
                    DBG('customer does not belongs to the' || '-->' ||
                        GLOBAL.CURRENT_BRANCH);
                  END IF;
                END IF;
              
              ELSE
                DBG('for this it will not generate MT935');
              END IF;
            END IF;
            I := I + 1;
          END LOOP;
        END IF;
        DBG('exiting');
        EXIT WHEN CR_AC_RCA%NOTFOUND;
      END LOOP;
    
      FOR C3 IN CR_BACKDATED_RCA(P_TODAY) LOOP
        DBG('starting of the back dated rca contracts-->' || C3.ACC ||
            '-->' || C3.CUST_NO);
        BEGIN
          DBG('inside the procedure pr_handoof_mt935 c3.brn-->' || C3.BRN);
          DBG('inside the procedure pr_handoof_mt935 c3.acc-->' || C3.ACC);
          DBG('inside the procedure pr_handoof_mt935 c3.prod-->' ||
              C3.PROD);
          DBG('c1.cust_no here coming is-->' || C3.CUST_NO);
          SELECT NVL(A.GEN_UCA, 'N')
            INTO L_GEN_UCA
            FROM ICTMS_ACC_PR A
           WHERE A.BRN = C3.BRN
             AND A.ACC = C3.ACC
             AND A.PROD = C3.PROD
             AND A.WAIVE = 'N'
             AND A.RECORD_STAT = 'O';
        EXCEPTION
          WHEN OTHERS THEN
            DBG('when oters selecting l_gen_uca3-->' || SQLERRM);
            L_GEN_UCA := 'N';
        END;
        DBG('inside the procedure pr_handoof_mt935 l_gen_uca3-->' ||
            L_GEN_UCA);
        IF L_GEN_UCA = 'Y' THEN
          L_UDE_ID     := C3.UDE_ID;
          L_RATE       := C3.UDE_VAL;
          L_FLOAT_RATE := C3.RATE_CODE;
          DBG('floating rate code is-->' || C3.RATE_CODE);
          DBG('l_rate3-->' || L_RATE);
          DBG('l_ude_id3-->' || L_UDE_ID);
          SELECT NVL(UDE_TYPE, 'W')
            INTO L_UDE_TYPE
            FROM ICTMS_RULE_UDE
           WHERE RULE_ID =
                 (SELECT RULE FROM ICTMS_PR_INT WHERE PRODUCT_CODE = C3.PROD)
             AND UDE_ID = L_UDE_ID;
          DBG('l_ude_type3-->' || L_UDE_TYPE);
          DBG('c1.ude_eff_dt3 is-->' || C3.UDE_EFF_DT);
          L_CHANGE_BOOL := FALSE;
          IF L_UDE_TYPE = 'R' THEN
            BEGIN
              DBG('going to select from sttms_cust_account');
              SELECT ACCOUNT_CLASS, CCY
                INTO L_ACC_CLASS, L_CCY
                FROM STTMS_CUST_ACCOUNT
               WHERE CUST_AC_NO = C3.ACC
                 AND BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
              DBG('account class is-->' || L_ACC_CLASS);
              DBG('account currency is-->' || L_CCY);
            
              BEGIN
                DBG('before selecting l_gen_ude_val and l_rate_code-->' ||
                    L_UDE_ID || '-->' || C3.UDE_EFF_DT);
                SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                  INTO L_GEN_UDE_VAL, L_RATE_CODE
                  FROM ICTMS_PR_INT_UDEVALS
                 WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                   AND ACLASS = L_ACC_CLASS
                   AND CCY_CODE = L_CCY
                   AND PRODUCT_CODE = (SELECT PRODUCT_CODE
                                         FROM ICTMS_PR_INT_ACLASS
                                        WHERE ACLASS = L_ACC_CLASS
                                          AND CCY = L_CCY)
                   AND UDE_ID = L_UDE_ID
                   AND UDE_EFF_DT =
                       (SELECT MAX(UDE_EFF_DT)
                          FROM ICTMS_PR_INT_UDEVALS
                         WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH
                           AND ACLASS = L_ACC_CLASS
                           AND CCY_CODE = L_CCY
                           AND PRODUCT_CODE =
                               (SELECT PRODUCT_CODE
                                  FROM ICTMS_PR_INT_ACLASS
                                 WHERE ACLASS = L_ACC_CLASS
                                   AND CCY = L_CCY)
                           AND UDE_ID = L_UDE_ID
                           AND UDE_EFF_DT <= C3.UDE_EFF_DT);
                DBG('  l_gen_ude_val is3-->' || L_GEN_UDE_VAL);
                DBG(' l_rate_code3 -->' || L_RATE_CODE);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  DBG('inside no data found so checking the maintenance for all l_ude_id-->' ||
                      L_UDE_ID || '-->' || C3.UDE_EFF_DT);
                  SELECT NVL(UDE_VALUE, 0), NVL(RATE_CODE, 'XXX')
                    INTO L_GEN_UDE_VAL, L_RATE_CODE
                    FROM ICTMS_PR_INT_UDEVALS
                   WHERE BRANCH_CODE = 'ALL'
                     AND ACLASS = L_ACC_CLASS
                     AND CCY_CODE = L_CCY
                     AND PRODUCT_CODE = (SELECT PRODUCT_CODE
                                           FROM ICTMS_PR_INT_ACLASS
                                          WHERE ACLASS = L_ACC_CLASS
                                            AND CCY = L_CCY)
                     AND UDE_ID = L_UDE_ID
                     AND UDE_EFF_DT =
                         (SELECT MAX(UDE_EFF_DT)
                            FROM ICTMS_PR_INT_UDEVALS
                           WHERE BRANCH_CODE = 'ALL'
                             AND ACLASS = L_ACC_CLASS
                             AND CCY_CODE = L_CCY
                             AND PRODUCT_CODE =
                                 (SELECT PRODUCT_CODE
                                    FROM ICTMS_PR_INT_ACLASS
                                   WHERE ACLASS = L_ACC_CLASS
                                     AND CCY = L_CCY)
                             AND UDE_ID = L_UDE_ID
                             AND UDE_EFF_DT <= C3.UDE_EFF_DT);
                  DBG('now the l_gen_ude_val is3-->' || L_GEN_UDE_VAL);
                  DBG('now the l_rate_code is3-->' || L_RATE_CODE);
                WHEN OTHERS THEN
                  DBG('inside whn others of selecting ude value3-->' ||
                      SQLERRM);
                
              END;
              DBG('now going to fetch the rate-->' || L_RATE_CODE || '-->' ||
                  L_DR_UDE_VALUE);
              IF NVL(L_RATE_CODE, 'XXX') = 'XXX' THEN
                DBG('ude value is there3');
                L_REC_LEVY_EFF_RATE := L_GEN_UDE_VAL;
              ELSE
                DBG('rate code is der ofr ude value3');
                SELECT RATE + NVL(L_GEN_UDE_VAL, 0)
                
                  INTO L_REC_LEVY_EFF_RATE
                  FROM ICTMS_RATES
                 WHERE RATE_CODE = L_RATE_CODE
                   AND CCY_CODE = L_CCY
                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A'
                   AND EFF_DT = (SELECT MAX(EFF_DT)
                                   FROM ICTMS_RATES
                                  WHERE RATE_CODE = L_RATE_CODE
                                    AND CCY_CODE = L_CCY
                                    AND RECORD_STAT = 'O'
                                    AND AUTH_STAT = 'A'
                                    AND EFF_DT <= P_TODAY);
                DBG('after the select of rate code3-->' ||
                    L_REC_LEVY_EFF_RATE);
              END IF;
            
              DBG('here the rate is3-->' || L_REC_LEVY_EFF_RATE);
              DBG('here the special rate is3-->' || L_RATE);
              IF L_REC_LEVY_EFF_RATE <> L_RATE THEN
                DBG('seems to be rate are changing');
                L_CHANGE_BOOL := TRUE;
              ELSIF L_REC_LEVY_EFF_RATE = L_RATE THEN
                DBG('seems to be rate is not changed3');
                L_CHANGE_BOOL := FALSE;
              END IF;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('inisde no data found3');
                NULL;
              WHEN OTHERS THEN
                DBG('inisde when others while selecting from ICTMS_PR_INT_UDEVALS3-->' ||
                    SQLERRM);
                EXIT;
            END;
            SELECT COUNT(1)
              INTO L_CUST_COUNT
              FROM STTMS_CUSTOMER
             WHERE CUSTOMER_NO = C3.CUST_NO
               AND LOCAL_BRANCH = GLOBAL.CURRENT_BRANCH;
            DBG('l_cust_count3-->' || L_CUST_COUNT);
            DBG('customer is3-->' || C3.CUST_NO);
            DBG('cond_key is3-->' || GLOBAL.CURRENT_BRANCH || C3.ACC);
            DBG('ude is3-->' || L_UDE_ID);
            DBG('effective date is3-->' || C3.UDE_EFF_DT);
            BEGIN
              DBG('going to select Ictbs_ude_mt935_values');
              SELECT COUNT(*)
                INTO L_GEN_COUNT
                FROM ICTBS_UDE_MT935_VALUES
               WHERE COND_KEY = GLOBAL.CURRENT_BRANCH || C3.ACC
                    
                 AND UDE_ID = L_UDE_ID
                 AND UDE_EFF_DT = C3.UDE_EFF_DT;
              DBG('after selecting Ictbs_ude_mt935_values l_gen_count-->');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('inside whn others of this select-->' || SQLERRM);
                L_GEN_COUNT := 0;
            END;
            DBG('the count if generation is-->' || L_GEN_COUNT);
            IF L_CHANGE_BOOL THEN
              DBG('rate seems to be changed for the ude');
              IF L_GEN_COUNT = 0 THEN
              
                DBG('so its generated');
                DBG('before generating the reference no');
                IF NOT TRPKSS.FN_GET_PROCESS_REFNO(GLOBAL.CURRENT_BRANCH,
                                                   'MSOG',
                                                   
                                                   GLOBAL.PROCESS_DATE,
                                                   
                                                   LSERNO,
                                                   LDCN,
                                                   ERR_CODE) THEN
                  RAISE_APPLICATION_ERROR(-20001, 'DCN could not be got');
                  DBG('DCN generation bombed ' || ERR_CODE);
                END IF;
                DBG('DCN generated ' || LDCN);
                DBG('the ude id is-->' || L_UDE_ID);
                INSERT INTO MSTBS_MSG_HANDOFF
                  (DCN,
                   BRANCH,
                   PRODUCT,
                   REFERENCE_NO,
                   ESN,
                   MODULE,
                   MSG_TYPE,
                   RECEIVER,
                   MEDIA,
                   SWIFT_MSG_TYPE,
                   MSG_STATUS,
                   GENERATE_STATUS,
                   HOLD_STATUS,
                   AUTH_STAT,
                   DIRECTIVE_STATUS,
                   FROM_DATE,
                   CUST_AC_NO)
                VALUES
                  (LDCN,
                   C3.BRN,
                   C3.PROD,
                   C3.ACC,
                   1,
                   'IC',
                   'RTCHG_ADVICE',
                   C3.CUST_NO,
                   'SWIFT',
                   '935',
                   'N',
                   'N',
                   'N',
                   'A',
                   'B',
                   C3.UDE_EFF_DT,
                   C3.ACC);
                DBG('no of rows inserted into mstbs_msg_hoff is3-->' ||
                    SQL%ROWCOUNT);
                DBG('going to insert into Ictbs_ude_mt935_values3');
                DBG('here the dcn is3-->' || LDCN);
                DBG('here the ude id is3-->' || L_UDE_ID);
                DBG('here the rate is3-->' || L_RATE);
                DBG('here the ude eff dt3 is-->' || C3.UDE_EFF_DT);
                BEGIN
                  INSERT INTO ICTBS_UDE_MT935_VALUES
                    (DCN, UDE_ID, UDE_VALUE, UDE_EFF_DT, COND_KEY)
                  VALUES
                    (LDCN,
                     L_UDE_ID,
                     L_RATE,
                     C3.UDE_EFF_DT,
                     GLOBAL.CURRENT_BRANCH || C3.ACC);
                  DBG('no of rows inserted is3-->' || SQL%ROWCOUNT);
                EXCEPTION
                  WHEN OTHERS THEN
                    DBG('inside ehen others while inserting Ictbs_ude_mt935_values3-->' ||
                        SQLERRM);
                    EXIT;
                END;
                SELECT *
                  INTO MSG_HANDOFF_REC
                  FROM MSTBS_MSG_HANDOFF
                 WHERE DCN = LDCN;
                DBG('going to call the function mspkss.fn_generate_msg_out3');
                BOOL := MSPKSS.FN_GENERATE_MSG_OUT(MSG_HANDOFF_REC,
                                                   'N',
                                                   BAD_DCNS);
                IF BOOL THEN
                  DBG('message generation succesfull3');
                ELSE
                  DBG('message generation failed3');
                END IF;
              END IF;
            
            ELSE
              DBG('for this it will not generate MT935');
            END IF;
          END IF;
        END IF;
        DBG('exiting from back dated rate change advice');
        EXIT WHEN CR_BACKDATED_RCA%NOTFOUND;
      END LOOP;
    
      DBG('seems to be special condition maintenance is over');
    
    END IF;
    GLOBAL.PR_RESET_SKIP_KERNEL;
  
    DBG('before going out from pr_handoof_mt935');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('inside when others of pr_handoof_mt935-->' || SQLERRM);
      RETURN;
  END PR_HANDOOF_MT935;

  PROCEDURE PR_UPDATE_OD_INT(P_FRM_NO          ICTMS_RULE_FRM.FRM_NO%TYPE,
                             P_BRN             ICTM_ACC.BRN%TYPE,
                             P_RELATED_ACCOUNT ACTB_DAILY_LOG.RELATED_ACCOUNT%TYPE,
                             P_PROD            ICTM_ACC_PR.PROD%TYPE,
                             P_LCY_AMT         ACTB_DAILY_LOG.LCY_AMOUNT%TYPE,
                             P_FCY_AMT         ACTB_DAILY_LOG.FCY_AMOUNT%TYPE,
                             P_ACC_CCY         STTM_CUST_ACCOUNT.CCY%TYPE,
                             P_LCY             STTM_CUST_ACCOUNT.CCY%TYPE,
                             P_DT              DATE) IS
    L_STATUS ICTMS_PRODUCT_STATUS.STATUS%TYPE;
    L_WROF   ICTMS_PRODUCT_STATUS.CAP_REVR_INC%TYPE;
    L_OD_AMT ICTBS_OD_INTEREST.INT_AMT%TYPE;
    L_FRM_NO ICTMS_RULE_FRM.FRM_NO%TYPE;
  
  BEGIN
  
    L_FRM_NO := P_FRM_NO;
    DBG('3 Updating/Inserting ictbs_od_interest for brn,acc,prod,frm_no -' ||
        P_BRN || '~' || P_RELATED_ACCOUNT || '~' || P_PROD || '~' ||
        TO_CHAR(L_FRM_NO));
  
    BEGIN
      SELECT ACC_STATUS
        INTO L_STATUS
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_BRN
         AND CUST_AC_NO = P_RELATED_ACCOUNT;
    
      SELECT 'Y'
        INTO L_WROF
        FROM ICTMS_PRODUCT_STATUS
       WHERE PRODUCT_CODE = P_PROD
         AND CAP_REVR_INC = 'Y'
         AND STATUS = L_STATUS;
    
      DBG('l_status :' || L_STATUS);
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        L_WROF := 'N';
    END;
  
    DBG('l_wrof :' || L_WROF);
  
    IF P_ACC_CCY = P_LCY THEN
      L_OD_AMT := P_LCY_AMT;
    ELSE
      L_OD_AMT := P_FCY_AMT;
    END IF;
  
    BEGIN
      UPDATE ICTBS_OD_INTEREST
         SET INT_AMT          = INT_AMT + DECODE(NVL(L_WROF, 'N'),
                                                 'N',
                                                 NVL(L_OD_AMT, 0),
                                                 0),
             INT_AMT_AFT_WROF = INT_AMT_AFT_WROF +
                                DECODE(NVL(L_WROF, 'N'), 'Y', L_OD_AMT, 0)
       WHERE BRN = P_BRN
         AND ACC = P_RELATED_ACCOUNT
         AND PROD = P_PROD
         AND FRM_NO = L_FRM_NO;
    
      IF SQL%NOTFOUND THEN
        DBG('inserting into ictbs_od_interest');
        INSERT INTO ICTBS_OD_INTEREST
          (BRN, ACC, PROD, FRM_NO, INT_AMT, INT_AMT_AFT_WROF)
        VALUES
          (P_BRN,
           P_RELATED_ACCOUNT,
           P_PROD,
           L_FRM_NO,
           DECODE(L_WROF, 'N', NVL(L_OD_AMT, 0), 0),
           DECODE(L_WROF, 'Y', NVL(L_OD_AMT, 0), 0));
      END IF;
    END;
  
    BEGIN
      UPDATE ICTBS_OD_INTEREST_BREAKUP
         SET INT_AMT    = INT_AMT + NVL(L_OD_AMT, 0),
             REV_INCAMT = REV_INCAMT +
                          DECODE(L_WROF, 'Y', NVL(L_OD_AMT, 0), 0)
       WHERE BRN = P_BRN
         AND ACC = P_RELATED_ACCOUNT
         AND PROD = P_PROD
         AND ENT_DT = P_DT
         AND FRM_NO = L_FRM_NO;
    
      IF SQL%NOTFOUND THEN
        DBG('inserting into ictbs_od_interest_breakup');
      
        INSERT INTO ICTBS_OD_INTEREST_BREAKUP
          (BRN,
           ACC,
           PROD,
           ENT_DT,
           FRM_NO,
           INT_AMT,
           WROF_FLAG,
           INT_PAID,
           REV_INCAMT)
        VALUES
          (P_BRN,
           P_RELATED_ACCOUNT,
           P_PROD,
           P_DT,
           L_FRM_NO,
           L_OD_AMT,
           L_WROF,
           'N',
           DECODE(L_WROF, 'Y', NVL(L_OD_AMT, 0), 0));
      
      END IF;
    END;
  
  END PR_UPDATE_OD_INT;

  FUNCTION FN_POP_PROD_ACCR_ENTRIES(P_CCY      IN VARCHAR2,
                                    P_STATUS   IN VARCHAR2,
                                    P_DT       IN DATE,
                                    P_PROCESS  IN NUMBER,
                                    P_TB_ICENT IN REC_ICENT) RETURN BOOLEAN IS
  
    L_PREV_ADJ_AMT ICTB_PROD_ACCR_ENTRIES.PAST_ACQUIRED_ADJ%TYPE;
    L_PREV_ACQ_AMT ICTB_PROD_ACCR_ENTRIES.PAST_ACQUIRED_AMT%TYPE;
    L_CUR_ACQ_AMT  ICTB_PROD_ACCR_ENTRIES.ACQUIRED_AMT%TYPE;
    L_CUR_ADJ_AMT  ICTB_PROD_ACCR_ENTRIES.ACQUIRED_ADJ%TYPE;
  
  BEGIN
  
    DBG('Inside fn_prod_accr_entries');
  
    FOR J IN P_TB_ICENT.FIRST .. P_TB_ICENT.LAST LOOP
      DBG('Inside the loop with count-->' || J);
    
      L_PREV_ADJ_AMT := 0;
      L_PREV_ACQ_AMT := 0;
      L_CUR_ACQ_AMT  := 0;
      L_CUR_ADJ_AMT  := 0;
    
      BEGIN
        DBG('Before insertion');
        DBG('here application date is-->' || GLOBAL.APPLICATION_DATE || '~' || P_TB_ICENT(J).PROD || '~' || P_DT || '~' || P_TB_ICENT(J)
            .ACQUIRED_AMT || '~' || P_TB_ICENT(J).CUR_RUN_ACCR || '~' || P_TB_ICENT(J)
            .ACQUIRED_ADJ);
      
        IF NVL(P_TB_ICENT(J).CUR_RUN_ACCR, 0) <> 0
          
           OR ((NVL(P_TB_ICENT(J).ACQUIRED_AMT, 0) <> 0 OR
               NVL(P_TB_ICENT(J).ACQUIRED_ADJ, 0) <> 0) AND
               NVL(P_TB_ICENT(J).ACQUIRED_AMT, 0) <>
               NVL(P_TB_ICENT(J).ACQUIRED_ADJ, 0))
        
         THEN
          DBG('inserting now-->' || P_TB_ICENT(J).CUR_RUN_ACCR || '~' || P_TB_ICENT(J)
              .ACQUIRED_AMT || '~' || P_TB_ICENT(J).ACQUIRED_ADJ);
        
          IF TB_PAST_ADJ_ICENT_PROD.EXISTS(J) THEN
            L_PREV_ACQ_AMT := NVL(TB_PAST_ADJ_ICENT_PROD(J).ACQUIRED_AMT, 0);
            L_PREV_ADJ_AMT := NVL(TB_PAST_ADJ_ICENT_PROD(J).ACQUIRED_ADJ, 0);
          ELSE
            L_PREV_ACQ_AMT := 0;
            L_PREV_ADJ_AMT := 0;
          END IF;
          L_CUR_ACQ_AMT := P_TB_ICENT(J).ACQUIRED_AMT - L_PREV_ACQ_AMT;
          L_CUR_ADJ_AMT := P_TB_ICENT(J).ACQUIRED_ADJ - L_PREV_ADJ_AMT;
        
          INSERT INTO ICTB_PROD_ACCR_ENTRIES
            (BRN,
             PROD,
             FRM_NO,
             CCY,
             STATUS,
             PROCESS,
             VALUE_DT,
             CUR_RUN_ACCR,
             ACQUIRED_AMT,
             ACQUIRED_ADJ,
             
             PAST_ACQUIRED_AMT,
             PAST_ACQUIRED_ADJ,
             
             ENTRY_PASSED,
             TRN_DT,
             INTRADAY)
          VALUES
            (P_TB_ICENT(J).BRN,
             P_TB_ICENT(J).PROD,
             P_TB_ICENT(J).FRM_NO,
             P_CCY,
             P_STATUS,
             P_PROCESS,
             P_DT,
             P_TB_ICENT(J).CUR_RUN_ACCR,
             
             L_CUR_ACQ_AMT,
             L_CUR_ADJ_AMT,
             L_PREV_ACQ_AMT,
             L_PREV_ADJ_AMT,
             
             'N',
             GLOBAL.APPLICATION_DATE,
             DECODE(ICPKS_INTRADAY_NEW.G_IC_BKGRND_JOB, 1, 'Y', 'N'));
          DBG('number of records inserted is-->' || SQL%ROWCOUNT);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in insert into the Log table');
          DBG('SQLERRM-->' || SQLERRM);
          RETURN FALSE;
      END;
    END LOOP;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in fn_pop_prod_accr_entries');
      RETURN FALSE;
  END FN_POP_PROD_ACCR_ENTRIES;

  FUNCTION FN_PROD_ACCR_ACCTNG(P_BRN VARCHAR2) RETURN INTEGER AS
  
    EXP_CONV EXCEPTION;
    JAI              NUMBER;
    NUM              NUMBER;
    L_PROD           VARCHAR2(4);
    R_PR             REC_PRINT;
    L_TBLOOKUP       ACPKSS.TBL_LOOKUP;
    TEMP_HOFF        ACPKSS.TBL_ACHOFF;
    TB_BASIC_HANDOFF ACPKSS.TBL_ACHOFF;
    TB_HOFF_PRODUCT  ACPKSS.TBL_ACHOFF;
    L_REF            ACTBS_DAILY_LOG.TRN_REF_NO%TYPE;
    L_FRM_NO         ICTMS_RULE_FRM.FRM_NO%TYPE;
    L_LCY_AMT        ACTBS_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_XRATE          ACTBS_DAILY_LOG.EXCH_RATE%TYPE;
    ECODE            ERTBS_MSGS.ERR_CODE%TYPE;
    HOFF_COUNT       NUMBER;
    CONS_COUNT       NUMBER;
    SR               NUMBER;
    JP               NUMBER;
    ERRMSG           VARCHAR2(2000);
    EPRM             VARCHAR2(2000);
    L_LCY            VARCHAR2(3) := GLOBAL.LCY;
    RETSTAT          INTEGER := 0;
    L_STATUS         VARCHAR2(6);
  
    CURSOR CR_PROD_ACCR_ENTRIES IS
      SELECT IPAE.BRN,
             IPAE.PROD,
             IPAE.FRM_NO,
             IPAE.CCY,
             IPAE.STATUS,
             IPAE.VALUE_DT,
             SUM(IPAE.CUR_RUN_ACCR) CUR_RUN_ACCR,
             SUM(IPAE.ACQUIRED_AMT) ACQUIRED_AMT,
             SUM(IPAE.ACQUIRED_ADJ) ACQUIRED_ADJ,
             SUM(IPAE.PAST_ACQUIRED_AMT) PAST_ACQUIRED_AMT,
             SUM(IPAE.PAST_ACQUIRED_ADJ) PAST_ACQUIRED_ADJ
        FROM ICTBS_PROD_ACCR_ENTRIES IPAE
       WHERE BRN = P_BRN
         AND ENTRY_PASSED = 'N'
       GROUP BY IPAE.BRN,
                IPAE.PROD,
                IPAE.FRM_NO,
                IPAE.CCY,
                IPAE.STATUS,
                IPAE.VALUE_DT;
  
  BEGIN
  
    DBG('Inside fn_prod_accr_acctng' || P_BRN);
    DBG('Just inside prod accrue' || 'hoff count is ' ||
        TB_HOFF_PRODUCT.COUNT);
  
    SAVEPOINT SP_PROD_ACCR;
    FOR REC IN CR_PROD_ACCR_ENTRIES LOOP
      DBG('Inside loop');
      TB_BASIC_HANDOFF(1).EVENT := 'IACR';
      TB_BASIC_HANDOFF(1).MODULE := 'IC';
      TB_BASIC_HANDOFF(1).EVENT_SR_NO := 1;
      TB_BASIC_HANDOFF(1).TRN_DT := NVL(GLOBAL.APPLICATION_DATE,
                                        REC.VALUE_DT);
      TB_BASIC_HANDOFF(1).VALUE_DT := REC.VALUE_DT;
      TB_BASIC_HANDOFF(1).AC_BRANCH := REC.BRN;
      TB_BASIC_HANDOFF(1).USER_ID := GLOBAL.USER_ID;
      TB_BASIC_HANDOFF(1).BATCH_NO := 0;
      TB_BASIC_HANDOFF(1).CURR_NO := 0;
      TB_BASIC_HANDOFF(1).AVLDAYS := 0;
      TB_BASIC_HANDOFF(1).TXN_INIT_DATE := GLOBAL.APPLICATION_DATE;
    
      IF NVL(L_PROD, '****') <> REC.PROD OR
         NVL(L_STATUS, '****') <> REC.STATUS THEN
      
        PR_LOOKUP(REC.PROD, 'IACR', REC.STATUS, L_TBLOOKUP);
        L_PROD   := REC.PROD;
        L_STATUS := REC.STATUS;
        PR_CACHE_PROD(REC.PROD, REC.STATUS);
        FIND_KEY(REC.PROD, R_PR);
      END IF;
    
      IF NVL(L_TBLOOKUP.COUNT, 0) <> 0 THEN
        DBG('rec.prod ' || REC.PROD || 'rec.ccy ' || REC.CCY ||
            'rec.frm_no' || REC.FRM_NO);
        L_REF := REC.BRN || REC.PROD || REC.CCY ||
                 LTRIM(RTRIM(TO_CHAR(REC.FRM_NO, '00000'))) || 'A';
        DBG('The reference number is ' || L_REF);
        FOR I IN L_TBLOOKUP.FIRST .. L_TBLOOKUP.LAST LOOP
          NUM := I;
          JAI := NVL(TB_HOFF_PRODUCT.COUNT, 0) + 1;
          DBG('even lookup had some' || REC.FRM_NO);
          L_FRM_NO := TO_NUMBER(SUBSTR(L_TBLOOKUP(I).ACCROLE,
                                       INSTR(L_TBLOOKUP(I).ACCROLE, '-', -1) + 1));
          DBG('Form numbr is l_frm_no' || L_FRM_NO || 'amt tag is ' || L_TBLOOKUP(I)
              .AMTTAG || 'rec.frm_no' || REC.FRM_NO);
          IF (L_FRM_NO = REC.FRM_NO AND L_TBLOOKUP(I).AMTTAG = 'IACR') THEN
            TB_HOFF_PRODUCT(JAI + I) := TB_BASIC_HANDOFF(1);
            TB_HOFF_PRODUCT(JAI + I).EVENT := 'IACR';
            TB_HOFF_PRODUCT(JAI + I).TRN_REF_NO := L_REF;
            TB_HOFF_PRODUCT(JAI + I).AC_NO := L_TBLOOKUP(I).ACCOUNT;
            TB_HOFF_PRODUCT(JAI + I).AC_BRANCH := REC.BRN;
            TB_HOFF_PRODUCT(JAI + I).AC_CCY := REC.CCY;
            TB_HOFF_PRODUCT(JAI + I).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
            TB_HOFF_PRODUCT(JAI + I).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
            TB_HOFF_PRODUCT(JAI + I).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
            TB_HOFF_PRODUCT(JAI + I).NETTING_IND := L_TBLOOKUP(I).NETIND;
            TB_HOFF_PRODUCT(JAI + I).AVLDAYS := 0;
            TB_HOFF_PRODUCT(JAI + I).MIS_HEAD := L_TBLOOKUP(I).MIS_HEAD;
            TB_HOFF_PRODUCT(JAI + I).PRODUCT_ACCRUAL := 'P';
            DBG('ac no is ' || TB_HOFF_PRODUCT(JAI + I).AC_NO || '~' || TB_HOFF_PRODUCT(JAI + I)
                .AC_CCY);
            DBG('After completing th basics..and moving to amts ' ||
                REC.CCY || '~' || L_LCY);
            IF REC.CCY <> L_LCY THEN
              DBG('Ccys are different ' || REC.CCY || ' ' || L_LCY);
              TB_HOFF_PRODUCT(JAI + I).FCY_AMOUNT := NVL(REC.CUR_RUN_ACCR,
                                                         0);
              L_XRATE := NULL;
              L_LCY_AMT := 0;
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(REC.BRN,
                                                 REC.CCY,
                                                 L_LCY,
                                                 NVL(REC.CUR_RUN_ACCR, 0)
                                                 
                                                ,
                                                 'Y',
                                                 L_LCY_AMT,
                                                 L_XRATE,
                                                 ECODE) THEN
                DBG('Haath from fn_amt1_to_amt2...' || ECODE);
                RAISE EXP_CONV;
              ELSE
                TB_HOFF_PRODUCT(JAI + I).EXCH_RATE := L_XRATE;
                TB_HOFF_PRODUCT(JAI + I).FCY_AMOUNT := NVL(REC.CUR_RUN_ACCR,
                                                           0);
              
                TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := NVL(L_LCY_AMT, 0);
              
              END IF;
            ELSE
              TB_HOFF_PRODUCT(JAI + I).EXCH_RATE := NULL;
              TB_HOFF_PRODUCT(JAI + I).FCY_AMOUNT := 0;
              DBG('Current accrual-->' || REC.CUR_RUN_ACCR);
              TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := NVL(REC.CUR_RUN_ACCR,
                                                         0);
            END IF;
            TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PRODUCT(JAI + I)
                                                                                  .AC_CCY,
                                                                                  TB_HOFF_PRODUCT(JAI + I)
                                                                                  .FCY_AMOUNT,
                                                                                  LCY,
                                                                                  TB_HOFF_PRODUCT(JAI + I)
                                                                                  .LCY_AMOUNT);
            DBG('lcy/fcy amt is ' || TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT || '~' || TB_HOFF_PRODUCT(JAI + I)
                .FCY_AMOUNT);
            IF TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT = 0 THEN
              DBG('lcy amount is zero we can not post this even in prod accr');
              TB_HOFF_PRODUCT.DELETE(JAI + I);
            ELSE
              SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
              TEMP_HOFF(SR) := TB_HOFF_PRODUCT(JAI + I);
              TB_HOFF_PRODUCT.DELETE(JAI + I);
            END IF;
          ELSIF (L_FRM_NO = REC.FRM_NO AND L_TBLOOKUP(I)
                .AMTTAG = 'IACR_ADJ' AND REC.ACQUIRED_AMT <> 0) THEN
            DBG('In the else cond for IACR_ADJ');
            TB_HOFF_PRODUCT(JAI + I) := TB_BASIC_HANDOFF(1);
            TB_HOFF_PRODUCT(JAI + I).TRN_REF_NO := L_REF;
            TB_HOFF_PRODUCT(JAI + I).AC_NO := L_TBLOOKUP(I).ACCOUNT;
            TB_HOFF_PRODUCT(JAI + I).AC_BRANCH := REC.BRN;
            TB_HOFF_PRODUCT(JAI + I).AC_CCY := REC.CCY;
            TB_HOFF_PRODUCT(JAI + I).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
            TB_HOFF_PRODUCT(JAI + I).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
            TB_HOFF_PRODUCT(JAI + I).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
            TB_HOFF_PRODUCT(JAI + I).NETTING_IND := L_TBLOOKUP(I).NETIND;
            TB_HOFF_PRODUCT(JAI + I).AVLDAYS := 0;
            TB_HOFF_PRODUCT(JAI + I).MIS_HEAD := L_TBLOOKUP(I).MIS_HEAD;
            TB_HOFF_PRODUCT(JAI + I).PRODUCT_ACCRUAL := 'P';
            DBG('ac no is ' || TB_HOFF_PRODUCT(JAI + I).AC_NO || '~' || TB_HOFF_PRODUCT(JAI + I)
                .AC_CCY);
            IF REC.CCY <> L_LCY THEN
            
              TB_HOFF_PRODUCT(JAI + I).FCY_AMOUNT := (NVL(REC.ACQUIRED_AMT,
                                                          0) +
                                                     NVL(REC.PAST_ACQUIRED_AMT,
                                                          0)) -
                                                     (NVL(REC.ACQUIRED_ADJ,
                                                          0) +
                                                     NVL(REC.PAST_ACQUIRED_ADJ,
                                                          0));
            
              L_XRATE   := NULL;
              L_LCY_AMT := NULL;
              IF NOT ICPKSS_UTIL.FN_AMT1_TO_AMT2(REC.BRN,
                                                 REC.CCY,
                                                 L_LCY,
                                                 TB_HOFF_PRODUCT(JAI + I)
                                                 .FCY_AMOUNT,
                                                 'Y',
                                                 L_LCY_AMT,
                                                 L_XRATE,
                                                 ECODE) THEN
                DBG('2 Haath from fn_amt1_to_amt2...' || ECODE);
                RAISE EXP_CONV;
              ELSE
                TB_HOFF_PRODUCT(JAI + I).EXCH_RATE := L_XRATE;
                TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := NVL(L_LCY_AMT, 0);
              END IF;
            ELSE
              TB_HOFF_PRODUCT(JAI + I).EXCH_RATE := NULL;
              TB_HOFF_PRODUCT(JAI + I).FCY_AMOUNT := NULL;
            
              TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := (NVL(REC.ACQUIRED_AMT,
                                                          0) +
                                                     NVL(REC.PAST_ACQUIRED_AMT,
                                                          0)) -
                                                     (NVL(REC.ACQUIRED_ADJ,
                                                          0) +
                                                     NVL(REC.PAST_ACQUIRED_ADJ,
                                                          0));
              L_XRATE := NULL;
            
            END IF;
            DBG('tb_hoff_product(jai+i).fcy_amount ' || TB_HOFF_PRODUCT(JAI + I)
                .FCY_AMOUNT || 'lcy_amount' || TB_HOFF_PRODUCT(JAI + I)
                .LCY_AMOUNT);
            TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PRODUCT(JAI + I)
                                                                                  .AC_CCY,
                                                                                  TB_HOFF_PRODUCT(JAI + I)
                                                                                  .FCY_AMOUNT,
                                                                                  L_LCY,
                                                                                  TB_HOFF_PRODUCT(JAI + I)
                                                                                  .LCY_AMOUNT);
            IF TB_HOFF_PRODUCT(JAI + I).LCY_AMOUNT = 0 THEN
              DBG('lcy amount is zero we can not post this even in prod accr');
              TB_HOFF_PRODUCT.DELETE(JAI + I);
            ELSE
              SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
              TEMP_HOFF(SR) := TB_HOFF_PRODUCT(JAI + I);
              TB_HOFF_PRODUCT.DELETE(JAI + I);
            END IF;
          
          ELSIF (L_FRM_NO = REC.FRM_NO AND L_TBLOOKUP(I)
                .AMTTAG = 'IACR_ADJ_PREV' AND REC.PAST_ACQUIRED_AMT <> 0) THEN
            DBG('In the else cond for IACR_ADJ_PREV');
            TB_HOFF_PROD(JAI + I) := TB_BASIC_HOFF(1);
            TB_HOFF_PROD(JAI + I).TRN_REF_NO := L_REF;
            TB_HOFF_PROD(JAI + I).AC_NO := L_TBLOOKUP(I).ACCOUNT;
            TB_HOFF_PROD(JAI + I).AC_BRANCH := REC.BRN;
            TB_HOFF_PROD(JAI + I).AC_CCY := REC.CCY;
            TB_HOFF_PROD(JAI + I).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
            TB_HOFF_PROD(JAI + I).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
            TB_HOFF_PROD(JAI + I).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
            TB_HOFF_PROD(JAI + I).NETTING_IND := L_TBLOOKUP(I).NETIND;
            TB_HOFF_PROD(JAI + I).AVLDAYS := 0;
            TB_HOFF_PROD(JAI + I).MIS_HEAD := L_TBLOOKUP(I).MIS_HEAD;
          
            TB_HOFF_PROD(JAI + I).PRODUCT_ACCRUAL := 'P';
            DBG('ac no is ' || TB_HOFF_PROD(JAI + I).AC_NO || '~' || TB_HOFF_PROD(JAI + I)
                .AC_CCY);
            IF G_STTM_CUSTACC.CCY <> LCY THEN
            
              TB_HOFF_PROD(JAI + I).FCY_AMOUNT := REC.PAST_ACQUIRED_AMT -
                                                  REC.PAST_ACQUIRED_ADJ;
            
              L_XRATE   := NULL;
              L_LCY_AMT := NULL;
              IF NOT
                  ICPKSS_UTIL.FN_AMT1_TO_AMT2(REC.BRN,
                                              REC.CCY,
                                              LCY,
                                              TB_HOFF_PROD(JAI + I).FCY_AMOUNT,
                                              'Y',
                                              L_LCY_AMT,
                                              L_XRATE,
                                              ECODE) THEN
                DBG('2 Haath from fn_amt1_to_amt2...' || ECODE);
              
                RAISE EXP_CONV;
              ELSE
                TB_HOFF_PROD(JAI + I).EXCH_RATE := L_XRATE;
                TB_HOFF_PROD(JAI + I).LCY_AMOUNT := NVL(L_LCY_AMT, 0);
              END IF;
            ELSE
              TB_HOFF_PROD(JAI + I).EXCH_RATE := NULL;
              TB_HOFF_PROD(JAI + I).FCY_AMOUNT := NULL;
              TB_HOFF_PROD(JAI + I).LCY_AMOUNT := REC.PAST_ACQUIRED_AMT -
                                                  REC.PAST_ACQUIRED_ADJ;
            
            END IF;
            DBG('tb_hoff_prod(jai+i).fcy_amount ' || TB_HOFF_PROD(JAI + I)
                .FCY_AMOUNT);
            DBG('tb_hoff_prod(jai+i).lcy_amount ' || TB_HOFF_PROD(JAI + I)
                .LCY_AMOUNT);
            TB_HOFF_PROD(JAI + I).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PROD(JAI + I)
                                                                               .AC_CCY,
                                                                               TB_HOFF_PROD(JAI + I)
                                                                               .FCY_AMOUNT,
                                                                               LCY,
                                                                               TB_HOFF_PROD(JAI + I)
                                                                               .LCY_AMOUNT);
            IF TB_HOFF_PROD(JAI + I).LCY_AMOUNT = 0 THEN
              DBG('lcy amount is zero we can not post this even in prod accr');
              TB_HOFF_PROD.DELETE(JAI + I);
            ELSE
              SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
              TEMP_HOFF(SR) := TB_HOFF_PROD(JAI + I);
              TB_HOFF_PROD.DELETE(JAI + I);
            END IF;
          ELSIF (L_FRM_NO = REC.FRM_NO AND L_TBLOOKUP(I)
                .AMTTAG = 'IACR_ADJ_CURR' AND REC.ACQUIRED_AMT <> 0) THEN
            DBG('In the else cond for IACR_ADJ_CURR');
            TB_HOFF_PROD(JAI + I) := TB_BASIC_HOFF(1);
            TB_HOFF_PROD(JAI + I).TRN_REF_NO := L_REF;
            TB_HOFF_PROD(JAI + I).AC_NO := L_TBLOOKUP(I).ACCOUNT;
            TB_HOFF_PROD(JAI + I).AC_BRANCH := REC.BRN;
            TB_HOFF_PROD(JAI + I).AC_CCY := REC.CCY;
            TB_HOFF_PROD(JAI + I).DRCR_IND := L_TBLOOKUP(I).DRCRIND;
            TB_HOFF_PROD(JAI + I).TRN_CODE := L_TBLOOKUP(I).TRNCODE;
            TB_HOFF_PROD(JAI + I).AMOUNT_TAG := L_TBLOOKUP(I).AMTTAG;
            TB_HOFF_PROD(JAI + I).NETTING_IND := L_TBLOOKUP(I).NETIND;
            TB_HOFF_PROD(JAI + I).AVLDAYS := 0;
            TB_HOFF_PROD(JAI + I).MIS_HEAD := L_TBLOOKUP(I).MIS_HEAD;
          
            TB_HOFF_PROD(JAI + I).PRODUCT_ACCRUAL := 'P';
            DBG('ac no is ' || TB_HOFF_PROD(JAI + I).AC_NO || '~' || TB_HOFF_PROD(JAI + I)
                .AC_CCY);
            IF G_STTM_CUSTACC.CCY <> LCY THEN
            
              TB_HOFF_PROD(JAI + I).FCY_AMOUNT := NVL(REC.ACQUIRED_AMT, 0) -
                                                  NVL(REC.ACQUIRED_ADJ, 0);
            
              L_XRATE   := NULL;
              L_LCY_AMT := NULL;
              IF NOT
                  ICPKSS_UTIL.FN_AMT1_TO_AMT2(REC.BRN,
                                              REC.CCY,
                                              LCY,
                                              TB_HOFF_PROD(JAI + I).FCY_AMOUNT,
                                              'Y',
                                              L_LCY_AMT,
                                              L_XRATE,
                                              ECODE) THEN
                DBG('2 Haath from fn_amt1_to_amt2...' || ECODE);
              
                RAISE EXP_CONV;
              ELSE
                TB_HOFF_PROD(JAI + I).EXCH_RATE := L_XRATE;
                TB_HOFF_PROD(JAI + I).LCY_AMOUNT := NVL(L_LCY_AMT, 0);
              END IF;
            ELSE
              TB_HOFF_PROD(JAI + I).EXCH_RATE := NULL;
              TB_HOFF_PROD(JAI + I).FCY_AMOUNT := NULL;
            
              TB_HOFF_PROD(JAI + I).LCY_AMOUNT := NVL(REC.ACQUIRED_AMT, 0) -
                                                  NVL(REC.ACQUIRED_ADJ, 0);
            
            END IF;
            DBG('tb_hoff_prod(jai+i).fcy_amount ' || TB_HOFF_PROD(JAI + I)
                .FCY_AMOUNT);
            DBG('tb_hoff_prod(jai+i).lcy_amount ' || TB_HOFF_PROD(JAI + I)
                .LCY_AMOUNT);
            TB_HOFF_PROD(JAI + I).LCY_AMOUNT := ICPKSS_UTIL.FN_SIGNIFICANT_AMT(TB_HOFF_PROD(JAI + I)
                                                                               .AC_CCY,
                                                                               TB_HOFF_PROD(JAI + I)
                                                                               .FCY_AMOUNT,
                                                                               LCY,
                                                                               TB_HOFF_PROD(JAI + I)
                                                                               .LCY_AMOUNT);
            IF TB_HOFF_PROD(JAI + I).LCY_AMOUNT = 0 THEN
              DBG('lcy amount is zero we can not post this even in prod accr');
              TB_HOFF_PROD.DELETE(JAI + I);
            ELSE
              SR := NVL(TEMP_HOFF.COUNT, 0) + 1;
              TEMP_HOFF(SR) := TB_HOFF_PROD(JAI + I);
              TB_HOFF_PROD.DELETE(JAI + I);
            END IF;
          
          END IF;
        END LOOP;
      END IF;
    
      DBG('Before updating the entries passed for the product');
      UPDATE ICTBS_PROD_ACCR_ENTRIES
         SET ENTRY_PASSED = 'Y', TRN_DT = GLOBAL.APPLICATION_DATE
       WHERE BRN = P_BRN
         AND PROD = REC.PROD
         AND FRM_NO = REC.FRM_NO
         AND CCY = REC.CCY
         AND STATUS = REC.STATUS
         AND VALUE_DT = REC.VALUE_DT
         AND ENTRY_PASSED = 'N';
    
      IF SQL%NOTFOUND THEN
        DBG('Failed in update of ICTB_PROD_ACCR_ENTRIES');
        RAISE EXP_CONV;
      END IF;
    
    END LOOP;
  
    HOFF_COUNT := TEMP_HOFF.COUNT;
    CONS_COUNT := TB_HOFF_PRODUCT.COUNT;
    DBG('Hoff/ cons count are ' || HOFF_COUNT || '~' || CONS_COUNT);
    IF CONS_COUNT <> 0 THEN
      CONS_COUNT := CONS_COUNT + 1;
    END IF;
    JP := TEMP_HOFF.FIRST;
    WHILE JP <= TEMP_HOFF.LAST LOOP
      TB_HOFF_PRODUCT(CONS_COUNT + JP) := TEMP_HOFF(JP);
      JP := TEMP_HOFF.NEXT(JP);
    END LOOP;
  
    DBG('going out of prod accrual' || TB_HOFF_PRODUCT.COUNT);
  
    IF TB_HOFF_PRODUCT.COUNT <> 0 THEN
      DBG('here hoff_prod has got entries ' || TB_HOFF_PRODUCT.COUNT);
      OVPKSS.PR_INITERRTBL;
      GLOBAL.SET_PRODUCT_ACCRUAL('P');
      IF NOT ACPKSS.FN_ACHANDOFF(P_BRN || 'IC',
                                 1,
                                 GLOBAL.APPLICATION_DATE,
                                 TB_HOFF_PRODUCT,
                                 'B',
                                 'Y',
                                 'N',
                                 GLOBAL.USER_ID,
                                 ERRMSG,
                                 EPRM) THEN
        DBG('Failed in passing the entry...log this');
        TB_HOFF_PRODUCT.DELETE;
        RAISE EXP_CONV;
      END IF;
      TB_HOFF_PRODUCT.DELETE;
      GLOBAL.SET_PRODUCT_ACCRUAL('N');
    ELSE
      DBG('no entries for prod accrual also');
    END IF;
    COMMIT;
  
    RETURN RETSTAT;
  EXCEPTION
    WHEN EXP_CONV THEN
      DBG('PROBS DURING CONVERSION in fn_prod_accr_acctng');
      DBG('Rollback done here -sp_prod_accr');
      ROLLBACK TO SP_PROD_ACCR;
      TB_HOFF_PRODUCT.DELETE(JAI + NUM);
      RETURN - 1;
    WHEN OTHERS THEN
      DBG('IN WOT of fn_prod_accr_acctng ' || SQLERRM);
      DBG('Trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DBG('Rollback done here -sp_prod_accr');
      ROLLBACK TO SP_PROD_ACCR;
      TB_HOFF_PRODUCT.DELETE(JAI + NUM);
      RETURN - 1;
  END FN_PROD_ACCR_ACCTNG;

  FUNCTION FN_FIND_LAST_CHILD(P_PARENT_PHY_BRN VARCHAR2,
                              P_PARENT_PHY_ACC VARCHAR2,
                              P_CHILD_SYS_ACC  VARCHAR2,
                              P_CHILD_SYS_BRN  VARCHAR2,
                              P_AMOUNT         NUMBER,
                              P_TAG            VARCHAR2) RETURN BOOLEAN IS
    L_BRANCH  ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACCOUNT ILTB_SYS_ACCOUNT.ACCOUNT%TYPE;
  BEGIN
    DBG('iNSIDE fn_find_last_child');
    DBG('p_tag value is-->' || P_TAG);
    IF P_TAG = 'ILIQ' THEN
    
      IF G_TB_SYS_ACCTS.EXISTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN) THEN
      
        IF G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
         .G_TB_CHILD_ACCTS.COUNT > 0 THEN
        
          BEGIN
            SELECT BRANCH_CODE, ACCOUNT
              INTO L_BRANCH, L_ACCOUNT
              FROM ILTB_SYS_ACCOUNT
             WHERE SYSTEM_ACCOUNT_BRANCH = P_CHILD_SYS_BRN
               AND SYSTEM_ACCOUNT = P_CHILD_SYS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('selection of physical account failed- ' || SQLERRM);
              L_BRANCH  := NULL;
              L_ACCOUNT := NULL;
          END;
          DBG('l_branch--->' || L_BRANCH);
          DBG('l_account--->' || L_ACCOUNT);
          IF G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_CHILD_ACCTS.EXISTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN) THEN
            G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).P_CONT_AMT := NVL(G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
                                                                                                                                          .P_CONT_AMT,
                                                                                                                                          0) -
                                                                                                                                      NVL(P_AMOUNT,
                                                                                                                                          0);
          END IF;
          IF G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_CHILD_ACCTS.EXISTS(L_ACCOUNT || L_BRANCH) THEN
            G_TB_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS.DELETE(L_ACCOUNT ||
                                                                                         L_BRANCH);
          END IF;
        END IF;
      END IF;
    
    ELSIF P_TAG = 'TAX' THEN
    
      IF G_TB_SYS_ACCTS_TAX.EXISTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN) THEN
      
        IF G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
         .G_TB_CHILD_ACCTS_TAX.COUNT > 0 THEN
        
          BEGIN
            SELECT BRANCH_CODE, ACCOUNT
              INTO L_BRANCH, L_ACCOUNT
              FROM ILTB_SYS_ACCOUNT
             WHERE SYSTEM_ACCOUNT_BRANCH = P_CHILD_SYS_BRN
               AND SYSTEM_ACCOUNT = P_CHILD_SYS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('selection of physical account failed- ' || SQLERRM);
              L_BRANCH  := NULL;
              L_ACCOUNT := NULL;
          END;
          DBG('l_branch--->' || L_BRANCH);
          DBG('l_account--->' || L_ACCOUNT);
          IF G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_CHILD_ACCTS_TAX.EXISTS(P_PARENT_PHY_ACC ||
                                          P_PARENT_PHY_BRN) THEN
            G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).P_CONT_AMT := NVL(G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
                                                                                                                                                  .P_CONT_AMT,
                                                                                                                                                  0) -
                                                                                                                                              NVL(P_AMOUNT,
                                                                                                                                                  0);
          END IF;
          IF G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_CHILD_ACCTS_TAX.EXISTS(L_ACCOUNT || L_BRANCH) THEN
            G_TB_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_CHILD_ACCTS_TAX.DELETE(L_ACCOUNT ||
                                                                                                 L_BRANCH);
          END IF;
        END IF;
      END IF;
    
    END IF;
  
    DBG('SUCCESS FROM fn_find_last_child');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('fn_find_last_child function failed- ' || SQLERRM);
      RETURN FALSE;
  END FN_FIND_LAST_CHILD;

  FUNCTION FN_LIQ_ADJUSTMENT(P_BRN     IN ILTB_SYS_ACCOUNT.SYSTEM_ACCOUNT_BRANCH%TYPE,
                             P_ACC     IN ILTB_SYS_ACCOUNT.SYSTEM_ACCOUNT%TYPE,
                             P_PHY_BRN IN ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE,
                             P_PHY_ACC IN ILTB_SYS_ACCOUNT.ACCOUNT%TYPE,
                             P_AMT     IN NUMBER,
                             P_TAG     IN VARCHAR2) RETURN BOOLEAN IS
  
    L_TB_CHILD_ACCTS     TY_TB_CHILD_ACCTS;
    L_TB_CHILD_ACCTS_TAX TY_TB_CHILD_ACCTS_TAX;
  
    CURSOR CUR_CHILD_ACCS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM ILTM_ACCOUNT
       WHERE PARENT_ACCOUNT = P_ACC
         AND PARENT_ACCOUNT_BRANCH = P_BRN
         AND ACCOUNT <> P_ACC
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
  
    TYPE TY_TB_ACCTS IS TABLE OF CUR_CHILD_ACCS%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_SYS_ACCS TY_TB_ACCTS;
    L_IDX         PLS_INTEGER;
  
  BEGIN
    DBG('Inside function fn_liq_adjustment');
    DBG('physiccal branch=' || P_PHY_BRN || '  physical acocunt=' ||
        P_PHY_ACC);
    DBG('Amount is-->' || P_AMT);
    DBG('p_tag is-->' || P_TAG);
    IF P_TAG = 'ILIQ' THEN
      IF NOT G_TB_SYS_ACCTS.EXISTS(P_PHY_ACC || P_PHY_BRN) THEN
      
        IF CUR_CHILD_ACCS%ISOPEN THEN
          CLOSE CUR_CHILD_ACCS;
        END IF;
      
        OPEN CUR_CHILD_ACCS(P_PHY_BRN, P_PHY_ACC);
        FETCH CUR_CHILD_ACCS BULK COLLECT
          INTO L_TB_SYS_ACCS;
        CLOSE CUR_CHILD_ACCS;
      
        IF L_TB_SYS_ACCS.COUNT > 0 THEN
          L_IDX := L_TB_SYS_ACCS.FIRST;
          WHILE L_IDX IS NOT NULL LOOP
            L_TB_CHILD_ACCTS(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_ACCOUNT := L_TB_SYS_ACCS(L_IDX)
                                                                                                            .ACCOUNT;
            L_TB_CHILD_ACCTS(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_CONT_AMT := 0;
          
            L_IDX := L_TB_SYS_ACCS.NEXT(L_IDX);
          END LOOP;
        
          L_TB_CHILD_ACCTS(P_PHY_ACC || P_PHY_BRN).P_ACCOUNT := P_PHY_ACC;
          L_TB_CHILD_ACCTS(P_PHY_ACC || P_PHY_BRN).P_CONT_AMT := P_AMT;
        
          G_TB_SYS_ACCTS(P_PHY_ACC || P_PHY_BRN).G_TB_CHILD_ACCTS := L_TB_CHILD_ACCTS;
        END IF;
      END IF;
    
    ELSIF P_TAG = 'TAX' THEN
      IF NOT G_TB_SYS_ACCTS_TAX.EXISTS(P_PHY_ACC || P_PHY_BRN) THEN
      
        IF CUR_CHILD_ACCS%ISOPEN THEN
          CLOSE CUR_CHILD_ACCS;
        END IF;
      
        OPEN CUR_CHILD_ACCS(P_PHY_BRN, P_PHY_ACC);
        FETCH CUR_CHILD_ACCS BULK COLLECT
          INTO L_TB_SYS_ACCS;
        CLOSE CUR_CHILD_ACCS;
      
        IF L_TB_SYS_ACCS.COUNT > 0 THEN
          L_IDX := L_TB_SYS_ACCS.FIRST;
          WHILE L_IDX IS NOT NULL LOOP
            L_TB_CHILD_ACCTS_TAX(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_ACCOUNT := L_TB_SYS_ACCS(L_IDX)
                                                                                                                .ACCOUNT;
            L_TB_CHILD_ACCTS_TAX(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_CONT_AMT := 0;
          
            L_IDX := L_TB_SYS_ACCS.NEXT(L_IDX);
          END LOOP;
        
          L_TB_CHILD_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).P_ACCOUNT := P_PHY_ACC;
          L_TB_CHILD_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).P_CONT_AMT := P_AMT;
        
          G_TB_SYS_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).G_TB_CHILD_ACCTS_TAX := L_TB_CHILD_ACCTS_TAX;
        END IF;
      END IF;
    
    END IF;
  
    DBG('Success from fn_liq_adjustment');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('fn_liq_adjustment function failed- ' || SQLERRM);
      RETURN FALSE;
  END FN_LIQ_ADJUSTMENT;

  FUNCTION FN_ONLIQ_ADJUSTMENT(P_PHY_BRN IN ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE,
                               P_PHY_ACC IN ILTB_SYS_ACCOUNT.ACCOUNT%TYPE,
                               P_AMT     IN NUMBER,
                               P_TAG     IN VARCHAR2) RETURN BOOLEAN IS
  
    CURSOR CUR_CHILD_ACCS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM ILTM_ACCOUNT
       WHERE PARENT_ACCOUNT = P_ACC
         AND PARENT_ACCOUNT_BRANCH = P_BRN
         AND ACCOUNT <> P_ACC
         AND RECORD_STAT = 'O'
         AND AUTH_STAT = 'A';
  
    TYPE TY_TB_ACCTS IS TABLE OF CUR_CHILD_ACCS%ROWTYPE INDEX BY PLS_INTEGER;
    L_TB_SYS_ACCS TY_TB_ACCTS;
    L_IDX         PLS_INTEGER;
  
    L_TB_ONL_CHILD_ACCTS     TY_TB_ONL_CHILD_ACCTS;
    L_TB_ONL_CHILD_ACCTS_TAX TY_TB_ONL_CHILD_ACCTS_TAX;
  
  BEGIN
    DBG('Inside function fn_onliq_adjustment');
    DBG('physiccal branch=' || P_PHY_BRN || '  physical acocunt=' ||
        P_PHY_ACC);
    DBG('Amount is-->' || P_AMT);
    DBG('p_tag is-->' || P_TAG);
    IF P_TAG = 'ILIQ' THEN
      G_TB_ONL_SYS_ACCTS.DELETE(P_PHY_ACC || P_PHY_BRN);
    
      IF NOT G_TB_ONL_SYS_ACCTS.EXISTS(P_PHY_ACC || P_PHY_BRN) THEN
        DBG('so far no accounts exists...');
        IF CUR_CHILD_ACCS%ISOPEN THEN
          CLOSE CUR_CHILD_ACCS;
        END IF;
      
        OPEN CUR_CHILD_ACCS(P_PHY_BRN, P_PHY_ACC);
        FETCH CUR_CHILD_ACCS BULK COLLECT
          INTO L_TB_SYS_ACCS;
        CLOSE CUR_CHILD_ACCS;
      
        IF L_TB_SYS_ACCS.COUNT > 0 THEN
          L_IDX := L_TB_SYS_ACCS.FIRST;
          WHILE L_IDX IS NOT NULL LOOP
            L_TB_ONL_CHILD_ACCTS(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_ACCOUNT := L_TB_SYS_ACCS(L_IDX)
                                                                                                                .ACCOUNT;
            L_TB_ONL_CHILD_ACCTS(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_CONT_AMT := 0;
          
            L_IDX := L_TB_SYS_ACCS.NEXT(L_IDX);
          END LOOP;
        
          L_TB_ONL_CHILD_ACCTS(P_PHY_ACC || P_PHY_BRN).P_ACCOUNT := P_PHY_ACC;
          L_TB_ONL_CHILD_ACCTS(P_PHY_ACC || P_PHY_BRN).P_CONT_AMT := P_AMT;
        
          G_TB_ONL_SYS_ACCTS(P_PHY_ACC || P_PHY_BRN).G_TB_ONL_CHILD_ACCTS := L_TB_ONL_CHILD_ACCTS;
          DBG('populated the plsql table');
        END IF;
      END IF;
    ELSIF P_TAG = 'TAX' THEN
      G_TB_ONL_SYS_ACCTS_TAX.DELETE(P_PHY_ACC || P_PHY_BRN);
      IF NOT G_TB_ONL_SYS_ACCTS_TAX.EXISTS(P_PHY_ACC || P_PHY_BRN) THEN
        DBG('so far no accounts exists for tax...');
        IF CUR_CHILD_ACCS%ISOPEN THEN
          CLOSE CUR_CHILD_ACCS;
        END IF;
      
        OPEN CUR_CHILD_ACCS(P_PHY_BRN, P_PHY_ACC);
        FETCH CUR_CHILD_ACCS BULK COLLECT
          INTO L_TB_SYS_ACCS;
        CLOSE CUR_CHILD_ACCS;
      
        IF L_TB_SYS_ACCS.COUNT > 0 THEN
          L_IDX := L_TB_SYS_ACCS.FIRST;
          WHILE L_IDX IS NOT NULL LOOP
            L_TB_ONL_CHILD_ACCTS_TAX(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_ACCOUNT := L_TB_SYS_ACCS(L_IDX)
                                                                                                                    .ACCOUNT;
            L_TB_ONL_CHILD_ACCTS_TAX(L_TB_SYS_ACCS(L_IDX).ACCOUNT || L_TB_SYS_ACCS(L_IDX).BRANCH_CODE).P_CONT_AMT := 0;
          
            L_IDX := L_TB_SYS_ACCS.NEXT(L_IDX);
          END LOOP;
        
          L_TB_ONL_CHILD_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).P_ACCOUNT := P_PHY_ACC;
          L_TB_ONL_CHILD_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).P_CONT_AMT := P_AMT;
        
          G_TB_ONL_SYS_ACCTS_TAX(P_PHY_ACC || P_PHY_BRN).G_TB_ONL_CHILD_ACCTS_TAX := L_TB_ONL_CHILD_ACCTS_TAX;
          DBG('populated the plsql table for tax');
        END IF;
      END IF;
    
    END IF;
    DBG('Success from fn_onliq_adjustment');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('fn_onliq_adjustment function failed- ' || SQLERRM);
      RETURN FALSE;
  END FN_ONLIQ_ADJUSTMENT;

  FUNCTION FN_MARK_BKCALC_FOR_UDEVALS(P_BRN ICTBS_ACC_PR.BRN%TYPE,
                                      P_ACC ICTBS_ACC_PR.ACC%TYPE)
    RETURN BOOLEAN IS
    TYPE T1 IS TABLE OF ICTBS_BACK_DATED_EVENTS.BRN%TYPE INDEX BY BINARY_INTEGER;
    TYPE T2 IS TABLE OF ICTBS_BACK_DATED_EVENTS.ACC%TYPE INDEX BY BINARY_INTEGER;
    TYPE T3 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROD%TYPE INDEX BY BINARY_INTEGER;
    TYPE T4 IS TABLE OF ICTBS_BACK_DATED_EVENTS.EVENT_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T5 IS TABLE OF ICTBS_BACK_DATED_EVENTS.EVENT_DATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T6 IS TABLE OF ICTBS_BACK_DATED_EVENTS.VALUE_DT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T7 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_ID%TYPE INDEX BY BINARY_INTEGER;
    TYPE T8 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_AMT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T9 IS TABLE OF ICTBS_BACK_DATED_EVENTS.RATE_CODE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T10 IS TABLE OF ICTBS_BACK_DATED_EVENTS.RATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T11 IS TABLE OF ICTBS_BACK_DATED_EVENTS.UDE_CHG_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE T12 IS TABLE OF ICTBS_BACK_DATED_EVENTS.ENT_AMOUNT%TYPE INDEX BY BINARY_INTEGER;
    TYPE T13 IS TABLE OF ICTBS_BACK_DATED_EVENTS.DRCR_IND%TYPE INDEX BY BINARY_INTEGER;
    TYPE T14 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROCESS_STATUS%TYPE INDEX BY BINARY_INTEGER;
    TYPE T15 IS TABLE OF ICTBS_BACK_DATED_EVENTS.PROCESS_FROM_DATE%TYPE INDEX BY BINARY_INTEGER;
    TB_BKDT_EVENTS_BRN            T1;
    TB_BKDT_EVENTS_ACC            T2;
    TB_BKDT_EVENTS_PROD           T3;
    TB_BKDT_EVENTS_EVENT_TYPE     T4;
    TB_BKDT_EVENTS_EVENT_DATE     T5;
    TB_BKDT_EVENTS_VALUE_DT       T6;
    TB_BKDT_EVENTS_UDE_ID         T7;
    TB_BKDT_EVENTS_UDE_AMT        T8;
    TB_BKDT_EVENTS_RATE_CODE      T9;
    TB_BKDT_EVENTS_RATE           T10;
    TB_BKDT_EVENTS_UDE_CHG_TYPE   T11;
    TB_BKDT_EVENTS_ENT_AMOUNT     T12;
    TB_BKDT_EVENTS_ENT_DRCR_IND   T13;
    TB_BKDT_EVENTS_ENT_PROC_STAT  T14;
    TB_BKDT_EVENTS_ENT_PROC_FRMDT T15;
    TYPE TB1 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.BRN%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB2 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.PROD%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB3 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.COND_TYPE%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB4 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.COND_KEY%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB5 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.UDE_ID%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB6 IS TABLE OF ICTBS_BACK_DATED_UDEVALS.UDE_EFF_DT%TYPE INDEX BY BINARY_INTEGER;
    TYPE TB7 IS TABLE OF ROWID INDEX BY BINARY_INTEGER;
    TB_BKDT_EVEDEL_BRN        TB1;
    TB_BKDT_EVEDEL_PROD       TB2;
    TB_BKDT_EVEDEL_COND_TYPE  TB3;
    TB_BKDT_EVEDEL_COND_KEY   TB4;
    TB_BKDT_EVEDEL_UDE_ID     TB5;
    TB_BKDT_EVEDEL_UDE_EFF_DT TB6;
    TYPE TC1 IS TABLE OF ICTBS_ACC_PR.BKVAL_MINCALC_DATE%TYPE INDEX BY BINARY_INTEGER;
    TYPE TC2 IS TABLE OF ICTBS_ACC_PR.BKVAL_RECALC_FLAG%TYPE INDEX BY BINARY_INTEGER;
    TYPE TC3 IS TABLE OF ICTBS_ACC_PR.NEXT_LIQ_DT%TYPE INDEX BY BINARY_INTEGER;
    TB_BKACCPR_NEXTLIQ_DT    TC3;
    L_UDE_EFF_DT             ICTBS_BACK_DATED_UDEVALS.UDE_EFF_DT%TYPE;
    L_BV_POOL_PERIOD         STTMS_BRANCH.BACK_VALUE_DAYS%TYPE;
    TB_BKACCPR_RECALC_FLAG   TC2;
    TB_BKACCPR_MINCALC_DATE  TC1;
    TB_BKACCPR_ROWID         TB7;
    L_BACK_VALUED_EVENTS_REC ICTBS_BACK_DATED_EVENTS%ROWTYPE;
    NULREC                   ICTBS_BACK_DATED_EVENTS%ROWTYPE;
    I                        NUMBER := 0;
    J                        NUMBER := 0;
    SR                       NUMBER := 0;
    L_ICTMS_ACC              ICTM_ACC%ROWTYPE;
    CURSOR CR_UDEVALS(P_BRN VARCHAR2, P_ACC VARCHAR2) IS
      SELECT *
        FROM ICTBS_BACK_DATED_UDEVALS I, ICTMS_PR_INT P
       WHERE I.BRN = P_BRN
         AND I.COND_KEY = P_BRN || P_ACC
         AND I.PROD = P.PRODUCT_CODE
         AND (P.BACK_CALC_FLAG = 'Y' OR
             (P.DEFERRED_FLAG = 'Y' AND P.CALC_DAYS > 0))
       ORDER BY COND_TYPE, COND_KEY, UDE_EFF_DT DESC;
  
    CURSOR CR_SC_ACC_PR(P_BRN VARCHAR2, P_ACC VARCHAR2, P_PROD VARCHAR2) IS
      SELECT A.*, ROWID ROW_ID
        FROM ICTBS_ACC_PR A
       WHERE A.BRN = P_BRN
         AND A.ACC = P_ACC
         AND A.PROD = P_PROD;
    CURSOR CR_GC_ACC_PR(P_BRN      VARCHAR2,
                        P_PROD     VARCHAR2,
                        P_COND_KEY VARCHAR2) IS
      SELECT A.*, ROWID ROW_ID
        FROM ICTBS_ACC_PR A
       WHERE A.BRN = P_BRN
         AND A.PROD = P_PROD
         AND A.ACLASS || A.CCY = P_COND_KEY
         AND NOT EXISTS (SELECT 1
                FROM ICTM_PR_INT_ACLASS I
               WHERE I.SC_ONLY = 'Y'
                 AND I.RECORD_STAT = 'N'
                 AND I.PRODUCT_CODE = A.PROD
                 AND I.ACLASS = A.ACLASS
                 AND I.CCY = A.CCY);
    FUNCTION FN_MARK_BKCALC_FOR_IL(P_BRANCH                IN ILTBS_SYS_ACCOUNT.BRANCH_CODE%TYPE,
                                   P_PRODUCT_CODE          IN ICTMS_PR_INT.PRODUCT_CODE%TYPE,
                                   P_LIQN_START_ACCOUNT    IN ICTMS_PR_INT.LIQN_START_ACCOUNT%TYPE,
                                   P_START_LIQ_DT          IN ILTBS_SYS_ACCOUNT.EFF_DATE%TYPE,
                                   P_LIQN_DAYS             IN ICTMS_PR_INT.LIQN_DAYS%TYPE,
                                   P_LIQN_MONTHS           IN ICTMS_PR_INT.LIQN_MONTHS%TYPE,
                                   P_LIQN_YEARS            IN ICTMS_PR_INT.LIQN_YEARS%TYPE,
                                   P_UDE_EFF_DATE          IN ILTBS_SYS_ACCOUNT.EFF_DATE%TYPE,
                                   P_CHANGE_TYPE           IN VARCHAR2,
                                   P_CONDITION_TYPE        IN NUMBER,
                                   P_COND_KEY              IN ICTBS_BACK_DATED_UDEVALS.COND_KEY%TYPE,
                                   TB_BKACCPR_RECALC_FLAG  IN OUT TC2,
                                   TB_BKACCPR_MINCALC_DATE IN OUT TC1,
                                   TB_BKACCPR_ROWID        IN OUT TB7,
                                   TB_BKACCPR_NEXTLIQ_DT   IN OUT TC3,
                                   P_SR                    IN OUT NUMBER)
      RETURN BOOLEAN IS
      CURSOR CR_SPECIAL_CONDITIONS(C_ACC VARCHAR2, C_UDE_EFF_DATE DATE) IS
        SELECT A.*,
               B.SYSTEM_ACCOUNT_BRANCH,
               B.ACCOUNT CUST_ACCOUNT,
               A.ROWID
          FROM ICTBS_ACC_PR A, ILTBS_SYS_ACCOUNT B, ICTMS_ACC_PR C
         WHERE A.BRN = P_BRANCH
           AND A.PROD = P_PRODUCT_CODE
           AND B.BRANCH_CODE = A.BRN
           AND INSTR(C_ACC, B.ACCOUNT, 1) > 0
           AND B.SYSTEM_ACCOUNT = A.ACC
           AND NVL(A.SYSTEM_ACCOUNT, 'N') = 'Y'
           AND C.BRN = A.BRN
           AND C.ACC = B.ACCOUNT
           AND C.PROD = P_PRODUCT_CODE
           AND NVL(A.STOP_IC, 'N') NOT IN ('D', 'Y')
           AND NVL(C.WAIVE, 'N') = 'N'
           AND (NVL(A.LAST_LIQ_DT, (C_UDE_EFF_DATE - 1)) >= C_UDE_EFF_DATE OR
               A.BKVAL_MINCALC_DATE IS NOT NULL);
      CURSOR CR_GENERAL_CONDITIONS(C_UDE_EFF_DATE DATE) IS
        SELECT A.*,
               B.SYSTEM_ACCOUNT_BRANCH,
               B.ACCOUNT CUST_ACCOUNT,
               A.ROWID
          FROM ICTBS_ACC_PR A, ILTBS_SYS_ACCOUNT B
         WHERE A.BRN = P_BRANCH
           AND A.PROD = P_PRODUCT_CODE
           AND INSTR(P_COND_KEY, A.ACLASS || A.CCY, 1) > 0
           AND B.BRANCH_CODE = A.BRN
           AND B.SYSTEM_ACCOUNT = A.ACC
           AND NVL(A.SYSTEM_ACCOUNT, 'N') = 'Y'
           AND NVL(A.STOP_IC, 'N') NOT IN ('D', 'Y')
           AND ((NVL(A.LAST_LIQ_DT, C_UDE_EFF_DATE - 1) >= C_UDE_EFF_DATE AND
               NVL(A.SC_MAP_DT, C_UDE_EFF_DATE + 1) > C_UDE_EFF_DATE) OR
               A.BKVAL_MINCALC_DATE IS NOT NULL);
      CURSOR C_SYS_CUR(C_BRANCH       VARCHAR2,
                       C_GROUP_CODE   VARCHAR2,
                       C_UDE_EFF_DATE VARCHAR2) IS
        SELECT A.SYSTEM_ACCOUNT_BRANCH,
               A.SYSTEM_ACCOUNT,
               A.ACC_TYPE,
               B.PROD,
               B.ROWID
          FROM ILTBS_SYS_ACCOUNT A, ICTB_ACC_PR B
         WHERE B.BRN = A.BRANCH_CODE
           AND B.ACC = A.SYSTEM_ACCOUNT
           AND A.BRANCH_CODE = C_BRANCH
           AND A.GROUP_CODE = C_GROUP_CODE
           AND A.EFF_DATE =
               (SELECT MAX(EFF_DATE)
                  FROM ILTBS_SYS_ACCOUNT C
                 WHERE C.BRANCH_CODE = A.BRANCH_CODE
                   AND C.GROUP_CODE = A.GROUP_CODE
                   AND C.ACCOUNT = A.ACCOUNT
                   AND C.ACC_TYPE = A.ACC_TYPE
                   AND EFF_DATE <= C_UDE_EFF_DATE);
      L_NEXT_LIQD_DT          DATE;
      L_ROWID                 VARCHAR2(20);
      L_BKVAL_MINCALC_DATE    ICTBS_ACC_PR.BKVAL_MINCALC_DATE%TYPE;
      L_LAST_LIQ_DT           ICTBS_ACC_PR.LAST_LIQ_DT%TYPE;
      L_PREV_CUST_ACCOUNT     ICTBS_ACC_SYS_MAP.CUST_AC_NO%TYPE;
      L_COMBVT_DATE           DATE;
      L_COMBVT_DATE_POOL      DATE;
      L_VAL_DT                DATE;
      L_INT_START_DATE        DATE;
      L_MASTER_NEXT_LIQ_DT    DATE;
      L_MASTER_INT_START_DATE DATE;
      L_GROUP_CODE            ILTMS_GROUP_CODE.GROUP_CODE%TYPE;
      TYPE G_GRP_TAB IS TABLE OF ILTMS_GROUP_CODE.GROUP_CODE%TYPE INDEX BY VARCHAR2(64);
      G_GRP_LIST G_GRP_TAB;
    BEGIN
      DBG('Start of function fn_mark_bkcalc_for_il');
      DBG('Incoming parameters -->' || P_CONDITION_TYPE || '~' ||
          P_COND_KEY || '~' || P_UDE_EFF_DATE || '~' || P_PRODUCT_CODE || '~' ||
          P_LIQN_START_ACCOUNT);
      L_NEXT_LIQD_DT := NULL;
      IF P_CONDITION_TYPE = 0 THEN
      
        DBG('Inside spl condition check ');
        FOR REC IN CR_SPECIAL_CONDITIONS(SUBSTR(P_COND_KEY, 4),
                                         P_UDE_EFF_DATE) LOOP
          DBG('Some spl condition entries are there !!!');
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := NULL;
            DBG('For special condition liquidation start set ');
            DBG('Select interest start date for cust account - ' ||
                REC.CUST_ACCOUNT);
            SELECT INT_START_DATE
              INTO L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.BRN
               AND ACC = REC.CUST_ACCOUNT;
            DBG('Getting the next interest start date for date - ' ||
                L_INT_START_DATE);
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            DBG('Getting next liqd date for the prod - ' || REC.PROD ||
                ' and date - ' || L_INT_START_DATE);
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         L_INT_START_DATE,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          ELSIF (P_LIQN_START_ACCOUNT = 'N' AND L_NEXT_LIQD_DT IS NULL) THEN
            DBG('Liqd flag not set ');
            DBG('Getting next liqd date for the start liq date passed ');
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         P_START_LIQ_DT,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          END IF;
          SELECT GROUP_CODE
            INTO L_GROUP_CODE
            FROM ILTBS_SYS_ACCOUNT
           WHERE BRANCH_CODE = REC.BRN
             AND SYSTEM_ACCOUNT = REC.ACC;
          DBG('Group code selected for the account - ' || REC.ACC ||
              ' is - ' || L_GROUP_CODE);
          IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
            DBG('Updating for the group code the value 0 for eff_date - ' ||
                P_UDE_EFF_DATE);
            DBG('Branch value is ' || REC.BRN);
            FOR SYS_REC IN C_SYS_CUR(REC.BRN, L_GROUP_CODE, P_UDE_EFF_DATE) LOOP
              DBG('Inside sys account cursor - ' || SYS_REC.SYSTEM_ACCOUNT);
              TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
              TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(REC.BKVAL_MINCALC_DATE,
                                                         P_UDE_EFF_DATE),
                                                     P_UDE_EFF_DATE);
              TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
              TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_NEXT_LIQD_DT;
              P_SR := P_SR + 1;
            END LOOP;
            G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
          END IF;
          DBG('Selecting the back valued date from acc pr for account - ' ||
              REC.ACC);
          SELECT A.BKVAL_MINCALC_DATE, A.LAST_LIQ_DT, A.ROWID
            INTO L_BKVAL_MINCALC_DATE, L_LAST_LIQ_DT, L_ROWID
            FROM ICTBS_ACC_PR A
           WHERE BRN = P_BRANCH
             AND ACC = REC.ACC
             AND PROD = P_PRODUCT_CODE;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := NULL;
            DBG('Select interest start date for the account - ' ||
                REC.CUST_ACCOUNT);
            SELECT INT_START_DATE
              INTO L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.SYSTEM_ACCOUNT_BRANCH
               AND ACC = REC.CUST_ACCOUNT;
            DBG('Selecting the next int start date for date - ' ||
                L_INT_START_DATE);
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            DBG('Selecting next liq date for the date - ' ||
                L_INT_START_DATE);
            L_MASTER_NEXT_LIQ_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                               L_INT_START_DATE,
                                                                               GLOBAL.APPLICATION_DATE,
                                                                               P_LIQN_DAYS,
                                                                               P_LIQN_MONTHS,
                                                                               P_LIQN_YEARS);
          ELSE
            L_MASTER_NEXT_LIQ_DT := L_NEXT_LIQD_DT;
          END IF;
          DBG('Liquidation date for master in SC-->' ||
              L_MASTER_NEXT_LIQ_DT);
          IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
            DBG('Updating for the group code the value 0 for eff_date - ' ||
                P_UDE_EFF_DATE);
            DBG('Branch value is ' || REC.BRN);
            FOR SYS_REC IN C_SYS_CUR(REC.BRN, L_GROUP_CODE, P_UDE_EFF_DATE) LOOP
              DBG('Inside sys account cursor - ' || SYS_REC.SYSTEM_ACCOUNT);
              TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
              TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(L_BKVAL_MINCALC_DATE,
                                                         P_UDE_EFF_DATE),
                                                     P_UDE_EFF_DATE);
              TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
              TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_MASTER_NEXT_LIQ_DT;
              P_SR := P_SR + 1;
            END LOOP;
            G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
          END IF;
          DBG('Here AFTER the ROW TYPE UPDATE AND i ');
        END LOOP;
      ELSE
        L_PREV_CUST_ACCOUNT := '###';
        L_COMBVT_DATE       := NULL;
        FOR REC IN CR_GENERAL_CONDITIONS(P_UDE_EFF_DATE) LOOP
          DBG('In loop for general condition for acc -->' || REC.ACC);
          IF L_PREV_CUST_ACCOUNT <> REC.ACC THEN
            SELECT COMBVT_DATE, INT_START_DATE
              INTO L_COMBVT_DATE, L_INT_START_DATE
              FROM ICTMS_ACC
             WHERE BRN = REC.BRN
               AND ACC = REC.CUST_ACCOUNT;
          END IF;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_INT_START_DATE := ADD_MONTHS(L_INT_START_DATE,
                                           12 * P_LIQN_YEARS + P_LIQN_MONTHS) +
                                P_LIQN_DAYS - 1;
            L_NEXT_LIQD_DT   := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                           L_INT_START_DATE,
                                                                           GLOBAL.APPLICATION_DATE,
                                                                           P_LIQN_DAYS,
                                                                           P_LIQN_MONTHS,
                                                                           P_LIQN_YEARS);
          ELSIF (P_LIQN_START_ACCOUNT = 'N' AND L_NEXT_LIQD_DT IS NULL) THEN
            L_NEXT_LIQD_DT := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                         P_START_LIQ_DT,
                                                                         GLOBAL.APPLICATION_DATE,
                                                                         P_LIQN_DAYS,
                                                                         P_LIQN_MONTHS,
                                                                         P_LIQN_YEARS);
          END IF;
          SELECT GROUP_CODE
            INTO L_GROUP_CODE
            FROM ILTBS_SYS_ACCOUNT
           WHERE BRANCH_CODE = REC.BRN
             AND SYSTEM_ACCOUNT = REC.ACC;
          DBG('Group code selected for the account - ' || REC.ACC ||
              ' is - ' || L_GROUP_CODE);
          IF REC.LAST_LIQ_DT > NVL(L_COMBVT_DATE, REC.LAST_LIQ_DT - 1) THEN
            IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
              FOR SYS_REC IN C_SYS_CUR(REC.BRN,
                                       L_GROUP_CODE,
                                       P_UDE_EFF_DATE) LOOP
                L_VAL_DT := GREATEST(P_UDE_EFF_DATE,
                                     NVL(L_COMBVT_DATE, P_UDE_EFF_DATE));
                TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
                TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(REC.BKVAL_MINCALC_DATE,
                                                           L_VAL_DT),
                                                       L_VAL_DT);
                TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
                TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_NEXT_LIQD_DT;
                P_SR := P_SR + 1;
              END LOOP;
            END IF;
          END IF;
          SELECT COMBVT_DATE, INT_START_DATE
            INTO L_COMBVT_DATE_POOL, L_MASTER_INT_START_DATE
            FROM ICTMS_ACC
           WHERE BRN = REC.BRN
             AND ACC = REC.CUST_ACCOUNT;
          IF P_LIQN_START_ACCOUNT = 'Y' THEN
            L_MASTER_INT_START_DATE := ADD_MONTHS(L_MASTER_INT_START_DATE,
                                                  12 * P_LIQN_YEARS +
                                                  P_LIQN_MONTHS) +
                                       P_LIQN_DAYS - 1;
            L_MASTER_NEXT_LIQ_DT    := ICPKSS_RESOLVE_MAINT.FN_GET_NEXT_LIQD_DATE(REC.PROD,
                                                                                  L_MASTER_INT_START_DATE,
                                                                                  GLOBAL.APPLICATION_DATE,
                                                                                  P_LIQN_DAYS,
                                                                                  P_LIQN_MONTHS,
                                                                                  P_LIQN_YEARS);
          ELSE
            L_MASTER_NEXT_LIQ_DT := L_NEXT_LIQD_DT;
          END IF;
          SELECT A.BKVAL_MINCALC_DATE, A.LAST_LIQ_DT, A.ROWID
            INTO L_BKVAL_MINCALC_DATE, L_LAST_LIQ_DT, L_ROWID
            FROM ICTBS_ACC_PR A
           WHERE BRN = P_BRANCH
             AND ACC = REC.ACC
             AND PROD = P_PRODUCT_CODE;
          IF L_LAST_LIQ_DT > NVL(L_COMBVT_DATE_POOL, L_LAST_LIQ_DT - 1) THEN
            IF NOT G_GRP_LIST.EXISTS(L_GROUP_CODE) THEN
              DBG('Updating for the group code the value 0 for eff_date - ' ||
                  P_UDE_EFF_DATE);
              DBG('Branch value is ' || REC.BRN);
              FOR SYS_REC IN C_SYS_CUR(REC.BRN,
                                       L_GROUP_CODE,
                                       P_UDE_EFF_DATE) LOOP
                DBG('Inside sys account cursor - ' ||
                    SYS_REC.SYSTEM_ACCOUNT);
                L_VAL_DT := GREATEST(P_UDE_EFF_DATE,
                                     NVL(L_COMBVT_DATE_POOL, P_UDE_EFF_DATE));
                TB_BKACCPR_RECALC_FLAG(P_SR) := 'Y';
                TB_BKACCPR_MINCALC_DATE(P_SR) := LEAST(NVL(L_BKVAL_MINCALC_DATE,
                                                           L_VAL_DT),
                                                       L_VAL_DT);
                TB_BKACCPR_ROWID(P_SR) := SYS_REC.ROWID;
                TB_BKACCPR_NEXTLIQ_DT(P_SR) := L_MASTER_NEXT_LIQ_DT;
                P_SR := P_SR + 1;
              END LOOP;
              G_GRP_LIST(L_GROUP_CODE) := L_GROUP_CODE;
            END IF;
          END IF;
          L_PREV_CUST_ACCOUNT := REC.CUST_ACCOUNT;
        END LOOP;
      END IF;
      DBG('End of function fn_mark_bkcalc_for_il');
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('In when others of function fn_update_stopic' || SQLERRM);
        RETURN FALSE;
    END FN_MARK_BKCALC_FOR_IL;
  BEGIN
    DBG('entered the bkval udevals for an account');
    FOR C1 IN CR_UDEVALS(P_BRN, P_ACC) LOOP
      DBG('Just going to do the things for the acc..' || C1.COND_KEY || '~' ||
          C1.PROD);
      IF C1.COND_TYPE = 0 THEN
        DBG('Type Is O');
        I  := NVL(TB_BKDT_EVENTS_BRN.COUNT, 0) + 1;
        SR := NVL(TB_BKACCPR_RECALC_FLAG.COUNT, 0) + 1;
        FOR C2 IN CR_SC_ACC_PR(C1.BRN, SUBSTR(C1.COND_KEY, 4), C1.PROD) LOOP
          DBG('Inside loop of C2' || SR);
          IF NVL(C2.LAST_LIQ_DT, C1.UDE_EFF_DT - 1) >= C1.UDE_EFF_DT OR
             C2.BKVAL_MINCALC_DATE IS NOT NULL THEN
            TB_BKACCPR_RECALC_FLAG(SR) := 'Y';
            TB_BKACCPR_MINCALC_DATE(SR) := LEAST(NVL(C2.BKVAL_MINCALC_DATE,
                                                     C1.UDE_EFF_DT),
                                                 C1.UDE_EFF_DT);
            TB_BKACCPR_ROWID(SR) := C2.ROW_ID;
          
            DBG('tb_bkaccpr_mincalc_date(sr) before-->' ||
                TB_BKACCPR_MINCALC_DATE(SR));
            L_ICTMS_ACC := ICPKS_CACHE.FN_GET_ICTM_ACC(C2.ACC, C2.BRN);
            DBG('l_ictms_acc.int_start_date-->' ||
                L_ICTMS_ACC.INT_START_DATE);
            TB_BKACCPR_MINCALC_DATE(SR) := GREATEST(TB_BKACCPR_MINCALC_DATE(SR),
                                                    L_ICTMS_ACC.INT_START_DATE);
            DBG('tb_bkaccpr_mincalc_date(sr) After-->' ||
                TB_BKACCPR_MINCALC_DATE(SR));
            SR                                    := SR + 1;
            L_BACK_VALUED_EVENTS_REC              := NULREC;
            L_BACK_VALUED_EVENTS_REC.BRN          := C2.BRN;
            L_BACK_VALUED_EVENTS_REC.ACC          := C2.ACC;
            L_BACK_VALUED_EVENTS_REC.PROD         := C2.PROD;
            L_BACK_VALUED_EVENTS_REC.EVENT_TYPE   := 'U';
            L_BACK_VALUED_EVENTS_REC.EVENT_DATE   := GLOBAL.APPLICATION_DATE;
            L_BACK_VALUED_EVENTS_REC.VALUE_DT     := C1.UDE_EFF_DT;
            L_BACK_VALUED_EVENTS_REC.UDE_ID       := C1.UDE_ID;
            L_BACK_VALUED_EVENTS_REC.UDE_AMT      := C1.AMT;
            L_BACK_VALUED_EVENTS_REC.RATE_CODE    := C1.RATE_CODE;
            L_BACK_VALUED_EVENTS_REC.RATE         := C1.RATE;
            L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE := C1.CHANGE_TYPE;
            IF C1.UDE_EFF_DT < C2.FIRST_FIRST_CALC_DATE THEN
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'E';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C2.FIRST_FIRST_CALC_DATE;
            ELSE
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'P';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C1.UDE_EFF_DT;
            END IF;
            TB_BKDT_EVENTS_BRN(I) := L_BACK_VALUED_EVENTS_REC.BRN;
            TB_BKDT_EVENTS_ACC(I) := L_BACK_VALUED_EVENTS_REC.ACC;
            TB_BKDT_EVENTS_PROD(I) := L_BACK_VALUED_EVENTS_REC.PROD;
            TB_BKDT_EVENTS_EVENT_TYPE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_TYPE;
            TB_BKDT_EVENTS_EVENT_DATE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_DATE;
            TB_BKDT_EVENTS_VALUE_DT(I) := L_BACK_VALUED_EVENTS_REC.VALUE_DT;
            TB_BKDT_EVENTS_UDE_ID(I) := L_BACK_VALUED_EVENTS_REC.UDE_ID;
            TB_BKDT_EVENTS_UDE_AMT(I) := L_BACK_VALUED_EVENTS_REC.UDE_AMT;
            TB_BKDT_EVENTS_RATE_CODE(I) := L_BACK_VALUED_EVENTS_REC.RATE_CODE;
            TB_BKDT_EVENTS_RATE(I) := L_BACK_VALUED_EVENTS_REC.RATE;
            TB_BKDT_EVENTS_UDE_CHG_TYPE(I) := L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE;
            TB_BKDT_EVENTS_ENT_AMOUNT(I) := L_BACK_VALUED_EVENTS_REC.ENT_AMOUNT;
            TB_BKDT_EVENTS_ENT_DRCR_IND(I) := L_BACK_VALUED_EVENTS_REC.DRCR_IND;
            TB_BKDT_EVENTS_ENT_PROC_STAT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS;
            TB_BKDT_EVENTS_ENT_PROC_FRMDT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE;
            I := I + 1;
            DBG('Here after the row type update and i ');
          END IF;
        END LOOP;
      ELSE
        DBG('before i');
        I := NVL(TB_BKDT_EVENTS_BRN.COUNT, 0) + 1;
        DBG('Affter i');
        SR := NVL(TB_BKACCPR_RECALC_FLAG.COUNT, 0) + 1;
        DBG('I am in else condition');
        FOR C3 IN CR_GC_ACC_PR(C1.BRN, C1.PROD, SUBSTR(C1.COND_KEY, 4)) LOOP
          DBG('Inside loop for cursor cr_gc_acc_pr-->Branch' || C1.BRN ||
              'Product - ' || C1.PROD || 'Condition Key - ' ||
              SUBSTR(C1.COND_KEY, 4));
          IF (NVL(C3.LAST_LIQ_DT, C1.UDE_EFF_DT - 1) >= C1.UDE_EFF_DT AND
             NVL(C3.SC_MAP_DT, C1.UDE_EFF_DT + 1) > C1.UDE_EFF_DT) OR
             C3.BKVAL_MINCALC_DATE IS NOT NULL THEN
            DBG('updating gc for the above');
            TB_BKACCPR_RECALC_FLAG(SR) := 'Y';
            DBG('After Y');
            TB_BKACCPR_MINCALC_DATE(SR) := LEAST(NVL(C3.BKVAL_MINCALC_DATE,
                                                     C1.UDE_EFF_DT),
                                                 C1.UDE_EFF_DT);
            DBG('After date');
            TB_BKACCPR_ROWID(SR) := C3.ROW_ID;
            DBG('After rowid');
            SR := SR + 1;
            DBG('After our hand');
            L_BACK_VALUED_EVENTS_REC              := NULREC;
            L_BACK_VALUED_EVENTS_REC.BRN          := C3.BRN;
            L_BACK_VALUED_EVENTS_REC.ACC          := C3.ACC;
            L_BACK_VALUED_EVENTS_REC.PROD         := C3.PROD;
            L_BACK_VALUED_EVENTS_REC.EVENT_TYPE   := 'U';
            L_BACK_VALUED_EVENTS_REC.EVENT_DATE   := GLOBAL.APPLICATION_DATE;
            L_BACK_VALUED_EVENTS_REC.VALUE_DT     := C1.UDE_EFF_DT;
            L_BACK_VALUED_EVENTS_REC.UDE_ID       := C1.UDE_ID;
            L_BACK_VALUED_EVENTS_REC.UDE_AMT      := C1.AMT;
            L_BACK_VALUED_EVENTS_REC.RATE_CODE    := C1.RATE_CODE;
            L_BACK_VALUED_EVENTS_REC.RATE         := C1.RATE;
            L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE := C1.CHANGE_TYPE;
            DBG('Just going for EP');
            IF C1.UDE_EFF_DT < C3.FIRST_FIRST_CALC_DATE THEN
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'E';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C3.FIRST_FIRST_CALC_DATE;
            ELSE
              L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS    := 'P';
              L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE := C1.UDE_EFF_DT;
            END IF;
            DBG('After EP');
            TB_BKDT_EVENTS_BRN(I) := L_BACK_VALUED_EVENTS_REC.BRN;
            TB_BKDT_EVENTS_ACC(I) := L_BACK_VALUED_EVENTS_REC.ACC;
            TB_BKDT_EVENTS_PROD(I) := L_BACK_VALUED_EVENTS_REC.PROD;
            TB_BKDT_EVENTS_EVENT_TYPE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_TYPE;
            TB_BKDT_EVENTS_EVENT_DATE(I) := L_BACK_VALUED_EVENTS_REC.EVENT_DATE;
            TB_BKDT_EVENTS_VALUE_DT(I) := L_BACK_VALUED_EVENTS_REC.VALUE_DT;
            TB_BKDT_EVENTS_UDE_ID(I) := L_BACK_VALUED_EVENTS_REC.UDE_ID;
            TB_BKDT_EVENTS_UDE_AMT(I) := L_BACK_VALUED_EVENTS_REC.UDE_AMT;
            TB_BKDT_EVENTS_RATE_CODE(I) := L_BACK_VALUED_EVENTS_REC.RATE_CODE;
            TB_BKDT_EVENTS_RATE(I) := L_BACK_VALUED_EVENTS_REC.RATE;
            TB_BKDT_EVENTS_UDE_CHG_TYPE(I) := L_BACK_VALUED_EVENTS_REC.UDE_CHG_TYPE;
            TB_BKDT_EVENTS_ENT_AMOUNT(I) := L_BACK_VALUED_EVENTS_REC.ENT_AMOUNT;
            TB_BKDT_EVENTS_ENT_DRCR_IND(I) := L_BACK_VALUED_EVENTS_REC.DRCR_IND;
            TB_BKDT_EVENTS_ENT_PROC_STAT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_STATUS;
            TB_BKDT_EVENTS_ENT_PROC_FRMDT(I) := L_BACK_VALUED_EVENTS_REC.PROCESS_FROM_DATE;
            DBG('Just going for i');
            I := I + 1;
          END IF;
        END LOOP;
      END IF;
      DBG('Inside else part for the call to fn_mark_bkcalc_for_il');
      DBG('ude eff date is ' || C1.UDE_EFF_DT);
      IF C1.IL_PRODUCT = 'Y' THEN
        DBG('Product is IL product ');
      
        L_UDE_EFF_DT := C1.UDE_EFF_DT;
        DBG('Final ude eff date is ' || L_UDE_EFF_DT);
        IF NOT FN_MARK_BKCALC_FOR_IL(C1.BRN,
                                     C1.PROD,
                                     C1.LIQN_START_ACCOUNT,
                                     C1.LIQN_START_DATE,
                                     C1.LIQN_DAYS,
                                     C1.LIQN_MONTHS,
                                     C1.LIQN_YEARS,
                                     L_UDE_EFF_DT,
                                     C1.CHANGE_TYPE,
                                     C1.COND_TYPE,
                                     C1.COND_KEY,
                                     TB_BKACCPR_RECALC_FLAG,
                                     TB_BKACCPR_MINCALC_DATE,
                                     TB_BKACCPR_ROWID,
                                     TB_BKACCPR_NEXTLIQ_DT,
                                     SR) THEN
          DBG('Failedin function fn_mark_bkclac_for_il');
          RETURN FALSE;
        END IF;
      END IF;
      DBG('before etc');
      TB_BKDT_EVEDEL_BRN(J) := C1.BRN;
      TB_BKDT_EVEDEL_PROD(J) := C1.PROD;
      TB_BKDT_EVEDEL_COND_TYPE(J) := C1.COND_TYPE;
      TB_BKDT_EVEDEL_COND_KEY(J) := C1.COND_KEY;
      TB_BKDT_EVEDEL_UDE_ID(J) := C1.UDE_ID;
      TB_BKDT_EVEDEL_UDE_EFF_DT(J) := C1.UDE_EFF_DT;
      J := J + 1;
    END LOOP;
    DBG('After end loop');
    IF NVL(TB_BKDT_EVENTS_ACC.COUNT, 0) <> 0 THEN
      DBG('Before inserting into ictbs_back_dated_events ' ||
          TB_BKDT_EVENTS_ACC.COUNT);
      FORALL K IN TB_BKDT_EVENTS_ACC.FIRST .. TB_BKDT_EVENTS_ACC.LAST
        INSERT INTO ICTBS_BACK_DATED_EVENTS
          (BRN,
           ACC,
           PROD,
           EVENT_TYPE,
           EVENT_DATE,
           VALUE_DT,
           UDE_ID,
           UDE_AMT,
           RATE_CODE,
           RATE,
           UDE_CHG_TYPE,
           ENT_AMOUNT,
           DRCR_IND,
           PROCESS_STATUS,
           PROCESS_FROM_DATE)
        VALUES
          (TB_BKDT_EVENTS_BRN(K),
           TB_BKDT_EVENTS_ACC(K),
           TB_BKDT_EVENTS_PROD(K),
           TB_BKDT_EVENTS_EVENT_TYPE(K),
           TB_BKDT_EVENTS_EVENT_DATE(K),
           TB_BKDT_EVENTS_VALUE_DT(K),
           TB_BKDT_EVENTS_UDE_ID(K),
           TB_BKDT_EVENTS_UDE_AMT(K),
           TB_BKDT_EVENTS_RATE_CODE(K),
           TB_BKDT_EVENTS_RATE(K),
           TB_BKDT_EVENTS_UDE_CHG_TYPE(K),
           TB_BKDT_EVENTS_ENT_AMOUNT(K),
           TB_BKDT_EVENTS_ENT_DRCR_IND(K),
           TB_BKDT_EVENTS_ENT_PROC_STAT(K),
           TB_BKDT_EVENTS_ENT_PROC_FRMDT(K));
    END IF;
  
    DBG('After the back dated events..insert');
    IF NVL(TB_BKDT_EVEDEL_BRN.COUNT, 0) <> 0 THEN
      FORALL K IN TB_BKDT_EVEDEL_BRN.FIRST .. TB_BKDT_EVEDEL_BRN.LAST
        DELETE FROM ICTBS_BACK_DATED_UDEVALS
         WHERE BRN = TB_BKDT_EVEDEL_BRN(K)
           AND PROD = TB_BKDT_EVEDEL_PROD(K)
           AND COND_TYPE = TB_BKDT_EVEDEL_COND_TYPE(K)
           AND COND_KEY = TB_BKDT_EVEDEL_COND_KEY(K)
           AND UDE_ID = TB_BKDT_EVEDEL_UDE_ID(K)
           AND UDE_EFF_DT = TB_BKDT_EVEDEL_UDE_EFF_DT(K);
    END IF;
    DBG('After the back dated udevals..delte');
    DBG('Goig to update back calc date as');
    IF NVL(TB_BKACCPR_ROWID.COUNT, 0) <> 0 THEN
      FORALL K IN TB_BKACCPR_ROWID.FIRST .. TB_BKACCPR_ROWID.LAST
        UPDATE ICTBS_ACC_PR
           SET BKVAL_RECALC_FLAG  = TB_BKACCPR_RECALC_FLAG(K),
               BKVAL_MINCALC_DATE = TB_BKACCPR_MINCALC_DATE(K)
         WHERE ROWID = TB_BKACCPR_ROWID(K);
    END IF;
    DBG('update and commit');
  
    DBG('the transaction would be commited only if is from gateway(gw)  - global.pkg_is_txn_via_gw ' ||
        GLOBAL.PKG_IS_TXN_VIA_GW);
    DBG('icpks_test.g_onliq_flag is :' || ICPKS_TEST.G_ONLIQ_FLAG);
    IF GLOBAL.PKG_IS_TXN_VIA_GW <> 'Y' AND NOT GWPKS_UTIL.G_FROM_BEAN AND
       NVL(ICPKS_TEST.G_ONLIQ_FLAG, 'N') <> 'Y' THEN
      DBG('Commiting the transaction as it is NOT COMING from the gateway');
      COMMIT;
    ELSE
      DBG('the commit will not happen as the txn is coming via gateway');
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of fn_mark_bkcalc_for_udevals' || SQLERRM);
      RETURN FALSE;
  END FN_MARK_BKCALC_FOR_UDEVALS;

  FUNCTION FN_FIND_LAST_CHILD_ONLIQ(P_PARENT_PHY_BRN VARCHAR2,
                                    P_PARENT_PHY_ACC VARCHAR2,
                                    P_CHILD_SYS_ACC  VARCHAR2,
                                    P_CHILD_SYS_BRN  VARCHAR2,
                                    P_AMOUNT         NUMBER,
                                    P_TAG            VARCHAR2) RETURN BOOLEAN IS
    L_BRANCH  ILTB_SYS_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACCOUNT ILTB_SYS_ACCOUNT.ACCOUNT%TYPE;
  BEGIN
    DBG('iNSIDE fn_find_last_child_onliq');
    DBG('p_tag value is-->' || P_TAG);
    IF P_TAG = 'ILIQ' THEN
    
      IF G_TB_ONL_SYS_ACCTS.EXISTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN) THEN
      
        IF G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
         .G_TB_ONL_CHILD_ACCTS.COUNT > 0 THEN
        
          BEGIN
            SELECT BRANCH_CODE, ACCOUNT
              INTO L_BRANCH, L_ACCOUNT
              FROM ILTB_SYS_ACCOUNT
             WHERE SYSTEM_ACCOUNT_BRANCH = P_CHILD_SYS_BRN
               AND SYSTEM_ACCOUNT = P_CHILD_SYS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('selection of physical account failed- ' || SQLERRM);
              L_BRANCH  := NULL;
              L_ACCOUNT := NULL;
          END;
          DBG('l_branch--->' || L_BRANCH);
          DBG('l_account--->' || L_ACCOUNT);
          IF G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_ONL_CHILD_ACCTS.EXISTS(P_PARENT_PHY_ACC ||
                                          P_PARENT_PHY_BRN) THEN
            G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).P_CONT_AMT := NVL(G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
                                                                                                                                                  .P_CONT_AMT,
                                                                                                                                                  0) -
                                                                                                                                              NVL(P_AMOUNT,
                                                                                                                                                  0);
          END IF;
          IF G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_ONL_CHILD_ACCTS.EXISTS(L_ACCOUNT || L_BRANCH) THEN
            G_TB_ONL_SYS_ACCTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS.DELETE(L_ACCOUNT ||
                                                                                                 L_BRANCH);
          END IF;
        END IF;
      END IF;
    ELSIF P_TAG = 'TAX' THEN
    
      IF G_TB_ONL_SYS_ACCTS_TAX.EXISTS(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN) THEN
      
        IF G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
         .G_TB_ONL_CHILD_ACCTS_TAX.COUNT > 0 THEN
        
          BEGIN
            SELECT BRANCH_CODE, ACCOUNT
              INTO L_BRANCH, L_ACCOUNT
              FROM ILTB_SYS_ACCOUNT
             WHERE SYSTEM_ACCOUNT_BRANCH = P_CHILD_SYS_BRN
               AND SYSTEM_ACCOUNT = P_CHILD_SYS_ACC;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('selection of physical account failed- ' || SQLERRM);
              L_BRANCH  := NULL;
              L_ACCOUNT := NULL;
          END;
          DBG('l_branch--->' || L_BRANCH);
          DBG('l_account--->' || L_ACCOUNT);
          IF G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_ONL_CHILD_ACCTS_TAX.EXISTS(P_PARENT_PHY_ACC ||
                                              P_PARENT_PHY_BRN) THEN
            G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).P_CONT_AMT := NVL(G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
                                                                                                                                                          .P_CONT_AMT,
                                                                                                                                                          0) -
                                                                                                                                                      NVL(P_AMOUNT,
                                                                                                                                                          0);
          END IF;
          IF G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN)
           .G_TB_ONL_CHILD_ACCTS_TAX.EXISTS(L_ACCOUNT || L_BRANCH) THEN
            G_TB_ONL_SYS_ACCTS_TAX(P_PARENT_PHY_ACC || P_PARENT_PHY_BRN).G_TB_ONL_CHILD_ACCTS_TAX.DELETE(L_ACCOUNT ||
                                                                                                         L_BRANCH);
          END IF;
        END IF;
      END IF;
    
    END IF;
    DBG('SUCCESS FROM fn_find_last_child_onliq');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('fn_find_last_child_onliq function failed- ' || SQLERRM);
      RETURN FALSE;
  END FN_FIND_LAST_CHILD_ONLIQ;

  PROCEDURE PR_RETRY_RESOLUTION(P_BRN VARCHAR2) IS
    L_COUNT NUMBER := 0;
  BEGIN
  
    BEGIN
    
      DBG('Retry for ude_eff_dt >= ' ||
          TO_CHAR((GLOBAL.APPLICATION_DATE - PKG_RES_RETRY_RANGE),
                  'DD-MON-YYYY'));
      FOR REC IN (SELECT X.*
                    FROM ICTM_ACC_EFFDT X
                   WHERE X.BRN = GLOBAL.CURRENT_BRANCH
                     AND X.RECORD_STAT = 'O'
                     AND X.UDE_EFF_DT >=
                         (GLOBAL.APPLICATION_DATE - PKG_RES_RETRY_RANGE)
                     AND EXISTS (SELECT 1
                            FROM ICTB_ACC_PR Z
                           WHERE X.BRN = Z.BRN
                             AND X.ACC = Z.ACC
                             AND X.PROD = Z.PROD)
                     AND NOT EXISTS
                   (SELECT 1
                            FROM ICTB_UDEVAL_ROW Y
                           WHERE X.PROD = Y.PROD
                             AND X.UDE_EFF_DT = Y.UDE_EFF_DT
                             AND Y.COND_TYPE = 0
                             AND Y.COND_KEY = X.BRN || X.ACC)) LOOP
      
        DBG('UPDATING: ' || REC.BRN || '~' || REC.ACC || '~' || REC.PROD || '~' ||
            TO_CHAR(REC.UDE_EFF_DT, 'DD-MON-YY'));
        UPDATE ICTBS_MAINT_QUEUE
           SET STATUS = 'U'
         WHERE BRN = REC.BRN
           AND MAINT_TYPE = 'SP'
           AND MAINT_KEY = REC.BRN || '~' || REC.ACC || '~' || REC.PROD || '~' ||
               TO_CHAR(REC.UDE_EFF_DT, 'DD-MON-YY');
      
        IF SQL%ROWCOUNT = 0 THEN
        
          DBG('UPDATING: ' || REC.BRN || '~' || REC.ACC || '~' || REC.PROD || '~' ||
              TO_DATE(REC.UDE_EFF_DT, 'DD-MON-YYYY'));
          UPDATE ICTBS_MAINT_QUEUE
             SET STATUS = 'U'
           WHERE BRN = REC.BRN
             AND MAINT_TYPE = 'SP'
             AND MAINT_KEY = REC.BRN || '~' || REC.ACC || '~' || REC.PROD || '~' ||
                 TO_DATE(REC.UDE_EFF_DT, 'DD-MON-YYYY');
        
          IF SQL%ROWCOUNT = 0 THEN
          
            BEGIN
            
              DBG('INSERTING: ' || REC.BRN || '~' || REC.ACC || '~' ||
                  REC.PROD || '~' || REC.UDE_EFF_DT);
              INSERT INTO ICTB_MAINT_QUEUE
                (BRN, MAINT_TYPE, MAINT_KEY, TIMESTAMP, STATUS)
              VALUES
                (REC.BRN,
                 'SP',
                 REC.BRN || '~' || REC.ACC || '~' || REC.PROD || '~' ||
                 REC.UDE_EFF_DT,
                 SYSDATE,
                 'U');
            
            EXCEPTION
              WHEN DUP_VAL_ON_INDEX THEN
                NULL;
            END;
          END IF;
        
        END IF;
      
        COMMIT;
      END LOOP;
    
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
  
    DBG('pr_retry_resolution COMPLETED');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('pr_validate_acc_pr Unexpected error ' || SQLERRM ||
          ' During Maintenance Resolution 2');
  END PR_RETRY_RESOLUTION;

BEGIN

  BEGIN
    SELECT NVL(NUM_PROCESS, 1)
      INTO P_IC_MAX_PROCESS
      FROM ICTMS_BRANCH_PARAMETERS
     WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception in selecting IC branch parameter for branch:' ||
          GLOBAL.CURRENT_BRANCH || 'Error:' || SQLERRM);
  END;
  DBG('Value of l_ic_max_process is ' || P_IC_MAX_PROCESS);

  APPDT           := GLOBAL.APPLICATION_DATE;
  LCY             := GLOBAL.LCY;
  UID             := GLOBAL.USER_ID;
  NULREC.AMT      := NULL;
  NULREC.BOOK_AMT := NULL;
  NULREC.XRATE    := NULL;
  NULREC.LCY_AMT  := NULL;

  FOR I IN (SELECT * FROM ICTMS_PR_INT) LOOP
    L_PR_INT(CSPKSS_UTILS.FN_HASH40(I.PRODUCT_CODE)) := I;
  END LOOP;
  L_TBL_LOOKUP.DELETE;
  FOR I IN (SELECT * FROM ICTMS_PRODUCT_DEFINITION) LOOP
    IND := CSPKSS_UTILS.FN_HASH40(I.PRODUCT_CODE);
    L_PRODINDEX(IND).PRODUCT_CODE := I.PRODUCT_CODE;
    L_PRODINDEX(IND).BOOK_ACC_TYPE := I.BOOK_ACC_TYPE;
  
  END LOOP;

  BEGIN
  
    SELECT COUNT(*)
      INTO PKG_CHG_COUNT
      FROM CSTM_PRODUCT P, ICTM_PR_CHG C
     WHERE P.PRODUCT_CODE = C.PRODUCT_CODE
       AND P.RECORD_STAT = 'O';
    ACPKSS.PR_SET_BATCH_ACC(TRUE);
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in icpks_test for selecting count' || SQLERRM);
  END;

  BEGIN
    G_SLEEP_TIMER := NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('IC_JOB_SLEEP_TIMER'),
                         30);
  EXCEPTION
    WHEN OTHERS THEN
      G_SLEEP_TIMER := 30;
  END;

  IF CSPKS_FEATURE.FN_INSTALLED('IC_RERESOLVE', GLOBAL.HEAD_OFFICE) THEN
    BEGIN
      PKG_RES_RETRY_COUNT := NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('RES_RETRY_COUNT'),
                                 0);
      DBG('PKG_RES_RETRY_COUNT is: ' || PKG_RES_RETRY_COUNT);
    EXCEPTION
      WHEN OTHERS THEN
        PKG_RES_RETRY_COUNT := 0;
    END;
  
    BEGIN
      PKG_RES_RETRY_RANGE := NVL(CSPKS_OS_PARAM.GET_PARAM_VAL('RES_RETRY_RANGE'),
                                 0);
      DBG('PKG_RES_RETRY_RANGE is: ' || PKG_RES_RETRY_RANGE);
    EXCEPTION
      WHEN OTHERS THEN
        PKG_RES_RETRY_RANGE := 0;
    END;
  END IF;

END ICPKS_TEST;
