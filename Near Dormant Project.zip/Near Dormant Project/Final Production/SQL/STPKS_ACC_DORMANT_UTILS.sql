CREATE OR REPLACE PACKAGE BODY STPKS_ACC_DORMANT_UTILS AS

  FUNCTION FN_GET_NEAR_DORMANT_STATUS(P_ACC_NO IN VARCHAR2,
                                      P_BRN    IN VARCHAR2) RETURN CHAR AS
  
    L_NEAR_DORMANT_DAYS   NUMBER;
    L_NEAR_DORMANT_STATUS VARCHAR2(1) := 'N';
  
    L_DORMANCY_DATE STTM_CUST_ACCOUNT.DORMANCY_DATE%TYPE;
    L_DIFF_DAYS NUMBER := 0;
  
  BEGIN
  
    global.pr_init(P_BRN, 'SYSTEM');
  
    --temp starts
    /*L_NEAR_DORMANT_DAYS := FN_GET_NOACTIVITY_DAYS(P_ACC_NO, P_BRN);
    
    
    IF NVL(L_NEAR_DORMANT_DAYS, 0) >= 335 THEN
    
      L_NEAR_DORMANT_STATUS := 'Y';
    
    END IF;*/
    --temp starts
  
    /*IF P_ACC_NO = '000149551' THEN
      
    L_NEAR_DORMANT_STATUS := 'Y';
    
    END IF;*/
  
    dbms_output.put_line('L_NEAR_DORMANT_STATUS=' || L_NEAR_DORMANT_STATUS);
  
    --temp starts
    BEGIN
      SELECT A.DORMANCY_DATE
        INTO L_DORMANCY_DATE
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC_NO
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_DORMANCY_DATE := NULL;
    END;
    
    --dbms_output.put_line('L_DORMANCY_DATE=' || L_DORMANCY_DATE);
    --dbms_output.put_line('GLOBAL.application_date=' || GLOBAL.application_date);
    L_DIFF_DAYS := L_DORMANCY_DATE - GLOBAL.application_date;
    
    --dbms_output.put_line('L_DIFF_DAYS=' || L_DIFF_DAYS);
  
    IF L_DORMANCY_DATE IS NOT NULL AND
       L_DORMANCY_DATE - GLOBAL.application_date <=30 /*and L_DORMANCY_DATE - GLOBAL.application_date <365*/ THEN
    
      L_NEAR_DORMANT_STATUS := 'Y';
    
    END IF;
  
    --temp ends
  
    RETURN L_NEAR_DORMANT_STATUS;
  
  EXCEPTION
    WHEN OTHERS THEN
      
     --dbms_output.put_line('error line number='||dbms_utility.format_error_backtrace);
  --dbms_output.put_line('error code='||sqlcode);
  --dbms_output.put_line('error message='||sqlerrm);
      DEBUG.PR_DEBUG('AC', 'FAILED IN GETTING THE NEAR DORMANT STATUS');
    
      RETURN L_NEAR_DORMANT_STATUS;
    
  END FN_GET_NEAR_DORMANT_STATUS;

  FUNCTION FN_GET_NOACTIVITY_DAYS(P_ACC_NO IN VARCHAR2, P_BRN IN VARCHAR2)
    RETURN NUMBER
  
   AS
  
    L_LATEST_TRN_DT ACTB_DAILY_LOG.TRN_DT%TYPE;
    L_COUNT         NUMBER := 0;
  
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    L_NEXT_WORKING_DAY  STTM_DATES.NEXT_WORKING_DAY%TYPE;
    L_NO_ACTIVITY_DAYS  NUMBER;
  
  BEGIN
  
    global.pr_init(P_BRN, 'SYSTEM');
  
    --GET ACCOUNT DETAILS
    BEGIN
    
      SELECT *
        INTO L_STTM_CUST_ACCOUNT
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC_NO
         AND A.BRANCH_CODE = P_BRN
         AND A.ONCE_AUTH = 'Y';
    
    EXCEPTION
      WHEN OTHERS THEN
        L_STTM_CUST_ACCOUNT := NULL;
    END;
  
    --GET NEXT WORKING DAY
    BEGIN
      SELECT NEXT_WORKING_DAY - 1
        INTO L_NEXT_WORKING_DAY
        FROM STTM_DATES
       WHERE BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_NEXT_WORKING_DAY := GLOBAL.APPLICATION_DATE;
    END;
  
    --dbms_output.put_line('L_NEXT_WORKING_DAY=' || L_NEXT_WORKING_DAY);
    --dbms_output.put_line('L_STTM_CUST_ACCOUNT.DATE_LAST_DR_ACTIVITY=' ||
    --                     L_STTM_CUST_ACCOUNT.DATE_LAST_DR_ACTIVITY);
    --dbms_output.put_line('L_STTM_CUST_ACCOUNT.AC_OPEN_DATE=' ||
    --                     L_STTM_CUST_ACCOUNT.AC_OPEN_DATE);
   -- dbms_output.put_line('L_STTM_CUST_ACCOUNT.DATE_LAST_CR_ACTIVITY=' ||
    --                     L_STTM_CUST_ACCOUNT.DATE_LAST_CR_ACTIVITY);
  
    --dbms_output.put_line('greatest date=' ||
     --                    GREATEST(NVL(L_STTM_CUST_ACCOUNT.DATE_LAST_DR_ACTIVITY,
      --                                L_STTM_CUST_ACCOUNT.AC_OPEN_DATE),
      --                            NVL(L_STTM_CUST_ACCOUNT.DATE_LAST_CR_ACTIVITY,
       --                               L_STTM_CUST_ACCOUNT.AC_OPEN_DATE)));
  
    IF L_STTM_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL AND
       L_NEXT_WORKING_DAY IS NOT NULL THEN
    
      L_NO_ACTIVITY_DAYS := (L_NEXT_WORKING_DAY -
                            GREATEST(NVL(L_STTM_CUST_ACCOUNT.DATE_LAST_DR_ACTIVITY,
                                          L_STTM_CUST_ACCOUNT.AC_OPEN_DATE),
                                      NVL(L_STTM_CUST_ACCOUNT.DATE_LAST_CR_ACTIVITY,
                                          L_STTM_CUST_ACCOUNT.AC_OPEN_DATE)));
    
    END IF;
  
    --dbms_output.put_line('L_NO_ACTIVITY_DAYS=' || L_NO_ACTIVITY_DAYS);
  
    RETURN L_NO_ACTIVITY_DAYS;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_NO_ACTIVITY_DAYS;
  END FN_GET_NOACTIVITY_DAYS;

  FUNCTION FN_GET_NEAR_DORMANT_DATE(P_ACC_NO IN VARCHAR2,
                                    P_BRN    IN VARCHAR2)
  --RETURN STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE AS
  
   RETURN VARCHAR2 AS
  
    L_NEAR_DORMANT_DATE STTM_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
  
    L_NEAR_DORMANT_STATUS CHAR(1) := 'N';
    
     L_DORMANCY_DATE STTM_CUST_ACCOUNT.DORMANCY_DATE%TYPE; --temp changes
  
  BEGIN
  
    DBMS_OUTPUT.PUT_LINE('INSIDE FN_GET_NEAR_DORMANT_DATE');
  
    global.pr_init(P_BRN, 'SYSTEM');
  
    L_NEAR_DORMANT_STATUS := FN_GET_NEAR_DORMANT_STATUS(P_ACC_NO, P_BRN);
  
    DBMS_OUTPUT.PUT_LINE('L_NEAR_DORMANT_STATUS=' || L_NEAR_DORMANT_STATUS);
  
    IF L_NEAR_DORMANT_STATUS = 'Y' THEN
    
      --L_NEAR_DORMANT_DATE := GLOBAL.application_date + 30; --temp changes
      
      --temp changes starts
      BEGIN
      SELECT A.DORMANCY_DATE
        INTO L_DORMANCY_DATE
        FROM STTM_CUST_ACCOUNT A
       WHERE A.CUST_AC_NO = P_ACC_NO
         AND A.BRANCH_CODE = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_DORMANCY_DATE := NULL;
    END;
    
    --dbms_output.put_line('L_DORMANCY_DATE=' || L_DORMANCY_DATE);
    
      
      L_NEAR_DORMANT_DATE :=  L_DORMANCY_DATE;
      --temp changes ends
    
      RETURN TO_CHAR(L_NEAR_DORMANT_DATE, 'YYYY-MM-DD');
    
    END IF;
  
    DEBUG.PR_DEBUG('AC', 'L_NEAR_DORMANT_DATE=' || L_NEAR_DORMANT_DATE);
  
    RETURN L_NEAR_DORMANT_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN GETTING THE NEAR DORMANT DATE');
    
      RETURN L_NEAR_DORMANT_DATE;
    
  END FN_GET_NEAR_DORMANT_DATE;

  FUNCTION FN_GET_DORM_STATUS(P_ACC_NO IN VARCHAR2, P_BRN IN VARCHAR2)
    RETURN CHAR AS
  
    L_ACC_DORM_STATUS CHAR(1) := 'N';
    
  
  BEGIN
  
    BEGIN
      SELECT A.AC_STAT_DORMANT
        INTO L_ACC_DORM_STATUS
        FROM STTM_ACCOUNT_BALANCE A
       WHERE A.CUST_AC_NO = P_ACC_NO
         AND A.CUST_AC_BRN = P_BRN;
    EXCEPTION
      WHEN OTHERS THEN
        L_ACC_DORM_STATUS := 'N';
    END;
  
    RETURN L_ACC_DORM_STATUS;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN GETTING THE DORMANT STATUS');
      RETURN L_ACC_DORM_STATUS;
    
  END FN_GET_DORM_STATUS;

END STPKS_ACC_DORMANT_UTILS;
