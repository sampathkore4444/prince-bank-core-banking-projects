CREATE OR REPLACE PACKAGE BODY stpks_stdaccdt_main AS

  G_STDACCDT STPKS_STDACCDT_MAIN.TY_STDACCDT;
  G_UI_NAME  VARCHAR2(50) := 'STDACCDT';
  G_REQ_KEY  VARCHAR2(32767);

  G_SKIP_SYS    BOOLEAN := FALSE;
  G_SKIP_KERNEL BOOLEAN := FALSE;
  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'stpks_stdaccdt_Main ==>' || P_MSG;
      DEBUG.PR_DEBUG('ST', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_SOURCE     VARCHAR2,
                         P_ERR_CODE   VARCHAR2,
                         P_ERR_PARAMS VARCHAR2) IS
    L_FID VARCHAR2(32767) := 'STDACCDT';
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE, L_FID, P_ERR_CODE, P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    STPKS_STDACCDT_KERNEL.PR_SKIP_HANDLER(P_STAGE);
  END PR_SKIP_HANDLER;
  PROCEDURE PR_SET_SKIP_SYS IS
  BEGIN
    G_SKIP_SYS := TRUE;
  END PR_SET_SKIP_SYS;
  PROCEDURE PR_SET_ACTIVATE_SYS IS
  BEGIN
    G_SKIP_SYS := FALSE;
  END PR_SET_ACTIVATE_SYS;
  FUNCTION FN_SKIP_SYS RETURN BOOLEAN IS
  BEGIN
    RETURN G_SKIP_SYS;
  END FN_SKIP_SYS;
  PROCEDURE PR_SET_SKIP_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := TRUE;
  END PR_SET_SKIP_KERNEL;
  PROCEDURE PR_SET_ACTIVATE_KERNEL IS
  BEGIN
    G_SKIP_KERNEL := FALSE;
  END PR_SET_ACTIVATE_KERNEL;
  FUNCTION FN_SKIP_KERNEL RETURN BOOLEAN IS
  BEGIN
    IF CSPKS_REQ_GLOBAL.G_RELEASE_TYPE = CSPKS_REQ_GLOBAL.P_KERNEL THEN
      RETURN FALSE;
    ELSE
      RETURN G_SKIP_KERNEL;
    END IF;
  END FN_SKIP_KERNEL;
  FUNCTION FN_SYS_BUILD_FC_TYPE(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                P_STDACCDT         IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_PK_COUNTER       NUMBER := 1;
    L_COUNT            NUMBER;
    L_PARENT_REC       NUMBER := 0;
    L_KEY              VARCHAR2(255);
    L_PKEY             VARCHAR2(32767);
    L_PVAL             VARCHAR2(32767);
    L_VAL              VARCHAR2(32767);
    L_TAG              VARCHAR2(100);
    L_NODE             VARCHAR2(100);
    L_KEY_VALS         VARCHAR2(32767);
    L_KEY_TAGS         VARCHAR2(32767);
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    L_DSN_REC_CNT_2    NUMBER;
    L_BND_CNTR_2       NUMBER;

  BEGIN

    DBG('In Fn_Sys_Build_Fc_Type..');

    L_NODE := CSPKS_REQ_GLOBAL.FN_GETNODE;
    WHILE (L_NODE <> 'EOPL') LOOP

      IF L_NODE = 'BLK_STVW_ACCOUNT_SUMARY' THEN
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO := CSPKS_REQ_GLOBAL.FN_GETVAL;
      ELSIF L_NODE = 'BLK_STVW_ACCOUNT_SUMARY__A' THEN
        L_DSN_REC_CNT_2 := P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT + 1;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CUSTACNO := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).BRANCH_CODE := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CCY := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CURRENT_BALANCE := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNT_TYPE := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CUSTOMER_NAME := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNTDESCRIPTION := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNT_CLASS := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCLASSDESC := CSPKS_REQ_GLOBAL.FN_GETVAL;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).BRANCH_CODE := P_STDACCDT.V_STVW_ACCOUNT_SUMARY.BRANCH_CODE;
      END IF;
      L_NODE := CSPKS_REQ_GLOBAL.FN_GETNODE;
    END LOOP;

    P_STDACCDT.ADDL_INFO := P_ADDL_INFO;
    DBG('Returning Success From Fn_Sys_Build_Fc_Type.. ');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdaccdt_Main.Fn_Sys_Build_Fc_Type ');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_BUILD_FC_TYPE;
  FUNCTION FN_SYS_BUILD_WS_TYPE(P_SOURCE           IN VARCHAR2,
                                P_SOURCE_OPERATION IN VARCHAR2,
                                P_FUNCTION_ID      IN VARCHAR2,
                                P_ACTION_CODE      IN VARCHAR2,
                                P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                P_STDACCDT         IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                P_ERR_CODE         IN OUT VARCHAR2,
                                P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_PK_COUNTER       NUMBER := 1;
    L_COUNT            NUMBER;
    L_PARENT_REC       NUMBER := 0;
    L_KEY              VARCHAR2(255);
    L_PKEY             VARCHAR2(32767);
    L_PVAL             VARCHAR2(32767);
    L_VAL              VARCHAR2(32767);
    L_TAG              VARCHAR2(100);
    L_NODE             VARCHAR2(100);
    L_KEY_VALS         VARCHAR2(32767);
    L_KEY_TAGS         VARCHAR2(32767);
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    INVALID_DATE EXCEPTION;
    L_DSN_REC_CNT_2 NUMBER;
    L_BND_CNTR_2    NUMBER;

  BEGIN

    DBG('In Fn_Sys_Build_Ws_Type..');

    L_NODE := CSPKS_REQ_GLOBAL.FN_GETNODE;
    WHILE (L_NODE <> 'EOPL') LOOP

      IF L_NODE IN ('BLK_STVW_ACCOUNT_SUMARY',
                    'Stvw-Account-Sumary-Full',
                    'Stvw-Account-Sumary-IO') THEN
        L_KEY := CSPKS_REQ_GLOBAL.FN_GETTAG;
        L_VAL := CSPKS_REQ_GLOBAL.FN_GETVAL;
        WHILE (L_KEY <> 'EOPL') LOOP

          IF L_KEY = 'CUST_NO' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO := L_VAL;
          END IF;
          L_KEY := CSPKS_REQ_GLOBAL.FN_GETTAG;
          L_VAL := CSPKS_REQ_GLOBAL.FN_GETVAL;
        END LOOP;
      ELSIF L_NODE IN
            ('BLK_STVW_ACCOUNT_SUMARY__A', 'Stvw-Account-Sumary--A') THEN
        L_DSN_REC_CNT_2 := P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT + 1;
        L_KEY           := CSPKS_REQ_GLOBAL.FN_GETTAG;
        L_VAL           := CSPKS_REQ_GLOBAL.FN_GETVAL;
        WHILE (L_KEY <> 'EOPL') LOOP

          IF L_KEY = 'CUSTACNO' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CUSTACNO := L_VAL;
          ELSIF L_KEY = 'BRANCH_CODE' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).BRANCH_CODE := L_VAL;
          ELSIF L_KEY = 'CCY' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CCY := L_VAL;
          ELSIF L_KEY IN ('CURRBAL', 'CURRENT_BALANCE') THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CURRENT_BALANCE := L_VAL;
          ELSIF L_KEY = 'ACCOUNT_TYPE' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNT_TYPE := L_VAL;
          ELSIF L_KEY = 'CUSTOMER_NAME' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CUSTOMER_NAME := L_VAL;
          ELSIF L_KEY IN ('AC_DESC', 'ACCOUNTDESCRIPTION') THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNTDESCRIPTION := L_VAL;
          ELSIF L_KEY = 'ACCOUNT_CLASS' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCOUNT_CLASS := L_VAL;
          ELSIF L_KEY = 'ACCLASSDESC' THEN
            P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).ACCLASSDESC := L_VAL;
          END IF;
          L_KEY := CSPKS_REQ_GLOBAL.FN_GETTAG;
          L_VAL := CSPKS_REQ_GLOBAL.FN_GETVAL;
        END LOOP;
        P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).BRANCH_CODE := P_STDACCDT.V_STVW_ACCOUNT_SUMARY.BRANCH_CODE;
      END IF;
      L_NODE := CSPKS_REQ_GLOBAL.FN_GETNODE;
    END LOOP;

    P_STDACCDT.ADDL_INFO := P_ADDL_INFO;
    DBG('Returning Success From Fn_Sys_Build_Fc_Type.. ');
    RETURN TRUE;

  EXCEPTION
    WHEN INVALID_DATE THEN
      PR_LOG_ERROR(P_SOURCE,
                   'ST-OTHR-003',
                   L_KEY || '~' || CSPKS_REQ_GLOBAL.G_DATE_FORMAT);
      RETURN FALSE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdaccdt_Main.Fn_Sys_Build_Fc_Type ');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_BUILD_WS_TYPE;
  FUNCTION FN_SYS_BUILD_FC_TS(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_STDACCDT         IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_LEVEL_FORMAT     VARCHAR2(32767);
    L_PARENT_FORMAT    VARCHAR2(32767);
    L_DATE_VAL         VARCHAR2(32767);
    L_MASTER_CHILDS    NUMBER := 0;
    L_DESC_VC          VARCHAR2(32767);
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    L_0_LVL_COUNTER    NUMBER := 0;
    L_1_LVL_COUNTER    NUMBER := 0;
    L_2_LVL_COUNTER    NUMBER := 0;
    L_DSN_REC_CNT_2    NUMBER;
    L_BND_CNTR_2       NUMBER;
    L_CNTR_BEFORE      NUMBER := 0;
    L_MASTER_WHERE     VARCHAR2(32767);
    L_COUNT            NUMBER := 0;

  BEGIN
    DBG('In Fn_Sys_Build_Fc_Ts..');

    L_1_LVL_COUNTER := 0;
    L_0_LVL_COUNTER := L_0_LVL_COUNTER + 1;
    L_LEVEL_FORMAT  := L_0_LVL_COUNTER;
    CSPKS_REQ_GLOBAL.PR_WRITE('P',
                              'BLK_STVW_ACCOUNT_SUMARY',
                              L_LEVEL_FORMAT);
    CSPKS_REQ_GLOBAL.PR_WRITE('V',
                              'CUST_NO',
                              P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO);

    L_DSN_REC_CNT_2 := 0;
    IF P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT > 0 THEN
      FOR I_2 IN 1 .. P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT LOOP
        L_DSN_REC_CNT_2 := I_2;
        L_MASTER_CHILDS := L_MASTER_CHILDS + 1;
        L_1_LVL_COUNTER := L_1_LVL_COUNTER + 1;
        L_LEVEL_FORMAT  := L_0_LVL_COUNTER || '.' || L_1_LVL_COUNTER;
        CSPKS_REQ_GLOBAL.PR_WRITE('P',
                                  'BLK_STVW_ACCOUNT_SUMARY__A',
                                  L_LEVEL_FORMAT);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'CUSTACNO',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .CUSTACNO);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'BRANCH_CODE',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .BRANCH_CODE);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'CCY',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CCY);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'CURRENT_BALANCE',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .CURRENT_BALANCE);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'ACCOUNT_TYPE',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .ACCOUNT_TYPE);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'CUSTOMER_NAME',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .CUSTOMER_NAME);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'ACCOUNTDESCRIPTION',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .ACCOUNTDESCRIPTION);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'ACCOUNT_CLASS',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .ACCOUNT_CLASS);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'ACCLASSDESC',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                  .ACCLASSDESC);
      END LOOP;
    END IF;
    DBG('Returning Success From Fn_Sys_Build_Fc_Ts..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Build_Fc_Ts..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_BUILD_FC_TS;
  FUNCTION FN_SYS_BUILD_WS_TS(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_EXCHANGE_PATTERN IN VARCHAR2,
                              P_STDACCDT         IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_LEVEL_FORMAT     VARCHAR2(32767);
    L_PARENT_FORMAT    VARCHAR2(32767);
    L_DATE_VAL         VARCHAR2(32767);
    L_MASTER_CHILDS    NUMBER := 0;
    L_DESC_VC          VARCHAR2(32767);
    L_SOURCE_OPERATION VARCHAR2(100) := P_SOURCE_OPERATION;
    L_KEY_COLS         VARCHAR2(32767);
    L_KEY_VALS         VARCHAR2(32767);
    L_0_LVL_COUNTER    NUMBER := 0;
    L_1_LVL_COUNTER    NUMBER := 0;
    L_2_LVL_COUNTER    NUMBER := 0;
    L_DSN_REC_CNT_2    NUMBER;
    L_BND_CNTR_2       NUMBER;
    L_CNTR_BEFORE      NUMBER := 0;
    L_MASTER_WHERE     VARCHAR2(32767);
    L_COUNT            NUMBER := 0;
    
    L_DORM_DATE VARCHAR2(32767);

  BEGIN
    DBG('In Fn_Sys_Build_Ws_Ts..');
    IF SUBSTR(P_EXCHANGE_PATTERN, 3, 4) = 'FS' THEN
      DBG('Building Full Screen Reply..');

      IF (P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO IS NOT NULL) THEN
        L_1_LVL_COUNTER := 0;
        L_0_LVL_COUNTER := L_0_LVL_COUNTER + 1;
        L_LEVEL_FORMAT  := L_0_LVL_COUNTER;
        CSPKS_REQ_GLOBAL.PR_WRITE('P',
                                  'Stvw-Account-Sumary-Full',
                                  L_LEVEL_FORMAT);
        CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                  'CUST_NO',
                                  P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO);

        L_DSN_REC_CNT_2 := 0;
        IF P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT > 0 THEN
          FOR I_2 IN 1 .. P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT LOOP
            L_DSN_REC_CNT_2 := I_2;
            L_MASTER_CHILDS := L_MASTER_CHILDS + 1;
            L_1_LVL_COUNTER := L_1_LVL_COUNTER + 1;
            L_LEVEL_FORMAT  := L_0_LVL_COUNTER || '.' || L_1_LVL_COUNTER;
            CSPKS_REQ_GLOBAL.PR_WRITE('P',
                                      'Stvw-Account-Sumary--A',
                                      L_LEVEL_FORMAT);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'CUSTACNO',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .CUSTACNO);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'BRANCH_CODE',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .BRANCH_CODE);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'CCY',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2).CCY);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'CURRBAL',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .CURRENT_BALANCE);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'ACCOUNT_TYPE',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .ACCOUNT_TYPE);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'CUSTOMER_NAME',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .CUSTOMER_NAME);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'AC_DESC',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .ACCOUNTDESCRIPTION);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'ACCOUNT_CLASS',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .ACCOUNT_CLASS);
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'ACCLASSDESC',
                                      P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_DSN_REC_CNT_2)
                                      .ACCLASSDESC);
            --sampath starts
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'DORM_STAT',
                                     STPKS_ACC_DORMANT_UTILS.FN_GET_DORM_STATUS(P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).CUSTACNO,
                                     P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).BRANCH_CODE));
            
            
            
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'NEAR_DORM_STAT',
                                     STPKS_ACC_DORMANT_UTILS.FN_GET_NEAR_DORMANT_STATUS(P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).CUSTACNO,
                                     P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).BRANCH_CODE));
              
            
            L_DORM_DATE := STPKS_ACC_DORMANT_UTILS.FN_GET_NEAR_DORMANT_DATE(P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).CUSTACNO,
                                     P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).BRANCH_CODE);
            
            DBG('L_DORM_DATE='||L_DORM_dATE);
            
           
            
            CSPKS_REQ_GLOBAL.PR_WRITE('V',
                                      'NEAR_DORM_DATE',
                                    STPKS_ACC_DORMANT_UTILS.FN_GET_NEAR_DORMANT_DATE(P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).CUSTACNO,
                                     P_STDACCDT.v_stvw_account_sumary__a(L_DSN_REC_CNT_2).BRANCH_CODE));
            
            
            
            
            --sampth ends
          END LOOP;
        END IF;
      END IF;
    ELSE
      DBG('Building Primary Key Reply..');
      CSPKS_REQ_GLOBAL.PR_WRITE('P', 'Stvw-Account-Sumary-PK', '1');
      L_KEY_COLS := 'CUST_NO~';
      L_KEY_VALS := P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO || '~';
      CSPKS_REQ_GLOBAL.PR_WRITE('V', L_KEY_COLS, L_KEY_VALS);
    END IF;
    DBG('Returning Success From Fn_Sys_Build_Ws_Ts..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Build_Fc_Ts..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_BUILD_WS_TS;
  FUNCTION FN_SYS_CHECK_MANDATORY(P_SOURCE     IN VARCHAR2,
                                  P_PK_OR_FULL IN VARCHAR2 DEFAULT 'FULL',
                                  P_STDACCDT   IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                  P_ERR_CODE   IN OUT VARCHAR2,
                                  P_ERR_PARAMS IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT             NUMBER := 0;
    L_KEY               VARCHAR2(5000);
    L_BLK               VARCHAR2(100);
    L_FLD               VARCHAR2(100);
    L_REC_SENT          BOOLEAN := TRUE;
    L_BASE_DATA_FROM_FC VARCHAR2(1) := 'Y';

  BEGIN

    DBG('In Fn_Sys_Check_Mandatory..');

    L_FLD := 'STVW_ACCOUNT_SUMARY.CUST_NO';
    IF P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO IS NULL THEN
      DBG('Field cust_no is Null..');
      P_ERR_CODE   := 'ST-MAND-001';
      P_ERR_PARAMS := '@' || L_FLD;
      RETURN FALSE;
    END IF;

    IF P_PK_OR_FULL = 'FULL' THEN
      DBG('Full Mandatory Checks..');

      L_BLK := 'STVW_ACCOUNT_SUMARY';

      L_BLK := 'STVW_ACCOUNT_SUMARY__A';
    END IF;

    DBG('Returning Success From Fn_Sys_Check_Mandatory ..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_CHECK_MANDATORY;
  FUNCTION FN_SYS_BASIC_VALS(P_SOURCE     IN VARCHAR2,
                             P_STDACCDT   IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                             P_ERR_CODE   IN OUT VARCHAR2,
                             P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_COUNT   NUMBER := 0;
    L_KEY     VARCHAR2(5000) := NULL;
    I         NUMBER := 1;
    L_BLK     VARCHAR2(100) := 0;
    L_FLD     VARCHAR2(100) := 0;
    L_INV_CHR VARCHAR2(5) := NULL;
  BEGIN

    DBG('In Fn_Sys_Basic_Vals..');
    DBG('Duplicate Records Check For :v_stvw_account_sumary__a..');
    L_COUNT := P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A.COUNT;
    IF L_COUNT > 0 THEN
      FOR L_INDEX IN 1 .. L_COUNT LOOP
        L_KEY := NULL;
        IF L_INDEX < L_COUNT THEN
          FOR L_INDEX1 IN L_INDEX + 1 .. L_COUNT LOOP
            IF (NVL(P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_INDEX).BRANCH_CODE,
                    '@') = NVL(P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_INDEX1)
                                .BRANCH_CODE,
                                '@')) THEN
              DBG('Duplicare Record Found for :' || L_KEY);
              L_KEY := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                        G_UI_NAME,
                                                        'STVW_ACCOUNT_SUMARY__A.BRANCH_CODE') || '-' || P_STDACCDT.V_STVW_ACCOUNT_SUMARY__A(L_INDEX)
                      .BRANCH_CODE;
              PR_LOG_ERROR(P_SOURCE,
                           'ST-VALS-009',
                           '@STVW_ACCOUNT_SUMARY__A~' || L_KEY);
            END IF;
          END LOOP;
        END IF;
      END LOOP;
    END IF;
    DBG('Returning Success From Fn_Sys_Basic_Vals..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Basic_Vals..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_BASIC_VALS;

  FUNCTION FN_SYS_DEFAULT_VALS(P_SOURCE       IN VARCHAR2,
                               P_WRK_STDACCDT IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                               P_ERR_CODE     IN OUT VARCHAR2,
                               P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_COUNT NUMBER := 0;
  BEGIN

    DBG('In Fn_Sys_Default_Vals..');
    DBG('Returning Success From Fn_Sys_Default_Vals..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Default_Vals..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_DEFAULT_VALS;

  FUNCTION FN_SYS_QUERY_DESC_FIELDS(P_SOURCE           IN VARCHAR2,
                                    P_SOURCE_OPERATION IN VARCHAR2,
                                    P_FUNCTION_ID      IN VARCHAR2,
                                    P_ACTION_CODE      IN VARCHAR2,
                                    P_WRK_STDACCDT     IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                    P_ERR_CODE         IN OUT VARCHAR2,
                                    P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY           VARCHAR2(5000) := NULL;
    L_COUNT         NUMBER := 0;
    L_KEY_TAGS      VARCHAR2(32767);
    L_KEY_VALS      VARCHAR2(32767);
    L_REC_EXISTS    BOOLEAN := TRUE;
    L_DSN_REC_CNT_2 NUMBER := 0;
    L_BND_CNTR_2    NUMBER := 0;
  BEGIN
    DBG('In Fn_Sys_Query_Desc_Fields..');
    DBG('Returning Success From Fn_Sys_Query_Desc_Fields..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Query_Desc_Fields ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_QUERY_DESC_FIELDS;
  FUNCTION FN_SYS_LOV_VALS(P_SOURCE       IN VARCHAR2,
                           P_WRK_STDACCDT IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                           P_ERR_CODE     IN OUT VARCHAR2,
                           P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_COUNT         NUMBER := 0;
    L_KEY           VARCHAR2(5000) := NULL;
    I               NUMBER := 1;
    L_LOV_COUNT     NUMBER := 0;
    L_BLK           VARCHAR2(100) := 0;
    L_FLD           VARCHAR2(100) := 0;
    L_INV_CHR       VARCHAR2(5) := NULL;
    L_DSN_REC_CNT_1 NUMBER := 0;
    L_BND_CNTR_1    NUMBER := 0;
    L_DSN_REC_CNT_2 NUMBER := 0;
    L_BND_CNTR_2    NUMBER := 0;
  BEGIN

    DBG('In Fn_Sys_Lov_Vals');
    L_BLK := 'STVW_ACCOUNT_SUMARY';
    L_FLD := 'STVW_ACCOUNT_SUMARY.CUST_NO';
    IF P_WRK_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO IS NOT NULL THEN
      SELECT COUNT(*)
        INTO L_LOV_COUNT
        FROM (SELECT C.CUSTOMER_NO, CUSTOMER_NAME1
                FROM STVWS_STTM_CUSTOMER C
               WHERE ((C.GROUP_CODE IS NOT NULL AND EXISTS
                      (SELECT 1
                          FROM STVWS_USER_GROUP G
                         WHERE G.USER_ID = GLOBAL.USER_ID
                           AND G.GROUP_CODE = C.GROUP_CODE)) OR
                     C.GROUP_CODE IS NULL)
                 AND ((C.ACCESS_GROUP IS NOT NULL AND EXISTS
                      (SELECT 1
                          FROM STVWS_USER_ACCESS H
                         WHERE H.USER_ID = GLOBAL.USER_ID
                           AND H.ACCESS_GROUP = C.ACCESS_GROUP)) OR
                     C.ACCESS_GROUP IS NULL)
                 AND SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, 'STDACCDT') IN
                     ('N', 'Y')
                 AND C.CUSTOMER_NO NOT IN
                     (SELECT FC.CUSTOMER_NO
                        FROM STTMS_CUST_FORGET_DETAIL FC
                       WHERE PROCESS_STATUS = 'P'))
       WHERE CUSTOMER_NO = P_WRK_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO;
      IF L_LOV_COUNT = 0 THEN
        DBG('Invalid Value For The Field  :CUST_NO:' ||
            P_WRK_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO);
        PR_LOG_ERROR(P_SOURCE,
                     'ST-VALS-011',
                     P_WRK_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO ||
                     '~@STVW_ACCOUNT_SUMARY.CUST_NO~@STVW_ACCOUNT_SUMARY');
      END IF;
    END IF;
    DBG('Returning Success From Fn_Sys_Lov_Vals..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In When Others of Fn_Sys_Lov_Vals..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_LOV_VALS;

  FUNCTION FN_SYS_CHECK_MANDATORY_NODES(P_SOURCE       IN VARCHAR2,
                                        P_WRK_STDACCDT IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                        P_ERR_CODE     IN OUT VARCHAR2,
                                        P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT             NUMBER := 0;
    L_BASE_DATA_FROM_FC VARCHAR2(1) := 'Y';
    L_BLK               VARCHAR2(100);
    L_FLD               VARCHAR2(100);
  BEGIN

    DBG('In Fn_Gen_Sys_Node_Mand_Checks..');
    DBG('Returning Success From Fn_Sys_Check_Mandatory_Nodes..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of Fn_Sys_Check_Mandatory_Nodes..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_SYS_CHECK_MANDATORY_NODES;

  FUNCTION FN_BUILD_TYPE(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                         P_STDACCDT         IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_MAIN_FUNCTION  SMTB_MENU.FUNCTION_ID%TYPE := P_FUNCTION_ID;
    L_CHILD_FUNCTION SMTB_MENU.FUNCTION_ID%TYPE := P_FUNCTION_ID;

  BEGIN

    DBG('In Fn_Build_Ws_Type..');

    IF CSPKS_REQ_UTILS.FN_IS_REQ_FC_FORMAT(P_SOURCE, P_FUNCTION_ID) THEN
      IF NOT FN_SYS_BUILD_FC_TYPE(P_SOURCE,
                                  P_SOURCE_OPERATION,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_ADDL_INFO,
                                  P_STDACCDT,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Build_Fc_Type..');
        RETURN FALSE;
      END IF;
    ELSE
      IF NOT FN_SYS_BUILD_WS_TYPE(P_SOURCE,
                                  P_SOURCE_OPERATION,
                                  P_FUNCTION_ID,
                                  P_ACTION_CODE,
                                  P_ADDL_INFO,
                                  P_STDACCDT,
                                  P_ERR_CODE,
                                  P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Build_Ws_Type..');
        RETURN FALSE;
      END IF;
    END IF;
    PR_SKIP_HANDLER('POSTTYPE');
    IF NOT
        STPKS_STDACCDT_KERNEL.FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE,
                                                           P_SOURCE_OPERATION,
                                                           P_FUNCTION_ID,
                                                           P_ACTION_CODE,
                                                           L_CHILD_FUNCTION,
                                                           P_ADDL_INFO,
                                                           P_STDACCDT,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
      DBG('Failed in stpks_stdaccdt_Kernel.Fn_Post_Build_Type_Structure..');
      RETURN FALSE;
    END IF;
    DBG('Returning Success From Fn_Build_Type..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdaccdt_Main.Fn_Build_Type ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_BUILD_TYPE;
  FUNCTION FN_BUILD_TS_LIST(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_EXCHANGE_PATTERN IN VARCHAR2,
                            P_STDACCDT         IN STPKS_STDACCDT_MAIN.TY_STDACCDT,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_MAIN_FUNCTION SMTB_MENU.FUNCTION_ID%TYPE := P_FUNCTION_ID;

  BEGIN

    DBG('In Fn_Build_Ts_List..');

    IF CSPKS_REQ_UTILS.FN_IS_RES_FC_FORMAT(P_SOURCE, P_FUNCTION_ID) THEN
      IF NOT FN_SYS_BUILD_FC_TS(P_SOURCE,
                                P_SOURCE_OPERATION,
                                P_FUNCTION_ID,
                                P_ACTION_CODE,
                                P_STDACCDT,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Build_Fc_Ts');
        RETURN FALSE;
      END IF;
    ELSE
      IF NOT FN_SYS_BUILD_WS_TS(P_SOURCE,
                                P_SOURCE_OPERATION,
                                P_FUNCTION_ID,
                                P_ACTION_CODE,
                                P_EXCHANGE_PATTERN,
                                P_STDACCDT,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Build_Ws_Ts');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning from Fn_Build_Ts_List');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In when others of stpks_stdaccdt_Main.Fn_Build_Ts_List ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_BUILD_TS_LIST;
  FUNCTION FN_GET_KEY_INFORMATION(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_STDACCDT         IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY_COLS  VARCHAR2(32767);
    L_KEY_VALS  VARCHAR2(32767);
    L_FUNC_TYPE VARCHAR2(32767);
  BEGIN

    DBG('In Fn_Get_Key_Information..');
    L_KEY_COLS := 'CUST_NO~';
    L_KEY_VALS := P_STDACCDT.V_STVW_ACCOUNT_SUMARY.CUST_NO || '~';
    DBG('Calling Cspks_Req_Utils.Fn_Get_Key_Information..');
    IF NOT CSPKS_REQ_UTILS.FN_GET_KEY_INFORMATION(P_SOURCE,
                                                  P_SOURCE_OPERATION,
                                                  P_FUNCTION_ID,
                                                  P_ACTION_CODE,
                                                  'OTHERS',
                                                  'STVW_ACCOUNT_SUMARY',
                                                  'BLK_STVW_ACCOUNT_SUMARY',
                                                  'Stvw-Account-Sumary',
                                                  L_KEY_COLS,
                                                  L_KEY_VALS,
                                                  P_STDACCDT.ADDL_INFO,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
      DBG('Failed in  Cspks_Req_Utils.Fn_Get_Key_Information..');
      RETURN FALSE;
    END IF;
    IF P_STDACCDT.ADDL_INFO.EXISTS('RECORD_KEY') THEN
      G_REQ_KEY := P_STDACCDT.ADDL_INFO('RECORD_KEY');
    END IF;
    DBG('Returning Succsess From Fn_Get_Key_Information..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdaccdt_Main.Fn_Get_Key_Information..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_KEY_INFORMATION;
  FUNCTION FN_REBUILD_TS_LIST(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_EXCHANGE_PATTERN IN VARCHAR2,
                              P_STATUS           IN OUT VARCHAR2,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    E_FAILURE_EXCEPTION EXCEPTION;

  BEGIN

    DBG('In Fn_Rebuild_Ts_List ');
    IF NOT FN_BUILD_TS_LIST(P_SOURCE,
                            P_SOURCE_OPERATION,
                            P_FUNCTION_ID,
                            P_ACTION_CODE,
                            P_EXCHANGE_PATTERN,
                            G_STDACCDT,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Build_Ts_List');
      P_STATUS := 'F';
      RETURN FALSE;
    END IF;
    DBG('Returning from Fn_Rebuild_Ts_List..');
    RETURN TRUE;

  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('From E_Failure_Exception of Fn_Rebuild_Ts_List');
      P_STATUS := 'F';
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      RETURN TRUE;
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Rebuild_Ts_List');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_STATUS     := 'F';
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_REBUILD_TS_LIST;

  FUNCTION FN_MAIN(P_SOURCE           IN VARCHAR2,
                   P_SOURCE_OPERATION IN VARCHAR2,
                   P_FUNCTION_ID      IN VARCHAR2,
                   P_ACTION_CODE      IN VARCHAR2,
                   P_MULTI_TRIP_ID    IN VARCHAR2,
                   P_REQUEST_NO       IN VARCHAR2,
                   P_STDACCDT         IN OUT STPKS_STDACCDT_MAIN.TY_STDACCDT,
                   P_STATUS           IN OUT VARCHAR2,
                   P_ERR_CODE         IN OUT VARCHAR2,
                   P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_POST_UPL_STAT VARCHAR2(1) := 'A';
    E_FAILURE_EXCEPTION  EXCEPTION;
    E_OVERRIDE_EXCEPTION EXCEPTION;

  BEGIN

    DBG('In Fn_Main');

    SAVEPOINT SP_MAIN_STDACCDT;
    P_STATUS := 'S';

    DBG('In fn_Main..');

    G_STDACCDT := P_STDACCDT;
    IF NOT STPKS_STDACCDT_KERNEL.FN_MAIN(P_SOURCE,
                                         P_SOURCE_OPERATION,
                                         P_FUNCTION_ID,
                                         P_ACTION_CODE,
                                         P_FUNCTION_ID,
                                         P_MULTI_TRIP_ID,
                                         P_REQUEST_NO,
                                         P_STDACCDT,
                                         P_STATUS,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Main..');
      RAISE E_FAILURE_EXCEPTION;
    END IF;
    IF P_STATUS = 'E' THEN
      DBG('Raising Error Exception..');
      RAISE E_FAILURE_EXCEPTION;
    ELSIF P_STATUS = 'O' THEN
      DBG('Raising Override Exception..');
      RAISE E_OVERRIDE_EXCEPTION;
    END IF;
    G_STDACCDT := P_STDACCDT;
    DBG('Errors     :' || P_ERR_CODE);
    DBG('Parameters :' || P_ERR_PARAMS);

    DBG('Returning Success From Fn_Main..');
    RETURN TRUE;

  EXCEPTION
    WHEN E_FAILURE_EXCEPTION THEN
      DBG('From E_Failure_Exception of Fn_Main');
      P_STATUS        := 'E';
      L_POST_UPL_STAT := 'F';
      ROLLBACK TO SP_MAIN_STDACCDT;
      CSPKS_REQ_UTILS.PR_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                            P_ACTION_CODE,
                                            L_POST_UPL_STAT,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS);
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      RETURN TRUE;

    WHEN E_OVERRIDE_EXCEPTION THEN
      DBG('From E_Override_Exception of Fn_Main');
      P_STATUS        := 'O';
      L_POST_UPL_STAT := 'O';
      IF NOT CSPKS_REQ_UTILS.FN_LOG_OVERRIDES(P_MULTI_TRIP_ID,
                                              P_REQUEST_NO,
                                              P_ERR_CODE,
                                              P_ERR_PARAMS) THEN
        DBG('Failed inCspks_Req_Utils.Fn_Log_Overrides..');
        P_ERR_CODE   := 'ST-OTHR-001';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
      CSPKS_REQ_UTILS.PR_GET_FINAL_ERR_CODE(P_FUNCTION_ID,
                                            P_ACTION_CODE,
                                            L_POST_UPL_STAT,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS);
      PR_LOG_ERROR(P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
      DBG('Errors     :' || P_ERR_CODE);
      DBG('Parameters :' || P_ERR_PARAMS);
      RETURN TRUE;

    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Main ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_STATUS := 'E';
      ROLLBACK TO SP_MAIN_STDACCDT;
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_MAIN;

  FUNCTION FN_PROCESS_REQUEST(P_SOURCE           IN VARCHAR2,
                              P_SOURCE_OPERATION IN VARCHAR2,
                              P_FUNCTION_ID      IN VARCHAR2,
                              P_ACTION_CODE      IN VARCHAR2,
                              P_EXCHANGE_PATTERN IN VARCHAR2,
                              P_MULTI_TRIP_ID    IN VARCHAR2,
                              P_REQUEST_NO       IN VARCHAR2,
                              P_ADDL_INFO        IN OUT CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                              P_STATUS           IN OUT VARCHAR2,
                              P_ERR_CODE         IN OUT VARCHAR2,
                              P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_STDACCDT STPKS_STDACCDT_MAIN.TY_STDACCDT;

  BEGIN

    DBG('In Fn_Process_Request ');
    IF NOT FN_BUILD_TYPE(P_SOURCE,
                         P_SOURCE_OPERATION,
                         P_FUNCTION_ID,
                         P_ACTION_CODE,
                         P_ADDL_INFO,
                         L_STDACCDT,
                         P_ERR_CODE,
                         P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Build_Type');
      P_STATUS := 'F';
      RETURN FALSE;
    END IF;
    IF NOT FN_MAIN(P_SOURCE,
                   P_SOURCE_OPERATION,
                   P_FUNCTION_ID,
                   P_ACTION_CODE,
                   P_MULTI_TRIP_ID,
                   P_REQUEST_NO,
                   L_STDACCDT,
                   P_STATUS,
                   P_ERR_CODE,
                   P_ERR_PARAMS) THEN
      DBG('Failed in Fn_main');
      RETURN FALSE;
    END IF;

    P_ADDL_INFO := L_STDACCDT.ADDL_INFO;
    IF CSPKS_REQ_GLOBAL.FN_BUILD_RESP THEN
      CSPKS_REQ_GLOBAL.PR_RESET;
      IF NOT FN_BUILD_TS_LIST(P_SOURCE,
                              P_SOURCE_OPERATION,
                              P_FUNCTION_ID,
                              P_ACTION_CODE,
                              P_EXCHANGE_PATTERN,
                              L_STDACCDT,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Build_Ts_List');
        P_STATUS := 'F';
        RETURN FALSE;
      END IF;
      CSPKS_REQ_GLOBAL.PR_CLOSE_TS;
    END IF;
    DBG('Returning from Fn_Process_Request..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**', 'In when others of Fn_Process_Request');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_STATUS     := 'F';
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PROCESS_REQUEST;

  FUNCTION FN_GET_NODE_DATA(P_NODE_DATA  IN OUT CSPKS_REQ_GLOBAL.TY_TB_CHR_NODE_DATA,
                            P_ERR_CODE   IN OUT VARCHAR2,
                            P_ERR_PARAMS IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_CNTR NUMBER := 0;
  BEGIN

    DBG('In Fn_Get_Node_Data..');
    L_CNTR := NVL(P_NODE_DATA.COUNT, 0) + 1;
    P_NODE_DATA(L_CNTR).NODE_NAME := 'BLK_STVW_ACCOUNT_SUMARY';
    P_NODE_DATA(L_CNTR).XSD_NODE := 'Stvw-Account-Sumary';
    P_NODE_DATA(L_CNTR).NODE_PARENT := '';
    P_NODE_DATA(L_CNTR).NODE_RELATION_TYPE := '1';
    P_NODE_DATA(L_CNTR).QUERY_NODE := '0';
    P_NODE_DATA(L_CNTR).NODE_FIELDS := 'CUST_NO~';
    P_NODE_DATA(L_CNTR).NODE_TAGS := 'CUST_NO~';

    L_CNTR := NVL(P_NODE_DATA.COUNT, 0) + 1;
    P_NODE_DATA(L_CNTR).NODE_NAME := 'BLK_STVW_ACCOUNT_SUMARY__A';
    P_NODE_DATA(L_CNTR).XSD_NODE := 'Stvw-Account-Sumary--A';
    P_NODE_DATA(L_CNTR).NODE_PARENT := 'BLK_STVW_ACCOUNT_SUMARY';
    P_NODE_DATA(L_CNTR).NODE_RELATION_TYPE := 'N';
    P_NODE_DATA(L_CNTR).QUERY_NODE := '0';
    P_NODE_DATA(L_CNTR).NODE_FIELDS := 'CUSTACNO~BRANCH_CODE~CCY~CURRENT_BALANCE~ACCOUNT_TYPE~CUSTOMER_NAME~ACCOUNTDESCRIPTION~ACCOUNT_CLASS~ACCLASSDESC~';
    P_NODE_DATA(L_CNTR).NODE_TAGS := 'CUSTACNO~BRANCH_CODE~CCY~CURRBAL~ACCOUNT_TYPE~CUSTOMER_NAME~AC_DESC~ACCOUNT_CLASS~ACCLASSDESC~';

    DBG('Returning From Fn_Get_Node_Data.. ');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdaccdt_Main.Fn_Get_Node_Data..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_GET_NODE_DATA;
END STPKS_STDACCDT_MAIN;
