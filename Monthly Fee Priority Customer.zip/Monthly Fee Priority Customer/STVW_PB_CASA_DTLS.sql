CREATE OR REPLACE VIEW STVW_PB_CASA_DTLS AS
SELECT B.CUST_AC_NO, C.CUSTOMER_NO, A.acy_withdrawable_bal, A.cust_ac_brn, A.ccy
     FROM STTM_ACCOUNT_BALANCE A, STTM_CUST_ACCOUNT B, STTM_CUSTOMER C
 WHERE A.CUST_AC_NO = B.CUST_AC_NO
   AND B.CUST_NO IN (SELECT A.CUSTOMER_NO
                       FROM STTM_CUSTOMER A
                      WHERE A.CUSTOMER_NO IN
                            (SELECT CUST_NO
                               FROM STTM_CUST_ACCOUNT B
                              WHERE B.ACCOUNT_CLASS IN ('CA06', 'CA07')
                                AND B.RECORD_STAT = 'O'))
   AND B.CUST_NO = C.CUSTOMER_NO
   AND B.ACCOUNT_CLASS IN ('CA06', 'CA07')
   AND B.ACCOUNT_TYPE <> 'Y';
