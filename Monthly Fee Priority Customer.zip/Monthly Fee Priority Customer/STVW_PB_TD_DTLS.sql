CREATE OR REPLACE VIEW STVW_PB_TD_DTLS AS
SELECT a.CUSTOMER_NO CUSTOMER_NO,
       b.ac_desc ACCOUNT_DESCRIPTION,
       CASE a.CUSTOMER_TYPE
         WHEN 'I' THEN
          'INDIVIDUAL'
         WHEN 'C' THEN
          'CORPORATE'
         WHEN 'B' THEN
          'BANK'
       END "CUSTOMER_TYPE",

       b.branch_code,
       b.CUST_AC_NO,
       CASE b.record_stat
         WHEN 'O' THEN
          'Open'
         WHEN 'C' THEN
          'Close'
       END "ACCOUNT_STATUS",
       CASE b.JOINT_AC_INDICATOR
         WHEN 'S' THEN
          'SINGLE'
         WHEN 'J' THEN
          'JOINT'
       END "ACCOUNT_TYPE",
       CASE b.mode_of_operation
         WHEN 'S' THEN
          'SINGLE'
         WHEN 'J' THEN
          'JOINTLY'
         WHEN 'E' THEN
          'EITHER ANYONE OR SURVIVOR'
         WHEN 'F' THEN
          'FORMER OR SURVIVOR'
         WHEN 'M' THEN
          'MANDATE HOLDER'
       END "MODE_OF_OPERATION",
       b.CCY,
       y.Td_Amount INITIAL_DEPOSIT,
       (nvl(y.TD_AMOUNT, 0) + NVL(y.TOPUP_AMT, 0) - NVL(y.REDEM_AMT, 0)) "PRINCIPAL_BALANCE",
       c.MATURITY_DATE,
       DECODE(NVL(b.mudarabah_accounts, 'N'), 'N', c.maturity_amount, NULL) MATURITY_AMOUNT,
       b.AC_OPEN_DATE,
       c.int_start_date
  from sttm_customer      a,
       sttm_cust_account  b,
       ictms_Acc          c,
       ictm_td_details    y
 WHERE a.CUSTOMER_NO = b.CUST_NO
   and b.CUST_AC_NO = c.ACC
   and b.branch_code = c.BRN
   and y.brn = b.branch_code
   and y.acc = b.CUST_ac_no
   AND B.ACCOUNT_TYPE = 'Y'
   --AND B.ACCOUNT_CLASS IN ('CA06', 'CA07')
;
