CREATE OR REPLACE PACKAGE BODY IFPKS_PBCUST_FEE_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_PBCUST_FEE_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_CHECK_TDBAL_MORE_10K_USD(P_CUSTOMER_NO IN VARCHAR2)
    RETURN BOOLEAN AS
  
    CURSOR C1(P_CUSTOMER_NO STTM_CUSTOMER.CUSTOMER_NO%TYPE) IS
      SELECT * FROM STVW_PB_TD_DTLS A WHERE A.CUSTOMER_NO = P_CUSTOMER_NO;
  
    L_10K_USD_FLAG CHAR(1) := 'N';
  
    L_EXCH_RATE          ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG          NUMBER;
    L_error_code         VARCHAR2(200);
    L_error_parameter    VARCHAR2(200);
    L_USD_AMOUNT_DERIVED ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  
  BEGIN
  
    FOR G IN C1(P_CUSTOMER_NO) LOOP
    
      GLOBAL.PR_INIT(G.BRANCH_CODE, 'SYSTEM');
    
      IF G.CCY = 'USD' THEN
      
        IF G.PRINCIPAL_BALANCE > 10000 THEN
        
          L_10K_USD_FLAG := 'Y';
        
          RETURN TRUE;
        
          --BREAK;
        
        END IF;
      
      ELSIF G.CCY = 'KHR' THEN
      
        --Get USD
        IF NOT CYPKSS.FN_GETRATE(G.BRANCH_CODE,
                                 G.CCY,
                                 'USD',
                                 'STANDARD',
                                 'B',
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 L_ERROR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(G.CCY,
                                      'USD',
                                      G.PRINCIPAL_BALANCE,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_USD_AMOUNT_DERIVED,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_USD_AMOUNT_DERIVED=' || L_USD_AMOUNT_DERIVED);
      
        IF L_USD_AMOUNT_DERIVED > 10000 THEN
        
          L_10K_USD_FLAG := 'Y';
        
          RETURN TRUE;
        
          --BREAK;
        
        END IF;
      
      END IF;
    
    END LOOP;
  
    RETURN FALSE;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_CHECK_TDBAL_MORE_10K_US');
      DBG('ERROR CODE IN FN_CHECK_TDBAL_MORE_10K_US=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_CHECK_TDBAL_MORE_10K_US=' || SQLERRM);
      RETURN FALSE;
    
  END FN_CHECK_TDBAL_MORE_10K_USD;

  FUNCTION FN_CHECK_CASABAL_MORE_10K_USD(P_CUSTOMER_NO IN VARCHAR2)
    RETURN BOOLEAN AS
  
    CURSOR C1(P_CUSTOMER_NO STTM_CUSTOMER.CUSTOMER_NO%TYPE) IS
    
      SELECT *
        FROM STVW_PB_CASA_DTLS A
       WHERE A.CUSTOMER_NO = P_CUSTOMER_NO;
  
    L_10K_USD_FLAG CHAR(1) := 'N';
  
    L_EXCH_RATE          ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG          NUMBER;
    L_error_code         VARCHAR2(200);
    L_error_parameter    VARCHAR2(200);
    L_USD_AMOUNT_DERIVED ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
  
  BEGIN
  
    FOR G IN C1(P_CUSTOMER_NO) LOOP
    
      GLOBAL.PR_INIT(G.CUST_AC_BRN, 'SYSTEM');
    
      IF G.CCY = 'USD' THEN
      
        IF G.ACY_WITHDRAWABLE_BAL > 10000 THEN
        
          L_10K_USD_FLAG := 'Y';
        
          RETURN TRUE;
        
          --BREAK;
        
        END IF;
      
      ELSIF G.CCY = 'KHR' THEN
      
        --Get USD
        IF NOT CYPKSS.FN_GETRATE(G.CUST_AC_BRN,
                                 G.CCY,
                                 'USD',
                                 'STANDARD',
                                 'B',
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 L_ERROR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(G.CCY,
                                      'USD',
                                      G.ACY_WITHDRAWABLE_BAL,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_USD_AMOUNT_DERIVED,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_USD_AMOUNT_DERIVED=' || L_USD_AMOUNT_DERIVED);
      
        IF L_USD_AMOUNT_DERIVED > 10000 THEN
        
          L_10K_USD_FLAG := 'Y';
        
          RETURN TRUE;
        
          --BREAK;
        
        END IF;
      
      END IF;
    
    END LOOP;
  
    RETURN FALSE;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_CHECK_CASABAL_MORE_10K_USD');
      DBG('ERROR CODE IN FN_CHECK_CASABAL_MORE_10K_USD=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_CHECK_CASABAL_MORE_10K_USD=' || SQLERRM);
      RETURN FALSE;
    
  END FN_CHECK_CASABAL_MORE_10K_USD;

  FUNCTION FN_RETURN_ACC_LESSTHAN_10K_USD(P_CUSTOMER_NO IN VARCHAR2)
    RETURN STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE AS
  
    CURSOR C1(P_CUSTOMER_NO STTM_CUSTOMER.CUSTOMER_NO%TYPE) IS
    
      SELECT *
        FROM STVW_PB_CASA_DTLS A
       WHERE A.CUSTOMER_NO = P_CUSTOMER_NO;
  
    L_10K_USD_FLAG CHAR(1) := 'N';
  
    L_EXCH_RATE          ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG          NUMBER;
    L_error_code         VARCHAR2(200);
    L_error_parameter    VARCHAR2(200);
    L_USD_AMOUNT_DERIVED ACTB_DAILY_LOG.LCY_AMOUNT%TYPE;
    L_ACCOUNT_TO_DEBIT   STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
  BEGIN
  
    FOR G IN C1(P_CUSTOMER_NO) LOOP
    
      GLOBAL.PR_INIT(G.CUST_AC_BRN, 'SYSTEM');
    
      IF G.CCY = 'USD' THEN
      
        IF G.ACY_WITHDRAWABLE_BAL > 15 AND G.ACY_WITHDRAWABLE_BAL < 10000 THEN
        
          L_ACCOUNT_TO_DEBIT := G.CUST_AC_NO;
        
          RETURN L_ACCOUNT_TO_DEBIT;
        
        END IF;
      
      ELSIF G.CCY = 'KHR' THEN
      
        --Get USD
        IF NOT CYPKSS.FN_GETRATE(G.CUST_AC_BRN,
                                 G.CCY,
                                 'USD',
                                 'STANDARD',
                                 'B',
                                 GLOBAL.APPLICATION_DATE,
                                 GLOBAL.APPLICATION_DATE,
                                 L_EXCH_RATE,
                                 L_RATE_FLAG,
                                 L_ERROR_CODE) THEN
          DBG('FAILED IN FN_GETRATE');
        
        ELSE
          L_EXCH_RATE := 1;
        END IF;
      
        DBG('L_EXCH_RATE=' || L_EXCH_RATE);
      
        --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
        IF NOT CYPKSS.FN_AMT1_TO_AMT2(G.CCY,
                                      'USD',
                                      G.ACY_WITHDRAWABLE_BAL,
                                      L_EXCH_RATE,
                                      'Y',
                                      L_USD_AMOUNT_DERIVED,
                                      L_ERROR_PARAMETER) THEN
          DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
          ROLLBACK;
        END IF;
        DBG('FINAL L_USD_AMOUNT_DERIVED=' || L_USD_AMOUNT_DERIVED);
      
        IF L_USD_AMOUNT_DERIVED > 15 AND L_USD_AMOUNT_DERIVED < 10000 THEN
        
          L_ACCOUNT_TO_DEBIT := G.CUST_AC_NO;
        
          RETURN L_ACCOUNT_TO_DEBIT;
        
        END IF;
      
      END IF;
    
    END LOOP;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_RETURN_ACC_LESSTHAN_10K_USD');
      DBG('ERROR CODE IN FN_RETURN_ACC_LESSTHAN_10K_USD=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_RETURN_ACC_LESSTHAN_10K_USD=' || SQLERRM);
    
  END FN_RETURN_ACC_LESSTHAN_10K_USD;

  PROCEDURE PR_PROCESS_PBCUST_FEE(P_PARAM_NAMES VARCHAR2,
                                  P_PARAM_VALS  VARCHAR2) AS
  
    L_CUST_ACCOUNT          STTM_CUST_ACCOUNT%ROWTYPE;
    L_CUST                  STTM_CUSTOMER%ROWTYPE;
    PKG_DETB_RTL_TELLER_REC DETBS_RTL_TELLER%ROWTYPE;
    L_SERIAL_NO             VARCHAR2(16);
    L_TRN_REF_NO            ACTB_DAILY_LOG.TRN_REF_NO%TYPE;
    L_GEN_SEQ_NO            VARCHAR2(100);
  
    P_ERR_CODE   VARCHAR2(255);
    P_ERR_PARAMS VARCHAR2(255);
  
    L_ARC_MAINT IFTM_ARC_MAINT%ROWTYPE;
  
    L_PAYMENT_AMOUNT ACTB_DAILY_LOG.LCY_AMOUNT%TYPE := 15; --PLS CHECK
  
    L_COUNT NUMBER;
  
    L_EXCH_RATE ACTB_DAILY_LOG.EXCH_RATE%TYPE;
    L_RATE_FLAG NUMBER;
  
    L_TXN_AMT IFTB_AIA_MASTER.TXN_AMOUNT%TYPE;
  
    L_PROD     CSTM_PRODUCT%ROWTYPE;
    L_CHG1_AMT IFTM_ARC_MAINT.COD_CHG_AMT%TYPE;
  
    L_REL_CUSTOMER STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_AC_CCY       STTM_CUST_ACCOUNT.CCY%TYPE;
    L_IB_FLAG      VARCHAR2(1) DEFAULT 'N';
    L_RETRY_COUNT  NUMBER := 0;
  
    L_RATE       NUMBER;
    L_CHARGE_AMT NUMBER := 0;
  
    L_DEBIT_ACC_FEE STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
    CURSOR C1 IS
      SELECT *
        FROM STTM_CUSTOMER A
       WHERE A.CUSTOMER_NO IN (SELECT CUST_NO
                                 FROM STTM_CUST_ACCOUNT B
                                WHERE B.ACCOUNT_CLASS IN ('CA06', 'CA07')
                                  AND B.RECORD_STAT = 'O')
         AND A.RECORD_STAT = 'O';
  
    PROCEDURE DBG(P_MSG VARCHAR2) IS
      L_MSG VARCHAR2(32767);
    BEGIN
      IF DEBUG.PKG_DEBUG_ON <> 2 THEN
        L_MSG := 'PR_PROCESS_AIA_SI_PAYMENTS ==>' || P_MSG;
        DEBUG.PR_DEBUG('IF', L_MSG);
      END IF;
    END DBG;
  
  BEGIN
  
    IF EXTRACT(DAY FROM SYSDATE) =
       CAST(TO_CHAR(LAST_DAY(SYSDATE), 'DD') AS INT) THEN
      --Executes on the last day of the month
    
      FOR G IN C1 LOOP
      
        BEGIN
        
          --Call AIA Api to get the due date
          GLOBAL.PR_INIT('001', 'SYSTEM');
        
          SAVEPOINT A;
        
          --Get Account details
          BEGIN
          
            SELECT COUNT(1)
              INTO L_COUNT
              FROM STTM_ACCOUNT_BALANCE A,
                   STTM_CUST_ACCOUNT    B,
                   STTM_CUSTOMER        C
             WHERE A.CUST_AC_NO = B.CUST_AC_NO
               AND B.CUST_NO IN
                   (SELECT A.CUSTOMER_NO
                      FROM STTM_CUSTOMER A
                     WHERE A.CUSTOMER_NO IN
                           (SELECT CUST_NO
                              FROM STTM_CUST_ACCOUNT B
                             WHERE B.ACCOUNT_CLASS IN ('CA06', 'CA07')
                               AND B.RECORD_STAT = 'O'))
               AND B.CUST_NO = C.CUSTOMER_NO
                  
                  --AND B.ACCOUNT_CLASS IN ('CA06', 'CA07')
                  -- AND B.ACCOUNT_TYPE <> 'Y'
               AND C.CUSTOMER_NO = G.CUSTOMER_NO; -- '00000017';
          
          EXCEPTION
            WHEN OTHERS THEN
              L_COUNT := 0;
          END;
        
          --For each customer check if account if CASA or TD
        
          --Check if TD Bal is more than 10K USD
          IF NOT FN_CHECK_TDBAL_MORE_10K_USD(G.CUSTOMER_NO) THEN
          
            DBG('TD ACCOUNT HAS LESS THAN 10K MONTHLY AVERAGE BALANCE');
          
          ELSE
          
            DBG('TD ACCOUNT HAS MORE THAN 10K MONTHLY AVERAGE BALANCE');
          
          END IF;
        
          --Check if CASA bal is more than 10K USD
          IF NOT FN_CHECK_CASABAL_MORE_10K_USD(G.CUSTOMER_NO) THEN
          
            DBG('CASA ACCOUNT HAS LESS THAN 10K MONTHLY AVERAGE BALANCE');
          
          ELSE
          
            DBG('CASA ACCOUNT HAS MORE THAN 10K MONTHLY AVERAGE BALANCE');
          
          END IF;
        
          --Get the CASA Account to debit the fee
          L_DEBIT_ACC_FEE := FN_RETURN_ACC_LESSTHAN_10K_USD(G.CUSTOMER_NO);
        
          --Get Account details
          BEGIN
          
            SELECT *
              INTO L_CUST_ACCOUNT
              FROM STTM_CUST_ACCOUNT A
             WHERE A.CUST_AC_NO = L_DEBIT_ACC_FEE;
          
          EXCEPTION
            WHEN OTHERS THEN
              L_CUST_ACCOUNT := NULL;
          END;
        
          IF L_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL THEN
          
            GLOBAL.PR_INIT(L_CUST_ACCOUNT.BRANCH_CODE, 'SYSTEM');
          
            pkg_detb_rtl_teller_rec.product_code := 'AI01'; --SI PRODICT CODE
          
            --Get Product Details
            BEGIN
              SELECT *
                INTO L_PROD
                FROM CSTM_PRODUCT
               WHERE PRODUCT_CODE = pkg_detb_rtl_teller_rec.product_code
                 AND RECORD_STAT = 'O'
                 AND AUTH_STAT = 'A';
            EXCEPTION
              WHEN OTHERS THEN
                L_PROD := null;
            END;
          
            --GET REFERENCE NO
            IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                               PKG_DETB_RTL_TELLER_REC.PRODUCT_CODE,
                                               GLOBAL.APPLICATION_DATE,
                                               L_SERIAL_NO,
                                               L_TRN_REF_NO,
                                               P_ERR_CODE) THEN
              DBG('FAILED IN GENERATION TRANSACTION REF NO');
              ROLLBACK TO A;
              CONTINUE;
            ELSE
              DBG('L_TRN_REF_NO=' || L_TRN_REF_NO);
            END IF;
          
            --GET BEN CUSTOMER DETAILS
            BEGIN
              SELECT X.*
                INTO L_CUST
                FROM STTM_CUSTOMER X
               WHERE X.CUSTOMER_NO = L_CUST_ACCOUNT.CUST_NO;
            EXCEPTION
              WHEN OTHERS THEN
                DEBUG.PR_DEBUG('IF', 'FAILED IN GETTING CUSTOMER DETAILS');
            END;
          
            PKG_DETB_RTL_TELLER_REC.XREF := L_TRN_REF_NO;
          
            --Get Arc Maintenance
            SELECT *
              INTO L_ARC_MAINT
              FROM IFTM_ARC_MAINT A
             WHERE A.COD_PROD_ACC_CLS =
                   pkg_detb_rtl_teller_rec.product_code
               AND ROWNUM = 1;
          
            PKG_DETB_RTL_TELLER_REC.BRANCH_CODE := L_CUST_ACCOUNT.BRANCH_CODE;
            PKG_DETB_RTL_TELLER_REC.TRN_REF_NO  := L_TRN_REF_NO;
          
            PKG_DETB_RTL_TELLER_REC.TXN_ACC    := '000021058'; --AIA Credit Account pls check
            PKG_DETB_RTL_TELLER_REC.TXN_CCY    := GLOBAL.LCY;
            PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := '991'; --GLOBAL.CURRENT_BRANCH;
            --PKG_DETB_RTL_TELLER_REC.TXN_BRANCH := PKG_DETB_RTL_TELLER_REC.OFS_BRANCH;
          
            --XRATE CALCULATION STARTS
            IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
            
              IF NOT CYPKSS.FN_GETRATE(L_CUST_ACCOUNT.BRANCH_CODE,
                                       L_CUST_ACCOUNT.CCY,
                                       'USD', --L_CCY_CODE, --'KHR', --L_AC_CCY,--l_ccy2, --L_AC_CCY,
                                       'COMM', --L_PROD.RATE_TYPE_PREFERRED,
                                       'B', --L_RATE_CODE1, --l_prod.rate_code_preferred,
                                       GLOBAL.APPLICATION_DATE,
                                       GLOBAL.APPLICATION_DATE,
                                       L_EXCH_RATE,
                                       L_RATE_FLAG,
                                       P_ERR_CODE) THEN
                DBG('FAILED IN FN_GETRATE');
                ROLLBACK TO A;
                CONTINUE;
              END IF;
            ELSE
              L_EXCH_RATE := 1;
            END IF;
          
            DBG('L_EXCH_RATE=' || L_EXCH_RATE);
          
            IF L_CUST_ACCOUNT.CCY <> 'USD' THEN
              --USING ABOVE RATE..CONVERT KHR TO USD AMOUNT
              IF NOT CYPKSS.FN_AMT1_TO_AMT2('USD', --L_CCY_CODE,
                                            L_CUST_ACCOUNT.CCY,
                                            l_payment_amount, ---G.TXN_AMOUNT,
                                            L_EXCH_RATE,
                                            'Y',
                                            L_TXN_AMT,
                                            P_ERR_PARAMS) THEN
                DBG('FAILED IN CONVERTING FROM AMOUNT1 TO AMOUNT2');
                ROLLBACK TO A;
                CONTINUE;
              END IF;
            ELSE
              L_TXN_AMT := l_payment_amount;
            END IF;
          
            DBG('FINAL L_TXN_AMT=' || L_TXN_AMT);
          
            PKG_DETB_RTL_TELLER_REC.OFS_ACC := L_CUST_ACCOUNT.CUST_AC_NO;
          
            PKG_DETB_RTL_TELLER_REC.OFS_CCY    := L_CUST_ACCOUNT.CCY;
            PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT := L_TXN_AMT;
          
            PKG_DETB_RTL_TELLER_REC.OFS_BRANCH := L_CUST_ACCOUNT.BRANCH_CODE; --GLOBAL.current_branch;
          
            PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT := l_payment_amount;
          
            PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE     := L_ARC_MAINT.COD_MAIN_TXN_CODE; --'000'; --TRANSACION CODE
            PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE     := L_ARC_MAINT.COD_OFFSET_TXN_CODE; --'000'; --TRANSACION CODE
            PKG_DETB_RTL_TELLER_REC.EXCH_RATE        := L_EXCH_RATE;
            PKG_DETB_RTL_TELLER_REC.TRN_DT           := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.VALUE_DT         := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.REL_CUSTOMER     := L_CUST.CUSTOMER_NO;
            PKG_DETB_RTL_TELLER_REC.BENEF_NAME       := L_CUST.CUSTOMER_NAME1;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR1      := L_CUST.ADDRESS_LINE1;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR2      := L_CUST.ADDRESS_LINE2;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR3      := L_CUST.ADDRESS_LINE3;
            PKG_DETB_RTL_TELLER_REC.BENEF_ADDR4      := L_CUST.ADDRESS_LINE4;
            PKG_DETB_RTL_TELLER_REC.LIQN_DT          := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.RECORD_STAT      := 'A';
            PKG_DETB_RTL_TELLER_REC.AUTH_STAT        := 'U';
            PKG_DETB_RTL_TELLER_REC.MAKER_ID         := 'SYSTEM';
            PKG_DETB_RTL_TELLER_REC.MAKER_DT_STAMP   := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.CHECKER_ID       := 'SYSTEM';
            PKG_DETB_RTL_TELLER_REC.CHECKER_DT_STAMP := GLOBAL.APPLICATION_DATE;
            PKG_DETB_RTL_TELLER_REC.MOD_NO           := 1;
            PKG_DETB_RTL_TELLER_REC.SCODE            := 'FLEXCUBE';
            PKG_DETB_RTL_TELLER_REC.DR_ACC           := 'OFS';
            PKG_DETB_RTL_TELLER_REC.MODULE           := 'RT';
            PKG_DETB_RTL_TELLER_REC.ESN              := 1;
            PKG_DETB_RTL_TELLER_REC.EVENT_CODE       := 'INIT';
            PKG_DETB_RTL_TELLER_REC.TRACK_RECEIVABLE := 'N';
            PKG_DETB_RTL_TELLER_REC.TIME_RECEIVED    := SYSDATE;
          
            --Charge Details
          
            SELECT cust_no, ccy
              INTO l_rel_customer, l_ac_ccy
              FROM sttm_cust_account
             WHERE cust_ac_no = L_CUST_ACCOUNT.CUST_AC_NO;
          
            dbg('got l_rel_customer' || l_rel_customer);
          
            IF NOT cspkss_arc.fn_charge_pickup(GLOBAL.current_branch,
                                               'AI01',
                                               'P',
                                               'AI01',
                                               '*.*',
                                               l_rel_customer,
                                               '*.*',
                                               l_payment_amount,
                                               l_prod.rate_type_preferred,
                                               l_prod.rate_code_preferred,
                                               NULL,
                                               l_rel_customer,
                                               l_ib_flag,
                                               depks_rtl_teller.pkg_arc_row,
                                               p_err_code,
                                               p_err_params,
                                               L_CUST_ACCOUNT.CUST_AC_NO,
                                               GLOBAL.current_branch) THEN
              dbg('CHARGE PICKUP failed');
              --RETURN FALSE;
              ROLLBACK TO A;
              CONTINUE;
              --RETURN;
            END IF;
          
            DBG('PKG_ARC_ROW.COD_CHG_TYPE=' ||
                DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TYPE);
            DBG('PKG_ARC_ROW.COD_CHG_GL=' ||
                DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_GL);
            DBG('PKG_ARC_ROW.COD_CHG_CCY=' ||
                DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_CCY);
            DBG('PKG_ARC_ROW.COD_CHG_TXN_CODE=' ||
                DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_TXN_CODE);
            DBG('PKG_ARC_ROW.COD_CHG_AMT=' ||
                DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT);
          
            DBG('l_arc_maint.COD_CHG_TYPE=' || l_arc_maint.COD_CHG_TYPE);
            DBG('l_arc_maint.COD_CHG_GL=' || l_arc_maint.COD_CHG_GL);
            DBG('l_arc_maint.COD_CHG_CCY=' || l_arc_maint.COD_CHG_CCY);
            DBG('l_arc_maint.COD_CHG_TXN_CODE=' ||
                l_arc_maint.COD_CHG_TXN_CODE);
            DBG('l_arc_maint.COD_CHG_AMT=' || l_arc_maint.COD_CHG_AMT);
          
            pkg_detb_rtl_teller_rec.charge_account := L_CUST_ACCOUNT.CUST_AC_NO;
          
            dbg('l_arc_maint.cod_chg_gl=' || l_arc_maint.cod_chg_gl);
            dbg('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
            dbg('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
          
            pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
            pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
            pkg_detb_rtl_teller_rec.chg_amt          := l_arc_maint.cod_chg_amt;
            depks_rtl_teller.pkg_arc_row.cod_chg_amt := l_arc_maint.cod_chg_amt;
          
            dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT=' ||
                depks_rtl_teller.pkg_arc_row.cod_chg_amt);
          
            depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
          
            dbg('L_CUST_ACCOUNT.CCY=' || L_CUST_ACCOUNT.CCY);
          
            IF l_arc_maint.cod_chg_ccy <> L_CUST_ACCOUNT.CCY THEN
              IF NOT cypkss.fn_amt1_to_amt2(GLOBAL.current_branch,
                                            l_arc_maint.cod_chg_ccy,
                                            L_CUST_ACCOUNT.CCY,
                                            l_prod.rate_type_preferred,
                                            l_prod.rate_code_preferred,
                                            l_arc_maint.cod_chg_amt,
                                            'Y',
                                            l_charge_amt,
                                            l_rate,
                                            p_err_params) THEN
                debug.pr_debug('**', 'In When Others of EX RATE.');
                debug.pr_debug('**', SQLERRM);
                p_err_code   := 'ST-OTHR-001';
                p_err_params := NULL;
                ROLLBACK TO A;
                CONTINUE;
                --RETURN FALSE;
              END IF;
            
              pkg_detb_rtl_teller_rec.chg_in_acy       := l_charge_amt;
              pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := l_rate;
            
            ELSE
              pkg_detb_rtl_teller_rec.chg_in_acy       := l_charge_amt;
              pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
            END IF;
          
            DBG('pkg_detb_rtl_teller_rec.chg_in_acy=' ||
                pkg_detb_rtl_teller_rec.chg_in_acy);
            DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate=' ||
                pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
          
            DBG('l_arc_maint.cod_chg_amt=' || l_arc_maint.cod_chg_amt);
            DBG('l_arc_maint.cod_chg_rate=' || l_arc_maint.cod_chg_rate);
            DBG('l_arc_maint.cod_chg_netting=' ||
                l_arc_maint.cod_chg_netting);
            DBG('l_arc_maint.cod_chg_txn_code=' ||
                l_arc_maint.cod_chg_txn_code);
            DBG('l_arc_maint.cod_mis_head=' || l_arc_maint.cod_mis_head);
            DBG('l_arc_maint.cod_chg_desc=' || l_arc_maint.cod_chg_desc);
            DBG('l_arc_maint.cod_chg_type=' || l_arc_maint.cod_chg_type);
            DBG('PKG_ARC_ROW.CHARGE_CODE=' || l_arc_maint.CHARGE_CODE);
          
            pkg_detb_rtl_teller_rec.chg_in_lcy   := l_arc_maint.cod_chg_amt;
            pkg_detb_rtl_teller_rec.acy_lcy_rate := l_arc_maint.cod_chg_rate; --p_ifdrftpm.v_iftbs_rft_master.exch_rate;
            pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
            pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
            pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
            pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
            pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
            pkg_detb_rtl_teller_rec.waiver       := 'N';
            pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
          
            DBG('pkg_detb_rtl_teller_rec.chg_type=' ||
                pkg_detb_rtl_teller_rec.chg_type);
          
            DBG('Calling depks_rtl_teller.fn_save');
          
            IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                            P_ERR_CODE,
                                            P_ERR_PARAMS) THEN
              dbg('FAILED IN FN_SAVE');
            
              ROLLBACK TO A;
            
              DBG('P_ERR_CODE=' || P_ERR_CODE);
              DBG('P_ERR_PARAMS=' || P_ERR_PARAMS);
              DBG('L_GEN_SEQ_NO=' || L_GEN_SEQ_NO);
            
              /* IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG_NEW(G.PARTNER_RECEIPT_REF,
              L_GEN_SEQ_NO,
              l_transactionUniqueNo,
              'E',
              L_IN_RESP,
              P_ERR_CODE,
              P_ERR_PARAMS);*/
            
              COMMIT;
              CONTINUE;
            ELSE
              DBG('SUCCESS IN FN_SAVE');
            
              DBG('CALLING DEPKS_RTL_TELLER.FN_RTL_TELLER_AUTH');
              IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(L_CUST_ACCOUNT.BRANCH_CODE,
                                                          L_TRN_REF_NO,
                                                          GLOBAL.USER_ID,
                                                          GLOBAL.LCY,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
                DBG('AUTH RETRUNED FALSE' || P_ERR_CODE);
                DBG('FAILED TO PROCESS TRANSACTION');
                DBG('ROLLINGBACK TO SAVEPOINT A');
              
                ROLLBACK TO A;
              
                /* IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG_NEW(G.PARTNER_RECEIPT_REF,
                L_GEN_SEQ_NO,
                l_transactionUniqueNo,
                'E',
                L_IN_RESP,
                P_ERR_CODE,
                P_ERR_PARAMS);*/
                COMMIT;
              
                CONTINUE;
              
              ELSE
              
                DBG('SUCCESS IN FN_AUTH');
              
                insert into IFTB_AIA_SI_PAYMENTS_MASTER
                values
                  (L_TRN_REF_NO,
                   NULL, --G.AIA_POLICY_NO,
                   PKG_DETB_RTL_TELLER_REC.TXN_ACC, --AIA corporate account
                   PKG_DETB_RTL_TELLER_REC.TXN_CCY, --usd always
                   PKG_DETB_RTL_TELLER_REC.OFS_AMOUNT, --AIA usd amount  always
                   PKG_DETB_RTL_TELLER_REC.TXN_BRANCH,
                   PKG_DETB_RTL_TELLER_REC.TXN_TRN_CODE,
                   PKG_DETB_RTL_TELLER_REC.OFS_ACC,
                   PKG_DETB_RTL_TELLER_REC.OFS_CCY,
                   PKG_DETB_RTL_TELLER_REC.TXN_AMOUNT,
                   PKG_DETB_RTL_TELLER_REC.OFS_BRANCH,
                   PKG_DETB_RTL_TELLER_REC.OFS_TRN_CODE,
                   PKG_DETB_RTL_TELLER_REC.LCY_AMOUNT,
                   PKG_DETB_RTL_TELLER_REC.TRN_DT,
                   PKG_DETB_RTL_TELLER_REC.VALUE_DT,
                   NULL
                   --G.PARTNER_RECEIPT_REF
                   );
              
                --Get AIA CONFIRM PAYMENT
              
                /*IF NOT IFPKS_AIA_SI_UTILS.FN_MSG_UPLOAD(G.PARTNER_RECEIPT_REF,
                                                        G.AIA_POLICY_NO,
                                                        'C',
                                                        L_FORMATTED_MSG,
                                                        'Payment Confirmation Call',
                                                        l_payment_amount,
                                                        l_paymentDueDate,
                                                        l_transactionUniqueNo,
                                                        L_GEN_SEQ_NO,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
                
                  DBG('FAILED IN AIA PAYMENT CALL');
                
                  --RETURN FALSE;
                  ROLLBACK TO A;
                  CONTINUE;
                
                  IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG_NEW(L_GEN_SEQ_NO,
                                                              l_transactionUniqueNo,
                                                              L_TRN_REF_NO,
                                                              'E',
                                                              L_IN_RESP,
                                                              P_ERR_CODE,
                                                              P_ERR_PARAMS);
                
                ELSE
                
                  DBG('SUCCESS IN AIA PAYMENT CALL=' || L_GEN_SEQ_NO);
                  DBG('SUCCESS IN AIA PAYMENT CALL=' ||
                      l_transactionUniqueNo);
                
                  IFPKS_AIA_SI_UTILS.PR_UPDATE_AIA_WS_LOG_NEW(L_GEN_SEQ_NO,
                                                              l_transactionUniqueNo,
                                                              L_TRN_REF_NO,
                                                              'S',
                                                              'C');
                
                  COMMIT;
                END IF;*/
              END IF;
            END IF;
          
          END IF;
        
        EXCEPTION
          WHEN OTHERS THEN
            -- DBG('FAILED IN PROCESSING CURRENT INCOMING ORDER ID=' ||
            --   L_ORDER_ID);
            DBG('ERROR LINE NUMBER=' ||
                DBMS_UTILITY.format_error_backtrace);
            DBG('ERROR CODE=' || SQLCODE);
            DBG('ERROR MESSAGE=' || SQLERRM);
            CONTINUE;
        END;
      
      END LOOP;
    
    END IF;
  
  END PR_PROCESS_PBCUST_FEE;

END IFPKS_PBCUST_FEE_UTILS;
