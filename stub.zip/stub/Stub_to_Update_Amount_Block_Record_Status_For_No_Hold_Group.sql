Step 1: Create a below table

CREATE TABLE CATM_AMOUNT_BLOCKS_PRINCE AS SELECT * FROM CATM_AMOUNT_BLOCKS WHERE EXPIRY_DATE <='28-APR-2020' AND RECORD_STAT = 'O' AND AMOUNT_BLOCK_TYPE IN ('S','F') AND HOLD_CODE IS NULL
AND ACCOUNT IN (SELECT CUST_AC_NO FROM STTM_CUST_ACCOUNT WHERE ACCOUNT_TYPE <> 'Y') AND AUTH_STAT = 'A'
/

Step 2: Add a new column "STATUS" for validity

ALTER TABLE CATM_AMOUNT_BLOCKS_PRINCE ADD (STATUS CHAR(1) DEFAULT 'N')
/

Step 3: Take the count of below query

SELECT * FROM CATM_AMOUNT_BLOCKS_PRINCE WHERE STATUS = 'N' --Take the count

Step 4: Execute the below stub in SQL Window

DECLARE
  CURSOR C1 IS
    SELECT *
      FROM CATM_AMOUNT_BLOCKS_PRINCE WHERE STATUS = 'N';
BEGIN

  FOR G IN C1 LOOP
  BEGIN
    GLOBAL.PR_INIT(G.BRANCH, 'SYSTEM');
  
    UPDATE CATM_AMOUNT_BLOCKS
       SET MAKER_ID    = 'SYSTEM',
           CHECKER_ID  = 'SYSTEM',
           MOD_NO      = MOD_NO + 1,
           RECORD_STAT = 'C',
           MAKER_DT_STAMP = GLOBAL.application_date,
           CHECKER_DT_STAMP = GLOBAL.application_date
     WHERE AMOUNT_BLOCK_NO = G.AMOUNT_BLOCK_NO
       AND ACCOUNT = G.ACCOUNT
       AND BRANCH = G.BRANCH;
       
      UPDATE CATM_AMOUNT_BLOCKS_PRINCE SET STATUS = 'Y' WHERE AMOUNT_BLOCK_NO = G.AMOUNT_BLOCK_NO
       AND ACCOUNT = G.ACCOUNT
       AND BRANCH = G.BRANCH AND STATUS = 'N';
  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      CONTINUE;
  END;
  END LOOP;

EXCEPTION
  WHEN OTHERS THEN
  DBMS_OUTPUT.put_line('ERROR CODE='||SQLCODE);
  DBMS_OUTPUT.put_line('ERROR MESSAGE='||SQLERRM);
END;

Step 5: Take the count for verification

SELECT * FROM CATM_AMOUNT_BLOCKS_PRINCE WHERE STATUS = 'Y' --Take the count

Step 6: Matching or Not

Count of Step3 and Step5 must match. If not, execute the stub once again.

Step 7: If step 6 is successful then execute below command else contact me!!

DROP TABLE CATM_AMOUNT_BLOCKS_PRINCE
/