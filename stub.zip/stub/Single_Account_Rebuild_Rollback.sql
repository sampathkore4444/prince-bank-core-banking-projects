SET NUMFORMAT 999,999,999,999,999,999,999.999
SET ARRAY 10
SET AUTOP OFF
SET HEAD ON
SET FEEDBACK ON -- disable update and other outputs
SET LINE 10000
SET PAGESIZE 10000
SET ECHO OFF
SET TRIMSPOOL OFF
SET TRIMOUT OFF
SET TERMOUT OFF
COL lv_dt NEW_VALUE lv_dt
SELECT TO_CHAR(SYSDATE, 'YYMMDDHH24MISS') lv_dt FROM dual;
SET TERMOUT ON
SET WRAP ON
SET COLSEP ";"
SET VERIFY OFF -- disable :new, :old output
SET LONG 100000
BEGIN
    DBMS_OUTPUT.ENABLE (buffer_size => NULL);
END;
/

SPOOL D:\acoount_rebuild_Rollback_3-24497850761.spl


select * from sttm_cust_account where cust_ac_no = '000029728';

select * from sttm_account_balance where cust_ac_no = '000029728';

Declare
  l_acy_curr_bal                actb_daily_log.lcy_amount%type := 0;
  l_lcy_curr_bal                actb_daily_log.lcy_amount%type := 0;
  l_acy_uncollected             actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_dr               actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_cr               actb_daily_log.lcy_amount%type := 0;
  l_acy_tank_dr                 actb_daily_log.lcy_amount%type := 0;
  l_acy_tank_cr                 actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_tank_cr          actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_tank_dr          actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_uncollected      actb_daily_log.lcy_amount%type := 0;
  l_acy_tank_uncollected        actb_daily_log.lcy_amount%type := 0;
  l_acy_unauth_tank_uncollected actb_daily_log.lcy_amount%type := 0;
  l_acy_blocked_amt             catm_amount_blocks.amount%type;
  l_receivable_amount           cstb_auto_settle_block.amount_due%type;
  l_update                      boolean := false;

Begin
  for i in (select a.branch_code,
                   a.cust_ac_no,
                   a.ccy,
                   a.acy_curr_balance,
                   a.lcy_curr_balance,
                   a.acy_unauth_dr,
                   a.acy_tank_cr,
                   a.acy_tank_dr,
                   a.acy_unauth_tank_cr,
                   a.acy_unauth_tank_dr,
                   a.acy_unauth_uncollected,
                   a.acy_tank_uncollected,
                   a.acy_unauth_tank_uncollected,
                   b.acy_uncollected,
                   b.acy_unauth_cr,
                   b.acy_withdrawable_bal,
                   b.acy_blocked_amt,
                   b.receivable_amount
              from sttm_cust_account a, sttm_account_balance b
             where a.cust_ac_no = b.cust_ac_no
               and a.cust_ac_no in ('000029728')) loop
  
    global.pr_init(i.branch_code, 'SYSTEM');
  
    begin
      select sum(decode(drcr_ind, 'D', -1, 1) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(drcr_ind, 'D', -1, 1) * lcy_amount),
             sum(decode(auth_stat, 'A', 0, 1) * decode(drcr_ind, 'D', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(auth_stat, 'A', 0, 1) * decode(drcr_ind, 'C', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(drcr_ind, 'D', 1, 0) *
                 decode(balance_upd, 'T', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(drcr_ind, 'C', 1, 0) *
                 decode(balance_upd, 'T', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(drcr_ind, 'C', 1, 0) * decode(auth_stat, 'A', 0, 1) *
                 decode(balance_upd, 'T', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(drcr_ind, 'D', 1, 0) * decode(auth_stat, 'A', 0, 1) *
                 decode(balance_upd, 'T', 1, 0) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount))
        into l_acy_curr_bal,
             l_lcy_curr_bal,
             l_acy_unauth_dr,
             l_acy_unauth_cr,
             l_acy_tank_dr,
             l_acy_tank_cr,
             l_acy_unauth_tank_cr,
             l_acy_unauth_tank_dr
        from acvw_all_ac_entries
       where ac_branch = i.branch_code
         and ac_no = i.cust_ac_no;
    exception
      when no_data_found then
        l_acy_curr_bal := 0;
        l_lcy_curr_bal := 0;
      when others then
        dbms_output.put_line('Error while fetching the data from ac entry for ' ||
                             i.cust_ac_no);
    end;
  
    begin
      select sum(decode(auth_stat, 'A', 0, 1) *
                 decode(drcr_ind, 'D', -1, 1) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(balance_upd, 'T', 1, 0) *
                 decode(drcr_ind, 'D', -1, 1) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount)),
             sum(decode(auth_stat, 'A', 0, 1) *
                 decode(balance_upd, 'T', 1, 0) *
                 decode(drcr_ind, 'D', -1, 1) *
                 decode(i.ccy, global.lcy, lcy_amount, fcy_amount))
        into l_acy_unauth_uncollected,
             l_acy_tank_uncollected,
             l_acy_unauth_tank_uncollected
        from acvw_all_ac_entries
       where ac_branch = i.branch_code
         and ac_no = i.cust_ac_no
         and value_dt > global.application_date;
    exception
      when no_data_found then
        l_acy_unauth_uncollected := 0;
      when others then
        dbms_output.put_line('Error while fetching the uncollected data from ac entry for ' ||
                             i.cust_ac_no);
    end;
  
    begin
      select sum(amount)
        into l_acy_uncollected
        from actb_funcol
       where branch = i.branch_code
         and account = i.cust_ac_no;
    
    exception
      when no_data_found then
        l_acy_uncollected := 0;
      when others then
        dbms_output.put_line('Error while fetching the data from actb_funcol for ' ||
                             i.cust_ac_no);
    end;
  
    begin
      select sum(amount)
        into l_acy_blocked_amt
        from catm_amount_blocks
       where branch = i.branch_code
         and account = i.cust_ac_no
         and record_stat = 'O'
         and nvl(expiry_date, global.application_date) >=
             global.application_date;
    exception
      when no_data_found then
        l_acy_blocked_amt := 0;
      when others then
        dbms_output.put_line('Error while fetching the data from catm_amt_block for ' ||
                             i.cust_ac_no);
    end;
  
    begin
      select sum(amount_due - amount_paid)
        into l_receivable_amount
        from cstb_auto_settle_block
       where account_br = i.branch_code
         and account_no = i.cust_ac_no;
    exception
      when no_data_found then
        l_receivable_amount := 0;
      when others then
        dbms_output.put_line('Error while fetching the data from auto settle block for ' ||
                             i.cust_ac_no);
    end;
  
    if nvl(l_acy_curr_bal, 0) <> nvl(i.acy_curr_balance, 0) or
       nvl(l_lcy_curr_bal, 0) <> nvl(i.lcy_curr_balance, 0) then
      l_update := true;
    
    end if;
  
    if nvl(l_acy_uncollected, 0) <> nvl(i.acy_uncollected, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_cr, 0) <> nvl(i.acy_unauth_cr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_dr, 0) <> nvl(i.acy_unauth_dr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_tank_cr, 0) <> nvl(i.acy_tank_cr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_tank_dr, 0) <> nvl(i.acy_tank_dr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_tank_cr, 0) <> nvl(i.acy_unauth_tank_cr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_tank_dr, 0) <> nvl(i.acy_unauth_tank_dr, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_uncollected, 0) <> nvl(i.acy_unauth_uncollected, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_tank_uncollected, 0) <> nvl(i.acy_tank_uncollected, 0) then
      l_update := true;
    end if;
  
    if nvl(l_acy_unauth_tank_uncollected, 0) <>
       nvl(i.acy_unauth_tank_uncollected, 0) then
      l_update := true;
    end if;
  
    if nvl(i.acy_withdrawable_bal, 0) <>
       (nvl(i.acy_curr_balance, 0) - nvl(i.acy_uncollected, 0) -
        nvl(i.acy_unauth_cr, 0) - nvl(i.receivable_amount, 0) -
        nvl(i.acy_blocked_amt, 0)) then
      l_update := true;
    end if;
  
    /*  if nvl(i.acy_withdrawable_bal, 0) <>
       (nvl(l_acy_curr_bal, 0) - nvl(l_acy_uncollected, 0) -
        nvl(l_acy_unauth_cr, 0) - nvl(l_acy_blocked_amt, 0) -
        nvl(l_receivable_amount, 0)) then
      l_update := true;
    end if;*/
  
    if l_update = true then
    
      update sttm_cust_account
         set acy_curr_balance            = nvl(l_acy_curr_bal, 0),
             lcy_curr_balance            = nvl(l_lcy_curr_bal, 0),
             acy_unauth_uncollected      = nvl(l_acy_unauth_uncollected, 0),
             acy_tank_cr                 = nvl(l_acy_tank_cr, 0),
             acy_tank_dr                 = nvl(l_acy_tank_dr, 0),
             acy_unauth_tank_cr          = nvl(l_acy_unauth_tank_cr, 0),
             acy_unauth_tank_dr          = nvl(l_acy_unauth_tank_dr, 0),
             acy_tank_uncollected        = nvl(l_acy_tank_uncollected, 0),
             acy_unauth_tank_uncollected = nvl(l_acy_unauth_tank_uncollected,
                                               0),
             acy_unauth_dr               = nvl(l_acy_unauth_dr, 0),
			 acy_unauth_cr		         = nvl(l_acy_unauth_cr, 0)
       where branch_code = i.branch_code
         and cust_ac_no = i.cust_ac_no;
    
      update sttm_account_balance
         set acy_uncollected      = nvl(l_acy_uncollected, 0),
             acy_blocked_amt      = nvl(l_acy_blocked_amt, 0),
             receivable_amount    = nvl(l_receivable_amount, 0),
             acy_unauth_cr        = nvl(l_acy_unauth_cr, 0),
             acy_withdrawable_bal = nvl(l_acy_curr_bal, 0) -
                                    nvl(l_acy_uncollected, 0) -
                                    nvl(l_acy_unauth_cr, 0) -
                                    nvl(l_acy_blocked_amt, 0) -
                                    nvl(l_receivable_amount, 0)
       where cust_ac_brn = i.branch_code
         and cust_ac_no = i.cust_ac_no;
    
      l_update := false;
    end if;
    --commit;
  end loop;
End;
/
select * from sttm_cust_account where cust_ac_no = '000029728';
select * from sttm_account_balance where cust_ac_no = '000029728';
rollback;

set echo off
spool off
