import java.io.IOException;
import java.nio.file.*;

public class LogFileMonitor {

    public static void main(String[] args) throws IOException, InterruptedException {
        Path logFilePath = Paths.get("path/to/file.log");

        WatchService watchService = FileSystems.getDefault().newWatchService();
        logFilePath.getParent().register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

        while (true) {
            WatchKey key;
            try {
                key = watchService.take();
            } catch (InterruptedException ex) {
                return;
            }

            for (WatchEvent<?> event : key.pollEvents()) {
                WatchEvent.Kind<?> kind = event.kind();

                if (kind == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }

                WatchEvent<Path> pathEvent = (WatchEvent<Path>) event;
                Path modifiedFilePath = pathEvent.context();

                if (modifiedFilePath.endsWith(logFilePath.getFileName())) {
                    checkForErrors(logFilePath);
                }
            }

            boolean reset = key.reset();
            if (!reset) {
                break;
            }
        }
    }

    public static void checkForErrors(Path logFilePath) throws IOException {
        Files.lines(logFilePath)
                .filter(line -> line.contains("Error"))
                .forEach(System.out::println);
    }
}