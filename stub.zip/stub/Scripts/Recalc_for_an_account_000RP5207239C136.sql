declare
            p_err_code                    varchar2(255);
            p_err_param                  varchar2(255);
            l_count	number;
begin
            global.pr_init('000', 'BKOCSI');
            clpkss_batch.g_commit_freq := 1000;
            
            for rec in (select * from cltb_account_apps_master where account_number in ('000RP5207239C136' ) and branch_code='000')
            loop            	
            		FOR REC1 in (select * from cltb_account_components where account_number=rec.account_number and branch_code=rec.branch_code)
            		loop
            			select count(*) into l_count from cltb_account_schedules 
									where account_number=rec.account_number
									and branch_code=rec.branch_code
									and component_name=rec1.component_name
									and schedule_due_date = rec.maturity_date;									
									
									IF L_COUNT = 0 THEN									
											BEGIN 
														INSERT INTO cltbs_account_schedules
														(account_number,
														branch_code,
														component_name,
														formula_name,
														schedule_type,
														schedule_st_date,
														schedule_due_date,
														grace_days,
														orig_amount_due,
														amount_due,
														adj_amount,
														amount_settled,
														amount_overdue,
														accrued_amount,
														settlement_ccy,
														lcy_equivalent,
														dly_avg_amt,
														schedule_flag,
														waiver_flag,
														sch_status, 
														amount_readjusted,
														last_pmnt_value_date, 
														mora_int,      
														RETRY_START_DATE, 
														schedule_no      
														,READJ_SETTLED
														,LAST_READJ_XRATE,
														emi_amount,
														schedule_linkage,
														capitalized,
														process_no,
														adj_settled,
														account_gl,
														writeoff_amt
														,susp_amt_due     
														,susp_amt_settled  
														,susp_amt_lcy      
														,susp_read_amt     
														,susp_read_settled 
														,last_susp_xrate   
														,amount_waived     
														,LIST_DAYS
														,LIST_AVG_AMT
														,IRR_APPLICABLE
														)
														SELECT account_number, branch_code, component_name,
														formula_name, schedule_type, schedule_st_date,
														schedule_due_date, grace_days, orig_amount_due,
														amount_due, adj_amount, amount_settled,
														amount_overdue, accrued_amount, settlement_ccy,
														lcy_equivalent, dly_avg_amt,schedule_flag, waiver_flag,
														sch_status,  
														amount_readjusted,
														last_pmnt_value_date, 
														mora_int,              
														RETRY_START_DATE,     
														schedule_no       
														, READJ_SETTLED, LAST_READJ_XRATE,
														emi_amount,
														schedule_linkage,
														capitalized,
														process_no,
														adj_settled,
														account_gl,
														writeoff_amt
														,susp_amt_due      
														,susp_amt_settled  
														,susp_amt_lcy      
														,susp_read_amt    
														,susp_read_settled
														,last_susp_xrate  
														,amount_waived     
														,LIST_DAYS
														,LIST_AVG_AMT
														,IRR_APPLICABLE
														FROM cltbs_acc_schedules_history
														WHERE account_number = rec.account_number
														AND   branch_code = rec.branch_code
														AND component_name= rec1.component_name
														and schedule_due_date = rec.maturity_date
														AND   version_no = rec.version_no - 1;
												EXCEPTION
													WHEN OTHERS THEN
													debug.pr_debug('CL','Failed in CLTBS_ACCOUNT_SCHEDULES with error :'||SQLERRM);
												END;
												debug.pr_debug('CL','Account Number '||rec.account_number);
												debug.pr_debug('CL','Branch Code'||rec.branch_code);
												debug.pr_debug('CL','Component Name '||rec1.component_name);
												debug.pr_debug('CL','Maturity Date '||rec.maturity_date);
												debug.pr_debug('CL','Version No '||rec.version_no);												
									END IF;
            		end loop;
            		update cltb_account_master 
								set calc_reqd = 'Y'
								, recalc_action_code = 'E'
								where branch_code = rec.branch_code AND ACCOUNT_NUMBER = rec.account_number;            		
            debug.pr_debug('CL','Going for recalc of account '||rec.account_number);
            
            if not clpkss_recalc.fn_recalc_for_an_account(rec.account_number
							, rec.branch_code
							, to_date'15-JAN-2008','DD-MM-RRRR')
							, p_err_code
							, p_err_param
							)
            THEN
                        dbms_output.put_line('failure ' || p_err_param);
            ELSE
                        dbms_output.put_line('success ');
            END IF;								
            end loop;

exception
            when others then
                        DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
end;
/
commit;

