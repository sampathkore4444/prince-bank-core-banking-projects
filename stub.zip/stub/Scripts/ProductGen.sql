DECLARE
	p_err_code   ertbs_msgs.err_code%TYPE;
	p_err_param  ertbs_msgs.message%TYPE;
BEGIN
	global.pr_init('EST', 'SAN');
	FOR each_rec in (SELECT product_code FROM cltm_product WHERE once_auth='Y' )
	LOOP
		dbms_output.put_line('Inside for the Product : '||each_rec.product_code);
		IF NOT clpkss_prd_rulegen.fn_create_rules(each_rec.product_code,
												  p_err_code,
												  p_err_param
												 )
		THEN
			dbms_output.put_line('Error ' || p_err_code' : '||p_err_param);  
		END IF;
	END LOOP;
END;
/
