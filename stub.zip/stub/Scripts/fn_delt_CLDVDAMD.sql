declare
			p_account varchar2(35) := '000PENL071380802';
			p_branch   varchar2(3) := '000';            
            p_err_code   ertbs_msgs.err_code%type;
            p_err_param  ertbs_msgs.message%type;
begin
            global.pr_init('000', 'SAN');
            clpkss_batch.g_commit_freq := 1000;
			IF NOT clpks_iface.fn_delt_CLDVDAMD(p_account,
												p_branch,
											  p_account,
											  p_err_code,
											  p_err_param)
			THEN
				 DBMS_OUTPUT.PUT_LINE('clpkss_liqd.fn_aliq_for_a_day failed with :-( ' || p_err_code || p_err_param);
    		else
    			dbms_output.put_line('ALIQ successful');
			END IF;  
exception
when others then
dbms_output.put_line('aliq failed with '||sqlerrm);
end;
/
commit;