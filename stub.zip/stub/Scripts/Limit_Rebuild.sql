DECLARE
	p_err_code   			ertbs_msgs.err_code%type;
	p_err_param  			ertbs_msgs.message%type;
	l_rec_account    		cltbs_account_master%ROWTYPE;
	l_account_number		cltbs_account_master.account_number%type := '001LLC1072701066';
	l_branch_code			cltbs_account_master.branch_code%type := '001';
	l_total_recd			cltbs_account_master.AMOUNT_DISBURSED%TYPE;
	l_total_paid			CLTBS_AMOUNT_PAID.AMOUNT_PAID%TYPE;

BEGIN
	global.pr_init('001', 'SYSTEM');

	l_rec_account := clpks_cache.fn_account_master(l_account_number,l_branch_code);

	DELETE FROM lmtbs_line_utils u
	WHERE  u.ref_no = l_account_number
	AND amt_tag = 'PRINCIPAL';

	SELECT NVL(SUM(AMOUNT_RECD),0) INTO l_total_recd
	FROM cltbs_amount_recd
	WHERE account_number=l_account_number 
	AND branch_code	= l_branch_code
	AND component_name ='PRINCIPAL';		
	
	debug.pr_debug('CL','Total Disbursed Amount :- '||l_total_recd);
	debug.pr_debug('CL','Entering clpkss_util.fn_update_utilization 1');

	IF NOT clpkss_util.fn_update_utilization(l_rec_account,
											 'I',
											 l_total_recd,
											 p_err_code,
											 p_err_param
										    )
	THEN
		 debug.pr_debug('CL','failed in clpkss_util.fn_update_utilization');
		 RETURN;
	END IF;

	debug.pr_debug('CL','After clpkss_util.fn_update_utilization.');

	SELECT NVL(SUM(AMOUNT_PAID),0) INTO l_total_paid
	FROM cltbs_amount_paid
	WHERE account_number=l_account_number 
	AND branch_code	= l_branch_code
	AND component_name ='PRINCIPAL';		

	debug.pr_debug('CL','Total Paid amount :- '||NVL(l_total_paid,0));
    debug.pr_debug('CL','Entering clpkss_util.fn_update_utilization 2');

	IF NVL(l_total_paid,0) > 0
	THEN
		IF NOT clpkss_util.fn_update_utilization(l_rec_account,
												 'D',
												 NVL(l_total_paid,0),
												 p_err_code,
												 p_err_param
												)
		THEN
			 debug.pr_debug('CL','Failed in clpkss_util.fn_update_utilization with : '||p_err_code||' : '||p_err_param);
			 RETURN;
		END IF;
	END IF;

	COMMIT;

EXCEPTION
	WHEN OTHERS
	THEN
		debug.pr_debug('CL','Error IN WO : ' ||SQLERRM);
END;
/