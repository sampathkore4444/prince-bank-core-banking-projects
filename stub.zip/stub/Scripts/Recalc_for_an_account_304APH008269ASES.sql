declare
            p_err_code                    varchar2(255);
            p_err_param                  varchar2(255);
begin
            global.pr_init('304', 'SYSTEM');
            clpkss_batch.g_commit_freq := 1000;
            update cltb_account_master 
            set calc_reqd = 'Y'
            , recalc_action_code = 'E'
            where branch_code = '304' 
            AND ACCOUNT_NUMBER = '304APH008269ASES';
            
            UPDATE CLTB_ACCOUNT_COMP_BALANCES
            SET BALANCE = 47321.45
            WHERE ACCOUNT_NUMBER='304APH008269ASES'
            AND BRANCH_CODE='304'
            AND COMPONENT_NAME='PRINCIPAL_EXPECTED'
            AND VAL_DATE =TO_DATE('16-OCT-2008','DD-MM-RRRR');
            
            if not clpkss_recalc.fn_recalc_for_an_account('304APH008269ASES'
																													, '304'
																													, TO_DATE('16-OCT-2008','DD-MM-RRRR')
																													, p_err_code
																													, p_err_param
																													)
            THEN
                        dbms_output.put_line('failure ' || p_err_param);
            ELSE
                        dbms_output.put_line('success ');
            END IF;
exception
            when others then
                        DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
end;
/
commit;
