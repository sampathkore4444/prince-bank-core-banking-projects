DECLARE
            p_err_code                    varchar2(255);
            p_err_param                  varchar2(255);
            l_balance 			CLTBS_ACCOUNT_COMP_BAL_BREAKUP.BALANCE%type := 0;
            l_lcy_balance 			CLTBS_ACCOUNT_COMP_BAL_BREAKUP.LCY_BALANCE%type := 0;
            
            CURSOR cr_mismatch
            IS            
						SELECT * FROM
						(SELECT A.ACCOUNT_NUMBER, A.BRANCH_CODE, SUM(A.AMOUNT_DUE-A.AMOUNT_SETTLED) SUM1 
								FROM CLTB_ACCOUNT_SCHEDULES A, CLTB_ACCOUNT_MASTER B 
								WHERE A.ACCOUNT_NUMBER=B.ACCOUNT_NUMBER 
								AND A.BRANCH_CODE = B.BRANCH_CODE
								AND A.COMPONENT_NAME='PRINCIPAL'
								AND B.ACCOUNT_STATUS='A'
								AND USER_DEFINED_STATUS = 'NORM'
								GROUP BY A.ACCOUNT_NUMBER, A.BRANCH_CODE) T1,
						(SELECT ACCOUNT_NUMBER ACCNUM, BRANCH_CODE BRNCODE, SUM(BALANCE) SUM2 
								FROM CLTB_ACCOUNT_COMP_BAL_BREAKUP 
								WHERE COMPONENT='PRINCIPAL'
								GROUP BY ACCOUNT_NUMBER, BRANCH_CODE) T2
						WHERE T1.ACCOUNT_NUMBER=T2.ACCNUM
						AND T1.BRANCH_CODE =T2.BRNCODE
						AND T1.SUM1<>T2.SUM2;
						
						CURSOR cr_pr_event_details(p_accno CLTBS_EVENT_ENTRIES.account_number%type, p_brncode CLTBS_EVENT_ENTRIES.branch_code%type)
						IS
							SELECT * 
							FROM CLTBS_EVENT_ENTRIES
							WHERE ACCOUNT_NUMBER = p_accno
							AND BRANCH_CODE = p_brncode
							AND COMPONENT_NAME = 'PRINCIPAL'
							AND EVENT_CODE IN ('DSBR','REVD','MLIQ','ALIQ','REVP')
							ORDER BY EVENT_CODE;
							
						CURSOR cr_ins_event_details(p_accno CLTBS_EVENT_ENTRIES.account_number%type, p_brncode CLTBS_EVENT_ENTRIES.branch_code%type)
						IS
							SELECT * 
							FROM CLTBS_EVENT_ENTRIES
							WHERE ACCOUNT_NUMBER = p_accno
							AND BRANCH_CODE = p_brncode
							AND COMPONENT_NAME = 'MAIN_INT'
							AND EVENT_CODE IN ('ACCR','RACR','MLIQ','ALIQ','REVP')
							ORDER BY EVENT_CODE;
            
BEGIN
            global.pr_init('001', 'SAN');
            clpkss_batch.g_commit_freq := 1000;
            
            FOR REC IN cr_mismatch
            LOOP
            		DEBUG.PR_DEBUG('CL','Account Number :- '||rec.account_number);
            		
            		/*************************************************************************
            		
            											CODE FOR PRINCIPAL
            		
            		**************************************************************************/
            		l_balance := 0;
            		l_lcy_balance := 0;
            		FOR REC1 IN cr_pr_event_details(rec.account_number,rec.branch_code)
            		LOOP
            			DEBUG.PR_DEBUG('CL','INCR DESCR :- '||REC1.INCR_DECR_FLAG);
            			DEBUG.PR_DEBUG('CL','EVENT CODE :- '||REC1.EVENT_CODE);
            			DEBUG.PR_DEBUG('CL','LCY_AMOUNT :- '||REC1.LCY_AMOUNT);
            			DEBUG.PR_DEBUG('CL','AMOUNT :- '||REC1.AMOUNT);
            			IF NVL(REC1.INCR_DECR_FLAG,'#') = 'I' AND REC1.EVENT_CODE IN ('DSBR','REVD') AND REC1.DR_ACC_ROLE='LOAN_ACCOUNT'  and REC1.CR_ACC_ROLE='CR_SETTL_BRIDGE'
            			THEN
	            				l_balance 		:= l_balance + NVL(REC1.AMOUNT,0);
	            				l_lcy_balance	:= l_lcy_balance + NVL(REC1.LCY_AMOUNT,0);
	            		END IF;
	            		
            			IF NVL(REC1.INCR_DECR_FLAG,'#') = 'D' AND REC1.EVENT_CODE IN ('MLIQ','ALIQ','REVP')
            			THEN
	            				l_balance 		:= l_balance - NVL(REC1.AMOUNT,0);
	            				l_lcy_balance	:= l_lcy_balance - NVL(REC1.LCY_AMOUNT,0);
	            		END IF;
            		END LOOP;
            		DEBUG.PR_DEBUG('CL','l_balance :- '||l_balance);
            		DEBUG.PR_DEBUG('CL','l_lcy_balance :- '||l_lcy_balance);  
            		
            		UPDATE CLTBS_ACCOUNT_COMP_BAL_BREAKUP
            		SET BALANCE = l_balance
            		,LCY_BALANCE = l_lcy_balance
            		WHERE ACCOUNT_NUMBER = rec.account_number
            		AND BRANCH_CODE = rec.branch_code
            		AND COMPONENT ='PRINCIPAL'
            		AND STATUS_CODE ='NORM';
            		
            		
            		/*************************************************************************
            		
            											CODE FOR MAIN_INT
            		
            		**************************************************************************/            		
            		
            		l_balance := 0;
            		l_lcy_balance := 0;
            		FOR REC1 IN cr_ins_event_details(rec.account_number,rec.branch_code)
            		LOOP
            			DEBUG.PR_DEBUG('CL','INCR DESCR :- '||REC1.INCR_DECR_FLAG);
            			DEBUG.PR_DEBUG('CL','EVENT CODE :- '||REC1.EVENT_CODE);
            			DEBUG.PR_DEBUG('CL','LCY_AMOUNT :- '||REC1.LCY_AMOUNT);
            			DEBUG.PR_DEBUG('CL','AMOUNT :- '||REC1.AMOUNT);
            			IF NVL(REC1.INCR_DECR_FLAG,'#') = 'I' AND REC1.EVENT_CODE IN ('ACCR','RACR') 
            			THEN
	            				l_balance 		:= l_balance + NVL(REC1.AMOUNT,0);
	            				l_lcy_balance	:= l_lcy_balance + NVL(REC1.LCY_AMOUNT,0);
	            		END IF;
	            		
            			IF NVL(REC1.INCR_DECR_FLAG,'#') = 'D' AND REC1.EVENT_CODE IN ('MLIQ','ALIQ','REVP')
            			THEN
	            				l_balance 		:= l_balance - NVL(REC1.AMOUNT,0);
	            				l_lcy_balance	:= l_lcy_balance - NVL(REC1.LCY_AMOUNT,0);
	            		END IF;
            		END LOOP;
            		DEBUG.PR_DEBUG('CL','l_balance :- '||l_balance);
            		DEBUG.PR_DEBUG('CL','l_lcy_balance :- '||l_lcy_balance);  
            		
            		UPDATE CLTBS_ACCOUNT_COMP_BAL_BREAKUP
            		SET BALANCE = l_balance
            		,LCY_BALANCE = l_lcy_balance
            		WHERE ACCOUNT_NUMBER = rec.account_number
            		AND BRANCH_CODE = rec.branch_code
            		AND COMPONENT ='MAIN_INT'
            		AND STATUS_CODE ='NORM';
            		
            		
            END LOOP;
exception
            when others then
                        DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
end;
/
COMMIT;