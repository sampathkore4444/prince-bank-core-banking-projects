DECLARE
	p_err_code   ertbs_msgs.err_code%TYPE;
	p_err_param  ertbs_msgs.message%TYPE;
BEGIN
	global.pr_init('CHO', 'SANTOSH');
	IF NOT clpkss_prd_rulegen.fn_create_shell( p_err_code)
	THEN
		dbms_output.put_line('Error ' || p_err_code);
	END IF;
END;
/
