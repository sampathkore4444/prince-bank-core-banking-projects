declare
	lseqname			varchar2(30);
	lseqcnt				integer;
begin
	global.pr_init('001', 'SAN');
	
	for each_product in (select product_code
							from cltms_product
							WHERE once_auth = 'Y' 
							AND record_stat = 'O'
							)
	loop							
		FOR each_branch IN (SELECT branch_code
							  FROM sttm_branch a
							 WHERE once_auth = 'Y' AND
								   record_stat = 'O' AND NOT EXISTS
							 (SELECT 1
									  FROM user_sequences
									 WHERE sequence_name =
										   UPPER('TRSQ_' ||
												 a.Branch_code ||
												 each_product.product_code)))
		LOOP
			lSeqName := 'TRSQ_' || each_branch.Branch_code || each_product.product_code;
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			EXECUTE IMMEDIATE ('CREATE SEQUENCE ' || lSeqname ||
							  ' INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER');
		END LOOP;
	end loop;
	

	for each_product in (select product_code
							from cltms_product
							WHERE once_auth = 'Y' 
							AND record_stat = 'O'
							)
	loop							
		FOR each_branch IN (SELECT branch_code
							  FROM sttm_branch a
							 WHERE once_auth = 'Y' AND
								   record_stat = 'O' AND NOT EXISTS
							 (SELECT 1
									  FROM user_sequences
									 WHERE sequence_name =
										   UPPER('TRSQ_' ||
												 a.Branch_code ||
												 each_product.product_code || '_SIM')))
		LOOP
			lSeqName := 'TRSQ_' || each_branch.Branch_code || each_product.product_code || '_SIM';
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			EXECUTE IMMEDIATE ('CREATE SEQUENCE ' || lSeqname ||
							  ' INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER');
		END LOOP;
	end loop;
end;
/
--CREATE SEQUENCE TRSQ_ESTR170 INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER
--CREATE SEQUENCE TRSQ_IRRZTRF INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER 