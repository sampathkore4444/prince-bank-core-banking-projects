DECLARE
p_error_code VARCHAR2(1000);
p_error_param VARCHAR2(1000);
p_rec_account clpkss_object.ty_rec_account;

BEGIN
          --Fetch the account_master record
global.pr_init('BKV','SAN');
           IF NOT CLPKSS_OBJECT.fn_create_acct_object('BKVILBP05001A3SZ',
                                                       'BKV',
                                                       p_rec_account,
                                                       p_error_code,
                                                       p_error_param)
           THEN
               DEBUG.PR_DEBUG('CL','fn_create_acct_object process failed');
           END IF;


	  if not clpks_yacr.fn_compute_irr( p_rec_account ,
                         p_rec_account.ACCOUNT_DET.value_date,
                         p_error_code,
                         p_error_param)
	THEN
               DEBUG.PR_DEBUG('CL','fn_create_acct_object process failed');
           END IF;

END;
/

