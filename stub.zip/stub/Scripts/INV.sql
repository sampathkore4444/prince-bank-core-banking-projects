set head off
set pause off
set feedback off
spool d:\inv1.sql
select 'ALTER '|| decode (object_type, 'PACKAGE BODY', 'PACKAGE',object_type)
        || ' ' || object_name|| ' ' ||
    decode (object_type, 'PACKAGE BODY', 'COMPILE BODY;','COMPILE;')
from user_objects
where
STATUS  = 'INVALID'
order by  object_type desc
/
spool off
set feedback on
set pause off 
set head on	