DECLARE
            p_err_code                    varchar2(255);
            p_err_param                  varchar2(255);
            
            CURSOR cr_account_ude
            IS
  	    SELECT * 
            FROM CLTB_ACCOUNT_UDE_VALUES A
            WHERE RATE_CODE IS NOT NULL
            AND EXISTS (SELECT 1 FROM CLTB_ACCOUNT_MASTER WHERE ACCOUNT_NUMBER=A.ACCOUNT_NUMBER AND BRANCH_CODE = A.BRANCH_CODE AND ACCOUNT_STATUS='A')
            ORDER BY BRANCH_CODE,ACCOUNT_NUMBER,EFFECTIVE_DATE;
            
						CURSOR cur_cache_rates(p_rate_code CFTMS_RATE_CODE.RATE_CODE%type
																			,p_tenor NUMBER
																			,p_from_date DATE
																			,p_account_rec CLTBS_ACCOUNT_MASTER%ROWTYPE
																			)
						 IS
						SELECT  a.EFFECTIVE_DATE
									,a.INT_RATE
									 		 FROM CFTMS_FLOAT_RATE_DETAIL a, CFTMS_FLOAT_RATE_MASTER b, CFTMS_RATE_CODE c
											 WHERE c.branch_code = p_account_rec.branch_code
										 and c.rate_code = p_rate_code
										 and c.record_stat ='O'
										 and c.once_auth ='Y'
										 and b.branch_code = c.branch_code
										 and b.rate_code = c.rate_code

										and b.ccy_code = p_account_rec.currency
										 and p_account_rec.AMOUNT_FINANCED > b.prev_amount_slab
										 and p_account_rec.AMOUNT_FINANCED <= b.amount_slab
										 --and b.effective_date >= p_from_date
										 and b.effective_date <= p_account_rec.maturity_date
										 and b.borrow_lend_ind ='L'
										 and a.branch_code = c.branch_code
										 and a.rate_code = c.rate_code
										 and a.ccy_code = b.ccy_code
										 and a.amount_slab = b.amount_slab
										 and a.effective_date = b.effective_date
										 and p_tenor >= a.tenor_from
										 and p_tenor <= a.tenor_to
										 and a.borrow_lend_ind = b.borrow_lend_ind
										 order by EFFECTIVE_DATE;       
            
            l_account_rec		CLTBS_ACCOUNT_MASTER%ROWTYPE;
						l_tb_effective_date     DBMS_SQL.Date_Table;
						l_tb_int_rate           DBMS_SQL.Number_Table;       
						L_TENOR      NUMBER := 0;
						l_days_basis VARCHAR2(1);
						l_year_basis VARCHAR2(1);			
						l_hsh_eff_dt PLS_INTEGER;
						TYPE ty_rec_rates IS RECORD( eff_date CFTMS_FLOAT_RATE_MASTER.EFFECTIVE_DATE%type,
																					 rate    CFTMS_RATE_CODE.RATE_CODE%type);						
						TYPE  ty_tb_rates  IS TABLE OF ty_rec_rates index by PLS_INTEGER ;
      			TYPE ty_rec_rate_code IS RECORD(rate_code CFTMS_RATE_CODE.RATE_CODE%type,
                                     g_tb_rates ty_tb_rates);						
						TYPE  ty_tb_rate_codes  IS TABLE OF ty_rec_rate_code index by CFTMS_RATE_CODE.RATE_CODE%type  ;
						l_tb_rate_codes ty_tb_rate_codes;
						L_UDE_VAL_IDX      	PLS_INTEGER;            
						L_CACHE_DT_IDX      PLS_INTEGER;
						l_rate_code					CFTMS_RATE_CODE.RATE_CODE%type;
						l_resolved_value		CLTBS_ACCOUNT_UDE_VALUES.RESOLVED_VALUE%TYPE;
						l_calc_resolved_value		CLTBS_ACCOUNT_UDE_VALUES.RESOLVED_VALUE%TYPE;
BEGIN
            global.pr_init('001', 'BKV');
            clpkss_batch.g_commit_freq := 1000;
						DEBUG.PR_DEBUG('CL','Account Number					Effective Date			UDE_ID			Rate Code			Resolved Value			Computed Resolved Value');            
            FOR REC IN cr_account_ude
            LOOP
                        debug.pr_debug('CL','rec.account_number'||rec.account_number);
            		l_account_rec := clpks_cache.fn_account_master(rec.account_number,rec.branch_code);
								IF (NOT CLPKSS_UTIL.fn_get_ccy_int_method(l_account_rec.CURRENCY,
																													l_days_basis,
																													l_year_basis))
								THEN
										DEBUG.PR_DEBUG('CL','Failed in call to CLPKSS_UTIL.fn_get_ccy_int_method');
										l_tb_rate_codes.DELETE;--kadhir delete added
										l_tb_effective_date.DELETE;
										l_tb_int_rate.DELETE;										
										RETURN ;
								END IF;            		
								IF (NOT CLPKSS_UTIL.fn_get_date_diff(l_account_rec.VALUE_DATE,
																									 l_account_rec.MATURITY_DATE,
																									 l_days_basis,
																									 l_tenor))
								THEN
									DEBUG.PR_DEBUG('CL','Failed in call to CLPKSS_UTIL.fn_get_date_diff');
									l_tb_rate_codes.DELETE;--kadhir delete added
									l_tb_effective_date.DELETE;
									l_tb_int_rate.DELETE;									
									RETURN ;
								END IF;    
								
								IF cur_cache_rates%ISOPEN
								THEN
									close cur_cache_rates;
								END IF;

								l_rate_code := rec.Rate_code;
								debug.pr_debug('CL','l_tenor'||l_tenor);
								OPEN cur_cache_rates(rec.Rate_code, l_tenor,rec.effective_date,l_account_rec);            		
								FETCH cur_cache_rates BULK COLLECT INTO l_tb_effective_date,l_tb_int_rate limit 1000 ;
								l_resolved_value := rec.RESOLVED_VALUE;
								IF l_tb_effective_date.COUNT > 0
								THEN
									FOR i IN l_tb_effective_date.FIRST..l_tb_effective_date.LAST
									LOOP
										l_hsh_eff_dt := clpkss_util.fn_hash_date(l_tb_effective_date(i)) ;
										l_tb_rate_codes(l_rate_code).g_tb_rates(l_hsh_eff_dt).eff_date  := l_tb_effective_date(i);
										l_tb_rate_codes(l_rate_code).g_tb_rates(l_hsh_eff_dt).rate      := l_tb_int_rate(i);
									END LOOP;
									l_cache_dt_idx :=0;
									l_ude_val_idx := clpkss_util.fn_hash_date(rec.effective_date) ;
									l_cache_dt_idx := l_ude_val_idx;
									IF NOT l_tb_rate_codes(l_rate_code).g_tb_rates.exists(l_cache_dt_idx)
									THEN
											IF l_tb_rate_codes(l_rate_code).g_tb_rates.prior(l_cache_dt_idx) IS NULL
											THEN
													debug.pr_debug('CL','Im in if');
													l_calc_resolved_value := nvl(rec.ude_value,0);
											ELSE 
													debug.pr_debug('CL','Im in Else');
													l_cache_dt_idx := l_tb_rate_codes(l_rate_code).g_tb_rates.PRIOR(l_cache_dt_idx);
													l_calc_resolved_value := l_tb_rate_codes(l_rate_code).g_tb_rates(l_cache_dt_idx).RATE +nvl(rec.ude_value,0);
											END IF;
											
									ELSE 
											l_calc_resolved_value := l_tb_rate_codes(l_rate_code).g_tb_rates(l_cache_dt_idx).rate +nvl(rec.ude_value,0);
									END IF ;	
									IF NVL(l_calc_resolved_value,0) <> NVL(l_resolved_value,0)
									THEN
										debug.pr_debug('CL',rec.account_number||'				'||rec.effective_date||'			'||rec.ude_id||'			'||rec.Rate_code||'			'||l_resolved_value||'			'||l_calc_resolved_value); 
									END IF;
								END IF; 	
            END LOOP;
            l_tb_rate_codes.DELETE;
            l_tb_effective_date.DELETE;
            l_tb_int_rate.DELETE;
exception
            when others then
                        DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
												l_tb_rate_codes.DELETE;
												l_tb_effective_date.DELETE;
												l_tb_int_rate.DELETE;                        
end;
/