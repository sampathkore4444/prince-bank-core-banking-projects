disc
--conn clmtr1/mtr2@bprom
--conn fccuser/sprite@fccho
conn clmtr1/mtr2@bprom
set serverout on size 100000
declare
	p_err_code   ertbs_msgs.err_code%type;
	p_err_param  ertbs_msgs.message%type;
begin

	global.pr_init('HOB', 'MONTOYA');
	
	for each_rec in (select policy_code from cltm_policy where once_auth = 'Y')
	loop
		if not pkg_cldpolmt.fn_create_policy_rule( each_rec.policy_code, p_err_code,p_err_param)
		then
		  dbms_output.put_line('error ' || p_err_code);
		end if;
	end loop;
	
	if not pkg_cldpolmt.fn_create_policy_shell(p_err_code,p_err_param ) then
		dbms_output.put_line('error ' || p_err_code);
		dbms_output.put_line('error ' || p_err_param);  
	end if;
end;
/
