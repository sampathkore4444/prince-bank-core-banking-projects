declare
	p_err_code   ertbs_msgs.err_code%type;
	p_err_param  ertbs_msgs.message%type;
	p_acc		 VARCHAR2(35) := 'SANGOOD072220015';
begin
	global.pr_init('JOB', 'SANTOSH');
	IF NOT  clpks_batch.fn_process('JOB',
									'B',
									1,
									p_err_code,
									p_err_param
								 )
	THEN
		DBMS_OUTPUT.PUT_LINE('Error with error'||p_err_code);			
	END IF;
end;
/
