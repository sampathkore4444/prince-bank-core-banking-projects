disc
conn clitr1/pepsi@bprom

set serverout on size 100000

spoo D:\Hand.sql
declare
	p_err_code		varchar2(255);
	p_err_param		varchar2(255);
	l_acc_no		varchar2(35):='CHORAK1001851028';
begin
	global.pr_init('PAN', 'PANKAJ');

	clpkss_batch.g_commit_freq := 1000;
	
	if not clpkss_batch.fn_process('PAN'--p_branch_code
								 ,'T'--p_eoc_group
								 ,1--p_process_no
								 ,p_err_code
								 ,p_err_param
								 ,l_acc_no
								 )
	THEN
		DBMS_OUTPUT.PUT_LINE('Failure ' || p_err_param);
	ELSE
		DBMS_OUTPUT.PUT_LINE('Success ');
	END IF;
	
	commit;
exception
	when others then
		DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
end;
/
spoo off;
