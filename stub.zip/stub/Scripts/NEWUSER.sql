
declare 
  abc varchar2(20);
  l_pwd0	varchar2(100);
  l_pwd1	varchar2(100);
begin

  abc := upper('&userid');
  l_pwd0 := upper('&password');

  INSERT INTO SMTB_USER ( USER_ID, START_DATE, USER_NAME, USER_PASSWORD, TILL_ALLOWED
, ACCLASS_ALLOWED, PRODUCTS_ALLOWED, BRANCHES_ALLOWED, LAST_SIGNED_ON, TIME_LEVEL
, USER_CATEGORY, USER_STATUS, PWD_CHANGED_ON, NO_CUMULATIVE_LOGINS, NO_SUCCESSIVE_LOGINS
, FORCE_PASSWD_CHANGE, USER_LANGUAGE, HOME_BRANCH, GL_ALLOWED, MAKER_ID, MAKER_DT_STAMP
, CHECKER_ID, CHECKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, AUTH_STAT, RESET_PASSWORD
, ENCRYPTION_MODE, DEPARTMENTS_ALLOWED, HOME_DEPARTMENT, APPLY_GAAP_RESTRICTION ) VALUES ( 
abc,  TO_Date( '04/04/2004 12:00:00 AM', 'MM/DD/YYYY HH:MI:SS AM'), abc
, l_pwd0,'D', 'D', 'D', 'D',  TO_Date( '04/04/2004 09:30:12 AM', 'MM/DD/YYYY HH:MI:SS AM')
, 9, 'S', 'E',  TO_Date( '04/04/2004 09:28:27 AM', 'MM/DD/YYYY HH:MI:SS AM'), 0, 0
, 1, 'ENG', 'HOB', 'D', 'USER2',  TO_Date( '04/04/2004 09:27:23 AM', 'MM/DD/YYYY HH:MI:SS AM')
, 'USER3',  TO_Date( '04/04/2004 09:28
53 AM', 'MM/DD/YYYY HH:MI:SS AM'), 1, 'Y', 'O'
, 'A', 'Y', 'O', 'D', 'DEP', 'N');

l_pwd1 := smpkss.fn_encrypt_app_password(nvl(l_pwd0,'PASSWORD'),abc) ;
dbms_output.put_line(l_pwd1||' is pwd');
IF l_pwd1 is not null then	
UPDATE SMTB_USER SET USER_PASSWORD = l_pwd1 where user_id = abc;
END IF;

UPDATE SMTB_USER SET FORCE_PASSWD_CHANGE = 0 where user_id = abc;

UPDATE SMTB_USER_REG SET PARAM_VALUE = '\\Ip-bpd-01\VERCON\SOFT\FLEXCUBE_LATAM\LATAM6.3\LATAM_HOST_6.3_UL\fmx;\\Ip-bpd-01\VERCON\SOFT\FLEXCUBE_LATAM\FCLATAM6.2 Consol\LATAM_HOST\fmx;\\pluto\temp\IQA\FMX;' WHERE USER_ID = abc AND PARAM_NAME= 'FORMS60_PATH';

UPDATE SMTB_USER_REG SET PARAM_VALUE = upper('&TID') WHERE USER_ID = abc AND PARAM_NAME= 'TERMINALID';

commit;
dbms_output.put_line('user::'||abc||' created');
exception
when others then
rollback;
dbms_output.put_line('user::'||abc||' not created'||'::'||sqlerrm);
end;
/

