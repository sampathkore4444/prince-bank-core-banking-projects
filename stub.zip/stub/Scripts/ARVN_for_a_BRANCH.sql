DECLARE
	p_err_code          VARCHAR2(255);
	p_err_param         VARCHAR2(255);
	p_acc_number		VARCHAR2(35) := '001PW32072500001';
BEGIN
	global.pr_init('001', 'BP0ANTA');
	clpkss_batch.g_commit_freq := 1000;

	UPDATE CLTMS_EFFECTED_RATES 
	SET RATE_RECORD_STATUS = 'C'
	WHERE branch_code = '001'
	AND RATE_CODE = 'POOL_HUF' 
	AND CCY_CODE='HUF'
	AND AMOUNT_SLAB=99999999999
	AND EFFECTIVE_DATE='05-NOV-2007' 
	AND BORROW_LEND_IND='L';

	IF NOT clpks_revn.fn_arvn_for_account(p_acc_number,
										  '001',
										  p_err_code,
										  p_err_param
										 )
	THEN
		dbms_output.put_line('Failure ' ||p_err_code||' : '||p_err_param);
	ELSE
		dbms_output.put_line('Success');
	END IF;

	IF NOT clpks_revn.fn_proc_revision_for_account('001'
													p_acc_number,
													'05-Nov-2007',
													p_err_code,
													p_err_param
												  )
	THEN
		dbms_output.put_line('Failure ' ||p_err_code||' : '||p_err_param);
	ELSE
		dbms_output.put_line('Success ');
	END IF;

EXCEPTION
    WHEN OTHERS 
	THEN
		DBMS_OUTPUT.PUT_LINE('Error ' ||SQLERRM);
END;
/

@D:\CLACC
ROLLBACK;
