SELECT * FROM cltb_text_desc WHERE lang_code <> 'ENG'

UPDATE cltb_text_desc SET lang_code='HUN'  WHERE lang_code = 'ENG'

SELECT * FROM cstb_amount_tag WHERE language_code <> 'ENG'

UPDATE cstb_amount_tag SET language_code='HUN'  WHERE language_code = 'ENG'

SELECT * FROM ertb_msgs WHERE language<> 'ENG'

UPDATE ertb_msgs SET language='HUN'  WHERE language = 'ENG'

SELECT * FROM smtb_function_description WHERE lang_code<>'ENG'

UPDATE smtb_function_description SET lang_code='HUN'  WHERE lang_code = 'ENG' AND function_id <>'CLSACCDT'

SELECT * FROM mstm_adv_format
SELECT * FROM mstm_adv_format_det
SELECT * FROM mstm_adv_format_det
SELECT * FROM mstm_adv_format
SELECT * FROM smtb_function_description

SELECT * FROM smtb_user WHERE user_id='SAN' FOR UPDATE

SELECT * FROM smtb_user_reg WHERE user_id='SAN' FOR UPDATE

SELECT * FROM smtb_menu