/*************************************************************************************************
**  This source is part of the FLEXCUBE-Corporate Banking Software System
**  and is copyrighted by i-flex solutions limited.
**  All rights reserved.  No part of this work may be reproduced,
**  stored in a retrieval system, adopted or transmitted in any form or
**  by any means, electronic, mechanical, photographic, graphic,
**  optic recording or otherwise, translated in any language or
**  computer language, without the prior written permission of
**  i-flex solutions limited.
**
**  i-flex solutions limited.
**  10-11, SDF I, SEEPZ, Andheri (East),
**  MUMBAI - 400 096.
**  INDIA
**
**  Copyright (c) 1997 - 2004 by
**  i-flex solutions limited.
**
**    	Log Number          : 1
**    	Modified By         : A.Prasanna Kumar
**    	Modified On         : 30-Dec-2004
**    	Modified Reason     : Against SFR#001. IT FCCCL 1.0. 9NT252. Install Script.
****************************************************************************************************/

declare
	lseqname			varchar2(30);
	lseqcnt				integer;
begin
	global.pr_init('000', 'SYSTEM');
	
	for each_product in (select product_code
							from cltms_product
							WHERE once_auth = 'Y' 
							AND record_stat = 'O'
							)
	loop							
		FOR each_branch IN (SELECT branch_code
							  FROM sttm_branch a
							 WHERE once_auth = 'Y' AND
								   record_stat = 'O' AND NOT EXISTS
							 (SELECT 1
									  FROM user_sequences
									 WHERE sequence_name =
										   UPPER('TRSQ_' ||
												 a.Branch_code ||
												 each_product.product_code)))
		LOOP
			lSeqName := 'TRSQ_' || each_branch.Branch_code || each_product.product_code;
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			EXECUTE IMMEDIATE ('CREATE SEQUENCE ' || lSeqname ||
							  ' INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER');
		END LOOP;
	end loop;
	

	for each_product in (select product_code
							from cltms_product
							WHERE once_auth = 'Y' 
							AND record_stat = 'O'
							)
	loop							
		FOR each_branch IN (SELECT branch_code
							  FROM sttm_branch a
							 WHERE once_auth = 'Y' AND
								   record_stat = 'O' AND NOT EXISTS
							 (SELECT 1
									  FROM user_sequences
									 WHERE sequence_name =
										   UPPER('TRSQ_' ||
												 a.Branch_code ||
												 each_product.product_code || '_SIM')))
		LOOP
			lSeqName := 'TRSQ_' || each_branch.Branch_code || each_product.product_code || '_SIM';
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			EXECUTE IMMEDIATE ('CREATE SEQUENCE ' || lSeqname ||
							  ' INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE ORDER');
		END LOOP;
	end loop;
	
	for each_branch in (select branch_code
							from cltm_branch_parameters
							WHERE once_auth = 'Y' 
							AND record_stat = 'O'
						)
	loop
		FOR each_rec IN (SELECT *
					   FROM cstbs_process a
					  WHERE module = 'CL' AND NOT EXISTS
					  (SELECT 1
							   FROM user_sequences
							  WHERE sequence_name =
									UPPER('TRSQ_' || each_branch.branch_code ||
										  a.process_code)))
		LOOP

			lseqname := 'TRSQ_' || each_branch.branch_code || each_rec.process_code;
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			
			EXECUTE IMMEDIATE ('create sequence ' || lseqname ||
							  ' increment by 1 start with 1000 nomaxvalue nocycle order ');
		END LOOP;	
		
		
		SELECT COUNT(*)
		  INTO lseqcnt
		  FROM user_sequences
		 WHERE sequence_name = UPPER('TRSQ_' || each_branch.branch_code || 'ZLRS');

		IF lseqcnt = 0
		THEN
			lseqname := 'TRSQ_' || each_branch.branch_code || 'ZLRS';
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			
			EXECUTE IMMEDIATE ('create sequence ' || lseqname ||
							  ' increment by 1 start with 1000 nomaxvalue nocycle order ');
		END IF;
		
		SELECT COUNT(*)
		  INTO lseqcnt
		  FROM user_sequences
		 WHERE sequence_name = UPPER('TRSQ_' || each_branch.branch_code || 'ZLRS_SIM');

		IF lseqcnt = 0
		THEN
			lseqname := 'TRSQ_' || each_branch.branch_code || 'ZLRS_SIM';
			debug.pr_debug('CL','SEQ NAME IS ' || LSEQNAME);
			
			EXECUTE IMMEDIATE ('create sequence ' || lseqname ||
							  ' increment by 1 start with 1000 nomaxvalue nocycle order ');
		END IF;
		
		
	end loop;
	
end;
/
