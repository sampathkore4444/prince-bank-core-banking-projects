declare
  res Boolean;
  p_errcode varchar2(11);  
  p_errmsg  varchar2(255);

  TYPE t_rec IS RECORD (                
      p_format       VARCHAR2(100),
      p_xmlname      VARCHAR2(100)
      );
  
  TYPE t_list IS TABLE OF t_rec index by binary_integer;
  l_list t_list;
begin

    l_list(1).p_format   := 'CL_BILL_ADVC' ;            l_list(1).p_xmlname   := 'BILNOTC';
    l_list(2).p_format   := 'CL_TAX_ADVICE' ;           l_list(2).p_xmlname   := 'TAX_ADVICE';
    l_list(3).p_format   := 'CL_ROLL_ADV' ;             l_list(3).p_xmlname   := 'CL_ROLL_ADV';
    l_list(4).p_format   := 'CL_AMD_ADV' ;              l_list(4).p_xmlname   := 'CLAMDADV';
    l_list(5).p_format   := 'CL_INT_STMT' ;             l_list(5).p_xmlname   := 'CL_INT_STMT';
    l_list(6).p_format   := 'CL_DELQ_ADV' ;             l_list(6).p_xmlname   := 'DELINQYADV';
    l_list(7).p_format   := 'CL_LOAN_SUMMARY' ;    		l_list(7).p_xmlname   := 'CLST_SUMMARY';
    l_list(8).p_format   := 'CL_LOAN_DETAIL' ;         	l_list(8).p_xmlname   := 'CLST_DETAILED';
    l_list(9).p_format   := 'CL_CONTR_STMT' ;          	l_list(9).p_xmlname   := 'CL_CONT_ADV';
    l_list(10).p_format  := 'CL_RTCH_ADV' ;             l_list(10).p_xmlname  := 'RATECH_ADV';
    l_list(11).p_format  := 'CL_CAP_ADV' ;              l_list(11).p_xmlname  := 'CL_CAP';
    l_list(12).p_format  := 'CL_PSIM_ADV' ;             l_list(12).p_xmlname  := 'CL_PAY_SIM';
    l_list(13).p_format  := 'CL_PMT_ADV' ;              l_list(13).p_xmlname  := 'PAYMENT_ADVICE';
    l_list(14).p_format  := 'CL_ACC_SIM_ADV' ;      	l_list(14).p_xmlname  := 'CL_ENQUIRY';
    l_list(15).p_format  := 'CL_INIT_ADV' ;             l_list(15).p_xmlname  := 'CL_INIT_ADV';
    l_list(16).p_format  := 'CL_CR_ADV' ;               l_list(16).p_xmlname  := 'CR_ADV';
    l_list(17).p_format  := 'CL_DR_ADV' ;               l_list(17).p_xmlname  := 'DR_ADV';
    l_list(18).p_format  := 'ADV_COUPON' ;            	l_list(18).p_xmlname  := 'COUPON';

    global.pr_init('CHO', 'SANTOSH');
    
    FOR  i IN l_list.FIRST..l_list.LAST
    LOOP
     res := MSPKS_ADV_GEN.FN_GENERATE_FORMAT_PROC(l_list(i).p_format,l_list(i).p_xmlname, 'ENG', p_errcode,p_errmsg);
     if NOT res then                                                                                                                                                                                                                                                                                                                                                                        
          Dbms_Output.put_line(' ------> --------------------------------------------------------');                                                                        
          Dbms_Output.put_line(' ------> '||l_list(i).p_format||' ---> COMPILATION FAILED !!!! ');
          Dbms_Output.put_line(' ------> Error code is <'||TO_CHAR(p_errcode)||'>');
          Dbms_Output.put_line(' ------> Error message is <'||p_errmsg||'>');
          Dbms_Output.put_line(' ------> --------------------------------------------------------');                                                                        
     ELSE
          Dbms_Output.put_line(l_list(i).p_format||'  -> Compiled Successfully !! ');
     end if;     

   END LOOP;

end; 
/