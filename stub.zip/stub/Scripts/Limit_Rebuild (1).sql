
declare
            p_err_code   			ertbs_msgs.err_code%type;
            p_err_param  			ertbs_msgs.message%type;
            l_rec_account    	cltbs_account_master%ROWTYPE;
            l_account_number	cltbs_account_master.account_number%type := '001LLC1072701066';					--Account number is required.
            l_branch_code			cltbs_account_master.branch_code%type := '001';									--Branch Code need to be given
            l_total_recd			cltbs_account_master.AMOUNT_DISBURSED%TYPE;
            l_total_paid			CLTBS_AMOUNT_PAID.AMOUNT_PAID%TYPE;
begin	
	global.pr_init('001', 'SYSTEM');
	
	l_rec_account := clpks_cache.fn_account_master(l_account_number,l_branch_code);

	DELETE FROM lmtbs_line_utils u
	WHERE  u.ref_no = l_account_number AND amt_tag = 'PRINCIPAL';
	
	BEGIN
		SELECT SUM(AMOUNT_RECD) INTO l_total_recd
		FROM CLTBS_AMOUNT_RECD
		WHERE ACCOUNT_NUMBER=l_account_number 
		AND BRANCH_CODE	= l_branch_code
		AND COMPONENT_NAME ='PRINCIPAL';		
	EXCEPTION
		WHEN OTHERS THEN
			l_total_recd := 0;					
	END;	
	debug.pr_debug('CL','Total Disbursed Amount :- '||l_total_recd);
	debug.pr_debug('CL','Entering clpkss_util.fn_update_utilization 1');
	IF NOT clpkss_util.fn_update_utilization(l_rec_account,
																					'I',
																					l_total_recd,
																					p_err_code,
																					p_err_param)
	THEN
		 debug.pr_debug('CL','failed in clpkss_util.fn_update_utilization');
		 RETURN;
	END IF;
	debug.pr_debug('CL','After clpkss_util.fn_update_utilization.');
	BEGIN
		SELECT SUM(AMOUNT_PAID) INTO l_total_paid
		FROM CLTBS_AMOUNT_PAID
		WHERE ACCOUNT_NUMBER=l_account_number 
		AND BRANCH_CODE	= l_branch_code
		AND COMPONENT_NAME ='PRINCIPAL';		
	EXCEPTION
		WHEN OTHERS THEN
			debug.pr_debug('CL','In When Others.');
			l_total_paid := 0;					
	END;
	debug.pr_debug('CL','Total Paid amount :- '||NVL(l_total_paid,0));
        debug.pr_debug('CL','Entering clpkss_util.fn_update_utilization 2');
	IF NVL(l_total_paid,0) > 0 then
	IF NOT clpkss_util.fn_update_utilization(l_rec_account,
																					'D',
																					NVL(l_total_paid,0),	
																					p_err_code,
																					p_err_param)
	THEN
		 debug.pr_debug('CL','failed in clpkss_util.fn_update_utilization');
		 RETURN;
	END IF;
	end if;
	COMMIT;
exception
	when others then
				debug.pr_debug('CL','Error ' || substr(sqlerrm, 1, 255));
end;
/