accept CRN PROMPT 'Enter the CL Account No ==> '
accept BRN PROMPT 'Enter the Branch ==> '
declare
				p_account 				varchar2(35);
				p_branch   				varchar2(3);            
				p_error_code 			ertbs_msgs.err_code%type;
				p_error_param			ertbs_msgs.message%type;
        l_user_id         cltbs_account_events_diary.maker_id%TYPE;
        l_sysdate         DATE;
        l_app_date        DATE;				
        p_tb_event_entries clpkss_element_types.ty_tb_event_entries;
        l_idx_evntent     PLS_INTEGER;
        lEntriesIdx       PLS_INTEGER; 
        p_rec_account     cltbs_account_master%ROWTYPE;
        l_tb_tmp_entries  clpkss_element_types.ty_tb_event_entries;
        lTabFinalEntries  clpkss_element_types.ty_tb_event_entries; 
        l_bv_flag         BOOLEAN := FALSE;
        p_pending_entries 		BOOLEAN := FALSE;
        lAccObj           clpkss_object.ty_rec_account; 
    	TYPE rec_accr_amnt IS RECORD(
                 ACCRUED_AMOUNT cltbs_account_schedules.accrued_amount%TYPE,
                 component_name cltbs_account_schedules.accrued_amount%TYPE);
    	TYPE	tbl_acc_amt IS TABLE OF rec_accr_amnt INDEX BY PLS_INTEGER;
		l_acc_amt tbl_acc_amt;
      	CURSOR cr_accr_amt(p_account varchar2,p_branch varchar2)
	    IS
	      SELECT ACCRUED_AMOUNT,component_name
	        FROM cltb_account_schedules
	       WHERE account_number = p_account
	         AND branch_code    = p_branch
           AND component_name in ('PEN_PRIN')
           AND SCHEDULE_ST_DATE > '01-MAY-2008';
begin
            global.pr_init('001', 'SYSTEM');
            clpkss_batch.g_commit_freq := 1000;
            
						l_user_id  	:= global.USER_ID;
						l_sysdate 	:= global.application_date;
						l_app_date 	:= global.application_date;              
            
            p_account 	:= '&CRN ';
            p_branch 	:= '&BRN';
            p_rec_account := clpks_cache.fn_account_master(p_account,p_branch);
            DEBUG.PR_DEBUG('CL','Building RACR accounting entries for account :- '||p_account);
            IF p_rec_account.account_number IS NOT NULL
            THEN
              IF cr_accr_amt%ISOPEN
              THEN
                  CLOSE cr_accr_amt;
              END IF;
              OPEN cr_accr_amt(p_account,p_branch);
              FETCH cr_accr_amt BULK COLLECT INTO l_acc_amt;
              CLOSE cr_accr_amt;
              FOR zz IN l_acc_amt.FIRST .. l_acc_amt.LAST
	      LOOP
              IF NVL(l_acc_amt(zz).ACCRUED_AMOUNT,0) > 0 and l_acc_amt(zz).component_name='PEN_PRIN'
              THEN              
								DEBUG.PR_DEBUG('CL','Building RACR accounting entries for account :- '||p_account);
								INSERT INTO CLTB_ACCOUNT_EVENTS_DIARY 
													(ACCOUNT_NUMBER, 
													BRANCH_CODE, 
													COMPONENT_NAME, 							
													EVENT_CODE, 
													EXECUTION_DATE, 
													EXECUTION_STATUS, 
													MAKER_ID, 
													MAKER_DT_STAMP, 
													CHECKER_ID, 
													CHECKER_DT_STAMP, 
													EVENT_SEQ_NO, 
													EVENT_DATE, 
													CONTRACT_STATUS, 
													AUTH_STATUS, 
													PROCESS_NO, 
													CUTOFF_STATUS, 
													CUTOFF_ESN, 
													VERSION_NO, 
													INTERFACE_ID, 
													LAST_ACCR_DT)
								VALUES (p_account, 
												p_branch, 
												'PEN_PRIN', 
												'RACR', 
												l_sysdate, 
												'P', 
												l_user_id, 
												l_sysdate, 
												l_user_id, 
												l_sysdate, 
												p_rec_account.latest_esn+1, 
												l_sysdate, 
												'A', 
												'A',
												1,
												null, 
												null, 
												p_rec_account.version_no, 
												null, 
												null);

								l_idx_evntent := NVL(p_tb_event_entries.COUNT, 0) + 1;
								p_tb_event_entries(l_idx_evntent) .branch_code    		:= p_rec_account.branch_code;
								p_tb_event_entries(l_idx_evntent) .account_number 		:= p_rec_account.account_number;
								p_tb_event_entries(l_idx_evntent) .event_code     		:= 'RACR';
								p_tb_event_entries(l_idx_evntent) .value_date     		:= l_sysdate;
								p_tb_event_entries(l_idx_evntent) .amount         		:= l_acc_amt(zz).ACCRUED_AMOUNT;
								p_tb_event_entries(l_idx_evntent) .amount_exp    			:= l_acc_amt(zz).ACCRUED_AMOUNT;
								p_tb_event_entries(l_idx_evntent) .amount_odue  			:= 0; 
								p_tb_event_entries(l_idx_evntent) .incr_decr_flag 		:= 'I'; 
								p_tb_event_entries(l_idx_evntent) .lcy_updated 				:= 'N';
								p_tb_event_entries(l_idx_evntent) .amount_tag     		:= 'PEN_PRIN_RACR';
								p_tb_event_entries(l_idx_evntent) .ccy            		:= 'MKD';
								p_tb_event_entries(l_idx_evntent) .entry_passed   		:= 'N';
								p_tb_event_entries(l_idx_evntent) .event_seq_no   		:= p_rec_account.latest_esn + 1;
								p_tb_event_entries(l_idx_evntent) .process_no     		:= p_rec_account.process_no;
								p_tb_event_entries(l_idx_evntent) .schedule_due_date  := l_sysdate;
								p_tb_event_entries(l_idx_evntent) .component_name     := 'PEN_PRIN';

								UPDATE cltbs_account_master						
								SET latest_esn = latest_esn + 1
								WHERE account_number = p_account
								AND branch_code	=p_branch;
								DEBUG.PR_DEBUG('CL','Going to Clear Account Object');
								IF NOT clpkss_object.fn_clear_acc_object (lAccObj, p_error_code, p_error_param)
								THEN
										DEBUG.PR_DEBUG('CL','Failed in call to clear obj ::' || p_error_code);
										rollback;
								END IF;
								DEBUG.PR_DEBUG('CL','Going to Create account object');

								IF NOT CLPKSS_OBJECT.fn_create_acct_object(p_rec_account.account_number, p_rec_account.branch_code, lAccObj, p_error_code, p_error_param)
								THEN
										rollback;
								END IF;						


								FOR zz IN p_tb_event_entries.FIRST .. p_tb_event_entries.LAST
								LOOP
										l_tb_tmp_entries.DELETE;
										l_tb_tmp_entries(1) := p_tb_event_entries(zz);
										IF NOT clpkss_accounting.fn_frame_event_entries(lAccObj,
																																		'RACR',
																																		NULL,
																																		l_tb_tmp_entries,
																																		p_error_code,
																																		p_error_param)
										THEN
												DEBUG.PR_DEBUG('CL','Failed in frame event entries ::' || p_error_code);
												ROLLBACK;
										ELSE
												DEBUG.PR_DEBUG('CL','In Else part of after calling clpkss_accounting.fn_frame_event_entries ');
												lEntriesIdx := lTabFinalEntries.COUNT;
												IF l_tb_tmp_entries.count > 0 then
													FOR I IN l_tb_tmp_entries.FIRST .. l_tb_tmp_entries.LAST
													LOOP
														lEntriesIdx := lEntriesIdx + 1;
														lTabFinalEntries(lEntriesIdx) := l_tb_tmp_entries(I);
													END LOOP;
													l_tb_tmp_entries.DELETE;
												END IF;
										END IF;
								END LOOP;

								IF NVL(lTabFinalEntries.COUNT, 0) > 0  
								THEN
											IF NOT clpkss_accounting.fn_store_event_entries(
																							lTabFinalEntries,
																							'B',
																							p_error_code,
																							p_error_param)
											THEN
													DEBUG.PR_DEBUG('CL','Failed in store event entries ::' || p_error_code);
													ROLLBACK;
											END IF;
											DEBUG.PR_DEBUG('CL','Trhu with store event entries !!!');
											DEBUG.PR_DEBUG('CL','Calling clpkss_accounting.fn_accounting_for_branch...');
											p_pending_entries := TRUE;  
											l_bv_flag := TRUE;
											IF NOT clpkss_accounting.fn_accounting_for_loanac(p_branch,p_account,
																																				 l_app_date,
																																				 p_error_code,
																																				 p_error_param,
																																				 l_bv_flag)
											THEN
												 DEBUG.PR_DEBUG('CL','clpkss_accounting.fn_accounting_for_branch failed with :-(' || p_error_code || p_error_param);
												 p_pending_entries := FALSE;
											END IF;
											p_pending_entries := FALSE; 
											l_bv_flag 				:= FALSE;
								END IF;
  					END IF;
						p_tb_event_entries.DELETE;
						lTabFinalEntries.DELETE;
						l_tb_tmp_entries.DELETE;
						DEBUG.PR_DEBUG('CL','Accounting entries of account '||p_account ||' is over');		
 						
exception
when others then
	dbms_output.put_line('aliq failed with '||sqlerrm);
end;
/
commit;