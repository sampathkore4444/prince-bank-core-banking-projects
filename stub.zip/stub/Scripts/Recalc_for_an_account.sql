DECLARE
	p_err_code     VARCHAR2(255);
	p_err_param    VARCHAR2(255);
BEGIN
	global.pr_init('000', 'SYSTEM');
	clpkss_batch.g_commit_freq := 1000;

	UPDATE cltb_account_master 
	SET calc_reqd = 'Y',
		recalc_action_code = 'E'
	WHERE branch_code = '000'
	AND account_number = '000RP5108200F2ZB';

	IF NOT clpkss_recalc.fn_recalc_for_an_account('000RP5108200F2ZB',
												   '000',
												   TO_DATE('21-JUL-2008','DD-MM-RRRR'),
												   p_err_code,
												   p_err_param
												 )
	THEN
		dbms_output.put_line('Failure ' || p_err_param);
	ELSE
		dbms_output.put_line('Success ');
	END IF;

EXCEPTION
	WHEN OTHERS 
	THEN
		DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
END;
/
commit;
