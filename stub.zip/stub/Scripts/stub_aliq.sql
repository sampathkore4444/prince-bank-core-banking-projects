declare
	p_account varchar2(35) := '101CONS081120018';
	p_branch   varchar2(3) := '101';
	PErr varchar2(100);
	PPrm  varchar2(255);
begin
	global.pr_init('101', 'SYSTEM');

	clpkss_batch.g_commit_freq := 1000;
	
	if not clpkss_liqd.fn_aliq_for_an_account( p_account,
                    		p_branch,
                    		'20-MAY-2008',
                    		pErr,
                    		pPrm)
    then
    	dbms_output.put_line('ALIQ failed with '||pErr);
    else
    	dbms_output.put_line('ALIQ successful');
    end if;
   IF NOT clpkss_accounting.fn_accounting_for_loanac(p_branch,
            												p_account,
	                                                       '20-MAY-2008',
	                                                       pErr,
	                                                       pPrm)
	THEN
			ROLLBACK;
	         	dbms_output.put_line('clpkss_accounting.fn_accounting_for_branch failed with :-(' || PErr || PPrm);
	        
	ELSE
			dbms_output.put_line('Completed successfully');
    END IF; 
    commit;
exception
when others then
dbms_output.put_line('Dsbr failed with '||sqlerrm);
end;
/