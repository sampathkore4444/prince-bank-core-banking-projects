SET TRIMSPOOL ON
SET PAGES 1000
SET LINESIZE 100000
SET HEAD OFF
spool c:\drop.sql
select 'Drop ' || object_type || ' ' || object_name || decode(object_type, 'TABLE', ' cascade constraints;',';')
from user_objects
where object_type  in ('PACKAGE', 'PACKAGE BODY', 'TABLE', 'VIEW', 'SEQUENCE', 'DATABASE LINK','PROCEDURE', 'FUNCTION', 'SYNONYM','TYPE','LIBRARY','INDEX','TABLE PARTITION')
/
spool off


