declare

            p_err_code   ertbs_msgs.err_code%type;

            p_err_param  ertbs_msgs.message%type;

begin

 

            global.pr_init('001', 'SAN');
 
       
   
        /***
            for each_rec in (select product_code from cltm_product where  PRODUCT_CODE='HSL1' AND once_auth='Y')

            loop

                        dbms_output.put_line('inside for the product');

                        if not clpkss_prd_rulegen.fn_create_rules(each_rec.product_code , p_err_code,p_err_param )

                        then

                          dbms_output.put_line('error ' || p_err_code);

                          dbms_output.put_line('error ' || p_err_param);  

                        end if;

            end loop;
  
 ***/ 

     

       
            if not clpkss_prd_rulegen.fn_create_shell( p_err_code)

            then

              dbms_output.put_line('error ' || p_err_code);

            end if;
       
        

end;

/