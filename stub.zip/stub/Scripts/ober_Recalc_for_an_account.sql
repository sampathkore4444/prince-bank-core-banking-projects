declare
            p_err_code                    varchar2(255);
            p_err_param                  varchar2(255);
begin
            global.pr_init('001', 'IFLEXAUTH');
            clpkss_batch.g_commit_freq := 1000;
            
            DELETE FROM CLTB_ACCOUNT_UDE_EFF_DATES
            WHERE ACCOUNT_NUMBER='001PW32072500001'
            AND BRANCH_CODE='001'
            AND EFFECTIVE_DATE='05-NOV-2007';
            
            DELETE FROM CLTB_ACCOUNT_UDE_VALUES
            WHERE ACCOUNT_NUMBER='001PW32072500001'
            AND BRANCH_CODE='001'
            AND UDE_ID='INTEREST_RATE'
            AND EFFECTIVE_DATE='05-NOV-2007';        
            
            INSERT INTO CLTB_ACCOUNT_UDE_EFF_DATES
            VALUES('001PW32072500001','001','24-OCT-2007');
            
            
            INSERT INTO CLTB_ACCOUNT_UDE_VALUES
            VALUES('001PW32072500001','001','24-OCT-2007','INTEREST_RATE',1,'POOL_HUF','A','R',8.5);
            
            INSERT INTO CLTB_CALC_DATES
            VALUES('001PW32072500001','001','E','24-OCT-2007',1,NULL);
            
            UPDATE CLTB_ACCOUNT_MASTER 
            SET CALC_REQD = 'Y'
            , RECALC_ACTION_CODE = 'E'
            WHERE BRANCH_CODE = '001' AND ACCOUNT_NUMBER = '001PW32072500001';
            
            if not clpkss_recalc.fn_recalc_for_an_account('001PW32072500001'
							, '001'
							, '24-OCT-2007'
							, p_err_code
							, p_err_param
							)
            THEN
                        dbms_output.put_line('failure ' || p_err_param);
            ELSE
                        dbms_output.put_line('success ');
            END IF;
exception
            when others then
                        DBMS_OUTPUT.PUT_LINE('Error ' || substr(sqlerrm, 1, 255));
end;
/
@D:\CLACC
ROLLBACK;

