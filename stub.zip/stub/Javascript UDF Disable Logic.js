fnInTab_TAB_UDF_KERNEL{

document.getElementById("BLK_UDF_DETAILS_VIEW__FLDVAL10").disabled = true;

return true;
    


fnInTab_TAB_UDF_CUSTOM{

document.getElementById("BLK_UDF_DETAILS_VIEW__FLDVAL10").disabled = true;

return true;
    
}