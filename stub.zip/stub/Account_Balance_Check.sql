DECLARE
  P_BRANCH   VARCHAR2(100) := '102';
  P_ACCOUNT  VARCHAR2(100) := '000049647';
  L_AVL_BAL  NUMBER;
  P_LIM_FLAG CHAR(1) := 'N';
BEGIN
  GLOBAL.PR_INIT('102','SAMPATH1');
  IF NOT ACPKS_MISC.FN_GETAVLBAL(P_BRANCH, P_ACCOUNT, L_AVL_BAL, P_LIM_FLAG) THEN
    DBMS_OUTPUT.PUT_LINE('Failed in the call to fn_getavlbal');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Amount ' ||
                         ' blocked avl balance after fn_getavlba=l' ||
                         L_AVL_BAL);
  END IF;
END;