CREATE OR REPLACE PROCEDURE PR_PROCESS_NOTIFICATIONS_ARCHIVAL AS

  l_commit_interval NUMBER := 10000; -- Number of records to process before committing
  l_counter         NUMBER := 0; -- Counter to keep track of processed records

BEGIN

  SAVEPOINT INITIAL_POINT;

  FOR G IN (SELECT *
              FROM STTB_TRAN_DTLS_DIGITAL A
             WHERE A.AUTH_TIMESTAMP <= SYSTIMESTAMP - INTERVAL '7' DAY) LOOP
  
    INSERT INTO STTB_TRAN_DTLS_DIGITAL_HIST VALUES G;
  
    DELETE FROM STTB_TRAN_DTLS_DIGITAL A
     WHERE A.AUTH_TIMESTAMP <= SYSTIMESTAMP - INTERVAL '7' DAY;
  
    l_counter := l_counter + 1;
  
    -- Commit after processing the specified number of records
    IF l_counter >= l_commit_interval THEN
    
      COMMIT;
    
      l_counter := 0; -- Reset the counter after committing
    
    END IF;
  
  END LOOP;

  -- Commit any remaining records
  IF l_counter > 0 THEN
    COMMIT;
  END IF;
  
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK TO INITIAL_POINT;
    DEBUG.PR_DEBUG('AC', 'FAILED IN MOVING=' || SQLERRM);
END;
