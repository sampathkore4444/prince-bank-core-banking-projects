DECLARE
  P_BRANCH      VARCHAR2(100) := '100';
  P_USER_ID     VARCHAR2(100) := 'FLEXSWITCH';
  P_SOURCE      VARCHAR2(100) := 'FLEXSWITCH';
  P_CHANNEL     VARCHAR2(100) := 'ATM';
  P_ISO_MESSAGE VARCHAR2(32567) := '~0200~1000000000000000~971000~000000002000~~~0828085928~~~~471462~183401~0315~~0828~~0828~6011~~~~~~~~~~~~~~123451~~~~~000071115351~~~~A0000078~ABOA           ~14,EkReach,KPT                          ~~~~~~840~~~~~~~~~~~ATM_REFILL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~791078~~TranCode:97,TranID:71115228,PAN:10000000*****0000,Account:,OrigTime:15-MAR-18,OrigAmount:2000Currenc~~~~~~~~~~~~~~~~~~~~~~~~';
  P_ERR_CODE    VARCHAR2(100);
  P_ERR_PARAM   VARCHAR2(100);

BEGIN
  gwpks_createswtransaction.PR_MSG_HANDLER(P_BRANCH,
                                           P_USER_ID,
                                           P_SOURCE,
                                           P_CHANNEL,
                                           P_ISO_MESSAGE,
                                           P_ERR_CODE,
                                           P_ERR_PARAM);
  DBMS_OUTPUT.PUT_LINE('ERROR CODE=' || P_ERR_CODE);
  DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE=' || P_ERR_PARAM);
END;