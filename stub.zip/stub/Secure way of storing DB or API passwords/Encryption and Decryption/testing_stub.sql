--Generate the key
select DBMS_CRYPTO.RANDOMBYTES(32) from dual; --8273CC9AF1DB2277C2CC848FC8281B9A7C4E93CC070D374004DD611A6C69EE81

--Encrypt Function
CREATE OR REPLACE FUNCTION encrypt_password(p_password VARCHAR2) RETURN RAW IS
  encrypted_data RAW(2000);
BEGIN
  encrypted_data := DBMS_CRYPTO.ENCRYPT(src => UTL_I18N.STRING_TO_RAW(p_password,
                                                                      'AL32UTF8'),
                                        typ => DBMS_CRYPTO.ENCRYPT_AES256 +
                                               DBMS_CRYPTO.CHAIN_CBC +
                                               DBMS_CRYPTO.PAD_PKCS5,
                                        key => '8273CC9AF1DB2277C2CC848FC8281B9A7C4E93CC070D374004DD611A6C69EE81' --Use a secure method to provide the key here
                                        );
  RETURN encrypted_data;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR CODE='||SQLCODE);
    DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE='||SQLERRM);
END encrypt_password;

--Decrypt Function
CREATE OR REPLACE FUNCTION decrypt_password(p_encrypted_data RAW)
  RETURN VARCHAR2 IS
  decrypted_data VARCHAR2(2000);
BEGIN
  decrypted_data := UTL_I18N.RAW_TO_CHAR(DBMS_CRYPTO.DECRYPT(src => p_encrypted_data,
                                                             typ => DBMS_CRYPTO.ENCRYPT_AES256 +
                                                                    DBMS_CRYPTO.CHAIN_CBC +
                                                                    DBMS_CRYPTO.PAD_PKCS5,
                                                             key => '8273CC9AF1DB2277C2CC848FC8281B9A7C4E93CC070D374004DD611A6C69EE81' -- Use a secure method to provide the key here
                                                             ),
                                         'AL32UTF8');
  RETURN decrypted_data;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR CODE=' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE=' || SQLERRM);
END decrypt_password;


--Get the encrypted password
SELECT encrypt_password('SVADMIN') from dual;  --6E20C77E42C2E819AD00C47B9F26E09E


--Get the decrypted password
SELECT decrypt_password('6E20C77E42C2E819AD00C47B9F26E09E') from dual;  --SVADMIN

