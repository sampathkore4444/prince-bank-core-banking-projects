declare
 clear_text varchar2(50) := 'svwiadmin';
begin
  dbms_output.put_line( 'Hashed value of ' || clear_text || ' is: ' || bcrypt_encrypt(p_string => clear_text));
end;

-- Hashed value of 3257890141PassA@ is: $2a$05$C9YTmsiZ7pHbxWJiK3TrT.HgcaJzGP90jdmL27diB31PoKKk14YCq

declare
 clear_text varchar2(50) := 'svwiadmin';
 hashed_value varchar2(100) := '$2a$05$C9YTmsiZ7pHbxWJiK3TrT.HgcaJzGP90jdmL27diB31PoKKk14YCq';
 compair_result boolean := false;
begin
 compair_result := bcrypt_matches(p_string => clear_text, '$2a$05$C9YTmsiZ7pHbxWJiK3TrT.HgcaJzGP90jdmL27diB31PoKKk14YCq');
 if compair_result = true then
  dbms_output.put_line('Matched Successfully');
  else
    dbms_output.put_line('Un_Matched !!');
  end if;
end;

-- Matched Successfully

select * from cstb_param_custom where param_name like '%PGW_SMART_VISTA%';