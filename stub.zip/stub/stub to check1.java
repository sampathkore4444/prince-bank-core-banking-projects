import java.io.IOException;
import java.nio.file.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class LogFileMonitor {

    public static void main(String[] args) throws IOException, InterruptedException {
        Path logFilePath = Paths.get("path/to/file.log");

        WatchService watchService = FileSystems.getDefault().newWatchService();
        logFilePath.getParent().register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

        while (true) {
            WatchKey key;
            try {
                key = watchService.take();
            } catch (InterruptedException ex) {
                return;
            }

            for (WatchEvent<?> event : key.pollEvents()) {
                WatchEvent.Kind<?> kind = event.kind();

                if (kind == StandardWatchEventKinds.OVERFLOW) {
                    continue;
                }

                WatchEvent<Path> pathEvent = (WatchEvent<Path>) event;
                Path modifiedFilePath = pathEvent.context();

                if (modifiedFilePath.endsWith(logFilePath.getFileName())) {
                    checkForErrors(logFilePath);
                }
            }

            boolean reset = key.reset();
            if (!reset) {
                break;
            }
        }
    }

    public static void checkForErrors(Path logFilePath) throws IOException {
        Files.lines(logFilePath)
                .filter(line -> line.contains("Error"))
                .forEach(errorLine -> sendEmail("recipient@example.com", errorLine));
    }

    public static void sendEmail(String recipient, String errorLine) {
        // Set up mail server and properties
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host", "smtp.mailserver.com");

        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties);

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress("your-email@example.com"));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));

            // Set Subject: header field
            message.setSubject("Error Found in Log File");

            // Now set the actual message
            message.setText("Error found in log file: " + errorLine);

            // Send message
            Transport.send(message);
            System.out.println("Email sent successfully...");

        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }
}


Please replace "your-email@example.com" and "smtp.mailserver.com" with your email address and your SMTP server details.
⠀⠀
This code will send an email to the specified recipient email address each time it finds a line in the log file containing the word "Error".