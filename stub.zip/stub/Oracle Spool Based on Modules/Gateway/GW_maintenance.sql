set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set trimspool on
set colsep ';'
set numformat 9999999999999999.999

SPOOL GW_maintenance.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'GW_MAINTENANCE'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT


PROMPT gwtb_parameters
select * from gwtb_parameters;

PROMPT gwtms_ext_sys_master;
select * from gwtms_ext_sys_master;

PROMPT gwtm_ext_sys_queues
select * from gwtm_ext_sys_queues;

PROMPT gwtm_ext_sys_functions
select * from gwtm_ext_sys_functions;

PROMPT gwtm_gateway_functions
select * from gwtm_gateway_functions;

PROMPT gwtm_fcj_functions
select * from gwtm_fcj_functions;

PROMPT gwtm_services_master
select * from gwtm_services_master;

PROMPT gwtm_ftp_parameter
select * from gwtm_ftp_parameter;

PROMPT gwtm_notif_installed
select * from gwtm_notif_installed;

PROMPT gwtm_24x7avail_operations
select * from gwtm_24x7avail_operations;

PROMPT gwtm_operations_master
select * from gwtm_operations_master;

PROMPT gwtm_ext_communicators
select * from gwtm_ext_communicators;

PROMPT gwtm_notification_tag_map
select * from gwtm_notification_tag_map;

PROMPT gwtm_notifications_master
select * from gwtm_notifications_master;

PROMPT gwtm_notifications_enroute
select * from gwtm_notifications_enroute;

PROMPT gwtm_notification_triggers
select * from gwtm_notification_triggers;

PROMPT gwtm_node_fld_map
select * from gwtm_node_fld_map;

PROMPT gwtm_mt_task_initiation
select * from gwtm_mt_task_initiation;

PROMPT gwtm_sepa_operation_master
select * from gwtm_sepa_operation_master;

PROMPT gwtm_standard_xml
select * from gwtm_standard_xml;

PROMPT gwtb_poss_param
select * from gwtb_poss_param;


set echo off
spool off
