Accept uid prompt 'Please enter the User Id (Case Sensitive)=> '

set head on
set array 1
set linesize 10000
set pagesize 50000
set colsep ';'
set long 10000
set echo on
set trimspool on

SPOOL SM_user_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'SM_USER_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

select * from smtb_user where user_id = '&uid';

select * from smtb_browser_functions where user_id = '&uid';

select * from smtb_users_functions where user_id = '&uid';

select * from smtb_user_branches where user_id = '&uid';

select * from smtb_user_func_disallow where user_id = '&uid';

select * from smtb_user_role where user_id = '&uid';

select * from smtb_role_master where role_id in (select role_id from smtb_user_role where user_id = '&uid');

select * from smtb_role_detail where role_id in (select role_id from smtb_user_role where user_id = '&uid');

select * from smtb_user_products where user_id = '&uid';

select * from smvws_user_products where user_id = '&uid';

select * from smtb_msgs_rights where user_role_id = '&uid';

select * from smtb_msgs_rights where user_role_id in (select role_id from smtb_user_role where user_id = '&uid');

select * from SMTB_USER_LM_TILLS  where user_id = '&UID';

prompt Maintenance
prompt 
promt SMTB_DASHBOARD_DETAILS
select * from SMTB_DASHBOARD_DETAILS where user_id = '&uid';

prompt SMTB_DASHBOARD_MASTER
select * from SMTB_DASHBOARD_MASTER;

prompt SMTB_DUPLICATE_FIELDS
select * from SMTB_DUPLICATE_FIELDS;


set echo off
spool off