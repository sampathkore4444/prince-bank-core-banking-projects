SET LINE 1000
SET ECHO ON
SET TRIMSPOOL ON
SET HEAD ON
SET PAGESIZE 10000
set line 999
set serveroutput on

accept l_class prompt    'Enter Class :' 
accept l_entity prompt   'Enter External Entity :' 
accept l_account prompt  'Enter External Account :' 
accept l_currency prompt 'Enter Currency :' 

SPOOL RE_account_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'RE_ACCOUNT_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

prompt RETBS_EXTERNAL_ENTRY
SELECT * FROM RETBS_EXTERNAL_ENTRY
where RECON_CLASS      = '&l_class' AND
EXTERNAL_ENTITY        = '&l_entity' AND
EXTERNAL_ACCOUNT       = '&l_account' AND
CURRENCY               = '&l_currency' 
/

prompt RETBS_EXTERNAL_STATEMENT
SELECT * FROM RETBS_EXTERNAL_STATEMENT
where RECON_CLASS      = '&l_class' AND
EXTERNAL_ENTITY        = '&l_entity' AND
EXTERNAL_ACCOUNT       = '&l_account' AND
CURRENCY               = '&l_currency'  
/

prompt RETBS_EXTACC_RECON_INFO 
SELECT * FROM RETBS_EXTACC_RECON_INFO 
where RECON_CLASS      = '&l_class' AND
EXTERNAL_ENTITY        = '&l_entity' AND
EXTERNAL_ACCOUNT       = '&l_account' AND
CURRENCY               = '&l_currency' 
/

prompt RETBS_EXTERNAL_ENTRY
SELECT * FROM RETBS_MATCH_EXTERNAL_ENTRY A,RETBS_EXTERNAL_ENTRY B
WHERE  A.INTERNAL_REF_NO = B.INTERNAL_REF_NO
AND    A.EXTERNAL_REF_NO = B.EXTERNAL_REF_NO
AND    A.ENTRY_SEQ_NO    = B.ENTRY_SEQ_NO
And    b.RECON_CLASS     = '&l_class' 
AND    b.EXTERNAL_ENTITY = '&l_entity' 
AND    b.EXTERNAL_ACCOUNT = '&l_account' 
AND    b.CURRENCY         = '&l_currency' 
/


SET ECHO OFF
SPOOL OFF
