ACCEPT PREF_NO PROMPT 'Enter the payment reference no -> ' 

SET LINE 1000
SET HEAD ON
SET ECHO ON
SET TRIMSPOOL ON
SET FEEDBACK 1

SPOOL UP_payment_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'UP_PAYMENT_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

SELECT * FROM uptbs_ptxn_log WHERE cod_reference_no = UPPER('&PREF_NO');

SELECT * FROM CSTBS_CONTRACT_INFO WHERE CONTRACT_REF_NO= UPPER('&PREF_NO');

SELECT * FROM ACVW_ALL_AC_ENTRIES WHERE TRN_REF_NO = UPPER('&PREF_NO');

SELECT * FROM ACVWS_STMT_COLS WHERE MODULE_CODE='UP' ;

SET ECHO OFF
SPOOL OFF
