/*  ILM script */
accept Acc_no PROMPT 'Enter the account number ==> '

set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set trimspool on
set colsep ';'
set numformat 9999999999999999.99

SPOOL ILM_account_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'ILM_ACCOUNT_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

column SHORT_NAME noprint
column address1 noprint
column address2 noprint
column address3 noprint
column address4 noprint
column ADDR1 noprint
column ADDR2  noprint
column PASSPORT_NO  noprint
column address_line1 noprint
column address_line2 noprint
column address_line3 noprint
column address_line4 noprint
column SHORT_NAME2  noprint
column customer_name1 noprint 
column FULL_NAME noprint
column CUST_NAME1 noprint
column UNIQUE_ID_VALUE noprint
column BENEF_NAME  noprint
column BENFNAME   noprint
column AC_GL_DESC NoPrint
column SWIFT_CODE NoPrint
column AC_DESC NoPrint
column CHECKBOOK_NAME_1 NoPrint
column CHECKBOOK_NAME_2 NoPrint


column Brn_code new_value Brn_code
/
select BRANCH_CODE Brn_code from sttm_cust_account where cust_ac_no='&Acc_no'
/
column currency new_value currency
/
select ccy currency from sttm_cust_account where branch_code = '&Brn_code' and cust_ac_no='&Acc_no'
/
column Ac_class new_value Ac_class
/
select account_class Ac_class from sttm_cust_account where branch_code = '&Brn_code' and cust_ac_no='&Acc_no'
/
column Cust_id new_value Cust_id
/
select Cust_no Cust_id from sttm_cust_account where branch_code = '&Brn_code' and cust_ac_no='&Acc_no'
/
select * from CYTMS_CUST_SPREAD_MASTER where CUSTOMER = '&Cust_id';
select * from CYTM_CUST_SPREAD_DETAILS where CUSTOMER = '&Cust_id';
Select * from ICTM_PR_INT_EFFDT where BRANCH_CODE ='&Brn_code' and ACLASS = '&Ac_class' and product_code IN (select distinct prod from ictbs_acc_pr where brn ='&Brn_code' and acc = '&Acc_no')
order by product_code;
select * from ICTMS_PR_INT_UDEVALS where BRANCH_CODE ='&Brn_code' and ACLASS = '&Ac_class' and product_code IN (select distinct prod from ictbs_acc_pr where brn ='&Brn_code' and acc = '&Acc_no')
order by product_code;
select * from ICVW_UDE_ICDUDVAL 
where aclass = '&Ac_class' 
and product_code IN (select distinct prod from ictbs_acc_pr where brn ='&Brn_code' and acc = '&Acc_no')
order by product_code;

PROMPT 'ALL RULES LINKED TO THE ACCOUNT'

SELECT * FROM ictms_rule WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C')
);

SELECT * FROM ictms_rule_frm WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&Ac_class'
   and a.ccy ='&currency'
   and a.record_stat <> 'C') ) order by rule_id, frm_no;

select * from ictm_expr where rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C')) order by rule_id, frm_no, expr_line;


SELECT * FROM ictms_rule_frm_elements WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy =  '&currency'
   and a.record_stat <> 'C'));

SELECT * FROM ictms_rule_sde WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass ='&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'));

SELECT * FROM ictms_rule_ude WHERE rule_id IN (select RULE from ictms_pr_int
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'));

Prompt 'INTEREST PROD DETAILS'

prompt ictms_pr_int
select * from ictms_pr_int 
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
order by product_code
;

prompt ictbs_pr_int_aclass
select * from ictms_pr_int_aclass 
where product_code IN (select product_code
  from ictm_pr_int_aclass a
 where a.aclass ='&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by product_code
;
prompt pr_int_effdt
select * from ICTMS_PR_INT_EFFDT where product_code in ( select product_code
  from ictm_pr_int_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'
)
;
prompt ictms_pr_int_udevals
select * from ictms_pr_int_udevals where product_code in (select product_code
  from ictm_pr_int_aclass a
 where a.aclass =  '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) 
;
Prompt 'CHARGE PROD DETAILS'
prompt ictms_pr_chg
select * from ictms_pr_chg where product_code  IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
) ;
Prompt ICTM_PR_CHG_ACLASS
select A.*
  from ictm_pr_chg_aclass a
 where a.aclass ='&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
order by product_code
;
prompt ICTM_PR_CHG_CONSOL
select * from ICTM_PR_CHG_CONSOL
where prod IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by prod ;
prompt ICTM_PR_CHG_SLAB
select * from ICTM_PR_CHG_SLAB
where product_code IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy = '&currency'
   and a.record_stat <> 'C'
)
order by product_code
;
prompt ICTM_PR_CHG_TXN
select * from ICTM_PR_CHG_TXN
where prod IN (
select product_code
  from ictm_pr_chg_aclass a
 where a.aclass = '&Ac_class'
   and a.ccy ='&currency'
   and a.record_stat <> 'C'
)
order by prod
;
select * from STTMS_CUSTOMER  where CUSTOMER_no = '&Cust_id';
select * from sttm_cust_account where cust_ac_no = '&Acc_no';
select * from ACTB_VD_BAL where acc = '&Acc_no';	
select * from sttms_account_class where account_class = '&Ac_class';
select * from ILTM_BRANCH_PARAMETERS where branch_code = '&Brn_code';
select g.* from ILTM_GROUP_CODE g where  g.GROUP_CODE  in (select l.GROUP_CODE from ILTM_GROUP_ACCOUNT_LINK l where l.branch_code in (select m.BRANCH_CODE from  ILTM_MIRROR_ACCOUNT m where m.CUST_AC_NO = '&Acc_no'));

column grp_code new_value grp_code
/
select GROUP_CODE grp_code from ILTB_SYS_ACCOUNT  where BRANCH_CODE = '&Brn_code' and ACCOUNT = '&Acc_no'; 
/
column grp_code_brn new_value grp_code_brn
/
select GROUP_CODE_BRN grp_code_brn from ILTB_SYS_ACCOUNT  where BRANCH_CODE = '&Brn_code' and ACCOUNT = '&Acc_no'; 
select * from  ILTB_GROUP_BVT where BRANCH_CODE = '&grp_code_brn' and GROUP_CODE = '&grp_code';
select * from  ILTB_GROUP_BVT_QUEUE where BRANCH_CODE = '&grp_code_brn' and GROUP_CODE = '&grp_code';
select * from  ILTB_GROUP_QUEUE where BRANCH_CODE = '&grp_code_brn' and GROUP_CODE = '&grp_code';
select * from  ILTM_MIRROR_ACCOUNT where CUST_AC_NO = '&Acc_no';
 Prompt 'ILTM_ACCOUNT'
Select * from ILTM_ACCOUNT where BRANCH_CODE = '&Brn_code' and ACCOUNT = '&Acc_no';
 Prompt 'ILTB_SYS_ACCOUNT'
select * from ILTB_ENTRIES where BRN = '&Brn_code' and ACC = '&Acc_no';
select l.* from ILTM_GROUP_ACCOUNT_LINK l where  l.branch_code in (select m.BRANCH_CODE from  ILTM_MIRROR_ACCOUNT m where m.CUST_AC_NO = '&Acc_no');
Prompt 'IL VD DETAILS'
select * from ILTB_VD_BALANCES where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
select * from ILTB_VD_CONTRIBUTIONS where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
select * from ILTB_VD_POOL_BALANCES where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
Prompt 'IL BD DETAILS'
select * from ILTB_BD_BALANCES where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
select * from ILTB_BD_CONTRIBUTIONS where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
select * from ILTB_BD_POOL_BALANCES where system_account_branch = '&Brn_code' and system_account = '&Acc_no';
Prompt 'ILTB_ENTRIES'
select * from ILTB_ENTRIES where brn = '&Brn_code' and acc = '&Acc_no';
prompt acvw_all_ac_entries
select * from acvws_all_ac_entries where ac_branch='&Brn_code' and '&Acc_no' in (ac_no,related_account)
order by ac_entry_sr_no;

select * from ILTB_BATCH_DETAILS;

set echo off
spool off 