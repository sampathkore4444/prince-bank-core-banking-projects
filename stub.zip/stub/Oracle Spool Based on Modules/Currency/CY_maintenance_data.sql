accept BRN PROMPT 'Pls enter the Branch Code ==> '
accept CCY PROMPT 'Pls enter the Currency Code ==> '

set array 1024
set head on
set feedback on
set line 32767
set pagesize 32767
set long 32767
set colsep ";"
set trimspool on
set verify on
set feedback on
set numformat 99999999999999999999D999
set termout off
set echo on

define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint

select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

SPOOL CY_maintenance_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'CY_MAINTENANCE_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT


show user;

exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');

exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');

Prompt 'STTM_DATES'
SELECT * FROM STTM_DATES
 WHERE BRANCH_CODE = (select ho_branch from sttm_bank where rownum=1);
prompt 
prompt CYTMS_CCY_DEFN_MASTER
select * from CYTMS_CCY_DEFN_MASTER where ccy_code='&CCY';
prompt
prompt CYTMS_RATE_TYPE
select * from CYTMS_RATE_TYPE;
prompt
prompt CYTMS_RATES_MASTER
select * from CYTMS_RATES_MASTER where branch_code='&BRN' and (ccy1='&CCY' or ccy2='&CCY');
prompt
prompt CYTMS_CCY_PAIR_DEFN_MASTER
select * from CYTMS_CCY_PAIR_DEFN_MASTER where ccy1='&CCY' or ccy2='&CCY' or through_ccy='&CCY'
prompt
prompt CYTMS_RATES
select * from CYTMS_RATES where branch_code='&BRN' and (ccy1='&CCY' or ccy2='&CCY'); 
prompt
prompt CYTMS_CCY_COUNTRY_MAP_MASTER
select * from CYTMS_CCY_COUNTRY_MAP_MASTER where currency_code='&CCY';
prompt
prompt CYTMS_FWDRATE_MASTER
select * from CYTMS_FWDRATE_MASTER where branch='&BRN' and (currency1='&CCY' or currency2='&CCY');
prompt
prompt CYTMS_FWDRATE_DETAILS
select * from CYTMS_FWDRATE_DETAILS where branch='&BRN' and (currency1='&CCY' or currency2='&CCY');
prompt
prompt CYVWS_FWDRATE_FINAL_RATE
select * from CYVWS_FWDRATE_FINAL_RATE where branch='&BRN' and (ccy1='&CCY' or ccy2='&CCY');
prompt
prompt CYTM_CCY_POSITION_GL
select * from CYTM_CCY_POSITION_GL;
prompt
prompt CYTMS_OFFSET_TIME
select * from CYTMS_OFFSET_TIME where branch_code='&BRN' and ccy_code='&CCY';
prompt
prompt CYTB_RATES_HISTORY
select * from CYTB_RATES_HISTORY where branch_code='&BRN' and (ccy1='&CCY' or ccy2='&CCY') and trunc(rate_date)<=trunc(sysdate-365);

set termout on
set echo off

spool off