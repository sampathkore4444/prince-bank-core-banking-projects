accept CRN PROMPT 'Enter the contract reference no ==> '
accept CUSTOMER_NO prompt 'Enter the Customer No ==> '
accept brn prompt 'Enter the branch ====>'
set array 1
set line 5000
set head on
set trimspool on
set pagesize 10000
set feedback on
set echo on

COL CUSTOMER_NAME NoPrint
COL payment_details noprint
COL clause_descr noprint
COL doc_descr noprint
COL doc_reference noprint
COL address1 noprint
col address2 noprint
col address3 noprint
col warehouse_address noprint
col cust_name noprint
col cust_address_lin1 noprint
col cust_address_lin2 noprint
col cust_address_lin3 noprint
col cust_address_lin4 noprint
col tracer_code noprint
Col ADDRESS4 NoPrint

SPOOL MS_contract_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'MS_CONTRACT_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

PROMPT CSTBS_CONTRACT
SELECT * FROM CSTBS_CONTRACT WHERE CONTRACT_REF_NO = UPPER('&CRN');

PROMPT CSTBS_CONTRACT_EVENT_LOG
SELECT * FROM CSTBS_CONTRACT_EVENT_LOG WHERE CONTRACT_REF_NO = UPPER('&CRN');

PROMPT CSTBS_CONTRACT_EVENT_ADVICE
SELECT * FROM CSTBS_CONTRACT_EVENT_ADVICE WHERE CONTRACT_REF_NO = UPPER('&CRN');

PROMPT ISTBS_CONTRACTIS
SELECT * FROM ISTBS_CONTRACTIS WHERE CONTRACT_REF_NO = '&CRN';

PROMPT ISTBS_CONTRACT_DETAILS
SELECT * FROM ISTBS_CONTRACT_DETAILS WHERE CONTRACT_REF_NO = '&CRN';

PROMPT ISTBS_CONTRACTIS_SWIFT
SELECT * FROM ISTBS_CONTRACTIS_SWIFT WHERE CONTRACT_REF_NO = UPPER('&CRN');

PROMPT ISTBS_MSGHO
SELECT * FROM ISTBS_MSGHO WHERE contract_ref_no = '&CRN' ORDER BY EVENT_SEQ_NO, MSG_TYPE, RECEIVER, SERIAL_NO;

SELECT * FROM MSTBS_MSG_HANDOFF WHERE reference_no = '&CRN';

PROMPT MSTBS_DLY_MSG_OUT
SELECT * FROM MSTBS_DLY_MSG_OUT WHERE reference_no = '&CRN'
ORDER BY ESN, MSG_TYPE, RECEIVER, SERIAL_NO;

PROMPT MSTBS_DLY_MSG_IN
SELECT * FROM MSTBS_DLY_MSG_IN WHERE reference_no = '&CRN'
ORDER BY SWIFT_MSG_TYPE, SERIAL_NO;

PROMPT MSTBS_ARCHIVE_OUT
SELECT * FROM mstbs_archive_out where REFERENCE_NO   =UPPER('&CRN');

PROMPT CSTB_CONTRACT_EXCEPTION
SELECT * FROM CSTBS_CONTRACT_EXCEPTION
WHERE CONTRACT_REF_NO = '&CRN';

PROMPT CSTMS_PRODUCT
SELECT * FROM CSTMS_PRODUCT WHERE PRODUCT_CODE = SUBSTR(UPPER('&CRN'),4,4);

PROMPT CSTMS_PRODUCT_EVENT_ADVICE
SELECT * FROM CSTMS_PRODUCT_EVENT_ADVICE
WHERE PRODUCT_CODE = SUBSTR(UPPER('&CRN'),4,4);

PROMPT STTMS_BRANCH
SELECT * FROM STTMS_BRANCH WHERE BRANCH_CODE = UPPER('&BRN');

SPOOL OFF
