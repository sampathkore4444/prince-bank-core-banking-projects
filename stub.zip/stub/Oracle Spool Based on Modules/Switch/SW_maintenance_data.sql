set array 1024
set head on
set feedback on
set line 32767
set pagesize 32767
set long 32767
set colsep ";"
set trimspool on
set verify on
set feedback on
set numformat 99999999999999999999D999
set termout off
set echo on

define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint

select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

SPOOL SW_maintenance_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'SW_MAINTENANCE_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT


show user;

exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');

exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');

Prompt 'STTM_DATES'
SELECT * FROM STTM_DATES
 WHERE BRANCH_CODE = (select ho_branch from sttm_bank where rownum=1);

prompt SWTMS_FCLITERAL_CODE
select * from SWTMS_FCLITERAL_CODE;

prompt SWTB_TXN_SUPPORT_CHANNEL
select * from SWTB_TXN_SUPPORT_CHANNEL;

prompt SWTM_TERMINAL_DETAILS
select * from SWTM_TERMINAL_DETAILS;

prompt SWTMS_NETWORK_DETAILS
select * from SWTMS_NETWORK_DETAILS;

prompt SWTMS_ACQUIRER_DETAILS
select * from SWTMS_ACQUIRER_DETAILS;

prompt SWTMS_ISSUER_DETAILS
select * from SWTMS_ISSUER_DETAILS;

prompt SWTMS_PRODUCT_MAPPING
select * from SWTMS_PRODUCT_MAPPING;

prompt SWTM_CHANNEL
select * from SWTM_CHANNEL;

prompt swtb_param
select * from swtb_param;

prompt SWTB_RESPONSE_MAP
select * from SWTB_RESPONSE_MAP;


set termout on
set echo off

spool off