accept RRN PROMPT 'Enter the Retrieval Reference no ==> '

set array 1024
set head on
set feedback on
set line 32767
set pagesize 32767
set long 32767
set colsep ";"
set trimspool on
set verify on
set feedback on
set numformat 99999999999999999999D999
set termout off
set echo on

define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint

select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

SPOOL SW_transaction_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'SW_TRANSACTION_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT 
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT

show user;

exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');

exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');

Prompt 'STTM_DATES'

SELECT * FROM STTM_DATES
 WHERE BRANCH_CODE = (select ho_branch from sttm_bank where rownum=1);

prompt swtb_txn_log
select * from swtb_txn_log where RRN = '&RRN';

Prompt swtb_retry_log
select * from swtb_retry_log where RRN = '&RRN';

prompt detb_rtl_teller
select xref, 
product_code, 
branch_code, 
trn_ref_no, 
txn_acc, 
txn_ccy, 
txn_amount, 
txn_branch, 
txn_trn_code, 
ofs_acc, 
ofs_ccy, 
ofs_amount, 
ofs_branch, 
ofs_trn_code, 
exch_rate, 
lcy_amount, 
trn_dt, 
value_dt, 
dr_instrument_code, 
cr_instrument_code, 
rel_customer, 
charge_account, 
chg_gl, 
chg_ccy, 
chg_amt, 
chg_in_acy, 
chg_in_lcy, 
chg_ccy_acy_rate, 
acy_lcy_rate, 
netting_ind, 
txn_code, 
mis_head_1, 
chg_gl_1, 
chg_ccy_1, 
chg_amt_1, 
chg_in_acy_1, 
chg_in_lcy_1, 
chg_ccy_acy_rate_1, 
acy_lcy_rate_1, 
netting_ind_1, 
txn_code_1, 
mis_head_2, 
chg_gl_2, 
chg_ccy_2, 
chg_amt_2, 
chg_in_acy_2, 
chg_in_lcy_2, 
chg_ccy_acy_rate_2, 
acy_lcy_rate_2, 
netting_ind_2, 
txn_code_2, 
mis_head_3, 
chg_gl_3, 
chg_ccy_3, 
chg_amt_3, 
chg_in_acy_3, 
chg_in_lcy_3, 
chg_ccy_acy_rate_3, 
acy_lcy_rate_3, 
netting_ind_3, 
txn_code_3, 
mis_head_4, 
chg_gl_4, 
chg_ccy_4, 
chg_amt_4, 
chg_in_acy_4, 
chg_in_lcy_4, 
chg_ccy_acy_rate_4, 
acy_lcy_rate_4, 
netting_ind_4, 
txn_code_4, 
mis_head_5, 
rem_acc, 
rem_bank, 
rem_branch, 
routing_no, 
end_point, 
serial_no, 
record_stat, 
auth_stat, 
maker_id, 
maker_dt_stamp, 
checker_id, 
checker_dt_stamp, 
repair_reason, 
mod_no, 
scode, 
mis_head, 
dr_acc, 
module, 
esn, 
event_code, 
route_code, 
ft_problem, 
track_receivable, 
time_received, 
their_chgs2, 
their_chgs3, 
their_chgs4, 
their_chgs, 
their_chgs1, 
their_acc, 
their_acc1, 
their_acc2, 
their_acc3, 
their_acc4, 
lcy_exch_rate, 
tot_chg_in_tcy, 
chg_desc, 
chg_desc1, 
chg_desc2, 
chg_desc3, 
chg_desc4, 
chg_type, 
chg_type1, 
chg_type2, 
chg_type3, 
chg_type4, 
waiver, 
waiver1, 
waiver2, 
waiver3, 
waiver4, 
lcy_chg_exch_rate, 
lcy_chg_exch_rate1, 
lcy_chg_exch_rate2, 
lcy_chg_exch_rate3, 
lcy_chg_exch_rate4, 
chg_contra_leg, 
netting_reqd, 
service_provider, 
bill_number, 
bill_issue_date, 
consumer_no, 
txn_status, 
cashback_amount, 
txn_tanked, 
instr_date, 
liqn_dt, 
revr_dt, 
fund_id, 
fund_ref_no, 
negotiated_rate, 
negotiation_ref_no, 
sdb_ref_no, 
project_name, 
unit_payment, 
unit_id, 
deposit_slip_no, 
reject_code, 
cheque_issue_date, 
maint_charge_applied, 
chg_dr_leg, 
chg_dr_leg_1, 
chg_dr_leg_2, 
chg_dr_leg_3, 
chg_dr_leg_4, 
token_no, 
denom_varinace, 
org_exch_rate, 
org_amount, 
vir_acc_no, 
net_txn_amt, 
net_ofs_amt, 
comm_mode from detb_rtl_teller where trn_ref_no in (select trn_ref_no from swtb_txn_log where RRN = '&RRN') or  trn_ref_no in (select trn_ref_no from swtb_txn_log where RRN = '&RRN');

prompt actb_daily_log
select * from actb_daily_log where trn_ref_no in (select trn_ref_no from swtb_txn_log where RRN = '&RRN'); 

prompt SWTM_CARD_DETAILS
select * from SWTM_CARD_DETAILS where atm_card_no in (select PAN from swtb_txn_log where RRN = '&RRN');

prompt STTMS_CARD_CUSTOMER
select * from STTMS_CARD_CUSTOMER where customer_id in (select cust_no from sttm_cust_account where cust_ac_no in (select fcc_acc_no from SWTM_CARD_DETAILS where atm_card_no in (select PAN from swtb_txn_log where RRN = '&RRN')));

prompt STTMS_CARD_ACCOUNT
select * from STTMS_CARD_ACCOUNT where cust_ac_no in (select fcc_acc_no from SWTM_CARD_DETAILS where atm_card_no in (select PAN from swtb_txn_log where RRN = '&RRN'));

prompt IFTM_ARC_MAINT
select * from IFTM_ARC_MAINT where cod_prod_acc_cls in 
(select product_code from detb_rtl_teller where trn_ref_no in (select trn_ref_no from swtb_txn_log where RRN = '&RRN') or  trn_ref_no in (select trn_ref_no from swtb_txn_log where RRN = '&RRN'));


set termout on
set echo off

spool off