accept FNCID PROMPT 'Pls enter the FUNCTION ID ==> '

set array 1024
set head on
set feedback on
set line 32767
set pagesize 32767
set long 32767
set colsep ";"
set trimspool on
set verify on
set feedback on
set numformat 99999999999999999999D999
set termout off
set echo on

define lv_ttstamp=date
column ttstamp new_value lv_ttstamp noprint

select to_char(sysdate,'RRRRMMDDHH24MISS') as ttstamp from dual;

SPOOL UD_fields_data.SPL

PROMPT
PROMPT Automation Validation
Prompt ----------------------
select 'UD_FIELDS_DATA'||'_SPOOL' from dual;
Prompt
Prompt Version Information
prompt --------------------
select 'SRDC DOC ID 2549877.1 / Version V1.0 Released on 05-MAY-2020' from dual;
PROMPT
PROMPT Patch Set Version
Prompt ------------------
SELECT * FROM CSTB_PARAM WHERE PARAM_NAME like '%RELEASE%';
PROMPT
PROMPT Product-wise PS Release at Environment
Prompt ---------------------------------------
SELECT * FROM SMTB_MODULES_GROUP;
PROMPT


show user;

exec dbms_session.set_nls('NLS_DATE_FORMAT','''DD/MM/RRRR HH24:MI:SS''');

exec dbms_session.set_nls('NLS_NUMERIC_CHARACTERS','''.,''');

Prompt 'STTM_DATES'
SELECT * FROM STTM_DATES
 WHERE BRANCH_CODE = (select ho_branch from sttm_bank where rownum=1);

Prompt UDTMS_FIELDS
select * from UDTMS_FIELDS where function_id = upper('&FNCID');

prompt UDTMS_LOV
select * from UDTMS_LOV where field_name in (select field_name from UDTMS_FIELDS where function_id = upper('&FNCID'));

prompt CSTMS_FUNC_KEY_MAP_MASTER
select * from CSTMS_FUNC_KEY_MAP_MASTER where function_id = upper('&FNCID');

prompt CSTMS_FUNC_KEY_MAP
select* from CSTMS_FUNC_KEY_MAP where function_id = upper('&FNCID');


set termout on
set echo off

spool off