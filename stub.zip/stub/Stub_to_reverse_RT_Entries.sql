declare
  P_ERR_CODE   varchar2(100);
  P_ERR_PARAM  varchar2(100);
  L_FN_CALL_ID varchar2(100);
begin
  global.pr_init('993', 'SYSTEM');
  savepoint a;
  IF NOT DEPKS_RTL_TELLER.FN_REVERSE('991KHQR20353D3PS',
                                     P_ERR_CODE,
                                     P_ERR_PARAM) THEN
    dbms_output.put_line('Failed inside depks_rtl_teller_cluster.Fn_Save');
    dbms_output.put_line('Rolling back to savepoint rtl reverse');
    ROLLBACK TO a;
  
  ELSE
    
  IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                    '991KHQR20353D3PS',
                                                    GLOBAL.USER_ID,
                                                    GLOBAL.LCY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
          dbms_output.put_line('AUTH RETURNED FALSE ' || P_ERR_CODE);
ELSE
   dbms_output.put_line('REVERSE AUTH DONE');
END IF;  

  END IF;
end;

DECLARE
 P_ERR_CODE   varchar2(100);
  P_ERR_PARAM  varchar2(100);
BEGIN
  Global.pr_init('993', 'SYSTEM');
  savepoint a;

IF NOT DEPKSS_RTL_TELLER.FN_RTL_TELLER_AUTH(GLOBAL.CURRENT_BRANCH,
                                                    '993KHQR220374768',
                                                    GLOBAL.USER_ID,
                                                    GLOBAL.LCY,
                                                    P_ERR_CODE,
                                                    P_ERR_PARAM) THEN
          dbms_output.put_line('AUTH RETURNED FALSE ' || P_ERR_CODE);
END IF;  

END;