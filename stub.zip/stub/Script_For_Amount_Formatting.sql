
DECLARE
L_ROUNDED_AMT VARCHAR2(1000);
begin
global.pr_init('001','SYSTEM');
if cypks.fn_amt_round('USD', '553800', L_ROUNDED_AMT)  then
  dbms_output.put_line('FAILED L_ROUNDED_AMT='||L_ROUNDED_AMT);
else
  
dbms_output.put_line('L_ROUNDED_AMT='||L_ROUNDED_AMT);

end if;

end;

select cypks.CSFN_FORMAT_AMT('USD',20.000) from dual
