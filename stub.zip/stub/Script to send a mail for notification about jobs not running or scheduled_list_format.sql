DECLARE
  mail_conn      utl_smtp.connection;
  L_MAIL_HOST    VARCHAR2(100) := '10.80.81.2';
  L_MAIL_PORT_NO VARCHAR2(100) := 25;
  L_USER_ID      VARCHAR2(100) := 'support.app';
  L_PASSWORD     VARCHAR2(100) := 'PB@123!2020@';

  L_FROM_ADDRESS VARCHAR2(100) := 'kore.sampathkumar@princebank.com.kh';

  L_TO_ADDRESS VARCHAR2(100) := 'kore.sampathkumar@princebank.com.kh';

  L_MAIL_SUBJECT VARCHAR2(100) := 'Alert: Jobs are not running or scheduled!!';

  L_MAIL_TEXT VARCHAR2(32767); --:= 'Job $L_JOB_NAME is down. Please check!!';

  L_START_TEXT VARCHAR2(32767);
  L_TABLEROWCOL_DATA VARCHAR2(32767);
  L_JOB_TEXT   VARCHAR2(32767);
  L_END_TEXT   VARCHAR2(32767);

  CURSOR C1 IS
    SELECT JOB_NAME, TRIGGER_STATE, NEXT_FIRE_TIME, ERROR
      FROM SMVW_JOB_SCHEDULE
     WHERE JOB_NAME IN ('BAKONG_INCOMING_PROCESS',
                        'BAKONG_IN_HANDOFF',
                        'FAST_INCOMING_HANDOFF',
                        'FAST_INCOMING_PROCESS',
                        'PR_PROCESS_AIA_SI_PAYMENTS')
       AND TRIGGER_STATE NOT IN ('LBL_SCHEDULED', 'SCHEDULED');

BEGIN

  --FOR G IN C1 LOOP
  
   -- BEGIN
    
      mail_conn := UTL_smtp.open_connection(L_MAIL_HOST, L_MAIL_PORT_NO);
    
     --DBMS_OUTPUT.PUT_LINE('JOB NAME=' || G.JOB_NAME);
    
      --utl_smtp.starttls(mail_conn);
    
      UTL_SMTP.AUTH(mail_conn, L_USER_ID, L_PASSWORD, schemes => 'PLAIN');
    
      utl_smtp.mail(mail_conn, L_FROM_ADDRESS);
      utl_smtp.rcpt(mail_conn, L_TO_ADDRESS);
    
      UTL_smtp.open_data(mail_conn);
    
      UTL_SMTP.write_data(mail_conn,
                          'Date: ' ||
                          TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') ||
                          UTL_TCP.crlf);
      UTL_SMTP.write_data(mail_conn,
                          'To: ' || L_TO_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(mail_conn,
                          'From: ' || L_FROM_ADDRESS || UTL_TCP.crlf);
      UTL_SMTP.write_data(mail_conn,
                          'Subject: ' || L_MAIL_SUBJECT || UTL_TCP.crlf);
    
      UTL_smtp.write_data(mail_conn,
                          'MIME-Version: ' || '1.0' || UTL_tcp.CRLF);
    
      UTL_smtp.write_data(mail_conn, 'Content-Type: ' || 'text/html;');
    
      UTL_smtp.write_data(mail_conn,
                          'Content-Transfer-Encoding: ' || '"8Bit"' ||
                          UTL_tcp.CRLF);
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF);
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF || '');
    
      L_START_TEXT := '<html><body><div>

<p>Dear CBS Team,</p><p>Good Day!!</p>
<p> This is to inform you that the below jobs are either not running or scheduled. I request you to check and take an action further.</p><ul>';
    
      FOR G IN C1 LOOP
      
        L_JOB_TEXT := L_JOB_TEXT || '<li>' || G.JOB_NAME || '</li>';
      
      END LOOP;
      
  
        
      dbms_output.put_line('L_JOB_TEXT='||L_JOB_TEXT);
    
      L_END_TEXT := '</ul><p>Thank You</p><p>Regards,</p><p>CBS Job Bot</p></div> </body></html>';
    
      L_MAIL_TEXT := L_START_TEXT || L_JOB_TEXT || L_END_TEXT;
    
      DBMS_OUTPUT.PUT_LINE('L_MAIL_TEXT=' || L_MAIL_TEXT);
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF || L_MAIL_TEXT);
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF || '');
    
      UTL_smtp.write_data(mail_conn, UTL_tcp.CRLF || '');
    
      /*     UTL_SMTP.write_data(mail_conn,
                          'Reply-To: ' || L_TO_ADDRESS || UTL_TCP.crlf ||
                          UTL_TCP.crlf);
                          
      UTL_SMTP.write_data(mail_conn,
                          L_MAIL_TEXT || UTL_TCP.crlf || UTL_TCP.crlf);*/
    
      UTL_smtp.close_data(mail_conn);
      UTL_smtp.quit(mail_conn);
  --  EXCEPTION
    --  WHEN OTHERS THEN
     --   CONTINUE;
   -- END;
 -- END LOOP;

EXCEPTION
  WHEN UTL_smtp.transient_error OR UTL_smtp.permanent_error THEN
    UTL_smtp.quit(mail_conn);
    dbms_output.put_line(sqlerrm);
  WHEN OTHERS THEN
    dbms_output.put_line('Error line number=' ||
                         DBMS_UTILITY.format_error_backtrace);
    dbms_output.put_line(sqlerrm);
    UTL_smtp.quit(mail_conn);
    
  
END;
