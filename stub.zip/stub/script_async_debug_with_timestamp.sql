   GLOBAL.PR_INIT(P_TY_ATM_TXN_REC.ORIG_BRANCH_CODE, L_USER_ID);

        --sampath starts
        DEBUG.PR_SET_ASYNC_REF(GLOBAL.USER_ID || '_' ||
                               GLOBAL.CURRENT_BRANCH || '_' ||
                               REPLACE(TO_CHAR(SYSTIMESTAMP, 'HH:MI:SS.FF'),
                                       ':'));
        --sampath ends