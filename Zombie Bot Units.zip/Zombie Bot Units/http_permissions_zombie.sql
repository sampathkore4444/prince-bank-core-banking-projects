begin
dbms_network_acl_admin.create_acl (
acl => 'http_permissions_zombie.xml',
description => 'HTTP Access',
principal => 'P1FCHPRFM',
is_grant => TRUE,
privilege => 'connect',
start_date => null,
end_date => null
);
end;
/
commit;

begin
DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_zombie.xml',
principal => 'P1FCHPRFM',
is_grant => true,
privilege => 'connect');
end;
/
commit;

begin
DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl => 'http_permissions_zombie.xml',
principal => 'P1FCHPRFM',
is_grant => true,
privilege => 'resolve');
end;
/
commit;

BEGIN
dbms_network_acl_admin.assign_acl (
acl => 'http_permissions_zombie.xml',
host => '192.168.1.88', 
lower_port => 25,
upper_port => 25
);
END;