prompt Importing table sttm_job_definition...
set feedback off
set define off
insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('MAIL_ALERT_ZOMBIE_BOT', 'PLSQL', 'Zombie bot to notify if jobs are either stopped or not scheduled', 'SchedulerFactory', 'S', null, 'PLSQL', 'IFPKS_ZOMBIE_BOT_UTILS.PR_MAIL_ALERT_PROCESS', -1, 30.00, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('11-11-2020 22:57:43', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('11-11-2020 22:57:43', 'dd-mm-yyyy hh24:mi:ss'), 3, 'Y', 'O', 'SAMPATH2', 'QUARTZ', 'N', 5, null, 1, 'M');

prompt Done.
