prompt Importing table STTM_JOB_PARAM...
set feedback off
set define off
insert into STTM_JOB_PARAM (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('MAIL_ALERT_ZOMBIE_BOT', 'NAME', 'VARCHAR', 'OFSS');

prompt Done.
