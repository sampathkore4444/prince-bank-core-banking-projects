-- Create table
create table STTM_COLLATERAL_MASTER
(
  customer_no      VARCHAR2(9),
  liability_no     VARCHAR2(9),
  collat_ref_no    VARCHAR2(16),
  id               NUMBER(20),
  customer_name    VARCHAR2(105),
  maker_id         VARCHAR2(12),
  maker_dt_stamp   DATE,
  checker_id       VARCHAR2(12),
  checker_dt_stamp DATE,
  auth_stat        VARCHAR2(1),
  record_stat      VARCHAR2(1),
  once_auth        VARCHAR2(1),
  mod_no           NUMBER(4)
)
/
alter table STTM_COLLATERAL_MASTER add primary key (ID, LIABILITY_NO, CUSTOMER_NO, COLLAT_REF_NO)
/
-- Create table
create table STTM_COLLATERAL_DETAIL
(
  customer_no   VARCHAR2(9),
  liability_no  VARCHAR2(9),
  collat_ref_no VARCHAR2(16),
  id            NUMBER(20),
  reval_date    DATE,
  reval_by      VARCHAR2(105),
  reval_name    VARCHAR2(105),
  reval_amt     NUMBER
)
/
alter table STTM_COLLATERAL_DETAIL add primary key (ID, LIABILITY_NO, CUSTOMER_NO, COLLAT_REF_NO, REVAL_DATE)
/
-- Create table
create table STTB_STATIC_COLLAT_DETAILS
(
  collateral_type VARCHAR2(105),
  issued_by       VARCHAR2(105)
)
/
alter table STTB_STATIC_COLLAT_DETAILS add primary key (COLLATERAL_TYPE, ISSUED_BY)
/