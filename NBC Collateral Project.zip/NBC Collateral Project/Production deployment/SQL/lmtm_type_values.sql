insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('COLLATERAL_REVAL', 'Branch Level', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('COLLATERAL_REVAL', 'External Property Valuer', null);

insert into lmtm_type_values (TYPE, VALUE, CODE)
values ('COLLATERAL_REVAL', 'Internal Property Valuer (IPV)', null);

COMMIT;
