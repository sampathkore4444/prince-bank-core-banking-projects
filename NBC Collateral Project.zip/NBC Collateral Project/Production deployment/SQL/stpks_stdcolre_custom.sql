CREATE OR REPLACE PACKAGE BODY stpks_stdcolre_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcolre_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2024 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcolre_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcolre         IN OUT stpks_stdcolre_Main.ty_stdcolre,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcolre_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  PROCEDURE PR_CLOSE_REVALUATION(P_COLLAT_REF_NO STTM_COLLATERAL_MASTER.COLLAT_REF_NO%TYPE) AS
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    BEGIN
      UPDATE STTM_COLLATERAL_MASTER A
         SET A.RECORD_STAT = 'C',
             A.MAKER_ID    = 'SYSTEM',
             A.CHECKER_ID  = 'SYSTEM'
       WHERE A.COLLAT_REF_NO = P_COLLAT_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED WHILE UPDATING');
    END;
  
    COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in closing the collateral revaluation');
    
  END PR_CLOSE_REVALUATION;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcolre         IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    L_SEQ_NO NUMBER := 1;
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    IF p_Action_Code IN (CSPKS_REQ_GLOBAL.p_New, CSPKS_REQ_GLOBAL.p_Modify) THEN
    
      FOR G IN 1 .. p_stdcolre.v_sttm_collateral_detail.count LOOP
      
        p_stdcolre.v_sttm_collateral_detail(G).ID := L_SEQ_NO;
      
        IF p_stdcolre.v_sttm_collateral_detail(G)
         .REVAL_DATE > GLOBAL.application_date THEN
        
          p_err_code := 'ST-COLR-001';
        
          pr_log_error('STDCOLRE', 'FLEXCUBE', p_err_code, NULL);
        
          RETURN FALSE;
        
        END IF;
      
        /*IF p_stdcolre.v_sttm_collateral_detail(G)
         .REVAL_DATE < GLOBAL.application_date THEN
         
          p_err_code := 'ST-COLR-002';
        
          pr_log_error('STDCOLRE', 'FLEXCUBE', p_err_code, NULL);
        
          RETURN FALSE;
        
        END IF;*/
      
        L_SEQ_NO := L_SEQ_NO + 1;
      
      END LOOP;
    
      FOR G IN 1 .. p_stdcolre.v_sttm_collateral_detail.count LOOP
      
        IF p_stdcolre.v_sttm_collateral_detail(G)
         .REVAL_DATE > GLOBAL.application_date THEN
        
          p_err_code := 'ST-COLR-001';
        
          pr_log_error('STDCOLRE', 'FLEXCUBE', p_err_code, NULL);
        
          RETURN FALSE;
        
        END IF;
      
      END LOOP;
    
    END IF;
  
    DBG('p_stdcolre.v_sttm_collateral_detail.COUNT=' ||
        p_stdcolre.v_sttm_collateral_detail.COUNT);
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcolre         IN stpks_stdcolre_Main.ty_stdcolre,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcolre         IN stpks_stdcolre_Main.ty_stdcolre,
                                       p_Prev_stdcolre    IN OUT stpks_stdcolre_Main.ty_stdcolre,
                                       p_Wrk_stdcolre     IN OUT stpks_stdcolre_Main.ty_stdcolre,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcolre         IN stpks_stdcolre_Main.Ty_stdcolre,
                                        p_Prev_stdcolre    IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                                        p_Wrk_stdcolre     IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcolre         IN stpks_stdcolre_Main.Ty_stdcolre,
                            p_Prev_stdcolre    IN stpks_stdcolre_Main.Ty_stdcolre,
                            p_Wrk_stdcolre     IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    --L_MAX_REVAL_DATE DATE;
  
    TYPE REVAL_DATE_LIST IS TABLE OF DATE INDEX BY BINARY_INTEGER;
  
    REVAL_DATE_VALUES REVAL_DATE_LIST;
    L_MAX_REVAL_DATE  DATE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.p_Auth) THEN
    
      BEGIN
        SELECT *
          BULK COLLECT
          INTO p_Wrk_stdcolre.v_sttm_collateral_detail
          FROM STTM_COLLATERAL_DETAIL A
         WHERE A.CUSTOMER_NO =
               p_stdcolre.v_sttm_collateral_master.customer_no
           and a.collat_ref_no =
               p_stdcolre.v_sttm_collateral_master.collat_ref_no;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Unable to get collateral details');
      END;
    
      FOR G IN p_Wrk_stdcolre.v_sttm_collateral_detail.FIRST .. p_Wrk_stdcolre.v_sttm_collateral_detail.LAST LOOP
      
        IF G = p_Wrk_stdcolre.v_sttm_collateral_detail.COUNT THEN
        
          L_MAX_REVAL_DATE := p_Wrk_stdcolre.v_sttm_collateral_detail(G)
                              .REVAL_DATE;
        
        END IF;
      
      END LOOP;
    
      DBG('L_MAX_REVAL_DATE=' || L_MAX_REVAL_DATE);
    
      BEGIN
        UPDATE GETM_COLLAT A
           SET A.REVAL_DATE = L_MAX_REVAL_DATE, A.REVAL_COLLAT = 'Y'
         WHERE A.UDF_VALUE_11 =
               P_STDCOLRE.V_STTM_COLLATERAL_MASTER.COLLAT_REF_NO
           AND A.CUSTOMER_NO =
               P_STDCOLRE.V_STTM_COLLATERAL_MASTER.CUSTOMER_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed to update reval date details');
      END;
    
      DBG('ROW COUNT=' || SQL%ROWCOUNT);
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcolre         IN stpks_stdcolre_Main.Ty_stdcolre,
                             p_prev_stdcolre    IN stpks_stdcolre_Main.Ty_stdcolre,
                             p_wrk_stdcolre     IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcolre         IN stpks_stdcolre_Main.Ty_stdcolre,
                        p_Wrk_stdcolre     IN OUT stpks_stdcolre_Main.Ty_stdcolre,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcolre_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcolre         IN stpks_stdcolre_Main.ty_stdcolre,
                         p_wrk_stdcolre     IN OUT stpks_stdcolre_Main.ty_stdcolre,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcolre_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcolre_custom;
