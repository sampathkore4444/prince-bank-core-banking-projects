insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('CASH/ FIX_DEPOSIT', 'BFIs');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('CASH/ FIX_DEPOSIT', 'N/A');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('GUARANTEE', 'General CGCC Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('GUARANTEE', 'Non-Scheme');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('GUARANTEE', 'Portfolio Guarantee Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('GUARANTEE', 'SME Scheme');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('HARD TITLE', 'Cadastral Office');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('MOVABLE_ASSET', 'Related Authority Ministry');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'BFIs');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'Cadastral Office');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'Commune Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'District Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'General CGCC Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'N/A');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'Non-Scheme');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'Portfolio Guarantee Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'Related Authority Ministry');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('OTHER', 'SME Scheme');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('SOFT TITLE', 'Commune Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('SOFT TITLE', 'District Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'BFIs');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'Cadastral Office');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'Commune Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'District Level');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'General CGCC Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'N/A');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'Non-Scheme');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'Portfolio Guarantee Schemes');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'Related Authority Ministry');

insert into sttb_static_collat_details (COLLATERAL_TYPE, ISSUED_BY)
values ('UNSECURED', 'SME Scheme');

COMMIT;
