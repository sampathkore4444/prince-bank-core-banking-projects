insert into lmtm_type_of_types (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('COLLATERAL_REVAL', 'List of revaluation values', 'SAMPATH2', 'SAMPATH2', to_date('05-03-2023 09:01:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('05-03-2023 09:01:15', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
