CREATE OR REPLACE TRIGGER ELTR_GETM_COLLAT_CUSTOM
  FOR INSERT OR UPDATE ON GETM_COLLAT
  COMPOUND TRIGGER

  BEFORE EACH ROW IS
  
    L_SEQ_NO           varchar2(3);
    L_COUNT            NUMBER;
    L_LIABNO           GETM_LIAB.LIAB_NO%TYPE;
    L_COLLAT_VAL_COUNT NUMBER := 0;
  
    closing_reason_empty      EXCEPTION;
    collat_type_isse_val      EXCEPTION;
    collat_type_gaurantee_val EXCEPTION;
    --PRAGMA exception_init(closing_reason_empty, -20111);
  
  BEGIN
  
    DEBUG.PR_DEBUG('AC',
                   '**********START OF ELTR_GETM_COLLAT_CUSTOM*******');
  
    DEBUG.PR_DEBUG('AC', 'NEW COLLATERAL CODE=' || :NEW.COLLATERAL_CODE);
  
    DEBUG.PR_DEBUG('AC', 'OLD COLLATERAL CODE=' || :OLD.COLLATERAL_CODE);
  
    DEBUG.PR_DEBUG('AC', ':NEW.LIAB_ID=' || :NEW.LIAB_ID);
    --get liab id
    BEGIN
      SELECT A.LIAB_NO
        INTO L_LIABNO
        FROM GETM_LIAB A
       WHERE A.ID = :NEW.LIAB_ID;
    EXCEPTION
      WHEN OTHERS THEN
        L_LIABNO := NULL;
    END;
  
    DEBUG.PR_DEBUG('AC', 'L_LIABNO=' || L_LIABNO);
  
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
        FROM GETM_COLLAT A
       WHERE A.CUSTOMER_NO = NVL(:NEW.CUSTOMER_NO, L_LIABNO);
    
      --         AND A.COLLATERAL_CODE <> :NEW.COLLATERAL_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    DEBUG.PR_DEBUG('AC', 'L_COUNT=' || L_COUNT);
    
    IF UPDATING THEN
    
      DEBUG.PR_DEBUG('AC', 'inside updating');
    
      L_SEQ_NO := LPAD(L_COUNT + 1, 3, '0');
    
      :NEW.UDF_VALUE_11 := 'COL_' || NVL(:NEW.CUSTOMER_NO, L_LIABNO) || '_' ||
                           L_SEQ_NO;
                           
    END IF;
  
    IF INSERTING THEN
    
      DEBUG.PR_DEBUG('AC', 'inside inserting');
    
      L_SEQ_NO := LPAD(L_COUNT + 1, 3, '0');
    
      :NEW.UDF_VALUE_11 := 'COL_' || NVL(:NEW.CUSTOMER_NO, L_LIABNO) || '_' ||
                           L_SEQ_NO;
    
      IF :NEW.CUSTOMER_NO IS NULL THEN
      
        :NEW.CUSTOMER_NO := L_LIABNO;
      
      END IF;
    
      --check the validation
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COLLAT_VAL_COUNT
          FROM sttb_static_collat_details A
         WHERE A.COLLATERAL_TYPE = :NEW.UDF_VALUE_4
           AND A.ISSUED_BY = :NEW.UDF_VALUE_13;
      
      EXCEPTION
      
        WHEN OTHERS THEN
          L_COLLAT_VAL_COUNT := 0;
      END;
    
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_4=' || :NEW.UDF_VALUE_4);
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_13=' || :NEW.UDF_VALUE_13);
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_12=' || :NEW.UDF_VALUE_12);
    
      DEBUG.PR_DEBUG('AC', 'L_COLLAT_VAL_COUNT=' || L_COLLAT_VAL_COUNT);
    
      IF L_COLLAT_VAL_COUNT = 0 THEN
        raise collat_type_isse_val;
        --raise_application_error(-20001, 'Closing Reason Can Not be empty');
      END IF;
    
      IF :NEW.UDF_VALUE_4 IN ('CASH/ FIX_DEPOSIT', 'GUARANTEE') AND
         :NEW.UDF_VALUE_12 IS NULL THEN
      
        raise collat_type_gaurantee_val;
      
      END IF;
    
    END IF;
  
    IF UPDATING THEN
    
      DEBUG.PR_DEBUG('AC', ':NEW.RECORD_STAT=' || :NEW.RECORD_STAT);
      DEBUG.PR_DEBUG('AC', ':OLD.RECORD_STAT=' || :OLD.RECORD_STAT);
    
      --check the validation
      BEGIN
      
        SELECT COUNT(1)
          INTO L_COLLAT_VAL_COUNT
          FROM sttb_static_collat_details A
         WHERE A.COLLATERAL_TYPE = :NEW.UDF_VALUE_4
           AND A.ISSUED_BY = :NEW.UDF_VALUE_13;
      
      EXCEPTION
      
        WHEN OTHERS THEN
          L_COLLAT_VAL_COUNT := 0;
      END;
    
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_4=' || :NEW.UDF_VALUE_4);
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_13=' || :NEW.UDF_VALUE_13);
      DEBUG.PR_DEBUG('AC', ':NEW.UDF_VALUE_12=' || :NEW.UDF_VALUE_12);
    
      DEBUG.PR_DEBUG('AC', ':NEW.RECORD_STAT=' || :NEW.RECORD_STAT);
      DEBUG.PR_DEBUG('AC', ':OLD.RECORD_STAT=' || :OLD.RECORD_STAT);
    
      DEBUG.PR_DEBUG('AC', 'L_COLLAT_VAL_COUNT=' || L_COLLAT_VAL_COUNT);
    
      IF L_COLLAT_VAL_COUNT = 0 THEN
        raise collat_type_isse_val;
        --raise_application_error(-20001, 'Closing Reason Can Not be empty');
      END IF;
    
      IF :NEW.UDF_VALUE_4 IN ('CASH/ FIX_DEPOSIT', 'GUARANTEE') AND
         :NEW.UDF_VALUE_12 IS NULL THEN
      
        raise collat_type_gaurantee_val;
      
      END IF;
    
      IF :NEW.UDF_VALUE_20 IN ('Other reason') AND
         :NEW.UDF_VALUE_21 IS NULL THEN
      
        raise collat_type_gaurantee_val;
      
      END IF;
      
      IF :NEW.UDF_VALUE_20 NOT IN ('Other reason') AND
         :NEW.UDF_VALUE_21 IS NOT NULL THEN
      
        raise collat_type_gaurantee_val;
      
      END IF;
    
      IF :NEW.RECORD_STAT = 'C' THEN
      
        DEBUG.PR_DEBUG('AC', 'OLD AUTH STAT=' || :OLD.AUTH_STAT);
        DEBUG.PR_DEBUG('AC', 'NEW AUTH STAT=' || :NEW.AUTH_STAT);
      
        IF :NEW.AUTH_STAT = 'A' THEN
        
          --stpks_stdcolre_custom.PR_CLOSE_REVALUATION(:NEW.UDF_VALUE_11);
        BEGIN
          UPDATE STTM_COLLATERAL_MASTER A
             SET A.RECORD_STAT = 'C',
                 A.MAKER_ID    = 'SYSTEM',
                 A.CHECKER_ID  = 'SYSTEM'
           WHERE A.COLLAT_REF_NO = :NEW.UDF_VALUE_11;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('AC','FAILED IN UPDATING THE COLLATERAL REVAL');
        END;
        END IF;
      
        IF :NEW.UDF_VALUE_20 IN ('Other reason') AND :NEW.UDF_VALUE_21 IS NULL THEN
        
          raise closing_reason_empty;
          --raise_application_error(-20001, 'Closing Reason Can Not be empty');
        
        END IF;
      
      END IF;
      
      IF :NEW.RECORD_STAT = 'O' THEN
      
        DEBUG.PR_DEBUG('AC', 'OLD AUTH STAT=' || :OLD.AUTH_STAT);
        DEBUG.PR_DEBUG('AC', 'NEW AUTH STAT=' || :NEW.AUTH_STAT);
      
        IF :NEW.AUTH_STAT = 'A' THEN
        
          --stpks_stdcolre_custom.PR_CLOSE_REVALUATION(:NEW.UDF_VALUE_11);
        BEGIN
          UPDATE STTM_COLLATERAL_MASTER A
             SET A.RECORD_STAT = 'O'--,
                 --A.MAKER_ID    = 'SYSTEM',
                 --A.CHECKER_ID  = 'SYSTEM'
           WHERE A.COLLAT_REF_NO = :NEW.UDF_VALUE_11;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('AC','FAILED IN UPDATING THE COLLATERAL REVAL');
        END;
        END IF;
      
       
      END IF;
    
    END IF;
  
    DEBUG.PR_DEBUG('AC', 'RETURNING FROM TRIGGER');
  
  EXCEPTION
    WHEN collat_type_gaurantee_val THEN
      raise_application_error(-20003,
                              'GUARANTEE_PERCENTAGE_CASA_TD_NO is mandatory');
    WHEN collat_type_isse_val THEN
      raise_application_error(-20002,
                              'Invalid combination of Collateral Type and Issued By');
    WHEN closing_reason_empty THEN
      raise_application_error(-20001, 'Closing Reason Can Not be empty');
    
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN ELTR_GETM_COLLAT_CUSTOM');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN ELTR_GETM_COLLAT_CUSTOM=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN ELTR_GETM_COLLAT_CUSTOM=' || SQLERRM);
    
    /* Cspks_Req_Utils.Pr_Log_Error('FLEXCUBE',
    'GEDCOLLT',
    'CO-VALS-012',
    null);*/
  
    --raise_application_error(-20001, 'Closing Reason Can Not be empty');
  END BEFORE EACH ROW;

END ELTR_GETM_COLLAT_CUSTOM;
