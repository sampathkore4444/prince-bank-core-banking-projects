BEGIN

  INSERT INTO IFTB_NCS_MASTER@OBPM_REMOTE
  VALUES
    ('001',
     'O',
     '123',
     '123',
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null, --beneficiary account from UDF,
     null, --beneficiary bic from UDF
     null, --beneficiary name from UDF
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     null,
     'A',
     'O',
     'Y',
     1,
     NULL,
     NULL,
     NULL,
     NULL,
     NULL,
     NULL,
     NULL,
     NULL,
     NULL);

END;