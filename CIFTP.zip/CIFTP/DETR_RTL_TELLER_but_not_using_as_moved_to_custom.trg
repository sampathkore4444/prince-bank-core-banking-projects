CREATE OR REPLACE TRIGGER DETR_RTL_TELLER
  AFTER INSERT OR UPDATE ON DETB_RTL_TELLER

  FOR EACH ROW

DECLARE
  L_BEN_BANK_NAME     CSTMS_CONTRACT_USERDEF_FIELDS.FIELD_VAL_1%TYPE;
  L_BEN_BANK_ACC_NO   CSTMS_CONTRACT_USERDEF_FIELDS.FIELD_VAL_2%TYPE;
  L_BEN_BANK_ACC_NAME CSTMS_CONTRACT_USERDEF_FIELDS.FIELD_VAL_3%TYPE;
  L_PROCESSING_DATE   DATE;
  L_PAYEE_BANK_CODE   VARCHAR2(6);
BEGIN

  DEBUG.PR_DEBUG('AC', '**********START OF DETR_RTL_TELLER***********');

  DEBUG.PR_DEBUG('AC', ':NEW.auth_stat=' || :NEW.auth_stat);

  IF :NEW.AUTH_STAT = 'A' AND :NEW.PRODUCT_CODE = 'IBFT' THEN
  
    --Derive Beneficiary Account from UDF contract Table
    BEGIN
      SELECT FIELD_VAL_1, FIELD_VAL_2, FIELD_VAL_3
        INTO L_BEN_BANK_NAME, L_BEN_BANK_ACC_NO, L_BEN_BANK_ACC_NAME
        FROM CSTMS_CONTRACT_USERDEF_FIELDS
       WHERE CONTRACT_REF_NO = :NEW.TRN_REF_NO;
    EXCEPTION
      WHEN OTHERS THEN
        L_BEN_BANK_NAME     := NULL;
        L_BEN_BANK_ACC_NO   := NULL;
        L_BEN_BANK_ACC_NAME := NULL;
    END;
  
    --Caluclate Processing Date
    IF TO_CHAR(:NEW.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') >= '08:00' AND
      
       TO_CHAR(:NEW.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '12:00' THEN
    
      L_PROCESSING_DATE := :NEW.TRN_DT;
    
    ELSIF TO_CHAR(:NEW.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') > '12:00' AND
          TO_CHAR(:NEW.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '23:59' THEN
    
      L_PROCESSING_DATE := SYSDATE + 1;
    
    ELSE
    
      L_PROCESSING_DATE := SYSDATE;
    
    END IF;
  
    --Derive Payee bank based on BIC Code from lmtm type static table
    BEGIN
      SELECT A.PAYEEBANK_CODE --A.BANK_CODE
        INTO L_PAYEE_BANK_CODE
        FROM STVW_IBFT_BANK_NAME_BIC_CODE A
        --FROM IFTB_CIFTP_BANKS_LIST A
       WHERE A.BIC_CODE = L_BEN_BANK_NAME;
       --PART_CODE = L_BEN_BANK_NAME;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_PAYEE_BANK_CODE := NULL;
    END;
    
       --Derive Payee bank based on BIC Code from lmtm type static table
    BEGIN
      SELECT A.BANK_CODE --A.BANK_CODE
        INTO L_PAYEE_BANK_CODE
        FROM IFTB_CIFTP_BANKS_LIST A
       WHERE A.PART_CODE = L_BEN_BANK_NAME;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_PAYEE_BANK_CODE := NULL;
    END;
  
    INSERT INTO IFTB_INTERBANK_TRANSFER_TXNS
    VALUES
      (:NEW.XREF,
       :NEW.TRN_REF_NO,
       :NEW.TRN_DT,
       :NEW.VALUE_DT,
       :NEW.AUTH_STAT,
       :NEW.SCODE,
       :NEW.MAKER_ID,
       :NEW.CHECKER_ID,
       :NEW.MAKER_DT_STAMP,
       :NEW.CHECKER_DT_STAMP,
       L_BEN_BANK_NAME,
       L_BEN_BANK_ACC_NO,
       :NEW.TXN_AMOUNT,
       
       :NEW.TXN_ACC,
       :NEW.OFS_ACC,
       :NEW.TXN_CCY,
       :NEW.TRN_DT, --Payment Date
       L_PROCESSING_DATE, --Processing Date
       L_PAYEE_BANK_CODE,
       L_BEN_BANK_ACC_NAME,
       SYSDATE);
  
    INSERT INTO IFTB_INTERBANK_TRANSFER_TXNS_T
    VALUES
      (:NEW.XREF,
       :NEW.TRN_REF_NO,
       :NEW.TRN_DT,
       :NEW.VALUE_DT,
       :NEW.AUTH_STAT,
       :NEW.SCODE,
       :NEW.MAKER_ID,
       :NEW.CHECKER_ID,
       :NEW.MAKER_DT_STAMP,
       :NEW.CHECKER_DT_STAMP,
       L_BEN_BANK_NAME,
       L_BEN_BANK_ACC_NO,
       :NEW.TXN_AMOUNT,
       :NEW.TXN_ACC,
       :NEW.OFS_ACC,
       
       :NEW.TXN_CCY,
       :NEW.TRN_DT, --Payment Date
       L_PROCESSING_DATE, --Processing Date
       L_PAYEE_BANK_CODE,
       L_BEN_BANK_ACC_NAME,
       SYSDATE);
  
  END IF;

  DEBUG.PR_DEBUG('IF', '**********END OF DETR_RTL_TELLER***********');

EXCEPTION
  WHEN OTHERS THEN
    Debug.Pr_Debug('ST', 'Failed in DETR_RTL_TELLER. Error = ' || SQLERRM);
END DETR_RTL_TELLER;
