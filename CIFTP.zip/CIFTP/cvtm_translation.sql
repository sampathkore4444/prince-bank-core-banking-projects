prompt Importing table cvtm_translation...
set feedback off
set define off
insert into cvtm_translation (SOURCE_CODE, TRANSLATION_TYPE, EXTERNAL_BRANCH, EXTERNAL_VALUE, INTERNAL_BRANCH, INTERNAL_VALUE)
values ('XXXX', 'TXN_CODE', '000', 'BTF', null, 'BTF');

insert into cvtm_translation (SOURCE_CODE, TRANSLATION_TYPE, EXTERNAL_BRANCH, EXTERNAL_VALUE, INTERNAL_BRANCH, INTERNAL_VALUE)
values ('XXXX', 'TXN_CODE', '000', 'BKL', null, 'BKL');

insert into cvtm_translation (SOURCE_CODE, TRANSLATION_TYPE, EXTERNAL_BRANCH, EXTERNAL_VALUE, INTERNAL_BRANCH, INTERNAL_VALUE)
values ('XXXX', 'TXN_CODE', '000', 'ITF', null, 'ITF');

insert into cvtm_translation (SOURCE_CODE, TRANSLATION_TYPE, EXTERNAL_BRANCH, EXTERNAL_VALUE, INTERNAL_BRANCH, INTERNAL_VALUE)
values ('XXXX', 'TXN_CODE', '000', 'BLF', null, 'BLF');

prompt Done.
