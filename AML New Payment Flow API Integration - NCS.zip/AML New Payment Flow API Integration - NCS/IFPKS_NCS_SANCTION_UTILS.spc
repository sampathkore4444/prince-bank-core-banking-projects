CREATE OR REPLACE PACKAGE IFPKS_NCS_SANCTION_UTILS AS

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC;

  FUNCTION FN_AML_PAYMENT_CALL_B(P_USER_NAME               IN VARCHAR2,
                                 P_BRANCH_CODE             IN VARCHAR2,
                                 P_SYS_NAME                IN VARCHAR2,
                                 P_UNIQUE_NO               IN VARCHAR2,
                                 P_SEARCH_NAME             IN VARCHAR2,
                                 P_SEARCH_COUNTRY          IN VARCHAR2,
                                 P_SEARCH_F1_BANK_NAME     IN VARCHAR2,
                                 P_SEARCH_ID               IN VARCHAR2,
                                 P_PASSPORT_VERIFY         IN VARCHAR2,
                                 P_SECURITY_NO1            IN VARCHAR2,
                                 P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                 P_PASSPORT_EXPDATE        IN VARCHAR2,
                                 P_SECURITY_NO2            IN VARCHAR2,
                                 P_RISK_FACTORS            IN VARCHAR2,
                                 P_SEARCH_F2_ADDR          IN VARCHAR2,
                                 P_SEARCH_F3_PURPOSE       IN VARCHAR2,
                                 P_SEARCH_F4_REMARKS       IN VARCHAR2,
                                 P_SEARCH_F5_TXN_AMT       IN VARCHAR2,
                                 P_SEARCH_F6_TXN_CCY       IN VARCHAR2,
                                 P_SEARCH_F7_ACC_NO        IN VARCHAR2,
                                 P_SEARCH_F8               IN VARCHAR2,
                                 P_SEARCH_F9               IN VARCHAR2,
                                 P_PROD_CHANNEL            IN VARCHAR2,
                                 P_PROD_CODE               IN VARCHAR2,
                                 P_CONTENT                 IN VARCHAR2,
                                 P_RETURN_HIT              IN VARCHAR2,
                                 P_RETURN_SCANID           IN VARCHAR2,
                                 P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                                 P_CUSTOMER_NO             IN VARCHAR2,
                                 P_SENDER_NAME             IN VARCHAR2,
                                 P_SENDER_COUNTRY          IN VARCHAR2,
                                 P_BEN_NAME                IN VARCHAR2,
                                 P_BEN_COUNTRY             IN VARCHAR2,
                                 P_FCREF_NO                IN VARCHAR2,
                                 P_SCAN_ID                 OUT VARCHAR2,
                                 P_HIT_STATUS              OUT VARCHAR2,
                                 P_RESPONSE                OUT CLOB)
    RETURN BOOLEAN;

  FUNCTION FN_GET_AML_PAYMENT_STATUS(P_SYS_NAME     IN VARCHAR2,
                                     P_UNIQUE_NO    IN VARCHAR2,
                                     P_SCAN_ID      IN VARCHAR2,
                                     P_CUSTOMER_NO  IN VARCHAR2,
                                     P_FCREF_NO     IN VARCHAR2,
                                     P_PROD_CHANNEL IN VARCHAR2,
                                     P_PROD_CODE    IN VARCHAR2,
                                     P_RESPONSE     OUT CLOB) RETURN BOOLEAN;

END IFPKS_NCS_SANCTION_UTILS;
