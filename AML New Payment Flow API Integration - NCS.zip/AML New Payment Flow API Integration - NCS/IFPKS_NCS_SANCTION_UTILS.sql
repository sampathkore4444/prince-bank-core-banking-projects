CREATE OR REPLACE PACKAGE BODY IFPKS_NCS_SANCTION_UTILS AS

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'IFPKS_NCS_SANCTION_UTILS ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION FN_GET_FORMATTED_MSG(P_RAW_CONTENT             IN VARCHAR2,
                                P_USER_NAME               IN VARCHAR2,
                                P_BRANCH_CODE             IN VARCHAR2,
                                P_SYS_NAME                IN VARCHAR2,
                                P_UNIQUE_NO               IN VARCHAR2,
                                P_SEARCH_NAME             IN VARCHAR2,
                                P_SEARCH_COUNTRY          IN VARCHAR2,
                                P_SEARCH_F1               IN VARCHAR2,
                                P_SEARCH_ID               IN VARCHAR2,
                                P_PASSPORT_VERIFY         IN VARCHAR2,
                                P_SECURITY_NO1            IN VARCHAR2,
                                P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                P_PASSPORT_EXPDATE        IN VARCHAR2,
                                P_SECURITY_NO2            IN VARCHAR2,
                                P_RISK_FACTORS            IN VARCHAR2,
                                P_SEARCH_F2               IN VARCHAR2,
                                P_SEARCH_F3               IN VARCHAR2,
                                P_SEARCH_F4               IN VARCHAR2,
                                P_SEARCH_F5               IN VARCHAR2,
                                P_SEARCH_F6               IN VARCHAR2,
                                P_SEARCH_F7               IN VARCHAR2,
                                P_SEARCH_F8               IN VARCHAR2,
                                P_SEARCH_F9               IN VARCHAR2,
                                P_PROD_CHANNEL            IN VARCHAR2,
                                P_PROD_CODE               IN VARCHAR2,
                                P_CONTENT                 IN VARCHAR2,
                                P_RETURN_HIT              IN VARCHAR2,
                                P_RETURN_SCANID           IN VARCHAR2,
                                P_RETURN_ENCRYPT_SCANID   IN VARCHAR2)
    RETURN CLOB AS
  
    L_FORMATTED_MSG VARCHAR2(32767);
  
  BEGIN
  
    L_FORMATTED_MSG := P_RAW_CONTENT;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_USER_NAME', P_USER_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_BRANCH_CODE',
                               P_BRANCH_CODE);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SYS_NAME', P_SYS_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_UNIQUE_NO', P_UNIQUE_NO);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEARCH_NAME',
                               P_SEARCH_NAME);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SEARCH_COUNTRY',
                               P_SEARCH_COUNTRY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F1', P_SEARCH_F1);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_ID', P_SEARCH_ID);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_VERIFY',
                               P_PASSPORT_VERIFY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SECURITY_NO1',
                               P_SECURITY_NO1);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_EXPDATE_VERIFY',
                               P_PASSPORT_EXPDATE_VERIFY);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PASSPORT_EXPDATE',
                               P_PASSPORT_EXPDATE);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SECURITY_NO2',
                               P_SECURITY_NO2);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RISK_FACTORS',
                               P_RISK_FACTORS);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F2', P_SEARCH_F2);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F3', P_SEARCH_F3);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F4', P_SEARCH_F4);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F5', P_SEARCH_F5);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F6', P_SEARCH_F6);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F7', P_SEARCH_F7);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F8', P_SEARCH_F8);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SEARCH_F9', P_SEARCH_F9);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_PROD_CHANNEL',
                               P_PROD_CHANNEL);
  
    IF P_PROD_CODE IN ('NCSF') THEN
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SCAN_OPTION', '9');
    
    END IF;
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_CONTENT', P_CONTENT);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_HIT',
                               P_RETURN_HIT);
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_SCANID',
                               P_RETURN_SCANID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_SCANID',
                               P_RETURN_SCANID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_RETURN_ENCRYPT_SCANID',
                               P_RETURN_ENCRYPT_SCANID);
  
    RETURN L_FORMATTED_MSG;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_GET_FORMATTED_MSG');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN FN_GET_FORMATTED_MSG=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_GET_FORMATTED_MSG=' || SQLERRM);
    
  END FN_GET_FORMATTED_MSG;

  PROCEDURE PR_INSERT_CORAL_NCS_WS_LOG(P_UNIQUE_REF_NO  IN VARCHAR2,
                                       P_CUST_NO        IN VARCHAR2,
                                       P_DATE           IN DATE,
                                       P_REQ_TYPE       IN VARCHAR2,
                                       P_ACTION_CODE    IN VARCHAR2,
                                       P_REQ_MSG        IN CLOB,
                                       P_FCREF_NO       IN VARCHAR2,
                                       P_SENDER_NAME    IN VARCHAR2,
                                       P_SENDER_COUNTRY IN VARCHAR2,
                                       P_BEN_NAME       IN VARCHAR2,
                                       P_BEN_COUNTRY    IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('WHO CALLED ME=' || DBMS_UTILITY.format_call_stack);
    DBG('INSIDE PR_INSERT_CORAL_NCS_WS_LOG');
    INSERT INTO STTB_CORAL_NCS_WS_LOG
      (UNIQUE_REFERENCE_NO,
       CUSTOMER_NO,
       INVOKE_DATE,
       REQ_TYPE,
       REQ_MSG,
       ACTION,
       FC_REF_NO,
       SENDER_NAME,
       SENDER_HIGH_CNT,
       BEN_NAME,
       BEN_HIGH_CNT)
    VALUES
      (P_UNIQUE_REF_NO,
       P_CUST_NO,
       P_DATE,
       P_REQ_TYPE,
       P_REQ_MSG,
       P_ACTION_CODE,
       P_FCREF_NO,
       P_SENDER_NAME,
       P_SENDER_COUNTRY,
       P_BEN_NAME,
       P_BEN_COUNTRY);
  
    COMMIT;
  
  END PR_INSERT_CORAL_NCS_WS_LOG;

  PROCEDURE PR_UPDATE_CORAL_NCS_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                       P_SCAN_ID      IN VARCHAR2,
                                       P_STATUS       IN CHAR,
                                       P_RES_MSG      IN CLOB) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    DBG('P_REFERENCE_NO=' || P_REFERENCE_NO);
    UPDATE STTB_CORAL_NCS_WS_LOG
       SET SCAN_ID = P_SCAN_ID, STATUS = P_STATUS, RES_MSG = P_RES_MSG
     WHERE UNIQUE_REFERENCE_NO = P_REFERENCE_NO;
  
    COMMIT;
  
  END PR_UPDATE_CORAL_NCS_WS_LOG;

  FUNCTION FN_GET_AML_PAYMENT_STATUS RETURN CLOB IS
  
    L_FORMATTED_MSG varchar2(4000);
  
  BEGIN
    DBG('SATRT OF FN_GET_AML_PAYMENT_STATUS');
  
    L_FORMATTED_MSG := '{"AuthUser":"AMLSVC", "AuthPswd":"AMLSVC", "Username":"$L_USER_ID", "SysName": "$L_SYSTEM_NAME", "ScanOption": "$L_SCAN_OPTION", "UniqueNo": "$L_UNIQUE_NO", "ScanID": "$L_SCAN_ID"}';
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_AML_PAYMENT_STATUS');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_AML_PAYMENT_STATUS');
      DBG('ERROR CODE IN FN_GET_AML_PAYMENT_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_AML_PAYMENT_STATUS=' || SQLERRM);
    
  END FN_GET_AML_PAYMENT_STATUS;

  FUNCTION FN_GET_FMT_AML_PAYMENT_STATUS(P_SYSTEM_NAME IN VARCHAR2,
                                         P_UNIQUE_NO   IN VARCHAR2,
                                         P_SCAN_ID     IN VARCHAR2,
                                         P_PROD_CODE   IN VARCHAR2)
    RETURN CLOB IS
  
    L_FORMATTED_MSG CLOB;
    L_USER_ID       VARCHAR2(35);
    L_SYSTEM_NAME   VARCHAR2(35);
    L_UNIQUE_NO     VARCHAR2(35);
    L_SCAN_ID       STTB_CORAL_NCS_WS_LOG.SCAN_ID%TYPE;
  
  BEGIN
  
    DBG('SATRT OF FN_GET_FMT_AML_PAYMENT_STATUS');
  
    L_FORMATTED_MSG := FN_GET_AML_PAYMENT_STATUS;
  
    DBG('BEFORE REPLACEMENT OF AML PAYMENT JSON=' || L_FORMATTED_MSG);
  
    L_USER_ID := GLOBAL.user_id;
  
    DBG('L_USER_ID=' || L_USER_ID);
  
    L_SYSTEM_NAME := P_SYSTEM_NAME;
  
    DBG('L_SYSTEM_NAME=' || L_SYSTEM_NAME);
  
    L_UNIQUE_NO := P_UNIQUE_NO;
  
    DBG('L_UNIQUE_NO=' || L_UNIQUE_NO);
  
    L_SCAN_ID := P_SCAN_ID;
  
    DBG('L_SCAN_ID=' || L_SCAN_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_USER_ID', L_USER_ID);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG,
                               '$L_SYSTEM_NAME',
                               L_SYSTEM_NAME);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_UNIQUE_NO', L_UNIQUE_NO);
  
    L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SCAN_ID', L_SCAN_ID);
  
    IF P_PROD_CODE IN ('NCSF') THEN
    
      L_FORMATTED_MSG := REPLACE(L_FORMATTED_MSG, '$L_SCAN_OPTION', '9');
    
    END IF;
  
    DBG('BEFORE REPLACEMENT OF AML PAYMENT STATUS JSON=' ||
        L_FORMATTED_MSG);
  
    RETURN L_FORMATTED_MSG;
  
    DBG('END OF FN_GET_FMT_AML_PAYMENT_STATUS');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_FMT_AML_PAYMENT_STATUS');
      DBG('ERROR CODE IN FN_GET_FMT_AML_PAYMENT_STATUS=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_FMT_AML_PAYMENT_STATUS=' || SQLERRM);
    
  END FN_GET_FMT_AML_PAYMENT_STATUS;

  FUNCTION FN_GET_AML_PAYMENT_STATUS(P_SYS_NAME     IN VARCHAR2,
                                     P_UNIQUE_NO    IN VARCHAR2,
                                     P_SCAN_ID      IN VARCHAR2,
                                     P_CUSTOMER_NO  IN VARCHAR2,
                                     P_FCREF_NO     IN VARCHAR2,
                                     P_PROD_CHANNEL IN VARCHAR2,
                                     P_PROD_CODE    IN VARCHAR2,
                                     P_RESPONSE     OUT CLOB) RETURN BOOLEAN AS
  
    L_HTTP_REQUEST  UTL_HTTP.REQ;
    L_HTTP_RESPONSE UTL_HTTP.RESP;
    L_URL           VARCHAR2(105);
    NAME            VARCHAR2(4000);
    BUFFER          VARCHAR2(32767);
    BUFFER1         CLOB;
    L_RESP_OK       BOOLEAN;
    L_RESP_NUM      NUMBER;
    L_LENGTH        NUMBER;
  
    L_FORMATTED_CONTENT VARCHAR2(32767);
  
    L_REF           VARCHAR2(16);
    L_SEQ           NUMBER;
    L_RETURN_STATUS VARCHAR2(100);
    L_HIT_VALUE     VARCHAR2(100);
  
  begin
  
    SELECT OBPM_NCS_AML_API_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    DBG('L_REF=' || L_REF);
  
    L_FORMATTED_CONTENT := FN_GET_FMT_AML_PAYMENT_STATUS(P_SYS_NAME,
                                                         P_FCREF_NO,
                                                         P_SCAN_ID,
                                                         P_PROD_CODE);
  
    debug.pr_debug('IF',
                   'L_CONTENT AFTER FORMATTING=' || L_FORMATTED_CONTENT);
  
    IF P_PROD_CHANNEL = 'NCS' THEN
    
      PR_INSERT_CORAL_NCS_WS_LOG(L_REF,
                                 P_CUSTOMER_NO,
                                 SYSDATE,
                                 'ONLINE_STATUS',
                                 'STATUSSCAN_AUTH',
                                 L_FORMATTED_CONTENT,
                                 P_FCREF_NO,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL);
    
    END IF;
  
    SELECT PARAM_VAL
      INTO L_URL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = UPPER('CORAL_VALIDATION_PAY_STAT_URL');
  
    debug.pr_debug('IF', 'L_URL=' || L_URL);
  
    l_http_request := utl_http.begin_request(L_URL, 'POST', ' HTTP/1.1');
  
    utl_http.set_authentication(l_http_request,
                                'prince',
                                'qwer!@#$',
                                'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
  
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/json;charset=UTF-8');
  
    select REGEXP_COUNT(DUMP(L_FORMATTED_CONTENT, 1016), 'c3')
      into l_length
      from dual;
  
    debug.pr_debug('IF', 'l_length=' || l_length);
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(L_FORMATTED_CONTENT) + l_length);
  
    debug.pr_debug('IF', 'L_CONTENT=' || L_FORMATTED_CONTENT);
  
    UTL_HTTP.WRITE_TEXT(L_HTTP_REQUEST, L_FORMATTED_CONTENT);
  
    UTL_HTTP.WRITE_RAW(L_HTTP_REQUEST,
                       UTL_RAW.CAST_TO_RAW(L_FORMATTED_CONTENT));
  
    L_HTTP_RESPONSE := UTL_HTTP.GET_RESPONSE(L_HTTP_REQUEST);
  
    debug.pr_debug('IF', 'status code=' || L_HTTP_RESPONSE.STATUS_CODE);
  
    L_RESP_OK := FALSE;
    SELECT DECODE(L_HTTP_RESPONSE.STATUS_CODE, 200, 1, 0)
      INTO L_RESP_NUM
      FROM DUAL;
  
    debug.pr_debug('IF', 'l_resp_num=' || L_RESP_NUM);
  
    IF L_RESP_NUM = 1 THEN
      L_RESP_OK := TRUE;
    ELSIF L_RESP_NUM = 0 THEN
      L_RESP_OK := FALSE;
    END IF;
  
    IF L_RESP_OK THEN
      -- PROCESS THE RESPONSE FROM THE HTTP CALL
      BEGIN
        LOOP
          UTL_HTTP.READ_LINE(L_HTTP_RESPONSE, BUFFER);
          BUFFER1 := BUFFER1 || BUFFER;
        END LOOP;
        UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
      EXCEPTION
        WHEN UTL_HTTP.END_OF_BODY THEN
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
        WHEN OTHERS THEN
          debug.pr_debug('IF', 'ERROR CODE=' || SQLCODE);
          debug.pr_debug('IF', 'ERROR MESSAGE=' || SQLERRM);
      END;
    
      P_RESPONSE := BUFFER1;
    
      --update response
      IF P_PROD_CHANNEL = 'NCS' THEN
      
        PR_UPDATE_CORAL_NCS_WS_LOG(L_REF,
                                   P_SCAN_ID,
                                   L_RETURN_STATUS,
                                   P_RESPONSE);
      
      END IF;
    
      DEBUG.PR_DEBUG('IF', 'buffer1=' || BUFFER1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    IF l_resp_ok THEN
      debug.pr_debug('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      debug.pr_debug('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_GET_AML_PAYMENT_STATUS');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN FN_GET_AML_PAYMENT_STATUS=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_GET_AML_PAYMENT_STATUS=' ||
                     SQLERRM);
      RETURN FALSE;
  END FN_GET_AML_PAYMENT_STATUS;

  FUNCTION FN_AML_PAYMENT_CALL_B(P_USER_NAME               IN VARCHAR2,
                                 P_BRANCH_CODE             IN VARCHAR2,
                                 P_SYS_NAME                IN VARCHAR2,
                                 P_UNIQUE_NO               IN VARCHAR2,
                                 P_SEARCH_NAME             IN VARCHAR2,
                                 P_SEARCH_COUNTRY          IN VARCHAR2,
                                 P_SEARCH_F1_BANK_NAME     IN VARCHAR2,
                                 P_SEARCH_ID               IN VARCHAR2,
                                 P_PASSPORT_VERIFY         IN VARCHAR2,
                                 P_SECURITY_NO1            IN VARCHAR2,
                                 P_PASSPORT_EXPDATE_VERIFY IN VARCHAR2,
                                 P_PASSPORT_EXPDATE        IN VARCHAR2,
                                 P_SECURITY_NO2            IN VARCHAR2,
                                 P_RISK_FACTORS            IN VARCHAR2,
                                 P_SEARCH_F2_ADDR          IN VARCHAR2,
                                 P_SEARCH_F3_PURPOSE       IN VARCHAR2,
                                 P_SEARCH_F4_REMARKS       IN VARCHAR2,
                                 P_SEARCH_F5_TXN_AMT       IN VARCHAR2,
                                 P_SEARCH_F6_TXN_CCY       IN VARCHAR2,
                                 P_SEARCH_F7_ACC_NO        IN VARCHAR2,
                                 P_SEARCH_F8               IN VARCHAR2,
                                 P_SEARCH_F9               IN VARCHAR2,
                                 P_PROD_CHANNEL            IN VARCHAR2,
                                 P_PROD_CODE               IN VARCHAR2,
                                 P_CONTENT                 IN VARCHAR2,
                                 P_RETURN_HIT              IN VARCHAR2,
                                 P_RETURN_SCANID           IN VARCHAR2,
                                 P_RETURN_ENCRYPT_SCANID   IN VARCHAR2,
                                 P_CUSTOMER_NO             IN VARCHAR2,
                                 P_SENDER_NAME             IN VARCHAR2,
                                 P_SENDER_COUNTRY          IN VARCHAR2,
                                 P_BEN_NAME                IN VARCHAR2,
                                 P_BEN_COUNTRY             IN VARCHAR2,
                                 P_FCREF_NO                IN VARCHAR2,
                                 P_SCAN_ID                 OUT VARCHAR2,
                                 P_HIT_STATUS              OUT VARCHAR2,
                                 P_RESPONSE                OUT CLOB)
    RETURN BOOLEAN AS
  
    L_HTTP_REQUEST  UTL_HTTP.REQ;
    L_HTTP_RESPONSE UTL_HTTP.RESP;
    L_URL           VARCHAR2(105);
    NAME            VARCHAR2(4000);
    BUFFER          VARCHAR2(32767);
    BUFFER1         CLOB;
    L_RESP_OK       BOOLEAN;
    L_RESP_NUM      NUMBER;
    L_LENGTH        NUMBER;
    L_CONTENT       VARCHAR2(32767) := '{
    "AuthUser": "AMLSVC",
    "AuthPswd": "AMLSVC",
    "Username": "$L_USER_NAME",
    "BrCode": "$L_BRANCH_CODE",
    "SysName": "$L_SYS_NAME",
    "ScanOption": "$L_SCAN_OPTION",
    "UniqueNo": "$L_UNIQUE_NO",
    "SearchName":"$L_SEARCH_NAME",
    "SearchCountry": "$L_SEARCH_COUNTRY",
    "SearchF1": "$L_SEARCH_F1",
    "SearchID": "$L_SEARCH_ID",
    "PassportVerify": "$L_PASSPORT_VERIFY",
    "SecurityNo1": "$L_SECURITY_NO1",
    "PassExpiryDtVerify": "$L_PASSPORT_EXPDATE_VERIFY",
    "PassExpiryDate": "$L_PASSPORT_EXPDATE",
    "SecurityNo2": "$L_SECURITY_NO2",
    "RiskFactors": "$L_RISK_FACTORS",
    "SearchF2": "$L_SEARCH_F2",
    "SearchF3": "$L_SEARCH_F3",
    "SearchF4": "$L_SEARCH_F4",
    "SearchF5": "$L_SEARCH_F5",
    "SearchF6": "$L_SEARCH_F6",
    "SearchF7": "$L_SEARCH_F7",
    "SearchF8": "$L_SEARCH_F8",
    "SearchF9": "$L_SEARCH_F9",
    "ProdChannel": "$L_PROD_CHANNEL",
    "Content": "$L_CONTENT",
    "RtnHit": "$L_RETURN_HIT",
    "RtnScanID":"0",
    "RtnAlertID":"0",
    "RtnEnCryptScanID":"$L_RETURN_ENCRYPT_SCANID"
}';
  
    L_FORMATTED_CONTENT VARCHAR2(32767);
  
    L_REF           VARCHAR2(16);
    L_SEQ           NUMBER;
    L_RTN_SCAN_ID   VARCHAR2(100);
    L_RETURN_STATUS VARCHAR2(100);
    L_RISK_LEVEL    CHAR(1);
    L_HIT_VALUE     VARCHAR2(100);
  
    L_RESP_IN_XML  CLOB;
    P_DOCUMENT_XML XMLTYPE;
    L_IN_RESP      CLOB;
  
  begin
  
    SELECT OBPM_NCS_AML_API_WS_CALL_LOG_ID.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_REF := SUBSTR(TO_CHAR(SYSDATE, 'yymm'), 2) || LPAD(L_SEQ, 9, '0');
  
    DBG('L_REF=' || L_REF);
  
    L_FORMATTED_CONTENT := FN_GET_FORMATTED_MSG(L_CONTENT,
                                                
                                                P_USER_NAME,
                                                P_BRANCH_CODE,
                                                P_SYS_NAME,
                                                P_FCREF_NO, --L_REF,
                                                P_SEARCH_NAME,
                                                P_SEARCH_COUNTRY,
                                                P_SEARCH_F1_BANK_NAME,
                                                P_SEARCH_ID,
                                                P_PASSPORT_VERIFY,
                                                P_SECURITY_NO1,
                                                P_PASSPORT_EXPDATE_VERIFY,
                                                P_PASSPORT_EXPDATE,
                                                P_SECURITY_NO2,
                                                P_RISK_FACTORS,
                                                P_SEARCH_F2_ADDR,
                                                P_SEARCH_F3_PURPOSE,
                                                P_SEARCH_F4_REMARKS,
                                                P_SEARCH_F5_TXN_AMT,
                                                P_SEARCH_F6_TXN_CCY,
                                                P_SEARCH_F7_ACC_NO,
                                                P_SEARCH_F8,
                                                P_SEARCH_F9,
                                                P_PROD_CHANNEL,
                                                P_PROD_CODE,
                                                P_CONTENT,
                                                P_RETURN_HIT,
                                                P_RETURN_SCANID,
                                                P_RETURN_ENCRYPT_SCANID);
  
    debug.pr_debug('IF',
                   'L_CONTENT AFTER FORMATTING=' || L_FORMATTED_CONTENT);
  
    IF P_PROD_CHANNEL = 'NCS' THEN
    
      PR_INSERT_CORAL_NCS_WS_LOG(L_REF,
                                 P_CUSTOMER_NO,
                                 SYSDATE,
                                 'ONLINE_SCAN',
                                 'DOSCAN_AUTH_B',
                                 L_FORMATTED_CONTENT,
                                 P_FCREF_NO,
                                 P_SENDER_NAME,
                                 P_SENDER_COUNTRY,
                                 P_BEN_NAME,
                                 P_BEN_COUNTRY);
    
    END IF;
  
    SELECT PARAM_VAL
      INTO L_URL
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = UPPER('CORAL_VALIDATE_PAY_WS_URL_B');
  
    debug.pr_debug('IF', 'L_URL=' || L_URL);
  
    l_http_request := utl_http.begin_request(L_URL, 'POST', ' HTTP/1.1');
  
    --utl_http.set_authentication(l_http_request,
    --                           'prince',
    --                           'qwer!@#$',
    --                          'Basic');
    utl_http.set_header(l_http_request, 'user-agent', 'mozilla/4.0');
  
    utl_http.set_header(l_http_request,
                        'content-type',
                        'application/json;charset=UTF-8');
  
    select REGEXP_COUNT(DUMP(L_FORMATTED_CONTENT, 1016), 'c3')
      into l_length
      from dual;
  
    debug.pr_debug('IF', 'l_length=' || l_length);
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(L_FORMATTED_CONTENT) + l_length);
  
    debug.pr_debug('IF', 'L_CONTENT=' || L_FORMATTED_CONTENT);
  
    UTL_HTTP.WRITE_TEXT(L_HTTP_REQUEST, L_FORMATTED_CONTENT);
  
    UTL_HTTP.WRITE_RAW(L_HTTP_REQUEST,
                       UTL_RAW.CAST_TO_RAW(L_FORMATTED_CONTENT));
  
    L_HTTP_RESPONSE := UTL_HTTP.GET_RESPONSE(L_HTTP_REQUEST);
  
    debug.pr_debug('IF', 'status code=' || L_HTTP_RESPONSE.STATUS_CODE);
  
    L_RESP_OK := FALSE;
    SELECT DECODE(L_HTTP_RESPONSE.STATUS_CODE, 200, 1, 0)
      INTO L_RESP_NUM
      FROM DUAL;
  
    debug.pr_debug('IF', 'l_resp_num=' || L_RESP_NUM);
  
    IF L_RESP_NUM = 1 THEN
      L_RESP_OK := TRUE;
    ELSIF L_RESP_NUM = 0 THEN
      L_RESP_OK := FALSE;
    END IF;
  
    IF L_RESP_OK THEN
      -- PROCESS THE RESPONSE FROM THE HTTP CALL
      BEGIN
        LOOP
          UTL_HTTP.READ_LINE(L_HTTP_RESPONSE, BUFFER);
          BUFFER1 := BUFFER1 || BUFFER;
        END LOOP;
        UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
      EXCEPTION
        WHEN UTL_HTTP.END_OF_BODY THEN
          UTL_HTTP.END_RESPONSE(L_HTTP_RESPONSE);
        WHEN OTHERS THEN
          debug.pr_debug('IF', 'ERROR CODE=' || SQLCODE);
          debug.pr_debug('IF', 'ERROR MESSAGE=' || SQLERRM);
      END;
    
      P_RESPONSE := BUFFER1;
    
      --Get JSON in XML
      L_RESP_IN_XML := IFPKS_PRINCE_JSON_UTILITY.jsonToXMLUtility(P_RESPONSE);
      DBG('L_RESP_IN_XML=' || L_RESP_IN_XML);
    
      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&lt;', '<');
      DBG('ONE STEP DONE AND AFTER UNESCAPE, IT IS =' || L_RESP_IN_XML);
    
      L_RESP_IN_XML := FN_CLOBREPLACE(L_RESP_IN_XML, '&gt;', '>');
      DBG('TWO STEP DONE AND AFTER UNESCAPE, IT IS=' || L_RESP_IN_XML);
    
      DBG('AFTER CUTTING OTHER IRRELEVANT PARTS , IT IS=' || L_RESP_IN_XML);
    
      P_DOCUMENT_XML := XMLTYPE(L_RESP_IN_XML);
    
      P_HIT_STATUS := P_DOCUMENT_XML.EXTRACT('/root/RtnHit/text()')
                      .GETSTRINGVAL;
    
      P_SCAN_ID := P_DOCUMENT_XML.EXTRACT('/root/RtnScanID/text()')
                   .GETSTRINGVAL;
    
      DBG('P_HIT_STATUS OF API-B =' || P_HIT_STATUS);
    
      DBG('P_SCAN_ID OF API-B=' || P_SCAN_ID);
    
      --update response
      IF P_PROD_CHANNEL = 'NCS' THEN
      
        PR_UPDATE_CORAL_NCS_WS_LOG(L_REF,
                                   P_SCAN_ID,
                                   P_HIT_STATUS,
                                   P_RESPONSE);
      
      END IF;
    
      DEBUG.PR_DEBUG('IF', 'buffer1=' || BUFFER1);
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    IF l_resp_ok THEN
      debug.pr_debug('IF', 'OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      debug.pr_debug('IF', 'PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('AC', 'FAILED IN FN_AML_PAYMENT_CALL_B');
      DEBUG.PR_DEBUG('AC',
                     'ERROR CODE IN FN_AML_PAYMENT_CALL_B=' || SQLCODE);
      DEBUG.PR_DEBUG('AC',
                     'ERROR MESSAGE IN FN_AML_PAYMENT_CALL_B=' || SQLERRM);
      RETURN FALSE;
  END FN_AML_PAYMENT_CALL_B;

END IFPKS_NCS_SANCTION_UTILS;
