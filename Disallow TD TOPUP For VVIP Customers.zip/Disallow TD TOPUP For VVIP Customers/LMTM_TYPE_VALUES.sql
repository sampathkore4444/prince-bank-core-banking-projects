insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164296', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164291', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164267', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164833', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164801', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164842', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164841', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164840', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164835', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164822', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164820', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164812', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164808', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000167634', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000166726', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000165558', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000165622', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000164817', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000165447', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000165461', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000166810', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000167755', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_ACC', '000171123', null);

COMMIT;
