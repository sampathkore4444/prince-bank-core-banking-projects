insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00058104', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00083905', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00132174', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00137969', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00138127', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00140126', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00157885', null);

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('TD_TOPUP_DIS_CIF', '00180641', null);

COMMIT;
