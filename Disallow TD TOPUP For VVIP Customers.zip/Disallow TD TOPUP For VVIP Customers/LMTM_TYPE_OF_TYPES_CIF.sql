insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('TD_TOPUP_DIS_CIF', 'Disallow Top-Up For Below CIFS', 'SAMPATH2', 'SAMPATH2', to_date('10-03-2023 17:03:14', 'dd-mm-yyyy hh24:mi:ss'), to_date('10-03-2023 17:03:15', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
