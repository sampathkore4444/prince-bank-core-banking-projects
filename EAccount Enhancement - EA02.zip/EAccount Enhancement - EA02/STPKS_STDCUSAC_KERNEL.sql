CREATE OR REPLACE PACKAGE BODY Stpks_Stdcusac_Kernel AS

  G_UI_NAME VARCHAR2(32767);

  PKG_CUST_NO        VARCHAR2(32767);
  PKG_LINKAGE_REF_NO VARCHAR2(32767);
  PKG_LINK_REF_NO    VARCHAR2(32767);

  G_TEMP_CHECK        STVWS_CHQBK_REQUEST%ROWTYPE;
  G_TEMP_CARD         STVWS_DC_REQUEST%ROWTYPE;
  V_ALW_INV_TRACK     STTM_BANK.ALW_INV_TRACK%TYPE;
  G_CHQ_MASK          STTMS_BRANCH.CHQNO_MASK%TYPE;
  G_PRM_UNIQUE_CHEQUE STTM_BANK.UNIQUE_CHEQUE_NO%TYPE;

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'stpks_stdcusac_Kernel ==>' || P_MSG;
    DEBUG.PR_DEBUG('ST', L_MSG);
  END DBG;

  PROCEDURE PR_LOG_ERROR(P_FUNCTION_ID IN VARCHAR2,
                         P_SOURCE      VARCHAR2,
                         P_ERR_CODE    VARCHAR2,
                         P_ERR_PARAMS  VARCHAR2) IS
  BEGIN
    CSPKS_REQ_UTILS.PR_LOG_ERROR(P_SOURCE,
                                 P_FUNCTION_ID,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS);
  END PR_LOG_ERROR;
  PROCEDURE PR_SKIP_HANDLER(P_STAGE IN VARCHAR2) IS
  BEGIN
    DBG('In Pr_Skip_Handler..');

    IF P_STAGE IN ('POSTTANKQRY') THEN

      STPKS_STDCUSAC_MAIN.PR_SET_ACTIVATE_KERNEL;

    END IF;

  END PR_SKIP_HANDLER;

  FUNCTION FN_UPDATE_ACC_LINKAGE(P_FUNCTION_ID IN VARCHAR2,
                                 P_SOURCE      IN VARCHAR2,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_LINKED_REF_NO STTM_CUST_ACCOUNT_LINKAGES.LINKED_REF_NO%TYPE;
  BEGIN
    DBG('Inside fn_update_acc_linkage');
    DBG('Customer no-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    DBG('Customer ac no-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('pkg_cust_no-->' || PKG_CUST_NO);

    DELETE FROM CSTBS_RELATIONSHIP_LINKAGE
     WHERE BRANCH = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
       AND CUSTOMER = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
       AND REF_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to update Sttm_cust_account_linkage ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_UPDATE_ACC_LINKAGE;

  FUNCTION FN_POST_BUILD_TYPE_STRUCTURE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_ADDL_INFO        IN CSPKS_REQ_GLOBAL.TY_ADDL_INFO,
                                        P_STDCUSAC         IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_CRM_STDCUSAC  STPKS_STDCUSAC_MAIN.TY_STDCUSAC;
    L_REQUEST_NO    VARCHAR2(20);
    L_STATUS        VARCHAR2(20);
    L_POST_UPL_STAT VARCHAR2(10) := 'U';
    L_ON_OVD_ACTION VARCHAR2(10) := 'E';
    L_BULK_UPLOAD   BOOLEAN := FALSE;

    L_TANKING CHAR;
  BEGIN

    DBG('In Fn_Post_Build_type_structure..');

    IF P_SOURCE = 'EBODIRECT' AND P_SOURCE_OPERATION = 'ModifyCustAcc' THEN
      L_CRM_STDCUSAC  := P_STDCUSAC;
      L_POST_UPL_STAT := CSPKS_REQ_GLOBAL.FN_GET_POST_UPL_STAT();
      L_ON_OVD_ACTION := CSPKS_REQ_GLOBAL.FN_GET_ON_OVERRIDE_ACTION();
      L_BULK_UPLOAD   := CSPKS_REQ_GLOBAL.FN_GET_BULK_UPLOAD();
      CSPKS_REQ_GLOBAL.PR_BACKUP;
      CSPKS_REQ_GLOBAL.PR_SET_POST_UPL_STAT('A');
      CSPKS_REQ_GLOBAL.PR_SET_ON_OVERRIDE_ACTION('I');
      CSPKS_REQ_GLOBAL.PR_SET_BULK_UPLOAD(TRUE);
      CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(FALSE);
      CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := CSPKS_REQ_GLOBAL.P_QUERY;
      IF NOT STPKS_STDCUSAC_MAIN.FN_MAIN(P_SOURCE,
                                         P_SOURCE_OPERATION,
                                         P_FUNCTION_ID,
                                         CSPKS_REQ_GLOBAL.P_QUERY,
                                         CSPKS_REQ_WRAPPER.G_MULTI_TRIP_ID,
                                         L_REQUEST_NO,
                                         P_STDCUSAC,
                                         L_STATUS,
                                         P_ERR_CODE,
                                         P_ERR_PARAMS) THEN
        DBG('Failed in Fn_main..');
        CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := P_ACTION_CODE;
        RETURN FALSE;
      ELSIF L_STATUS = 'F' THEN
        CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := P_ACTION_CODE;
        RETURN FALSE;
      END IF;
      CSPKS_REQ_GLOBAL.G_HEADER('ACTION') := P_ACTION_CODE;
      CSPKS_REQ_GLOBAL.G_RES := '';
      CSPKS_REQ_GLOBAL.PR_RESTORE;
      CSPKS_REQ_GLOBAL.PR_SET_BUILD_RESP(TRUE);
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION     := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA        := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.COUNTRY_CODE;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1     := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2     := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3     := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4     := L_CRM_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4;
      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO       := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
                                                          0) + 1;
    END IF;

    P_STDCUSAC.TY_CSCOFACM.V_CSTBS_EXT_WS_MASTER.KEY_ID := P_STDCUSAC.TY_CSCOFACM.V_CSTBS_EXT_WS_MASTER.KEY_ID ||
                                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE IS NOT NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT IS NOT NULL THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_END_DATE   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_END_DATE;
      END IF;
    END IF;

    DBG('p_Source' || P_SOURCE);
    DBG('p_Action_Code' || P_ACTION_CODE);
    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = 'AUTH' THEN
      BEGIN
        SELECT ACCOUNT_CLASS, CUST_NO, CCY
          INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          SELECT NVL(TANK_MODIFICATIONS, 'N')
            INTO L_TANKING
            FROM SMTBS_MENU
           WHERE FUNCTION_ID = P_FUNCTION_ID;
          IF L_TANKING = 'Y' THEN
            BEGIN
              SELECT CHAR_FLD_6, CHAR_FLD_4, CHAR_FLD_5, DATE_FLD_1
                INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE
                FROM STTBS_RECORD_LOG
               WHERE KEY_ID =
                     '~STTM_CUST_ACCOUNT~' ||
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Invalid account no. not assinging anything. will fail in vals');
            END;
          ELSE
            DBG('Invalid account no. not assinging anything. will fail in vals');
          END IF;
      END;
    END IF;

    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others Of stpks_stdcusac_Kernel.Fn_Post_Build_type_structure ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_BUILD_TYPE_STRUCTURE;

  FUNCTION FN_PRECHECKMAND_CALLS(P_FUNCTION_ID IN VARCHAR2,
                                 P_SOURCE      IN VARCHAR2,
                                 P_ACTION_CODE IN VARCHAR2,
                                 P_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ERR_CODE    IN OUT VARCHAR2,
                                 P_ERR_PARAMS  IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    Z               NUMBER := 1;
    L_PREV_CUSTOMER STTMS_CUSTOMER.CUSTOMER_NO%TYPE;

    L_RECOMPUTE_MATDT STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
    L_MATURITY_DATE   ICTM_ACC.MATURITY_DATE%TYPE;

    L_REL    SVTM_JH_TEMPTBL.RELATION%TYPE;
    L_JHCOD1 STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;

    L_CUST_ACC_MASK VARCHAR2(20);
    L_INILEN        NUMBER;
    L_FINLEN        NUMBER;
    L_DOLLAR_LEN    NUMBER;

    L_MATURITY_DATE_BK DATE;

    L_DAYS   NUMBER := 0;
    L_MONTHS NUMBER := 0;
    L_YEARS  NUMBER := 0;

    L_SECTORCODE DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;

    L_MULTI_CURRENCY      VARCHAR2(20);
    L_COUNT_1             NUMBER;
    L_COUNT_2             NUMBER;
    L_MULTI_CURRENCY_FLAG VARCHAR2(1);

  BEGIN
    DBG('Inside fn_precheckmand_calls');
    DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

    IF (P_ACTION_CODE IN ('DEFAULT', CSPKS_REQ_GLOBAL.P_COPY)

       OR
       (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND P_SOURCE <> 'FLEXCUBE'))

       AND P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL

     THEN
      BEGIN
        SELECT CUSTOMER_ACC_MASK
          INTO L_CUST_ACC_MASK
          FROM STTMS_ACC_PARAM
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('IN no_data_found exception ' || SQLERRM);
          SELECT CUSTOMER_ACC_MASK
            INTO L_CUST_ACC_MASK
            FROM STTMS_ACC_PARAM
           WHERE BRANCH_CODE = '***';
        WHEN OTHERS THEN
          DBG('Failed while fetching mask details ' || SQLERRM);
          RETURN FALSE;
      END;

      DBG('Account Class' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);

      BEGIN
        SELECT MULTI_CURRENCY
          INTO L_MULTI_CURRENCY_FLAG
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        DBG('multi_currency' || L_MULTI_CURRENCY_FLAG);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('IN no_data_found exception ' || SQLERRM);
          L_MULTI_CURRENCY_FLAG := 'N';
        WHEN OTHERS THEN
          DBG('In WOT of fn_other_defaults with: ' || SQLERRM ||
              ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;

      P_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT')(1)('MULTI_CURRENCY') := L_MULTI_CURRENCY_FLAG;

      IF L_MULTI_CURRENCY_FLAG = 'Y' THEN
        BEGIN
          SELECT MULTI_CCY_ACC_MASK

            INTO P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD94
            FROM STTM_MULTICCY_ACC_PARAM
           WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

          DBG('MULTI_CCY_ACC_MASK' ||
              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD94);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('IN no_data_found exception ' || SQLERRM);
            SELECT MULTI_CCY_ACC_MASK

              INTO P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD94
              FROM STTM_MULTICCY_ACC_PARAM
             WHERE BRANCH_CODE = '***';

            DBG('MULTI_CCY_ACC_MASK in bank level' ||
                P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD94);
          WHEN OTHERS THEN
            DBG('Failed while fetching mask details ' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;

      DBG('l_cust_acc_mask---->' || L_CUST_ACC_MASK);
      L_INILEN     := NVL(NVL(LENGTH(L_CUST_ACC_MASK), 0), 0);
      L_FINLEN     := NVL(NVL(LENGTH(REPLACE(L_CUST_ACC_MASK, '$', '')), 0),
                          0);
      L_DOLLAR_LEN := L_INILEN - L_FINLEN;
      IF L_DOLLAR_LEN > LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY) THEN
        DBG('Currency parameter in Account mask greater than Selected currency length');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-ACC-803',
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
      END IF;

      IF REGEXP_COUNT(L_CUST_ACC_MASK, 'L', 1, 'i') >
         LENGTH(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS) THEN
        DBG('Account Class parameter Account mask greater than Selected account class length');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-ACC-802',
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_COPY THEN
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.DELETE;

        P_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.DELETE;
        P_STDCUSAC.V_STTMS_CUSTAC_TXNCODE.DELETE;

        P_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.DELETE;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL      := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL      := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE := NULL;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE := NULL;

      END IF;

    END IF;

    IF P_ACTION_CODE = 'DEFAULT' THEN
      DBG('Calling fn_acccls_pickup');
      DBG('Before Default, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL THEN

        PR_LOG_ERROR(P_FUNCTION_ID,
                     P_SOURCE,
                     'ST-MAN01',
                     '@STTMS_CUST_ACCOUNT.CUST_NO');
        RETURN FALSE;
      END IF;

      SELECT FN_GET_UDF_VAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO)
        INTO P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD2
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

      SELECT FN_GET_UDF_VAL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO)
        INTO P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD68
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

      DBG('Initialized the acc mask with the UDF value....' ||
          P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD2);

      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_ACCCLS_PICKUP(P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      P_SOURCE) THEN
        DBG('fn_acccls_pickup has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('After Default, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('Total documents defaulted for the account->' ||
          P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);

      DBG('Going to do operations on temp table for DEFAULT action');
      BEGIN
        DELETE FROM SVTM_JH_TEMPTBL
         WHERE ACC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Nothing to delete');
      END;

      BEGIN
        DBG('Going to insert in SVTM_JH_TEMPTBL');
        INSERT INTO SVTM_JH_TEMPTBL
        VALUES
          (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
           'Authorized Signatory',
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Not able to insert');
      END;

    END IF;

    IF P_ACTION_CODE = 'EXTDEFAULT' THEN
      DBG('EXTDEFAULT');
      DBG('Before Extdefault, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_ACCCLS_PICKUP(P_FUNCTION_ID,
                                                      P_STDCUSAC,
                                                      P_SOURCE,
                                                      TRUE) THEN
        DBG('fn_acccls_pickup has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('After Extdefault, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    END IF;

    IF P_ACTION_CODE = 'DEFAULT' THEN
      IF P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT = 0 THEN
        FOR T IN (SELECT A.*
                    FROM CSTB_RELATIONSHIP_LINKAGE A
                   WHERE REF_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
                     AND CUSTOMER = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
                     AND RELATIONSHIP IN ('PRIMARY', 'primary', 'Primary')
                  UNION (SELECT B.*
                          FROM CSTB_RELATIONSHIP_LINKAGE B
                         WHERE INHERIT = 'Y'
                           AND REF_NO =
                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO)) LOOP
          P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z).CUSTOMER := T.CUSTOMER;
          P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z).RELATIONSHIP := T.RELATIONSHIP;
          P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z).INHERIT := T.INHERIT;
          DBG('customer in le -->' || P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z)
              .CUSTOMER);
          DBG('relationship in le -->' || P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z)
              .RELATIONSHIP);
          DBG('inherit in le -->' || P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(Z)
              .INHERIT);
          Z := Z + 1;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT > 0 THEN
        FOR L_ACC_LINKED_ENTITY IN P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.FIRST .. P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.LAST LOOP
          DBG('Inside Linked Entity assignment');
          IF P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(L_ACC_LINKED_ENTITY)
           .RELATIONSHIP IN ('PRIMARY', 'primary', 'Primary') AND P_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(L_ACC_LINKED_ENTITY)
             .CUSTOMER != P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
            DBG('Inside condition of PRIMARY Relationship');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC141', '');
          END IF;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'ACCVAL' THEN
      DBG('ACCVAL');
      DBG('Before Acc Gen, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('Msk acc: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD2);

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NULL THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD2;
      END IF;

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NULL THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD68;
      END IF;
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO IS NULL THEN
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD55;
      END IF;
      DBG('p_Stdcusac.v_Sttms_Cust_Account.Cust_Ac_No' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('p_Stdcusac.v_Sttms_Cust_Account.MULTI_CCY_AC_NO' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);

      DBG('Calling stpkss_stdcusac_utils_0.fn_accgen to validate that account');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_ACCGEN(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('fn_accgen has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('After Acc Gen, Account No: ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

      DBG('After Acc Gen, multi currency account number : ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);

      DBG('Going to do operations on temp table');
      BEGIN
        DELETE FROM SVTM_JH_TEMPTBL
         WHERE ACC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Nothing to delete');
      END;
      BEGIN
        DBG('Going to insert in SVTM_JH_TEMPTBL');
        INSERT INTO SVTM_JH_TEMPTBL
        VALUES
          (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
           'Authorized Signatory',
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Not able to insert');
      END;

    END IF;

    DBG('After Acc Gen, multi currency account number_NEW : ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);

    IF P_ACTION_CODE = 'DEFAULT' OR
       (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND P_SOURCE <> 'FLEXCUBE') OR
       (P_ACTION_CODE = 'MODIFY' AND
       PKG_CUST_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO) THEN

      DBG('MISPKP--> Assigning the mandatory fields');

      P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD33   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT_1
          FROM STTM_MULTI_CCY_ACCNT_MASTER
         WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

      END;

      IF L_COUNT_1 <> 0 THEN
        DBG('Multi currency account already exists for the chosen pair of customer and account_class');
        PR_LOG_ERROR(P_FUNCTION_ID,
                     'FLEXCUBE',
                     'ST-MCA-001',
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
      END IF;
      DBG('l_count_1' || L_COUNT_1);

      IF NOT STPKS_STDCUSAC_UTILS_0.FN_PICKUP_MIS(P_FUNCTION_ID,
                                                  P_STDCUSAC.TY_MICACCTM,
                                                  FALSE,
                                                  FALSE) THEN
        DBG('MISPKP--> FAILED');
      END IF;

    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL AND
       P_ACTION_CODE = 'BPELVALIDATE' THEN
      DBG('BPEL Validations');
      DBG('Action is BPELVALIDATE and custno is null... Defaulting walkin_customer');
      SELECT WALKIN_CUSTOMER
        INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
        FROM STTM_BRANCH
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      DBG('Customer: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG(P_ACTION_CODE);
      DBG('Make the pks of the unpicked subsystems null');

      DBG('After Acc Gen, multi currency account number_NEW : ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);

      IF NOT STPKS_STDCUSAC_UTILS_0.FN_UNPICKED_SUBSYS(P_FUNCTION_ID,
                                                       P_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_0.fn_unpicked_subsys has returned false');
        RETURN FALSE;
      END IF;

      IF P_STDCUSAC.V_STTMS_BIC_CODE.COUNT > 0 THEN
        FOR I IN P_STDCUSAC.V_STTMS_BIC_CODE.FIRST .. P_STDCUSAC.V_STTMS_BIC_CODE.LAST LOOP
          P_STDCUSAC.V_STTMS_BIC_CODE(I).AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_STDCUSAC.V_STTMS_BIC_CODE(I).GL_CUST := 'A';
          P_STDCUSAC.V_STTMS_BIC_CODE(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        END LOOP;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW AND
         (P_SOURCE <> 'FLEXCUBE' OR
         NVL(CSPKS_CSDXLUPD_UTILS.G_XLUPD, '*.*') = 'CSDXLUPD') THEN
        DBG('Calling stpkss_stdcusac_utils_0.fn_acccls_pickup for web services');

        IF NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53, 0) <> 0 OR
           NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) <> 0 OR
           NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) <> 0 THEN
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53,
                                                          0);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                                                          0);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                                                          0);
        END IF;

        DBG('Changing maturity date and next maturity date as tenor is changed');

        BEGIN
          SELECT RECOMPUTE_MAT_DATE
            INTO L_RECOMPUTE_MATDT
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        EXCEPTION
          WHEN OTHERS THEN
            L_RECOMPUTE_MATDT := 'N';
            DBG('no data found for aclass ' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
        END;
        DBG('l_recompute_matdt ->' || L_RECOMPUTE_MATDT);
        DBG('p_stdcusac.v_ictms_acc.roll_tenor_pref ->' ||
            P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);

        IF L_RECOMPUTE_MATDT = 'Y' AND
           P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF NOT IN ('A', 'I') THEN
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF := 'L';
          DBG('p_stdcusac.v_ictms_acc.roll_tenor_pref inside ->' ||
              P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
        ELSE
          P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF := 'A';
        END IF;

        IF NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) <> 0 OR
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) <> 0 OR
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) <> 0 THEN
          DBG('Original Tenor detrails not equal to zero hence assigning');
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                          0);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                          0);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                          0);

          DBG('#24821961:Interest start date ' ||
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
          DBG('#24821961:Account open date ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

          L_MATURITY_DATE := ADD_MONTHS(NVL(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                        P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                        (P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                             P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

          DBG('#24821961:Interest start date ' ||
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

          DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
              P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
          DBG('l_maturity_date-->' || L_MATURITY_DATE);
          IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
            L_MATURITY_DATE_BK := L_MATURITY_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                        L_MATURITY_DATE) THEN
              DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
              L_MATURITY_DATE := L_MATURITY_DATE_BK;
            END IF;
          END IF;

          IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL THEN
            IF L_MATURITY_DATE <> P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
              DBG('Maturity date given is not correct');
              RETURN FALSE;
            END IF;
          END IF;
        END IF;

        DBG('#24821961 :Maturity date ' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        IF P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NULL THEN

          DBG('Maturity date is null and hence assigning');
          IF P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE IS NULL THEN
            DBG('interest start date is null hence assigning');
            IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NULL THEN
              DBG('acc opening date is null hence assigning app date' ||
                  GLOBAL.APPLICATION_DATE);
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := GLOBAL.APPLICATION_DATE;
            ELSE
              DBG('assigining accont open date to int start date' ||
                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
            END IF;
          END IF;

          DBG('#24821961 2nd:Interest start date ' ||
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
          DBG('#24821961 2nd:Account open date ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

          P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := ADD_MONTHS(NVL(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                                             P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                                             (P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                                                  P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

          DBG('#24821961 2nd :Interest start date ' ||
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

          DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Maturity_Date-->' ||
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

          DBG('p_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
              P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
          DBG('p_Stdcusac.v_Ictms_Acc.Maturity_Date-->' ||
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
          IF NVL(P_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
            L_MATURITY_DATE_BK := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                        P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
              DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_MATURITY_DATE_BK;
            END IF;
          END IF;

        END IF;

        DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Orig_Tenor_Days-->' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);

        DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Orig_Tenor_Months-->' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);

        DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Orig_Tenor_Years-->' ||
            P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);
        IF NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) = 0 AND
           NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) = 0 THEN
          DBG('Original Tenor detrails equal to zero hence ORIG TENOR DAYS-->' ||
              P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
          DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Int_Start_Date-->' ||
              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
          DBG('#24821961 p_Stdcusac.v_Ictms_Acc.Maturity_Date-->' ||
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
          DBG('#24821961 ac_open_date ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -

                                                      NVL(P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := 0;
          P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := 0;
          DBG('#24821961 2nd p_Stdcusac.v_Ictms_Acc.Orig_Tenor_Days-->' ||
              P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);

        END IF;

        DBG('orig tenor days ' || P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
        DBG('orig tenor mon ' || P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);
        DBG('orig tenor years ' || P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);
        DBG('New Maturity date is ' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        DBG('Dep tenor days ' ||
            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53);
        DBG('Dep tenor mon ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52);
        DBG('Dep tenor years ' ||
            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51);
        DBG('New Maturity date is ' ||
            P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          DBG('Calculating next maturity date since auto rollover is Y');
          BEGIN
            SELECT RECOMPUTE_MAT_DATE
              INTO L_RECOMPUTE_MATDT
              FROM STTM_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
          EXCEPTION
            WHEN OTHERS THEN
              L_RECOMPUTE_MATDT := 'N';
              DBG('NO DATA FOUND FOR ACLASS ' ||
                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
          END;
          DBG('l_recompute_matdt--> ' || L_RECOMPUTE_MATDT);
          IF NVL(L_RECOMPUTE_MATDT, 'N') = 'N' THEN
            IF NVL(P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF, '*') <> 'I' THEN
              P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS   := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                              0);
              P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                              0);
              P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS  := NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                              0);
            END IF;
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
          ELSE
            P_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
          END IF;

        END IF;
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                              P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

        IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD71 IS NOT NULL AND
           (P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23 IS NULL OR
           P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25 IS NULL) THEN
          CSPKSS_CLG_SERV.PR_BREAK_ROUTING_NO(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD71,
                                              L_SECTORCODE,
                                              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23,
                                              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25);
          DBG('Clearing Bank p_stdcusac.v_cstbs_ui_columns.char_field23=' ||
              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23);
          DBG('Clearing Branch p_stdcusac.v_cstbs_ui_columns.char_field25=' ||
              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25);
        END IF;

        IF NOT STPKSS_STDCUSAC_UTILS_0.FN_ACCCLS_PICKUP(P_FUNCTION_ID,
                                                        P_STDCUSAC,
                                                        P_SOURCE) THEN
          DBG('fn_acccls_pickup has returned false');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_DEBIT_AMT IS NULL AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INTERIM_CREDIT_AMT IS NOT NULL THEN
      P_ERR_CODE   := 'MS-920-4';
      P_ERR_PARAMS := '';
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'MS-920-4', P_ERR_PARAMS);
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('MODIFY');
      DBG('Doing basic defaults');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_BASIC_DEFAULT(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_basic_default has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND P_SOURCE = 'FCAT' THEN
      DBG('MODIFY 2');
      DBG('Doing Assignment');
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_ASSIGN(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_assign has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'BUILD_SUBSTAT' THEN
      DBG('BUILD_SUBSTAT');
      DBG('Building the initial subsysstat');
      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_BUILD_INITSTAT(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_0.fn_build_initstat has returned false');
        RETURN FALSE;
      END IF;

      DBG('Now going to do operations on Jh_temp table, insert and delete of primary customer and joint holders');
      DBG('Going to do operations on temp table for deleting temp table');
      BEGIN
        DELETE FROM SVTM_JH_TEMPTBL
         WHERE ACC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        DBG('No. of rows deleted is ' || SQL%ROWCOUNT);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Nothing to delete');
      END;
      DBG('Cust_No->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      DBG('Cust_Ac_No-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('branch_code-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('Going to insert in SVTM_JH_TEMPTBL');
      INSERT INTO SVTM_JH_TEMPTBL
      VALUES
        (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
         'Authorized Signatory',
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('COUNT->' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
      IF P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
        FOR I IN P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
          IF (NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE,
                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) <=
             GLOBAL.APPLICATION_DATE) AND
             (NVL(P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                  GLOBAL.APPLICATION_DATE) >= GLOBAL.APPLICATION_DATE) THEN
            L_JHCOD1 := P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                        .JOINT_HOLDER;
            DBG('l_jhcod1->' || L_JHCOD1);
            SELECT DECODE(L_JHCOD1,
                          'CON',
                          'Customer contact person',
                          'CUS',
                          'Custodian',
                          'DEV',
                          'Developer',
                          'GUA',
                          'Guarantor',
                          'GUR',
                          'Guardian',
                          'JAF',
                          'Joint and first',
                          'JAO',
                          'Joint and other',
                          'JOF',
                          'Joint or first',
                          'JOO',
                          'Joint or other',
                          'NOM',
                          'Nominee',
                          'REL',
                          'Related for enquiry',
                          'SOL',
                          'Solicitor',
                          'SOW',
                          'Sole owner',
                          'THR',
                          'Third party',
                          'TRU',
                          'Trustee',
                          'VAL',
                          'Valuer',
                          'POA',
                          'Power of attorney',
                          'Authorized signatory')
              INTO L_REL
              FROM DUAL;
            DBG('l_rel->' || L_REL);
            DBG('Going to insert in SVTM_JH_TEMPTBL2');
            INSERT INTO SVTM_JH_TEMPTBL
            VALUES
              (P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).JOINT_HOLDER_CODE,
               L_REL,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            DBG('Inserted for ::' || P_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                .JOINT_HOLDER_CODE);
          END IF;
        END LOOP;
      END IF;

      IF P_FUNCTION_ID = 'STDCUSAC' OR G_CHILD_FUNCTION THEN
        IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
          FOR LINK_REC IN 1 .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
            BEGIN
              SELECT LIABILITY_NO
                INTO P_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT_LINKAGES')(LINK_REC)('LIAB_NO')
                FROM (SELECT *
                        FROM STVW_JV_CUSTOMER
                       WHERE CUSTOMER_NO =
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
                         AND NVL(CUST_AC_NO,
                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) =
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                         AND PROJECT_ACCOUNT =
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROJECT_ACCOUNT
                       ORDER BY CUSTOMER_NO, PARTY_RATIO DESC)
               WHERE PARTY_ID = P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(LINK_REC)
                    .CUSTOMER_NO
                 AND ROWNUM < 2;
            EXCEPTION
              WHEN OTHERS THEN
                P_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT_LINKAGES')(LINK_REC)('LIAB_NO') := NULL;
                DBG(SQLERRM);
                DBG('Failed in selecting the Desc Fields For  :CUSTOMER_NO');
            END;
          END LOOP;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_COPY THEN
      DBG('COPY');
      DBG('Calling copy_init');

      G_ACTION_CODE := CSPKS_REQ_GLOBAL.P_COPY;

      IF NOT STPKS_STDCUSAC_UTILS_2.FN_COPY_INIT(P_FUNCTION_ID, P_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_copy_init has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('CLOSE');
      DBG('Assigning primary keys');
      DBG('Brn: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('Acc: ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_COPY) THEN
      DBG('here inside branch_code' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('here inside cust_ac_no' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('p_wrk_stdcusac.v_cust_account_linkages.count>>>' ||
          P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
      IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
        DBG('defaulting Branch and Account Starts for linkages');
        FOR I IN P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.FIRST .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.LAST LOOP

          IF P_SOURCE <> 'FLEXCUBE' THEN
            DBG('Source is not flexcube, Hence assigning Null to Branch and Acc');
            P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).BRANCH_CODE := NULL;
            P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).CUST_AC_NO := NULL;

            BEGIN
              SELECT LINKAGE_TYPE
                INTO P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKAGE_TYPE
                FROM STVW_ACC_LINKAGES
               WHERE LINKED_REF_NO = P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                    .LINKED_REF_NO;

            EXCEPTION
              WHEN OTHERS THEN
                P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKAGE_TYPE := NULL;
                DBG(SQLERRM);
                DBG('Failed in selecting linkage_type ');
            END;

          END IF;

          IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).BRANCH_CODE IS NULL THEN
            P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          END IF;
          DBG('here inside branch_code >>' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
              .BRANCH_CODE);
          IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).CUST_AC_NO IS NULL THEN

            P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END IF;

          DBG('here inside cust_ac_no >>' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
              .CUST_AC_NO);
        END LOOP;
      END IF;
    END IF;

    DBG('Total documents defaulted for the account->1' ||
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);
    DBG('fn_precheckmand_calls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_precheckmand_calls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_PRECHECKMAND_CALLS;

  FUNCTION FN_VALIDATE_SALARY_ACCOUNT(P_FUNCTION_ID   IN VARCHAR2,
                                      P_STDCUSAC      IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                      P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                      P_ACTION_CODE   IN VARCHAR2,
                                      P_ERR_CODE      IN OUT VARCHAR2,
                                      P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_COUNT NUMBER;
    I       NUMBER;

    TYPE TY_TB_CATM_AMOUNT_BLOCKS IS TABLE OF CATMS_AMOUNT_BLOCKS%ROWTYPE INDEX BY BINARY_INTEGER;
    P_ERR_COD               ERTBS_MSGS.ERR_CODE%TYPE;
    P_ERR_PARAM             VARCHAR2(255);
    L_REC_CLOSE_SAL_AMT_BLK TY_TB_CATM_AMOUNT_BLOCKS;

    CURSOR CR_CLOSE_SAL_AMT_BLK(L_CUST_AC_NO STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE) IS
      SELECT A.*
        FROM CATMS_AMOUNT_BLOCKS A, CLTBS_AMTBLK_SALARY_MAP B
       WHERE A.ACCOUNT = L_CUST_AC_NO
         AND A.AMOUNT_BLOCK_NO = B.AMOUNT_BLOCK_NO
         AND A.HOLD_CODE IN
             (SELECT HOLD_CODE FROM STTM_HOLD_MASTER WHERE HOLD_TYPE = 'S')
         AND A.AUTH_STAT = 'A'
         AND A.RECORD_STAT = 'O';

  BEGIN
    IF P_ACTION_CODE <> 'NEW' AND
       P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SALARY_ACCOUNT <>
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SALARY_ACCOUNT AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.SALARY_ACCOUNT, 'Y') = 'N' THEN

      BEGIN
        DBG('inside fn_validate_salary_account');
        DBG('p_stdcusac.v_sttms_cust_account.cust_ac_no-->' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        DBG('p_stdcusac.v_sttms_cust_account.cust_no-->' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

        SELECT COUNT(*)
          INTO L_COUNT
          FROM STTMS_CUST_ACCOUNT      A,
               CLTBS_ACCOUNT_MASTER    B,
               CLTB_ACCOUNT_COMPONENTS C
         WHERE A.CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND A.CUST_AC_NO = NVL(C.DR_PROD_AC, C.SVC_ACC_AC)
           AND A.CUST_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND A.CUST_NO = B.CUSTOMER_ID
           AND B.ACCOUNT_NUMBER = C.ACCOUNT_NUMBER
           AND B.BRANCH_CODE = C.BRANCH_CODE
           AND B.LOAN_AGAINST_SAL = 'Y';
        DBG('l_count' || L_COUNT);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG(' inside no_data_found fn_validate_salary_account ' ||
              SQLERRM);
          L_COUNT := 0;
        WHEN OTHERS THEN
          DBG('Oracle Error :' || SQLERRM);
          RETURN FALSE;
      END;

      IF L_COUNT > 0 THEN

        P_ERR_CODE   := 'ST-SAL-001';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        DBG('updating Cltbs_Account_Master');
        BEGIN
          UPDATE CLTBS_ACCOUNT_MASTER
             SET LOAN_AGAINST_SAL = 'N'
           WHERE CUSTOMER_ID = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
             AND LOAN_AGAINST_SAL = 'Y';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG(' inside no_data_found fn_validate_salary_account.Cltbs_Account_Master ' ||
                SQLERRM);

          WHEN OTHERS THEN
            DBG('In WOT of fn_validate_salary_account with:Cltbs_Account_Master ' ||
                SQLERRM || ' and trace: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN FALSE;
        END;

        DBG('updating cstbs_auto_settle_block');
        BEGIN

          UPDATE CSTBS_AUTO_SETTLE_BLOCK
             SET RECOVERY_AGAINST_SAL = 'N'
           WHERE ACCOUNT_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND RECOVERY_AGAINST_SAL = 'Y';
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG(' inside no_data_found fn_validate_salary_account.cstbs_auto_settle_block ' ||
                SQLERRM);

          WHEN OTHERS THEN
            DBG('In WOT of fn_validate_salary_account with:cstbs_auto_settle_block ' ||
                SQLERRM || ' and trace: ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            RETURN FALSE;
        END;

      END IF;

      IF CR_CLOSE_SAL_AMT_BLK%ISOPEN THEN
        CLOSE CR_CLOSE_SAL_AMT_BLK;
      END IF;

      OPEN CR_CLOSE_SAL_AMT_BLK(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      FETCH CR_CLOSE_SAL_AMT_BLK BULK COLLECT
        INTO L_REC_CLOSE_SAL_AMT_BLK;
      CLOSE CR_CLOSE_SAL_AMT_BLK;

      DBG('l_rec_close_sal_amt_blk.COUNT' || L_REC_CLOSE_SAL_AMT_BLK.COUNT);
      IF L_REC_CLOSE_SAL_AMT_BLK.COUNT > 0 THEN

        P_ERR_CODE   := 'ST-SAL-001';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        FOR I IN L_REC_CLOSE_SAL_AMT_BLK.FIRST .. L_REC_CLOSE_SAL_AMT_BLK.LAST LOOP
          DBG('l_rec_close_sal_amt_blk(i).amount_block_no' || L_REC_CLOSE_SAL_AMT_BLK(I)
              .AMOUNT_BLOCK_NO);
          IF NOT CASAPKSS.FN_AMOUNT_BLOCK_SWITCH(GLOBAL.APPLICATION_DATE,
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                 L_REC_CLOSE_SAL_AMT_BLK(I)
                                                 .AMOUNT_BLOCK_NO,
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                 'D',
                                                 P_ERR_COD,
                                                 P_ERR_PARAM) THEN
            DBG('FAILED IN CALL TO CASAPKSS.fn_amount_block_switch');
            RETURN FALSE;
          END IF;

          DBG('updating cltbs_amtblk_salary_map');
          BEGIN
            UPDATE CLTBS_AMTBLK_SALARY_MAP
               SET PROCESSED = 'C'

             WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG(' inside no_data_found fn_validate_salary_account.cltbs_amtblk_salary_map ' ||
                  SQLERRM);

            WHEN OTHERS THEN
              DBG('In WOT of fn_validate_salary_account with:cltbs_amtblk_salary_map ' ||
                  SQLERRM || ' and trace: ' ||
                  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              RETURN FALSE;
          END;

        END LOOP;
      END IF;
    END IF;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_validate_salary_account with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_VALIDATE_SALARY_ACCOUNT;

  FUNCTION FN_POSTDFLTVAL_CALLS(P_FUNCTION_ID   IN VARCHAR2,
                                P_SOURCE        IN VARCHAR2,
                                P_ACTION_CODE   IN VARCHAR2,
                                P_STDCUSAC      IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_PREV_STDCUSAC IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_WRK_STDCUSAC  IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                P_ERR_CODE      IN OUT VARCHAR2,
                                P_ERR_PARAMS    IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_SUBSYSTEM_TY_FLDS GWPKS_UTIL.TY_SUBSYSTEM_FLDS;
    L_EXISTING_MOD      STTMS_CUST_ACCOUNT.MOD_NO%TYPE;
    L_AC_OPEN_DATE      STTMS_CUST_ACCOUNT.AC_OPEN_DATE%TYPE;
    L_DCD               CHAR(1);
    L_COMP_TYPE         CLTBS_ACCOUNT_COMPONENTS.COMPONENT_TYPE%TYPE;
    L_AC_CLASS_TYPE     STTM_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    I                   NUMBER;

    L_FOUND      BOOLEAN := FALSE;
    L_PREV_FOUND BOOLEAN := FALSE;

    L_DESC_VC     STTMS_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_MODULE_CODE VARCHAR2(2);
    L_ROL_RES     NUMBER := 0;

    L_ERR_CODE_LIST VARCHAR2(120);
    L_ERR_COUNT     NUMBER := 0;
    L_ERR_CODE      VARCHAR2(20);
    L_LOV_COUNT     NUMBER;
    L_KEY           VARCHAR2(255);

    CURSOR CR_PRODS(PACLASS VARCHAR2, PCCY VARCHAR2) IS
      SELECT A.PRODUCT_CODE PROD, C.PRODUCT_END_DATE
        FROM CSTMS_PRODUCT C, ICTM_PR_INT_ACLASS A
       WHERE C.PRODUCT_CODE = A.PRODUCT_CODE
         AND C.RECORD_STAT = 'O'
         AND C.ONCE_AUTH = 'Y'
         AND A.ACLASS = PACLASS
         AND A.CCY = PCCY
         AND A.RECORD_STAT = 'N';
    R_PROD CR_PRODS%ROWTYPE;

    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_ERR_CODE1     ERTB_MSGS.ERR_CODE%TYPE;

  BEGIN
    DBG('Inside fn_postdfltval_calls');

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('Account class:' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);

      CVPKS_UTILS.GET_ACCOUNT_CLASS(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                    L_ACC_CLASS_REC,
                                    L_ERR_CODE1);
      L_AC_CLASS_TYPE := L_ACC_CLASS_REC.AC_CLASS_TYPE;
      IF L_AC_CLASS_TYPE IS NULL THEN

        SELECT AC_CLASS_TYPE
          INTO L_AC_CLASS_TYPE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END IF;

      OPEN CR_PRODS(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
      LOOP
        FETCH CR_PRODS
          INTO R_PROD;
        EXIT WHEN CR_PRODS%NOTFOUND;
        IF R_PROD.PRODUCT_END_DATE < GLOBAL.APPLICATION_DATE THEN
          DBG('Product has already expired');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'IC-PROD-16',
                       R_PROD.PROD || '~');
        END IF;
      END LOOP;

      IF P_SOURCE <> 'FLEXCUBE' THEN
        IF NVL(L_AC_CLASS_TYPE, '*') <>
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE, '*') THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACC-805', NULL);
        END IF;

      END IF;

      IF NOT STPKS_ACLASS_TRANSFER.G_ACLASS_TRANSFER THEN
        DBG('In stpks_aclass_transfer.g_aclass_transfer TRUE');
        IF P_FUNCTION_ID = 'STDCUSAC' AND
           P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_CLOSE) THEN
          DBG('Account class validation in Role level');

          SELECT COUNT(1)
            INTO L_ROL_RES
            FROM SMVWS_ROLE_ACCCLASS
           WHERE ACCOUNT_CLASS =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
          IF L_ROL_RES = 0 THEN
            DBG('Account class is restricted for the user ' ||
                GLOBAL.USER_ID);
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-155', NULL);
          END IF;
        END IF;
      END IF;
    END IF;

    DBG('Account No: ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF P_ACTION_CODE IN ('DEFAULT', 'EXTDEFAULT', 'COMPUTE') AND
       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO = 'DUMMY' THEN

      DBG('Setting the Account No from DUMMY back to null');
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := NULL;
    END IF;

    IF P_ACTION_CODE = 'ICPKP' THEN
      DBG('ICPKP');
      DBG('Calling fn_subsys_pkp');
      IF NOT
          STPKSS_STDCUSAC_UTILS_0.FN_PICKUP_IC(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('fn_subsys_pkp has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('BEFORE CHKING account_auto_closed IN REOPEN');
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      DBG('INSIDE account_auto_closed IN REOPEN');
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 := 'Acct Closed';
      UPDATE STTMS_CUST_ACCOUNT
         SET ACCOUNT_AUTO_CLOSED = 'N'

       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

      DBG('UPDATED account_auto_closed IN REOPEN');
    END IF;
    DBG('BEFORE CHKING account_auto_closed IN AUTH,NEW,MODIFY');
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_AUTH) THEN

      DBG('INSIDE account_auto_closed IF LOOP');
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT = 'O' THEN
        UPDATE STTMS_CUST_ACCOUNT
           SET ACCOUNT_AUTO_CLOSED = 'N'

         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

      END IF;
      DBG('UPDATED account_auto_closed');
    END IF;
    DBG('OUTSIDE account_auto_closed IF LOOP');

    DBG('BEFORE account_auto_closed CHK FOR UPLOAD');
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_AUTO_CLOSED = 'Y' THEN
      DBG('Account cannot be Created or Modified with AccountAutoClosed Flag value as Y');
      PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACLOSE', NULL);
      RETURN FALSE;
    END IF;
    DBG('AFTER account_auto_closed CHK FOR UPLOAD');

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_AUTH,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      DBG('p_action_code  ' || P_ACTION_CODE);
      DBG('Deep5 Kernel p_stdcusac' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      DBG('before calling cspkss_tradelicense_eod.pr_cust_tradelicovd');
      CSPKSS_TRADELICENSE_EOD.PR_CUST_TRADELICOVD(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      DBG('After calling cspkss_tradelicense_eod.pr_cust_tradelicovd');
    END IF;

    DBG('PRIV: p_Action_Code : ' || P_ACTION_CODE);
    DBG('TEMP#: cust_no : ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    DBG('PRIV: cust_no : ' ||
        P_WRK_STDCUSAC.V_SVTM_CIF_PRI_CUST.CUSTOMER_NO);
    DBG('PRIV: PRI : ' ||
        P_WRK_STDCUSAC.V_SVTM_CIF_PRI_CUST.PRIVATE_CUSTOMER);

    BEGIN

      SELECT NVL(PRIVATE_CUSTOMER, 'N')
        INTO P_WRK_STDCUSAC.V_SVTM_CIF_PRI_CUST.PRIVATE_CUSTOMER
        FROM STTMS_CUSTOMER
       WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('No Data Found For Private_Customer-->' || SQLERRM);
    END;

    DBG('AFTER: PRI : ' ||
        P_WRK_STDCUSAC.V_SVTM_CIF_PRI_CUST.PRIVATE_CUSTOMER);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DEFAULT THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
      END IF;
      DBG('account open date' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN

      IF L_AC_CLASS_TYPE = 'Y' THEN

        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
        IF P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          DBG('Calculating the  and next maturity date');
          DBG('Next maturity date');
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE +
                                                           P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20;
        END IF;
      END IF;

      DBG('NEW');
      DBG('Deep5 Kernel p_stdcusac' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);
      DBG('Deep6 Kernel p_wrk_stdcusac' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);
      DBG('Deep6 Kernel p_prev_stdcusac' ||
          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_CUST_AC_NO);

      DBG('Picking up unpicked subsystems');

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
      END IF;

      DBG('Checking for account open date here ...' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
      L_AC_OPEN_DATE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;

      DBG('Stat: ' || P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);

      DBG('Saving the Account');
      IF NOT STPKSS_STDCUSAC_UTILS_1.FN_UPLOAD(P_FUNCTION_ID,
                                               P_WRK_STDCUSAC,
                                               P_ACTION_CODE,
                                               P_SOURCE,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
        DBG('stpkss_stdcusac_utils_0.fn_upload has returned false');

        DBG('Subsysstat: ' ||
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);

        RETURN FALSE;
      END IF;

      DBG('Population of the acc_type');
      IF NOT STPKSS_STDCUSAC_UTILS_2.FN_POPULATE_ACC_TYPE(P_FUNCTION_ID,
                                                          P_PREV_STDCUSAC,
                                                          P_WRK_STDCUSAC) THEN
        DBG('fn_populate_acc_type has returned false');
        RETURN FALSE;
      END IF;

      DBG('Checking Account open date here after pick up...' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
      DBG('l_ac_open_date ::' || L_AC_OPEN_DATE);
      IF L_AC_OPEN_DATE <> P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
        DBG('After Pick up date has got changed now... For XML Upload');
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := L_AC_OPEN_DATE;
      END IF;
      DBG('Finally here account Open date = ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    END IF;

    DBG('p_Action_Code' || P_ACTION_CODE);
    DBG('p_stdcusac.v_sttms_cust_account.ONCE_AUTH' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY AND
       NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 IS NULL THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5;
      END IF;

      IF NOT STPKSS_STDCUSAC_UTILS_1.FN_UPLOAD(P_FUNCTION_ID,
                                               P_WRK_STDCUSAC,
                                               P_ACTION_CODE,
                                               P_SOURCE,
                                               P_ERR_CODE,
                                               P_ERR_PARAMS) THEN
        DBG('stpkss_stdcusac_utils_0.fn_upload has returned false');
        DBG('Subsysstat: ' ||
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Validating pospay and MT110 check');
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.MT110_RECON_REQD-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT110_RECON_REQD);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.POSITIVE_PAY_AC-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_NEW) THEN
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MT110_RECON_REQD, 'N') = 'Y' AND
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.POSITIVE_PAY_AC, 'N') = 'Y' THEN
        DBG('Both Positive pay and MT110 cannot be chosen');
        P_ERR_CODE   := 'ST-ACC-302';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('MODIFY');

      IF L_AC_CLASS_TYPE = 'Y' THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
        IF P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          DBG('Calculating the  and next maturity date');
          DBG('Next maturity date');
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE +
                                                           P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20;
        END IF;
      END IF;

      BEGIN
        SELECT DUAL_CCY_DEPOSIT
          INTO L_DCD
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_DCD := 'N';
      END;
      IF L_DCD = 'Y' THEN
        IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'Y' THEN
          IF P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.LINK_CCY OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.CCY_OPTION_PROD OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.EXCH_RATE OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_SETT_ACC <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_SETT_ACC OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_GL <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.LINKED_CCY_GL OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.FIXING_DAYS OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.YLD_ENHANCEMENT <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.YLD_ENHANCEMENT OR
             P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.INCEPTION_FAIR_VALUE <>
             P_PREV_STDCUSAC.V_ICTMS_DCD_MASTER.INCEPTION_FAIR_VALUE THEN
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-DCD-015', '');

          END IF;
        END IF;
      END IF;

      DBG('Checking if the Linkages record has been modified with adding new row');
      DBG('p_wrk_stdcusac.v_cust_account_linkages.count' ||
          P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
      DBG('p_prev_stdcusac.v_cust_account_linkages.COUNT' ||
          P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

      FOR I IN 1 .. P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
        DBG('p_Wrk_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Customer_No-->' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .CUSTOMER_NO);
        DBG('p_Wrk_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linkage_Type-->' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKAGE_TYPE);
        DBG('p_Wrk_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linked_Ref_No-->' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKED_REF_NO);
        DBG('p_Wrk_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linkage_Percentage-->' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKAGE_PERCENTAGE);
        DBG('');
      END LOOP;

      FOR I IN 1 .. P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
        DBG('p_Prev_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Customer_No-->' || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .CUSTOMER_NO);
        DBG('p_Prev_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linkage_Type-->' || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKAGE_TYPE);
        DBG('p_Prev_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linked_Ref_No-->' || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKED_REF_NO);
        DBG('p_Prev_Stdcusac.v_Cust_Account_Linkages(' || I ||
            ').Linkage_Percentage-->' || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .LINKAGE_PERCENTAGE);
        DBG('');
      END LOOP;

      IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 AND
         P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN

        IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT <>
           P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT THEN
          L_FOUND := TRUE;
        END IF;
        IF NOT L_FOUND THEN
          FOR I IN 1 .. P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
            L_FOUND := TRUE;
            FOR J IN 1 .. P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
              IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
               .CUSTOMER_NO || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                 .LINKAGE_TYPE || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                 .LINKED_REF_NO || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                 .LINKAGE_PERCENTAGE = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .CUSTOMER_NO || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .LINKAGE_TYPE || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .LINKED_REF_NO || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .LINKAGE_PERCENTAGE THEN
                DBG('Found the record p_Wrk_Stdcusac...');
                L_FOUND := FALSE;
              END IF;
            END LOOP;
            IF L_FOUND THEN
              EXIT;
            END IF;
          END LOOP;
        END IF;
      END IF;

      DBG('Before sending  to Stpkss_Stdcusac_Utils_2.Fn_Populate_Reinit_Acc');
      IF L_FOUND OR L_PREV_FOUND THEN
        DBG('Inside sending  to Stpkss_Stdcusac_Utils_2.Fn_Populate_Reinit_Acc');
        IF NOT
            STPKSS_STDCUSAC_UTILS_2.FN_POPULATE_REINIT_ACC(P_FUNCTION_ID,
                                                           P_PREV_STDCUSAC,
                                                           P_WRK_STDCUSAC,
                                                           P_ERR_CODE,
                                                           P_ERR_PARAMS) THEN
          DBG('fn_populate_Linkages_type has returned false');
          RETURN FALSE;
        END IF;
      END IF;
      DBG('After sending  to Stpkss_Stdcusac_Utils_2.Fn_Populate_Reinit_Acc');

      DBG('Checking if the Linkages record has been modified with adding new row');
      DBG('p_wrk_stdcusac.v_cust_account_linkages.count' ||
          P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
      DBG('p_prev_stdcusac.v_cust_account_linkages.COUNT' ||
          P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

      DBG('p_wrk_stdcusac-char_field5-->' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
      DBG('p_stdcusac-char_field5->' ||
          P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 IS NULL THEN

        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5;

      END IF;

      DBG('Validating the alt acc no');

      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO IS NOT NULL THEN
        DBG('Value exists for Micacctm so assigning');
        P_WRK_STDCUSAC.TY_MICACCTM := P_STDCUSAC.TY_MICACCTM;
      END IF;
      DBG('Sweep_to_acc_branch stdcusac  - bfr Stpkss_Stdcusac_Utils_2.Fn_Modify_Acc : ' ||
          P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.SWEEP_TO_ACC_BRANCH);
      DBG(' p_stdcusac.ty_iccinstr.v_ictbs_deposit_instruction.deposit_ccy   bfr Stpkss_Stdcusac_Utils_2.Fn_Modify_Acc ' ||
          P_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEPOSIT_CCY);

      P_WRK_STDCUSAC.TY_ICCINSTR := P_STDCUSAC.TY_ICCINSTR;

      DBG(' p_stdcusac.ty_iccinstr.v_ictbs_deposit_instruction.deposit_ccy   bfr Stpkss_Stdcusac_Utils_2.Fn_Modify_Acc ' ||
          P_WRK_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.DEPOSIT_CCY);

      P_WRK_STDCUSAC.TY_ICCINTPO := P_STDCUSAC.TY_ICCINTPO;

      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10 IS NULL THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD10;
      END IF;
      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 IS NULL THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD13;
      END IF;
      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12 IS NULL THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD12;
      END IF;
      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD3 IS NULL THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD3 := P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD3;
      END IF;

      IF NOT STPKSS_STDCUSAC_UTILS_2.FN_MODIFY_ACC(P_FUNCTION_ID,
                                                   P_PREV_STDCUSAC,
                                                   P_WRK_STDCUSAC,
                                                   P_ACTION_CODE,
                                                   P_SOURCE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('stpkss_stdcusac_utils_0.fn_validate_altacc has returned false');
        RETURN FALSE;
      END IF;

      DBG('Validating the offset details on Modification');
      DBG('Calling stpks_stdcusac_utils_1.fn_validate_offsetdet');
      IF NOT STPKS_STDCUSAC_UTILS_1.FN_VALIDATE_OFFSETDET(P_FUNCTION_ID,
                                                          P_PREV_STDCUSAC,
                                                          P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_1.fn_validate_offsetdet has returned false');
        RETURN FALSE;
      END IF;

      DBG('Population of the acc_type');
      IF NOT STPKSS_STDCUSAC_UTILS_2.FN_POPULATE_ACC_TYPE(P_FUNCTION_ID,
                                                          P_PREV_STDCUSAC,
                                                          P_WRK_STDCUSAC) THEN
        DBG('fn_populate_acc_type has returned false');
        RETURN FALSE;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'NEW' OR (P_ACTION_CODE = 'MODIFY' AND L_FOUND) THEN
      FOR I IN 1 .. P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
        IF P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKED_REF_NO IS NOT NULL THEN

          SELECT COUNT(1)
            INTO L_LOV_COUNT
            FROM STVW_ACC_LINKAGES Z, STTM_CUSTOMER A
           WHERE A.CUSTOMER_NO = P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                .CUSTOMER_NO
             AND Z.LINKAGE_TYPE = P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                .LINKAGE_TYPE
             AND Z.LIABILITY_NO = A.LIABILITY_NO
             AND COALESCE(Z.CUSTOMER_NO, A.CUSTOMER_NO) = A.CUSTOMER_NO
             AND LINKED_REF_NO = P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                .LINKED_REF_NO;

          IF L_LOV_COUNT = 0 THEN
            DBG('Invalid Value For The Field  :LINKED_REF_NO:' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                .LINKED_REF_NO);
            L_KEY := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                      G_UI_NAME,
                                                      'STTMS_CUST_ACCOUNT_LINKAGES.CUSTOMER_NO') || '-' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                    .CUSTOMER_NO || ':' ||
                     CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                      G_UI_NAME,
                                                      'STTMS_CUST_ACCOUNT_LINKAGES.LINKAGE_TYPE') || '-' ||
                     CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                      G_UI_NAME,
                                                      'STTMS_CUST_ACCOUNT_LINKAGES.LINKAGE_TYPE.' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                                      .LINKAGE_TYPE) || ':' ||
                     CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                      G_UI_NAME,
                                                      'STTMS_CUST_ACCOUNT_LINKAGES.LINKED_REF_NO') || '-' || P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                    .LINKED_REF_NO;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-VALS-013',
                         P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                         .LINKED_REF_NO ||
                          '~@STTMS_CUST_ACCOUNT_LINKAGES.LINKED_REF_NO' || '~' ||
                          L_KEY || '~@STTMS_CUST_ACCOUNT_LINKAGES');
          END IF;
        END IF;
        IF (P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKAGE_TYPE = 'F') THEN
          IF NOT
              ELPKS_FACILITY_SERVICE.FN_VALIDATE_RESTRICTIONS(P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES           (I)
                                                              .LINKED_REF_NO,
                                                              P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES           (I)
                                                              .CUSTOMER_NO,
                                                              P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES           (I)
                                                              .BRANCH_CODE,
                                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,

                                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                              0,
                                                              L_ERR_CODE_LIST) THEN
            DBG('l_err_code_list -->' || L_ERR_CODE_LIST);
            L_ERR_COUNT := NVL(REGEXP_COUNT(L_ERR_CODE_LIST, '~', 1), 0);
            DBG('l_err_count -->' || L_ERR_COUNT);
            FOR L_INDEX IN 1 .. L_ERR_COUNT LOOP
              L_ERR_CODE := CSPKES_MISC.FN_GETPARAM(L_ERR_CODE_LIST,
                                                    L_INDEX,
                                                    '~');
              DBG('l_err_code -->' || L_ERR_CODE);
              IF NOT (L_ERR_CODE IS NULL) THEN
                IF (L_ERR_CODE = 'EL-PRDES-01') THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
                ELSIF (L_ERR_CODE = 'EL-RES-003') THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                               .CUSTOMER_NO);
                ELSIF (L_ERR_CODE = 'EL-RES-001') THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,
                               P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                               .BRANCH_CODE);
                ELSIF (L_ERR_CODE = 'EL-RES-002') THEN
                  PR_LOG_ERROR(P_FUNCTION_ID,
                               'FLEXCUBE',
                               L_ERR_CODE,

                               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
                ELSE
                  PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
                END IF;
              END IF;
            END LOOP;
          END IF;
        END IF;
      END LOOP;
    END IF;

    IF P_ACTION_CODE = 'MISPKP' THEN
      DBG('MISPKP');
      DBG('Brn: ' ||
          P_WRK_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE ||
          ' Acc: ' ||
          P_WRK_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO ||
          ' Untref: ' ||
          P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.UNIT_REF_NO);

      DBG('Subsys string: ' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);

      IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 IS NULL THEN
        DBG('in fn_pickup_ic since subsystem status is null, Setting all sub ststems statuses as @del ');
        L_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('UDFDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('CHGCONDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('CHGDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('INTDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('AUTODEPDETAILS').STAT := 'D';
        L_SUBSYSTEM_TY_FLDS('LINKEDENT').STAT := 'D';
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 := STPKS_STDCUSAC_UTILS_0.FN_BUILD_SUBSYSSTAT(P_FUNCTION_ID,
                                                                                                    L_SUBSYSTEM_TY_FLDS);
        DBG('after setting, Subsys string: ' ||
            P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
      END IF;

      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                      L_SUBSYSTEM_TY_FLDS) THEN
        DBG('fn_parse_subsysstats has returned false');
        RETURN FALSE;
      END IF;
      DBG('MIS SUBSYSSTAT: ' || L_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);

      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_PICKUP_MIS(P_FUNCTION_ID,
                                               P_WRK_STDCUSAC.TY_MICACCTM) THEN
        DBG('fn_pickup_mis has returned false');
        RETURN FALSE;
      END IF;
      DBG('MIS pickup success');

      DBG('Setting the Subsys stat of INTDETAILS to U');
      L_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT := 'U';
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 := STPKS_STDCUSAC_UTILS_0.FN_BUILD_SUBSYSSTAT(P_FUNCTION_ID,
                                                                                                  L_SUBSYSTEM_TY_FLDS);
      DBG('Finally... MIS SUBSYSSTAT: ' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
    END IF;

    IF P_ACTION_CODE = 'QRYAMTDT' THEN
      DBG('Populating the Amounts and Dates screen');
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_POPULATE_AMTDT(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_populate_amtdt has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_COPY THEN
      DBG('COPY');
      DBG('Calling stpks_stdcusac_utils_2.fn_copy_acc');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_COPY_ACC(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_0.fn_copy_acc has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      DBG('DELETE');
      DBG('Calling stpks_stdcusac_utils_2.fn_delete_acc');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_DELETE_ACC(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_delete_acc has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      DBG('REOPEN');
      DBG('Calling stpks_stdcusac_utils_2.fn_reopen_acc');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_REOPEN_ACC(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_reopen_acc has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('CLOSE');

      DBG('setting the bean flag to true coz of the dirty commit in ic pkg');
      GWPKS_UTIL.G_FROM_BEAN := TRUE;

      STPKS_STDCUSAC_UTILS_2.G_CR_USER    := GLOBAL.USER_ID;
      STPKS_STDCUSAC_UTILS_2.G_AC_CLOSURE := TRUE;

      IF P_SOURCE = 'FLEXCUBE' THEN
        P_WRK_STDCUSAC := P_STDCUSAC;
      END IF;

      DBG('Brn: ' ||
          P_WRK_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE);
      DBG('Acc: ' ||
          P_WRK_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO);

      DBG('p_wrk_stdcusac.v_sttms_cust_account.branch_code' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('p_wrk_stdcusac.v_sttms_cust_account.cust_ac_no' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

      P_WRK_STDCUSAC.TY_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      P_WRK_STDCUSAC.TY_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

      DBG('Assigning the close mode variables into corresponding work variables');
      P_WRK_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE := P_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE;

      DBG('p_wrk_stdcusac.ty_stcaclos.v_STTMS_CUST_ACCOUNT.branch_code: ' ||
          P_WRK_STDCUSAC.TY_STCACLOS.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      DBG('p_wrk_stdcusac.ty_stcaclos.v_STTMS_CUST_ACCOUNT.cust_ac_no: ' ||
          P_WRK_STDCUSAC.TY_STCACLOS.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

      IF NOT STPKS_STDCUSAC_UTILS_2.FN_CLOSE_ACC(P_FUNCTION_ID,
                                                 P_WRK_STDCUSAC.TY_STCACLOS,
                                                 P_SOURCE,
                                                 P_ACTION_CODE) THEN
        DBG('stpks_stdcusac_utils_2.fn_close_acc has returned false');
        RETURN FALSE;
      END IF;

      DBG('Passbook number is - ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_NUMBER);
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PASSBOOK_NUMBER IS NOT NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'GW-CA-011', '');
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 := 'Acct Closed';
        IF NOT GWPKS_PASSBOOKSTATUSCHANGE.FN_CLOSE_PASSBOOK(P_WRK_STDCUSAC,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('Failed in updating the passbook details because of ');
          RETURN FALSE;
        END IF;
      END IF;

      DBG('Incrementing the mod no');
      BEGIN
        SELECT MOD_NO
          INTO L_EXISTING_MOD
          FROM STTMS_CUST_ACCOUNT
         WHERE BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in sttms_cust_account for Mod no');
          L_EXISTING_MOD := 0;
      END;

      DBG('l_existing_mod: ' || L_EXISTING_MOD);
      DBG('Sent in mod: ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO);
      IF L_EXISTING_MOD > 0 THEN
        IF L_EXISTING_MOD >= P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO THEN
          DBG('Incrementing the mod no in the work variable');
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO + 1;
        END IF;
      END IF;
      DBG('Sent in mod: ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO);

      DBG('BRN  ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE ||
          'CUST AC NO' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      BEGIN
        SELECT COMPONENT_TYPE, MODULE_CODE
          INTO L_COMP_TYPE, L_MODULE_CODE
          FROM CLTBS_ACCOUNT_COMPONENTS A, CLTB_ACCOUNT_MASTER B
         WHERE A.DR_ACC_BRN =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND A.DR_PROD_AC =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND B.BRANCH_CODE = A.BRANCH_CODE
           AND B.ACCOUNT_NUMBER = A.ACCOUNT_NUMBER
           AND COMPONENT_TYPE = 'S'
           AND B.ACCOUNT_STATUS = 'A'
           AND B.MATURITY_DATE >= GLOBAL.APPLICATION_DATE;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COMP_TYPE := '#';
          DBG('No data found in sttms_cust_account for Mod no');
      END;

      IF NVL(L_COMP_TYPE, '#') = 'S' THEN
        IF L_MODULE_CODE = 'CI' THEN
          DBG('SAvings account linked to Islamic finance cannot be closed duing tenor');
          P_ERR_CODE   := 'CI-SINT10';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        ELSE
          DBG('savings account linked at loan should not be allowed to CLOSE during the tenor of the loan');
          P_ERR_CODE   := 'CL-SINT04';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'POPDT' THEN
      DBG('POPDT');
      DBG('Calling stpkss_stdcusac_utils_0.fn_popdt');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_POPDT(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpkss_stdcusac_utils_0.fn_popdt has returned false');
        NULL;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'MINBALCHECK' THEN
      DBG('MINBALCHECK');
      DBG('Calling stpkss_stdcusac_utils_0.fn_minbal_check');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_MINBAL_CHECK(P_FUNCTION_ID,
                                                     P_WRK_STDCUSAC) THEN
        DBG('stpkss_stdcusac_utils_0.fn_minbal_check has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    BEGIN
      L_DESC_VC := P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT') (1)
                   ('CUSTNAME');
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('The action code is not Query so system will never populated the value');
        DBG('And so we pick from sttm_customer');
        BEGIN

          SELECT FULL_NAME
            INTO L_DESC_VC
            FROM STTM_CUSTOMER

           WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Luck.. this time it has failed/.. no customer name');
            DBG('Error is ' || SQLERRM);
        END;
        DBG('The customer name is null inside if ');
        DBG('l_Desc_Vc : ' || L_DESC_VC);
        P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT')(1)('CUSTNAME') := L_DESC_VC;
      WHEN OTHERS THEN
        DBG(SQLERRM);
        DBG('Failed in Populating Description Field   :CUSTNAME');
    END;

    DBG('Calling fn_validate_salary_account');
    IF NOT FN_VALIDATE_SALARY_ACCOUNT(P_FUNCTION_ID,
                                      P_STDCUSAC,
                                      P_PREV_STDCUSAC,
                                      P_ACTION_CODE,
                                      P_ERR_CODE,
                                      P_ERR_PARAMS) THEN
      DBG('fn_validate_salary_account has returned false');
      RETURN FALSE;
    END IF;

    DBG('prev customer ->' || P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    DBG('curr customer =>' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    IF P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <>
       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
      STPKSS_STDCUSAC_UTILS_0.PR_PICKUP_NEW_SIG_DET(P_WRK_STDCUSAC);
    END IF;

    DBG('fn_postdfltval_calls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_postdfltval_calls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POSTDFLTVAL_CALLS;

  FUNCTION FN_PROCESS_DATE(P_SOURCE           IN VARCHAR2,
                           P_SOURCE_OPERATION IN VARCHAR2,
                           P_FUNCTION_ID      IN VARCHAR2,
                           P_ACTION_CODE      IN VARCHAR2,
                           P_CHILD_FUNCTION   IN VARCHAR2,
                           P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_PREV_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                           P_ERR_CODE         IN OUT VARCHAR2,
                           P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;
    L_MATURITY_DATE      DATE;
  BEGIN
    DBG('Start of Fn_Process_Date');
    DBG('p_Action_Code = ' || P_ACTION_CODE);

    IF P_ACTION_CODE IN ('CHANGEMATDT', CSPKS_REQ_GLOBAL.P_NEW) AND
       P_SOURCE IN ('FLEXCUBE', 'FLEXBRANCH') AND
       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' THEN

      DBG('Changing maturity date and next maturity date as tenor is changed');
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53,
                                                            0);
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                                                            0);
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                                                            0);
      IF P_ACTION_CODE = 'CHANGEMATDT' THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                                                            0);
      END IF;
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := ADD_MONTHS((P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE),
                                                             P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 +
                                                             (P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 * 12)) +
                                                  P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53;

      DBG('p_Wrk_Stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
      DBG('p_Wrk_Stdcusac.v_ictms_acc.maturity_date-->' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53, 0) = 0 THEN
        L_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                    P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
          DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_MATURITY_DATE;
        END IF;
      END IF;

      DBG('New Maturity date is ' || P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      IF P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'A' AND
         P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS    := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                             0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS  := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                             0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS   := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                             0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
      ELSE
        P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
      END IF;
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
    END IF;
    IF P_ACTION_CODE = 'CHANGETENOR' THEN
      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) = 0 AND
         NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) = 0 THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                          P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 := 0;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 := 0;
      ELSE
        DBG('IN Else');
        BEGIN
          WITH TTL_MONTHS AS
           (SELECT P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                   ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                              TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                   P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE))) RES,
                   TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                        P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE)) MON
              FROM DUAL)
          SELECT CASE
                   WHEN RES >= 0 THEN
                    TRUNC(MON / 12)
                   ELSE
                    TRUNC((MON - 1) / 12)
                 END YEARS,
                 CASE
                   WHEN RES >= 0 THEN
                    MOD(MON, 12)
                   ELSE
                    MOD(MON - 1, 12)
                 END MONTHS,
                 CASE
                   WHEN RES >= 0 THEN
                    P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                    ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                               MON)
                   ELSE
                    P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                    ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                               MON - 1)
                 END DAYS
            INTO P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                 P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                 P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53
            FROM TTL_MONTHS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed to change tenor but continuing');
        END;
      END IF;
      P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53,
                                                          0);
      P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                                                          0);
      P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                                                          0);

      DBG('Maturity_Date = ' || P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

      IF P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'A' AND
         P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS   := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS  := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                            0);

      END IF;
    END IF;

    IF P_FUNCTION_ID IN
       ('STDCUSTD', 'IADCUSTD', 'STDTDSIM', 'TDMM', 'IPTDMM') AND
       P_ACTION_CODE IN
       ('NEW', 'MODIFY', 'COMPUTE', 'CHANGETENOR', 'CHANGEMATDT') THEN
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) > 30 AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) +
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC015', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) > 11 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC004', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC013', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC014', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC012', NULL);
      END IF;
    END IF;

    IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') AND
       P_ACTION_CODE IN ('NEW', 'MODIFY', 'COMPUTE') THEN
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC013', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC014', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) < 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC012', NULL);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS, 0) > 11 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC004', '');
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) > 30 AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS, 0) +
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS, 0) > 0 THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC015', '');
      END IF;
    END IF;

    BEGIN
      SELECT NVL(RECOMPUTE_MAT_DATE, 'N')
        INTO L_RECOMPUTE_MAT_DATE
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        L_RECOMPUTE_MAT_DATE := 'N';
        DBG('Failed to fetch recompute maturity date flag from account class but continuing');
    END;

    IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') AND
       P_ACTION_CODE IN ('NEW', 'MODIFY') AND
       NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER, 'N') = 'Y' THEN

      IF (P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'L' AND
         L_RECOMPUTE_MAT_DATE = 'N') OR (P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' AND
         L_RECOMPUTE_MAT_DATE = 'Y') THEN
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'IC-MSC011', '');
      END IF;
    END IF;

    IF P_ACTION_CODE = 'COMPUTE' THEN
      IF L_RECOMPUTE_MAT_DATE = 'Y' AND
         P_PREV_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'L' THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF := 'L';
        DBG('#27404929 p_stdcusac.v_ictms_acc.roll_tenor_pref ' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
      ELSIF P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
            (L_RECOMPUTE_MAT_DATE = 'N' OR L_RECOMPUTE_MAT_DATE IS NULL) THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF := 'A';
      END IF;

    END IF;

    DBG('P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER AFTER' ||
        P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER);
    DBG('P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF AFTER' ||
        P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);

    DBG('End of Fn_Process_Date');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_postdfltval_calls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_PROCESS_DATE;

  FUNCTION FN_PREUPLD_CALLS(P_FUNCTION_ID  IN VARCHAR2,
                            P_SOURCE       IN VARCHAR2,
                            P_ACTION_CODE  IN VARCHAR2,
                            P_WRK_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_IC_INCLUSION STTMS_ACCOUNT_CLASS.IC_INCLUSION%TYPE;
    L_AUTO_USER    SMTB_USER.AUTO_AUTH%TYPE;
    L_DCD_FLAG     STTMS_ACCOUNT_CLASS.DUAL_CCY_DEPOSIT%TYPE;
    L_ONCE_AUTH    STTMS_CUST_ACCOUNT.ONCE_AUTH%TYPE;

  BEGIN
    DBG('Inside fn_preupld_calls');
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    IF P_ACTION_CODE IN

       ('DEFAULT',
        'EXTDEFAULT',
        'ICPKP',
        'ACCGEN',
        'MISPKP',
        'QRYAMTDT',
        'POPDT',
        'COMPUTE') THEN
      DBG('Skipping sys op');
      STPKS_STDCUSAC_MAIN.PR_SET_SKIP_SYS;
    END IF;

    DBG('Deleting ictm_acc variables');
    DBG('Acc class: ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    BEGIN
      SELECT NVL(IC_INCLUSION, 'N')
        INTO L_IC_INCLUSION
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('WOT of ic_inclusion selection');
        L_IC_INCLUSION := 'N';
    END;
    DBG('l_ic_inclusion: ' || L_IC_INCLUSION);
    IF L_IC_INCLUSION = 'N' THEN
      DBG('Beginning deletion');
      P_WRK_STDCUSAC.V_ICTMS_ACC.BRN := NULL;
      P_WRK_STDCUSAC.V_ICTMS_ACC.ACC := NULL;
    END IF;

    BEGIN
      SELECT DUAL_CCY_DEPOSIT
        INTO L_DCD_FLAG
        FROM STTMS_ACCOUNT_CLASS
       WHERE ACCOUNT_CLASS =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    EXCEPTION
      WHEN OTHERS THEN
        L_DCD_FLAG := 'N';
    END;
    DBG('dual ccy deposit flag: ' || L_DCD_FLAG);
    IF NVL(L_DCD_FLAG, 'N') = 'N' THEN
      DELETE ICTMS_DCD_MASTER
       WHERE TD_BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND TD_ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      DBG('rowcount: ' || SQL%ROWCOUNT);

      IF P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.TD_BRN IS NOT NULL AND
         P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.TD_ACC IS NOT NULL THEN
        P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.TD_BRN := NULL;
        P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.TD_ACC := NULL;
        P_WRK_STDCUSAC.V_ICTMS_DCD_MASTER.TD_CCY := NULL;
      END IF;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN
      DBG('AUTH');
      DBG('Calling Auth package');
      DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH <> 'Y' THEN
        IF NOT
            STPKS_STDCUSAC_UTILS_1.PR_ACCOUNT_OPENING(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC,
                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
          DBG('account opening charges have failed');
          RETURN FALSE;
        END IF;
      END IF;

      IF NOT STPKS_STDCUSAC_UTILS_2.FN_AUTH_CUSTACC(P_FUNCTION_ID,
                                                    P_WRK_STDCUSAC,
                                                    P_ACTION_CODE,
                                                    P_SOURCE) THEN
        DBG('stpks_stdcusac_utils_2.fn_auth_custacc has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_preupld_calls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_preupld_calls with: ' || SQLERRM || ' and trace: ' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_PREUPLD_CALLS;

  FUNCTION FN_POSTUPLD_CALLS(P_FUNCTION_ID  IN VARCHAR2,
                             P_SOURCE       IN VARCHAR2,
                             P_ACTION_CODE  IN VARCHAR2,
                             P_WRK_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ERR_CODE     IN OUT VARCHAR2,
                             P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside fn_postupld_calls');

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_AUTH) THEN
      DBG(P_ACTION_CODE);
      DBG('Calling stpks_stdcusac_utils_1.fn_postupld_valdn');
      IF NOT STPKS_STDCUSAC_UTILS_1.FN_POSTUPLD_VALDN(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC,
                                                      P_ACTION_CODE,
                                                      P_SOURCE) THEN
        DBG('stpks_stdcusac_utils_1.fn_postupld_valdn has returned false');
        RETURN FALSE;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        DBG('Calling fn_post_update_table for NEW');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_POST_UPDATE_TABLE(P_FUNCTION_ID,
                                                        P_WRK_STDCUSAC) THEN
          DBG('fn_post_update_table has returned false');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        DBG('Calling stpks_stdcusac_utils_1.fn_insert_replines_detail');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_INSERT_REPLINES_DETAIL(P_FUNCTION_ID,
                                                             P_WRK_STDCUSAC) THEN
          DBG('stpks_stdcusac_utils_1.fn_insert_replines_detail has returned false');
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('CLOSE');
      DBG('Calling stpks_stdcusac_utils_2.fn_post_close_acc');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_POST_CLOSE_ACC(P_FUNCTION_ID,
                                                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN
        DBG('stpks_stdcusac_utils_2.fn_post_close_acc has returned false');
        RETURN FALSE;
      END IF;

      DBG('resetting the bean flag to false coz of the dirty commit in ic pkg');
      GWPKS_UTIL.G_FROM_BEAN := FALSE;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_REOPEN THEN
      DBG('REOPEN');
      DBG('Calling stpks_stdcusac_utils_2.fn_reopen_acc for post upld');
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_REOPEN_ACC(P_FUNCTION_ID,
                                                  P_WRK_STDCUSAC,
                                                  TRUE) THEN
        DBG('stpks_stdcusac_utils_2.fn_reopen_acc for post upld has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('fn_postupld_calls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_postupld_calls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POSTUPLD_CALLS;

  FUNCTION FN_POSTQUERYCALLS(P_FUNCTION_ID  IN VARCHAR2,
                             P_WRK_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC)
    RETURN BOOLEAN IS
    L_OD_FACILITY STTMS_ACCOUNT_CLASS.OVERDRAFT_FACILITY%TYPE;
    L_GET_MAT     BOOLEAN := FALSE;
    L_STR         VARCHAR2(4000);
  BEGIN
    DBG('Inside fn_postquerycalls');

    DBG('Defaulting OD facility in Post query for the account class: ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NOT NULL THEN
      BEGIN
        SELECT NVL(OVERDRAFT_FACILITY, 'N')
          INTO L_OD_FACILITY
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_OD_FACILITY := 'N';
        WHEN OTHERS THEN
          L_OD_FACILITY := 'N';
      END;
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD44 := L_OD_FACILITY;
    END IF;

    DBG('SD Reference number defaulting with acc no: ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    BEGIN
      SELECT SD_REF_NO
        INTO P_WRK_STDCUSAC.V_SFTMS_CUST_SUBSCRIPTION.SD_REF_NO
        FROM SFTM_CUST_SUBSCRIPTION
       WHERE TD_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND TD_BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('No data found for SD ref no');
        NULL;
    END;
    DBG('SD Ref no: ' ||
        P_WRK_STDCUSAC.V_SFTMS_CUST_SUBSCRIPTION.SD_REF_NO);

    DBG('Customer: ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

    DBG('fn_postquerycalls returning true');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT of fn_postquerycalls with: ' || SQLERRM ||
          ' and trace: ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-OTHR-001', '');
      RETURN FALSE;
  END FN_POSTQUERYCALLS;

  FUNCTION FN_PRE_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                  P_SOURCE_OPERATION IN VARCHAR2,
                                  P_FUNCTION_ID      IN VARCHAR2,
                                  P_ACTION_CODE      IN VARCHAR2,
                                  P_CHILD_FUNCTION   IN VARCHAR2,
                                  P_STDCUSAC         IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                  P_ERR_CODE         IN OUT VARCHAR2,
                                  P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    L_COUNT    NUMBER;
    L_INDEX    NUMBER;
    L_KEY_ID   STTBS_RECORD_MASTER.KEY_ID%TYPE;
    RM_CUST_NO STTM_CUST_ACCOUNT.CUST_NO%TYPE;

    L_SUBSYSTEM_TY_FLDS GWPKS_UTIL.TY_SUBSYSTEM_FLDS;

    L_FUNCTION_ID   VARCHAR2(8);
    L_ACCOUNT_CLASS STTM_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;

    L_FROZEN              STTM_CUSTOMER.FROZEN%TYPE;
    L_DECEASED            STTM_CUSTOMER.DECEASED%TYPE;
    L_WHEREABOUTS_UNKNOWN STTM_CUSTOMER.WHEREABOUTS_UNKNOWN%TYPE;

    L_RATE_COUNT          NUMBER;
    L_MULTI_CURRENCY_FLAG VARCHAR2(1);
    L_MULTI_CURRENCY      VARCHAR2(20);

    L_LOC_CODE      STTMS_CUST_ACCOUNT.LOCATION%TYPE;
    L_DEFAULT_MEDIA STTMS_CUST_ACCOUNT.MEDIA%TYPE;

    L_CAMT_STMTT_CYCLE VARCHAR2(1);
    L_CAMT_FREQUENCY   NUMBER;
    L_CAMT_FIXED_TIME  NUMBER;
    
    

  BEGIN
    DBG('Rate Flag :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG ||
        '~Pool code :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);
    L_COUNT := P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;

    DBG('p_Stdcusac.v_Sttms_Cust_Account.Account_Type  ' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE);
   
  --sampath starts for EA02
    IF p_Action_Code IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_AUTH) THEN
    
      IF p_stdcusac.v_sttms_cust_account.ACCOUNT_CLASS = 'EA02' THEN
      
        BEGIN
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_NO = p_stdcusac.v_sttms_cust_account.CUST_NO
             AND A.ACCOUNT_CLASS = 'EA02'
             AND A.RECORD_STAT = 'O'
             AND A.ONCE_AUTH = 'Y';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        IF L_COUNT >=5 THEN
        
          Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-001', NULL);
        
          RETURN FALSE;
        
        END IF;
		
		 IF p_stdcusac.v_sttms_cust_account.JOINT_AC_INDICATOR = 'J' THEN
          
        Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-002', NULL);
        
          RETURN FALSE;
      
      END IF;
    
    END IF;
    --sampath ends for EA02
     
  
   IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE <> 'Y' THEN
      DBG('Going to delete v_ictms_pcpayout_details and v_ictms_bcpayout_details');
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_PCPAYOUT_DETAILS := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_BCPAYOUT_DETAILS := NULL;
      P_STDCUSAC.TY_ICCINTPO.V_ICTMS_BCPAYOUT_DETAILS := NULL;

      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_DETAILS  := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTD_ACCOUNT  := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC       := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_PCPAYOUT_DETAILS := NULL;

      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDPCPAYOUT := NULL;
      P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDBCPAYOUT := NULL;
      IF (P_STDCUSAC.TY_ICCTDFPO.V_CHILDTDPAYOUT_DETAILS.COUNT > 0) THEN
        P_STDCUSAC.TY_ICCTDFPO.V_CHILDTDPAYOUT_DETAILS.DELETE;
      END IF;
      IF (P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_UDEVALS.COUNT > 0) THEN
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_UDEVALS.DELETE;
      END IF;
      IF (P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_EFFDT.COUNT > 0) THEN
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_EFFDT.DELETE;
      END IF;
      IF (P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_PR.COUNT > 0) THEN
        P_STDCUSAC.TY_ICCTDFPO.V_ICTMS_CHILDTDACC_PR.DELETE;
      END IF;

      DBG('After delete v_ictms_pcpayout_details and v_ictms_bcpayout_details');
    END IF;

    DBG('p_source--->' || P_SOURCE);
    IF P_SOURCE <> 'FLEXCUBE' THEN
      GLOBAL.PKG_IS_TXN_VIA_GW := 'Y';

      IF P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        BEGIN
          SELECT LOC_CODE, DEFAULT_MEDIA
            INTO L_LOC_CODE, L_DEFAULT_MEDIA
            FROM STTM_CUSTOMER A, STTMS_ACCADDR_LOCTYPE B
           WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
             AND B.LOCATION = A.LOC_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            L_LOC_CODE      := NULL;
            L_DEFAULT_MEDIA := NULL;
        END;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION,
                                                        L_LOC_CODE);
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA    := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA,
                                                        L_DEFAULT_MEDIA);
        DBG('p_Stdcusac.v_sttms_cust_account.location :- ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION);
        DBG('p_Stdcusac.v_sttms_cust_account.media :- ' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA);
      END IF;

    END IF;

    P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ORG_FUNC_ID := P_FUNCTION_ID;

    DBG('In Fn_Pre_Check_Mandatory');

    PKG_CUST_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    DBG('p_stdcusac.v_cust_account_linkages.COUNT-->' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    IF P_ACTION_CODE = 'MODIFY' THEN

      BEGIN
        SELECT NVL(FROZEN, 'N'),
               NVL(DECEASED, 'N'),
               NVL(WHEREABOUTS_UNKNOWN, 'N')
          INTO L_FROZEN, L_DECEASED, L_WHEREABOUTS_UNKNOWN
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('NO data found Exception');
      END;

      IF L_FROZEN = 'Y' OR L_DECEASED = 'Y' OR L_WHEREABOUTS_UNKNOWN = 'Y' THEN
        DBG('Customer is Frozen or Deceased or Whereabouts Unknown.Hence Account details cannot be Modified');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-ACC-578', '');
        RETURN FALSE;
      END IF;

      BEGIN
        SELECT CUST_NO,
               ACCOUNT_CLASS

              ,
               DORMANCY_DATE,
               C.AC_STAT_DORMANT

          INTO PKG_CUST_NO,
               L_ACCOUNT_CLASS

              ,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE

              ,
               P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT

          FROM STTMS_CUST_ACCOUNT B, STTM_ACCOUNT_BALANCE C
         WHERE

         B.CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND B.BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND C.CUST_AC_BRN = B.BRANCH_CODE
         AND C.CUST_AC_NO = B.CUST_AC_NO

        ;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_KEY_ID := '~STTM_CUST_ACCOUNT~' ||
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
          BEGIN
            SELECT CHAR_FLD_4
              INTO PKG_CUST_NO
              FROM STTBS_RECORD_MASTER
             WHERE KEY_ID = L_KEY_ID;
          EXCEPTION
            WHEN OTHERS THEN
              PKG_CUST_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
          END;
        WHEN OTHERS THEN
          PKG_CUST_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      END;

      DBG('old customer is    ' || PKG_CUST_NO);
      DBG('new customer is    ' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      IF PKG_CUST_NO <> P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
        IF NOT CSPKSS_ACC_SERVICE.FN_VALIDATE_CUST_CHANGE(PKG_CUST_NO,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
          DBG('fn_validate_cust_change returned false');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;
      END IF;

      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                           L_ACCOUNT_CLASS);
    END IF;

    P_STDCUSAC.TY_STCOSWP.V_STTMS_CUST_ACCOUNT.CCY           := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    P_STDCUSAC.TY_STCOSWP.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'Y' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST = 'Y' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N' THEN
      DBG('chq_book_facility is yes');
      BEGIN
        SELECT NVL(ALW_INV_TRACK, 'N')
          INTO V_ALW_INV_TRACK
          FROM STTMS_BANK
         WHERE RECORD_STAT = 'O'
           AND AUTH_STAT = 'A'
           AND ONCE_AUTH = 'Y'
           AND ROWNUM = 1;
      EXCEPTION

        WHEN NO_DATA_FOUND THEN
          P_ERR_CODE   := 'ST-BRN04';
          P_ERR_PARAMS := '';

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;

        WHEN OTHERS THEN
          DBG('no bank exists!!!');
      END;
    END IF;
    DBG('v_alw_inv_track ' || V_ALW_INV_TRACK);

    IF V_ALW_INV_TRACK = 'Y' THEN
      DBG('cheque_book_type ' ||
          P_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHEQUE_BOOK_TYPE);
      DBG('v_alw_inv_track ' || V_ALW_INV_TRACK);
      IF P_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHEQUE_BOOK_TYPE IS NULL THEN
        P_ERR_CODE   := 'CS-IRA001';
        P_ERR_PARAMS := '@v_stvws_chqbk_request.cheque_book_type';
        RETURN FALSE;
      END IF;
      IF P_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES IS NULL THEN
        P_ERR_CODE   := 'CS-IRA001';
        P_ERR_PARAMS := '@v_stvws_chqbk_request.CHECK_LEAVES';
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Total documents defaulted for the account->' ||
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);
    DBG('Action: ' || P_ACTION_CODE);
    DBG('Subsysstat: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);

    DBG('Calling fn_precheckmand_calls');
    IF NOT FN_PRECHECKMAND_CALLS(P_FUNCTION_ID,
                                 P_SOURCE,
                                 P_ACTION_CODE,
                                 P_STDCUSAC,
                                 P_ERR_CODE,
                                 P_ERR_PARAMS) THEN
      DBG('fn_precheckmand_calls has returned false');
      RETURN FALSE;
    END IF;

    DBG('ACTION:' || P_ACTION_CODE);

    IF P_ACTION_CODE NOT IN (CSPKS_REQ_GLOBAL.P_QUERY, 'QRYAMTDT', 'POPDT') THEN

      DBG('ACCOUNT NO:' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);

      IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                             NULL,
                                             GLOBAL.CURRENT_BRANCH,

                                             'N',
                                             P_ERR_PARAMS,
                                             P_ERR_CODE) THEN

        DBG('failed in cspks_staff_restr.fn_check_cust');
        DBG('user dosent have access on this customer:' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        RETURN FALSE;
      END IF;

      IF NOT CSPKS_CROSS_RM_RESTR.FN_CHECK_ACCESS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                  P_ERR_PARAMS,
                                                  P_ERR_CODE) THEN
        DBG('failed in cspks_cross_rm_restr.fn_check_access');
        DBG('user dosent have access on this customer:' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        RETURN FALSE;
      END IF;

    ELSIF P_ACTION_CODE IN ('QRYAMTDT') THEN

      DBG('in else');

      IF NOT CSPKS_STAFF_RESTR.FN_CHECK_CUST(NULL,
                                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                             GLOBAL.CURRENT_BRANCH,
                                             'Y',
                                             P_ERR_PARAMS,
                                             P_ERR_CODE) THEN

        DBG('failed in cspks_staff_restr.fn_check_cust');
        DBG('user dosent have access on this account:' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        RETURN FALSE;
      END IF;

      DBG('account no-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('branch code-->' || P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      BEGIN
        SELECT CUST_NO
          INTO RM_CUST_NO
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RM_CUST_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      END;
      DBG('cust no-->' || RM_CUST_NO);

      IF NOT CSPKS_CROSS_RM_RESTR.FN_CHECK_ACCESS(RM_CUST_NO,
                                                  P_ERR_PARAMS,
                                                  P_ERR_CODE) THEN
        DBG('failed in cspks_cross_rm_restr.fn_check_access');
        DBG('user dosent have access on this customer:' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        RETURN FALSE;
      END IF;

    END IF;

    IF P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT <> 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME.COUNT LOOP
        P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).MESSAGE_TYPE := '942';

        P_STDCUSAC.V_ACCOUNT_REPORT_GEN_TIME(I).SERIAL_NO := I;

      END LOOP;
    END IF;
    IF P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT <> 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_REPORT_GEN_TIME__GEN1.COUNT LOOP
        P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).MESSAGE_TYPE := '941';

        P_STDCUSAC.V_REPORT_GEN_TIME__GEN1(I).SERIAL_NO := I;

      END LOOP;
    END IF;

    IF P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT LOOP
        P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_CHG_CONSOL(I).PROD := P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD;
      END LOOP;
    END IF;

    DBG('Subsysstat##: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
    DBG('Total documents defaulted for the account->1' ||
        P_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);

    IF P_SOURCE <> 'FLEXCUBE' AND P_FUNCTION_ID = 'IADCUSTD' AND
       P_ACTION_CODE = 'MODIFY' THEN
      DBG('p_Stdcusac.v_sttms_cust_account.cust_ac_no :' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('p_Stdcusac.v_sttms_cust_account.branch_code :' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
      IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN

        DBG(' p_stdcusac.v_ICTMS_TDPAYout_DETAILS.COUNT ' ||
            P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT);
        FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO := I;
        END LOOP;
      END IF;

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS = 'N' OR
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS IS NULL THEN
        DBG('Entered If');
        SELECT MUDARABAH_ACC_CLASS, AC_CLASS_TYPE
          INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS,
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END IF;
    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0 THEN
      FOR I IN P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.FIRST .. P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.LAST LOOP
        P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(I).SEQNO := I;
      END LOOP;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW) THEN
      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32 := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

      BEGIN
        SELECT MULTI_CURRENCY
          INTO L_MULTI_CURRENCY_FLAG
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END;

      DBG('L_MULTI_CURRENCY_FLAG' || L_MULTI_CURRENCY_FLAG);
      IF L_MULTI_CURRENCY_FLAG = 'Y' THEN
        G_MULTI_CURRENCY := STPKS_STDCUSAC_UTILS_0.FN_MULTI_CURRENCY_CHECK(P_FUNCTION_ID,
                                                                           P_STDCUSAC,
                                                                           L_MULTI_CURRENCY);

        IF G_MULTI_CURRENCY = TRUE THEN

          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          DBG('p_stdcusac.v_sttms_cust_account.alt_ac_no' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ALT_AC_NO);
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT       := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION         := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH         := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT        := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE := 'N';

          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY        := 'N';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST          := 'N';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.LODGEMENT_BOOK_FACILITY     := 'N';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_REQUIRED := 'N';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEVEL    := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_REORDER_CHECK_LEAVES   := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_1            := NULL;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKBOOK_NAME_2            := NULL;

          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CLEARING_AC_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST := 'N';
        END IF;
      END IF;

      IF NOT
          STPKS_STDCUSAC_UTILS_0.FN_PARSE_SUBSYSSTATS(P_FUNCTION_ID,
                                                      P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5,
                                                      L_SUBSYSTEM_TY_FLDS) THEN
        DBG('fn_parse_subsysstats has returned false');
        RETURN FALSE;
      END IF;
      DBG('MISDETAILS: ' || L_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT);

      DBG('HERE p_micacctm.v_mitb_class_mapping.rate_flag : ' ||
          P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG);
      DBG('HERE p_micacctm.v_mitb_class_mapping.pool_code : ' ||
          P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);

      IF L_SUBSYSTEM_TY_FLDS('MISDETAILS')
       .STAT <> 'U' AND
          (NVL(P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG, 'P') = 'P' AND
           P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE IS NULL) THEN
        DBG('MIS Pickup');

        DBG('CHAR 33 ' ||
            P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD33);
        DBG('MICACCTM BRANCH CODE ' ||
            P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO  := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD33   := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        IF NOT STPKS_STDCUSAC_UTILS_0.FN_PICKUP_MIS(P_FUNCTION_ID,
                                                    P_STDCUSAC.TY_MICACCTM,
                                                    TRUE,
                                                    FALSE) THEN
          DBG('fn_pickup_mis has returned false');
          RETURN FALSE;
        ELSE
          DBG('fn_pickup_mis has returned true');
          L_SUBSYSTEM_TY_FLDS('MISDETAILS').STAT := 'U';
          P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5 := STPKS_STDCUSAC_UTILS_0.FN_BUILD_SUBSYSSTAT(P_FUNCTION_ID,
                                                                                                  L_SUBSYSTEM_TY_FLDS);
        END IF;
      END IF;

      IF P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CUSTOMER IS NULL THEN
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CUSTOMER := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      END IF;

    ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32 := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      DBG('p_Stdcusac.ty_micacctm.v_cstb_ui_columns.char_field32 is ' ||
          P_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32);
    END IF;

    IF P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
      FOR I IN 1 .. P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT LOOP
        P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).SEQNO := I;
      END LOOP;
    END IF;

    DBG('BEFORE KEY ID PRECHECK' ||
        P_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);

    P_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || ':' ||
                                                              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    DBG('RETRO_12_3_25900387');

    DBG('AFTER KEY ID PRECHECK IS' ||
        P_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);

    BEGIN
      P_STDCUSAC.DESC_FIELDS('STTMS_ACC_NOTICE_PREF')(1)('CCY') := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    EXCEPTION
      WHEN OTHERS THEN
        DBG(SQLERRM);
        DBG('Failed in Populating Description Field   :CCY');
    END;

    FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT LOOP
      IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RATE_CODE IS NOT NULL THEN
        SELECT COUNT(*)
          INTO L_RATE_COUNT
          FROM ICVWS_RES_ICRATES
         WHERE BRANCH_CODE = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).BRN
           AND RATE_CODE = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RATE_CODE;

        IF L_RATE_COUNT = 0 THEN
          DBG('This Rate Code has not been maintained for this branch');
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       'ST-IC0013',
                       P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I).RATE_CODE);
        END IF;
      END IF;
    END LOOP;

    DBG('Pre_chnl_Brn ' ||
        P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    IF P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NULL THEN
      P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    END IF;
    IF P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NULL THEN
      P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    END IF;
    IF P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL THEN
      P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.CUST_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    END IF;
    IF P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NULL THEN
      P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    END IF;
    DBG('Post_chnl_Brn  ' ||
        P_STDCUSAC.TY_STCCHNLM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);

    DBG('p_Stdcusac.v_cstbs_ui_columns.CHAR_FIELD54' ||
        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD54);
    IF (P_SOURCE <> 'FLEXCUBE') THEN
      IF P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD54 IS NOT NULL THEN
        BEGIN
          SELECT ADDRESS_LINE1,
                 ADDRESS_LINE2,
                 ADDRESS_LINE3,
                 ADDRESS_LINE4,
                 PIN_CODE,
                 COUNTRY
            INTO P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS1,
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS2,
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS3,
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ADDRESS4,
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.PINCODE,
                 P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD14

            FROM STTM_ADDRESS
           WHERE ADDRESS_CODE = P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD54;
          DBG('**');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No records present ');
        END;
      END IF;
    END IF;

    IF P_FUNCTION_ID = 'STDCUSAC' AND P_ACTION_CODE IN ('DEFAULT', 'NEW') THEN

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE IS NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FREQUENCY IS NULL AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME IS NULL THEN
        BEGIN
          SELECT CAMT_STMT_CYCLE, CAMT_FREQUENCY, CAMT_FIXED_TIME
            INTO L_CAMT_STMTT_CYCLE, L_CAMT_FREQUENCY, L_CAMT_FIXED_TIME
            FROM STTMS_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('NO_DATA_FOUND IN STTM_ACCOUNT_CLASS FOR ACLS -->' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
        END;

        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE := L_CAMT_STMTT_CYCLE;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FREQUENCY  := L_CAMT_FREQUENCY;
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME := L_CAMT_FIXED_TIME;
        DBG('CAMT_STMT_CYCLE @ account class level-->' ||
            L_CAMT_STMTT_CYCLE);
        DBG('CAMT_STMT_CYCLE @ account level-->' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE);
      END IF;
    END IF;

    DBG('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Pre_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_CHECK_MANDATORY;

  FUNCTION FN_POST_CHECK_MANDATORY(P_SOURCE           IN VARCHAR2,
                                   P_SOURCE_OPERATION IN VARCHAR2,
                                   P_FUNCTION_ID      IN VARCHAR2,
                                   P_ACTION_CODE      IN VARCHAR2,
                                   P_CHILD_FUNCTION   IN VARCHAR2,
                                   P_PK_OR_FULL       IN VARCHAR2 DEFAULT 'FULL',
                                   P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                   P_ERR_CODE         IN OUT VARCHAR2,
                                   P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

    P_ACCT_TYPE VARCHAR2(1);
    L_COUNT     NUMBER := 0;

    L_AC_CLASS_TYPE STTMS_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_AC_CLASS      STTMS_CUST_ACCOUNT.ACCOUNT_CLASS%TYPE;

    L_MUDARABAH_ACCOUNTS STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS%TYPE;

    L_ONCE_AUTH STTMS_CUST_ACCOUNT.ONCE_AUTH%TYPE;

    L_AUTH STTMS_CUST_ACCOUNT.AUTH_STAT%TYPE;
    L_USER SMTB_USER.USER_ID%TYPE;

    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_ERR_CODE      ERTB_MSGS.ERR_CODE%TYPE;

    L_TANKING_REQD VARCHAR2(1);
    L_COUNT1       NUMBER := 0;

  BEGIN

    DBG('In Fn_Post_Check_Mandatory..');
    DBG('Rate Flag :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG ||
        '~Pool code :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);

    DBG('Action: ' || P_ACTION_CODE);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      DBG('Other user validation begins.');
      DBG('Key id-->''~STTM_CUST_ACCOUNT~' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~');
      BEGIN
        SELECT AUTH_STAT, MAKER_ID
          INTO L_AUTH, L_USER
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT AUTH_STAT, MAKER_ID
              INTO L_AUTH, L_USER
              FROM STTB_RECORD_LOG
             WHERE KEY_ID =
                   '~STTM_CUST_ACCOUNT~' ||
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~'

               AND MOD_NO =
                   (SELECT MAX(MOD_NO)
                      FROM STTB_RECORD_LOG
                     WHERE KEY_ID =
                           '~STTM_CUST_ACCOUNT~' ||
                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~');

          EXCEPTION
            WHEN OTHERS THEN
              DBG('no record in sttb_record_log');

          END;
        WHEN OTHERS THEN
          DBG('No record in Sttm_cust_account');
      END;
      DBG('l_auth-->' || L_AUTH);
      DBG('l_user-->' || L_USER);
      DBG('Current user-->' || GLOBAL.USER_ID);
      IF L_AUTH = 'U' AND L_USER <> GLOBAL.USER_ID THEN
        DBG('Unauthorized account-->' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        DBG('Maker id is not a current user');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-TDM-01', '');

      END IF;
    END IF;

    DBG('#1A Mis brn: ' ||
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('#1A Mis acc: ' ||
        P_STDCUSAC.TY_MICACCTM.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      BEGIN

        CVPKS_UTILS.GET_ACCOUNT_CLASS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                      L_ACC_CLASS_REC,
                                      L_ERR_CODE);
        P_ACCT_TYPE := L_ACC_CLASS_REC.AC_CLASS_TYPE;
        IF P_ACCT_TYPE IS NULL THEN

          SELECT AC_CLASS_TYPE
            INTO P_ACCT_TYPE
            FROM STTMS_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        END IF;

        DBG('p_stdcusac.v_sttms_cust_account.ac_stat_no_dr' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR);
        DBG('p_stdcusac.v_sttms_cust_account.ac_stat_no_cr' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR);
        DBG('p_stdcusac.v_sttms_cust_account.ac_stat_stop_pay' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_STOP_PAY);

        DBG('p_stdcusac.v_sttms_cust_account.ac_stat_dormant' ||
            P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT);

        DBG('p_stdcusac.v_sttms_cust_account.AC_STAT_FROZEN' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_FROZEN);
        DBG('p_stdcusac.v_sttms_cust_account.AC_STAT_DE_POST' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DE_POST);
        DBG('p_stdcusac.v_sttms_cust_account.status_change_automatic' ||
            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_CHANGE_AUTOMATIC);

        IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR = 'Y' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR = 'Y' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_STOP_PAY = 'Y' AND

           P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT = 'Y' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_FROZEN = 'Y' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DE_POST = 'Y' AND
           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_CHANGE_AUTOMATIC = 'Y') THEN

          P_ERR_CODE := 'ST-1208';
          RETURN FALSE;
        END IF;

        DEBUG.PR_DEBUG('ST',
                       'Escrow Transfer Flag' ||
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_TRANSFER);
        DEBUG.PR_DEBUG('ST',
                       'Escrow Transfer Percentage' ||
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_PERCENTAGE);
        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_TRANSFER, 'N') = 'Y' THEN
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
               AND ESCROW_PROCESS = 'N'
               AND ONCE_AUTH = 'Y'
               AND RECORD_STAT = 'O';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              L_COUNT := 0;
          END;
          DBG('l_count  : ' || L_COUNT);
          IF L_COUNT > 0 THEN
            OVPKSS.PR_APPENDTBL('ST-1213', NULL);
          END IF;
          DEBUG.PR_DEBUG('ST',
                         'Validation Checking If Escrow Transfer Applicable');
          IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_PERCENTAGE IS NULL) OR
             (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_AC_NO IS NULL) OR
             (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_BRANCH_CODE IS NULL) THEN
            OVPKS.PR_APPENDTBL('ST-1210', NULL);
          ELSE
            BEGIN
              SELECT COUNT(*)
                INTO L_COUNT
                FROM STTMS_CUST_ACCOUNT
               WHERE ESCROW_AC_NO =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                 AND ONCE_AUTH = 'Y'
                 AND RECORD_STAT = 'O';
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                L_COUNT := 0;
            END;
            DBG('l_count for escrow account  : ' || L_COUNT);
            IF L_COUNT > 0 THEN
              OVPKSS.PR_APPENDTBL('ST-1215', NULL);
            END IF;
          END IF;

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_PERCENTAGE = 0 THEN
            DBG('escrow percentage can not be zero or negative');
            OVPKSS.PR_APPENDTBL('BC-B0002', 'Escrow Percentage');

          END IF;

        ELSE
          DEBUG.PR_DEBUG('ST',
                         'Validation Checking If Escrow Transfer not Applicable');

          IF (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_PERCENTAGE IS NOT NULL) OR
             (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_AC_NO IS NOT NULL) OR
             (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ESCROW_BRANCH_CODE IS NOT NULL) THEN
            OVPKS.PR_APPENDTBL('ST-1211', NULL);
          END IF;
        END IF;

        DBG('SFR 475 TD Value  ' || P_ACCT_TYPE);

        IF P_ACCT_TYPE = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'N' AND
             P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'N' AND
             P_STDCUSAC.V_ICTMS_ACC.MOVE_INT_TO_UNCLAIMED = 'N' AND
             P_STDCUSAC.V_ICTMS_ACC.MOVE_PRIC_TO_UNCLAIMED = 'N' THEN
            DBG('TD Mandatory Check Failed');
            P_ERR_CODE := 'ST-0012';
            RETURN FALSE;
          END IF;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('**', 'In when others TD Mandatory  checks..');
          DEBUG.PR_DEBUG('**', SQLERRM);
          P_ERR_CODE   := 'ST-0012';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
      END;
    END IF;

    IF NOT GLOBALS_FRC_CORE.FN_GET_SMTB_MENU_REC_WRP(P_FUNCTION_ID,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
      DBG('Failed in FRC bec of - ' || P_ERR_CODE);
      DBG('Exception was not raised previously..instead handled..dng the same..');
      L_TANKING_REQD := 'N';
      P_ERR_CODE     := NULL;
      P_ERR_PARAMS   := NULL;
    ELSE
      DBG('Returned success from FRC..');
      L_TANKING_REQD := GLOBALS_FRC_CORE.G_TBL_SMTB_MENU_DEFN_REC.TANK_MODIFICATIONS;
    END IF;
    L_TANKING_REQD := NVL(L_TANKING_REQD, 'N');
    DBG('Value of l_Tanking_Reqd is - ' || L_TANKING_REQD ||
        'p_Action_Code - ' || P_ACTION_CODE);

    IF L_TANKING_REQD = 'Y' THEN
      IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_QUERY,
                           CSPKS_REQ_GLOBAL.P_MODIFY,
                           CSPKS_REQ_GLOBAL.P_CLOSE,
                           CSPKS_REQ_GLOBAL.P_REOPEN) THEN
        BEGIN
          SELECT ONCE_AUTH
            INTO L_ONCE_AUTH
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_ONCE_AUTH := 'N';
        END;
        DBG('l_Once_Auth' || L_ONCE_AUTH);

        IF L_ONCE_AUTH = 'Y' THEN
          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT1
              FROM STTMS_CUST_ACCOUNT A, STTMS_CUSTOMER B
             WHERE A.CUST_AC_NO =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
               AND A.BRANCH_CODE =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND A.CUST_NO = B.CUSTOMER_NO
               AND ((B.GROUP_CODE IS NOT NULL AND EXISTS
                    (SELECT 1
                        FROM STVWS_USER_GROUP C
                       WHERE C.USER_ID = GLOBAL.USER_ID
                         AND C.GROUP_CODE = B.GROUP_CODE)) OR
                   A.ONCE_AUTH = 'N' OR B.GROUP_CODE IS NULL)
               AND ((B.ACCESS_GROUP IS NOT NULL AND EXISTS
                    (SELECT 1
                        FROM STVWS_USER_ACCESS C
                       WHERE C.USER_ID = GLOBAL.USER_ID
                         AND C.ACCESS_GROUP = B.ACCESS_GROUP)) OR
                   B.ACCESS_GROUP IS NULL);

            DBG('l_Count1' || L_COUNT1);
            IF L_COUNT1 = 0 THEN
              DBG('User restricted to view this account' ||
                  P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
              P_ERR_CODE   := 'ST-GRP01';
              P_ERR_PARAMS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              RETURN FALSE;
            END IF;
          END;
        END IF;
      END IF;
    END IF;

    DBG('Linkages COunt p_stdcusac kernel5:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT || '~' || P_ACTION_CODE);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('Going to call acpks_utils.fn_ValidateAndRetryForAcc to post pending entries..');
      IF NOT ACPKS_UTILS.FN_VALIDATEANDRETRYFORACC(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('Failed in acpks_utils.fn_ValidateAndRetryForAcc : ' ||
            SQLERRM || '~' || P_ERR_CODE);
        IF P_ERR_CODE IS NULL THEN
          P_ERR_CODE   := 'ST-CUS24';
          P_ERR_PARAMS := NULL;
        END IF;
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Post_Check_Mandatory ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_CHECK_MANDATORY;

  FUNCTION FN_PRE_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                       P_SOURCE_OPERATION IN VARCHAR2,
                                       P_FUNCTION_ID      IN VARCHAR2,
                                       P_ACTION_CODE      IN VARCHAR2,
                                       P_CHILD_FUNCTION   IN VARCHAR2,
                                       P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                       P_PREV_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                       P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                       P_ERR_CODE         IN OUT VARCHAR2,
                                       P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    DBG('In Fn_Pre_Default_And_Validate..');
    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_prev_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Rate Flag :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG ||
        '~Pool code :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);

    DBG('p_source' || P_SOURCE);
    UVPKS_UDF_UPLOAD.G_UDF_SOURCE_CODE := P_SOURCE;
    DBG('Stat: ' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD5);
    DBG('Acc pr count: ' || P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);

    IF P_ACTION_CODE = 'MODIFY' THEN

      IF NOT FN_UPDATE_ACC_LINKAGE(P_FUNCTION_ID,
                                   P_SOURCE,
                                   P_ACTION_CODE,
                                   P_STDCUSAC,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
        DBG('fn_update_acc_linkage has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUSA-201', '');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_prev_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Pre_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_DEFAULT_AND_VALIDATE;

  FUNCTION FN_MATURITY_CALC(P_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_INT_RATE     OUT NUMBER,
                            P_MAT_AMOUNT   OUT NUMBER,
                            P_TB_UDE_DATES DBMS_SQL.DATE_TABLE,
                            P_ERR_CODE     IN OUT VARCHAR2,
                            P_ERR_PARAMS   IN OUT VARCHAR2) RETURN BOOLEAN IS
    L_PAYMENT_METHOD  ICTM_PR_INT.PAYMENT_METHOD%TYPE;
    L_CNT             NUMBER;
    L_ACC_TANKED_STAT STTM_CUST_ACCOUNT.ACC_TANKED_STAT%TYPE;
    L_COUNT           NUMBER := 0;
    L_PRODUCT_CODE    VARCHAR2(5);
    L_INT_RATE        NUMBER;
    L_TOTAL_AMOUNT    NUMBER;
    FAILURE_EXCEPTION EXCEPTION;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;
    L_ICDREDMN      TDVWS_TD_REDEMPTION%ROWTYPE;

    L_BASE_AMT    NUMBER;
    L_ACC_REC     STTM_CUST_ACCOUNT%ROWTYPE;
    L_TOT_INTREST NUMBER := 0;
    L_TOT_TAX     NUMBER := 0;

    L_TB_UDEVALS STPKS_STDCUSAC_MAIN.TY_TB_V_ICTMS_ACC_UDEVALS;
    L_TMP_IDX    PLS_INTEGER;
    L_TMP_IDX2   PLS_INTEGER;
    L_TMP_CNT    INTEGER := 0;

    L_REDEM_FULL_FLAG VARCHAR2(1);
    L_TB_CALC_BRKUP   STPKS_STDTDTOP_UTILS.TY_TB_RED_BRKUP;
    L_FUNCTION_ID     VARCHAR2(8);
    L_CUST_PROD       NUMBER := 0;
  BEGIN

    DBG('Start of Maturity calculaiton');
    IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
      SELECT PAYMENT_METHOD
        INTO L_PAYMENT_METHOD
        FROM ICTM_PR_INT
       WHERE PRODUCT_CODE = P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
    END IF;

    BEGIN
      DBG('Maturity Amount Calculation on COMPUTE action');
      SAVEPOINT MAT_AMT_CALC;

      L_COUNT := 0;
      IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
          DBG('Prod: ' || P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
          IF P_STDCUSAC.V_ICTMS_ACC_PR(I).WAIVE = 'N' THEN
            L_COUNT := L_COUNT + 1;
          END IF;
          IF L_COUNT > 1 THEN
            DBG('no. of PRODUCT USED  :' || L_COUNT);
            DBG('Failed:More than one product is not allowed for TD account');
            P_ERR_CODE   := 'IC-BOD099';
            P_ERR_PARAMS := NULL;
            RAISE FAILURE_EXCEPTION;
          END IF;

          SELECT COUNT(*)
            INTO L_CUST_PROD
            FROM ICVW_PR_CUST
           WHERE PROD = P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
             AND CUST = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

          DBG('l_cust_prod is :' || L_CUST_PROD);
          DBG('p_Stdcusac.v_Ictms_Acc_Pr(i).record_stat is :' || P_STDCUSAC.V_ICTMS_ACC_PR(I)
              .RECORD_STAT);

          IF L_CUST_PROD = 0 AND P_STDCUSAC.V_ICTMS_ACC_PR(I)
            .RECORD_STAT = 'O' THEN
            DBG('Failed: Interest Product is either Invalid or Restricted');
            P_ERR_CODE   := 'ST-ACC-575';
            P_ERR_PARAMS := P_STDCUSAC.V_ICTMS_ACC_PR(I).PROD;
            RAISE FAILURE_EXCEPTION;
          END IF;

        END LOOP;
      END IF;

      SELECT COUNT(*)
        INTO L_CNT
        FROM STTMS_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

      IF L_CNT = 0 THEN

        DBG('Inserting Into STTMS_CUST_ACCOUNT..');
        BEGIN
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT       := 'A';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH       := 'Y';
          L_ACC_TANKED_STAT                               := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT;
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT := 'N';

          DBG('p_Stdcusac.v_Sttms_Cust_Account.record_stat BEFORE-' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT);
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT := 'O';
          DBG('p_Stdcusac.v_Sttms_Cust_Account.record_stat AFTER-' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT);

          IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL AND
             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL THEN
            DBG('Record Sent..');
            INSERT INTO STTM_CUST_ACCOUNT
            VALUES P_STDCUSAC.V_STTMS_CUST_ACCOUNT;
          END IF;

          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT       := 'U';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH       := 'N';
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_TANKED_STAT := L_ACC_TANKED_STAT;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed In Insert intoSTTMS_CUST_ACCOUNT..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@STTMS_CUST_ACCOUNT';
            RAISE FAILURE_EXCEPTION;
        END;
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_INSERT_CUSTACSEQ('STDCUSAC',
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) THEN

          DBG('Failing in inserting custacseq');
        END IF;
      ELSE
        DBG('During modification updating sttm_cust_account');

        UPDATE STTM_CUST_ACCOUNT
           SET ONCE_AUTH = 'Y', AUTH_STAT = 'A'
         WHERE CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

        DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_ACC..');
        DELETE ICTM_ACC
         WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

          DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_TD_DETAILS..');
          DELETE ICTM_TD_DETAILS
           WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        END IF;
        DEBUG.PR_DEBUG('IC',
                       'p_tb_ude_dates.count' || P_TB_UDE_DATES.COUNT);

        DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_ACC_EFFDT..');

        DELETE ICTM_ACC_EFFDT
         WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

        DEBUG.PR_DEBUG('IC',
                       'p_tb_ude_dates.count=.' || P_TB_UDE_DATES.COUNT);
        IF P_TB_UDE_DATES.COUNT > 0 THEN

          DEBUG.PR_DEBUG('IC', 'BULK DELETE ICTMS_ACC_UDEVALS..');
          BEGIN
            FORALL L_IDX IN P_TB_UDE_DATES.FIRST .. P_TB_UDE_DATES.LAST SAVE
                                                    EXCEPTIONS
              DELETE ICTM_ACC_UDEVALS
               WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                 AND UDE_EFF_DT = P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_IDX)
                    .UDE_EFF_DT;
          EXCEPTION
            WHEN OTHERS THEN
              DBG(SQLERRM);
          END;

        ELSIF ICPKS_BOD.G_CHILDTD OR G_ACTION_CODE = 'NEW'

              OR STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y'

              OR GWPKS_UTIL.PKG_FUNC IN ('TDMM', 'IPTDMM') THEN

          DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_ACC_UDEVALS..');

          DELETE ICTM_ACC_UDEVALS
           WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        END IF;
        DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_ACC_PR..');
        DELETE ICTMS_ACC_PR
         WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

        DEBUG.PR_DEBUG('IC', 'DELETE ICTMS_TDPAYOUT_DETAILS..');
        DELETE ICTMS_TDPAYOUT_DETAILS
         WHERE BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

      END IF;

      DBG('Calling stpkss_stdcusac_utils_0.fn_popdt');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_POPDT('STDCUSAC', P_STDCUSAC) THEN
        DBG('stpkss_stdcusac_utils_0.fn_popdt has returned false');
        NULL;
      END IF;
      DBG('Calling Icpks_Resolve_Maint.Fn_Resolve_Acc');

      DEBUG.PR_DEBUG('IC', 'Inserting Into ICTMS_ACC..');
      BEGIN
        IF P_STDCUSAC.V_ICTMS_ACC.BRN IS NOT NULL AND
           P_STDCUSAC.V_ICTMS_ACC.ACC IS NOT NULL THEN
          DEBUG.PR_DEBUG('IC', 'Record Sent..');
          INSERT INTO ICTM_ACC VALUES P_STDCUSAC.V_ICTMS_ACC;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC', 'Failed In Insert intoICTMS_ACC..');
          DEBUG.PR_DEBUG('IC', SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@ICTMS_ACC';
          RAISE FAILURE_EXCEPTION;
      END;
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

        DBG('Inserting Into ICTMS_TD_DETAILS..');
        BEGIN
          IF P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN IS NOT NULL AND
             P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC IS NOT NULL AND
             P_STDCUSAC.V_ICTMS_TD_DETAILS.CCY IS NOT NULL THEN
            DBG('Record Sent..');
            INSERT INTO ICTM_TD_DETAILS
            VALUES P_STDCUSAC.V_ICTMS_TD_DETAILS;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Failed In Insert intoICTMS_TD_DETAILS..');
            DBG(SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@ICTMS_TD_DETAILS';
            RAISE FAILURE_EXCEPTION;
        END;
      END IF;

      DEBUG.PR_DEBUG('IC', 'Inserting Into ICTMS_ACC_EFFDT..');
      BEGIN
        L_COUNT := P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;

        DBG('Branch here :' || P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN);
        DBG('Account here is ' || P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC);
        IF P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN IS NOT NULL AND
           P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC IS NOT NULL THEN
          IF L_COUNT > 0 THEN
            FOR I IN 1 .. L_COUNT LOOP
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              P_STDCUSAC.V_ICTMS_ACC_EFFDT(I).PROD := P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
            END LOOP;
          END IF;
          FORALL L_INDEX IN 1 .. L_COUNT
            INSERT INTO ICTM_ACC_EFFDT
            VALUES P_STDCUSAC.V_ICTMS_ACC_EFFDT
              (L_INDEX);
          DBG('No. of rows inserted into ICTM_ACC_EFFDT is ' ||
              SQL%ROWCOUNT);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC', 'Failed In Insert intoICTMS_ACC_EFFDT..');
          DEBUG.PR_DEBUG('IC', SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@ICTMS_ACC_EFFDT';
          RAISE FAILURE_EXCEPTION;
      END;

      DEBUG.PR_DEBUG('IC',
                     'p_tb_ude_dates.count =.' || P_TB_UDE_DATES.COUNT);
      IF P_TB_UDE_DATES.COUNT > 0 THEN
        L_TB_UDEVALS.DELETE;
        L_TMP_IDX2 := P_TB_UDE_DATES.FIRST;
        WHILE L_TMP_IDX2 IS NOT NULL LOOP
          DBG('p_tb_ude_dates(l_tmp_idx2) =' || P_TB_UDE_DATES(L_TMP_IDX2));

          L_TMP_IDX := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST;
          WHILE L_TMP_IDX IS NOT NULL LOOP
            DBG('p_stdcusac.v_Ictms_Acc_Udevals(l_tmp_idx).ude_eff_dt=' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX)
                .UDE_EFF_DT);
            DBG('p_stdcusac.v_Ictms_Acc_Udevals(l_tmp_idx).ude_variance =' || P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX)
                .UDE_VARIANCE);

            IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX)
             .UDE_EFF_DT = P_TB_UDE_DATES(L_TMP_IDX2) THEN
              L_TMP_CNT := L_TB_UDEVALS.COUNT + 1;
              P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX).AUTH_STAT := 'A';
              P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX).RECORD_STAT := 'O';
              DBG('TEST1');
              L_TB_UDEVALS(L_TMP_CNT) := P_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_TMP_IDX);

            END IF;

            L_TMP_IDX := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.NEXT(L_TMP_IDX);
          END LOOP;
          L_TMP_IDX2 := P_TB_UDE_DATES.NEXT(L_TMP_IDX2);

        END LOOP;
        DBG('l_tb_udevals.count=' || L_TB_UDEVALS.COUNT);

        IF L_TB_UDEVALS.COUNT > 0 THEN
          BEGIN
            FORALL L_INDEX IN L_TB_UDEVALS.FIRST .. L_TB_UDEVALS.LAST SAVE
                                                    EXCEPTIONS
              INSERT INTO ICTM_ACC_UDEVALS VALUES L_TB_UDEVALS (L_INDEX);
          EXCEPTION
            WHEN OTHERS THEN
              DEBUG.PR_DEBUG('IC',
                             'Failed In Insert intoICTMS_ACC_UDEVALS..');
              DEBUG.PR_DEBUG('IC', SQLERRM);
              P_ERR_CODE   := 'ST-UPLD-001';
              P_ERR_PARAMS := '@ICTMS_ACC_UDEVALS';
              RAISE FAILURE_EXCEPTION;
          END;
          L_TB_UDEVALS.DELETE;
        END IF;
        DBG('rows inserted is ' || SQL%ROWCOUNT);

      ELSIF ICPKS_BOD.G_CHILDTD OR G_ACTION_CODE = 'NEW'

            OR STPKSS_STDCUSTD_KERNEL.G_SIMULATION = 'Y' OR
            GWPKS_UTIL.PKG_FUNC IN ('TDMM', 'IPTDMM')

       THEN

        DEBUG.PR_DEBUG('IC', 'Inserting Into ICTMS_ACC_UDEVALS..');
        BEGIN
          L_COUNT := P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;

          DBG('p_Stdcusac.v_Ictms_Acc_Udevals.Count = ' || L_COUNT);
          IF P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN IS NOT NULL AND
             P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC IS NOT NULL THEN
            IF ICPKS_BOD.G_CHILDTD THEN

              IF L_COUNT > 0 THEN
                IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
                  FOR I IN 1 .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.LAST LOOP
                    FOR I1 IN P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).PROD := P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).UDE_EFF_DT := P_STDCUSAC.V_ICTMS_ACC_EFFDT(I)
                                                                       .UDE_EFF_DT;
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).AUTH_STAT := 'A';
                      P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).RECORD_STAT := 'O';
                    END LOOP;
                  END LOOP;
                END IF;
              END IF;

            ELSE
              IF P_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
                FOR I1 IN P_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).AUTH_STAT := 'A';
                  P_STDCUSAC.V_ICTMS_ACC_UDEVALS(I1).RECORD_STAT := 'O';
                END LOOP;
              END IF;
            END IF;

            FORALL L_INDEX IN 1 .. L_COUNT
              INSERT INTO ICTM_ACC_UDEVALS
              VALUES P_STDCUSAC.V_ICTMS_ACC_UDEVALS
                (L_INDEX);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            DEBUG.PR_DEBUG('IC',
                           'Failed In Insert intoICTMS_ACC_UDEVALS..');
            DEBUG.PR_DEBUG('IC', SQLERRM);
            P_ERR_CODE   := 'ST-UPLD-001';
            P_ERR_PARAMS := '@ICTMS_ACC_UDEVALS';
            RAISE FAILURE_EXCEPTION;
        END;
      END IF;

      DBG('ictm_acc_pr count-' || P_STDCUSAC.V_ICTMS_ACC_PR.COUNT);

      IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN

        FOR I1 IN P_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
          P_STDCUSAC.V_ICTMS_ACC_PR(I1).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_STDCUSAC.V_ICTMS_ACC_PR(I1).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          P_STDCUSAC.V_ICTMS_ACC_PR(I1).PROD := P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;

          DBG('Once auth-' || P_STDCUSAC.V_ICTMS_ACC_PR(I1).ONCE_AUTH);
          DBG('Record_Stat-' || P_STDCUSAC.V_ICTMS_ACC_PR(I1).RECORD_STAT);
          P_STDCUSAC.V_ICTMS_ACC_PR(I1).ONCE_AUTH := 'Y';
          P_STDCUSAC.V_ICTMS_ACC_PR(I1).RECORD_STAT := 'O';
        END LOOP;
      END IF;

      DEBUG.PR_DEBUG('IC', 'Inserting Into ICTMS_ACC_PR..');
      BEGIN
        L_COUNT := P_STDCUSAC.V_ICTMS_ACC_PR.COUNT;
        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO ICTM_ACC_PR
          VALUES P_STDCUSAC.V_ICTMS_ACC_PR
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DEBUG.PR_DEBUG('IC', 'Failed In Insert intoICTMS_ACC_PR..');
          DEBUG.PR_DEBUG('IC', SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@ICTMS_ACC_PR';
          RAISE FAILURE_EXCEPTION;
      END;
      DBG('Inserting Into ICTMS_TDPAYOUT_DETAILS..');
      BEGIN
        L_COUNT := P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT;
        FOR L_INDEX IN 1 .. L_COUNT LOOP
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_INDEX).ACC := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_INDEX).BRN := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS(L_INDEX).SEQNO := L_INDEX;
        END LOOP;

        FORALL L_INDEX IN 1 .. L_COUNT
          INSERT INTO ICTM_TDPAYOUT_DETAILS
          VALUES P_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS
            (L_INDEX);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed In Insert intoICTMS_TDPAYOUT_DETAILS..');
          DBG(SQLERRM);
          P_ERR_CODE   := 'ST-UPLD-001';
          P_ERR_PARAMS := '@ICTMS_TDPAYOUT_DETAILS';
          RAISE FAILURE_EXCEPTION;
      END;

      DBG('Mudarabah accounts-->' ||
          NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS, 'N'));
      IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS, 'N') = 'Y' THEN
        DBG('Its a Islamic term deposit account..');
        L_FUNCTION_ID := 'IADCUSTD';
      ELSE
        DBG('Its a term deposit account..');
        L_FUNCTION_ID := 'STDCUSTD';
      END IF;
      DBG('l_function_id..' || L_FUNCTION_ID);

      DBG('Calling Uvpks_Udf_Upload.Fn_Pickup_Func_Udf.');

      IF NOT COPKS_UDF_UPLOAD.FN_PICKUP_FUNC_UDF(L_FUNCTION_ID,
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                                                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~',
                                                 P_ERR_CODE,
                                                 P_ERR_PARAMS) THEN
        DBG('Failed in Uvpks_Udf_Upload.Fn_Pickup_Func_Udf..');
        OVPKS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('Calling Uvpks_Udf_Upload.Fn_Function_Udf_Upload_Type.');

      DBG('The source is:' || CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') ||
          ' with action as:' || CSPKS_REQ_GLOBAL.G_HEADER('ACTION'));
      DBG('The UDF pickup count is:' || P_STDCUSAC.UDF_DETAILS.COUNT);
      IF P_STDCUSAC.UDF_DETAILS.COUNT > 0 THEN

        IF NOT COPKS_UDF_UPLOAD.FN_FUNCTION_UDF_UPLOAD_TYPE('',

                                                            L_FUNCTION_ID,
                                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~',
                                                            '',
                                                            P_STDCUSAC.UDF_DETAILS,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('Failed in Uvpks_Udf_Upload.Fn_Function_Udf_Upload_Type..');
          RETURN FALSE;
        END IF;
      END IF;

      IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        DEBUG.PR_DEBUG('IC',
                       'Product is -' || P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD);
        L_PRODUCT_CODE := P_STDCUSAC.V_ICTMS_ACC_PR(1).PROD;
      END IF;

      CVPKS_UTILS.GET_ACCOUNT_CLASS(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                    L_ACC_CLASS_REC,
                                    P_ERR_CODE);

      DBG('l_allow_topup' || L_ACC_CLASS_REC.ALLOW_TOPUP);
      DBG('l_Payment_Method' || L_PAYMENT_METHOD);
      IF

       (NVL(L_ACC_CLASS_REC.RD_FLAG, 'N') <> 'Y' AND
       NVL(L_ACC_CLASS_REC.MUDARABAH_ACC_CLASS, 'N') <> 'Y' AND
       L_PAYMENT_METHOD <> 'D')

       THEN

        DBG('calling stpks_stdtdtop_utils.fn_topup_settled');
        IF NOT STPKS_STDTDTOP_UTILS.FN_TOPUP_SETTLED(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                     'NEW',
                                                     P_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                     P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN

          DBG('failed in icpks_td_topup.fn_topup_settled');
          RETURN FALSE;
        END IF;

        IF NOT ICPKS_RESOLVE_MAINT.FN_RESOLVE_ACC(P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN,
                                                  P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
          DBG('err in resolution maintenance :' || P_ERR_CODE || '~' ||
              P_ERR_PARAMS);
          RAISE FAILURE_EXCEPTION;
        END IF;

        ICPKS_UDE.PR_MAKE_UDE_ROW_FOR_ANACC(P_STDCUSAC.V_ICTMS_TD_DETAILS.BRN,
                                            P_STDCUSAC.V_ICTMS_TD_DETAILS.ACC);
        STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('Y');

        ICPKSS_MAINT.PR_GET_FULL_REDEM(L_REDEM_FULL_FLAG);
        ICPKSS_MAINT.PR_SET_FULL_REDEM(NULL);

        L_ICDREDMN.BRN_CODE := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        L_ICDREDMN.AC_NO    := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

        L_ICDREDMN.WAVE_PENALTY   := 'Y';
        L_ICDREDMN.REDEMPTION_AMT := 0;
        L_ICDREDMN.CCY            := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        DBG('calling stpks_stdtdtop_utils.fn_matamt_comp to calculate Maturity Amount before Top-Up');
        IF NOT STPKS_STDTDTOP_UTILS.FN_MATAMT_COMP('FLEXCUBE',
                                                   'NEW',
                                                   L_ICDREDMN,
                                                   L_TB_CALC_BRKUP,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
          DBG('failed after calling fn_matamt_comp');
          P_ERR_CODE   := 'ST-TDMAT-01';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
        ICPKSS_MAINT.PR_SET_FULL_REDEM(L_REDEM_FULL_FLAG);
        L_TOTAL_AMOUNT := L_ICDREDMN.MATURITY_AMOUNT;
        STPKS_STDTDTOP_UTILS.PR_SET_ISTOPUP('');

        STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.NUM_FIELD25 := STPKS_STDTPSIM_KERNEL.G_REC_CALC.COUNT;
        IF STPKS_STDTPSIM_KERNEL.G_REC_CALC.COUNT > 0 THEN
          FOR I IN STPKS_STDTPSIM_KERNEL.G_REC_CALC.FIRST .. STPKS_STDTPSIM_KERNEL.G_REC_CALC.LAST LOOP
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(I).CHAR_FIELD3 := STPKS_STDTPSIM_KERNEL.G_REC_CALC(I)
                                                                                        .INTEREST_ONLY - STPKS_STDTPSIM_KERNEL.G_REC_CALC(I).TAX;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(I).CHAR_FIELD1 := L_ICDREDMN.BRN_CODE;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(I).CHAR_FIELD2 := L_ICDREDMN.AC_NO;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(I).DATE_FIELD2 := STPKS_STDTPSIM_KERNEL.G_REC_CALC(I)
                                                                                        .LIQN_DATE;
            STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_UI_COLUMNS__INT_PAYOUT(I).CHAR_FIELD4 := STPKS_STDTPSIM_KERNEL.G_REC_CALC(I)
                                                                                        .AMOUNT;
            L_TOT_INTREST := L_TOT_INTREST + STPKS_STDTPSIM_KERNEL.G_REC_CALC(I)
                            .INTEREST_ONLY;

            L_TOT_TAX := L_TOT_TAX + STPKS_STDTPSIM_KERNEL.G_REC_CALC(I).TAX;

          END LOOP;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.NUM_FIELD25  := STPKS_STDTPSIM_KERNEL.G_REC_CALC.COUNT;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.CHAR_FIELD54 := L_TOT_TAX;
          STPKS_STDCUSTD_KERNEL.G_STDCUSTD.V_CSTBS_UI_COLUMNS.CHAR_FIELD49 := L_TOT_INTREST;
        END IF;

      ELSE

        DBG('Going to call PR_CALC_MATURITY');
        STPKS_STDCUSAC_UTILS_1.PR_CALC_MATURITY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                L_PRODUCT_CODE,
                                                L_TOTAL_AMOUNT,
                                                'STDCUSAC',
                                                'N',
                                                P_STDCUSAC);
        DBG('In TOTAL_AMOUNT-->' || L_TOTAL_AMOUNT);
      END IF;

      IF NOT ICPKS_CACHE.FN_GETCUSTACC(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                       L_ACC_REC) THEN
        DEBUG.PR_DEBUG('IC', 'Could not get account');
      END IF;
      L_BASE_AMT := STPKS_STDCUSAC_UTILS_1.FN_GET_CUM_AMT(P_STDCUSAC.V_STTMS_CUST_ACCOUNT);
      DEBUG.PR_DEBUG('IC', 'Base Amount for simulation td ' || L_BASE_AMT);
      P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD3 := NVL(L_BASE_AMT, 0);
      DBG(' base amount' || P_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD3);

      IF L_PAYMENT_METHOD = 'B' THEN
        P_MAT_AMOUNT := L_TOTAL_AMOUNT;
      ELSE
        P_MAT_AMOUNT := P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT;
      END IF;

      L_INT_RATE := STPKS_STDCUSAC_UTILS_1.FN_PROJ_INTRATE('STDCUSAC',
                                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                           P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                           L_PRODUCT_CODE);

      P_INT_RATE := L_INT_RATE;
      DBG('Interest Rate-->' || P_INT_RATE);
      DBG('MATURITY AMOUNT-->' || P_MAT_AMOUNT);

      ROLLBACK TO MAT_AMT_CALC;

    EXCEPTION
      WHEN FAILURE_EXCEPTION THEN
        DEBUG.PR_DEBUG('ST', 'Failure EXCEPTION');
        ROLLBACK TO MAT_AMT_CALC;
        RETURN FALSE;
      WHEN OTHERS THEN
        DEBUG.PR_DEBUG('**', 'EXCEPTION IN MATURIY AMOUNT CALCULATION');
        DEBUG.PR_DEBUG('**', SQLERRM);
        ROLLBACK TO MAT_AMT_CALC;
        P_ERR_CODE   := 'ST-TDMAT-01';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
    END;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in calculating maturity amount');
      RETURN FALSE;
  END;

  FUNCTION FN_POST_DEFAULT_AND_VALIDATE(P_SOURCE           IN VARCHAR2,
                                        P_SOURCE_OPERATION IN VARCHAR2,
                                        P_FUNCTION_ID      IN VARCHAR2,
                                        P_ACTION_CODE      IN VARCHAR2,
                                        P_CHILD_FUNCTION   IN VARCHAR2,
                                        P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                        P_PREV_STDCUSAC    IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                        P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                        P_ERR_CODE         IN OUT VARCHAR2,
                                        P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    TYPE TY_V_ICTMS_ACC_UDEVALS IS TABLE OF ICTM_ACC_UDEVALS%ROWTYPE INDEX BY VARCHAR2(100);
    L_PREV_ICTMS_ACC_UDEVAL TY_V_ICTMS_ACC_UDEVALS;
    L_PREV_UDE_STRING       VARCHAR2(100);
    L_WORK_UDE_STRING       VARCHAR2(100);

    L_MATURITY_DATE      DATE;
    L_NEXT_MATURITY_DATE DATE;
    L_MULTI_CURRENCY     VARCHAR2(20);
    CURSOR CR_PRODS(PROD ICTM_ACC_PR.PROD%TYPE) IS
      SELECT A.PRODUCT_CODE PROD,
             DECODE(P.UDE_CCY, 'ACY', 'A', 'L') UDE_CCY
        FROM CSTMS_PRODUCT C, ICTM_PR_INT P, ICTM_PR_INT_ACLASS A
       WHERE C.PRODUCT_CODE = A.PRODUCT_CODE
         AND C.RECORD_STAT = 'O'
         AND C.ONCE_AUTH = 'Y'
         AND P.PRODUCT_CODE = A.PRODUCT_CODE
         AND A.ACLASS = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
         AND A.CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY
         AND A.RECORD_STAT = 'N'
         AND A.PRODUCT_CODE = PROD;

    PSERIAL      VARCHAR2(20);
    PREFERENCENO VARCHAR2(16);
    L_SEQVAL     INTEGER;
    P_ACCT_TYPE  VARCHAR2(10);

    L_RES            VARCHAR2(1000) := '';
    P_ACC_CLASS      VARCHAR2(10);
    P_ACC_CLASS_TYPE VARCHAR2(10);
    P_MIN_AMT        VARCHAR2(25);
    L_BRN_CR_DT      DATE;
    P_TY_RATE        LDPKS_SCHEDULES.TY_RATE;
    L_AC_CLASS_TYPE  STTM_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;
    L_RATE_CHART     STTM_ACCOUNT_CLASS.TD_RATECHART_ALLOW%TYPE;
    L_UDE_TYPE       ICTM_RULE_UDE.UDE_TYPE%TYPE;
    L_RULE_ID        ICTMS_PR_INT.RULE%TYPE;

    L_CUST_TYPE         STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
    K                   NUMBER := 1;
    L_NAME              STTM_CUSTOMER.SHORT_NAME%TYPE;
    L_AMOUNT_TO_PROCESS VARCHAR2(30);

    L_COUNT          NUMBER := 0;
    L_VIRACC_COUNT   NUMBER := 0;
    L_BLK            VARCHAR2(100) := 0;
    L_FLD            VARCHAR2(100) := 0;
    L_LOV_COUNT      NUMBER := 0;
    L_KEY            VARCHAR2(5000) := NULL;
    L_RDFLAG         STTM_ACCOUNT_CLASS.RD_FLAG%TYPE;
    L_MASTER_ACCOUNT STTM_CUST_ACCOUNT.MASTER_ACCOUNT_NO%TYPE;
    L_REPL_CUST_SIG  STTM_CUST_ACCOUNT.REPL_CUST_SIG%TYPE;

    L_PROJECT_ACCOUNT STTM_ACCOUNT_CLASS.PROJECT_ACCOUNT%TYPE;

    L_SECTORCODE    DETM_CLG_BRN_CODE.SECTOR_CODE%TYPE;
    L_CRVALDT       DATE;
    L_DRVALDT       DATE;
    L_LATE_CLEARING VARCHAR2(10);
    L_ERR_CODE      VARCHAR2(10);

    L_INDEX                     NUMBER;
    L_TOTAL_CONTRIBUTION        NUMBER := 0;
    L_ACCOUNT_DETAILS           STTM_CUST_ACCOUNT%ROWTYPE;
    L_JV_FLAG_STATUS            STTM_CUSTOMER.JOINT_VENTURE%TYPE;
    L_JOINT_VENTURE_CUSTOMER_NO STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_ORIGINAL_PARTY_RATIO      NUMBER(6, 3);
    L_CURRENT_PARTY_RATIO       NUMBER(6, 3);

    L_MOD_NO       NUMBER;
    L_PRODUCT_CODE VARCHAR2(5);
    L_TOTAL_AMOUNT NUMBER;
    L_INT_RATE     NUMBER;
    L_PAYIN_TOTAL  ICTB_ENTRIES_HISTORY.AMT%TYPE := 0;

    L_ACC_TANKED_STAT STTM_CUST_ACCOUNT.ACC_TANKED_STAT%TYPE;

    L_PAYMENT_METHOD ICTM_PR_INT.PAYMENT_METHOD%TYPE;

    L_COUNT1 NUMBER;

    L_REC_ACCOUNT_CLASS STTMS_ACCOUNT_CLASS%ROWTYPE;
    L_UTILIZED_AMOUNT   STTMS_SWEEP_DETAILS.UTILIZED_AMOUNT%TYPE;

    L_TRACK_LIMITS STTMS_CUSTOMER.TRACK_LIMITS%TYPE;
    L_LIMIT_CHECK  STTMS_ACCOUNT_CLASS.LIMIT_CHECK_REQUIRED%TYPE;
    L_COUNT2       NUMBER := 0;

    L_CNT_BLK_CUST NUMBER;
    L_CNT_CB_CUST  NUMBER;

    L_BRANCH       STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_ACC          STTMS_CUSTOMER.CUSTOMER_NO%TYPE;
    L_DOCLIST      STPKS_STDCUSAC_MAIN.TY_TB_STTMS_DOCTYPE_CHECK_LIST;
    L_PREV_DOCLIST STPKS_STDCUSAC_MAIN.TY_TB_STTMS_DOCTYPE_CHECK_LIST;
    L_CHQ_FAC      STTM_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY%TYPE;

    L_BOOLEAN BOOLEAN := TRUE;
    L_COUNT4  NUMBER := 0;

    L_RESULT              VARCHAR2(1000);
    L_SPEND_ANALYSIS_REQD VARCHAR2(1);

    L_MAT_AMOUNT        NUMBER;
    L_COUNT_1           NUMBER := 0;
    L_ACCCLS_STATUS_REC STTMS_ACCOUNT_CLASS_STATUS%ROWTYPE;
    L_MINOR             STTMS_BRANCH.MINOR_AGE%TYPE;
    L_CNT               NUMBER;
    L_ONCE_AUTH         VARCHAR2(1);
    L_ALPHA_OR_NUMA     VARCHAR2(3);

    L_JHCOD      STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;
    L_VALIDCIF   VARCHAR2(1000) := '';
    L_ESIG_COUNT NUMBER;
    L_REPNOW     NUMBER := 0;

    L_RECEIVABLE_AMOUNT      STTM_ACCOUNT_BALANCE.RECEIVABLE_AMOUNT%TYPE;
    L_PREV_MAT_DT            DATE;
    L_MULTICCY_COUNT_CLOSURE NUMBER(3) := 0;
    TYPE TY_TB_SIG_DTL_TMP IS TABLE OF SVTM_ACC_SIG_DET_TEMP%ROWTYPE INDEX BY BINARY_INTEGER;
    L_REC_SIG_DET TY_TB_SIG_DTL_TMP;
    CURSOR C_V_SVTMS_ACC_SIG_DET_TEMP IS
      SELECT A.*
        FROM SVTM_ACC_SIG_DET_TEMP A
       WHERE A.BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND A.ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    L_REL    SVTM_JH_TEMPTBL.RELATION%TYPE;
    L_JHCOD1 STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;

    L_JOINT_ERROR  BOOLEAN;
    L_AUTH_STAT    STTM_ACC_JOINT_MASTER.AUTH_STAT%TYPE;
    P_WRK_STDJHMNT STPKS_STDJHMNT_MAIN.TY_STDJHMNT;
    L_KEY_ID       VARCHAR(200);

    L_NXT_DATE DATE;

    L_MONTH_END_DEP STTMS_ACCOUNT_CLASS.MONTH_END_DEPOSIT%TYPE;
    L_HOL_PREF      STTMS_ACCOUNT_CLASS.HOLIDAY_CALENDAR%TYPE;
    L_ERROR         VARCHAR2(20);
    L_MONTH_END_FLG BOOLEAN := FALSE;
    L_WRK_DAY       DATE;

    L_TD_JNT_HOLD      STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR%TYPE;
    L_TD_CUST_NO       STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_COV_JNT_HOLD     STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR%TYPE;
    L_COV_CUST_NO      STTMS_CUST_ACCOUNT.CUST_NO%TYPE;
    L_COUNT_COV        NUMBER;
    L_COVOVD_CNT       NUMBER;
    L_COUNT_TD         NUMBER;
    L_TDOVD_CNT        NUMBER;
    L_SEQ_NO           NUMBER;
    L_ENABLE_SWP_IN    STTM_ACCOUNT_CLASS.ENABLE_SWEEP_IN%TYPE;
    L_ENABLE_REVSWP_IN STTM_ACCOUNT_CLASS.ENABLE_REV_SWEEP_IN%TYPE;
    L_ILM_APPLICABLE   STTM_ACCOUNT_CLASS.ILM_APPLICABLE%TYPE;

    L_RECOMPUTE_MAT_DATE STTM_ACCOUNT_CLASS.RECOMPUTE_MAT_DATE%TYPE;

    L_REC_FOUND       BOOLEAN := FALSE;
    L_LIAB_ID         VARCHAR2(30);
    L_LINE_START_DATE DATE;
    L_DELINK_DATE     DATE;

    L_CUST_PROD     NUMBER := 0;
    L_ACC_CLASS_REC STTM_ACCOUNT_CLASS%ROWTYPE;

    L_STDCUSAC_RECORD_KEY    VARCHAR2(32767);
    L_STDCUSAC_FUNCTION_TYPE VARCHAR2(32767);
    L_STDCUSAC_KEY_ID        VARCHAR2(32767);

    L_UPDATE_DONE BOOLEAN := FALSE;
    L_WRK_COUNT   NUMBER := 0;
    L_PREV_COUNT  NUMBER := 0;
    TYPE TY_TB_MODIFIED_RECS IS TABLE OF PLS_INTEGER INDEX BY VARCHAR2(60);
    L_TB_MOD_UDE TY_TB_MODIFIED_RECS;

    L_TB_UDE_DATES DBMS_SQL.DATE_TABLE;
    L_TB_HSH_DATES DBMS_SQL.NUMBER_TABLE;
    L_HSH_IDX      PLS_INTEGER;

    L_SWP_COUNT    NUMBER;
    L_SWPLNK_COUNT NUMBER;

    L_CCY VARCHAR2(3);

    L_HOLIDAY_CALENDAR STTMS_ACCOUNT_CLASS.HOLIDAY_CALENDAR%TYPE;
    L_HOLIDAY_MOVEMENT STTMS_ACCOUNT_CLASS.HOLIDAY_MOVEMENT%TYPE;

    L_HOL_MOV STTMS_ACCOUNT_CLASS.HOLIDAY_MOVEMENT%TYPE;

    L_HOL_RES VARCHAR2(1000);
    L_MESSAGE ERTBS_MSGS.ERR_CODE%TYPE;

    L_ALW_EU_OR_COMM VARCHAR2(1);
    L_T              VARCHAR2(1);
    L_BRANCH_RECORD  STTMS_BRANCH%ROWTYPE;
    L_COUNT_UNAUTH   NUMBER;
    L_AC_COUNT       NUMBER;

    L_ACL_IBAN_REQUIRED      STTM_ACCOUNT_CLASS.IBAN_REQUIRED %TYPE;
    L_CN_IBAN_CHECK_REQUIRED STTM_COUNTRY.IBAN_CHECK_REQD%TYPE;
    L_IBAN_AC_NO             STTMS_CUST_ACCOUNT.IBAN_AC_NO%TYPE;

    L_MIN_UDE_EFF_DATE DATE;

    L_TB_V_SVTMS_ACC_SIG_DET SVPKS_SVCACSIG_MAIN.TY_TB_V_SVTMS_ACC_SIG_DET;
    L_PRESENT                BOOLEAN := FALSE;

    L_PR_INT_UDEVALS ICTM_PR_INT_UDEVALS%ROWTYPE;
    L_BRN            STTMS_CUST_ACCOUNT.BRANCH_CODE%TYPE;
    L_CNTR           NUMBER;
    L_UDE_VALUE      ICTM_ACC_UDEVALS.UDE_VALUE%TYPE;
    L_RATE_CODE      ICTM_ACC_UDEVALS.RATE_CODE%TYPE;

    L_TEMP_JHCIF VARCHAR2(1000) := '';
    L_TEMP_JHREL VARCHAR2(1000) := '';
    L_COUNTCIF   NUMBER := 0;

    L_LOC_CODE      STTMS_CUST_ACCOUNT.LOCATION%TYPE;
    L_DEFAULT_MEDIA STTMS_CUST_ACCOUNT.MEDIA%TYPE;

    L_UDE_TYPE1 ICTMS_RULE_UDE.UDE_TYPE%TYPE;
    L_PROD_LOOP BOOLEAN;
    L_RATE      ICTMS_RATES.RATE%TYPE;
    L_EFFDT     VARCHAR2(10);
    L_UDE_FOUND BOOLEAN;
    L_UDE_CNT   NUMBER := 0;

    L_REPLICATED     BOOLEAN := FALSE;
    L_AVAILMENT_DATE GETM_FACILITY.AVAILMENT_DATE%TYPE;
    L_SIG_REPLICATE  CHAR(1) := 'N';
    L_OD_TYPE        STTM_ACCOUNT_CLASS.OVERDRAFT_FACILITY%TYPE;
    L_NETTINGREQD    STTM_CUST_ACCOUNT.NETTING_REQUIRED%TYPE;

    L_FROZEN              STTM_CUST_ACCOUNT.AC_STAT_FROZEN%TYPE;
    L_DORMANT             STTM_CUST_ACCOUNT.AC_STAT_DORMANT%TYPE;
    L_BOOKACC_CUSTOMER    STTM_CUST_ACCOUNT.CUST_NO%TYPE;
    L_DECEASED            STTM_CUSTOMER.DECEASED%TYPE;
    L_WHEREABOUTS_UNKNOWN STTM_CUSTOMER.WHEREABOUTS_UNKNOWN%TYPE;
    L_CUST_FROZEN         STTM_CUSTOMER.FROZEN%TYPE;

    L_COUNT3 NUMBER := 0;

    L_START NUMBER;
    L_END   NUMBER;

    L_LENGTH NUMBER;
    PROCEDURE PR_POP_TB_VARCHG(P_INDEX      NUMBER,
                               P_VAR_CHANGE BOOLEAN,
                               P_RATE_CHG   BOOLEAN) IS
      L_VARCHANGE   NUMBER := 0;
      L_RATE_CHANGE NUMBER := 0;
      L_FINAL_VAL   NUMBER := 0;
    BEGIN
      IF P_VAR_CHANGE THEN
        L_VARCHANGE := 1;
      END IF;
      IF P_RATE_CHG THEN
        L_RATE_CHANGE := 1;
      END IF;
      L_FINAL_VAL := (10 * L_VARCHANGE) + L_RATE_CHANGE;
      G_TB_VARIANCE_CHG(P_INDEX) := L_FINAL_VAL;
    END PR_POP_TB_VARCHG;

  BEGIN

    DBG('In Fn_Post_Default_And_Validate..');
    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_prev_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('p_function_id :' || P_FUNCTION_ID);
    DBG('p_Child_Function :' || P_CHILD_FUNCTION);
    DBG('Rate Flag :' ||
        P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG ||
        '~Pool code :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);
    DBG('PWrk --> Rate Flag :' ||
        P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.RATE_FLAG ||
        '~Pool code :' ||
        P_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.POOL_CODE);
    G_FUNCTION_ID                                 := P_FUNCTION_ID;
    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;

    DBG(' In stdcusac-->' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
    DBG(' In stdcusac-->' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    P_WRK_STDCUSAC.TY_ICCINSTR.V_STTMS_CUST_ACCOUNT.CCY             := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    P_WRK_STDCUSAC.TY_ICCINSTR.V_STTMS_CUST_ACCOUNT.CUST_NO         := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    P_WRK_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.CCY      := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
    P_WRK_STDCUSAC.TY_ICCINSTR.V_ICTBS_DEPOSIT_INSTRUCTION.CUSTOMER := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DR_OVD := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DR_OVD,
                                                              'N');
    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_CR_OVD := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_CR_OVD,
                                                              'N');

    IF P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT > 0 THEN
      FOR I_4 IN 1 .. P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT LOOP
        NULL;
        BEGIN
          SELECT DESCRIPTION
            INTO P_WRK_STDCUSAC.DESC_FIELDS('STTMS_ACCSTAT_REPLINES_DETAIL')(I_4)('DESCR')
            FROM (SELECT STATUS_CODE, DESCRIPTION
                    FROM STTM_CONTRACT_STATUSES
                   WHERE STATUS_TYPE IN ('A', 'B')
                     AND RECORD_STAT = 'O'
                     AND ONCE_AUTH = 'Y')
           WHERE STATUS_CODE = P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I_4)
                .STATUS
             AND ROWNUM < 2;
        EXCEPTION
          WHEN OTHERS THEN
            P_WRK_STDCUSAC.DESC_FIELDS('STTMS_ACCSTAT_REPLINES_DETAIL')(I_4)('DESCR') := NULL;
            DBG(SQLERRM);
            DBG('Failed in selecting the Desc Fields For  :ACSTATUS');
        END;
        DBG(P_WRK_STDCUSAC.DESC_FIELDS('STTMS_ACCSTAT_REPLINES_DETAIL')
            (I_4) ('DESCR'));
      END LOOP;
    END IF;

    DBG('action_code UDEPOP');
    IF P_ACTION_CODE = 'UDEPOP' THEN
      IF NOT STPKS_STDCUSAC_UTILS_1.FN_POP_CASA_UDEVALS(P_WRK_STDCUSAC,
                                                        P_ERR_CODE,
                                                        P_ERR_PARAMS) THEN
        DBG('Failed in stpks_stdcusac_utils_1.Fn_Pop_casa_udevals');
        PR_LOG_ERROR(P_FUNCTION_ID, P_ERR_CODE, P_ERR_PARAMS, '');
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      DBG('p_action_code for MIS' || P_ACTION_CODE);
      DBG('p_Wrk_stdcusac.ty_micacctm.v_mitb_class_mapping.ccy' ||
          P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CCY);
      DBG('p_Wrk_stdcusac.v_Sttms_Cust_Account.ccy' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
      IF P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CCY <>
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY THEN
        P_WRK_STDCUSAC.TY_MICACCTM.V_MITB_CLASS_MAPPING.CCY := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
      END IF;
    END IF;

    DBG('action_code default');
    DBG('p_action_code' || P_ACTION_CODE);

    IF P_ACTION_CODE = 'DEFAULT' OR
       (P_ACTION_CODE = 'NEW' AND P_SOURCE <> 'FLEXCUBE') THEN

      DBG('p_wrk_stdcusac.v_sttms_cust_account.CUST_NO' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      BEGIN

        SELECT LOC_CODE, DEFAULT_MEDIA

          INTO L_LOC_CODE, L_DEFAULT_MEDIA

          FROM STTM_CUSTOMER A, STTMS_ACCADDR_LOCTYPE B
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND B.LOCATION = A.LOC_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('in when no_data_found');

          L_LOC_CODE      := NULL;
          L_DEFAULT_MEDIA := NULL;

        WHEN OTHERS THEN
          DBG('in when others');

          L_LOC_CODE      := NULL;
          L_DEFAULT_MEDIA := NULL;

      END;

      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION,
                                                          L_LOC_CODE);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA    := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA,
                                                          L_DEFAULT_MEDIA);

      DBG('p_wrk_stdcusac.v_sttms_cust_account.location' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LOCATION);
      DBG('p_wrk_stdcusac.v_sttms_cust_account.media' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MEDIA);
    END IF;

    DBG('Action: ' || P_ACTION_CODE || 'g_function_id=' || G_FUNCTION_ID);
    G_ACTION_CODE := P_ACTION_CODE;

    IF P_ACTION_CODE = 'COPY' AND P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD') THEN
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := GLOBAL.APPLICATION_DATE;
      P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE        := GLOBAL.APPLICATION_DATE;
      P_WRK_STDCUSAC.V_ICTMS_ACC.CHG_START_DATE        := GLOBAL.APPLICATION_DATE;
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE         := ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                                                     P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                                                     (P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                                                          P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

      DBG('p_Wrk_Stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
      DBG('p_Wrk_Stdcusac.v_ictms_acc.maturity_date-->' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
        L_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT
            STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                    P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
          DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_MATURITY_DATE;
        END IF;
      END IF;

      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER, 'N') = 'Y' THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                    P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS +
                                                                    (P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS * 12)) +
                                                         P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS;

        DBG('p_Wrk_Stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('p_Wrk_Stdcusac.v_ictms_acc.next_maturity_date-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
        IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
          L_NEXT_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                      P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
          END IF;
        END IF;

      END IF;
      DBG('Copying the account, so reset done for all the dates');
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT := NULL;
      P_WRK_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE   := NULL;
    END IF;

    DBG('Calling Fn_Process_Date for CHANGEMATDT and CHANGETENOR');
    IF NOT FN_PROCESS_DATE(P_SOURCE,
                           P_SOURCE_OPERATION,
                           P_FUNCTION_ID,
                           P_ACTION_CODE,
                           P_CHILD_FUNCTION,
                           P_STDCUSAC,
                           P_PREV_STDCUSAC,
                           P_WRK_STDCUSAC,
                           P_ERR_CODE,
                           P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Process_Date');
      PR_LOG_ERROR(P_FUNCTION_ID, P_ERR_CODE, P_ERR_PARAMS, '');
    END IF;

    IF P_ACTION_CODE = 'NEW' THEN
      BEGIN
        SELECT *
          INTO L_ACCCLS_STATUS_REC
          FROM STTMS_ACCOUNT_CLASS_STATUS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
           AND STATUS =
               NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS, 'NORM');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Stage 1: Failed in Selection from sttms_account_class_status :  ' ||
              SQLERRM);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       'FLEXCUBE',
                       'ST-ACC-102',
                       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS || '~');
          RETURN FALSE;
      END;

      DBG('p_stdcusac.v_sttms_cust_account acc status::' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS || ':: ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL);
      IF P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT > 0 THEN
        FOR J IN 1 .. P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT LOOP
          IF P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
           .STATUS =
              NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS, 'NORM') THEN
            DBG('p_Wrk_Stdcusac.v_sttms_cust_account.dr_gl-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .DR_GL || 'p_Wrk_Stdcusac.v_sttms_cust_account.cr_gl-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .CR_GL ||
                'p_Wrk_Stdcusac.v_sttms_cust_account.dr_cb_line-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .DR_CB_LINE ||
                'p_Wrk_Stdcusac.v_sttms_cust_account.cr_cb_line-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .CR_CB_LINE ||
                'p_Wrk_Stdcusac.v_sttms_cust_account.dr_ho_line-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .DR_HO_LINE ||
                'p_Wrk_Stdcusac.v_sttms_cust_account.cr_ho_line-->' || P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                .CR_HO_LINE);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL      := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .DR_GL,
                                                                  L_ACCCLS_STATUS_REC.DR_GL);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL      := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .CR_GL,
                                                                  L_ACCCLS_STATUS_REC.CR_GL);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .DR_CB_LINE,
                                                                  L_ACCCLS_STATUS_REC.DR_CB_LINE);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .CR_CB_LINE,
                                                                  L_ACCCLS_STATUS_REC.CR_CB_LINE);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .DR_HO_LINE,
                                                                  L_ACCCLS_STATUS_REC.DR_HO_LINE);
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE := NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(J)
                                                                  .CR_HO_LINE,
                                                                  L_ACCCLS_STATUS_REC.CR_HO_LINE);
          END IF;
        END LOOP;
      END IF;
      DBG('p_Wrk_Stdcusac.v_sttms_cust_account.dr_gl -->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL);
      DBG('p_Wrk_Stdcusac.v_sttms_cust_account.cr_gl  -->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL      := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL,
                                                            L_ACCCLS_STATUS_REC.CR_GL);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL      := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL,
                                                            L_ACCCLS_STATUS_REC.DR_GL);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE,
                                                            L_ACCCLS_STATUS_REC.CR_CB_LINE);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE,
                                                            L_ACCCLS_STATUS_REC.DR_CB_LINE);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE,
                                                            L_ACCCLS_STATUS_REC.CR_HO_LINE);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE,
                                                            L_ACCCLS_STATUS_REC.DR_HO_LINE);
      DBG('p_Wrk_Stdcusac.v_sttms_cust_account.dr_gl -->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL);
      DBG('p_Wrk_Stdcusac.v_sttms_cust_account.cr_gl  -->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL);

    END IF;

    DBG('Action_code is ' || P_ACTION_CODE);
    DBG('Account_class and status is ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS || ' and ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS);

    IF (P_ACTION_CODE = 'MODIFY') THEN
      FOR I IN 1 .. P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL.COUNT LOOP
        IF P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
         .STATUS = NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACC_STATUS, 'NORM') THEN
          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).DR_GL, '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_GL := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                         .DR_GL;
          END IF;

          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).CR_GL, '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_GL := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                         .CR_GL;
          END IF;

          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).DR_HO_LINE,
                 '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_HO_LINE := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                              .DR_HO_LINE;
          END IF;

          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).CR_HO_LINE,
                 '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_HO_LINE := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                              .CR_HO_LINE;
          END IF;

          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).DR_CB_LINE,
                 '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DR_CB_LINE := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                              .DR_CB_LINE;
          END IF;

          IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE, '$') <>
             NVL(P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I).CR_CB_LINE,
                 '$') THEN
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CR_CB_LINE := P_WRK_STDCUSAC.V_ACCSTAT_REPLINES_DETAIL(I)
                                                              .CR_CB_LINE;
          END IF;
        END IF;
      END LOOP;
    END IF;

    DBG('Linkages COunt kernel4:' ||
        P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_stdcusac kernel4:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_Prev_stdcusac kernel4:' ||
        P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('p_Action_Code-->' || P_ACTION_CODE);
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.JOINT_AC_INDICATOR-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.mode_of_operation-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION);

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR, 'XX') = 'S' AND
         (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION IS NOT NULL AND
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION <> 'S') THEN
        DBG('Mode of Operation should be Single or null when Account Type is Single, Hence Error occured!!!');
        P_ERR_CODE   := 'ST-ACC-601';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR, 'XXXX') = 'J' AND
         (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION IS NOT NULL AND
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MODE_OF_OPERATION = 'S') THEN
        DBG('Mode of Operation cannot be Single when Account Type is Joint, Hence Error occured!!!');
        P_ERR_CODE   := 'ST-ACC-603';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC IS NOT NULL THEN
        L_LENGTH := LENGTH(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);
        FOR I IN 1 .. L_LENGTH LOOP
          IF SUBSTR(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC, I, 1) IN
             ('<', '>')

           THEN
            DBG('Retricted Text :Invalid Value For The Field  :AC_DESC:' ||
                P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC);

            PR_LOG_ERROR(P_FUNCTION_ID,
                         P_SOURCE,
                         'ST-VALS-012',
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC ||
                         '~@STTMS_CUST_ACCOUNT.AC_DESC~@STTMS_CUST_ACCOUNT');
          END IF;
        END LOOP;

        IF (L_LENGTH > 35) THEN
          DBG('Account Desc exceeds 35 characters');
          P_ERR_CODE   := 'ST-UD101';
          P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_DESC;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;

      END IF;

    END IF;

    IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') AND
       P_ACTION_CODE IN ('NEW', 'MODIFY', 'COMPUTE') THEN
      IF P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF = 'I' AND
         P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' AND
         P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS IS NULL AND
         P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS IS NULL AND
         P_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS IS NULL THEN
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-MSC018', '');
        RETURN FALSE;
      END IF;

    END IF;

    DBG('Action Code-->' || P_ACTION_CODE);
    DBG('Function ID-->' || P_FUNCTION_ID);

    IF P_FUNCTION_ID IN ('STDCUSAC', 'STDCUSTD', 'IADCUSAC', 'IADCUSTD') OR
       G_CHILD_FUNCTION THEN
      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
        BEGIN
          SELECT ENABLE_SWEEP_IN, ENABLE_REV_SWEEP_IN, ILM_APPLICABLE
            INTO L_ENABLE_SWP_IN, L_ENABLE_REVSWP_IN, L_ILM_APPLICABLE
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('NO_DATA_FOUND IN STTM_ACCOUNT_CLASS FOR ACLS -->' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
            L_ENABLE_SWP_IN := 'N';
        END;
        DBG('SWEEP_IN @ account class level-->' || L_ENABLE_SWP_IN);
        DBG('SWEEP_IN @ account level-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED);
        DBG('REV_SWEEP_IN @ account class level-->' || L_ENABLE_REVSWP_IN);
        DBG('REV_SWEEP_IN @ account level-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_OUT);

        IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'N' AND
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_OUT, 'N') = 'Y' THEN
          DBG('Reverse Sweep-in flag should be enabled only if Sweep-in flag is enabled.');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-SWP-033', '');

        END IF;

        IF NVL(L_ENABLE_SWP_IN, 'N') = 'N' AND
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'Y' THEN
          DBG('Sweep In Flag cannot be enabled when it is disabled at account class level');

          IF P_FUNCTION_ID = 'IADCUSAC' THEN
            P_ERR_CODE := 'IA-SWP-064';
          ELSE
            P_ERR_CODE := 'ST-SWP-064';
          END IF;

          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        ELSIF NVL(L_ENABLE_REVSWP_IN, 'N') = 'N' AND
              NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_OUT, 'N') = 'Y' THEN
          DBG('Reverse Sweep In Flag cannot be enabled when it is disabled at account class level');

          IF P_FUNCTION_ID = 'IADCUSAC' THEN
            P_ERR_CODE := 'IA-SWP-065';
          ELSE
            P_ERR_CODE := 'ST-SWP-065';
          END IF;

          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;
        DBG('Assigning Branch code and account number  for cover accounts');
        IF (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0) THEN
          FOR I IN P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.FIRST .. P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.LAST LOOP
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).BRANCH_CODE := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                                                                                     .BRANCH_CODE,
                                                                                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).CUST_ACCOUNT := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                                                                                      .CUST_ACCOUNT,
                                                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            DBG('Primary account for Cover::' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                .CUST_ACCOUNT);
          END LOOP;
        END IF;
        DBG('Assigning Branch code and account number  for TD accounts');
        IF (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0) THEN
          FOR J IN P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.FIRST .. P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.LAST LOOP
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(J).BRANCH_CODE := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(J)
                                                                                      .BRANCH_CODE,
                                                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(J).CUST_ACCOUNT := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(J)
                                                                                       .CUST_ACCOUNT,
                                                                                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            DBG('Primary account for TD::' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(J)
                .CUST_ACCOUNT);
          END LOOP;
        END IF;
        DBG('Assigning Branch code and account number  for AD accounts');
        IF (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.COUNT > 0) THEN
          FOR K IN P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.FIRST .. P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.LAST LOOP

            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD(K).BRANCH_CODE := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD(K)
                                                                                      .BRANCH_CODE,
                                                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD(K).CUST_ACCOUNT := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD(K)
                                                                                       .CUST_ACCOUNT,
                                                                                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            DBG('Primary account for AD ::' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD(K)
                .CUST_ACCOUNT);
          END LOOP;
        END IF;

        DBG('PRIMARY JOINT AC INDICATOR' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR);
        DBG('Primary customer number' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        IF P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0 THEN
          DBG('TD account count-->' ||
              P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT);
          FOR I IN P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.FIRST .. P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.LAST LOOP
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I).BRANCH_CODE := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                                                                                      .BRANCH_CODE,
                                                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I).CUST_ACCOUNT := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                                                                                       .CUST_ACCOUNT,
                                                                                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            DBG('TD account-->' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                .DEPOSIT_ACCOUNT);
            DBG('TD branch -->' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                .DEPOSIT_BRANCH);

            BEGIN
              SELECT JOINT_AC_INDICATOR, CUST_NO
                INTO L_TD_JNT_HOLD, L_TD_CUST_NO
                FROM STTMS_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                    .DEPOSIT_ACCOUNT
                 AND BRANCH_CODE = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                    .DEPOSIT_BRANCH;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('select failed' || SQLERRM);
            END;
            DBG('TD JOINT AC INDICATOR-->' || L_TD_JNT_HOLD);
            DBG('TD customer number-->' || L_TD_CUST_NO);

            SELECT COUNT(*)
              INTO L_TDOVD_CNT
              FROM STTM_SWEEP_DETAILS
             WHERE DEPOSIT_ACCOUNT = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                  .DEPOSIT_ACCOUNT
               AND DEPOSIT_BRANCH = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                  .DEPOSIT_BRANCH
               AND SWEEP_TYPE = 'ST';

            DBG('l_tdovd_cnt-->' || L_TDOVD_CNT);

            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR <>
               L_TD_JNT_HOLD AND L_TDOVD_CNT = 0 THEN
              DBG('JOINT HOLDER holding pattern mismatch of TD account and primary account');

              IF P_FUNCTION_ID = 'IADCUSAC' THEN
                P_ERR_CODE := 'IA-SWP-052';
              ELSE
                P_ERR_CODE := 'ST-SWP-052';
              END IF;

              P_ERR_PARAMS := P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                              .DEPOSIT_ACCOUNT || '~' ||
                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);

            END IF;
            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <> L_TD_CUST_NO AND
               L_TDOVD_CNT = 0 THEN
              DBG('customer number mismatch between TD account and primary account');

              IF P_FUNCTION_ID = 'IADCUSAC' THEN
                P_ERR_CODE := 'IA-SWP-053';
              ELSE
                P_ERR_CODE := 'ST-SWP-053';
              END IF;

              P_ERR_PARAMS := P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD(I)
                              .DEPOSIT_ACCOUNT || '~' ||
                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);

            END IF;
          END LOOP;
        END IF;

        IF P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0 THEN
          DBG('COVER account count-->' ||
              P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT);
          FOR I IN P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.FIRST .. P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.LAST LOOP
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).BRANCH_CODE := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                                                                                     .BRANCH_CODE,
                                                                                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I).CUST_ACCOUNT := NVL(P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                                                                                      .CUST_ACCOUNT,
                                                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
            DBG('cover account-->' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                .DEPOSIT_ACCOUNT);
            DBG('cover branch -->' || P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                .DEPOSIT_BRANCH);

            BEGIN
              SELECT JOINT_AC_INDICATOR, CUST_NO, NETTING_REQUIRED
                INTO L_COV_JNT_HOLD, L_COV_CUST_NO, L_NETTINGREQD
                FROM STTMS_CUST_ACCOUNT
               WHERE CUST_AC_NO = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                    .DEPOSIT_ACCOUNT
                 AND BRANCH_CODE = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                    .DEPOSIT_BRANCH;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('select failed' || SQLERRM);
            END;
            DBG('COVER JOINT AC INDICATOR-->' || L_COV_JNT_HOLD);
            DBG('COVER customer number-->' || L_COV_CUST_NO);

            IF NVL(L_NETTINGREQD, 'N') = 'Y' THEN
              DBG('Netting Enabled Account cannot be linked as Cover Account..');
              P_ERR_CODE   := 'ST-LMT-009';
              P_ERR_PARAMS := 'Netting Enabled Account cannot be linked as Cover Account';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
            END IF;

            SELECT COUNT(*)
              INTO L_COVOVD_CNT
              FROM STTM_SWEEP_DETAILS
             WHERE DEPOSIT_ACCOUNT = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                  .DEPOSIT_ACCOUNT
               AND DEPOSIT_BRANCH = P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                  .DEPOSIT_BRANCH
               AND SWEEP_TYPE = 'SC';

            DBG('l_covovd_cnt-->' || L_COVOVD_CNT);

            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR <>
               L_COV_JNT_HOLD AND L_COVOVD_CNT = 0 THEN
              DBG('JOINT HOLDER holding pattern mismatch of cover account and primary account');

              IF P_FUNCTION_ID = 'IADCUSAC' THEN
                P_ERR_CODE := 'IA-SWP-052';
              ELSE
                P_ERR_CODE := 'ST-SWP-052';
              END IF;

              P_ERR_PARAMS := P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                              .DEPOSIT_ACCOUNT || '~' ||
                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);

            END IF;
            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO <> L_COV_CUST_NO AND
               L_COVOVD_CNT = 0 THEN
              DBG('customer number mismatch between cover account and primary account');

              IF P_FUNCTION_ID = 'IADCUSAC' THEN
                P_ERR_CODE := 'IA-SWP-053';
              ELSE
                P_ERR_CODE := 'ST-SWP-053';
              END IF;

              P_ERR_PARAMS := P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C(I)
                              .DEPOSIT_ACCOUNT || '~' ||
                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);

            END IF;
          END LOOP;
        END IF;

        DBG('Sweep In Flage Before-->' ||
            P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED);
        DBG('sweep in flag Now-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED);

        DBG('Check whether the account is linked as cover account in any other sweep structure');
        SELECT COUNT(*)
          INTO L_COUNT_COV
          FROM STTMS_SWEEP_DETAILS
         WHERE DEPOSIT_ACCOUNT =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND DEPOSIT_BRANCH =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND SWEEP_TYPE = 'SC';
        DBG('l_count-->' || L_COUNT_COV);
        IF L_COUNT_COV > 0 AND
           (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0 OR
           P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0 OR
           P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.COUNT > 0) THEN
          DBG('Primary Account is already a cover account in another sweep structure.Delink all accounts in sweep structure');
          P_ERR_CODE   := 'ST-SWP-074';
          P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

        END IF;

        IF (NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'Y' AND
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'N') OR
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'N' THEN

          DBG('Check whether the account is linked as TD account in any other sweep structure');
          SELECT COUNT(*)
            INTO L_COUNT_TD
            FROM STTMS_SWEEP_DETAILS
           WHERE DEPOSIT_ACCOUNT =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND DEPOSIT_BRANCH =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND SWEEP_TYPE = 'ST';
          DBG('l_count-->' || L_COUNT_TD);
          IF P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0 OR
             NVL(L_COUNT_TD, 0) > 0 THEN
            DBG('Delink the Term Deposits from sweep in structure');

            IF P_FUNCTION_ID = 'IADCUSAC' THEN
              P_ERR_CODE := 'IA-SWP-058';
            ELSE
              P_ERR_CODE := 'ST-SWP-058';
            END IF;

            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);

          END IF;

          IF P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0 OR
             NVL(L_COUNT_COV, 0) > 0 THEN
            DBG('Delink the Cover Accounts from sweep in structure');

            IF P_FUNCTION_ID = 'IADCUSAC' THEN
              P_ERR_CODE := 'IA-SWP-057';
            ELSE
              P_ERR_CODE := 'ST-SWP-057';
            END IF;

            P_ERR_PARAMS := NULL;
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         P_ERR_CODE,
                         P_ERR_PARAMS);

          END IF;

          IF P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.COUNT > 0 THEN
            DBG('Delink the AD Accounts from sweep in structure');
            P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.DELETE;
          END IF;
        END IF;
      END IF;

    END IF;

    IF (P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0) THEN
      FOR I IN P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.FIRST .. P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.LAST LOOP
        DBG('p_Wrk_Stdcusac.v_sttms_doctype_check_list(i).cust_account b4 ::' || P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
            .CUST_AC_NO);
        P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).BRANCH_CODE := NVL(P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                                                        .BRANCH_CODE,
                                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).CUST_AC_NO := NVL(P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
                                                                       .CUST_AC_NO,
                                                                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        DBG('p_Wrk_Stdcusac.v_sttms_doctype_check_list(i).cust_account Aftr ::' || P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I)
            .CUST_AC_NO);
      END LOOP;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR L_INDEX IN 1 .. P_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
          IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
              IF (NVL(P_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX).PROD, '@') =
                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).PROD, '@')) THEN
                P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX1).RECORD_STAT := P_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX)
                                                                       .RECORD_STAT;
              END IF;

            END LOOP;
          END IF;
        END LOOP;
      END IF;

      DBG('Recievable amount is ' ||
          P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.RECEIVABLE_AMOUNT);

      BEGIN

        SELECT RECEIVABLE_AMOUNT
          INTO L_RECEIVABLE_AMOUNT
          FROM STTM_ACCOUNT_BALANCE
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND CUST_AC_BRN =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

        DBG('Receivable amount is ' || L_RECEIVABLE_AMOUNT);
        IF L_RECEIVABLE_AMOUNT > 0 THEN
          IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE = 'N' AND
             P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TRACK_RECEIVABLE = 'Y' THEN
            DBG('Value should not have been changed');
            P_ERR_CODE   := 'ST-ACC-262';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No balance in the account');
        WHEN OTHERS THEN
          DBG('Into when others but not going to end');
      END;

    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN

      BEGIN
        SELECT NVL(PROJECT_ACCOUNT, 'N')
          INTO L_PROJECT_ACCOUNT
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

        IF L_PROJECT_ACCOUNT = 'N' AND
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROJECT_ACCOUNT = 'Y' THEN
          P_ERR_CODE   := 'ST-PA-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED VALIDATION PROJECT ACCOUNT');
      END;
    END IF;

    BEGIN
      SELECT MASTER_ACCOUNT_NO, ONCE_AUTH
        INTO L_MASTER_ACCOUNT,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      IF L_MASTER_ACCOUNT IS NOT NULL THEN
        DBG('setting flag to Y');
        G_AUTO_DEPOSIT := 'Y';
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('setting flag to N');
        G_AUTO_DEPOSIT                                := 'N';
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH := 'N';
    END;

    DBG('p_Action_Code-->' || P_ACTION_CODE);
    DBG('IBAN_AC_NO   -->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    DBG('IBAN_REQUIRED-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);
    IF P_ACTION_CODE NOT IN ('POPDT', 'MISPKP', 'ACCVAL') THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NOT NULL THEN
        IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED, 'N') = 'N' THEN
          DBG('IBAN Account Number ' ||
              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO ||
              ' should not be entered, when IBAN Required flag is uncheked!');
          P_ERR_CODE   := 'ST-IBAN-02';
          P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;
    DBG('p_Action_Code-->' || P_ACTION_CODE);
    DBG('p_Source     -->' || P_SOURCE);
    DBG('IBAN_REQUIRED-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DEFAULT OR
       (P_SOURCE <> 'FLEXCUE' AND
       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED IS NULL AND
       P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW) THEN
      BEGIN
        SELECT NVL(ACL.IBAN_REQUIRED, 'N')
          INTO L_ACL_IBAN_REQUIRED
          FROM STTM_ACCOUNT_CLASS ACL
         WHERE ACL.ACCOUNT_CLASS =
               NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS, '**');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In WOT while selecting from STTM_ACCOUNT_CLASS!');
          DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
      DBG('l_acl_iban_required-->' || L_ACL_IBAN_REQUIRED);
      BEGIN
        SELECT NVL(CN.IBAN_CHECK_REQD, 'N')
          INTO L_CN_IBAN_CHECK_REQUIRED
          FROM STTM_COUNTRY CN
         WHERE CN.COUNTRY_CODE =
               (SELECT BR.COUNTRY_CODE
                  FROM STTM_BRANCH BR
                 WHERE BR.BRANCH_CODE = NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                            '**'));
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('In NDF while selecting from STTM_COUNTRY!');
          L_CN_IBAN_CHECK_REQUIRED := NULL;
        WHEN OTHERS THEN
          DBG('In WOT while selecting from STTM_COUNTRY!');
          DBG('Trace-->' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
          RETURN FALSE;
      END;
      DBG('L_CN_IBAN_CHECK_REQUIRED-->' || L_CN_IBAN_CHECK_REQUIRED);
      IF NVL(L_ACL_IBAN_REQUIRED, 'N') = 'Y' AND
         NVL(L_CN_IBAN_CHECK_REQUIRED, 'N') = 'Y' THEN
        DBG('Setting the STDCUSAC level IBAN_REQUIRED Flag to ''Y''!');
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED := 'Y';
      ELSE
        DBG('Setting the STDCUSAC level IBAN_REQUIRED Flag to ''N''!');
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED := 'N';
      END IF;
      DBG('IBAN_REQUIRED-->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);
    END IF;

    DBG('Calling fn_postdfltval_calls');
    IF NOT FN_POSTDFLTVAL_CALLS(P_FUNCTION_ID,
                                P_SOURCE,
                                P_ACTION_CODE,
                                P_STDCUSAC,
                                P_PREV_STDCUSAC,
                                P_WRK_STDCUSAC,
                                P_ERR_CODE,
                                P_ERR_PARAMS) THEN
      DBG('fn_postdfltval_calls has returned false');
      RETURN FALSE;
    END IF;

    DBG('p_Action_Code-->' || P_ACTION_CODE);
    DBG('IBAN_AC_NO   -->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO);
    DBG('IBAN_REQUIRED-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED);

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO IS NULL THEN
        IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_REQUIRED, 'N') = 'Y' THEN
          IF P_FUNCTION_ID NOT IN ('STDCASAC', 'STDCIF', 'STDCIFAD') THEN
            DBG('IBAN is mandatory if ''IBAN Required'' flag is checked.');
            P_ERR_CODE   := 'ST-IBAN-03';
            P_ERR_PARAMS := NULL;
            RETURN FALSE;
          END IF;
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      BEGIN
        SELECT IBAN_AC_NO
          INTO L_IBAN_AC_NO
          FROM STTM_CUST_ACCOUNT
         WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        DBG('l_iban_ac_no-->' || L_IBAN_AC_NO);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('WHEN OTHERS No iban_ac_no' || SQLERRM);
      END;

      IF L_IBAN_AC_NO IS NOT NULL AND
         L_IBAN_AC_NO <> P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IBAN_AC_NO THEN
        P_ERR_CODE   := 'ST-IBAN-04';
        P_ERR_PARAMS := NULL;
        DBG('IBAN field is modified.');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;
    END IF;

    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SOD_NOTIFICATION_PERCENT IS NOT NULL THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SOD_NOTIFICATION_PERCENT < 0 THEN
        DBG('negative value is not entertained');
        P_ERR_CODE   := 'ST-VALS-011';
        P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SOD_NOTIFICATION_PERCENT ||
                        '~@STTMS_CUST_ACCOUNT.SOD_NOTIFICATION_PERCENT~@STTMS_CUST_ACCOUNT';
        RETURN FALSE;
      END IF;
    END IF;

    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'Y' AND
       P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'N' THEN
      UPDATE STTM_CUST_ACCOUNT

         SET NO_OF_CHQ_REJ_RESET_ON = GLOBAL.APPLICATION_DATE

       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'N' AND
         P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'Y' THEN
        DBG('Cheque book facility is being enabled. Do you want to continue');
        P_ERR_CODE := 'CS-00014';

        P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY ||
                        '~@STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY~@STTMS_CUST_ACCOUNT';
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

        DBG('After commenting the Return false.');
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN P_WRK_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
          L_CUST_PROD := 0;
          SELECT COUNT(*)
            INTO L_CUST_PROD
            FROM ICVW_PR_CUST
           WHERE PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).PROD
             AND CUST = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
          DBG('l_cust_prod is :' || L_CUST_PROD);
          DBG('p_Wrk_Stdcusac.v_Ictms_Acc_Pr(i).record_stat is :' || P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
              .RECORD_STAT);
          IF L_CUST_PROD = 0 AND P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
            .RECORD_STAT = 'O' THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-575',
                         P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);

          END IF;
        END LOOP;
      END IF;

      IF P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR.LAST LOOP
          L_CUST_PROD := 0;
          SELECT COUNT(*)
            INTO L_CUST_PROD
            FROM ICVW_PR_CUST
           WHERE PROD = P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD
             AND CUST = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

          IF L_CUST_PROD = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-576',
                         P_STDCUSAC.TY_ICCHSPCN.V_ICTMS_ACC_PR(I).PROD);

          END IF;
        END LOOP;
      END IF;

      IF P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.FIRST .. P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR.LAST LOOP
          L_CUST_PROD := 0;
          SELECT COUNT(*)
            INTO L_CUST_PROD
            FROM ICVW_PR_CUST
           WHERE PROD = P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD
             AND CUST = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

          IF L_CUST_PROD = 0 THEN
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'ST-ACC-577',
                         P_STDCUSAC.TY_ICCCSPCN.V_ICTMS_ACC_PR(I).PROD);

          END IF;
        END LOOP;
      END IF;

      SELECT AC_CLASS_TYPE, TD_RATECHART_ALLOW, RD_FLAG
        INTO L_AC_CLASS_TYPE, L_RATE_CHART, L_RDFLAG
        FROM STTM_ACCOUNT_CLASS
       WHERE

       ACCOUNT_CLASS = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

      DBG(' account class type ' || L_AC_CLASS_TYPE);
      IF (L_AC_CLASS_TYPE = 'Y' AND NVL(L_RATE_CHART, 'N') = 'N') OR

         (NVL(L_RDFLAG, 'N') = 'Y' AND GLOBAL.X9$ <> 'BTNBNB') OR
         (NVL(L_RDFLAG, 'N') = 'Y' AND GLOBAL.X9$ = 'BTNBNB' AND
         NVL(L_RATE_CHART, 'N') = 'N') OR

         L_AC_CLASS_TYPE = 'N' AND
         P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
          FOR J IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
            IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
             .TD_RATE_CODE IS NOT NULL THEN
              DBG(' ERROR CODE' ||
                  'TD rate cannot be entered for rate chart not marked');
              P_ERR_CODE := 'ST-IC-0010';
              RETURN FALSE;
            END IF;
          END LOOP;
        END IF;
      END IF;

      IF L_AC_CLASS_TYPE = 'Y' AND
         P_ACTION_CODE IN
         (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

        DBG(' COUNT' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);

        DBG('coming action code as' || P_ACTION_CODE);

        IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
          FOR I IN P_WRK_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
            DBG(' COUNT for prod' || P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).PROD);
            FOR EACHREC IN CR_PRODS(P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).PROD) LOOP
              DBG(' prod ' || EACHREC.PROD);
              DBG(' eachrec ');
              SELECT RULE
                INTO L_RULE_ID
                FROM ICTMS_PR_INT
               WHERE PRODUCT_CODE = EACHREC.PROD;
              DBG(' l_rule_id  ' || L_RULE_ID);
              IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
                FOR J IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                  IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                   .PROD = EACHREC.PROD THEN
                    BEGIN
                      SELECT UDE_TYPE
                        INTO L_UDE_TYPE
                        FROM ICTM_RULE_UDE
                       WHERE UDE_ID = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                            .UDE_ID
                         AND RULE_ID = L_RULE_ID;

                    EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                        L_UDE_TYPE := NULL;
                    END;

                    DBG(' l_ude_type  ' || L_UDE_TYPE || 'ude value' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                        .UDE_VALUE);
                    IF L_UDE_TYPE = 'C' THEN

                      IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                       .RATE_CODE IS NOT NULL AND
                          NVL(L_RATE_CHART, 'N') = 'Y' THEN
                        DBG(' ERROR CODE' ||
                            'manual entry for rate code not entertaind for TD aclass');
                        P_ERR_CODE   := 'ST-IC-0002';
                        P_ERR_PARAMS := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                                        .UDE_ID;
                        RETURN FALSE;
                      END IF;
                      IF NVL(L_RATE_CHART, 'N') = 'Y' THEN

                        IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                         .TD_RATE_CODE IS NULL THEN
                          DBG(' ERROR CODE' ||
                              'TD rate code cannot be null for TD account');
                          P_ERR_CODE := 'ST-IC-0003';
                          PR_LOG_ERROR(P_FUNCTION_ID,
                                       'FLEXCUBE',
                                       P_ERR_CODE,
                                       '');

                        END IF;
                      END IF;
                      DBG('MATURITY DATE' ||
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
                      DBG('TENOR ' ||
                          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20);
                      DBG('FOR  UDE ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                          .UDE_ID);
                      DBG('checking rd flag' ||
                          P_WRK_STDCUSAC.V_ICTMS_ACC.RD_FLAG);

                    END IF;

                    IF L_UDE_TYPE <> 'C' AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
                      .TD_RATE_CODE IS NOT NULL AND
                       NVL(L_RATE_CHART, 'N') = 'N' THEN
                      DBG('TD Rate Code cannot be entered when the UDE Type is Rate Code as Rate');
                      P_ERR_CODE := 'ST-IC-1008';
                      RETURN FALSE;
                    END IF;

                    EXIT WHEN L_UDE_TYPE = 'C' AND NVL(L_RATE_CHART, 'N') = 'Y';
                  END IF;
                END LOOP;
              END IF;

              IF L_UDE_TYPE <> 'C' AND NVL(L_RATE_CHART, 'N') = 'Y' THEN

                DBG(' ERROR CODE' ||
                    'UDE as rate as rate code not mainteaned');
                P_ERR_CODE := 'ST-IC-0004';
                RETURN FALSE;
              END IF;
            END LOOP;
          END LOOP;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'NEW' AND P_SOURCE = 'FLEXCUBE' THEN

      DBG('account with dormant state  ' ||
          P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT);
      IF P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT = 'Y' THEN

        DBG('account can not be created in dormant state');
        P_ERR_CODE := 'ST-CUS208';
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      DBG('Acc. opening date : ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' AND
         P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21 = 'Q' THEN
        DBG('get value date');
        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' THEN

          CSPKSS_CLG_SERV.PR_BREAK_ROUTING_NO(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD71,
                                              L_SECTORCODE,
                                              P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23,
                                              P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25);

          DBG('l_sectorcode-->' || L_SECTORCODE);
          DBG('p_stdcusac.v_cstbs_ui_columns.char_field48--->' ||
              P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD48);

          IF NOT CSPKSS_CLG_SERVICES.FN_GET_VALUE_DATES(P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD23,
                                                        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD25,
                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD48,
                                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                        NULL,
                                                        L_SECTORCODE,
                                                        L_CRVALDT,
                                                        L_DRVALDT,
                                                        L_LATE_CLEARING,
                                                        L_ERR_CODE,
                                                        GLOBAL.APPLICATION_DATE,
                                                        'N',
                                                        'N') THEN

            DBG('failed to get the Value date');
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, '');
            RETURN FALSE;
          ELSE

            DBG('value date -->' || L_CRVALDT);
            DBG('account open date-->' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

            IF CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                        L_CRVALDT,
                                        L_RESULT) = TRUE THEN
              DBG('Cheque clearing date is holiday ' || L_RESULT);
              IF NVL(L_RESULT, '*') = 'H' THEN

                L_CRVALDT := CEPKSS_DATE.FN_GETWORKINGDAY('LCL',
                                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                          L_CRVALDT,
                                                          'N');
              END IF;
              DBG('Working date --> ' || L_CRVALDT);
            END IF;

            IF L_CRVALDT <>
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
              DBG('acount open date is different from the value date of the product');
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'ST-ACC-242',
                           L_CRVALDT);
              RETURN FALSE;
            END IF;
          END IF;
        END IF;
      ELSE

        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE >
           GLOBAL.APPLICATION_DATE THEN
          DBG('Validation Failed Account Open Date');
          P_ERR_CODE := 'ST-CUS10';
          RETURN FALSE;
        END IF;
      END IF;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN

        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE <>
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.STATUS_SINCE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
        END IF;
      END IF;

      SELECT COUNT(*)
        INTO L_COUNT1
        FROM STTBS_TRANSFERRED_ACCOUNT S
       WHERE S.CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND S.BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      DBG('l_count1 -->' || L_COUNT1);

      IF L_COUNT1 = 0 THEN

        IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
          IF NOT CEPKSS_DATE.FN_ISHOLIDAY('LCL',
                                          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                          L_RES) THEN
            DBG('cepkss_date.fn_isholiday has returned false... but continuing');
            NULL;
          END IF;
          DBG('IS Holiday  : ' || L_RES);
          IF L_RES = 'H' THEN
            OVPKS.PR_APPENDTBL('ST-CUS105', NULL);
          END IF;
        END IF;
      END IF;

      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANT_PARAM = 'M' THEN

        IF P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT <>
           P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT THEN
          IF P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT = 'N' THEN

            DBG('if the account WAS in dormant state PREVIOUSLY and dormant parameter WAS manual PREVIOUSLY then only  dormancy can be updated to N ');

          ELSE

            DBG('if the account was in NON DORMANT state PREVIOUSLY and dormant parameter WAS manual PREVIOUSLY then WE can NOT update the dormancy ');
            P_ERR_CODE := 'ST-CUS200';
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      IF ((P_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANT_PARAM <> 'M') AND

         (P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT <>
         P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT))

       THEN
        DBG('if the dormanCY parameter is NOT manual then  updatATION FOR the dormancy CANNOT BE DONE ');
        P_ERR_CODE := 'ST-CUS209';
        RETURN FALSE;
      END IF;

      BEGIN
        SELECT AC_CLASS_TYPE
          INTO P_ACCT_TYPE
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

        IF P_ACCT_TYPE = 'Y' THEN
          IF P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN

            IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'N' AND
               P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'S' THEN
              P_ERR_CODE := 'ST-0013';
              RETURN FALSE;
            END IF;

          END IF;

          DBG('p_stdcusac.v_Ictms_Acc.Rollover_Amt is ' ||
              P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT);
          DBG('p_stdcusac.v_ictms_acc.maturity_amount is ' ||
              P_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT);

        END IF;
      END;

    END IF;

    IF P_ACTION_CODE = 'NEW' THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' THEN

        L_COUNT := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT;
        DBG('l_Count' || L_COUNT);
        IF L_COUNT > 0 THEN

          FOR L_INDEX IN 1 .. L_COUNT LOOP
            L_BLK := 'SVTMS_ACC_SIG_DET';
            L_FLD := 'SVTMS_ACC_SIG_DET.CIF_SIG_ID';
            IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
             .CIF_SIG_ID IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_LOV_COUNT
                FROM (SELECT CIF_SIG_ID, CIF_SIG_NAME
                        FROM SVTMS_CIF_SIG_MASTER
                       WHERE CIF_ID =
                             P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO)
               WHERE CIF_SIG_ID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                    .CIF_SIG_ID;
              IF L_LOV_COUNT = 0 THEN
                DBG('Invalid Value For The Field  :CIF_SIG_ID:' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                    .CIF_SIG_ID);
                L_KEY := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                          G_UI_NAME,
                                                          'SVTMS_ACC_SIG_DET.CIF_SIG_ID') || '-' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                        .CIF_SIG_ID;
                PR_LOG_ERROR(P_SOURCE,
                             'SVCACSIG',
                             'ST-VALS-013',
                             P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                             .CIF_SIG_ID || '~@SVTMS_ACC_SIG_DET.CIF_SIG_ID' || '~' ||
                              L_KEY || '~@SVTMS_ACC_SIG_DET');
              END IF;
            END IF;
          END LOOP;
        END IF;

      ELSIF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
        L_COUNT := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT;
        DBG('l_Count' || L_COUNT);
        IF L_COUNT > 0 THEN
          DBG('Coming here to check whether the signature is valid for the customer');
          FOR L_INDEX IN 1 .. L_COUNT LOOP
            L_BLK := 'SVTMS_ACC_SIG_DET';
            L_FLD := 'SVTMS_ACC_SIG_DET.CIF_SIG_ID';
            IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
             .CIF_SIG_ID IS NOT NULL THEN
              SELECT COUNT(*)
                INTO L_LOV_COUNT
                FROM (SELECT CIF_SIG_ID, CIF_SIG_NAME
                        FROM SVTMS_CIF_SIG_MASTER
                       WHERE CIF_ID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                            .CIFID)
               WHERE CIF_SIG_ID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                    .CIF_SIG_ID;
              IF L_LOV_COUNT = 0 THEN
                DBG('Invalid Value For The Field  :CIF_SIG_ID:' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                    .CIF_SIG_ID);
                PR_LOG_ERROR(P_SOURCE,
                             'SVCACSIG',
                             'ST-VALS-013',
                             P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                             .CIF_SIG_ID || '~@SVTMS_ACC_SIG_DET.CIF_SIG_ID' || '~' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
                             .CIFID || '~@SVTMS_ACC_SIG_DET');
              END IF;
            END IF;
          END LOOP;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN

      DBG('customer acc no->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      BEGIN
        SELECT CHEQUE_BOOK_FACILITY
          INTO L_CHQ_FAC
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      END;
      DBG('Previous chq statement-->' ||
          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY);
      IF L_CHQ_FAC = 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'N' THEN
        DBG('Cheque book facility is unchecked from front end');
        UPDATE STTM_CUST_ACCOUNT
           SET NSF_AUTO_UPDATE = 'M'
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        DBG('after the update statement');
      END IF;

    END IF;

    IF (P_ACTION_CODE = 'MODIFY' OR P_ACTION_CODE = 'NEW') THEN
      BEGIN
        SELECT AC_CLASS_TYPE
          INTO P_ACCT_TYPE
          FROM STTMS_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        DBG('SFR 473 TD Value  ' || P_ACCT_TYPE);
      END;

      IF P_ACCT_TYPE = 'Y' THEN
        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'N' AND
           P_STDCUSAC.V_ICTMS_ACC.CLOSE_ON_MATURITY = 'Y' THEN
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
        END IF;

        DBG('For auto');
        IF P_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN

          IF P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_TYPE = 'S' THEN

            BEGIN
              SELECT NVL(MIN_AMOUNT, 0)
                INTO P_MIN_AMT
                FROM STTMS_ACCLS_MINMAX_AMT_CCY
               WHERE ACCOUNT_CLASS =
                     P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                 AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
              DBG('Min Amount selecting from sttms_accls_minmax_amt_ccy : ' ||
                  P_MIN_AMT);
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                BEGIN
                  SELECT NVL(MIN_AMOUNT, 0)
                    INTO P_MIN_AMT
                    FROM STTMS_ACCLS_MINMAX_AMT_CCY
                   WHERE ACCOUNT_CLASS =
                         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS
                     AND CCY = '*.*';
                  DBG('Selecting minimum amount for ccy *.* : ' ||
                      P_MIN_AMT);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    P_MIN_AMT := 0;
                    DBG('Assigning Mininum Amount has zero when it is not maintained');
                END;
              WHEN OTHERS THEN
                DBG('Min Max Amount not maintained for the account currency');
            END;
            DBG('p_min_amt : ' || P_MIN_AMT);

            IF P_MIN_AMT > P_STDCUSAC.V_ICTMS_ACC.ROLLOVER_AMT THEN
              P_ERR_CODE := 'ST-0016';
              RETURN FALSE;
            END IF;
          END IF;

        END IF;

      END IF;
    END IF;

    IF P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.COUNT > 0 THEN
      FOR J IN P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.FIRST .. P_STDCUSAC.V_ACCOUNT_PROV_PERCENT.LAST LOOP
        P_WRK_STDCUSAC.V_ACCOUNT_PROV_PERCENT(J).BRANCH_CODE := GLOBAL.CURRENT_BRANCH;
      END LOOP;
    END IF;

    IF P_ACTION_CODE NOT IN ('NEW') THEN
      DBG('sid here 1');
      IF P_SOURCE <> 'FLEXCUBE' THEN
        DBG('sid here 2');
        IF P_ACTION_CODE <> CSPKS_REQ_GLOBAL.P_CLOSE THEN

          L_MOD_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO;

          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO := L_MOD_NO;

        END IF;
        IF NOT STPKS_STDCUSAC_UTILS_2.FN_POPULATE_AMTDT(P_FUNCTION_ID,
                                                        P_WRK_STDCUSAC) THEN
          DBG('stpks_stdcusac_utils_2.fn_populate_amtdt has returned false');
          RETURN FALSE;
        END IF;
      END IF;
    ELSE

      DBG('sid here 3');
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_OPENING_BAL := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TODAY_TOVER_DR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TODAY_TOVER_CR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_OPENING_BAL    := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TODAY_TOVER_DR   := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TODAY_TOVER_CR   := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_DR          := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_CR          := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_TANK_UNCOLLECTED := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TANK_DR      := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_TANK_CR      := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_CURR_BALANCE := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_CURR_ACC_BAL           := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_UNCOLLECTED            := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.WITHDRAWABLE_UNCOLLED_FUND := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_BLOCKED_AMT            := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.RECEIVABLE_AMOUNT          := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL       := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_ACCRUED_DR_IC := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_ACCRUED_CR_IC := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DR_INT_DUE        := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.CHG_DUE           := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_DR     := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.ACY_UNAUTH_CR := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_UNCOLLECTED      := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_DR          := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_CR          := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_UNAUTH_TANK_UNCOLLECTED := 0;

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_DR          := TO_DATE(GLOBAL.APPLICATION_DATE,
                                                                              'DD-MM-RRRR');
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_CR          := TO_DATE(GLOBAL.APPLICATION_DATE,
                                                                              'DD-MM-RRRR');
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_DR_ACTIVITY := TO_DATE(GLOBAL.APPLICATION_DATE,
                                                                              'DD-MM-RRRR');
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.DATE_LAST_CR_ACTIVITY := TO_DATE(GLOBAL.APPLICATION_DATE,
                                                                              'DD-MM-RRRR');

      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_MTD_TOVER_DR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.ACY_MTD_TOVER_CR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_MTD_TOVER_DR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.LCY_MTD_TOVER_CR := 0;
      P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.PROVISION_AMOUNT := 0;
    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') AND
       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH <> 'Y' THEN
      DBG('INSIDE INITALISING OFFSET DETAILS');
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT > 0 THEN

        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION IS NOT NULL THEN
          IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION = 'G' THEN
            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT IS NULL THEN
              BEGIN
                SELECT GL_CODE, BRANCH_CODE
                  INTO P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT,
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH
                  FROM STTM_PAYIN_MODE
                 WHERE BRANCH_CODE =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND PAYIN_OPTION = 'G'

                   AND RECORD_STAT = 'O'
                   AND AUTH_STAT = 'A';

                DBG('INF_OFFSET_ACCOUNT INITIALISE-->' ||
                    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  P_ERR_CODE := 'ST-ACC-551';
                  DBG('No data found in GL ACC INITIALISE-->' || SQLERRM);
                  RETURN FALSE;
                WHEN OTHERS THEN
                  DBG('OTHERS in GL ACC INITIALISE-->' || SQLERRM);
                  RETURN FALSE;
              END;
            END IF;
          END IF;
        END IF;

        IF NOT CVPKS_UTILS.FN_GET_BRANCH_RECORD(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                L_BRANCH_RECORD) THEN
          DBG('Failed in getting branch details' || SQLERRM);
          RETURN FALSE;
        END IF;
        DBG('back_value_days ' || L_BRANCH_RECORD.BACK_VALUE_DAYS);
        DBG('back_valued check reqd ' ||
            L_BRANCH_RECORD.BACK_VALUED_CHK_REQ);
        DBG('application_date ' || GLOBAL.APPLICATION_DATE);
        DBG('ac_open_date is ' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
        IF NVL(L_BRANCH_RECORD.BACK_VALUED_CHK_REQ, 'N') = 'Y' AND
           ((GLOBAL.APPLICATION_DATE -
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) >
            NVL(L_BRANCH_RECORD.BACK_VALUE_DAYS, 0)) THEN
          DBG('Value Date of account opening exceeds the Back Valued Days maintained in Branch Parameter');
          P_ERR_CODE   := 'ST-ACC-804';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;

      ELSIF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION         := NULL;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT        := NULL;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH         := NULL;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE := 'N';
      END IF;

    END IF;

    IF (P_ACTION_CODE = 'MODIFY') THEN
      DBG('HELLO2-->' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'Y' THEN
        DBG('HELLO3');

        IF (NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT, 0) <>
           NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT, 0) OR
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION, 'A') <>
           NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION, 'A') OR
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH, 'A') <>
           NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH, 'A') OR
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT, 'A') <>
           NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT,
                'A') OR

           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE,
                'N') <> NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_WAIVE_ACC_OPEN_CHARGE,
                             'N'))

         THEN
          DBG('initial funding fields are not amendable.');
          P_ERR_CODE := 'ST-ACC-199';
          RETURN FALSE;
        END IF;
      END IF;

      IF P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CREATE_POOL = 'Y' AND
         P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT = 0 THEN
        DBG('Can not delete OD linkage while modifying');
        P_ERR_CODE := 'ST-ACC-459';
        RETURN FALSE;
      END IF;

    END IF;

    BEGIN
      SELECT X.CUSTOMER_TYPE, X.SHORT_NAME
        INTO L_CUST_TYPE, L_NAME
        FROM STTMS_CUSTOMER X
       WHERE X.CUSTOMER_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('no customer type is maintained');
        L_CUST_TYPE := 'I';
    END;

    IF (CSPKS_FEATURE.FN_INSTALLED('CORPACC_SIG_REPLICATE') AND
       L_CUST_TYPE = 'C') OR L_CUST_TYPE = 'I' THEN
      L_SIG_REPLICATE := 'Y';
    ELSE
      L_SIG_REPLICATE := 'N';
    END IF;

    IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG = 'Y'

       AND L_SIG_REPLICATE = 'Y' AND
       P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'S' AND
       P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('THAKUR CHANGES STArts');
      DBG('Current Signatures here' ||
          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);

      K := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT;
      K := K + 1;
      FOR J IN (SELECT M.*
                  FROM SVTM_CIF_SIG_MASTER M
                 WHERE M.CIF_ID = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
                   AND M.AUTH_STAT = 'A'
                   AND M.RECORD_STAT = 'O'
                   AND M.REPL_TO_ACC = 'Y'
                   AND EXISTS
                 (SELECT 1
                          FROM SVTM_CIF_SIG_DET L
                         WHERE L.CIF_ID = M.CIF_ID
                           AND L.CIF_SIG_ID = M.CIF_SIG_ID)) LOOP

        DBG('Came here to replicate');

        L_REPLICATED := FALSE;
        IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
          DBG('ALREADY SIGNATURES ARE PRESENT');
          FOR IDX IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
            DBG('idx is :' || IDX);
            IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(IDX)
             .CIF_SIG_ID = J.CIF_SIG_ID THEN
              DBG('REPLICA FOUND');
              L_REPLICATED := TRUE;
              EXIT;
            END IF;
          END LOOP;
        END IF;
        IF NOT L_REPLICATED THEN
          DBG('Not a replicated signature.. so can be replicated');

          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K).CIFID := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
          P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(K)('UIRELATION') := 'Authorized Signatory';

          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K).BRANCH := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K).ACC_NO := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K).CIF_SIG_ID := J.CIF_SIG_ID;

          P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K).CIF_SIG_NAME := J.CIF_SIG_NAME;

          K := K + 1;
        END IF;
      END LOOP;

    END IF;

    IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
      DBG('Coming here for JH codel');
      DBG('12.4_SUPPORT_RETRO_26229978 Coming here');
      FOR I IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
        BEGIN
          DBG('selecting the relation type for::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
              .CIFID);
          SELECT DECODE(JOINT_HOLDER,
                        'CON',
                        'Customer contact person',
                        'CUS',
                        'Custodian',
                        'DEV',
                        'Developer',
                        'GUA',
                        'Guarantor',
                        'GUR',
                        'Guardian',
                        'JAF',
                        'Joint and first',
                        'JAO',
                        'Joint and other',
                        'JOF',
                        'Joint or first',
                        'JOO',
                        'Joint or other',
                        'NOM',
                        'Nominee',
                        'REL',
                        'Related for enquiry',
                        'SOL',
                        'Solicitor',
                        'SOW',
                        'Sole owner',
                        'THR',
                        'Third party',
                        'TRU',
                        'Trustee',
                        'VAL',
                        'Valuer',
                        'POA',
                        'Power of attorney',
                        'Authorized signatory')
            INTO L_JHCOD
            FROM STTM_AC_LINKED_ENTITIES
           WHERE BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND JOINT_HOLDER_CODE = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                .CIFID;
          DBG('Relation type for::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
              .CIFID || '::' || L_JHCOD);
          P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION') := L_JHCOD;
        EXCEPTION

          WHEN NO_DATA_FOUND THEN
            DBG('12.4_SUPPORT_RETRO_26229978 Coming in Exception');
            BEGIN
              SELECT RELATION
                INTO P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION')
                FROM SVTM_JH_TEMPTBL
               WHERE BRANCH =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND ACC_NO =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                 AND CIFID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                    .CIFID;
              DBG('Relation type for :: ' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                  .CIFID || '::' ||
                  P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET') (I)
                  ('UIRELATION'));
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                DBG('12.4_SUPPORT_RETRO_26229978 Handling Exception when record is being created');
            END;

          WHEN OTHERS THEN
            DBG('No jointholders present,so this signature will be authorised signatory ');
            P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION') := 'Authorized signatory';

        END;

      END LOOP;

    END IF;

    DBG('THAKUR HERE WITH ACTION::' || P_ACTION_CODE ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG);
    IF P_ACTION_CODE = 'REP_ALL' OR P_SOURCE <> 'FLEXCUBE' OR
       (P_FUNCTION_ID = 'STDCASAC' AND P_ACTION_CODE <> 'DEFAULT') THEN
      DBG('Going to do operations on temp table');
      BEGIN
        DELETE FROM SVTM_JH_TEMPTBL
         WHERE ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Nothing to delete');
      END;
      BEGIN
        DBG('Cust_No->' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
        DBG('Cust_Ac_No-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        DBG('branch_code-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        DBG('Going to insert in SVTM_JH_TEMPTBL');
        INSERT INTO SVTM_JH_TEMPTBL
        VALUES
          (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
           'Authorized Signatory',
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
        DBG('COUNT->' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
        IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
          FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
            IF (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE,
                    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) <=
               GLOBAL.APPLICATION_DATE) AND
               (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                    GLOBAL.APPLICATION_DATE) >= GLOBAL.APPLICATION_DATE) THEN
              L_JHCOD1 := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                          .JOINT_HOLDER;
              DBG('l_jhcod1->' || L_JHCOD1);
              SELECT DECODE(L_JHCOD1,
                            'CON',
                            'Customer contact person',
                            'CUS',
                            'Custodian',
                            'DEV',
                            'Developer',
                            'GUA',
                            'Guarantor',
                            'GUR',
                            'Guardian',
                            'JAF',
                            'Joint and first',
                            'JAO',
                            'Joint and other',
                            'JOF',
                            'Joint or first',
                            'JOO',
                            'Joint or other',
                            'NOM',
                            'Nominee',
                            'REL',
                            'Related for enquiry',
                            'SOL',
                            'Solicitor',
                            'SOW',
                            'Sole owner',
                            'THR',
                            'Third party',
                            'TRU',
                            'Trustee',
                            'VAL',
                            'Valuer',
                            'POA',
                            'Power of attorney',
                            'Authorized signatory')
                INTO L_REL
                FROM DUAL;
              DBG('l_rel->' || L_REL);
              DBG('Going to insert in SVTM_JH_TEMPTBL2');
              INSERT INTO SVTM_JH_TEMPTBL
              VALUES
                (P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                 .JOINT_HOLDER_CODE,
                 L_REL,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
              DBG('Inserted for ::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                  .JOINT_HOLDER_CODE);
            END IF;
          END LOOP;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Insertion failed.' || SQLERRM || ' and trace: ' ||
              DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      END;

      IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
        DBG('Source is not flexcube.. Do save the signature details maintained in the account signatory subsystem, and do the replication for remaining joint holder signatures..');
        L_COUNTCIF := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
        DBG('Total added Joint Holders ::' || L_COUNTCIF);
        IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
          DBG('came here Total added Joint Holder');
          FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
            DBG('will form the string now::' || I);
            IF (I = L_COUNTCIF) THEN
              DBG('Last Record::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                  .JOINT_HOLDER_CODE);
              L_TEMP_JHCIF := L_TEMP_JHCIF || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER_CODE;
              L_TEMP_JHREL := L_TEMP_JHREL || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER;
            ELSE
              L_TEMP_JHCIF := L_TEMP_JHCIF || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER_CODE || '@';
              L_TEMP_JHREL := L_TEMP_JHREL || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                             .JOINT_HOLDER || '@';
            END IF;
          END LOOP;
          DBG('Joint Holder Values ::' || L_TEMP_JHCIF);
          DBG('Added Relations::' || L_TEMP_JHREL);
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99  := L_TEMP_JHCIF;
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD100 := L_TEMP_JHREL;
          DBG('Joint Holder Values ::' ||
              P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99);
          DBG('Added Relations::' ||
              P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD100);
        END IF;
      END IF;

      DBG('Calling Fn_JH_Sig_Repl');
      IF NOT FN_JH_SIG_REPL(P_FUNCTION_ID,
                            P_ACTION_CODE,
                            P_PREV_STDCUSAC,
                            P_WRK_STDCUSAC,
                            P_ERR_CODE,
                            P_ERR_PARAMS) THEN
        DBG('Fn_JH_Sig_Repl has returned false');
        RETURN FALSE;
      END IF;

      IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
        DBG('Coming here for Relation');
        FOR I IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
          BEGIN
            SELECT RELATION
              INTO L_REL
              FROM SVTM_JH_TEMPTBL
             WHERE ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
               AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND CIFID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                  .CIFID;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No relation found');
          END;
          P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION') := L_REL;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG = 'Y' AND

         L_SIG_REPLICATE = 'Y' AND
         P_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
        DBG('Going to replicate now for the left signatures');
        FOR I IN (SELECT *
                    FROM SVTM_JH_TEMPTBL
                   WHERE ACC_NO =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                     AND BRANCH =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) LOOP
          FOR J IN (SELECT M.*
                      FROM SVTM_CIF_SIG_MASTER M
                     WHERE M.CIF_ID = I.CIFID
                       AND M.AUTH_STAT = 'A'
                       AND M.RECORD_STAT = 'O'
                       AND M.REPL_TO_ACC = 'Y'
                       AND EXISTS
                     (SELECT 1
                              FROM SVTM_CIF_SIG_DET L
                             WHERE L.CIF_ID = M.CIF_ID
                               AND L.CIF_SIG_ID = M.CIF_SIG_ID)) LOOP
            INSERT INTO SVTM_ACC_SIG_DET_TEMP
            VALUES
              (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
               J.CIF_SIG_ID,
               '',
               '',
               '',
               '',
               '',

               J.CIF_SIG_NAME,

               I.CIFID);
            DBG('Record inserted in the temp table for::' || I.CIFID ||
                ' and ' || J.CIF_SIG_ID);
          END LOOP;
        END LOOP;

        DBG('Currently existing signatories on the screen::' ||
            P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);

        IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
          L_ESIG_COUNT := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT;
          DBG('Currently existing signature count::' || L_ESIG_COUNT);
          L_ESIG_COUNT := L_ESIG_COUNT + 1;
          FOR I IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
            BEGIN
              DBG('Going to delete the existing signature::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                  .CIFID);
              DELETE FROM SVTM_ACC_SIG_DET_TEMP
               WHERE BRANCH =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND ACC_NO =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                 AND CIFID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                    .CIFID
                 AND CIF_SIG_ID = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                    .CIF_SIG_ID;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Signature not in the temp list');
            END;
          END LOOP;
          DBG('Get the table data into record');
          OPEN C_V_SVTMS_ACC_SIG_DET_TEMP;
          LOOP
            FETCH C_V_SVTMS_ACC_SIG_DET_TEMP BULK COLLECT
              INTO L_REC_SIG_DET;
            EXIT WHEN C_V_SVTMS_ACC_SIG_DET_TEMP%NOTFOUND;
          END LOOP;
          CLOSE C_V_SVTMS_ACC_SIG_DET_TEMP;
          DBG('additional signature which should appear after save::' ||
              L_REC_SIG_DET.COUNT);
          IF L_REC_SIG_DET.COUNT > 0 THEN
            FOR J IN L_REC_SIG_DET.FIRST .. L_REC_SIG_DET.LAST LOOP
              DBG('First getting the name for the customer');
              BEGIN
                SELECT X.CUSTOMER_TYPE, X.SHORT_NAME
                  INTO L_CUST_TYPE, L_NAME
                  FROM STTMS_CUSTOMER X
                 WHERE X.CUSTOMER_NO = L_REC_SIG_DET(J).CIFID;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('no customer type is maintained');
                  L_CUST_TYPE := 'I';
              END;

              IF L_SIG_REPLICATE = 'Y' THEN
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).CIFID := L_REC_SIG_DET(J)
                                                                                      .CIFID;
                P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(L_ESIG_COUNT)('UIRELATION') := '';
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).BRANCH := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).ACC_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).CIF_SIG_ID := L_REC_SIG_DET(J)
                                                                                           .CIF_SIG_ID;

                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).CIF_SIG_NAME := L_REC_SIG_DET(J)
                                                                                             .CIF_SIG_NAME;

                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).SIG_TYPE := L_REC_SIG_DET(J)
                                                                                         .SIG_TYPE;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).SIG_MSG := L_REC_SIG_DET(J)
                                                                                        .SIG_MSG;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).SOLO_SUFFICIENT := L_REC_SIG_DET(J)
                                                                                                .SOLO_SUFFICIENT;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_ESIG_COUNT).APPROVAL_LIMIT := L_REC_SIG_DET(J)
                                                                                               .APPROVAL_LIMIT;

                L_ESIG_COUNT := L_ESIG_COUNT + 1;

              END IF;
            END LOOP;
          END IF;
        ELSIF (P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT = 0) AND
              ((CSPKS_FEATURE.FN_INSTALLED('CORPACC_SIG_REPLICATE') AND
              L_CUST_TYPE = 'C') OR L_CUST_TYPE = 'I') THEN
          DBG('All the replicated signatures should appear on the screen');
          DBG('Doing bulk collect of the temp data into screen');

          OPEN C_V_SVTMS_ACC_SIG_DET_TEMP;
          LOOP
            FETCH C_V_SVTMS_ACC_SIG_DET_TEMP BULK COLLECT
              INTO P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET;
            EXIT WHEN C_V_SVTMS_ACC_SIG_DET_TEMP%NOTFOUND;
          END LOOP;
          CLOSE C_V_SVTMS_ACC_SIG_DET_TEMP;

        END IF;
        BEGIN
          DBG('Desired work done,so deleting the temporary signatory table ');
          DELETE FROM SVTM_ACC_SIG_DET_TEMP
           WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No signatures are there to delete');
        END;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.JOINT_AC_INDICATOR = 'J' THEN
        DBG('Coming here to check whether the cifid is valid one');
        IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
          IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
            L_VALIDCIF := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
            FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
              L_VALIDCIF := L_VALIDCIF || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                           .JOINT_HOLDER_CODE;
            END LOOP;
            DBG('String Formed to check the valid cifid::' || L_VALIDCIF);
            FOR J IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
              DBG('Going to check the CIFID::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(J)
                  .CIFID);
              IF INSTR(L_VALIDCIF,
                       P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(J)
                       .CIFID) = 0 THEN
                P_ERR_CODE   := 'ST-ACC-998';
                P_ERR_PARAMS := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(J)
                                .CIFID;

                DBG('#p_Function_Id::' || P_FUNCTION_ID);
                DBG('#p_Err_Code::' || P_ERR_CODE);
                DBG('#p_Err_Params::' || P_ERR_PARAMS);
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);

              END IF;
            END LOOP;
          END IF;
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      DBG('Account ==> ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      DBG('Verifying ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO ||
          ' for a joint venture customer');

      FOR I IN 1 .. P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP

        DBG('p_Wrk_Stdcusac.v_Cust_Account_Linkages(i).customer_no .' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .CUSTOMER_NO);
        BEGIN

          SELECT AVAILMENT_DATE
            INTO L_AVAILMENT_DATE
            FROM GETM_FACILITY
           WHERE LIAB_ID = (SELECT A.ID
                              FROM GETM_LIAB A, GETM_LIAB_CUST B
                             WHERE B.LIAB_ID = A.ID
                               AND B.CUSTOMER_NO = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                  .CUSTOMER_NO)
             AND LINE_CODE || LINE_SERIAL = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                .LINKED_REF_NO;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG(' in no data found .');
            L_AVAILMENT_DATE := NULL;
        END;
        DBG('l_availment_date .' || L_AVAILMENT_DATE);
        DBG('application_date .' || GLOBAL.APPLICATION_DATE);
        IF L_AVAILMENT_DATE < GLOBAL.APPLICATION_DATE THEN
          DBG('Facility with availment date less then system date cannot be attach to customer account.');
          P_ERR_CODE   := 'ST-ACC-901';
          P_ERR_PARAMS := 'Facility with availment date less then system date cannot be attach to customer account';

        END IF;

        IF NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).LINKAGE_PERCENTAGE,
               0) <= 0 THEN
          DBG('Percentage of contribution should not be less or equal to Zero%.');
          P_ERR_CODE   := 'ST-ACC-163';
          P_ERR_PARAMS := 'Percentage of contribution';
          RETURN FALSE;
        END IF;
      END LOOP;

      L_TOTAL_CONTRIBUTION := 0;

      SELECT JOINT_VENTURE
        INTO L_JV_FLAG_STATUS
        FROM STTM_CUSTOMER
       WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

      IF NVL(L_JV_FLAG_STATUS, 'N') = 'Y' THEN

        DBG('case 1');
        DBG('The customer ' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO ||
            ' is a Joint Venture customer.');

        K := P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;

        DBG('No of Linkages: ' || K);

        IF K > 0 THEN
          FOR L_INDEX IN 1 .. K LOOP
            DBG('Inside JV loop');

            IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
             .CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN

              IF NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                     .LINKAGE_PERCENTAGE,
                     0) <> 100 THEN

                DBG('Linkage Percentage for the Joint Venture customer ' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                    .CUSTOMER_NO || ' should be 100%');
                P_ERR_CODE   := 'ST-ACC-351';
                P_ERR_PARAMS := P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                                .CUSTOMER_NO;
                RETURN FALSE;
              END IF;

            ELSE
              DBG('Checking for party ratios ');
              DBG('Checking customer number ' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                  .CUSTOMER_NO);

              L_TOTAL_CONTRIBUTION := L_TOTAL_CONTRIBUTION +
                                      NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                                          .LINKAGE_PERCENTAGE,
                                          0);

            END IF;

          END LOOP;

        END IF;
        DBG('l_total_contribution:' || L_TOTAL_CONTRIBUTION);
        IF MOD(L_TOTAL_CONTRIBUTION, 100) <> 0 THEN

          DBG('Total sum of percentage contribution does not add up to 100%.');
          P_ERR_CODE   := 'ST-ACC-350';
          P_ERR_PARAMS := '';
          RETURN FALSE;

        END IF;

      ELSIF NVL(L_JV_FLAG_STATUS, 'N') = 'N' AND
            NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROJECT_ACCOUNT, 'N') = 'N' THEN

        DBG('case 2');
        DBG('Linkage Contribution Validation Part ..');
        K                    := P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;
        L_TOTAL_CONTRIBUTION := 0;
        DBG(K || ' records found in the Account Linkages Multiple View');
        IF K > 0 THEN
          DBG('Inside Customer Verification code ...');
          FOR L_INDEX IN 1 .. K LOOP
            L_TOTAL_CONTRIBUTION := L_TOTAL_CONTRIBUTION +

                                    NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                                        .LINKAGE_PERCENTAGE,
                                        0);
          END LOOP;
          DBG('Total sum of percentage contribution ==> ' ||
              L_TOTAL_CONTRIBUTION);

          IF L_TOTAL_CONTRIBUTION <> 100 THEN

            DBG('Total sum of percentage contribution does not add up to 100%.');
            P_ERR_CODE   := 'ST-ACC-350';
            P_ERR_PARAMS := '';
            RETURN FALSE;
          END IF;

        END IF;

      ELSIF NVL(L_JV_FLAG_STATUS, 'N') = 'N' AND
            NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PROJECT_ACCOUNT, 'N') = 'Y' THEN
        DBG('case 3');
        K := P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;
        DBG(K || ' records found in the Account Linkages Multiple View');
        L_TOTAL_CONTRIBUTION := 0;
        IF K > 0 THEN
          FOR L_INDEX IN 1 .. K LOOP
            L_TOTAL_CONTRIBUTION := L_TOTAL_CONTRIBUTION +
                                    NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                                        .LINKAGE_PERCENTAGE,
                                        0);
          END LOOP;
        END IF;
        DBG('l_total_contribution:' || L_TOTAL_CONTRIBUTION);

        IF MOD(L_TOTAL_CONTRIBUTION, 100) <> 0 THEN

          DBG('Total sum of percentage contribution does not add up to 100%.');
          P_ERR_CODE   := 'ST-ACC-355';
          P_ERR_PARAMS := '';
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('inside the condition for checking blacklisted customer' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      BEGIN
        SELECT COUNT(1)
          INTO L_CNT_BLK_CUST
          FROM STTB_CUST_NSF_CON_DET
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND (NSFIB_IB_BLK_STAT = 'Y' AND
               NSFIB_IB_BLK_EXPDT > GLOBAL.APPLICATION_DATE OR
               NSFIB_CS_WBRCK_STAT = 'Y');
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in sttb_cust_nsf_con_det for blacklist');
          L_CNT_BLK_CUST := 0;
      END;

      DBG('count->' || L_CNT_BLK_CUST);

      BEGIN
        SELECT COUNT(1)
          INTO L_CNT_CB_CUST
          FROM STTB_CB_BLK_DET
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND BK_EXPDT > GLOBAL.APPLICATION_DATE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('No data found in sttb_cb_blk_det for blacklist');
          L_CNT_CB_CUST := 0;
      END;

      IF (L_CNT_BLK_CUST > 0 AND L_CNT_CB_CUST > 0) THEN
        DBG('The customer is both internally and central bank blacklisted customer');

        IF P_ACTION_CODE = 'NEW' THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC3', '');

        ELSE
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC13', '');
        END IF;

      END IF;

      IF L_CNT_BLK_CUST > 0 THEN
        DBG('The customer is internally blacklisted customer');

        IF P_ACTION_CODE = 'NEW' THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC1', '');

        ELSE
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC11', '');
        END IF;

      END IF;

      IF L_CNT_CB_CUST > 0 THEN
        DBG('The customer is Central bank blacklisted customer');

        IF P_ACTION_CODE = 'NEW' THEN

          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC2', '');

        ELSE
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-NSFAC12', '');
        END IF;

      END IF;

    END IF;

    DBG('p_wrk_stdcusac.v_sttms_cust_account.atm_facility  :  ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY);
    DBG('p_wrk_stdcusac.v_sttms_cust_account.AUTO_DC_REQUEST    :' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST);
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ATM_FACILITY = 'N' THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST = 'Y' THEN
        DBG('For Auto debit Card Request, ATM needs to be checked');
        P_ERR_CODE   := 'ST-CUS-22';
        P_ERR_PARAMS := NULL;
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHEQUE_BOOK_FACILITY = 'N' THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST = 'Y' THEN
        DBG('For Auto Check Book Request, Check book needs to be checked');
        P_ERR_CODE   := 'ST-CUS-23';
        P_ERR_PARAMS := NULL;
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    DBG('p_action_code  :' || P_ACTION_CODE);
    IF P_ACTION_CODE IN ('MOD_DEFAULT', 'COP_DEFAULT') THEN
      IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT IS NULL THEN
        DBG('Card Product cannot be null');
        P_ERR_CODE   := 'ST-CRDM07';
        P_ERR_PARAMS := NULL;
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      DBG('INSIDE IF---');

      IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                         P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT,
                                         GLOBAL.APPLICATION_DATE,
                                         PSERIAL,
                                         PREFERENCENO,
                                         P_ERR_CODE) THEN
        DBG('Failed in generating internal reference number with error code ' ||
            P_ERR_CODE);
        ROLLBACK;
        RETURN FALSE;
      END IF;
      DBG('Came out of this');
      P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO := PREFERENCENO;
      P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE       := GLOBAL.APPLICATION_DATE;
    END IF;

    IF P_SOURCE <> 'FLEXCUBE' THEN
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG IS NULL THEN

        IF L_SIG_REPLICATE = 'Y' THEN
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG := L_REPL_CUST_SIG;

        ELSIF L_SIG_REPLICATE <> 'Y' THEN
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG := 'N';
        END IF;

      END IF;
    END IF;

    BEGIN

      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD70 := CSPKSS_OS_PARAM.GET_PARAM_VAL('DMS_INSTALLED');

      DBG('DMS Installed :' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD70);
    EXCEPTION

      WHEN NO_DATA_FOUND THEN
        DBG('Cstb Param not maintained....');
    END;

    DBG('p_Prev_Stdcusac.v_sttms_doctype_check_list.count' ||
        P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT);

    IF P_ACTION_CODE = 'MODIFY' AND
       P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
      FOR J IN P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.FIRST .. P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.LAST LOOP
        L_PREV_DOCLIST(J) := P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(J);
      END LOOP;
    END IF;

    IF P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
      FOR I IN 1 .. P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT LOOP

        IF P_ACTION_CODE = 'MODIFY' AND
           P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.COUNT > 0 THEN
          FOR J IN P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.FIRST .. P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST.LAST LOOP
            L_PREV_DOCLIST(J) := P_PREV_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(J);
          END LOOP;
        END IF;

        L_DOCLIST(I) := P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I);

        IF L_DOCLIST(I).CHECKED = 'Y' THEN
          IF P_ACTION_CODE = 'NEW' THEN
            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).ACTUAL_SUBMISSION_DATE := GLOBAL.APPLICATION_DATE;
          END IF;
          IF P_ACTION_CODE = 'MODIFY' THEN

            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).ACTUAL_SUBMISSION_DATE := GLOBAL.APPLICATION_DATE;

          END IF;

        ELSIF L_DOCLIST(I).CHECKED = 'N' THEN
          IF P_ACTION_CODE = 'NEW' THEN
            DBG('inside action new with no dms');
            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).EXPIRY_DATE := NULL;
            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).ACTUAL_SUBMISSION_DATE := NULL;
            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).DOCREFNO := NULL;
          END IF;
          IF P_ACTION_CODE = 'MODIFY' THEN
            DBG('inside action modify with no dms');

            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).ACTUAL_SUBMISSION_DATE := NULL;
            P_WRK_STDCUSAC.V_STTMS_DOCTYPE_CHECK_LIST(I).DOCREFNO := NULL;
          END IF;
        END IF;
      END LOOP;
    END IF;
    IF G_MULTI_CURRENCY <> TRUE THEN
      IF NOT
          STPKS_STDCUSAC_UTILS_1.FN_VALIDATE_DOCNOTIFICATION(P_FUNCTION_ID,
                                                             L_BRANCH,
                                                             L_ACC,
                                                             L_DOCLIST,
                                                             L_PREV_DOCLIST,
                                                             P_WRK_STDCUSAC.V_STTMS_DOCTYPE_REMARKS,
                                                             P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD70,
                                                             P_ACTION_CODE,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
        DBG('Failed in fn_validate_docnotification');
      END IF;
    END IF;

    DBG('p_action_code' || P_ACTION_CODE);
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') AND
       P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD') THEN
      L_WRK_COUNT := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
            IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
             .UDE_VALUE IS NULL AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
               .RATE_CODE IS NULL AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
               .TD_RATE_CODE IS NULL THEN
              DBG('UDE ID $1 for Effective date $2 - UDE Value, Rate code and TD Rate code is NULL');
              P_ERR_CODE   := 'ST-TD-004';
              P_ERR_PARAMS := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_ID || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                              .UDE_EFF_DT;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           P_SOURCE,
                           P_ERR_CODE,
                           P_ERR_PARAMS);
              EXIT;
            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_SERVICE.P_MODIFY, 'COMPUTE') THEN
      DBG('Issue: ictb_maint_queue getting inserted with SP even if ude values are not modified.Performance issue');

      L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;
      L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;

      DBG('l_prev_count=' || L_PREV_COUNT);
      DBG('l_wrk_count=' || L_WRK_COUNT);
      DBG('p_action_code~once_auth~mod_no-->' || P_ACTION_CODE || '~' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH || '~' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO);
      IF P_ACTION_CODE = 'COMPUTE' AND
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH, 'N') <> 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO > 1 THEN
        L_PREV_COUNT := 0;
        DBG('l_prev_count==' || L_PREV_COUNT);
        DBG('l_wrk_count==' || L_WRK_COUNT);
      END IF;

      IF L_PREV_COUNT > 0 THEN
        FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
          L_PREV_UDE_STRING := NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).PROD,
                                   '@') || NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                               .UDE_EFF_DT,
                                               GLOBAL.MIN_DATE) ||
                               NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                                   .UDE_ID,
                                   '@');
          L_PREV_ICTMS_ACC_UDEVAL(L_PREV_UDE_STRING) := P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1);
        END LOOP;

      END IF;

      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP

          IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
           .PROD IS NOT NULL AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
             .UDE_EFF_DT IS NOT NULL AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
             .UDE_ID IS NOT NULL THEN

            L_REC_FOUND := FALSE;

            L_UPDATE_DONE := FALSE;

            G_VARIANCE_CHANGED := FALSE;
            G_RATE_CHANGED     := FALSE;

            DBG('l_prev_count=' || L_PREV_COUNT);
            DBG('l_wrk_count=' || L_WRK_COUNT);
            L_WORK_UDE_STRING := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD,
                                     '@') ||
                                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                     .UDE_EFF_DT,
                                     GLOBAL.MIN_DATE) ||
                                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                     .UDE_ID,
                                     '@');
            IF L_PREV_COUNT > 0 THEN

              IF L_PREV_ICTMS_ACC_UDEVAL.EXISTS(L_WORK_UDE_STRING) THEN

                DBG('GOING TO CHECK IF ANYTHING CHANGED HERE');
                IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .UDE_VALUE,
                        '0') <>
                   NVL(L_PREV_ICTMS_ACC_UDEVAL(L_WORK_UDE_STRING).UDE_VALUE,
                        '0')) OR
                   (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .RATE_CODE,
                        '@') <>
                   NVL(L_PREV_ICTMS_ACC_UDEVAL(L_WORK_UDE_STRING).RATE_CODE,
                        '@'))

                 THEN
                  L_UPDATE_DONE := TRUE;
                  DBG('rate code or ude value  is  modified...maintqueue should get updated in this case');
                  L_MIN_UDE_EFF_DATE := LEAST(NVL(L_MIN_UDE_EFF_DATE,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                                  .UDE_EFF_DT),
                                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                              .UDE_EFF_DT);
                END IF;

                IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .UDE_VARIANCE,
                        '0') <> NVL(L_PREV_ICTMS_ACC_UDEVAL(L_WORK_UDE_STRING)
                                     .UDE_VARIANCE,
                                     '0')) THEN
                  L_UPDATE_DONE      := TRUE;
                  G_VARIANCE_CHANGED := TRUE;
                  L_MIN_UDE_EFF_DATE := LEAST(NVL(L_MIN_UDE_EFF_DATE,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                                  .UDE_EFF_DT),
                                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                              .UDE_EFF_DT);
                  DBG('Variance  is  modified...maintqueue should get updated in this case');
                END IF;

                IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .TD_RATE_CODE,
                        '@') <> NVL(L_PREV_ICTMS_ACC_UDEVAL(L_WORK_UDE_STRING)
                                     .TD_RATE_CODE,
                                     '@')) THEN
                  G_RATE_CHANGED     := TRUE;
                  L_UPDATE_DONE      := TRUE;
                  L_MIN_UDE_EFF_DATE := LEAST(NVL(L_MIN_UDE_EFF_DATE,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                                  .UDE_EFF_DT),
                                              P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                              .UDE_EFF_DT);
                  DBG('td_rate_code  is  modified...maintqueue should get updated in this case');
                END IF;

                DBG('Record Has been Found.Update Case..');
                L_REC_FOUND := TRUE;

              END IF;

            END IF;

            DBG('l_min_ude_Eff_date' || L_MIN_UDE_EFF_DATE);
            DBG('p_wrk_stdcusac.v_ictms_acc.int_start_date' ||
                P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
            IF L_MIN_UDE_EFF_DATE <
               P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
              DBG('UDE Value for the previous effective dates cannot be modified');
              P_ERR_CODE   := 'IC-REDMN-20';
              P_ERR_PARAMS := '';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;

            IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
             .UDE_EFF_DT >= P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN

              L_HSH_IDX := STPKS_STDTDTOP_UTILS.FN_HASH_DATE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                                             .UDE_EFF_DT);
              PR_POP_TB_VARCHG(L_HSH_IDX,
                               G_VARIANCE_CHANGED,
                               G_RATE_CHANGED);

              IF L_REC_FOUND AND NOT L_UPDATE_DONE THEN
                DBG('ude values are not Modified...maintqueue updation is not necessary');

                IF L_TB_MOD_UDE.EXISTS(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                       .PROD || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                       .UDE_EFF_DT) THEN
                  DBG('some ude id is modified on this date and requires resolution so cannot update this date as N in maintqueue');
                ELSE

                  BEGIN
                    SELECT COUNT(1)
                      INTO L_CNT
                      FROM ICTB_MAINT_QUEUE
                     WHERE MAINT_TYPE = 'SP'
                       AND MAINT_KEY = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                          .UDE_EFF_DT
                       AND BRN =
                           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  EXCEPTION
                    WHEN OTHERS THEN
                      L_CNT := 0;
                  END;

                  IF L_CNT > 0 AND
                     P_ACTION_CODE IN (CSPKS_SERVICE.P_MODIFY) THEN
                    DBG('Updating the maint_queue with temp status N, during auth this will be updated back to P');

                    UPDATE ICTB_MAINT_QUEUE
                       SET STATUS = 'N'
                     WHERE MAINT_TYPE = 'SP'
                       AND MAINT_KEY = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                          .UDE_EFF_DT
                       AND BRN =
                           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                       AND STATUS <> 'U';

                    L_TB_MOD_UDE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_EFF_DT) := 1;

                    IF NOT L_TB_HSH_DATES.EXISTS(L_HSH_IDX) THEN
                      L_TB_UDE_DATES(L_INDEX) := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                                 .UDE_EFF_DT;

                      L_TB_HSH_DATES(L_HSH_IDX) := 1;
                    END IF;
                  END IF;

                END IF;
              ELSIF L_REC_FOUND AND L_UPDATE_DONE THEN
                L_TB_MOD_UDE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_EFF_DT) := 1;

                IF NOT L_TB_HSH_DATES.EXISTS(L_HSH_IDX) THEN
                  L_TB_UDE_DATES(L_INDEX) := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                             .UDE_EFF_DT;
                  L_TB_HSH_DATES(L_HSH_IDX) := 1;
                END IF;
                IF P_ACTION_CODE IN (CSPKS_SERVICE.P_MODIFY) THEN

                  UPDATE ICTB_MAINT_QUEUE
                     SET STATUS = 'U'
                   WHERE MAINT_TYPE = 'SP'
                     AND MAINT_KEY = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .UDE_EFF_DT
                     AND BRN =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND STATUS = 'N';
                END IF;

              ELSIF (NOT L_REC_FOUND) AND L_PREV_COUNT > 0 THEN

                DBG('case when prev record exists and is deleted from screen.');

                IF NOT L_TB_HSH_DATES.EXISTS(L_HSH_IDX) THEN
                  L_TB_UDE_DATES(L_INDEX) := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                             .UDE_EFF_DT;

                  L_TB_HSH_DATES(L_HSH_IDX) := 1;
                END IF;

                IF P_ACTION_CODE IN (CSPKS_SERVICE.P_MODIFY) THEN
                  UPDATE ICTB_MAINT_QUEUE
                     SET STATUS = 'U'
                   WHERE MAINT_TYPE = 'SP'
                     AND MAINT_KEY = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                        .UDE_EFF_DT
                     AND BRN =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND STATUS = 'N';
                END IF;

              ELSIF (NOT L_REC_FOUND) AND L_PREV_COUNT = 0 THEN
                DBG('when td account is booked newly and compute is done. should delete and insert all rows on resolving.');
                L_TB_MOD_UDE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_EFF_DT) := 1;

                IF NOT L_TB_HSH_DATES.EXISTS(L_HSH_IDX) THEN

                  IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE <
                     GLOBAL.APPLICATION_DATE AND
                     P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE <>
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
                    L_TB_UDE_DATES(L_INDEX) := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
                  ELSE

                    L_TB_UDE_DATES(L_INDEX) := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                                               .UDE_EFF_DT;
                  END IF;
                  L_TB_HSH_DATES(L_HSH_IDX) := 1;
                END IF;

              END IF;
            END IF;
          END IF;
        END LOOP;
      END IF;

      L_TB_MOD_UDE.DELETE;
      L_TB_HSH_DATES.DELETE;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_SERVICE.P_MODIFY) THEN
      DBG('Issue: ictb_maint_queue is not getting updated if the record stat of ude eff dt is changed');
      L_WRK_COUNT  := P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
      L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT;
      DBG('l_prev_count-->' || L_PREV_COUNT);
      DBG('l_wrk_count-->' || L_WRK_COUNT);

      FOR L_INDEX2 IN 1 .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
        IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX2).RECORD_STAT = 'O' THEN

          IF L_WRK_COUNT > 0 THEN
            FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
              IF

               NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD, '@') =
               NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_PR(L_INDEX2).PROD, '@') AND P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
              .UDE_EFF_DT >= P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE

               THEN
                L_UPDATE_DONE := FALSE;

                IF L_PREV_COUNT > 0 THEN
                  FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
                    IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD,
                            '@') = NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1).PROD,
                                        '@')) AND
                       (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                            .UDE_EFF_DT,
                            GLOBAL.MIN_DATE) =
                       NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                            .UDE_EFF_DT,
                            GLOBAL.MIN_DATE)) THEN
                      DBG('GOING TO CHECK IF ANYTHING RECORD_STAT IS CHANGED HERE');

                      IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                              .RECORD_STAT,
                              '@') <> NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX1)
                                           .RECORD_STAT,
                                           '@')) THEN
                        L_UPDATE_DONE := TRUE;
                      END IF;
                      EXIT;
                    END IF;
                  END LOOP;
                END IF;
                IF L_UPDATE_DONE THEN
                  DBG('Updating the maint_queue with status U');
                  UPDATE ICTB_MAINT_QUEUE
                     SET STATUS = 'U'
                   WHERE MAINT_TYPE = 'SP'
                     AND MAINT_KEY = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX).PROD || '~' || P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(L_INDEX)
                        .UDE_EFF_DT
                     AND BRN =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND STATUS <> 'U';
                END IF;
              END IF;
            END LOOP;
          END IF;

        END IF;
      END LOOP;

    END IF;

    DBG('Branch code' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('Cust ac no' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Action' || P_ACTION_CODE);

    IF P_ACTION_CODE IN ('COMPUTE', CSPKS_REQ_GLOBAL.P_MODIFY) AND

       P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') THEN

      IF P_ACTION_CODE = 'COMPUTE' THEN

        BEGIN
          SELECT COUNT(*)
            INTO L_AC_COUNT
            FROM STTM_CUST_ACCOUNT
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            L_AC_COUNT := NULL;
        END;

        IF NVL(L_AC_COUNT, 0) = 0 THEN

          L_NXT_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;

          BEGIN
            SELECT NVL(MONTH_END_DEPOSIT, 'N'),
                   NVL(HOLIDAY_MOVEMENT, 'H'),
                   NVL(HOLIDAY_CALENDAR, 'N')
              INTO L_MONTH_END_DEP, L_HOL_MOV, L_HOL_PREF
              FROM STTM_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS =
                   P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed here' || SQLERRM);
          END;

          DBG('Holiday movement' || L_HOL_MOV);
          DBG('Holiday calendar' || L_HOL_PREF);
          IF NOT ICPKS_HOLIDAY.FN_ISHOLIDAY(L_HOL_PREF,
                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                            P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                            P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                            L_HOL_RES,
                                            L_MESSAGE) THEN
            DBG('icpks_holiday.fn_isholiday has returned false');
          END IF;
          DBG('Maturity date is a' || L_HOL_RES);

          IF L_HOL_PREF IN ('L', 'C', 'B') AND L_HOL_MOV = 'H' AND
             L_HOL_RES = 'H' THEN
            DBG('Maturity date is a holiday as per the holiday treatment');
            PR_LOG_ERROR(P_FUNCTION_ID,
                         'FLEXCUBE',
                         'IC-MSC030',
                         P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
          END IF;

          DBG('Holiday Treatment starts');
          DBG('l_month_end_dep : ' || L_MONTH_END_DEP);
          DBG('p_stdcusac.v_sttms_cust_account.ac_open_date : ' ||
              P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
          IF L_MONTH_END_DEP = 'Y' AND
             NVL(P_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN

            DBG('Checking last working day of the account open date');
            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT('L',
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE),
                                                      L_WRK_DAY,
                                                      L_ERROR) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR, '');
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;

            IF L_WRK_DAY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE OR
               P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE =
               LAST_DAY(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) THEN
              L_MONTH_END_FLG := TRUE;
            END IF;
          END IF;

          L_PREV_MAT_DT := ADD_MONTHS((P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE),
                                      P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                      (P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                           P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

          IF L_MONTH_END_FLG THEN
            DBG('Checking for month end deposit');

            IF NOT ICPKS_HOLIDAY.FN_MONTH_END_DEPOSIT(L_HOL_PREF,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      LAST_DAY(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE),
                                                      L_NXT_DATE,
                                                      L_ERROR) THEN
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERROR, '');
              DBG('icpks_holiday.fn_month_end_deposit has failed but continuing');
            END IF;

            IF P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE <>
               LAST_DAY(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           'IC-MSC023',
                           P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                           LAST_DAY(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~');
            END IF;

            IF L_NXT_DATE <>
               LAST_DAY(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
              IF L_NXT_DATE <
                 LAST_DAY(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC010',
                             LAST_DAY(P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) || '~' ||
                             L_NXT_DATE || '~');
              END IF;
            END IF;
            P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(L_NXT_DATE,
                                                            P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
          ELSE

            DBG('calling holiday treatment');
            IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                      L_NXT_DATE,
                                                      P_FUNCTION_ID) THEN
              DBG('icpks_holiday.fn_get_maturity_date has failed but continuing');
            END IF;

            IF L_NXT_DATE <> P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
              IF L_NXT_DATE > P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC006',
                             P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                             L_NXT_DATE || '~');
              ELSE
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             'IC-MSC010',
                             P_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || '~' ||
                             L_NXT_DATE || '~');
              END IF;

              IF L_NXT_DATE <= P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE THEN
                DBG('Maturity Date cannot be less than or equal to interest start date, hence maturity date
                     movement is ignored');
              ELSE

                P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := NVL(L_NXT_DATE,
                                                                P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
              END IF;

            END IF;

          END IF;

          DBG('l_prev_mat_dt--->' || L_PREV_MAT_DT);
          DBG('p_Wrk_Stdcusac.v_ictms_acc.maturity_date--->' ||
              P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

          BEGIN
            SELECT NVL(HOLIDAY_MOVEMENT, 'H'), NVL(HOLIDAY_CALENDAR, 'N')
              INTO L_HOLIDAY_MOVEMENT, L_HOLIDAY_CALENDAR
              FROM STTM_ACCOUNT_CLASS
             WHERE ACCOUNT_CLASS =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
          EXCEPTION
            WHEN OTHERS THEN
              L_HOLIDAY_MOVEMENT := 'H';
              L_HOLIDAY_CALENDAR := 'N';
              DBG('NO DATA FOUND FOR ACLASS ' ||
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
          END;
          IF (L_HOLIDAY_MOVEMENT = 'H' OR L_HOLIDAY_CALENDAR = 'N' OR
             (L_PREV_MAT_DT = P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE)) AND
             P_SOURCE = 'FLEXCUBE' THEN
            DBG('holiday treatment is not select, hence copying from original tenor');
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS;
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS;
          ELSE

            IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) = 0 AND
               NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) = 0 AND
               P_SOURCE = 'FLEXCUBE' THEN
              P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
            ELSE
              BEGIN
                WITH TTL_MONTHS AS
                 (SELECT P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                         ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                    TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                         P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE))) RES,
                         TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                              P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE)) MON
                    FROM DUAL)
                SELECT CASE
                         WHEN RES >= 0 THEN
                          TRUNC(MON / 12)
                         ELSE
                          TRUNC((MON - 1) / 12)
                       END YEARS,
                       CASE
                         WHEN RES >= 0 THEN
                          MOD(MON, 12)
                         ELSE
                          MOD(MON - 1, 12)
                       END MONTHS,
                       CASE
                         WHEN RES >= 0 THEN
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                          ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                     MON)
                         ELSE
                          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                          ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                     MON - 1)
                       END DAYS
                  INTO P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                       P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                       P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53
                  FROM TTL_MONTHS;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('Failed while changing default tenor, ' || SQLERRM);
              END;
            END IF;
          END IF;
        END IF;
        DBG('p_Wrk_Stdcusac.v_ictms_acc.roll_tenor_pref' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF);
        IF P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_PREF <> 'L' AND
           P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                                      NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS,
                                                                          0) +
                                                                      NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS,
                                                                          0) * 12) +
                                                           NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS,
                                                               0);

          DBG('p_Wrk_Stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
              P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
          DBG('p_Wrk_Stdcusac.v_ictms_acc.next_maturity_date-->' ||
              P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE);
          IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
             NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS, 0) = 0 THEN
            L_NEXT_MATURITY_DATE := P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE;
            DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
            IF NOT
                STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(

                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                        P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE) THEN
              DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
              P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := L_NEXT_MATURITY_DATE;
            END IF;
          END IF;

        ELSE
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
        END IF;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
      END IF;

      DBG('Entered');
      IF NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT, '*') != 'A' THEN

        DBG('Pay in Count------>' ||
            P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
        IF P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
          FOR I IN 1 .. P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT LOOP

            DBG('p_prev_Stdcusac.v_Ictms_Td_Details.Td_Amount--->' ||
                P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);
            DBG('p_wrk_Stdcusac.v_Ictms_Td_Details.Td_Amount--->' ||
                P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);

            IF NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                   .MULTIMODE_PERCENTAGE,
                   0) > 0 AND
               NVL(P_PREV_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT, 0) <>
               P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT THEN

              DBG(' p_wrk_stdcusac.v_Ictms_Tdpayin_Details.COUNT  ' ||
                  P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
              DBG('i' || I);
              IF I = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT THEN
                P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT -
                                                                                L_PAYIN_TOTAL;
                DBG('amount ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .MULTIMODE_TDAMOUNT);
              ELSE

                DBG('Pay in Percentage--->' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .MULTIMODE_PERCENTAGE);
                P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := (P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT *
                                                                                NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                                                                     .MULTIMODE_PERCENTAGE,
                                                                                     0) / 100);

                DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_PAYOPT ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .MULTIMODE_PAYOPT);
                DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_TDOFFSET_CCY ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .MULTIMODE_TDOFFSET_CCY);
                IF P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .MULTIMODE_TDOFFSET_CCY = 'S' THEN
                  SELECT CCY
                    INTO L_CCY
                    FROM STTM_CUST_ACCOUNT
                   WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                        .MULTIMODE_TDOFFSET_ACC
                     AND BRANCH_CODE = P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                        .MULTIMODE_OFFSET_BRN;
                ELSE
                  L_CCY := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
                END IF;

                DBG('l_ccy ' || L_CCY);
                IF NOT CYPKSS.FN_AMT_ROUND(L_CCY,
                                           P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDAMOUNT,
                                           P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                           .MULTIMODE_TDAMOUNT) THEN
                  DBG('Failed in doing Round OFF of amount to offset currency');
                END IF;
                DBG('After Round OFF l_tdpayout_rec.redmamt  ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                    .MULTIMODE_TDAMOUNT);
              END IF;

            END IF;
            DBG('TDAMT--->' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                .MULTIMODE_TDAMOUNT);
            L_PAYIN_TOTAL := L_PAYIN_TOTAL + NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                                 .MULTIMODE_TDAMOUNT,
                                                 0);
          END LOOP;
        END IF;
        DBG('l_payin_total--->' || L_PAYIN_TOTAL);

        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD4 := L_PAYIN_TOTAL;
        DBG('Num_Field1' || P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1);
        DBG('Num_Field4' || P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD4);
      END IF;
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_POPDT(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpkss_stdcusac_utils_0.fn_popdt has returned false');
        NULL;
      END IF;

      DBG('g_tb_variance_chg.COUNT =' || G_TB_VARIANCE_CHG.COUNT);
      IF G_TB_VARIANCE_CHG.COUNT > 0 THEN
        DECLARE
          L_TMP_IDX PLS_INTEGER;
        BEGIN
          L_TMP_IDX := G_TB_VARIANCE_CHG.FIRST;
          WHILE L_TMP_IDX IS NOT NULL LOOP
            DBG('g_tb_variance_chg(' || L_TMP_IDX || ') IS ' ||
                G_TB_VARIANCE_CHG(L_TMP_IDX));
            L_TMP_IDX := G_TB_VARIANCE_CHG.NEXT(L_TMP_IDX);
          END LOOP;
        END;
      END IF;

      DBG('l_tb_ude_Dates.count = ' || L_TB_UDE_DATES.COUNT);
      IF NOT FN_MATURITY_CALC(P_WRK_STDCUSAC,
                              L_INT_RATE,
                              L_MAT_AMOUNT,
                              L_TB_UDE_DATES,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN

        DBG('failed in MATURITY CALCULATION');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      G_TB_VARIANCE_CHG.DELETE;
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT := L_MAT_AMOUNT;
      P_WRK_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE   := L_INT_RATE;

      IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
        IF ((P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) OR
           (P_WRK_STDCUSAC.V_ICTMS_TDPAYOUT_DETAILS.COUNT > 0)) THEN
          ICPKS_CALC.PR_CALC_PROJ_INT_TILL_MAT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                               GLOBAL.APPLICATION_DATE);
        ELSE
          BEGIN
            UPDATE ICTM_TD_DETAILS
               SET PROJECTED_INT_TILL_MAT = STPKSS_STDTDTOP_UTILS.G_TOTAL_INTEREST
             WHERE BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          END;
        END IF;
      END IF;

    END IF;

    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY IS NULL THEN
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SUBLIMIT           := NULL;
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.UNCOLL_FUNDS_LIMIT := NULL;
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT          := NULL;
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CREDIT_TXN_LIMIT   := NULL;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN

      SELECT COUNT(*)
        INTO L_VIRACC_COUNT
        FROM STTM_VIRTUAL_ACCOUNTS
       WHERE PHY_ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND PHY_BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND RECORD_STAT = 'O';
      IF L_VIRACC_COUNT > 0 THEN
        DBG('Can not close the customer account, virtual accounts present for it');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-VIR-010', '');
      END IF;

      DBG('inside multi ccy account');
      BEGIN

        SELECT COUNT(*)
          INTO L_MULTICCY_COUNT_CLOSURE
          FROM STTM_CUST_ACCOUNT
         WHERE RECORD_STAT = 'O'
           AND CUST_AC_NO IN
               (SELECT SUB_AC_NO
                  FROM STTM_MULTI_CCY_ACCNT_DTL
                 WHERE MULTI_CCY_AC_NO =
                       (SELECT MULTI_CCY_AC_NO
                          FROM STTM_MULTI_CCY_ACCNT_MASTER
                         WHERE MAIN_AC_NO =
                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO)
                   AND SUB_AC_NO <>
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        IF L_MULTICCY_COUNT_CLOSURE > 0 THEN
          DBG('this is a multi ccy account');
          DBG('Multicurrency account cannot be closed untill all the sub accounts are closed');
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-MUL-010', '');
        END IF;
      END;
      DBG('multi ccy account ends');

      SELECT COUNT(*)
        INTO L_COUNT
        FROM DETB_PDC_MASTER
       WHERE BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND BENEFICIARY_ACCOUNT_NO =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND STATUS IN ('A', 'H');

      DBG('Customer Account can not be closed if ben acc is not null');
      IF L_COUNT > 0 THEN
        P_ERR_CODE   := 'ST-ACC-560';
        P_ERR_PARAMS := '~' ||
                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;

      DBG('Check whether any accounts linked in sweep structure FOR ACCOUNT' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      SELECT COUNT(*)
        INTO L_SWP_COUNT
        FROM STTM_SWEEP_DETAILS
       WHERE CUST_ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

      IF NVL(L_SWP_COUNT, 0) > 0 THEN
        DBG('Cover accounts linked in sweep structure maintenenace hence deleting');
        DELETE FROM STTM_SWEEP_DETAILS
         WHERE CUST_ACCOUNT =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND SWEEP_TYPE = 'SC';
        DBG('Sweep Accounts Linked will be dispatched automatically during close action');
        P_ERR_CODE := 'ST-SWP-078';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;

      DBG('Check whether the account is linked in any other sweep structure-->' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
      SELECT COUNT(*)
        INTO L_SWPLNK_COUNT
        FROM STTM_SWEEP_DETAILS
       WHERE DEPOSIT_ACCOUNT =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND DEPOSIT_BRANCH =
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      IF NVL(L_SWPLNK_COUNT, 0) > 0 THEN
        DBG('Cover accounts linked in sweep structure maintenenace hence deleting');
        DELETE FROM STTM_SWEEP_DETAILS
         WHERE DEPOSIT_ACCOUNT =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND DEPOSIT_BRANCH =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND SWEEP_TYPE = 'SC';
        DBG('Account Linked in sweep structure will be dispatched automatically during close action');
        P_ERR_CODE := 'ST-SWP-079';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
      END IF;

    END IF;

    IF (P_FUNCTION_ID IN ('STDCUSAC', 'STDCASAC') OR G_CHILD_FUNCTION)

       AND P_ACTION_CODE IN ('NEW', 'MODIFY') THEN
      BEGIN
        SELECT NVL(TRACK_LIMITS, 'N')
          INTO L_TRACK_LIMITS
          FROM STTM_CUSTOMER
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      BEGIN
        SELECT NVL(LIMIT_CHECK_REQUIRED, 'N'), OVERDRAFT_FACILITY
          INTO L_LIMIT_CHECK, L_OD_TYPE
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION

        WHEN OTHERS THEN
          DBG('WHEN OTHERS Sttm_Account_Class' || SQLERRM);
          RETURN FALSE;
      END;

      IF (NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED, 'N') = 'Y' OR
         NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED, 'N') <>
         NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED, 'N')) AND
         NVL(CSPKS_OS_PARAM.GET_PARAM_VAL(PNAME => 'CA_ACCOUNT_NETTING'),
             'N') = 'Y' THEN
        IF NOT STPKS_ACCOUNT_NETTING.FN_VALIDATE_ACC_LIMIT(P_FUNCTION_ID,
                                                           P_STDCUSAC,
                                                           P_PREV_STDCUSAC,
                                                           L_OD_TYPE) THEN
          DBG('Failed in fn_validate_acc_limit..');
        END IF;

        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.NETTING_REQUIRED, 'N') = 'Y' AND
           ((P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__C.COUNT > 0) OR
            (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__TD.COUNT > 0) OR
            (P_WRK_STDCUSAC.TY_STCOSWP.V_STTMS_SWEEP_DETAILS__AD.COUNT > 0)) THEN
          DBG('Sweep structure cannot be maintained for the Netting Enabled Account..');
          P_ERR_CODE   := 'ST-LMT-009';
          P_ERR_PARAMS := 'Sweep structure cannot be maintained for the Netting Enabled Account';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;

      SELECT COUNT(*)
        INTO L_COUNT2
        FROM GETM_LIAB_CUST
       WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO

         AND RECORD_STAT = 'O'
         AND ONCE_AUTH = 'Y';

      IF (L_TRACK_LIMITS = 'N' AND L_COUNT2 = 0 AND L_LIMIT_CHECK = 'Y') THEN
        P_ERR_CODE   := 'ST-LIM33';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);

      END IF;

      IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

        IF NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE,
               SYSDATE + 1000) <>
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE,
               SYSDATE + 1000) AND
           NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE,
               SYSDATE + 1000) < GLOBAL.APPLICATION_DATE THEN

          DBG('TOD start date cannot be less than Application date');
          P_ERR_CODE   := 'ST-ACC-580';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

      END IF;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE <
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
        DBG('TOD start date cannot be less than acc open date');
        P_ERR_CODE   := 'ST-ACC-582';
        P_ERR_PARAMS := '';
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0) > 0 AND

         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE IS NULL THEN
        DBG('TOD Start date cannot be NULL if TOD Limit is given');
        P_ERR_CODE   := 'ST-ACC-581';
        P_ERR_PARAMS := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                         'STDCUSAC',
                                                         'STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE') || '~' ||
                        CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                         'STDCUSAC',
                                                         'STTMS_CUST_ACCOUNT.TOD_LIMIT');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE IS NOT NULL AND

         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0) = 0 THEN
        DBG('TOD Limit cannot be NULL if TOD Start date is given');
        P_ERR_CODE   := 'ST-ACC-581';
        P_ERR_PARAMS := CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                         'STDCUSAC',
                                                         'STTMS_CUST_ACCOUNT.TOD_LIMIT') || '~' ||
                        CSPKS_REQ_UTILS.FN_GET_ITEM_DESC(P_SOURCE,
                                                         'STDCUSAC',
                                                         'STTMS_CUST_ACCOUNT.TOD_LIMIT_START_DATE');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

    END IF;

    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      IF G_MULTI_CURRENCY <> TRUE THEN
        IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST, 'N') = 'Y' AND
           (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N') THEN
          IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO IS NOT NULL AND
             L_ALPHA_OR_NUMA = '0' THEN

            BEGIN
              SELECT CHQNO_MASK
                INTO G_CHQ_MASK
                FROM STTMS_BRANCH
               WHERE BRANCH_CODE =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Error in getting the cheque mask');
            END;

            L_ALPHA_OR_NUMA := INSTR(UPPER(G_CHQ_MASK), 'A');

            IF G_CHQ_MASK IS NULL THEN
              PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CA-CHQ-014', '');
              RETURN FALSE;
            END IF;
            FOR LOOP1 IN 1 .. LENGTH(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) LOOP
              IF SUBSTR(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO,
                        LOOP1,
                        1) NOT IN
                 ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0') THEN
                L_BOOLEAN := FALSE;
                EXIT;
              END IF;
            END LOOP;

            IF NOT L_BOOLEAN THEN
              DBG('First check Number Should be Numeric');
              P_ERR_CODE   := 'CA-CHQ-001';
              P_ERR_PARAMS := '';
              OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
              RETURN FALSE;
            END IF;

          END IF;
          IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES IS NULL OR
             P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES = 0 THEN
            P_ERR_CODE   := 'CA-00201';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CA-00201', '');
          END IF;

          IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ORDER_DATE IS NULL THEN
            P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ORDER_DATE := GLOBAL.APPLICATION_DATE;
          END IF;
          IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ORDER_DATE <
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
            OVPKSS.PR_APPENDTBL('ST-CHQ-10', NULL);
          END IF;
        END IF;
        IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST, 'N') = 'Y' AND
           (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N') THEN
          IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE IS NULL THEN

            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE := GLOBAL.APPLICATION_DATE;
          END IF;
          IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE <
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
            OVPKSS.PR_APPENDTBL('ST-CRD-10', NULL);
          END IF;
        END IF;
      END IF;
    END IF;

    DBG('BEFORE KEY ID POSTDFLT IS' ||
        P_WRK_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);
    P_WRK_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || ':' ||
                                                                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    DBG('AFTER KEY ID POSTDFLT IS' ||
        P_WRK_STDCUSAC.TY_CSCUPDOC.V_CSTB_DOC_UPLOAD_MASTER.KEY_ID);

    DBG('Spend analysis reqd: ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPEND_ANALYSIS_REQD);
    DBG('Account class: ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPEND_ANALYSIS_REQD, 'N') = 'Y' THEN
        BEGIN
          SELECT NVL(SPEND_ANALYSIS_REQD, 'N')
            INTO L_SPEND_ANALYSIS_REQD
            FROM STTMS_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        EXCEPTION
          WHEN OTHERS THEN
            L_SPEND_ANALYSIS_REQD := 'N';
        END;
        IF L_SPEND_ANALYSIS_REQD = 'N' THEN
          DBG('Spend Analysis tracking is not allowed for this account since it is turned off at the Account class level');
          P_ERR_CODE   := 'IT-SPND-014';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      IF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT <> 0 THEN
        BEGIN
          SELECT MINOR_AGE
            INTO L_MINOR
            FROM STTMS_BRANCH
           WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('No Minor Age Maintained for the Current Branch-->' ||
                GLOBAL.CURRENT_BRANCH);
        END;
        FOR I IN 1 .. P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES.COUNT LOOP
          IF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
           .NOMINEE_DOB <= GLOBAL.APPLICATION_DATE THEN
            IF (P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .NOMINEE_DOB >
                (ADD_MONTHS(GLOBAL.APPLICATION_DATE(),
                            - (NVL(L_MINOR, 18) * 12)))) THEN
              DBG('COMING HERE');
              IF NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I).IS_MINOR,
                     'N') = 'N' THEN
                P_ERR_CODE := 'TD-NOMINE01';
                DBG('Minor option is not checked');
                PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
              END IF;
            ELSE
              DBG('Nominee is not a minor');
              IF (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I).IS_MINOR,
                      'N') = 'N') AND (P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
                 .RELATIONSHIP IS NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
                 .ADDRESS1 IS NULL) THEN
                DBG('Relationship and Address details are mandatory');
                P_ERR_CODE   := 'TD-NOMINE05';
                P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
                                .NOMINEE_NAME;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
              END IF;
            END IF;
          ELSIF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
           .NOMINEE_DOB IS NOT NULL THEN
            DBG('DATE OF BIRTH CANNOT EXCEED CURRENT DATE');
            P_ERR_CODE := 'TD-NOMINE02';
            PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
          END IF;
          IF NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I).IS_MINOR, 'N') = 'Y' THEN
            IF (P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .NOMINEE_DOB <=
                (ADD_MONTHS(GLOBAL.APPLICATION_DATE(),
                            - (NVL(L_MINOR, 18) * 12)))) THEN
              P_ERR_CODE := 'TD-NOMINE03';
              DBG('Validation failed::Nominee is not a minor');
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
            ELSE
              IF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARDIAN_NAME IS NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
                 .GUARDIAN_RELATION IS NULL THEN
                P_ERR_CODE   := 'TD-NOMINE04';
                P_ERR_PARAMS := 'Guardian Name and Relationship';
                DBG('Guardian Name Cant be null for minors ');
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
              END IF;
            END IF;

          ELSE
            DBG('Nominee is not a Minor');
            IF P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
             .GUARDIAN_NAME IS NOT NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARDIAN_RELATION IS NOT NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARD_ADDR1 IS NOT NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARD_ADDR2 IS NOT NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARD_ADDR3 IS NOT NULL OR P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES(I)
               .GUARD_ADDR4 IS NOT NULL THEN
              DBG('Guardians Details should not be provided for Major Nominees');
              P_ERR_CODE := 'TD-NOMINE06';
              PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, NULL);
            END IF;

          END IF;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_DELETE THEN
      P_WRK_STDCUSAC.TY_CSCOFACM.V_CSTBS_EXT_WS_MASTER.KEY_ID := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO ||
                                                                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_CNT
          FROM STTMS_CUSTCH_HISTORY
         WHERE ACCOUNT_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND AUTHORIZED = 'U';
        IF L_CNT > 0 THEN
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CIF-565', '');
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed to select ->');
      END;
    END IF;

    DBG('changes by sam');
    IF P_ACTION_CODE = CSPKS_SERVICE.P_MODIFY THEN
      P_WRK_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.CUST_AC_NO  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      P_WRK_STDJHMNT.V_STTMS_ACC_JOINT_MASTER.BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      BEGIN
        SELECT AUTH_STAT
          INTO L_AUTH_STAT
          FROM STTM_ACC_JOINT_MASTER
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBG('nothing');
      END;
      DBG('Got l_Auth_Stat from Table: ' || L_AUTH_STAT);
      IF NVL(L_AUTH_STAT, '*') <> 'U' THEN

        L_STDCUSAC_RECORD_KEY    := CSPKS_REQ_GLOBAL.FN_GET_REQ_KEY;
        L_STDCUSAC_FUNCTION_TYPE := CSPKS_REQ_GLOBAL.FN_GET_FUNC_TYPE;
        L_STDCUSAC_KEY_ID        := CSPKS_REQ_GLOBAL.FN_GET_KEY_ID;

        IF NOT STPKS_STDJHMNT_MAIN.FN_GET_KEY_INFORMATION(P_SOURCE,
                                                          P_SOURCE_OPERATION,
                                                          'STDJHMNT',
                                                          'MODIFY',
                                                          P_WRK_STDJHMNT,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
          DBG('Failed in  stpks_stdjhmnt_mai.Fn_Get_Key_Information..');
          RETURN FALSE;
        END IF;
        IF P_WRK_STDJHMNT.ADDL_INFO.EXISTS('KEY_ID') THEN
          L_KEY_ID := P_WRK_STDJHMNT.ADDL_INFO('KEY_ID');
        END IF;
        DBG('l_key_id =' || L_KEY_ID);
        BEGIN
          SELECT AUTH_STAT
            INTO L_AUTH_STAT
            FROM STTB_RECORD_LOG
           WHERE KEY_ID = L_KEY_ID
             AND MOD_NO = (SELECT MAX(MOD_NO)
                             FROM STTB_RECORD_LOG
                            WHERE KEY_ID = L_KEY_ID);
          DBG('Got L_Auth from RECORD log ' || L_AUTH_STAT);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('NO date found? is key Wrong?');
        END;

        CSPKS_REQ_GLOBAL.PR_SET_REQ_KEY(L_STDCUSAC_RECORD_KEY);
        CSPKS_REQ_GLOBAL.PR_SET_FUNC_TYPE(L_STDCUSAC_FUNCTION_TYPE);
        CSPKS_REQ_GLOBAL.PR_SET_KEY_ID(L_STDCUSAC_KEY_ID);

      END IF;
      IF NVL(L_AUTH_STAT, '*') = 'U' THEN
        L_JOINT_ERROR := FALSE;
        DBG('P_wrk_count:' ||
            P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
        DBG('P_Prev_count:' ||
            P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
        IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT <>
           P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT THEN
          L_JOINT_ERROR := TRUE;
          DBG('Change in count');
        ELSE
          FOR I IN 1 .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT LOOP

            IF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).BRANCH_CODE,
                   '*') <>
               NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).BRANCH_CODE,
                   '*') THEN
              L_JOINT_ERROR := TRUE;
              DBG('Change in branch_code ');
            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .CUST_AC_NO,
                      '*') <> NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                  .CUST_AC_NO,
                                  '*') THEN
              L_JOINT_ERROR := TRUE;
              DBG('Change in cust_ac_no ');
            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_CODE,
                      '*') <> NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                  .JOINT_HOLDER_CODE,
                                  '*') THEN
              L_JOINT_ERROR := TRUE;
              DBG('Change in joint_holder_code ');
            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_DESCRIPTION,
                      '*') <> NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                  .JOINT_HOLDER_DESCRIPTION,
                                  '*') THEN
              L_JOINT_ERROR := TRUE;
              DBG('Change in joint_holder_description ');
            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER,
                      '*') <> NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                  .JOINT_HOLDER,
                                  '*') THEN
              L_JOINT_ERROR := TRUE;
              DBG('Change in joint_holder ');

            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .START_DATE,
                      SYSDATE + 1000) <>
                  NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .START_DATE,
                      SYSDATE + 1000) THEN

              L_JOINT_ERROR := TRUE;
              DBG('Change in start_date ');

            ELSIF NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                      SYSDATE + 1000) <>
                  NVL(P_PREV_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                      SYSDATE + 1000) THEN

              L_JOINT_ERROR := TRUE;
              DBG('Change in end_date ');
            END IF;
          END LOOP;
        END IF;
        IF L_JOINT_ERROR THEN
          DBG('Joint holder details of the account is in Unauthorized state in joint holder maintanance screen');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-JHM-012', ' ');
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE NOT IN ('MISPKP') AND
       NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT, 0) > 0 THEN
      DBG('COUNT-->' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
      FOR J IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
        DBG('Ude_variance-->' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
            .UDE_VARIANCE);
        IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
         .UDE_VARIANCE IS NOT NULL AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(J)
           .UDE_VARIANCE NOT BETWEEN - 100 AND 100 THEN
          DBG('ude variance is not in the allowed range...');
          P_ERR_CODE   := 'ST-VALS-080';
          P_ERR_PARAMS := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

        END IF;
      END LOOP;
    END IF;

    IF (P_FUNCTION_ID = 'STDCUSAC' OR G_CHILD_FUNCTION) AND
       P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      DBG('validation for Line Account');
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'L' THEN
        DBG('Its Line account');
        IF NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_DR, 'N') <> 'Y' AND
           NVL(P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_NO_CR, 'N') <> 'Y' THEN

          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACC-720', '');

        END IF;
      END IF;

      IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP

          IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).EFFECTIVE_DATE IS NULL AND P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
             .LINKAGE_TYPE = 'F' THEN

            P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).EFFECTIVE_DATE := GLOBAL.APPLICATION_DATE;

          END IF;

          IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I).EFFECTIVE_DATE IS NOT NULL AND P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
             .LINKAGE_TYPE <> 'F' THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'GEDFACOVD_4', '');
            RETURN FALSE;
          END IF;

          IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
           .EFFECTIVE_DATE < P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE THEN
            DBG('Coming for Account Open Check ');
            DBG('Account opening date is  ' ||
                P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'GEDFACOVD_5', '');
            RETURN FALSE;
          END IF;

          BEGIN
            SELECT MAX(DELINK_DATE)
              INTO L_DELINK_DATE
              FROM STTM_CUST_ACC_LNK_HIST
             WHERE BRANCH_CODE = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                  .BRANCH_CODE
               AND CUST_AC_NO = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                  .CUST_AC_NO
               AND LINKED_REF_NO = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                  .LINKED_REF_NO

               AND CUSTOMER_NO = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                  .CUSTOMER_NO
               AND LINKAGE_TYPE = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                  .LINKAGE_TYPE;

          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBG('No data for linkage history');
              L_DELINK_DATE := NULL;
          END;

          IF NOT
              ELPKS_FACILITY_SERVICE.FN_CHECK_LINE_START_DATE(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                                              .LINKED_REF_NO,
                                                              P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                                                              .CUSTOMER_NO,
                                                              L_LINE_START_DATE) THEN
            DBG('Failed in getting the Line Start Date');
          END IF;

          IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
           .EFFECTIVE_DATE < L_LINE_START_DATE THEN
            DBG('Line Start Date is  ' || L_LINE_START_DATE);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'GEDFACOVD_2', '');
            RETURN FALSE;
          END IF;

          IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
           .EFFECTIVE_DATE > GLOBAL.APPLICATION_DATE THEN
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'IC-WMNT08', '');
            RETURN FALSE;
          END IF;

          IF L_DELINK_DATE IS NOT NULL AND

             P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
            .EFFECTIVE_DATE <= L_DELINK_DATE THEN

            DBG('Application date is  ' || GLOBAL.APPLICATION_DATE);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'GEDFACOVD_6', '');
            RETURN FALSE;
          END IF;
        END LOOP;
      END IF;
    END IF;

    G_VARIANCE_CHANGED := FALSE;
    G_RATE_CHANGED     := FALSE;

    IF P_ACTION_CODE = 'ALWEUCOMM' THEN
      DBG('inside ALWEUCOMM action code ');
      DBG('p_stdcusac.v_sttms_cust_account.AUTO_CHQBK_REQUEST ' ||
          P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT := P_STDCUSAC.V_STTMS_CUST_ACCOUNT;
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST, 'N') = 'Y' THEN
        BEGIN
          SELECT CHQNO_MASK
            INTO G_CHQ_MASK
            FROM STTMS_BRANCH
           WHERE BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in getting the cheque mask');
        END;
        DBG('mask is' || G_CHQ_MASK);
      END IF;
      DBG('p_Action_Code inside my if :' || P_ACTION_CODE);
      L_T := SUBSTR(G_CHQ_MASK, 1, 1);

      IF L_T = 'T' THEN
        L_ALW_EU_OR_COMM := 'Y';
      ELSIF L_T = 'N' THEN
        L_ALW_EU_OR_COMM := 'N';
      END IF;

      IF L_ALW_EU_OR_COMM = 'Y' THEN
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD22 := L_ALW_EU_OR_COMM;
      ELSE
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD22 := L_ALW_EU_OR_COMM;
      END IF;
      DBG('p_wrk_stdcusac.v_cstbs_ui_columns.char_field22' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD22);
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT_UNAUTH
          FROM STTBS_RECORD_LOG
         WHERE KEY_ID =
               '~STTM_ACCOUNT_MAINT_INSTR~' ||
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~'
           AND AUTH_STAT = 'U';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed in selecting the count');
          L_COUNT_UNAUTH := 0;
      END;
      DBG('l_count_unauth is ' || L_COUNT_UNAUTH);
      IF L_COUNT_UNAUTH <> 0 AND
         ((NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_1,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_1,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_2,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_2,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_3,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_3,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_4,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.MAINT_INSTR_4,
                               '*#*')) OR
         (P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.DATE_OF_LAST_MAINT <>
         P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.DATE_OF_LAST_MAINT) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR1_WHEN,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR1_WHEN,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR2_WHEN,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR2_WHEN,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR3_WHEN,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR3_WHEN,
                               '*#*')) OR
         (NVL(P_WRK_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR4_WHEN,
               '*#*') <> NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_MAINT_INSTR.INSTR4_WHEN,
                               '*#*'))) THEN
        DBG('Going to change Instruction details? Sorry wont be allowed');
        P_ERR_CODE   := 'ST-ACC-705';
        P_ERR_PARAMS := NULL;
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('MODIFY') THEN
      IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
          IF P_PREV_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
            FOR A IN 1 .. P_PREV_STDCUSAC.V_ICTMS_ACC_PR.COUNT LOOP
              IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).PROD = P_PREV_STDCUSAC.V_ICTMS_ACC_PR(A).PROD AND P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
                 .RECORD_STAT <> P_PREV_STDCUSAC.V_ICTMS_ACC_PR(I)
                 .RECORD_STAT THEN
                IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
                  IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I).RECORD_STAT = 'C' THEN
                    FOR J IN 1 .. P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
                      IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
                       .PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(J).PROD THEN
                        P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(J).RECORD_STAT := 'C';
                      END IF;
                    END LOOP;
                  ELSE
                    FOR K IN 1 .. P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
                      IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
                       .PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(K).PROD THEN
                        P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(K).RECORD_STAT := 'O';

                        IF P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
                          FOR B IN 1 .. P_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT LOOP
                            IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(K)
                             .PROD = P_STDCUSAC.V_ICTMS_ACC_EFFDT(B).PROD AND P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(K)
                               .UDE_EFF_DT = P_STDCUSAC.V_ICTMS_ACC_EFFDT(B)
                               .UDE_EFF_DT THEN
                              P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(K).RECORD_STAT := P_STDCUSAC.V_ICTMS_ACC_EFFDT(B)
                                                                                 .RECORD_STAT;
                            END IF;
                          END LOOP;
                        END IF;

                      END IF;
                    END LOOP;
                  END IF;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('Signatures wrk 2 here' ||
        P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);
    DBG('Signatures read  2 here' ||
        P_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);
    DBG('Gonna check for duplicate signatures');
    IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
      K := 1;
      FOR IDX IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
        DBG('idx is :' || IDX);
        L_PRESENT := FALSE;
        IF L_TB_V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
          FOR IDX2 IN L_TB_V_SVTMS_ACC_SIG_DET.FIRST .. L_TB_V_SVTMS_ACC_SIG_DET.LAST LOOP
            IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(IDX)
             .CIF_SIG_ID = L_TB_V_SVTMS_ACC_SIG_DET(IDX2).CIF_SIG_ID AND
                (P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(IDX)
                 .CIFID = L_TB_V_SVTMS_ACC_SIG_DET(IDX2).CIFID) THEN
              L_PRESENT := TRUE;
              EXIT;
            END IF;
          END LOOP;
        END IF;
        IF NOT L_PRESENT THEN
          L_TB_V_SVTMS_ACC_SIG_DET(K) := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(IDX);
          K := K + 1;
        END IF;
      END LOOP;
    END IF;
    DBG('l_tb_v_svtms_acc_sig_det cpount is :' ||
        L_TB_V_SVTMS_ACC_SIG_DET.COUNT);
    P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET := L_TB_V_SVTMS_ACC_SIG_DET;
    DBG('Assigned the values after deleting duplicate signatures');
    DBG('Signatures wrk count here' ||
        P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);

    IF P_ACTION_CODE IN
       (CSPKS_REQ_GLOBAL.P_MODIFY, CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      DBG('p_wrk_stdcusac.v_ictms_acc_pr.count ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT);
      IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR.COUNT > 0 THEN
        DBG('p_wrk_stdcusac.v_ictms_acc_effdt.count ' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT);
        DBG('p_wrk_stdcusac.v_ictms_acc_udevals.count ' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
        FOR I IN P_WRK_STDCUSAC.V_ICTMS_ACC_PR.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_PR.LAST LOOP
          IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.COUNT > 0 THEN
            FOR J IN P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT.LAST LOOP
              IF P_WRK_STDCUSAC.V_ICTMS_ACC_PR(I)
               .PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(J).PROD THEN
                IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
                  FOR K IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                    IF P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(J).PROD = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).PROD AND P_WRK_STDCUSAC.V_ICTMS_ACC_EFFDT(J)
                       .UDE_EFF_DT = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                       .UDE_EFF_DT THEN
                      DBG('p_wrk_stdcusac.v_ictms_acc_udevals(k).ude_id ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                          .UDE_ID);
                      DBG('p_wrk_stdcusac.v_sttms_cust_account.CCY ' ||
                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
                      DBG('p_wrk_stdcusac.v_ictms_acc_udevals(k).Prod ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).PROD);
                      DBG('p_wrk_stdcusac.V_ictms_acc_udevals(k).ude_eff_dt ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                          .UDE_EFF_DT);
                      DBG('p_wrk_stdcusac.v_ictms_acc_udevals(k).ude_value ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                          .UDE_VALUE);
                      DBG('p_wrk_stdcusac.v_ictms_acc_udevals(k).ude_variance ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                          .UDE_VARIANCE);
                      DBG('p_wrk_stdcusac.V_ictms_acc_udevals(k).brn ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).BRN);
                      IF NOT
                          ICPKS_UTIL.FN_VALIDATE_MIN_MAX_UDE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .UDE_ID,
                                                             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).PROD,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .UDE_EFF_DT,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .RATE_CODE,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .TD_RATE_CODE,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .UDE_VALUE,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                             .UDE_VARIANCE,
                                                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).BRN,
                                                             'FLEXCUBE',
                                                             P_FUNCTION_ID,
                                                             P_ERR_CODE,
                                                             P_ERR_PARAMS) THEN
                        DBG('Failed in Min Max validation');
                        RETURN FALSE;
                      END IF;

                      IF NOT
                          ICPKS_UTIL.FN_VALIDATE_MIN_MAX_VARIANCE(

                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                                  .UDE_ID,
                                                                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K).PROD,
                                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS     (K)
                                                                  .UDE_VARIANCE,

                                                                  'FLEXCUBE',
                                                                  P_FUNCTION_ID,
                                                                  P_ERR_CODE,
                                                                  P_ERR_PARAMS) THEN
                        DBG('Failed in Min Max Variance validation');
                      END IF;

                    END IF;
                  END LOOP;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END LOOP;
      END IF;
    END IF;

    IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') THEN
      DBG('p_Wrk_stdcusac.v_ictms_acc_udevals.count ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT);
      IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
        FOR K IN P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
          IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
            L_PR_INT_UDEVALS := NULL;
            DBG('now for ude id ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                .UDE_ID);
            IF NOT ICPKSS_UTIL.FN_GET_RES_IC_RATE(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS               (K).BRN,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS               (K).PROD,
                                                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS               (K)
                                                  .UDE_EFF_DT,
                                                  P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS               (K)
                                                  .UDE_ID,
                                                  L_PR_INT_UDEVALS,
                                                  L_UDE_VALUE,
                                                  L_RATE_CODE) THEN
              DBG('Failed in Icpkss_Util.Fn_Get_Res_Ic_Rate ');
              L_UDE_VALUE := L_PR_INT_UDEVALS.UDE_VALUE;
              L_RATE_CODE := L_PR_INT_UDEVALS.RATE_CODE;
            END IF;

            DBG('ude value after resolution ' || L_UDE_VALUE);
            DBG('rate code after resolution ' || L_RATE_CODE);

            DBG('l_pr_int_udevals.ude_value is ' ||
                L_PR_INT_UDEVALS.UDE_VALUE);
            DBG('l_pr_int_udevals.rate_code is ' ||
                L_PR_INT_UDEVALS.RATE_CODE);
            DBG('l_pr_int_udevals.td_rate_code is ' ||
                L_PR_INT_UDEVALS.TD_RATE_CODE);

            IF L_PR_INT_UDEVALS.UDE_ID = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
              .UDE_ID THEN
              IF NVL(L_UDE_VALUE, 0) <>
                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_VALUE, 0) THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-VALS-111',
                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID);
              END IF;
              IF NVL(L_RATE_CODE, '***') <>
                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).RATE_CODE, '***') THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-VALS-112',
                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID);
              END IF;
              IF NVL(L_PR_INT_UDEVALS.TD_RATE_CODE, '***') <>
                 NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).TD_RATE_CODE,
                     '***') THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-VALS-113',
                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID);
              END IF;
              IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_VARIANCE, 0) > 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-VALS-114',
                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID);
              ELSIF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_VARIANCE,
                        0) < 0 THEN
                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             'ST-VALS-115',
                             P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID);
              END IF;
            END IF;
          ELSIF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
            IF P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT > 0 THEN
              FOR L IN P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.FIRST .. P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.LAST LOOP
                IF P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L)
                 .UDE_ID = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_ID AND P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L)
                   .UDE_EFF_DT = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                   .UDE_EFF_DT THEN
                  IF NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L).UDE_VALUE,
                         0) <>
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_VALUE, 0) THEN
                    DBG('Ude value changed for UDE ID ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                        .UDE_VALUE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'ST-VALS-111',
                                 P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                 .UDE_ID);
                  END IF;
                  IF NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L).RATE_CODE,
                         '***') <>
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).RATE_CODE,
                         '***') THEN
                    DBG('IC Rate code changed for UDE ID ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                        .RATE_CODE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'ST-VALS-112',
                                 P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                 .UDE_ID);
                  END IF;
                  IF NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L).TD_RATE_CODE,
                         '***') <>
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).TD_RATE_CODE,
                         '***') THEN
                    DBG('TD Rate code changed for UDE ID ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                        .TD_RATE_CODE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'ST-VALS-113',
                                 P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                 .UDE_ID);
                  END IF;
                  IF NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L).UDE_VARIANCE,
                         0) >
                     NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K).UDE_VARIANCE,
                         0) THEN
                    DBG('Variance decreased for UDE ID ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                        .UDE_VALUE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'ST-VALS-115',
                                 P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                 .UDE_ID);
                  ELSIF NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L)
                            .UDE_VARIANCE,
                            0) < NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                     .UDE_VARIANCE,
                                     0) THEN
                    DBG('Variance increased for UDE ID ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                        .UDE_VALUE);
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 P_SOURCE,
                                 'ST-VALS-114',
                                 P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(K)
                                 .UDE_ID);
                  END IF;
                END IF;
              END LOOP;
            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('Calling fn_validate_channels');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_VALIDATE_CHANNELS(P_SOURCE,
                                                          P_FUNCTION_ID,
                                                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                          P_STDCUSAC.TY_STCCHNLM.V_STTMS_ACCOUNT_CHANNEL,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('fn_default_channels has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
    END IF;

    IF P_ACTION_CODE IN ('MODIFY', 'NEW') THEN
      DBG('checking  for book account');
      IF P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_ACC <>
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO THEN
        DBG('Book acc is not the same as main account');
        BEGIN
          SELECT NVL(AC_STAT_FROZEN, 'N'),
                 NVL(AC_STAT_DORMANT, 'N'),
                 CUST_NO
            INTO L_FROZEN, L_DORMANT, L_BOOKACC_CUSTOMER
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_ACC
             AND BRANCH_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC.BOOK_BRN;
          DBG('Checking for book account customer : ' ||
              L_BOOKACC_CUSTOMER);
          SELECT NVL(DECEASED, 'N'),
                 NVL(WHEREABOUTS_UNKNOWN, 'N'),
                 NVL(FROZEN, 'N')
            INTO L_DECEASED, L_WHEREABOUTS_UNKNOWN, L_CUST_FROZEN
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = L_BOOKACC_CUSTOMER;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in selecting from sttm_cust_account');
            L_FROZEN              := 'N';
            L_DORMANT             := 'N';
            L_DECEASED            := 'N';
            L_WHEREABOUTS_UNKNOWN := 'N';
            L_CUST_FROZEN         := 'N';
        END;
        IF L_DORMANT = 'Y' OR L_FROZEN = 'Y' OR L_DECEASED = 'Y' OR
           L_WHEREABOUTS_UNKNOWN = 'Y' OR L_CUST_FROZEN = 'Y' THEN
          DBG('The interest booking account is either dormant,frozen or belongs to a frozen/deceased/whereabouts unknows customer');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACC-721', P_ERR_PARAMS);
        END IF;
      END IF;

      DBG('checking  for charge book account');
      IF P_WRK_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC <>
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO THEN
        DBG('Book acc is not the same as main account');
        BEGIN
          SELECT NVL(AC_STAT_FROZEN, 'N'),
                 NVL(AC_STAT_DORMANT, 'N'),
                 CUST_NO
            INTO L_FROZEN, L_DORMANT, L_BOOKACC_CUSTOMER
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_ACC
             AND BRANCH_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC.CHARGE_BOOK_BRN;
          DBG('Checking for charge account customer : ' ||
              L_BOOKACC_CUSTOMER);
          SELECT NVL(DECEASED, 'N'),
                 NVL(WHEREABOUTS_UNKNOWN, 'N'),
                 NVL(FROZEN, 'N')
            INTO L_DECEASED, L_WHEREABOUTS_UNKNOWN, L_CUST_FROZEN
            FROM STTMS_CUSTOMER
           WHERE CUSTOMER_NO = L_BOOKACC_CUSTOMER;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('Error in selecting from sttm_cust_account');
            L_FROZEN              := 'N';
            L_DORMANT             := 'N';
            L_DECEASED            := 'N';
            L_WHEREABOUTS_UNKNOWN := 'N';
            L_CUST_FROZEN         := 'N';
        END;
        IF L_DORMANT = 'Y' OR L_FROZEN = 'Y' OR L_DECEASED = 'Y' OR
           L_WHEREABOUTS_UNKNOWN = 'Y' OR L_CUST_FROZEN = 'Y' THEN
          DBG('The charge booking account is either dormant,frozen or belongs to a frozen/deceased/whereabouts unknows customer');
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-ACC-722', P_ERR_PARAMS);
        END IF;
      END IF;

    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      BEGIN
        SELECT 1
          INTO L_COUNT3
          FROM STTB_RECORD_LOG A
         WHERE A.KEY_ID =
               '~STTM_CUST_ACCOUNT~' ||
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~'
           AND A.ACTION_CODE = P_ACTION_CODE
           AND A.AUTH_STAT = 'U'
           AND A.TANKING_STATUS = 'T'
           AND MOD_NO =
               (SELECT MAX(B.MOD_NO)
                  FROM STTB_RECORD_LOG B
                 WHERE B.KEY_ID = A.KEY_ID
                   AND B.ACTION_CODE = A.ACTION_CODE
                   AND B.AUTH_STAT = A.AUTH_STAT
                   AND B.TANKING_STATUS = A.TANKING_STATUS);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          L_COUNT3 := 0;
        WHEN TOO_MANY_ROWS THEN
          L_COUNT3 := 1;
        WHEN OTHERS THEN
          L_COUNT3 := 0;
      END;

      DBG('l_count_unauth is ' || L_COUNT3);
      IF L_COUNT3 = 1 THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE    := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_DATE;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_BALANCE;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO      := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREVIOUS_STATEMENT_NO;
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREV_RUNBAL_PRINTED_IN_PBK := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.PREV_RUNBAL_PRINTED_IN_PBK;
      END IF;
    END IF;

    IF P_FUNCTION_ID = 'STDCUSAC' THEN

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE IS NULL AND

         (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FREQUENCY IS NOT NULL OR
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME IS NOT NULL) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'AC-CAM-001', '');

      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE = 'H' AND

         (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FREQUENCY IS NULL OR
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME IS NOT NULL) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'AC-CAM-002', '');

      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE = 'D' AND

         (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FREQUENCY IS NOT NULL OR
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME IS NULL) THEN

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'AC-CAM-003', '');

      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_STMT_CYCLE IS NOT NULL THEN

        BEGIN
          SELECT START_TIME, END_TIME
            INTO L_START, L_END
            FROM MSTM_CAMT052_PARAM
           WHERE BANK_CODE = (SELECT BANK_CODE FROM STTM_BANK)

             AND RECORD_STAT = 'O'
             AND AUTH_STAT = 'A'

          ;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Please maintain CAMT parameters in STDCAMPM');
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'AC-CAM-005', '');
        END;

        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME < L_START OR
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CAMT_FIXED_TIME > L_END THEN
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'AC-CAM-004', '');

        END IF;

      END IF;

    END IF;

    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_prev_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Post_Default_And_Validate ..');
      DEBUG.PR_DEBUG('**', SQLERRM);

      IF CR_PRODS%ISOPEN THEN
        CLOSE CR_PRODS;
      END IF;
      DEBUG.PR_DEBUG('**', DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_DEFAULT_AND_VALIDATE;

  FUNCTION FN_PRE_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                            P_SOURCE_OPERATION IN VARCHAR2,
                            P_FUNCTION_ID      IN VARCHAR2,
                            P_ACTION_CODE      IN VARCHAR2,
                            P_CHILD_FUNCTION   IN VARCHAR2,
                            P_POST_UPL_STAT    IN VARCHAR2,
                            P_MULTI_TRIP_ID    IN VARCHAR2,
                            P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_PREV_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                            P_ERR_CODE         IN OUT VARCHAR2,
                            P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    L_WRK_COUNT  NUMBER := 0;
    L_PREV_COUNT NUMBER := 0;
    L_PAY_METHOD ICTMS_PR_INT.PAYMENT_METHOD%TYPE;

  BEGIN

    DBG('In Fn_Pre_Upload_Db..');
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      G_TEMP_CHECK := P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST;
    END IF;
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW THEN
      G_TEMP_CARD := P_WRK_STDCUSAC.V_STVWS_DC_REQUEST;
    END IF;

    DBG('Linkages COunt kernel1:' ||
        P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_stdcusac kernel1:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_Prev_stdcusac kernel1:' ||
        P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

    P_WRK_STDCUSAC.TY_CSCOFACM.V_CSTBS_EXT_WS_MASTER.KEY_ID := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO ||
                                                               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

    DBG('p_action_code: ' || P_ACTION_CODE);

    P_WRK_STDCUSAC.TY_CSCCUSLN.V_STTM_CUST_ACCOUNT.CUST_AC_NO  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    P_WRK_STDCUSAC.TY_CSCCUSLN.V_STTM_CUST_ACCOUNT.BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      IF NVL(P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT, 'N') <>
         NVL(P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT, 'N') THEN
        UPDATE STTBS_ACCOUNT
           SET AC_STAT_DORMANT = P_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.AC_STAT_DORMANT

         WHERE AC_GL_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      END IF;
    END IF;

    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Calling fn_preupld_calls');
    IF NOT FN_PREUPLD_CALLS(P_FUNCTION_ID,
                            P_SOURCE,
                            P_ACTION_CODE,
                            P_WRK_STDCUSAC) THEN
      DBG('fn_preupld_calls has returned false');
      RETURN FALSE;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      IF P_SOURCE <> 'FLEXCUBE' THEN
        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE IS NULL THEN
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE;
        END IF;

        IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO IS NULL THEN
          SELECT MAX(MOD_NO + 1)
            INTO P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO
            FROM STTMS_CUST_ACCOUNT
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        END IF;

      END IF;
    END IF;

    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPL_AC_GEN := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPL_AC_GEN,
                                                          'N');

    IF P_ACTION_CODE = 'COPY' THEN

      DBG('Success Case...');
      DBG('Inside Copy...');
      DBG('Calling  Fn_Sys_Query_Desc_Fields..');
      IF NOT STPKS_STDCUSAC_MAIN.FN_SYS_QUERY_DESC_FIELDS(P_SOURCE,
                                                          P_SOURCE_OPERATION,
                                                          P_FUNCTION_ID,
                                                          P_ACTION_CODE,
                                                          P_WRK_STDCUSAC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Query_Desc_Fields..');
        RETURN FALSE;
      END IF;

    END IF;

    IF P_WRK_STDCUSAC.TY_ICCINSTR.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NULL THEN
      P_WRK_STDCUSAC.TY_ICCINSTR.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    END IF;

    IF P_ACTION_CODE = 'MODIFY' THEN
      DBG('Checking for ude val updation');
      L_WRK_COUNT := P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;

      L_PREV_COUNT := P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS.COUNT;

      IF L_WRK_COUNT > 0 THEN
        FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
          IF L_PREV_COUNT > 0 THEN
            FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
              IF (NVL(P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_ID,
                      '@') =
                 NVL(P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1).UDE_ID,
                      '@')

                 AND P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                 .UDE_EFF_DT = P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                 .UDE_EFF_DT

                 )

               THEN

                DBG('New Value is ' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX)
                    .UDE_VALUE);
                DBG('Product is' || P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD);

                BEGIN
                  SELECT PAYMENT_METHOD
                    INTO L_PAY_METHOD
                    FROM ICTM_PR_INT
                   WHERE PRODUCT_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).PROD;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    DBG('Bombed in selecting Product' || SQLERRM);
                    RETURN FALSE;
                END;
                DBG('Payment method is' || L_PAY_METHOD);
                IF L_PAY_METHOD = 'D' THEN

                  IF P_WRK_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX).UDE_VALUE <> P_PREV_STDCUSAC.V_ICTMS_ACC_UDEVALS(L_INDEX1)
                     .UDE_VALUE THEN
                    DBG('Record is Modified...');
                    PR_LOG_ERROR(P_FUNCTION_ID,
                                 'FLEXCUBE',
                                 'IC-DEPDIS04',
                                 P_ERR_PARAMS);
                  END IF;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END LOOP;
      END IF;
    END IF;

    DBG('Linkages COunt kernel2:' ||
        P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_stdcusac kernel2:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_Prev_stdcusac kernel2:' ||
        P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

    DBG('p_action_code=' || P_ACTION_CODE);
    DBG('cspks_service.p_auth=' || CSPKS_SERVICE.P_AUTH);
    IF P_ACTION_CODE = CSPKS_SERVICE.P_AUTH THEN
      DBG('inside post upload db_authorisation....need to update back the status to P from N in ictb_maint_queue');
      FOR I IN (SELECT DISTINCT PROD || '~' || UDE_EFF_DT PROD_UDE
                  FROM ICTM_ACC_UDEVALS
                 WHERE BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO) LOOP

        UPDATE ICTB_MAINT_QUEUE
           SET STATUS = 'P'
         WHERE MAINT_TYPE = 'SP'
           AND MAINT_KEY LIKE P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '~' ||
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '~' ||
               I.PROD_UDE
           AND BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND STATUS = 'N';
      END LOOP;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('Going to call fn_UpdateLimitUtil for modify');
      IF (P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 AND
         P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT = 0) OR
         (P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT = 0 AND
         P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0) THEN
        IF NOT STPKS_STDCUSAC_UTILS_2.FN_UPDATELIMITUTIL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                         'R',
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
          DBG('Failed in  fn_UpdateLimitUtil ... : ' || P_ERR_CODE ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;
    END IF;

    DBG('fatca p_prev_stdcusac.v_ictms_acc.interest_rate : ' ||
        P_PREV_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE || 'work : ' ||
        P_WRK_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE);
    DBG('fatca p_prev_stdcusac.v_ictms_acc.mat_dt : ' ||
        P_PREV_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE || 'work : ' ||
        P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
    DBG('action : ' || P_ACTION_CODE);

    IF P_FUNCTION_ID IN
       ('STDCUSTD', 'IADCUSTD', 'STDTDSIM', 'TDMM', 'IPTDMM') AND
       P_ACTION_CODE = 'MODIFY' AND
       (NVL(P_PREV_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE, '0') <>
       NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE, '0') OR
       NVL(P_PREV_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
            CSPKSS_UPLOAD.FN_DATE_TIME('01-JAN-1900')) <>
       NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
            CSPKSS_UPLOAD.FN_DATE_TIME('01-JAN-1900')))

     THEN
      BEGIN
        INSERT INTO STTMS_AC_GRANDFATHERED_LOG
        VALUES
          (P_WRK_STDCUSAC.V_ICTMS_ACC.BRN,
           P_WRK_STDCUSAC.V_ICTMS_ACC.ACC,
           GLOBAL.APPLICATION_DATE,
           'N');
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
          UPDATE STTMS_AC_GRANDFATHERED_LOG
             SET MODIFIED_DATE = GLOBAL.APPLICATION_DATE
           WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_ICTMS_ACC.ACC
             AND BRANCH_CODE = P_WRK_STDCUSAC.V_ICTMS_ACC.BRN;
      END;
    END IF;

    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IS_FORGOTTEN := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IS_FORGOTTEN,
                                                            'N');
    DBG('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Pre_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_UPLOAD_DB;

  FUNCTION FN_POST_UPLOAD_DB(P_SOURCE           IN VARCHAR2,
                             P_SOURCE_OPERATION IN VARCHAR2,
                             P_FUNCTION_ID      IN VARCHAR2,
                             P_ACTION_CODE      IN VARCHAR2,
                             P_CHILD_FUNCTION   IN VARCHAR2,
                             P_POST_UPL_STAT    IN VARCHAR2,
                             P_MULTI_TRIP_ID    IN VARCHAR2,
                             P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_PREV_STDCUSAC    IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                             P_ERR_CODE         IN OUT VARCHAR2,
                             P_ERR_PARAMS       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    REC_STAT VARCHAR2(1);

    L_WRK_STDCUSAC STPKS_STDCUSAC_MAIN.TY_STDCUSAC;

    L_TY_REC_CARD_UPLD    STPKS_STDCRDMS_MAIN.TY_STDCRDMS;
    L_TY_REC_CHQBOOK_UPLD CAPKS_CADCHBOO_MAIN.TY_CADCHBOO;
    P_STATUS              VARCHAR2(10);
    L_AUTO_AUTH_USERS     VARCHAR2(3);

    L_COUNT         NUMBER := 0;
    L_CHQBK_REQUEST STTMS_CHQBK_REQUEST%ROWTYPE;
    L_DC_REQUEST    STTMS_DC_REQUEST%ROWTYPE;
    L_COUNT2        NUMBER := 0;

    L_LINKAGE_CNT NUMBER;
    L_RECORD_STAT STTM_CUST_ACCOUNT.RECORD_STAT%TYPE;
    PSERIAL       VARCHAR2(20);
    PREFERENCENO  VARCHAR2(16);

    P_CUST_NO         STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    P_BRANCH_CODE     VARCHAR2(3);
    P_CONTRACT_REF_NO STTB_RM_CONTRACT_LOG.CONTRACT_REF_NO%TYPE;
    P_ACCOUNT_CLASS   STTB_RM_CONTRACT_LOG.ACCOUNT_CLASS%TYPE;
    P_CUST_AC_NO      STTB_RM_CONTRACT_LOG.CUST_AC_NO%TYPE;
    P_MODULE_CODE     STTB_RM_CONTRACT_LOG.MODULE_CODE%TYPE;
    P_RM_ID           STTB_RM_CONTRACT_LOG.CURR_RM_ID%TYPE;
    P_APP_DATE        STTMS_DATES.TODAY%TYPE;
    P_PROD_CODE       CSTM_PRODUCT.PRODUCT_CODE%TYPE;
    P_EVENT_CODE      VARCHAR2(6);
    L_ERR_PARAM       VARCHAR2(50);
    L_ERR_CODE        VARCHAR2(4000);
    L_AC_CLASS_TYPE   STTM_ACCOUNT_CLASS.AC_CLASS_TYPE%TYPE;

    L_ALPHA_OR_NUMA VARCHAR2(3);
    L_NUM           VARCHAR2(16);
    L_MAX_NUM       NUMBER;
    L_ALPHA_LEN     NUMBER;
    L_ALPHA_MASK    VARCHAR2(16);
    L_NUMA_MASK     VARCHAR2(16);
    L_ALPHA_NEXT    VARCHAR2(16);
    L_FIRST_CHQNO   CATM_CHECK_BOOK.FIRST_CHECK_NO%TYPE;
    L_NUMA_LEN      NUMBER;
    L_CNT           NUMBER;
    L_ACCOUNT       STTMS_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_INVALID_COUNT NUMBER;
    L_CHECK_NO      NUMBER(16);

    L_AUTO_AUTH BOOLEAN;
    L_AUTH_STAT STTM_ACC_JOINT_MASTER.AUTH_STAT%TYPE;

    L_WRK_COUNT    NUMBER;
    L_PREV_COUNT   NUMBER;
    L_REC_FOUND    BOOLEAN := FALSE;
    L_MIN_EFF_DATE DATE;

    L_DELINK_DATE DATE;
    L_SIG_COUNT   NUMBER := 0;
    L_MULTI_FLAG  VARCHAR2(1);

    P_MAIN_AC_NO       VARCHAR2(20);
    L_USER_ID          SMTB_USER.USER_ID%TYPE := GLOBAL.USER_ID;
    L_AUTH_STAT1       CHAR(1) := 'A';
    L_BRANCH1          STTM_BRANCH.BRANCH_CODE%TYPE := GLOBAL.CURRENT_BRANCH;
    L_COUNT_1          VARCHAR2(200);
    L_EFF_DT           ICTMS_ACC_EFFDT.UDE_EFF_DT%TYPE;
    L_EVENT_CLASS_CODE STTMS_ACCOUNT_CLASS.TURNOVER_EVENT_CLASS_CODE%TYPE;
  BEGIN

    DBG('In Fn_Post_Upload_Db..');

    DBG(P_ACTION_CODE);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN
      IF NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'N' AND
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SWEEP_REQUIRED, 'N') = 'Y' THEN

        DBG('CALLING stpks_stdcusac_utils_1.fn_insert_adsweep_det to insert auto deposit into swepe structure.');
        IF NOT STPKS_STDCUSAC_UTILS_1.FN_INSERT_ADSWEEP_DET(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('Failed in fn_insert_adsweep_det');
          RETURN FALSE;
        END IF;

      END IF;
    END IF;

    IF P_ACTION_CODE = 'AUTH' THEN
      IF NOT FN_UPDATE_SIG_HISTORY(P_FUNCTION_ID,
                                   P_ACTION_CODE,
                                   P_WRK_STDCUSAC,
                                   P_ERR_CODE,
                                   P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Update_Sig_History');
      END IF;
    END IF;

    BEGIN
      SELECT UNIQUE_CHEQUE_NO
        INTO G_PRM_UNIQUE_CHEQUE
        FROM STTMS_BANK
       WHERE RECORD_STAT = 'O'
         AND AUTH_STAT = 'A'
         AND ONCE_AUTH = 'Y'
         AND ROWNUM = 1;
    EXCEPTION

      WHEN NO_DATA_FOUND THEN
        P_ERR_CODE   := 'ST-BRN04';
        P_ERR_PARAMS := '';

        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;

      WHEN OTHERS THEN
        DBG('no bank exists!!!');
    END;

    IF G_PRM_UNIQUE_CHEQUE = 'Y' THEN
      DBG('Cheque number unique for branch....');
      L_ACCOUNT := NULL;
    ELSE
      L_ACCOUNT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    END IF;

    DBG('p_prev_stdcusac.v_sttms_cust_account.receivable_amount--> ' ||
        P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.RECEIVABLE_AMOUNT);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN

      IF P_PREV_STDCUSAC.V_STTMS_ACCOUNT_BALANCE.RECEIVABLE_AMOUNT <> 0 THEN
        DBG('Receivable Amount is greater than zero for the Account');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', 'ST-CUS125', '');
      END IF;
    END IF;

    DBG('Linkages COunt kernel1:' ||
        P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_stdcusac kernel1:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_Prev_stdcusac kernel1:' ||
        P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

    IF NOT
        STPKS_STDCUSAC_UTILS_1.FN_INSERT_STTM_ACC_BALANCE(P_FUNCTION_ID,
                                                          P_WRK_STDCUSAC,

                                                          P_PREV_STDCUSAC,

                                                          P_ACTION_CODE,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
      DBG('Failed in  fn_insert_sttm_acc_balance ... : ' || P_ERR_CODE ||
          SQLERRM);
      RETURN FALSE;
    END IF;

    DBG('Calling fn_postupld_calls');
    IF NOT FN_POSTUPLD_CALLS(P_FUNCTION_ID,
                             P_SOURCE,
                             P_ACTION_CODE,
                             P_WRK_STDCUSAC,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
      DBG('fn_postupld_calls has returned false');
      RETURN FALSE;
    END IF;

    DBG('In Mudrabah sweep..');
    DBG('l_record_stat A' || L_RECORD_STAT);
    BEGIN
      SELECT RECORD_STAT
        INTO L_RECORD_STAT
        FROM STTM_CUST_ACCOUNT
       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      DBG('l_record_stat B' || L_RECORD_STAT);
    EXCEPTION
      WHEN OTHERS THEN
        DBG('IN WOT of sttm_cust_account.record_stat' || SQLERRM);
    END;
    DBG('P Action_Code' || P_ACTION_CODE);
    DBG('Action_Code' || CSPKS_REQ_GLOBAL.P_AUTH);
    DBG('l_record_stat B1' || L_RECORD_STAT);
    DBG('p_Wrk_stdcusac.v_sttms_cust_account.record_stat' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT);

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      IF L_RECORD_STAT = 'C' THEN
        SELECT COUNT(*)
          INTO L_LINKAGE_CNT
          FROM STTM_SWEEP_DETAILS
         WHERE CUST_ACCOUNT =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND NVL(UTILIZED_AMOUNT, 0) = 0;

        DBG('l_linkage_cnt' || L_LINKAGE_CNT);

        IF L_LINKAGE_CNT > 0 THEN

          IF NOT STPKS_PROCESS_SWEEP.FN_DELINK_ALL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN

            DBG('error in delinking the deposit .');
            RETURN FALSE;
          ELSE
            DBG('success in delinking the deposit .');
          END IF;
        END IF;
      END IF;
    END IF;

    DBG('global.fn_get_auto_auth_status  -->' ||
        P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH);
    DBG('global.fn_get_auto_auth_status  -->' ||
        P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT);

    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.Auto_Chqbk_Request ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST);
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.Auto_Dc_Request  ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST);
    DBG('p_prev_Stdcusac.v_Sttms_Cust_Account.Auto_Chqbk_Request ' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST);
    DBG('p_prev_Stdcusac.v_Sttms_Cust_Account.Auto_Dc_Request  ' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST);
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.Once_Auth ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
    DBG('p_prev_Stdcusac.v_Sttms_Cust_Account.Once_Auth ' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH);
    DBG('p_Wrk_Stdcusac.v_Stvws_Dc_Request.card_product' ||
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT);
    DBG('p_prev_Stdcusac.v_Stvws_Dc_Request.card_product ' ||
        P_PREV_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT);
    DBG('p_Wrk_Stdcusac.v_Stvws_Dc_Request.request_reference_no ' ||
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO);
    DBG('p_prev_Stdcusac.v_Stvws_Dc_Request.request_reference_no ' ||
        P_PREV_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO);

    DBG('p_source' || P_SOURCE);
    DBG('p_Action_Code' || P_ACTION_CODE);
    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.Account_Class' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    DBG('p_prev_Stdcusac.v_Sttms_Cust_Account.Account_Class' ||
        P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);

    IF P_SOURCE <> 'FLEXCUBE' AND P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH THEN

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH;
      END IF;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST;
      END IF;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST;
      END IF;
      IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO IS NULL THEN
        P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST := P_PREV_STDCUSAC.V_STVWS_CHQBK_REQUEST;
      END IF;
      IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO IS NULL THEN
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST := P_PREV_STDCUSAC.V_STVWS_DC_REQUEST;
      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS IS NULL THEN
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS := P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      END IF;

    END IF;

    IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST, 'N') = 'Y' AND
       (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N') THEN
      DBG('inside 111--->');
      DBG('p_action_code  -->' || P_ACTION_CODE);
      DBG('cspks_req_global.p_new -->' || CSPKS_REQ_GLOBAL.P_NEW);
      DBG('global.fn_get_auto_auth_status  -->' ||
          GLOBAL.FN_GET_AUTO_AUTH_STATUS);

      IF P_ACTION_CODE IN ('NEW', 'MODIFY') AND
         P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO IS NOT NULL THEN
        L_FIRST_CHQNO := P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO;
        IF L_ALPHA_OR_NUMA = '0' THEN
          DBG('Numeric mask maintained for the branch');
          L_MAX_NUM                                           := REPLACE(UPPER(G_CHQ_MASK),
                                                                         'N',
                                                                         9);
          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO := LPAD(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO,

                                                                      LENGTH(G_CHQ_MASK),
                                                                      '0');
          IF LENGTH(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) <>
             LENGTH(G_CHQ_MASK) OR
             (NVL(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO, 0) +

              NVL(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES, 0)) >
             L_MAX_NUM THEN

            DBG(' Cheque no exceeded limit ');

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CA-CHB04', '');

            RETURN FALSE;
          END IF;

          IF NVL(LENGTH(RTRIM(TRANSLATE(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO,
                                        '0123456789',
                                        '         '))),
                 0) <> 0 THEN
            DBG('Input format is different ');

            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CA-CHQ-005', '');
            RETURN FALSE;
          END IF;
          IF G_PRM_UNIQUE_CHEQUE = 'Y' THEN

            SELECT COUNT(*)
              INTO L_INVALID_COUNT
              FROM CATMS_CHECK_DETAILS
             WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND CHECK_NO BETWEEN
                   TO_NUMBER(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) AND
                   (TO_NUMBER(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) +
                   P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES - 1);
            IF L_INVALID_COUNT > 0 THEN
              P_ERR_CODE   := 'CA-00202';
              P_ERR_PARAMS := '';

              RETURN FALSE;
            ELSE
              L_CHECK_NO := TO_NUMBER(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO);
              FOR I IN 1 .. P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES LOOP
                SELECT COUNT(*)
                  INTO L_INVALID_COUNT
                  FROM CATMS_STOP_PAYMENTS
                 WHERE BRANCH =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND ACCOUNT <>
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                   AND STOP_PAYMENT_TYPE = 'C'
                   AND L_CHECK_NO BETWEEN TO_NUMBER(START_CHECK_NO) AND
                       TO_NUMBER(END_CHECK_NO);
                IF L_INVALID_COUNT > 0 THEN
                  P_ERR_CODE   := 'CA-00205';
                  P_ERR_PARAMS := '';
                  PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CA-00205', '');
                  RETURN FALSE;
                END IF;
                L_CHECK_NO := L_CHECK_NO + 1;
              END LOOP;
            END IF;
          ELSE

            SELECT COUNT(*)
              INTO L_INVALID_COUNT
              FROM CATMS_CHECK_DETAILS
             WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND CHECK_NO BETWEEN
                   TO_NUMBER(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) AND
                   (TO_NUMBER(P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO) +
                   P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES - 1)
               AND ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            IF L_INVALID_COUNT > 0 THEN
              P_ERR_CODE   := 'CA-00202';
              P_ERR_PARAMS := '';

              RETURN FALSE;
            END IF;
          END IF;

        ELSE
          DBG('Alpha-Numeric mask maintained for the branch');
          IF LENGTH(L_FIRST_CHQNO) <> LENGTH(G_CHQ_MASK) THEN
            DBG('Length of the input check number is not same as the length of the mask maintained for this branch ');

            P_ERR_CODE   := 'CA-CHQ-003';
            P_ERR_PARAMS := '';
            DBG(P_ERR_CODE);
            DBG(P_ERR_PARAMS);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            RETURN FALSE;
          END IF;
          L_ALPHA_NEXT := RTRIM(TRANSLATE(L_FIRST_CHQNO,
                                          '0123456789',
                                          '         '));
          DBG('Alpha part of the check no is ' || L_ALPHA_NEXT);

          L_ALPHA_LEN := NVL(LENGTH(L_ALPHA_NEXT), 0);
          DBG('Length of the alpha part of the input chq num ' ||
              L_ALPHA_LEN);

          L_ALPHA_MASK := LENGTH(SUBSTR(G_CHQ_MASK,
                                        1,
                                        (INSTR(UPPER(G_CHQ_MASK), 'N') - 1)));
          DBG('Length of alpha part of the mask ' || L_ALPHA_MASK);

          L_NUMA_LEN := LENGTH(SUBSTR(G_CHQ_MASK, L_ALPHA_MASK + 1));

          L_NUM := SUBSTR(L_FIRST_CHQNO, L_ALPHA_LEN + 1);
          DBG('Numeric part of the check no is ' || L_NUM);

          L_MAX_NUM := TRANSLATE(L_NUM, '0123456789', '9999999999');
          DBG('Max number allowed for the series ' || L_MAX_NUM);

          IF (L_ALPHA_LEN <> L_ALPHA_MASK) OR (LENGTH(L_NUM) <> L_NUMA_LEN) THEN
            DBG('Input check number format is different from the mask format ');
            P_ERR_CODE   := 'CA-CHQ-005';
            P_ERR_PARAMS := '';
            DBG(P_ERR_CODE);
            DBG(P_ERR_PARAMS);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            RETURN FALSE;
          END IF;
          IF L_NUM + P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES >
             L_MAX_NUM THEN
            DBG('Insufficient cheques for the input series ');
            P_ERR_CODE   := 'CA-CHQ-006';
            P_ERR_PARAMS := '';
            DBG(P_ERR_CODE);
            DBG(P_ERR_PARAMS);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);

            RETURN FALSE;
          END IF;
          IF G_PRM_UNIQUE_CHEQUE = 'Y' THEN
            BEGIN
              SELECT COUNT(*)
                INTO L_CNT
                FROM CATM_CHECK_DETAILS
               WHERE

               BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND NVL(ACCOUNT, '*') = NVL(NVL(L_ACCOUNT, ACCOUNT), '*')
               AND CHECK_NO BETWEEN UPPER(L_FIRST_CHQNO) AND
               UPPER(L_ALPHA_NEXT) || LPAD((TO_NUMBER(L_NUM) +
                                           P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES - 1),
                                           L_NUMA_LEN,
                                           '0');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Problem in selecting the chq count');
                P_ERR_CODE   := 'CA-CHQ-007';
                P_ERR_PARAMS := '';

                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             P_ERR_CODE,
                             P_ERR_PARAMS);

            END;
          ELSE
            BEGIN
              SELECT COUNT(*)
                INTO L_CNT
                FROM CATM_CHECK_DETAILS
               WHERE NVL(ACCOUNT, '*') = NVL(NVL(L_ACCOUNT, ACCOUNT), '*')
                 AND BRANCH =
                     P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                 AND CHECK_NO BETWEEN UPPER(L_FIRST_CHQNO) AND
                     UPPER(L_ALPHA_NEXT) ||
                     LPAD((TO_NUMBER(L_NUM) +
                          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.CHECK_LEAVES - 1),
                          L_NUMA_LEN,
                          '0');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Problem in selecting the chq count');
                P_ERR_CODE   := 'CA-CHQ-007';
                P_ERR_PARAMS := '';

                PR_LOG_ERROR(P_FUNCTION_ID,
                             P_SOURCE,
                             P_ERR_CODE,
                             P_ERR_PARAMS);

            END;
          END IF;

          IF L_CNT > 0 THEN
            DBG(' cheque no already issued.. Requested series cannot be provided');
            RETURN FALSE;
          END IF;

        END IF;
      END IF;

      IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW

         ) THEN
        DBG('inside 222--->');

        IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO IS NULL THEN

          DBG('Do you want the system to generate the cheque number automatically?');
          P_ERR_CODE   := 'CA-CHQ-002';
          P_ERR_PARAMS := '';
          DBG(P_ERR_CODE);
          DBG(P_ERR_PARAMS);
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        END IF;

        P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

        IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH IS NULL OR
           P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT IS NULL

         THEN
          P_ERR_CODE   := 'ST-CHQ-01';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

        BEGIN
          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.REQUEST_STATUS := 'Requested';
          INSERT INTO STVWS_CHQBK_REQUEST
          VALUES P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST;
          DBG('rows inserted FOR CHQBK is  ' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('the error is here ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            DBG('The error is ' || SQLERRM);
            RETURN FALSE;
        END;

      ELSE

        IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY) THEN
          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

          IF P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH IS NULL OR
             P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT IS NULL

           THEN
            P_ERR_CODE   := 'ST-CHQ-01';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          BEGIN
            DELETE FROM STVWS_CHQBK_REQUEST
             WHERE ACCOUNT = P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.ACCOUNT
               AND BRANCH = P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.BRANCH;

            P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.REQUEST_STATUS := 'Requested';
            INSERT INTO STVWS_CHQBK_REQUEST
            VALUES P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST;
            DBG('rows inserted for card is  ' || SQL%ROWCOUNT);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('the error is here ' ||
                  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              DBG('The error is ' || SQLERRM);
              RETURN FALSE;
          END;
        END IF;

        IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH

           ) THEN

          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT
              FROM STTMS_CHQBK_REQUEST
             WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            DBG('l_count ' || L_COUNT);
          END;
          BEGIN
            SELECT *
              INTO L_CHQBK_REQUEST
              FROM STTMS_CHQBK_REQUEST
             WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('IN WOT of sttms_chqbk_request' || SQLERRM);
          END;
          P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST := L_CHQBK_REQUEST;
          IF L_COUNT > 0 THEN
            BEGIN
              L_TY_REC_CHQBOOK_UPLD.V_CATMS_CHECK_BOOK.BRANCH         := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              L_TY_REC_CHQBOOK_UPLD.V_CATMS_CHECK_BOOK.ACCOUNT        := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              L_TY_REC_CHQBOOK_UPLD.V_CATMS_CHECK_BOOK.FIRST_CHECK_NO := P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST.FIRST_CHECK_NO;
              DBG('Calling stpks_stdcusac_utils_0.fn_chqbook_upld');
              IF NOT STPKS_STDCUSAC_UTILS_0.FN_CHQBOOK_UPLD(P_WRK_STDCUSAC,
                                                            P_SOURCE_OPERATION,
                                                            P_ACTION_CODE,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
                DBG(' failed in stpks_stdcusac_utils_0.fn_chkbk_upld' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;
            END;
          END IF;
        END IF;

      END IF;
    END IF;
    IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST, 'N') = 'Y' AND
       (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N') THEN

      IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW

         ) THEN

        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_AC_NO  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_NO     := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        IF P_SOURCE <> 'FLEXCUBE' THEN
          IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO IS NULL THEN

            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT := NVL(P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT,
                                                                  P_PREV_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT);
            IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT IS NULL THEN
              DBG('Card Product cannot be null');
              P_ERR_CODE   := 'ST-CRDM07';
              P_ERR_PARAMS := NULL;
              PR_LOG_ERROR(P_FUNCTION_ID,
                           'FLEXCUBE',
                           P_ERR_CODE,
                           P_ERR_PARAMS);
              RETURN FALSE;
            END IF;
            DBG('INSIDE IF---');

            IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                               P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT,
                                               GLOBAL.APPLICATION_DATE,
                                               PSERIAL,
                                               PREFERENCENO,
                                               P_ERR_CODE) THEN
              DBG('Failed in generating internal reference number with error code ' ||
                  P_ERR_CODE);
              ROLLBACK;
              RETURN FALSE;
            END IF;
            DBG('Came out of this');
            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO := PREFERENCENO;
            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE       := GLOBAL.APPLICATION_DATE;
          END IF;
        END IF;

        IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.BRANCH_CODE IS NULL OR
           P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_AC_NO IS NULL OR
           P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_NO IS NULL OR
           P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO IS NULL THEN
          P_ERR_CODE   := 'ST-CRD-01';
          P_ERR_PARAMS := '';
          PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
          RETURN FALSE;
        END IF;

        BEGIN
          P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_STATUS  := 'R';
          P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.PRIMARY_CARD := 'Y';
          INSERT INTO STVWS_DC_REQUEST
          VALUES P_WRK_STDCUSAC.V_STVWS_DC_REQUEST;
          DBG('rows inserted for card is  ' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('the error is here ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            DBG('The error is ' || SQLERRM);
            RETURN FALSE;
        END;

      ELSE
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.BRANCH_CODE := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_AC_NO  := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_NO     := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

        IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY) THEN

          IF P_SOURCE <> 'FLEXCUBE' THEN
            IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO IS NULL THEN
              IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT IS NULL THEN
                DBG('Card Product cannot be null');
                P_ERR_CODE   := 'ST-CRDM07';
                P_ERR_PARAMS := NULL;
                PR_LOG_ERROR(P_FUNCTION_ID,
                             'FLEXCUBE',
                             P_ERR_CODE,
                             P_ERR_PARAMS);
                RETURN FALSE;
              END IF;
              DBG('INSIDE IF---');

              IF NOT TRPKSS.FN_GET_PRODUCT_REFNO(GLOBAL.CURRENT_BRANCH,
                                                 P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_PRODUCT,
                                                 GLOBAL.APPLICATION_DATE,
                                                 PSERIAL,
                                                 PREFERENCENO,
                                                 P_ERR_CODE) THEN
                DBG('Failed in generating internal reference number with error code ' ||
                    P_ERR_CODE);
                ROLLBACK;
                RETURN FALSE;
              END IF;
              DBG('Came out of this');
              P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO := PREFERENCENO;
              P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_APPL_DATE       := GLOBAL.APPLICATION_DATE;
            END IF;
          END IF;

          IF P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.BRANCH_CODE IS NULL OR
             P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_AC_NO IS NULL OR
             P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_NO IS NULL OR
             P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO IS NULL THEN
            P_ERR_CODE   := 'ST-CRD-01';
            P_ERR_PARAMS := '';
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
            RETURN FALSE;
          END IF;

          BEGIN
            DELETE FROM STVWS_DC_REQUEST
             WHERE CUST_AC_NO =
                   P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CUST_AC_NO
               AND BRANCH_CODE =
                   P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.BRANCH_CODE
               AND REQUEST_REFERENCE_NO =
                   P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO;
            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.CARD_STATUS  := 'R';
            P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.PRIMARY_CARD := 'Y';
            INSERT INTO STVWS_DC_REQUEST
            VALUES P_WRK_STDCUSAC.V_STVWS_DC_REQUEST;
            DBG('rows inserted for card is  ' || SQL%ROWCOUNT);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('the error is here ' ||
                  DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
              DBG('The error is ' || SQLERRM);
              RETURN FALSE;
          END;
        END IF;

        IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_AUTH

           ) THEN

          BEGIN
            SELECT COUNT(*)
              INTO L_COUNT2
              FROM STTMS_DC_REQUEST
             WHERE BRANCH_CODE =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND CUST_AC_NO =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
            DBG('l_count 2' || L_COUNT2);
          END;
          BEGIN
            SELECT *
              INTO L_DC_REQUEST
              FROM STTMS_DC_REQUEST
             WHERE BRANCH_CODE =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND CUST_AC_NO =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('IN WOT of sttms_chqbk_request' || SQLERRM);
          END;
          P_WRK_STDCUSAC.V_STVWS_DC_REQUEST := L_DC_REQUEST;
          IF L_COUNT2 > 0 THEN

            IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO IS NULL THEN
              BEGIN
                SELECT CUST_NO
                  INTO P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
                  FROM STTM_CUST_ACCOUNT
                 WHERE BRANCH_CODE =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                   AND CUST_AC_NO =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO := '';
              END;

            END IF;
            BEGIN
              L_TY_REC_CARD_UPLD.V_STTMS_DEBIT_CARD_MASTER.BRANCH_CODE          := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
              L_TY_REC_CARD_UPLD.V_STTMS_DEBIT_CARD_MASTER.CUST_AC_NO           := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
              L_TY_REC_CARD_UPLD.V_STTMS_DEBIT_CARD_MASTER.REQUEST_REFERENCE_NO := P_WRK_STDCUSAC.V_STVWS_DC_REQUEST.REQUEST_REFERENCE_NO;
              L_TY_REC_CARD_UPLD.V_STTMS_DEBIT_CARD_MASTER.CUST_NO              := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
              DBG('Calling stpks_stdcusac_utils_0.fn_card_upld');
              IF NOT STPKS_STDCUSAC_UTILS_0.FN_CARD_UPLD(P_WRK_STDCUSAC,
                                                         P_SOURCE_OPERATION,
                                                         P_ACTION_CODE,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
                DBG(' failed in stpks_stdcusac_utils_0.fn_card_upld' ||
                    SQLERRM);
                RETURN FALSE;
              END IF;
            END;
          END IF;

        END IF;

      END IF;
    END IF;

    DBG('#28146388 p_Action_Code ' || P_ACTION_CODE);
    IF (P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_NEW) THEN
      DBG('#28146388 ' || P_SOURCE);
      DBG('#28146388 p_Wrk_Stdcusac.v_Sttms_Cust_Account.AC_STAT_DORMANT ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DORMANT);
      DBG('#28146388 p_Wrk_Stdcusac.v_Sttms_Cust_Account.dormancy_date ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE);
      IF P_SOURCE <> 'FLEXCUBE' AND
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_STAT_DORMANT, 'N') = 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE IS NOT NULL AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE <=
         GLOBAL.APPLICATION_DATE THEN
        DBG('#28146388 insdie if');
        BEGIN
          INSERT INTO STTM_CUST_ACCOUNT_DORMANCY
            (BRANCH_CODE,
             CUST_AC_NO,
             DORMANCY_START_DT,
             DORMANCY_END_DT,
             REF_NO)
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DORMANCY_DATE,
             NULL,
             NULL);
          DBG('#28146388 rows inserted for card is  ' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('#28146388 the error is here ' ||
                DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
            DBG('The error is ' || SQLERRM);
        END;
      END IF;

      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT > 0 THEN
        BEGIN
          SELECT TURNOVER_EVENT_CLASS_CODE
            INTO L_EVENT_CLASS_CODE
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
          DBG('L_EVENT_CLASS_CODE-->' || L_EVENT_CLASS_CODE);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('in no data for event class');
            L_EVENT_CLASS_CODE := '';
        END;
      END IF;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT IS NOT NULL THEN
        DBG('p_wrk_stdcusac.ACCOUNT_CLASS-->' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
        IF L_EVENT_CLASS_CODE IS NULL THEN
          DBG('Event class code is null.');
          L_ERR_CODE  := 'ST-ACST08';
          L_ERR_PARAM := NULL;
          PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', L_ERR_CODE, L_ERR_PARAM);
          RETURN FALSE;
        END IF;
      END IF;

    END IF;

    DBG('Calling stpks_stdcusac_utils_2');

    IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH,
           P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH) <> 'Y' AND
       NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE,
           P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE) <> 'Y'

       AND P_ACTION_CODE = 'AUTH' THEN

      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE        := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                                     P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH   := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH,
                                                                     P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_BRANCH);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION   := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION,
                                                                     P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_PAY_IN_OPTION);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT  := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT,
                                                                     P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_OFFSET_ACCOUNT);
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT := NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT,
                                                                     P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.INF_ACC_OPENING_AMT);

      DBG('Calling stpks_stdcusac_utils_2. Fn_Custacc_Entries');
      IF NOT
          STPKS_STDCUSAC_UTILS_2.FN_CUSTACC_ENTRIES(P_FUNCTION_ID,
                                                    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT) THEN
        DBG('Failed in stpks_stdcusac_utils_2. Fn_Custacc_Entries');
        RETURN FALSE;
      END IF;

      IF CSPKS_FEATURE.FN_INSTALLED('ACCOPENADV',
                                    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) THEN
        DBG('Calling stpks_stdcusac_utils_2. Fn_Custadvice_Entires');
        IF NOT
            STPKS_STDCUSAC_UTILS_2.FN_CUSTADVICE_ENTIRES(P_FUNCTION_ID,
                                                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT) THEN
          DBG('Failed in fn_custadvice_entires');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'CLOSE' THEN

      BEGIN
        SELECT RECORD_STAT
          INTO REC_STAT
          FROM STTMS_CUST_ACCOUNT
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          DBG(SQLERRM);
          DBG('Failed in selection');
      END;
      IF NVL(REC_STAT, 'X') = 'C' THEN
        UPDATE SFTM_CUST_SUBSCRIPTION
           SET SUB_STATUS = 'C'
         WHERE TD_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND TD_BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
      END IF;
    END IF;

    IF P_ACTION_CODE = CSPKS_SERVICE.P_AUTH THEN
      DBG('>>> replication dbg::: ');
      DBG('>>>p_action_code: ' || P_ACTION_CODE);
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO IS NOT NULL THEN
        BEGIN
          SELECT *
            INTO L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT
            FROM STTM_CUST_ACCOUNT
           WHERE BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

          DBG('branch_code: ' ||
              L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
          DBG('cust_ac_no: ' ||
              L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('in whn othrs...during qry for rec bf4 replication in addon: ' ||
                SQLERRM);
            PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-REPL-10', NULL);
            RETURN FALSE;
        END;
      END IF;
      DBG('>>> auth_stat:: ' ||
          L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT);

      IF L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTH_STAT = 'A' THEN
        STPKS_REPLICATION_CONTROL.G_STDCUSAC := L_WRK_STDCUSAC;
        DBG('before calling stpkss_replication_control.Fn_Handle_Request...........');

        IF NOT STPKSS_REPLICATION_CONTROL.FN_HANDLE_REQUEST('STDCUSAC',
                                                            L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.RECORD_STAT,
                                                            L_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('failed in stpkss_replication_control.Fn_Handle_Request: ' ||
              P_ERR_CODE);
          PR_LOG_ERROR(P_FUNCTION_ID,
                       P_SOURCE,
                       NVL(P_ERR_CODE, 'ST-REPL-10'),
                       NULL);
          STPKS_REPLICATION_CONTROL.G_STDCUSAC := NULL;
          RETURN FALSE;
        END IF;
        STPKS_REPLICATION_CONTROL.G_STDCUSAC := NULL;
        DBG('return from stpkss_replication_control.Fn_Handle_Request');
      END IF;
    END IF;

    DBG('p_wrk_stdcusac.v_sttms_cust_account.cust_ac_no~' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('p_action_code~' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_SERVICE.P_NEW,
                         'NEW',
                         CSPKS_SERVICE.P_DELETE,
                         'DELETE',
                         'VERSIONDELETE',
                         CSPKS_SERVICE.P_AUTH,
                         'AUTH') THEN
      IF NOT STPKS_ACCGEN.FN_UPDATE_UNUSEDCUSTACNO('',
                                                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                   P_ACTION_CODE,
                                                   P_ERR_CODE,
                                                   P_ERR_PARAMS) THEN
        DBG('FAILED IN fn_update_unusedcustacno');
      END IF;
    END IF;

    IF P_POST_UPL_STAT IN ('A', 'U') THEN
      DBG('Success Case...');
      IF P_ACTION_CODE IN ('BUILD_SUBSTAT') THEN
        DBG('Calling  Fn_Sys_Query_Desc_Fields..');
        IF NOT STPKS_STDCUSAC_MAIN.FN_SYS_QUERY_DESC_FIELDS(P_SOURCE,
                                                            P_SOURCE_OPERATION,
                                                            P_FUNCTION_ID,
                                                            P_ACTION_CODE,
                                                            P_WRK_STDCUSAC,
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
          DBG('Failed in Fn_Sys_Query_Desc_Fields..');
          RETURN FALSE;
        END IF;
      END IF;
    END IF;

    DBG('Linkages COunt kernel3:' ||
        P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_stdcusac kernel3:' ||
        P_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);
    DBG('Linkages COunt p_Prev_stdcusac kernel3:' ||
        P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT);

    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.LIMIT_CCY IS NULL THEN
      P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT := NULL;
    END IF;

    DBG('p_Wrk_Stdcusac.v_Sttms_Cust_Account.Account_Class' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    DBG('p_Stdcusac.v_Sttms_Cust_Account.Account_Class' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
    SELECT AC_CLASS_TYPE
      INTO L_AC_CLASS_TYPE
      FROM STTM_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS =
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
    DBG('p_Function_Id' || P_FUNCTION_ID);

    DBG('p_Function_Id' || P_FUNCTION_ID);

    IF P_ACTION_CODE = CSPKS_SERVICE.P_AUTH AND P_FUNCTION_ID <> 'STDCUSTD' AND
       L_AC_CLASS_TYPE IN ('U', 'S') THEN
      BEGIN

        P_CUST_NO         := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
        P_BRANCH_CODE     := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        P_CUST_AC_NO      := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        P_ACCOUNT_CLASS   := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        P_CONTRACT_REF_NO := NULL;
        P_MODULE_CODE     := 'CO';
        P_APP_DATE        := GLOBAL.APPLICATION_DATE;
        P_PROD_CODE       := NULL;
        P_EVENT_CODE      := 'CONEW';
        STPKS_RM_REPORTS.PR_LOG_RM_TRANSACTIONS(P_CUST_NO,
                                                P_BRANCH_CODE,
                                                P_CONTRACT_REF_NO,
                                                P_ACCOUNT_CLASS,
                                                P_CUST_AC_NO,
                                                P_MODULE_CODE,
                                                P_APP_DATE,
                                                P_PROD_CODE,
                                                P_EVENT_CODE,
                                                L_ERR_PARAM,
                                                L_ERR_CODE);
        DBG('l_err_code' || L_ERR_CODE);
        DBG('l_err_code' || L_ERR_CODE);
      END;
    END IF;

    DBG('p_Action_Code' || P_ACTION_CODE);
    IF P_ACTION_CODE IN (CSPKS_SERVICE.P_AUTH) THEN
      L_WRK_STDCUSAC := P_WRK_STDCUSAC;
      IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID <> GLOBAL.USER_ID THEN
        L_WRK_STDCUSAC := P_PREV_STDCUSAC;
      END IF;
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_ADD_JOINT_ACC(P_SOURCE,
                                                     P_FUNCTION_ID,
                                                     L_WRK_STDCUSAC,
                                                     P_ERR_CODE,
                                                     P_ERR_PARAMS) THEN
        DBG('Error in adding Joint holder details');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'ST-JHM-013', ' ');
      END IF;
    END IF;

    BEGIN

      IF (P_FUNCTION_ID = 'STDCUSAC' OR G_CHILD_FUNCTION) AND
         P_ACTION_CODE = 'MODIFY' THEN
        L_WRK_COUNT  := P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;
        L_PREV_COUNT := P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT;
        IF L_PREV_COUNT > 0 THEN
          FOR L_INDEX1 IN 1 .. L_PREV_COUNT LOOP
            L_REC_FOUND := FALSE;
            IF L_WRK_COUNT > 0 THEN
              FOR L_INDEX IN 1 .. L_WRK_COUNT LOOP
                DBG('p_Wrk_stdcusac.v_cust_account_linkages(l_index).linked_ref_no' || P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                    .LINKED_REF_NO);
                DBG('p_Prev_stdcusac.v_cust_account_linkages  (l_index1).linked_ref_no' || P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                    .LINKED_REF_NO);
                IF (NVL(P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX)
                        .LINKED_REF_NO,
                        '@') = NVL(P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                    .LINKED_REF_NO,
                                    '@')) THEN
                  DBG('Record Has Been Found');
                  L_REC_FOUND := TRUE;
                  EXIT;
                END IF;
              END LOOP;
            END IF;

            IF NOT L_REC_FOUND AND P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
              .EFFECTIVE_DATE <> GLOBAL.APPLICATION_DATE THEN

              DBG('coming into insert');

              BEGIN
                INSERT INTO STTM_CUST_ACC_LNK_HIST
                  (BRANCH_CODE,
                   CUST_AC_NO,
                   CUSTOMER_NO,
                   LINKAGE_TYPE,
                   LINKED_REF_NO,
                   LINKAGE_PERCENTAGE,
                   LINKAGE_SEQ_NO,
                   LINKAGE_BRANCH,
                   LINKED_CCY,
                   EFFECTIVE_DATE,
                   DELINK_DATE)
                VALUES
                  (P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .BRANCH_CODE,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .CUST_AC_NO,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .CUSTOMER_NO,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .LINKAGE_TYPE,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .LINKED_REF_NO,

                   NVL(P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                       .LINKAGE_PERCENTAGE,
                       0),
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .LINKAGE_SEQ_NO,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .LINKAGE_BRANCH,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .LINKED_CCY,
                   P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                   .EFFECTIVE_DATE,

                   GLOBAL.APPLICATION_DATE - 1);
                DBG('Record is Deleted...');
              EXCEPTION
                WHEN DUP_VAL_ON_INDEX THEN
                  UPDATE STTM_CUST_ACC_LNK_HIST

                     SET DELINK_DATE    = GLOBAL.APPLICATION_DATE - 1,
                         EFFECTIVE_DATE = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                          .EFFECTIVE_DATE,
                         LINKAGE_SEQ_NO = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                          .LINKAGE_SEQ_NO,
                         LINKED_CCY     = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                          .LINKED_CCY,
                         LINKAGE_BRANCH = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                          .LINKAGE_BRANCH,

                         LINKAGE_PERCENTAGE = NVL(P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                                                  .LINKAGE_PERCENTAGE,
                                                  0)
                   WHERE BRANCH_CODE =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND CUST_AC_NO =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                     AND CUSTOMER_NO = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                        .CUSTOMER_NO
                     AND LINKAGE_TYPE = 'F'
                     AND LINKED_REF_NO = P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(L_INDEX1)
                        .LINKED_REF_NO;
              END;

            END IF;
          END LOOP;
        END IF;
      END IF;
    END;

    IF (P_FUNCTION_ID = 'STDCUSAC' OR G_CHILD_FUNCTION) AND
       P_ACTION_CODE IN ('MODIFY') THEN
      IF P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
          IF P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 THEN
            FOR J IN 1 .. P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT LOOP
              IF P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J).LINKAGE_TYPE = 'F' AND P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .LINKED_REF_NO = P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                 .LINKED_REF_NO THEN
                IF P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                 .EFFECTIVE_DATE <> P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                   .EFFECTIVE_DATE AND
                    (P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                     .EFFECTIVE_DATE < GLOBAL.APPLICATION_DATE OR P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(I)
                     .EFFECTIVE_DATE < GLOBAL.APPLICATION_DATE) THEN
                  IF L_MIN_EFF_DATE IS NULL THEN
                    L_MIN_EFF_DATE := LEAST(P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                                            .EFFECTIVE_DATE,
                                            P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES (I)
                                            .EFFECTIVE_DATE);
                  ELSE
                    L_MIN_EFF_DATE := LEAST(L_MIN_EFF_DATE,
                                            P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES(J)
                                            .EFFECTIVE_DATE,
                                            P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES (I)
                                            .EFFECTIVE_DATE);
                  END IF;
                END IF;
              END IF;
            END LOOP;
          END IF;
        END LOOP;
        IF L_MIN_EFF_DATE IS NOT NULL THEN
          IF L_MIN_EFF_DATE < GLOBAL.APPLICATION_DATE THEN
            UPDATE ICTBS_ACC_PR
               SET BKVAL_MINCALC_DATE = LEAST(NVL(BKVAL_MINCALC_DATE,
                                                  L_MIN_EFF_DATE),
                                              L_MIN_EFF_DATE),
                   BKVAL_RECALC_FLAG  = 'Y'
             WHERE BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
               AND ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
               AND PROD IN (SELECT PRODUCT_CODE
                              FROM ICTM_PR_INT
                             WHERE BACK_CALC_FLAG = 'Y');
          END IF;
        END IF;
      END IF;
    END IF;

    DBG('Source is ::' || P_SOURCE);
    DBG('Account No::' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    DBG('Branch Code::' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
    DBG('MULTI_CURRENCY_ACCOUNT NUMBER AT UPLOAD::' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    DBG('MULTI_CURRENCY_ACCOUNT NUMBER AT UPLOAD::' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    IF P_SOURCE <> 'FLEXCUBE' THEN
      DBG('Coming here only for source ::' || P_SOURCE);
      IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
        DBG('Since detail table is having data,so checking the master table for signature');
        SELECT COUNT(*)
          INTO L_SIG_COUNT
          FROM SVTM_ACC_SIG_MASTER A
         WHERE A.BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND A.ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        IF L_SIG_COUNT = 0 THEN
          DBG('INSERTING INTO SVTM_ACC_SIG_MASTER ');
          INSERT INTO SVTM_ACC_SIG_MASTER
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             NULL,

             NULL);

        ELSE
          DBG('SVTM_ACC_SIG_MASTER already has entry no need to insert');
        END IF;
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      DBG('Going to call fn_UpdateLimitUtil for modify');
      IF ((P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT = 0 AND
         P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0) OR
         (P_PREV_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT > 0 AND
         P_WRK_STDCUSAC.V_CUST_ACCOUNT_LINKAGES.COUNT = 0)) THEN
        IF NOT STPKS_STDCUSAC_UTILS_2.FN_UPDATELIMITUTIL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                         'N',
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
          DBG('Failed in  fn_UpdateLimitUtil ... : ' || P_ERR_CODE ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;

      DBG('TOD utilization' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT ||
          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT);
      DBG('Daylight' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT ||
          P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT);
      IF (NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT, 0) <>
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.DAYLIGHT_LIMIT_AMOUNT, 0)) OR
         (NVL(P_PREV_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0) <>
         NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.TOD_LIMIT, 0)) THEN
        DBG('Calling stpks_stdcusac_utils_2.fn_UpdateLimitUtil');
        IF NOT STPKS_STDCUSAC_UTILS_2.FN_UPDATELIMITUTIL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                                                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                         'N',
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
          DBG('Failed in  fn_UpdateLimitUtil ... : ' || P_ERR_CODE ||
              SQLERRM);
          OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        END IF;
      END IF;

    END IF;

    SELECT MULTI_CURRENCY
      INTO L_MULTI_FLAG
      FROM STTM_ACCOUNT_CLASS
     WHERE ACCOUNT_CLASS =
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

    IF P_ACTION_CODE IN ('NEW') THEN
      IF L_MULTI_FLAG = 'Y' THEN

        BEGIN
          SELECT COUNT(*)
            INTO L_COUNT_1
            FROM STTM_MULTI_CCY_ACCNT_MASTER
           WHERE MULTI_CCY_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO;

        END;
        DBG('L_COUNT_1' || L_COUNT_1);

        DBG('sub_Accounts' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO || '&' ||
            P_MAIN_AC_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);

        IF (L_COUNT_1 <> 0) THEN
          INSERT INTO STTM_MULTI_CCY_ACCNT_DTL
            (MULTI_CCY_AC_NO, SUB_AC_NO, CCY)
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
          UPDATE STTM_MULTI_CCY_ACCNT_MASTER
             SET AUTH_STAT        = 'U',
                 MAKER_ID         = GLOBAL.USER_ID,
                 MAKER_DT_STAMP   = GLOBAL.APPLICATION_DATE,
                 CHECKER_ID       = '',
                 CHECKER_DT_STAMP = ''
           WHERE MULTI_CCY_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO;
        END IF;

        DBG('main account' || P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS || '&' ||
            P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);

        IF (L_COUNT_1 = 0) THEN
          IF NOT
              SMPKS.FN_CHECK_AUTO_AUTH(L_USER_ID, P_FUNCTION_ID, L_BRANCH1) THEN
            L_AUTH_STAT1 := 'U';
          END IF;

          INSERT INTO STTM_MULTI_CCY_ACCNT_MASTER
            (CUSTOMER_NO,
             BRANCH_CODE,
             MULTI_CCY_AC_NO,
             MAIN_AC_NO,
             ACCOUNT_CLASS,
             CCY,
             AUTH_STAT,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_DT_STAMP,
             CHECKER_ID)
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
             L_AUTH_STAT1,
             GLOBAL.USER_ID,
             CSFN_TIMESTAMP,
             '',
             ''

             );
          INSERT INTO STTM_MULTI_CCY_ACCNT_DTL
            (MULTI_CCY_AC_NO, SUB_AC_NO, CCY)
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY);
          DBG('l_auth_stat1' || L_AUTH_STAT1);
          IF L_AUTH_STAT1 = 'A' THEN
            UPDATE STTM_MULTI_CCY_ACCNT_MASTER
               SET CHECKER_DT_STAMP = CSFN_TIMESTAMP,
                   CHECKER_ID       = GLOBAL.USER_ID
             WHERE MULTI_CCY_AC_NO =
                   P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO;
          END IF;
        END IF;

      END IF;
    END IF;
    IF P_ACTION_CODE = 'AUTH' THEN
      IF L_MULTI_FLAG = 'Y' THEN

        UPDATE STTM_MULTI_CCY_ACCNT_MASTER
           SET AUTH_STAT        = 'A',
               CHECKER_ID       = GLOBAL.USER_ID,
               CHECKER_DT_STAMP = GLOBAL.APPLICATION_DATE
         WHERE MULTI_CCY_AC_NO =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO;

      END IF;
    END IF;

    IF P_ACTION_CODE IN ('NEW') THEN
      IF G_MULTI_CURRENCY = TRUE THEN
        CSPKS_REQ_UTILS.PR_FILTER_ERR_TYPE('O');
      END IF;
    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_AUTH) THEN
      FOR EACH_REC IN (SELECT *
                         FROM ICTMS_ACC_PR A
                        WHERE A.ACC =
                              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                          AND A.BRN =
                              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                          AND A.RECORD_STAT = 'O'
                          AND A.PROD IN
                              (SELECT B.PRODUCT_CODE
                                 FROM ICTMS_PR_INT B
                                WHERE B.PRODUCT_CODE = A.PROD
                                  AND B.IL_PRODUCT = 'Y')) LOOP

        SELECT MIN(UDE_EFF_DT)
          INTO L_EFF_DT
          FROM ICTMS_ACC_EFFDT
         WHERE ACC = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRN = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND PROD = EACH_REC.PROD
           AND RECORD_STAT = 'O';
        DBG('l_eff_dt-->' || L_EFF_DT);
        DBG('prod-->' || EACH_REC.PROD);

        BEGIN
          UPDATE ICTBS_ACC_PR
             SET SC_MAP_DT = L_EFF_DT
           WHERE (BRN, ACC) IN
                 (SELECT SYSTEM_ACCOUNT_BRANCH, SYSTEM_ACCOUNT
                    FROM ILTB_SYS_ACCOUNT
                   WHERE BRANCH_CODE =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
                     AND ACCOUNT =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO)
             AND PROD = EACH_REC.PROD
             AND SC_MAP_DT IS NULL;
          DBG('rows updated-->' || SQL%ROWCOUNT);
        EXCEPTION
          WHEN OTHERS THEN
            DBG('IN WO EXCEPTION');
        END;
      END LOOP;
    END IF;

    DBG('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Post_Upload_Db ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_UPLOAD_DB;

  FUNCTION FN_PRE_QUERY(P_SOURCE           IN VARCHAR2,
                        P_SOURCE_OPERATION IN VARCHAR2,
                        P_FUNCTION_ID      IN VARCHAR2,
                        P_ACTION_CODE      IN VARCHAR2,
                        P_CHILD_FUNCTION   IN VARCHAR2,
                        P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                        P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                        P_QRYDATA_REQD     IN VARCHAR2,
                        P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                        P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                        P_ERR_CODE         IN OUT VARCHAR2,
                        P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

  BEGIN

    DBG('In Fn_Pre_Query..');
    DBG('#24821961 p_Source --> ' || P_SOURCE);
    G_SOURCE := P_SOURCE;
    DBG('#24821961 g_source --> ' || G_SOURCE);

    IF P_ACTION_CODE IN ('QRYAMTDT') THEN
      STPKS_STDCUSAC_MAIN.PR_SET_SKIP_SYS;
    END IF;

    DBG('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When Others of stpks_stdcusac_Kernel.Fn_Pre_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_PRE_QUERY;

  FUNCTION FN_POST_QUERY(P_SOURCE           IN VARCHAR2,
                         P_SOURCE_OPERATION IN VARCHAR2,
                         P_FUNCTION_ID      IN VARCHAR2,
                         P_ACTION_CODE      IN VARCHAR2,
                         P_CHILD_FUNCTION   IN VARCHAR2,
                         P_FULL_DATA        IN VARCHAR2 DEFAULT 'Y',
                         P_WITH_LOCK        IN VARCHAR2 DEFAULT 'N',
                         P_QRYDATA_REQD     IN VARCHAR2,
                         P_STDCUSAC         IN STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_WRK_STDCUSAC     IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_ERR_CODE         IN OUT VARCHAR2,
                         P_ERR_PARAMS       IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_CCY              VARCHAR2(3);
    L_PROD             ICTMS_PR_INT_ACLASS.PRODUCT_CODE%TYPE;
    L_ILPRODTYP        VARCHAR2(100);
    L_PRDDSC           CSTMS_PRODUCT.PRODUCT_DESCRIPTION%TYPE;
    L_ILPROD           ICTMS_PR_INT.IL_PRODUCT%TYPE;
    L_BRNST            STTMS_BRANCH.END_OF_INPUT%TYPE;
    L_ICCNT            PLS_INTEGER;
    L_PRIVATE_CUSTOMER VARCHAR2(1);
    L_COUNT1           NUMBER := 0;
    L_COUNT2           NUMBER := 0;

    L_STOCK_CATLOG_CD ICTMS_TD_DETAILS.STOCK_CATLOG_CD%TYPE;
    L_CERT_NO         ICTMS_TD_DETAILS.CERTIFICATE_NO%TYPE;
    L_DUPLICATE_ISSUE ICTMS_TD_DETAILS.DUPLICATE_ISSUE%TYPE;

    L_JHCOD      STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;
    L_TEMP_JHCIF VARCHAR2(1000) := '';
    L_TEMP_JHREL VARCHAR2(1000) := '';
    L_COUNTCIF   NUMBER := 0;

    L_MATURITY_DATE   DATE;
    L_RECOMPUTE_MATDT VARCHAR2(1);
    L_INT_RATE        NUMBER;
    L_TB_UDE_DATES    DBMS_SQL.DATE_TABLE;
    L_MAT_AMOUNT      NUMBER;

    L_HOLIDAY_CALENDAR STTMS_ACCOUNT_CLASS.HOLIDAY_CALENDAR%TYPE;
    L_HOLIDAY_MOVEMENT STTMS_ACCOUNT_CLASS.HOLIDAY_MOVEMENT%TYPE;

    L_PAYIN_TOTAL      ICTB_ENTRIES_HISTORY.AMT%TYPE := 0;
    L_MATURITY_DATE_BK DATE;
    L_ORIG_MAT_DT_BK   DATE;
    L_ORIG_MAT_DT      DATE;

    L_CURR_STAGE VARCHAR2(20);

    L_IS_FORGOTTEN CHAR(1);

    CURSOR C_V_STVW_STTMS_ACCOUNT_NOMS IS
      SELECT *
        FROM STVW_STTM_ACCOUNT_NOMINEES
       WHERE BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    CURSOR C_V_STVW_STTMS_CUST_ACCOUNT IS
      SELECT *
        FROM STVW_STTM_CUST_ACCOUNT
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    CURSOR C_V_STVW_STTM_AC_LNKD_ENTITIES IS
      SELECT *
        FROM STVW_STTM_AC_LINKED_ENTITIES
       WHERE BRANCH_CODE = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CUST_AC_NO = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    L_MASK VARCHAR2(1);

    L_CUST_CAT STTMS_CUSTOMER.CUSTOMER_CATEGORY%TYPE;
    CURSOR C_ICTM_ACC_PR(P_BRN      VARCHAR2,
                         P_ACC      VARCHAR2,
                         P_CUST_CAT VARCHAR2) IS
      SELECT *
        FROM ICTMS_ACC_PR
       WHERE BRN = P_BRN
         AND ACC = P_ACC
         AND PROD NOT IN
             (SELECT PRODUCT_CODE
                FROM CSTMS_PRODUCT
               WHERE CATEGORIES_LIST = 'D'
                 AND PRODUCT_CODE IN
                     (SELECT PRODUCT_CODE
                        FROM CSTMS_PRD_CAT_DISALLOW
                       WHERE CATEGORY_DISALLOW = P_CUST_CAT))
         AND PROD IN (SELECT PRODUCT_CODE
                        FROM ICTMS_PRODUCT_DEFINITION
                       WHERE PRODUCT_TYPE IN ('I', 'P'));

    L_RES_HOL_TRT DATE;
  BEGIN

    DBG('In Fn_Post_Query..');
    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD16 := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
    P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD17 := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

    DBG('MULTI_CURRENCY_ACCOUNT NUMBER AT UPLOAD::' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);
    DBG('MULTI_CURRENCY_ACCOUNT NUMBER AT UPLOAD::' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.MULTI_CCY_AC_NO);

    L_MASK := SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID);
    DBG('Action Code -->' || P_ACTION_CODE || 'Masking -->' || L_MASK);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND L_MASK = 'Y' THEN
      DBG('Masking for Account Nominees..');
      OPEN C_V_STVW_STTMS_ACCOUNT_NOMS;
      LOOP
        FETCH C_V_STVW_STTMS_ACCOUNT_NOMS BULK COLLECT
          INTO P_WRK_STDCUSAC.V_STTMS_ACCOUNT_NOMINEES;
        EXIT WHEN C_V_STVW_STTMS_ACCOUNT_NOMS%NOTFOUND;
      END LOOP;
      CLOSE C_V_STVW_STTMS_ACCOUNT_NOMS;
      DBG('Masking for Customer Account..');
      OPEN C_V_STVW_STTMS_CUST_ACCOUNT;
      LOOP
        FETCH C_V_STVW_STTMS_CUST_ACCOUNT
          INTO P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT;
        EXIT WHEN C_V_STVW_STTMS_CUST_ACCOUNT%NOTFOUND;
      END LOOP;
      CLOSE C_V_STVW_STTMS_CUST_ACCOUNT;
      DBG('Masking for joint holder..');
      OPEN C_V_STVW_STTM_AC_LNKD_ENTITIES;
      LOOP
        FETCH C_V_STVW_STTM_AC_LNKD_ENTITIES BULK COLLECT
          INTO P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES;
        EXIT WHEN C_V_STVW_STTM_AC_LNKD_ENTITIES%NOTFOUND;
      END LOOP;
      CLOSE C_V_STVW_STTM_AC_LNKD_ENTITIES;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN

      DBG('Is_forgotten: ' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IS_FORGOTTEN);
      IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.IS_FORGOTTEN, 'N') = 'Y' THEN
        DBG('Forgotten Customer account Details cannot be Queried');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;

      IF P_FUNCTION_ID = 'STDCUSAC' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ORG_FUNC_ID = 'STDCASAC' THEN
        DBG('Record Does not Exist..');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;

      IF P_FUNCTION_ID = 'STDCUSAC' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' THEN
        DBG('This Account is TD account so it should be queried in STDCUSTD');
        P_ERR_CODE   := 'ST-CUSA-001';
        P_ERR_PARAMS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      ELSE
        IF P_FUNCTION_ID = 'STDCUSTD' AND
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE <> 'Y' THEN
          DBG('This Account is TD account so it should be queried in STDCUSAC');
          P_ERR_CODE   := 'ST-CUST-001';
          P_ERR_PARAMS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          RETURN FALSE;
        END IF;
      END IF;
      IF P_FUNCTION_ID IN ('STDCUSAC', 'STDCUSTD') AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MUDARABAH_ACCOUNTS = 'Y' THEN
        DBG('Record Does not Exist..');
        P_ERR_CODE   := 'ST-VALS-002';
        P_ERR_PARAMS := P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        RETURN FALSE;
      END IF;
    END IF;

    L_CURR_STAGE := CSPKS_REQ_WRAPPER.FN_GET_CURR_STAGE(P_FUNCTION_ID);
    IF NVL(L_CURR_STAGE, '***') = 'POSTTANKQRY' THEN
      DBG('Returning true for POSTTANKQRY');
      RETURN TRUE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_CLOSE THEN
      DBG('Assigning acc closure variables from p_stdcusac, acc~brn~clmode : ' ||
          P_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE.AC_NO || '~' || '~' ||
          P_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE.BRANCH_CODE || '~' ||
          P_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE.CLOSE_MODE);
      P_WRK_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE := P_STDCUSAC.TY_STCACLOS.V_STTBS_CUST_AC_CLOSURE;
    END IF;

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND
       P_FUNCTION_ID = 'STDTDSIM' AND P_SOURCE <> 'FLEXCUBE' THEN

      DBG('Calling stpkss_stdcusac_utils_0.fn_acccls_pickup for web services');

      IF NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53, 0) <> 0 OR
         NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52, 0) <> 0 OR
         NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51, 0) <> 0 THEN
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                                                            0);
      END IF;

      DBG('Changing maturity date and next maturity date as tenor is changed');

      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) <> 0 OR
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) <> 0 OR
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) <> 0 THEN
        DBG('Original Tenor detrails not equal to zero hence assigning');
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                            0);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                            0);
        L_MATURITY_DATE                              := ADD_MONTHS((P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE),
                                                                   P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                                                   (P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                                                        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

        DBG('p_wrk_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('l_maturity_date-->' || L_MATURITY_DATE);
        IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
          L_MATURITY_DATE_BK := L_MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                         L_MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            L_MATURITY_DATE := L_MATURITY_DATE_BK;
          END IF;
        END IF;
        DBG('p_wrk_stdcusac.v_ictms_acc.maturity_date1-->' ||
            L_MATURITY_DATE);

        IF P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NOT NULL THEN
          IF L_MATURITY_DATE <> P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE THEN
            DBG('Maturity date given is not correct');
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      IF P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE IS NULL THEN

        DBG('Maturity date is null and hence assigning');
        P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := ADD_MONTHS((P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE),
                                                               P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                                               (P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                                                    P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;

        DBG('p_wrk_stdcusac.v_ictms_acc.CASCADE_MONTH-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH);
        DBG('p_wrk_stdcusac.v_ictms_acc.maturity_date-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
        IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
           NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
          L_MATURITY_DATE_BK := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE;
          DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
          IF NOT
              STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
            DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
            P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_MATURITY_DATE_BK;
          END IF;
        END IF;

      END IF;

      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) = 0 AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) = 0 THEN
        DBG('Original Tenor detrails equal to zero hence ORIG TENOR DAYS-->' ||
            P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS   := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                        P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS := 0;
        P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS  := 0;
      END IF;

      DBG('orig tenor days ' || P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS);
      DBG('orig tenor mon ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS);
      DBG('orig tenor years ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS);
      DBG('New Maturity date is ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);
      DBG('Dep tenor days ' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53);
      DBG('Dep tenor mon ' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52);
      DBG('Dep tenor years ' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51);
      DBG('New Maturity date is ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

      IF P_WRK_STDCUSAC.V_ICTMS_ACC.AUTO_ROLLOVER = 'Y' THEN
        DBG('Calculating next maturity date since auto rollover is Y');
        BEGIN
          SELECT RECOMPUTE_MAT_DATE
            INTO L_RECOMPUTE_MATDT
            FROM STTM_ACCOUNT_CLASS
           WHERE ACCOUNT_CLASS =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
        EXCEPTION
          WHEN OTHERS THEN
            L_RECOMPUTE_MATDT := 'N';
            DBG('NO DATA FOUND FOR ACLASS ' ||
                P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
        END;
        DBG('l_recompute_matdt--> ' || L_RECOMPUTE_MATDT);
        IF NVL(L_RECOMPUTE_MATDT, 'N') = 'N' THEN
          P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_DAYS    := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS,
                                                               0);
          P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_MONTHS  := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS,
                                                               0);
          P_WRK_STDCUSAC.V_ICTMS_ACC.ROLL_TENOR_YEARS   := NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS,
                                                               0);
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
        ELSE
          P_WRK_STDCUSAC.V_ICTMS_ACC.NEXT_MATURITY_DATE := NULL;
        END IF;

      END IF;
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := TO_CHAR(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                                P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);

      IF NOT ICPKS_HOLIDAY.FN_GET_MATURITY_DATE(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS,
                                                P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY,
                                                P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                L_RES_HOL_TRT,
                                                P_FUNCTION_ID) THEN
        DBG('icpks_holiday.fn_get_maturity_date has failed but continuing');
      END IF;
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE := L_RES_HOL_TRT;
      DBG('New Maturity date after holiday treatment ' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_ACCCLS_PICKUP(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC,
                                                      P_SOURCE) THEN
        DBG('fn_acccls_pickup has returned false');
        PR_LOG_ERROR(P_FUNCTION_ID, 'FLEXCUBE', P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      IF NOT FN_MATURITY_CALC(P_WRK_STDCUSAC,
                              L_INT_RATE,
                              L_MAT_AMOUNT,
                              L_TB_UDE_DATES,
                              P_ERR_CODE,
                              P_ERR_PARAMS) THEN

        DBG('failed in MATURITY CALCULATION');
        OVPKSS.PR_APPENDTBL(P_ERR_CODE, P_ERR_PARAMS);
        RETURN FALSE;
      END IF;
      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_AMOUNT := L_MAT_AMOUNT;
      P_WRK_STDCUSAC.V_ICTMS_ACC.INTEREST_RATE   := L_INT_RATE;
      DBG('Maturity amount cal ends with all values populated.');
      RETURN TRUE;
    END IF;

    IF P_FUNCTION_ID IN ('STDCUSTD', 'IADCUSTD', 'STDTDSIM') THEN

      BEGIN
        SELECT NVL(HOLIDAY_MOVEMENT, 'H'), NVL(HOLIDAY_CALENDAR, 'N')
          INTO L_HOLIDAY_MOVEMENT, L_HOLIDAY_CALENDAR
          FROM STTM_ACCOUNT_CLASS
         WHERE ACCOUNT_CLASS =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;
      EXCEPTION
        WHEN OTHERS THEN
          L_HOLIDAY_MOVEMENT := 'H';
          L_HOLIDAY_CALENDAR := 'N';
          DBG('NO DATA FOUND FOR ACLASS ' ||
              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS);
      END;

      L_ORIG_MAT_DT := ADD_MONTHS((P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE),
                                  P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS +
                                  (P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS * 12)) +
                       P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;
      IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.CASCADE_MONTH, 'N') = 'N' AND
         NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS, 0) = 0 THEN
        L_ORIG_MAT_DT_BK := L_ORIG_MAT_DT;
        DBG('calling stpks_stdcusac_utils_1.fn_cascade_matdt');
        IF NOT STPKS_STDCUSAC_UTILS_1.FN_CASCADE_MATDT(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE,
                                                       L_ORIG_MAT_DT) THEN
          DBG('Failed in stpks_stdcusac_utils_1.fn_cascade_matdt');
          L_ORIG_MAT_DT := L_ORIG_MAT_DT_BK;
        END IF;
      END IF;
      DBG('original mat dt --->' || L_ORIG_MAT_DT || '~' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE);

      IF L_HOLIDAY_MOVEMENT = 'H' OR L_HOLIDAY_CALENDAR = 'N' OR
         (L_ORIG_MAT_DT = P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE) THEN
        DBG('holiday treatment is not select, hence copying from original tenor');
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_DAYS;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 := P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS;
      ELSE

        IF NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_MONTHS, 0) = 0 AND
           NVL(P_WRK_STDCUSAC.V_ICTMS_ACC.ORIG_TENOR_YEARS, 0) = 0 THEN
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53 := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                            P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52 := 0;
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51 := 0;
        ELSE
          BEGIN
            WITH TTL_MONTHS AS
             (SELECT P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                     ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                                     P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE))) RES,
                     TRUNC(MONTHS_BETWEEN(P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE,
                                          P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE)) MON
                FROM DUAL)
            SELECT CASE
                     WHEN RES >= 0 THEN
                      TRUNC(MON / 12)
                     ELSE
                      TRUNC((MON - 1) / 12)
                   END YEARS,
                   CASE
                     WHEN RES >= 0 THEN
                      MOD(MON, 12)
                     ELSE
                      MOD(MON - 1, 12)
                   END MONTHS,
                   CASE
                     WHEN RES >= 0 THEN
                      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                      ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                 MON)
                     ELSE
                      P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                      ADD_MONTHS(P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE,
                                 MON - 1)
                   END DAYS
              INTO P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD51,
                   P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD52,
                   P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD53
              FROM TTL_MONTHS;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed while defaulting tenor, ' || SQLERRM);
          END;
        END IF;
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD20 := P_WRK_STDCUSAC.V_ICTMS_ACC.MATURITY_DATE -
                                                          P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
      END IF;
    END IF;

    DBG('Query Customer Name');
    BEGIN

      SELECT FULL_NAME
        INTO P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT')(1)('CUSTNAME')
        FROM STTM_CUSTOMER

       WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;

    EXCEPTION
      WHEN OTHERS THEN
        DBG('No Luck.. this time it has failed/.. no customer name');
        DBG('Error is ' || SQLERRM);
        P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT')(1)('CUSTNAME') := NULL;
    END;

    L_MASK := SMPKS_MASK_USER.FN_SETUSRCTX(GLOBAL.USER_ID, P_FUNCTION_ID);
    DBG('Action Code -->' || P_ACTION_CODE || 'Masking -->' || L_MASK);
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY AND L_MASK = 'Y' THEN
      BEGIN
        DBG('Masking for Customer.');
        SELECT FULL_NAME
          INTO P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUST_ACCOUNT')(1)('CUSTNAME')
          FROM (SELECT CUSTOMER_NO, SHORT_NAME, FULL_NAME
                  FROM (SELECT CUSTOMER_NO, SHORT_NAME, FULL_NAME
                          FROM STVW_STTM_CUSTOMER
                         WHERE RECORD_STAT = 'O'
                           AND ONCE_AUTH = 'Y'
                           AND NVL(DECEASED, 'N') = 'N'
                           AND NVL(FROZEN, 'N') = 'N'
                           AND NVL(WHEREABOUTS_UNKNOWN, 'N') = 'N'))
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND ROWNUM < 2;
        IF P_WRK_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT > 0 THEN
          FOR I_2 IN 1 .. P_WRK_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE.COUNT LOOP
            IF P_WRK_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(I_2)
             .CUSTOMER IS NOT NULL THEN
              BEGIN
                SELECT CUSTOMER_NAME1
                  INTO P_WRK_STDCUSAC.TY_CSCCUSLN.DESC_FIELDS('CSTB_RELATIONSHIP_LINKAGE')(I_2)('DESC')
                  FROM STVW_STTM_CUSTOMER
                 WHERE AUTH_STAT = 'A'
                   AND RECORD_STAT = 'O'
                   AND CUSTOMER_NO = P_WRK_STDCUSAC.TY_CSCCUSLN.V_CSTB_RELATIONSHIP_LINKAGE(I_2)
                      .CUSTOMER
                   AND ROWNUM < 2;
              EXCEPTION
                WHEN OTHERS THEN
                  P_WRK_STDCUSAC.TY_CSCCUSLN.DESC_FIELDS('CSTB_RELATIONSHIP_LINKAGE')(I_2)('DESC') := NULL;
                  DBG(SQLERRM);
                  DBG('Failed in selecting the Desc Fields For  :CUSTOMER');
              END;
            END IF;
          END LOOP;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Masking for Customer not found..');
      END;
    END IF;

    DBG('getting the .. DB44' ||
        P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT);
    IF P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.COUNT > 0 THEN
      FOR I_7 IN P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.FIRST .. P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS.LAST LOOP

        BEGIN
          DBG('getting the value for product desc.. ' || I_7 || ',' ||
              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO || ',' || P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I_7)
              .PRODUCT_CODE || ',' ||
              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
          SELECT PRODUCT_DESCRIPTION
            INTO P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUSTAC_PRODUCTS')(I_7)('PRDDESC')
            FROM CSTM_PRODUCT
           WHERE PRODUCT_CODE = P_WRK_STDCUSAC.V_STTMS_CUSTAC_PRODUCTS(I_7)
                .PRODUCT_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            P_WRK_STDCUSAC.DESC_FIELDS('STTMS_CUSTAC_PRODUCTS')(I_7)('PRDDESC') := NULL;
            DBG(SQLERRM);
            DBG('Failed in selecting the Desc Fields For  :PRD');
        END;
      END LOOP;
    END IF;

    DBG('status for passbook 1' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21);
    IF P_ACTION_CODE = 'EXECUTEQUERY' THEN
      BEGIN
        DBG('entering to post query for passbook');
        SELECT STATUS
          INTO P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21
          FROM CATM_PASSBOOK_DETAILS
         WHERE ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        DBG('status for passbook 1' ||
            P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD21);
      EXCEPTION

        WHEN NO_DATA_FOUND THEN
          DBG('status not available for the account');
      END;

      IF P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT > 0 THEN
        FOR I IN 1 .. P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT LOOP
          DBG('p_wrk_Stdcusac.v_Ictms_Td_Details.Td_Amount--->' ||
              P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT);

          IF NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                 .MULTIMODE_PERCENTAGE,
                 0) > 0 AND P_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT <>
             P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT THEN
            DBG(' p_wrk_stdcusac.v_Ictms_Tdpayin_Details.COUNT  ' ||
                P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT);
            DBG('i' || I);
            IF I = P_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS.COUNT THEN
              P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT -
                                                                              L_PAYIN_TOTAL;
              DBG('amount ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDAMOUNT);
            ELSE
              DBG('Pay in Percentage--->' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PERCENTAGE);
              P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I).MULTIMODE_TDAMOUNT := (P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.TD_AMOUNT *
                                                                              NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                                                                   .MULTIMODE_PERCENTAGE,
                                                                                   0) / 100);
              DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_PAYOPT ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_PAYOPT);
              DBG('p_stdcusac.v_Ictms_Tdpayin_Details(i).MULTIMODE_TDOFFSET_CCY ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDOFFSET_CCY);
              IF P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
               .MULTIMODE_TDOFFSET_CCY = 'S' THEN
                SELECT CCY
                  INTO L_CCY
                  FROM STTM_CUST_ACCOUNT
                 WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_TDOFFSET_ACC
                   AND BRANCH_CODE = P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                      .MULTIMODE_OFFSET_BRN;
              ELSE
                L_CCY := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
              END IF;
              DBG('l_ccy ' || L_CCY);
              IF NOT CYPKSS.FN_AMT_ROUND(L_CCY,
                                         P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT,
                                         P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                         .MULTIMODE_TDAMOUNT) THEN
                DBG('Failed in doing Round OFF of amount to offset currency');
              END IF;
              DBG('After Round OFF l_tdpayout_rec.redmamt  ' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                  .MULTIMODE_TDAMOUNT);
            END IF;
          END IF;
          DBG('TDAMT--->' || P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
              .MULTIMODE_TDAMOUNT);
          L_PAYIN_TOTAL := L_PAYIN_TOTAL + NVL(P_WRK_STDCUSAC.V_ICTMS_TDPAYIN_DETAILS(I)
                                               .MULTIMODE_TDAMOUNT,
                                               0);
        END LOOP;
      END IF;
      DBG('l_payin_total--->' || L_PAYIN_TOTAL);

      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD4 := L_PAYIN_TOTAL;

    END IF;
    DBG('Num_Field1    -->' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD1);
    DBG('Num_Field4    -->' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.NUM_FIELD4);

    SELECT END_OF_INPUT
      INTO L_BRNST
      FROM STTMS_BRANCH
     WHERE BRANCH_CODE = GLOBAL.CURRENT_BRANCH;
    P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD2 := L_BRNST;
    DBG(' p_wrk_stdcusac.v_cstbs_ui_columns__brnst.CHAR_FIELD2--->' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS__BRNST.CHAR_FIELD2);

    P_WRK_STDCUSAC.V_STTMS_ACCOUNT_BAL_TOV.CCY := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;

    IF P_SOURCE <> 'FLEXCUBE' THEN
      DBG('Source is:' || P_SOURCE);
      DBG('Calling stpkss_stdcusac_utils_0.fn_popdt');
      IF NOT STPKSS_STDCUSAC_UTILS_0.FN_POPDT(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
        DBG('stpkss_stdcusac_utils_0.fn_popdt has returned false');
        NULL;
      END IF;
      DBG('Interest Tabs interest start date  is:' ||
          P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE);
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD1 := P_WRK_STDCUSAC.V_ICTMS_ACC.INT_START_DATE;
      DBG('Deposit Tabs interest start date after assignment is:' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.DATE_FIELD1);
    END IF;

    IF ((P_ACTION_CODE = 'EXECUTEQUERY' OR
       (P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N' AND
       P_ACTION_CODE IN ('NEW', 'AUTH'))) AND P_SOURCE <> 'FLEXCUBE')

     THEN
      IF NOT STPKS_STDCUSAC_UTILS_2.FN_POPULATE_AMTDT(P_FUNCTION_ID,
                                                      P_WRK_STDCUSAC) THEN
        DBG('stpks_stdcusac_utils_2.fn_populate_amtdt has returned false');
        RETURN FALSE;
      END IF;
    END IF;

    DBG('Making post query calls');
    IF NOT FN_POSTQUERYCALLS(P_FUNCTION_ID, P_WRK_STDCUSAC) THEN
      DBG('fn_postquerycalls returning false');
      RETURN FALSE;
    END IF;

    DBG('inside if-->');
    DBG('p_wrk_stdcusac.v_sttms_cust_account.cust_ac_no' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
    IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_DC_REQUEST, 'N') = 'Y' AND
       (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N')

     THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT1
          FROM STVWS_DC_REQUEST
         WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END;
      IF L_COUNT1 > 0 THEN
        BEGIN
          SELECT *
            INTO P_WRK_STDCUSAC.V_STVWS_DC_REQUEST
            FROM STVWS_DC_REQUEST
           WHERE CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found in stvws_auto_acc_nominees' || SQLERRM);
          WHEN OTHERS THEN
            DBG('when others of stvws_auto_acc_nominees' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    END IF;
    IF NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AUTO_CHQBK_REQUEST, 'N') = 'Y' AND
       (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ONCE_AUTH = 'N') THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT2
          FROM STVWS_CHQBK_REQUEST
         WHERE ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      END;
      IF L_COUNT2 > 0 THEN
        BEGIN
          SELECT *
            INTO P_WRK_STDCUSAC.V_STVWS_CHQBK_REQUEST
            FROM STVWS_CHQBK_REQUEST
           WHERE ACCOUNT = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('No data found in stvws_auto_acc_nominees' || SQLERRM);
          WHEN OTHERS THEN
            DBG('when others of stvws_auto_acc_nominees' || SQLERRM);
            RETURN FALSE;
        END;
      END IF;
    END IF;

    IF P_ACTION_CODE = 'BUILD_SUBSTAT' THEN
      DBG('Calling  Fn_Sys_Query_Desc_Fields..');
      IF NOT STPKS_STDCUSAC_MAIN.FN_SYS_QUERY_DESC_FIELDS(P_SOURCE,
                                                          P_SOURCE_OPERATION,
                                                          P_FUNCTION_ID,
                                                          P_ACTION_CODE,
                                                          P_WRK_STDCUSAC,
                                                          P_ERR_CODE,
                                                          P_ERR_PARAMS) THEN
        DBG('Failed in Fn_Sys_Query_Desc_Fields..');
        RETURN FALSE;
      END IF;
    END IF;

    BEGIN
      IF P_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE = 'Y' THEN
        SELECT STOCK_CATLOG_CD, CERTIFICATE_NO, DUPLICATE_ISSUE
          INTO L_STOCK_CATLOG_CD, L_CERT_NO, L_DUPLICATE_ISSUE
          FROM ICTMS_TD_DETAILS
         WHERE ACC = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO
           AND BRN = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
           AND CCY = P_STDCUSAC.V_STTMS_CUST_ACCOUNT.CCY;
        P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.STOCK_CATLOG_CD := L_STOCK_CATLOG_CD;
        P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.CERTIFICATE_NO  := L_CERT_NO;
        P_WRK_STDCUSAC.V_ICTMS_TD_DETAILS.DUPLICATE_ISSUE := L_DUPLICATE_ISSUE;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        L_STOCK_CATLOG_CD := NULL;
        L_CERT_NO         := NULL;
    END;
    DBG('Stock Code' || L_STOCK_CATLOG_CD);
    DBG('Cert no' || L_CERT_NO);
    DBG('Duplicate Issue' || L_DUPLICATE_ISSUE);

    DBG('Calling Cspks_Req_Utils.Fn_Check_Branch_Rights..');
    IF NOT CSPKS_REQ_UTILS.FN_CHECK_BRANCH_RIGHTS(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                  GLOBAL.USER_ID,
                                                  P_FUNCTION_ID,
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
      DBG('Failed in Cspks_Req_Utils.Fn_Check_Branch_Rights: user does not have rights to query');
      RETURN FALSE;
    END IF;

    BEGIN

      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD70 := CSPKSS_OS_PARAM.GET_PARAM_VAL('DMS_INSTALLED');

      DBG('DMS Installed :' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD70);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBG('Cstb Param not maintained....');
    END;

    L_COUNTCIF := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT;
    DBG('Total added Joint Holders ::' || L_COUNTCIF);
    IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
      DBG('came here Total added Joint Holder');
      FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
        DBG('will form the string now::' || I);
        IF (I = L_COUNTCIF) THEN
          DBG('Last Record::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .JOINT_HOLDER_CODE);
          L_TEMP_JHCIF := L_TEMP_JHCIF || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                         .JOINT_HOLDER_CODE;
          L_TEMP_JHREL := L_TEMP_JHREL || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                         .JOINT_HOLDER;
        ELSE
          L_TEMP_JHCIF := L_TEMP_JHCIF || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                         .JOINT_HOLDER_CODE || '@';
          L_TEMP_JHREL := L_TEMP_JHREL || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                         .JOINT_HOLDER || '@';
        END IF;
      END LOOP;
      DBG('Joint Holder Values ::' || L_TEMP_JHCIF);
      DBG('Added Relations::' || L_TEMP_JHREL);
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99  := L_TEMP_JHCIF;
      P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD100 := L_TEMP_JHREL;
      DBG('Joint Holder Values ::' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99);
      DBG('Added Relations::' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD100);
    END IF;

    P_WRK_STDCUSAC.TY_MICACCTM.V_CSTB_UI_COLUMNS.CHAR_FIELD32 := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_CLASS;

    IF P_FUNCTION_ID = 'STDCUSAC' THEN
      DBG('Here for stdcusac' ||
          P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
      BEGIN
        SELECT CUSTOMER_CATEGORY
          INTO L_CUST_CAT
          FROM STTMS_CUSTOMER
         WHERE CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('In when Others ictm_acc_pr');
      END;
      DBG('l_cust_cat' || L_CUST_CAT);
      IF C_ICTM_ACC_PR%ISOPEN THEN
        CLOSE C_ICTM_ACC_PR;
      END IF;
      OPEN C_ICTM_ACC_PR(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                         L_CUST_CAT);
      FETCH C_ICTM_ACC_PR BULK COLLECT
        INTO P_WRK_STDCUSAC.V_ICTMS_ACC_PR;
      CLOSE C_ICTM_ACC_PR;
    END IF;

    IF P_ACTION_CODE IN ('QRYAMTDT') THEN
      STPKS_STDCUSAC_MAIN.PR_SET_ACTIVATE_SYS;
    END IF;

    DBG('p_Action_Code: ' || P_ACTION_CODE || '~cust_no: ' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO);
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_QUERY,
                         CSPKS_REQ_GLOBAL.P_MODIFY,
                         CSPKS_REQ_GLOBAL.P_CLOSE,
                         CSPKS_REQ_GLOBAL.P_REOPEN) THEN
      BEGIN
        SELECT COUNT(*)
          INTO L_COUNT1
          FROM STTMS_CUSTOMER B
         WHERE B.CUSTOMER_NO = NVL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                   B.CUSTOMER_NO)
           AND ((B.GROUP_CODE IS NOT NULL AND EXISTS
                (SELECT 1
                    FROM STVWS_USER_GROUP C
                   WHERE C.USER_ID = GLOBAL.USER_ID
                     AND C.GROUP_CODE = B.GROUP_CODE)) OR
               B.GROUP_CODE IS NULL)
           AND ((B.ACCESS_GROUP IS NOT NULL AND EXISTS
                (SELECT 1
                    FROM STVWS_USER_ACCESS C
                   WHERE C.USER_ID = GLOBAL.USER_ID
                     AND C.ACCESS_GROUP = B.ACCESS_GROUP)) OR
               B.ACCESS_GROUP IS NULL);
        IF L_COUNT1 = 0 THEN
          DBG('User restricted to view this account' ||
              P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
          P_ERR_CODE   := 'ST-GRP01';
          P_ERR_PARAMS := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
          RETURN FALSE;
        END IF;
      END;
    END IF;

    DBG('p_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
    DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date-->' ||
        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);

    DBG('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcusac_Kernel.Fn_Post_Query ..');
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_POST_QUERY;

  FUNCTION FN_JH_SIG_REPL(P_FUNCTION_ID   IN VARCHAR2,
                          P_ACTION_CODE   IN VARCHAR2,
                          P_PREV_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                          P_WRK_STDCUSAC  IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                          P_ERR_CODE      IN OUT VARCHAR2,
                          P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS

    L_J_CUST_TYPE   STTM_CUSTOMER.CUSTOMER_TYPE%TYPE;
    L_J_NAME        STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;
    L_SIGDATA       NUMBER := 0;
    L_JHCOD         STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;
    L_TEMP_JHCIF    VARCHAR2(1000) := '';
    L_TEMP_JHREL    VARCHAR2(1000) := '';
    L_DEL           NUMBER := 0;
    L_INS           NUMBER := 0;
    L_FIELD_COUNTER NUMBER;
    L_CURR_COL      VARCHAR2(100);
    L_SIG_REPLICATE CHAR(1) := 'N';
  BEGIN

    DBG('Currently existing jointholders::' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99);
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.REPL_CUST_SIG = 'Y' THEN
      L_SIGDATA := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT;
      DBG('Currently existing signature count is::' || L_SIGDATA);
      L_SIGDATA := L_SIGDATA + 1;
      DBG('p_wrk_stdcusac.v_sttms_ac_linked_entities.COUNT::' ||
          P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT);
      IF P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT = 0 THEN
        DBG('No Jointholders,so signatures will be removed now for joint holders');
        DBG('Calling fn_delete_sig');
        IF NOT FN_DELETE_SIG(P_FUNCTION_ID,
                             P_ACTION_CODE,
                             P_PREV_STDCUSAC,
                             P_WRK_STDCUSAC,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
          DBG('fn_delete_sig has returned false');
          RETURN FALSE;
        END IF;
      ELSIF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99 IS NOT NULL AND
            P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
        FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP

          DBG('Start date is coming as ' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .START_DATE);
          IF (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE,
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) <=
             GLOBAL.APPLICATION_DATE) AND
             (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                  GLOBAL.APPLICATION_DATE) >= GLOBAL.APPLICATION_DATE) THEN
            DBG('p_wrk_stdcusac.v_sttms_ac_linked_entities(i).start_date ' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                .START_DATE);
            DBG('p_Wrk_Stdcusac.v_sttms_cust_account.ac_open_date ' ||
                P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE);
            DBG('p_Action_Code ' || P_ACTION_CODE);

            IF INSTR(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99,
                     P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                     .JOINT_HOLDER_CODE) = 0 THEN
              DBG('Going to add signature for  joint holder::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                  .JOINT_HOLDER_CODE);
              BEGIN
                SELECT X.CUSTOMER_TYPE, X.SHORT_NAME
                  INTO L_J_CUST_TYPE, L_J_NAME
                  FROM STTMS_CUSTOMER X
                 WHERE X.CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_CODE;
              EXCEPTION
                WHEN OTHERS THEN
                  DBG('no customer type is maintained');
                  L_J_CUST_TYPE := 'I';
              END;
              DBG('l_j_Cust_Type::' || L_J_CUST_TYPE);
              DBG('l_j_Name::' || L_J_NAME);
              DBG('Customer No Coming here::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                  .JOINT_HOLDER_CODE);

              IF (CSPKS_FEATURE.FN_INSTALLED('CORPACC_SIG_REPLICATE') AND
                 L_J_CUST_TYPE = 'C') OR L_J_CUST_TYPE = 'I' THEN
                L_SIG_REPLICATE := 'Y';
              ELSE
                L_SIG_REPLICATE := 'N';
              END IF;

              IF L_SIG_REPLICATE = 'Y' THEN
                FOR J IN (SELECT M.*
                            FROM SVTM_CIF_SIG_MASTER M
                           WHERE M.CIF_ID = P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                .JOINT_HOLDER_CODE
                             AND M.AUTH_STAT = 'A'
                             AND M.RECORD_STAT = 'O'
                             AND M.REPL_TO_ACC = 'Y'
                             AND EXISTS
                           (SELECT 1
                                    FROM SVTM_CIF_SIG_DET L
                                   WHERE L.CIF_ID = M.CIF_ID
                                     AND L.CIF_SIG_ID = M.CIF_SIG_ID)) LOOP
                  DBG('Coming here TO INSERT for ::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                      .JOINT_HOLDER_CODE);
                  P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIFID := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                                                     .JOINT_HOLDER_CODE;
                  P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(L_SIGDATA)('UIRELATION') := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                                                                          .JOINT_HOLDER;
                  P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).BRANCH := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                  P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).ACC_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                  P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIF_SIG_ID := J.CIF_SIG_ID;

                  P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIF_SIG_NAME := J.CIF_SIG_NAME;

                  L_SIGDATA := L_SIGDATA + 1;
                END LOOP;

              END IF;
            END IF;
          END IF;
        END LOOP;
        DBG('Calling fn_delete_sig');
        IF NOT FN_DELETE_SIG(P_FUNCTION_ID,
                             P_ACTION_CODE,
                             P_PREV_STDCUSAC,
                             P_WRK_STDCUSAC,
                             P_ERR_CODE,
                             P_ERR_PARAMS) THEN
          DBG('fn_delete_sig has returned false');
          RETURN FALSE;
        END IF;
      ELSIF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99 IS NULL AND
            NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT, 0) > 0 THEN
        DBG('Will add the Signature for JH');
        IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN

          FOR K IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
            IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(K)
             .CIFID <> P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO THEN
              P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.DELETE(K);
            END IF;
          END LOOP;
        END IF;
        L_SIGDATA := P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT + 1;
        DBG('Will add the signature only for the added Joint holders');
        FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP

          DBG('Start date is coming as 2 ' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .START_DATE);
          IF (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).START_DATE,
                  P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.AC_OPEN_DATE) <=
             GLOBAL.APPLICATION_DATE) AND
             (NVL(P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I).END_DATE,
                  GLOBAL.APPLICATION_DATE) >= GLOBAL.APPLICATION_DATE) THEN

            BEGIN
              SELECT X.CUSTOMER_TYPE, X.SHORT_NAME
                INTO L_J_CUST_TYPE, L_J_NAME
                FROM STTMS_CUSTOMER X
               WHERE X.CUSTOMER_NO = P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                    .JOINT_HOLDER_CODE;
            EXCEPTION
              WHEN OTHERS THEN
                DBG('no customer type is maintained');
                L_J_CUST_TYPE := 'I';
            END;
            DBG('l_j_Cust_Type::' || L_J_CUST_TYPE);
            DBG('l_j_Name::' || L_J_NAME);
            DBG('Customer No Coming here::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                .JOINT_HOLDER_CODE);

            IF L_SIG_REPLICATE = 'Y' THEN
              FOR J IN (SELECT M.*
                          FROM SVTM_CIF_SIG_MASTER M
                         WHERE M.CIF_ID = P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                              .JOINT_HOLDER_CODE
                           AND M.AUTH_STAT = 'A'
                           AND M.RECORD_STAT = 'O'
                           AND M.REPL_TO_ACC = 'Y'
                           AND EXISTS
                         (SELECT 1
                                  FROM SVTM_CIF_SIG_DET L
                                 WHERE L.CIF_ID = M.CIF_ID
                                   AND L.CIF_SIG_ID = M.CIF_SIG_ID)) LOOP

                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIFID := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                                                   .JOINT_HOLDER_CODE;
                P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(L_SIGDATA)('UIRELATION') := P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
                                                                                                        .JOINT_HOLDER;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).BRANCH := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).ACC_NO := P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIF_SIG_ID := J.CIF_SIG_ID;

                P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_SIGDATA).CIF_SIG_NAME := J.CIF_SIG_NAME;

                L_SIGDATA := L_SIGDATA + 1;
              END LOOP;

            END IF;
          END IF;
        END LOOP;
      END IF;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcusac_Kernel.Fn_JH_Sig_Repl ..' ||
                     SQLERRM || ' and trace: ' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_JH_SIG_REPL;

  FUNCTION FN_DELETE_SIG(P_FUNCTION_ID IN VARCHAR2,
                         P_ACTION_CODE IN VARCHAR2

                        ,
                         P_PREV_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_WRK_STDCUSAC  IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                         P_ERR_CODE      IN OUT VARCHAR2,
                         P_ERR_PARAMS    IN OUT VARCHAR2) RETURN BOOLEAN IS
    TYPE TY_TB_SIG_DTL IS TABLE OF SVTM_ACC_SIG_DET%ROWTYPE INDEX BY BINARY_INTEGER;
    L_REC_SIG_DET   TY_TB_SIG_DTL;
    L_FIELD_COUNTER NUMBER;
    L_CURR_COL      VARCHAR2(100);
    L_DEL           NUMBER := 0;
    J               NUMBER := 0;
    K               NUMBER := 0;
    M               NUMBER := 0;
    L_COUNT         NUMBER := 0;
    L_JHCOD         STTM_AC_LINKED_ENTITIES.JOINT_HOLDER%TYPE;
    CURSOR C_V_SVTMS_ACC_SIG_DETS IS
      SELECT A.*
        FROM SVTM_ACC_SIG_DET_TEMP A
       WHERE A.BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND A.ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;

  BEGIN
    DBG('Came here in Fn_delete_sig');
    IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
      FOR L_INDEX IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
        INSERT INTO SVTM_ACC_SIG_DET_TEMP
        VALUES
          (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
           .CIF_SIG_ID,

           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX).SIG_MSG,
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX).SIG_TYPE,
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
           .APPROVAL_LIMIT,
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
           .SOLO_SUFFICIENT,

           '',
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX)
           .CIF_SIG_NAME,
           P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(L_INDEX).CIFID);
      END LOOP;
    END IF;
    DBG('Previous Joint Holders List coming here::' ||
        P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99);
    IF P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99 IS NOT NULL AND
       P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.COUNT > 0 THEN
      SELECT COUNT(*)
        INTO L_COUNT
        FROM SVTM_ACC_SIG_DET_TEMP
       WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
      DBG('Temp Table data::' || L_COUNT);
      DBG('Previous Joint Holders List coming here::' ||
          P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99);
      L_FIELD_COUNTER := 1;
      WHILE NVL(CSPKES_MISC.FN_GETPARAM(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99,
                                        L_FIELD_COUNTER,
                                        '@'),
                '??') <> 'EOPL' LOOP
        DBG('l_field_counter : ' || L_FIELD_COUNTER);
        L_CURR_COL := CSPKES_MISC.FN_GETPARAM(P_WRK_STDCUSAC.V_CSTBS_UI_COLUMNS.CHAR_FIELD99,
                                              L_FIELD_COUNTER,
                                              '@');
        DBG('l_curr_col ' || L_CURR_COL);
        DBG('Resetting the value of l_del flag inside the loop');
        L_DEL := 0;
        FOR I IN P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.FIRST .. P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES.LAST LOOP
          DBG('going to chek with::' || P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
              .JOINT_HOLDER_CODE);
          IF L_CURR_COL = P_WRK_STDCUSAC.V_STTMS_AC_LINKED_ENTITIES(I)
            .JOINT_HOLDER_CODE THEN
            L_DEL := 1;
          ELSE
            DBG('Go to check with next JH');
            EXIT WHEN L_DEL = 1;
          END IF;
        END LOOP;
        IF L_DEL = 0 THEN
          DBG('Going to delete signature for ::' || L_CURR_COL);
          DELETE FROM SVTM_ACC_SIG_DET_TEMP
           WHERE CIFID = L_CURR_COL
             AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
        END IF;
        L_FIELD_COUNTER := L_FIELD_COUNTER + 1;
      END LOOP;
    ELSE
      DELETE FROM SVTM_ACC_SIG_DET_TEMP
       WHERE ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND CIFID <> P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO;
    END IF;
    DBG('Clear all the screen data now');
    P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.DELETE;
    DBG('Sig Count now::' ||
        P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);
    DBG('Its enough,please insert now');
    SELECT COUNT(*)
      INTO L_COUNT
      FROM SVTM_ACC_SIG_DET_TEMP
     WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
       AND ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    DBG('No of rows which will appear in the signatory screen after this operation::' ||
        L_COUNT);
    OPEN C_V_SVTMS_ACC_SIG_DETS;
    LOOP
      FETCH C_V_SVTMS_ACC_SIG_DETS BULK COLLECT
        INTO P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET;
      EXIT WHEN C_V_SVTMS_ACC_SIG_DETS%NOTFOUND;
    END LOOP;
    CLOSE C_V_SVTMS_ACC_SIG_DETS;
    BEGIN
      DBG('Deleting the Dummy table data ');
      DELETE FROM SVTM_ACC_SIG_DET_TEMP
       WHERE BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Nothing to delete');
    END;

    IF P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT > 0 THEN
      DBG('Coming here for JH codel');
      FOR I IN P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.FIRST .. P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.LAST LOOP
        BEGIN
          DBG('selecting the relation type for::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
              .CIFID);
          SELECT JOINT_HOLDER
            INTO L_JHCOD
            FROM STTM_AC_LINKED_ENTITIES
           WHERE BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND JOINT_HOLDER_CODE = P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
                .CIFID;
          DBG('Relation type for::' || P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET(I)
              .CIFID || '::' || L_JHCOD);
          P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION') := L_JHCOD;

        EXCEPTION
          WHEN OTHERS THEN
            DBG('No jointholders present,so this signature will be authorised signatory ');
            P_WRK_STDCUSAC.TY_SVCACSIG.DESC_FIELDS('SVTMS_ACC_SIG_DET')(I)('UIRELATION') := 'AUS';

        END;

      END LOOP;
    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcusac_Kernel.Fn_delete_sig ..' ||
                     SQLERRM || ' and trace: ' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_DELETE_SIG;

  FUNCTION FN_UPDATE_SIG_HISTORY(P_FUNCTION_ID  IN VARCHAR2,
                                 P_ACTION_CODE  IN VARCHAR2,
                                 P_WRK_STDCUSAC IN OUT STPKS_STDCUSAC_MAIN.TY_STDCUSAC,
                                 P_ERR_CODE     IN OUT VARCHAR2,
                                 P_ERR_PARAMS   IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_HIST_DEL NUMBER := 0;
    L_HIST_ADD NUMBER := 0;
    L_MOD      NUMBER;
    L_STATUS   STTM_ACC_SIG_HISTORY.NATURE_OF_CHANGE%TYPE;
    L_ADD_IT   NUMBER := 0;
    TYPE TY_TB_STTM_ACC_SIG_HISTORY IS TABLE OF STTM_ACC_SIG_HISTORY%ROWTYPE INDEX BY BINARY_INTEGER;
    L_REC_STTM_ACC_SIG_HISTORY TY_TB_STTM_ACC_SIG_HISTORY;
    TYPE TY_TB_SVTM_ACC_SIG_DET IS TABLE OF SVTM_ACC_SIG_DET%ROWTYPE INDEX BY BINARY_INTEGER;
    L_REC_SVTM_ACC_SIG_DET TY_TB_SVTM_ACC_SIG_DET;
    L_SIGCNT               NUMBER;
    L_CHANGE               VARCHAR2(1);
    CURSOR CR_STTM_ACC_SIG_HISTORY IS
      SELECT *
        FROM STTM_ACC_SIG_HISTORY
       WHERE CUST_AC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH_CODE = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
         AND NATURE_OF_CHANGE = 'A';

    CURSOR CR_SVTM_ACC_SIG_DET IS
      SELECT *
        FROM SVTM_ACC_SIG_DET
       WHERE ACC_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
         AND BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
  BEGIN
    DBG('Inside Fn_Update_Sig_History ');
    DBG('Coming here to update the History Table');
    IF CR_STTM_ACC_SIG_HISTORY%ISOPEN THEN
      CLOSE CR_STTM_ACC_SIG_HISTORY;
    END IF;

    OPEN CR_STTM_ACC_SIG_HISTORY;
    FETCH CR_STTM_ACC_SIG_HISTORY BULK COLLECT
      INTO L_REC_STTM_ACC_SIG_HISTORY;
    CLOSE CR_STTM_ACC_SIG_HISTORY;

    IF CR_SVTM_ACC_SIG_DET%ISOPEN THEN
      CLOSE CR_SVTM_ACC_SIG_DET;
    END IF;

    OPEN CR_SVTM_ACC_SIG_DET;
    FETCH CR_SVTM_ACC_SIG_DET BULK COLLECT
      INTO L_REC_SVTM_ACC_SIG_DET;
    CLOSE CR_SVTM_ACC_SIG_DET;

    DBG('Checker_id::' || GLOBAL.USER_ID);
    DBG('Checker_id::' || FN_MNTSTAMP);
    P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP := FN_MNTSTAMP;
    DBG('Existing Signature Count::' || L_REC_STTM_ACC_SIG_HISTORY.COUNT);
    DBG('Current Signature Count::' ||
        P_WRK_STDCUSAC.TY_SVCACSIG.V_SVTMS_ACC_SIG_DET.COUNT);
    IF ((L_REC_STTM_ACC_SIG_HISTORY.COUNT = '0') AND
       (L_REC_SVTM_ACC_SIG_DET.COUNT > 0)) THEN
      DBG('Signatures are newly added');
      FOR I IN L_REC_SVTM_ACC_SIG_DET.FIRST .. L_REC_SVTM_ACC_SIG_DET.LAST LOOP

        INSERT INTO STTM_ACC_SIG_HISTORY

          (CUST_AC_NO,
           CUST_NO,
           BRANCH_CODE,
           CIF_SIG_ID,
           MOD_NO,
           SIGNATORY_NAME,
           SIGNATORY_TYPE,
           MAKER_ID,
           MAKER_DT_STAMP,
           CHECKER_ID,
           CHECKER_DT_STAMP,
           NATURE_OF_CHANGE)
        VALUES
          (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
           L_REC_SVTM_ACC_SIG_DET(I).CIFID,

           L_REC_SVTM_ACC_SIG_DET                              (I).BRANCH,
           L_REC_SVTM_ACC_SIG_DET                              (I)
           .CIF_SIG_ID,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
           L_REC_SVTM_ACC_SIG_DET                              (I)
           .CIF_SIG_NAME,
           L_REC_SVTM_ACC_SIG_DET                              (I).SIG_TYPE,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
           GLOBAL.USER_ID,
           P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
           'A');
      END LOOP;
    ELSIF ((L_REC_STTM_ACC_SIG_HISTORY.COUNT > 0) AND
          (L_REC_SVTM_ACC_SIG_DET.COUNT = 0)) THEN
      DBG('Signatures has been Deleted now');
      FOR I IN L_REC_STTM_ACC_SIG_HISTORY.FIRST .. L_REC_STTM_ACC_SIG_HISTORY.LAST LOOP

        BEGIN
          SELECT NATURE_OF_CHANGE
            INTO L_CHANGE
            FROM STTM_ACC_SIG_HISTORY A
           WHERE A.CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND A.CUST_NO = L_REC_STTM_ACC_SIG_HISTORY(I).CUST_NO
             AND A.CIF_SIG_ID = L_REC_STTM_ACC_SIG_HISTORY(I).CIF_SIG_ID
             AND A.BRANCH_CODE =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE
             AND MOD_NO =
                 (SELECT MAX(MOD_NO)
                    FROM STTM_ACC_SIG_HISTORY A
                   WHERE A.CUST_AC_NO =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                     AND A.CUST_NO = L_REC_STTM_ACC_SIG_HISTORY(I).CUST_NO
                     AND A.CIF_SIG_ID = L_REC_STTM_ACC_SIG_HISTORY(I)
                        .CIF_SIG_ID
                     AND A.BRANCH_CODE =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE);
          DBG('Nature of change for this combination in history::' ||
              L_CHANGE);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBG('Not any previous entry in the history table');
        END;
        DBG('l_change::' || L_CHANGE);
        IF L_CHANGE = 'A' THEN

          INSERT INTO STTM_ACC_SIG_HISTORY

            (CUST_AC_NO,
             CUST_NO,
             BRANCH_CODE,
             CIF_SIG_ID,
             MOD_NO,
             SIGNATORY_NAME,
             SIGNATORY_TYPE,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_ID,
             CHECKER_DT_STAMP,
             NATURE_OF_CHANGE)
          VALUES
            (L_REC_STTM_ACC_SIG_HISTORY                          (I)
             .CUST_AC_NO,
             L_REC_STTM_ACC_SIG_HISTORY                          (I).CUST_NO,
             L_REC_STTM_ACC_SIG_HISTORY                          (I)
             .BRANCH_CODE,
             L_REC_STTM_ACC_SIG_HISTORY                          (I)
             .CIF_SIG_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
             L_REC_STTM_ACC_SIG_HISTORY                          (I)
             .SIGNATORY_NAME,
             L_REC_STTM_ACC_SIG_HISTORY                          (I)
             .SIGNATORY_TYPE,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
             GLOBAL.USER_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
             'D');

        END IF;
        DBG('History updated for::' || L_REC_STTM_ACC_SIG_HISTORY(I)
            .CUST_NO || 'and' || L_REC_STTM_ACC_SIG_HISTORY(I).CIF_SIG_ID);

      END LOOP;
    ELSIF ((L_REC_STTM_ACC_SIG_HISTORY.COUNT > 0) AND
          (L_REC_SVTM_ACC_SIG_DET.COUNT > 0)) THEN
      DBG('Going to check whether the current signatures were present');
      FOR I IN L_REC_SVTM_ACC_SIG_DET.FIRST .. L_REC_SVTM_ACC_SIG_DET.LAST LOOP

        SELECT COUNT(*)
          INTO L_SIGCNT
          FROM STTM_ACC_SIG_HISTORY A
         WHERE A.CUST_AC_NO =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND A.CUST_NO = L_REC_SVTM_ACC_SIG_DET(I).CIFID
           AND A.CIF_SIG_ID = L_REC_SVTM_ACC_SIG_DET(I).CIF_SIG_ID
           AND A.BRANCH_CODE =
               P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
        IF L_SIGCNT = 0 THEN

          INSERT INTO STTM_ACC_SIG_HISTORY

            (CUST_AC_NO,
             CUST_NO,
             BRANCH_CODE,
             CIF_SIG_ID,
             MOD_NO,
             SIGNATORY_NAME,
             SIGNATORY_TYPE,
             MAKER_ID,
             MAKER_DT_STAMP,
             CHECKER_ID,
             CHECKER_DT_STAMP,
             NATURE_OF_CHANGE)
          VALUES
            (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
             L_REC_SVTM_ACC_SIG_DET                              (I).CIFID,
             L_REC_SVTM_ACC_SIG_DET                              (I).BRANCH,
             L_REC_SVTM_ACC_SIG_DET                              (I)
             .CIF_SIG_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
             L_REC_SVTM_ACC_SIG_DET                              (I)
             .CIF_SIG_NAME,
             L_REC_SVTM_ACC_SIG_DET                              (I)
             .SIG_TYPE,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
             GLOBAL.USER_ID,
             P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
             'A');
        ELSIF L_SIGCNT > 1 THEN
          SELECT NVL(NATURE_OF_CHANGE, 'D')
            INTO L_STATUS
            FROM STTM_ACC_SIG_HISTORY A
           WHERE A.CUST_AC_NO =
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
             AND A.MOD_NO =
                 (SELECT MAX(MOD_NO)
                    FROM STTM_ACC_SIG_HISTORY
                   WHERE CIF_SIG_ID = L_REC_SVTM_ACC_SIG_DET(I).CIF_SIG_ID
                     AND CUST_AC_NO =
                         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                     AND CUST_NO = L_REC_SVTM_ACC_SIG_DET(I).CIFID)
             AND A.CUST_NO = L_REC_SVTM_ACC_SIG_DET(I).CIFID
             AND A.CIF_SIG_ID = L_REC_SVTM_ACC_SIG_DET(I).CIF_SIG_ID;
          DBG('Status of the::' || L_REC_SVTM_ACC_SIG_DET(I).CIFID ||
              'is::' || L_STATUS);
          IF L_STATUS = 'D' THEN
            DBG('signature is there in deleted state,so need to add again');
            BEGIN
              INSERT INTO STTM_ACC_SIG_HISTORY

                (CUST_AC_NO,
                 CUST_NO,
                 BRANCH_CODE,
                 CIF_SIG_ID,
                 MOD_NO,
                 SIGNATORY_NAME,
                 SIGNATORY_TYPE,
                 MAKER_ID,
                 MAKER_DT_STAMP,
                 CHECKER_ID,
                 CHECKER_DT_STAMP,
                 NATURE_OF_CHANGE)
              VALUES
                (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO,
                 L_REC_SVTM_ACC_SIG_DET                              (I)
                 .CIFID,
                 L_REC_SVTM_ACC_SIG_DET                              (I)
                 .BRANCH,
                 L_REC_SVTM_ACC_SIG_DET                              (I)
                 .CIF_SIG_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
                 L_REC_SVTM_ACC_SIG_DET                              (I)
                 .CIF_SIG_NAME,
                 L_REC_SVTM_ACC_SIG_DET                              (I)
                 .SIG_TYPE,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
                 GLOBAL.USER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
                 'A');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in insertion with ::' || SQLERRM);
            END;
          END IF;
        END IF;
      END LOOP;
      DBG('Going to check whether previous signatures got deleted now');

      FOR J IN (SELECT *
                  FROM STTM_ACC_SIG_HISTORY A
                 WHERE (A.CUST_NO, A.CIF_SIG_ID, A.MOD_NO) IN
                       (SELECT A.CUST_NO, A.CIF_SIG_ID, MAX(MOD_NO)
                          FROM STTM_ACC_SIG_HISTORY B
                         WHERE A.CUST_AC_NO = B.CUST_AC_NO
                           AND A.CUST_NO = B.CUST_NO
                           AND A.CIF_SIG_ID = B.CIF_SIG_ID
                         GROUP BY A.CUST_NO, A.CIF_SIG_ID)
                   AND A.CUST_AC_NO =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
                   AND A.BRANCH_CODE =
                       P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE) LOOP
        DBG('Checking for::' || J.CUST_AC_NO || 'and' || J.CIF_SIG_ID);
        IF J.NATURE_OF_CHANGE = 'A' THEN
          DBG('Signature present in the added form');
          SELECT COUNT(*)
            INTO L_SIGCNT
            FROM SVTM_ACC_SIG_DET A
           WHERE A.ACC_NO = J.CUST_AC_NO
             AND A.CIFID = J.CUST_NO
             AND A.CIF_SIG_ID = J.CIF_SIG_ID
             AND A.BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          DBG('L_sigcnt' || L_SIGCNT);
          IF L_SIGCNT < 1 THEN
            DBG('This signature is deleted in this modification,logging history');
            BEGIN
              INSERT INTO STTM_ACC_SIG_HISTORY

                (CUST_AC_NO,
                 CUST_NO,
                 BRANCH_CODE,
                 CIF_SIG_ID,
                 MOD_NO,
                 SIGNATORY_NAME,
                 SIGNATORY_TYPE,
                 MAKER_ID,
                 MAKER_DT_STAMP,
                 CHECKER_ID,
                 CHECKER_DT_STAMP,
                 NATURE_OF_CHANGE)
              VALUES
                (J.CUST_AC_NO,
                 J.CUST_NO,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 J.CIF_SIG_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
                 J.SIGNATORY_NAME,
                 J.SIGNATORY_TYPE,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
                 GLOBAL.USER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
                 'D');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in insertion with ::' || SQLERRM);
            END;
          END IF;
        ELSIF J.NATURE_OF_CHANGE = 'D' THEN
          DBG('this signature is already deleted,checking whether added again');
          SELECT COUNT(*)
            INTO L_SIGCNT
            FROM SVTM_ACC_SIG_DET A
           WHERE A.ACC_NO = J.CUST_AC_NO
             AND A.CIFID = J.CUST_NO
             AND A.CIF_SIG_ID = J.CIF_SIG_ID
             AND A.BRANCH = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE;
          DBG('L_sigcnt' || L_SIGCNT);
          IF L_SIGCNT > 0 THEN
            DBG('Ooffff...added again..so need to log history for::' ||
                J.CUST_NO || ' and ' || J.CIF_SIG_ID);
            BEGIN
              INSERT INTO STTM_ACC_SIG_HISTORY

                (CUST_AC_NO,
                 CUST_NO,
                 BRANCH_CODE,
                 CIF_SIG_ID,
                 MOD_NO,
                 SIGNATORY_NAME,
                 SIGNATORY_TYPE,
                 MAKER_ID,
                 MAKER_DT_STAMP,
                 CHECKER_ID,
                 CHECKER_DT_STAMP,
                 NATURE_OF_CHANGE)
              VALUES
                (J.CUST_AC_NO,
                 J.CUST_NO,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                 J.CIF_SIG_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MOD_NO,
                 J.SIGNATORY_NAME,
                 J.SIGNATORY_TYPE,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.MAKER_DT_STAMP,
                 GLOBAL.USER_ID,
                 P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CHECKER_DT_STAMP,
                 'A');
            EXCEPTION
              WHEN OTHERS THEN
                DBG('Failed in insertion with ::' || SQLERRM);
            END;
          END IF;
        END IF;
        L_SIGCNT := 0;
      END LOOP;

    END IF;

    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('**',
                     'In When others of stpks_stdcusac_Kernel.Fn_Update_Sig_History ..' ||
                     SQLERRM || ' and trace: ' ||
                     DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
      DEBUG.PR_DEBUG('**', SQLERRM);
      P_ERR_CODE   := 'ST-OTHR-001';
      P_ERR_PARAMS := NULL;
      RETURN FALSE;
  END FN_UPDATE_SIG_HISTORY;

END STPKS_STDCUSAC_KERNEL;
