insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('AC-EACC-001', 'ENG', 'Customer has reached the maximum number of E-Accounts (5) allowed with Account Class EA02', 'E', 'N', 'STDCUSAC', 0, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('AC-EACC-002', 'ENG', 'Joint Account is not allowed for Account Class - EA02', 'E', 'N', 'STDCUSAC', 0, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
