CREATE OR REPLACE EDITIONABLE PACKAGE BODY "P1FCHPRFM"."STPKS_STDCUSAC_CUSTOM" AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcusac_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes

  ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA SI Payment Account Closure Validation
   ** Search String       : AIA SI Payment Account Closure Validation

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcusac_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcusac         IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcusac_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcusac         IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
   
     --sampath starts for EA02
    L_COUNT NUMBER := 0;
    --sampath ends for EA02
	
  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');
	
	 --sampath starts for EA02
    IF p_Action_Code IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_AUTH) THEN
    
      IF p_stdcusac.v_sttms_cust_account.ACCOUNT_CLASS = 'EA02' THEN
      
        BEGIN
        
          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_NO = p_stdcusac.v_sttms_cust_account.CUST_NO
             AND A.ACCOUNT_CLASS = 'EA02'
             AND A.RECORD_STAT = 'O'
             AND A.ONCE_AUTH = 'Y';
        
        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;
      
        IF L_COUNT >=5 THEN
        
          Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-001', NULL);
        
          RETURN FALSE;
        
        END IF;
        
        IF p_stdcusac.v_sttms_cust_account.JOINT_AC_INDICATOR = 'J' THEN
          
        Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-002', NULL);
        
          RETURN FALSE;
          
        END IF;
      
      END IF;
    
    END IF;
    --sampath ends for EA02

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

   --AIA SI Payment Account Closure Validation Starts
  L_COUNT NUMBER;
   --AIA SI Payment Account Closure Validation Ends

  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

  --AIA SI Payment Account Closure Validation Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE) THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_AIA_SI_MASTER A
         WHERE A.CUST_AC_NO = p_stdcusac.v_sttms_cust_account.CUST_AC_NO
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;

      IF L_COUNT > 0 THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'IF-AIA-006', NULL);

        RETURN FALSE;

      END IF;
    END IF;
    --AIA SI Payment Account Closure Validation Ends

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                       p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    --Coral Integration with Flexcube Changes commented starts
    --AML Integrations Changes Starts
    --L_FIELD_VAL_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_2%TYPE; --Coral Integration with Flexcube Changes Commented
    --AML Integrations Changes Ends
    --Coral Integration with Flexcube Changes commented Ends
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

  --Coral Integration with Flexcube Changes commented starts
    --AML Integrations Changes Starts
    /*IF P_ACTION_CODE IN ('NEW') THEN

      BEGIN

        L_FIELD_VAL_2 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                                 'AML_VALIDATED');

        IF L_FIELD_VAL_2 = 'No' THEN

          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_frozen := 'Y';
          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_no_dr  := 'Y';
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to SELECT UDF Value');
          DBG(SQLERRM);
      END;
    END IF;*/

    --AML Integrations Changes ends
    --Coral Integration with Flexcube Changes commented starts

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    ----SV UDF capture starts
    L_CARD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    ----SV UDF capture ends
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    ----SV UDF capture starts
    DBG('In Fn_Post_Upload_Db.. pavan');
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      if (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.atm_facility = 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE NOT IN
         ('Y', 'N')) then

        L_PROD_ID := ifpks_sv_cdc_custom.FN_GET_PROD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        L_CARD_ID := ifpks_sv_cdc_custom.FN_GET_CARD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

        IF (L_PROD_ID IS null OR L_CARD_ID is null) THEN
          DEBUG.PR_DEBUG('**', 'CARD ID OR PRODUCT_ID ARE NULL');
          P_ERR_CODE   := 'ST-SV-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      end if;

    --special premium account changes starts
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPL_AC_GEN = 'Y' THEN
      BEGIN
        UPDATE STTM_SPL_ACC_RANGE_DIG
           SET STATUS = 'Y'
         WHERE ACCOUNT_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND STATUS = 'N';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED TO UPDATE SPECIAL ACCOUNT RANGE');
      END;
    END IF;
    --special premium account changes ends

    END IF;

    ----SV UDF capture ends

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                         p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Query..');

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcusac_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcusac_custom;
/