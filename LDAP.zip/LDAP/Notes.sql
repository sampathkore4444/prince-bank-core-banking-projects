SELECT * FROM SMTB_PARAMETERS A for update;
SELECT * FROM SMTB_SSO_PARAM;
SELECT * FROM SMTB_USER A WHERE A.USER_ID = 'TEST.LDAP' for update;--TESTLDAP
SELECT * FROM SSTB_USER A WHERE A.USER_ID = 'TEST.LDAP' for update;
select /*+ result_cache */ * from SSTB_USER where user_id= 'TEST.LDAP' or upper(ldap_user)= 'TEST.LDAP';
select /*+ result_cache */ * from smtb_user_holiday where user_id =  'TEST.LDAP';
select * from smtb_user_role where user_id = 'YRAROTH';

select * from cstb_param where param_name = 'REAL_DEBUG' FOR UPDATE;
SELECT * FROM CSTB_DEBUG_USERS A WHERE A.USER_ID = 'TEST.LDAP';
SELECT * FROM CSTB_DEBUG_USERS A WHERE A.USER_ID = 'YRAROTH';
INSERT INTO CSTB_DEBUG_USERS SELECT MODULE, 'Y', 'TEST.LDAP' FROM CSTB_DEBUG_USERS A WHERE A.USER_ID = 'YRAROTH';

INSERT INTO smtb_user_role SELECT ROLE_ID, 'TEST.LDAP', AUTH_STAT, BRANCH_CODE FROM smtb_user_role where user_id = 'YRAROTH'

SELECT /*+ result_cache */
 *
  FROM smtb_userlog_details where user_id = 'TEST.LDAP' for update
 where user_id = (select user_id
                    from sstb_user
                   where user_id = 'TEST.LDAP'
                      or ldap_user = 'TEST.LDAP') for update

select * from smtb_userlog_details where user_id = 'YRAROTH' FOR UPDATE