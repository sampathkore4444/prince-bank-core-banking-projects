insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_MASTER', '70000279', 'Master Debit Platinum Card for Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_MASTER', '70000276', 'Master Debit Platinum Card for Staff', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_MASTER', '70000277', 'Master Debit Standard Card for Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_MASTER', '70000270', 'Master Debit Standard Card for Staff', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_MASTER', '70000320', 'Master Debit Standard Card for Corp Payroll', 'N');

COMMIT;
