insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_VISA', '70000282', 'Visa Debit Classic Card for Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_VISA', '70000281', 'Visa Debit Classic Card for Staff', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_VISA', '70000284', 'Visa Debit Platinum Card for Customer', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_VISA', '70000283', 'Visa Debit Platinum Card for Staff', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_VISA', '70000321', 'Visa Debit Classic Card for Corp Payroll', 'N');

COMMIT;
