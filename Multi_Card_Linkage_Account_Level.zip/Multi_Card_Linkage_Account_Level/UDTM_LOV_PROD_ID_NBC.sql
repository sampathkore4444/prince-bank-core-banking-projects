insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_NBC', '70000312', 'NBC Debit Card Customer - Normal', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_NBC', '70000313', 'NBC Debit Card Customer - Priority', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_NBC', '70000315', 'NBC Debit Card Staff - Normal', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_NBC', '70000316', 'NBC Debit Card Staff - Priority', 'N');

insert into UDTM_LOV (FIELD_NAME, LOV, LOV_DESC, IS_DEFAULT_VALUE)
values ('PROD_ID_NBC', '70000317', 'NBC Debit Card Corp Payroll - Normal', 'N');

COMMIT;