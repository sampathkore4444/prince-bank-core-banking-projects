CREATE OR REPLACE PACKAGE BODY IFPKS_SV_CDC_CUSTOM IS
  /*
          -----------------------------------------------------------------------------------------------------------------
  
          =================================================================================================================
          ****************************************    CHANGE HISTORY      *************************************************
          =================================================================================================================
  
              CREATED BY    : Techurate Dev Team
              CREATED ON    : 12-DEC-2018
  
              MODIFIED BY    : Techurate Dev Team
              MODIFIED ON    : 28-FEB-2019
              MODIFIED REASON: HANDLED THE ACCOUNTS WITH ALREADY HAVING ATM FACILITY
              SEARCH STRING  : CHANGES FOR TECH#20190228001
              
              CREATED BY    : Kore Sampath Kumar
              CREATED ON    : 24-March-2020
              Search String : Linking Multiple Cards At Account Level Changes
  */

  PROCEDURE DBG(LINE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'IFPKS_SV_CDC_CUSTOM-->' || LINE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN IFPKS_SV_CDC_CUSTOM.DBG');
      DBG(SQLERRM);
  END;

  PROCEDURE PR_PROCESS_MSG_INS IS
    L_COUNT1     NUMBER;
    L_COUNT2     NUMBER;
    L_CARD_COUNT NUMBER; -- added for TECH#20190228001
    L_CARD_ID    IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    -- L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
  
    CURSOR CUR_SV_CDC IS
      SELECT * FROM IFTB_SV_CDC_CUSTOM WHERE STATUS = 'I';
  BEGIN
    DBG('Started Inserting ');
    OPEN CUR_SV_CDC;
    LOOP
      FETCH CUR_SV_CDC
        INTO L_SV_CDC_DETAILS;
      IF CUR_SV_CDC%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('STARTED FOR ' || L_SV_CDC_DETAILS.PKEY_VALS);
      IF (L_SV_CDC_DETAILS.TABLE_NAME = 'CYTM_RATES') THEN
        DBG('Started Inserting for CYTM_RATES ');
        IF NOT
            FN_INS_CCY_RATE(L_SV_CDC_DETAILS.ID, L_SV_CDC_DETAILS.PKEY_VALS) THEN
          DBG('FAILED IN FN_INS_CCY_RATE');
          IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
            DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
          END IF;
        END IF;
      ELSIF (L_SV_CDC_DETAILS.TABLE_NAME = 'STTM_CUST_ACCOUNT') THEN
        --  L_PROD_ID := FN_GET_PROD_ID(SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 1, 3), SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 5));
        L_CARD_ID := FN_GET_CARD_ID(SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 1, 3),
                                    SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 5));
        if L_CARD_ID is not null then
          -- ADDED FOR TECH#20190228001
          DBG('Started Inserting for STTM_CUST_ACCOUNT ');
          DBG('Seq_number ' || L_SV_CDC_DETAILS.ID);
          IF (L_SV_CDC_DETAILS.RECORD_STAT = 'O') THEN
            DBG('account is in open stat ');
            IF (L_SV_CDC_DETAILS.ATM_FACILITY = 'Y') THEN
              DBG('account has atm facility ');
              SELECT COUNT(1)
                INTO L_COUNT1
                FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
               WHERE CUST_AC_NO = SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 5)
                 AND BRANCH_CODE = SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 1, 3)
                 AND XML_TYPE IN
                     (SELECT PARAM_VAL
                        FROM IFTM_SV_CONFIG_CUSTOM
                       WHERE PARAM_NAME IN ('OPN_ADD_ACC', 'ADD_NEW_CUST'));
              IF (L_COUNT1 > 0) THEN
                DBG('account has ALREADY APPLIED so activating status');
                IF NOT FN_INS_CHG_ACC_STAT(L_SV_CDC_DETAILS.ID,
                                           L_SV_CDC_DETAILS.ATM_FACILITY) THEN
                  DBG('FAILED IN FN_INS_CHG_ACC_STAT');
                  IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                    DBG('FAILED TO UPDATE STATUS FOR ' ||
                        L_SV_CDC_DETAILS.ID);
                  END IF;
                END IF;
              ELSE
                SELECT COUNT(1)
                  INTO L_COUNT2
                  FROM IFTB_SVCARD_CUSTDETAILS_CUSTOM
                 WHERE CUSTOMER_NO IN
                       (SELECT CUST_NO
                          FROM STTM_CUST_ACCOUNT
                         WHERE BRANCH_CODE =
                               SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 1, 3)
                           AND CUST_AC_NO =
                               SUBSTR(L_SV_CDC_DETAILS.PKEY_VALS, 5))
                   AND XML_TYPE IN
                       (SELECT PARAM_VAL
                          FROM IFTM_SV_CONFIG_CUSTOM
                         WHERE PARAM_NAME IN ('OPN_ADD_ACC', 'ADD_NEW_CUST'));
                IF (L_COUNT2 = 0) THEN
                  DBG('CUSTOMER CARD ASSIGNING FOR FIRST TIME FN_INS_ADD_NEW_CUST');
                  IF NOT FN_INS_ADD_NEW_CUST(L_SV_CDC_DETAILS.ID) THEN
                    DBG('FAILED IN FN_INS_ADD_NEW_CUST');
                    IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                      DBG('FAILED TO UPDATE STATUS FOR ' ||
                          L_SV_CDC_DETAILS.ID);
                    END IF;
                  END IF;
                ELSE
                  DBG('CALLING FRO ADDITIONAL ISSUING ACCOUNT FN_INS_OPN_ADD_ACC ');
                  IF NOT FN_INS_OPN_ADD_ACC(L_SV_CDC_DETAILS.ID) THEN
                    DBG('FAILED IN FN_INS_OPN_ADD_ACC');
                    IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                      DBG('FAILED TO UPDATE STATUS FOR ' ||
                          L_SV_CDC_DETAILS.ID);
                    END IF;
                  END IF;
                END IF;
              END IF;
            ELSE
              DBG('ATM FACILITY UNCHECKED SO SENDING DEACTIVATING status');
              IF NOT FN_INS_CHG_ACC_STAT(L_SV_CDC_DETAILS.ID,
                                         L_SV_CDC_DETAILS.ATM_FACILITY) THEN
                DBG('FAILED IN FN_INS_CHG_ACC_STAT');
                IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                  DBG('FAILED TO UPDATE STATUS FOR ' ||
                      L_SV_CDC_DETAILS.ID);
                END IF;
              END IF;
            END IF;
          ELSE
            DBG('ACCOUNT HAS BEEN CLOSED');
            IF NOT FN_INS_CLO_CUST_ACC(L_SV_CDC_DETAILS.ID) THEN
              DBG('FAILED IN FN_INS_CLO_CUST_ACC');
              IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
              END IF;
            END IF;
          END IF;
          ----------CHANGES STARTS FOR TECH#20190228001
        else
          DBG('NO CARD ID SO NO DATA');
          IF NOT FN_UPDATE_ERR_STATUS(L_SV_CDC_DETAILS.ID,
                                      'E',
                                      'CARD ID IS NULL') THEN
            DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
          END IF;
        end if;
        ----------CHENGES END FOR TECH#20190228001
      ELSIF (L_SV_CDC_DETAILS.TABLE_NAME = 'STTM_CUSTOMER') THEN
        ----------CHANGES STARTS FOR TECH#20190228001
        select count(IFPKS_SV_CDC_CUSTOM.FN_GET_CARD_ID(BRANCH_CODE,
                                                        CUST_AC_NO))
          into L_CARD_COUNT
          from sttm_cust_account
         where ATM_FACILITY = 'Y'
           and cust_no = L_SV_CDC_DETAILS.PKEY_VALS;
        if (L_CARD_COUNT > 0) then
          ----------CHENGES END FOR TECH#20190228001
          DBG('ENTERED FOR STTM_CUSTOMER');
          IF (L_SV_CDC_DETAILS.RECORD_STAT = 'O') THEN
            IF NOT FN_INS_CHG_CUST_DATA(L_SV_CDC_DETAILS.ID) THEN
              DBG('FAILED IN FN_INS_CHG_CUST_DATA');
              IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
              END IF;
            END IF;
            IF NOT FN_INS_CHG_CARD_INFO(L_SV_CDC_DETAILS.ID) THEN
              DBG('FAILED IN FN_INS_CHG_CARD_INFO');
              IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
              END IF;
            END IF;
          ELSE
            IF NOT FN_INS_CLO_CUST_CARD(L_SV_CDC_DETAILS.ID) THEN
              DBG('FAILED IN FN_INS_CLO_CUST_CARD');
              IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
                DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
              END IF;
            END IF;
          END IF;
          ----------CHANGES STARTS FOR TECH#20190228001
        else
          DBG('NO CARD ID SO DATA');
          IF NOT FN_UPDATE_ERR_STATUS(L_SV_CDC_DETAILS.ID,
                                      'E',
                                      'CARD ID IS NULL') THEN
            DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
          END IF;
        end if;
        ----------CHENGES END FOR TECH#20190228001
      ELSE
        ----------CHANGES STARTS FOR TECH#20190228001
        select count(IFPKS_SV_CDC_CUSTOM.FN_GET_CARD_ID(BRANCH_CODE,
                                                        CUST_AC_NO))
          into L_CARD_COUNT
          from sttm_cust_account
         where ATM_FACILITY = 'Y'
           and cust_no = L_SV_CDC_DETAILS.PKEY_VALS;
        if (L_CARD_COUNT > 0) then
          ----------CHENGES END FOR TECH#20190228001
          DBG('ENTERED FOR STTM_CUST_PERSONAL');
          IF NOT FN_INS_CHG_CUST_DATA(L_SV_CDC_DETAILS.ID) THEN
            DBG('FAILED IN FN_INS_CHG_CUST_DATA');
            IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
              DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
            END IF;
          END IF;
          IF NOT FN_INS_CHG_CARD_INFO(L_SV_CDC_DETAILS.ID) THEN
            DBG('FAILED IN FN_INS_CHG_CARD_INFO');
            IF NOT FN_UPDATE_STATUS(L_SV_CDC_DETAILS.ID, 'E') THEN
              DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
            END IF;
          END IF;
          ----------CHANGES STARTS FOR TECH#20190228001
        else
          DBG('NO CARD ID SO DATA');
          IF NOT FN_UPDATE_ERR_STATUS(L_SV_CDC_DETAILS.ID,
                                      'E',
                                      'CARD ID IS NULL') THEN
            DBG('FAILED TO UPDATE STATUS FOR ' || L_SV_CDC_DETAILS.ID);
          END IF;
        end if;
        ----------CHENGES END FOR TECH#20190228001
      END IF;
      -- COMMIT;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT PR_PROCESS_GEN ' || SQLERRM);
    
  END PR_PROCESS_MSG_INS;

  FUNCTION FN_INS_CHG_ACC_STAT(P_ID  IFTB_SV_CDC_CUSTOM.ID%TYPE,
                               P_ATM IFTB_SV_CDC_CUSTOM.ATM_FACILITY%TYPE)
    RETURN BOOLEAN IS
    L_ACC      STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_XML_TYPE VARCHAR2(5);
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
  BEGIN
    DBG('ENTERED FOR FN_INS_CHG_ACC_STAT');
    L_XML_TYPE := FN_GET_XML_TYPE('CHG_ACC_STAT');
  
    BEGIN
      SELECT PKEY_VALS INTO L_ACC FROM IFTB_SV_CDC_CUSTOM WHERE ID = P_ID;
      DBG('ACCOUNT NUMBER PROCESSING IS' || L_ACC);
    
      L_PROD_ID := FN_GET_PROD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      L_CARD_ID := FN_GET_CARD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      /*  IF NOT FN_GET_CARD_PROD_ID(SUBSTR(L_ACC,1,3),SUBSTR(L_ACC,5),L_CARD_ID,L_PROD_ID) THEN */
      IF L_CARD_ID IS NULL OR L_PROD_ID IS NULL THEN
        DBG('FAILED TO FETCH CARD ID AND PROD ID');
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed while fetching card_id or prod id ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
      END IF;
    
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE,
         CUSTOMER_NO,
         CUST_AC_NO,
         BRANCH_CODE,
         ATM_FACILITY,
         CARD_ID,
         PROD_ID)
        SELECT L_XML_TYPE,
               CUST_NO,
               CUST_AC_NO,
               BRANCH_CODE,
               P_ATM,
               L_CARD_ID,
               L_PROD_ID
          FROM STTM_CUST_ACCOUNT Z
         WHERE CUST_AC_NO = SUBSTR(L_ACC, 5)
           AND BRANCH_CODE = SUBSTR(L_ACC, 1, 3);
    
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
    
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CHG_ACC_STAT RECORD FOR ' || L_ACC);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CHG_ACC_STAT RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CHG_ACC_STAT');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_CHG_ACC_STAT with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CHG_ACC_STAT;

  FUNCTION FN_GET_XML_TYPE(P_CODE IFTM_SV_CONFIG_CUSTOM.PARAM_NAME%TYPE)
    RETURN VARCHAR2 IS
    L_XML_TYPE VARCHAR2(5) := NULL;
  BEGIN
    DBG('ENTERED FOR FN_GET_XML_TYPE');
    SELECT PARAM_VAL
      INTO L_XML_TYPE
      FROM IFTM_SV_CONFIG_CUSTOM
     WHERE PARAM_NAME = P_CODE;
    RETURN L_XML_TYPE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_XML_TYPE');
      RETURN NULL;
  END FN_GET_XML_TYPE;

  FUNCTION FN_INS_ADD_NEW_CUST(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE)
    RETURN BOOLEAN IS
    L_ACC      IFTB_SV_CDC_CUSTOM.PKEY_VALS%TYPE;
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    L_XML_TYPE VARCHAR2(5);
    
    --Linking Multiple Cards At Account Level Changes starts
    L_CARD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_MASTER%TYPE;
    L_PROD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_MASTER%TYPE;
  
    L_CARD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_VISA%TYPE;
    L_PROD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_VISA%TYPE;
    
    L_CARD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_NBC%TYPE;
    L_PROD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_NBC%TYPE;
    --Linking Multiple Cards At Account Level Changes ends
    
  BEGIN
    DBG('ENTERED FOR FN_INS_ADD_NEW_CUST');
  
    BEGIN
      SELECT PKEY_VALS INTO L_ACC FROM IFTB_SV_CDC_CUSTOM WHERE ID = P_ID;
    
      L_XML_TYPE := FN_GET_XML_TYPE('ADD_NEW_CUST');
    
      DBG('ACCOUNT NUMBER PROCESSING IS BRN-' || SUBSTR(L_ACC, 1, 3) ||
          '  ~ACC-' || SUBSTR(L_ACC, 5));
    
      L_PROD_ID := FN_GET_PROD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      L_CARD_ID := FN_GET_CARD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      
      --Linking Multiple Cards At Account Level Changes starts
      
      
      L_PROD_ID_MASTER := FN_GET_PROD_ID_MASTER(SUBSTR(L_ACC, 1, 3),
                                                SUBSTR(L_ACC, 5));
      L_CARD_ID_MASTER := FN_GET_CARD_ID_MASTER(SUBSTR(L_ACC, 1, 3),
                                                SUBSTR(L_ACC, 5));
      
      DBG('L_PROD_ID_MASTER='||L_PROD_ID_MASTER);
      DBG('L_CARD_ID_MASTER='||L_CARD_ID_MASTER);
      
      L_PROD_ID_VISA := FN_GET_PROD_ID_VISA(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      L_CARD_ID_VISA := FN_GET_CARD_ID_VISA(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
                                            
      
      DBG('L_PROD_ID_VISA='||L_PROD_ID_VISA);
      DBG('L_CARD_ID_VISA='||L_CARD_ID_VISA);
      
      L_PROD_ID_NBC := FN_GET_PROD_ID_NBC(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      L_CARD_ID_NBC := FN_GET_CARD_ID_NBC(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      
      
      DBG('L_PROD_ID_NBC='||L_PROD_ID_NBC);
      DBG('L_CARD_ID_NBC='||L_CARD_ID_NBC);
      
      --Linking Multiple Cards At Account Level Changes ends
      
      /*  IF NOT FN_GET_CARD_PROD_ID(SUBSTR(L_ACC,1,3),SUBSTR(L_ACC,5),L_CARD_ID,L_PROD_ID) THEN */
      IF L_CARD_ID IS NULL OR L_PROD_ID IS NULL THEN
        DBG('FAILED TO FETCH CARD ID AND PROD ID');
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed while fetching card_id or prod id ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
      END IF;
    
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE,
         CUSTOMER_NO,
         FULL_NAME,
         ADDRESS_LINE1,
         ADDRESS_LINE3,
         ADDRESS_LINE2,
         ADDRESS_LINE4,
         COUNTRY,
         NATIONALITY,
         UNIQUE_ID_NAME,
         UNIQUE_ID_VALUE,
         STAFF,
         FIRST_NAME,
         MIDDLE_NAME,
         LAST_NAME,
         DATE_OF_BIRTH,
         E_MAIL,
         RESIDENT_STATUS,
         MOBILE_NUMBER,
         CUST_AC_NO,
         BRANCH_CODE,
         CCY,
         ACCOUNT_TYPE,
         CARD_ID,
         PROD_ID,
         CARD_ID_MASTER,  --Linking Multiple Cards At Account Level Changes added
         PROD_ID_MASTER,   --Linking Multiple Cards At Account Level Changes added
         CARD_ID_VISA,  --Linking Multiple Cards At Account Level Changes added
         PROD_ID_VISA,  --Linking Multiple Cards At Account Level Changes added
         CARD_ID_NBC, --Linking Multiple Cards At Account Level Changes added
         PROD_ID_NBC) --Linking Multiple Cards At Account Level Changes added
        SELECT L_XML_TYPE,
               X.CUSTOMER_NO,
               X.FULL_NAME,
               X.ADDRESS_LINE1,
               X.ADDRESS_LINE3,
               X.ADDRESS_LINE2,
               X.ADDRESS_LINE4,
               X.COUNTRY,
               X.NATIONALITY,
               X.UNIQUE_ID_NAME,
               X.UNIQUE_ID_VALUE,
               X.STAFF,
               Y.FIRST_NAME,
               Y.MIDDLE_NAME,
               Y.LAST_NAME,
               Y.DATE_OF_BIRTH,
               Y.E_MAIL,
               Y.RESIDENT_STATUS,
               Y.MOBILE_NUMBER,
               Z.CUST_AC_NO,
               Z.BRANCH_CODE,
               Z.CCY,
               Z.ACCOUNT_TYPE,
               L_CARD_ID,
               L_PROD_ID,
               L_CARD_ID_MASTER, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_MASTER, --Linking Multiple Cards At Account Level Changes added
               L_CARD_ID_VISA, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_VISA, --Linking Multiple Cards At Account Level Changes added
               L_CARD_ID_NBC, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_NBC --Linking Multiple Cards At Account Level Changes added
          FROM STTM_CUSTOMER X, STTM_CUST_PERSONAL Y, STTM_CUST_ACCOUNT Z
         WHERE X.CUSTOMER_NO = Y.CUSTOMER_NO
           AND X.CUSTOMER_NO = Z.CUST_NO
           AND Y.CUSTOMER_NO = Z.CUST_NO
           AND Z.CUST_AC_NO = SUBSTR(L_ACC, 5)
           AND Z.BRANCH_CODE = SUBSTR(L_ACC, 1, 3);
    
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT ADD_NEW_CUST RECORD FOR ' || L_ACC);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert ADD_NEW_CUST RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_ADD_NEW_CUST');
      IF NOT
          FN_UPDATE_ERR_STATUS(P_ID,
                               'E',
                               'Failed in FN_INS_ADD_NEW_CUST ' || sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_ADD_NEW_CUST;

  FUNCTION FN_INS_OPN_ADD_ACC(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE) RETURN BOOLEAN IS
    L_ACC      STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    L_XML_TYPE VARCHAR2(5);
    
     --Linking Multiple Cards At Account Level Changes starts
    L_CARD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_MASTER%TYPE;
    L_PROD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_MASTER%TYPE;
  
    L_CARD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_VISA%TYPE;
    L_PROD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_VISA%TYPE;
    
    L_CARD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_NBC%TYPE;
    L_PROD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_NBC%TYPE;
    --Linking Multiple Cards At Account Level Changes ends
    
  BEGIN
    DBG('ENTERED FOR FN_INS_OPN_ADD_ACC');
  
    BEGIN
      SELECT PKEY_VALS INTO L_ACC FROM IFTB_SV_CDC_CUSTOM WHERE ID = P_ID;
    
      L_XML_TYPE := FN_GET_XML_TYPE('OPN_ADD_ACC');
      DBG('ACCOUNT NUMBER PROCESSING IS BRN-' || SUBSTR(L_ACC, 1, 3) ||
          '  ~ACC-' || SUBSTR(L_ACC, 5));
    
      L_PROD_ID := FN_GET_PROD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      L_CARD_ID := FN_GET_CARD_ID(SUBSTR(L_ACC, 1, 3), SUBSTR(L_ACC, 5));
      
     --Linking Multiple Cards At Account Level Changes starts
      
      
      L_PROD_ID_MASTER := FN_GET_PROD_ID_MASTER(SUBSTR(L_ACC, 1, 3),
                                                SUBSTR(L_ACC, 5));
      L_CARD_ID_MASTER := FN_GET_CARD_ID_MASTER(SUBSTR(L_ACC, 1, 3),
                                                SUBSTR(L_ACC, 5));
      
      DBG('L_PROD_ID_MASTER='||L_PROD_ID_MASTER);
      DBG('L_CARD_ID_MASTER='||L_CARD_ID_MASTER);
      
      L_PROD_ID_VISA := FN_GET_PROD_ID_VISA(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      L_CARD_ID_VISA := FN_GET_CARD_ID_VISA(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
                                            
      
      DBG('L_PROD_ID_VISA='||L_PROD_ID_VISA);
      DBG('L_CARD_ID_VISA='||L_CARD_ID_VISA);
      
      L_PROD_ID_NBC := FN_GET_PROD_ID_NBC(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      L_CARD_ID_NBC := FN_GET_CARD_ID_NBC(SUBSTR(L_ACC, 1, 3),
                                            SUBSTR(L_ACC, 5));
      
      
      DBG('L_PROD_ID_NBC='||L_PROD_ID_NBC);
      DBG('L_CARD_ID_NBC='||L_CARD_ID_NBC);
      
      --Linking Multiple Cards At Account Level Changes ends      
      
      /*  IF NOT FN_GET_CARD_PROD_ID(SUBSTR(L_ACC,1,3),SUBSTR(L_ACC,5),L_CARD_ID,L_PROD_ID) THEN */
      IF L_CARD_ID IS NULL OR L_PROD_ID IS NULL THEN
        DBG('FAILED TO FETCH CARD ID AND PROD ID');
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed while fetching card_id or prod id ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
      END IF;
    
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE,
         CUSTOMER_NO,
         FULL_NAME,
         FIRST_NAME,
         MIDDLE_NAME,
         LAST_NAME,
         DATE_OF_BIRTH,
         E_MAIL,
         RESIDENT_STATUS,
         MOBILE_NUMBER,
         CUST_AC_NO,
         UNIQUE_ID_NAME,
         UNIQUE_ID_VALUE,
         BRANCH_CODE,
         CCY,
         ACCOUNT_TYPE,
         CARD_ID,
         PROD_ID,
         CARD_ID_MASTER,  --Linking Multiple Cards At Account Level Changes added
         PROD_ID_MASTER,   --Linking Multiple Cards At Account Level Changes added
         CARD_ID_VISA,  --Linking Multiple Cards At Account Level Changes added
         PROD_ID_VISA,  --Linking Multiple Cards At Account Level Changes added
         CARD_ID_NBC, --Linking Multiple Cards At Account Level Changes added
         PROD_ID_NBC) --Linking Multiple Cards At Account Level Changes added)
        SELECT L_XML_TYPE,
               X.CUSTOMER_NO,
               X.FULL_NAME,
               Y.FIRST_NAME,
               Y.MIDDLE_NAME,
               Y.LAST_NAME,
               Y.Date_Of_Birth,
               Y.E_MAIL,
               Y.RESIDENT_STATUS,
               Y.MOBILE_NUMBER,
               Z.CUST_AC_NO,
               X.UNIQUE_ID_NAME,
               X.UNIQUE_ID_VALUE,
               Z.BRANCH_CODE,
               Z.CCY,
               Z.ACCOUNT_TYPE,
               L_CARD_ID,
               L_PROD_ID,
               L_CARD_ID_MASTER, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_MASTER, --Linking Multiple Cards At Account Level Changes added
               L_CARD_ID_VISA, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_VISA, --Linking Multiple Cards At Account Level Changes added
               L_CARD_ID_NBC, --Linking Multiple Cards At Account Level Changes added
               L_PROD_ID_NBC --Linking Multiple Cards At Account Level Changes added
          FROM STTM_CUSTOMER X, STTM_CUST_PERSONAL Y, STTM_CUST_ACCOUNT Z
         WHERE X.CUSTOMER_NO = Y.CUSTOMER_NO
           AND X.CUSTOMER_NO = Z.CUST_NO
           AND Y.CUSTOMER_NO = Z.CUST_NO
           AND Z.CUST_AC_NO = SUBSTR(L_ACC, 5)
           AND Z.BRANCH_CODE = SUBSTR(L_ACC, 1, 3);
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT OPN_ADD_ACC RECORD FOR ' || L_ACC);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert OPN_ADD_ACC RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_OPN_ADD_ACC');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_OPN_ADD_ACC with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_OPN_ADD_ACC;

  FUNCTION FN_INS_CLO_CUST_ACC(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE)
    RETURN BOOLEAN IS
    L_ACC      STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_XML_TYPE VARCHAR2(5);
  BEGIN
    DBG('ENTERED FOR FN_INS_CLO_CUST_ACC');
    L_XML_TYPE := FN_GET_XML_TYPE('CLO_CUST_ACC');
  
    BEGIN
      SELECT PKEY_VALS INTO L_ACC FROM IFTB_SV_CDC_CUSTOM WHERE ID = P_ID;
    
      DBG('ACCOUNT NUMBER PROCESSING IS' || L_ACC);
    
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE, CUSTOMER_NO, CUST_AC_NO, BRANCH_CODE) --ADDED FOR AGENT NUM AS BRANCH_CODE)
        SELECT L_XML_TYPE, CUST_NO, CUST_AC_NO, BRANCH_CODE
          FROM STTM_CUST_ACCOUNT Z
         WHERE CUST_AC_NO = SUBSTR(L_ACC, 5)
           AND BRANCH_CODE = SUBSTR(L_ACC, 1, 3);
    
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CLO_CUST_ACC RECORD FOR ' || L_ACC);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CLO_CUST_ACC RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CLO_CUST_ACC');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_CLO_CUST_ACC with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CLO_CUST_ACC;

  FUNCTION FN_UPDATE_STATUS(P_ID     IFTB_SV_CDC_CUSTOM.ID%TYPE,
                            P_STATUS IFTB_SV_CDC_CUSTOM.STATUS%TYPE)
    RETURN BOOLEAN IS
    L_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  BEGIN
    
    DBG('WHO CALLED ME='||DBMS_UTILITY.format_call_stack);
    DBG('ENTERED FOR FN_UPDATE_STATUS');
  
    BEGIN
      UPDATE IFTB_SV_CDC_CUSTOM SET STATUS = P_STATUS WHERE ID = P_ID;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || L_ACC);
        IF NOT
            FN_UPDATE_ERR_STATUS(P_ID,
                                 'E',
                                 'Faile in updating the status ' || sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  END FN_UPDATE_STATUS;

  FUNCTION FN_UPDATE_ERR_STATUS(P_ID        IFTB_SV_CDC_CUSTOM.ID%TYPE,
                                P_STATUS    IFTB_SV_CDC_CUSTOM.STATUS%TYPE,
                                P_ERR_PARAM VARCHAR2) RETURN BOOLEAN IS
    L_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  BEGIN
    DBG('ENTERED FOR FN_UPDATE_STATUS');
  
    BEGIN
      UPDATE IFTB_SV_CDC_CUSTOM
         SET STATUS = P_STATUS, ERR_PARAM = P_ERR_PARAM
       WHERE ID = P_ID;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || L_ACC);
        IF NOT
            FN_UPDATE_ERR_STATUS(P_ID,
                                 'E',
                                 'Failed to update the status 2 ' || sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  END FN_UPDATE_ERR_STATUS;

  FUNCTION FN_INS_CHG_CUST_DATA(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE)
    RETURN BOOLEAN IS
    L_CUSTOMER STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_XML_TYPE VARCHAR2(5);
  BEGIN
    DBG('ENTERED FOR FN_INS_CHG_CUST_DATA');
    L_XML_TYPE := FN_GET_XML_TYPE('CHG_CUST_DATA');
  
    BEGIN
      SELECT PKEY_VALS
        INTO L_CUSTOMER
        FROM IFTB_SV_CDC_CUSTOM
       WHERE ID = P_ID;
    
      DBG('CUSTOMER NUMBER PROCESSING IS' || L_CUSTOMER);
    
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE,
         CUSTOMER_NO,
         FULL_NAME,
         ADDRESS_LINE1,
         ADDRESS_LINE3,
         ADDRESS_LINE2,
         ADDRESS_LINE4,
         COUNTRY,
         NATIONALITY,
         UNIQUE_ID_NAME,
         UNIQUE_ID_VALUE,
         STAFF,
         FIRST_NAME,
         MIDDLE_NAME,
         LAST_NAME,
         RESIDENT_STATUS,
         MOBILE_NUMBER,
         BRANCH_CODE) --ADDED FOR AGENT NUM AS BRANCH_CODE
        SELECT L_XML_TYPE,
               X.CUSTOMER_NO,
               X.FULL_NAME,
               X.ADDRESS_LINE1,
               X.ADDRESS_LINE3,
               X.ADDRESS_LINE2,
               X.ADDRESS_LINE4,
               X.COUNTRY,
               X.NATIONALITY,
               X.UNIQUE_ID_NAME,
               X.UNIQUE_ID_VALUE,
               X.STAFF,
               Y.FIRST_NAME,
               Y.MIDDLE_NAME,
               Y.LAST_NAME,
               Y.RESIDENT_STATUS,
               Y.MOBILE_NUMBER,
               X.LOCAL_BRANCH
          FROM STTM_CUSTOMER X, STTM_CUST_PERSONAL Y
         WHERE X.CUSTOMER_NO = Y.CUSTOMER_NO
           AND X.CUSTOMER_NO = L_CUSTOMER;
    
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CHG_CUST_DATA RECORD FOR ' || L_CUSTOMER);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CHG_CUST_DATA RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CHG_CUST_DATA');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_CHG_CUST_DATA with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CHG_CUST_DATA;

  FUNCTION FN_INS_CHG_CARD_INFO(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE)
    RETURN BOOLEAN IS
    L_CUSTOMER STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    L_XML_TYPE VARCHAR2(5);
  BEGIN
    DBG('ENTERED FOR FN_INS_CHG_CARD_INFO');
    L_XML_TYPE := FN_GET_XML_TYPE('CHG_CARD_INFO');
  
    BEGIN
      SELECT PKEY_VALS
        INTO L_CUSTOMER
        FROM IFTB_SV_CDC_CUSTOM
       WHERE ID = P_ID;
    
      DBG('CUSTOMER NUMBER PROCESSING IS' || L_CUSTOMER);
    
      /*FOR REC IN (SELECT DISTINCT FIELD_VAL_10,FIELD_VAL_11 FROM CSTM_FUNCTION_USERDEF_FIELDS VV WHERE
      VV.REC_KEY IN(SELECT
      BRANCH_CODE||'~'||CUST_AC_NO||'~' FROM STTM_CUST_ACCOUNT WHERE ATM_FACILITY='Y' AND RECORD_STAT='O' AND  CUST_NO =L_CUSTOMER)) LOOP */
      FOR REC IN (SELECT BRANCH_CODE, CUST_AC_NO
                    FROM STTM_CUST_ACCOUNT
                   WHERE ATM_FACILITY = 'Y'
                     AND RECORD_STAT = 'O'
                     AND CUST_NO = L_CUSTOMER) LOOP
      
        L_PROD_ID := FN_GET_PROD_ID(REC.BRANCH_CODE, REC.CUST_AC_NO);
        L_CARD_ID := FN_GET_CARD_ID(REC.BRANCH_CODE, REC.CUST_AC_NO);
      
        INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
          (XML_TYPE,
           CUSTOMER_NO,
           FULL_NAME,
           ADDRESS_LINE1,
           ADDRESS_LINE3,
           ADDRESS_LINE2,
           ADDRESS_LINE4,
           COUNTRY,
           UNIQUE_ID_NAME,
           UNIQUE_ID_VALUE,
           STAFF,
           FIRST_NAME,
           MIDDLE_NAME,
           LAST_NAME,
           MOBILE_NUMBER,
           CARD_ID,
           PROD_ID,
           BRANCH_CODE) --ADDED FOR AGENET NUM AS BRANCH_CODE
          SELECT L_XML_TYPE,
                 X.CUSTOMER_NO,
                 X.FULL_NAME,
                 X.ADDRESS_LINE1,
                 X.ADDRESS_LINE3,
                 X.ADDRESS_LINE2,
                 X.ADDRESS_LINE4,
                 X.COUNTRY,
                 X.UNIQUE_ID_NAME,
                 X.UNIQUE_ID_VALUE,
                 X.STAFF,
                 Y.FIRST_NAME,
                 Y.MIDDLE_NAME,
                 Y.LAST_NAME,
                 Y.MOBILE_NUMBER,
                 L_CARD_ID,
                 L_PROD_ID,
                 X.LOCAL_BRANCH
            FROM STTM_CUSTOMER X, STTM_CUST_PERSONAL Y
           WHERE X.CUSTOMER_NO = Y.CUSTOMER_NO
             AND X.CUSTOMER_NO = L_CUSTOMER;
        IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
      
      END LOOP;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CHG_CARD_INFO RECORD FOR ' || L_CUSTOMER);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CHG_CARD_INFO RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CHG_CARD_INFO');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_CHG_CARD_INFO with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CHG_CARD_INFO;

  FUNCTION FN_INS_CLO_CUST_CARD(P_ID IFTB_SV_CDC_CUSTOM.ID%TYPE)
    RETURN BOOLEAN IS
    L_CUSTOMER STTM_CUSTOMER.CUSTOMER_NO%TYPE;
    L_CARD_ID  IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_XML_TYPE VARCHAR2(5);
  BEGIN
    DBG('ENTERED FOR FN_INS_CLO_CUST_CARD');
    L_XML_TYPE := FN_GET_XML_TYPE('CLO_CUST_CARD');
  
    BEGIN
      SELECT PKEY_VALS
        INTO L_CUSTOMER
        FROM IFTB_SV_CDC_CUSTOM
       WHERE ID = P_ID;
    
      DBG('CUSTOMER NUMBER PROCESSING IS' || L_CUSTOMER);
      /*FOR REC IN (SELECT DISTINCT FIELD_VAL_10,FIELD_VAL_11 FROM CSTM_FUNCTION_USERDEF_FIELDS VV WHERE
      VV.REC_KEY IN(SELECT
      BRANCH_CODE||'~'||CUST_AC_NO||'~' FROM STTM_CUST_ACCOUNT WHERE ATM_FACILITY='Y' AND RECORD_STAT='O' AND  CUST_NO =L_CUSTOMER)) LOOP */
      FOR REC IN (SELECT BRANCH_CODE, CUST_AC_NO
                    FROM STTM_CUST_ACCOUNT
                   WHERE ATM_FACILITY = 'Y'
                     AND RECORD_STAT = 'O'
                     AND CUST_NO = L_CUSTOMER) LOOP
      
        L_CARD_ID := FN_GET_CARD_ID(REC.BRANCH_CODE, REC.CUST_AC_NO);
      
        INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
          (XML_TYPE, CUSTOMER_NO, CARD_ID)
          SELECT L_XML_TYPE, X.CUSTOMER_NO, L_CARD_ID
            FROM STTM_CUSTOMER X
           WHERE X.CUSTOMER_NO = L_CUSTOMER;
      
        IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
      END LOOP;
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CLO_CUST_CARD RECORD FOR ' || L_CUSTOMER);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CLO_CUST_CARD RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CLO_CUST_CARD');
      IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                  'E',
                                  'Failed in FN_INS_CLO_CUST_CARD with ' ||
                                  sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CLO_CUST_CARD;

  FUNCTION FN_GET_CARD_ID(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                          P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL     VARCHAR2(200);
    L_NUM     NUMBER;
    L_CARD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_CARD_ID');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'CARD_ID';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_CARD_ID;
    DBG('L_CARD_ID ' || L_CARD_ID);
  
    DBG('done');
    RETURN L_CARD_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_CARD_ID' || SQLERRM);
      RETURN L_CARD_ID;
  END FN_GET_CARD_ID;
  
  --Linking Multiple Cards At Account Level Changes starts
  FUNCTION FN_GET_CARD_ID_MASTER(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                                 P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL            VARCHAR2(200);
    L_NUM            NUMBER;
    L_CARD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_MASTER%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_CARD_ID_MASTER');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'CARD_ID_MASTER';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_CARD_ID_MASTER;
    DBG('L_CARD_ID_MASTER ' || L_CARD_ID_MASTER);
  
    DBG('done');
    RETURN L_CARD_ID_MASTER;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_CARD_ID_MASTER' || SQLERRM);
      RETURN L_CARD_ID_MASTER;
  END FN_GET_CARD_ID_MASTER;

  FUNCTION FN_GET_CARD_ID_VISA(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                               P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL          VARCHAR2(200);
    L_NUM          NUMBER;
    L_CARD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_VISA%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_CARD_ID_VISA');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'CARD_ID_VISA';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_CARD_ID_VISA;
    DBG('L_CARD_ID_VISA ' || L_CARD_ID_VISA);
  
    DBG('done');
    RETURN L_CARD_ID_VISA;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_CARD_ID_VISA' || SQLERRM);
      RETURN L_CARD_ID_VISA;
  END FN_GET_CARD_ID_VISA;
  
  FUNCTION FN_GET_CARD_ID_NBC(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                                 P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL            VARCHAR2(200);
    L_NUM            NUMBER;
    L_CARD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID_NBC%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_CARD_ID_NBC');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'CARD_ID_NBC';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_CARD_ID_NBC;
    DBG('L_CARD_ID_NBC ' || L_CARD_ID_NBC);
  
    DBG('done');
    RETURN L_CARD_ID_NBC;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_CARD_ID_NBC' || SQLERRM);
      RETURN L_CARD_ID_NBC;
  END FN_GET_CARD_ID_NBC;
  --Linking Multiple Cards At Account Level Changes ends

  FUNCTION FN_GET_PROD_ID(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                          P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL     VARCHAR2(200);
    L_NUM     NUMBER;
    L_PROD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_PROD_ID');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'PROD_ID';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_PROD_ID;
    DBG('L_PROD_ID ' || L_PROD_ID);
  
    DBG('done');
    RETURN L_PROD_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PROD_ID' || SQLERRM);
      RETURN L_PROD_ID;
  END FN_GET_PROD_ID;
  
  --Linking Multiple Cards At Account Level Changes starts
  FUNCTION FN_GET_PROD_ID_MASTER(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                                 P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL            VARCHAR2(200);
    L_NUM            NUMBER;
    L_PROD_ID_MASTER IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_MASTER%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_PROD_ID_MASTER');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'PROD_ID_MASTER';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_PROD_ID_MASTER;
    DBG('L_PROD_ID_MASTER ' || L_PROD_ID_MASTER);
  
    DBG('done');
    RETURN L_PROD_ID_MASTER;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PROD_ID' || SQLERRM);
      RETURN L_PROD_ID_MASTER;
  END FN_GET_PROD_ID_MASTER;

  FUNCTION FN_GET_PROD_ID_VISA(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                               P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL          VARCHAR2(200);
    L_NUM          NUMBER;
    L_PROD_ID_VISA IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_VISA%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_PROD_ID_VISA');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'PROD_ID_VISA';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_PROD_ID_VISA;
    DBG('L_PROD_ID_VISA ' || L_PROD_ID_VISA);
  
    DBG('done');
    RETURN L_PROD_ID_VISA;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PROD_ID' || SQLERRM);
      RETURN L_PROD_ID_VISA;
  END FN_GET_PROD_ID_VISA;
  
  
  FUNCTION FN_GET_PROD_ID_NBC(P_BRN IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.BRANCH_CODE%TYPE,
                                 P_ACC IN IFTB_SVCARD_CUSTDETAILS_CUSTOM.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
  
    L_SQL            VARCHAR2(200);
    L_NUM            NUMBER;
    L_PROD_ID_NBC IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID_NBC%TYPE := NULL;
  BEGIN
    DBG('entered IN FN_GET_PROD_ID_NBC');
    DBG('entered IN branch' || P_BRN);
    DBG('entered IN account ' || P_ACC);
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = 'PROD_ID_NBC';
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'SELECT field_val_' || L_NUM ||
             ' FROM CSTM_FUNCTION_USERDEF_FIELDS
                WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' ||
             CHR(39) || ' and rec_key=' || CHR(39) || P_BRN || '~' || P_ACC || '~' ||
             CHR(39) || '';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL
      INTO L_PROD_ID_NBC;
    DBG('L_PROD_ID_NBC ' || L_PROD_ID_NBC);
  
    DBG('done');
    RETURN L_PROD_ID_NBC;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_PROD_ID' || SQLERRM);
      RETURN L_PROD_ID_NBC;
  END FN_GET_PROD_ID_NBC;
  --Linking Multiple Cards At Account Level Changes ends

  FUNCTION FN_INS_CCY_RATE(P_ID       IFTB_SV_CDC_CUSTOM.ID%TYPE,
                           P_KEY_VALS IFTB_SV_CDC_CUSTOM.PKEY_VALS%TYPE)
    RETURN BOOLEAN IS
    L_ACC      STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
    L_XML_TYPE VARCHAR2(5);
  BEGIN
    DBG('ENTERED FOR FN_INS_CCY_RATE');
    L_XML_TYPE := FN_GET_XML_TYPE('CCY_RATE');
  
    BEGIN
      INSERT INTO IFTB_SVCARD_CUSTDETAILS_CUSTOM
        (XML_TYPE,
         CY_BRANCH_CODE,
         SRC_CCY,
         DEST_CCY,
         RATE_TYPE,
         MID_RATE,
         BUY_RATE,
         SALE_RATE,
         RATE_DATE,
         RATE_SERIAL)
        SELECT L_XML_TYPE,
               BRANCH_CODE,
               CCY1,
               CCY2,
               RATE_TYPE,
               MID_RATE,
               BUY_RATE,
               SALE_RATE,
               RATE_DATE,
               RATE_SERIAL
          FROM CYTM_RATES
         WHERE BRANCH_CODE = SUBSTR(P_KEY_VALS, 1, 3)
           AND CCY1 = SUBSTR(P_KEY_VALS, 5, 3)
           AND CCY2 = SUBSTR(P_KEY_VALS, 9, 3)
           AND RATE_TYPE = SUBSTR(P_KEY_VALS, 13);
    
      IF NOT FN_UPDATE_STATUS(P_ID, 'S') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
    
      RETURN TRUE;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED TO INSERT CCY_RATE RECORD FOR ' || L_ACC);
        IF NOT FN_UPDATE_ERR_STATUS(P_ID,
                                    'E',
                                    'Failed to Insert CCY_RATE RECORD with ' ||
                                    sqlerrm) THEN
          DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
        END IF;
        RETURN FALSE;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_INS_CCY_RATE');
      IF NOT
          FN_UPDATE_ERR_STATUS(P_ID,
                               'E',
                               'Failed in FN_INS_CCY_RATE ' || sqlerrm) THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_INS_CCY_RATE;
END IFPKS_SV_CDC_CUSTOM;
