-- Create table
create table IFTB_MULTIACLINK_INC_TRACK
(
  app_id      VARCHAR2(35) not null,
  file_date   DATE,
  request_msg CLOB,
  status      CHAR(1),
  time_in     DATE,
  cust_ac_no  VARCHAR2(35),
  card_id     VARCHAR2(35),
  product_id  VARCHAR2(35),
  card_type   VARCHAR2(35)
)
/
alter table IFTB_MULTIACLINK_INC_TRACK
  add primary key (APP_ID)
/

