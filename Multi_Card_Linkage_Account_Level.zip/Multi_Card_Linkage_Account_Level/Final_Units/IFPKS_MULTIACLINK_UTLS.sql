CREATE OR REPLACE PACKAGE BODY IFPKS_MULTIACLINK_UTLS IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_MULTIACLINK_UTLS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  PROCEDURE PR_RETURN_COSMETIC_XML(P_XML          IN VARCHAR2,
                                   P_COSMETIC_XML OUT VARCHAR2) IS
  
    --P_COSMETIC_XML VARCHAR2(32000);
  
  BEGIN
  
    P_COSMETIC_XML := P_XML;
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns="http://sv.bpc.in/SVAP"><?xml version="1.0" encoding="UTF-8"?',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              ' xmlns="http://sv.bpc.in/SVAP"',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML,
                              '<?xml version="1.0" encoding="UTF-8"?>',
                              NULL);
  
    P_COSMETIC_XML := REPLACE(P_COSMETIC_XML, ' id="card_1"', NULL);
  
  END PR_RETURN_COSMETIC_XML;

  PROCEDURE PR_UPDATE_UDF_VAL(P_AC_NO      IN VARCHAR2,
                              P_FIELD_NAME IN VARCHAR2,
                              P_VAL        IN VARCHAR2) IS
  
    L_SQL       VARCHAR2(200);
    L_NUM       NUMBER;
    L_FIELD_VAL VARCHAR2(2000) := NULL;
  BEGIN
    DBG('Entered IN PR_UPDATE_UDF_VAL');
  
    SELECT FIELD_NUM
      INTO L_NUM
      FROM CSTM_FUNCTION_UDF_FIELDS_MAP
     WHERE FUNCTION_ID = 'STDCUSAC'
       AND FIELD_NAME = P_FIELD_NAME;
  
    DBG('L_NUM ' || L_NUM);
  
    L_SQL := 'UPDATE CSTM_FUNCTION_USERDEF_FIELDS SET field_val_' || L_NUM ||
             ' = ' || CHR(39) || P_VAL || CHR(39) ||
             '  WHERE FUNCTION_ID =' || CHR(39) || 'STDCUSAC' || CHR(39) ||
             ' and rec_key=' || CHR(39) || P_AC_NO || '~''';
  
    DBG('L_SQL ' || L_SQL);
  
    EXECUTE IMMEDIATE L_SQL;
  
    DBG('done');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_UPDATE_UDF_VAL' || SQLERRM);
    
  END PR_UPDATE_UDF_VAL;

  /*FUNCTION FN_GET_APP_ID(P_REQUEST_MSG IN CLOB) RETURN VARCHAR2 IS
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
    L_APP_ID           VARCHAR2(100);
  BEGIN
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_APP_ID := P_DOCUMENT_XML.EXTRACT('/payment_orders/inst_id/text()')
                .GETSTRINGVAL;
  
    DBG('L_APP_ID=' || L_APP_ID);
  
    RETURN L_APP_ID;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING FN_GET_INST_ID');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      RETURN L_APP_ID;
  END FN_GET_APP_ID;*/

  FUNCTION FN_GET_PARAMS RETURN CSTB_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(CSTB_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT *
      INTO G_CSTB_PARAMS
      FROM CSTB_PARAM_CUSTOM
     WHERE PARAM_NAME = 'AUTO_MULTIACLINK_PRM';
    DBG('Returing from FN_GET_PARAMS');
    RETURN G_CSTB_PARAMS;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_cstb_params := NULL;
      RETURN g_cstb_params;
  END;

  PROCEDURE PR_PROCESS_MULTIAC_APP_ID IS
  
    CURSOR C1 IS
      SELECT * FROM IFTB_MULTIACLINK_INC_TRACK WHERE STATUS IN ('U');
  
  BEGIN
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        UPDATE STTM_CUST_ACCOUNT
           SET ATM_FACILITY = 'Y'
         WHERE CUST_AC_NO = G.CUST_AC_NO
           AND ATM_FACILITY = 'N';
      
        --Update CARD ID UDF Value
        PR_UPDATE_UDF_VAL(G.CUST_AC_NO, 'CARD_ID', G.CARD_ID);
      
        --Update PROD ID UDF Value
        PR_UPDATE_UDF_VAL(G.CUST_AC_NO, 'PROD_ID', G.PRODUCT_ID);
      
        --update status in the incoming table also
        UPDATE IFTB_MULTIACLINK_INC_TRACK
           SET STATUS = 'P'
         WHERE APP_ID = G.APP_ID;
      
      EXCEPTION
        WHEN OTHERS THEN
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE IN PR_PROCESS_MULTIAC_APP_ID=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_MULTIAC_APP_ID=' || SQLERRM);
    
  END PR_PROCESS_MULTIAC_APP_ID;

  PROCEDURE PR_MULTIACLINK_INC_HANDOFF(P_REQ_MSG   IN XMLTYPE,
                                       P_FILE_NAME IN VARCHAR2) IS
  
    L_RESPONSE VARCHAR2(32767);
  
    L_START              NUMBER := 1;
    L_END                NUMBER := 0;
    L_NO_OF_APPLICATIONS NUMBER := 0;
    L_APP                CLOB;
    L_APP_ID             VARCHAR2(100);
  
    P_REQ_MSG_CLOB CLOB;
    L_SEQ          VARCHAR2(100);
  
  BEGIN
  
    --GLOBAL.PR_INIT('SYSTEM', '001');
  
    DBG('START OF PR_MULTIACLINK_INC_HANDOFF');
  
    P_REQ_MSG_CLOB := P_REQ_MSG.getClobVal();
  
    --DBG('P_REQ_MSG_CLOB=' || P_REQ_MSG_CLOB);
  
    --L_APP_ID := FN_GET_APP_ID(P_REQ_MSG_CLOB);
  
    --SEQUENCE GENERATION FOR APP ID
    SELECT FC_GEN_MULTICARD_AC_LINK_SEQ.NEXTVAL INTO L_SEQ FROM DUAL;
  
    L_APP_ID := SUBSTR(TO_CHAR(SYSDATE, 'YYMM'), 2) || LPAD(L_SEQ, 9, '0');
  
    DBG('L_APP_ID=' || L_APP_ID);
  
    L_NO_OF_APPLICATIONS := (LENGTH(P_REQ_MSG_CLOB) -
                            LENGTH(REPLACE(P_REQ_MSG_CLOB,
                                            '</application>',
                                            ''))) /
                            length('</application>');
  
    DBG('L_NO_OF_APPLICATIONS=' || L_NO_OF_APPLICATIONS);
  
    FOR G IN 1 .. L_NO_OF_APPLICATIONS LOOP
    
      DBG('G value=' || G);
      DBG('BEGIN L_START=' || L_START);
      DBG('BEGIN L_END=' || L_END);
    
      L_START := INSTR(P_REQ_MSG_CLOB, '<application>', L_START, G);
      L_END   := INSTR(P_REQ_MSG_CLOB, '</application>', L_START, 1);
    
      DBG('AFTER L_START=' || L_START);
      DBG('AFTER L_END=' || L_END);
    
      --DBMS_OUTPUT.PUT_LINE('FINAL SUB END=' || L_END - L_START + LENGTH('</payment_order>'));
    
      L_APP := SUBSTR(P_REQ_MSG_CLOB,
                      L_START,
                      L_END - L_START + LENGTH('</application>'));
    
      --DBMS_OUTPUT.PUT_LINE('L_PAY_ORDER=' || L_PAY_ORDER);
    
      PR_INSERT_MULTIACLINK_TRACKER(L_APP_ID,
                                    -- L_FILE_DATE,
                                    --L_FILE_NUMBER,
                                    L_APP,
                                    P_FILE_NAME);
    
      L_START := 1;
    
      DBG('-------------------');
    
    END LOOP;
  
    DBG('DONE WITH HANDOFF');
  
    -- RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      -- RETURN FALSE;
  END PR_MULTIACLINK_INC_HANDOFF;

  PROCEDURE PR_INSERT_MULTIACLINK_TRACKER(P_APP_ID IN VARCHAR2,
                                          --P_FILE_DATE   IN VARCHAR2,
                                          --P_FILE_NO     IN VARCHAR2,
                                          P_REQUEST_MSG IN CLOB,
                                          P_FILE_NAME   IN VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    L_COSMETIC_RES_MSG CLOB;
    P_DOCUMENT_XML     XMLTYPE;
  
    L_APP_ID IFTM_AUTO_DEBIT_PAYMENT_REQ.ORDER_ID%TYPE;
  
    L_AC_NO STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE;
  
    L_CARD_ID IFTB_MULTIACLINK_INC_TRACK.CARD_ID%TYPE;
  
    L_PRODUCT_ID IFTB_MULTIACLINK_INC_TRACK.PRODUCT_ID%TYPE;
  
    L_CARD_TYPE IFTB_MULTIACLINK_INC_TRACK.CARD_TYPE%TYPE;
  
    L_CARD_AC_NO IFTB_MULTIACLINK_INC_TRACK.CUST_AC_NO%TYPE;
  
    L_COUNT NUMBER;
  
  BEGIN
  
    DBG('BEFORE START OF PR_INSERT_MULTIACLINK_TRACKER');
  
    PR_RETURN_COSMETIC_XML(P_REQUEST_MSG, L_COSMETIC_RES_MSG);
  
    DBG('L_COSMETIC_RES_MSG=' || L_COSMETIC_RES_MSG);
  
    P_DOCUMENT_XML := XMLTYPE(L_COSMETIC_RES_MSG);
  
    L_CARD_ID := P_DOCUMENT_XML.EXTRACT('/application/customer/contract/card/card_id/text()')
                 .GETSTRINGVAL;
  
    DBG('L_CARD_ID=' || L_CARD_ID);
  
    L_PRODUCT_ID := P_DOCUMENT_XML.EXTRACT('/application/customer/contract/product_id/text()')
                    .GETSTRINGVAL;
  
    DBG('L_PRODUCT_ID=' || L_PRODUCT_ID);
  
    IF L_PRODUCT_ID IN
       ('70000279', '70000276', '70000277', '70000270', '70000320') THEN
    
      L_CARD_TYPE := 'M';
    
    ELSIF L_PRODUCT_ID IN
          ('70000282', '70000281', '70000284', '70000283', '70000321') THEN
    
      L_CARD_TYPE := 'V';
    
    ELSIF L_PRODUCT_ID IN
          ('70000312', '70000313', '70000315', '70000316', '70000317') THEN
    
      L_CARD_TYPE := 'C';
    
    END IF;
  
    DBG('L_CARD_TYPE=' || L_CARD_TYPE);
  
    --Check if above APP ID already available
    BEGIN
      SELECT COUNT(1)
        INTO L_COUNT
      
        FROM IFTB_MULTIACLINK_INC_TRACK
       WHERE APP_ID = P_APP_ID;
      -- AND STATUS = 'P';
    EXCEPTION
      WHEN OTHERS THEN
        L_COUNT := 0;
    END;
  
    IF L_COUNT = 0 THEN
      INSERT INTO IFTB_MULTIACLINK_INC_TRACK
        (APP_ID,
         FILE_DATE,
         REQUEST_MSG,
         STATUS,
         TIME_IN,
         CUST_AC_NO,
         CARD_ID,
         PRODUCT_ID,
         CARD_TYPE)
      VALUES
        (P_APP_ID,
         SYSDATE,
         P_REQUEST_MSG,
         'U',
         SYSDATE,
         L_AC_NO,
         L_CARD_ID,
         L_PRODUCT_ID,
         L_CARD_TYPE);
    
    END IF;
  
    DBG('AFTER INSERTING INTO PR_INSERT_MULTIACLINK_TRACKER');
    DBG('COMMITTING');
    COMMIT;
    DBG('RETURNING SUCCESSFULLY FROM PR_INSERT_MULTIACLINK_TRACKER');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INSERT_MULTIACLINK_TRACKER');
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
    
  END PR_INSERT_MULTIACLINK_TRACKER;

  PROCEDURE PR_INIT_MSG IS
    FILE      VARCHAR2(32767);
    FILE_NAME VARCHAR2(100);
    FPATH     VARCHAR2(1000);
  BEGIN
    --global.pr_init('000', 'SYSTEM');
  
    DBG('entered  ');
    g_cstb_params := FN_GET_PARAMS;
    DBG('Income path :' || g_cstb_params.PARAM_VAL);
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_cstb_params.PARAM_VAL;
  
    DBG('FPATH  - ' || FPATH);
    FILE_NAME := FN_READ_MULTICARD_AC_LINK('/u01/fcubs/interfaces/MultiAcLink/Incoming/ready');
    DBG('FILE_NAME  - ' || FILE_NAME);
  
    PR_MOVE_FILE(FILE_NAME);
    DBG('Success  ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_MOVE_FILE(P_FILE_NAME IN VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN
  
    --GLOBAL.PR_INIT('002', 'SYSTEM');
  
    DBG('INSIDE PR_MOVE_FILE=' || P_FILE_NAME);
  
    IF P_FILE_NAME IS NOT NULL THEN
      UTL_FILE.FRENAME('AUTO_MULTIACLINK_DIR_READY',
                       P_FILE_NAME,
                       'AUTO_MULTIACLINK_DIR_WIP',
                       P_FILE_NAME,
                       TRUE);
      DBG('moved to wip');
      DBG('File name: ' || P_FILE_NAME);
    
      SELECT XMLTYPE(BFILENAME('AUTO_MULTIACLINK_DIR_WIP', P_FILE_NAME),
                     NLS_CHARSET_ID('AL32UTF16'))
        INTO L_XML
        FROM DUAL;
    
      --Handle Handoff
      PR_MULTIACLINK_INC_HANDOFF(L_XML, P_FILE_NAME);
    
      --Handle Process
      PR_PROCESS_MULTIAC_APP_ID;
    
      --Generate Outgoing Auto Debit Respnse xml file
      --PR_GENERATE_AUTODEBIT_RESPONSE;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_MOVE_FILE=' || SQLERRM);
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_MOVE_FILE;

  PROCEDURE PR_MULTIACLINK_UPLOAD(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    GLOBAL.PR_INIT('001', 'SYSTEM');
  
    DBG('INSIDE PR_MULTIACLINK_UPLOAD');
  
    PR_INIT_MSG;
  
    DBG('Successful return from PR_MULTIACLINK_UPLOAD');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Exception during PR_MULTIACLINK_UPLOAD' || SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
  END PR_MULTIACLINK_UPLOAD;

  PROCEDURE PR_PROCESS_MULTIACLINK(PARAMNAME VARCHAR2, PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    --GLOBAL.PR_INIT('000', 'SYSTEM');
  
    PR_PROCESS_MULTIAC_APP_ID;
  
    DBG('SUCCESSFUL RETURN FROM PR_PROCESS_MULTIACLINK');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_PROCESS_MULTIACLINK');
      DBG('ERROR CODE=' || SQLCODE);
      DBG('ERROR MESSAGE=' || SQLERRM);
  END PR_PROCESS_MULTIACLINK;

END IFPKS_MULTIACLINK_UTLS;
