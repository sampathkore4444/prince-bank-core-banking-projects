--TFCDB
DECLARE
  L_DATE DATE := '01-JAN-2023';
begin
  -- Call the procedure
  FOR G IN 1 .. 31 LOOP
    dbms_output.put_line('1='||L_DATE);
    begin
      ifpks_e_account_utils.pr_process_eaccounts_adb_for_a_day1(l_date);
      dbms_output.put_line('2');
      L_DATE := L_DATE + 1;
      dbms_output.put_line('3='||L_DATE);
    exception
      when others then
        dbms_output.put_line('Error Code=' || SQLCODE);
        dbms_output.put_line('Error Message=' || SQLERRM);
    end;
  END LOOP;
exception
  when others then
    dbms_output.put_line('Error Code=' || SQLCODE);
    dbms_output.put_line('Error Message=' || SQLERRM);
end;




SELECT * FROM ACTB_VD_BAL A WHERE A.ACC = '000076775' and A.VAL_DT >= '01-JAN-2023' order by val_dt;
SELECT * FROM STTM_aCCOUNT_BALANCE A WHERE A.CUST_AC_NO = '000076775';
SELECT * FROM STTM_CUST_ACCOUNT A WHERE A.CUST_AC_NO = '000076775'
SELECT * FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK FOR UPDATE;

  SELECT B.CUST_AC_NO, A.VAL_DT, B.CUST_AC_BRN, B.CCY, '00131669' CUST_NO, A.BAL, B.ACY_WITHDRAWABLE_BAL, A.LCY_BAL
        FROM ACTB_VD_BAL A, STTM_ACCOUNT_BALANCE B
       WHERE A.ACC = B.CUST_AC_NO
         AND A.ACC = '000076775'
         AND A.VAL_DT >= '01-JAN-2023';
		 
--MOCKPSET

SELECT * FROM STTM_CUST_ACCOUNT A WHERE A.ACCOUNT_CLASS IN ('EA01', 'EA02') and a.branch_code = '001'
SELECT * FROM ACTB_VD_BAL A WHERE A.ACC = '000057826' and A.VAL_DT >= '01-JAN-2023' order by val_dt;
SELECT * FROM STTM_aCCOUNT_BALANCE A WHERE A.CUST_AC_NO = '000057826';
SELECT * FROM STTM_CUST_ACCOUNT A WHERE A.CUST_AC_NO = '000057826'
SELECT * FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK FOR UPDATE;
delete from IFTB_E_ACCOUNT_ADB_DAILY_TRACK;
update IFTB_E_ACCOUNT_ADB_DAILY_TRACK a set a.insurance_coverage = 'Y' 

  SELECT B.CUST_AC_NO, A.VAL_DT, B.CUST_AC_BRN, B.CCY, '00131669' CUST_NO, A.BAL, B.ACY_WITHDRAWABLE_BAL, A.LCY_BAL
        FROM ACTB_VD_BAL A, STTM_ACCOUNT_BALANCE B
       WHERE A.ACC = B.CUST_AC_NO
         AND A.ACC = '000057826'
         AND A.VAL_DT >= '03-APR-2021';
		 
		 
DECLARE
  L_DATE DATE := '01-APR-2021';
BEGIN
  -- Call the procedure
  FOR G IN 1 .. 30 LOOP
    dbms_output.put_line('1='||L_DATE);
    begin
      ifpks_e_account_utils.pr_process_eaccounts_adb_for_a_day1(l_date);
      dbms_output.put_line('2');
      L_DATE := L_DATE + 1;
      dbms_output.put_line('3='||L_DATE);
    exception
      when others then
        dbms_output.put_line('Error Code=' || SQLCODE);
        dbms_output.put_line('Error Message=' || SQLERRM);
    end;
  END LOOP;
exception
  when others then
    dbms_output.put_line('Error Code=' || SQLCODE);
    dbms_output.put_line('Error Message=' || SQLERRM);
end;
