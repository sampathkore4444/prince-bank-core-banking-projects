CREATE OR REPLACE PACKAGE BODY IFPKS_E_ACCOUNT_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_E_ACCOUNT_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_GET_VAL_DATE_DAY_BAL(P_ACC_NO IN VARCHAR2, P_DATE IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE AS
  
    L_VALUE_DATE_DAY_BALANCE ACTB_VD_BAL.LCY_BAL%TYPE;
  
  BEGIN
  
    --Get day from date
    --L_DAY := EXTRACT(DAY FROM P_DATE);
  
    --select max value date before missing date that is passed as parameter
    SELECT LCY_BAL
      INTO L_VALUE_DATE_DAY_BALANCE
      FROM ACTB_VD_BAL A
     WHERE A.ACC = P_ACC_NO
       AND A.VAL_DT = P_DATE;
  
    DBG('L_VALUE_DATE_DAY_BALANCE=' || L_VALUE_DATE_DAY_BALANCE);
  
    RETURN L_VALUE_DATE_DAY_BALANCE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_VAL_DATE_DAY_BAL');
      DBG('EROOR CODE IN FN_GET_VAL_DATE_DAY_BAL=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_VAL_DATE_DAY_BAL=' || SQLERRM);
      RETURN L_VALUE_DATE_DAY_BALANCE;
    
  END FN_GET_VAL_DATE_DAY_BAL;

  FUNCTION FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE(P_ACC_NO IN VARCHAR2,
                                                       P_DATE   IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE AS
  
    L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE ACTB_VD_BAL.LCY_BAL%TYPE;
  
  BEGIN
  
    --Get day from date
    --L_DAY := EXTRACT(DAY FROM P_DATE);
  
    --select max value date before missing date that is passed as parameter
    SELECT LCY_BAL
      INTO L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE
      FROM ACTB_VD_BAL A
     WHERE A.ACC = P_ACC_NO
       AND A.VAL_DT IN (SELECT MAX(VAL_DT)
                          FROM ACTB_VD_BAL B
                         WHERE B.ACC = P_ACC_NO
                           AND B.VAL_DT < P_DATE);
  
    DBG('L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
        L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE);
  
    RETURN L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE');
      DBG('EROOR CODE IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
          SQLERRM);
    
      RETURN L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;
    
  END FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;

  FUNCTION FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(P_ACC_NO IN VARCHAR2,
                                                   P_DATE   IN VARCHAR2) --pass sysdate to it
   RETURN NUMBER AS
  
    L_EACH_DAY_BAL          NUMBER := 0;
    L_SUM_PREVIOUS_DAYS_BAL NUMBER := 0;
    L_DAY                   VARCHAR2(2);
    L_MONTH                 VARCHAR2(3);
    L_YEAR                  VARCHAR2(4);
    L_CURR_DATE             VARCHAR2(20);
  BEGIN
  
    --L_DAY := EXTRACT(DAY FROM TO_DATE('11-JAN-2023'));
  
    FOR G IN 1 .. EXTRACT(DAY FROM TO_DATE(P_DATE)) - 1 LOOP
      --until yesterday
    
      L_DAY   := EXTRACT(DAY FROM TO_DATE(P_DATE));
      L_MONTH := TO_CHAR(TO_DATE(P_DATE), 'Mon');
      L_YEAR  := EXTRACT(YEAR FROM TO_DATE(P_DATE));
    
      L_CURR_DATE := L_DAY || '-' || L_MONTH || '-' || L_YEAR;
    
      DBG('L_CURR_DATE=' || L_CURR_DATE);
    
      --Get G day balance from vd bal
      L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_VAL_DATE_DAY_BAL(P_ACC_NO,
                                                                      L_CURR_DATE);
      DBG(L_EACH_DAY_BAL);
    
      IF L_EACH_DAY_BAL IS NULL THEN
      
        L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE(P_ACC_NO,
                                                                                            L_CURR_DATE);
      
        DBG(L_EACH_DAY_BAL);
      END IF;
    
      L_SUM_PREVIOUS_DAYS_BAL := L_SUM_PREVIOUS_DAYS_BAL + L_EACH_DAY_BAL;
    
    END LOOP;
  
    RETURN L_SUM_PREVIOUS_DAYS_BAL;
  
  EXCEPTION
  
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY');
      DBG('ERROR CODE IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY=' ||
          SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
    
      RETURN L_SUM_PREVIOUS_DAYS_BAL;
    
  END FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY AS
  
    CURSOR C1 IS
      SELECT A.CUST_NO,
             B.CUST_AC_NO,
             B.CUST_AC_BRN,
             B.CCY,
             B.ACY_WITHDRAWABLE_BAL
        FROM STTM_CUST_ACCOUNT A, STTM_ACCOUNT_BALANCE B
       WHERE A.CUST_AC_NO = B.CUST_AC_NO
         AND A.BRANCH_CODE = B.CUST_AC_BRN
         AND A.ACCOUNT_CLASS IN ('EA01', 'EA02')
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y';
  
    L_ACY_WITHDRAWABLE_BAL                 STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND NUMBER;
    L_SUM_OF_BAL_UNTIL_YESTERDAY           NUMBER := 0;
    L_NO_OF_DAYS_IN_A_MONTH                NUMBER;
    L_ADB_CALC_RESULT_IN_USD               NUMBER(22, 3) := 0;
    L_ADB_CALC_RESULT_IN_KHR               NUMBER(22, 3) := 0;
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        SAVEPOINT A;
      
        --Get current balance 
        L_ACY_WITHDRAWABLE_BAL := G.ACY_WITHDRAWABLE_BAL;
      
        L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND := (LAST_DAY(TRUNC(SYSDATE,
                                                                  'MM')) -
                                                  TRUNC(SYSDATE)) + 1;
      
        L_SUM_OF_BAL_UNTIL_YESTERDAY := FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(G.CUST_AC_NO,
                                                                                SYSDATE);
      
        L_NO_OF_DAYS_IN_A_MONTH := EXTRACT(DAY FROM LAST_DAY(SYSDATE));
      
        IF G.CCY = 'KHR' THEN
        
          L_ADB_CALC_RESULT_IN_KHR := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                            L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                            L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                            L_NO_OF_DAYS_IN_A_MONTH,
                                            2);
        
          L_ADB_CALC_RESULT_IN_USD := ROUND(L_ADB_CALC_RESULT_IN_KHR / 4000,
                                            2);
        
        ELSE
        
          L_ADB_CALC_RESULT_IN_USD := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                            L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                            L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                            L_NO_OF_DAYS_IN_A_MONTH,
                                            2);
        
        END IF;
      
        --INSERT INTO DAILY TRACK TABLE
        INSERT INTO IFTB_E_ACCOUNT_ADB_DAILY_TRACK
          (CUSTOMER_NO,
           CUST_AC_NO,
           CUST_AC_BRN,
           CCY,
           ADB_CALC_DATE,
           ACY_WITHDRAWABLE_BAL,
           DAYS_FROM_TODAY_TILL_MONTHEND,
           BAL_AS_OF_YESTERDAY,
           NO_OF_DAYS_IN_MONTH,
           ADB_RESULT_IN_USD,
           ADB_RESULT_IN_KHR)
        VALUES
          (G.CUST_NO,
           G.CUST_AC_NO,
           G.CUST_AC_BRN,
           G.CCY,
           SYSDATE,
           G.ACY_WITHDRAWABLE_BAL,
           L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND,
           L_SUM_OF_BAL_UNTIL_YESTERDAY,
           L_NO_OF_DAYS_IN_A_MONTH,
           L_ADB_CALC_RESULT_IN_USD,
           L_ADB_CALC_RESULT_IN_KHR);
      
        COMMIT;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT RECORD=' ||
                         DBMS_UTILITY.format_error_backtrace);
        
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT RECORD=' || SQLERRM);
        
          ROLLBACK TO A;
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY');
      DBG('EROOR CODE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY=' ||
          SQLERRM);
    
  END PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_EACCOUNTS_ADB');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY;
  
    DEBUG.PR_DEBUG('IF', 'Successful return from PR_PROCESS_EACCOUNTS_ADB');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_EACCOUNTS_ADB' || SQLERRM);
  END PR_PROCESS_EACCOUNTS_ADB;

END IFPKS_E_ACCOUNT_UTILS;
