
DECLARE
  L_SUM_PREVIOUS_DAYS_BAL        NUMBER := 0;
  L_LAST_VAL_DATE_BEFORE_GAP     ACTB_VD_BAL.VAL_DT%TYPE;
  L_LAST_VAL_DATE_BAL_BEFORE_GAP ACTB_VD_BAL.LCY_BAL%TYPE;
  FLAG                           NUMBER := 0;
BEGIN

  FOR G IN (SELECT *
              FROM ACTB_VD_BAL A
             WHERE A.ACC = '000051070'
               AND VAL_DT >= '01-JAN-2023'
               AND VAL_DT <= '31-JAN-2023') LOOP
  
    --DBMS_OUTPUT.PUT_LINE(EXTRACT(DAY FROM G.VAL_DT));
    --IF EXTRACT(DAY FROM G.VAL_DT) < EXTRACT(DAY FROM SYSDATE)
  
    -- IF   
  
    IF G.VAL_DT < '11-JAN-2023' THEN --SYSDATE
    
      L_SUM_PREVIOUS_DAYS_BAL := L_SUM_PREVIOUS_DAYS_BAL + G.LCY_BAL;
    
      L_LAST_VAL_DATE_BEFORE_GAP     := G.VAL_DT;
      L_LAST_VAL_DATE_BAL_BEFORE_GAP := G.LCY_BAL;
    
    ELSE
      FLAG := 1;
      EXIT;
    END IF;
  
  END LOOP;

  IF FLAG = 1 THEN
  
    L_SUM_PREVIOUS_DAYS_BAL := L_SUM_PREVIOUS_DAYS_BAL +
                               (TO_DATE('11-JAN-2023', 'DD-MON-YYYY') -  --SYSDATE
                               L_LAST_VAL_DATE_BEFORE_GAP - 1) *
                               L_LAST_VAL_DATE_BAL_BEFORE_GAP;
                               
    FLAG                    := 0;
    
  END IF;

  DBMS_OUTPUT.put_line('L_SUM_PREVIOUS_DAYS_BAL=' ||
                       L_SUM_PREVIOUS_DAYS_BAL);

END;

--SELECT * FROM ACTB_VD_BAL A WHERE A.ACC = '000051070' AND VAL_DT >= '01-JAN-2023' AND VAL_DT <='31-JAN-2023';






DECLARE
  L_EACH_DAY_BAL NUMBER := 0;
  L_SUM_PREVIOUS_DAYS_BAL        NUMBER := 0;
  L_DAY VARCHAR2(2);
  L_MONTH VARCHAR2(3);
  L_YEAR VARCHAR2(4);
  L_CURR_DATE VARCHAR2(20);
BEGIN
   --L_DAY := EXTRACT(DAY FROM TO_DATE('11-JAN-2023'));
  FOR G IN 1.. EXTRACT(DAY FROM TO_DATE('11-JAN-2023')) LOOP
    
    L_DAY := EXTRACT(DAY FROM TO_DATE('11-JAN-2023'));
    L_MONTH := TO_CHAR(TO_DATE('11-JAN-2023'), 'Mon');
    L_YEAR := EXTRACT(YEAR FROM TO_DATE('11-JAN-2023'));
    
    L_CURR_DATE := L_DAY || '-' || L_MONTH || '-' || L_YEAR;
    
    DBMS_OUTPUT.PUT_LINE('L_CURR_DATE='||L_CURR_DATE);
  
    --Get G day balance from vd bal
    L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_VAL_DATE_DAY_BAL('000051070',
                                                           L_CURR_DATE);
    DBMS_OUTPUT.PUT_LINE(L_EACH_DAY_BAL);
    
    IF L_EACH_DAY_BAL IS NULL THEN
    
      L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE('000051070',
                                                           L_CURR_DATE);
      
      DBMS_OUTPUT.PUT_LINE(L_EACH_DAY_BAL);
    END IF;
    
    L_SUM_PREVIOUS_DAYS_BAL := L_SUM_PREVIOUS_DAYS_BAL + L_EACH_DAY_BAL;
  
  END LOOP;
EXCEPTION

  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLCODE);
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    DBMS_OUTPUT.PUT_LINE('ERROR LINE NUMBER='||DBMS_UTILITY.format_error_backtrace);
END;
 