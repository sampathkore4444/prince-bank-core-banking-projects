CREATE OR REPLACE PACKAGE BODY IFPKS_E_ACCOUNT_UTILS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_E_ACCOUNT_UTILS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_GET_MAX_INSURANCE_COVERAGE_FLAG(P_CIF_NO IN VARCHAR2,
                                              P_ACC_NO IN VARCHAR2)
  
   RETURN IFTB_E_ACCOUNT_ADB_DAILY_TRACK.INSURANCE_COVERAGE%TYPE AS
  
    L_INSURANCE_COVERAGE IFTB_E_ACCOUNT_ADB_DAILY_TRACK.INSURANCE_COVERAGE%TYPE;
    
    L_COUNT NUMBER :=0;
  
  BEGIN
    
   SELECT COUNT(1)
        INTO L_COUNT
        FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK A
       WHERE A.CUSTOMER_NO = P_CIF_NO
         AND A.CUST_AC_NO = P_ACC_NO
         AND JOB_RUN_TIME IN
             (SELECT MAX(JOB_RUN_TIME)
                FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK A
               WHERE A.CUSTOMER_NO = P_CIF_NO
                 AND A.CUST_AC_NO = P_ACC_NO);
  
  IF L_COUNT > 0 THEN
    BEGIN
    
      SELECT NVL(A.INSURANCE_COVERAGE, 'N')
        INTO L_INSURANCE_COVERAGE
        FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK A
       WHERE A.CUSTOMER_NO = P_CIF_NO
         AND A.CUST_AC_NO = P_ACC_NO
         AND JOB_RUN_TIME IN
             (SELECT MAX(JOB_RUN_TIME)
                FROM IFTB_E_ACCOUNT_ADB_DAILY_TRACK A
               WHERE A.CUSTOMER_NO = P_CIF_NO
                 AND A.CUST_AC_NO = P_ACC_NO);
    
    EXCEPTION
      WHEN OTHERS THEN
        L_INSURANCE_COVERAGE := 'Y';
    END;
  
    RETURN L_INSURANCE_COVERAGE;
    
    ELSE
      
    RETURN 'Y';
      
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE SPECIMEN NO');
      DBG('ERROR CODE IN FN_GET_MAX_SPECIMEN_NO=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MAX_SPECIMEN_NO=' || SQLERRM);
      L_INSURANCE_COVERAGE := 'Y';
      RETURN L_INSURANCE_COVERAGE;
    
  END FN_GET_MAX_INSURANCE_COVERAGE_FLAG;

  FUNCTION FN_GET_VAL_DATE_DAY_BAL(P_ACC_NO IN VARCHAR2,
                                   P_CCY    IN VARCHAR2,
                                   P_DATE   IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE AS
  
    L_VALUE_DATE_DAY_BALANCE ACTB_VD_BAL.LCY_BAL%TYPE;
  
  BEGIN
  
    --Get day from date
    --L_DAY := EXTRACT(DAY FROM P_DATE);
  
    --select max value date before missing date that is passed as parameter
    IF P_CCY = 'KHR' THEN
    
      SELECT NVL(BAL, 0)
        INTO L_VALUE_DATE_DAY_BALANCE
        FROM ACTB_VD_BAL A
       WHERE A.ACC = P_ACC_NO
         AND A.VAL_DT = P_DATE;
    
    ELSE
    
      SELECT NVL(LCY_BAL, 0)
        INTO L_VALUE_DATE_DAY_BALANCE
        FROM ACTB_VD_BAL A
       WHERE A.ACC = P_ACC_NO
         AND A.VAL_DT = P_DATE;
    
    END IF;
  
    DBG('L_VALUE_DATE_DAY_BALANCE=' || L_VALUE_DATE_DAY_BALANCE);
    --DBMS_OUTPUT.PUT_LINE('L_VALUE_DATE_DAY_BALANCE=' ||
    --                      L_VALUE_DATE_DAY_BALANCE);
  
    RETURN L_VALUE_DATE_DAY_BALANCE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_VAL_DATE_DAY_BAL');
      DBG('EROOR CODE IN FN_GET_VAL_DATE_DAY_BAL=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_VAL_DATE_DAY_BAL=' || SQLERRM);
      RETURN L_VALUE_DATE_DAY_BALANCE;
    
  END FN_GET_VAL_DATE_DAY_BAL;

  FUNCTION FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE(P_ACC_NO IN VARCHAR2,
                                                       P_CCY    IN VARCHAR2,
                                                       P_DATE   IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE AS
  
    L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE ACTB_VD_BAL.LCY_BAL%TYPE;
  
  BEGIN
  
    --Get day from date
    --L_DAY := EXTRACT(DAY FROM P_DATE);
  
    --DBMS_OUTPUT.PUT_LINE('FINAL DATE=' || TO_DATE(P_DATE, 'DD-MON-YYYY'));
    DBG('FINAL DATE=' || TO_DATE(P_DATE, 'DD-MON-YYYY'));
    --select max value date before missing date that is passed as parameter
    IF P_CCY = 'KHR' THEN
    
      SELECT BAL
        INTO L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE
        FROM ACTB_VD_BAL A
       WHERE A.ACC = P_ACC_NO
         AND A.VAL_DT IN (SELECT MAX(VAL_DT)
                            FROM ACTB_VD_BAL B
                           WHERE B.ACC = P_ACC_NO
                             AND B.VAL_DT < P_DATE);
    
    ELSE
    
      SELECT LCY_BAL
        INTO L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE
        FROM ACTB_VD_BAL A
       WHERE A.ACC = P_ACC_NO
         AND A.VAL_DT IN (SELECT MAX(VAL_DT)
                            FROM ACTB_VD_BAL B
                           WHERE B.ACC = P_ACC_NO
                             AND B.VAL_DT < P_DATE);
    
    END IF;
  
    DBG('L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
        L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE);
  
    --DBMS_OUTPUT.PUT_LINE('L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
    --                   L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE);
  
    RETURN L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE');
      DBG('EROOR CODE IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE=' ||
          SQLERRM);
    
      RETURN L_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;
    
  END FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE;

  FUNCTION FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(P_ACC_NO IN VARCHAR2,
                                                   P_CCY    IN VARCHAR2,
                                                   P_DATE   IN VARCHAR2) --pass sysdate to it
   RETURN NUMBER AS
  
    L_EACH_DAY_BAL          NUMBER := 0;
    L_SUM_PREVIOUS_DAYS_BAL NUMBER := 0;
    L_DAY                   VARCHAR2(2);
    L_MONTH                 VARCHAR2(3);
    L_YEAR                  VARCHAR2(4);
    L_CURR_DATE             VARCHAR2(20);
  BEGIN
  
    --L_DAY := EXTRACT(DAY FROM TO_DATE('11-JAN-2023'));
  
    FOR G IN 1 .. EXTRACT(DAY FROM TO_DATE(P_DATE)) - 1 LOOP
      --until yesterday
    
      L_DAY   := EXTRACT(DAY FROM TO_DATE(P_DATE));
      L_MONTH := TO_CHAR(TO_DATE(P_DATE), 'Mon');
      L_YEAR  := EXTRACT(YEAR FROM TO_DATE(P_DATE));
    
      L_CURR_DATE := L_DAY || '-' || L_MONTH || '-' || L_YEAR;
    
      DBG('L_CURR_DATE=' || L_CURR_DATE);
    
      --DBMS_OUTPUT.PUT_LINE('L_CURR_DATE=' || L_CURR_DATE);
    
      L_CURR_DATE := G || '-' || L_MONTH || '-' || L_YEAR;
    
      -- DBMS_OUTPUT.PUT_LINE('L_CURR_DATE1=' ||L_CURR_DATE);
      DBG('L_CURR_DATE1=' || L_CURR_DATE);
    
      --Get G day balance from vd bal
      L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_VAL_DATE_DAY_BAL(P_ACC_NO,
                                                                      P_CCY,
                                                                      L_CURR_DATE);
      DBG('L_EACH_DAY_BAL 0=' || L_EACH_DAY_BAL);
    
      --DBMS_OUTPUT.PUT_LINE('L_EACH_DAY_BAL 0=' || L_EACH_DAY_BAL);
    
      IF L_EACH_DAY_BAL IS NULL THEN
      
        L_EACH_DAY_BAL := IFPKS_E_ACCOUNT_UTILS.FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE(P_ACC_NO,
                                                                                            P_CCY,
                                                                                            L_CURR_DATE);
      
        DBG('L_EACH_DAY_BAL 0=' || L_EACH_DAY_BAL);
      
        -- DBMS_OUTPUT.PUT_LINE('L_EACH_DAY_BAL=' || L_EACH_DAY_BAL);
      
      END IF;
    
      L_SUM_PREVIOUS_DAYS_BAL := L_SUM_PREVIOUS_DAYS_BAL +
                                 NVL(L_EACH_DAY_BAL, 0);
    
      DBG('EACH ITERATION L_SUM_PREVIOUS_DAYS_BAL=' ||
          L_SUM_PREVIOUS_DAYS_BAL);
    
    --DBMS_OUTPUT.PUT_LINE('L_SUM_PREVIOUS_DAYS_BAL=' ||
    --                    L_SUM_PREVIOUS_DAYS_BAL);
    
    END LOOP;
  
    -- DBMS_OUTPUT.PUT_LINE('FINAL L_SUM_PREVIOUS_DAYS_BAL=' ||
    --                     L_SUM_PREVIOUS_DAYS_BAL);
  
    DBG('FINAL L_SUM_PREVIOUS_DAYS_BAL=' || L_SUM_PREVIOUS_DAYS_BAL);
  
    RETURN L_SUM_PREVIOUS_DAYS_BAL;
  
  EXCEPTION
  
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY');
      DBG('ERROR CODE IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY=' ||
          SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY=' ||
          SQLERRM);
      DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_error_backtrace);
    
      RETURN L_SUM_PREVIOUS_DAYS_BAL;
    
  END FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY AS
  
    CURSOR C1 IS
      SELECT A.CUST_NO,
             B.CUST_AC_NO,
             B.CUST_AC_BRN,
             B.CCY,
             B.ACY_WITHDRAWABLE_BAL
        FROM STTM_CUST_ACCOUNT A, STTM_ACCOUNT_BALANCE B
       WHERE A.CUST_AC_NO = B.CUST_AC_NO
         AND A.BRANCH_CODE = B.CUST_AC_BRN
         AND A.ACCOUNT_CLASS IN ('EA01', 'EA02')
         AND A.RECORD_STAT = 'O'
         AND A.ONCE_AUTH = 'Y'
      --AND A.CUST_AC_NO in ('000078089','000078091') --Chikki Chikki
      --AND A.CUST_AC_NO = '000076775'
      /*SELECT B.CUST_AC_NO, B.ACY_WITHDRAWABLE_BAL, B.CUST_AC_BRN, B.CCY, '001' CUST_NO
       FROM ACTB_VD_BAL A, STTM_ACCOUNT_BALANCE B
      WHERE A.ACC = B.CUST_AC_NO
        AND A.ACC = '000076775'
        AND A.VAL_DT <= '30-OCT-2022'*/
      ;
  
    L_ACY_WITHDRAWABLE_BAL                 STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND NUMBER;
    L_SUM_OF_BAL_UNTIL_YESTERDAY           NUMBER := 0;
    L_NO_OF_DAYS_IN_A_MONTH                NUMBER;
    L_ADB_CALC_RESULT_IN_USD               NUMBER(22, 3) := 0;
    L_ADB_CALC_RESULT_IN_KHR               NUMBER(22, 3) := 0;
    
    L_INSURANCE_COVERAGE IFTB_E_ACCOUNT_ADB_DAILY_TRACK.INSURANCE_COVERAGE%TYPE;
  
    --L_DATE DATE;
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    --L_DATE := '01-OCT-2022';
  
    FOR G IN C1 LOOP
    
      BEGIN
      
        GLOBAL.pr_init(G.CUST_AC_BRN, 'SYSTEM');
      
        SAVEPOINT A;
      
        --Get current balance
        L_ACY_WITHDRAWABLE_BAL := G.ACY_WITHDRAWABLE_BAL;
      
        L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND := (LAST_DAY(TRUNC(GLOBAL.application_date /*SYSDATE*/,
                                                                  'MM')) -
                                                  TRUNC(GLOBAL.application_date /*SYSDATE*/)) + 1;
      
        --        DBMS_OUTPUT.PUT_LINE('L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND=' ||
        --                         L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND);
      
        DBG('L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND=' ||
            L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND);
      
        IF EXTRACT(DAY FROM TO_DATE(GLOBAL.application_date /*SYSDATE*/)) = 1 THEN
        
          --  DBMS_OUTPUT.PUT_LINE('VERY FIRST DAY');
        
          L_SUM_OF_BAL_UNTIL_YESTERDAY := 0;
        
        ELSE
        
          -- DBMS_OUTPUT.PUT_LINE('NOT A VERY FIRST DAY');
        
          L_SUM_OF_BAL_UNTIL_YESTERDAY := FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(G.CUST_AC_NO,
                                                                                  G.CCY,
                                                                                  GLOBAL.application_date /*SYSDATE*/);
        END IF;
      
        -- DBMS_OUTPUT.PUT_LINE('L_SUM_OF_BAL_UNTIL_YESTERDAY=' ||
        --                      L_SUM_OF_BAL_UNTIL_YESTERDAY);
      
        DBG('L_SUM_OF_BAL_UNTIL_YESTERDAY=' ||
            L_SUM_OF_BAL_UNTIL_YESTERDAY);
      
        L_NO_OF_DAYS_IN_A_MONTH := EXTRACT(DAY FROM
                                           LAST_DAY(GLOBAL.application_date /*SYSDATE*/));
      
        -- DBMS_OUTPUT.PUT_LINE('L_NO_OF_DAYS_IN_A_MONTH=' ||
        --                      L_NO_OF_DAYS_IN_A_MONTH);
      
        DBG('L_NO_OF_DAYS_IN_A_MONTH=' || L_NO_OF_DAYS_IN_A_MONTH);
      
        IF G.CCY = 'KHR' THEN
        
          L_ADB_CALC_RESULT_IN_KHR := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                            L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                            L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                            L_NO_OF_DAYS_IN_A_MONTH,
                                            2);
        
          L_ADB_CALC_RESULT_IN_USD := ROUND(L_ADB_CALC_RESULT_IN_KHR / 4000,
                                            2);
        
        ELSE
        
          L_ADB_CALC_RESULT_IN_USD := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                            L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                            L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                            L_NO_OF_DAYS_IN_A_MONTH,
                                            2);
        
        END IF;
      
        --DBMS_OUTPUT.PUT_LINE('L_ADB_CALC_RESULT_IN_USD=' ||
        --                    L_ADB_CALC_RESULT_IN_USD);
      
        DBG('L_ADB_CALC_RESULT_IN_USD=' || L_ADB_CALC_RESULT_IN_USD);
      
        --INSERT INTO DAILY TRACK TABLE
        
        L_INSURANCE_COVERAGE := FN_GET_MAX_INSURANCE_COVERAGE_FLAG(G.CUST_NO, G.CUST_AC_NO);
        
        INSERT INTO IFTB_E_ACCOUNT_ADB_DAILY_TRACK
          (CUSTOMER_NO,
           CUST_AC_NO,
           CUST_AC_BRN,
           CCY,
           ADB_CALC_DATE,
           ACY_WITHDRAWABLE_BAL,
           DAYS_FROM_TODAY_TILL_MONTHEND,
           BAL_AS_OF_YESTERDAY,
           NO_OF_DAYS_IN_MONTH,
           ADB_RESULT_IN_USD,
           ADB_RESULT_IN_KHR,
           INSURANCE_COVERAGE,
           JOB_RUN_TIME)
        VALUES
          (G.CUST_NO,
           G.CUST_AC_NO,
           G.CUST_AC_BRN,
           G.CCY,
           GLOBAL.application_date, --SYSDATE,
           G.ACY_WITHDRAWABLE_BAL,
           L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND,
           L_SUM_OF_BAL_UNTIL_YESTERDAY,
           L_NO_OF_DAYS_IN_A_MONTH,
           L_ADB_CALC_RESULT_IN_USD,
           L_ADB_CALC_RESULT_IN_KHR,
           L_INSURANCE_COVERAGE,
           --'Y',
           SYSDATE);
      
        COMMIT;
      
      EXCEPTION
        WHEN OTHERS THEN
        
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT RECORD=' ||
                         DBMS_UTILITY.format_error_backtrace);
        
          DEBUG.PR_DEBUG('AC',
                         'FAILED IN PROCESSING CURRENT RECORD=' || SQLERRM);
        
          ROLLBACK TO A;
        
          CONTINUE;
      END;
    END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY');
      DBG('EROOR CODE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY=' ||
          SQLERRM);
    
  END PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1(L_DATE        in date,
                                                L_CUST_AC_NO  in VARCHAR2,
                                                L_CUST_AC_BRN IN VARCHAR2,
                                                L_CUST_AC_CCY IN VARCHAR2) AS
  
    CURSOR C1 IS
    /*  SELECT A.CUST_NO,
                                                                                                                                                                                 B.CUST_AC_NO,
                                                                                                                                                                                 B.CUST_AC_BRN,
                                                                                                                                                                                 B.CCY,
                                                                                                                                                                                 B.ACY_WITHDRAWABLE_BAL
                                                                                                                                                                            FROM STTM_CUST_ACCOUNT A, STTM_ACCOUNT_BALANCE B
                                                                                                                                                                           WHERE A.CUST_AC_NO = B.CUST_AC_NO
                                                                                                                                                                             AND A.BRANCH_CODE = B.CUST_AC_BRN
                                                                                                                                                                             AND A.ACCOUNT_CLASS IN ('EA01', 'EA02')
                                                                                                                                                                             AND A.RECORD_STAT = 'O'
                                                                                                                                                                             AND A.ONCE_AUTH = 'Y'
                                                                                                                                                                          --AND A.CUST_AC_NO = '000076775'*/
      SELECT B.CUST_AC_NO,
             B.ACY_WITHDRAWABLE_BAL,
             B.CUST_AC_BRN,
             B.CCY,
             '00131669' CUST_NO
        FROM ACTB_VD_BAL A, STTM_ACCOUNT_BALANCE B
       WHERE A.ACC = B.CUST_AC_NO
         AND A.ACC = '000076775'
         AND A.VAL_DT >= '01-JAN-2023';
  
    L_ACY_WITHDRAWABLE_BAL                 STTM_ACCOUNT_BALANCE.ACY_WITHDRAWABLE_BAL%TYPE;
    L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND NUMBER;
    L_SUM_OF_BAL_UNTIL_YESTERDAY           NUMBER := 0;
    L_NO_OF_DAYS_IN_A_MONTH                NUMBER;
    L_ADB_CALC_RESULT_IN_USD               NUMBER(22, 3) := 0;
    L_ADB_CALC_RESULT_IN_KHR               NUMBER(22, 3) := 0;
  
    --L_CUST_AC_NO  VARCHAR2(100) := '000076775';
    --L_CUST_AC_BRN VARCHAR2(100) := '030';
    --L_CUST_AC_CCY VARCHAR2(100) := 'USD';
  
    --L_DATE DATE;
  
    PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    --L_DATE := '01-OCT-2022';
  
    --FOR G IN C1 LOOP
  
    BEGIN
    
      SAVEPOINT A;
    
      DBMS_OUTPUT.PUT_LINE('L_DATE=' || L_DATE);
    
      --Get current balance
      L_ACY_WITHDRAWABLE_BAL := NVL(FN_GET_VAL_DATE_DAY_BAL(L_CUST_AC_NO,
                                                            L_CUST_AC_ccy,
                                                            L_DATE),
                                    FN_GET_VAL_DATE_DAY_BAL(L_CUST_AC_NO,
                                                            L_CUST_AC_ccy,
                                                            '01-JAN-2023')); -- G.ACY_WITHDRAWABLE_BAL;
    
      DBMS_OUTPUT.PUT_LINE('L_ACY_WITHDRAWABLE_BAL=' ||
                           L_ACY_WITHDRAWABLE_BAL);
    
      L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND := (LAST_DAY(TRUNC(L_DATE /*SYSDATE*/,
                                                                'MM')) -
                                                TRUNC(L_DATE /*SYSDATE*/)) + 1;
    
      DBMS_OUTPUT.PUT_LINE('L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND=' ||
                           L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND);
    
      IF EXTRACT(DAY FROM TO_DATE(L_DATE /*SYSDATE*/)) = 1 THEN
      
        L_SUM_OF_BAL_UNTIL_YESTERDAY := 0;
      
        DBMS_OUTPUT.PUT_LINE('L_SUM_OF_BAL_UNTIL_YESTERDAY=' ||
                             L_SUM_OF_BAL_UNTIL_YESTERDAY);
      
      ELSE
      
        L_SUM_OF_BAL_UNTIL_YESTERDAY := FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(L_CUST_AC_NO,
                                                                                L_CUST_AC_ccy,
                                                                                L_DATE /*SYSDATE*/);
      
        DBMS_OUTPUT.PUT_LINE('L_SUM_OF_BAL_UNTIL_YESTERDAY=' ||
                             L_SUM_OF_BAL_UNTIL_YESTERDAY);
      
      END IF;
    
      L_NO_OF_DAYS_IN_A_MONTH := EXTRACT(DAY FROM
                                         LAST_DAY(L_DATE /*SYSDATE*/));
    
      DBMS_OUTPUT.PUT_LINE('L_NO_OF_DAYS_IN_A_MONTH=' ||
                           L_NO_OF_DAYS_IN_A_MONTH);
    
      IF L_CUST_AC_ccy = 'KHR' THEN
      
        L_ADB_CALC_RESULT_IN_KHR := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                          L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                          L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                          L_NO_OF_DAYS_IN_A_MONTH,
                                          2);
      
        L_ADB_CALC_RESULT_IN_USD := ROUND(L_ADB_CALC_RESULT_IN_KHR / 4000,
                                          2);
      
      ELSE
      
        L_ADB_CALC_RESULT_IN_USD := ROUND(((L_ACY_WITHDRAWABLE_BAL *
                                          L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND) +
                                          L_SUM_OF_BAL_UNTIL_YESTERDAY) /
                                          L_NO_OF_DAYS_IN_A_MONTH,
                                          2);
      
        L_ADB_CALC_RESULT_IN_KHR := L_ADB_CALC_RESULT_IN_USD * 4000;
      
      END IF;
    
      DBMS_OUTPUT.PUT_LINE('L_ADB_CALC_RESULT_IN_USD=' ||
                           L_ADB_CALC_RESULT_IN_USD);
    
      --INSERT INTO DAILY TRACK TABLE
      INSERT INTO IFTB_E_ACCOUNT_ADB_DAILY_TRACK
        (CUSTOMER_NO,
         CUST_AC_NO,
         CUST_AC_BRN,
         CCY,
         ADB_CALC_DATE,
         ACY_WITHDRAWABLE_BAL,
         DAYS_FROM_TODAY_TILL_MONTHEND,
         BAL_AS_OF_YESTERDAY,
         NO_OF_DAYS_IN_MONTH,
         ADB_RESULT_IN_USD,
         ADB_RESULT_IN_KHR,
         INSURANCE_COVERAGE)
      VALUES
        ('00131669',
         L_CUST_AC_NO,
         L_CUST_AC_BRN,
         L_CUST_AC_ccy,
         L_DATE /*SYSDATE*/,
         L_ACY_WITHDRAWABLE_BAL,
         L_NO_OF_DAYS_FROM_TODAY_UNTIL_MONTHEND,
         L_SUM_OF_BAL_UNTIL_YESTERDAY,
         L_NO_OF_DAYS_IN_A_MONTH,
         L_ADB_CALC_RESULT_IN_USD,
         L_ADB_CALC_RESULT_IN_KHR,
         'Y');
    
      COMMIT;
    
    EXCEPTION
      WHEN OTHERS THEN
      
        DEBUG.PR_DEBUG('AC',
                       'FAILED IN PROCESSING CURRENT RECORD=' ||
                       DBMS_UTILITY.format_error_backtrace);
      
        DEBUG.PR_DEBUG('AC',
                       'FAILED IN PROCESSING CURRENT RECORD=' || SQLERRM);
      
        DBMS_OUTPUT.PUT_LINE('ERROR CODE=' || SQLCODE);
        DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE=' || SQLERRM);
      
        ROLLBACK TO A;
      
      --CONTINUE;
    END;
    --END LOOP;
  
  EXCEPTION
    WHEN OTHERS THEN
    
      DBG('FAILED IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1');
      DBG('EROOR CODE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1=' ||
          SQLERRM);
    
      DBMS_OUTPUT.PUT_LINE('ERROR CODE1=' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('ERROR MESSAGE1=' || SQLERRM);
    
  END PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2) AS
  
  BEGIN
  
    DEBUG.PR_DEBUG('IF', 'Inside PR_PROCESS_EACCOUNTS_ADB');
  
    DEBUG.PR_DEBUG('IF', 'paramName = ' || PARAMNAME);
    DEBUG.PR_DEBUG('IF', 'paramValue = ' || PARAMVALUE);
  
    PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY;
  
    DEBUG.PR_DEBUG('IF', 'Successful return from PR_PROCESS_EACCOUNTS_ADB');
  EXCEPTION
    WHEN OTHERS THEN
      DEBUG.PR_DEBUG('IF',
                     'Exception during PR_PROCESS_EACCOUNTS_ADB' || SQLERRM);
  END PR_PROCESS_EACCOUNTS_ADB;

END IFPKS_E_ACCOUNT_UTILS;
