CREATE OR REPLACE PACKAGE IFPKS_E_ACCOUNT_UTILS AS

  FUNCTION FN_GET_VAL_DATE_DAY_BAL(P_ACC_NO IN VARCHAR2,
                                   P_CCY    IN VARCHAR2,
                                   P_DATE   IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE;

  FUNCTION FN_GET_MAX_VAL_DATE_BAL_BEFORE_MISSING_DATE(P_ACC_NO IN VARCHAR2,
                                                       P_CCY    IN VARCHAR2,
                                                       P_DATE   IN DATE)
    RETURN ACTB_VD_BAL.LCY_BAL%TYPE;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB_FOR_A_DAY1(L_DATE in date,
                                                
                                                L_CUST_AC_NO  in VARCHAR2,
                                                L_CUST_AC_BRN IN VARCHAR2,
                                                L_CUST_AC_CCY IN VARCHAR2);

  FUNCTION FN_GET_SUM_BAL_FROM_BEG_UNTIL_YESTERDAY(P_ACC_NO IN VARCHAR2,
                                                   P_CCY    IN VARCHAR2,
                                                   P_DATE   IN VARCHAR2)
    RETURN NUMBER;

  PROCEDURE PR_PROCESS_EACCOUNTS_ADB(PARAMNAME  VARCHAR2,
                                     PARAMVALUE VARCHAR2);

END IFPKS_E_ACCOUNT_UTILS;
