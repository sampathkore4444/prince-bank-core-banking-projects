insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('AC-EACC-003', 'ENG', 'Account Class EA02 is not allowed to open at over the counter', 'E', 'N', 'STDCUSAC', 0, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
