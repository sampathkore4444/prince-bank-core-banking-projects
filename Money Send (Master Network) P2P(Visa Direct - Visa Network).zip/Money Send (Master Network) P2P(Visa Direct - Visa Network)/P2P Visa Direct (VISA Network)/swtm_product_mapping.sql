insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('MSD', 'R', 'VMSD', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 22:21:27', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 22:21:28', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'VISA', 'KH', 'POS');

insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('MSD', 'R', 'MSD1', 'O', 'A', 1, 'SAMPATH2', to_date('14-01-2020 22:24:23', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('14-01-2020 22:24:24', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'VISA', 'ALL', 'POS');

COMMIT;
