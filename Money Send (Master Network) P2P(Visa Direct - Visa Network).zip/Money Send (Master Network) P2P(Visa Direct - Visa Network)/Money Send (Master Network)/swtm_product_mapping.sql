insert into swtm_product_mapping (FC_LITERAL, CATEGORY, PRODUCT_CODE, RECORD_STAT, AUTH_STAT, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, ONCE_AUTH, CUST_CATEGORY, NETWORK, ACQ_COUNTRY, CHANNEL)
values ('MSD', 'R', 'PMSD', 'O', 'A', 2, 'YRAROTH', to_date('16-12-2019 23:15:50', 'dd-mm-yyyy hh24:mi:ss'), 'HLEANG', to_date('16-12-2019 23:16:01', 'dd-mm-yyyy hh24:mi:ss'), 'Y', 'ALL', 'MASTER', 'ALL', 'POS');

COMMIT;
