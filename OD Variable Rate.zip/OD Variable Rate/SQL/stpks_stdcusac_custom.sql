CREATE OR REPLACE PACKAGE BODY STPKS_STDCUSAC_CUSTOM AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : stpks_stdcusac_custom.sql
  **
  ** Module     : Static Maintenance
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2019 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY

  SFR Number         :
  Changed By         :
  Change Description :

  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes

  ** Modified By         : Kore Sampath Kumar
   ** Modified On         : 15-Nov-2021
   ** Modified Reason     : AIA SI Payment Account Closure Validation
   ** Search String       : AIA SI Payment Account Closure Validation

  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'stpks_stdcusac_Custom ==>' || p_Msg;
      Debug.Pr_Debug('ST', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  
   --OD Variable Rate for CASA Sampath Starts
  FUNCTION FN_GET_RATE_CODE_VALUE(P_BRANCH_CODE IN STTM_CUST_ACCOUNT.BRANCH_CODE%TYPE,
                                  P_CCY         IN STTM_CUST_ACCOUNT.CCY%TYPE)
    RETURN ictm_rates.rate%type AS
  
    l_rate ictm_rates.rate%type;
  
  BEGIN
  
    begin
      select nvl(rate, 0)
        into l_rate
        from ictm_rate_def a, ictm_rates b
       where a.rate_code = b.rate_code
         and a.ccy_code = b.ccy_code
         and a.branch_code = b.branch_code
         and a.branch_code = 'ALL'
         and a.ccy_code = p_ccy
         and a.record_stat = 'O'
         and a.auth_stat = 'A'
         and b.eff_dt in (select max(c.eff_dt)
                            from ictm_rates c
                           where c.rate_code = a.rate_code
                             and c.branch_code = a.branch_code
                             and c.ccy_code = a.ccy_code
                             and c.ccy_code = p_ccy);
    
      return l_rate;
    EXCEPTION
      WHEN OTHERS THEN
      
        return nvl(l_rate, 0);
    end;
  
  exception
    when others then
      return nvl(l_rate, 0);
    
  END;
  --OD Variable Rate for CASA Sampath Ends

  --Referral Sampath Starts
  FUNCTION FN_GET_SALE_CHANNEL(P_ACC_NO IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN STTM_CUSTOMER_CUSTOM.SALE_CHANNEL%TYPE AS

    L_SALE_CHANNEL STTM_CUSTOMER_CUSTOM.SALE_CHANNEL%TYPE;

  BEGIN

    BEGIN

      SELECT A.SALE_CHANNEL
        INTO L_SALE_CHANNEL
        FROM sttm_cust_account_custom A
       WHERE A.CUST_AC_NO = P_ACC_NO;

    EXCEPTION
      WHEN OTHERS THEN
        L_SALE_CHANNEL := NULL;

    END;

    DBG('L_SALE_CHANNEL=' || L_SALE_CHANNEL);

    RETURN L_SALE_CHANNEL;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE SALE CHANNEL DETAILS');

      L_SALE_CHANNEL := NULL;
      RETURN L_SALE_CHANNEL;

  END FN_GET_SALE_CHANNEL;

  FUNCTION FN_GET_CUST_NAME(P_PERSON_TYPE IN VARCHAR2,
                            P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
    RETURN STTM_CUSTOMER.CUSTOMER_NAME1%TYPE AS

    L_CUST_NAME STTM_CUSTOMER.CUSTOMER_NAME1%TYPE;

    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;

  BEGIN

    IF P_PERSON_TYPE = 'RP' THEN
      BEGIN

        SELECT REFERRAL_PERSON
          INTO L_REFERRAL_PERSON
          FROM sttm_cust_account_custom A
         WHERE A.CUST_AC_NO = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_PERSON := NULL;

      END;

      DBG('L_REFERRAL_PERSON=' || L_REFERRAL_PERSON);

      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = L_REFERRAL_PERSON;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;

    END IF;

    IF P_PERSON_TYPE = 'RO' THEN

      BEGIN

        SELECT A.RELATIONSHIP_OFFICER
          INTO L_RELATIONSHIP_OFFICER
          FROM sttm_cust_account_custom A
         WHERE A.CUST_AC_NO = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_RELATIONSHIP_OFFICER := NULL;

      END;

      DBG('L_RELATIONSHIP_OFFICER=' || L_RELATIONSHIP_OFFICER);

      BEGIN
        SELECT A.CUSTOMER_NAME1
          INTO L_CUST_NAME
          FROM STTM_CUSTOMER A
         WHERE A.CUSTOMER_NO = L_RELATIONSHIP_OFFICER;
      EXCEPTION
        WHEN OTHERS THEN
          L_CUST_NAME := NULL;
      END;

    END IF;

    DBG('L_CUST_NAME=' || L_CUST_NAME);

    RETURN L_CUST_NAME;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN GETTING THE CUSTOMER NAME');

      L_CUST_NAME := NULL;
      RETURN L_CUST_NAME;

  END FN_GET_CUST_NAME;
  --Referral Sampath Ends
  --SOKUN CHNAGE TO GET REFERRAL AND RELATIONSHIP
  FUNCTION FN_GET_REFERRAL_PERSON(P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
  RETURN STTM_CUSTOMER_CUSTOM.REFERRAL_PERSON%TYPE AS

    L_REFERRAL_PERSON      STTM_CUSTOMER_CUSTOM.REFERRAL_PERSON%TYPE;
  BEGIN

   BEGIN

        SELECT REFERRAL_PERSON
          INTO L_REFERRAL_PERSON
          FROM sttm_cust_account_custom A
         WHERE A.CUST_AC_NO = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_REFERRAL_PERSON := NULL;

      END;

    RETURN L_REFERRAL_PERSON;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_REFERRAL_PERSON');

      L_REFERRAL_PERSON := NULL;
      RETURN L_REFERRAL_PERSON;

  END FN_GET_REFERRAL_PERSON;
  FUNCTION FN_GET_RELATIONSHIP_OFFICER(P_ACC_NO      IN STTM_CUST_ACCOUNT.CUST_NO%TYPE)
  RETURN STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE AS

    L_RELATIONSHIP_OFFICER STTM_CUSTOMER_CUSTOM.RELATIONSHIP_OFFICER%TYPE;
  BEGIN

   BEGIN

       SELECT A.RELATIONSHIP_OFFICER
          INTO L_RELATIONSHIP_OFFICER
          FROM sttm_cust_account_custom A
         WHERE A.CUST_AC_NO = P_ACC_NO;

      EXCEPTION
        WHEN OTHERS THEN
          L_RELATIONSHIP_OFFICER := NULL;

      END;

    RETURN L_RELATIONSHIP_OFFICER;

  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_RELATIONSHIP_OFFICER');

      L_RELATIONSHIP_OFFICER := NULL;
      RETURN L_RELATIONSHIP_OFFICER;

  END FN_GET_RELATIONSHIP_OFFICER;
  --END SOKUN CHNAGE TO GET REFERRAL AND RELATIONSHIP
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_stdcusac         IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Build_type_structure..');

    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of stpks_stdcusac_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_stdcusac         IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

     --sampath starts for EA02
    L_COUNT NUMBER := 0;
    --sampath ends for EA02
	
	--OD Variable Rate for CASA Sampath Starts
    l_user_rate    number := 0;
    L_MAX_EFF_DATE ictms_acc_effdt.UDE_EFF_DT%type;
    L_EFF_DT_COUNT NUMBER := 0;
    --OD Variable Rate for CASA Sampath Ends

  BEGIN

    Dbg('In Fn_Pre_Check_Mandatory');
	
	--OD Variable Rate for CASA Sampath Starts
    IF P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS IN
       ('PR01', 'BO01', 'MA01') THEN
    
      dbg('p_stdcusac.v_ictm_acc_custom.rate_type=' ||
          p_stdcusac.v_ictm_acc_custom.rate_type);
    
      --dbg('prod=' || P_STDCUSAC.v_ictms_acc_pr(1).PROD);
      dbg('prod count=' || P_STDCUSAC.v_ictms_acc_pr.count);
      begin
        null;
      exception
        when others then
          null;
      end;
    
      IF P_ACTION_CODE IN ('UDEPOP', 'NEW') THEN
      
        IF p_stdcusac.v_ictm_acc_custom.rate_type IS NULL AND
           P_STDCUSAC.v_ictms_acc_pr.count > 0 THEN
        
          Pr_Log_Error(p_Source,
                       p_Function_Id,
                       'ST-ODACC-02',
                       P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS);
        
          RETURN FALSE;
        
        END IF;
      
        IF P_ACTION_CODE IN
           (CSPKS_REQ_GLOBAL.p_New, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
        
          IF p_stdcusac.v_ictm_acc_custom.resolved_value IS NULL AND
             P_STDCUSAC.v_ictms_acc_pr.count > 0 THEN
          
            Pr_Log_Error(p_Source,
                         p_Function_Id,
                         'ST-ODACC-07',
                         P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS);
          
            RETURN FALSE;
          
            null;
          
          END IF;
        
        END IF;
      
      END IF;
    
      --FOR G IN p_stdcusac.v_ictms_acc_effdt.FIRST .. p_stdcusac.v_ictms_acc_effdt.LAST LOOP
      IF p_stdcusac.v_ictms_acc_effdt.COUNT = 0 AND
         P_ACTION_CODE IN ('UDEPOP') THEN
      
        Pr_Log_Error(p_Source,
                     p_Function_Id,
                     'ST-ODACC-04',
                     P_STDCUSAC.v_sttms_cust_account.ACCOUNT_CLASS);
      
        RETURN FALSE;
      
      END IF;
      --END LOOP;
    
      IF p_stdcusac.v_ictm_acc_custom.RATE_TYPE = 'F' THEN
      
        IF p_stdcusac.v_ictms_acc_udevals.COUNT > 0 THEN
        
          --issue starts
          L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(1).UDE_EFF_DT;
        
          FOR G IN p_stdcusac.v_ictms_acc_effdt.FIRST .. p_stdcusac.v_ictms_acc_effdt.LAST LOOP
          
            IF p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT > L_MAX_EFF_DATE THEN
            
              L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT;
            
            END IF;
          
          END LOOP;
          --issue ends
        
          FOR G IN p_stdcusac.v_ictms_acc_udevals.FIRST .. p_stdcusac.v_ictms_acc_udevals.LAST LOOP
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .rate_code is not null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --issue fix added AND condition
            
              Pr_Log_Error(p_Source, p_Function_Id, 'ST-ODACC-01', NULL);
            
              RETURN FALSE;
            
            end if;
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .ude_value is not null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --HERE ADDED LATER AND CONDITION  then
            
              l_user_rate := p_stdcusac.v_ictms_acc_udevals(G).ude_value;
            
            end if;
          
          END LOOP;
        
        END IF;
      
        p_stdcusac.v_ictm_acc_custom.resolved_value := nvl(l_user_rate, 0);
      
      END IF;
    
      IF p_stdcusac.v_ictm_acc_custom.RATE_TYPE = 'V' THEN
      
        IF p_stdcusac.v_ictms_acc_effdt.COUNT > 0 THEN
        
          L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(1).UDE_EFF_DT; --issue changes
        
          FOR G IN p_stdcusac.v_ictms_acc_effdt.FIRST .. p_stdcusac.v_ictms_acc_effdt.LAST LOOP
          
            IF p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT IS NULL THEN
            
              Pr_Log_Error(p_Source, p_Function_Id, 'ST-ODACC-06', NULL);
            
              RETURN FALSE;
            
            END IF;
          
            --issue starts
            IF p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT > L_MAX_EFF_DATE THEN
            
              L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT;
            
            END IF;
            --issue ends
          
          END LOOP;
        
        END IF;
      
        DBG('p_stdcusac.v_ictms_acc_udevals.COUNT=' ||
            p_stdcusac.v_ictms_acc_udevals.COUNT);
      
        --Get latest effective date
        --issue starts
        DBG('p_stdcusac.v_ictms_acc_effdt.COUNT=' ||
            p_stdcusac.v_ictms_acc_effdt.COUNT);
        DBG('L_MAX_EFF_DATE=' || L_MAX_EFF_DATE);
        BEGIN
          SELECT COUNT(1)
            INTO L_EFF_DT_COUNT
            FROM ICTM_ACC_EFFDT A
           WHERE A.ACC = p_stdcusac.v_sttms_cust_account.CUST_AC_NO
             AND A.BRN = P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE
             AND TO_CHAR(A.UDE_EFF_DT, 'DD-MON-YYYY') = L_MAX_EFF_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_EFF_DT_COUNT := 0;
        END;
      
        DBG('L_EFF_DT_COUNT=' || L_EFF_DT_COUNT);
        --issue ends
      
        IF p_stdcusac.v_ictms_acc_udevals.COUNT > 0 /*AND L_EFF_DT_COUNT > 0 */
         THEN
        
          FOR G IN p_stdcusac.v_ictms_acc_udevals.FIRST .. p_stdcusac.v_ictms_acc_udevals.LAST LOOP
          
            dbg('p_stdcusac.v_ictms_acc_udevals(G).UDE_EFF_DT=' || p_stdcusac.v_ictms_acc_udevals(G)
                .UDE_EFF_DT);
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .rate_code is null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --issue changes added AND condition
            
              Pr_Log_Error(p_Source, p_Function_Id, 'ST-ODACC-03', NULL);
            
              RETURN FALSE;
            
            end if;
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .ude_value is not null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --HERE ADDED LATER AND CONDITION
            
              l_user_rate := p_stdcusac.v_ictms_acc_udevals(G).ude_value;
            
            end if;
          
            if p_stdcusac.v_ictms_acc_udevals(G).UDE_ID <> 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .rate_code is not null then
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'ST-ODACC-05',
                           p_stdcusac.v_ictms_acc_udevals(G).UDE_ID);
            
              RETURN FALSE;
            
            end if;
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .rate_code is null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --issue changes added AND condition
            
              Pr_Log_Error(p_Source,
                           p_Function_Id,
                           'ST-ODACC-02',
                           p_stdcusac.v_ictms_acc_udevals(G).UDE_ID);
            
              RETURN FALSE;
            
            end if;
          
          END LOOP;
        
        END IF;
      
        DBG('l_user_rate=' || l_user_rate);
      
        p_stdcusac.v_ictm_acc_custom.resolved_value := nvl(l_user_rate, 0) +
                                                       NVL(FN_GET_RATE_CODE_VALUE(P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE,
                                                                                  P_STDCUSAC.v_sttms_cust_account.CCY),
                                                           0);
      
        DBG('p_stdcusac.v_ictm_acc_custom.resolved_value=' ||
            p_stdcusac.v_ictm_acc_custom.resolved_value);
      
      END IF;
    
    END IF;
    --OD Variable Rate for CASA Sampath Ends

    --Fix for storing account custom fields itnto custom table Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      p_stdcusac.v_sttm_cust_account_custom.branch_code := p_stdcusac.v_sttms_cust_account.branch_code;
      p_stdcusac.v_sttm_cust_account_custom.cust_ac_no  := p_stdcusac.v_sttms_cust_account.cust_ac_no;
      p_stdcusac.v_sttm_cust_account_custom.ccy         := p_stdcusac.v_sttms_cust_account.ccy;
      p_stdcusac.v_sttm_cust_account_custom.cust_no     := p_stdcusac.v_sttms_cust_account.cust_no;
    END IF;
    --Fix for storing account custom fields itnto custom table Sampath Ends

   --sampath starts for EA02
    IF p_Action_Code IN (CSPKS_REQ_GLOBAL.P_NEW) THEN

      IF p_stdcusac.v_sttms_cust_account.ACCOUNT_CLASS = 'EA02' THEN

        BEGIN

          SELECT COUNT(1)
            INTO L_COUNT
            FROM STTM_CUST_ACCOUNT A
           WHERE A.CUST_NO = p_stdcusac.v_sttms_cust_account.CUST_NO
             AND A.ACCOUNT_CLASS = 'EA02'
             AND A.RECORD_STAT = 'O'
             AND A.ONCE_AUTH = 'Y';

        EXCEPTION
          WHEN OTHERS THEN
            L_COUNT := 0;
        END;

        IF L_COUNT >=5 THEN

          Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-001', NULL);

          RETURN FALSE;

        END IF;

        IF p_stdcusac.v_sttms_cust_account.JOINT_AC_INDICATOR = 'J' THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'AC-EACC-002', NULL);

          RETURN FALSE;

        END IF;

      END IF;

    END IF;
    --sampath ends for EA02

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      IF CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE', 'FLEXCUBE') THEN

     IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) AND CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXCUBE') THEN
        IF P_STDCUSAC.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER IS NULL AND NVL(global.user_id, '**') <> 'SYSTEM' THEN
          DBG('Relationship officer should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-024', '');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.v_sttm_cust_account_custom.SALE_CHANNEL IS NULL AND NVL(global.user_id, '**') <> 'SYSTEM' THEN
          DBG('Sale Channel should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-025', '');
          RETURN FALSE;
        END IF;

    END IF;

    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_MODIFY) AND CSPKS_REQ_GLOBAL.G_HEADER('SOURCE') IN ('FLEXIPRINCE') THEN
        IF P_STDCUSAC.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER IS NULL THEN
          DBG('Relationship officer should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-024', '');
          RETURN FALSE;
        END IF;

        IF P_STDCUSAC.v_sttm_cust_account_custom.SALE_CHANNEL IS NULL THEN
          DBG('Sale Channel should not be null for Individual customers');
          PR_LOG_ERROR(p_Function_id, 'FLEXCUBE', 'ST-PRIN-025', '');
          RETURN FALSE;
        END IF;

    END IF;

      END IF;

    END IF;
    --Referral Sampath Ends

    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS

   --AIA SI Payment Account Closure Validation Starts
  L_COUNT NUMBER;
   --AIA SI Payment Account Closure Validation Ends

  BEGIN

    Dbg('In Fn_Post_Check_Mandatory..');

  --AIA SI Payment Account Closure Validation Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_CLOSE) THEN
      BEGIN
        SELECT COUNT(1)
          INTO L_COUNT
          FROM IFTB_AIA_SI_MASTER A
         WHERE A.CUST_AC_NO = p_stdcusac.v_sttms_cust_account.CUST_AC_NO
           AND RECORD_STAT = 'O'
           AND ONCE_AUTH = 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('ERROR CODE=' || SQLCODE);
          DBG('ERROR MESSAGE=' || SQLERRM);
      END;

      IF L_COUNT > 0 THEN

        Pr_Log_Error(p_Source, p_Function_Id, 'IF-AIA-006', NULL);

        RETURN FALSE;

      END IF;
    END IF;
    --AIA SI Payment Account Closure Validation Ends

    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                                       p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  --Referral Sampath Starts
    L_STTM_CUST_ACCOUNT_CUSTOM STTM_CUST_ACCOUNT_CUSTOM%ROWTYPE;
    --Referral Sampath Ends

  BEGIN

    Dbg('In Fn_Pre_Default_And_Validate..');

  --Referral Sampath Starts

    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_MODIFY THEN

      BEGIN

        SELECT *
          INTO L_STTM_CUST_ACCOUNT_CUSTOM
          FROM STTM_CUST_ACCOUNT_CUSTOM A
         WHERE A.CUST_AC_NO =
               p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO
           AND A.BRANCH_CODE =
               p_Wrk_stdcusac.v_sttms_cust_account.BRANCH_CODE;

      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT_CUSTOM := NULL;
      END;

      DBG('L_STTM_CUST_ACCOUNT_CUSTOM.BRANCH_CODE='||L_STTM_CUST_ACCOUNT_CUSTOM.BRANCH_CODE);
      DBG('L_STTM_CUST_ACCOUNT_CUSTOM.CUST_AC_NO='||L_STTM_CUST_ACCOUNT_CUSTOM.CUST_AC_NO);
      DBG('L_STTM_CUST_ACCOUNT_CUSTOM.RELATIONSHIP_OFFICER='||L_STTM_CUST_ACCOUNT_CUSTOM.RELATIONSHIP_OFFICER);
      DBG('L_STTM_CUST_ACCOUNT_CUSTOM.REFERRAL_PERSON='||L_STTM_CUST_ACCOUNT_CUSTOM.REFERRAL_PERSON);

      IF L_STTM_CUST_ACCOUNT_CUSTOM.BRANCH_CODE IS NOT NULL AND
         L_STTM_CUST_ACCOUNT_CUSTOM.CUST_AC_NO IS NOT NULL THEN

        p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := L_STTM_CUST_ACCOUNT_CUSTOM.RELATIONSHIP_OFFICER;
        p_Wrk_stdcusac.v_sttm_cust_account_custom.REFERRAL_PERSON      := L_STTM_CUST_ACCOUNT_CUSTOM.REFERRAL_PERSON;

      END IF;

      DBG('p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER='||p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER);
      DBG('p_Wrk_stdcusac.v_sttm_cust_account_custom.REFERRAL_PERSON='||p_Wrk_stdcusac.v_sttm_cust_account_custom.REFERRAL_PERSON);

    END IF;

    --Referral Sampath Ends

    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Prev_stdcusac    IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Post_Default_And_Validate..');

    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                            p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    --Coral Integration with Flexcube Changes commented starts
    --AML Integrations Changes Starts
    --L_FIELD_VAL_2 CSTM_FUNCTION_USERDEF_FIELDS.FIELD_VAL_2%TYPE; --Coral Integration with Flexcube Changes Commented
    --AML Integrations Changes Ends
    --Coral Integration with Flexcube Changes commented Ends
	
	--OD Variable Rate for CASA Sampath Starts
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    l_user_rate         number := 0;
    L_RATE_TYPE         ICTM_ACC_CUSTOM.RATE_TYPE%TYPE;
  
    L_MAX_EFF_DATE ictms_acc_effdt.UDE_EFF_DT%type;
    L_EFF_DT_COUNT NUMBER := 0;
  
    --OD Variable Rate for CASA Sampath Ends
	
  BEGIN

    Dbg('In Fn_Pre_Upload_Db..');

  --Coral Integration with Flexcube Changes commented starts
    --AML Integrations Changes Starts
    /*IF P_ACTION_CODE IN ('NEW') THEN

      BEGIN

        L_FIELD_VAL_2 := CSPKS_AML_INTEGRATION_CUSTOM.FN_UDF_VAL(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_NO,
                                                                 'AML_VALIDATED');

        IF L_FIELD_VAL_2 = 'No' THEN

          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_frozen := 'Y';
          P_WRK_STDCUSAC.v_sttms_cust_account.ac_stat_no_dr  := 'Y';
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to SELECT UDF Value');
          DBG(SQLERRM);
      END;
    END IF;*/

    --AML Integrations Changes ends
    --Coral Integration with Flexcube Changes commented starts

    --Fix for storing account custom fields itnto custom table Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN
      p_Wrk_stdcusac.v_sttm_cust_account_custom.branch_code := p_Wrk_stdcusac.v_sttms_cust_account.branch_code;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.cust_ac_no  := p_Wrk_stdcusac.v_sttms_cust_account.cust_ac_no;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.ccy         := p_wrk_stdcusac.v_sttms_cust_account.ccy;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.cust_no     := p_Wrk_stdcusac.v_sttms_cust_account.cust_no;
    END IF;
    --Fix for storing account custom fields itnto custom table Sampath Ends
	
	--OD Variable Rate for CASA Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.p_Modify) THEN
    
      dbg('p_stdcusac.v_ictm_acc_custom.RATE_TYPE=' || L_RATE_TYPE);
      dbg('p_stdcusac.v_ictm_acc_custom.resolved_value=' ||
          p_stdcusac.v_ictm_acc_custom.resolved_value);
      dbg('p_WRK_stdcusac.v_ictm_acc_custom.resolved_value=' ||
          p_WRK_stdcusac.v_ictm_acc_custom.resolved_value);
    
      IF NVL(p_wrk_stdcusac.v_ictm_acc_custom.RATE_TYPE, '*') = 'F' THEN
        
      
      IF p_stdcusac.v_ictms_acc_udevals.COUNT > 0 THEN
        
          --issue starts
          L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(1).UDE_EFF_DT;
        
          FOR G IN p_stdcusac.v_ictms_acc_effdt.FIRST .. p_stdcusac.v_ictms_acc_effdt.LAST LOOP
          
            IF p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT > L_MAX_EFF_DATE THEN
            
              L_MAX_EFF_DATE := p_stdcusac.v_ictms_acc_effdt(G).UDE_EFF_DT;
            
            END IF;
          
          END LOOP;
          --issue ends
        
          FOR G IN p_stdcusac.v_ictms_acc_udevals.FIRST .. p_stdcusac.v_ictms_acc_udevals.LAST LOOP
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .rate_code is not null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --issue fix added AND condition
            
              Pr_Log_Error(p_Source, p_Function_Id, 'ST-ODACC-01', NULL);
            
              RETURN FALSE;
            
            end if;
          
            if p_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_stdcusac.v_ictms_acc_udevals(G)
               .ude_value is not null AND p_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --HERE ADDED LATER AND CONDITION  then
            
              l_user_rate := p_stdcusac.v_ictms_acc_udevals(G).ude_value;
            
            end if;
          
          END LOOP;
        
        END IF;
      
        p_wrk_stdcusac.v_ictm_acc_custom.resolved_value := nvl(l_user_rate, 0);
      
        --updating resolved value
        begin
          update ictm_acc_custom a
             set a.resolved_value = p_wrk_stdcusac.v_ictm_acc_custom.resolved_value
           where a.brn = p_WRK_stdcusac.v_sttms_cust_account.branch_code
             and a.acc = p_WRK_stdcusac.v_sttms_cust_account.cust_ac_no;
        exception
          when others then
            dbg('failed in updating the resolved value');
        end;
      
      END IF;
    
      IF NVL(p_wrk_stdcusac.v_ictm_acc_custom.RATE_TYPE, '*') = 'V' THEN
      
        IF p_WRK_stdcusac.v_ictms_acc_effdt.COUNT > 0 THEN
        
          L_MAX_EFF_DATE := p_WRK_stdcusac.v_ictms_acc_effdt(1).UDE_EFF_DT; --issue changes
        
          FOR G IN p_WRK_stdcusac.v_ictms_acc_effdt.FIRST .. p_WRK_stdcusac.v_ictms_acc_effdt.LAST LOOP
          
            --issue starts
            IF p_WRK_stdcusac.v_ictms_acc_effdt(G)
             .UDE_EFF_DT > L_MAX_EFF_DATE THEN
            
              L_MAX_EFF_DATE := p_WRK_stdcusac.v_ictms_acc_effdt(G)
                                .UDE_EFF_DT;
            
            END IF;
            --issue ends
          
          END LOOP;
        
        END IF;
      
        DBG('p_WRK_stdcusac.v_ictms_acc_udevals.COUNT=' ||
            p_WRK_stdcusac.v_ictms_acc_udevals.COUNT);
      
        --Get latest effective date
        --issue starts
        DBG('p_WRK_stdcusac.v_ictms_acc_effdt.COUNT=' ||
            p_WRK_stdcusac.v_ictms_acc_effdt.COUNT);
        DBG('L_MAX_EFF_DATE=' || L_MAX_EFF_DATE);
        BEGIN
          SELECT COUNT(1)
            INTO L_EFF_DT_COUNT
            FROM ICTM_ACC_EFFDT A
           WHERE A.ACC = p_WRK_stdcusac.v_sttms_cust_account.CUST_AC_NO
             AND A.BRN = p_WRK_stdcusac.v_sttms_cust_account.BRANCH_CODE
             AND TO_CHAR(A.UDE_EFF_DT, 'DD-MON-YYYY') = L_MAX_EFF_DATE;
        EXCEPTION
          WHEN OTHERS THEN
            L_EFF_DT_COUNT := 0;
        END;
      
        DBG('L_EFF_DT_COUNT=' || L_EFF_DT_COUNT);
        --issue ends
        --apple ends
      
        IF p_wrk_stdcusac.v_ictms_acc_udevals.COUNT > 0 THEN
        
          FOR G IN p_wrk_stdcusac.v_ictms_acc_udevals.FIRST .. p_wrk_stdcusac.v_ictms_acc_udevals.LAST LOOP
          
            if p_wrk_stdcusac.v_ictms_acc_udevals(G)
             .UDE_ID = 'DR_INT_RATE' AND p_wrk_stdcusac.v_ictms_acc_udevals(G)
               .ude_value is not null AND p_wrk_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT >= L_MAX_EFF_DATE then
              --issue changes added AND condition
            
              DBG('l_user_rate LOOP=' || l_user_rate);
              DBG('p_wrk_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT=' || p_wrk_stdcusac.v_ictms_acc_udevals(G)
                  .UDE_EFF_DT);
            
              l_user_rate := p_wrk_stdcusac.v_ictms_acc_udevals(G).ude_value;
            
            end if;
          
          END LOOP;
        
        END IF;
      
        dbg('l_user_rate=' || l_user_rate);
      
        p_WRK_stdcusac.v_ictm_acc_custom.resolved_value := nvl(l_user_rate,
                                                               0) +
                                                           NVL(FN_GET_RATE_CODE_VALUE(P_WRK_STDCUSAC.v_sttms_cust_account.BRANCH_CODE,
                                                                                      P_WRK_STDCUSAC.v_sttms_cust_account.CCY),
                                                               0);
      
        DBG('p_WRK_stdcusac.v_ictm_acc_custom.resolved_value apple=' ||
            p_WRK_stdcusac.v_ictm_acc_custom.resolved_value);
      
        /*IF P_ACTION_CODE IN ('MODIFY', 'SAVE') THEN
        
          dbg('p_stdcusac.v_ictm_acc_custom.resolved_value=' ||
              p_stdcusac.v_ictm_acc_custom.resolved_value);
          dbg('p_Wrk_stdcusac.v_ictm_acc_custom.resolved_value=' ||
              p_Wrk_stdcusac.v_ictm_acc_custom.resolved_value);
          --p_Wrk_stdcusac.v_ictm_acc_custom.resolved_value := 100;
          dbg('p_Wrk_stdcusac.v_ictm_acc_custom.resolved_value=' ||
              p_Wrk_stdcusac.v_ictm_acc_custom.resolved_value);
        
          return false;
        
        END IF;*/
      
        --updating resolved value
        begin
          update ictm_acc_custom a
             set a.resolved_value = p_WRK_stdcusac.v_ictm_acc_custom.resolved_value
           where a.brn = p_WRK_stdcusac.v_sttms_cust_account.branch_code
             and a.acc = p_WRK_stdcusac.v_sttms_cust_account.cust_ac_no;
        exception
          when others then
            dbg('failed in updating the resolved value');
        end;
      
      END IF;
    
    END IF;
    --OD Variable Rate for CASA Sampath Ends

    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_prev_stdcusac    IN stpks_stdcusac_Main.Ty_stdcusac,
                             p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    ----SV UDF capture starts
    L_CARD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.CARD_ID%TYPE;
    L_PROD_ID IFTB_SVCARD_CUSTDETAILS_CUSTOM.PROD_ID%TYPE;
    ----SV UDF capture ends
  BEGIN

    Dbg('In Fn_Post_Upload_Db..');

    ----SV UDF capture starts
    DBG('In Fn_Post_Upload_Db.. pavan');
    IF P_ACTION_CODE IN ('NEW', 'MODIFY') THEN

      if (P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.atm_facility = 'Y' AND
         P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.ACCOUNT_TYPE NOT IN
         ('Y', 'N')) then

        L_PROD_ID := ifpks_sv_cdc_custom.FN_GET_PROD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);
        L_CARD_ID := ifpks_sv_cdc_custom.FN_GET_CARD_ID(P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.BRANCH_CODE,
                                                        P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO);

        IF (L_PROD_ID IS null OR L_CARD_ID is null) THEN
          DEBUG.PR_DEBUG('**', 'CARD ID OR PRODUCT_ID ARE NULL');
          P_ERR_CODE   := 'ST-SV-001';
          P_ERR_PARAMS := NULL;
          RETURN FALSE;
        END IF;
      end if;

    --special premium account changes starts
    IF P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.SPL_AC_GEN = 'Y' THEN
      BEGIN
        UPDATE STTM_SPL_ACC_RANGE_DIG
           SET STATUS = 'Y'
         WHERE ACCOUNT_NO = P_WRK_STDCUSAC.V_STTMS_CUST_ACCOUNT.CUST_AC_NO
           AND STATUS = 'N';
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED TO UPDATE SPECIAL ACCOUNT RANGE');
      END;
    END IF;
    --special premium account changes ends

    END IF;

    ----SV UDF capture ends

    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_stdcusac         IN stpks_stdcusac_Main.Ty_stdcusac,
                        p_Wrk_stdcusac     IN OUT stpks_stdcusac_Main.Ty_stdcusac,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN

    Dbg('In Fn_Pre_Query..');

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      p_Wrk_stdcusac.v_sttm_cust_account_custom.sale_channel         := p_stdcusac.v_sttm_cust_account_custom.sale_channel;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.referral_person      := p_stdcusac.v_sttm_cust_account_custom.referral_person;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := p_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER;

    END IF;

    /*IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN

      p_Wrk_stdcusac.v_sttm_cust_account_custom.sale_channel         := FN_GET_SALE_CHANNEL(p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
      p_Wrk_stdcusac.v_sttm_cust_account_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                         p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
      p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                         p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);

    END IF;*/
    --Referral Sampath Ends

    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of stpks_stdcusac_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_stdcusac         IN stpks_stdcusac_Main.ty_stdcusac,
                         p_wrk_stdcusac     IN OUT stpks_stdcusac_Main.ty_stdcusac,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
						 
  --OD Variable Rate for CASA Sampath Starts
    L_STTM_CUST_ACCOUNT STTM_CUST_ACCOUNT%ROWTYPE;
    l_user_rate         number := 0;
    L_RATE_TYPE         ICTM_ACC_CUSTOM.RATE_TYPE%TYPE;
  
    L_MAX_EFF_DATE ictms_acc_effdt.UDE_EFF_DT%type;
    L_EFF_DT_COUNT NUMBER := 0;
  
    --OD Variable Rate for CASA Sampath Ends
  
  BEGIN

    Dbg('In Fn_Post_Query..');

  --Referral Sampath Starts
    IF P_ACTION_CODE IN (CSPKS_REQ_GLOBAL.P_NEW, CSPKS_REQ_GLOBAL.P_MODIFY) THEN

      p_Wrk_stdcusac.v_sttm_cust_account_custom.sale_channel         := p_stdcusac.v_sttm_cust_account_custom.sale_channel;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.referral_person      := p_stdcusac.v_sttm_cust_account_custom.referral_person;
      p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := p_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER;

    END IF;
  --SOKUN CHANGE TO ASSIGN VALUE FOR REFERRAL AND OFFICER WHEN QUERY
  IF CSPKS_REQ_GLOBAL.G_HEADER('ACTION') IN (CSPKS_REQ_GLOBAL.P_QUERY) THEN
    p_Wrk_stdcusac.v_sttm_cust_account_custom.sale_channel         := FN_GET_SALE_CHANNEL(p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
    p_Wrk_stdcusac.v_sttm_cust_account_custom.referral_person := FN_GET_REFERRAL_PERSON(p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
    p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := FN_GET_RELATIONSHIP_OFFICER(p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
    END IF;
  --END SOKUN CHANGE TO ASSIGN VALUE FOR REFERRAL AND OFFICER WHEN QUERY

   /* IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN

      p_Wrk_stdcusac.v_sttm_cust_account_custom.sale_channel         := FN_GET_SALE_CHANNEL(p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
      p_Wrk_stdcusac.v_sttm_cust_account_custom.referral_person      := FN_GET_CUST_NAME('RP',
                                                                                         p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);
      p_Wrk_stdcusac.v_sttm_cust_account_custom.RELATIONSHIP_OFFICER := FN_GET_CUST_NAME('RO',
                                                                                         p_Wrk_stdcusac.v_sttms_cust_account.CUST_AC_NO);

    END IF;*/
    --Referral Sampath Ends
	
	--OD Variable Rate for CASA Sampath Starts
    IF P_ACTION_CODE = CSPKS_REQ_GLOBAL.P_QUERY THEN
    
      --p_wrk_stdcusac.v_ictm_acc_custom.resolved_value := 100;
    
      BEGIN
        SELECT *
          INTO L_STTM_CUST_ACCOUNT
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = p_stdcusac.v_sttms_cust_account.cust_Ac_no;
      EXCEPTION
        WHEN OTHERS THEN
          L_STTM_CUST_ACCOUNT := NULL;
      END;
    
      dbg(p_stdcusac.v_sttms_cust_account.cust_Ac_no);
      dbg('P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE=' ||
          P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE);
    
      dbg(NVL(FN_GET_RATE_CODE_VALUE('029', 'USD'), 0));
      dbg('L_STTM_CUST_ACCOUNT.BRANCH_CODE=' ||
          L_STTM_CUST_ACCOUNT.BRANCH_CODE);
      dbg('L_STTM_CUST_ACCOUNT.CCY=' || L_STTM_CUST_ACCOUNT.CCY);
    
      BEGIN
        select A.RATE_TYPE
          INTO L_RATE_TYPE
          from ictm_acc_custom a
         where a.acc = p_stdcusac.v_sttms_cust_account.cust_Ac_no
           and a.brn = P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          L_RATE_TYPE := null;
      END;
    
      dbg('p_stdcusac.v_ictm_acc_custom.RATE_TYPE=' || L_RATE_TYPE);
    
      BEGIN
        select A.RATE_TYPE
          INTO L_RATE_TYPE
          from ictm_acc_custom a
         where a.acc = p_stdcusac.v_sttms_cust_account.cust_Ac_no
           and a.brn = P_STDCUSAC.v_sttms_cust_account.BRANCH_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          L_RATE_TYPE := null;
      END;
    
      IF L_STTM_CUST_ACCOUNT.BRANCH_CODE IS NOT NULL AND
         L_STTM_CUST_ACCOUNT.CCY IS NOT NULL THEN
      
        IF NVL(L_RATE_TYPE, '*') = 'V' THEN
        
          DBG('p_wrk_stdcusac.v_ictms_acc_udevals.COUNT=' ||
              p_wrk_stdcusac.v_ictms_acc_udevals.COUNT);
        
          --apple starts
          IF p_WRK_stdcusac.v_ictms_acc_effdt.COUNT > 0 THEN
          
            L_MAX_EFF_DATE := p_WRK_stdcusac.v_ictms_acc_effdt(1).UDE_EFF_DT; --issue changes
          
            FOR G IN p_WRK_stdcusac.v_ictms_acc_effdt.FIRST .. p_WRK_stdcusac.v_ictms_acc_effdt.LAST LOOP
            
              --issue starts
              IF p_WRK_stdcusac.v_ictms_acc_effdt(G)
               .UDE_EFF_DT > L_MAX_EFF_DATE THEN
              
                L_MAX_EFF_DATE := p_WRK_stdcusac.v_ictms_acc_effdt(G)
                                  .UDE_EFF_DT;
              
              END IF;
              --issue ends
            
            END LOOP;
          
          END IF;
        
          DBG('p_WRK_stdcusac.v_ictms_acc_udevals.COUNT=' ||
              p_WRK_stdcusac.v_ictms_acc_udevals.COUNT);
        
          --Get latest effective date
          --issue starts
          DBG('p_WRK_stdcusac.v_ictms_acc_effdt.COUNT=' ||
              p_WRK_stdcusac.v_ictms_acc_effdt.COUNT);
          DBG('L_MAX_EFF_DATE=' || L_MAX_EFF_DATE);
          BEGIN
            SELECT COUNT(1)
              INTO L_EFF_DT_COUNT
              FROM ICTM_ACC_EFFDT A
             WHERE A.ACC = p_WRK_stdcusac.v_sttms_cust_account.CUST_AC_NO
               AND A.BRN = p_WRK_stdcusac.v_sttms_cust_account.BRANCH_CODE
               AND TO_CHAR(A.UDE_EFF_DT, 'DD-MON-YYYY') = L_MAX_EFF_DATE;
          EXCEPTION
            WHEN OTHERS THEN
              L_EFF_DT_COUNT := 0;
          END;
        
          DBG('L_EFF_DT_COUNT=' || L_EFF_DT_COUNT);
          --issue ends
          --apple ends
        
          IF p_wrk_stdcusac.v_ictms_acc_udevals.COUNT > 0 THEN
          
            FOR G IN p_wrk_stdcusac.v_ictms_acc_udevals.FIRST .. p_wrk_stdcusac.v_ictms_acc_udevals.LAST LOOP
            
              if p_wrk_stdcusac.v_ictms_acc_udevals(G)
               .UDE_ID = 'DR_INT_RATE' AND p_wrk_stdcusac.v_ictms_acc_udevals(G)
                 .ude_value is not null AND p_wrk_stdcusac.v_ictms_acc_udevals(G)
                 .UDE_EFF_DT >= L_MAX_EFF_DATE then
                --issue changes added AND condition
              
                DBG('l_user_rate LOOP=' || l_user_rate);
                DBG('p_wrk_stdcusac.v_ictms_acc_udevals(G)
               .UDE_EFF_DT=' || p_wrk_stdcusac.v_ictms_acc_udevals(G)
                    .UDE_EFF_DT);
              
                l_user_rate := p_wrk_stdcusac.v_ictms_acc_udevals(G)
                               .ude_value;
              
              end if;
            
            END LOOP;
          
          END IF;
        
          dbg('l_user_rate=' || l_user_rate);
        
          p_WRK_stdcusac.v_ictm_acc_custom.resolved_value := nvl(l_user_rate,
                                                                 0) +
                                                             NVL(FN_GET_RATE_CODE_VALUE(P_WRK_STDCUSAC.v_sttms_cust_account.BRANCH_CODE,
                                                                                        P_WRK_STDCUSAC.v_sttms_cust_account.CCY),
                                                                 0);
        
        END IF;
      
      END IF;
    
    END IF;
    --OD Variable Rate for CASA Sampath Ends

    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of stpks_stdcusac_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END stpks_stdcusac_custom;
