-- Create table
create table ICTM_ACC_CUSTOM
(
  brn            VARCHAR2(3),
  acc            VARCHAR2(20),
  rate_type      CHAR(1),
  resolved_value NUMBER
)
/
alter table ICTM_ACC_CUSTOM add primary key (BRN, ACC)
/