CREATE OR REPLACE PACKAGE STPKS_CORAL_WS_LOG IS

  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : STPKS_CORAL_WS_LOG.spc
  **
  ** Module     : Static Maintenance

  CHANGE HISTORY


  Changed By         : Kore Sampath Kumar
  Change Description : Coral Integration with Flexcube Changes

  Changed By         : Kore Sampath Kumar
  Change Description : Delete CIF from coral table to avoid passing old scan id to AML
  
  Changed By         : Kore Sampath Kumar
  Change Description : AML Name Screening
  Search String		 : AML Name Screening

  -------------------------------------------------------------------------------------------------------
  */

  FUNCTION FN_RETURN_COSMETIC_XML(P_XML IN VARCHAR2) RETURN VARCHAR2;

  PROCEDURE PR_INSERT_MODIFY_IND_CUST(P_UNIQUE_REF_NO      IN VARCHAR2,
                                      P_CUSTOMER_NO        IN VARCHAR2,
                                      P_ACTION_CODE        IN VARCHAR2,
                                      P_CUST_CATEGORY      VARCHAR2,
                                      P_CURR_FULL_NAME_CHK VARCHAR2,
                                      P_CURR_DATE_CHK      VARCHAR2,
                                      P_CURR_COUNTRY_CHK   VARCHAR2,
                                      P_CURR_BIRTH_COUNTRY VARCHAR2,
                                      P_CURR_COUNTRY       VARCHAR2,
                                      P_CURR_NATIONALITY   VARCHAR2,
                                      P_CURR_P_COUNTRY     VARCHAR2,
                                      P_CURR_ECO_SECTOR    VARCHAR2,
                                      P_CURR_OCCUPATION    VARCHAR2,
                                      P_CURR_SECURITY_NO_1 VARCHAR2,
                                      P_CURR_SECURITY_NO_2 VARCHAR2,
                                      P_MODIFY_TIME        DATE,
                                      P_MOD_NO             NUMBER);

  PROCEDURE PR_INSERT_MODIFY_CORP_CUST(P_UNIQUE_REF_NO      IN VARCHAR2,
                                       P_CUSTOMER_NO        IN VARCHAR2,
                                       P_ACTION_CODE        IN VARCHAR2,
                                       P_CUST_CATEGORY      VARCHAR2,
                                       P_CURR_FULL_NAME_CHK VARCHAR2,
                                       P_CURR_DATE_CHK      VARCHAR2,
                                       P_CURR_COUNTRY_CHK   VARCHAR2,
                                       P_COMPLEX_STRUCT     VARCHAR2,
                                       P_COUNTRY            VARCHAR2,
                                       P_R_COUNTRY          VARCHAR2,
                                       P_INCORP_COUNTRY     VARCHAR2,
                                       P_ECO_SECTOR         VARCHAR2,
                                       P_OCCUPATION         VARCHAR2,
                                       P_MODIFY_TIME        DATE,
                                       P_MOD_NO             NUMBER);

  PROCEDURE PR_DELETE_MODIFY_IND_CUST(P_CUSTOMER_NO IN VARCHAR2,
                                      P_MOD_NO      NUMBER);

  PROCEDURE PR_DELETE_MODIFY_CORP_CUST(P_CUSTOMER_NO IN VARCHAR2,
                                       P_MOD_NO      NUMBER);

  PROCEDURE PR_INSERT_CORAL_WS_LOG(P_UNIQUE_REF_NO IN VARCHAR2,
                                   P_CUST_NO       IN VARCHAR2,
                                   P_DATE          IN DATE,
                                   P_REQ_TYPE      IN VARCHAR2,
                                   P_ACTION_CODE   IN VARCHAR2,
                                   P_REQ_MSG       IN CLOB,
								   P_SESSION_UNIQUE_ID IN VARCHAR2); --AML Name Screening 


  --sampath flexi starts
  FUNCTION FN_INSERT_CORAL_WS_LOG(P_UNIQUE_REF_NO IN VARCHAR2,
                                  P_CUST_NO       IN VARCHAR2,
                                  P_SCAN_ID       IN VARCHAR2,

                                  P_DATE        IN DATE,
                                  P_REQ_TYPE    IN VARCHAR2,
                                  P_STATUS      IN VARCHAR2,
                                  P_ACTION_CODE IN VARCHAR2,
                                  P_RISK_LEVEL  IN VARCHAR2,
                                  P_HIT_VALUE   IN VARCHAR2,
								  P_SESSION_UNIQUE_ID IN VARCHAR2)  --AML Name Screening 
								  RETURN BOOLEAN;
  --sampath flexi ends

  --Delete CIF from coral table to avoid passing old scan id to AML Starts
  PROCEDURE PR_DELETE_CORAL_WS_LOG_OVD(P_CUST_NO IN VARCHAR2);
  PROCEDURE PR_DELETE_CORAL_WS_LOG_OVD(P_CUST_NO             IN VARCHAR2,
                                       P_UNIQUE_REFERENCE_NO IN VARCHAR2);
  --Delete CIF from coral table to avoid passing old scan id to AML Ends

  PROCEDURE PR_DELETE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2);

  PROCEDURE PR_INSERT_CORAL_DATA(L_RTN_SCAN_ID   IN VARCHAR2,
                                 L_RETURN_STATUS IN VARCHAR2,
                                 L_FULL_NAME_CHK IN VARCHAR2,
                                 L_DATE_CHK      IN DATE,
                                 L_COUNTRY_CHK   IN VARCHAR2,
                                 L_DATE          IN DATE,
                                 L_STAT          IN VARCHAR2,
                                 L_BRN           IN VARCHAR2);

  PROCEDURE PR_UPDATE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                   P_SCAN_ID      IN VARCHAR2,
                                   P_STATUS       IN CHAR,
                                   P_RISK_LEVEL   IN CHAR,
                                   P_HIT_VALUE    IN VARCHAR2, --added for temp fix
                                   P_RES_MSG      IN CLOB);

  PROCEDURE PR_UPDATE_CORAL_WS_LOG(P_REFERENCE_NO IN VARCHAR2,
                                   P_SCAN_ID      IN VARCHAR2,
                                   P_STATUS       IN CHAR,
                                   P_RES_MSG      IN CLOB);
END STPKS_CORAL_WS_LOG;
