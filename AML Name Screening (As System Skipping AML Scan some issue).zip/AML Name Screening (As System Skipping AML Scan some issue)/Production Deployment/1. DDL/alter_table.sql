alter table sttb_coral_ws_log add (session_unique_id VARCHAR2(16))
/