select * from actb_daily_log a where a.trn_ref_no = '001ADCF212280004';

select * from CSTB_AUTO_SETTLE_BLOCK a where a.contract_ref_no = '001ADCF212280004'