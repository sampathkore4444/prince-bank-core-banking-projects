-- Create table
create table IFTB_ANNUAL_FEE_REFNUM_LOG
(
  ref_num           VARCHAR2(16) not null,
  trn_ref_no        VARCHAR2(16) not null,
  status            CHAR(1),
  error_code        VARCHAR2(11),
  error_param       VARCHAR2(4000),
  invoke_date_start DATE,
  invoke_date_end   DATE
)
/
alter table IFTB_ANNUAL_FEE_REFNUM_LOG add primary key (REF_NUM, TRN_REF_NO)
/
-- Create table
create table IFTB_ANNUAL_FEE_INCOMING_TRACK
(
  inst_id      VARCHAR2(16),
  file_date    DATE,
  file_no      VARCHAR2(16),
  ref_num      VARCHAR2(16) not null,
  request_msg  CLOB,
  status       CHAR(1),
  time_in      DATE,
  cust_no      VARCHAR2(15),
  txn_amount   NUMBER,
  iso_ccy_code NUMBER,
  ccy_code     VARCHAR2(3),
  order_date   DATE,
  cust_ac_no   VARCHAR2(15),
  file_name    VARCHAR2(100),
  purpose      VARCHAR2(15),
  oper_type    CHAR(1)
)
/
-- Create table
create table IFTB_ANNUAL_FEE_INC_TRACK
(
  inst_id      VARCHAR2(16),
  file_date    DATE,
  file_no      VARCHAR2(16),
  ref_num      VARCHAR2(16),
  request_msg  CLOB,
  status       CHAR(1),
  time_in      DATE,
  cust_no      VARCHAR2(15),
  txn_amount   NUMBER,
  iso_ccy_code NUMBER,
  ccy_code     VARCHAR2(3),
  order_date   DATE,
  cust_ac_no   VARCHAR2(15),
  file_name    VARCHAR2(100),
  purpose      VARCHAR2(15),
  oper_type    CHAR(1)
)
/