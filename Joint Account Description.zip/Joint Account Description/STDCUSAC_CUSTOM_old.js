function fnPostAccPickup_CUSTOM()
{
 
      document.getElementById('BLK_CUST_ACCOUNT__ADESC').value = null;
 
	return true;
}