/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software System and is copyrighted by 
**  Oracle Financial Services Software Limited.
**  
**  All rights reserved.  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle Financial Services Software Limited.
**  
**  Oracle Financial Services Software Limited.
**  10-11, SDF I, SEEPZ, Andheri (East),
**  Mumbai - 400 096.
**  India.
**  
**  Copyright (c) 2008 - 2014 by Oracle Financial Services Software Limited. All rights reserved.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : STDCUSAC_CUSTOM.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

function fnPreSave_CVS_JNTACCHLD_CUSTOM(screenArgs) {
		appendData();
		
		var L_ACC_TYPE;
		var L_OP_MODE;
		var L_AC_DESC;
		

		var currRow;
		var totalRows;
		g_prev_gAction = '';
		g_prev_gAction = gAction;
		gAction = 'REP_ALL';
		fcjRequestDOM = buildUBSXml();
		servletURL = "FCClientHandler";
		fcjResponseDOM = fnPost(fcjRequestDOM,servletURL,functionId);
		//PNTFLX01011_FCUBS_12.1_MAT_21310050 starts
		showProcessMsg = false;
		//gAction = '';
		//PNTFLX01011_FCUBS_12.1_MAT_21310050 ends
		if(!fnProcessResponse()){
		gAction=g_prev_gAction;
		return false;
		}

		gAction=g_prev_gAction; 
		appendData();
		var totalRows;

	
	console.log("fnPreSave_CVS_JNTACCHLD_CUSTOM");
	
	L_ACC_TYPE =getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ACCTYPE"));
	
	L_OP_MODE = getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/OPMODE"));
	
	L_AC_DESC = getNodeText( selectSingleNode(dbDataDOM,"BLK_CUST_ACCOUNT/ADESC"));
	
	console.log("L_ACC_TYPE="+L_ACC_TYPE)
	
	console.log("L_OP_MODE="+L_OP_MODE)
	
	console.log("L_AC_DESC="+L_AC_DESC)
	
	parent.document.getElementById('BLK_CUST_ACCOUNT__ACCTYPE').value = L_ACC_TYPE;
	
	parent.document.getElementById('BLK_CUST_ACCOUNT__OPMODE').value = L_OP_MODE;
	
	parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value = L_AC_DESC;	

	if (parent.document.getElementById('BLK_CUST_ACCOUNT__ACCTYPE').value == 'J') 
	{
		
		totalRows = document.getElementById('BLK_JOINTHOLDERS').tBodies[0].rows.length;
		
		console.log("totalRows="+totalRows);

		if (totalRows > 0) 
		{

			for (var i = 0; i < totalRows; i++) 
			{

				if (i != totalRows) 
				{
					
					if (L_OP_MODE == 'E') 
					{
                        
						if (!parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value.includes(document.getElementsByName("JNTHLDDESC")[i].value)) 
						{
						   parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value = parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value + ' / ' + document.getElementsByName("JNTHLDDESC")[i].value;
						}
						
					}

					if (L_OP_MODE == 'J' || L_OP_MODE == 'M' || L_OP_MODE == 'F') 
					{
						if (!parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value.includes(document.getElementsByName("JNTHLDDESC")[i].value)) 
						{
						   parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value = parent.document.getElementById("BLK_CUST_ACCOUNT__ADESC").value + ' & ' + document.getElementsByName("JNTHLDDESC")[i].value;
						}
					}

				}
				
			}
		}

	}


	return true;
}