-- Create table
create table IFTB_KHQR_MASTER
(
  fc_xref_no    VARCHAR2(25),
  dig_ref_no    VARCHAR2(25) not null,
  upload_date   TIMESTAMP(6),
  txn_account   VARCHAR2(20),
  txn_ccy       VARCHAR2(3),
  txn_amount    NUMBER(22,3),
  status        CHAR(1) default 'U',
  error_code    VARCHAR2(25),
  error_message VARCHAR2(255)
)
/
alter table IFTB_KHQR_MASTER add primary key (DIG_REF_NO)
/