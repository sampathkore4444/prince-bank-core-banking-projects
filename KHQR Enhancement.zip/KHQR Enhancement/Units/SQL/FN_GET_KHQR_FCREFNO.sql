CREATE OR REPLACE FUNCTION FN_GET_KHQR_FCREFNO(P_ERR_CODE OUT VARCHAR2)
  RETURN ACTB_DAILY_LOG.TRN_REF_NO%TYPE AS

  L_FCREFNO ACTB_DAILY_LOG.TRN_REF_NO%TYPE;

  l_serial_no  VARCHAR2(16);
  l_trn_ref_no iftb_rft_master.trn_ref_no%TYPE;

  p_err_code1 VARCHAR2(105);

BEGIN

  DEBUG.PR_DEBUG('IF', 'START OF FN_GET_KHQR_FCREFNO');

  IF NOT trpkss.fn_get_product_refno(GLOBAL.current_branch,
                                     'KHQR',
                                     to_Date(fn_sysdate, 'DD-MM-YY'), --global.application_date,
                                     l_serial_no,
                                     L_FCREFNO,
                                     p_err_code1) THEN
  
    DEBUG.PR_DEBUG('IF', 'Failed in generation Transaction Ref No');
  
    P_ERR_CODE := p_err_code1;
  
  ELSE
  
    DEBUG.PR_DEBUG('IF', 'Success in generation Transaction Ref No');
    DEBUG.PR_DEBUG('IF', 'L_FCREFNO=' || L_FCREFNO);
  
  END IF;

  RETURN L_FCREFNO;

EXCEPTION
  WHEN OTHERS THEN
    DEBUG.PR_DEBUG('IF', 'FAILED IN FN_GET_KHQR_FCREFNO');
    DEBUG.PR_DEBUG('IF', 'ERROR COE IN FN_GET_KHQR_FCREFNO=' || SQLCODE);
    DEBUG.PR_DEBUG('IF',
                   'ERROR MESSAGE IN FN_GET_KHQR_FCREFNO=' || SQLERRM);
    P_ERR_CODE := p_err_code1;
    RETURN L_FCREFNO;
  
END FN_GET_KHQR_FCREFNO;
