prompt Importing table sttm_job_definition...
set feedback off
set define off
insert into sttm_job_definition (JOB_CODE, JOB_GROUP, JOB_DESCRIPTION, SCHEDULER, TRG_TYPE, CRON_EXPR, JOB_TYPE, JOB_CLASS_OR_PROC, SIMPLE_TRG_REPEAT, SIMPLE_TRG_FREQUENCY, TRIGGER_LISTENER, ACTIVE, JNDI_NAME, LOGGING_REQD, AUTH_STAT, CHECKER_DT_STAMP, CHECKER_ID, MAKER_DT_STAMP, MOD_NO, ONCE_AUTH, RECORD_STAT, MAKER_ID, SCHED_TYPE, VETO_BLK_TRG, PRIORITY, MSG_QUEUE, MAX_NO_INSTANCES, STARTUP_MODE)
values ('KHQR_INWARD_JOB', 'PLSQL', 'Job to Process KHQR Inward Transaction Step 1', 'SchedulerFactory', 'S', null, 'PLSQL', 'IFPKS_KHQR_PAY_UTILS.PR_PROCESS_KHQR_INWARD_PYMNTS', -1, 60.00, null, 'Y', 'jdbc/fcjdevDS', 'Y', 'A', to_date('03-04-2021 01:18:22', 'dd-mm-yyyy hh24:mi:ss'), 'SAMPATH2', to_date('03-04-2021 01:18:22', 'dd-mm-yyyy hh24:mi:ss'), 1, 'Y', 'O', 'SAMPATH2', 'QUARTZ', 'N', 5, null, 1, 'M');

prompt Done.
