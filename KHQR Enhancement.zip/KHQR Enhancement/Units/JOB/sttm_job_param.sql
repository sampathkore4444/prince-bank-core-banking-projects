prompt Importing table sttm_job_param...
set feedback off
set define off
insert into sttm_job_param (JOB_CODE, PARAM_NAME, DATA_TYPE, PARAM_VALUE)
values ('KHQR_INWARD_JOB', 'NAME', 'VARCHAR', 'OFSS');

prompt Done.
