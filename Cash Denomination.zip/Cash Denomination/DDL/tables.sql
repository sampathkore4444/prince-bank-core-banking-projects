-- Create table
create table IFTB_CCY_DENOM_DTLS
(
  ccy_code    VARCHAR2(3) not null,
  denom_value NUMBER(22,3) not null
)
/
ALTER TABLE IFTB_CCY_DENOM_DTLS ADD PRIMARY KEY(CCY_CODE, DENOM_VALUE)
/
-- Create table
-- Create table
create table IFTB_CASH_DENOM_MASTER
(
  xref_id             VARCHAR2(35) not null,
  trn_ref_no          VARCHAR2(16) not null,
  transaction_type    VARCHAR2(25),
  transaction_desc    VARCHAR2(25),
  txn_amount          NUMBER,
  txn_ccy             VARCHAR2(3),
  txn_date            DATE,
  branch_code         VARCHAR2(3),
  txn_maker_id        VARCHAR2(12),
  txn_checker_id      VARCHAR2(12),
  maker_id            VARCHAR2(12),
  maker_dt_stamp      DATE,
  checker_id          VARCHAR2(12),
  checker_dt_stamp    DATE,
  auth_stat           VARCHAR2(1),
  record_stat         VARCHAR2(1),
  once_auth           VARCHAR2(1),
  mod_no              NUMBER(4),
  total_denom_amt     NUMBER(22,3),
  tot_amt_in_usd      NUMBER(22,3),
  tot_amt_in_khr      NUMBER(22,3),
  from_till_id        VARCHAR2(25),
  to_till_id          VARCHAR2(25),
  tot_calc_amt_in_usd NUMBER(22,3),
  tot_calc_amt_in_khr NUMBER(22,3),
  advice_slip         CLOB
)
/
alter table IFTB_CASH_DENOM_MASTER add primary key (XREF_ID, TRN_REF_NO)
/
-- Create table
-- Create table
create table IFTB_CASH_DENOM_DETAIL
(
  xref_id        VARCHAR2(35) not null,
  trn_ref_no     VARCHAR2(16) not null,
  id             NUMBER not null,
  ccy_code       VARCHAR2(3),
  note_type      VARCHAR2(25),
  no_of_notes    NUMBER,
  sub_tot_result NUMBER
)
/
alter table IFTB_CASH_DENOM_DETAIL add primary key (XREF_ID, TRN_REF_NO, ID)
/