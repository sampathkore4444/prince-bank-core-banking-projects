CREATE OR REPLACE PACKAGE BODY SMPKS_CUSTOM IS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    L_MSG := 'smpks_custom ==>' || P_MSG;
    DEBUG.PR_DEBUG('SM', L_MSG);
  END DBG;

  FUNCTION FN_LIMITS_VALIDATE(P_FLAG    IN CHAR,
                              P_CCY     IN CYTM_CCY_DEFN.CCY_CODE%TYPE,
                              P_AMOUNT  IN SMTBS_ROLE_LIMIT.INPUT_LIMIT%TYPE,
                              P_USER_ID IN SMTBS_USER.USER_ID%TYPE,
                              
                              P_CURR_BRN_CODE   IN SMTB_ROLE_DETAIL.BRANCH_CODE%TYPE,
                              P_FN_CALL_ID      IN NUMBER,
                              P_TB_CLUSTER_DATA IN OUT GLOBAL.TY_TB_CLUSTER_DATA,
                              P_ERROR_CODE      OUT ERTBS_MSGS.ERR_CODE%TYPE,
                              P_ERROR_PARAM     OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function fn_limits_validate..');
  
    DBG('Returning successfully from the function fn_limits_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of the function fn_limits_validate..');
      RETURN FALSE;
  END FN_LIMITS_VALIDATE;

  FUNCTION FN_PRE_CHECK_AUTO_AUTH(PUSER_ID     IN SMTBS_USER.USER_ID%TYPE,
                                  PFUNCTION_ID IN SMTBS_MENU.FUNCTION_ID%TYPE,
                                  PBRANCH_CODE IN STTMS_CORE_BRANCH.BRANCH_CODE%TYPE)
  
   RETURN BOOLEAN IS
  BEGIN
    DBG('Inside the function fn_pre_check_auto_auth..');
  
    --sampath starts
    IF PFUNCTION_ID = 'IFDDENOM' THEN
    
      GLOBAL.pr_set_skip_kernel;
    
      RETURN TRUE;
    
    END IF;
    --sampath ends
  
    DBG('Returning successfully from the function fn_pre_check_auto_auth..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In when others of the function fn_pre_check_auto_auth..');
      RETURN FALSE;
  END FN_PRE_CHECK_AUTO_AUTH;

END SMPKS_CUSTOM;
