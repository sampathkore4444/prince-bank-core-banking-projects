insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-01', 'ENG', 'Denomination Currency should be same as Transaction Currency for the id:', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-02', 'ENG', 'Denomination Currency should be same as Transaction Currency for the id: $1', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-03', 'ENG', 'Denomination Currency should not be null for the id: $1 under denomination details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-04', 'ENG', 'Note Type should not be null for the id: $1 under denomination details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-05', 'ENG', 'No: of Notes should not be null for the id: $1 under denomination details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-06', 'ENG', 'Sub-Amount should not be null for the id: $1 under denomination details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-07', 'ENG', 'Denomination Details Can Not be Empty', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-08', 'ENG', 'Sum of Denomination Sub-Amounts should be equal to System Total ($1)', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-09', 'ENG', 'Sum of Denomination Sub-Amounts of KHR currency should be equal to System Total (KHR)', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-10', 'ENG', 'Sum of Denomination Sub-Amounts of USD currency should be equal to System Total (USD)', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-11', 'ENG', 'Failed in deleting the denomination details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-12', 'ENG', 'Denominations are duplicated for ID: $1', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

COMMIT;
