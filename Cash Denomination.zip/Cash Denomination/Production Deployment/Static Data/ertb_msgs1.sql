prompt Importing table ertb_msgs...
set feedback off
set define off
insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-13', 'ENG', 'The transaction is related to purely KHR currency and hence denom currency can not be USD in denom details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

insert into ertb_msgs (ERR_CODE, LANGUAGE, MESSAGE, TYPE, CONFIRMATION_REQD, FUNCTION_ID, MAX_SUB_PARAM, MODIFIABLE, BATCH_TYPE, DERIVED_MSG, OVD_CLASS, PARAM_TYPES, PARAMS_TO_MATCH, PARAMS_TO_COMPARE, DIRECTION_OF_COMPARISION)
values ('IF-DENOM-14', 'ENG', 'The transaction is related to purely USD currency and hence denom currency can not be KHR in denom details', 'E', 'N', 'IFDDENOM', 1, 'N', 'E', null, 'N', null, null, null, null);

prompt Done.
