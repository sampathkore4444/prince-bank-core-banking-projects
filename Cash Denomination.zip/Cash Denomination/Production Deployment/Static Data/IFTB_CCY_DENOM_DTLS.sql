insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 0.100);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 0.200);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 0.500);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 1.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 2.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 5.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 10.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 20.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('CNY', 50.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 50.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 100.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 200.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 500.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 1000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 2000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 5000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 10000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 20000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 30000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 50000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('KHR', 100000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 1.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 5.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 10.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 20.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 50.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 100.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 500.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('THB', 1000.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 1.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 2.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 5.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 10.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 20.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 50.000);

insert into IFTB_CCY_DENOM_DTLS (CCY_CODE, DENOM_VALUE)
values ('USD', 100.000);

COMMIT;