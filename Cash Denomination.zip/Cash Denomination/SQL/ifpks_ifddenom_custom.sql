CREATE OR REPLACE PACKAGE BODY ifpks_ifddenom_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifddenom_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2023 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
  SFR Number         :
  Changed By         :
  Change Description :
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_Msg := 'ifpks_ifddenom_Custom ==>' || p_Msg;
      Debug.Pr_Debug('IF', l_Msg);
    END IF;
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION fn_Post_build_type_structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_ifddenom         IN OUT ifpks_ifddenom_Main.ty_ifddenom,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_type_structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others Of ifpks_ifddenom_Custom.Fn_Post_Build_type_structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  /* FUNCTION FN_GET_TXN_TYPE(P_XREF_ID IN VARCHAR2) RETURN FBTB_TXNLOG_MASTER.FUNCTIONID%TYPE AS
  
  SELECT 
  
  BEGIN
    
  
    
  EXCEPTION
    WHEN OTHERS THEN
      
    DBG('FAILED IN FN_GET_TXN_TYPE');
    DBG('ERROR CODE IN FN_GET_TXN_TYPE='||SQLCODE);
    DBG('ERROR MESSAGE IN FN_GET_TXN_TYPE='||SQLERRM);
      
  END FN_GET_TXN_TYPE;*/
  
  

  FUNCTION FN_DELETE_DENOM_DTLS(p_ifddenom IN ifpks_ifddenom_Main.ty_ifddenom)
    RETURN BOOLEAN AS
  
    --PRAGMA AUTONOMOUS_TRANSACTION;
  
  BEGIN
  
    DBG(p_ifddenom.v_iftb_cash_denom_master.xref_id);
  
    BEGIN
      
      DELETE FROM IFTB_CASH_DENOM_MASTER A
       WHERE A.XREF_ID = p_ifddenom.v_iftb_cash_denom_master.xref_id;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED WHILE DELETING THE MASTER TABLE=' || SQLCODE);
        DBG('FAILED WHILE DELETING THE MASTER TABLE=' || SQLERRM);
      
        RETURN FALSE;
    END;
  
    BEGIN
      DELETE FROM IFTB_CASH_DENOM_DETAIL A
       WHERE A.XREF_ID = p_ifddenom.v_iftb_cash_denom_master.xref_id;
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED WHILE DELETING THE DETAIL TABLE');
        RETURN FALSE;
    END;
  
    BEGIN
      DELETE FROM STTB_RECORD_LOG A
       WHERE A.KEY_ID =
             '~IFTB_CASH_DENOM_MASTER~' ||
             p_ifddenom.v_iftb_cash_denom_master.xref_id || '~' ||
             p_ifddenom.v_iftb_cash_denom_master.trn_ref_no || '~';
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED WHILE DELETING THE RECORD LOG TABLE');
        RETURN FALSE;
    END;
  
    BEGIN
      DELETE FROM STTB_RECORD_LOG_VWCHG A
       WHERE A.KEY_ID =
             '~IFTB_CASH_DENOM_MASTER~' ||
             p_ifddenom.v_iftb_cash_denom_master.xref_id || '~' ||
             p_ifddenom.v_iftb_cash_denom_master.trn_ref_no || '~';
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('FAILED WHILE DELETING THE RECORD LOG VIEWCHANGE TABLE');
        RETURN FALSE;
    END;
  
    --COMMIT;
  
    RETURN TRUE;
  
  EXCEPTION
  
    WHEN OTHERS THEN
    
      DBG('FAILED IN FN_DELETE_DENOM_DTLS');
    
      RETURN FALSE;
    
  END FN_DELETE_DENOM_DTLS;

  FUNCTION FN_GET_TIMESTAMP(P_XREFID IN IFTB_CASH_DENOM_MASTER.XREF_ID%TYPE)
    RETURN VARCHAR2 AS
  
    L_FBTB_TXNLOG_MASTER FBTB_TXNLOG_MASTER%ROWTYPE;
  
    L_TIMESTAMP_VALUE VARCHAR2(100);
  
  BEGIN
  
    BEGIN
      SELECT *
        INTO L_FBTB_TXNLOG_MASTER
        FROM FBTB_TXNLOG_MASTER A
       WHERE A.XREFID = P_XREFID;
    
    EXCEPTION
      WHEN OTHERS THEN
        L_FBTB_TXNLOG_MASTER := NULL;
    END;
  
   /* L_TIMESTAMP_VALUE := substr(TO_TIMESTAMP(L_FBTB_TXNLOG_MASTER.CHECKERDATESTAMP,
                                             'YYYY-MM-DD HH24:MI:SS.FF'),
                                10);
  
    DBG('L_TIMESTAMP_VALUE1=' || L_TIMESTAMP_VALUE);*/
  
    IF INSTR(L_TIMESTAMP_VALUE, 'AM') > 0 THEN
    
      L_TIMESTAMP_VALUE := TO_CHAR(L_FBTB_TXNLOG_MASTER.CHECKERDATESTAMP, 'HH:MI:SS AM');/*TO_CHAR(TO_TIMESTAMP(L_TIMESTAMP_VALUE,
                                                'HH:MI:SS.FF9 AM'),
                                   'HH:MI:SS.FF2 AM');*/
    
    ELSE
    
      L_TIMESTAMP_VALUE := TO_CHAR(L_FBTB_TXNLOG_MASTER.CHECKERDATESTAMP, 'HH:MI:SS PM');/*TO_CHAR(TO_TIMESTAMP(L_TIMESTAMP_VALUE,
                                                'HH:MI:SS.FF9 PM'),
                                   'HH:MI:SS.FF2 PM');*/
    
    END IF;
  
    DBG('L_TIMESTAMP_VALUE2=' || L_TIMESTAMP_VALUE);
  
    RETURN L_TIMESTAMP_VALUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_TIMESTAMP');
      RETURN L_TIMESTAMP_VALUE;
  END FN_GET_TIMESTAMP;

  FUNCTION FN_BUILD_TXN_ADVICE_SLIP(p_Wrk_ifddenom IN ifpks_ifddenom_Main.ty_ifddenom)
    RETURN VARCHAR2 AS
  
    l_html        clob;
    l_denom_Count number := 0;
  BEGIN
  
    l_html := '<html>';
  
    --l_html := l_html || '<title>Transaction Slip</title>';
    
    l_html := l_html || '<style>td, th {  align:right;  font-family:Times New Roman;   font-size:12; letter-spacing: 2px}</style>';
  
    l_html := l_html || '<body>';
  
    --Header Table 1
    l_html := l_html || '<table align="center">';
    
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
    l_html := l_html || '<tr></tr>';
  
    --Row 1
    l_html := l_html || '<tr>';
  
    l_html := l_html || '<td>' || 'External Refernce No' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.xref_id || '</td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || 'Transaction Branch Code' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.branch_code ||
              '</td>';
  
    l_html := l_html || '</tr>';
  
    --Row 2
    l_html := l_html || '<tr>';
  
    l_html := l_html || '<td>' || 'Transaction Type' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.transaction_type ||
              '</td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || 'Transaction Date' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_date || '</td>';
  
    l_html := l_html || '</tr>';
  
    --Row 3
    l_html := l_html || '<tr>';
  
    l_html := l_html || '<td>' || 'Transaction Description' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.transaction_desc ||
              '</td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || 'Transaction Time' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              FN_GET_TIMESTAMP(p_Wrk_ifddenom.v_iftb_cash_denom_master.xref_id) ||
              '</td>';
  
    l_html := l_html || '</tr>';
  
    --Row 4
    l_html := l_html || '<tr>';
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
    
      l_html := l_html || '<td>' || 'System Total (USD)' || '</td>';
    
    ELSE
    
      l_html := l_html || '<td>' || 'Transaction Amount' || '</td>';
    
    END IF;
  
    l_html := l_html || '<td></td>';
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
    
      l_html := l_html || '<td>' || ':' ||
      
                cypks.CSFN_FORMAT_AMT('USD', p_Wrk_ifddenom.v_iftb_cash_denom_master.tot_amt_in_usd) ||
                '</td>';
    
    ELSE
    
      l_html := l_html || '<td>' || ':' ||
                 cypks.CSFN_FORMAT_AMT(p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_ccy, p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_amount) || --pls check currency
                '</td>';
    
    END IF;
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || 'TXN Maker ID' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_maker_id ||
              '</td>';
  
    l_html := l_html || '</tr>';
  
    --Row 5
    l_html := l_html || '<tr>';
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
    
      l_html := l_html || '<td>' || 'System Total (KHR)' || '</td>';
    
    ELSE
    
      l_html := l_html || '<td>' || 'Transaction Currency' || '</td>';
    
    END IF;
  
    l_html := l_html || '<td></td>';
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
    
      l_html := l_html || '<td>' || ':' ||
                cypks.CSFN_FORMAT_AMT('KHR', p_Wrk_ifddenom.v_iftb_cash_denom_master.tot_amt_in_khr) ||
                '</td>';
    
    ELSE
    
      l_html := l_html || '<td>' || ':' ||
                p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_ccy || '</td>';
    
    END IF;
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || 'TXN Checker ID' || '</td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' || ':' ||
              p_Wrk_ifddenom.v_iftb_cash_denom_master.txn_checker_id ||
              '</td>';
  
    l_html := l_html || '</tr>';
    
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
    
      --Row 6
      --nope
    
      --Row 7
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || 'To Till ID' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_Wrk_ifddenom.v_iftb_cash_denom_master.TO_TILL_ID ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
    END IF;
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'SCTT' THEN
    
      --Row 6
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || 'From Till ID' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_Wrk_ifddenom.v_iftb_cash_denom_master.FROM_TILL_ID ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
      --Row 7
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || null || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || 'To Till ID' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_Wrk_ifddenom.v_iftb_cash_denom_master.TO_TILL_ID ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
    END IF;
  
    l_html := l_html || '</table>';
  
    --Body Table 2
    l_html := l_html || '<table align="center">';
  
    l_html := l_html || '<tr>';
  
    l_html := l_html || '<th>No.</th>';
  
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
  
    l_html := l_html || '<th>Currency Type</th>';
  
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
  
    l_html := l_html || '<th>Note Type</th>';
  
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
  
    l_html := l_html || '<th># of Note</th>';
  
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
    l_html := l_html || '<th></th>';
  
    l_html := l_html || '<th>Sub-Amount</th>';
  
    l_html := l_html || '</tr>';
  
    l_denom_Count := p_Wrk_ifddenom.v_iftb_cash_denom_detail.COUNT;
  
    -- Generate the rows of the table using a loop
    FOR G IN p_Wrk_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_Wrk_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
    
      --IF G < p_Wrk_ifddenom.v_iftb_cash_denom_detail.LAST THEN
    
      l_html := l_html || '<tr>';
    
      -- Add the columns of the row
      l_html := l_html || '<td>' || p_Wrk_ifddenom.v_iftb_cash_denom_detail(G).ID ||
                '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' ||  cypks.csfn_format_amt(p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE,p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .NOTE_TYPE) || CASE p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE
               WHEN 'KHR' THEN '.00' ELSE NULL END  || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || p_Wrk_ifddenom.v_iftb_cash_denom_detail(G).NO_OF_NOTES|| '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || cypks.CSFN_FORMAT_AMT(p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE, p_Wrk_ifddenom.v_iftb_cash_denom_detail(G)
               .SUB_TOT_RESULT) || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '</tr>';
    
    --END IF;
    
    END LOOP;
  
    l_html := l_html || '<tr>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' ||
              CASE p_Wrk_ifddenom.v_iftb_cash_denom_master.TXN_CCY
                WHEN 'USD' THEN
                 'Total (USD)'
                ELSE
                 'Total (KHR)'
              END || '</td>';
  
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
    l_html := l_html || '<td></td>';
  
    l_html := l_html || '<td>' ||
              CASE p_Wrk_ifddenom.v_iftb_cash_denom_master.TXN_CCY
                WHEN 'USD' THEN
                 cypks.CSFN_FORMAT_AMT(p_Wrk_ifddenom.v_iftb_cash_denom_master.TXN_CCY, p_Wrk_ifddenom.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_USD)
                ELSE
                 cypks.CSFN_FORMAT_AMT(p_Wrk_ifddenom.v_iftb_cash_denom_master.TXN_CCY, p_Wrk_ifddenom.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_KHR)
              END || '</td>';
  
    l_html := l_html || '</tr>';
  
    IF p_Wrk_ifddenom.v_iftb_cash_denom_master.TRANSACTION_TYPE = 'TVCL' THEN
      --above covers KHR and this if covers USD
    
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || 'Total (USD)' || '</td>';
    
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' ||
                cypks.CSFN_FORMAT_AMT('USD', p_Wrk_ifddenom.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_USD) ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
    END IF;
  
    l_html := l_html || '</table>';
  
    l_html := l_html || '</body>';
  
    l_html := l_html || '</html>';
  
    dbg('Final HTML=' || l_html);
  
    RETURN l_html;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_BUILD_TXN_ADVICE_SLIP');
      DBG('ERROR CODE IN FN_BUILD_TXN_ADVICE_SLIP=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_BUILD_TXN_ADVICE_SLIP=' || SQLERRM);
      RETURN L_HTML;
  END FN_BUILD_TXN_ADVICE_SLIP;

  FUNCTION FN_GET_TILL_VAULT_ID(P_USER_ID     IN VARCHAR2,
                                P_BRANCH_CODE IN SMTB_USER_TILLS.BRANCH_CODE%TYPE)
    RETURN SMTB_USER_TILLS.TILL_ID%TYPE AS
  
    L_SMTB_USER_TILLS SMTB_USER_TILLS%ROWTYPE;
  
  BEGIN
  
    SELECT *
      INTO L_SMTB_USER_TILLS
      FROM SMTB_USER_TILLS A
     WHERE A.USER_ID = P_USER_ID
       AND A.BRANCH_CODE = P_BRANCH_CODE;
  
    RETURN L_SMTB_USER_TILLS.TILL_ID;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN L_SMTB_USER_TILLS.TILL_ID;
    
  END FN_GET_TILL_VAULT_ID;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_ifddenom         IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  
    L_DETB_RTL_TELLER     DETB_RTL_TELLER%ROWTYPE;
    L_FBTB_TXNLOG_MASTER  FBTB_TXNLOG_MASTER%ROWTYPE;
    L_FBTB_TXNLOG_DETAILS FBTB_TXNLOG_DETAILS%ROWTYPE;
  
    TYPE T_IFTB_CASH_DENOM_DETAIL IS TABLE OF IFTB_CASH_DENOM_DETAIL%ROWTYPE;
    V_IFTB_CASH_DENOM_DETAIL T_IFTB_CASH_DENOM_DETAIL;
  
    l_denom_Count number := 0;
  
    L_DENOM_SUB_AMTS     NUMBER := 0;
    L_DENOM_SUB_AMTS_KHR NUMBER := 0;
    L_DENOM_SUB_AMTS_USD NUMBER := 0;
  
    L_SMTB_USER_MAKER_TILL_ID   SMTB_USER_TILLS.TILL_ID%TYPE;
    L_SMTB_USER_CHECKER_TILL_ID SMTB_USER_TILLS.TILL_ID%TYPE;
  
    L_RESPXML     FBTB_TXNLOG_DETAILS.RESPXML%TYPE;
    L_SUB_RESPXML FBTB_TXNLOG_DETAILS.RESPXML%TYPE;
  
    l_pos1      number;
    l_pos2      number;
    l_khr_value varchar2(1000);
    l_usd_value varchar2(1000);
    
    l_check_dedupe_denom_exists boolean:=FALSE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory');
  
    IF P_ACTION_CODE = 'POPULATE' THEN
    
      BEGIN
        SELECT *
          INTO L_DETB_RTL_TELLER
          FROM DETB_RTL_TELLER A
         WHERE A.XREF = p_ifddenom.v_iftb_cash_denom_master.XREF_ID;
      
      EXCEPTION
        WHEN OTHERS THEN
          L_DETB_RTL_TELLER := NULL;
      END;
    
      DBG('L_DETB_RTL_TELLER.TRN_REF_NO=' || L_DETB_RTL_TELLER.TRN_REF_NO);
      DBG('L_DETB_RTL_TELLER.PRODUCT_CODE=' ||
          L_DETB_RTL_TELLER.PRODUCT_CODE);
      DBG('L_DETB_RTL_TELLER.TXN_AMOUNT=' || L_DETB_RTL_TELLER.TXN_AMOUNT);
      DBG('L_DETB_RTL_TELLER.TXN_CCY=' || L_DETB_RTL_TELLER.TXN_CCY);
      DBG('L_DETB_RTL_TELLER.TXN_BRANCH=' || L_DETB_RTL_TELLER.TXN_BRANCH);
      DBG('L_DETB_RTL_TELLER.TRN_DT=' || L_DETB_RTL_TELLER.TRN_DT);
      DBG('L_DETB_RTL_TELLER.MAKER_DT_STAMP=' ||
          L_DETB_RTL_TELLER.MAKER_DT_STAMP);
      DBG('L_DETB_RTL_TELLER.MAKER_ID=' || L_DETB_RTL_TELLER.MAKER_ID);
      DBG('L_DETB_RTL_TELLER.CHECKER_ID=' || L_DETB_RTL_TELLER.CHECKER_ID);
    
      P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRN_REF_NO := L_DETB_RTL_TELLER.TRN_REF_NO;
    
      L_SMTB_USER_MAKER_TILL_ID := FN_GET_TILL_VAULT_ID(L_DETB_RTL_TELLER.MAKER_ID,
                                                        L_DETB_RTL_TELLER.TXN_BRANCH);
    
      L_SMTB_USER_CHECKER_TILL_ID := FN_GET_TILL_VAULT_ID(L_DETB_RTL_TELLER.CHECKER_ID,
                                                          L_DETB_RTL_TELLER.TXN_BRANCH);
    
      P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRANSACTION_TYPE := CASE
                                                               L_DETB_RTL_TELLER.PRODUCT_CODE
                                                                WHEN 'CHFV' THEN
                                                                 '9007'
                                                                WHEN 'CHTV' THEN
                                                                 '9008'
                                                                WHEN 'CHTT' THEN
                                                                 'SCTT'
                                                                ELSE
                                                                 'TVCL'
                                                              END;
    
      P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRANSACTION_DESC := CASE
                                                               L_DETB_RTL_TELLER.PRODUCT_CODE
                                                                WHEN 'CHFV' THEN
                                                                 'Transfer Cash from Vault'
                                                                WHEN 'CHTV' THEN
                                                                 'Transfer Cash to Vault'
                                                                WHEN 'CHTT' THEN
                                                                 'Sell Cash to Teller'
                                                                ELSE
                                                                 'Till Balancing & Closure'
                                                              END;
    
      IF L_DETB_RTL_TELLER.PRODUCT_CODE IN ('CHFV', 'CHTV', 'CHTT') THEN
      
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_AMOUNT := L_DETB_RTL_TELLER.TXN_AMOUNT;
      
        IF L_DETB_RTL_TELLER.TXN_CCY = 'USD' THEN
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_USD := L_DETB_RTL_TELLER.TXN_AMOUNT;
        
        ELSIF L_DETB_RTL_TELLER.TXN_CCY = 'KHR' THEN
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_KHR := L_DETB_RTL_TELLER.TXN_AMOUNT;
        
        END IF;
      
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CCY        := L_DETB_RTL_TELLER.TXN_CCY;
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.BRANCH_CODE    := L_DETB_RTL_TELLER.TXN_BRANCH;
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_DATE       := L_DETB_RTL_TELLER.MAKER_DT_STAMP; --TRN_DT;
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_MAKER_ID   := L_DETB_RTL_TELLER.MAKER_ID;
        P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CHECKER_ID := L_DETB_RTL_TELLER.CHECKER_ID;
      
        BEGIN
          SELECT *
            INTO L_FBTB_TXNLOG_MASTER
            FROM FBTB_TXNLOG_MASTER A
           WHERE A.FUNCTIONID = CASE L_DETB_RTL_TELLER.PRODUCT_CODE
                   WHEN 'CHFV' THEN
                    '9007'
                   WHEN 'CHTV' THEN
                    '9008'
                   WHEN 'CHTT' THEN
                    'SCTT'
                   ELSE
                    'TVCL'
                 END
             AND XREFID = p_ifddenom.v_iftb_cash_denom_master.XREF_ID;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_FBTB_TXNLOG_MASTER := NULL;
        END;
      
        IF L_DETB_RTL_TELLER.PRODUCT_CODE IN ('CHTT') THEN
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.FROM_TILL_ID := L_SMTB_USER_MAKER_TILL_ID;
        
          L_SMTB_USER_CHECKER_TILL_ID := FN_GET_TILL_VAULT_ID(L_FBTB_TXNLOG_MASTER.ASSIGNEDTO,
                                                              L_DETB_RTL_TELLER.TXN_BRANCH);
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TO_TILL_ID := L_SMTB_USER_CHECKER_TILL_ID;
        
        END IF;
      
      ELSE
      
        BEGIN
        
          SELECT *
            INTO L_FBTB_TXNLOG_MASTER
            FROM FBTB_TXNLOG_MASTER A
           WHERE A.FUNCTIONID = 'TVCL'
             AND XREFID = p_ifddenom.v_iftb_cash_denom_master.XREF_ID;
        
        EXCEPTION
          WHEN OTHERS THEN
            L_FBTB_TXNLOG_MASTER := NULL;
        END;
      
        BEGIN
        
          SELECT *
            INTO L_FBTB_TXNLOG_DETAILS
            FROM FBTB_TXNLOG_DETAILS A
           WHERE A.FUNCTIONID = 'TVCL'
             AND XREFID = p_ifddenom.v_iftb_cash_denom_master.XREF_ID
             AND A.TXNSTATUS = 'COM';
        EXCEPTION
          WHEN OTHERS THEN
            L_FBTB_TXNLOG_DETAILS := NULL;
        END;
      
        IF L_FBTB_TXNLOG_MASTER.FUNCTIONID IS NOT NULL THEN
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRN_REF_NO := L_FBTB_TXNLOG_MASTER.XREFID;
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.BRANCH_CODE    := L_FBTB_TXNLOG_MASTER.BRANCHCODE;
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_DATE       := L_FBTB_TXNLOG_DETAILS.STAGEENDDATE; --TRN_DT;
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_MAKER_ID   := L_FBTB_TXNLOG_MASTER.MAKERID;
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CHECKER_ID := L_FBTB_TXNLOG_MASTER.CHECKERID;
        
          L_SMTB_USER_MAKER_TILL_ID := FN_GET_TILL_VAULT_ID(L_FBTB_TXNLOG_MASTER.MAKERID,
                                                            L_FBTB_TXNLOG_MASTER.BRANCHCODE);
        
          DBG('L_SMTB_USER_MAKER_TILL_ID=' || L_SMTB_USER_MAKER_TILL_ID);
        
          L_SMTB_USER_CHECKER_TILL_ID := FN_GET_TILL_VAULT_ID(L_FBTB_TXNLOG_MASTER.CHECKERID,
                                                              L_FBTB_TXNLOG_MASTER.BRANCHCODE);
        
          DBG('L_SMTB_USER_CHECKER_TILL_ID=' ||
              L_SMTB_USER_CHECKER_TILL_ID);
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.FROM_TILL_ID := L_SMTB_USER_MAKER_TILL_ID;
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TO_TILL_ID := L_SMTB_USER_CHECKER_TILL_ID;
        
          L_RESPXML := L_FBTB_TXNLOG_DETAILS.Respxml;
        
          dbg('L_RESPXML=' || L_RESPXML);
        
          select substr(L_RESPXML,
                        INSTR(L_RESPXML, '<REC TYPE="BLK_SUMMARY"><FV><![') + 36)
            into L_SUB_RESPXML
            from dual;
        
          dbg('L_SUB_RESPXML=' || L_SUB_RESPXML);
		
		IF instr(L_SUB_RESPXML, 'USD') > 0 AND
             instr(L_SUB_RESPXML, 'KHR') > 0 THEN
        
          l_pos1 := instr(L_SUB_RESPXML, '~', 1, 3);
        
          dbms_output.put_line('l_pos1=' || l_pos1);
        
          l_pos2 := instr(L_SUB_RESPXML, '~', 1, 4);
        
          dbms_output.put_line('l_pos2=' || l_pos2);
        
          select substr(L_SUB_RESPXML, l_pos1 + 1, l_pos2 - l_pos1 - 1)
            into l_khr_value
            from dual;
        
          dbms_output.put_line(l_khr_value);
        
          dbg('l_khr_value=' || l_khr_value);
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_KHR := l_khr_value;
        
          l_pos1 := instr(L_SUB_RESPXML, '~', 1, 7);
        
          dbms_output.put_line('l_pos1=' || l_pos1);
        
          l_pos2 := instr(L_SUB_RESPXML, '~', 1, 8);
        
          dbms_output.put_line('l_pos2=' || l_pos2);
        
          select substr(L_SUB_RESPXML, l_pos1 + 1, l_pos2 - l_pos1 - 1)
            into l_usd_value
            from dual;
        
          dbms_output.put_line(l_usd_value);
          dbg('l_usd_value=' || l_usd_value);
        
          P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_USD := l_usd_value;
		  
		  END IF;
		  
		  IF instr(L_SUB_RESPXML, 'USD') > 0 AND
             INSTR(L_SUB_RESPXML, 'KHR') = 0 THEN
          
            l_pos1 := instr(L_SUB_RESPXML, '~', 1, 3);
          
            dbms_output.put_line('l_pos1=' || l_pos1);
          
            l_pos2 := instr(L_SUB_RESPXML, '~', 1, 4);
          
            dbms_output.put_line('l_pos2=' || l_pos2);
          
            select substr(L_SUB_RESPXML, l_pos1 + 1, l_pos2 - l_pos1 - 1)
              into l_USD_value
              from dual;
          
            --END IF;
          
            --dbms_output.put_line('l_USD_value=' || l_USD_value);
          
            dbg('l_USD_value=' || l_USD_value);
          
            P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_USD := l_USD_value;
            
          END IF;
        
          IF instr(L_SUB_RESPXML, 'KHR') > 0 AND
             INSTR(L_SUB_RESPXML, 'USD') = 0 THEN
          
            l_pos1 := instr(L_SUB_RESPXML, '~', 1, 3);
          
            dbms_output.put_line('l_pos1=' || l_pos1);
          
            l_pos2 := instr(L_SUB_RESPXML, '~', 1, 4);
          
            dbms_output.put_line('l_pos2=' || l_pos2);
          
            select substr(L_SUB_RESPXML, l_pos1 + 1, l_pos2 - l_pos1 - 1)
              into l_KHR_value
              from dual;
          
            --END IF;
          
            --dbms_output.put_line('l_KHR_value=' || l_KHR_value);
          
            dbg('l_KHR_value=' || l_KHR_value);
          
            P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TOT_AMT_IN_KHR := l_KHR_value;
          
          END IF;
        
        END IF;
      
      END IF;
    
    END IF;
  
    IF P_ACTION_CODE = 'NEW' THEN
    
      IF P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRANSACTION_TYPE IN
         ('9007', '9008', 'SCTT') THEN
      
        l_denom_Count := p_ifddenom.v_iftb_cash_denom_detail.COUNT;
      
        IF L_DENOM_COUNT = 0 THEN
        
          p_Err_Code := 'IF-DENOM-07';
        
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
        
          RETURN FALSE;
        
        END IF;
      
        IF P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CCY = 'USD' THEN
        
          IF l_denom_Count > 0 THEN
          
            FOR G IN p_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            
              IF p_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE <> P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CCY THEN
              
                p_Err_Code := 'IF-DENOM-01';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
              
                --ovpks.Pr_Appendtbl(p_Err_Code, 'a');
              
                --RETURN FALSE;
              
              END IF;
            
            END LOOP;
            
            --Check for duplication of denoms
          FOR J in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            FOR K in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
               IF J <> K AND p_ifddenom.v_iftb_cash_denom_detail(J).note_type = p_ifddenom.v_iftb_cash_denom_detail(K).note_type
                 AND p_ifddenom.v_iftb_cash_denom_detail(J).CCY_CODE = p_ifddenom.v_iftb_cash_denom_detail(K).CCY_CODE THEN
                  
                  --l_check_dedupe_denom_exists := TRUE;
                  dbg('apple1 of denom dedupe');
                  p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(J).id || ',' || p_ifddenom.v_iftb_cash_denom_detail(K).id);
                             
               END IF;
            END LOOP;
          END LOOP;
          
          /*IF l_check_dedupe_denom_exists THEN
            
            p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
         
         END IF;*/
          
          END IF;        
        
        END IF;
      
        IF P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CCY = 'KHR' THEN
        
          IF l_denom_Count > 0 THEN
          
            FOR G IN p_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            
              IF p_ifddenom.v_iftb_cash_denom_detail(G)
               .CCY_CODE <> P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TXN_CCY THEN
              
                p_Err_Code := 'IF-DENOM-01';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
              
                --ovpks.Pr_Appendtbl(p_Err_Code, p_ifddenom.v_iftb_cash_denom_detail(G).id);
              
                --RETURN FALSE;
              
              END IF;
            
            END LOOP;
            
            --Check for duplication of denoms
          FOR J in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            FOR K in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
               IF J <> K AND p_ifddenom.v_iftb_cash_denom_detail(J).note_type = p_ifddenom.v_iftb_cash_denom_detail(K).note_type
                 AND p_ifddenom.v_iftb_cash_denom_detail(J).CCY_CODE = p_ifddenom.v_iftb_cash_denom_detail(K).CCY_CODE THEN
                  
                  --l_check_dedupe_denom_exists := TRUE;
                  dbg('apple2 of denom dedupe');
                  p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(J).id || ',' || p_ifddenom.v_iftb_cash_denom_detail(K).id);
                             
               END IF;
            END LOOP;
          END LOOP;
          
          /*IF l_check_dedupe_denom_exists THEN
            
            p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
         
         END IF;*/
          
          END IF;
        
        END IF;
      
        --Check if anything is null for all denominations
        FOR G IN 1 .. L_DENOM_COUNT LOOP
        
          IF P_IFDDENOM.v_iftb_cash_denom_detail(G).CCY_CODE IS NULL THEN
          
            P_Err_Code := 'IF-DENOM-03';
          
            Pr_Log_Error(p_Function_id,
                         p_Source,
                         p_Err_Code,
                         p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
          
            --RETURN FALSE;
          
          END IF;
        
          IF P_IFDDENOM.v_iftb_cash_denom_detail(G).NOTE_TYPE IS NULL THEN
          
            P_Err_Code := 'IF-DENOM-04';
          
            Pr_Log_Error(p_Function_id,
                         p_Source,
                         p_Err_Code,
                         p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
          
            --RETURN FALSE;
          
          END IF;
        
          IF P_IFDDENOM.v_iftb_cash_denom_detail(G).NO_OF_NOTES IS NULL THEN
          
            P_Err_Code := 'IF-DENOM-05';
          
            Pr_Log_Error(p_Function_id,
                         p_Source,
                         p_Err_Code,
                         p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
          
            --RETURN FALSE;
          
          END IF;
        
          IF P_IFDDENOM.v_iftb_cash_denom_detail(G).SUB_TOT_RESULT IS NULL THEN
          
            P_Err_Code := 'IF-DENOM-06';
          
            Pr_Log_Error(p_Function_id,
                         p_Source,
                         p_Err_Code,
                         p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
          
            --RETURN FALSE;
          
          END IF;
        
        END LOOP;
      
        --Again calculate if anything modified during save
        FOR G IN 1 .. l_denom_Count LOOP
        
          p_ifddenom.v_iftb_cash_denom_detail(G).SUB_TOT_RESULT := p_ifddenom.v_iftb_cash_denom_detail(G)
                                                                   .NOTE_TYPE * p_ifddenom.v_iftb_cash_denom_detail(G)
                                                                   .NO_OF_NOTES;
        
        END LOOP;
      
        FOR G IN 1 .. L_DENOM_COUNT LOOP
        
          L_DENOM_SUB_AMTS := L_DENOM_SUB_AMTS + p_ifddenom.v_iftb_cash_denom_detail(G)
                             .SUB_TOT_RESULT;
        
        END LOOP;
      
        IF L_DENOM_SUB_AMTS <>
           p_ifddenom.v_iftb_cash_denom_master.TXN_AMOUNT THEN
        
          P_Err_Code := 'IF-DENOM-08';
        
          Pr_Log_Error(p_Function_id,
                       p_Source,
                       p_Err_Code,
                       p_Err_Params ||
                       P_IFDDENOM.v_iftb_cash_denom_master.TXN_CCY);
        
          --RETURN FALSE;
        
        ELSE
        
          IF P_IFDDENOM.v_iftb_cash_denom_master.TXN_CCY = 'KHR' THEN
          
            P_IFDDENOM.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_KHR := L_DENOM_SUB_AMTS;
          
          ELSIF P_IFDDENOM.v_iftb_cash_denom_master.TXN_CCY = 'USD' THEN
          
            P_IFDDENOM.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_USD := L_DENOM_SUB_AMTS;
          
          END IF;
        
        END IF;
      
      END IF;
    
      IF P_IFDDENOM.V_IFTB_CASH_DENOM_MASTER.TRANSACTION_TYPE IN ('TVCL') THEN
      
        l_denom_Count := p_ifddenom.v_iftb_cash_denom_detail.COUNT;
      
        IF L_DENOM_COUNT = 0 THEN
        
          p_Err_Code := 'IF-DENOM-07';
        
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
        
          RETURN FALSE;
        
        END IF;
		
		IF L_DENOM_COUNT > 0 THEN
        
          IF p_ifddenom.v_iftb_cash_denom_master.tot_amt_in_usd is null then
          
            FOR J in p_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            
              IF p_ifddenom.v_iftb_cash_denom_detail(J).ccy_code = 'USD' THEN
              
                p_Err_Code := 'IF-DENOM-13';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params);
              
              END IF;
            
            END LOOP;
          
          END IF;
          
          IF p_ifddenom.v_iftb_cash_denom_master.tot_amt_in_khr is null then
          
            FOR J in p_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            
              IF p_ifddenom.v_iftb_cash_denom_detail(J).ccy_code = 'KHR' THEN
              
                p_Err_Code := 'IF-DENOM-14';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params);
              
              END IF;
            
            END LOOP;
          
          END IF;
        
        END IF;
      
        FOR G IN 1 .. L_DENOM_COUNT LOOP
        
          IF p_ifddenom.v_iftb_cash_denom_detail(G).CCY_CODE = 'KHR' THEN
          
            L_DENOM_SUB_AMTS_KHR := L_DENOM_SUB_AMTS_KHR + p_ifddenom.v_iftb_cash_denom_detail(G)
                                   .SUB_TOT_RESULT;
          
          END IF;
        
          IF p_ifddenom.v_iftb_cash_denom_detail(G).CCY_CODE = 'USD' THEN
          
            L_DENOM_SUB_AMTS_USD := L_DENOM_SUB_AMTS_USD + p_ifddenom.v_iftb_cash_denom_detail(G)
                                   .SUB_TOT_RESULT;
          
          END IF;
        
        END LOOP;
      
        IF L_DENOM_SUB_AMTS_KHR <>
           p_ifddenom.v_iftb_cash_denom_master.TOT_AMT_IN_KHR THEN
        
          P_Err_Code := 'IF-DENOM-09';
        
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
        
        END IF;
      
        IF L_DENOM_SUB_AMTS_USD <>
           p_ifddenom.v_iftb_cash_denom_master.TOT_AMT_IN_USD THEN
        
          P_Err_Code := 'IF-DENOM-10';
        
          Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
        
        ELSE
        
          P_IFDDENOM.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_KHR := L_DENOM_SUB_AMTS_KHR;
        
          P_IFDDENOM.v_iftb_cash_denom_master.TOT_CALC_AMT_IN_USD := L_DENOM_SUB_AMTS_USD;
        
        END IF;
        
        IF L_DENOM_COUNT > 0 THEN
        --Check for duplication of denoms
          FOR J in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
            FOR K in p_ifddenom.v_iftb_cash_denom_detail.FIRST..p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
               IF J <> K AND p_ifddenom.v_iftb_cash_denom_detail(J).note_type = p_ifddenom.v_iftb_cash_denom_detail(K).note_type
                 AND p_ifddenom.v_iftb_cash_denom_detail(J).CCY_CODE = p_ifddenom.v_iftb_cash_denom_detail(K).CCY_CODE THEN
                  
                  --l_check_dedupe_denom_exists := TRUE;
                  dbg('apple3 of denom dedupe');
                  p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(J).id || ',' || p_ifddenom.v_iftb_cash_denom_detail(K).id);
                             
               END IF;
            END LOOP;
          END LOOP;
          
          /*IF l_check_dedupe_denom_exists THEN
            
            p_Err_Code := 'IF-DENOM-12';
              
                Pr_Log_Error(p_Function_id,
                             p_Source,
                             p_Err_Code,
                             p_Err_Params || p_ifddenom.v_iftb_cash_denom_detail(G).id);
         
         END IF;*/
         
         END IF;
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifddenom         IN ifpks_ifddenom_Main.ty_ifddenom,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_ifddenom         IN ifpks_ifddenom_Main.ty_ifddenom,
                                       p_Prev_ifddenom    IN OUT ifpks_ifddenom_Main.ty_ifddenom,
                                       p_Wrk_ifddenom     IN OUT ifpks_ifddenom_Main.ty_ifddenom,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
  
    Dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_ifddenom         IN ifpks_ifddenom_Main.Ty_ifddenom,
                                        p_Prev_ifddenom    IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                                        p_Wrk_ifddenom     IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    l_html        VARCHAR2(32767);
    l_denom_Count NUMBER := 0;
  
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    IF P_ACTION_CODE = 'GENERATE_ADVICE' THEN
    
      l_html := '<html>';
    
      l_html := l_html || '<title>Transaction Slip</title>';
    
      l_html := l_html || '<body>';
    
      --Header Table 1
      l_html := l_html || '<table>';
    
      --Row 1
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || 'External Refernce No' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.xref_id || '</td>';
    
      l_html := l_html || '<td>' || 'Transaction Branch Code' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.branch_code || '</td>';
    
      l_html := l_html || '</tr>';
    
      --Row 2
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || 'Transaction Type' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.transaction_type ||
                '</td>';
    
      l_html := l_html || '<td>' || 'Transaction Date' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.txn_date || '</td>';
    
      l_html := l_html || '</tr>';
    
      --Row 3
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || 'Transaction Description' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.transaction_desc ||
                '</td>';
    
      l_html := l_html || '<td>' || 'Transaction Time' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                FN_GET_TIMESTAMP(p_Wrk_ifddenom.v_iftb_cash_denom_master.xref_id) ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
      --Row 4
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || 'Transaction Amount' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.txn_amount || '</td>';
    
      l_html := l_html || '<td>' || 'TXN Maker ID' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.txn_maker_id || '</td>';
    
      l_html := l_html || '</tr>';
    
      --Row 5
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<td>' || 'Transaction Currency' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.txn_ccy || '</td>';
    
      l_html := l_html || '<td>' || 'TXN Maker ID' || '</td>';
    
      l_html := l_html || '<td></td>';
    
      l_html := l_html || '<td>' || ':' ||
                p_ifddenom.v_iftb_cash_denom_master.txn_checker_id ||
                '</td>';
    
      l_html := l_html || '</tr>';
    
      l_html := l_html || '</table>';
    
      --Body Table 2
      l_html := l_html || '<table>';
    
      l_html := l_html || '<tr>';
    
      l_html := l_html || '<th>No.</th>';
    
      l_html := l_html || '<th>Currency Type</th>';
    
      l_html := l_html || '<th>Note Type</th>';
    
      l_html := l_html || '<th># of Note</th>';
    
      l_html := l_html || '<th>Sub-Amount</th>';
    
      l_html := l_html || '</tr>';
    
      l_denom_Count := p_Wrk_ifddenom.v_iftb_cash_denom_detail.COUNT;
    
      -- Generate the rows of the table using a loop
      FOR G IN p_ifddenom.v_iftb_cash_denom_detail.FIRST .. p_ifddenom.v_iftb_cash_denom_detail.LAST LOOP
      
        l_html := l_html || '<tr>';
      
        -- Add the columns of the row
        l_html := l_html || '<td>' || p_ifddenom.v_iftb_cash_denom_detail(G).ID ||
                  '</td>';
      
        l_html := l_html || '<td>' || p_ifddenom.v_iftb_cash_denom_detail(G)
                 .CCY_CODE || '</td>';
      
        l_html := l_html || '<td>' || p_ifddenom.v_iftb_cash_denom_detail(G)
                 .NOTE_TYPE || '</td>';
      
        l_html := l_html || '<td>' || p_ifddenom.v_iftb_cash_denom_detail(G)
                 .NO_OF_NOTES || '</td>';
      
        l_html := l_html || '<td>' || p_ifddenom.v_iftb_cash_denom_detail(G)
                 .SUB_TOT_RESULT || '</td>';
      
        l_html := l_html || '</tr>';
      
      END LOOP;
    
      l_html := l_html || '</table>';
    
      l_html := l_html || '</body>';
    
      l_html := l_html || '</html>';
    
      dbg('Final HTML=' || l_html);
    
    END IF;
  
    IF P_ACTION_CODE = 'DELDENOM' THEN
    
      DBG('INSIDE DELDENOM ACTION CODE');
    
      IF NOT FN_DELETE_DENOM_DTLS(p_ifddenom) THEN
      
        p_Err_Code := 'IF-DENOM-11';
      
        Pr_Log_Error(p_Function_id, p_Source, p_Err_Code, p_Err_Params);
      
        RETURN FALSE;
      
      ELSE
      
        RETURN TRUE;
      
      END IF;
    
    END IF;
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Post_Upl_Stat    IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_ifddenom         IN ifpks_ifddenom_Main.Ty_ifddenom,
                            p_Prev_ifddenom    IN ifpks_ifddenom_Main.Ty_ifddenom,
                            p_Wrk_ifddenom     IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
    L_ADVICE_CLOB IFTB_CASH_DENOM_MASTER.ADVICE_SLIP%TYPE;
  
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..=' || p_Action_Code);
  
    IF P_ACTION_CODE = 'NEW' THEN
    
      L_ADVICE_CLOB := FN_BUILD_TXN_ADVICE_SLIP(p_ifddenom);
    
      p_Wrk_ifddenom.v_iftb_cash_denom_master.ADVICE_SLIP := L_ADVICE_CLOB;
    
    END IF;
  
    /*IF P_ACTION_CODE = 'CLOSE' THEN
    
      BEGIN
        INSERT INTO IFTB_CASH_DENOM_MASTER_HIST
          SELECT *
            FROM IFTB_CASH_DENOM_MASTER A
           WHERE A.XREF_ID =
                 p_Wrk_ifddenom.v_iftb_cash_denom_master.XREF_ID;
      
      IF SQL%ROWCOUNT <> 0 THEN
        
      DELETE FROM IFTB_
        
      END IF;
      
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED WHILE INSERTINIG INTO HISTORY TABLE');
      END;
    
      BEGIN
        INSERT INTO IFTB_CASH_DENOM_DETAIL_HIST
          SELECT *
            FROM IFTB_CASH_DENOM_DETAIL A
           WHERE A.XREF_ID =
                 p_Wrk_ifddenom.v_iftb_cash_denom_master.XREF_ID;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED WHILE INSERTINIG INTO HISTORY TABLE');
      END;
    
    END IF;*/
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Post_Upl_Stat    IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_ifddenom         IN ifpks_ifddenom_Main.Ty_ifddenom,
                             p_prev_ifddenom    IN ifpks_ifddenom_Main.Ty_ifddenom,
                             p_wrk_ifddenom     IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
  
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_ifddenom         IN ifpks_ifddenom_Main.Ty_ifddenom,
                        p_Wrk_ifddenom     IN OUT ifpks_ifddenom_Main.Ty_ifddenom,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of ifpks_ifddenom_Custom.Fn_Pre_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_ifddenom         IN ifpks_ifddenom_Main.ty_ifddenom,
                         p_wrk_ifddenom     IN OUT ifpks_ifddenom_Main.ty_ifddenom,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Query..');
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of ifpks_ifddenom_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Query;

END ifpks_ifddenom_custom;
