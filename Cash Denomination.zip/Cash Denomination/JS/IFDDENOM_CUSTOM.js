function fnEnableKeyFields_CUSTOM() {
    debugs("IFDDENOM", "fnEnableKeyFields_CUSTOM");
	fnEnableElement(document.getElementById("BLK_MASTER__BTN_GEN_ADVICE"));
		return true;
}

function fnEnableDelDenomField_CUSTOM() {
    debugs("IFDDENOM", "fnEnableDelDenomField_CUSTOM");
	fnEnableElement(document.getElementById("BLK_MASTER__BTN_DEL_DENOM"));
		return true;
}


function fnPostLoad_CUSTOM(){
	debugs("In fnPostLoad_CUSTOM", "A");
	//fnDisableElement(document.getElementById("cmdAddRow_BLK_DETAIL"));
	//fnDisableElement(document.getElementById("cmdDelRow_BLK_DETAIL"));
	fnEnableKeyFields_CUSTOM();
	return true;	
}

function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	//fnDisableElement(document.getElementById("cmdAddRow_BLK_DETAIL"));
	//fnDisableElement(document.getElementById("cmdDelRow_BLK_DETAIL"));
	return true;	
}

function fnPostSave_CUSTOM() {
	debugs("In fnPostSave_CUSTOM", "A");	
	fnEnableKeyFields_CUSTOM();
	fnEnableDelDenomField_CUSTOM();
	return true;
}

function fnPostAuth_CUSTOM() {

	debugs("In fnPostAuth_CUSTOMM", "A");	
	fnEnableKeyFields_CUSTOM();
        fnEnableDelDenomField_CUSTOM();
	return true;
}



function fnPostExecuteQuery_CUSTOM() {

	debugs("In fnPostExecuteQuery_CUSTOM", "A");	
	fnEnableKeyFields_CUSTOM();
        fnEnableDelDenomField_CUSTOM()
	return true;
}

function fnCalcSubAmt1() {

    debugs("In fnCalcSubAmt1", "A");

    console.log("Inside fnCalcSubAmt");

    var rowNum = document.getElementById("BLK_DETAIL").tBodies[0].rows.length - 1;

    console.log("rowNum=" + rowNum);

    for (var i = 0; i <= rowNum; i++) {

      //  console.log("No of rows=" + i);


        var noteType = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0].value;

        console.log("noteType=" + noteType);

      //  if (!noteType) {

       //     console.log("Note Type is Null");

      //      alert("Please enter Note Type for the row number=" + i);

       //     return true;

       // }

        var numOfNotes = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[4].getElementsByTagName("INPUT")[0].value;

        console.log("numOfNotes=" + numOfNotes);

        if (noteType && numOfNotes) {

            var subAmount = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT");

            console.log("subAmount=" + subAmount);

            subAmount[0].value = noteType * numOfNotes;

            subAmount[1].value = noteType * numOfNotes;


        }

    }

    return true;

}

function fnCalcSubAmt(){

debugs("In fnCalcSubAmt", "A");

console.log("Inside fnCalcSubAmt");

var rowNum = document.getElementById("BLK_DETAIL").tBodies[0].rows.length - 1;

console.log("rowNum="+rowNum);

for(var i=0;i <= rowNum ; i++ ){

console.log("No of rows="+i);

//if(rowNum==0){

//var noteType = document.getElementById("BLK_DETAIL__NOTE_TYPE").value;

//var numOfNotes = document.getElementById("BLK_DETAIL__NO_OF_NOTESI").value;

var noteType = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[3].getElementsByTagName("INPUT")[0].value;

console.log("noteType="+noteType);

if(!noteType){

	    console.log("Note Type is Null");

	    alert("Please enter Note Type for the row number=" +i);
	    
 	    return true;	
		
	}

var numOfNotes = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[4].getElementsByTagName("INPUT")[0].value;

console.log("numOfNotes="+numOfNotes);

if(!numOfNotes){

	   console.log("Number of Notes is Null");

	    alert("Please enter No: of Notes for the row number=" +i);
		
	}


var subAmount = document.getElementById("BLK_DETAIL").tBodies[0].rows[i].cells[5].getElementsByTagName("INPUT"); 

console.log("subAmount="+subAmount);

subAmount[0].value = noteType * numOfNotes; //subAmount[1].value = noteType * numOfNotes;

subAmount[1].value = noteType * numOfNotes;

//document.getElementById("BLK_DETAIL").tBodies[0].rows[rowNum].cells[5].getElementsByTagName("INPUT")[0].value = noteType * numOfNotes;

//document.getElementById("BLK_DETAIL__SUB_TOT_RESULTI").value = noteType * numOfNotes;

//}else{

//var noteType = document.getElementById("BLK_DETAIL__NOTE_TYPE").value;

//var numOfNotes = document.getElementById("BLK_DETAIL__NO_OF_NOTESI").value;

//document.getElementById("BLK_DETAIL__SUB_TOT_RESULTI").value = noteType * numOfNotes;


//}

}

return true;

}

function fn_GetTxnDtls()
{	
	debugs("In fn_GetTxnDtls", "A");
	g_prevAction = gAction;
	gAction = "POPULATE";
	appendData();
	gAction = "POPULATE";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	}
	gAction=g_prevAction;
	g_PickupClicked = 1;
	

	return true;
}

function fnPostAddRow_BLK_DETAIL_CUSTOM()
{
   var rowcount = document.getElementById("BLK_DETAIL").tBodies[0].rows;
   var rows = rowcount.length;
   var l_currPage= parseInt(getInnerText(document.getElementById("CurrPage__BLK_DETAIL")));
   var l_pageSize= parseInt(document.getElementById("BLK_DETAIL").getAttribute("pgsize"));
   if(l_currPage>1){
       rows = l_pageSize*(l_currPage-1)+rows;
   }
   var rowNum = document.getElementById("BLK_DETAIL").tBodies[0].rows.length;

		if(l_currPage>1){
 var l_rownum = rows-rowNum;

for(var i=1;i <= rowNum ; i++ ){

  var inputArry = document.getElementById("BLK_DETAIL").tBodies[0].rows[i-1].cells[1].getElementsByTagName("INPUT"); 
  inputArry[0].value = inputArry[1].value = l_rownum + i;
}
}else
{
rowNum = document.getElementById("BLK_DETAIL").tBodies[0].rows.length - 1;
	var inputArry1 = document.getElementById("BLK_DETAIL").tBodies[0].rows[rowNum].cells[1].getElementsByTagName("INPUT"); 
	inputArry1[0].value = inputArry1[1].value = rows; 
}
   fireHTMLEvent(document.getElementById("BLK_DETAIL").tBodies[0].rows[rowNum].cells[0].getElementsByTagName("INPUT")[0], "onpropertychange");
     return true;
}

function fnPostDeleteRow_BLK_DETAIL_KERNEL()
{
	 
	var rowcount = document.getElementById("BLK_DETAIL").tBodies[0].rows;
	var rows = rowcount.length;
	var l_currPage= parseInt(getInnerText(document.getElementById("CurrPage__BLK_DETAIL")));
	var l_pageSize= parseInt(document.getElementById("BLK_DETAIL").getAttribute("pgsize"));
	if(l_currPage>1){
       rows = l_pageSize*(l_currPage-1)+rows;
	}

	var totalPages =  Math.ceil((rows/l_pageSize));
	var rowNum = document.getElementById("BLK_DETAIL").tBodies[0].rows.length;
	if(l_currPage>1){
 		var l_rownum = rows-rowNum;
		for(var i=1;i <= rowNum ; i++ ){


		var inputArry2 = document.getElementById("BLK_DETAIL").tBodies[0].rows[i-1].cells[1].getElementsByTagName("INPUT"); 
		inputArry2[0].value = inputArry2[1].value = l_rownum + i;

		}
	}
	else{
		for(var i=1;i <= rows ; i++ ){

		var inputArry3 = document.getElementById("BLK_DETAIL").tBodies[0].rows[i-1].cells[1].getElementsByTagName("INPUT"); 
		inputArry3[0].value = inputArry3[1].value = i; 

	}	}
	fireHTMLEvent(document.getElementById("BLK_DETAIL").tBodies[0].rows[rowNum].cells[0].getElementsByTagName("INPUT")[0], "onpropertychange");
    return true;

}

function fn_genTxnAdvice() {

    var advice;
    advice = fnGetDataXMLFromFCJXML(fcjResponseDOM, 1).getElementsByTagName("ADVICE_SLIP")[0].childNodes[0].substringData(0, fnGetDataXMLFromFCJXML(fcjResponseDOM, 1).getElementsByTagName("ADVICE_SLIP")[0].childNodes[0].length);
    var w = window.open("", "MyWindow", "width=850,height=1200,resizable=yes,scrollbars=yes,status=1,toolbar=yes");
    w.document.write(advice);
    w.document.close();
    w.print();
    w.close();

    return true;
}

function fn_DelDenomDtls(){

debugs("In fn_DelDenomDtls", "A");
	g_prevAction = gAction;
	gAction = "DELDENOM";
	appendData();
	gAction = "DELDENOM";

       
         
	fcjRequestDOM = buildUBSXml();
	

 	l_html_value = fnGetDataXMLFromFCJXML(fcjRequestDOM, 1).getElementsByTagName("ADVICE_SLIP")[0].childNodes[0].nodeValue;
        var fcjRequestDOMElement = fcjRequestDOM.getElementsByTagName("FV")[0];
	var fcjRequestDOMValue = fcjRequestDOMElement.innerHTML;
	fcjRequestDOMValue  = fcjRequestDOMValue.replace(l_html_value, "null");
	fcjRequestDOMElement.innerHTML = fcjRequestDOMValue;


    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	
	}
	gAction=g_prevAction;
		
	return true;


}