DECLARE
    req   UTL_HTTP.REQ;
    resp  UTL_HTTP.RESP;
    token VARCHAR2(10000) := 'LmRGcOGpZk3OhCSw-BkSxb3bslwByGG9G9W555-uJ4WmujHprA1n7-fcAbeyQEKZ4rXDpi9eTbDRQX7ffV7vmxXu2FbvK_9Ae4z3MgnULulMhzBlYMPjuMzdwr8xOT0rhM1fIM-s34xb3a4jpxxijLjzbWuo_uCMV4sKH9cj6PxK6ul4DX7HjIVHKlgwpksNje4EIO-jyfQmiZjF95DIxjI134ixJXtRdX9531c2i5lWNSyPESBMH9VPZ8FourVeviiMAv30dFkDgM3G3r7zygpJhOH-nuBW8xs91vnC9LyMBvy62BDnrdo0MunQXergvg2I17uwb12qsyobtEMkzneeyqDy-rnqLq09mxN8yrbRjXYiSW5KsG3a4zmFK8V1_BzieZtYddvcIHQja1dyVdVaC83mLLnfyxPXVx80UE3FM9_Cl3G1tNX_W1VRCX5tGaBUqx7E8mt0iIpxu3OGzWA_LqeemE4eXAzypkxTOqM';
    url   VARCHAR2(200) := 'http://10.80.80.139/ISEMTxnScreenAPI/api/TxnScreen/TxnRealTimeScreen';
    content_length NUMBER;
    payload VARCHAR2(3000) := '{
      "OfficerId": "SAMPATH1",
      "Location": "993",
      "Source": "SWIFT",
      "ServiceType": "3",
      "RedFlagType": "Y",
      "FileId": "pacs.008",
      "MsgId": "993OBPM233330002",
      "CreDtTm": "2024-04-07T12:04:21",
      "NbOfTxs": "1",
      "TtlAmt": "100",
      "TtlAmtCcy": "USD",
      "SttlmInf_Date": "29-NOV-23",
      "PayInfo_Direction": "CRDT",
      "PayInfo_Ccy": "USD",
      "PayInfo_Amt": "100",
      "PayInfo_Date": "29-NOV-23",
      "SenderAccountNo": "000180548",
      "SenderName": "PBRFT-KHR-S06",
      "SenderIDNo": "",
      "Sender_BICFI": "PINCKHPPXXXX",
      "SenderStreetName": "",
      "SenderPostCode": "",
      "SenderTownName": "",
      "SenderCountry": "KH",
      "BeneAccountNo": "000121563",
      "BeneName": "",
      "BeneIDNo": "",
      "Bene_BICFI": "AAADFRP1XXX",
      "BeneStreetName": "",
      "BenePostCode": "",
      "BeneTownName": "",
      "BeneCountry": "",
      "Purpose_CodeOrProp": "",
      "InstructingAgent_BICFI": "",
      "InstructingAgentName": "",
      "InstructingAgentCountry": "",
      "InstructedAgent_BICFI": "",
      "InstructedAgentName": "",
      "InstructedAgentCountry":"",
      "IntermediaryAgent_BICFI": "",
      "IntermediaryAgentName": "",
      "IntermediaryAgentCountry": "",
      "IntermediaryAgent_BICFI_02": "",
      "IntermediaryAgentName_02": "",
      "IntermediaryAgentCountry_02": "",
      "IntermediaryAgent_BICFI_03":  "",
      "IntermediaryAgentName_03": "",
      "IntermediaryAgentCountry_03": "",
      "CounterParty1":"",
      "CounterParty2":"",
      "CounterParty3":"",
      "CounterParty4":"",
      "PaymentChannel":"OTC"
      }'; -- Your request payload here
    
BEGIN
    content_length := LENGTH(payload);
    
    req := UTL_HTTP.BEGIN_REQUEST(url, 'POST', UTL_HTTP.HTTP_VERSION_1_1);
    
    UTL_HTTP.SET_HEADER(req, 'Content-Type', 'application/json');
    UTL_HTTP.SET_HEADER(req, 'Content-Length', content_length);
    UTL_HTTP.SET_HEADER(req, 'Authorization', 'Bearer ' || token);
    
    UTL_HTTP.WRITE_TEXT(req, payload);
    
    resp := UTL_HTTP.GET_RESPONSE(req);
    
    dbms_output.put_line(resp.status_code);
    
    -- Handle response here
    
    UTL_HTTP.END_RESPONSE(resp);
EXCEPTION
    WHEN UTL_HTTP.REQUEST_FAILED THEN
        -- Error handling
        DBMS_OUTPUT.PUT_LINE('HTTP request failed: ' || SQLERRM);
    WHEN others THEN
        -- Other exceptions handling
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END;
/
