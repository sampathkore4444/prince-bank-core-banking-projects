insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('IBFT_BIC_BNK_COD', 'Inter Bank Transfer BIC Code and Bank Code Mapping', 'SAMPATH1', 'SAMPATH2', to_date('23-12-2019', 'dd-mm-yyyy'), to_date('23-12-2019', 'dd-mm-yyyy'), 'O', 'A', '1', 'Y');

COMMIT;
