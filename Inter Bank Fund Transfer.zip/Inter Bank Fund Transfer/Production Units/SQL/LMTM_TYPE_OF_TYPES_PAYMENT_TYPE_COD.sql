insert into LMTM_TYPE_OF_TYPES (TYPE, DESCRIPTION, MAKER_ID, CHECKER_ID, MAKER_DT_STAMP, CHECKER_DT_STAMP, RECORD_STAT, AUTH_STAT, MOD_NO, ONCE_AUTH)
values ('PAYMENT_TYPE_COD', 'Payment Type Code for Inter Bank Transfer for SDR File Generation', 'SAMPATH1', 'SAMPATH1', to_date('16-10-2019 10:30:18', 'dd-mm-yyyy hh24:mi:ss'), to_date('16-10-2019 10:30:18', 'dd-mm-yyyy hh24:mi:ss'), 'O', 'A', '1', 'Y');

COMMIT;
