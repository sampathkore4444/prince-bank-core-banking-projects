prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PAYMENT_TYPE_COD', 'KHR_OUTWARD_CHEQUE', '101000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PAYMENT_TYPE_COD', 'KHR_OUTWARD_REMITTANCE', '601000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PAYMENT_TYPE_COD', 'USD_OUTWARD_CHEQUE', '102000');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('PAYMENT_TYPE_COD', 'USD_OUTWARD_REMITTANCE', '602000');

prompt Done.
