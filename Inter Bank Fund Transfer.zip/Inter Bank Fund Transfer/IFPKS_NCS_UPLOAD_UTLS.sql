CREATE OR REPLACE PACKAGE BODY IFPKS_NCS_UPLOAD_UTLS AS

  PROCEDURE DBG(P_MSG VARCHAR2) IS
    L_MSG VARCHAR2(32767);
  BEGIN
    IF DEBUG.PKG_DEBUG_ON <> 2 THEN
      L_MSG := 'IFPKS_NCS_UPLOAD_UTLS ==>' || P_MSG;
      DEBUG.PR_DEBUG('IF', L_MSG);
    END IF;
  END DBG;

  FUNCTION FN_GET_PAYMENT_TYPE_CODE(P_VALUE IN LMTM_TYPE_VALUES.VALUE%TYPE,
                                    P_TYPE  IN LMTM_TYPE_VALUES.TYPE%TYPE)
    RETURN LMTM_TYPE_VALUES.CODE%TYPE IS
    L_CODE LMTM_TYPE_VALUES.CODE%TYPE;
  BEGIN
    SELECT CODE
      INTO L_CODE
      FROM LMTM_TYPE_VALUES
     WHERE VALUE = P_VALUE
       AND TYPE = P_TYPE;
  
    RETURN L_CODE;
  
  EXCEPTION
    WHEN OTHERS THEN
      L_CODE := NULL;
      RETURN L_CODE;
  END FN_GET_PAYMENT_TYPE_CODE;

  FUNCTION FN_GET_PAYER_NAME(P_ACC_NO IN STTM_CUST_ACCOUNT.AC_DESC%TYPE)
    RETURN STTM_CUST_ACCOUNT.AC_DESC%TYPE IS
    L_AC_DESC STTM_CUST_ACCOUNT.AC_DESC%TYPE;
  BEGIN
  
    SELECT AC_DESC
      INTO L_AC_DESC
      FROM STTM_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ACC_NO
       AND RECORD_STAT = 'O'
       AND AUTH_STAT = 'A';
  
    RETURN L_AC_DESC;
  
  EXCEPTION
    WHEN OTHERS THEN
      L_AC_DESC := NULL;
    
      RETURN L_AC_DESC;
    
  END FN_GET_PAYER_NAME;

  FUNCTION FN_GET_NCS_TEMPLATE RETURN CLOB IS
  
    L_CLOB CLOB;
  
  BEGIN
    DBG('START OF FN_GET_NCS_TEMPLATE');
  
    L_CLOB := '<Payment>
    <PaymentTypeCode>$L_PAYTYPE_CODE</PaymentTypeCode>
    <SerialNo>$L_SERIAL_NO</SerialNo>
    <PaymentDate>@L_PAYMNT_DATE</PaymentDate>
    <PayerBank>041903</PayerBank>
    <PayerCheckDigit>6</PayerCheckDigit>
    <PayerAccountNo>$L_DR_ACC_NO</PayerAccountNo>
    <CurrencyCode>$L_CCY</CurrencyCode>
    <Amount>$L_TXN_AMOUNT</Amount>
    <SecurityCode/>
    <PayerName>$PAYER_NAME</PayerName>
    <PayerRef>PRINCE BANK PLC</PayerRef>
    <PayeeBank>$L_BEN_BIC</PayeeBank>
    <PayeeCheckDigit>6</PayeeCheckDigit>
    <PayeeAccountNo>$L_CR_ACC_NO</PayeeAccountNo>
    <PayeeName>$L_CR_CUST_NAME</PayeeName>
    <PayeeRef/>
    <ReturnCode/>
    <InputDate/>
    <ProcessingDate>$L_PROC_DATE</ProcessingDate>
    <InputBatchNo/>
    <OutputBatchNo/>
  </Payment>';
  
    RETURN L_CLOB;
  
    DBG('END OF FN_GET_NCS_TEMPLATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_GET_NCS_TEMPLATE');
      DBG('ERROR CODE IN FN_GET_NCS_TEMPLATE=' || SQLCODE);
      DBG('ERROR MESSAGE IN FN_GET_NCS_TEMPLATE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN FN_GET_NCS_TEMPLATE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    
  END FN_GET_NCS_TEMPLATE;

  PROCEDURE PR_WRITE_CLOB_TO_FILE(P_IN_DIR_NAME  IN VARCHAR2,
                                  P_IN_FILE_NAME IN VARCHAR2,
                                  P_IN_CLOB      IN CLOB) IS
    L_FILE   UTL_FILE.FILE_TYPE;
    L_AMT    NUMBER := 32000;
    L_OFFSET NUMBER := 1;
    L_LENGTH NUMBER := NVL(DBMS_LOB.GETLENGTH(P_IN_CLOB), 0);
    L_BUFF   VARCHAR2(32760);
  BEGIN
    --OPEN FILE
    L_FILE := UTL_FILE.FOPEN(P_IN_DIR_NAME, P_IN_FILE_NAME, 'w', 32760);
  
    --READ CLOB AND UPLOAD INTO FILE
    WHILE (L_OFFSET < L_LENGTH) LOOP
      DBMS_LOB.READ(P_IN_CLOB, L_AMT, L_OFFSET, L_BUFF);
    
      UTL_FILE.PUT(L_FILE, L_BUFF);
      UTL_FILE.FFLUSH(L_FILE);
      UTL_FILE.NEW_LINE(L_FILE);
    
      L_OFFSET := L_OFFSET + L_AMT;
    END LOOP;
  
    --CLOSE FILE
    UTL_FILE.FCLOSE(L_FILE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_WRITE_CLOB_TO_FILE');
      DBG('ERROR CODE IN PR_WRITE_CLOB_TO_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_WRITE_CLOB_TO_FILE=' || SQLERRM);
      DBG('ERROR LINE NUMBER IN PR_WRITE_CLOB_TO_FILE=' ||
          DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
  END PR_WRITE_CLOB_TO_FILE;

  PROCEDURE PR_GEN_NCS_UPLOAD_FILE IS
    L_RESP_CLOB     CLOB;
    L_RESP_TEMPLATE CLOB;
    L_FILE_NAME     VARCHAR2(32767);
    L_RESP_CODE     VARCHAR2(10);
  BEGIN
  
    DBG('START OF PR_GEN_NCS_UPLOAD_FILE');
  
    FOR G IN (SELECT *
                FROM IFTB_INTERBANK_TRANSFER_TXNS
               WHERE PROCESSING_DATE = GLOBAL.APPLICATION_DATE) LOOP
    
      L_RESP_TEMPLATE := FN_GET_NCS_TEMPLATE;
      
      --File Name
      L_FILE_NAME := 'IBFT_'|| GLOBAL.APPLICATION_DATE;
    
      --Payment Type Code
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PAYTYPE_CODE',
                                 FN_GET_PAYMENT_TYPE_CODE('USD_OUTWARD_REMITTANCE',
                                                          'PAYMENT_TYPE_COD'));
    
      --Serial No
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_SERIAL_NO',
                                 'ODT' || TO_CHAR(G.TRN_DATE, 'YYMMDD') ||
                                 '0001');
    
      --Payment Date
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PAYMNT_DATE',
                                 TO_CHAR(G.TRN_DATE, 'DDMMYYYY'));
    
      --Payer Account No
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_DR_ACC_NO',
                                 G.DEBIT_ACCOUNT);
    
      --Currency Code
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_CCY',
                                 G.DEBIT_ACCOUNT_CCY);
    
      --Amount
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_TXN_AMOUNT',
                                 G.TXN_AMOUNT);
    
      --Payer Name
      L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$PAYER_NAME',
                                 FN_GET_PAYER_NAME(G.DEBIT_ACCOUNT));
    
      --Payee Bank
      /*  L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
      '$L_BEN_BIC',
      FN_GET_PAYER_NAME(G.AC_NO));*/
    
      --Processing Date 
      /*IF TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') >= '08:00' AND
        
         TO_CHAR(G.CHECKER_DT_STAMP, 'HH24' || ':' || 'MI') <= '12:00' THEN
      
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PROC_DATE',
                                   TO_CHAR(G.VALUE_DATE, 'DDMMYYYY'));
      
      ELSE
      
        L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                   '$L_PROC_DATE',
                                   TO_CHAR(G.VALUE_DATE + 1, 'DDMMYYYY'));
      
      END IF;*/
      
       L_RESP_TEMPLATE := REPLACE(L_RESP_TEMPLATE,
                                 '$L_PROC_DATE',
                                 G.PROCESSING_DATE);
    
      L_RESP_CLOB := L_RESP_CLOB || L_RESP_TEMPLATE;
    
      L_RESP_TEMPLATE := NULL;
    
    END LOOP;
  
    DBG('DONE WITH GENERATING CLOB RESPONSE');
  
    --Appending Header, Body and Tailer
    L_RESP_CLOB := '<?xml version="1.0" encoding="UTF-8"?>
<SDRFile>' || L_RESP_CLOB || '</SDRFile>';
  
    --Write to output file
    DBG('START OF WRITING CLOB TO AN XML FILE');
    PR_WRITE_CLOB_TO_FILE('/u01/fcubs/interfaces/Auto_Debit_Payment/Incoming/comp',
                          REPLACE(L_FILE_NAME, 'REQ', 'RES') || '.XML',
                          L_RESP_CLOB);
  
    DBG('END OF WRITING CLOB TO AN XML FILE');
  
    DBG('END OF PR_GEN_NCS_UPLOAD_FILE');
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_GEN_NCS_UPLOAD_FILE');
      DBG('ERROR CODE IN PR_GEN_NCS_UPLOAD_FILE=' || SQLCODE);
      DBG('ERROR MESSAGE IN PR_GEN_NCS_UPLOAD_FILE=' || SQLERRM);
  END PR_GEN_NCS_UPLOAD_FILE;

END IFPKS_NCS_UPLOAD_UTLS;
/