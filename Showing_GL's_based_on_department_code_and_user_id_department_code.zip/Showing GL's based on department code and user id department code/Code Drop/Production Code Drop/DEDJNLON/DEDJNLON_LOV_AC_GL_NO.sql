Function ID : DEDJNLON

LOV ID : LOV_AC_GL_NO

SELECT AC_GL_NO, AC_DESC, AC_OR_GL, CCY, CUST_NO
  FROM (SELECT AC_GL_NO,
               AC_GL_DESC  AC_DESC,
               AC_OR_GL    AC_OR_GL,
               AC_GL_CCY   CCY,
               BRANCH_CODE,
               RELCUST     CUST_NO
          FROM STVW_DEACCOUNT
         WHERE USER_ID = GLOBAL.USER_ID
           AND NVL(BRANCH_CODE, ?) = ?
           AND AC_OR_GL <> 'G')
UNION
SELECT A.AC_GL_NO, A.AC_GL_DESC, A.AC_OR_GL, A.AC_GL_CCY, A.CUST_NO
  FROM STTB_ACCOUNT A
 WHERE A.AC_GL_NO IN
       (SELECT A.CODE
          FROM LMTM_TYPE_VALUES A, SMTB_USER B
         WHERE B.USER_ID = GLOBAL.USER_ID
           AND A.TYPE = 'DEPT_ID_' || B.DEPT_CODE)
   AND A.ac_gl_rec_status IN ('O', 'A')
   AND nvl(A.gl_stat_de_post, 'Y') = 'Y'
UNION
SELECT A.AC_GL_NO, A.AC_GL_DESC, A.AC_OR_GL, A.AC_GL_CCY, A.CUST_NO
  FROM STTB_ACCOUNT A
 WHERE A.AC_GL_NO IN
       (SELECT A.CODE
          FROM LMTM_TYPE_VALUES A, SMTB_USER B
         WHERE B.USER_ID = GLOBAL.USER_ID
           AND A.TYPE = 'FN_DEPT_SPL_' || B.DEPT_CODE)
       AND nvl(A.gl_stat_de_post, 'Y') = 'Y'
UNION
SELECT A.AC_GL_NO, A.AC_GL_DESC, A.AC_OR_GL, A.AC_GL_CCY, A.CUST_NO
  FROM STTB_ACCOUNT A
 WHERE A.AC_GL_NO IN
       (SELECT A.CODE
          FROM LMTM_TYPE_VALUES A, SMTB_USER B
         WHERE B.USER_ID = GLOBAL.USER_ID
           AND A.TYPE = 'FN_DEPTSPL1_' || B.DEPT_CODE)
