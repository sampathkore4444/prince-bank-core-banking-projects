FUNCTION ID : CLDPYMNT

LOV ID : LOV_UI_SETT_ACC

SELECT ACCOUNT_NO,
       BRANCH_CODE,
       AC_DESC,
       DECODE(AC_OR_GL,
              'A',
              'Account',
              'G',
              'General Ledger',
              'L',
              'Loan',
              'M',
              'Multi Currency',
              'V',
              'Virtual Account',
              'Account') AC_OR_GL
  FROM STVWS_CL_ACCOUNT
 WHERE RECORD_STAT = 'O'
   AND ((BRANCH_CODE IS NOT NULL AND BRANCH_CODE = ? AND
       Nvl(CURRENCY, 'M') = Decode(AC_OR_GL, 'M', 'M', ?) AND
       AC_OR_GL IN ('A', 'K', 'V', 'M')) OR
       (AC_OR_GL IN ('K', 'V') AND BRANCH_CODE IS NULL))
   OR ACCOUNT_NO IN (SELECT A.CODE
                      FROM LMTM_TYPE_VALUES A
                     WHERE A.TYPE = 'FN_ID_CLDPYMNT')
