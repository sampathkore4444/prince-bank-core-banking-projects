prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '222600003', '222600003');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '222600010', '222600010');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '296920014', '296920014');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '296920020', '296920020');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '389210041', '389210041');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '389210046', '389210046');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '389220006', '389220006');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '392200001', '392200001');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '573170014', '573170014');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '574930007', '574930007');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '574930009', '574930009');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0970', '670000002', '670000002');

prompt Done.
