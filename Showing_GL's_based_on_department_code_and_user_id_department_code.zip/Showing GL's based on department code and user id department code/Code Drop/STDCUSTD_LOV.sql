--LOV_PAYINOFFSETACC
select a.ac_gl_no, nvl(a.branch_code, global.current_branch) branch_code, decode(a.ac_or_gl, 'A', a.ac_gl_Ccy, '') ccy, a.ac_gl_desc ADESC, a.ac_or_gl PAYIN from sttb_account a where a.ac_or_GL = DECODE(?, 'S', 'A', 'G', 'G') and ((a.ac_or_GL = 'G'  AND EXISTS (SELECT A.CODE
          FROM LMTM_TYPE_VALUES A, SMTB_USER B
         WHERE B.USER_ID = GLOBAL.USER_ID
               AND A.TYPE = B.DEPT_CODE) and exists (select 1 from sttms_payin_mode c where c.branch_code = global.current_branch and c.payin_option = 'G' and c.gl_code = a.ac_gl_no) or (a.ac_or_GL = 'A' and exists (select '1' from sttm_cust_account where cust_ac_no = a.ac_gl_no and branch_Code = a.branch_code and account_type <> 'Y' AND CUST_NO IN (SELECT X.CUSTOMER_NO FROM STTMS_CUSTOMER X WHERE (X.ACCESS_GROUP IS NOT NULL AND EXISTS (SELECT 1 FROM STVW_USER_ACCESS B WHERE B.USER_ID = GLOBAL.USER_ID AND B.ACCESS_GROUP = X.ACCESS_GROUP)) OR X.ACCESS_GROUP IS NULL))))) and a.once_auth = 'Y' and a.ac_gl_rec_Status = 'O'

--LOV_PAYOUTOFFSETACC
select a.ac_gl_no, a.ac_gl_desc ADESC, decode(a.ac_or_gl, 'A', a.ac_gl_Ccy, '') ccy, a.branch_code, a.ac_or_gl PAYIN from sttb_account a where a.ac_or_GL = DECODE(?, 'S', 'A', 'G', 'G') and (((a.ac_or_GL = 'G' AND EXISTS (SELECT A.CODE
          FROM LMTM_TYPE_VALUES A, SMTB_USER B
         WHERE B.USER_ID = GLOBAL.USER_ID
           AND A.TYPE = B.DEPT_CODE)) or (a.ac_or_GL = 'A' and exists (select 1 from sttm_cust_account where cust_ac_no = a.ac_gl_no and branch_Code = a.branch_code and account_type <> 'Y' AND CUST_NO IN (SELECT X.CUSTOMER_NO FROM STTMS_CUSTOMER X WHERE (X.ACCESS_GROUP IS NOT NULL AND EXISTS (SELECT 1 FROM STVW_USER_ACCESS B WHERE B.USER_ID = GLOBAL.USER_ID AND B.ACCESS_GROUP = X.ACCESS_GROUP)) OR X.ACCESS_GROUP IS NULL))))) and a.once_auth = 'Y' and a.ac_gl_rec_Status = 'O'
