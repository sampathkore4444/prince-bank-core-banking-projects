prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0150', '296910002', '296910002');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0150', '389220002', '389220002');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0150', '389220005', '389220005');

prompt Done.
