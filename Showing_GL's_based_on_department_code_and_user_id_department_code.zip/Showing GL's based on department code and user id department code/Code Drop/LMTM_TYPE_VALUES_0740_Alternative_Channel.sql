prompt Importing table LMTM_TYPE_VALUES...
set feedback off
set define off
insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '296920023', '296920023');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '296920024', '296920024');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '389210033', '389210033');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '571150016', '571150016');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '573170003', '573170003');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '573177018', '573177018');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '670000003', '670000003');

insert into LMTM_TYPE_VALUES (TYPE, VALUE, CODE)
values ('0740', '670000004', '670000004');

prompt Done.
