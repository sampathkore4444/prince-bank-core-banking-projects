/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2019, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDOFAST_SYS.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**  Last Modified By   : 
**  Last modified on   : 
**  Full Version       : 
**  Reason             : 
****************************************************************************************************************************/

//***** Code for criteria Search *****
var criteriaSearch  = 'N';
//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR THE SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var fieldNameArray = {"BLK_FAST_MASTER":"SOURCE_CODE~BRANCH_CODE~MSG_FLOW~TRANSFER_MODE~TRN_REF_NO~PRODUCT_CODE~TRANSFER_DATE~TXN_CCY~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~TXN_STATUS~TXN_REMARKS~MSG_ID~PAY_ID~REM_ACC~REM_NAME~REM_ADD1~REM_ADD2~REM_ADD3~REM_ADD4~BEN_ACC~BEN_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~BEN_REMARKS~BEN_PHONE~BEN_EMAIL~INSTR_ID~ETEND_ID~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH","BLK_FAST_CHARGE":"TRN_REF_NO~CHG_SRNO~CHG_DESC~WAIVER~CHG_AMT~CHG_CCY~LCY_CHG~FCY_CHG~CHG_GL~NETTING_REQ~XRATE~TXN_CODE~CHG_TYPE"};

var multipleEntryPageSize = {};

var multipleEntrySVBlocks = "";

var tabMEBlks = {};

var msgxml=""; 
msgxml += '    <FLD>'; 
msgxml += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_FAST_MASTER">SOURCE_CODE~BRANCH_CODE~MSG_FLOW~TRANSFER_MODE~TRN_REF_NO~PRODUCT_CODE~TRANSFER_DATE~TXN_CCY~TXN_AMT~TOT_CHG_AMT~NET_TXN_AMT~EXCH_RATE~TXN_STATUS~TXN_REMARKS~MSG_ID~PAY_ID~REM_ACC~REM_NAME~REM_ADD1~REM_ADD2~REM_ADD3~REM_ADD4~BEN_ACC~BEN_BIC~BEN_NAME~BEN_ADD1~BEN_ADD2~BEN_ADD3~BEN_ADD4~BEN_REMARKS~BEN_PHONE~BEN_EMAIL~INSTR_ID~ETEND_ID~MAKER~MAKERSTAMP~CHECKER~CHECKERSTAMP~MODNO~TXNSTAT~AUTHSTAT~ONCEAUTH</FN>'; 
msgxml += '      <FN PARENT="BLK_FAST_MASTER" RELATION_TYPE="N" TYPE="BLK_FAST_CHARGE">TRN_REF_NO~CHG_SRNO~CHG_DESC~WAIVER~CHG_AMT~CHG_CCY~LCY_CHG~FCY_CHG~CHG_GL~NETTING_REQ~XRATE~TXN_CODE~CHG_TYPE</FN>'; 
msgxml += '    </FLD>'; 

var strScreenName = "CVS_MAIN";
var qryReqd = "Y";
var txnBranchFld = "" ;
var originSystem = "";
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** FCJ XML FOR SUMMARY SCREEN *****
//----------------------------------------------------------------------------------------------------------------------
var msgxml_sum=""; 
msgxml_sum += '    <FLD>'; 
msgxml_sum += '      <FN PARENT="" RELATION_TYPE="1" TYPE="BLK_FAST_MASTER">AUTHSTAT~TXNSTAT~TRN_REF_NO~SOURCE_CODE~TRANSFER_MODE~MSG_FLOW~PRODUCT_CODE~REM_ACC~REM_NAME~BEN_ACC~BEN_NAME~TXN_CCY~TXN_AMT~TXN_STATUS~BRANCH_CODE~TRANSFER_DATE~PAY_ID~MSG_ID~BEN_PHONE</FN>'; 
msgxml_sum += '    </FLD>'; 

var detailFuncId = "IFDOFAST";
var defaultWhereClause = "";
var defaultOrderByClause ="";
var multiBrnWhereClause ="";
var g_SummaryType ="S";
var g_SummaryBtnCount =0;
var g_SummaryBlock ="BLK_FAST_MASTER";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR DATABINDING *****
//----------------------------------------------------------------------------------------------------------------------
 var relationArray = {"BLK_FAST_MASTER" : "","BLK_FAST_CHARGE" : "BLK_FAST_MASTER~N"}; 

 var dataSrcLocationArray = new Array("BLK_FAST_MASTER","BLK_FAST_CHARGE"); 
 // Array of all Data Sources used in the screen 
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR QUERY MODE *****
//----------------------------------------------------------------------------------------------------------------------
var detailRequired = true ;
var intCurrentQueryResultIndex = 0;
var intCurrentQueryRecordCount = 0;

var queryFields = new Array();    //Values should be set inside IFDOFAST.js, in "BlockName__FieldName" format
var pkFields    = new Array();    //Values should be set inside IFDOFAST.js, in "BlockName__FieldName" format
queryFields[0] = "BLK_FAST_MASTER__TRN_REF_NO";
pkFields[0] = "BLK_FAST_MASTER__TRN_REF_NO";
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR AMENDABLE/SUBSYSTEM Fields *****
//----------------------------------------------------------------------------------------------------------------------
//***** Fields Amendable while Modification *****
var modifyAmendArr = {"BLK_FAST_MASTER":["BEN_ACC","BEN_ADD1","BEN_ADD2","BEN_ADD3","BEN_ADD4","BEN_BIC","BEN_NAME","BEN_PHONE","BEN_REMARKS","REM_ACC","REM_ADD1","REM_ADD2","REM_ADD3","REM_ADD4","REM_NAME"]};
var closeAmendArr = new Array(); 
var reopenAmendArr = new Array(); 
var reverseAmendArr = new Array(); 
var deleteAmendArr = new Array(); 
var rolloverAmendArr = new Array(); 
var confirmAmendArr = new Array(); 
var liquidateAmendArr = new Array(); 
var queryAmendArr = new Array(); 
var authorizeAmendArr = new Array(); 
//----------------------------------------------------------------------------------------------------------------------

var subsysArr    = new Array(); 

//----------------------------------------------------------------------------------------------------------------------

//***** CODE FOR LOVs *****
//----------------------------------------------------------------------------------------------------------------------
var lovInfoFlds = {"BLK_FAST_MASTER__PRODUCT_CODE__LOV_PRODCODE":["BLK_FAST_MASTER__PRODUCT_CODE~~","BLK_FAST_MASTER__MSG_FLOW!~BLK_FAST_MASTER__TRANSFER_MODE!","N~N",""],"BLK_FAST_MASTER__TXN_CCY__LOV_TXNCCY":["BLK_FAST_MASTER__TXN_CCY~~","BLK_FAST_MASTER__TRANSFER_MODE!","N~N",""],"BLK_FAST_MASTER__REM_ACC__LOV_ACCNO":["~BLK_FAST_MASTER__REM_ACC~BLK_FAST_MASTER__REM_NAME~~~","BLK_FAST_MASTER__MSG_FLOW!","N~N~N~N~N",""],"BLK_FAST_MASTER__BEN_BIC__LOV_BENBIC":["BLK_FAST_MASTER__BEN_BIC~~","BLK_FAST_MASTER__TRANSFER_MODE!","N~N",""]};
var offlineLovInfoFlds = {};
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR TABS *****
//----------------------------------------------------------------------------------------------------------------------
var strHeaderTabId = 'TAB_HEADER';
var strFooterTabId = 'TAB_FOOTER';
var strCurrentTabId = 'TAB_MAIN';
//--------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------
var multipleEntryIDs = new Array();
var multipleEntryArray = new Array();
var multipleEntryCells = new Array();
//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR MULTIPLE ENTRY VIEW SINGLE ENTRY BLOCKS *****
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
//***** SCRIPT FOR ATTACHED CALLFORMS *****
 //----------------------------------------------------------------------------------------------------------------------

 var CallFormArray= new Array("CSCONCHG~BLK_FAST_MASTER"); 

 var CallFormRelat=new Array("IFTBS_FAST_MASTER.TRN_REF_NO=DETBS_RTL_TELLER.TRN_REF_NO"); 

 var CallRelatType= new Array("N"); 


 var ArrFuncOrigin=new Array();
 var ArrPrntFunc=new Array();
 var ArrPrntOrigin=new Array();
 var ArrRoutingType=new Array();


 // Code for Loading Cluster/Custom js File Starts
 var ArrClusterModified=new Array();
 var ArrCustomModified=new Array();
 // Code for Loading Cluster/Custom js File ends

ArrFuncOrigin["IFDOFAST"]="CUSTOM";
ArrPrntFunc["IFDOFAST"]="";
ArrPrntOrigin["IFDOFAST"]="";
ArrRoutingType["IFDOFAST"]="X";


 // Code for Loading Cluster/Custom js File Starts
ArrClusterModified["IFDOFAST"]="N";
ArrCustomModified["IFDOFAST"]="Y";

 // Code for Loading Cluster/Custom js File ends


 /* Code For OBIEE functionalities */ 
var obScrArgName  = new Array(); 
var obScrArgSource  = new Array(); 
//***** CODE FOR SCREEN ARGS *****
//----------------------------------------------------------------------------------------------------------------------
var scrArgName = {"CSCONCHG":"","CSDMSGVW":""};
var scrArgSource = {"CSCONCHG":"","CSDMSGVW":""};
var scrArgVals = {"CSCONCHG":"","CSDMSGVW":""};
var scrArgDest = {};
//***** CODE FOR SUB-SYSTEM DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
var dpndntOnFlds = {"CSCONCHG":""};
var dpndntOnSrvs = {"CSCONCHG":""};
//***** CODE FOR TAB DEPENDENT  FIELDS   *****
//----------------------------------------------------------------------------------------------------------------------
//***** CODE FOR CALLFORM TABS *****
//----------------------------------------------------------------------------------------------------------------------
var callformTabArray = new Array(); 
//***** CODE FOR ACTION STAGE DETAILS *****
//----------------------------------------------------------------------------------------------------------------------
var actStageArry = {};
//***** CODE FOR IMAGE FLDSET *****
//----------------------------------------------------------------------------------------------------------------------