del script.txt
echo spool %cd%\spool.txt >script.txt
for %%i in (*.ddl,*.cnv,,*.vw,*.inc,*.prc,*.fnc,*.spc,*.sql,*.pck,*.trg) do echo Prompt Compiling unit %%i >>Script.txt & echo @"%cd%\%%i" >> script.txt
echo spool off  >>script.txt
