/***************************************************************************************************************************
**  This source is part of the FLEXCUBE Software Product. 
**  Copyright (c) 2008 ,2019, Oracle and/or its affiliates.
**  All rights reserved.
**  
**  No part of this work may be reproduced, stored in a retrieval system, 
**  adopted or transmitted in any form or by any means, electronic, mechanical, photographic, 
**  graphic, optic recording or otherwise, translated in any language or computer language, 
**  without the prior written permission of Oracle and/or its affiliates.
**  
**  Oracle Financial Services Software Limited.
**  Oracle Park, Off Western Express Highway,
**  Goregaon (East),
**  Mumbai - 400 063,
**  India.
**  
**  Written by         : 
**  Date of creation   : 
**  File Name          : IFDOFAST_CUSTOM.js
**  Purpose            : 
**  Called From        : 
**  
**  CHANGE LOG
**    Modified By      : KORE SAMPATH KUMAR
**    Modified Reason  : Prince FAST Interface Changes 
**    Modified On      : 21-Jun-2019
**    Search String    : PRINCE 12.4 FAST CUSTOMIZATION CHANGES
****************************************************************************************************************************/
function fnPostNew_CUSTOM(){
	debugs("In fnPostNew_CUSTOM", "A");
	document.getElementById("BLK_FAST_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_FAST_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	document.getElementById("BLK_FAST_MASTER__SOURCE_CODE").value = 'FLEXCUBE';
	//document.getElementById("BLK_FAST_MASTER__MSG_FLOW").value = "I";   // temp
	fnTransferMode();
	return true;	
}
function fnPostCopy_CUSTOM() {
	debugs("In fnPostCopy_CUSTOM", "A");
	document.getElementById("BLK_FAST_MASTER__BRANCH_CODE").value = mainWin.CurrentBranch;
	document.getElementById("BLK_FAST_MASTER__TRANSFER_DATE").value = mainWin.AppDate;
	document.getElementById("BLK_FAST_MASTER__SOURCE_CODE").value = 'FLEXCUBE';
	document.getElementById("BLK_FAST_MASTER__MSG_ID").value = "";
	document.getElementById("BLK_FAST_MASTER__PAY_ID").value = "";
	document.getElementById("BLK_FAST_MASTER__TXN_STATUS").value = "";
	document.getElementById("BLK_FAST_MASTER__TXN_REMARKS").value = "";
	fnTransferMode();
	//document.getElementById("BLK_FAST_MASTER__MSG_FLOW").value = "I";  // temp
	return true;
}
function fnPostUnlock_CUSTOM(){
	debugs("In fnPostUnlock_CUSTOM", "A");
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE2"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE3"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__PRODUCT_CODE"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TXN_CCY"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TXN_AMT"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__REM_ACC"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__BTN_PICKUP"));
	return true;
}
function fnPostLoad_CUSTOM(){
	debugs("In fnPostLoad_CUSTOM");
	//document.getElementById("BLK_FAST_MASTER__MSG_FLOW").value = "I"; // temp
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostLoad_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
	}
	
	if (document.getElementById("BLK_FAST_MASTER__MSG_FLOW").value == 'I'){
		document.getElementById("New").disabled = true;
		document.getElementById("New").style.display = "none";
		
		document.getElementById("Copy").disabled = true;
		document.getElementById("Copy").style.display = "none";
		
		document.getElementById("Close").disabled = true;
		document.getElementById("Close").style.display = "none";
		
		/*document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
		
		document.getElementById("Authorize").disabled = true;
		document.getElementById("Authorize").style.display = "none";*/
	} // temp
	return true;
}
function fnPostExecuteQuery_CUSTOM(){
	debugs("In fnPostExecuteQuery_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostExecuteQuery_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
	}
	return true;
}

function fnPostSave_CVS_AUTHORIZE_CUSTOM(){
	debugs("In fnPostSave_CVS_AUTHORIZE_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostSave_CVS_AUTHORIZE_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
	}
	return true;
}
function fnPostAuthorize_CUSTOM(){
	debugs("In fnPostAuthorize_CUSTOM");
	var authStatNode = document.getElementsByName("AUTHSTAT");
    var l_AuthVal = getAuthTxnNodeValue(authStatNode);
	debugs("In fnPostAuthorize_CUSTOM"+l_AuthVal);
	if (l_AuthVal == "A"){
		document.getElementById("Unlock").disabled = true;
		document.getElementById("Unlock").style.display = "none";
	}
	return true;
}

function fnTransferMode() {
	debugs("In fnTransferMode", "A");
	if (document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE").checked) {
		document.getElementById("BLK_FAST_MASTER__TXN_CCY").value = "KHR";
	}
	if (document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE2").checked) {
		document.getElementById("BLK_FAST_MASTER__TXN_CCY").value = "USD";
	}
	return true;
}

function fnPickup() {
	debugs("In fnPickup", "A");
	g_prevAction = gAction;
	gAction = "PICKUP";
	appendData();
	gAction = "PICKUP";
	fcjRequestDOM = buildUBSXml();
    fcjResponseDOM = fnPost(fcjRequestDOM, servletURL, functionId);
    if (!fnProcessResponse()) {
		gAction = g_prevAction;
        return false;
    }
    var msgStatus = getNodeText(selectSingleNode(fcjResponseDOM, "FCUBS_RES_ENV/FCUBS_HEADER/MSGSTAT"));
	if (msgStatus == "FAILURE") {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_ERROR_RESP");
	} else {
	var messageNode = selectSingleNode(fcjResponseDOM,"FCUBS_RES_ENV/FCUBS_BODY/FCUBS_WARNING_RESP");
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE2"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TRANSFER_MODE3"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__PRODUCT_CODE"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TXN_CCY"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__TXN_AMT"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__REM_ACC"));
	fnDisableElement(document.getElementById("BLK_FAST_MASTER__BTN_PICKUP"));
	}
	gAction=g_prevAction;
	return true;
}

function fnPreSave_CUSTOM(){
	debugs("In fnPreSave_CUSTOM", "A");
	if (document.getElementById("BLK_FAST_MASTER__TRN_REF_NO").value == "") {			
		debugs("In Please click on Pick up before save", "A");
		alert("Please click on Pick up before save");
		return false;
	}
	return true;	
}
