CREATE OR REPLACE PACKAGE BODY DEPKS_FAST_PAYMENT_CUSTOM IS

  PROCEDURE DBG(X VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('DE', 'DEPKS_FAST_PAYMENT_CUSTOM >>>: ' || X);
  END DBG;
  PROCEDURE PR_INIT_MSG IS
    FILE        VARCHAR2(32767);
    p_FILE_NAME VARCHAR2(1000);
    FPATH       VARCHAR2(100);
  BEGIN
    global.pr_init('001', 'SYSTEM');
    debug.pr_close;
     DBG('entered  ');
    l_fast_params := FN_GET_PARAMS;
    DBG('Income path :' || g_fast_params.IN_PATH);
    SELECT DIRECTORY_PATH
      INTO FPATH
      FROM DBA_DIRECTORIES
     WHERE DIRECTORY_NAME = g_fast_params.IN_PATH;
  
    DBG('FPATH  - ' || FPATH);
    FILE := DIRLIST_FILE(FPATH, ',');
    DBG('FILE  - ' || FILE);
    LOOP
      EXIT WHEN FILE IS NULL;
      p_FILE_NAME := SUBSTR(FILE, INSTR(FILE, ',', -1) + 1);
      DBG('FILE NAME IS: ' || p_FILE_NAME);
      PR_PROCESS_FILE(p_FILE_NAME);
      FILE := SUBSTR(FILE, 1, INSTR(FILE, ',', -1) - 1);
    END LOOP;
    DBG('Success  ');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_INIT_MSG ' || SQLERRM);
  END PR_INIT_MSG;

  PROCEDURE PR_PROCESS_FILE(p_FILE_NAME VARCHAR2) IS
    L_XML XMLTYPE;
  BEGIN
  
    UTL_FILE.FRENAME('FAST_IN_READY',
                     p_FILE_NAME,
                     'FAST_IN_WIP',
                     p_FILE_NAME,
                     TRUE);
    DBG('moved to wip');
    DBG('File name: ' || p_FILE_NAME);
    SELECT XMLTYPE(BFILENAME('FAST_IN_WIP', p_FILE_NAME),
                   NLS_CHARSET_ID('AL32UTF16'))
      INTO L_XML
      FROM DUAL;
    DBG('STATUS FILE : ' || NVL(INSTR(L_XML.getclobval(),
                                      'urn:iso:std:iso:20022:tech:xsd:pain.002.001.06'),
                                0));
    DBG('TRN FILE : ' || NVL(INSTR(L_XML.getclobval(),
                                   'urn:iso:std:iso:20022:tech:xsd:pain.001.001.05'),
                             0));
    IF NVL(INSTR(L_XML.getclobval(),
                 'urn:iso:std:iso:20022:tech:xsd:pain.001.001.05'),
           0) > 0 THEN
      IF NOT FN_PROCESS_TRN(p_FILE_NAME, L_XML) THEN
        UTL_FILE.FRENAME('FAST_IN_WIP',
                         p_FILE_NAME,
                         'FAST_IN_ERR',
                         p_FILE_NAME,
                         TRUE);
        DBG('moved to error as it failed ');
      ELSE
        UTL_FILE.FRENAME('FAST_IN_WIP',
                         p_FILE_NAME,
                         'FAST_IN_COMP',
                         p_FILE_NAME,
                         TRUE);
        DBG('moved to completed as it success ');
      END IF;
    ELSIF NVL(INSTR(L_XML.getclobval(),
                    'urn:iso:std:iso:20022:tech:xsd:pain.002.001.06'),
              0) > 0 THEN
      IF NOT FN_PROCESS_STATUS(p_FILE_NAME, L_XML) THEN
        UTL_FILE.FRENAME('FAST_IN_WIP',
                         p_FILE_NAME,
                         'FAST_IN_ERR',
                         p_FILE_NAME,
                         TRUE);
        DBG('moved to error as it failed ');
      ELSE
        UTL_FILE.FRENAME('FAST_IN_WIP',
                         p_FILE_NAME,
                         'FAST_IN_COMP',
                         p_FILE_NAME,
                         TRUE);
        DBG('moved to completed as it success ');
      END IF;
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN WOT OF PR_PROCESS_FILE' || SQLERRM);
  END PR_PROCESS_FILE;

  FUNCTION FN_PROCESS_TRN(p_FILE_NAME IN VARCHAR2, P_XML XMLTYPE)
    RETURN BOOLEAN AS
    L_XML            XMLTYPE;
    l_ty_rtupld      depks_retailtellerupload.typ_retailtellerupld_rec;
    l_source         VARCHAR2(15) := 'BANKON';
    l_err_tbl        ovpkss.tbl_error;
    l_rec_txn_ctrl   gwpks_brntxn_control.typ_txn_ctrl;
    l_status_on_save CHAR;
    l_ret            NUMBER;
    l_serial         varchar2(16);
    l_Err_Code       VARCHAR2(1000);
    l_err_param      varchar2(100);
    l_msg            CLOB;
    L_SEQ            VARCHAR2(12);
    l_bic_count      NUMBER := 0;
  BEGIN
    DBG('Inside FN_PROCESS_TRN ' || p_FILE_NAME);
    l_err_tbl.delete;
    ovpks.Pr_Initerrtbl;
  
    L_XML := P_XML;
    DBG('TEST HEREEERE ' || p_FILE_NAME);
  
    l_msg := replace(L_XML.getclobval(),
                     '<Document xsi:schemaLocation="xsd/pain.001.001.05.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">',
                     '<Document>');
  
    l_msg := replace(l_msg,
                     '<Document xsi:schemaLocation="jaxb/iso20022/pain.001.001.05.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">',
                     '<Document>');
  
    DBG('l_msg ' || l_msg);
    L_XML := XMLTYPE.createXML(l_msg);
  
    FOR R IN (SELECT
              --header
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/MsgId/text()') AS MSGID,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/CreDtTm/text()') AS CREDTTM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/NbOfTxs/text()') AS NBOFTXS,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/CtrlSum/text()') AS CTRLSUM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/Nm/text()') AS NM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/PstlAdr/StrtNm/text()') AS INIT_STRTNM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/PstlAdr/BldgNb/text()') AS INIT_BLDGNB,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/PstlAdr/PstCd/text()') AS INIT_PSTCD,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/PstlAdr/TwnNm/text()') AS INIT_TWNNM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/GrpHdr/InitgPty/PstlAdr/Ctry/text()') AS INIT_CTRY,
               
               --
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/PmtInfId/text()') AS PMTINFID,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/PmtMtd/text()') AS PMTMTD,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/BtchBookg/text()') AS BTCHBOOKG,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/ReqdExctnDt/text()') AS REQDEXCTNDT,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/Dbtr/Nm/text()') AS DRNM,
               
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Id/Othr/Id/text()') AS DRACC,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/DbtrAcct/Ccy/text()') AS DRCCY,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/DbtrAgt/FinInstnId/BICFI/text()') AS DRBICFI,
               
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/InstrId/text()') AS INSTRID,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/PmtId/EndToEndId/text()') AS ENDTOENDID,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Amt/InstdAmt/text()') AS INSTDAMT,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Amt/InstdAmt/@Ccy') AS CRCCY, -- Need to get ccy value
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/ChrgBr/text()') AS CHRGBR,
               
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAgt/FinInstnId/BICFI/text()') AS CRBICFI,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/Nm/text()') AS CRNM,
               
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/PstlAdr/StrtNm/text()') AS CR_STRTNM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/PstlAdr/BldgNb/text()') AS CR_BLDGNB,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/PstlAdr/PstCd/text()') AS CR_PSTCD,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/PstlAdr/TwnNm/text()') AS CR_TWNNM,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Cdtr/PstlAdr/Ctry/text()') AS CR_CTRY,
               
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/CdtrAcct/Id/Othr/Id/text()') AS CRACC,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/Purp/Cd/text()') AS CD,
               EXTRACTVALUE(VALUE(P),
                            '/CstmrCdtTrfInitn/PmtInf/CdtTrfTxInf/RmtInf/Ustrd/text()') AS USTRD
              
                FROM TABLE(XMLSEQUENCE(EXTRACT(L_XML,
                                               '/Document/CstmrCdtTrfInitn'))) P) LOOP
    
      DBG('MsgId ' || R.MsgId);
      DBG('CreDtTm ' || R.CreDtTm);
      DBG('NbOfTxs ' || R.NbOfTxs);
      DBG('CtrlSum ' || R.CtrlSum);
      DBG('Nm ' || R.Nm);
      DBG('INIT_STRTNM ' || R.INIT_STRTNM);
    
      DBG('PMTINFID ' || R.PMTINFID);
      DBG('PMTMTD ' || R.PMTMTD);
      DBG('BTCHBOOKG ' || R.BTCHBOOKG);
      DBG('REQDEXCTNDT ' || R.REQDEXCTNDT);
      DBG('DRNM ' || R.DRNM);
    
      DBG('DRACC ' || R.DRACC);
      DBG('DRCCY ' || R.DRCCY);
      DBG('DRBICFI ' || R.DRBICFI);
      DBG('INSTRID ' || R.INSTRID);
      DBG('ENDTOENDID ' || R.ENDTOENDID);
    
      DBG('INSTDAMT ' || R.INSTDAMT);
      DBG('CRCCY ' || R.CRCCY);
      DBG('CHRGBR ' || R.CHRGBR);
    
      DBG('CRBICFI ' || R.CRBICFI);
      DBG('CRNM ' || R.CRNM);
      DBG('CR_STRTNM ' || R.CR_STRTNM);
      DBG('CRACC ' || R.CRACC);
      DBG('CD ' || R.CD);
      DBG('USTRD ' || R.USTRD);
      L_SEQ := LPAD(TXNSEQFJB.NEXTVAL, 8, 0);
      INSERT INTO DETB_FAST_PAY_CUSTOM
        (msg_id,
         create_time,
         no_of_txns,
         control_sum,
         init_party_name,
         INIT_STREET_NAME,
         init_build_no,
         init_postal_cd,
         init_town_name,
         init_country,
         pmt_info_id,
         payment_method,
         batch_booking,
         req_exc_trndt,
         dr_name,
         dr_acc,
         ccy,
         dr_bic,
         instruction_id,
         endtoendid,
         amount,
         cr_ccy,
         cr_bic,
         cr_name,
         cr_street_name,
         cr_build_no,
         cr_postal_cd,
         cr_town_name,
         cr_country,
         cr_acc,
         cod,
         unstruc_code,
         SEQ)
      values
        (R.MsgId,
         R.CreDtTm,
         R.NbOfTxs,
         R.CtrlSum,
         R.Nm,
         R.INIT_STRTNM,
         R.INIT_BLDGNB,
         R.INIT_PSTCD,
         R.INIT_TWNNM,
         R.INIT_CTRY,
         R.PMTINFID,
         R.PMTMTD,
         R.BTCHBOOKG,
         R.REQDEXCTNDT,
         R.DRNM,
         R.DRACC,
         R.DRCCY,
         R.DRBICFI,
         R.INSTRID,
         R.ENDTOENDID,
         R.INSTDAMT,
         R.CRCCY,
         R.CRBICFI,
         R.CRNM,
         R.CR_STRTNM,
         R.CR_BLDGNB,
         R.CR_PSTCD,
         R.CR_TWNNM,
         R.CR_CTRY,
         R.CRACC,
         R.CD,
         R.USTRD,
         L_SEQ);
    
      BEGIN
      
        BEGIN
          select BRANCH_CODE, CCY, cust_ac_no
            INTO l_ty_rtupld.ty_upld_rtl_teller.ofs_branch,
                 l_ty_rtupld.ty_upld_rtl_teller.ofs_ccy,
                 l_ty_rtupld.ty_upld_rtl_teller.ofs_acc
            from sttm_cust_account
           where cust_Ac_no = R.CRACC;
        EXCEPTION
          WHEN OTHERS THEN
            DBG('FAILED TO GET BENEFICIARY DETAILS' || SQLERRM);
            PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '01');
            RETURN FALSE;
        END;
        IF R.CtrlSum <> R.INSTDAMT THEN
          DBG('Instruction amount and control sum are not equal');
          PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '02');
          RETURN FALSE;
        END IF;
      
        SELECT COUNT(1)
          INTO l_bic_count
          FROM DETB_FAST_BIC_CODE_CUSTOM
         WHERE BIC_CODE = R.DRBICFI;
        IF l_bic_count <= 0 THEN
          DBG('Bic is not maintained');
          PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '04');
          RETURN FALSE;
        END IF;
        DBG('ofs Branch code is ' ||
            l_ty_rtupld.ty_upld_rtl_teller.ofs_branch);
        global.pr_init(l_ty_rtupld.ty_upld_rtl_teller.ofs_branch, 'BANKON');
      
        DBG('Calling fn_get_process_refno');
        IF NOT trpkss.fn_get_process_refno(global.current_branch,
                                           'FTDI',
                                           global.application_date,
                                           l_serial,
                                           l_ty_rtupld.ty_upld_rtl_teller.trn_ref_no,
                                           l_err_code) THEN
          DBG('Failed in generating prod ref no ' || l_err_code);
        END IF;
        DBG('Calling fn_get_process_refno');
        l_ty_rtupld.ty_upld_rtl_teller.xref           := 'FJB' ||
                                                         TO_CHAR(SYSDATE,
                                                                 'YYDDD') ||
                                                         L_SEQ;
        l_ty_rtupld.ty_upld_rtl_teller.branch_code    := global.current_branch;
        l_ty_rtupld.ty_upld_rtl_teller.trn_dt         := global.application_date;
        l_ty_rtupld.ty_upld_rtl_teller.value_dt       := global.application_date;
        l_ty_rtupld.ty_upld_rtl_teller.product_code   := 'FTDI';
        l_ty_rtupld.ty_upld_rtl_teller.auth_stat      := 'A';
        l_ty_rtupld.ty_upld_rtl_teller.record_stat    := 'O';
        l_ty_rtupld.ty_upld_rtl_teller.maker_id       := global.user_id;
        l_ty_rtupld.ty_upld_rtl_teller.maker_dt_stamp := fn_sysdate;
        l_ty_rtupld.ty_upld_rtl_teller.narrative      := NULL;
        l_ty_rtupld.ty_upld_rtl_teller.txn_acc        := R.DRACC;
        DBG('Before l_ty_rtupld.ty_upld_rtl_teller.txn_acc ' ||
            l_ty_rtupld.ty_upld_rtl_teller.txn_acc);
      
        l_ty_rtupld.ty_upld_rtl_teller.txn_acc := g_fast_params.NOSTRO_ACCOUNT;
      
        DBG('After l_ty_rtupld.ty_upld_rtl_teller.txn_acc ' ||
            l_ty_rtupld.ty_upld_rtl_teller.txn_acc);
      
        select branch_code, CCY
          INTO l_ty_rtupld.ty_upld_rtl_teller.txn_branch,
               l_ty_rtupld.ty_upld_rtl_teller.txn_ccy
          from sttm_cust_account
         where cust_ac_no = l_ty_rtupld.ty_upld_rtl_teller.txn_acc;
      
        l_ty_rtupld.ty_upld_rtl_teller.ofs_amount := NULL;
        l_ty_rtupld.ty_upld_rtl_teller.txn_amount := R.INSTDAMT;
        DEPKS_RTL_TELLER.G_TRN_REF_NO             := null;
        IF NOT depkss_retailtellerupload.fn_upload(l_ty_rtupld.ty_upld_rtl_teller,
                                                   l_ty_rtupld.tbl_chgdets,
                                                   l_ty_rtupld.ty_misdetails,
                                                   l_ty_rtupld.tbl_udfdetails,
                                                   l_ty_rtupld.ty_pcdetails,
                                                   l_ty_rtupld.ty_mckdetails,
                                                   l_ty_rtupld.ty_msgdets,
                                                   l_ty_rtupld.tbl_node,
                                                   l_source,
                                                   l_rec_txn_ctrl.override_flag,
                                                   l_status_on_save,
                                                   l_ret,
                                                   l_err_tbl) THEN
          DBG('Failed while calling depks_retailtellerupload.fn_upload' ||
              SQLCODE || '~' || l_err_code);
          FOR i IN 1 .. l_Err_Tbl.COUNT LOOP
            l_Err_Code := l_Err_Tbl(i).Err_Code;
            DBG('Failed in fn_upload ' || l_err_code);
          END LOOP;
          DBG('Failed to process transaction');
          PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '03');
          RETURN FALSE;
        END IF;
        dbg('l_ty_rtupld.ty_upld_rtl_teller.trn_ref_no == ' ||
            l_ty_rtupld.ty_upld_rtl_teller.trn_ref_no);
        dbg('l_ty_rtupld.ty_upld_rtl_teller.branch_code == ' ||
            l_ty_rtupld.ty_upld_rtl_teller.branch_code);
      
        IF NOT depkss_rtl_teller.fn_rtl_teller_auth(l_ty_rtupld.ty_upld_rtl_teller.branch_code,
                                                    l_ty_rtupld.ty_upld_rtl_teller.trn_ref_no,
                                                    global.user_id,
                                                    global.lcy,
                                                    l_err_code,
                                                    l_err_param) THEN
          dbg('Auth returned false ' || l_err_code);
          DBG('Failed to process transaction');
          PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '03');
          RETURN FALSE;
        END IF;
      
        UPDATE DETB_FAST_PAY_CUSTOM
           set record_stat      = 'O',
               auth_stat        = 'A',
               once_auth        = 'Y',
               mod_no           = '1',
               maker_id         = global.user_id,
               maker_dt_stamp   = fn_sysdate,
               checker_id       = global.user_id,
               checker_dt_stamp = fn_sysdate,
               trn_ref_no       = l_ty_rtupld.ty_upld_rtl_teller.trn_ref_no,
               xref             = l_ty_rtupld.ty_upld_rtl_teller.xref,
               handoff_stat     = 'I',
               txn_status       = 'INIT'
         where msg_id = R.MsgId
           and seq = l_seq;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('FAILED TO PROCESS');
          DBG('Failed to process transaction');
          PR_TRN_STATUS_UPDATE(R.MsgId, L_SEQ, 'F', '03');
          RETURN FALSE;
      END;
    
      DBG('SUCCESS');
    END LOOP;
    DBG('Returing from FN_PROCESS_TRN');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_PROCESS_TRN;

  FUNCTION FN_PROCESS_STATUS(p_FILE_NAME IN VARCHAR2, P_XML XMLTYPE)
    RETURN BOOLEAN AS
    L_XML            XMLTYPE;
    l_ty_rtupld      depks_retailtellerupload.typ_retailtellerupld_rec;
    l_source         VARCHAR2(15) := 'BANKON';
    l_err_tbl        ovpkss.tbl_error;
    l_rec_txn_ctrl   gwpks_brntxn_control.typ_txn_ctrl;
    l_status_on_save CHAR;
    l_ret            NUMBER;
    l_serial         varchar2(16);
    l_Err_Code       VARCHAR2(1000);
    l_err_param      varchar2(100);
    l_str_pos        number;
    l_msg            clob;
    l_xref           VARCHAR2(35);
    l_fccref         VARCHAR2(35);
    l_override_flag  VARCHAR2(1);
    l_auto_auth_flag VARCHAR2(1);
    l_branch_code    VARCHAR2(3);
  BEGIN
    DBG('Inside FN_PROCESS_STATUS ' || p_FILE_NAME);
  
    L_XML := P_XML;
    DBG('File name: ' || p_FILE_NAME);
    l_str_pos := INSTR(L_XML.getclobval(), 'pain.002.001.06');
    DBG('l_str_pos ' || l_str_pos);
  
    IF l_str_pos > 0 THEN
      l_msg := replace(L_XML.getclobval(),
                       '<Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06">',
                       '<Document>');
      DBG('l_msg ' || l_msg);
      L_XML := XMLTYPE.createXML(l_msg);
    
      FOR R IN (SELECT EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/MsgId/text()') AS MSGID,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/CreDtTm/text()') AS CREDTTM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/Nm/text()') AS INIT_NAME,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/PstlAdr/StrtNm/text()') AS STREET_NAME,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/PstlAdr/BldgNb/text()') AS BLDGNB,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/PstlAdr/PstCd/text()') AS PSTCD,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/PstlAdr/TwnNm/text()') AS TWNNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/InitgPty/PstlAdr/Ctry/text()') AS CTRY,
                       --
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/DbtrAgt/FinInstnId/BICFI/text()') AS DRBICFI,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/GrpHdr/CdtrAgt/FinInstnId/BICFI/text()') AS CRBICFI,
                       
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlGrpInfAndSts/OrgnlMsgId/text()') AS ORGNLMSGID,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlGrpInfAndSts/OrgnlMsgNmId/text()') AS ORGNLMSGNMID,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlGrpInfAndSts/OrgnlCreDtTm/text()') AS ORGNLCREDTTM,
                       
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/OrgnlPmtInfId/text()') AS ORGNLPMTINFID,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlEndToEndId/text()') AS ORGNLENDTOENDID,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/TxSts/text()') AS TXSTS,
                       
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Amt/InstdAmt/text()') AS INSTDAMT,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Amt/InstdAmt/@Ccy') AS CCY,
                       
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/Nm/text()') AS DRNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/StrtNm/text()') AS DRSTRTNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/BldgNb/text()') AS DRBLDGNB,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/PstCd/text()') AS DRPSTCD,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/TwnNm/text()') AS DRTWNNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Ctry/text()') AS DRCTRY,
                       
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/Nm/text()') AS CRNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/StrtNm/text()') AS CRSTRTNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/BldgNb/text()') AS CRBLDGNB,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/PstCd/text()') AS CRPSTCD,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/TwnNm/text()') AS CRTWNNM,
                       EXTRACTVALUE(VALUE(P),
                                    '/CstmrPmtStsRpt/OrgnlPmtInfAndSts/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/Ctry/text()') AS CRCTRY
                
                  FROM TABLE(XMLSEQUENCE(EXTRACT(L_XML, '//CstmrPmtStsRpt'))) P) LOOP
      
        DBG('MsgId ' || R.MSGID);
        DBG('CreDtTm ' || R.CREDTTM);
        DBG('ORGNLMSGID ' || R.ORGNLMSGID);
        DBG('ORGNLMSGNMID ' || R.ORGNLMSGNMID);
        DBG('ORGNLCREDTTM ' || R.ORGNLCREDTTM);
      
        DBG('ORGNLPMTINFID ' || R.ORGNLPMTINFID);
        DBG('ORGNLENDTOENDID ' || R.ORGNLENDTOENDID);
        DBG('TXSTS ' || R.TXSTS);
      
        insert into DETB_FAST_TRN_LOG_CUSTOM
          (msg_id,
           seq_no,
           trn_ref_no,
           trn_status,
           SYS_TIME,
           handoff_stat,
           MESSAGE,
           XREF,
           MSG_NAME_ID,
           CREATE_TIME,
           PAY_INFO_ID,
           END_TO_END_ID,
           PAYMENT_TYPE)
          select msg_id,
                 lpad(TRSQ_FAST_PAY.NEXTVAL, 6, '0'),
                 trn_ref_no,
                 R.TXSTS,
                 sysdate,
                 'N',
                 P_XML.getClobVal,
                 XREF,
                 MSG_NAME_ID,
                 CREATE_TIME,
                 PAY_INFO_ID,
                 END_TO_END_ID,
                 'O'
            FROM detb_fast_trn_log_custom
           where msg_id = R.ORGNLMSGID
             and pay_info_id = R.ORGNLPMTINFID
             and end_to_end_id = R.ORGNLENDTOENDID;
      
        DBG('Success' || SQL%ROWCOUNT);
      
        begin
          select xref, trn_ref_no
            INTO l_xref, l_fccref
            from DETB_FAST_TRN_LOG_CUSTOM
           where msg_id = R.ORGNLMSGID
             and pay_info_id = R.ORGNLPMTINFID
             and end_to_end_id = R.ORGNLENDTOENDID;
          dbg('l_xref ' || l_xref || ' ~l_fccref : ' || l_fccref);
        
          select branch_code
            into l_branch_code
            from detb_rtl_teller
           where trn_ref_no = l_fccref;
        exception
          when others then
            dbg('failed while fetching ref' || sqlerrm);
        end;
      
        IF R.TXSTS = 'RJCT' THEN
        
          dbg('Calling depks_retailtellerupload.fn_reverse');
          IF NOT depks_retailtellerupload.fn_reverse(l_xref,
                                                     l_fccref,
                                                     l_source,
                                                     l_override_flag,
                                                     l_auto_auth_flag,
                                                     l_err_tbl) THEN
            Dbg('Failed in depks_retailtellerupload.fn_reverse' || sqlerrm);
            RETURN FALSE;
          END IF;
        
          IF NOT depkss_rtl_teller.fn_rtl_teller_auth(l_branch_code,
                                                      l_fccref,
                                                      global.user_id,
                                                      global.lcy,
                                                      l_err_code,
                                                      l_err_param) THEN
            dbg('Auth returned false ' || l_err_code);
            RETURN FALSE;
          END IF;
          dbg('Reversal success');
        
        END IF;
        /*UPDATE cstm_contract_userdef_fields
        set field_val_5 = R.TXSTS
        where contract_ref_no = l_fccref;*/
      
      END LOOP;
    END IF;
    DBG('Returing from FN_PROCESS_STATUS');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      RETURN FALSE;
  END FN_PROCESS_STATUS;
  FUNCTION FN_GET_PARAMS RETURN DETM_FAST_PARAM_CUSTOM%ROWTYPE RESULT_CACHE RELIES_ON(DETM_FAST_PARAM_CUSTOM) IS
  BEGIN
    DBG('Inside FN_GET_PARAMS');
    SELECT * INTO g_fast_params FROM DETM_FAST_PARAM_CUSTOM;
    DBG('Returing from FN_GET_PARAMS');
    RETURN g_fast_params;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed in FN_GET_PARAMS' || SQLERRM);
      DBG('Error ' || dbms_utility.format_error_backtrace);
      g_fast_params := NULL;
      RETURN g_fast_params;
  END;
  PROCEDURE PR_TRN_STATUS_UPDATE(P_MSG_ID      VARCHAR2,
                                 P_SEQ         VARCHAR2,
                                 P_STATUS      VARCHAR2,
                                 P_REASON_CODE VARCHAR2) IS
  BEGIN
    DBG('INSIDE PR_TRN_STATUS_UPDATE');
    UPDATE DETB_FAST_PAY_CUSTOM
       set maker_id       = global.user_id,
           maker_dt_stamp = fn_sysdate,
           handoff_stat   = 'I',
           txn_status     = P_STATUS,
           REASON_CODE    = P_REASON_CODE
     where msg_id = P_MSG_ID
       AND SEQ = P_SEQ;
    DBG('RETURNING FROM PR_TRN_STATUS_UPDATE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN PR_TRN_STATUS_UPDATE' || SQLERRM);
  END PR_TRN_STATUS_UPDATE;
END DEPKS_FAST_PAYMENT_CUSTOM;
/