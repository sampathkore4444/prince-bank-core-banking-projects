CREATE OR REPLACE PACKAGE BODY DEPKS_FAST_POPULATE_CUSTOM IS

  PROCEDURE DBG(LINE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('DE', 'DEPKS_FAST_HANDOFF_CUSTOM-->' || LINE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN DEPKS_FAST_HANDOFF_CUSTOM.DBG');
      DBG(SQLERRM);
  END;

  PROCEDURE PR_PROCESS_INIT(P_NAME VARCHAR2, P_VALUE VARCHAR2) IS
  
    CURSOR CR_XML_GEN IS
      SELECT * FROM DETB_FAST_TRN_LOG_CUSTOM WHERE HANDOFF_STAT = 'I';
    L_DETB_FAST_TRN_LOG_CUSTOM DETB_FAST_TRN_LOG_CUSTOM%ROWTYPE;
  BEGIN
    DBG('Inside pr_process_init');
    global.pr_init('001', 'SYSTEM');
    DBG('Started Processing ');
    l_fast_params := depks_fast_payment_custom.FN_GET_PARAMS;
    OPEN CR_XML_GEN;
    LOOP
      FETCH CR_XML_GEN
        INTO L_DETB_FAST_TRN_LOG_CUSTOM;
      IF CR_XML_GEN%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('STARTED FOR ' || L_DETB_FAST_TRN_LOG_CUSTOM.TRN_REF_NO);
      IF NOT FN_OUT_MSG_GEN(L_DETB_FAST_TRN_LOG_CUSTOM) THEN
        DBG('FAILED TO PREPARE XML FOR ' ||
            L_DETB_FAST_TRN_LOG_CUSTOM.TRN_REF_NO);
        IF NOT FN_UPDATE_STATUS(L_DETB_FAST_TRN_LOG_CUSTOM.SEQ_NO, 'E') THEN
          DBG('FAILED TO UPDATE STATUS FOR ' ||
              L_DETB_FAST_TRN_LOG_CUSTOM.SEQ_NO);
        END IF;
      END IF;
    END LOOP;
    DBG('Returing from pr_process_init');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in pr_process_init');
  END PR_PROCESS_INIT;

  PROCEDURE PR_GEN_STATUS_FILE IS
  
    CURSOR CR_XML_GEN_SUCC IS
      SELECT *
        FROM detb_fast_pay_custom
       WHERE HANDOFF_STAT = 'I'
         and txn_status = 'INIT';
  
    CURSOR CR_XML_GEN_FAIL IS
      SELECT *
        FROM detb_fast_pay_custom
       WHERE HANDOFF_STAT = 'I'
         and txn_status = 'F';
    L_detb_fast_pay_custom detb_fast_pay_custom%ROWTYPE;
  BEGIN
    DBG('Inside PR_GEN_STATUS_FILE');
    global.pr_init('001', 'SYSTEM');

    DBG('Started Processing ');
    l_fast_params := depks_fast_payment_custom.FN_GET_PARAMS;
    OPEN CR_XML_GEN_SUCC;
    LOOP
      FETCH CR_XML_GEN_SUCC
        INTO L_detb_fast_pay_custom;
      IF CR_XML_GEN_SUCC%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('STARTED FOR ' || l_detb_fast_pay_custom.TRN_REF_NO);
      IF NOT FN_ACSC_MSG_GEN(L_detb_fast_pay_custom) THEN
        DBG('FAILED TO PREPARE XML FOR ' ||
            l_detb_fast_pay_custom.TRN_REF_NO);
        UPDATE detb_fast_pay_custom
           set handoff_stat = 'E'
         where MSG_ID = l_detb_fast_pay_custom.Msg_Id
           and seq = L_detb_fast_pay_custom.seq;
      END IF;
    END LOOP;
    DBG('MESSAGE GENERATION FOR FAILED LOG');
    OPEN CR_XML_GEN_FAIL;
    LOOP
      FETCH CR_XML_GEN_FAIL
        INTO L_detb_fast_pay_custom;
      IF CR_XML_GEN_FAIL%NOTFOUND THEN
        EXIT;
      END IF;
      DBG('STARTED FOR ' || l_detb_fast_pay_custom.msg_id);
      IF NOT FN_REJECT_MSG_GEN(L_detb_fast_pay_custom) THEN
        DBG('FAILED TO PREPARE XML FOR ' || l_detb_fast_pay_custom.msg_id);
        UPDATE detb_fast_pay_custom
           set handoff_stat = 'E'
         where MSG_ID = l_detb_fast_pay_custom.Msg_Id
           and seq = L_detb_fast_pay_custom.Seq;
      END IF;
    END LOOP;
    DBG('Returing from PR_GEN_STATUS_FILE');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in PR_GEN_STATUS_FILE');
  END PR_GEN_STATUS_FILE;

  FUNCTION FN_OUT_MSG_GEN(P_DETB_FAST_TRN_LOG_CUSTOM DETB_FAST_TRN_LOG_CUSTOM%ROWTYPE)
    RETURN BOOLEAN IS
    XML_MESSAGE CLOB := '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Document xsi:schemaLocation="jaxb/iso20022/pain.001.001.05.xsd" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<CstmrCdtTrfInitn>
<GrpHdr>
<MsgId>$MSG_ID</MsgId>
<CreDtTm>$CREATE_DT</CreDtTm>
<NbOfTxs>$NOOFTXN</NbOfTxs>
<CtrlSum>$CONTROL_SUM</CtrlSum>
<InitgPty>
<Nm>$INIT_PARY_NAME</Nm>
</InitgPty>
<PstlAdr>
<StrtNm>$INIT_ST_NM</StrtNm>
<BldgNb>$INIT_BLD_NO</BldgNb>
<PstCd>$INIT_PS_CD</PstCd>
<TwnNm>$INIT_TWN_NM</TwnNm>
<Ctry>$INIT_CNTRY</Ctry>
</PstlAdr>
</GrpHdr>
<PmtInf>
<PmtInfId>$PAY_INFO_ID</PmtInfId>
<PmtMtd>TRF</PmtMtd>
<BtchBookg>false</BtchBookg>
<ReqdExctnDt>$REQ_EXEC_DATE</ReqdExctnDt>
<Dbtr>
<Nm>$DR_NAME</Nm>
</Dbtr>
<DbtrAcct>
<Id>
<Othr>
<Id>$DR_ACC</Id>
</Othr>
</Id>
<Ccy>$DR_CCY</Ccy>
</DbtrAcct>
<DbtrAgt>
<FinInstnId>
<BICFI>$DR_BIC</BICFI>
</FinInstnId>
</DbtrAgt>
<CdtTrfTxInf>
<PmtId>
<InstrId>$CR_INSTR_ID</InstrId>
<EndToEndId>$ENDTOENDID</EndToEndId>
</PmtId>
<Amt>
<InstdAmt Ccy="KHR">$AMOUNT</InstdAmt>
</Amt>
<ChrgBr>CRED</ChrgBr>
<CdtrAgt>
<FinInstnId>
<BICFI>$CR_BIC</BICFI>
</FinInstnId>
</CdtrAgt>
<Cdtr>
<Nm>$CR_NAME</Nm>
<PstlAdr>
<StrtNm>$CR_ST_NM</StrtNm>
<BldgNb>$CR_BLD_NO</BldgNb>
<PstCd>$CR_PS_CD</PstCd>
<TwnNm>$CR_TWN_NM</TwnNm>
<Ctry>$CR_CNTRY</Ctry>
</PstlAdr>
</Cdtr>
<CdtrAcct>
<Id>
<Othr>
<Id>$CR_ACC</Id>
</Othr>
</Id>
</CdtrAcct>
<Purp>
<Cd>GDDS</Cd>
</Purp>
<RmtInf>
<Ustrd>$REM_DESC</Ustrd>
</RmtInf>
</CdtTrfTxInf>
</PmtInf>
</CstmrCdtTrfInitn>
</Document>
';
  
    l_Msg_id         DETB_FAST_PAY_CUSTOM.MSG_ID%TYPE;
    l_create_dt      DETB_FAST_PAY_CUSTOM.CREATE_TIME%TYPE;
    l_amt            DETB_FAST_PAY_CUSTOM.Control_Sum%TYPE;
    l_INIT_PARY_NAME DETB_FAST_PAY_CUSTOM.Init_Party_Name%TYPE;
    l_PAY_INFO_ID    DETB_FAST_PAY_CUSTOM.PMT_INFO_ID%TYPE;
    l_REQ_EXEC_DATE  DETB_FAST_PAY_CUSTOM.Req_Exc_Trndt%TYPE;
    l_DR_NAME        DETB_FAST_PAY_CUSTOM.DR_NAME%TYPE;
    L_DR_CCY         DETB_FAST_PAY_CUSTOM.CCY%TYPE;
    L_DR_BIC         DETB_FAST_PAY_CUSTOM.DR_BIC%TYPE;
    L_CR_INSTR_ID    DETB_FAST_PAY_CUSTOM.INSTRUCTION_ID%TYPE;
    L_ENDTOENDID     DETB_FAST_PAY_CUSTOM.ENDTOENDID%TYPE;
    L_AMOUNT         DETB_FAST_PAY_CUSTOM.AMOUNT%TYPE;
    L_CR_BIC         DETB_FAST_PAY_CUSTOM.CR_BIC%TYPE;
    L_CR_NAME        DETB_FAST_PAY_CUSTOM.CR_NAME%TYPE;
    L_CR_ACC         DETB_FAST_PAY_CUSTOM.CR_ACC%TYPE;
    L_REM_DESC       DETB_FAST_PAY_CUSTOM.unstruc_code%TYPE;
    l_SWIFT_ADDR     sttm_branch.swift_addr%TYPE;
    l_pay_info_seq   varchar2(20);
  
    L_DETB_RTL_TELLER           DETB_RTL_TELLER%ROWTYPE;
    L_userdef_fields            cstm_contract_userdef_fields%ROWTYPE;
    L_SEQ                       NUMBER;
    l_DETB_FAST_BIC_CODE_CUSTOM DETB_FAST_BIC_CODE_CUSTOM%rowtype;
    L_STTM_BANK                 STTM_BANK%ROWTYPE;
  BEGIN
    DBG('Inside pr_process_init');
    BEGIN
      SELECT *
        INTO L_DETB_RTL_TELLER
        FROM DETB_RTL_TELLER
       WHERE TRN_REF_NO = P_DETB_FAST_TRN_LOG_CUSTOM.TRN_REF_NO;
    
      select *
        INTO L_userdef_fields
        from cstm_contract_userdef_fields
       where contract_ref_no = P_DETB_FAST_TRN_LOG_CUSTOM.TRN_REF_NO;
    
      select *
        INTO l_DETB_FAST_BIC_CODE_CUSTOM
        from DETB_FAST_BIC_CODE_CUSTOM
       where bank_name = L_userdef_fields.Field_Val_4;
    
      SELECT REPLACE(to_char(L_DETB_RTL_TELLER.MAKER_DT_STAMP,
                             'YYYY-MM-DD HH:MM:SS'),
                     ' ',
                     'T')
        INTO l_create_dt
        FROM DUAL;
      DBG('l_create_dt ' || l_create_dt);
    
      l_SWIFT_ADDR := l_fast_params.participant_code;
      DBG('l_SWIFT_ADDR ' || l_SWIFT_ADDR);
    
      l_pay_info_seq := fn_gen_alpha_ref(FAST_ID_SEQ.Nextval);
      DBG('l_pay_info_seq ' || l_pay_info_seq);
    
      l_PAY_INFO_ID := l_SWIFT_ADDR || '/' ||
                       l_DETB_FAST_BIC_CODE_CUSTOM.Participant_Code || '/' ||
                       l_pay_info_seq;
      DBG('l_PAY_INFO_ID ' || l_PAY_INFO_ID);
    
      l_DR_NAME := FN_GET_ACC_NAME(L_DETB_RTL_TELLER.Txn_Acc);
      DBG('l_DR_NAME ' || l_DR_NAME);
    
      L_CR_INSTR_ID := l_SWIFT_ADDR || '/' || l_pay_info_seq;
      DBG('L_CR_INSTR_ID ' || L_CR_INSTR_ID);
      L_ENDTOENDID := L_DETB_RTL_TELLER.TXN_ACC || '-' ||
                      L_userdef_fields.Field_Val_2;
      DBG('L_ENDTOENDID ' || L_ENDTOENDID);
    
      L_STTM_BANK := global_frc.fn_get_bank_rec_frc;
      DBG('l_INIT_PARY_NAME ' || l_INIT_PARY_NAME);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$MSG_ID',
                             P_DETB_FAST_TRN_LOG_CUSTOM.MSG_ID);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CREATE_DT', l_create_dt);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$NOOFTXN', '1');
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CONTROL_SUM',
                             L_DETB_RTL_TELLER.TXN_AMOUNT);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_PARY_NAME',
                             L_STTM_BANK.Bank_Name);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_ST_NM',
                             L_STTM_BANK.Resp_Officer_Address_Line1);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_BLD_NO',
                             L_STTM_BANK.Resp_Officer_Address_Line2);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_PS_CD',
                             L_STTM_BANK.Resp_Officer_Address_Line3);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_TWN_NM',
                             L_STTM_BANK.Resp_Officer_Address_Line4);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$INIT_CNTRY', 'KH');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$PAY_INFO_ID', l_PAY_INFO_ID);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$REQ_EXEC_DATE', l_create_dt);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DR_NAME', l_DR_NAME);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_ACC',
                             L_DETB_RTL_TELLER.TXN_ACC);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_CCY',
                             L_DETB_RTL_TELLER.TXN_CCY);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DR_BIC', l_SWIFT_ADDR);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CR_INSTR_ID', L_CR_INSTR_ID);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$ENDTOENDID', L_ENDTOENDID);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$AMOUNT',
                             L_DETB_RTL_TELLER.OFS_AMOUNT);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_BIC',
                             l_DETB_FAST_BIC_CODE_CUSTOM.Bic_Code);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_NAME',
                             L_userdef_fields.Field_Val_3);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_ST_NM',
                             L_userdef_fields.Field_Val_5);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_BLD_NO',
                             L_userdef_fields.Field_Val_6);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_PS_CD',
                             L_userdef_fields.Field_Val_7);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_TWN_NM',
                             L_userdef_fields.Field_Val_9);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_CNTRY',
                             L_userdef_fields.Field_Val_8);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_ACC',
                             L_userdef_fields.Field_Val_2);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$REM_DESC',
                             L_userdef_fields.Field_Val_10);
      DBG('Generated xml file ' || XML_MESSAGE);
    
      UPDATE DETB_FAST_TRN_LOG_CUSTOM
         set msg_name_id   = 'pain.001.001.05',
             create_time   = l_create_dt,
             pay_info_id   = l_PAY_INFO_ID,
             end_to_end_id = L_ENDTOENDID,
             handoff_stat  = 'G',
             message       = XML_MESSAGE
       WHERE seq_no = P_DETB_FAST_TRN_LOG_CUSTOM.Seq_No;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while generating the xml file' || SQLERRM);
    END;
    RETURN TRUE;
    DBG('Returing from pr_process_init');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in pr_process_init');
      RETURN FALSE;
  END FN_OUT_MSG_GEN;

  FUNCTION FN_REJECT_MSG_GEN(P_DETB_FAST_PAY_CUSTOM IN DETB_FAST_PAY_CUSTOM%ROWTYPE)
    RETURN BOOLEAN IS
    XML_MESSAGE CLOB := '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.007.001.05">
<CstmrPmtRvsl>
<GrpHdr>
<MsgId>$MSG_ID</MsgId>
<CreDtTm>$CREATE_DT</CreDtTm>
<NbOfTxs>1</NbOfTxs>
<InitgPty>
<Nm>$INIT_PARY_NAME</Nm>
<PstlAdr>
<StrtNm>$ISTREET_NAME</StrtNm>
<BldgNb>$IBLDGNB</BldgNb>
<PstCd>$IPOST_CODE</PstCd>
<TwnNm>$ITOWN_NAME</TwnNm>
<Ctry>$ICOUNTRY</Ctry>
</PstlAdr>
</InitgPty>
<DbtrAgt>
<FinInstnId>
<BICFI>$DR_BIC</BICFI>
</FinInstnId>
</DbtrAgt>
<CdtrAgt>
<FinInstnId>
<BICFI>$CR_BIC</BICFI>
</FinInstnId>
</CdtrAgt>
</GrpHdr>
<OrgnlGrpInf>
<OrgnlMsgId>$ORG_MSG_ID</OrgnlMsgId>
<OrgnlMsgNmId>pain.001.001.05</OrgnlMsgNmId>
<OrgnlCreDtTm>$ORG_CREATE_DT</OrgnlCreDtTm>
</OrgnlGrpInf>
<OrgnlPmtInfAndRvsl>
<OrgnlPmtInfId>$ORG_PAY_INFO_ID</OrgnlPmtInfId>
<TxInf>
<RvslId>$REVR_ID</RvslId>
<OrgnlEndToEndId>$END_TO_END</OrgnlEndToEndId>
<OrgnlInstdAmt Ccy="KHR">$AMOUNT</OrgnlInstdAmt>
<RvsdInstdAmt Ccy="KHR">$REV_AMOUNT</RvsdInstdAmt>
<RvslRsnInf>
<Orgtr>
<Nm>$ORG_NAME</Nm>
<PstlAdr>
<StrtNm>$ORG_STREET</StrtNm>
<BldgNb>$ORG_BUILD_NO</BldgNb>
<PstCd>$POSTAL_CODE</PstCd>
<TwnNm>$TOWN</TwnNm>
<Ctry>$COUNTRY</Ctry>
</PstlAdr>
</Orgtr>
<Rsn>
<Cd>AM05</Cd>
</Rsn>
</RvslRsnInf>
<OrgnlTxRef>
<ReqdExctnDt>$EXEC_DATE</ReqdExctnDt>
<Dbtr>
<Nm>$DR_NAME</Nm>
<PstlAdr>
<StrtNm>$DRSTREET_NAME</StrtNm>
<BldgNb>$DRBLDGNB</BldgNb>
<PstCd>$DRPOST_CODE</PstCd>
<TwnNm>$DRTOWN</TwnNm>
<Ctry>$DCOUNTRY</Ctry>
</PstlAdr>
</Dbtr>
<DbtrAcct>
<Id>
<Othr>
<Id>$DR_ACC</Id>
</Othr>
</Id>
</DbtrAcct>
<Cdtr>
<Nm>$CR_NAME</Nm>
<PstlAdr>
<StrtNm>$CRSTREET_NAME</StrtNm>
<BldgNb>$CRBLDGNB</BldgNb>
<PstCd>$CRPOST_CODE</PstCd>
<TwnNm>$CRTOWN</TwnNm>
<Ctry>$CRCOUNTRY</Ctry>
</PstlAdr>
</Cdtr>
</OrgnlTxRef>
</TxInf>
</OrgnlPmtInfAndRvsl>
</CstmrPmtRvsl>
</Document>
';
  
    l_Msg_id         DETB_FAST_PAY_CUSTOM.MSG_ID%TYPE;
    l_create_dt      DETB_FAST_PAY_CUSTOM.CREATE_TIME%TYPE;
    l_amt            DETB_FAST_PAY_CUSTOM.Control_Sum%TYPE;
    l_INIT_PARY_NAME DETB_FAST_PAY_CUSTOM.Init_Party_Name%TYPE;
    l_PAY_INFO_ID    DETB_FAST_PAY_CUSTOM.PMT_INFO_ID%TYPE;
    l_REQ_EXEC_DATE  DETB_FAST_PAY_CUSTOM.Req_Exc_Trndt%TYPE;
    l_DR_NAME        DETB_FAST_PAY_CUSTOM.DR_NAME%TYPE;
    L_DR_CCY         DETB_FAST_PAY_CUSTOM.CCY%TYPE;
    L_DR_BIC         DETB_FAST_PAY_CUSTOM.DR_BIC%TYPE;
    L_CR_INSTR_ID    DETB_FAST_PAY_CUSTOM.INSTRUCTION_ID%TYPE;
    L_ENDTOENDID     DETB_FAST_PAY_CUSTOM.ENDTOENDID%TYPE;
    L_AMOUNT         DETB_FAST_PAY_CUSTOM.AMOUNT%TYPE;
    L_CR_BIC         DETB_FAST_PAY_CUSTOM.CR_BIC%TYPE;
    L_CR_NAME        DETB_FAST_PAY_CUSTOM.CR_NAME%TYPE;
    L_CR_ACC         DETB_FAST_PAY_CUSTOM.CR_ACC%TYPE;
    L_REM_DESC       DETB_FAST_PAY_CUSTOM.unstruc_code%TYPE;
    l_SWIFT_ADDR     sttm_branch.swift_addr%TYPE;
    l_pay_info_seq   varchar2(20);
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_userdef_fields  cstm_contract_userdef_fields%ROWTYPE;
    L_SEQ             NUMBER;
  
    -- l_bic_directory        istm_bic_directory%rowtype;
    l_detb_fast_pay_custom detb_fast_pay_custom%ROWTYPE;
    l_STTM_BANK            STTM_BANK%rowtype;
  BEGIN
    DBG('Inside FN_reject_MSG_GEN');
  
    BEGIN
      SELECT REPLACE(to_char(P_DETB_FAST_PAY_CUSTOM.MAKER_DT_STAMP,
                             'YYYY-MM-DD HH:MM:SS'),
                     ' ',
                     'T'),
             TRSQ_FAST_PAY.NEXTVAL
        INTO l_create_dt, l_seq
        FROM DUAL;
      DBG('l_create_dt ' || l_create_dt);
    
      l_SWIFT_ADDR := l_fast_params.participant_code;
      DBG('l_SWIFT_ADDR ' || l_SWIFT_ADDR);
      l_Msg_id := 'REF' || l_SWIFT_ADDR || LPAD(L_SEQ, 9, '0');
      dbg('l_Msg_id ' || l_Msg_id);
    
      L_STTM_BANK := global_frc.fn_get_bank_rec_frc;
      DBG('l_INIT_PARY_NAME ' || l_INIT_PARY_NAME);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$MSG_ID', l_Msg_id);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CREATE_DT', l_create_dt);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_PARY_NAME',
                             l_STTM_BANK.Bank_Name);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ISTREET_NAME',
                             L_STTM_BANK.Resp_Officer_Address_Line1);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$IBLDGNB',
                             L_STTM_BANK.Resp_Officer_Address_Line2);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$IPOST_CODE',
                             L_STTM_BANK.Resp_Officer_Address_Line3);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ITOWN_NAME',
                             L_STTM_BANK.Resp_Officer_Address_Line4);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$ICOUNTRY', 'KH');
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_BIC',
                             p_detb_fast_pay_custom.dr_bic);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_BIC',
                             p_detb_fast_pay_custom.cr_bic);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_MSG_ID',
                             p_detb_fast_pay_custom.msg_id);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_CREATE_DT',
                             p_detb_fast_pay_custom.create_time);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_PAY_INFO_ID',
                             p_detb_fast_pay_custom.pmt_info_id);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$REVR_ID', LPAD(L_SEQ, 9, '0'));
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$END_TO_END',
                             p_detb_fast_pay_custom.endtoendid);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$AMOUNT',
                             p_detb_fast_pay_custom.amount);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$REV_AMOUNT',
                             p_detb_fast_pay_custom.amount);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_NAME',
                             p_detb_fast_pay_custom.init_party_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_STREET',
                             p_detb_fast_pay_custom.init_street_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_BUILD_NO',
                             p_detb_fast_pay_custom.init_build_no);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$POSTAL_CODE',
                             p_detb_fast_pay_custom.init_postal_cd);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$TOWN',
                             p_detb_fast_pay_custom.init_town_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$COUNTRY',
                             p_detb_fast_pay_custom.init_country);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$EXEC_DATE',
                             p_detb_fast_pay_custom.req_exc_trndt);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_NAME',
                             p_detb_fast_pay_custom.cr_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DRSTREET_NAME',
                             p_detb_fast_pay_custom.cr_street_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DRBLDGNB',
                             p_detb_fast_pay_custom.cr_build_no);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DRPOST_CODE',
                             p_detb_fast_pay_custom.cr_postal_cd);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DRTOWN',
                             p_detb_fast_pay_custom.cr_town_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DCOUNTRY',
                             p_detb_fast_pay_custom.cr_country);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_ACC',
                             p_detb_fast_pay_custom.cr_acc);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_NAME',
                             p_detb_fast_pay_custom.dr_name);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CRSTREET_NAME', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CRBLDGNB', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CRPOST_CODE', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CRTOWN', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CRCOUNTRY', '');
    
      DBG('Generated xml file ' || XML_MESSAGE);
    
      insert into DETB_FAST_TRN_LOG_CUSTOM
        (msg_id,
         seq_no,
         trn_ref_no,
         trn_status,
         SYS_TIME,
         handoff_stat,
         MESSAGE,
         XREF,
         MSG_NAME_ID,
         CREATE_TIME,
         PAY_INFO_ID,
         END_TO_END_ID,
         PAYMENT_TYPE)
      VALUES
        (l_Msg_id,
         L_SEQ,
         P_DETB_FAST_PAY_CUSTOM.TRN_REF_NO,
         'REF',
         SYSDATE,
         'G',
         XML_MESSAGE,
         P_DETB_FAST_PAY_CUSTOM.XREF,
         'pain.007.001.05',
         l_create_dt,
         P_DETB_FAST_PAY_CUSTOM.PMT_INFO_ID,
         P_DETB_FAST_PAY_CUSTOM.ENDTOENDID,
         'I');
    
      UPDATE detb_fast_pay_custom
         set TXN_STATUS = 'REF', HANDOFF_STAT = 'G'
       WHERE msg_id = p_detb_fast_pay_custom.msg_id
         and seq = P_DETB_FAST_PAY_CUSTOM.Seq;
    exception
      when others then
        DBG('Failed while generating msg' || sqlerrm);
        UPDATE detb_fast_pay_custom
           set TXN_STATUS = 'REF', HANDOFF_STAT = 'E'
         WHERE TRN_REF_NO = p_detb_fast_pay_custom.msg_id
           and seq = P_DETB_FAST_PAY_CUSTOM.Seq;
    end;
    DBG('Returing from FN_REJECT_MSG_GEN');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in FN_REJECT_MSG_GEN' || SQLERRM);
      RETURN FALSE;
  END FN_REJECT_MSG_GEN;

  FUNCTION FN_ACSC_MSG_GEN(p_detb_fast_pay_custom IN detb_fast_pay_custom%ROWTYPE)
    RETURN BOOLEAN IS
    XML_MESSAGE CLOB := '<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.06">
<CstmrPmtStsRpt>
<GrpHdr>
<MsgId>$MSG_ID</MsgId>
<CreDtTm>$CREATE_DT</CreDtTm>
<InitgPty>
<Nm>$INIT_PARY_NAME</Nm>
<PstlAdr>
<StrtNm>$ISTREET_NAME</StrtNm>
<BldgNb>$IBLDGNB</BldgNb>
<PstCd>$IPOST_CODE</PstCd>
<TwnNm>$ITOWN_NAME</TwnNm>
<Ctry>$ICOUNTRY</Ctry>
</PstlAdr>
</InitgPty>
<DbtrAgt>
<FinInstnId>
<BICFI>$DR_BIC</BICFI>
</FinInstnId>
</DbtrAgt>
<CdtrAgt>
<FinInstnId>
<BICFI>$CR_BIC</BICFI>
</FinInstnId>
</CdtrAgt>
</GrpHdr>
<OrgnlGrpInfAndSts>
<OrgnlMsgId>$ORG_MSG_ID</OrgnlMsgId>
<OrgnlMsgNmId>pacs.001.001.05</OrgnlMsgNmId>
<OrgnlCreDtTm>$ORG_CREATE_DT</OrgnlCreDtTm>
</OrgnlGrpInfAndSts>
<OrgnlPmtInfAndSts>
<OrgnlPmtInfId>$ORG_PAY_INFO_ID</OrgnlPmtInfId>
<TxInfAndSts>
<OrgnlEndToEndId>$END_TO_END</OrgnlEndToEndId>
<TxSts>ACSC</TxSts>
<OrgnlTxRef>
<Amt>
<InstdAmt Ccy="KHR">$AMOUNT</InstdAmt>
</Amt>
<Dbtr>
<Nm>$DR_NAME</Nm>
<PstlAdr>
<StrtNm>$DRSTREET_NAME</StrtNm>
<BldgNb>$DRBLDGNB</BldgNb>
<PstCd>$DRPOST_CODE</PstCd>
<TwnNm>$DRTOWN</TwnNm>
<Ctry>$DCOUNTRY</Ctry>
</PstlAdr>
</Dbtr>
<Cdtr>
<Nm>$CR_NAME</Nm>
<PstlAdr>
<StrtNm>$CRSTREET_NAME</StrtNm>
<BldgNb>$CRBLDGNB</BldgNb>
<PstCd>$CRPOST_CODE</PstCd>
<TwnNm>$CRTOWN</TwnNm>
<Ctry>$CRCOUNTRY</Ctry>
</PstlAdr>
</Cdtr>
</OrgnlTxRef>
</TxInfAndSts>
</OrgnlPmtInfAndSts>
</CstmrPmtStsRpt>
</Document>
';
  
    l_Msg_id         DETB_FAST_PAY_CUSTOM.MSG_ID%TYPE;
    l_create_dt      DETB_FAST_PAY_CUSTOM.CREATE_TIME%TYPE;
    l_amt            DETB_FAST_PAY_CUSTOM.Control_Sum%TYPE;
    l_INIT_PARY_NAME DETB_FAST_PAY_CUSTOM.Init_Party_Name%TYPE;
    l_PAY_INFO_ID    DETB_FAST_PAY_CUSTOM.PMT_INFO_ID%TYPE;
    l_REQ_EXEC_DATE  DETB_FAST_PAY_CUSTOM.Req_Exc_Trndt%TYPE;
    l_DR_NAME        DETB_FAST_PAY_CUSTOM.DR_NAME%TYPE;
    L_DR_CCY         DETB_FAST_PAY_CUSTOM.CCY%TYPE;
    L_DR_BIC         DETB_FAST_PAY_CUSTOM.DR_BIC%TYPE;
    L_CR_INSTR_ID    DETB_FAST_PAY_CUSTOM.INSTRUCTION_ID%TYPE;
    L_ENDTOENDID     DETB_FAST_PAY_CUSTOM.ENDTOENDID%TYPE;
    L_AMOUNT         DETB_FAST_PAY_CUSTOM.AMOUNT%TYPE;
    L_CR_BIC         DETB_FAST_PAY_CUSTOM.CR_BIC%TYPE;
    L_CR_NAME        DETB_FAST_PAY_CUSTOM.CR_NAME%TYPE;
    L_CR_ACC         DETB_FAST_PAY_CUSTOM.CR_ACC%TYPE;
    L_REM_DESC       DETB_FAST_PAY_CUSTOM.unstruc_code%TYPE;
    l_SWIFT_ADDR     sttm_branch.swift_addr%TYPE;
    l_pay_info_seq   varchar2(20);
  
    L_DETB_RTL_TELLER DETB_RTL_TELLER%ROWTYPE;
    L_userdef_fields  cstm_contract_userdef_fields%ROWTYPE;
    L_SEQ             NUMBER;
  
    --l_bic_directory        istm_bic_directory%rowtype;
    l_detb_fast_pay_custom detb_fast_pay_custom%ROWTYPE;
    l_STTM_BANK            STTM_BANK%rowtype;
  BEGIN
    DBG('Inside FN_ACSC_MSG_GEN');
  
    BEGIN
    
      /*SELECT *
       INTO L_DETB_RTL_TELLER
       FROM DETB_RTL_TELLER
      WHERE TRN_REF_NO = p_detb_fast_pay_custom.TRN_REF_NO;*/
    
      SELECT REPLACE(to_char(p_detb_fast_pay_custom.MAKER_DT_STAMP,
                             'YYYY-MM-DD HH:MM:SS'),
                     ' ',
                     'T'),
             TRSQ_FAST_PAY.NEXTVAL
        INTO l_create_dt, l_seq
        FROM DUAL;
      DBG('l_create_dt ' || l_create_dt);
    
      l_SWIFT_ADDR := l_fast_params.PARTICIPANT_CODE;
    
      DBG('l_SWIFT_ADDR ' || l_SWIFT_ADDR);
      l_Msg_id := 'REP' || l_SWIFT_ADDR || LPAD(L_SEQ, 9, '0');
      dbg('l_Msg_id ' || l_Msg_id);
    
      L_STTM_BANK := global_frc.fn_get_bank_rec_frc;
      DBG('l_INIT_PARY_NAME ' || l_INIT_PARY_NAME);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$MSG_ID', l_Msg_id);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$CREATE_DT', l_create_dt);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$INIT_PARY_NAME',
                             l_STTM_BANK.Bank_Name);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ISTREET_NAME',
                             l_STTM_BANK.Resp_Officer_Address_Line1);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$IBLDGNB',
                             l_STTM_BANK.Resp_Officer_Address_Line2);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$IPOST_CODE',
                             l_STTM_BANK.Resp_Officer_Address_Line3);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ITOWN_NAME',
                             l_STTM_BANK.Resp_Officer_Address_Line4);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$ICOUNTRY', 'KH');
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_BIC',
                             p_detb_fast_pay_custom.dr_bic);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_BIC',
                             p_detb_fast_pay_custom.cr_bic);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_MSG_ID',
                             p_detb_fast_pay_custom.msg_id);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_CREATE_DT',
                             p_detb_fast_pay_custom.create_time);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$ORG_PAY_INFO_ID',
                             p_detb_fast_pay_custom.pmt_info_id);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$END_TO_END',
                             p_detb_fast_pay_custom.endtoendid);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$AMOUNT',
                             p_detb_fast_pay_custom.amount);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$DR_NAME',
                             p_detb_fast_pay_custom.dr_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DRSTREET_NAME', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DRBLDGNB', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DRPOST_CODE', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DRTOWN', '');
      XML_MESSAGE := REPLACE(XML_MESSAGE, '$DCOUNTRY', '');
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CR_NAME',
                             p_detb_fast_pay_custom.cr_name);
    
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CRSTREET_NAME',
                             p_detb_fast_pay_custom.cr_street_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CRBLDGNB',
                             p_detb_fast_pay_custom.cr_build_no);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CRPOST_CODE',
                             p_detb_fast_pay_custom.cr_postal_cd);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CRTOWN',
                             p_detb_fast_pay_custom.cr_town_name);
      XML_MESSAGE := REPLACE(XML_MESSAGE,
                             '$CRCOUNTRY',
                             p_detb_fast_pay_custom.cr_town_name);
    
      DBG('Generated xml file ' || XML_MESSAGE);
    
      insert into DETB_FAST_TRN_LOG_CUSTOM
        (msg_id,
         seq_no,
         trn_ref_no,
         trn_status,
         SYS_TIME,
         handoff_stat,
         MESSAGE,
         XREF,
         MSG_NAME_ID,
         CREATE_TIME,
         PAY_INFO_ID,
         END_TO_END_ID,
         PAYMENT_TYPE)
      VALUES
        (l_Msg_id,
         L_SEQ,
         P_DETB_FAST_PAY_CUSTOM.TRN_REF_NO,
         'ACSC',
         SYSDATE,
         'G',
         XML_MESSAGE,
         P_DETB_FAST_PAY_CUSTOM.XREF,
         'pain.002.001.06',
         l_create_dt,
         P_DETB_FAST_PAY_CUSTOM.PMT_INFO_ID,
         P_DETB_FAST_PAY_CUSTOM.ENDTOENDID,
         'I');
    
      UPDATE detb_fast_pay_custom
         set TXN_STATUS = 'ACSC', HANDOFF_STAT = 'G'
       WHERE msg_id = p_detb_fast_pay_custom.msg_id
         and seq = p_detb_fast_pay_custom.seq;
    
    EXCEPTION
      WHEN OTHERS THEN
        DBG('Failed while generating the xml file' || SQLERRM);
        UPDATE detb_fast_pay_custom
           set TXN_STATUS = 'ACSC', HANDOFF_STAT = 'E'
         WHERE TRN_REF_NO = p_detb_fast_pay_custom.msg_id
           and seq = p_detb_fast_pay_custom.seq;
    END;
  
    DBG('Returing from FN_ACSC_MSG_GEN');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('WOT in FN_ACSC_MSG_GEN' || SQLERRM);
      RETURN FALSE;
  END FN_ACSC_MSG_GEN;
  FUNCTION FN_UPDATE_STATUS(P_ID     DETB_FAST_TRN_LOG_CUSTOM.SEQ_NO%TYPE,
                            P_STATUS DETB_FAST_TRN_LOG_CUSTOM.handoff_stat%TYPE)
    RETURN BOOLEAN IS
  
  BEGIN
    DBG('ENTERED FOR FN_UPDATE_STATUS');
    UPDATE DETB_FAST_TRN_LOG_CUSTOM
       SET handoff_stat = P_STATUS
     WHERE SEQ_NO = P_ID;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('FAILED IN FN_UPDATE_STATUS');
      IF NOT FN_UPDATE_STATUS(P_ID, 'E') THEN
        DBG('FAILED TO UPDATE STATUS FOR ' || P_ID);
      END IF;
      RETURN FALSE;
  END FN_UPDATE_STATUS;

  FUNCTION FN_UPDATE_MSG(P_SEQ_NO  IN DETB_FAST_TRN_LOG_CUSTOM.SEQ_NO%TYPE,
                         P_MESSAGE IN DETB_FAST_TRN_LOG_CUSTOM.MESSAGE%TYPE)
    RETURN BOOLEAN IS
  BEGIN
    DBG('came to FN_UPDATE_MSG' || P_SEQ_NO);
    UPDATE DETB_FAST_TRN_LOG_CUSTOM
       SET MESSAGE = P_MESSAGE
     WHERE SEQ_NO = P_SEQ_NO;
  
    IF NOT (FN_UPDATE_STATUS(P_SEQ_NO, 'G')) THEN
      DBG('failed to update status' || P_SEQ_NO);
      RETURN FALSE;
    END IF;
    --COMMIT;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN FALSE;
  END FN_UPDATE_MSG;
  FUNCTION FN_GET_ACC_NAME(P_ACC STTM_CUST_ACCOUNT.CUST_AC_NO%TYPE)
    RETURN VARCHAR2 IS
    L_ACC_NAME STTM_CUST_ACCOUNT.AC_DESC%TYPE;
  BEGIN
    DBG('came to FN_GET_ACC_NAME for ' || P_ACC);
  
    SELECT AC_DESC
      INTO L_ACC_NAME
      FROM STTM_CUST_ACCOUNT
     WHERE CUST_AC_NO = P_ACC;
    DBG('returning FN_GET_ACC_NAME with  ' || L_ACC_NAME);
    RETURN L_ACC_NAME;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('failed in FN_GET_ACC_NAME');
      DBG(SQLCODE || ' ' || SQLERRM);
      RETURN NULL;
  END FN_GET_ACC_NAME;

END DEPKS_FAST_POPULATE_CUSTOM;
/