CREATE OR REPLACE PACKAGE BODY DEPKS_FAST_HANDOFF_CUSTOM IS

  PROCEDURE DBG(LINE IN VARCHAR2) IS
  BEGIN
    DEBUG.PR_DEBUG('IF', 'depks_fast_HANDOFF_CUSTOM-->' || LINE);
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed IN depks_fast_HANDOFF_CUSTOM.DBG');
      DBG(SQLERRM);
  END;
  PROCEDURE PR_INIT_PROCESS IS
  
    L_COUNT NUMBER := 0;
  
  BEGIN
    DBG('came inside pr_init_process');
    SELECT COUNT(1)
      INTO L_COUNT
      from DETB_FAST_TRN_LOG_CUSTOM
     WHERE handoff_stat = 'G'
       AND PAYMENT_TYPE = 'O';
    IF L_COUNT > 0 THEN
      BEGIN
        /*FOR L_PARAM_DATA IN (SELECT PARAM_NAME, PARAM_VALue
                               FROM detb_fast_parameters
                              WHERE PARAM_NAME IN
                                    ('FILE_PATH', 'FILE_EXT', 'FILE_NAME')) LOOP
          IF L_PARAM_DATA.PARAM_NAME = 'FILE_PATH' THEN
            L_FILE_PATH := L_PARAM_DATA.PARAM_VALue;
          ELSIF L_PARAM_DATA.PARAM_NAME = 'FILE_EXT' THEN
            L_FILE_EXT := L_PARAM_DATA.PARAM_VALue;
          ELSIF L_PARAM_DATA.PARAM_NAME = 'FILE_NAME' THEN
            L_FILE_NAME := L_PARAM_DATA.PARAM_VALue;
          END IF;
        END LOOP;*/
        l_fast_params := depks_fast_payment_custom.FN_GET_PARAMS;
      
        L_FILE_PATH := l_fast_params.out_path;
        L_FILE_EXT  := l_fast_params.file_ext;
        L_FILE_NAME := l_fast_params.out_file_name;
        DBG('FILE Path >> ' || L_FILE_PATH);
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to obtain param details ' || SQLERRM);
          --RETURN FALSE;
      END;
      BEGIN
        DBG('started  writing');
        FOR L_TRN_DATA in (select *
                             from DETB_FAST_TRN_LOG_CUSTOM
                            WHERE handoff_stat = 'G'
                              AND PAYMENT_TYPE = 'O'
                            ORDER BY SEQ_NO) LOOP
        
          DBG('processing for ' || L_TRN_DATA.SEQ_NO);
        
          BEGIN
            DBG('getting xml for processing for ' || L_TRN_DATA.SEQ_NO);
            L_FILE_NAME := L_FILE_NAME || '_' || L_TRN_DATA.msg_id || '_' ||
                           TO_CHAR(SYSDATE, 'DDMMYY') ||
                           TO_CHAR(SYSDATE, 'HHMISS') || L_FILE_EXT;
            DBG('L_FILE_NAME  >> ' || L_FILE_NAME);
            L_FILE_HANDLER := UTL_FILE.FOPEN(L_FILE_PATH,
                                             L_FILE_NAME,
                                             'W',
                                             32767);
            DBG('FILE Opened >> ' || L_FILE_NAME);
            PR_WRITE_TO_FILE(L_FILE_HANDLER, L_TRN_DATA.MESSAGE);
            PR_UPDATE_STATUS(L_TRN_DATA.SEQ_NO, 'H', L_FILE_NAME);
            UTL_FILE.fclose(L_FILE_HANDLER);
          EXCEPTION
            WHEN OTHERS THEN
              DBG('failed ' || sqlerrm);
              DBG('failed to  processing for ' || L_TRN_DATA.SEQ_NO);
              PR_UPDATE_STATUS(L_TRN_DATA.SEQ_NO, 'E', L_FILE_NAME);
          END;
        END LOOP;
        DBG('came oout loop');
        UTL_FILE.FCLOSE_ALL;
        DBG('XML Loaded successfully ');
      EXCEPTION
        WHEN OTHERS THEN
          DBG('failed' || SQLERRM);
      END;
      DBG('now generating the file ');
    END IF;
  
    DBG('came out');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT pr_INIT_PROCESS ' || SQLERRM);
  END PR_INIT_PROCESS;

  PROCEDURE PR_INCOMING_HANDOFF IS
  
    L_COUNT NUMBER := 0;
  
  BEGIN
    DBG('came inside PR_INCOMING_HANDOFF');
    SELECT COUNT(1)
      INTO L_COUNT
      from DETB_FAST_TRN_LOG_CUSTOM
     WHERE handoff_stat = 'G'
       AND PAYMENT_TYPE = 'I';
    IF L_COUNT > 0 THEN
      BEGIN
        /*FOR L_PARAM_DATA IN (SELECT PARAM_NAME, PARAM_VALue
                               FROM detb_fast_parameters
                              WHERE PARAM_NAME IN
                                    ('FILE_PATH', 'FILE_EXT', 'INC_FILE_NAME')) LOOP
          IF L_PARAM_DATA.PARAM_NAME = 'FILE_PATH' THEN
            L_FILE_PATH := L_PARAM_DATA.PARAM_VALue;
          ELSIF L_PARAM_DATA.PARAM_NAME = 'FILE_EXT' THEN
            L_FILE_EXT := L_PARAM_DATA.PARAM_VALue;
          ELSIF L_PARAM_DATA.PARAM_NAME = 'INC_FILE_NAME' THEN
            L_FILE_NAME := L_PARAM_DATA.PARAM_VALue;
          END IF;
        END LOOP;*/
        l_fast_params := depks_fast_payment_custom.FN_GET_PARAMS;
      
        L_FILE_PATH := l_fast_params.out_path;
        L_FILE_EXT  := l_fast_params.file_ext;
        L_FILE_NAME := l_fast_params.out_file_name;
      EXCEPTION
        WHEN OTHERS THEN
          DBG('Failed to obtain param details for IFTB_CLEARING_PARAM_CUSTOM');
          --RETURN FALSE;
      END;
    
      BEGIN
      
        DBG('started  writing');
      
        for L_TRN_DATA in (select *
                             from DETB_FAST_TRN_LOG_CUSTOM
                            WHERE handoff_stat = 'G'
                              AND PAYMENT_TYPE = 'I'
                            ORDER BY SEQ_NO) loop
        
          -------------
          DBG('processing for ' || L_TRN_DATA.SEQ_NO);
        
          begin
            DBG('getting xml for processing for ' || L_TRN_DATA.SEQ_NO);
            L_FILE_NAME := L_FILE_NAME || '_' || L_TRN_DATA.msg_id || '_' ||
                           TO_CHAR(SYSDATE, 'DDMMYY') ||
                           TO_CHAR(SYSDATE, 'HHMISS') || L_FILE_EXT;
            DBG('FILE Name >> ' || L_FILE_NAME);
            L_FILE_HANDLER := UTL_FILE.FOPEN(L_FILE_PATH,
                                             L_FILE_NAME,
                                             'W',
                                             32767);
            DBG('FILE Opened >> ' || L_FILE_NAME);
            PR_WRITE_TO_FILE(L_FILE_HANDLER, L_TRN_DATA.MESSAGE);
            PR_UPDATE_STATUS(L_TRN_DATA.SEQ_NO, 'H', L_FILE_NAME);
            UTL_FILE.fclose(L_FILE_HANDLER);
          exception
            when others then
              DBG('failed ' || sqlerrm);
              DBG('failed to  processing for ' || L_TRN_DATA.SEQ_NO);
              PR_UPDATE_STATUS(L_TRN_DATA.SEQ_NO, 'E', L_FILE_NAME);
          end;
        END LOOP;
        DBG('came oout loop');
        -- PR_WRITE_TO_FILE(L_FILE_HANDLER, L_XML_FOOTER);
        UTL_FILE.FCLOSE_ALL;
      
        DBG('XML Loaded successfully ');
      exception
        when others then
          DBG('failed');
      end;
      DBG('now generating the file ');
    END IF;
  
    DBG('came out');
  EXCEPTION
    WHEN OTHERS THEN
      DBG('In WOT PR_INCOMING_HANDOFF ' || SQLERRM);
  END PR_INCOMING_HANDOFF;

  PROCEDURE PR_WRITE_TO_FILE(P_FILE_HANDLER IN UTL_FILE.FILE_TYPE,
                             P_MESSAGE      IN DETB_FAST_TRN_LOG_CUSTOM.MESSAGE%TYPE) IS
  BEGIN
    DBG('CAME INSIDE WRITING');
    UTL_FILE.put_LINE(P_FILE_HANDLER, P_MESSAGE);
  
  END PR_WRITE_TO_FILE;

  PROCEDURE PR_UPDATE_STATUS(P_SEQ_NO    IN DETB_FAST_TRN_LOG_CUSTOM.SEQ_NO%TYPE,
                             P_STATUS    IN VARCHAR2,
                             P_FILE_NAME IN DETB_FAST_TRN_LOG_CUSTOM.FILE_NAME%TYPE) IS
  BEGIN
    UPDATE DETB_FAST_TRN_LOG_CUSTOM
       SET handoff_stat = P_STATUS, File_name = P_FILE_NAME
     WHERE SEQ_NO = P_SEQ_NO;
    DBG('record is in process state : ' || P_SEQ_NO);
    --COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to update status : ' || sqlerrm);
      RAISE;
  END PR_UPDATE_STATUS;

  PROCEDURE PR_UPDATE_FILENAME(P_FILENAME IN DETB_FAST_TRN_LOG_CUSTOM.FILE_NAME%TYPE,
                               P_STATUS   IN VARCHAR2) IS
  BEGIN
    UPDATE DETB_FAST_TRN_LOG_CUSTOM
       SET handoff_stat = P_STATUS, FILE_NAME = P_FILENAME
     WHERE handoff_stat = 'P';
    -- COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBG('Failed to update file name : ' || sqlerrm);
      RAISE;
  END PR_UPDATE_FILENAME;

END DEPKS_FAST_HANDOFF_CUSTOM;
/