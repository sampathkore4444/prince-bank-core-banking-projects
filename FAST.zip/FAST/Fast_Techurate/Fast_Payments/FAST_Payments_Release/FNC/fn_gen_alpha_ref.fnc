create or replace function fn_gen_alpha_ref(P_SEQ number) return varchar2 is
  l_seq          number := p_seq;
  TYPE CHAR_SET_VA IS VARRAY(36) OF CHAR;
  L_CHAR_SET  CHAR_SET_VA := CHAR_SET_VA('0',
                                         '1',
                                         '2',
                                         '3',
                                         '4',
                                         '5',
                                         '6',
                                         '7',
                                         '8',
                                         '9',
                                         'a',
                                         'b',
                                         'c',
                                         'd',
                                         'e',
                                         'f',
                                         'g',
                                         'h',
                                         'i',
                                         'j',
                                         'k',
                                         'l',
                                         'm',
                                         'n',
                                         'o',
                                         'p',
                                         'q',
                                         'r',
                                         's',
                                         't',
                                         'u',
                                         'v',
                                         'w',
                                         'x',
                                         'y',
                                         'z');
  l_alpha_seq varchar2(6) := '';
  l_reminder  number;
BEGIN
  l_alpha_seq := '';
  loop
    l_reminder  := mod(l_seq, 36);
    l_reminder  := l_reminder + 1;
    l_alpha_seq := L_CHAR_SET(l_reminder) || l_alpha_seq;
    l_seq       := floor((l_seq / 36));
    exit when l_seq <= 0;
  end loop;
  l_alpha_seq := lpad(l_alpha_seq, 6, '0');
  return l_alpha_seq;
END;
/