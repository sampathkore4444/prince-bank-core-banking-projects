﻿prompt Importing table detm_fast_param_custom...
set feedback off
set define off
insert into detm_fast_param_custom (INTERFACE, BIC_CODE, PARTICIPANT_CODE, IN_PATH, OUT_PATH, RECORD_STAT, AUTH_STAT, ONCE_AUTH, MOD_NO, MAKER_ID, MAKER_DT_STAMP, CHECKER_ID, CHECKER_DT_STAMP, FLEX_PRODUCT, DIGITAL_PRODUCT, NOSTRO_ACCOUNT, OUT_FILE_NAME, FILE_EXT)
values ('FAST', 'PRINXXXX', 'PRINKHPPXXXX', 'FAST_IN_READY', 'FAST_OUT_DIR', 'O', 'A', 'Y', 1, 'SYSTEM', to_date('06-10-2018 14:18:56', 'dd-mm-yyyy hh24:mi:ss'), 'SYSTEM', to_date('06-10-2018 14:18:56', 'dd-mm-yyyy hh24:mi:ss'), 'FTRQ', 'FTTS', '000000036', 'FAST_OUT', '.xml');

prompt Done.
