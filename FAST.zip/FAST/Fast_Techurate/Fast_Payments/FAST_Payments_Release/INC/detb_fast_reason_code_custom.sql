﻿prompt Importing table detb_fast_reason_code_custom...
set feedback off
set define off
insert into detb_fast_reason_code_custom (REASON_CODE, REASON_DESC)
values ('03', 'TRANSACTION FAILURE');

insert into detb_fast_reason_code_custom (REASON_CODE, REASON_DESC)
values ('02', 'INSTRUCTION AMOUNT NOT MATCHED WITH CONTROL AMOUNT');

insert into detb_fast_reason_code_custom (REASON_CODE, REASON_DESC)
values ('01', 'INVALID ACCOUNT');

insert into detb_fast_reason_code_custom (REASON_CODE, REASON_DESC)
values ('00', 'SUCCESS');

insert into detb_fast_reason_code_custom (REASON_CODE, REASON_DESC)
values ('04', 'INVALID BIC CODE');

prompt Done.
