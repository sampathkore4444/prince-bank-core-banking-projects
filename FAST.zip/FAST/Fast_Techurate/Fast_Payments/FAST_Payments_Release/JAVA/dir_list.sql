BEGIN
  DBMS_JAVA.grant_permission('P1FCHPRFM',
    'java.io.FilePermission', '<>', 'read');
  DBMS_JAVA.grant_permission('P1FCHPRFM',
    'SYS:java.lang.RuntimePermission',
    'writeFileDescriptor', '');
  DBMS_JAVA.grant_permission('P1FCHPRFM',
    'SYS:java.lang.RuntimePermission',
    'readFileDescriptor', '');
END;
/
