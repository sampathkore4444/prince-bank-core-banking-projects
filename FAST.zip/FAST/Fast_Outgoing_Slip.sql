SELECT A.TRN_REF_NO       "TRANSACTION_REFERENCE",
       A.BRANCH_CODE      "BRANCH_CODE",
       A.REM_NAME         "DR_ACC_NAME",
       A.REM_ACC          "DR_ACC_NO",
       A.TXN_CCY          "TRANSACTION_CURRENCY",
       A.TXN_AMT          "TRANSACTION_AMOUNT",
       A.TOT_CHG_AMT      "FEE_CHARGE",
       A.NET_TXN_AMT      "TOTAL_TXN_AMOUNT",
       A.EXCH_RATE        "EXCHANGE_RATE",
       A.BEN_NAME         "CR_ACC_NAME",
       A.BEN_ACC          "CR_ACC_NO",
       A.BEN_BIC          "SWIFT/BIC CODE",
       NULL               "BANK_NAME",
       NULL               "BANK_ADDRESS",
       A.MAKER_ID         "MAKER_ID",
       A.CHECKER_ID       "CHECKER_ID",
       A.MAKER_DT_STAMP   "TRN_CREATION_TIME",
       A.CHECKER_DT_STAMP "TRN_AUTH_TIME"
  FROM IFTB_FAST_MASTER A
 WHERE A.TRN_REF_NO = &P_TRN_REF_NO
   AND A.AUTH_STAT = 'A';