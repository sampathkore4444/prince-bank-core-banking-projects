CREATE OR REPLACE PACKAGE BODY ifpks_ifdofast_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : ifpks_ifdofast_custom.sql
  **
  ** Module     : Interfaces
  **
  ** This source is part of the Oracle FLEXCUBE Software Product.
  ** Copyright (R) 2008,2018 , Oracle and/or its affiliates.  All rights reserved
  **
  **
  ** No part of this work may be reproduced, stored in a retrieval system, adopted
  ** or transmitted in any form or by any means, electronic, mechanical,
  ** photographic, graphic, optic recording or otherwise, translated in any
  ** language or computer language, without the prior written permission of
  ** Oracle and/or its affiliates.
  **
  ** Oracle Financial Services Software Limited.
  ** Oracle Park, Off Western Express Highway,
  ** Goregaon (East),
  ** Mumbai - 400 063, India
  ** India
  
  **    Modified By      : KORE SAMPATH KUMAR
  **    Modified Reason  : PRINCE FAST Interface Changes 
  **    Modified On      : 21-June-2018
  **    Search String    : PRINCE 12.4 FAST CUSTOMIZATION CHANGES
  
  
  
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE dbg(p_msg VARCHAR2) IS
    l_msg VARCHAR2(32767);
  BEGIN
    IF debug.pkg_debug_on <> 2 THEN
      l_msg := 'ifpks_ifdofast_Custom ==>' || p_msg;
      debug.pr_debug('IF', l_msg);
    END IF;
  END dbg;

  PROCEDURE pr_log_error(p_function_id IN VARCHAR2,
                         p_source      VARCHAR2,
                         p_err_code    VARCHAR2,
                         p_err_params  VARCHAR2) IS
  BEGIN
    cspks_req_utils.pr_log_error(p_source,
                                 p_function_id,
                                 p_err_code,
                                 p_err_params);
  END pr_log_error;

  PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
  BEGIN
    --DBG('In Pr_Skip_Handler..');
    NULL;
  END pr_skip_handler;

  -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START

  FUNCTION get_param_val(pname VARCHAR2) RETURN VARCHAR2 result_cache relies_on(cstb_param_custom) IS
    retval VARCHAR2(255);
    CURSOR c(pn VARCHAR2) IS
      SELECT param_val FROM cstb_param_custom WHERE param_name = pn;
  BEGIN
    OPEN c(upper(ltrim(rtrim(pname))));
    FETCH c
      INTO retval;
    CLOSE c;
    DBG('retval=' || retval);
    RETURN retval;
  END get_param_val;

  FUNCTION fn_clobreplace(p_clob    CLOB,
                          p_pattern VARCHAR2,
                          p_replace VARCHAR2 := NULL) RETURN CLOB
    DETERMINISTIC IS
    v_lob    CLOB;
    v_len    INTEGER := dbms_lob.getlength(p_clob);
    v_pos    INTEGER;
    v_offset INTEGER := 1;
    v_plen   PLS_INTEGER := length(p_pattern);
    v_rlen   PLS_INTEGER := nvl(length(p_replace), 0);
  BEGIN
    IF nvl(v_len, 0) = 0 OR p_pattern IS NULL THEN
      RETURN p_clob;
    END IF;
  
    dbms_lob.createtemporary(v_lob, TRUE, 2);
    dbms_lob.copy(v_lob, p_clob, v_len);
    LOOP
      v_pos := dbms_lob.instr(lob_loc => v_lob,
                              pattern => p_pattern,
                              offset  => v_offset);
      IF v_pos > 0 THEN
        IF v_len - (v_pos + v_plen) + 1 > 0 THEN
          dbms_lob.copy(v_lob,
                        v_lob,
                        v_len - (v_pos + v_plen) + 1,
                        v_pos + v_rlen,
                        v_pos + v_plen);
        END IF;
        IF v_rlen > 0 THEN
          dbms_lob.write(v_lob, v_rlen, v_pos, p_replace);
        END IF;
        v_offset := v_pos + v_rlen;
        v_len    := v_len - v_plen + v_rlen;
        dbms_lob.trim(v_lob, v_len);
      ELSE
        RETURN v_lob;
      END IF;
    END LOOP;
  END fn_clobreplace;

  FUNCTION fn_process_entries(p_ifdofast  IN OUT ifpks_ifdofast_main.ty_ifdofast,
                              p_action    CHAR,
                              p_errcode   IN OUT VARCHAR2,
                              p_errparams IN OUT VARCHAR2) RETURN BOOLEAN IS
    CURSOR cur_acc IS
      SELECT t.trn_ref_no, t.event_sr_no, t.ac_ccy, t.ac_branch, t.user_id
        FROM actb_daily_log t, iftb_fast_master t1
       WHERE t.trn_ref_no = t1.trn_ref_no
         AND t.trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no
         AND t.event_sr_no = 1
         AND t.auth_stat <> 'A';
    i           NUMBER := 0;
    l_terminate BOOLEAN := FALSE;
  BEGIN
    dbg('In fn_process_entries with ' ||
        p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~~~' || p_action);
    IF p_action NOT IN ('D', 'A') THEN
      dbg('Action code not in Delete or Auth...Return TRUE now');
      RETURN TRUE;
    END IF;
    FOR c1 IN cur_acc LOOP
      i := 0;
      IF acpkss.fn_acservice(c1.ac_branch,
                             global.application_date,
                             global.lcy,
                             c1.trn_ref_no,
                             c1.event_sr_no,
                             p_action,
                             c1.user_id,
                             p_errcode,
                             p_errparams) THEN
        dbg('SUCCESS - ' || c1.trn_ref_no);
      ELSE
        dbg('ERROR - ' || c1.trn_ref_no || SQLERRM);
        dbg('ERROR - ' || p_errcode || '~~~' || p_errparams);
        l_terminate := TRUE;
        dbg('After setting l_terminate to TRUE and leave the LOOP');
        EXIT;
      END IF;
      UPDATE detbs_rtl_teller
         SET auth_stat        = 'A',
             checker_id       = global.user_id,
             checker_dt_stamp = csfn_timestamp,
             record_stat      = decode(record_stat, 'O', 'A', record_stat),
             mod_no           = 1
       WHERE trn_ref_no = c1.trn_ref_no;
    
      i := i + 1;
      dbg('COUNT-->' || i);
    END LOOP;
    IF NOT l_terminate THEN
      dbg('AUTH is fine...Return TRUE now ');
      RETURN TRUE;
    ELSE
      dbg('AUTH is NOT fine...Return FALSE now ');
      RETURN FALSE;
    END IF;
    dbg('Leaving fn_process_entries now....');
  END fn_process_entries;

  FUNCTION fn_gen_out_msg_pay_id(p_ifdofast IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                 p_msgid    OUT VARCHAR2,
                                 p_payid    OUT VARCHAR2,
                                 p_instrid  OUT VARCHAR2) RETURN BOOLEAN IS
    l_bank_code cstm_arc_settle.route_code%TYPE;
    l_seq       NUMBER;
  BEGIN
    dbg('In fn_gen_out_msg_pay_id');
    BEGIN
      SELECT route_code
        INTO l_bank_code
        FROM cstm_arc_settle
       WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code
         AND auth_stat = 'A'
         AND record_stat = 'O';
    EXCEPTION
      WHEN no_data_found THEN
        dbg('query fail with ' || SQLERRM);
        l_bank_code := 'ABAAKHPPXXXX';
        --RETURN FALSE;
    END;
  
    DBG('l_bank_code=' || l_bank_code);
  
    SELECT trsq_msgid.nextval INTO l_seq FROM dual;
    -- msg id
    p_msgid := l_bank_code || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_msgid as ' || p_msgid);
  
    -- pay id
    /*p_payid := l_bank_code || '/' || 'ACLBKHPP' || 'XXXX/' ||
    lpad(TRIM(to_char(l_seq)), 5, '0');*/
  
    p_payid := l_bank_code || '/' ||
               SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 1, 4) ||
               'KHPP' || 'XXXX/' || lpad(TRIM(to_char(l_seq)), 5, '0');
  
    dbg('Returns p_payid as ' || p_payid);
    -- instr id
    p_instrid := l_bank_code || '/' || lpad(TRIM(to_char(l_seq)), 5, '0');
    dbg('Returns p_instrid as ' || p_instrid);
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('bombed with ' || SQLERRM);
      RETURN FALSE;
  END fn_gen_out_msg_pay_id;

  FUNCTION fn_enrich_chg(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_err_code   IN OUT VARCHAR2,
                         p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_tot_chg_amt NUMBER(22, 3);
    l_prod        cstm_product%ROWTYPE;
    l_rate        NUMBER;
  
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_charge_amt   NUMBER := 0;
  
  BEGIN
    dbg('Inside fn_enrich_chg');
  
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;
    
    --Sum of all charges
    FOR each_chg IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
    
      dbg('Inside each_chg~waiver' || each_chg || '~' || p_ifdofast.v_iftbs_fast_charge(each_chg)
          .waiver);
      dbg('l_tot_chg_amt' || l_tot_chg_amt);
      IF p_ifdofast.v_iftbs_fast_charge(each_chg).waiver = 'Y' THEN
        dbg('Waiver is Y');
      
        l_tot_chg_amt := nvl(l_tot_chg_amt, 0) + 0;
      
      ELSE
        dbg('LCY_CHG' || p_ifdofast.v_iftbs_fast_charge(each_chg).lcy_chg);
        l_tot_chg_amt := nvl(l_tot_chg_amt, 0) +
                         nvl(p_ifdofast.v_iftbs_fast_charge(each_chg)
                             .lcy_chg,
                             0);
      END IF;
    
    END LOOP;
  
    dbg('L_TOT_CHG_AMT~P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);
  
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> global.lcy THEN
      IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    global.lcy,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    l_tot_chg_amt,
                                    'Y',
                                    p_ifdofast.v_iftbs_fast_master.tot_chg_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', 'In When Others of EX RATE.');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt;
    END IF;
    dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TOT_CHG_AMT ' ||
        p_ifdofast.v_iftbs_fast_master.tot_chg_amt);
  
    p_ifdofast.v_iftbs_fast_master.net_txn_amt := p_ifdofast.v_iftbs_fast_master.txn_amt +
                                                  p_ifdofast.v_iftbs_fast_master.tot_chg_amt;
  
    dbg('Successfully completed fn_enrich_chg');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('bombed with ' || SQLERRM);
      RETURN FALSE;
  END fn_enrich_chg;

  FUNCTION fn_enrich_product(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                             p_err_code   IN OUT VARCHAR2,
                             p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
    l_serial_no    VARCHAR2(16);
    l_trn_ref_no   iftb_fast_master.trn_ref_no%TYPE;
    l_ty_rtupld    depks_retailtellerupload.typ_retailtellerupld_rec;
    l_ret          BOOLEAN;
    l_tot_chg_amt  NUMBER(22, 3);
    l_rel_customer sttm_customer.customer_no%TYPE;
    l_ac_ccy       sttm_cust_account.ccy%TYPE;
    l_ib_flag      VARCHAR2(1) DEFAULT 'Y';
    l_arc_maint    iftm_arc_maint%ROWTYPE;
    l_prod         cstm_product%ROWTYPE;
    l_rate         NUMBER;
    l_charge_amt   NUMBER := 0;
    l_rate_flag    NUMBER;
    l_ccy1         iftb_fast_master.txn_ccy%TYPE;
    l_ccy2         iftb_fast_master.txn_ccy%TYPE;
  
    l_tot_chg_amount            iftb_fast_master.net_txn_amt%TYPE;
    l_txn_amt                   iftb_fast_master.txn_amt%TYPE;
    l_txn_amt1                  iftb_fast_master.txn_amt%TYPE;
    l_rate_code                 cstm_product.rate_code_preferred%Type;
    l_rate_code1                cstm_product.rate_code_preferred%Type;
    l_tot_chg_amt_in_txn_ccy    iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amt_in_lcy_ccy    iftb_fast_master.txn_amt%TYPE;
    l_arc_rate_code_type        iftm_arc_maint.cod_rate_code%Type;
    l_tot_chg_amount_in_txn_ccy iftb_fast_master.txn_amt%TYPE;
    l_tot_chg_amount_in_acc_ccy iftb_fast_master.txn_amt%TYPE;
  
  BEGIN
  
    dbg('In FN_ENRICH_PRODUCT');
    --dbg('p_Action_Code' || p_action_code);
  
    -- mandatory check
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      IF p_ifdofast.v_iftbs_fast_master.product_code IS NULL THEN
        dbg('Mandatory Field Product Code cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Product Code';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy IS NULL THEN
        dbg('Mandatory Fields Transaction Currency cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Currency';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.txn_amt IS NULL THEN
        dbg('Mandatory Fields Transaction Amount cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Transaction Amount';
        RETURN FALSE;
      END IF;
      IF p_ifdofast.v_iftbs_fast_master.rem_acc IS NULL THEN
        dbg('Mandatory Fields Remitter Account cannot be null');
        p_err_code   := 'DV-DVRT-01';
        p_err_params := 'Remitter Account';
        RETURN FALSE;
      END IF;
    END IF;
  
    -- reference no
    IF p_ifdofast.v_iftbs_fast_master.trn_ref_no IS NULL THEN
      IF NOT trpkss.fn_get_product_refno(p_ifdofast.v_iftbs_fast_master.branch_code,
                                         p_ifdofast.v_iftbs_fast_master.product_code,
                                         p_ifdofast.v_iftbs_fast_master.transfer_date,
                                         l_serial_no,
                                         l_trn_ref_no,
                                         p_err_code) THEN
        dbg('Failed in generation Transaction Ref No');
        RETURN FALSE;
      ELSE
        dbg('l_trn_ref_no=' || l_trn_ref_no);
        p_ifdofast.v_iftbs_fast_master.trn_ref_no := l_trn_ref_no;
      
      END IF;
    END IF;
  
    -- charge pickup
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      SELECT cust_no, ccy
        INTO l_rel_customer, l_ac_ccy
        FROM sttm_cust_account
       WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;
    ELSE
      BEGIN
        SELECT cust_no, ccy
          INTO l_rel_customer, l_ac_ccy
          FROM sttm_cust_account
         WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Invalid Ben Account for Incoming Txn');
          pr_log_error('IFDOFAST',
                       p_ifdofast.v_iftbs_fast_master.source_code,
                       'IF-FST017',
                       NULL);
      END;
    END IF;
  
    dbg('got l_rel_customer' || l_rel_customer);
  
    IF NOT
        cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    p_ifdofast.v_iftbs_fast_master.product_code,
                                    'P',
                                    p_ifdofast.v_iftbs_fast_master.product_code,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_rel_customer,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    p_ifdofast.v_iftbs_fast_master.txn_amt,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    NULL,
                                    l_rel_customer,
                                    l_ib_flag,
                                    l_arc_maint,
                                    p_err_code,
                                    p_err_params,
                                    p_ifdofast.v_iftbs_fast_master.rem_acc,
                                    p_ifdofast.v_iftbs_fast_master.branch_code) THEN
      dbg('CHARGE PICKUP failed');
      RETURN FALSE;
    END IF;
  
    DBG('l_arc_maint.cod_chg_amt =' || l_arc_maint.cod_chg_amt);
  
    --Charge1
    IF l_arc_maint.cod_chg_amt IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(1).chg_srno := 1;
      p_ifdofast.v_iftbs_fast_charge(1).chg_desc := l_arc_maint.cod_chg_desc;
      p_ifdofast.v_iftbs_fast_charge(1).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(1).chg_amt := l_arc_maint.cod_chg_amt;
      p_ifdofast.v_iftbs_fast_charge(1).chg_ccy := l_arc_maint.cod_chg_ccy;
    
      DBG('p_ifdofast.v_iftbs_fast_charge(1).trn_ref_no=' || p_ifdofast.v_iftbs_fast_charge(1)
          .trn_ref_no);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_srno=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_srno);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_desc=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_desc);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).waiver=' || p_ifdofast.v_iftbs_fast_charge(1)
          .waiver);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_amt=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_amt);
      DBG('p_ifdofast.v_iftbs_fast_charge(1).chg_ccy=' || p_ifdofast.v_iftbs_fast_charge(1)
          .chg_ccy);
    
      DBG('p_ifdofast.v_iftbs_fast_charge.count=' ||
          p_ifdofast.v_iftbs_fast_charge.count);
    
      DBG('global.lcy=' || global.lcy);
      DBG('l_arc_maint.cod_chg_ccy=' || l_arc_maint.cod_chg_ccy);
    
      -- Converting charge into local ccy for display in charge tab
      IF l_arc_maint.cod_chg_ccy <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).lcy_chg := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).xrate := 1;
      END IF;
      dbg('Amount 1 in Local ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
          .lcy_chg);
    
      -- Converting charge into txn ccy 
      IF l_arc_maint.cod_chg_ccy <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := l_rate;
        dbg(' * Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_txn := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).txn_xrate := 1;
        dbg('** Amount 1 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_txn);
      END IF;
    
      -- Converting charge into acc ccy       
      IF l_arc_maint.cod_chg_ccy <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy,
                                      l_ac_ccy,
                                      l_prod.rate_type_preferred,
                                      NVL(l_arc_maint.cod_rate_code_Type, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                      l_arc_maint.cod_chg_amt,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := l_rate;
        dbg('* Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(1).chg_in_acc := l_arc_maint.cod_chg_amt;
        p_ifdofast.v_iftbs_fast_charge(1).acc_xrate := 1;
        dbg('** Amount 1 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(1)
            .chg_in_acc);
      END IF;
    END IF;
  
    --Charge2
    IF l_arc_maint.cod_chg_amt1 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(2).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(2).chg_srno := 2;
      p_ifdofast.v_iftbs_fast_charge(2).chg_desc := l_arc_maint.cod_chg_desc1;
      p_ifdofast.v_iftbs_fast_charge(2).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(2).chg_amt := l_arc_maint.cod_chg_amt1;
      p_ifdofast.v_iftbs_fast_charge(2).chg_ccy := l_arc_maint.cod_chg_ccy1;
    
      IF l_arc_maint.cod_chg_ccy1 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy1,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt1,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).lcy_chg := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy 
      IF l_arc_maint.cod_chg_ccy1 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := l_rate;
        dbg('* Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_txn := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).txn_xrate := 1;
        dbg('** Amount 2 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_txn);
      END IF;
    
      -- Converting charge into acc ccy       
      IF l_arc_maint.cod_chg_ccy1 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy1,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type1, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt1,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := l_rate;
        dbg('* Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(2).chg_in_acc := l_arc_maint.cod_chg_amt1;
        p_ifdofast.v_iftbs_fast_charge(2).acc_xrate := 1;
        dbg('** Amount 2 in acc ccy->' || p_ifdofast.v_iftbs_fast_charge(2)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(2).oth_ccy := l_arc_maint.cod_chg_ccy1;
    
    END IF;
  
    --Charge3
    IF l_arc_maint.cod_chg_amt2 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(3).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(3).chg_srno := 3;
      p_ifdofast.v_iftbs_fast_charge(3).chg_desc := l_arc_maint.cod_chg_desc2;
      p_ifdofast.v_iftbs_fast_charge(3).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(3).chg_amt := l_arc_maint.cod_chg_amt2;
      p_ifdofast.v_iftbs_fast_charge(3).chg_ccy := l_arc_maint.cod_chg_ccy2;
    
      IF l_arc_maint.cod_chg_ccy2 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy2,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt2,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).lcy_chg := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy 
      IF l_arc_maint.cod_chg_ccy2 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := l_rate;
        dbg('* Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_txn := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).txn_xrate := 1;
        dbg('** Amount 3 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_txn);
      END IF;
    
      -- Converting charge into acc ccy       
      IF l_arc_maint.cod_chg_ccy2 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy2,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type2, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt2,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := l_rate;
        dbg('* Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(3).chg_in_acc := l_arc_maint.cod_chg_amt2;
        p_ifdofast.v_iftbs_fast_charge(3).acc_xrate := 1;
        dbg('** Amount 3 in ACC ccy->' || p_ifdofast.v_iftbs_fast_charge(3)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(3).oth_ccy := l_arc_maint.cod_chg_ccy2;
    END IF;
  
    --Charge4
    IF l_arc_maint.cod_chg_amt3 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(4).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(4).chg_srno := 4;
      p_ifdofast.v_iftbs_fast_charge(4).chg_desc := l_arc_maint.cod_chg_desc3;
      p_ifdofast.v_iftbs_fast_charge(4).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(4).chg_amt := l_arc_maint.cod_chg_amt3;
      p_ifdofast.v_iftbs_fast_charge(4).chg_ccy := l_arc_maint.cod_chg_ccy3;
    
      IF l_arc_maint.cod_chg_ccy3 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy3,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt3,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).lcy_chg := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy 
      IF l_arc_maint.cod_chg_ccy3 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy3,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type3, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt3,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := l_rate;
        dbg('* Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_txn := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).txn_xrate := 1;
        dbg('** Amount 4 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_txn);
      END IF;
    
      -- Converting charge into acc ccy       
      IF l_arc_maint.cod_chg_ccy3 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy3,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type3, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt3,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := l_rate;
        dbg('* Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(4).chg_in_acc := l_arc_maint.cod_chg_amt3;
        p_ifdofast.v_iftbs_fast_charge(4).acc_xrate := 1;
        dbg('** Amount 4 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(4)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(4).oth_ccy := l_arc_maint.cod_chg_ccy3;
    
    END IF;
  
    --Charge5
    IF l_arc_maint.cod_chg_amt4 IS NOT NULL THEN
      p_ifdofast.v_iftbs_fast_charge(5).trn_ref_no := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      p_ifdofast.v_iftbs_fast_charge(5).chg_srno := 5;
      p_ifdofast.v_iftbs_fast_charge(5).chg_desc := l_arc_maint.cod_chg_desc4;
      p_ifdofast.v_iftbs_fast_charge(5).waiver := 'N';
      p_ifdofast.v_iftbs_fast_charge(5).chg_amt := l_arc_maint.cod_chg_amt4;
      p_ifdofast.v_iftbs_fast_charge(5).chg_ccy := l_arc_maint.cod_chg_ccy4;
    
      IF l_arc_maint.cod_chg_ccy4 <> global.lcy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      l_arc_maint.cod_chg_ccy4,
                                      global.lcy,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      l_arc_maint.cod_chg_amt4,
                                      'Y',
                                      l_charge_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).xrate := l_rate;
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).lcy_chg := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).xrate := 1;
      END IF;
    
      -- Converting charge into txn ccy 
      IF l_arc_maint.cod_chg_ccy4 <> p_ifdofast.v_iftbs_fast_master.txn_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy4,
                                   p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type4, 'M'), -- l_prod.rate_code_preferred, -- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt4,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := l_rate;
        dbg('* Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_txn);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_txn := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).txn_xrate := 1;
        dbg('** Amount 5 in TXN ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_txn);
      END IF;
    
      -- Converting charge into acc ccy       
      IF l_arc_maint.cod_chg_ccy4 <> l_ac_ccy THEN
        l_rate       := NULL;
        l_charge_amt := NULL;
        IF NOT
            cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                   l_arc_maint.cod_chg_ccy4,
                                   l_ac_ccy,
                                   l_prod.rate_type_preferred,
                                   NVL(l_arc_maint.cod_rate_code_Type4, 'M'), -- l_prod.rate_code_preferred,-- Rate code should be taken as calculated at kernel level
                                   l_arc_maint.cod_chg_amt4,
                                   'Y',
                                   l_charge_amt,
                                   l_rate,
                                   p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
        dbg('mj ...converted charge1-->' || l_charge_amt);
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_charge_amt;
        p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := l_rate;
        dbg('* Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_acc);
      ELSE
        p_ifdofast.v_iftbs_fast_charge(5).chg_in_acc := l_arc_maint.cod_chg_amt4;
        p_ifdofast.v_iftbs_fast_charge(5).acc_xrate := 1;
        dbg('** Amount 5 in OTH ccy->' || p_ifdofast.v_iftbs_fast_charge(5)
            .chg_in_acc);
      END IF;
      p_ifdofast.v_iftbs_fast_charge(5).oth_ccy := l_arc_maint.cod_chg_ccy4;
    
    END IF;
  
    dbg('Done all charges calculation');
  
    -- Total Charge amount in transaction currency
    FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
    
      l_tot_chg_amt_in_txn_ccy := nvl(l_tot_chg_amt_in_txn_ccy, 0) +
                                  nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                      .chg_in_txn,
                                      0);
    
    END LOOP;
    dbg('L_TOT_CHG_AMT~P_IFDOFAST.v_iftbs_pgw_master_custom.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);
  
    dbg('Total charge to be paid in TXN CCY ->' ||
        l_tot_chg_amt_in_txn_ccy);
    p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt_in_txn_ccy; -- We are displaying total charge in txn amount only --Tuning of code in charge calculation
  
    -- Total Charge amount in local and remitter/account ccy
    FOR J IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      dbg('1 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy ||
          'p_ifdofast.v_iftbs_fast_charge(j).lcy_chg' || p_ifdofast.v_iftbs_fast_charge(j)
          .lcy_chg);
      dbg('1 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy ||
          'p_ifdofast.v_iftbs_fast_charge(j).chg_in_acc' || p_ifdofast.v_iftbs_fast_charge(j)
          .chg_in_acc);
      l_tot_chg_amt_in_lcy_ccy    := nvl(l_tot_chg_amt_in_lcy_ccy, 0) +
                                     nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                         .lcy_chg,
                                         0);
      l_tot_chg_amount_in_acc_ccy := nvl(l_tot_chg_amount_in_acc_ccy, 0) +
                                     nvl(p_ifdofast.v_iftbs_fast_charge(j)
                                         .chg_in_acc,
                                         0);
    
      dbg('2 l_tot_chg_amt_in_lcy_ccy->' || l_tot_chg_amt_in_lcy_ccy);
      dbg('2 l_tot_chg_amount_in_acc_ccy->' || l_tot_chg_amount_in_acc_ccy);
    End Loop;
  
    dbg('chgs calculated ->');
  
    If l_prod.rate_code_preferred = 'B' and
       p_ifdofast.v_iftbs_fast_master.transfer_mode in ('F') Then
      l_rate_code := Null;
      If (p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy and
         l_ac_ccy != global.lcy) OR
         (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy) Then
        l_rate_code := 'B';
      
      Else
        l_rate_code := l_prod.rate_code_preferred;
      End If;
    Else
      l_rate_code := l_prod.rate_code_preferred;
    End If;
    dbg('p_ifdofast.v_iftbs_pgw_master_custom.txn_amt->' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);
  
    dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
  
    If l_ac_ccy <> global.lcy Then
      begin
        select decode(l_rate_code,
                      'B',
                      'S',
                      'S',
                      'B',
                      'M',
                      'M',
                      l_rate_code)
          Into l_rate_code1
          from dual;
      exception
        when others then
          dbg('Exception found l_rate_code-> ' || l_rate_code);
      end;
    End If;
    dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
        l_rate_code1);
    dbg('l_txn_amt l_txn_amt l_txn_amt='||l_txn_amt);
    -- Total Txn amount in remitter currency
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN
      l_rate := NULL;
      --l_charge_amt := NULL;
      l_txn_amt1 := p_ifdofast.v_iftbs_fast_master.txn_amt;
      /*IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_ac_ccy,
                                    l_prod.rate_type_preferred,
                                    nvl(l_rate_code1, l_rate_code),
                                    l_txn_amt1,
                                    'Y',
                                    l_txn_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', '');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;*/
      
     IF NOT cypkss.FN_AMT1_TO_AMT2(p_ifdofast.v_iftbs_fast_master.txn_ccy,
                           l_ac_ccy,
                           l_txn_amt1,
                           ,
                           'Y',
                           l_txn_amt,
                           p_err_params) THEN
           RETURN FALSE;                
         END IF;                  
    END IF;
    dbg('Final txn_amt->' || l_txn_amt || 'Final chg_amount->' ||
        l_tot_chg_amount);
    dbg('Total Charges in local ccy->' || l_tot_chg_amt_in_lcy_ccy);
    dbg('Total Charges in txn ccy->' || l_tot_chg_amount_in_txn_ccy);
    dbg('Total Charges in acc ccy->' || l_tot_chg_amount_in_acc_ccy);
  
    -- Net DB Amount (Charges + Txn amount)  
    If p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy Then
      dbg('apple');
      p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(l_txn_amt, 0) +
                                                    (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                         0));
    
    Elsif p_ifdofast.v_iftbs_fast_master.txn_ccy = l_ac_ccy Then
      dbg('mango');
      p_ifdofast.v_iftbs_fast_master.net_txn_amt := nvl(p_ifdofast.v_iftbs_fast_master.txn_amt,
                                                        0) +
                                                    (Nvl(l_tot_chg_amount_in_acc_ccy,
                                                         0));
    
    End If;
    dbg('p_ifdofast.v_iftbs_fast_master.net_txn_amt->' ||
        p_ifdofast.v_iftbs_fast_master.net_txn_amt);
  
    -- xrate
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN
    
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy THEN
        l_ccy1 := l_ac_ccy;
        l_ccy2 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      ELSE
        l_ccy1 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
        l_ccy2 := l_ac_ccy;
      END IF;
      dbg('l_rate_code->' || l_rate_code || 'l_prod.rate_type_preferred' ||
          l_prod.rate_type_preferred);
      dbg('Before p_ifdofast.v_iftbs_pgw_master_custom.exch_rate->' ||
          p_ifdofast.v_iftbs_fast_master.exch_rate);
    
      If (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
         l_ac_ccy <> global.lcy and
         p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy) and
         l_prod.rate_code_preferred = 'B' Then
        l_rate_code := 'S';
      End If;
    
      dbg('l_rate_code->' || l_rate_code);
      
      dbg('l_prod.rate_type_preferred='||l_prod.rate_type_preferred);
    
      IF NOT cypkss.fn_getrate(p_ifdofast.v_iftbs_fast_master.branch_code,
                               l_ccy2,
                               l_ccy1, --L_AC_CCY,--l_ccy2, --L_AC_CCY,                                                                         
                               l_prod.rate_type_preferred,
                               l_rate_code, --l_prod.rate_code_preferred, 
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.exch_rate,
                               l_rate_flag,
                               p_err_code) THEN
        dbg('Failed in Fn_GetRate');
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.exch_rate := 1;
    END IF;
    
    DBG('p_ifdofast.v_iftbs_fast_master.exch_rate=='||p_ifdofast.v_iftbs_fast_master.exch_rate);
  
    /*FOR j IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      dbg('P_IFDOFAST.V_IFTBS_FAST_CHARGE(J).LCY_CHG' || p_ifdofast.v_iftbs_fast_charge(j)
          .lcy_chg);
      l_tot_chg_amt := nvl(l_tot_chg_amt, 0) +
                       nvl(p_ifdofast.v_iftbs_fast_charge(j).lcy_chg, 0);
    END LOOP;
    
    dbg('L_TOT_CHG_AMT~P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY~GLOBAL.LCY' ||
        l_tot_chg_amt || '~' || p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        global.lcy);
    
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> global.lcy THEN
      IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                    global.lcy,
                                    p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                    l_prod.rate_type_preferred,
                                    l_prod.rate_code_preferred,
                                    l_tot_chg_amt,
                                    'Y',
                                    p_ifdofast.v_iftbs_fast_master.tot_chg_amt,
                                    l_rate,
                                    p_err_params) THEN
        debug.pr_debug('**', 'In When Others of EX RATE.');
        debug.pr_debug('**', SQLERRM);
        p_err_code   := 'ST-OTHR-001';
        p_err_params := NULL;
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.tot_chg_amt := l_tot_chg_amt;
    END IF;
    dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TOT_CHG_AMT ' ||
        p_ifdofast.v_iftbs_fast_master.tot_chg_amt);
    
    p_ifdofast.v_iftbs_fast_master.net_txn_amt := p_ifdofast.v_iftbs_fast_master.txn_amt +
                                                  p_ifdofast.v_iftbs_fast_master.tot_chg_amt;
    
    -- xrate
    IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_ac_ccy THEN
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy THEN
        l_ccy1 := l_ac_ccy;
        l_ccy2 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      ELSE
        l_ccy1 := p_ifdofast.v_iftbs_fast_master.txn_ccy;
        l_ccy2 := l_ac_ccy;
      END IF;
      IF NOT cypkss.fn_getrate(p_ifdofast.v_iftbs_fast_master.branch_code,
                               l_ccy1, --P_IFDOFAST.V_IFTBS_FAST_MASTER.TXN_CCY,
                               l_ccy2, --L_AC_CCY,
                               l_prod.rate_type_preferred,
                               l_prod.rate_code_preferred,
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.transfer_date,
                               p_ifdofast.v_iftbs_fast_master.exch_rate,
                               l_rate_flag,
                               p_err_code) THEN
        dbg('Failed in Fn_GetRate');
        RETURN FALSE;
      END IF;
    ELSE
      p_ifdofast.v_iftbs_fast_master.exch_rate := 1;
    END IF;*/
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      SELECT address1, address2, address3, address4
        INTO p_ifdofast.v_iftbs_fast_master.rem_add1,
             p_ifdofast.v_iftbs_fast_master.rem_add2,
             p_ifdofast.v_iftbs_fast_master.rem_add3,
             p_ifdofast.v_iftbs_fast_master.rem_add4
        FROM sttm_cust_account
       WHERE cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;
    END IF;
  
    dbg('Returning Success From FN_ENRICH_PRODUCT..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_ENRICH_PRODUCT ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_enrich_product;

  FUNCTION fn_save(p_ifdofast              IN OUT ifpks_ifdofast_main.ty_ifdofast,
                   pkg_detb_rtl_teller_rec IN OUT detbs_rtl_teller%ROWTYPE,
                   p_err_code              IN OUT VARCHAR2,
                   p_err_params            IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_cust_ac    sttm_cust_account%ROWTYPE;
    l_arc_maint  iftms_arc_maint%ROWTYPE;
    l_cust       sttm_customer%ROWTYPE;
    l_prod       cstm_product%ROWTYPE;
    l_ib_flag    VARCHAR2(1) DEFAULT 'Y';
    l_txn_amt    iftbs_fast_master.txn_amt%TYPE;
    l_txn_amt1   iftbs_fast_master.txn_amt%TYPE;
    l_rate       NUMBER;
    l_rate_code  cstm_product.rate_code_preferred%Type;
    l_rate_code1 cstm_product.rate_code_preferred%Type;
  
  BEGIN
    dbg('In FN_SAVE');
  
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
    
      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdofast.v_iftbs_fast_master.rem_acc;
    
      -- msg id
      IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN
        IF NOT
            fn_gen_out_msg_pay_id(p_ifdofast,
                                  p_ifdofast.v_iftbs_fast_master.msg_id,
                                  p_ifdofast.v_iftbs_fast_master.pay_id,
                                  p_ifdofast.v_iftbs_fast_master.instr_id) THEN
          dbg('Failed in generation Msg id');
          RETURN FALSE;
        END IF;
      
        -- end to end id
        p_ifdofast.v_iftbs_fast_master.etend_id := p_ifdofast.v_iftbs_fast_master.rem_acc || '-' ||
                                                   p_ifdofast.v_iftbs_fast_master.ben_acc;
      
      END IF;
    ELSE
    
      SELECT x.*
        INTO l_cust_ac
        FROM sttm_cust_account x
       WHERE x.cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;
    
    END IF;
  
    SELECT x.*
      INTO l_cust
      FROM sttm_customer x
     WHERE x.customer_no = l_cust_ac.cust_no;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      cspkss_arc.pr_get_arc_row(p_ifdofast.v_iftbs_fast_master.branch_code,
                                p_ifdofast.v_iftbs_fast_master.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdofast.v_iftbs_fast_master.rem_acc,
                                p_ifdofast.v_iftbs_fast_master.branch_code);
    ELSE
      cspkss_arc.pr_get_arc_row(p_ifdofast.v_iftbs_fast_master.branch_code,
                                p_ifdofast.v_iftbs_fast_master.product_code,
                                'P',
                                '*.*', -- trans_type
                                p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                l_ib_flag,
                                l_arc_maint,
                                p_err_code,
                                p_err_params,
                                p_ifdofast.v_iftbs_fast_master.ben_acc,
                                p_ifdofast.v_iftbs_fast_master.branch_code);
    END IF;
  
    IF p_err_code IS NOT NULL THEN
      dbg('CSPKSS_ARC.PR_GET_ARC_ROW returned false');
      RETURN FALSE;
    END IF;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      'P',
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdofast.v_iftbs_fast_master.rem_acc,
                                      p_ifdofast.v_iftbs_fast_master.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    ELSE
      IF NOT
          cspkss_arc.fn_charge_pickup(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      'P',
                                      p_ifdofast.v_iftbs_fast_master.product_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.cust_no,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      NULL,
                                      l_cust_ac.cust_no,
                                      l_ib_flag,
                                      depks_rtl_teller.pkg_arc_row,
                                      p_err_code,
                                      p_err_params,
                                      p_ifdofast.v_iftbs_fast_master.ben_acc,
                                      p_ifdofast.v_iftbs_fast_master.branch_code) THEN
        dbg('CHARGE PICKUP failed');
        RETURN FALSE;
      END IF;
    END IF;
  
    pkg_detb_rtl_teller_rec.xref         := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
    pkg_detb_rtl_teller_rec.product_code := p_ifdofast.v_iftbs_fast_master.product_code;
    pkg_detb_rtl_teller_rec.branch_code  := p_ifdofast.v_iftbs_fast_master.branch_code;
    pkg_detb_rtl_teller_rec.trn_ref_no   := p_ifdofast.v_iftbs_fast_master.trn_ref_no;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      pkg_detb_rtl_teller_rec.txn_acc := p_ifdofast.v_iftbs_fast_master.rem_acc;
      pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
      --pkg_detb_rtl_teller_rec.txn_branch := p_ifdofast.v_iftbs_fast_master.branch_code;
      pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;
    
      pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
      pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      pkg_detb_rtl_teller_rec.ofs_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      /* pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                      '*.*',
                                                      p_ifdofast.v_iftbs_fast_master.branch_code);
      */
      --Get Nostro Account Branch for the offset leg
      BEGIN
        SELECT BRANCH_CODE
          INTO pkg_detb_rtl_teller_rec.ofs_branch
          FROM STTM_CUST_ACCOUNT
         WHERE CUST_AC_NO = pkg_detb_rtl_teller_rec.ofs_acc;
      EXCEPTION
        WHEN OTHERS THEN
          pkg_detb_rtl_teller_rec.ofs_branch := '991';
      END;
      -- Begin ACCOUNTING ENTRIES Display and fix for Wrong Exch calculation
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_cust_ac.ccy THEN
        l_rate     := NULL;
        l_txn_amt1 := p_ifdofast.v_iftbs_fast_master.txn_amt;
      
        If l_prod.rate_code_preferred = 'B' and
           p_ifdofast.v_iftbs_fast_master.transfer_mode in ('F') Then
          l_rate_code := Null;
          If (p_ifdofast.v_iftbs_fast_master.txn_ccy = global.lcy and
             l_cust_ac.ccy != global.lcy) Or
             (p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
             l_cust_ac.ccy <> global.lcy and
             p_ifdofast.v_iftbs_fast_master.txn_ccy <> l_cust_ac.ccy) Then
            l_rate_code := 'B';
          Elsif p_ifdofast.v_iftbs_fast_master.txn_ccy != global.lcy and
                l_cust_ac.ccy = global.lcy and
                p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' Then
            l_rate_code := 'S';
          Else
            l_rate_code := l_prod.rate_code_preferred;
          End If;
        Else
          l_rate_code := l_prod.rate_code_preferred;
        End If;
      
        dbg(' Before l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);
        If l_cust_ac.ccy <> global.lcy Then
          begin
            select decode(l_rate_code,
                          'B',
                          'S',
                          'S',
                          'B',
                          'M',
                          'M',
                          l_rate_code)
              Into l_rate_code1
              from dual;
          exception
            when others then
              dbg('Exception found l_rate_code-> ' || l_rate_code);
          end;
        End If;
        dbg(' after l_rate_code->' || l_rate_code || 'l_rate_code1' ||
            l_rate_code1);
      
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      l_cust_ac.ccy,
                                      l_prod.rate_type_preferred,
                                      nvl(l_rate_code1, l_rate_code),
                                      l_txn_amt1,
                                      'Y',
                                      l_txn_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', '');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
      END IF;
      dbg('l_txn_amt1->' || l_txn_amt1);
      pkg_detb_rtl_teller_rec.txn_amount := l_txn_amt;
      -- END 
    
    ELSE
      pkg_detb_rtl_teller_rec.txn_acc := p_ifdofast.v_iftbs_fast_master.ben_acc;
      pkg_detb_rtl_teller_rec.txn_ccy := l_cust_ac.ccy;
      --pkg_detb_rtl_teller_rec.txn_branch := p_ifdofast.v_iftbs_fast_master.branch_code;
      pkg_detb_rtl_teller_rec.txn_branch := l_cust_ac.branch_code;
    
      pkg_detb_rtl_teller_rec.ofs_acc    := l_arc_maint.cod_offset_acc;
      pkg_detb_rtl_teller_rec.ofs_ccy    := p_ifdofast.v_iftbs_fast_master.txn_ccy;
      pkg_detb_rtl_teller_rec.ofs_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      pkg_detb_rtl_teller_rec.txn_amount := p_ifdofast.v_iftbs_fast_master.txn_amt;
      pkg_detb_rtl_teller_rec.ofs_branch := REPLACE(l_arc_maint.cod_offset_brn,
                                                    '*.*',
                                                    p_ifdofast.v_iftbs_fast_master.branch_code);
    END IF;
    pkg_detb_rtl_teller_rec.txn_trn_code     := l_arc_maint.cod_main_txn_code;
    pkg_detb_rtl_teller_rec.ofs_trn_code     := l_arc_maint.cod_offset_txn_code;
    pkg_detb_rtl_teller_rec.exch_rate        := p_ifdofast.v_iftbs_fast_master.exch_rate;
    pkg_detb_rtl_teller_rec.trn_dt           := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.value_dt         := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.rel_customer     := l_cust_ac.cust_no;
    pkg_detb_rtl_teller_rec.benef_name       := l_cust.customer_name1;
    pkg_detb_rtl_teller_rec.benef_addr1      := l_cust.address_line1;
    pkg_detb_rtl_teller_rec.benef_addr2      := l_cust.address_line2;
    pkg_detb_rtl_teller_rec.benef_addr3      := l_cust.address_line3;
    pkg_detb_rtl_teller_rec.benef_addr4      := l_cust.address_line4;
    pkg_detb_rtl_teller_rec.liqn_dt          := p_ifdofast.v_iftbs_fast_master.transfer_date;
    pkg_detb_rtl_teller_rec.record_stat      := 'A';
    pkg_detb_rtl_teller_rec.auth_stat        := 'U';
    pkg_detb_rtl_teller_rec.maker_id         := p_ifdofast.v_iftbs_fast_master.maker_id;
    pkg_detb_rtl_teller_rec.maker_dt_stamp   := p_ifdofast.v_iftbs_fast_master.maker_dt_stamp;
    pkg_detb_rtl_teller_rec.checker_id       := p_ifdofast.v_iftbs_fast_master.checker_id;
    pkg_detb_rtl_teller_rec.checker_dt_stamp := p_ifdofast.v_iftbs_fast_master.checker_dt_stamp;
    pkg_detb_rtl_teller_rec.mod_no           := p_ifdofast.v_iftbs_fast_master.mod_no;
    pkg_detb_rtl_teller_rec.scode            := p_ifdofast.v_iftbs_fast_master.source_code;
    pkg_detb_rtl_teller_rec.dr_acc           := l_arc_maint.dr_acc;
    pkg_detb_rtl_teller_rec.module           := 'RT';
    pkg_detb_rtl_teller_rec.esn              := 1;
    pkg_detb_rtl_teller_rec.event_code       := 'INIT';
    pkg_detb_rtl_teller_rec.track_receivable := 'N';
    pkg_detb_rtl_teller_rec.time_received    := SYSDATE;
  
    -- 1
    FOR k IN 1 .. p_ifdofast.v_iftbs_fast_charge.count LOOP
      IF k = 1 THEN
        dbg('CHG AMT' || p_ifdofast.v_iftbs_fast_charge(k).chg_amt);
        IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
          pkg_detb_rtl_teller_rec.charge_account := p_ifdofast.v_iftbs_fast_master.rem_acc;
        ELSE
          pkg_detb_rtl_teller_rec.charge_account := p_ifdofast.v_iftbs_fast_master.ben_acc;
        END IF;
        pkg_detb_rtl_teller_rec.chg_gl           := l_arc_maint.cod_chg_gl;
        pkg_detb_rtl_teller_rec.chg_ccy          := l_arc_maint.cod_chg_ccy;
        pkg_detb_rtl_teller_rec.chg_amt          := p_ifdofast.v_iftbs_fast_charge(k)
                                                    .chg_amt;
        depks_rtl_teller.pkg_arc_row.cod_chg_amt := p_ifdofast.v_iftbs_fast_charge(k)
                                                    .chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt);
        depks_rtl_teller.pkg_arc_row.cod_chg_type := l_arc_maint.cod_chg_type;
        IF l_arc_maint.cod_chg_ccy <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy       := p_ifdofast.v_iftbs_fast_charge(k)
                                                      .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate := 1;
        END IF;
        
        DBG('pkg_detb_rtl_teller_rec.chg_ccy_acy_rate='||pkg_detb_rtl_teller_rec.chg_ccy_acy_rate);
      
        pkg_detb_rtl_teller_rec.chg_in_lcy   := p_ifdofast.v_iftbs_fast_charge(k)
                                                .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind  := l_arc_maint.cod_chg_netting;
        pkg_detb_rtl_teller_rec.txn_code     := l_arc_maint.cod_chg_txn_code;
        pkg_detb_rtl_teller_rec.mis_head_1   := l_arc_maint.cod_mis_head;
        pkg_detb_rtl_teller_rec.chg_desc     := l_arc_maint.cod_chg_desc;
        pkg_detb_rtl_teller_rec.chg_type     := l_arc_maint.cod_chg_type;
        pkg_detb_rtl_teller_rec.waiver       := p_ifdofast.v_iftbs_fast_charge(k)
                                                .waiver;
        pkg_detb_rtl_teller_rec.their_chgs   := l_arc_maint.cod_their_chgs;
      END IF;
      -- 2
      IF k = 2 THEN
        pkg_detb_rtl_teller_rec.chg_gl_1  := l_arc_maint.cod_chg_gl1;
        pkg_detb_rtl_teller_rec.chg_ccy_1 := l_arc_maint.cod_chg_ccy1;
        pkg_detb_rtl_teller_rec.chg_amt_1 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt1 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT1' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt1);
        depks_rtl_teller.pkg_arc_row.cod_chg_type1 := l_arc_maint.cod_chg_type1;
      
        IF l_arc_maint.cod_chg_ccy1 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy1,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_1,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_1       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_1 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_1   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_1 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_1  := l_arc_maint.cod_chg_netting1;
        pkg_detb_rtl_teller_rec.txn_code_1     := l_arc_maint.cod_chg_txn_code1;
        pkg_detb_rtl_teller_rec.mis_head_2     := l_arc_maint.cod_mis_head1;
        pkg_detb_rtl_teller_rec.chg_desc1      := l_arc_maint.cod_chg_desc1;
        pkg_detb_rtl_teller_rec.chg_type1      := l_arc_maint.cod_chg_type1;
        pkg_detb_rtl_teller_rec.waiver1        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs1    := l_arc_maint.cod_their_chgs1;
      END IF;
      -- 3
      IF k = 3 THEN
        pkg_detb_rtl_teller_rec.chg_gl_2  := l_arc_maint.cod_chg_gl2;
        pkg_detb_rtl_teller_rec.chg_ccy_2 := l_arc_maint.cod_chg_ccy2;
        pkg_detb_rtl_teller_rec.chg_amt_2 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt2 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT2' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt2);
        depks_rtl_teller.pkg_arc_row.cod_chg_type2 := l_arc_maint.cod_chg_type2;
      
        IF l_arc_maint.cod_chg_ccy2 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy2,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_2,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_2       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_2 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_2   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_2 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_2  := l_arc_maint.cod_chg_netting2;
        pkg_detb_rtl_teller_rec.txn_code_2     := l_arc_maint.cod_chg_txn_code2;
        pkg_detb_rtl_teller_rec.mis_head_3     := l_arc_maint.cod_mis_head2;
        pkg_detb_rtl_teller_rec.chg_desc2      := l_arc_maint.cod_chg_desc2;
        pkg_detb_rtl_teller_rec.chg_type2      := l_arc_maint.cod_chg_type2;
        pkg_detb_rtl_teller_rec.waiver2        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs2    := l_arc_maint.cod_their_chgs2;
      END IF;
    
      -- 4
      IF k = 4 THEN
        pkg_detb_rtl_teller_rec.chg_gl_3  := l_arc_maint.cod_chg_gl3;
        pkg_detb_rtl_teller_rec.chg_ccy_3 := l_arc_maint.cod_chg_ccy3;
        pkg_detb_rtl_teller_rec.chg_amt_3 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt3 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT3' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt3);
        depks_rtl_teller.pkg_arc_row.cod_chg_type3 := l_arc_maint.cod_chg_type3;
        IF l_arc_maint.cod_chg_ccy3 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy3,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_3,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_3       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_3 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_3   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_3 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_3  := l_arc_maint.cod_chg_netting3;
        pkg_detb_rtl_teller_rec.txn_code_3     := l_arc_maint.cod_chg_txn_code3;
        pkg_detb_rtl_teller_rec.mis_head_4     := l_arc_maint.cod_mis_head3;
        pkg_detb_rtl_teller_rec.chg_desc3      := l_arc_maint.cod_chg_desc3;
        pkg_detb_rtl_teller_rec.chg_type3      := l_arc_maint.cod_chg_type3;
        pkg_detb_rtl_teller_rec.waiver3        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs3    := l_arc_maint.cod_their_chgs3;
      END IF;
      -- 5
      IF k = 5 THEN
        pkg_detb_rtl_teller_rec.chg_gl_4  := l_arc_maint.cod_chg_gl4;
        pkg_detb_rtl_teller_rec.chg_ccy_4 := l_arc_maint.cod_chg_ccy4;
        pkg_detb_rtl_teller_rec.chg_amt_4 := p_ifdofast.v_iftbs_fast_charge(k)
                                             .chg_amt;
      
        depks_rtl_teller.pkg_arc_row.cod_chg_amt4 := p_ifdofast.v_iftbs_fast_charge(k)
                                                     .chg_amt;
      
        dbg('DEPKS_RTL_TELLER.PKG_ARC_ROW.COD_CHG_AMT4' ||
            depks_rtl_teller.pkg_arc_row.cod_chg_amt4);
        depks_rtl_teller.pkg_arc_row.cod_chg_type4 := l_arc_maint.cod_chg_type4;
        IF l_arc_maint.cod_chg_ccy4 <> l_cust_ac.ccy THEN
          IF NOT
              cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                     l_arc_maint.cod_chg_ccy4,
                                     l_cust_ac.ccy,
                                     l_prod.rate_type_preferred,
                                     l_prod.rate_code_preferred,
                                     p_ifdofast.v_iftbs_fast_charge(k).chg_amt,
                                     'Y',
                                     pkg_detb_rtl_teller_rec.chg_in_acy_4,
                                     pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4,
                                     p_err_params) THEN
            debug.pr_debug('**', 'In When Others of EX RATE.');
            debug.pr_debug('**', SQLERRM);
            p_err_code   := 'ST-OTHR-001';
            p_err_params := NULL;
            RETURN FALSE;
          END IF;
        ELSE
          pkg_detb_rtl_teller_rec.chg_in_acy_4       := p_ifdofast.v_iftbs_fast_charge(k)
                                                        .chg_amt;
          pkg_detb_rtl_teller_rec.chg_ccy_acy_rate_4 := 1;
        END IF;
      
        pkg_detb_rtl_teller_rec.chg_in_lcy_4   := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .lcy_chg;
        pkg_detb_rtl_teller_rec.acy_lcy_rate_4 := p_ifdofast.v_iftbs_fast_master.exch_rate;
        pkg_detb_rtl_teller_rec.netting_ind_4  := l_arc_maint.cod_chg_netting4;
        pkg_detb_rtl_teller_rec.txn_code_4     := l_arc_maint.cod_chg_txn_code4;
        pkg_detb_rtl_teller_rec.mis_head_5     := l_arc_maint.cod_mis_head4;
        pkg_detb_rtl_teller_rec.chg_desc4      := l_arc_maint.cod_chg_desc4;
        pkg_detb_rtl_teller_rec.chg_type4      := l_arc_maint.cod_chg_type4;
        pkg_detb_rtl_teller_rec.waiver4        := p_ifdofast.v_iftbs_fast_charge(k)
                                                  .waiver;
        pkg_detb_rtl_teller_rec.their_chgs4    := l_arc_maint.cod_their_chgs4;
      END IF;
    END LOOP;
    /* 
     PKG_DETB_RTL_TELLER_REC.their_acc :=
    PKG_DETB_RTL_TELLER_REC.their_acc1 := 
    PKG_DETB_RTL_TELLER_REC.their_acc2 := 
    PKG_DETB_RTL_TELLER_REC.their_acc3 := 
    PKG_DETB_RTL_TELLER_REC.their_acc4 := 
    PKG_DETB_RTL_TELLER_REC.lcy_exch_rate := 
    PKG_DETB_RTL_TELLER_REC.tot_chg_in_tcy :=     
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate := 
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate1 := 
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate2 := 
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate3 := 
    PKG_DETB_RTL_TELLER_REC.lcy_chg_exch_rate4 := 
    PKG_DETB_RTL_TELLER_REC.chg_contra_leg := 
    PKG_DETB_RTL_TELLER_REC.netting_reqd := */
    dbg('Calling depks_rtl_teller.fn_save');
  
    IF NOT depks_rtl_teller.fn_save(pkg_detb_rtl_teller_rec,
                                    p_err_code,
                                    p_err_params) THEN
      dbg('Failed in Fn_Save');
      RETURN FALSE;
    END IF;
    dbg('Calling depks_rtl_teller.pr_messaging');
    --depks_rtl_teller.pr_messaging;
  
    dbg('Returning Success From FN_SAVE..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_SAVE ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_save;

  FUNCTION fn_fast_out_msg_gen(p_ifdofast   IN OUT ifpks_ifdofast_main.ty_ifdofast,
                               p_msg        IN OUT CLOB,
                               p_err_code   IN OUT VARCHAR2,
                               p_err_params IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_xml_hdr_comp VARCHAR2(1000) := '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                                     <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.05" 
                                     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="xsd/pain.001.001.05.xsd"> ';
  
    l_xml_tag     CLOB;
    l_date        VARCHAR2(23);
    l_reqdexctndt VARCHAR2(23);
    l_gl_walkin   VARCHAR2(35);
    l_str1        VARCHAR2(10);
    l_date_ins    DATE;
    l_instr_id    VARCHAR2(35);
    l_etend_id    VARCHAR2(35);
  BEGIN
    dbg('In FN_FAST_OUT_MSG_GEN..');
    dbg('Start of pr_gen_pain_001_001_05');
    dbg('Message Identfication' || p_ifdofast.v_iftbs_fast_master.msg_id);
    l_date        := to_char(SYSDATE, 'YYYY-MM-DD') || 'T' ||
                     to_char(SYSDATE, 'hh24:MM:SS');
    l_reqdexctndt := to_char(SYSDATE, 'YYYY-MM-DD');
    l_str1        := substr(l_date, 1, 10);
    l_date_ins    := to_date(l_str1, 'YYYY-MM-DD');
    dbg('Date-->' || l_date);
    dbg('Date_INS-->' || l_date_ins);
  
    dbms_lob.createtemporary(l_xml_tag, cache => TRUE);
  
    /*SELECT cod_txn_account
      INTO l_gl_walkin
      FROM iftm_arc_maint
     WHERE cod_prod_acc_cls = p_ifdofast.v_iftbs_fast_master.product_code;
    
    dbg('l_GL_Walkin-->' || l_gl_walkin);*/
  
    l_xml_hdr_comp := l_xml_hdr_comp || chr(10) || '<CstmrCdtTrfInitn>' ||
                      chr(10);
    l_xml_hdr_comp := l_xml_hdr_comp || '<GrpHdr>' || chr(10);
  
    dbms_lob.append(l_xml_tag, l_xml_hdr_comp);
  
    dbg('Going to for loop');
  
    dbg('Msg_id-->' || p_ifdofast.v_iftbs_fast_master.msg_id);
    dbms_lob.append(l_xml_tag,
                    '<MsgId>' || p_ifdofast.v_iftbs_fast_master.msg_id ||
                    '</MsgId>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<CreDtTm>' || l_date || '</CreDtTm>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<NbOfTxs>' || '1' || '</NbOfTxs>' || chr(10));
  
    dbg('Total transfer amount-->' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);
    dbms_lob.append(l_xml_tag,
                    '<CtrlSum>' || p_ifdofast.v_iftbs_fast_master.txn_amt ||
                    '</CtrlSum>' || chr(10));
    dbms_lob.append(l_xml_tag,
                    '<InitgPty>' || chr(10) || '<Nm>' || 'Prince Bank PLC' ||
                    '</Nm>' || chr(10) || '</InitgPty>' || chr(10));
  
    dbms_lob.append(l_xml_tag, '</GrpHdr>' || chr(10));
  
    dbg('PAYMNT_IDENT_CODE -->' || p_ifdofast.v_iftbs_fast_master.pay_id); -- PAY_ID
  
    dbg('REQ_EXEC_DATE -->' || l_date);
  
    dbms_lob.append(l_xml_tag,
                    '<PmtInf>' || chr(10) || '<PmtInfId>' ||
                    p_ifdofast.v_iftbs_fast_master.pay_id || '</PmtInfId>' || -- PAY_ID
                    chr(10) || '<PmtMtd>' || 'TRF' || '</PmtMtd>' ||
                    chr(10) || '<BtchBookg>' || 'false' || '</BtchBookg>' ||
                    chr(10) || '<ReqdExctnDt>' || l_reqdexctndt ||
                    '</ReqdExctnDt>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<Dbtr>' || chr(10) || '<Nm>' ||
                    p_ifdofast.v_iftbs_fast_master.rem_name || '</Nm>' ||
                    chr(10) || '</Dbtr>' || chr(10));
  
    dbg('Account number  -->' || p_ifdofast.v_iftbs_fast_master.rem_acc);
  
    dbms_lob.append(l_xml_tag,
                    '<DbtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdofast.v_iftbs_fast_master.rem_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '<Ccy>' || p_ifdofast.v_iftbs_fast_master.txn_ccy ||
                    '</Ccy>' || chr(10) || '</DbtrAcct>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<DbtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' || 'PRINXXXX' || '</BICFI>' || chr(10) ||
                    '</FinInstnId>' || chr(10) || '</DbtrAgt>' || chr(10));
  
    dbg('p_ifdofast.v_iftbs_fast_master.etend_id' ||
        p_ifdofast.v_iftbs_fast_master.etend_id);
    dbg('p_ifdofast.v_iftbs_fast_master.instr_id' ||
        p_ifdofast.v_iftbs_fast_master.instr_id);
  
    SELECT instr_id, etend_id
      INTO l_instr_id, l_etend_id
      FROM iftb_fast_master
     WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
  
    dbms_lob.append(l_xml_tag,
                    '<CdtTrfTxInf>' || chr(10) || '<PmtId>' || chr(10) ||
                    '<InstrId>' ||
                    nvl(p_ifdofast.v_iftbs_fast_master.instr_id, l_instr_id) ||
                    '</InstrId>' || chr(10) || '<EndToEndId>' ||
                    nvl(p_ifdofast.v_iftbs_fast_master.etend_id, l_etend_id) ||
                    '</EndToEndId>' || chr(10) || '</PmtId>' || chr(10) ||
                    '<Amt>' || chr(10) || '<InstdAmt Ccy = "' ||
                    p_ifdofast.v_iftbs_fast_master.txn_ccy || '">' ||
                    p_ifdofast.v_iftbs_fast_master.txn_amt || '</InstdAmt>' ||
                    chr(10) || '</Amt>' || chr(10) || '<ChrgBr>' || 'CRED' ||
                    '</ChrgBr>' || chr(10));
  
    dbg('BEN_BIC  -->' || p_ifdofast.v_iftbs_fast_master.ben_bic);
  
    /*dbms_lob.append(l_xml_tag,
    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
    '<BICFI>' || 'ACLB' || 'XXXX' || '</BICFI>' || chr(10) ||
    '</FinInstnId>' || chr(10) || '</CdtrAgt>' || chr(10));*/
  
    dbms_lob.append(l_xml_tag,
                    '<CdtrAgt>' || chr(10) || '<FinInstnId>' || chr(10) ||
                    '<BICFI>' ||
                    SUBSTR(p_ifdofast.v_iftbs_fast_master.BEN_BIC, 1, 4) ||
                    'XXXX' || '</BICFI>' || chr(10) || '</FinInstnId>' ||
                    chr(10) || '</CdtrAgt>' || chr(10));
  
    dbg('BENEF_NAME  -->' || p_ifdofast.v_iftbs_fast_master.ben_name);
  
    dbms_lob.append(l_xml_tag,
                    '<Cdtr>' || chr(10) || '<Nm>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_name || '</Nm>' ||
                    chr(10) || '</Cdtr>' || chr(10));
  
    dbg('BEN_ACCOUNT  -->' || p_ifdofast.v_iftbs_fast_master.ben_acc);
  
    dbms_lob.append(l_xml_tag,
                    '<CdtrAcct>' || chr(10) || '<Id>' || chr(10) ||
                    '<Othr>' || chr(10) || '<Id>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_acc || '</Id>' ||
                    chr(10) || '</Othr>' || chr(10) || '</Id>' || chr(10) ||
                    '</CdtrAcct>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '<Purp>' || chr(10) || '<Cd>' || 'GDDS' || '</Cd>' ||
                    chr(10) || '</Purp>' || chr(10));
  
    dbg('DESCRIPTION  -->' || p_ifdofast.v_iftbs_fast_master.ben_remarks);
  
    dbms_lob.append(l_xml_tag,
                    '<RmtInf>' || chr(10) || '<Ustrd>' ||
                    p_ifdofast.v_iftbs_fast_master.ben_remarks || '/' ||
                    substr(p_ifdofast.v_iftbs_fast_master.pay_id, -8) ||
                    '</Ustrd>' || chr(10) || '<Strd>' || chr(10) ||
                    '<RfrdDocInf>' || chr(10) || '<Tp>' || chr(10) ||
                    '<CdOrPrtry>' || chr(10) || '<Cd>' || 'CINV' || '</Cd>' ||
                    chr(10) || '</CdOrPrtry>' || chr(10) || '</Tp>' ||
                    chr(10) || '<Nb>' || '987-AC' || '</Nb>' || chr(10) ||
                    '<RltdDt>' || to_char(SYSDATE, 'YYYY-MM-DD') ||
                    '</RltdDt>' || chr(10) || '</RfrdDocInf>' || chr(10) ||
                    '</Strd>' || chr(10) || '</RmtInf>' || chr(10));
  
    dbms_lob.append(l_xml_tag,
                    '</CdtTrfTxInf>' || chr(10) || '</PmtInf>' || chr(10));
    l_xml_tag := l_xml_tag || '</CstmrCdtTrfInitn>' || chr(10);
    l_xml_tag := l_xml_tag || '</Document>' || chr(10);
    dbg('Final message-->' || dbms_lob.substr(l_xml_tag, 32767, 1));
    p_msg := l_xml_tag;
    dbms_lob.freetemporary(l_xml_tag);
    dbg('Returning Success From FN_FAST_OUT_MSG_GEN..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.FN_FAST_OUT_MSG_GEN ..');
      debug.pr_debug('**', SQLERRM);
      dbms_lob.freetemporary(l_xml_tag);
      p_err_code   := 'IF-FAST-009';
      p_err_params := 'Can not generate pain_001.001.05';
      RETURN FALSE;
  END fn_fast_out_msg_gen;

  FUNCTION FN_FAST_HTTP_CALL(p_msg_type VARCHAR2,
                             p_out_msg  VARCHAR2,
                             p_in_resp  IN OUT CLOB) RETURN BOOLEAN IS
    l_http_request  utl_http.req;
    l_http_response utl_http.resp;
    l_buffer_size   NUMBER(10) := 512;
    l_substring_msg VARCHAR2(32767);
    l_raw_data      RAW(2000);
    l_clob_response CLOB;
    l_url           cstb_param.param_val%TYPE;
    l_resp_ok       BOOLEAN;
    l_resp_num      NUMBER;
  
  BEGIN
    dbg('In FN_FAST_HTTP_CALL');
    dbg(p_msg_type || '~' || length(p_out_msg));
    dbms_lob.createtemporary(lob_loc => l_clob_response, cache => TRUE);
  
    IF p_msg_type = 'F' THEN
      utl_http.set_transfer_timeout(get_param_val('PGW_OUT_FAST_TIMEOUT'));
      l_url := get_param_val('PGW_OUT_FAST_URL');
    
    END IF;
  
    dbg('l_url-->' || l_url);
    l_http_request := utl_http.begin_request(url          => l_url,
                                             method       => 'POST',
                                             http_version => 'HTTP/1.1');
    utl_http.set_header(l_http_request, 'User-Agent', 'Mozilla/4.0');
    utl_http.set_header(l_http_request, 'Connection', 'close');
    utl_http.set_header(l_http_request,
                        'Content-Type',
                        'text/xml; charset=utf-8');
    -- UTL_HTTP.set_header (l_http_request, 'Content-Length', lengthb(CONVERT(p_out_msg, 'UTF8')));
  
    utl_http.set_header(l_http_request,
                        'Content-Length',
                        length(p_out_msg));
    <<request_loop>>
  
    FOR i IN 0 .. ceil(length(p_out_msg) / l_buffer_size) - 1 LOOP
      l_substring_msg := substr(p_out_msg,
                                i * l_buffer_size + 1,
                                l_buffer_size);
      BEGIN
        l_raw_data := utl_raw.cast_to_raw(l_substring_msg);
        utl_http.write_raw(r => l_http_request, data => l_raw_data);
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Request Loop NDF');
          EXIT request_loop;
      END;
    END LOOP request_loop;
    l_http_response := utl_http.get_response(l_http_request);
    dbg('Response> status_code: "' || l_http_response.status_code || '"');
  
    l_resp_ok := FALSE;
    SELECT decode(l_http_response.status_code, 200, 1, 0)
      INTO l_resp_num
      FROM dual;
  
    IF l_resp_num = 1 THEN
      l_resp_ok := TRUE;
    ELSIF l_resp_num = 0 THEN
      l_resp_ok := FALSE;
    END IF;
  
    IF l_resp_ok THEN
      BEGIN
        <<response_loop>>
        LOOP
          utl_http.read_raw(l_http_response, l_raw_data, l_buffer_size);
          l_clob_response := l_clob_response ||
                             utl_raw.cast_to_varchar2(l_raw_data);
        END LOOP response_loop;
      EXCEPTION
        WHEN utl_http.end_of_body THEN
          utl_http.end_response(l_http_response);
        WHEN OTHERS THEN
          dbg('Inside Exception others in response');
          dbg(SQLERRM);
          dbg(dbms_utility.format_error_backtrace);
          utl_http.end_response(l_http_response);
      END;
      dbg('Out of Loop');
      --dbg('Length of response-->' || dbms_lob.getlength(l_clob_response));
      -- dbg('value of response-->' ||
      --    dbms_lob.substr(l_clob_response, 32767));
      p_in_resp := l_clob_response;
    
    END IF;
  
    IF l_http_request.private_hndl IS NOT NULL THEN
      utl_http.end_request(l_http_request);
    END IF;
  
    IF l_http_response.private_hndl IS NOT NULL THEN
      utl_http.end_response(l_http_response);
    END IF;
  
    dbms_lob.freetemporary(l_clob_response);
  
    IF l_resp_ok THEN
      dbg('OK_RETURN TRUE NOW');
      RETURN TRUE;
    ELSE
      dbg('PROBLEM...RETURN FALSE');
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...' || SQLERRM);
      RETURN FALSE;
  END FN_FAST_HTTP_CALL;

  FUNCTION fn_msg_upload(p_source      IN VARCHAR2,
                         p_function_id IN VARCHAR2,
                         p_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_msg         IN OUT CLOB,
                         p_err_code    IN OUT VARCHAR2,
                         p_err_params  IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    l_formatted_msg CLOB;
    l_pgw_uid       cstb_param_custom.param_val%TYPE;
    l_pgw_pwd       cstb_param_custom.param_val%TYPE;
    l_in_resp       CLOB;
    e_update_error EXCEPTION;
    l_txnstatus iftb_fast_master.txn_status%TYPE := get_param_val('PGW_TEMP_TXN_STAT');
    l_rejreason iftb_fast_master.txn_remarks%TYPE := get_param_val('PGW_TEMP_TXN_REMARKS');
    l_pos       NUMBER := 0;
    r_pos       NUMBER := 0;
  BEGIN
    dbg('Inside fn_msg_upload - inserting to iftbs_pgw_msgs');
  
    INSERT INTO iftbs_pgw_msgs
    VALUES
      (p_ifdofast.v_iftbs_fast_master.msg_id,
       p_ifdofast.v_iftbs_fast_master.trn_ref_no,
       p_ifdofast.v_iftbs_fast_master.transfer_mode,
       p_msg,
       NULL,
       csfn_timestamp,
       p_ifdofast.v_iftbs_fast_master.msg_flow,
       'G');
  
    dbg('Insert done');
    dbg('transfer mode' || p_ifdofast.v_iftbs_fast_master.transfer_mode);
  
    IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN
    
      l_formatted_msg := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
            <soapenv:Header/>
            <soapenv:Body>
               <fas:makeFullFundTransfer>
                  <cm_user_name>' ||
                         get_param_val('PGW_OUT_FAST_UID') ||
                         '</cm_user_name>
                  <cm_password>' ||
                         get_param_val('PGW_OUT_FAST_PWD') ||
                         '</cm_password>
                  <iso_message><![CDATA[' || p_msg ||
                         ']]></iso_message>
                  <import_file_name></import_file_name>
               </fas:makeFullFundTransfer>
            </soapenv:Body>
          </soapenv:Envelope>';
    
      dbg('l_formatted_msg for fast' || l_formatted_msg);
    
      IF NOT FN_FAST_HTTP_CALL('F', L_FORMATTED_MSG, L_IN_RESP) THEN
        DBG('failed to send pain_001_001_05');
        RAISE E_UPDATE_ERROR;
      END IF;
    
      DBG('Sent and response is ' || L_IN_RESP);
      L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&lt;', '<');
      DBG('One step done-->' || L_IN_RESP);
      L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&gt;', '>');
      DBG('Two step done and after UNESCAPE, it is ' || L_IN_RESP);
      L_POS := DBMS_LOB.INSTR(L_IN_RESP, '<return>', 1, 1);
      DBG('l_pos is ' || L_POS);
      R_POS := DBMS_LOB.INSTR(L_IN_RESP, '</return>', 1, 1);
      DBG('r_pos is ' || R_POS);
      L_IN_RESP := TRIM(DBMS_LOB.SUBSTR(L_IN_RESP,
                                        R_POS - L_POS - LENGTH('<return>'),
                                        L_POS + LENGTH('<return>')));
    
      DBG('After cutting other irrelevant parts , it is ' || L_IN_RESP);
    
      SELECT XT.TXSTS TXSTS, XT.REJREASON REJREASON
        INTO L_TXNSTATUS, L_REJREASON
        FROM XMLTABLE(XMLNAMESPACES(DEFAULT 'urn:iso:std:iso:20022:tech:xsd:pain.002.001.06'),
                      '/Document/CstmrPmtStsRpt' PASSING XMLTYPE(L_IN_RESP)
                      COLUMNS TXSTS VARCHAR2(23) PATH
                      'OrgnlPmtInfAndSts/TxInfAndSts/TxSts',
                      REJREASON VARCHAR2(20) PATH
                      'OrgnlPmtInfAndSts/TxInfAndSts/StsRsnInf/AddtlInf') XT;
      DBG('l_txnstatus is ' || L_TXNSTATUS);
      DBG('l_rejreason is ' || L_REJREASON); -- COMMENTED TEMPORARILY FOR OFFSHORE TESTING - ALL TXN TO GO AS ACCEPTED
    
    END IF; -- Based on msg type, calling the FUNCTION http call and processing the response accordingly
  
    IF l_txnstatus = 'RJCT' THEN
      dbg('Transaction Rejected. Cannot procede further.');
      /* p_err_code   := 'GI-FST-013';
      p_err_params := l_rejreason || '~';*/
    
      dbg('Need to DELETE any accounting entries fired UNAUTH since it is REJT from NBC-->' ||
          p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~' ||
          p_ifdofast.v_iftbs_fast_master.msg_id);
      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
      
        dbg('Fail in DELETE accounting entries');
        RAISE e_update_error;
      END IF;
    
      UPDATE iftb_fast_master
         SET txn_status = l_txnstatus, txn_remarks = l_rejreason
       WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      dbg('updated-->' || SQL%ROWCOUNT);
    
      pr_log_error(p_function_id,
                   p_source,
                   'IF-FST006',
                   l_txnstatus || '~' || l_rejreason);
    
    ELSE
    
      --Call getOutgoingTransaction API call   
      IF NOT fn_process_entries(p_ifdofast, 'A', p_err_code, p_err_params) THEN
        dbg('Fail in AUTH accounting entries');
        RAISE e_update_error;
      END IF;
    END IF;
  
    dbg('updated the status and reject reason to ALL transactions in the BATCH');
    UPDATE iftb_fast_master
       SET txn_status = l_txnstatus, txn_remarks = l_rejreason
     WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
    dbg('updated-->' || SQL%ROWCOUNT);
  
    pr_log_error(p_function_id,
                 p_source,
                 'IF-FST005',
                 l_txnstatus || '~' || l_rejreason);
  
    dbg('Successfully processed fn_msg_upload');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in fn_msg_upload' || SQLERRM);
      RETURN FALSE;
  END fn_msg_upload;

  -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
  FUNCTION fn_post_build_type_structure(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_addl_info        IN cspks_req_global.ty_addl_info,
                                        p_ifdofast         IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    dbg('In Fn_Post_Build_type_structure..');
  
    dbg('Returning Success From Fn_Post_Build_Type_Structure');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others Of ifpks_ifdofast_Custom.Fn_Post_Build_type_structure ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_build_type_structure;

  FUNCTION fn_pre_check_mandatory(p_source           IN VARCHAR2,
                                  p_source_operation IN VARCHAR2,
                                  p_function_id      IN VARCHAR2,
                                  p_action_code      IN VARCHAR2,
                                  p_child_function   IN VARCHAR2,
                                  p_ifdofast         IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                  p_err_code         IN OUT VARCHAR2,
                                  p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
    l_out_msg             CLOB;
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
  
  BEGIN
  
    dbg('In Fn_Pre_Check_Mandatory' || p_action_code);
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - START
  
    dbg('p_Action_Code' || p_action_code);
    IF p_action_code = 'PICKUP' THEN
      IF NOT fn_enrich_product(p_ifdofast, p_err_code, p_err_params) THEN
        dbg('Failed in Fn_Enrich_Product');
        RETURN FALSE;
      END IF;
    END IF;
  
    IF p_action_code = 'ENRICHCHG' THEN
    
      IF NOT fn_enrich_chg(p_ifdofast, p_err_code, p_err_params) THEN
        dbg('Failed in fn_enrich_chg');
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_call_stack);
        DBG('ERROR LINE NUMBER=' || DBMS_UTILITY.format_ERROR_stack);
      
        RETURN FALSE;
      END IF;
    END IF;
  
    --Get Outgoing Transaction by ID
    IF p_action_code = 'GETOUTTXNSTATUS' THEN
    
      dbg(' Message generation success, going to upload now');
      IF NOT FN_GET_OUTGOING_TXN_BY_ID(p_ifdofast,
                                       l_out_msg,
                                       p_err_code,
                                       p_err_params) THEN
        dbg('Failed in fn_msg_upload');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Save Transaction
    IF p_action_code = cspks_req_global.p_new THEN
      IF NOT fn_save(p_ifdofast,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in FN_SAVE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Modify Transaction
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('Voila 2');
    
      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in modify fn_delete');
        RETURN FALSE;
      END IF;
    
      IF NOT fn_save(p_ifdofast,
                     l_detb_rtl_teller_rec,
                     p_err_code,
                     p_err_params) THEN
        dbg('Failed in modify fn_save');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Delete Transaction
    IF p_action_code = cspks_req_global.p_delete THEN
      IF NOT depks_rtl_teller.fn_delete(p_ifdofast.v_iftbs_fast_master.trn_ref_no,
                                        p_err_code,
                                        p_err_params) THEN
        dbg('Failed in FN_DELETE');
        RETURN FALSE;
      END IF;
    END IF;
  
    --Auth Transaction
    IF p_action_code = cspks_req_global.p_auth THEN
    
      dbg('P_IFDOFAST.V_IFTBS_FAST_MASTER.TRANSFER_MODE ' ||
          p_ifdofast.v_iftbs_fast_master.transfer_mode);
    
      IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
        IF p_ifdofast.v_iftbs_fast_master.transfer_mode = 'F' THEN
          DBG('p_ifdofast.v_iftbs_fast_master.MAKER_ID=' ||
              p_ifdofast.v_iftbs_fast_master.MAKER_ID);
          DBG('p_ifdofast.v_iftbs_fast_master.CHECKER_ID=' ||
              p_ifdofast.v_iftbs_fast_master.CHECKER_ID);
          DBG('GLOBAL.USER_ID' || GLOBAL.USER_ID);
          --Maker Can not authorize
          IF p_ifdofast.v_iftbs_fast_master.MAKER_ID = GLOBAL.USER_ID THEN
            pr_log_error(p_function_id, p_source, 'CF-AUT-002', NULL);
            RETURN FALSE;
          END IF;
          --Generate Fast Outgoing message
          IF NOT fn_fast_out_msg_gen(p_ifdofast,
                                     l_out_msg,
                                     p_err_code,
                                     p_err_params) THEN
            dbg('Failed in FN_FAST_OUT_MSG_GEN');
            RETURN FALSE;
          END IF;
        
        END IF;
      
        dbg(' Message generation success, going to upload now');
        IF NOT fn_msg_upload(p_source,
                             p_function_id,
                             p_ifdofast,
                             l_out_msg,
                             p_err_code,
                             p_err_params) THEN
          dbg('Failed in fn_msg_upload');
          RETURN FALSE;
        END IF;
        dbg('fn_msg_upload successful');
      END IF;
      dbg('Done with upload process, going to generate advice');
      --depks_rtl_teller.pr_gen_adv_for_contract(p_ifdofast.v_iftbs_fast_master.trn_ref_no);
      dbg('Done with advice generation ');
    END IF;
    -- PRINCE 12.4 FAST CUSTOMIZATION CHANGES - END
    dbg('Returning Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION fn_post_check_mandatory(p_source           IN VARCHAR2,
                                   p_source_operation IN VARCHAR2,
                                   p_function_id      IN VARCHAR2,
                                   p_action_code      IN VARCHAR2,
                                   p_child_function   IN VARCHAR2,
                                   p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                   p_err_code         IN OUT VARCHAR2,
                                   p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    dbg('In Fn_Post_Check_Mandatory..');
  
    dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_check_mandatory;

  FUNCTION fn_pre_default_and_validate(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_child_function   IN VARCHAR2,
                                       p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                       p_prev_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                       p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_result       NUMBER(2);
    l_lcl_ben_name sttm_customer.customer_name1%TYPE;
    l_cust_name    sttm_customer.customer_name1%TYPE;
    l_match        VARCHAR2(1) := 'N';
  BEGIN
  
    dbg('In Fn_Pre_Default_And_Validate..' || p_action_code);
    dbg('p_ifdofast.v_iftbs_fast_master.transfer_mode' ||
        p_ifdofast.v_iftbs_fast_master.transfer_mode);
  
    IF p_action_code = cspks_req_global.p_modify THEN
      dbg('p_prev_ifdofast.v_iftbs_fast_master.maker_id' ||
          p_prev_ifdofast.v_iftbs_fast_master.maker_id);
      dbg('p_prev_ifdofast.v_iftbs_fast_master.auth_stat' ||
          p_prev_ifdofast.v_iftbs_fast_master.auth_stat);
    
      IF p_prev_ifdofast.v_iftbs_fast_master.auth_stat = 'U' AND
         p_prev_ifdofast.v_iftbs_fast_master.maker_id != global.user_id THEN
        pr_log_error(p_function_id, p_source, 'IA-ONL-016', NULL);
      END IF;
    END IF;
  
    -- only alpha numeric for fast & local
    IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_modify) AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode IN ('F') AND
       p_ifdofast.v_iftbs_fast_master.msg_flow = 'O' THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_name,
                                        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Name is not alpha numeric');
        pr_log_error(p_function_id, p_source, 'IF-FST003', NULL);
      END IF;
    
      IF (p_ifdofast.v_iftbs_fast_master.ben_acc IS NULL OR
         p_ifdofast.v_iftbs_fast_master.ben_name IS NULL OR
         p_ifdofast.v_iftbs_fast_master.ben_bic IS NULL) THEN
        dbg('Ben Acc, Ben Name, Ben Bic is mandatory for FAST Payment');
        pr_log_error(p_function_id, p_source, 'IF-FST010', NULL);
      END IF;
    
    END IF;
  
    -- generic vals
    IF p_ifdofast.v_iftbs_fast_master.txn_amt < 0 THEN
      dbg('Txn Amount cannot be negative');
      pr_log_error(p_function_id, p_source, 'IF-FST012', NULL);
    END IF;
  
    IF p_ifdofast.v_iftbs_fast_master.ben_phone IS NOT NULL THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_phone,
                                        '0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Phone is not numeric');
        pr_log_error(p_function_id, p_source, 'IF-FST013', NULL);
      END IF;
    END IF;
  
    IF p_ifdofast.v_iftbs_fast_master.transfer_mode IN ('F') AND
       p_ifdofast.v_iftbs_fast_master.ben_acc IS NOT NULL THEN
      l_result := length(TRIM(translate(p_ifdofast.v_iftbs_fast_master.ben_acc,
                                        '0123456789',
                                        ' ')));
      IF l_result > 0 THEN
        dbg('Ben Account is not numeric for FAST Payments');
        pr_log_error(p_function_id, p_source, 'IF-FST015', NULL);
      END IF;
    END IF;
  
    -- local ben name validation  
    IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_modify) AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' AND
       p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' THEN
      dbg('In here for ben name validation' ||
          p_ifdofast.v_iftbs_fast_master.ben_name);
    
      l_lcl_ben_name := p_ifdofast.v_iftbs_fast_master.ben_name;
    
      SELECT customer_name1
        INTO l_cust_name
        FROM sttm_customer, sttm_cust_account
       WHERE customer_no = cust_no
         AND cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;
    
      IF upper(l_lcl_ben_name) = upper(l_cust_name) THEN
        dbg('1st step matched');
        l_match := 'Y';
      ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                'LTD|LIMITED|CO|INC|LNC',
                                '')) = upper(l_cust_name) THEN
        dbg('2nd step matched');
        l_match := 'Y';
      END IF;
      IF l_match = 'N' THEN
        pr_log_error(p_function_id,
                     p_source,
                     'IF-FST004',
                     l_lcl_ben_name || '~' || l_cust_name);
      END IF;
    
    END IF;
  
    dbg('Returning Success From fn_pre_default_and_validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_default_and_validate;

  FUNCTION fn_post_default_and_validate(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                                        p_prev_ifdofast    IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    dbg('In Fn_Post_Default_And_Validate..');
  
    dbg('Returning Success From Fn_Post_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_default_and_validate;

  FUNCTION fn_pre_upload_db(p_source           IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_child_function   IN VARCHAR2,
                            p_post_upl_stat    IN VARCHAR2,
                            p_multi_trip_id    IN VARCHAR2,
                            p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                            p_prev_ifdofast    IN ifpks_ifdofast_main.ty_ifdofast,
                            p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    L_KEY_ID varchar2(1000);
  BEGIN
  
    dbg('In Fn_Pre_Upload_Db..');
  
    dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_upload_db;

  FUNCTION fn_post_upload_db(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_child_function   IN VARCHAR2,
                             p_post_upl_stat    IN VARCHAR2,
                             p_multi_trip_id    IN VARCHAR2,
                             p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                             p_prev_ifdofast    IN ifpks_ifdofast_main.ty_ifdofast,
                             p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_ovd_cnt             NUMBER(1) := 0;
    l_auto_auth           VARCHAR2(1) := 'N';
    l_usd_txn_amt         NUMBER(22, 3);
    l_rate                NUMBER;
    l_prod                cstm_product%ROWTYPE;
    l_ifdofast            ifpks_ifdofast_main.ty_ifdofast;
    l_lcl_ben_name        sttm_customer.customer_name1%TYPE;
    l_cust_name           sttm_customer.customer_name1%TYPE;
    l_match               VARCHAR2(1) := 'N';
    l_detb_rtl_teller_rec detb_rtl_teller%ROWTYPE;
  BEGIN
  
    dbg('In Fn_Post_Upload_Db..');
  
    dbg('Checking for Local Auto Auth.' ||
        p_ifdofast.v_iftbs_fast_master.msg_flow || '~' ||
        p_ifdofast.v_iftbs_fast_master.transfer_mode || '~' ||
        p_ifdofast.v_iftbs_fast_master.trn_ref_no || '~' ||
        p_ifdofast.v_iftbs_fast_master.txn_ccy || '~' ||
        p_ifdofast.v_iftbs_fast_master.txn_amt);
  
    SELECT x.*
      INTO l_prod
      FROM cstm_product x
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code;
  
    IF p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' AND
       p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' THEN
      dbg('In here USD Limit is' || get_param_val('PGW_IN_LCL_USD_LIMIT'));
      IF p_ifdofast.v_iftbs_fast_master.txn_ccy = 'USD' THEN
        IF p_ifdofast.v_iftbs_fast_master.txn_amt <=
           get_param_val('PGW_IN_LCL_USD_LIMIT') THEN
          l_auto_auth := 'Y';
        END IF;
      ELSE
        IF NOT cypkss.fn_amt1_to_amt2(p_ifdofast.v_iftbs_fast_master.branch_code,
                                      p_ifdofast.v_iftbs_fast_master.txn_ccy,
                                      'USD',
                                      l_prod.rate_type_preferred,
                                      l_prod.rate_code_preferred,
                                      p_ifdofast.v_iftbs_fast_master.txn_amt,
                                      'Y',
                                      l_usd_txn_amt,
                                      l_rate,
                                      p_err_params) THEN
          debug.pr_debug('**', 'In When Others of EX RATE.');
          debug.pr_debug('**', SQLERRM);
          p_err_code   := 'ST-OTHR-001';
          p_err_params := NULL;
          RETURN FALSE;
        END IF;
      
        dbg('in here l_usd_txn_amt' || l_usd_txn_amt);
        IF l_usd_txn_amt <= get_param_val('PGW_IN_LCL_USD_LIMIT') THEN
          l_auto_auth := 'Y';
        END IF;
      END IF;
    
      /*BEGIN
        SELECT COUNT(1)
          INTO l_ovd_cnt
          FROM sttb_record_log t1, cstb_request_ovd_details t2
         WHERE t1.msg_id = t2.msg_id
           AND t1.key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%'
           AND t2.error_code = 'IF-FST004';
      EXCEPTION
        WHEN no_data_found THEN
          dbg('In no data found');
          l_ovd_cnt := 0;
        WHEN OTHERS THEN
          dbg('In when others');
          l_ovd_cnt := 0;
      END;
      dbg('l_ovd_cnt' || l_ovd_cnt);*/
    
      -- local ben name validation  
      IF p_action_code IN
         (cspks_req_global.p_new, cspks_req_global.p_modify) AND
         p_ifdofast.v_iftbs_fast_master.transfer_mode = 'L' AND
         p_ifdofast.v_iftbs_fast_master.msg_flow = 'I' THEN
        dbg('In here for ben name validation' ||
            p_ifdofast.v_iftbs_fast_master.ben_name);
      
        l_lcl_ben_name := p_ifdofast.v_iftbs_fast_master.ben_name;
      
        SELECT customer_name1
          INTO l_cust_name
          FROM sttm_customer, sttm_cust_account
         WHERE customer_no = cust_no
           AND cust_ac_no = p_ifdofast.v_iftbs_fast_master.ben_acc;
      
        IF upper(l_lcl_ben_name) = upper(l_cust_name) THEN
          dbg('1st step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) = upper(l_cust_name) THEN
          dbg('2nd step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_cust_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) = upper(l_lcl_ben_name) THEN
          dbg('3rd step matched');
          l_match := 'Y';
        ELSIF TRIM(regexp_replace(upper(l_lcl_ben_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) =
              TRIM(regexp_replace(upper(l_cust_name),
                                  'LTD|LIMITED|CO|INC|LNC',
                                  '')) THEN
          dbg('4th step matched');
          l_match := 'Y';
        END IF;
      
        IF l_match = 'N' THEN
          ovpkss.pr_appendtbl('IF-FST004',
                              l_lcl_ben_name || '~' || l_cust_name || '~');
        END IF;
      
      END IF;
    
      IF l_match = 'Y' AND l_auto_auth = 'Y' THEN
        dbg('going to do auto auth');
        UPDATE iftb_fast_master
           SET auth_stat        = 'A',
               once_auth        = 'Y',
               checker_id       = global.user_id,
               checker_dt_stamp = csfn_timestamp,
               mod_no           = 1
         WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      
        UPDATE detb_rtl_teller
           SET auth_stat        = 'A',
               checker_id       = global.user_id,
               checker_dt_stamp = csfn_timestamp,
               record_stat      = decode(record_stat, 'O', 'A', record_stat),
               mod_no           = 1
         WHERE trn_ref_no = p_ifdofast.v_iftbs_fast_master.trn_ref_no;
      
        UPDATE sttb_record_log
           SET auth_stat              = 'A',
               checker_id             = global.user_id,
               checker_dt_stamp       = csfn_timestamp,
               first_auth_stat        = 'A',
               first_checker_id       = global.user_id,
               first_checker_dt_stamp = csfn_timestamp
         WHERE function_id = 'IFDOFAST'
           AND key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%';
      
        UPDATE sttb_record_master
           SET auth_stat              = 'A',
               checker_id             = global.user_id,
               checker_dt_stamp       = csfn_timestamp,
               first_auth_stat        = 'A',
               first_checker_id       = global.user_id,
               first_checker_dt_stamp = csfn_timestamp,
               latest_auth_mod_no     = 1
         WHERE function_id = 'IFDOFAST'
           AND key_id LIKE
               '%' || p_ifdofast.v_iftbs_fast_master.trn_ref_no || '%';
      
        l_ifdofast := p_ifdofast;
        IF NOT fn_process_entries(l_ifdofast, 'A', p_err_code, p_err_params) THEN
          dbg('Fail in AUTH accounting entries');
          RETURN FALSE;
        END IF;
      
      END IF;
    END IF;
    dbg('Out of Auto AUTH for Local Payment');
  
    dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Post_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_upload_db;

  FUNCTION fn_pre_query(p_source           IN VARCHAR2,
                        p_source_operation IN VARCHAR2,
                        p_function_id      IN VARCHAR2,
                        p_action_code      IN VARCHAR2,
                        p_child_function   IN VARCHAR2,
                        p_full_data        IN VARCHAR2 DEFAULT 'Y',
                        p_with_lock        IN VARCHAR2 DEFAULT 'N',
                        p_qrydata_reqd     IN VARCHAR2,
                        p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                        p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                        p_err_code         IN OUT VARCHAR2,
                        p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of ifpks_ifdofast_Custom.Fn_Pre_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_query;

  FUNCTION fn_post_query(p_source           IN VARCHAR2,
                         p_source_operation IN VARCHAR2,
                         p_function_id      IN VARCHAR2,
                         p_action_code      IN VARCHAR2,
                         p_child_function   IN VARCHAR2,
                         p_full_data        IN VARCHAR2 DEFAULT 'Y',
                         p_with_lock        IN VARCHAR2 DEFAULT 'N',
                         p_qrydata_reqd     IN VARCHAR2,
                         p_ifdofast         IN ifpks_ifdofast_main.ty_ifdofast,
                         p_wrk_ifdofast     IN OUT ifpks_ifdofast_main.ty_ifdofast,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  
    L_csvw_retail_charge_details csvw_retail_charge_details%ROWTYPE;
  
  BEGIN
  
    dbg('In Fn_Post_Query..=' || p_action_code);
  
    dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When others of ifpks_ifdofast_Custom.Fn_Post_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_query;

  FUNCTION FN_GET_OUTGOING_TXN_BY_ID(p_ifdofast        IN OUT ifpks_ifdofast_main.ty_ifdofast,
                                     P_PAYER_PART_CODE IN VARCHAR2,
                                     p_err_code        IN OUT VARCHAR2,
                                     p_err_params      IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_bank_code     cstm_arc_settle.route_code%TYPE;
    l_reference_no  VARCHAR2(100);
    l_formatted_msg CLOB;
    l_in_resp       CLOB;
    e_update_error EXCEPTION;
    l_pos       NUMBER := 0;
    r_pos       NUMBER := 0;
    l_txnstatus iftb_fast_master.txn_status%TYPE := get_param_val('PGW_TEMP_TXN_STAT');
    L_TXNREASON iftb_fast_master.txn_remarks%TYPE := get_param_val('PGW_TEMP_TXN_REMARKS');
  BEGIN
    DBG('************START OF FN_GET_OUTGOING_TXN_BY_ID*********');
    --Get Participant Code
  
    SELECT route_code
      into l_bank_code
      FROM cstm_arc_settle
     WHERE product_code = p_ifdofast.v_iftbs_fast_master.product_code
       AND auth_stat = 'A'
       AND record_stat = 'O';
  
    --Get reference no
  
    l_reference_no := SUBSTR(p_ifdofast.v_iftbs_fast_master.msg_id, -5);
  
    l_formatted_msg := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:fas="http://fastwebservice.nbc.org.kh/">
            <soapenv:Header/>
            <soapenv:Body>
               <fas:getOutgoingTransactionByPmtInfId>
                  <cm_user_name>' ||
                       get_param_val('PGW_OUT_FAST_UID') ||
                       '</cm_user_name>
                  <cm_password>' ||
                       get_param_val('PGW_OUT_FAST_PWD') ||
                       '</cm_password>
                  <payer_participant_code>' ||
                       l_bank_code || '</payer_participant_code>

                  <instruction_ref>' ||
                       l_reference_no || '</instruction_ref>
               </fas:getOutgoingTransactionByPmtInfId>
            </soapenv:Body>
          </soapenv:Envelope>';
  
    dbg('l_formatted_msg for fast' || l_formatted_msg);
  
    IF NOT FN_FAST_HTTP_CALL('F', L_FORMATTED_MSG, L_IN_RESP) THEN
      DBG('failed to send pain_001_001_05');
      RAISE E_UPDATE_ERROR;
    END IF;
  
    DBG('Sent and response is ' || L_IN_RESP);
    L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&lt;', '<');
    DBG('One step done-->' || L_IN_RESP);
    L_IN_RESP := FN_CLOBREPLACE(L_IN_RESP, '&gt;', '>');
    DBG('Two step done and after UNESCAPE, it is ' || L_IN_RESP);
    L_POS := DBMS_LOB.INSTR(L_IN_RESP, '<return>', 1, 1);
    DBG('l_pos is ' || L_POS);
    R_POS := DBMS_LOB.INSTR(L_IN_RESP, '</return>', 1, 1);
    DBG('r_pos is ' || R_POS);
    L_IN_RESP := TRIM(DBMS_LOB.SUBSTR(L_IN_RESP,
                                      R_POS - L_POS - LENGTH('<return>'),
                                      L_POS + LENGTH('<return>')));
  
    DBG('After cutting other irrelevant parts , it is ' || L_IN_RESP);
  
    SELECT XT.Ustrd TXSTS, XT.TXNREASON TXNREASON
      INTO L_TXNSTATUS, L_TXNREASON
      FROM XMLTABLE(XMLNAMESPACES(DEFAULT 'urn:iso:std:iso:20022:tech:xsd:pain.001.001.05'),
                    '/Document/CstmrCdtTrfInitn' PASSING XMLTYPE(L_IN_RESP)
                    COLUMNS Ustrd VARCHAR2(23) PATH
                    'PmtInf/CdtTrfTxInf/RmtInf/Ustrd',
                    TXNREASON VARCHAR2(20) PATH
                    'PmtInf/CdtTrfTxInf/RmtInf/Strd/AddtlRmtInf') XT;
    DBG('L_TXNSTATUS is ' || L_TXNSTATUS);
    DBG('L_TXNREASON is ' || L_TXNREASON);
  
    IF L_TXNSTATUS = 'RCFI' THEN
    
      p_ifdofast.v_iftbs_fast_master.TXN_STATUS  := L_TXNSTATUS;
      p_ifdofast.v_iftbs_fast_master.TXN_REMARKS := 'Received but no ack';
    
    END IF;
  
    dbg('Successfully processed FN_GET_OUTGOING_TXN_BY_ID');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      dbg('In WOT...Return false now...failed in FN_GET_OUTGOING_TXN_BY_ID' ||
          SQLERRM);
      RETURN FALSE;
    
  END FN_GET_OUTGOING_TXN_BY_ID;

END ifpks_ifdofast_custom;
